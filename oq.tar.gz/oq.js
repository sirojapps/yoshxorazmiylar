/* Yosh Xorazmiylar — o'quvchi kabineti (oq.js) */
(function(){
if(window.OQ)return;
const BASE='/oq/';
const IMG=new Proxy({},{get:(t,k)=>BASE+String(k)+'.webp'});
let HOST,ROOT,S,READY=new Set(),SAVED='',saveT=null,SID=0;
const CSS=":host{all:initial}\n*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}\n\n:root{--navy:#0f1f5c;--ink:#1e2a55;--muted:#5b6788;--blue:#1f6fff;--blue2:#2f8bff;--blue-d:#0b3a9e;--line:#e3eaf7;--good:#1fa34a;--good-soft:#e2f7e8;--wrong:#d63b4a;--wrong-soft:#fde4e7;--gold:#f5b400;--card:#fff;color-scheme:light}\n.wrap{margin:0;min-height:100vh;font-family:\"Golos Text\",system-ui,-apple-system,\"Segoe UI\",Roboto,sans-serif;color:var(--ink);background:linear-gradient(180deg,#dfe9ff 0%,#eef3ff 45%,#f3f0ff 100%);background-attachment:fixed}\n:where(.wrap) button{font:inherit;color:inherit;border:0;background:none;cursor:pointer;padding:0}\n.app{max-width:520px;margin:0 auto;min-height:100vh;position:relative;padding-bottom:96px}\n/* top bars */\n.hbar{background:linear-gradient(180deg,#0a2f86 0%,#1450c8 100%);color:#fff;padding:14px 16px 16px;display:flex;align-items:center;gap:10px;border-radius:0 0 22px 22px}\n.hbar .t{flex:1;text-align:center;font-size:22px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:8px}\n.hbar .t img{width:36px;height:36px;border-radius:50%;object-fit:contain}\n.hbtn{width:38px;height:38px;display:grid;place-items:center;color:#fff}\n.hbtn svg{width:26px;height:26px}\n.home-h{display:flex;align-items:center;gap:10px;padding:14px 16px 12px;background:linear-gradient(180deg,#0a2f86 0%,#1450c8 100%);color:#fff}\n.home-h .lg{width:44px;height:36px;display:grid;place-items:center}\n.home-h .nm{flex:1;line-height:1.1}.home-h .nm b{font-size:19px}.home-h .nm small{display:block;font-size:11.5px;opacity:.9}\n.bell{position:relative;width:36px;height:36px;display:grid;place-items:center}\n.bell svg{width:26px;height:26px}\n.bell i{position:absolute;top:0;right:0;background:#ff3b4e;color:#fff;font-style:normal;font-size:11px;font-weight:700;min-width:18px;height:18px;border-radius:9px;display:grid;place-items:center;border:2px solid #1450c8}\n.ava{width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,#ffcf5a,#ff8a3d);color:#fff;font-weight:800;display:grid;place-items:center;border:2px solid #fff}\n.pad{padding:14px 14px 0}\n.card{background:var(--card);border-radius:20px;box-shadow:0 4px 18px rgba(31,80,200,.10);border:1px solid #edf2ff}\n/* banner */\n.banner{border-radius:20px;overflow:hidden;background:#fff;box-shadow:0 6px 22px rgba(20,70,190,.18)}\n.banner img{display:block;width:100%;height:auto}\n.greet{padding:12px 16px 14px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:linear-gradient(90deg,#1450c8,#2f8bff);color:#fff}\n.greet b{font-size:21px;flex:1;min-width:200px}\n.ypill{background:#ffd84a;color:#2a2200;font-weight:700;font-size:13px;padding:5px 12px;border-radius:999px;box-shadow:0 2px 0 rgba(0,0,0,.08)}\n/* tiles */\n.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:14px}\n.tile{border-radius:18px;padding:10px 4px 10px;display:flex;flex-direction:column;align-items:center;gap:6px;font-weight:700;font-size:14.5px;color:var(--navy);border:1px solid rgba(255,255,255,.8);box-shadow:0 4px 12px rgba(31,80,200,.10)}\n.tile img{width:50px;height:50px;object-fit:contain;border-radius:50%}\n.tile.b{background:linear-gradient(180deg,#e7f0ff,#d6e6ff)}.tile.g{background:linear-gradient(180deg,#e6f8e8,#d2f0d6)}.tile.p{background:linear-gradient(180deg,#ffe8ef,#ffd6e2)}.tile.o{background:linear-gradient(180deg,#fff1dc,#ffe2b8)}\n/* sections */\n.sec{margin-top:14px;padding:14px 16px}\n.sec-h{display:flex;align-items:center;gap:10px;margin-bottom:10px}\n.sec-h b{flex:1;font-size:19px;color:var(--navy)}\n.sec-h .c{font-weight:800;color:var(--navy)}\n.sec-h svg.ch{width:20px;height:20px;color:var(--blue)}\n.sec-h .ico{width:28px;height:28px;color:var(--blue)}\n.chk{display:flex;align-items:center;gap:12px;padding:6px 0;font-size:16px;width:100%;text-align:left}\n.cb{width:24px;height:24px;border-radius:50%;border:2.5px solid #9fb0d4;flex:none;display:grid;place-items:center}\n.cb.on{background:var(--good);border-color:var(--good)}\n.cb.on::after{content:\"\";width:6px;height:11px;border:solid #fff;border-width:0 3px 3px 0;transform:translateY(-1px) rotate(45deg)}\n.path{display:flex;align-items:flex-start;position:relative;padding-top:4px}\n.path::before{content:\"\";position:absolute;left:16%;right:16%;top:21px;height:5px;border-radius:3px;background:linear-gradient(90deg,var(--good) 0 50%,#b9cdf5 50%)}\n.step{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;position:relative;z-index:1}\n.dot{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;color:#fff;border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.15)}\n.dot svg{width:18px;height:18px}\n.dot.d{background:var(--good)}.dot.c{background:var(--blue)}.dot.l{background:#7d8aa8}\n.step>span:last-child{font-weight:700;font-size:14px;padding:6px 10px;border-radius:12px;text-align:center}\n.step.d>span:last-child{background:#e2f7e8}.step.c>span:last-child{background:#dfeaff}.step.l>span:last-child{background:#eef1f7;color:#4b5675}\n/* segmented */\n.seg{display:flex;background:#fff;border-radius:18px;padding:4px;box-shadow:0 3px 12px rgba(31,80,200,.12);gap:4px}\n.seg button{flex:1;padding:10px 6px;border-radius:14px;font-weight:600;font-size:15px;color:var(--navy)}\n.seg button.on{background:linear-gradient(180deg,#2f8bff,#1450c8);color:#fff;box-shadow:0 3px 8px rgba(20,80,200,.35)}\n.sel{margin-top:10px;display:flex;align-items:center;background:#fff;border-radius:16px;padding:0 14px;box-shadow:0 3px 12px rgba(31,80,200,.10);position:relative}\n.sel select{appearance:none;-webkit-appearance:none;border:0;background:transparent;font:inherit;font-weight:700;color:var(--navy);padding:13px 0;flex:1;font-size:16px;outline:none}\n.sel svg{width:20px;height:20px;color:var(--navy);pointer-events:none}\n/* list rows */\n.row{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-top:10px;width:100%;text-align:left;border-radius:18px;background:linear-gradient(180deg,#fff,#f7f9ff);box-shadow:0 3px 12px rgba(31,80,200,.10);border:1px solid #edf2ff}\n.row.pk{background:linear-gradient(180deg,#fbf3ff,#f6eefe)}\n.row img.gi{width:58px;height:54px;object-fit:contain;flex:none}\n.row img.ti{width:44px;height:44px;object-fit:contain;flex:none}\n.row .m{flex:1;min-width:0}\n.row .m b{display:block;font-size:17px;color:var(--navy);line-height:1.2}\n.row .m small{display:block;font-size:14px;color:#33406a;margin-top:3px}\n.badge{display:inline-flex;align-items:center;gap:6px;font-weight:800;font-size:15px;padding:5px 10px;border-radius:999px;flex:none}\n.badge.ok{background:var(--good-soft);color:#13341f}\n.ck{width:22px;height:22px;border-radius:50%;background:var(--good);display:grid;place-items:center}\n.ck::after{content:\"\";width:5px;height:10px;border:solid #fff;border-width:0 2.5px 2.5px 0;transform:translateY(-1px) rotate(45deg)}\n.ring{width:26px;height:26px;border-radius:50%;flex:none;display:grid;place-items:center}\n.ring::after{content:\"\";width:16px;height:16px;border-radius:50%;background:#fff}\n.badge.pr{background:#f1f4fb;color:var(--navy)}\n.lock{width:44px;height:44px;border-radius:50%;background:linear-gradient(180deg,#e9edf5,#cfd6e4);display:grid;place-items:center;flex:none;color:#4a5878}\n.lock svg{width:22px;height:22px}\n.playc{width:44px;height:44px;border-radius:50%;background:linear-gradient(180deg,#2f8bff,#1450c8);display:grid;place-items:center;color:#fff;flex:none;box-shadow:0 3px 8px rgba(20,80,200,.35)}\n.playc svg{width:20px;height:20px;margin-left:3px}\n.row.locked{opacity:.92}\n/* lesson */\n.player{border-radius:18px;overflow:hidden;position:relative;background:linear-gradient(160deg,#2c5b49,#1f4537);aspect-ratio:16/10;box-shadow:0 6px 18px rgba(0,0,0,.18);display:flex}\n.player .tc{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}\n.player .bt{position:absolute;left:36%;right:6%;top:12%;color:#f4f7f2;font-size:22px;font-weight:600;padding:0;display:flex;align-items:flex-start;justify-content:center;text-align:center;line-height:1.25;font-family:\"Comic Sans MS\",\"Golos Text\",sans-serif}\n.player .pb{position:absolute;left:66%;top:56%;transform:translate(-50%,-50%);width:64px;height:64px;border-radius:50%;border:3px solid #fff;background:rgba(0,0,0,.25);display:grid;place-items:center;color:#fff}\n.player .pb svg{width:28px;height:28px;margin-left:4px}\n.player .ctl{position:absolute;left:0;right:0;bottom:0;padding:8px 12px;background:linear-gradient(0deg,rgba(0,0,0,.6),transparent);color:#fff;display:flex;align-items:center;gap:10px;font-size:13px;font-weight:600}\n.player .ctl .bar{flex:1;height:5px;border-radius:3px;background:rgba(255,255,255,.35);position:relative}\n.player .ctl .bar i{position:absolute;left:0;top:0;bottom:0;border-radius:3px;background:#2fd6b4}\n.lt{font-size:22px;font-weight:800;color:var(--navy);margin:16px 2px 8px}\n.li{display:flex;gap:12px;align-items:flex-start;margin:12px 0}\n.li img{width:46px;height:46px;object-fit:contain;flex:none}\n.li b{display:block;font-size:17px;color:var(--navy)}\n.li span{font-size:15.5px;color:#26325c}\n.cta{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:16px;border-radius:999px;background:linear-gradient(180deg,#2f8bff,#1450c8);color:#fff;font-weight:700;font-size:18px;box-shadow:0 6px 14px rgba(20,80,200,.35);margin-top:16px}\n.cta svg{width:22px;height:22px}\n.cta.ghost{background:#fff;color:var(--blue);box-shadow:0 3px 10px rgba(31,80,200,.15)}\n.ex{padding:14px;margin-top:10px}\n.ex .q{font-size:20px;font-weight:700;color:var(--navy)}\n.ex .s{margin-top:6px;color:#33406a;font-size:15px}\n/* practice */\n.qhead{padding:12px 16px;text-align:center}\n.qhead b{font-size:18px;color:var(--navy)}\n.pbar{height:12px;border-radius:7px;background:#dbe5f6;margin-top:8px;overflow:hidden}\n.pbar i{display:block;height:100%;border-radius:7px;background:linear-gradient(90deg,#27b33e,#45d35a);transition:width .4s}\n.qcard{margin-top:12px;padding:14px;background:linear-gradient(180deg,#eaf1ff,#f6f9ff)}\n.qcard .lb{font-size:19px;font-weight:700;color:var(--navy);margin:4px 4px 10px}\n.qcard .ex2{background:#fff;border-radius:16px;padding:18px 12px;text-align:center;font-size:34px;font-weight:800;color:var(--navy);line-height:1.25;box-shadow:inset 0 0 0 1px #e6ecf8}\n.qcard .ex2.tx{font-size:20px;font-weight:600;text-align:left}\n.opts{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}\n.opt{position:relative;padding:18px 8px;border-radius:18px;background:linear-gradient(180deg,#fff,#eef3fd);box-shadow:0 3px 10px rgba(31,80,200,.14),inset 0 0 0 2px #d7e2f7;font-size:28px;font-weight:800;color:var(--navy);transition:background .2s}\n.opt.ok{background:linear-gradient(180deg,#eaffea,#c9f2cd);box-shadow:inset 0 0 0 3px #27b33e}\n.opt.ok::after{content:\"\u2713\";position:absolute;right:16px;top:50%;transform:translateY(-50%);color:#27b33e;font-size:24px}\n.opt.bad{background:linear-gradient(180deg,#fff0f1,#fbd7db);box-shadow:inset 0 0 0 3px var(--wrong);color:var(--wrong);animation:sh .35s}\n@keyframes sh{25%{transform:translateX(-5px)}75%{transform:translateX(5px)}}\n.win{margin-top:18px;position:relative;border-radius:999px;background:linear-gradient(180deg,#ffe066,#ffbe0b);display:flex;align-items:center;gap:10px;padding:8px 18px 8px 10px;box-shadow:0 6px 16px rgba(245,180,0,.35);animation:pop .35s}\n.win img{width:64px;height:64px;object-fit:contain;margin-top:-14px}\n.win b{flex:1;text-align:center;font-size:22px;color:#0f3a2a;line-height:1.2}\n.win.bad{background:linear-gradient(180deg,#fff,#ffe9ec);box-shadow:0 4px 12px rgba(214,59,74,.2)}\n.win.bad b{color:var(--wrong);font-size:18px}\n.conf{position:absolute;inset:-16px -6px;pointer-events:none}\n.conf i{position:absolute;width:8px;height:12px;border-radius:2px}\n@keyframes pop{0%{transform:scale(.85);opacity:0}100%{transform:scale(1);opacity:1}}\n.qnav{display:flex;gap:12px;margin-top:18px}\n.qnav button{flex:1;padding:14px;border-radius:999px;font-weight:700;font-size:18px;display:flex;align-items:center;justify-content:center;gap:8px}\n.qnav .bk{background:#fff;color:var(--blue);box-shadow:0 3px 10px rgba(31,80,200,.15)}\n.qnav .nx{background:linear-gradient(180deg,#2f8bff,#1450c8);color:#fff;box-shadow:0 6px 14px rgba(20,80,200,.35)}\n.qnav .nx:disabled{opacity:.4}\n/* games */\n.games{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}\n.gm{padding:8px;border-radius:20px;background:#fff;box-shadow:0 4px 14px rgba(31,80,200,.12);text-align:center}\n.gm img{width:100%;aspect-ratio:127/82;object-fit:cover;border-radius:14px;display:block}\n.gm b{display:block;font-size:17px;color:var(--navy);padding:8px 2px 4px;line-height:1.15}\n/* results */\n.res{display:flex;align-items:center;gap:14px;padding:16px;margin-top:12px}\n.donut{width:136px;height:136px;flex:none}\n.stat{flex:1}\n.stat div{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #eef2fa;font-size:16px}\n.stat div:last-child{border:0}\n.stat b{margin-left:auto;font-size:18px;color:var(--navy)}\n.si{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;color:#fff;font-size:14px;font-weight:800;flex:none}\n.bars .br{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #eef2fa}\n.bars .br:last-child{border:0}\n.bars .br span{width:38%;font-weight:600;font-size:15.5px;color:var(--navy)}\n.bars .bt{flex:1;height:14px;border-radius:8px;background:#cfe0fb;overflow:hidden}\n.bars .bt i{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,#26a63b,#3cc955)}\n.bars .br b{width:46px;text-align:right;color:var(--navy)}\n/* achievements */\n.ach{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px}\n.ach .a{border-radius:18px;padding:10px 6px;text-align:center;box-shadow:0 4px 12px rgba(31,80,200,.12)}\n.ach .a img{width:54px;height:54px;object-fit:contain}\n.ach .a b{display:block;font-size:20px;color:var(--navy);line-height:1.1}\n.ach .a small{font-size:14px;color:var(--navy)}\n.medals{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;background:#f6f8ff;border-radius:16px;padding:10px 6px}\n.md{text-align:center;font-size:14px;font-weight:600;color:var(--navy);line-height:1.2}\n.md img{width:68px;height:64px;object-fit:contain;mix-blend-mode:multiply;display:block;margin:0 auto 4px}\n.md .lock{width:62px;height:62px;margin:0 auto 6px}\n.rank{display:flex;align-items:center;gap:12px;background:#f6f8ff;border-radius:16px;padding:12px}\n.rank img{width:52px;height:52px;object-fit:contain}\n.rank div{flex:1;font-size:16.5px;color:var(--navy)}\n/* levels, hints */\n.lvb{display:inline-flex;gap:3px;vertical-align:middle}\n.lvb i{width:12px;height:8px;border-radius:3px;display:block}\n.lvl{display:inline-flex;align-items:center;gap:7px;font-size:13.5px;font-weight:700}\n.legend{display:flex;flex-wrap:wrap;gap:8px 14px;margin:10px 2px 0;font-size:13px;color:var(--navy);font-weight:600}\n.legend span{display:inline-flex;align-items:center;gap:6px}\n.mylv{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;margin-top:12px;font-weight:600;color:var(--navy);flex-wrap:wrap}\n.rules{margin:10px 0}\n.rules div{display:grid;grid-template-columns:auto auto 1fr;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid #eef2fa;font-size:14.5px;color:#33406a}\n.rules div:last-child{border:0}\n.rules div b{color:var(--navy)}\n.rules div.on b{color:var(--good)}\n.tag{display:inline-flex;align-items:center;gap:6px;background:#f1ebff;color:#5b2fc9;font-weight:700;font-size:13px;padding:5px 10px;border-radius:999px;margin:0 0 6px 4px}\n.hint{margin-top:10px}\n.hint ol{margin:0 0 8px;padding:10px 12px 10px 30px;background:#fffbe6;border:1px solid #ffe08a;border-radius:14px;color:#3d3200;font-size:15.5px;line-height:1.45}\n.hint li{margin:2px 0}\n.hbtn2{display:inline-flex;align-items:center;gap:7px;background:#fff6d6;color:#8a6200;border:1.5px solid #ffd45a;padding:8px 14px;border-radius:999px;font-weight:700;font-size:15px}\n.hbtn2 small{font-weight:600;opacity:.75}\n.hbtn2.pulse{animation:pl 1.2s 3}\n@keyframes pl{50%{box-shadow:0 0 0 7px rgba(255,200,40,.35)}}\n.ups{background:#f4f8ff;border-radius:14px;padding:10px 12px;margin:6px 0 4px;text-align:left;font-size:14.5px;color:#33406a;line-height:1.6}\n.alrt{display:flex;gap:10px;align-items:center;padding:10px;border-radius:14px;background:#fff4f0;border:1px solid #ffd5c7;margin-top:8px}\n.alrt>span{width:28px;height:28px;border-radius:50%;background:#f08a3c;color:#fff;font-weight:800;display:grid;place-items:center;flex:none}\n.alrt b{display:block;color:var(--navy)}.alrt small{color:#6b5a52}\n.rpill{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.18);color:#fff;font-weight:700;font-size:13px;padding:3px 10px 3px 4px;border-radius:999px;border:1px solid rgba(255,255,255,.35)}\n.rpill img{width:26px;height:30px;object-fit:contain}\n.rankc{display:flex;align-items:center;gap:14px;padding:14px 16px;margin-top:2px}\n.rankc img.big{width:96px;height:auto;flex:none}\n.rankc .ri{flex:1;min-width:0}\n.rankc .ri small{display:block;color:var(--muted);font-size:13px}\n.rankc .ri b{display:block;font-size:24px;color:var(--navy)}\n.rankc .ri span{font-weight:600;color:#33406a;font-size:14px}\n.ranks{display:grid;grid-template-columns:repeat(6,1fr);gap:4px;margin-top:10px}\n.ranks div{text-align:center}\n.ranks img{width:100%;max-width:70px}\n.ranks small{display:block;font-size:11.5px;font-weight:700;color:var(--navy)}\n.ranks .no img{filter:grayscale(1);opacity:.4}\n.md{background:none}\n.md.no img{filter:grayscale(1);opacity:.42}\n.medals .md img{width:100%;max-width:120px;height:auto;margin:0 auto}\n.newrank{display:flex;align-items:center;gap:12px;justify-content:center;background:linear-gradient(90deg,#fff7d6,#ffe9a8);border-radius:16px;padding:10px;margin:8px 0}\n.newrank img{width:64px}.newrank small{display:block;color:#8a6200;font-weight:700}.newrank b{font-size:20px;color:var(--navy)}\n.sico{width:34px;height:34px;object-fit:contain}\n.bell img{display:block}\n.bcr{display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:9px 10px;border-radius:14px;background:#f5f8ff;margin-top:6px}\n.bcr img{width:38px;height:38px;object-fit:contain}.bcr span{flex:1;font-size:14.5px;color:var(--navy);font-weight:600}\n.bcr b{background:#fff3c4;color:#7a5600;padding:4px 10px;border-radius:999px;font-size:13.5px;white-space:nowrap}\n.bcn{display:block;margin-top:8px;color:var(--muted);font-size:12.5px}\n.bc{margin-top:14px}\n.tpb{padding:12px 14px;margin-top:12px}.tpb b{color:var(--navy)}.tpb div{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}\n.tpb span{font-size:13px;font-weight:600;padding:4px 10px;border-radius:999px;background:#eef1f7;color:#4b5675}.tpb span.ok{background:var(--good-soft);color:#13341f}\n.gain{display:inline-block;margin:4px 0 8px;background:linear-gradient(90deg,#fff3c4,#ffe08a);color:#5a3e00;font-weight:800;font-size:18px;padding:6px 16px;border-radius:999px}\n/* bottom nav */\n.bnav{position:fixed;left:50%;transform:translateX(-50%);bottom:10px;width:min(500px,calc(100% - 20px));background:#fff;border-radius:22px;box-shadow:0 6px 20px rgba(20,60,160,.18);display:flex;padding:6px;z-index:30}\n.bnav button{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:7px 0 6px;border-radius:16px;font-size:12px;font-weight:600;color:var(--navy)}\n.bnav svg{width:26px;height:26px}\n.bnav button.on{background:linear-gradient(180deg,#2f8bff,#1450c8);color:#fff;box-shadow:0 4px 10px rgba(20,80,200,.35)}\n/* misc */\n.toast{position:fixed;left:50%;bottom:96px;transform:translateX(-50%);background:#0f1f5c;color:#fff;padding:10px 16px;border-radius:12px;font-size:14px;z-index:60;max-width:90%;text-align:center}\n.ov{position:fixed;inset:0;background:rgba(10,25,70,.5);z-index:50;display:flex;align-items:center;justify-content:center;padding:16px}\n.ov .box{background:#fff;border-radius:20px;padding:20px;max-width:440px;width:100%}\n.empty{padding:22px;text-align:center;color:var(--muted);margin-top:12px}\n.prof{padding:18px;text-align:center;margin-top:14px}\n.prof .ava{width:80px;height:80px;font-size:30px;margin:0 auto 10px}\n.prof dl{display:grid;grid-template-columns:auto 1fr;gap:10px 14px;text-align:left;margin:16px 0 0}\n.prof dt{color:var(--muted)}.prof dd{margin:0;font-weight:600;color:var(--navy)}\n\n.list{display:grid;gap:10px;margin-top:10px}\n.list>.row{margin-top:0}\n.side{display:none}\n@media (min-width:700px){\n .app{max-width:980px}\n .bnav{width:min(640px,calc(100% - 20px))}\n .pad{padding:18px 20px 0}\n .list{grid-template-columns:1fr 1fr}\n .games{grid-template-columns:repeat(3,1fr)}\n .hgrid{display:grid;grid-template-columns:1.1fr 1fr;gap:18px;align-items:start}\n .hgrid .hr>.sec:first-child{margin-top:0}\n .dgrid{display:grid;grid-template-columns:1.15fr 1fr;gap:20px;align-items:start}\n .dgrid .lt{margin-top:14px}\n .ngrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start}\n .ngrid>.card{margin-top:12px}\n .ygrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start}\n .ygrid .medals{grid-template-columns:repeat(3,1fr)}\n .qwrap{max-width:640px;margin:0 auto}\n .seg,.sel{max-width:600px}\n .hbar,.home-h{border-radius:0 0 26px 26px}\n}\n@media (min-width:1100px){\n .wrap{padding-left:264px}\n .side{display:flex;flex-direction:column;gap:8px;position:fixed;left:0;top:0;bottom:0;width:264px;padding:18px 14px;background:linear-gradient(180deg,#0a2f86 0%,#1450c8 100%);color:#fff;z-index:40}\n .side .brand{display:flex;align-items:center;gap:10px;padding:4px 6px 20px}\n .side .brand svg{width:46px;height:36px}\n .side .brand b{font-size:20px;display:block;line-height:1.1}.side .brand small{font-size:12px;opacity:.85}\n .side .nv{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:14px;font-weight:600;font-size:16px;color:#fff;background:rgba(255,255,255,.08);width:100%;text-align:left}\n .side .nv img{width:30px;height:30px;border-radius:50%;flex:none}\n .side .nv:hover{background:rgba(255,255,255,.16)}\n .side .nv.on{background:#fff;color:#1450c8;box-shadow:0 6px 16px rgba(0,0,0,.18)}\n .side .sub{font-size:12px;opacity:.75;padding:12px 8px 2px;text-transform:uppercase;letter-spacing:.06em}\n .side .me{margin-top:auto;display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.12);border-radius:14px;padding:10px}\n .side .me small{display:block;opacity:.85;font-size:12px}\n .medals{grid-template-columns:repeat(4,1fr)}\n .bnav{display:none!important}\n .app{max-width:1200px}\n .app{padding-bottom:40px}\n .home-h .lg,.home-h .nm b,.home-h .nm small{display:none}\n .home-h .nm::before{content:\"Bosh sahifa\";font-size:22px;font-weight:700}\n .hbar,.home-h{border-radius:0 0 24px 24px;margin:0 20px}\n .list{grid-template-columns:repeat(3,1fr)}\n .games{grid-template-columns:repeat(4,1fr)}\n .hgrid{grid-template-columns:1.2fr 1fr}\n .toast{bottom:30px}\n .opt:hover{box-shadow:0 3px 10px rgba(31,80,200,.14),inset 0 0 0 2px #2f8bff}\n}\n\n.oqx{position:fixed;top:10px;right:12px;z-index:45;width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.95);color:#0f1f5c;font-size:24px;line-height:38px;text-align:center;box-shadow:0 2px 10px rgba(0,0,0,.25);font-family:inherit}\n.home-h{padding-right:60px}\n.lfr{position:fixed;inset:0;z-index:70;background:#fff;display:flex;flex-direction:column}\n.lfr iframe{flex:1;border:0;width:100%}\n.lfr .lb{display:flex;gap:8px;padding:8px;background:#0a2f86}\n.lfr .lb button{flex:1;padding:12px;border-radius:12px;font-weight:700;font-size:16px}\n.lfr .lb .ok{background:#27b33e;color:#fff}.lfr .lb .no{background:#fff;color:#0a2f86}\n.ex2 img,.pimg{max-width:100%;max-height:260px;display:block;margin:8px auto;border-radius:10px}\n.opt img{max-width:100%;max-height:110px;display:block;margin:0 auto}\n.opt.txt{font-size:20px}\n.ex2.tx{font-size:20px;font-weight:600;text-align:left;line-height:1.4}\n.loadov{position:fixed;inset:0;z-index:80;background:rgba(255,255,255,.7);display:flex;align-items:center;justify-content:center;font:600 16px \"Golos Text\",sans-serif;color:#0f1f5c}\n";

const I={
 back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
 arrowL:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12H5M11 5l-7 7 7 7"/></svg>',
 search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
 chev:'<svg class="ch" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
 down:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
 bell:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/></svg>',
 home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg>',
 play:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z" fill="currentColor"/></svg>',
 playf:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
 chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="4" y="13" width="3.5" height="7" rx="1"/><rect x="10.25" y="9" width="3.5" height="11" rx="1"/><rect x="16.5" y="4" width="3.5" height="16" rx="1"/></svg>',
 cup:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3a3 3 0 0 1-3 4M7 5H4a3 3 0 0 0 3 4"/></svg>',
 user:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
 lock:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 10V8a5 5 0 0 1 10 0v2h1a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zm2 0h6V8a3 3 0 0 0-6 0zm3 4a1.5 1.5 0 0 0-1 2.6V18h2v-1.4a1.5 1.5 0 0 0-1-2.6z"/></svg>',
 check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>',
 cal:'<svg viewBox="0 0 24 24" fill="none" stroke="#1f6fff" stroke-width="2"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/><path d="M7 14h2M11 14h2M15 14h2M7 17h2M11 17h2" stroke-linecap="round"/></svg>',
 map:'<svg viewBox="0 0 24 24" fill="#1f6fff"><path d="M3 20l5-9 4 5 3-4 6 8z" opacity=".55"/><path d="M14 3l7 3-7 3z"/><rect x="13" y="3" width="1.6" height="10"/></svg>',
 timer:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 13l3-3M9 2h6"/></svg>',
 clip:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2.5h6V4M9 12l2 2 4-4"/></svg>',
 bulb:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/></svg>',
 redo:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>',
 logo:'<svg viewBox="0 0 48 36" fill="none" stroke="#fff" stroke-width="2.2" stroke-linejoin="round"><path d="M4 12c7-2 14-1 20 3 6-4 13-5 20-3v20c-7-2-14-1-20 3-6-4-13-5-20-3z"/><path d="M24 15v20"/><path d="M24 2l2 5h-4zM16 5l3 4M32 5l-3 4" stroke="#ffd84a"/></svg>'
};
/* ---------- data ---------- */
let G={};
const ICON=n=>/Kasr|Ulush/.test(n)?'t_kasr':/Geometr/.test(n)?'t_geom':/Kattalik/.test(n)?'t_kattalik':/Qo'shish/.test(n)?'t_qoshish':/Ko'paytirish/.test(n)?'t_kopaytirish':/Ifoda/.test(n)?'t_ifoda':/Matnli/.test(n)?'t_masala':/yakuni/.test(n)?'t_qiyin':/To'plam/.test(n)?'t_toplam':/Mantiq/.test(n)?'t_mantiq':/Tanqidiy/.test(n)?'t_tanqidiy':/Kelajak/.test(n)?'t_kelajak':/Ma'lumot/.test(n)?'t_malumot':'t_sonlar';
const SHORT=n=>n.replace(/\s*\(.*\)/,'').replace(/:.*/,'').replace("Qo'shish va ayirish",'Amallar').replace("Ko'paytirish va bo'lish","Ko'paytirish").replace(/-sinf yakuni.*/,'-sinf yakuni');
const LV=["Boshlanmagan","Urinib ko'rgan","Tanish","Yaxshi biladi","O'zlashtirgan"];
const LVC=['#c3cad8','#f08a3c','#f5b400','#2f8bff','#1fa34a'];
const DAILY={1:6,2:8,3:10,4:12};
const RANK=[[0,"Boshlovchi"],[1000,"O'rganuvchi"],[3000,"Izlanuvchi"],[5000,"Bilimdon"],[7500,"Yetakchi"],[10000,"Yosh Xorazmiy"]];
const OPT=n=>/Mantiq|Tanqidiy|Kelajak/.test(n);           // ixtiyoriy bo'limlar: unvonga kerak emas
const coreT=()=>(G[S.grade]||[]).filter(g=>!OPT(g.name)).flatMap(g=>g.t);
const allT=()=>(G[S.grade]||[]).filter(g=>!/Tanqidiy/.test(g.name)).flatMap(g=>g.t);
const PT=()=>{const n=coreT().length;return n?Math.round(10000/n):0};  // bitta mavzu bali (o'zgarmaydi)
const LVSH=[0,0,.3,.7,1];
function tParts(c){const P=PT(),les=S.prog[c]>=7?Math.round(P*.2):0,ms=Math.round(P*.5*LVSH[lv(c)]),ts=S.tp[c]?P-Math.round(P*.2)-Math.round(P*.5):0;return{P,les,ms,ts,sum:les+ms+ts}}
function calcPts(){if(allDone())return 10000;return Math.min(9999,coreT().reduce((s,t)=>s+tParts(t.c).sum,0))}
function optStars(){return allT().filter(t=>!coreT().includes(t)).reduce((s,t)=>s+(lv(t.c)===4?10:lv(t.c)>=2?4:0)+(S.tp[t.c]?5:0),0)}
const allDone=()=>coreT().length&&coreT().every(t=>lv(t.c)===4&&S.tp[t.c]);
const rankOf=p=>{let r=0;RANK.forEach((x,i)=>{if(i<5&&p>=x[0])r=i});if(allDone())r=5;return r};
const fmt=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ');
const PKEYS=['lv','seen','prog','tp','stars','streak','last','mashq','extra','xday','correct','wrong','tests','err','alerts','fast','task','days'];
const TODAY=()=>{const d=new Date(Date.now()+5*36e5);return d.toISOString().slice(0,10)};
const YDAY=()=>{const d=new Date(Date.now()+5*36e5-864e5);return d.toISOString().slice(0,10)};
function fresh(kid,p){p=p||{};const s={kid,name:kid.first,grade:kid.grade,sex:kid.sex,view:'grade',scr:'home',stack:[],seg:{},q:null,
  lv:{},seen:{},prog:{},tp:{},stars:0,streak:0,last:'',mashq:0,extra:0,xday:{d:'',n:0},correct:0,wrong:0,tests:0,err:{},alerts:[],fast:false,task:{d:'',dars:false,mashq:false,test:false},days:{}};
  for(const k of PKEYS)if(p[k]!=null)s[k]=p[k];
  if(s.task.d!==TODAY())s.task={d:TODAY(),dars:false,mashq:false,test:false};
  if(s.last&&s.last!==TODAY()&&s.last!==YDAY())s.streak=0;
  return s}
function act(n){const d=TODAY();if(S.last!==d){S.streak=S.last===YDAY()?S.streak+1:1;S.last=d}S.days[d]=(S.days[d]||0)+(n||0);
  const ks=Object.keys(S.days).sort();while(ks.length>60)delete S.days[ks.shift()]}
function groups(){return G[S.view==='grade'?S.grade:S.view]||[]}
const lv=c=>S.lv[c]||0;
const pct=gr=>Math.round(gr.t.reduce((s,t)=>s+lv(t.c),0)/(4*gr.t.length)*100);
const locked=(gr,i)=>/Tanqidiy/.test(gr.name)||(i>0&&pct(groups()[i-1])<30&&pct(gr)===0);
function curGroup(){const gs=groups();return gs.find(g=>pct(g)<100)||gs[0]}
function curTopic(gr){gr=gr||curGroup();return gr.t.find(t=>lv(t.c)<3)||gr.t[0]}
const lvBars=v=>`<span class="lvb">${[1,2,3,4].map(k=>`<i style="background:${k<=v?LVC[v]:'#e3e8f2'}"></i>`).join('')}</span>`;
const lvPill=v=>`<span class="lvl">${lvBars(v)}<span style="color:${v?LVC[v]:'#7b86a3'}">${LV[v]}</span></span>`;
const esc=s=>String(s).replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const $=s=>ROOT.querySelector(s);
function toast(t){const e=document.createElement('div');e.className='toast';e.textContent=t;ROOT.appendChild(e);setTimeout(()=>e.remove(),2200)}
/* ---------- navigation ---------- */
function go(scr,arg,push=true){if(push)S.stack.push([S.scr,S.arg]);S.scr=scr;S.arg=arg;render();HOST.scrollTop=0}
function back(){let p=S.stack.pop();while(p&&p[0]==='mashq'&&!S.q)p=S.stack.pop();if(p){S.scr=p[0];S.arg=p[1]}else S.scr='home';render();HOST.scrollTop=0}
function tab(scr){S.stack=[];S.scr=scr;S.arg=null;render();HOST.scrollTop=0}
const NAV=[['home','Bosh sahifa',I.home],['darslar','Darslar',I.play],['natija','Natijalar',I.chart],['yutuq','Yutuqlar',I.cup],['profil','Profil',I.user]];
const NAVOF={home:'home',darslar:'darslar',bolim:'darslar',dars:'darslar',mashq:'darslar',test:'darslar',oyin:'darslar',natija:'natija',yutuq:'yutuq',profil:'profil'};
function render(){S.pts=calcPts();save();{const x=ROOT.querySelector('.oqx');if(x)x.style.display=S.scr==='home'?'':'none'}
  const on=NAVOF[S.scr];
  $('#bnav').style.display=S.scr==='mashq'?'none':'flex';
  $('#bnav').innerHTML=NAV.map(([k,n,ic])=>`<button class="${on===k?'on':''}" data-c="tab('${k}')">${ic}${n}</button>`).join('');
  $('#side').innerHTML=`<div class="brand">${I.logo}<div><b>Yosh Xorazmiylar</b><small>Matematika ta'lim platformasi</small></div></div>`+NAV.map(([k,n,ic])=>`<button class="nv ${on===k?'on':''}" data-c="tab('${k}')"><img src="${IMG[{home:'p_home',darslar:'p_darslar',natija:'p_natija',yutuq:'p_yutuq',profil:'p_profil'}[k]]}">${n}</button>`).join('')+`<div class="sub">Bo'limlar</div>`+[['startDaily()','Mashqlar',`<img src="${IMG.p_mashq}">`],["go('test')",'Testlar',`<img src="${IMG.p_test}">`],["go('oyin')","O'yinlar",`<img src="${IMG.p_oyin}">`]].map(([f,n,ic])=>`<button class="nv ${({mashq:'Mashqlar',test:'Testlar',oyin:"O'yinlar"})[S.scr]===n?'on':''}" data-c="${f}">${ic}${n}</button>`).join('')+`<div class="me"><img src="${IMG['l_d'+(rankOf(S.pts)+1)]}" style="width:44px"><div><b>${S.name}</b><small>${RANK[rankOf(S.pts)][1]} · ${fmt(S.pts)} ball</small><small>${esc(S.kid.cls)} · ${esc(S.kid.school)}</small></div></div><button class="nv" data-c="close()">↩ Saytga qaytish</button>`;
  $('#app').innerHTML=({home,darslar,bolim,dars,mashq,test,oyin,natija,yutuq,profil})[S.scr]();
}
const HICO={darslar:'p_darslar',bolim:'p_mavzular',dars:'p_video',mashq:'p_mashq',test:'p_test',oyin:'p_oyin',natija:'p_natija',yutuq:'p_yutuq',profil:'p_profil'};
function bar(t,right='',ico=''){ico=ico||(HICO[S.scr]?`<img src="${IMG[HICO[S.scr]]}">`:'');return `<div class="hbar"><button class="hbtn" data-c="back()">${S.scr==='test'||S.scr==='oyin'||S.scr==='yutuq'?I.arrowL:I.back}</button><div class="t">${ico}${t}</div><span class="hbtn">${right}</span></div>`}
function seg(key,items){const v=S.seg[key]??0;return `<div class="seg">${items.map((x,i)=>`<button class="${v===i?'on':''}" data-c="S.seg['${key}']=${i};render()">${x}</button>`).join('')}</div>`}
/* ---------- BOSH SAHIFA ---------- */
function home(){
  const k=S.grade+S.sex, gs=G[S.grade]||[], t=S.task, dn=[t.dars,t.mashq,t.test].filter(Boolean).length;
  const ci=gs.findIndex(g=>pct(g)<100), st=gs.length?[Math.max(0,ci-1),Math.max(0,ci-1)+1,Math.max(0,ci-1)+2].map(i=>gs[i]).filter(Boolean):[];
  return `<div class="home-h"><span class="lg">${I.logo}</span><div class="nm"><b>Yosh Xorazmiylar</b><small>Matematika ta'lim platformasi</small></div>
   <button class="ava" data-c="tab('profil')">${esc(S.name[0]||'')}</button></div>
  <div class="pad"><div class="hgrid"><div class="hl">
   <div class="banner"><img src="${IMG['bn_'+k]}" alt=""><div class="greet"><b>Assalomu alaykum, ${esc(S.name)}!</b><span class="ypill">${S.grade}-sinf • Matematika</span><button class="rpill" data-c="tab('yutuq')"><img src="${IMG['l_d'+(rankOf(S.pts)+1)]}">${RANK[rankOf(S.pts)][1]} · ${fmt(S.pts)} ball</button></div></div>
   <div class="tiles">
    <button class="tile b" data-c="go('darslar')"><img src="${IMG.p_darslar}">Darslar</button>
    <button class="tile g" data-c="startDaily()"><img src="${IMG.p_mashq}">Mashqlar</button>
    <button class="tile p" data-c="go('test')"><img src="${IMG.p_test}">Testlar</button>
    <button class="tile o" data-c="go('oyin')"><img src="${IMG.p_oyin}">O'yinlar</button>
   </div>
   ${ballCard()}
   </div><div class="hr"><div class="card sec"><div class="sec-h"><img class="sico" src="${IMG.q_kunlik}"><b>Bugungi vazifa</b><span class="c">${dn}/3</span><span style="color:var(--blue);width:20px">${I.chev}</span></div>
    <div style="display:flex;align-items:center;gap:8px"><div style="flex:1">
     <button class="chk" data-c="${gs.length?`go('dars','${curTopic().c}')`:''}"><span class="cb ${t.dars?'on':''}"></span>Darsni ko'rish</button>
     <button class="chk" data-c="startDaily()"><span class="cb ${t.mashq?'on':''}"></span>${DAILY[S.grade]} ta mashqni bajarish</button>
     <button class="chk" data-c="${gs.length?`topicTest('${curTopic().c}')`:''}"><span class="cb ${t.test?'on':''}"></span>Mavzu testini topshirish</button></div>
     <img src="${IMG.p_mashq}" style="width:72px"></div></div>
   ${st.length?`<div class="card sec" style="margin-bottom:8px"><div class="sec-h"><img class="sico" src="${IMG.q_yol}"><b>Mening o'quv yo'lim</b><span style="color:var(--blue);width:20px">${I.chev}</span></div>
    <div class="path">${st.map((g,i)=>{const p=pct(g),c=p===100?'d':i===st.findIndex(x=>pct(x)<100)?'c':'l';return `<button class="step ${c}" data-c="${c==='l'?`toast('Avvalgi bo\\'limni tugatsangiz ochiladi')`:`go('bolim',${gs.indexOf(g)})`}"><span class="dot ${c}">${c==='d'?I.check:c==='c'?I.playf:I.lock}</span><span>${gs.indexOf(g)+1}. ${esc(SHORT(g.name))}</span></button>`}).join('')}</div></div>`
    :`<div class="card empty">Bu sinf mavzulari tez orada qo'shiladi.</div>`}
  </div></div></div>`;
}
function ballCard(){
  const gs=G[S.grade]||[];if(!gs.length)return '';const t=curTopic(),p=tParts(t.c),P=p.P,out=[];
  if(S.prog[t.c]<7)out.push([`go('dars','${t.c}')`,'p_video',`"${t.n}" darsini oxirigacha ko'ring`,Math.round(P*.2)]);
  if(lv(t.c)<4)out.push([`go('dars','${t.c}');startMashq('${t.c}')`,'p_mashq',`Shu mavzu mashqini bajaring (9/10 = to'liq)`,Math.round(P*.5)-p.ms]);
  if(!S.tp[t.c])out.push([`topicTest('${t.c}')`,'p_test',`Mavzu testini topshiring (5 tadan 4 tasi)`,P-Math.round(P*.2)-Math.round(P*.5)]);
  if(!S.task.mashq)out.push(['startDaily()','q_kunlik',`Kunlik vazifani bajaring`,0,'+5 ★']);
  return `<div class="card sec bc"><div class="sec-h"><img class="sico" src="${IMG.q_ball}"><b>Ball to'plash</b><span class="c" style="font-size:14px">${fmt(S.pts)} / 10 000</span></div>
   <div class="pbar" style="margin:0 0 10px"><i style="width:${Math.min(100,S.pts/100)}%"></i></div>
   ${out.slice(0,3).map(o=>`<button class="bcr" data-c="${o[0]}"><img src="${IMG[o[1]]}"><span>${esc(o[2])}</span><b>${o[4]||'+'+o[3]+' ball'}</b></button>`).join('')}
   <small class="bcn">Har bir mavzu ${P} ball: dars 20%, mashqlar 50%, test 30%. Olingan ball hech qachon kamaymaydi. Mantiq va Kelajak matematikasi bo'limlari ixtiyoriy: ular yulduz (★) va medal beradi.</small></div>`}
/* ---------- DARSLAR ---------- */
function darslar(){
  const gs=groups(), s=S.seg.d??0;
  const list=gs.map((g,i)=>({g,i})).filter(({g,i})=>s===0||(pct(g)>0&&!locked(g,i)));
  return bar('Darslar',I.search)+`<div class="pad">${seg('d',['Barcha mavzular',"O'zlashtirish"])}
   <div class="sel"><b style="padding:13px 0;color:var(--navy);font-size:16px">${S.grade}-sinf • Matematika</b></div>
   ${gs.length?`<div class="legend">${[1,2,3,4].map(v=>`<span>${lvBars(v)}${LV[v]}</span>`).join('')}</div>`:'<div class="card empty">Bu sinf mavzulari tez orada qo\'shiladi.</div>'}
   <div class="list">${(()=>{let n=0;return list.map(({g,i})=>{const a=gs.slice(0,i).reduce((s,x)=>s+x.t.length,0)+1,b=a+g.t.length-1,p=pct(g),L=locked(g,i);
     return `<button class="row ${i<2?'pk':''}" data-c="${L?`toast('${/Tanqidiy/.test(g.name)?"Bu bo\\'lim hozircha yopiq":"Avvalgi bo\\'limlarni o\\'zlashtirsangiz ochiladi"}')`:`go('bolim',${i})`}">
      <img class="gi" src="${IMG[ICON(g.name)]}"><div class="m"><b>${i+1}. ${esc(g.name.replace(/^\S+ /,m=>/\d-sinf/.test(g.name)?'':m))}</b><small>(${a}–${b}-dars)</small></div>
      ${L?`<span class="lock">${I.lock}</span>`:p===100?`<span class="badge ok"><span class="ck"></span>100%</span>`:`<span class="badge pr"><span class="ring" style="background:conic-gradient(${p>=50?'#f5b400':'#f08a3c'} ${p}%,#e6ebf5 0)"></span>${p}%</span>`}</button>`}).join('')})()}</div>
  </div>`;
}
function bolim(){
  const gs=groups(), g=gs[S.arg];
  return bar(esc(SHORT(g.name)))+`<div class="pad"><div class="card sec" style="margin-top:0"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><b style="color:var(--navy);font-size:17px">${esc(g.name)}</b><span class="badge pr"><span class="ring" style="background:conic-gradient(#1fa34a ${pct(g)}%,#e6ebf5 0)"></span>${pct(g)}%</span></div>
    <div class="legend" style="margin:10px 0 0">${[1,2,3,4].map(v=>`<span>${lvBars(v)}${LV[v]}</span>`).join('')}</div>
    ${pct(g)<100?`<button class="cta ghost" style="margin-top:12px" data-c="bolimTest(${S.arg})">Bo'lim sinovi: bilsangiz, butun bo'limni bir testda o'ting</button><small class="bcn">${g.t.length*2} ta savol. ${g.t.length*2-Math.ceil(g.t.length*2*.1)} tasidan ko'pini topsangiz, bo'limdagi hamma mavzu "O'zlashtirgan" bo'ladi va ballari beriladi.</small>`:''}</div>
   <div class="list">${g.t.map((t,j)=>{const v=lv(t.c),open=j===0||v>0||lv(g.t[j-1].c)>=2;return `<button class="row" data-c="${open?`go('dars','${t.c}')`:`toast('Avvalgi darsda kamida \\'Tanish\\' darajasiga yetsangiz ochiladi')`}">
     <div class="m"><small style="margin:0 0 2px">${j+1}-dars</small><b style="font-size:16px">${esc(t.n)}</b>${open?`<div style="margin-top:6px">${lvPill(v)}</div>`:''}</div>
     ${!open?`<span class="lock">${I.lock}</span>`:v===4?`<span class="badge ok"><span class="ck"></span></span>`:`<span class="playc">${I.playf}</span>`}</button>`}).join('')}</div></div>`;
}
function findT(c){for(const g of Object.values(G))for(const gr of g){const j=gr.t.findIndex(t=>t.c===c);if(j>=0)return{gr,j,t:gr.t[j]}}}
function dars(){
  const {gr,j,t}=findT(S.arg), prev=j>0?gr.t[j-1].n:null, s=S.seg.l??0, p=S.prog[t.c]||(lv(t.c)>=2?7:0), v=lv(t.c);
  const sample=[gen(t.c),gen(t.c)];
  const body=s===0?`<div class="lt">${esc(t.n)}</div>
     <div class="li"><img src="${IMG.q_kunlik}"><div><b>Dars maqsadi:</b><span>"${esc(t.n)}" mavzusini qadamba-qadam, chizmalar bilan o'rganish.</span></div></div>
     <div class="li"><img src="${IMG.p_darslar}"><div><b>Kerakli bilimlar:</b><span>${prev?esc(prev):'Oldingi sinfda o\'rganilgan bilimlar'}.</span></div></div>
     <div class="li"><img src="${IMG.a_kurs}"><div><b>Dars natijasida:</b><span>shu mavzudagi misol va masalalarni mustaqil yecha olasiz.</span></div></div>`
   :s===1?sample.map((x,i)=>`<div class="card ex"><div class="q">${i+1}-misol: ${esc(x.q)}</div><div class="s">Javob: <b>${esc(x.a)}</b>. To'liq yechimi interaktiv darsda qadamba-qadam ko'rsatiladi.</div></div>`).join('')
   :`<div class="card ex"><div class="q">10 ta mashq</div><div class="s">Darajangiz mashq natijasiga qarab oshadi (birinchi urinishda topilgan javoblar):</div>
      <div class="rules">${[[1,'Mashqni boshlasangiz'],[2,'10 tadan kamida 5 tasi'],[3,'10 tadan kamida 7 tasi'],[4,'10 tadan kamida 9 tasi yoki takrorlashda xatosiz javob']].map(([k,s])=>`<div class="${v>=k?'on':''}">${lvBars(k)}<b>${LV[k]}</b><span>${s}</span></div>`).join('')}</div>
      <div class="s" style="font-size:13.5px">"O'zlashtirgan" mavzuda takrorlash paytida xato qilinsa, daraja "Yaxshi biladi"ga tushadi.</div></div>`;
  return bar('Dars',I.search)+`<div class="pad"><div class="dgrid"><div>
   <button class="player" style="width:100%" data-c="openLesson('${t.c}')"><img class="tc" src="${IMG.teacher}"><div class="bt">${esc(t.n)}</div><span class="pb">${I.playf}</span>
    <div class="ctl"><span style="width:18px">${I.playf}</span><span>${p}/7 qadam</span><div class="bar"><i style="width:${p/7*100}%"></i></div><span>Interaktiv</span></div></button>
   <div class="card mylv"><span>Sizning darajangiz:</span>${lvPill(v)}</div>
   </div><div><div style="margin-top:14px">${seg('l',['Dars haqida','Misollar','Mashqlar'])}</div>${body}
   <button class="cta" data-c="startMashq('${t.c}')">Mashqlarni bajarish ${I.chev.replace('class="ch"','')}</button>
   <button class="cta ghost" data-c="topicTest('${t.c}')">${S.tp[t.c]?'Mavzu testi topshirilgan ✓':'Mavzu testini topshirish'}</button>
   ${OPT(gr.name)?`<div class="card tpb"><b>Ixtiyoriy mavzu: o'zlashtirsangiz +10 ★, testi uchun +5 ★ va medal</b></div>`:(()=>{const q=tParts(t.c);return `<div class="card tpb"><b>Shu mavzudan ball: ${q.sum} / ${q.P}</b><div><span class="${q.les?'ok':''}">Dars ${q.les}/${Math.round(q.P*.2)}</span><span class="${q.ms===Math.round(q.P*.5)?'ok':''}">Mashq ${q.ms}/${Math.round(q.P*.5)}</span><span class="${q.ts?'ok':''}">Test ${q.ts}/${q.P-Math.round(q.P*.2)-Math.round(q.P*.5)}</span></div></div>`})()}
   </div></div></div>`;
}
function openLesson(c){
  if(!READY.has(c)){toast("Bu mavzuning interaktiv darsi tayyorlanmoqda");return}
  const o=document.createElement('div');o.className='lfr';
  o.innerHTML=`<iframe src="/darslar/lesson.html#${encodeURIComponent(c)}" allow="autoplay"></iframe><div class="lb"><button class="no" data-c="this.closest('.lfr').remove()">Yopish</button><button class="ok" data-c="lessonDone('${c}',this)">Darsni tugatdim ✓</button></div>`;
  ROOT.appendChild(o)}
function lessonDone(c,el){const b=calcPts();S.prog[c]=7;S.task.dars=true;if(!S.lv[c])S.lv[c]=1;S.seen[c]=Date.now();act(0);el.closest('.lfr').remove();render();const d=calcPts()-b;toast(d?'+'+d+' ball':'Barakalla!')}
/* ---------- MASHQ ---------- */
const R=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
function shuf(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function opts(a,c){const s=new Set([a]);for(const x of c){if(s.size>=4)break;if(x>0&&x!==a)s.add(x)}let k=2;while(s.size<4){s.add(a+k);k+=3}return shuf([...s])}
function digits(n){return String(n).split('').reverse().map(Number)}
const XN=['birliklar','o\'nliklar','yuzliklar','minglar'];
function addHints(a,b){const A=digits(a),B=digits(b),h=[];let c=0;for(let i=0;i<Math.max(A.length,B.length);i++){const x=A[i]||0,y=B[i]||0,s=x+y+c;
  h.push(`${XN[i][0].toUpperCase()+XN[i].slice(1)}ni qo'shing: ${x}${i<B.length?` + ${y}`:''}${c?' + 1 (o\'tkazilgan)':''} = ${s}.`+(s>=10&&i<Math.max(A.length,B.length)-1?` ${s%10} ni yozamiz, 1 ni keyingi xonaga o'tkazamiz.`:''));c=s>=10?1:0}return h}
function subHints(a,b){const A=digits(a),B=digits(b),h=[];let br=0;const U=s=>s[0].toUpperCase()+s.slice(1);
  for(let i=0;i<A.length;i++){const y=B[i]||0;if(i>=B.length&&!br){h.push(`Qolgan xonalarni o'zgarishsiz tushiramiz: ${String(Math.floor(a/10**i))}.`);break}
    const x=A[i]-br, pre=br?`${A[i]} tadan 1 tasini oldingi xonaga berdik, ${x} qoldi. `:'';
    if(x<y){h.push(`${U(XN[i])}: ${pre}${x} dan ${y} ayrilmaydi. Keyingi xonadan 1 ta olamiz: ${x+10} − ${y} = ${x+10-y}.`);br=1}
    else{h.push(`${U(XN[i])}: ${pre}${x} − ${y} = ${x-y}.`);br=0}}return h}
function mulHints(b,a){if(b<10)return a<=5?[`${b} × ${a} — bu ${a} ta ${b} ni qo'shish: ${Array(a).fill(b).join(' + ')}.`]:[`${b} × ${a - 1} = ${b*(a-1)} ekanini eslang.`,`Unga yana bitta ${b} ni qo'shing: ${b*(a-1)} + ${b} = ${b*a}.`];
  const T=b-b%10,U=b%10;return [`${b} ni o'nlik va birlikka ajrating: ${b} = ${T} + ${U}.`,`${T} × ${a} = ${T*a},  ${U} × ${a} = ${U*a}.`,`Ikkalasini qo'shing: ${T*a} + ${U*a} = ${T*a+U*a}.`]}
function gen(code){
  const g=+code[0], L=code[1];
  if(g===1){if(Math.random()<.5){const a=R(2,9),b=R(1,9),s=a+b;return{ty:"Qo'shish (20 ichida)",lb:'Hisoblang:',q:`${a} + ${b} = ?`,a:s,o:opts(s,[s+1,s-1,s+2]),h:[`${a} ga ${b} ni birma-bir qo'shib sanang: ${a}, ${Array.from({length:b},(_,k)=>a+k+1).join(', ')}.`]}}
    const a=R(1,10);let b;do{b=R(1,10)}while(b===a);return{ty:'Taqqoslash',lb:'Taqqoslang:',q:`${a} ☐ ${b}`,a:a>b?'>':'<',o:['>','<','='],h:[`Sanoqda qaysi son keyinroq keladi? Keyinroq kelgani katta.`]}}
  if(L==='C'||(L!=='A'&&L!=='B'&&Math.random()<.35)){const a=R(2,9);let b;do{b=g>=3?R(11,48):R(2,9)}while(b%10===0);const s=a*b;return{ty:"Ko'paytirish",lb:"Ko'paytmani hisoblang:",q:`${b} × ${a} = ?`,a:s,o:opts(s,[s+a,s-a,s+10,s-1]),h:mulHints(b,a)}}
  if(L==='A'&&g===2){const a=R(20,99);let b;do{b=R(20,99)}while(b===a);const ta=Math.floor(a/10),tb=Math.floor(b/10);return{ty:'Taqqoslash',lb:'Taqqoslang:',q:`${a} ☐ ${b}`,a:a>b?'>':'<',o:['>','<','='],
    h:[`Avval o'nliklarni taqqoslang: ${a} da ${ta} ta, ${b} da ${tb} ta o'nlik.`,ta!==tb?`O'nliklari ko'p bo'lgan son katta.`:`O'nliklari teng. Endi birliklarni taqqoslang: ${a%10} va ${b%10}.`]}}
  const nz=n=>!String(n).slice(0,-1).includes('0')&&n%10!==0;
  const pair=()=>{let p;do{p=g>=4?[R(210,789),R(105,399)]:g===3?[R(110,689),R(102,299)]:[R(14,68),R(6,29)]}while(!nz(p[0])||!nz(p[1]));return p};
  const carry=(a,b)=>{const A=digits(a),B=digits(b);let c=0,any=false;for(let i=0;i<A.length;i++){const s=A[i]+(B[i]||0)+c;c=s>=10?1:0;if(c)any=true}return any},
        borrow=(a,b)=>{const A=digits(a),B=digits(b);let r=0,any=false;for(let i=0;i<A.length;i++){const x=A[i]-r,y=B[i]||0;r=x<y?1:0;if(r)any=true}return any};
  const want=code==='2B1'?false:/^2B[23]$/.test(code)?true:Math.random()<.75, op=code==='2B2'?'+':code==='2B3'?'-':(Math.random()<.55?'+':'-');
  if(op==='+'){let a,b,k=0;do{[a,b]=pair();k++}while(carry(a,b)!==want&&k<40);const s=a+b;return{ty:carry(a,b)?"O'nlikdan o'tib qo'shish":"Qo'shish",lb:'Hisoblang:',q:`${a} + ${b} = ?`,a:s,o:opts(s,[s+10,s-10,s+1,s+100]),h:addHints(a,b)}}
  let a,b,k=0;do{[a,b]=pair();if(b>=a)[a,b]=[a+b,b];k++}while((borrow(a,b)!==want||!nz(a))&&k<60);const s=a-b;return{ty:borrow(a,b)?"O'nlikdan o'tib ayirish":"Ayirish",lb:'Hisoblang:',q:`${a} − ${b} = ?`,a:s,o:opts(s,[s+10,s-10,s+1,s-1]),h:subHints(a,b)}
}
function norm(it){if(it.ai==null){it.sym=typeof it.a==='string';it.ai=it.o.indexOf(it.a)}return it}
function mUrl2(x){return !x?'':String(x).startsWith('data:')?x:(typeof mUrl==='function'?mUrl(x):x)}
function fromBank(p,tn){const o=(p.o||[]).map(v=>typeof v==='string'?{t:v}:v);const ai='ABCDE'.indexOf(p.a);if(ai<0||!o.length)return null;
  const q=String(p.q||''),txt=q.length>24||/\n/.test(q);
  return{ty:tn||'Masala',lb:'',q,qh:`<div class="ex2 ${txt||p.img?'tx':''}">${esc(q).replace(/\n/g,'<br>')}${p.img?`<img class="pimg" src="${mUrl2(p.img)}" alt="">`:''}</div>`,
    oh:o.map(v=>`${v.i?`<img src="${mUrl2(v.i)}" alt="">`:''}${v.t?`<span>${esc(v.t)}</span>`:''}`),o:o.map((v,k)=>k),ai,sym:o.length===3,txt:o.some(v=>String(v.t||'').length>6),
    h:String(p.sol||'').split(/\n+/).map(x=>x.trim()).filter(Boolean).slice(0,6)}}
const BANK={};
async function bankItems(code,n){const tn=(findT(code)||{t:{n:''}}).t.n;let rows=[];
  try{const d=await api('oq.misol',{sid:S.kid.id,topic:code,n:Math.min(12,n+2)});rows=d.rows||[]}catch(e){}
  const out=[];for(const r of rows){const it=fromBank(r,tn);if(it)out.push(it);if(out.length>=n)break}
  while(out.length<n)out.push(norm(gen(code)));return out.map(norm)}
async function loading(f){const o=document.createElement('div');o.className='loadov';o.textContent='Misollar yuklanmoqda…';ROOT.appendChild(o);try{return await f()}finally{o.remove()}}
function topicCode(){return groups().length&&S.view==='grade'?curTopic().c:(G[S.grade]?curTopic().c:'1A1')}
async function startDaily(extra){
  const N=DAILY[S.grade], gs=G[S.grade]||[], c=gs.length?curTopicOf(gs).c:'1A1';
  const old=gs.flatMap(g=>g.t).filter(t=>lv(t.c)>=3&&t.c!==c).sort((x,y)=>(S.seen[x.c]||0)-(S.seen[y.c]||0));
  const r=old.length?Math.round(N*.25):0, rev=old.slice(0,r);
  const items=await loading(async()=>{const a=await bankItems(c,N-rev.length);for(const t of rev){const [x]=await bankItems(t.c,1);a.push(Object.assign(x,{rc:t.c,rn:t.n}))}return a});
  S.q={c,kind:extra?'extra':'kun',items:shuf(items),i:0,st:[],first:0,ups:[],t0:Date.now(),r0:rankOf(S.pts),p0:calcPts()};go('mashq')}
function curTopicOf(gs){const g=gs.find(x=>pct(x)<100)||gs[0];return g.t.find(t=>lv(t.c)<3)||g.t[0]}
async function startMashq(c){const items=await loading(()=>bankItems(c,10));S.q={c,kind:'mavzu',items,i:0,st:[],first:0,ups:[],r0:rankOf(S.pts),p0:calcPts()};if(lv(c)===0){S.lv[c]=1;S.q.ups.push([c,0,1])}go('mashq')}
function mashq(){
  const Q=S.q, n=Q.items.length;
  if(Q.i>=n){const sc=Q.first, N=DAILY[S.grade];let up='';
    if(Q.kind==='mavzu'){const nv=sc>=9?4:sc>=7?3:sc>=5?2:1,ov=lv(Q.c);if(!Q.fin){Q.fin=1;if(nv>ov){S.lv[Q.c]=nv;Q.ups.push([Q.c,ov,nv])}}}
    const um={};Q.ups.forEach(([c,x,y])=>{um[c]=um[c]?[c,um[c][1],y]:[c,x,y]});const ups=Object.values(um).filter(u=>u[1]!==u[2]);
    if(Q.kind==='btest'&&!Q.fin4){Q.fin4=1;if(sc>=n-Math.ceil(n*.1)){groups()[Q.gi].t.forEach(t=>{if(lv(t.c)<4)Q.ups.push([t.c,lv(t.c),4]);S.lv[t.c]=4;S.tp[t.c]=true;S.prog[t.c]=7})}}
    if(Q.kind==='ttest'&&!Q.fin3){Q.fin3=1;if(sc>=4)S.tp[Q.c]=true}
    if(Q.kind==='kun'&&!Q.fin2){Q.fin2=1;if(sc===n&&Date.now()-Q.t0<300000)S.fast=true}
    const dp=calcPts()-Q.p0, rn=rankOf(calcPts());if(Q.r0!=null&&rn>Q.r0)up+=`<div class="newrank"><img src="${IMG['l_d'+(rn+1)]}"><div><small>Yangi daraja!</small><b>${RANK[rn][1]}</b></div></div>`;
    if(ups.length)up+=`<div class="ups">${ups.map(([c,a,b])=>{const t=findT(c);return `<div>${b>a?'▲':'▼'} <b>${esc(t?t.t.n:c)}</b>: ${LV[a]} → <span style="color:${LVC[b]}">${LV[b]}</span></div>`}).join('')}</div>`;
    return bar('Mashqlar',I.timer)+`<div class="pad qwrap"><div class="card" style="padding:22px;text-align:center;margin-top:12px">
    <img src="${IMG.p_yutuq}" style="width:110px"><div style="font-size:40px;font-weight:800;color:var(--good)">${sc}/${n}</div>
    <b style="font-size:20px;color:var(--navy)">${sc/n>=.7?'Barakalla!':'Yaxshi harakat!'}</b><p style="color:#33406a">${n} ta misoldan ${sc} tasini birinchi urinishda topdingiz.${Q.kind==='ttest'?(sc>=4?' Mavzu testi topshirildi!':' Test uchun 5 tadan kamida 4 tasini topish kerak.'):''}</p>
    <div class="gain">${dp>0?`+${dp} ball`:'Ball o\'zgarmadi'}${Q.kind==='kun'||Q.kind==='extra'?` · +${S.xday.n>3&&Q.kind==='extra'?Math.ceil(sc/2):sc} ★`:''}</div>${up}
    <button class="cta" data-c="endMashq()">Tayyor</button>
    ${Q.kind==='kun'||Q.kind==='extra'?`<button class="cta ghost" data-c="endMashq(1)">Yana ${N} ta misol</button>`:''}</div></div>`}
  const it=Q.items[Q.i], st=Q.st[Q.i]||{}, sym=it.sym, hs=st.hs||0;
  const conf=st.ok?`<div class="conf">${Array.from({length:18},(_,k)=>`<i style="left:${(k*53)%100}%;top:${k%2?R(0,10):R(85,100)}%;background:${['#ff4d6d','#2f8bff','#27b33e','#ffbe0b','#9b5de5'][k%5]};transform:rotate(${k*37}deg)"></i>`).join('')}</div>`:'';
  const hint=it.h&&it.h.length?`<div class="hint">${hs?`<ol>${it.h.slice(0,hs).map(x=>`<li>${esc(x)}</li>`).join('')}</ol>`:''}
     ${!st.ok&&hs<it.h.length?`<button class="hbtn2 ${st.miss?'pulse':''}" data-c="showHint()"><img src="${IMG.q_maslahat}" style="width:26px"> ${hs?'Keyingi qadam':'Maslahat'} <small>${hs}/${it.h.length}</small></button>`:''}</div>`:'';
  return bar('Mashqlar',I.timer)+`<div class="pad qwrap">
   <div class="card qhead"><b>${Q.i+1}/${n}-mashq</b><div class="pbar"><i style="width:${(Q.i+(st.ok?1:0))/n*100}%"></i></div></div>
   <div class="card qcard">${it.rc?`<div class="tag"><img src="${IMG.q_takror}" style="width:22px"> Takrorlash: ${esc(it.rn)}</div>`:''}${it.lb?`<div class="lb">${it.lb}</div>`:''}${it.qh||`<div class="ex2">${esc(it.q)}</div>`}${hint}</div>
   <div class="opts" style="${it.txt?'grid-template-columns:1fr':sym?'grid-template-columns:1fr 1fr 1fr':''}">${it.o.map((v,k)=>`<button class="opt ${it.oh?'txt':''} ${st.ok&&k===it.ai?'ok':''}" ${st.ok?'disabled':''} data-c="pick(this,${k})">${it.oh?`<b style="opacity:.55;margin-right:6px">${'ABCDE'[k]})</b>${it.oh[k]}`:esc(v)}</button>`).join('')}</div>
   <div id="fb">${st.ok?`<div class="win">${conf}<img src="${IMG.q_ball}"><b>To'g'ri javob!<br>${st.first?'Birinchi urinishda!':st.hint&&!st.miss?'Maslahat bilan topdingiz':"O'ylab topdingiz"}</b></div>`:''}</div>
   <div class="qnav"><button class="bk" data-c="${Q.i?'S.q.i--;render()':'back()'}">${I.back.replace('<svg','<svg width="20" height="20"')} Orqaga</button>
    <button class="nx" ${st.ok?'':'disabled'} data-c="S.q.i++;render()">${Q.i===n-1?'Natija':'Keyingi'} ${I.chev.replace('class="ch"','width="20" height="20"')}</button></div></div>`;
}
let lockQ=false;
function showHint(){const Q=S.q,st=Q.st[Q.i]=Q.st[Q.i]||{miss:false};st.hs=(st.hs||0)+1;st.hint=true;render()}
function pick(el,k){
  if(lockQ)return;const Q=S.q,it=Q.items[Q.i],st=Q.st[Q.i]=Q.st[Q.i]||{miss:false};
  if(k===it.ai){st.ok=true;act(1);st.first=!st.miss&&!st.hint;if(st.first){Q.first++;S.correct++;if(Q.kind==='kun'||Q.kind==='extra')S.stars+=(Q.kind==='extra'&&S.xday.n>3)?.5:1}
    if(it.rc&&st.first&&lv(it.rc)===3){S.lv[it.rc]=4;Q.ups.push([it.rc,3,4])}
    if(it.rc)S.seen[it.rc]=Date.now();render()}
  else{if(!st.miss){S.wrong++;
      S.err[it.ty]=(S.err[it.ty]||0)+1;if(S.err[it.ty]%3===0){const a=S.alerts.find(x=>x.ty===it.ty);if(a){a.n=S.err[it.ty];a.when=TODAY()}else{S.alerts.unshift({ty:it.ty,n:3,when:TODAY()});S.alerts=S.alerts.slice(0,20)}}
      if(it.rc&&lv(it.rc)===4){S.lv[it.rc]=3;Q.ups.push([it.rc,4,3])}}
    st.miss=true;lockQ=true;el.classList.add('bad');
    $('#fb').innerHTML=`<div class="win bad"><b>Bu javob noto'g'ri. Yana bir bor o'ylab ko'ring${it.h&&(st.hs||0)<it.h.length?' yoki "Maslahat"ni bosing':''}.</b></div>`;
    const hb=ROOT.querySelector('.hbtn2');if(hb)hb.classList.add('pulse');
    setTimeout(()=>{el.classList.remove('bad');lockQ=false},2000)}
}
function endMashq(more){const Q=S.q;S.mashq++;S.seen[Q.c]=Date.now();if(Q.kind==='kun')S.task.mashq=true;if(/test/.test(Q.kind))S.tests++;S.q=null;if(more){S.extra++;if(S.xday.d!==TODAY())S.xday={d:TODAY(),n:0};S.xday.n++;S.stack.pop();startDaily(1)}else back()}
/* ---------- TESTLAR ---------- */
function test(){
  const gs=groups().filter(g=>!/Tanqidiy|Mantiq/.test(g.name)).slice(0,5), s=S.seg.t??0, ic=['t_star','t_green','t_purple','t_orange','t_clock'];
  const rows=s===0?gs.map((g,i)=>{const p=pct(g),L=p===0&&i>2;return `<button class="row" data-c="${L?`toast('Mavzuni o\\'zlashtirsangiz ochiladi')`:p===100?`toast('Bo\\'lim o\\'zlashtirilgan')`:`topicTest('${(g.t.find(x=>!S.tp[x.c])||g.t[0]).c}')`}"><img class="ti" src="${IMG[ICON(g.name)]}"><div class="m"><b>${esc(SHORT(g.name))} bo'yicha test</b><small>${g.t.length>8?15:10} ta savol • ${g.t.length>8?15:10} daqiqa</small></div>
     ${L?`<span class="lock">${I.lock}</span>`:p===100?`<span class="badge ok"><span class="ck"></span>100%</span>`:`<span class="playc">${I.playf}</span>`}</button>`}).join('')
   :`<div class="card empty">Ustoz bergan va yakuniy testlar shu yerda chiqadi. Hozircha test yo'q.</div>`;
  return bar('Testlar',`<span style="width:26px">${I.clip}</span>`)+`<div class="pad">${seg('t',['Mavzu testlari','Yakuniy testlar'])}<div class="list">${rows}</div></div>`;
}
async function miniTest(c){const items=await loading(()=>bankItems(c,5));S.q={c,kind:'test',items,i:0,st:[],first:0,ups:[],r0:rankOf(S.pts),p0:calcPts()};S.task.test=true;go('mashq')}
async function bolimTest(i){const g=groups()[i];const items=await loading(async()=>{const a=[];for(const t of g.t)a.push(...await bankItems(t.c,2));return a});S.q={c:g.t[0].c,gi:i,kind:'btest',items,i:0,st:[],first:0,ups:[],r0:rankOf(S.pts),p0:calcPts()};go('mashq')}
async function topicTest(c){const items=await loading(()=>bankItems(c,5));S.q={c,kind:'ttest',items,i:0,st:[],first:0,ups:[],r0:rankOf(S.pts),p0:calcPts()};S.task.test=true;go('mashq')}
/* ---------- O'YINLAR ---------- */
function oyin(){
  const all=[['g_castle','Sonlar sarguzashti',1],['g_ops','Amallar marafoni',2],['g_pie','Kasrlar olami',2],['g_geo','Geometrik kvest',1],['g_chest','Mantiqiy topishmoqlar',1],['g_clock','Tezkor hisoblash',2]];
  const s=S.seg.o??0, l=all.filter(x=>s===0||x[2]===s);
  return bar("Matematik o'yinlar")+`<div class="pad">${seg('o',['Barchasi','Mantiqiy','Hisoblash'])}<div class="games">${l.map(x=>`<button class="gm" data-c="toast('O\\'yinlar tez orada ochiladi')"><img src="${IMG[x[0]]}"><b>${x[1]}</b></button>`).join('')}</div></div>`;
}
/* ---------- NATIJALAR ---------- */
function natija(){
  const s=S.seg.n??0, tot=S.correct+S.wrong, p=tot?Math.round(S.correct/tot*100):0;
  const gs=groups().filter(g=>pct(g)>0);
  const bars=gs.map(g=>`<div class="br"><span>${esc(SHORT(g.name))}</span><div class="bt"><i style="width:${pct(g)}%"></i></div><b>${pct(g)}%</b></div>`).join('')||'<p style="color:var(--muted)">Hali natija yo\'q</p>';
  const r=54,C=2*Math.PI*r;
  const donut=`<svg class="donut" viewBox="0 0 136 136"><circle cx="68" cy="68" r="${r}" fill="none" stroke="#dcefdc" stroke-width="16"/><circle cx="68" cy="68" r="${r}" fill="none" stroke="url(#gg)" stroke-width="16" stroke-linecap="round" stroke-dasharray="${C*p/100} ${C}" transform="rotate(-90 68 68)"/><defs><linearGradient id="gg"><stop offset="0" stop-color="#1fa34a"/><stop offset="1" stop-color="#5bd36b"/></linearGradient></defs><text x="68" y="70" text-anchor="middle" font-size="30" font-weight="800" fill="#0f1f5c">${p}%</text><text x="68" y="92" text-anchor="middle" font-size="12.5" fill="#0f1f5c">O'zlashtirish</text></svg>`;
  const week=Array.from({length:7},(_,i)=>{const d=new Date(Date.now()+5*36e5-(6-i)*864e5),k=d.toISOString().slice(0,10);return[['Ya','Du','Se','Ch','Pa','Ju','Sh'][d.getUTCDay()],S.days[k]||0]}),wm=Math.max(5,...week.map(w=>w[1]));
  const dyn=`<div class="card sec"><div class="sec-h"><b>Haftalik faollik</b><span style="color:var(--muted);font-size:13px">yechilgan misollar</span></div><svg viewBox="0 0 320 170" style="width:100%">${week.map(([d,v],i)=>`<rect x="${16+i*44}" y="${140-v/wm*110}" width="28" height="${v/wm*110}" rx="6" fill="${i===6?'#1f6fff':'#9cc0ff'}"/><text x="${30+i*44}" y="160" text-anchor="middle" font-size="12" fill="#0f1f5c">${d}</text><text x="${30+i*44}" y="${134-v/wm*110}" text-anchor="middle" font-size="12" font-weight="700" fill="#0f1f5c">${v||''}</text>`).join('')}</svg></div>`;
  const main=`<div class="card res">${donut}<div class="stat"><div><span class="si" style="background:var(--good)">✓</span>To'g'ri:<b>${S.correct}</b></div><div><span class="si" style="background:var(--wrong)">✕</span>Noto'g'ri:<b>${S.wrong}</b></div><div><span class="si" style="background:var(--blue);border-radius:6px">≡</span>Testlar:<b>${S.tests}</b></div></div></div>`;
  const tb=`<div class="card sec"><div class="sec-h"><span class="ico" style="color:var(--blue)">${I.chart}</span><b>Mavzular bo'yicha natija</b></div><div class="bars">${bars}</div></div>`;
  return bar('Mening natijalarim')+`<div class="pad">${seg('n',['Umumiy','Mavzular','Dinamika'])}${s===0?'<div class="ngrid">'+main+tb+'</div>':s===1?tb:dyn}</div>`;
}
/* ---------- YUTUQLAR ---------- */
const MED=[
 ['a_birinchi','Birinchi dars',"Birinchi darsni tugatsangiz",()=>Object.values(S.lv).some(v=>v>0)],
 ['a_mavzu_ustasi','Mavzu ustasi',"Birinchi mavzuni \"O'zlashtirgan\" darajasiga yetkazsangiz",()=>gT().some(t=>lv(t.c)===4)],
 ['a_bolim',"Bo'limni yakunladi","Bitta bo'limni 100% qilsangiz",()=>gG().some(g=>pct(g)===100)],
 ['a_kurs','Kursni tugatdi',"Butun sinf kursini 100% qilsangiz",()=>gG().filter(g=>!/Tanqidiy/.test(g.name)).every(g=>pct(g)===100)],
 ['a_k7','7 kun ketma-ket',"7 kun uzluksiz shug'ullansangiz",()=>S.streak>=7],
 ['a_k30','30 kun ketma-ket',"30 kun uzluksiz shug'ullansangiz",()=>S.streak>=30],
 ['a_tezkor',"Tezkor o'quvchi","Kunlik vazifani 5 daqiqadan tez va xatosiz bajarsangiz",()=>S.fast],
 ['m_hisob','Hisoblash ustasi',"Qo'shish, ayirish, ko'paytirish va bo'lish bo'limlarini o'zlashtirsangiz",()=>{const l=gG().filter(g=>/Qo'shish|Ko'paytirish/.test(g.name));return l.length&&l.every(g=>pct(g)===100)}],
 ['m_geom','Geometriya bilimdoni',"Geometriya bo'limini o'zlashtirsangiz",()=>gG().some(g=>/Geometr/.test(g.name)&&pct(g)===100)],
 ['m_formula','Formula ustasi',"\"Ifodalar va tenglamalar\" bo'limini o'zlashtirsangiz (3–4-sinf)",()=>gG().some(g=>/Ifoda/.test(g.name)&&pct(g)===100)],
 ['m_mantiq','Mantiqiy fikrlovchi',"Mantiq bo'limidan 10 ta darsni o'zlashtirsangiz",()=>gG().filter(g=>/Mantiq/.test(g.name)).flatMap(g=>g.t).filter(t=>lv(t.c)===4).length>=10],
 ['m_masala','Masala yechuvchi',"Matnli masalalar bo'limini o'zlashtirsangiz",()=>gG().some(g=>/Matnli/.test(g.name)&&pct(g)===100)],
 ['m_kashf','Kashfiyotchi',"5 xil bo'limdan dars boshlasangiz",()=>gG().filter(g=>g.t.some(t=>lv(t.c)>0)).length>=5],
 ['m_ilm','Ilmga qiziquvchi',"\"Yana … ta misol\" tugmasini 20 marta bossangiz",()=>S.extra>=20]];
const gG=()=>G[S.grade]||[], gT=()=>gG().flatMap(g=>g.t);
const kz=i=>{const g=gG().find(g=>/Kelajak/.test(g.name));return g?g.t[i]:null};
[['f_chamalash','Chamalash ustasi'],['f_ehtimol','Ehtimollar bilimdoni'],['f_shifr','Shifr ustasi'],['f_tejamkor','Tejamkor'],['f_dasturchi','Kichik dasturchi'],['f_tahlil',"Ma'lumot tahlilchisi"]].forEach(([k,n],i)=>MED.push([k,n,`Kelajak matematikasidagi "${n.split(' ')[0]}" mavzusini o'zlashtirsangiz`,()=>{const t=kz(i);return !!t&&lv(t.c)===4}]));
MED.push(['f_kashfiyot','Kelajak kashfiyotchisi',"Kelajak matematikasining 6 ta mavzusini hammasini o'zlashtirsangiz",()=>[0,1,2,3,4,5].every(i=>{const t=kz(i);return t&&lv(t.c)===4})]);
function medal(i){const m=MED[i],ok=m[3]();const o=document.createElement('div');o.className='ov';o.addEventListener('click',e=>{if(e.target===o)o.remove()});
 o.innerHTML=`<div class="box" style="text-align:center"><img src="${IMG[m[0]]}" style="width:150px;${ok?'':'filter:grayscale(1);opacity:.5'}"><h3 style="margin:8px 0 4px;color:var(--navy)">${m[1]}</h3><p style="margin:0;color:#33406a">${ok?'Siz bu medalni oldingiz. Barakalla!':'Qanday olinadi: '+m[2]+'.'}</p><button class="cta" data-c="this.closest('.ov').remove()">Yopish</button></div>`;ROOT.appendChild(o)}
function yutuq(){
  const mast=gT().filter(t=>lv(t.c)===4).length, r=rankOf(S.pts), nx=RANK[r+1];
  const got=MED.filter(m=>m[3]()).length;
  const sec=(title,from,to)=>`<div class="card sec"><div class="sec-h"><b>${title}</b><span class="c" style="font-size:14px">${MED.slice(from,to).filter(m=>m[3]()).length}/${to-from}</span></div><div class="medals">${MED.slice(from,to).map((m,i)=>`<button class="md ${m[3]()?'':'no'}" data-c="medal(${from+i})"><img src="${IMG[m[0]]}" alt="${m[1]}"></button>`).join('')}</div></div>`;
  return bar('Yutuqlarim')+`<div class="pad">
   <div class="card rankc"><img class="big" src="${IMG['l_d'+(r+1)]}"><div class="ri"><small>Rivojlanish darajam</small><b>${RANK[r][1]}</b><span>${r+1}-daraja · ${fmt(S.pts)} / 10 000 ball · ${Math.floor(S.stars+optStars())} ★</span>
     ${nx?`<div class="pbar" style="margin-top:8px"><i style="width:${(S.pts-RANK[r][0])/(nx[0]-RANK[r][0])*100}%"></i></div><small>${nx[0]===10000?`"Yosh Xorazmiy" — kursdagi hamma mavzuni o'zlashtirib, testlarini topshirganda`:`"${nx[1]}" darajasiga ${fmt(nx[0]-S.pts)} ball qoldi`}</small>`:'<small>Eng yuqori daraja!</small>'}</div></div>
   <div class="ranks">${RANK.map((x,i)=>`<div class="${i<=r?'':'no'}"><img src="${IMG['l_d'+(i+1)]}"><small>${fmt(x[0])}+</small></div>`).join('')}</div>
   <div class="ach"><div class="a" style="background:linear-gradient(180deg,#fff4dc,#ffe9bf)"><img src="${IMG.q_kunlik}"><b>${S.streak} kun</b><small>faollik</small></div>
    <div class="a" style="background:linear-gradient(180deg,#eaf2ff,#d9e7ff)"><img src="${IMG.p_mashq}"><b>${S.mashq} ta</b><small>mashq</small></div>
    <div class="a" style="background:linear-gradient(180deg,#f3ecff,#e6dbff)"><img src="${IMG.p_yutuq}"><b>${got}/${MED.length}</b><small>medal</small></div></div>
   <div class="ygrid"><div>${sec("O'quv yutuqlari",0,7)}</div><div>${sec('Matematik mahorat',7,14)}${sec('Kelajak medallari',14,21)}
</div></div></div></div>`;
}
/* ---------- PROFIL ---------- */
function profil(){return bar('Profil')+`<div class="pad"><div class="card prof"><div class="ava">${esc(S.name[0]||'')}</div><b style="font-size:20px;color:var(--navy)">${esc(S.kid.name)}</b>
  <dl><dt>Sinf</dt><dd>${esc(S.kid.cls)}</dd><dt>Maktab</dt><dd>${esc(S.kid.school)}</dd>${S.kid.teacher?`<dt>Sinf rahbari</dt><dd>${esc(S.kid.teacher)}</dd>`:''}<dt>Ball</dt><dd>${fmt(S.pts)} / 10 000</dd><dt>Yulduzlar</dt><dd>${Math.floor(S.stars+optStars())} ★</dd><dt>Daraja</dt><dd>${RANK[rankOf(S.pts)][1]} (${rankOf(S.pts)+1}-daraja)</dd></dl>
  <button class="cta ghost" data-c="close()">Saytga qaytish</button></div>
  <div class="card sec"><div class="sec-h"><b>Qiyin bo'layotgan joylar</b></div>
   <p style="margin:0 0 10px;color:#33406a;font-size:14.5px">Bir turdagi misolda 3 marta xato qilinsa, shu yerda va sinf rahbaringiz kabinetida belgi chiqadi. Ustoz shu mavzuda yordam beradi.</p>
   ${S.alerts.length?S.alerts.map(a=>`<div class="alrt"><span>!</span><div><b>${esc(a.ty)}</b><small>${a.n} marta xato · ${a.when} · ustozga ko'rinadi</small></div></div>`).join(''):'<p style="color:var(--good);margin:0">Hozircha belgi yo\'q. Barakalla!</p>'}</div></div>`}


function save(){if(!S||!SID)return;const p={};for(const k of PKEYS)p[k]=S[k];const j=JSON.stringify(p);if(j===SAVED)return;clearTimeout(saveT);
  saveT=setTimeout(()=>{SAVED=j;api('oq.yoz',{sid:SID,prog:p,pts:calcPts(),rank:rankOf(calcPts())}).catch(()=>{SAVED=''})},1200)}
function flush(){if(saveT){clearTimeout(saveT);saveT=null;const p={};for(const k of PKEYS)p[k]=S[k];SAVED=JSON.stringify(p);return api('oq.yoz',{sid:SID,prog:p,pts:calcPts(),rank:rankOf(calcPts())}).catch(()=>{})}}
function close(){flush();if(HOST){HOST.remove();HOST=null}document.documentElement.style.overflow=''}
const NAMES=new Set(["$", "BANK", "DAILY", "G", "HICO", "I", "ICON", "LV", "LVC", "LVSH", "MED", "NAV", "NAVOF", "OPT", "PKEYS", "PT", "R", "RANK", "SHORT", "TODAY", "XN", "YDAY", "act", "addHints", "allDone", "allT", "back", "ballCard", "bankItems", "bar", "bolim", "bolimTest", "calcPts", "coreT", "curGroup", "curTopic", "curTopicOf", "dars", "darslar", "digits", "endMashq", "esc", "findT", "fmt", "fresh", "fromBank", "gG", "gen", "go", "groups", "home", "kz", "lessonDone", "loading", "lockQ", "locked", "lv", "lvBars", "lvPill", "mUrl2", "mashq", "medal", "miniTest", "mulHints", "natija", "norm", "openLesson", "optStars", "opts", "oyin", "pct", "pick", "profil", "rankOf", "render", "seg", "showHint", "shuf", "startDaily", "startMashq", "subHints", "tParts", "tab", "test", "toast", "topicCode", "topicTest", "yutuq", "close", "save", "flush", "IMG", "HOST", "ROOT", "S", "READY", "toast"]);
const SCOPE=new Proxy({},{has:(t,k)=>NAMES.has(k),get:(t,k)=>eval(k)});
function run(code,el,ev){try{return Function('__s','event','with(__s){'+code+'\n}').call(el,SCOPE,ev)}catch(e){console.error(e)}}
async function open(sid){
  if(HOST)close();SID=+sid;
  let d;try{d=await api('oq.get',{sid:SID})}catch(e){(typeof toast==='function'?toast:alert)(e.message||'Xatolik');return}
  HOST=document.createElement('div');HOST.id='oqHost';HOST.style.cssText='position:fixed;inset:0;z-index:9000;overflow:auto;background:#eef3ff;-webkit-overflow-scrolling:touch';
  ROOT=HOST.attachShadow({mode:'open'});
  ROOT.innerHTML='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600;700;800&display=swap"><style>'+CSS+'</style><div class="wrap">'+"<aside class=\"side\" id=\"side\"></aside><div class=\"app\" id=\"app\"></div>\n<nav class=\"bnav\" id=\"bnav\"></nav>"+'<button class="oqx" data-c="close()" title="Yopish">×</button></div>';
  ROOT.addEventListener('click',e=>{const b=e.target.closest('[data-c]');if(b&&ROOT.contains(b)){e.preventDefault();run(b.getAttribute('data-c'),b,e)}});
  ROOT.addEventListener('change',e=>{const b=e.target.closest('[data-ch]');if(b)run(b.getAttribute('data-ch'),b,e)});
  document.body.appendChild(HOST);document.documentElement.style.overflow='hidden';
  G={};G[d.kid.grade]=(d.topics||[]).map(([n,l])=>({name:String(n).replace(/^[^A-Za-z0-9Ѐ-ӿ']+/,'').trim(),t:l.map(([c,nm])=>({c,n:nm}))}));
  const nm=String(d.kid.name||'').trim().split(/\s+/);d.kid.first=nm[1]||nm[0]||'';
  S=fresh(d.kid,d.prog);{const p={};for(const k of PKEYS)p[k]=S[k];SAVED=JSON.stringify(p)}
  try{const a=await fetch('/darslar/ready.json',{cache:'no-cache'}).then(r=>r.ok?r.json():[]);READY=new Set(a)}catch(e){}
  render();
}
window.addEventListener('pagehide',()=>{if(S)flush()});
window.OQ={open,close};
})();
