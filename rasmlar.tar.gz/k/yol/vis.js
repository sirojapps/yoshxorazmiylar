// Asosiy bank — rasm chizgich. Misoldagi v (tavsif) dan SVG/HTML yasaydi. Brauzerda ham, Node'da ham ishlaydi.
// Narsalar (olma, qalam, tanga...) — ChatGPT chizgan rasmlar (img/*.webp). Dastur faqat joylaydi, sonni yozadi,
// chiziq/jadval/diagramma/shakl kabi o‘lchov chizmalarini chizadi.
// Qo‘shimcha turlar: vis-ext/<nom>.js faylida V.ext.<tur> = v => '<svg ...>' deb qo‘shiladi.
(function (root) {
  const V = { ext: {} };
  V.IMG = {}; // nomi -> manzil (sahifada data: bilan to‘ldiriladi)
  const src = n => V.IMG[n] || ('img/' + n + '.webp?v=' + (root.YVER || ''));
  V.has = n => !!V.IMG[n];
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const P = { ink: '#0b2a6f', blue: '#2563eb', sky: '#dbeafe', gold: '#f5b301', red: '#ef4444', green: '#16a34a', grey: '#94a3b8', line: '#334155', pale: '#f1f5f9',
    fills: ['#60a5fa', '#34d399', '#fbbf24', '#f472b6', '#a78bfa', '#fb923c', '#2dd4bf'] };
  V.P = P;
  const svg = (w, h, body, mw) => `<svg class="vs" viewBox="0 0 ${w} ${h}" style="width:100%;max-width:${mw || w}px" xmlns="http://www.w3.org/2000/svg" font-family="Nunito,system-ui,sans-serif">${body}</svg>`;
  const T = (x, y, s, o = {}) => `<text x="${x}" y="${y}" font-size="${o.fs || 16}" font-weight="${o.fw || 800}" fill="${o.c || P.ink}" text-anchor="${o.a || 'middle'}" dominant-baseline="central"${o.st ? ' stroke="#fff" stroke-width="4" paint-order="stroke"' : ''}>${esc(s)}</text>`;
  V.T = T; V.svg = svg; V.esc = esc; V.src = src;
  const im = (n, x, y, w, h) => `<image href="${src(n)}" x="${x}" y="${y}" width="${w}" height="${h || w}" preserveAspectRatio="xMidYMid meet"/>`;
  V.im = im;

  // --- obj: narsalar guruhlari. {g:[{img,n,lb,box,cross}], cols}
  // Qoida (Siroj 09.11 21:57): olingan/yeyilgan narsalar ustiga CHIZIQ TORTILMAYDI — rasm «avvalgi holat»ni ko‘rsatadi, bola ayirishni o‘zi qiladi (chizilsa qolganini sanab qo‘yadi). cross qabul qilinadi, lekin chizilmaydi.
  // shtrix (yopiq o‘nlik) uchun naqsh — har chaqiriqda yangi id
  let hatchN = 0;
  const hatch = (x, y, w, h, lb) => { const id = 'ht' + (++hatchN); return `<defs><pattern id="${id}" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="10" stroke="#93c5fd" stroke-width="3"/></pattern></defs><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="14" fill="url(#${id})" stroke="#3b82f6" stroke-width="2.5"/><rect x="${x + w / 2 - 34}" y="${y + h / 2 - 18}" width="68" height="36" rx="10" fill="#fff" stroke="#3b82f6" stroke-width="2"/>${T(x + w / 2, y + h / 2 + 1, lb, { fs: 20, c: P.blue })}` };
  V.hatch = hatch;
  // Haqiqiy «10 talik» idish rasmlari (ChatGPT): [ochiq, yopiq]
  V.BOX10 = { olma: ['olma-quti-ochiq', 'olma-quti-yopiq'], nok: ['nok-quti-ochiq', 'nok-quti-yopiq'], tuxum: ['tuxum-qolip-ochiq', 'tuxum-qolip-yopiq'], 'koptok-qizil': ['shar-quti-ochiq', 'shar-quti-yopiq'] };
  function obj(v) {
    const gs0 = v.g, cols = v.cols || 5;
    // Qoida (Siroj 09.11): to‘la o‘nliklar bittalab sanaladigan bo‘lmasin — ≥2 ta to‘la guruh bo‘lsa, birinchisi ochiq, qolganlari yopiq (shtrix, «10»)
    const full = gs0.filter(g => g.n === 10 && !g.cross && !g.dash && !g.num);
    // Haqiqiy «10 talik» idish rasmlari (ChatGPT): [ochiq, yopiq] — bor bo‘lsa, to‘la guruh shu rasm bilan chiqadi (birinchisi ochiq, qolgani yopiq)
    const BOX = V.BOX10;
    let seenFull = false; const gs = gs0.map(g => { if (full.length >= 2 && full.includes(g)) { const bx = BOX[g.img]; const r = seenFull ? { ...g, closed: true, pic: bx && bx[1] } : { ...g, pic: bx && bx[0] }; seenFull = true; return r } return g });
    const s = v.size || (gs.reduce((a, g) => a + (g.closed || g.pic ? 0 : g.n), 0) > 30 ? 30 : 40);
    const PS = 112; // idish rasmi kattaligi
    const blocks = gs.map(g => { if (g.pic) return { g, c: 1, r: 1, w: PS, h: PS + (g.lb ? 24 : 0) }; const c = Math.min(cols, g.n), r = Math.ceil(g.n / cols); return { g, c, r, w: Math.max(c, 1) * s + 16, h: Math.max(r, 1) * s + 16 + (g.lb ? 24 : 0) } });
    let W = 0, H = 0, x = 0, y = 0, rowH = 0; const maxW = v.maxW || 560; const pos = [];
    for (const b of blocks) { if (x && x + b.w > maxW) { x = 0; y += rowH + 12; rowH = 0 } pos.push([x, y]); x += b.w + 12; rowH = Math.max(rowH, b.h); W = Math.max(W, x - 12) } H = y + rowH;
    let out = '';
    blocks.forEach((b, i) => {
      const [bx, by] = pos[i], g = b.g;
      if (g.pic) { out += im(g.pic, bx, by, PS, PS); if (g.lb) out += T(bx + b.w / 2, by + b.h - 13, g.lb, { fs: 15 }); return }
      if (g.closed) { out += hatch(bx, by, b.w, b.h - (g.lb ? 24 : 0), '10 ta'); if (g.lb) out += T(bx + b.w / 2, by + b.h - 13, g.lb, { fs: 15 }); return }
      if (g.hl) out += `<rect x="${bx - 3}" y="${by - 3}" width="${b.w + 6}" height="${b.h + 6}" rx="16" fill="#fef08a" stroke="#f59e0b" stroke-width="3"/>`; // Ustoz ko‘rsatuvi: shu guruh yonib turadi
      if (gs.length > 1 || g.box) out += `<rect x="${bx}" y="${by}" width="${b.w}" height="${b.h}" rx="14" fill="${g.box === 'none' ? 'none' : '#eff6ff'}" stroke="#93c5fd" stroke-width="2" ${g.dash ? 'stroke-dasharray="6 5"' : ''}/>`;
      for (let k = 0; k < g.n; k++) {
        const cx = bx + 8 + (k % cols) * s, cy = by + 8 + Math.floor(k / cols) * s;
        out += im(g.img, cx + 2, cy + 2, s - 4);
        if (false && g.cross && k >= g.n - g.cross) out += `<path d="M${cx + 4} ${cy + 4}L${cx + s - 4} ${cy + s - 4}M${cx + s - 4} ${cy + 4}L${cx + 4} ${cy + s - 4}" stroke="${P.red}" stroke-width="4" stroke-linecap="round"/>`;
        if (g.num) out += T(cx + s - 6, cy + 8, k + 1, { fs: 11, c: P.blue, st: 1 });
      }
      if (g.lb) out += T(bx + b.w / 2, by + b.h - 13, g.lb, { fs: 15 });
    });
    return svg(W + 8, H + 8, `<g transform="translate(4 4)">${out}</g>`);
  }

  // --- nline: sonlar nuri. {a,b,step,lab (har nechta),pts:[{x,c,lb}],jumps:[{f,t,lb}],hide:[x],q:[x]}
  function nline(v) {
    const a = v.a, b = v.b, st = v.step || 1, n = Math.round((b - a) / st), W = 560, L = 24, R = W - 24, u = (R - L) / n, y = 80;
    const X = x => L + (x - a) / st * u; let o = `<line x1="${L - 10}" y1="${y}" x2="${R + 14}" y2="${y}" stroke="${P.line}" stroke-width="3"/><path d="M${R + 16} ${y}l-10 -6v12z" fill="${P.line}"/>`;
    const lab = v.lab || (n > 20 ? 5 : 1);
    for (let i = 0; i <= n; i++) {
      const x = a + i * st, big = i % lab === 0; o += `<line x1="${X(x)}" y1="${y - (big ? 9 : 5)}" x2="${X(x)}" y2="${y + (big ? 9 : 5)}" stroke="${P.line}" stroke-width="${big ? 2.5 : 1.5}"/>`;
      if (big && !(v.hide || []).includes(x)) o += T(X(x), y + 26, x, { fs: n > 20 ? 14 : 18 });
      if ((v.q || []).includes(x)) o += `<rect x="${X(x) - 15}" y="${y + 12}" width="30" height="24" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + T(X(x), y + 24, '?', { fs: 16, c: '#b45309' });
    }
    const anyHl = (v.jumps || []).some(j => j.hl); // Ustoz ko‘rsatuvi: hl sakrash yonadi (to‘q sariq, qalin), qolganlari kulrang
    (v.jumps || []).forEach((j, k) => { const x1 = X(j.f), x2 = X(j.t), h = Math.min(50, 18 + Math.abs(x2 - x1) / 4); const jc = anyHl ? (j.hl ? '#f59e0b' : '#cbd5e1') : (j.c || P.fills[k % 7]); o += `<path d="M${x1} ${y - 8}Q${(x1 + x2) / 2} ${y - 8 - h * 1.6} ${x2} ${y - 10}" fill="none" stroke="${jc}" stroke-width="${j.hl ? 5 : 3}"/><path d="M${x2} ${y - 9}l${x2 > x1 ? -9 : 9} -5l${x2 > x1 ? 1 : -1} 9z" fill="${jc}"/>`; if (j.lb) o += T((x1 + x2) / 2, y - 12 - h * .85, j.lb, { fs: 17, c: j.c || P.ink, st: 1 }) });
    (v.pts || []).forEach(p => { o += `<circle cx="${X(p.x)}" cy="${y}" r="7" fill="${p.c || P.red}" stroke="#fff" stroke-width="2"/>`; if (p.lb) o += T(X(p.x), y - 20, p.lb, { fs: 17, c: p.c || P.red, st: 1 }) });
    return svg(W, 118, o);
  }

  // --- tbl: jadval {h:[...], rows:[[...]], hl, cap}
  function tbl(v) {
    const th = (v.h || []).map(x => `<th>${x}</th>`).join('');
    const tr = v.rows.map((r, i) => `<tr${i === v.hl ? ' class="hl"' : ''}>${r.map((c, j) => (v.rh && j === 0 ? `<th>${c}</th>` : `<td>${c}</td>`)).join('')}</tr>`).join('');
    return `<table class="vt">${v.cap ? `<caption>${v.cap}</caption>` : ''}${th ? `<thead><tr>${th}</tr></thead>` : ''}<tbody>${tr}</tbody></table>`;
  }

  // --- bar: ustunli diagramma {lb:[], val:[], step, max, unit, title}
  function bar(v) {
    const n = v.lb.length, max = v.max || Math.max(...v.val), step = v.step || (max > 20 ? 5 : max > 10 ? 2 : 1), top = Math.ceil(max / step) * step;
    const L = 44, B = 210, H = 180, bw = Math.min(64, 420 / n * .6), gap = (500 - L) / n; let o = '';
    for (let y = 0; y <= top; y += step) { const yy = B - y / top * H; o += `<line x1="${L}" y1="${yy}" x2="${500}" y2="${yy}" stroke="#e2e8f0" stroke-width="1.5"/>` + T(L - 8, yy, y, { fs: 19, a: 'end' }) }
    v.val.forEach((x, i) => { const cx = L + gap * (i + .5), h = x / top * H; o += `<rect x="${cx - bw / 2}" y="${B - h}" width="${bw}" height="${h}" rx="6" fill="${(v.c && v.c[i]) || P.fills[i % 7]}"/>`; if (v.showv !== false && !(v.hide || []).includes(i)) o += T(cx, B - h - 13, x, { fs: 20 }); o += T(cx, B + 20, v.lb[i], { fs: n > 6 ? 15 : 18 }) });
    o += `<line x1="${L}" y1="${B}" x2="500" y2="${B}" stroke="${P.line}" stroke-width="2.5"/><line x1="${L}" y1="${B}" x2="${L}" y2="${B - H - 10}" stroke="${P.line}" stroke-width="2.5"/>`;
    if (v.title) o += T(270, 12, v.title, { fs: 18 });
    return svg(510, 240, o);
  }

  // --- pic: piktogramma {lb:[], val:[], img, per, key}
  function pic(v) {
    const per = v.per || 1, s = 30, uid = 'hc' + (V._n = (V._n || 0) + 1) + '_', rows = v.lb.map((l, i) => { const k = v.val[i] / per, full = Math.floor(k), half = k - full >= .5; return { l, full, half } });
    const W = 120 + Math.max(...rows.map(r => r.full + (r.half ? 1 : 0))) * s + 10; let o = '';
    rows.forEach((r, i) => { const y = 8 + i * (s + 10); o += `<rect x="0" y="${y - 4}" width="${W}" height="${s + 8}" rx="8" fill="${i % 2 ? '#fff' : '#eff6ff'}"/>` + T(8, y + s / 2, r.l, { fs: 14, a: 'start' }); for (let k = 0; k < r.full; k++) o += im(v.img, 116 + k * s, y, s - 2); if (r.half) o += `<clipPath id="${uid}${i}"><rect x="${116 + r.full * s}" y="${y}" width="${(s - 2) / 2}" height="${s}"/></clipPath><g clip-path="url(#${uid}${i})">${im(v.img, 116 + r.full * s, y, s - 2)}</g>` });
    const H = 8 + rows.length * (s + 10); o += `<g>${im(v.img, 6, H + 4, 24)}${T(36, H + 16, '= ' + (v.key || per + ' ta'), { fs: 14, a: 'start' })}</g>`;
    return svg(Math.max(W, 220), H + 34, o);
  }

  // --- geo: katakli/oddiy chizma. Birlik — katak (u px). {w,h,u,grid,el:[...]}
  // el: {p:'poly',pts,fill,lb:[tomon yozuvlari],vl:[uch nomlari]} {p:'seg',a,b,lb,ends:'pt'|'ray'|'line'|'none',c} {p:'pt',a,lb}
  //     {p:'circ',c,r,fill,ring} {p:'txt',a,s} {p:'ang',a,b,c (uch b), right} {p:'cells',list:[[x,y]],fill}
  function geo(v) {
    const u = v.u || 28, W = v.w * u, H = v.h * u, pd = 22; const X = p => pd + p[0] * u, Y = p => pd + p[1] * u; let o = '';
    if (v.grid) { for (let i = 0; i <= v.w; i++) o += `<line x1="${pd + i * u}" y1="${pd}" x2="${pd + i * u}" y2="${pd + H}" stroke="#bfdbfe" stroke-width="1"/>`; for (let j = 0; j <= v.h; j++) o += `<line x1="${pd}" y1="${pd + j * u}" x2="${pd + W}" y2="${pd + j * u}" stroke="#bfdbfe" stroke-width="1"/>` }
    for (const e of v.el) {
      const c = (e.p === 'ang' || e.p === 'circ') ? (e.col || P.blue) : (e.c || P.blue);
      if (e.p === 'cells') for (const q of e.list) o += `<rect x="${X(q) + 1}" y="${Y(q) + 1}" width="${u - 2}" height="${u - 2}" rx="3" fill="${e.fill || '#93c5fd'}"/>`;
      if (e.p === 'poly') {
        o += `<polygon points="${e.pts.map(p => X(p) + ',' + Y(p)).join(' ')}" fill="${e.fill || '#bfdbfe99'}" stroke="${c}" stroke-width="3" stroke-linejoin="round"/>`;
        const cx = e.pts.reduce((a, p) => a + p[0], 0) / e.pts.length, cy = e.pts.reduce((a, p) => a + p[1], 0) / e.pts.length;
        (e.lb || []).forEach((l, i) => { if (l == null || l === '') return; const p = e.pts[i], q = e.pts[(i + 1) % e.pts.length], mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2; let dx = mx - cx, dy = my - cy; const d = Math.hypot(dx, dy) || 1; o += T(X([mx + dx / d * .55, 0]), Y([0, my + dy / d * .55]), l, { fs: 14, st: 1 }) });
        (e.vl || []).forEach((l, i) => { const p = e.pts[i]; let dx = p[0] - cx, dy = p[1] - cy; const d = Math.hypot(dx, dy) || 1; o += T(X([p[0] + dx / d * .55, 0]), Y([0, p[1] + dy / d * .55]), l, { fs: 15, c: P.red, st: 1 }) });
      }
      if (e.p === 'seg') {
        let a = e.a, b = e.b; const dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy);
        const ext = (p, s) => [p[0] + dx / d * s, p[1] + dy / d * s]; const A = e.ends === 'line' ? ext(a, -1.2) : a, B = (e.ends === 'line' || e.ends === 'ray') ? ext(b, 1.4) : b;
        o += `<line x1="${X(A)}" y1="${Y(A)}" x2="${X(B)}" y2="${Y(B)}" stroke="${c}" stroke-width="3.5" stroke-linecap="round"${e.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
        if (e.ends === 'ray' || e.ends === 'line') { const ang = Math.atan2(dy, dx) * 180 / Math.PI; o += `<path d="M0 0l-11 -6v12z" fill="${c}" transform="translate(${X(B)} ${Y(B)}) rotate(${ang})"/>`; if (e.ends === 'line') o += `<path d="M0 0l-11 -6v12z" fill="${c}" transform="translate(${X(A)} ${Y(A)}) rotate(${ang + 180})"/>` }
        if (e.ends !== 'none') { o += `<circle cx="${X(a)}" cy="${Y(a)}" r="5" fill="${P.ink}"/>`; if (!e.ends || e.ends === 'pt') o += `<circle cx="${X(b)}" cy="${Y(b)}" r="5" fill="${P.ink}"/>` }
        if (e.lb) o += T(X([(a[0] + b[0]) / 2 - dy / d * .55, 0]), Y([0, (a[1] + b[1]) / 2 + dx / d * .55]), e.lb, { fs: 14, st: 1 });
        if (e.la) o += T(X(a) - 2, Y(a) - 16, e.la, { fs: 15, c: P.red, st: 1 }); if (e.lbb) o += T(X(b) + 2, Y(b) - 16, e.lbb, { fs: 15, c: P.red, st: 1 });
      }
      if (e.p === 'pt') { o += `<circle cx="${X(e.a)}" cy="${Y(e.a)}" r="5.5" fill="${e.c || P.ink}"/>`; if (e.lb) o += T(X(e.a) + 12, Y(e.a) - 14, e.lb, { fs: 15, c: P.red, st: 1 }) }
      if (e.p === 'circ') o += `<circle cx="${X(e.c)}" cy="${Y(e.c)}" r="${e.r * u}" fill="${e.ring ? 'none' : (e.fill || '#bfdbfe99')}" stroke="${e.sc || P.blue}" stroke-width="3"/>`;
      if (e.p === 'txt') o += T(X(e.a), Y(e.a), e.s, { fs: e.fs || 15, c: e.c || P.ink, st: 1 });
      if (e.p === 'ang') {
        const [a, b, cc] = [e.a, e.b, e.c]; const a1 = Math.atan2(a[1] - b[1], a[0] - b[0]), a2 = Math.atan2(cc[1] - b[1], cc[0] - b[0]), r = .8;
        o += `<line x1="${X(b)}" y1="${Y(b)}" x2="${X(a)}" y2="${Y(a)}" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/><line x1="${X(b)}" y1="${Y(b)}" x2="${X(cc)}" y2="${Y(cc)}" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/>`;
        if (e.right) { const p1 = [b[0] + Math.cos(a1) * .55, b[1] + Math.sin(a1) * .55], p3 = [b[0] + Math.cos(a2) * .55, b[1] + Math.sin(a2) * .55], p2 = [p1[0] + p3[0] - b[0], p1[1] + p3[1] - b[1]]; o += `<path d="M${X(p1)} ${Y(p1)}L${X(p2)} ${Y(p2)}L${X(p3)} ${Y(p3)}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` }
        else if (e.arc !== false) { let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; const p1 = [b[0] + Math.cos(a1) * r, b[1] + Math.sin(a1) * r], p2 = [b[0] + Math.cos(a2) * r, b[1] + Math.sin(a2) * r]; o += `<path d="M${X(p1)} ${Y(p1)}A${r * u} ${r * u} 0 0 ${d > 0 ? 1 : 0} ${X(p2)} ${Y(p2)}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` }
        o += `<circle cx="${X(b)}" cy="${Y(b)}" r="4.5" fill="${P.ink}"/>`;
      }
    }
    return svg(W + pd * 2, H + pd * 2, o, v.mw);
  }

  // --- b10: yuzlik/o‘nlik/birlik {h,d,u}
  // b10: {h,d,u} yuzlik/o‘nlik/birlik; cd/cu — oxirgi nechta o‘nlik/birlik chizib tashlanadi (ayirish);
  //      add:{d,u} — «+» belgisidan keyin qo‘shiladigan guruh (qo‘shish). Matndagi har son rasmda ko‘rinsin.
  // b10: {h,d,u, add:{h,d,u}, sub:{h,d,u}, hl} — yuzlik/o‘nlik/birlik. Ostida izoh qatori: [tayoqcha] = 10, [kubik] = 1 (bola rasmning o‘zidan tushunsin).
  // hl (Ustoz ko‘rsatuvi uchun yonib turadigan qism): 'd' — hamma o‘nliklar, 'u' — hamma birliklar, 'h' — yuzliklar, 'base' — birinchi guruh, 'add'/'sub' — ikkinchi guruh, 'all' — hammasi.
  const GLOW = (x, y, w, h) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="#fef08a" stroke="#f59e0b" stroke-width="3"/>`;
  function b10(v) {
    let o = '', x = 0; const hS = 92, glows = [], hl = v.hl;
    const want = (key, part) => hl && (hl === 'all' || hl === part || hl === key);
    const grp = (g, key) => {
      const x0 = x;
      if (g.h) { const xs = x; for (let i = 0; i < g.h; i++) { o += im('yuzlik', x, 0, hS); x += hS + 6 } if (want(key, 'h')) glows.push([xs - 4, -4, x - 6 - xs + 8, hS + 8]); x += 8 }
      if (g.d) { const xs = x - 26; for (let i = 0; i < g.d; i++) { o += im('onlik', x - 32, 0, 82, hS); x += 18 } if (want(key, 'd')) glows.push([xs - 4, -4, x - 18 + 26 - xs + 8, hS + 8]); x += 22 }
      if (g.u) { const xs = x - 2; for (let i = 0; i < g.u; i++) { o += im('birlik', x + (i % 2) * 18, hS - 18 - Math.floor(i / 2) * 18, 16) } const rows = Math.ceil(g.u / 2); if (want(key, 'u')) glows.push([xs - 4, hS - 18 * rows - 6, (g.u > 1 ? 36 : 18) + 12, 18 * rows + 10]); x += 40 }
      if (hl === key && !['h', 'd', 'u', 'all'].includes(hl)) glows.push([x0 - 4, -4, x - x0 + 4, hS + 8]);
    };
    grp(v, 'base');
    // add:{d,u} — «+» dan keyin qo‘shiladigan guruh; sub:{d,u} — «−» dan keyin ayriladigan guruh (ikkalasi ham alohida ko‘rinadi, chizib tashlash yo‘q)
    for (const [key, sign] of [['add', '+'], ['sub', '−']]) if (v[key]) { x += 6; o += `<text x="${x + 12}" y="${hS / 2 + 12}" font-size="34" font-weight="900" fill="${P.blue}" text-anchor="middle">${sign}</text>`; x += 34 + 24; grp(v[key], key) }
    const W = Math.max(x, 60);
    // Izoh qatori (Siroj 09.11): bola «tayoqcha = 10, kubik = 1» ekanini rasmning o‘zidan bilsin
    const ly = hS + 14, lh = 30; let lx = 0;
    const any = k => (v[k] || 0) + ((v.add || {})[k] || 0) + ((v.sub || {})[k] || 0);
    if (any('h')) { o += im('yuzlik', lx, ly, lh) + T(lx + lh + 4, ly + lh / 2, '= 100', { fs: 15, a: 'start', st: 1 }); lx += lh + 70 }
    if (any('d')) { o += im('onlik', lx - 10, ly, 28, lh) + T(lx + 14, ly + lh / 2, '= 10', { fs: 15, a: 'start', st: 1 }); lx += 66 }
    if (any('u')) { o += im('birlik', lx + 2, ly + lh / 2 - 8, 16) + T(lx + 24, ly + lh / 2, '= 1', { fs: 15, a: 'start', st: 1 }); lx += 60 }
    const FW = Math.max(W, lx) + 8, FH = ly + lh + 6;
    return svg(FW, FH, `<g transform="translate(4 4)">${glows.map(g => GLOW(...g)).join('')}${o}</g>`, FW * 1.4);
  }

  // --- clock: {h,m}
  function clock(v) { // strelka rasmlari 200x200, aylanish o‘qi (99, 97)
    const c = 100, mA = v.m * 6, hA = (v.h % 12) * 30 + v.m / 2;
    const hand = (n, a, k) => `<image href="${src(n)}" x="${c - 99 * k}" y="${c - 97 * k}" width="${200 * k}" height="${200 * k}" transform="rotate(${a} ${c} ${c})"/>`;
    return svg(200, 200, im('soat-yuz', 0, 0, 200) + hand('soat-qisqa', hA, .56) + hand('soat-uzun', mA, .8), 210);
  }

  // --- ruler: chizg‘ich {n:cm, seg:[a,b], lb, mm}
  function ruler(v) {
    const n = v.n, u = Math.min(40, 520 / n), L = 16, W = L * 2 + n * u; let o = `<rect x="4" y="44" width="${W - 8}" height="54" rx="8" fill="#fde68a" stroke="#d97706" stroke-width="2"/>`;
    for (let i = 0; i <= n; i++) { o += `<line x1="${L + i * u}" y1="44" x2="${L + i * u}" y2="${66}" stroke="#78350f" stroke-width="2"/>` + T(L + i * u, 82, i, { fs: 13, c: '#78350f' }); if (i < n && u >= 20) o += `<line x1="${L + (i + .5) * u}" y1="44" x2="${L + (i + .5) * u}" y2="56" stroke="#78350f" stroke-width="1.3"/>` }
    if (v.seg) { const [a, b] = v.seg; o += `<line x1="${L + a * u}" y1="24" x2="${L + b * u}" y2="24" stroke="${P.blue}" stroke-width="6" stroke-linecap="round"/><circle cx="${L + a * u}" cy="24" r="5" fill="${P.ink}"/><circle cx="${L + b * u}" cy="24" r="5" fill="${P.ink}"/>`; if (v.lb) o += T(L + (a + b) / 2 * u, 8, v.lb, { fs: 14 }) }
    if (v.obj) o += `<image href="${src(v.obj)}" x="${L + v.objA * u}" y="0" width="${(v.objB - v.objA) * u}" height="40" preserveAspectRatio="none"/>`;
    return svg(W, 104, o);
  }

  // --- pul: tanga va pul {v:[qiymat,...]} — 1000 gacha tanga, kattasi qog‘oz pul
  const NOTE = { 1000: '#a7f3d0', 2000: '#bae6fd', 5000: '#fecaca', 10000: '#ddd6fe', 20000: '#fde68a', 50000: '#fbcfe8', 100000: '#c7d2fe', 200000: '#99f6e4' };
  function pul(v) {
    let o = '', x = 0, y = 0; const maxW = 540; let rowH = 0, W = 0;
    for (const a of v.v) {
      const coin = a < 1000 || v.coin1000 && a === 1000, w = coin ? 64 : 130, h = coin ? 64 : 64;
      if (x + w > maxW) { x = 0; y += rowH + 8; rowH = 0 }
      if (coin) o += im('tanga', x, y, 64) + T(x + 32, y + 33, C(a), { fs: a >= 1000 ? 15 : 18, c: '#7c4a03' });
      else o += `<rect x="${x + 1}" y="${y + 4}" width="${w - 2}" height="${h - 8}" rx="8" fill="${NOTE[a] || '#e0f2fe'}" stroke="#0f766e" stroke-width="2"/><rect x="${x + 8}" y="${y + 11}" width="${w - 16}" height="${h - 22}" rx="5" fill="none" stroke="#0f766e88" stroke-width="1.5" stroke-dasharray="3 3"/>` + T(x + w / 2, y + h / 2, C(a), { fs: 20, c: '#134e4a' }) + T(x + w - 22, y + 17, 'so‘m', { fs: 9, c: '#134e4a' });
      x += w + 8; rowH = Math.max(rowH, h); W = Math.max(W, x);
    }
    return svg(W, y + rowH + 2, o);
  }
  const C = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  // --- cubes: izometrik kubiklar {hm:[[h,...],...]} (qator x ustun, har katakda nechta qavat)
  function cubes(v) {
    const s = v.s || 30, hm = v.hm, R = hm.length, Cn = hm[0].length; const dx = s * .866, dy = s * .5; let o = '';
    const H = Math.max(...hm.flat()); const ox = R * dx + 10, oy = H * s + 10;
    const cube = (i, j, k, col) => { const x = ox + (j - i) * dx, y = oy + (i + j) * dy - k * s; return `<g stroke="#1e3a8a" stroke-width="1.5" stroke-linejoin="round"><path d="M${x} ${y}l${dx} ${-dy}l${-dx} ${-dy}l${-dx} ${dy}z" fill="${col[0]}"/><path d="M${x} ${y}l${-dx} ${-dy}v${s}l${dx} ${dy}z" fill="${col[1]}"/><path d="M${x} ${y}l${dx} ${-dy}v${s}l${-dx} ${dy}z" fill="${col[2]}"/></g>` };
    const cols = v.mono ? [['#93c5fd', '#3b82f6', '#60a5fa']] : [['#93c5fd', '#3b82f6', '#60a5fa'], ['#fde68a', '#f59e0b', '#fbbf24'], ['#a7f3d0', '#10b981', '#34d399'], ['#fbcfe8', '#ec4899', '#f472b6']];
    for (let i = 0; i < R; i++) for (let j = 0; j < Cn; j++) for (let k = 0; k < hm[i][j]; k++) o += cube(i, j, k, cols[(i + j + k) % cols.length]);
    const W = ox + Cn * dx + 10, Hh = oy + (R + Cn) * dy + s + 10 - s; return svg(W + 4, Hh + 4, o, Math.min(320, W * 1.3));
  }

  // --- solid: fazoviy shakl chizmasi {s:'kub'|'par'|'shar'|'silindr'|'konus'|'piramida'}
  function solid(v) {
    const st = 'stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"', hid = 'stroke="#1e3a8a" stroke-width="1.8" stroke-dasharray="6 5" fill="none"'; let o = '';
    const g = (id, a, b) => `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;
    switch (v.s) {
      case 'kub': case 'par': { const w = v.s === 'kub' ? 90 : 130, h = 90, d = 40; o = `<defs>${g('f', '#93c5fd', '#3b82f6')}${g('t', '#dbeafe', '#93c5fd')}${g('r', '#60a5fa', '#1d4ed8')}</defs><path d="M30 ${50 + d * 0}h${w}v${h}h${-w}z" fill="url(#f)" ${st}/><path d="M30 50l${d} ${-d}h${w}l${-d} ${d}z" fill="url(#t)" ${st}/><path d="M${30 + w} 50l${d} ${-d}v${h}l${-d} ${d}z" fill="url(#r)" ${st}/><path d="M${30 + d} ${50 - d + h}v${-h}M${30 + d} ${50 - d + h}h${w}M${30 + d} ${50 - d + h}l${-d} ${d}" ${hid}/>`; return svg(80 + w + d, 160, o, 220) }
      case 'shar': o = `<defs><radialGradient id="s" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fff"/><stop offset=".35" stop-color="#93c5fd"/><stop offset="1" stop-color="#1d4ed8"/></radialGradient></defs><circle cx="80" cy="80" r="66" fill="url(#s)" ${st}/><ellipse cx="80" cy="80" rx="66" ry="18" fill="none" stroke="#1e3a8a" stroke-width="1.8" stroke-dasharray="6 5"/>`; return svg(160, 160, o, 170);
      case 'silindr': o = `<defs>${g('c', '#93c5fd', '#1d4ed8')}</defs><path d="M20 40v100a60 18 0 0 0 120 0v-100" fill="url(#c)" ${st}/><ellipse cx="80" cy="40" rx="60" ry="18" fill="#dbeafe" ${st}/><path d="M20 140a60 18 0 0 1 120 0" ${hid}/>`; return svg(160, 165, o, 170);
      case 'konus': o = `<defs>${g('k', '#93c5fd', '#1d4ed8')}</defs><path d="M80 12L20 140a60 18 0 0 0 120 0z" fill="url(#k)" ${st}/><path d="M20 140a60 18 0 0 1 120 0" ${hid}/>`; return svg(160, 165, o, 170);
      case 'piramida': o = `<defs>${g('p1', '#93c5fd', '#3b82f6')}${g('p2', '#60a5fa', '#1d4ed8')}</defs><path d="M85 12L20 130L110 150z" fill="url(#p1)" ${st}/><path d="M85 12L110 150L160 115z" fill="url(#p2)" ${st}/><path d="M20 130L70 100L160 115M85 12L70 100" ${hid}/>`; return svg(175, 160, o, 180);
    } return '';
  }

  // --- expr: katta ifoda, ☐ — bo‘sh katak {s}
  function expr(v) { const HL = v.hl ? (x => x.includes(esc(v.hl)) ? x.replace(esc(v.hl), '\u0001' + esc(v.hl) + '\u0002') : x) : (x => x); return `<div class="vx">${String(v.s).split('<br>').map(x => HL(esc(x))).join('\n').replace(/ ([·:=+−×]) /g, '\u00a0$1\u00a0').replace(/☐/g, '<i class="bx"></i>').replace(/\?/g, '<i class="bx">?</i>').replace(/\n/g, '<br>')}</div>`.replace(/\u0001/g, '<mark class="vhl">').replace(/\u0002/g, '</mark>') }

  // --- seq: sonlar/belgilar qatori {l:['3','6','?'], shape:'circle'|'box'}
  function seq(v) { return `<div class="vq">${v.l.map(x => `<span class="${x === '?' ? 'qm' : ''}${v.shape === 'circle' ? ' cr' : ''}">${esc(x)}</span>`).join('')}</div>` }

  // --- grid: katakli jadval (sehrli kvadrat, jumboq) {cells:[[...]], hl:[[r,c]]}
  function grid(v) { return `<table class="vg">${v.cells.map((r, i) => `<tr>${r.map((c, j) => `<td class="${c === '?' ? 'qm' : ''}${(v.hl || []).some(h => h[0] === i && h[1] === j) ? ' hl' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('')}</table>` }

  // --- col: ustun ko‘rinishida {a,b,op,r (yoki '?'), hide:[raqam joylari]}
  function col(v) {
    const a = String(v.a), b = String(v.b), r = v.r == null ? '' : String(v.r), w = Math.max(a.length, b.length + 1, r.length) + 1;
    const row = (s, cls) => `<div class="cr ${cls || ''}">${[...s.padStart(w, ' ')].map(ch => `<span>${ch === ' ' ? '' : ch === '?' ? '<i class="bx">?</i>' : ch}</span>`).join('')}</div>`;
    return `<div class="vc"><b class="op">${v.op === '-' ? '−' : v.op === '*' ? '×' : '+'}</b>${row(a)}${row(b)}<div class="ln"></div>${row(r)}</div>`;
  }

  // --- tarozi: {l:[{img,n}|{s:'5 kg'}], r:[...], tilt: -1 chap og‘ir, 0 teng, 1 o‘ng og‘ir}
  function tarozi(v) {
    const t = (v.tilt || 0) * 10, cx = 200; let o = `<path d="M${cx - 50} 210h100l-20 -16h-60z" fill="#64748b"/><rect x="${cx - 6}" y="70" width="12" height="130" rx="4" fill="#94a3b8"/>`;
    o += `<g transform="rotate(${t} ${cx} 74)"><rect x="40" y="68" width="320" height="10" rx="5" fill="#475569"/>`;
    const pan = (x, list, side) => { let s = `<line x1="${x}" y1="78" x2="${x - 50}" y2="140" stroke="#64748b" stroke-width="2"/><line x1="${x}" y1="78" x2="${x + 50}" y2="140" stroke="#64748b" stroke-width="2"/><g transform="rotate(${-t} ${x} 140)"><path d="M${x - 66} 140h132a66 18 0 0 1 -132 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>`; let k = 0; const all = []; list.forEach(e => { if (e.s) all.push(e); else for (let i = 0; i < e.n; i++) all.push({ img: e.img }) }); const sz = all.length > 6 ? 28 : 40, per = all.length > 6 ? 5 : 4; all.forEach((e, i) => { const xx = x - (Math.min(all.length, per) * sz) / 2 + (i % per) * sz, yy = 140 - sz - Math.floor(i / per) * sz * .85; s += e.img ? im(e.img, xx, yy, sz) : im('gir', xx - 4, yy - 8, sz + 8) + T(xx + sz / 2, yy + sz * .55, e.s, { fs: (sz > 30 ? 13 : 11) - (String(e.s).length > 4 ? 2 : 0), c: '#fff', fw: 900 }) }); return s + '</g>' };
    o += pan(70, v.l, -1) + pan(330, v.r, 1) + '</g>';
    return svg(400, 215, o, 420);
  }

  // --- cal: oy kalendari {days (oy kunlari soni), start (1-kun hafta kuni 0=Du), hl:[kunlar], title}
  function cal(v) {
    const H = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya']; let c = '<tr>' + H.map((h, i) => `<th${i > 4 ? ' class="we"' : ''}>${h}</th>`).join('') + '</tr><tr>'; let k = 0;
    for (; k < v.start; k++) c += '<td></td>';
    for (let d = 1; d <= v.days; d++, k++) { if (k && k % 7 === 0) c += '</tr><tr>'; c += `<td class="${(v.hl || []).includes(d) ? 'hl' : ''}${k % 7 > 4 ? ' we' : ''}">${(v.q || []).includes(d) ? '?' : d}</td>` }
    return `<table class="vcal">${v.title ? `<caption>${v.title}</caption>` : ''}${c}</tr></table>`;
  }

  // --- gug: gugurt cho‘plari {segs:[[x1,y1,x2,y2],...], hl:[indekslar], w,h} (birlik — cho‘p uzunligi)
  function gug(v) {
    const u = 54, pd = 16; let o = '';
    v.segs.forEach((s, i) => { const [x1, y1, x2, y2] = s.map(z => z * u + pd), a = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI, L = Math.hypot(x2 - x1, y2 - y1); o += `<g transform="translate(${x1} ${y1}) rotate(${a})"><rect x="5" y="-4" width="${L - 10}" height="8" rx="3" fill="${(v.hl || []).includes(i) ? '#fca5a5' : '#fcd34d'}" stroke="#b45309" stroke-width="1.5"/><ellipse cx="${L - 8}" cy="0" rx="7" ry="6" fill="#dc2626"/></g>` });
    return svg(v.w * u + pd * 2, v.h * u + pd * 2, o, Math.max(240, v.w * u * 1.1));
  }

  // --- imgs: rasmlar qatori (tanlov uchun) {l:[img], lb:[yozuv]}
  function imgs(v) { const s = v.s || 70; return svg(v.l.length * (s + 14), s + (v.lb ? 26 : 4), v.l.map((n, i) => im(n, i * (s + 14) + 7, 2, s) + (v.lb ? T(i * (s + 14) + 7 + s / 2, s + 16, v.lb[i], { fs: 15 }) : '')).join('')) }

  // --- shapes: tekis shakllar qatori (sanash, qonuniyat) {l:[{s:'doira'|'kvadrat'|'uchburchak'|'tortburchak'|'yulduz'|'romb'|'olti', c:rang, lb}], s}
  function shp(kind, x, y, s, c) {
    const st = `stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round" fill="${c}"`;
    switch (kind) {
      case 'doira': return `<circle cx="${x + s / 2}" cy="${y + s / 2}" r="${s / 2 - 3}" ${st}/>`;
      case 'kvadrat': return `<rect x="${x + 4}" y="${y + 4}" width="${s - 8}" height="${s - 8}" rx="3" ${st}/>`;
      case 'tortburchak': return `<rect x="${x + 2}" y="${y + s * .22}" width="${s - 4}" height="${s * .56}" rx="3" ${st}/>`;
      case 'uchburchak': return `<path d="M${x + s / 2} ${y + 4}L${x + s - 3} ${y + s - 5}H${x + 3}z" ${st}/>`;
      case 'romb': return `<path d="M${x + s / 2} ${y + 2}L${x + s - 4} ${y + s / 2}L${x + s / 2} ${y + s - 2}L${x + 4} ${y + s / 2}z" ${st}/>`;
      case 'yulduz': { let p = ''; for (let i = 0; i < 10; i++) { const r = i % 2 ? s * .2 : s * .47, a = -Math.PI / 2 + i * Math.PI / 5; p += (i ? 'L' : 'M') + (x + s / 2 + r * Math.cos(a)).toFixed(1) + ' ' + (y + s / 2 + 2 + r * Math.sin(a)).toFixed(1) } return `<path d="${p}z" ${st}/>` }
      case 'olti': { let p = ''; for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; p += (i ? 'L' : 'M') + (x + s / 2 + s * .46 * Math.cos(a)).toFixed(1) + ' ' + (y + s / 2 + s * .46 * Math.sin(a)).toFixed(1) } return `<path d="${p}z" ${st}/>` }
      case '?': return `<rect x="${x + 3}" y="${y + 3}" width="${s - 6}" height="${s - 6}" rx="10" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="6 4"/>` + T(x + s / 2, y + s / 2, '?', { fs: s * .5, c: '#b45309' });
    } return '';
  }
  V.shp = shp;
  function shapes(v) { const s = v.s || 52; return svg(v.l.length * (s + 10), s + (v.l.some(e => e.lb) ? 24 : 4), v.l.map((e, i) => shp(e.s, i * (s + 10) + 5, 2, s, e.c || P.fills[i % 7]) + (e.lb ? T(i * (s + 10) + 5 + s / 2, s + 14, e.lb, { fs: 14 }) : '')).join('')) }

  V.render = v => {
    if (!v) return '';
    if (Array.isArray(v)) return v.map(V.render).join('');
    if (V.ext[v.t]) return V.ext[v.t](v, V);
    switch (v.t) {
      case 'obj': return obj(v); case 'nline': return nline(v); case 'tbl': return tbl(v); case 'bar': return bar(v); case 'pic': return pic(v);
      case 'geo': return geo(v); case 'b10': return b10(v); case 'clock': return clock(v); case 'ruler': return ruler(v); case 'pul': return pul(v);
      case 'cubes': return cubes(v); case 'solid': return solid(v); case 'expr': return expr(v); case 'seq': return seq(v); case 'grid': return grid(v);
      case 'col': return col(v); case 'tarozi': return tarozi(v); case 'cal': return cal(v); case 'gug': return gug(v); case 'imgs': return imgs(v); case 'shapes': return shapes(v);
    }
    return `<div class="vmiss">[rasm turi topilmadi: ${esc(v.t)}]</div>`;
  };
  V.TYPES = ['obj', 'nline', 'tbl', 'bar', 'pic', 'geo', 'b10', 'clock', 'ruler', 'pul', 'cubes', 'solid', 'expr', 'seq', 'grid', 'col', 'tarozi', 'cal', 'gug', 'imgs', 'shapes'];
  V.CSS = `.vs{display:block;margin:6px auto;height:auto}
.vt{border-collapse:separate;border-spacing:0;margin:6px auto;font:800 15px Nunito,system-ui,sans-serif;color:#0b2a6f;border:2px solid #93c5fd;border-radius:12px;overflow:hidden}
.vt th{background:#dbeafe;padding:7px 10px}.vt td{padding:7px 10px;text-align:center;border-top:1px solid #dbeafe;background:#fff}.vt tr.hl td{background:#fef3c7}.vt caption{font-weight:900;padding:4px}
.vx{font:900 28px Nunito,system-ui,sans-serif;color:#0b2a6f;text-align:center;margin:8px 0;letter-spacing:1px}.vhl{background:#fde047;border-radius:8px;padding:0 6px}
.bx{display:inline-block;min-width:38px;height:40px;line-height:40px;border:2.5px dashed #f5b301;border-radius:10px;background:#fff7d6;color:#b45309;font-style:normal;vertical-align:middle;margin:0 4px}
.vq{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:8px 0}.vq span{min-width:46px;height:46px;padding:0 6px;display:grid;place-items:center;border-radius:12px;background:#eff6ff;border:2px solid #93c5fd;font:900 21px Nunito,system-ui,sans-serif;color:#0b2a6f}.vq span.cr{border-radius:50%}.vq span.qm{background:#fff7d6;border:2.5px dashed #f5b301;color:#b45309}
.vg{border-collapse:collapse;margin:8px auto}.vg td{width:50px;height:50px;border:2.5px solid #3b82f6;text-align:center;font:900 22px Nunito,system-ui,sans-serif;color:#0b2a6f;background:#fff}.vg td.qm{background:#fff7d6;color:#b45309}.vg td.hl{background:#dcfce7}
.vc{position:relative;display:inline-block;margin:8px auto;padding:4px 14px 4px 34px;background:#fff;border-radius:12px;border:2px solid #dbeafe;font:900 26px/1.25 'Courier New',monospace;color:#0b2a6f}.vc .op{position:absolute;left:10px;top:26px;font-family:Nunito,sans-serif}.vc .cr{display:flex;justify-content:flex-end}.vc .cr span{width:24px;text-align:center}.vc .ln{border-top:3px solid #0b2a6f;margin:2px 0}.vc .bx{min-width:22px;height:30px;line-height:30px;margin:0;font-size:20px}
.vcal{border-collapse:collapse;margin:6px auto;font:800 14px Nunito,system-ui,sans-serif;color:#0b2a6f;background:#fff;border-radius:12px;overflow:hidden}.vcal caption{font-weight:900;padding:4px;font-size:16px}.vcal th{background:#dbeafe;padding:5px 7px}.vcal td{width:36px;height:30px;text-align:center;border:1px solid #e2e8f0}.vcal .we{color:#dc2626}.vcal td.hl{background:#fde68a;border-radius:50%}
.vmiss{padding:10px;border:2px dashed #f87171;border-radius:10px;color:#b91c1c;font-weight:800}`;
  // V.fit(ildiz): brauzerda rasm sahifaga qo‘yilgach chaqiriladi. Yozuv yoki nuqta chizma maydonidan (viewBox) tashqariga chiqib
  // kesilgan bo‘lsa, maydonni shunga moslab kengaytiradi (10.11: 18 605 chizmadan 523 tasida harf/yozuv kesilgan edi).
  // Har svg bir marta tekshiriladi (data-f). Sahifa: V.fit() ni har chizishdan keyin yoki MutationObserver bilan chaqiradi.
  V.over = sv => {
    const r = sv.getBoundingClientRect(); if (!r.width || !r.height) return null; let l = 0, t = 0, rr = 0, bb = 0;
    sv.querySelectorAll('text,circle').forEach(e => {
      const q = e.getBoundingClientRect(); if (!q.width || !q.height) return; if (e.tagName === 'circle' && q.width > 30) return;
      l = Math.max(l, r.left - q.left); t = Math.max(t, r.top - q.top); rr = Math.max(rr, q.right - r.right); bb = Math.max(bb, q.bottom - r.bottom);
    });
    return (l > 1 || t > 1 || rr > 1 || bb > 1) ? [l, t, rr, bb, r.width] : null;
  };
  V.fit = el => {
    if (typeof document === 'undefined') return;
    (el || document).querySelectorAll('svg.vs:not([data-f])').forEach(sv => {
      try {
        const vb = sv.viewBox.baseVal; if (!vb || !vb.width) return; const o = V.over(sv);
        if (sv.getBoundingClientRect().width) sv.setAttribute('data-f', '1'); if (!o) return;
        const u = vb.width / o[4], PD = 3, x0 = vb.x - (o[0] > 1 ? o[0] * u + PD : 0), y0 = vb.y - (o[1] > 1 ? o[1] * u + PD : 0),
          x1 = vb.x + vb.width + (o[2] > 1 ? o[2] * u + PD : 0), y1 = vb.y + vb.height + (o[3] > 1 ? o[3] * u + PD : 0);
        const k = (x1 - x0) / vb.width, mw = parseFloat(sv.style.maxWidth);
        sv.setAttribute('viewBox', x0 + ' ' + y0 + ' ' + (x1 - x0) + ' ' + (y1 - y0));
        if (mw) sv.style.maxWidth = Math.round(mw * k) + 'px';
      } catch (e) { }
    });
  };
  if (typeof module !== 'undefined') module.exports = V; else root.V = V;
})(this);

// 2A guruhi qo‘shimcha rasmlari.
// '2A-b10rows' — bir nechta sonni yuzlik/o‘nlik/birlik bilan BIR XIL masshtabda, nomi bilan ko‘rsatadi:
//   {t:'2A-b10rows', rows:[{lb:'Ali', h:2, d:3, u:4}, ...]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2A-b10rows'] = (v, V) => {
    const hS = 80, LW = 96, gap = 14; let o = '', W = 0;
    v.rows.forEach((r, k) => {
      const y = k * (hS + gap); let x = LW;
      o += `<rect x="0" y="${y}" width="${LW - 10}" height="${hS}" rx="12" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"/>` + V.T((LW - 10) / 2, y + hS / 2, r.lb, { fs: 16 });
      for (let i = 0; i < (r.h || 0); i++) { o += V.im('yuzlik', x, y, hS); x += hS + 6 } if (r.h) x += 8;
      for (let i = 0; i < (r.d || 0); i++) { o += V.im('onlik', x - 28, y, 72, hS); x += 16 } if (r.d) x += 20;
      for (let i = 0; i < (r.u || 0); i++) o += V.im('birlik', x + (i % 2) * 16, y + hS - 16 - Math.floor(i / 2) * 16, 14); if (r.u) x += 36;
      W = Math.max(W, x);
    });
    const H = v.rows.length * (hS + gap) - gap;
    return V.svg(W + 4, H + 4, o);
  };
})();

// 2B2–2B7 uchun qo‘shimcha rasmlar:
//  '2B-ramka' — o‘nlik ramkalar (10 katakli) va fishkalar: {fr:['1111111122','2220000000'], lb:['',''] (ixtiyoriy)}
//      har ramka — 10 belgili satr: '0' bo‘sh, '1' ko‘k fishka, '2' sariq fishka, 'x' chizilgan ko‘k, 'y' chizilgan sariq.
//  '2B-komp'  — tenglik va komponent nomlari: {l:['45','+','27','=','72'], lb:['qo‘shiluvchi','','qo‘shiluvchi','','yig‘indi'], hl:4}
//      hl — sariq bilan ajratilgan son (indeks); lb ichida '?' bo‘lsa — so‘roq katagi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2B-ramka'] = (v, V) => {
    const P = V.P, c = 26, fw = 5 * c + 12, fh = 2 * c + 12, gap = 12, per = v.per || (v.fr.length === 4 ? 2 : Math.min(3, v.fr.length)), hasLb = (v.lb || []).some(Boolean);
    const COL = { 1: ['#3b82f6', '#1e40af'], 2: ['#fbbf24', '#b45309'], x: ['#3b82f6', '#1e40af'], y: ['#fbbf24', '#b45309'] };
    let o = '';
    // Qoida (Siroj 09.11): bir xil fishkali to‘la ramkalar ≥2 bo‘lsa — birinchisi ochiq, qolganlari yopiq (shtrix, «10»), bola bittalab sanamasin
    const pure = v.fr.filter(f => /^(1{10}|2{10})$/.test(f)); let seen = false;
    v.fr.forEach((f, i) => {
      const fx = (i % per) * (fw + gap), fy = Math.floor(i / per) * (fh + gap + (hasLb ? 20 : 0));
      if (pure.length >= 2 && pure.includes(f)) { if (seen) { o += V.hatch(fx + 1, fy + 1, fw - 2, fh - 2, '10'); if (v.lb && v.lb[i]) o += V.T(fx + fw / 2, fy + fh + 11, v.lb[i], { fs: 14 }); return } seen = true }
      o += `<rect x="${fx + 1}" y="${fy + 1}" width="${fw - 2}" height="${fh - 2}" rx="10" fill="#eff6ff" stroke="#3b82f6" stroke-width="2.5"/>`;
      for (let k = 0; k < 10; k++) {
        const cx = fx + 6 + (k % 5) * c + c / 2, cy = fy + 6 + Math.floor(k / 5) * c + c / 2, ch = f[k];
        o += `<rect x="${cx - c / 2 + 1}" y="${cy - c / 2 + 1}" width="${c - 2}" height="${c - 2}" rx="4" fill="#fff" stroke="#bfdbfe" stroke-width="1.5"/>`;
        if (COL[ch]) o += `<circle cx="${cx}" cy="${cy}" r="${c / 2 - 3.5}" fill="${COL[ch][0]}" stroke="${COL[ch][1]}" stroke-width="1.5"/>`;
        if (false && (ch === 'x' || ch === 'y')) o += `<path d="M${cx - 8} ${cy - 8}L${cx + 8} ${cy + 8}M${cx + 8} ${cy - 8}L${cx - 8} ${cy + 8}" stroke="${P.red}" stroke-width="3.5" stroke-linecap="round"/>`;
      }
      if (v.lb && v.lb[i]) o += V.T(fx + fw / 2, fy + fh + 11, v.lb[i], { fs: 14 });
    });
    const rows = Math.ceil(v.fr.length / per), W = per * (fw + gap) - gap, H = rows * (fh + gap + (hasLb ? 20 : 0)) - gap;
    return V.svg(W + 2, H + 2, o, Math.min(W * 1.15, 560));
  };
  V.ext['2B-komp'] = (v, V) => {
    const box = (s, i) => {
      const op = /^[+−=]$/.test(s), hl = i === v.hl, lb = (v.lb || [])[i] || '', q = lb === '?';
      const num = op ? `<div style="font:900 26px Nunito,system-ui,sans-serif;color:#0b2a6f;height:44px;line-height:44px">${V.esc(s)}</div>`
        : `<div style="font:900 24px Nunito,system-ui,sans-serif;color:#0b2a6f;min-width:44px;height:44px;line-height:40px;padding:0 6px;border-radius:12px;border:2.5px solid ${hl ? '#f5b301' : '#93c5fd'};background:${hl ? '#fff7d6' : '#eff6ff'}">${V.esc(s)}</div>`;
      const l = op ? '' : q ? `<div style="margin-top:6px;display:inline-block;min-width:34px;border:2px dashed #f5b301;background:#fff7d6;color:#b45309;border-radius:8px;font:900 15px Nunito,system-ui,sans-serif;padding:1px 6px">?</div>`
        : lb ? `<div style="margin-top:6px;font:800 12px Nunito,system-ui,sans-serif;color:#1d4ed8">${V.esc(lb)}</div>` : '';
      return `<div style="display:flex;flex-direction:column;align-items:center;min-width:${op ? 14 : 44}px">${num}${l}</div>`;
    };
    return `<div style="display:flex;justify-content:center;align-items:flex-start;gap:5px;margin:8px 0;flex-wrap:nowrap">${v.l.map(box).join('')}</div>`;
  };
})();

// 2B1 uchun rasm: '2B1-qolip' — har birida aniq 10 ta tuxum bo‘lgan qoliplar (ChatGPT rasmi tuxum-qolip) + yonida alohida tuxumlar,
//   {t:'2B1-qolip', trays:2, n:9, cross:7} — cross endi chizilmaydi (Siroj 09.11): rasm avvalgi holatni ko‘rsatadi.
// RASMLAR: tuxum-qolip-ochiq tuxum-qolip-yopiq olma-quti-ochiq olma-quti-yopiq nok-quti-ochiq nok-quti-yopiq shar-quti-ochiq shar-quti-yopiq tuxum olma nok koptok-qizil
// Qoida (Siroj, 09.11): narsalarni qo‘lda qutiga «joylamaymiz» — nechta quti bo‘lsa, shuncha kichik tayyor quti rasmi qo‘yiladi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2B1-qolip'] = (v, V) => {
    const { im, T, P, svg } = V;
    const tw = 118, th = 118, gap = 8; let o = '', x = 0;
    // Qoida (Siroj 09.11): faqat birinchi qolip ochiq ko‘rinadi, qolganlari yopiq (shtrix) va ustida «10» — bola bittalab sanamasin
    const kind = v.kind || 'tuxum', bx = (V.BOX10 || {})[kind] || ['tuxum-qolip-ochiq', 'tuxum-qolip-yopiq'];
    for (let i = 0; i < v.trays; i++) { o += im(i === 0 ? bx[0] : bx[1], x, 0, tw, th); o += T(x + tw / 2, th + 8, '10 ta', { fs: 14, st: 1 }); x += tw + gap }
    const W1 = x - gap;
    const GL = (gx, gy, gw, gh) => `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" rx="14" fill="#fef08a" stroke="#f59e0b" stroke-width="3"/>`; let glow = ''; // Ustoz ko‘rsatuvi: yonib turadigan qism
    if (v.hl === 'trays' || v.hl === 'all') glow += GL(-4, -4, W1 + 8, th + 24);
    // alohida tuxumlar — pastki qatorda, kattaroq
    const s = 40, y = th + 26; let x2 = 0;
    for (let i = 0; i < v.n; i++) {
      o += im(kind, x2 + 3, y, s - 6);
      // Qoida (Siroj 09.11 21:57): olingan/yeyilgan narsalar ustiga CHIZIQ TORTILMAYDI — rasm «avvalgi holat»ni ko‘rsatadi, bola ayirishni o‘zi qiladi (chizilsa qolganini sanab qo‘yadi).
      if (false && i >= v.n - (v.cross || 0)) o += `<path d="M${x2 + 4} ${y + 1}L${x2 + s - 4} ${y + s - 7}M${x2 + s - 4} ${y + 1}L${x2 + 4} ${y + s - 7}" stroke="${P.red}" stroke-width="4" stroke-linecap="round"/>`;
      x2 += s;
    }
    o += T(x2 + 8, y + s / 2 - 3, `${v.n} ta`, { fs: 15, a: 'start', st: 1 });
    if (v.hl === 'loose' || v.hl === 'all') glow += GL(-4, y - 4, x2 + 56, s + 4);
    const W = Math.max(W1, x2 + 56), H = y + s + 6;
    return svg(W + 12, H + 4, `<g transform="translate(6 6)">${glow}${o}</g>`, Math.min(520, (W + 12) * 1.1));
  };
})();

// 2B8–2B13 uchun qo‘shimcha rasmlar:
//  '2B8-model' — chizma model (Singapur): {rows:[{lb:'Ali', parts:[{w:27,s:'27'},{w:26,s:'?'}]}], tot:'53' (1-qator ustida qavs), diff:'?' (2-qator oxirida farq)}
//  '2B8-uch'   — misollar oilasi uchburchagi: {top:'13', l:'7', r:'6'} (top — yig‘indi, pastda qo‘shiluvchilar; '?' bo‘lishi mumkin)
//  '2B8-ustun' — ko‘p qatorli ustun: {rows:['24','35','18'], op:'+'|'-', r:'??'}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const Q = '#fff7d6', QS = '#f5b301', QC = '#b45309';
  V.ext['2B8-model'] = (v, V) => {
    const T = V.T, P = V.P, rows = v.rows, hasLb = rows.some(r => r.lb), L = hasLb ? 100 : 12, W = 440, maxW = W - L - 14;
    const tot = r => r.parts.reduce((a, p) => a + p.w, 0), mx = Math.max(...rows.map(tot)), k = maxW / mx;
    const top = v.tot != null ? 42 : 6, rh = 44, gap = 20; let o = '', y = top;
    rows.forEach((r, i) => {
      let x = L;
      if (r.lb) o += T(L - 8, y + rh / 2, r.lb, { fs: 18, a: 'end' });
      r.parts.forEach((p, j) => {
        const w = p.w * k, q = p.s === '?';
        o += `<rect x="${x}" y="${y}" width="${w}" height="${rh}" rx="4" fill="${q ? Q : p.c || P.fills[(i * 2 + j) % 7] + '55'}" stroke="${q ? QS : '#1e3a8a'}" stroke-width="2"${q ? ' stroke-dasharray="6 4"' : ''}/>`;
        if (p.s != null) o += T(x + w / 2, y + rh / 2, p.s, { fs: 20, c: q ? QC : P.ink });
        x += w;
      });
      if (i === 1 && v.diff != null) {
        const end = L + tot(rows[0]) * k, q = v.diff === '?';
        if (end > x + 2) o += `<rect x="${x}" y="${y}" width="${end - x}" height="${rh}" rx="4" fill="${q ? Q : '#fff'}" stroke="${QS}" stroke-width="2" stroke-dasharray="6 4"/>` + T((x + end) / 2, y + rh / 2, v.diff, { fs: 20, c: QC });
      }
      y += rh + gap;
    });
    if (v.tot != null) {
      const x1 = L, x2 = L + tot(rows[0]) * k, yb = top - 8, q = v.tot === '?';
      o += `<path d="M${x1} ${yb + 6}V${yb}H${x2}V${yb + 6}" fill="none" stroke="${P.blue}" stroke-width="2.5"/>`;
      o += `<rect x="${(x1 + x2) / 2 - 30}" y="${yb - 26}" width="60" height="24" rx="8" fill="${q ? Q : '#fff'}" stroke="${q ? QS : '#fff'}" stroke-width="2"/>` + T((x1 + x2) / 2, yb - 14, v.tot, { fs: 20, c: q ? QC : P.ink });
    }
    return V.svg(W, y - gap + 4, o, 460);
  };
  V.ext['2B8-uch'] = (v, V) => {
    const T = V.T, P = V.P; let o = `<path d="M120 34L28 160H212z" fill="#eff6ff" stroke="#93c5fd" stroke-width="3" stroke-linejoin="round"/>` + T(120, 118, '+  −', { fs: 22, c: P.blue });
    const c = (x, y, s) => { const q = s === '?'; return `<circle cx="${x}" cy="${y}" r="27" fill="${q ? Q : '#fff'}" stroke="${q ? QS : '#1e3a8a'}" stroke-width="2.5"${q ? ' stroke-dasharray="6 4"' : ''}/>` + T(x, y, s, { fs: 20, c: q ? QC : P.ink }) };
    o += c(120, 32, v.top) + c(30, 160, v.l) + c(210, 160, v.r);
    return V.svg(240, 192, o, 240);
  };
  V.ext['2B8-ustun'] = (v, V) => {
    const rows = v.rows.map(String), r = v.r == null ? '' : String(v.r), w = Math.max(...rows.map(s => s.length + 1), r.length) + 1;
    const row = s => `<div class="cr">${[...s.padStart(w, ' ')].map(ch => `<span>${ch === ' ' ? '' : ch === '?' ? '<i class="bx">?</i>' : ch}</span>`).join('')}</div>`;
    const top = 4 + (rows.length - 1) * 32 - 6;
    return `<div class="vc"><b class="op" style="top:${top}px">${v.op === '-' ? '−' : '+'}</b>${rows.map(row).join('')}<div class="ln"></div>${row(r)}</div>`;
  };
})();

// 2C guruhi uchun qo‘shimcha rasm turlari.
// '2C-tarozi' — katta pallali tarozi: {t:'2C-tarozi', l:[{img,n}|{s:'5 kg'}], r:[...], tilt:-1|0|1}
//   tilt: -1 chap og‘ir (chap palla pastda), 0 teng, 1 o‘ng og‘ir. Narsalar va toshlar telefonda ham aniq ko‘rinadigan kattalikda.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2C-tarozi'] = (v, V) => {
    const W = 380, cx = W / 2, t = v.tilt || 0, sh = t < 0 ? 14 : t > 0 ? -14 : 0; // chap palla siljishi (tilt=-1 -> pastga)
    const yL = 180 + sh, yR = 180 - sh;
    const bL = 70 + sh, bR = 70 - sh;
    let o = `<path d="M${cx - 60} 250h120l-18 -18h-84z" fill="#64748b"/><rect x="${cx - 7}" y="66" width="14" height="168" rx="5" fill="#94a3b8"/>`;
    o += `<line x1="30" y1="${bL}" x2="${W - 30}" y2="${bR}" stroke="#475569" stroke-width="10" stroke-linecap="round"/><circle cx="${cx}" cy="70" r="9" fill="#334155"/>`;
    const pan = (x, by, py, list) => {
      let s = `<line x1="${x}" y1="${by}" x2="${x - 70}" y2="${py}" stroke="#64748b" stroke-width="2.5"/><line x1="${x}" y1="${by}" x2="${x + 70}" y2="${py}" stroke="#64748b" stroke-width="2.5"/>`;
      s += `<path d="M${x - 84} ${py}h168a84 22 0 0 1 -168 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2.5"/>`;
      const all = []; list.forEach(e => { if (e.s) all.push(e); else for (let i = 0; i < e.n; i++) all.push({ img: e.img }) });
      const per = all.length > 6 ? 4 : 3, sz = all.length > 6 ? 38 : 48;
      all.forEach((e, i) => {
        const row = Math.floor(i / per), inRow = Math.min(per, all.length - row * per), col = i % per;
        const xx = x - inRow * sz / 2 + col * sz, yy = py - sz - row * (sz * .82);
        if (e.img) s += V.im(e.img, xx + 1, yy, sz - 2);
        else s += V.im('gir', xx - 2, yy - 6, sz + 4) + V.T(xx + sz / 2, yy + sz * .58, e.s, { fs: e.s.length > 4 ? 12 : 15, c: '#0b2a6f', st: 1 });
      });
      return s;
    };
    o += pan(80, bL, yL, v.l) + pan(W - 80, bR, yR, v.r);
    return V.svg(W, 256, o, 400);
  };
})();

// 2C guruhi (ko‘paytirish va bo‘lish) uchun qo‘shimcha rasm turlari.
//  '2C9-massiv' — doirachalar massivi: {r: qator, c: ustun, split: [k] (birinchi k ustun boshqa rangda), cross: oxirgi nechta}
//  '2C9-jadval' — ko‘paytirish jadvali bo‘lagi: {rows:[6,7], cols:[3,4,5], q:[[i,j]], cells:[[..]] (ixtiyoriy), hl:[[i,j]]}
//  '2C9-yuzlik' — sonlar jadvali: {from:1, to:60, cols:10, hl:[sonlar], ring:[sonlar], q:[sonlar]}
//  '2C9-ifoda'  — uzun ifoda (expr kabi, lekin kichikroq shrift, bir qatorda): {s:'(6 + 2) · 7 = 6 · 7 + ☐ · 7'}
//  '2C9-ustun'  — ustun ko‘rinishida ko‘paytirish, belgi "·" (vis.js col asosida): {a, b, r}
//  '2C9-maydon' — maydon modeli (to‘g‘ri to‘rtburchak qismlarga bo‘lingan): {parts:['20','4'], w:[3,1], m:'3', vals:['60','12']}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T;
  const FILL = ['#f87171', '#60a5fa', '#34d399', '#fbbf24'];

  V.ext['2C9-massiv'] = v => {
    const r = v.r, c = v.c, s = v.s || (c > 8 ? 30 : 34), pd = 10; let o = '';
    const W = c * s + pd * 2, H = r * s + pd * 2;
    o += `<rect x="1" y="1" width="${W - 2}" height="${H - 2}" rx="12" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"/>`;
    const sp = v.split || [];
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) {
      let k = 0; for (const x of sp) if (j >= x) k++;
      const col = sp.length ? FILL[k % FILL.length] : (v.fill || '#60a5fa');
      const cx = pd + j * s + s / 2, cy = pd + i * s + s / 2;
      o += `<circle cx="${cx}" cy="${cy}" r="${s / 2 - 4}" fill="${col}" stroke="#1e3a8a" stroke-width="1.5"/>`;
    }
    for (const x of sp) o += `<line x1="${pd + x * s}" y1="4" x2="${pd + x * s}" y2="${H - 4}" stroke="${P.ink}" stroke-width="2.5" stroke-dasharray="6 4"/>`;
    return V.svg(W, H, o, Math.min(W * 1.1, 380));
  };

  V.ext['2C9-jadval'] = v => {
    const rows = v.rows, cols = v.cols, s = v.s || 44, W = (cols.length + 1) * s + 4, H = (rows.length + 1) * s + 4; let o = '';
    const q = v.q || [], hl = v.hl || [], has = (L, i, j) => L.some(e => e[0] === i && e[1] === j);
    const cell = (x, y, fill, txt, col) => `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${fill}" stroke="#3b82f6" stroke-width="2"/>` + (txt === '' ? '' : T(x + s / 2, y + s / 2 + 1, txt, { fs: String(txt).length > 2 ? 16 : 19, c: col || P.ink }));
    o += cell(2, 2, '#1d4ed8', '·', '#fff');
    cols.forEach((c, j) => { o += cell(2 + (j + 1) * s, 2, '#dbeafe', c) });
    rows.forEach((r, i) => {
      o += cell(2, 2 + (i + 1) * s, '#dbeafe', r);
      cols.forEach((c, j) => {
        const isq = has(q, i, j); let t = v.cells ? v.cells[i][j] : r * c; if (isq) t = '?';
        o += cell(2 + (j + 1) * s, 2 + (i + 1) * s, isq ? '#fff7d6' : has(hl, i, j) ? '#dcfce7' : '#fff', t == null ? '' : t, isq ? '#b45309' : P.ink);
      });
    });
    return V.svg(W, H, o, Math.min(W * 1.15, 380));
  };

  V.ext['2C9-yuzlik'] = v => {
    const a = v.from || 1, b = v.to || 100, cols = v.cols || 10, s = 34; const n = b - a + 1, rws = Math.ceil(n / cols);
    const hl = new Set(v.hl || []), ring = new Set(v.ring || []), q = new Set(v.q || []); let o = '';
    for (let k = 0; k < n; k++) {
      const x = 2 + (k % cols) * s, y = 2 + Math.floor(k / cols) * s, num = a + k;
      const f = q.has(num) ? '#fff7d6' : hl.has(num) ? (v.hc || '#fde68a') : '#fff';
      o += `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${f}" stroke="#93c5fd" stroke-width="1.5"/>`;
      if (ring.has(num)) o += `<circle cx="${x + s / 2}" cy="${y + s / 2}" r="${s / 2 - 3}" fill="none" stroke="${P.blue}" stroke-width="3"/>`;
      o += T(x + s / 2, y + s / 2 + 1, q.has(num) ? '?' : num, { fs: 14, c: q.has(num) ? '#b45309' : P.ink });
    }
    const W = cols * s + 4, H = rws * s + 4;
    return V.svg(W, H, o, Math.min(W * 1.1, 380));
  };

  V.ext['2C9-ifoda'] = v => `<div class="vx" style="font-size:${v.fs || 21}px;white-space:nowrap;letter-spacing:0">${V.esc(v.s).replace(/☐/g, '<i class="bx" style="min-width:30px;height:32px;line-height:32px"></i>').replace(/\?/g, '<i class="bx" style="min-width:30px;height:32px;line-height:32px">?</i>')}</div>`;

  V.ext['2C9-ustun'] = v => V.render(Object.assign({}, v, { t: 'col', op: '*' })).replace('<b class="op">×</b>', '<b class="op">·</b>');

  V.ext['2C9-maydon'] = v => {
    const ws = v.w || v.parts.map(() => 1), tot = ws.reduce((x, y) => x + y, 0), WW = 300, h = 90, L = 40, top = 30; let o = '', x = L;
    v.parts.forEach((p, i) => {
      const w = WW * ws[i] / tot;
      o += `<rect x="${x}" y="${top}" width="${w}" height="${h}" fill="${['#bfdbfe', '#fde68a', '#bbf7d0'][i % 3]}" stroke="${P.ink}" stroke-width="2.5"/>`;
      o += T(x + w / 2, top - 14, p, { fs: 16 });
      if (v.vals) o += T(x + w / 2, top + h / 2, v.vals[i], { fs: 18, c: v.vals[i] === '?' ? '#b45309' : P.ink });
      x += w;
    });
    o += T(L - 16, top + h / 2, v.m, { fs: 16 });
    return V.svg(L + WW + 10, top + h + 6, o, 360);
  };
})();

// 2D (matnli masalalar) uchun qo‘shimcha rasm turlari:
//  '2D-chizma' — Singapur "chizma model" (bar model):
//     {t:'2D-chizma', rows:[{lb:'Anvar', seg:[{n:24, s:'24'}, {n:8, s:'?', dash:true, c:'#..'}], r:'?', top:{a:0,b:1,s:'?'}, bot:{a:0,b:1,s:'45'}}],
//      vbr:{a:0, b:1, s:'Jami: ?'}, max:...}
//     n — bo‘lak uzunligi (masshtab uchun), s — bo‘lak ichidagi yozuv, dash — punktir (farq / yetishmaydigan qism),
//     r — qator oxiridagi yozuv, top/bot — qator ustidagi/ostidagi qavs (a..b bo‘laklar), vbr — o‘ngdagi tik qavs (a..b qatorlar).
//  '2D-yol' — yo‘l sxemasi: {t:'2D-yol', pts:['Uy','Maktab','Bozor'], d:[{n:25,s:'25 m'},{n:40,s:'?'}], tot:'?' (butun yo‘l qavsi), img:[...]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T;
  const ink = '#1e3a8a';
  // gorizontal qavs: x1..x2, y — asos, up=true bo‘lsa yuqoriga qaraydi
  const hbr = (x1, x2, y, up, s) => {
    const d = up ? -1 : 1, m = (x1 + x2) / 2, r = Math.min(8, (x2 - x1) / 4);
    const p = `M${x1} ${y}q0 ${d * 7} ${r} ${d * 7}H${m - 6}q6 0 6 ${d * 7}q0 ${-d * 7} 6 ${-d * 7}H${x2 - r}q${r} 0 ${r} ${-d * 7}`;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + (s != null && s !== '' ? T(m, y + d * 24, s, { fs: 15, c: s === '?' || /\?/.test(s) ? '#b45309' : P.ink, st: 1 }) : '');
  };
  // tik qavs: y1..y2, x — asos, o‘ngga qaraydi
  const vbr = (y1, y2, x, s) => {
    const m = (y1 + y2) / 2;
    const p = `M${x} ${y1}q7 0 7 7V${m - 6}q0 6 7 6q-7 0 -7 6V${y2 - 7}q0 7 -7 7`;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + T(x + 20, m, s, { fs: 15, a: 'start', c: /\?/.test(s) ? '#b45309' : P.ink });
  };
  const tw = s => String(s == null ? '' : s).length * 10;

  V.ext['2D-chizma'] = (v) => {
    const rows = v.rows, bh = 36;
    const sum = r => r.seg.reduce((a, s) => a + s.n, 0);
    const max = v.max || Math.max(...rows.map(sum));
    const lbw = rows.some(r => r.lb) ? Math.max(...rows.map(r => tw(r.lb))) + 14 : 4;
    const BW = v.bw || 260, k = BW / max;
    let y = 4, o = '', W = 0; const ys = [];
    rows.forEach((r, i) => {
      if (r.top) y += 32;
      let x = lbw; const xs = [x];
      if (r.lb) o += T(lbw - 8, y + bh / 2, r.lb, { fs: 15, a: 'end' });
      r.seg.forEach((s, j) => {
        const w = s.n * k, col = s.c || P.fills[(r.ci != null ? r.ci : i) % 7];
        o += s.dash
          ? `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="#fffbeb" stroke="#b45309" stroke-width="2" stroke-dasharray="6 4"/>`
          : `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="${col}" stroke="${ink}" stroke-width="2"/>`;
        if (s.s != null && s.s !== '') {
          const q = /\?/.test(String(s.s));
          if (w >= tw(s.s) + 6) o += T(x + w / 2, y + bh / 2, s.s, { fs: 15, c: q ? '#b45309' : P.ink, st: q ? 0 : 1 });
          else o += T(x + w / 2, y - 10, s.s, { fs: 13, c: q ? '#b45309' : P.ink, st: 1 });
        }
        x += w; xs.push(x);
      });
      if (r.top) o += hbr(xs[r.top.a], xs[r.top.b + 1], y - 3, true, r.top.s);
      if (r.bot) o += hbr(xs[r.bot.a], xs[r.bot.b + 1], y + bh + 3, false, r.bot.s);
      let xe = x;
      if (r.r != null && r.r !== '') { o += T(x + 10, y + bh / 2, r.r, { fs: 16, a: 'start', c: /\?/.test(String(r.r)) ? '#b45309' : P.ink }); xe = x + 14 + tw(r.r) }
      W = Math.max(W, xe);
      ys.push([y, y + bh, x]);
      y += bh + (r.bot ? 34 : 0) + 14;
    });
    if (v.vbr) {
      const a = ys[v.vbr.a], b = ys[v.vbr.b], xm = Math.max(...ys.slice(v.vbr.a, v.vbr.b + 1).map(q => q[2])) + 10;
      const xx = Math.max(xm, W + 6);
      o += vbr(a[0], b[1], xx, v.vbr.s); W = Math.max(W, xx + 24 + tw(v.vbr.s));
    }
    const H = y - 14 + 6;
    return V.svg(W + 4, H, o, Math.min(560, (W + 4) * 1.15));
  };

  V.ext['2D-yol'] = (v) => {
    const n = v.pts.length, tot = v.d.reduce((a, d) => a + d.n, 0), L = 30, BW = v.bw || 360, k = BW / tot, y = 54 + (v.title ? 26 : 0);
    let o = v.title ? T(L - 10, 12, v.title, { fs: 15, a: 'start', c: P.blue }) : '', x = L; const xs = [x];
    v.d.forEach(d => { x += d.n * k; xs.push(x) });
    o += `<line x1="${L}" y1="${y}" x2="${L + BW}" y2="${y}" stroke="${P.line}" stroke-width="4" stroke-linecap="round"/>`;
    v.d.forEach((d, i) => { o += hbr(xs[i] + 3, xs[i + 1] - 3, y - 12, true, d.s) });
    v.pts.forEach((p, i) => {
      o += `<circle cx="${xs[i]}" cy="${y}" r="8" fill="${i === 0 ? P.green : i === n - 1 ? P.red : P.blue}" stroke="#fff" stroke-width="2.5"/>`;
      o += T(i === 0 ? xs[i] - 10 : i === n - 1 ? xs[i] + 10 : xs[i], y + 24, p, { fs: 15, st: 1, a: i === 0 ? 'start' : i === n - 1 && n > 1 ? 'end' : 'middle' });
    });
    let H = y + 40;
    if (v.tot) { o += hbr(L, L + BW, y + 40, false, v.tot); H = y + 76 }
    return V.svg(L * 2 + 360, H, o, 470);
  };

  // '2D-narx' — narx yorlig‘li narsalar: {t:'2D-narx', l:[{img:'daftar', s:'3 000 so‘m'}], s:64}
  V.ext['2D-narx'] = (v) => {
    const s = v.s || 64; let x = 0, o = '';
    v.l.forEach(e => {
      const lw = String(e.s).length * 8.6 + 14, w = Math.max(s, lw) + 10;
      o += V.im(e.img, x + (w - s) / 2, 0, s);
      o += `<rect x="${x + (w - lw) / 2}" y="${s + 4}" width="${lw}" height="24" rx="7" fill="#fef3c7" stroke="#f59e0b" stroke-width="1.5"/>` + T(x + w / 2, s + 16, e.s, { fs: 14, c: '#92400e' });
      x += w;
    });
    return V.svg(x, s + 32, o, Math.min(560, x * 1.1));
  };
})();

// 2E (Kattaliklar) uchun qo‘shimcha rasm turlari:
//  '2E-soat'    — bitta soat (strelkalar to‘g‘ri o‘qda aylanadi): {t:'2E-soat', h, m}
//  '2E-soatlar' — bir nechta kichik soat, ostida yozuv: {t:'2E-soatlar', l:[{h,m},...], lb:['A','B',...]}
//  '2E-idish'   — o‘lchov idishi (litr shkalasi), suv sathi: {t:'2E-idish', l:[{max:10, val:6, step:1, lab:2, lb:'A'}]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;

  // bitta soat (200x200 koordinatada), siljitilgan va kichraytirilgan.
  // Strelka rasmlari (soat-qisqa, soat-uzun) — 200x200 kvadrat, aylanish o‘qi taxminan (99, 97) nuqtada, strelka tepaga qaragan.
  const clockAt = (V, x, y, S, h, m) => {
    const c = 100, mA = m * 6, hA = (h % 12) * 30 + m / 2;
    const hand = (n, a, k) => `<image href="${V.src(n)}" x="${c - 99 * k}" y="${c - 97 * k}" width="${200 * k}" height="${200 * k}" transform="rotate(${a} ${c} ${c})"/>`;
    return `<g transform="translate(${x} ${y}) scale(${S / 200})">${V.im('soat-yuz', 0, 0, 200)}${hand('soat-qisqa', hA, .56)}${hand('soat-uzun', mA, .8)}</g>`;
  };
  // bitta katta soat: {t:'2E-soat', h, m}
  V.ext['2E-soat'] = (v, V) => V.svg(200, 200, clockAt(V, 0, 0, 200, v.h, v.m), 210);

  V.ext['2E-soatlar'] = (v, V) => {
    const n = v.l.length, S = n > 2 ? 120 : 150, gap = 14, perRow = n > 2 ? 2 : n;
    const rows = Math.ceil(n / perRow), cellH = S + (v.lb ? 28 : 6);
    let o = '';
    v.l.forEach((t, i) => {
      const cx = (i % perRow) * (S + gap), cy = Math.floor(i / perRow) * cellH;
      o += clockAt(V, cx, cy, S, t.h, t.m);
      if (v.lb) o += V.T(cx + S / 2, cy + S + 14, v.lb[i], { fs: 17 });
    });
    const W = perRow * S + (perRow - 1) * gap;
    return V.svg(W, rows * cellH, o, W * 1.15);
  };

  // o‘lchov idishi: shisha banka, chap tomonida shkala (litr)
  V.ext['2E-idish'] = (v, V) => {
    const list = v.l, many = list.length > 1, w = many ? 64 : 84, H = 200, top = 22, gap = many ? 18 : 40, bw = w + 56; let o = '';
    list.forEach((e, i) => {
      const x0 = i * (bw + gap) + 34, max = e.max, val = e.val, st = e.step || 1, lab = e.lab || st, y0 = top + H;
      const Y = q => y0 - q / max * H;
      // suv
      if (val > 0) o += `<path d="M${x0} ${Y(val)}H${x0 + w}V${y0 - 10}q0 10 -10 10H${x0 + 10}q-10 0 -10 -10z" fill="#7dd3fc" opacity=".85"/><path d="M${x0} ${Y(val)}H${x0 + w}" stroke="#0284c7" stroke-width="3"/>`;
      // idish
      o += `<path d="M${x0} ${top - 12}V${y0 - 10}q0 10 10 10H${x0 + w - 10}q10 0 10 -10V${top - 12}" fill="none" stroke="#334155" stroke-width="3.5" stroke-linejoin="round"/>`;
      // shkala
      for (let q = 0; q <= max; q += st) {
        const big = q % lab === 0; o += `<line x1="${x0}" y1="${Y(q)}" x2="${x0 + (big ? 22 : 12)}" y2="${Y(q)}" stroke="#334155" stroke-width="${big ? 2.5 : 1.5}"/>`;
        if (big && !(e.hide || []).includes(q)) o += V.T(x0 - 16, Y(q), q, { fs: many ? 17 : 14 });
      }
      o += V.T(x0 + w + 16, top - 4, 'l', { fs: 18, c: '#0369a1' });
      if (e.lb) o += V.T(x0 + w / 2, y0 + 22, e.lb, { fs: 22 });
    });
    const W = list.length * (bw + gap) - gap + 10;
    return V.svg(W, top + H + (list.some(e => e.lb) ? 34 : 10), o, Math.min(W * 1.1, 520));
  };
})();

// 2F (2-sinf geometriya) uchun qo‘shimcha rasm turlari.
// '2F-jism' — fazoviy shakllar qatori, tagida harf/yozuv: {t:'2F-jism', l:[{s:'kub'|'par'|'shar'|'silindr'|'konus'|'piramida', lb:'A'}], h:80}
//   Har shakl vis.js dagi 'solid' chizmasidan olinadi va bitta SVG ichiga kichraytirib joylanadi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2F-jism'] = (v, V) => {
    const H = v.h || 80, gap = 12; let x = 4, o = '';
    const hasLb = v.l.some(e => e.lb);
    for (const e of v.l) {
      const s = V.render({ t: 'solid', s: e.s });
      const vb = s.match(/viewBox="0 0 ([\d.]+) ([\d.]+)"/); const w0 = +vb[1], h0 = +vb[2];
      const inner = s.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '');
      const k = H / h0, w = w0 * k;
      o += `<g transform="translate(${x.toFixed(1)} 2) scale(${k.toFixed(4)})">${inner}</g>`;
      if (e.lb) o += V.T(x + w / 2, H + 16, e.lb, { fs: 16, c: e.c || V.P.red });
      x += w + gap;
    }
    const W = x - gap + 4;
    return V.svg(W, H + (hasLb ? 30 : 6), o);
  };
})();
// '2F-geo' — vis.js dagi geo + qo‘shimcha element ('ang' tomonlari ham shu yerda chiziladi, rangi: col): {p:'ln', a:[x,y], b:[x,y], ends:'line'|'ray'|'none', c, dash, w}
//   'ln' — uchlarida nuqta (doiracha) chizilmaydigan chiziq: ray — b tomonda o‘q, line — ikki tomonda o‘q (uzaytirilib).
//   Qolgan elementlar (seg, pt, poly, txt, ang, circ, cells) — xuddi geo dagidek.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['2F-geo'] = (v, V) => {
    const u = v.u || 28, pd = 22, X = p => pd + p[0] * u, Y = p => pd + p[1] * u;
    // vis.js geo 'ang' tomonlarini rangsiz chizadi (stroke = e.c nuqta bo‘lib qoladi) — tomonlarni shu yerda chizamiz
    const extra = v.el.filter(e => e.p === 'ln'), rest = v.el.filter(e => e.p !== 'ln');
    for (const e of v.el) if (e.p === 'ang') extra.push({ p: 'ln', a: e.b, b: e.a, ends: 'none', c: e.col }, { p: 'ln', a: e.b, b: e.c, ends: 'none', c: e.col });
    let s = V.render(Object.assign({}, v, { t: 'geo', el: rest }));
    let o = '';
    for (const e of extra) {
      const a = e.a, b = e.b, dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy), c = e.c || V.P.blue;
      const ext = (p, k) => [p[0] + dx / d * k, p[1] + dy / d * k];
      const A = e.ends === 'line' ? ext(a, -(e.ex == null ? 1 : e.ex)) : a, B = (e.ends === 'line' || e.ends === 'ray') ? ext(b, e.ex == null ? 1 : e.ex) : b;
      o += `<line x1="${X(A)}" y1="${Y(A)}" x2="${X(B)}" y2="${Y(B)}" stroke="${c}" stroke-width="${e.w || 3.5}" stroke-linecap="round"${e.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
      const ang = Math.atan2(dy, dx) * 180 / Math.PI, arr = (P, r) => `<path d="M0 0l-12 -6.5v13z" fill="${c}" transform="translate(${X(P)} ${Y(P)}) rotate(${r})"/>`;
      if (e.ends === 'ray' || e.ends === 'line') o += arr(B, ang);
      if (e.ends === 'line') o += arr(A, ang + 180);
    }
    const m = s.lastIndexOf('stroke="#bfdbfe" stroke-width="1"/>');
    if (m >= 0) { const k = m + 'stroke="#bfdbfe" stroke-width="1"/>'.length; s = s.slice(0, k) + o + s.slice(k) }
    else s = s.replace(/^(<svg[^>]*>)/, '$1' + o);
    return s;
  };
})();

// 2F guruhi uchun qo‘shimcha rasm turlari (2F7–2F11).
// '2F-kub'    — kubiklar, darslikdagidek qiya (frontal) proyeksiyada: old yog‘i to‘liq kvadrat, chuqurlik o‘ngga-yuqoriga.
//               {t:'2F-kub', hm:[[3,2,1],[1,1,0]], s:30, floor:true, mono:false}
//               hm[i][j] — i: qator (0 — eng orqadagi), j: ustun (chapdan o‘ngga), qiymat — nechta kubik ustma-ust.
//               Bu chizmada balandlik (tepaga) va chuqurlik (o‘ngga-yuqoriga) adashmaydi.
// '2F-kublar' — bir nechta shaklni yonma-yon, tagiga harf bilan: {t:'2F-kublar', l:[{hm, lb:'A'}, ...]}
// V.F2.geom(hm, s) — har kubikning chizish tartibidagi tashqi oltiburchagi (ko‘rinishni dastur bilan sanash uchun).
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const PAD = 8;
  function geom(hm, s) {
    s = s || 30; const d = Math.round(s * .42), R = hm.length, Cn = hm[0].length, H = Math.max(1, ...hm.flat());
    const Y0 = PAD + (R - 1) * d + H * s + d; const list = [];
    for (let i = 0; i < R; i++) for (let j = 0; j < Cn; j++) for (let k = 0; k < hm[i][j]; k++) {
      const z = R - 1 - i, X = PAD + j * s + z * d, Yb = Y0 - z * d - k * s;
      list.push({ i, j, k, X, Yb, P: [[X, Yb], [X, Yb - s], [X + d, Yb - s - d], [X + s + d, Yb - s - d], [X + s + d, Yb - d], [X + s, Yb]] });
    }
    return { s, d, R, Cn, H, Y0, W: PAD * 2 + Cn * s + R * d, Hh: Y0 + PAD, list };
  }
  const COLS = [['#60a5fa', '#bfdbfe', '#2563eb'], ['#fbbf24', '#fde68a', '#d97706'], ['#34d399', '#a7f3d0', '#059669'], ['#f472b6', '#fbcfe8', '#db2777']];
  function draw(v) {
    const g = geom(v.hm, v.s), { s, d, R, Cn, Y0 } = g; let o = '';
    if (v.floor !== false) for (let i = 0; i < R; i++) for (let j = 0; j < Cn; j++) { const z = R - 1 - i, X = PAD + j * s + z * d, Yb = Y0 - z * d; o += `<path d="M${X} ${Yb}h${s}l${d} ${-d}h${-s}z" fill="#f1f5f9" stroke="#94a3b8" stroke-width="1" stroke-dasharray="3 3"/>` }
    for (const c of g.list) {
      const col = v.mono ? COLS[0] : COLS[(c.i + c.j + c.k) % COLS.length], { X, Yb } = c;
      o += `<g stroke="#1e3a8a" stroke-width="1.6" stroke-linejoin="round"><path d="M${X} ${Yb - s}h${s}l${d} ${-d}h${-s}z" fill="${col[1]}"/><path d="M${X + s} ${Yb}v${-s}l${d} ${-d}v${s}z" fill="${col[2]}"/><rect x="${X}" y="${Yb - s}" width="${s}" height="${s}" fill="${col[0]}"/></g>`;
    }
    return V.svg(g.W, g.Hh, o, Math.min(330, g.W * 1.25));
  }
  V.F2 = { geom };
  V.ext['2F-kub'] = v => draw(v);
  V.ext['2F-kublar'] = v => '<div style="display:flex;gap:12px;justify-content:center;align-items:flex-end">' +
    v.l.map(x => `<div style="flex:1 1 0;min-width:0;max-width:200px;text-align:center">${draw(x)}<div style="font:900 20px Nunito,system-ui,sans-serif;color:#ef4444">${V.esc(x.lb)}</div></div>`).join('') + '</div>';
})();

// 2G / 2Y guruhlari uchun qo‘shimcha rasm turlari:
//   '2GY-model' — Singapur "chizma model" (bar model): qatorlar, bo‘laklar, qavslar.
//   '2GY-chop'  — cho‘p belgili jadval (tally): har 5 ta cho‘p — bitta dasta.
//   '2GY-bars'  — bir nechta kichik ustunli diagramma (A, B, C, D) — "qaysi diagramma mos?" uchun.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const FILL = ['#bfdbfe', '#fde68a', '#bbf7d0', '#fbcfe8', '#ddd6fe', '#fed7aa'];
  const INK = '#0b2a6f', LINE = '#1e3a8a';

  // gorizontal qavs: x1..x2, y0 — bo‘lak chetidagi chiziq, dir = -1 (tepaga) yoki 1 (pastga)
  const hbrace = (x1, x2, y0, dir) => {
    const m = (x1 + x2) / 2, a = y0 + dir * 7, t = y0 + dir * 13, r = Math.min(8, (x2 - x1) / 4);
    return `<path d="M${x1} ${y0}Q${x1} ${a} ${x1 + r} ${a}L${m - r} ${a}Q${m} ${a} ${m} ${t}Q${m} ${a} ${m + r} ${a}L${x2 - r} ${a}Q${x2} ${a} ${x2} ${y0}" fill="none" stroke="${INK}" stroke-width="2.2"/>`;
  };
  const vbrace = (x0, y1, y2) => {
    const m = (y1 + y2) / 2, a = x0 + 7, t = x0 + 13, r = Math.min(8, (y2 - y1) / 4);
    return `<path d="M${x0} ${y1}Q${a} ${y1} ${a} ${y1 + r}L${a} ${m - r}Q${a} ${m} ${t} ${m}Q${a} ${m} ${a} ${m + r}L${a} ${y2 - r}Q${a} ${y2} ${x0} ${y2}" fill="none" stroke="${INK}" stroke-width="2.2"/>`;
  };
  const tw = (s, fs) => String(s).length * fs * 0.58;

  // {rows:[{lb, segs:[{n, s, c, dash}], top:{s, i0, i1}, bot:{s, i0, i1}}], right:{s, r0, r1}}
  V.ext['2GY-model'] = (v, V) => {
    const rows = v.rows, maxLen = Math.max(...rows.map(r => r.segs.reduce((a, s) => a + s.n, 0)));
    const right = v.right, L = 78, W = 420, RW = right ? Math.max(60, tw(right.s, 15) + 26) : 8;
    const k = (W - L - RW) / maxLen, BH = 32; let y = 6, o = ''; const pos = [];
    rows.forEach((r, ri) => {
      if (r.top) y += 30;
      const yb = y; let x = L; const xs = [];
      r.segs.forEach((s, si) => {
        const w = s.n * k; xs.push([x, x + w]);
        const fill = s.dash ? '#fff7d6' : FILL[(s.c != null ? s.c : ri) % FILL.length];
        o += `<rect x="${x}" y="${yb}" width="${w}" height="${BH}" fill="${fill}" stroke="${s.dash ? '#d97706' : LINE}" stroke-width="2"${s.dash ? ' stroke-dasharray="6 4"' : ''}/>`;
        if (s.s) { const fs = tw(s.s, 15) < w - 4 ? 15 : tw(s.s, 12) < w - 2 ? 12 : 10; o += V.T(x + w / 2, yb + BH / 2, s.s, { fs, c: s.dash ? '#b45309' : INK }) }
        x += w;
      });
      o += V.T(L - 8, yb + BH / 2, r.lb || '', { fs: 15, a: 'end' });
      const br = (b, dir) => { const i0 = b.i0 || 0, i1 = b.i1 != null ? b.i1 : r.segs.length - 1, x1 = xs[i0][0], x2 = xs[i1][1], y0 = dir < 0 ? yb - 2 : yb + BH + 2; return hbrace(x1, x2, y0, dir) + V.T((x1 + x2) / 2, y0 + dir * 22, b.s, { fs: 15, c: b.s.includes('?') ? '#b45309' : INK, st: 1 }) };
      if (r.top) o += br(r.top, -1);
      if (r.bot) o += br(r.bot, 1);
      pos.push([yb, yb + BH]);
      y = yb + BH + (r.bot ? 34 : 0) + 14;
    });
    if (right) {
      const r0 = right.r0 || 0, r1 = right.r1 != null ? right.r1 : rows.length - 1, x0 = L + maxLen * k + 6, y1 = pos[r0][0], y2 = pos[r1][1];
      o += vbrace(x0, y1, y2) + V.T(x0 + 18, (y1 + y2) / 2, right.s, { fs: 15, a: 'start', c: right.s.includes('?') ? '#b45309' : INK });
    }
    return V.svg(W, y - 6, o);
  };

  // {h:['Meva','Cho‘plar'], rows:[{lb, n}], num: true (son ustuni), q: [qator indekslari — son o‘rniga ?]}
  V.ext['2GY-chop'] = (v, V) => {
    const rows = v.rows, maxN = Math.max(...rows.map(r => r.n)), groups = Math.ceil(maxN / 5) || 1;
    const L = 120, GW = 46, RH = 40, numW = v.num ? 60 : 0, W = L + groups * GW + 16 + numW; let o = '';
    const H0 = v.h ? 34 : 0;
    if (v.h) { o += `<rect x="0" y="0" width="${W}" height="${H0}" rx="10" fill="#dbeafe"/>` + V.T(10, H0 / 2, v.h[0], { fs: 15, a: 'start' }) + V.T(L + (groups * GW) / 2, H0 / 2, v.h[1], { fs: 15 }); if (v.num) o += V.T(W - numW / 2, H0 / 2, v.h[2] || 'Soni', { fs: 15 }) }
    rows.forEach((r, i) => {
      const y = H0 + 4 + i * RH; o += `<rect x="0" y="${y}" width="${W}" height="${RH - 4}" rx="8" fill="${i % 2 ? '#fff' : '#eff6ff'}"/>` + V.T(10, y + (RH - 4) / 2, r.lb, { fs: 15, a: 'start' });
      for (let k = 0; k < r.n; k++) {
        const g = Math.floor(k / 5), p = k % 5, gx = L + g * GW;
        if (p < 4) o += `<line x1="${gx + 4 + p * 8}" y1="${y + 6}" x2="${gx + 4 + p * 8}" y2="${y + RH - 10}" stroke="${INK}" stroke-width="3" stroke-linecap="round"/>`;
        else o += `<line x1="${gx - 1}" y1="${y + RH - 13}" x2="${gx + 33}" y2="${y + 9}" stroke="#dc2626" stroke-width="3" stroke-linecap="round"/>`;
      }
      if (v.num) { const qq = (v.q || []).includes(i); o += qq ? `<rect x="${W - numW + 12}" y="${y + 4}" width="${numW - 24}" height="${RH - 12}" rx="6" fill="#fff7d6" stroke="#f5b301" stroke-width="2"/>` + V.T(W - numW / 2, y + (RH - 4) / 2, '?', { fs: 16, c: '#b45309' }) : V.T(W - numW / 2, y + (RH - 4) / 2, r.n, { fs: 15 }) }
    });
    return V.svg(W, H0 + 4 + rows.length * RH, o, Math.max(W, 260));
  };

  // {lb:['Olma','Nok',...], ch:[{name:'A', val:[...]}...], step, max}
  V.ext['2GY-bars'] = (v, V) => {
    const n = v.lb.length, max = v.max || Math.max(...v.ch.flatMap(c => c.val)), step = v.step || 1, top = Math.ceil(max / step) * step;
    const CW = 200, CH = 180, L = 26, B = 152, H = 108, gap = (CW - L - 8) / n, bw = Math.min(30, gap * .6); let o = '';
    v.ch.forEach((c, ci) => {
      const ox = (ci % 2) * (CW + 10), oy = Math.floor(ci / 2) * (CH + 10);
      o += `<g transform="translate(${ox} ${oy})"><rect x="0" y="0" width="${CW}" height="${CH}" rx="12" fill="#fff" stroke="#93c5fd" stroke-width="2"/>`;
      o += `<circle cx="20" cy="18" r="13" fill="#2563eb"/>` + V.T(20, 18, c.name, { fs: 15, c: '#fff' });
      for (let yv = 0; yv <= top; yv += step) { const yy = B - yv / top * H; o += `<line x1="${L}" y1="${yy}" x2="${CW - 8}" y2="${yy}" stroke="${(yv / step) % 2 ? '#eef2f7' : '#d5dde8'}" stroke-width="1.2"/>` + (top / step > 6 && (yv / step) % 2 ? '' : V.T(L - 5, yy, yv, { fs: 12, a: 'end' })) }
      c.val.forEach((x, i) => { const cx = L + gap * (i + .5), h = x / top * H; o += `<rect x="${cx - bw / 2}" y="${B - h}" width="${bw}" height="${h}" rx="4" fill="${V.P.fills[i % 7]}"/>` + V.T(cx, B + 15, v.lb[i], { fs: 12 }) });
      o += `<line x1="${L}" y1="${B}" x2="${CW - 8}" y2="${B}" stroke="#334155" stroke-width="2"/><line x1="${L}" y1="${B}" x2="${L}" y2="${B - H - 6}" stroke="#334155" stroke-width="2"/></g>`;
    });
    const rowsN = Math.ceil(v.ch.length / 2);
    return V.svg(2 * CW + 10, rowsN * (CH + 10) - 10, o);
  };
  // '2GY-pic' — piktogramma (vis.js 'pic' bilan bir xil), lekin yarim rasm clipPath id siz chiziladi:
  // sahifada ko‘p piktogramma bo‘lsa, bir xil id lar to‘qnashib yarim rasm ko‘rinmay qolardi.
  V.ext['2GY-pic'] = (v, V) => {
    const per = v.per || 1, s = 30, rows = v.lb.map((l, i) => { const k = v.val[i] / per, full = Math.floor(k + 1e-9), half = k - full >= .5; return { l, full, half } });
    const W = 120 + Math.max(...rows.map(r => r.full + (r.half ? 1 : 0)), 1) * s + 10; let o = '';
    rows.forEach((r, i) => {
      const y = 8 + i * (s + 10); o += `<rect x="0" y="${y - 4}" width="${W}" height="${s + 8}" rx="8" fill="${i % 2 ? '#fff' : '#eff6ff'}"/>` + V.T(8, y + s / 2, r.l, { fs: 14, a: 'start' });
      for (let k = 0; k < r.full; k++) o += V.im(v.img, 116 + k * s, y, s - 2);
      if (r.half) o += `<svg x="${116 + r.full * s}" y="${y}" width="${(s - 2) / 2}" height="${s}" overflow="hidden">${V.im(v.img, 0, 0, s - 2)}</svg>`;
    });
    const H = 8 + rows.length * (s + 10); o += V.im(v.img, 6, H + 4, 24) + V.T(36, H + 16, '= ' + (v.key || per + ' ta'), { fs: 14, a: 'start' });
    return V.svg(Math.max(W, 220), H + 34, o);
  };
  // '2GY-scene' — narsalar aralash to‘plami (saralash uchun): {l:[img,...], cols:6, s:50, lb:[yozuv]}
  V.ext['2GY-scene'] = (v, V) => {
    const n = v.l.length, cols = Math.min(v.cols || 6, n), s = v.s || 50, gap = 8, rows = Math.ceil(n / cols), lh = v.lb ? 20 : 0;
    const W = cols * (s + gap) + gap + 4, H = rows * (s + gap + lh) + gap + 4; let o = `<rect x="1" y="1" width="${W - 2}" height="${H - 2}" rx="14" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2"/>`;
    v.l.forEach((m, i) => { const x = 2 + gap + (i % cols) * (s + gap), y = 2 + gap + Math.floor(i / cols) * (s + gap + lh); o += V.im(m, x, y, s); if (v.lb) o += V.T(x + s / 2, y + s + 9, v.lb[i], { fs: 14 }) });
    return V.svg(W, H, o);
  };
})();

// 2H (Mantiq va olimpiada) uchun qo‘shimcha rasm turlari: kub/zar, kub yoyilmasi, labirint/katakli maydon, yo‘llar grafi,
// shakl tenglamalari, odamchalar qatori, stakanlar. Turlar nomi '2H11-' bilan boshlanadi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg, esc = V.esc;

  // --- kub/zar (bir yoki bir nechta ustma-ust): {l:[{t,f,r}], s} — t ust, f old (chap), r o‘ng yoq yozuvi; pastdan yuqoriga
  // bir nechta minora yonma-yon: {cols:[[{t,f,r}],[...]], lb:['A','B']}
  V.ext['2H11-kub'] = v => {
    const s = v.s || 64, dx = s * .866, dy = s * .5; const cols = v.cols || [v.l]; let o = '', W = 0;
    const H0 = Math.max(...cols.map(c => c.length)) * s + 2 * dy + 8;
    cols.forEach((col, ci) => {
      const ox = 6 + ci * (2 * dx + 26) + dx, base = H0 - 4; // pastki old uch
      col.forEach((d, k) => {
        const x = ox, y = base - k * s; // y — old qirraning pastki uchi
        const top = `M${x} ${y - s}l${dx} ${-dy}l${-dx} ${-dy}l${-dx} ${dy}z`, left = `M${x} ${y - s}l${-dx} ${-dy}v${s}l${dx} ${dy}z`, right = `M${x} ${y - s}l${dx} ${-dy}v${s}l${-dx} ${dy}z`;
        const q = c => c === '?';
        o += `<g stroke="#1e3a8a" stroke-width="2" stroke-linejoin="round"><path d="${top}" fill="${q(d.t) ? '#fff7d6' : '#eff6ff'}"/><path d="${left}" fill="${q(d.f) ? '#fff7d6' : '#bfdbfe'}"/><path d="${right}" fill="${q(d.r) ? '#fff7d6' : '#93c5fd'}"/></g>`;
        if (d.t != null && d.t !== '') o += T(x, y - s - dy, d.t, { fs: s * .34, c: q(d.t) ? '#b45309' : P.ink });
        if (d.f != null && d.f !== '') o += T(x - dx / 2, y - s / 2 - dy / 2 + 2, d.f, { fs: s * .34, c: q(d.f) ? '#b45309' : P.ink });
        if (d.r != null && d.r !== '') o += T(x + dx / 2, y - s / 2 - dy / 2 + 2, d.r, { fs: s * .34, c: q(d.r) ? '#b45309' : P.ink });
      });
      if (v.lb) o += T(ox, H0 + 14, v.lb[ci], { fs: 16, c: P.red });
      W = ox + dx + 6;
    });
    return svg(W, H0 + (v.lb ? 28 : 4), o, Math.min(360, W * 1.3));
  };

  // --- kub yoyilmalari: {nets:[{cells:[[x,y]], lab:[..], col:[..], name}], u}
  V.ext['2H11-yoy'] = v => {
    const u = v.u || (v.nets.length > 1 ? 24 : 40), gap = 22; let o = '', x = 0, y = 0, rowH = 0, W = 0; const maxW = v.maxW || (v.nets.length > 1 ? 330 : 400);
    v.nets.forEach((n, i) => {
      const mx = Math.max(...n.cells.map(c => c[0])) + 1, my = Math.max(...n.cells.map(c => c[1])) + 1, w = Math.max(mx * u, 40), h = my * u + (n.name ? 26 : 0);
      if (x && x + w > maxW) { x = 0; y += rowH + gap; rowH = 0 }
      n.cells.forEach((c, k) => {
        const cx = x + c[0] * u + 2, cy = y + c[1] * u + 2;
        o += `<rect x="${cx}" y="${cy}" width="${u}" height="${u}" fill="${(n.col && n.col[k]) || '#dbeafe'}" stroke="#1e3a8a" stroke-width="2"/>`;
        if (n.lab && n.lab[k] != null && n.lab[k] !== '') o += T(cx + u / 2, cy + u / 2 + 1, n.lab[k], { fs: u * .5, c: n.lab[k] === '?' ? '#b45309' : P.ink });
      });
      if (n.name) o += T(x + w / 2 + 2, y + my * u + 18, n.name, { fs: 17, c: P.red });
      x += w + gap; rowH = Math.max(rowH, h); W = Math.max(W, x - gap);
    });
    return svg(W + 4, y + rowH + 4, o, Math.min(400, (W + 4) * (v.nets.length > 1 ? 1.15 : 1)));
  };

  // --- labirint / katakli maydon: {w,h,u, rw:['0101..'], bw:['...'] (o‘ng/past devorlar, '1' — devor), open:true (devorsiz katakli),
  //   ent:[{x,y,s:'t'|'b'|'l'|'r',lb,c}], marks:[{x,y,img|s|fill|lb}], arr:['RDLU.'], nums:[[..]], path:[[x,y],..], block:[[x,y]]}
  V.ext['2H11-lab'] = v => {
    const w = v.w, h = v.h, u = v.u || (w > 6 ? 36 : 44), pd = 28, X = i => pd + i * u, Y = j => pd + j * u; let o = '';
    o += `<rect x="${pd}" y="${pd}" width="${w * u}" height="${h * u}" fill="${v.bg || '#f8fbff'}"/>`;
    (v.block || []).forEach(b => o += `<rect x="${X(b[0]) + 1}" y="${Y(b[1]) + 1}" width="${u - 2}" height="${u - 2}" rx="4" fill="#475569"/>`);
    (v.marks || []).forEach(m => { if (m.fill) o += `<rect x="${X(m.x) + 2}" y="${Y(m.y) + 2}" width="${u - 4}" height="${u - 4}" rx="6" fill="${m.fill}"/>` });
    if (v.open) { for (let i = 1; i < w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#94a3b8" stroke-width="1.5"/>`; for (let j = 1; j < h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#94a3b8" stroke-width="1.5"/>` }
    if (v.path) o += `<polyline points="${v.path.map(p => (X(p[0]) + u / 2) + ',' + (Y(p[1]) + u / 2)).join(' ')}" fill="none" stroke="${P.red}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="${v.pathDash ? '8 6' : ''}"/>`;
    (v.marks || []).forEach(m => {
      const cx = X(m.x) + u / 2, cy = Y(m.y) + u / 2;
      if (m.img) o += V.im(m.img, X(m.x) + u * .12, Y(m.y) + u * .12, u * .76);
      if (m.s) o += `<circle cx="${cx}" cy="${cy}" r="${u * .36}" fill="${m.c || '#fde68a'}" stroke="#b45309" stroke-width="2"/>` + T(cx, cy + 1, m.s, { fs: u * .4, c: '#7c2d12' });
      if (m.lb) { const k = m.img || m.s || m.corner; o += T(k ? X(m.x) + 9 : cx, k ? Y(m.y) + 10 : cy + 1, m.lb, { fs: k ? 14 : u * .45, c: P.red, st: 1 }) }
    });
    (v.nums || []).forEach((r, j) => r.forEach((n, i) => { if (n !== '' && n != null) o += T(X(i) + u / 2, Y(j) + u / 2 + 1, n, { fs: u * .42 }) }));
    const AR = { R: 0, D: 90, L: 180, U: 270 };
    (v.arr || []).forEach((r, j) => [...r].forEach((a, i) => { if (AR[a] == null) return; o += `<path d="M${-u * .28} 0H${u * .16}M${u * .02} ${-u * .17}L${u * .28} 0L${u * .02} ${u * .17}" fill="none" stroke="${P.blue}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" transform="translate(${X(i) + u / 2} ${Y(j) + u / 2}) rotate(${AR[a]})"/>` }));
    // devorlar
    let walls = '';
    if (!v.open) for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      if (i < w - 1 && v.rw[j][i] === '1') walls += `M${X(i + 1)} ${Y(j)}V${Y(j + 1)}`;
      if (j < h - 1 && v.bw[j][i] === '1') walls += `M${X(i)} ${Y(j + 1)}H${X(i + 1)}`;
    }
    const gapAt = (s, k) => (v.ent || []).some(e => e.s === s && (s === 't' || s === 'b' ? e.x : e.y) === k);
    for (let i = 0; i < w; i++) { if (!gapAt('t', i)) walls += `M${X(i)} ${Y(0)}H${X(i + 1)}`; if (!gapAt('b', i)) walls += `M${X(i)} ${Y(h)}H${X(i + 1)}` }
    for (let j = 0; j < h; j++) { if (!gapAt('l', j)) walls += `M${X(0)} ${Y(j)}V${Y(j + 1)}`; if (!gapAt('r', j)) walls += `M${X(w)} ${Y(j)}V${Y(j + 1)}` }
    o += `<path d="${walls}" stroke="${v.open ? '#1e3a8a' : '#1e3a8a'}" stroke-width="${v.open ? 3 : 5}" stroke-linecap="round" fill="none"/>`;
    (v.ent || []).forEach(e => {
      const [x, y] = e.s === 't' ? [X(e.x) + u / 2, pd - 13] : e.s === 'b' ? [X(e.x) + u / 2, Y(h) + 14] : e.s === 'l' ? [pd - 14, Y(e.y) + u / 2] : [X(w) + 14, Y(e.y) + u / 2];
      o += T(x, y, e.lb, { fs: 17, c: e.c || P.red, st: 1 });
    });
    return svg(w * u + pd * 2, h * u + pd * 2, o, Math.min(380, (w * u + pd * 2) * 1.1));
  };

  // --- yo‘llar grafi: {w,h (birlik 1 = u px), nodes:[{x,y,lb,img,c}], edges:[{a,b,lb,k (egrilik)}], arrows:false}
  V.ext['2H11-graf'] = v => {
    const u = v.u || 70, pd = 30, X = x => pd + x * u, Y = y => pd + y * u, N = v.nodes; let o = '', lab = '';
    v.edges.forEach(e => {
      const A = N[e.a], B = N[e.b], x1 = X(A.x), y1 = Y(A.y), x2 = X(B.x), y2 = Y(B.y), dx = x2 - x1, dy = y2 - y1, d = Math.hypot(dx, dy), k = (e.k || 0) * 26;
      const mx = (x1 + x2) / 2 - dy / d * k, my = (y1 + y2) / 2 + dx / d * k;
      o += `<path d="M${x1} ${y1}Q${2 * mx - (x1 + x2) / 2} ${2 * my - (y1 + y2) / 2} ${x2} ${y2}" fill="none" stroke="${e.c || '#64748b'}" stroke-width="4" stroke-linecap="round"/>`;
      if (e.lb != null) lab += `<rect x="${mx - 14}" y="${my - 11}" width="28" height="22" rx="6" fill="#fff" stroke="#cbd5e1"/>` + T(mx, my + 1, e.lb, { fs: 14, c: '#7c2d12' });
    });
    N.forEach(n => { if (n.hide) return; o += `<circle cx="${X(n.x)}" cy="${Y(n.y)}" r="19" fill="${n.c || '#dbeafe'}" stroke="#1e3a8a" stroke-width="2.5"/>` + T(X(n.x), Y(n.y) + 1, n.lb, { fs: 16 }) });
    return svg(v.w * u + pd * 2, v.h * u + pd * 2, o + lab, Math.min(380, (v.w * u + pd * 2)));
  };

  // --- shakl tenglamalari: {rows:[['doira','+','uchburchak','=','12'], ...]} — shakl nomi yoki matn
  const SC = { doira: '#60a5fa', uchburchak: '#34d399', kvadrat: '#fbbf24', yulduz: '#f472b6', romb: '#a78bfa', olti: '#fb923c', tortburchak: '#2dd4bf' };
  V.ext['2H11-teng'] = v => {
    const s = v.s || 38, rh = s + 10; let o = '', W = 0;
    v.rows.forEach((r, j) => {
      let x = 4; const y = 4 + j * rh;
      r.forEach(t => {
        if (SC[t] || t === '?') { o += V.shp(t, x, y, s, SC[t]); x += s + 4 }
        else { const str = String(t), w = Math.max(18, str.length * s * .36) + 6; o += T(x + w / 2, y + s / 2 + 1, str, { fs: s * .62, c: str === '?' ? '#b45309' : P.ink }); x += w + 4 }
      });
      W = Math.max(W, x);
    });
    return svg(W + 4, v.rows.length * rh + 2, o, Math.min(360, (W + 4) * 1.15));
  };

  // --- odamchalar qatori: {l:[{lb, c, h (bo‘y 0.7..1.2), top, hl}], front:'l'|'r'}
  V.ext['2H11-saf'] = v => {
    const s = v.s || 44, n = v.l.length, gap = 6, H = s * 2.4; let o = '';
    const W = n * (s + gap) + (v.front ? 46 : 0), off = v.front === 'l' ? 46 : 0;
    v.l.forEach((p, i) => {
      const k = p.h || 1, cx = off + i * (s + gap) + s / 2, by = H - 2, bh = s * 1.15 * k, hr = s * .24;
      const c = p.c || P.fills[i % 7];
      o += `<rect x="${cx - s * .3}" y="${by - bh}" width="${s * .6}" height="${bh}" rx="${s * .2}" fill="${c}" stroke="#1e3a8a" stroke-width="2"/>`;
      o += `<circle cx="${cx}" cy="${by - bh - hr - 1}" r="${hr}" fill="#fde2c4" stroke="#1e3a8a" stroke-width="2"/>`;
      if (p.hl) o += `<circle cx="${cx}" cy="${by - bh - hr - 1}" r="${hr + 5}" fill="none" stroke="${P.red}" stroke-width="2.5"/>`;
      if (p.lb != null) o += T(cx, by - bh / 2, p.lb, { fs: p.lb.length > 2 ? 11 : 15, c: '#fff', st: 0 });
      if (p.top != null) o += T(cx, by - bh - hr * 2 - 14, p.top, { fs: 14, c: P.red, st: 1 });
    });
    if (v.front) { const ax = v.front === 'l' ? 4 : W - 42; o += `<path d="M${ax + (v.front === 'l' ? 34 : 4)} ${H - 30}H${ax + (v.front === 'l' ? 6 : 32)}" stroke="${P.green}" stroke-width="4" stroke-linecap="round"/><path d="M${v.front === 'l' ? ax + 2 : ax + 38} ${H - 30}l${v.front === 'l' ? 10 : -10} -7v14z" fill="${P.green}"/>` + T(ax + 20, H - 12, 'oldi', { fs: 12, c: P.green }) }
    return svg(W, H + 2, o, Math.min(380, W * 1.2));
  };

  // --- to‘ntarilgan stakanlar: {n, lb:['A','B','C'], ball: indeks yoki -1}
  V.ext['2H11-stakan'] = v => {
    const s = 64, n = v.n; let o = '';
    for (let i = 0; i < n; i++) {
      const x = 10 + i * (s + 24);
      o += `<path d="M${x + 12} 10H${x + s - 12}L${x + s} 80H${x}z" fill="${P.fills[i % 7]}" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/><rect x="${x - 4}" y="78" width="${s + 8}" height="7" rx="3" fill="#1e3a8a"/>`;
      if (v.ball === i) o += `<circle cx="${x + s / 2}" cy="102" r="12" fill="${P.red}" stroke="#7f1d1d" stroke-width="2"/>`;
      if (v.lb) o += `<rect x="${x + s / 2 - 16}" y="122" width="32" height="26" rx="6" fill="#fff7d6" stroke="#f5b301" stroke-width="2"/>` + T(x + s / 2, 136, v.lb[i], { fs: 17, c: '#b45309' });
    }
    return svg(10 + n * (s + 24), 152, o, Math.min(360, (10 + n * (s + 24)) * 1.2));
  };
})();

// 3A, 3B guruhlari (3-sinf: sonlar, qo‘shish va ayirish) uchun qo‘shimcha rasm turlari:
//  '3AB-abak'    — cho‘t (abak): har sterjenda munchoqlar. {t:'3AB-abak', n:[3,0,5], lb:['Y','O‘','B'], q:[1] (shu sterjen ustida "?")}
//  '3AB-xona'    — xonalar jadvali (sinflar bilan): {t:'3AB-xona', d:['3','4','?','0','5','2'], cls:true}
//                  d — chapdan o‘ngga raqamlar (uzunligi 3..6). cls — sinf nomlari (Minglar / Birlar). hl — ajratib ko‘rsatiladigan katak (indeks).
//  '3AB-model'   — chizma model (Singapur): {t:'3AB-model', max:500, rows:[{lb:'Ali', segs:[{v:300,lb:'300'},{v:200,lb:'?',q:1}], tot:'?', ext:{v:100,lb:'?'}}]}
//                  tot — qator ustida qavs va yozuv (jami), ext — qator oxirida punktir bo‘lak (farq).
//  '3AB-uylar'   — ko‘chadagi uylar raqami: {t:'3AB-uylar', l:['24','26','?','30']}
//  '3AB-rimsoat' — Rim raqamli soat: {t:'3AB-rimsoat', h:3, m:0}
//  '3AB-piramida' — sonlar piramidasi (har g‘isht — ostidagi ikkitasining yig‘indisi): {t:'3AB-piramida', rows:[['?'],['500','?'],['200','300','150']]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P;

  V.ext['3AB-abak'] = (v, V) => {
    const n = v.n, k = n.length, rw = 58, bead = 15, top = 30, H = 9 * bead + 26, W = k * rw + 20; let o = '';
    o += `<rect x="4" y="${top + H}" width="${W - 8}" height="14" rx="5" fill="#92400e"/>`;
    n.forEach((c, i) => {
      const x = 10 + i * rw + rw / 2;
      o += `<line x1="${x}" y1="${top}" x2="${x}" y2="${top + H}" stroke="#78350f" stroke-width="5" stroke-linecap="round"/>`;
      for (let b = 0; b < c; b++) { const y = top + H - 10 - b * bead; o += `<ellipse cx="${x}" cy="${y}" rx="22" ry="${bead / 2 - .5}" fill="${P.fills[i % 7]}" stroke="#1e3a8a" stroke-width="1.5"/>` }
      if ((v.q || []).includes(i)) o += `<rect x="${x - 15}" y="${top - 28}" width="30" height="26" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + V.T(x, top - 15, '?', { fs: 16, c: '#b45309' });
      if (v.lb) o += V.T(x, top + H + 30, v.lb[i], { fs: String(v.lb[i]).length > 6 ? 12 : String(v.lb[i]).length > 4 ? 13 : 15 });
    });
    return V.svg(W, top + H + 44, o, Math.min(W * 1.3, 420));
  };

  V.ext['3AB-xona'] = (v, V) => {
    const NM = ['yuz minglar', 'o‘n minglar', 'minglar', 'yuzlar', 'o‘nlar', 'birlar'];
    const d = v.d, k = d.length, names = NM.slice(6 - k);
    let h1 = '';
    if (v.cls && k > 3) h1 = `<tr><th colspan="${k - 3}" style="background:#fde68a">Minglar sinfi</th><th colspan="3" style="background:#bbf7d0">Birlar sinfi</th></tr>`;
    const h2 = '<tr>' + names.map(x => `<th style="font-size:12px;padding:5px 4px">${x}</th>`).join('') + '</tr>';
    const r = '<tr>' + d.map((x, i) => x === '?' ? '<td style="background:#fff7d6;color:#b45309;font-size:22px">?</td>' : `<td style="font-size:22px${i === v.hl ? ';background:#fde68a;color:#b91c1c' : ''}">${V.esc(x)}</td>`).join('') + '</tr>';
    return `<table class="vt">${h1}${h2}${r}</table>`;
  };

  V.ext['3AB-model'] = (v, V) => {
    const rows = v.rows, LW = rows.some(r => r.lb) ? 70 : 4, W = 370, bw = W - LW - 10, rh = 40, tH = 34;
    const max = v.max || Math.max(...rows.map(r => r.segs.reduce((a, s) => a + s.v, 0) + (r.ext ? r.ext.v : 0)));
    const sc = bw / max; let o = '', y = 0;
    rows.forEach((r, i) => {
      if (r.tot) y += tH;
      let x = LW; const y0 = y;
      if (r.lb) o += V.T(LW - 8, y0 + rh / 2, r.lb, { fs: 14, a: 'end' });
      r.segs.forEach((s, j) => {
        const w = s.v * sc;
        o += s.q ? `<rect x="${x}" y="${y0}" width="${w}" height="${rh}" rx="4" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="6 4"/>`
          : `<rect x="${x}" y="${y0}" width="${w}" height="${rh}" rx="4" fill="${s.c || P.fills[(i * 2 + j) % 7]}" stroke="#1e3a8a" stroke-width="2"/>`;
        if (s.lb) o += V.T(x + w / 2, y0 + rh / 2, s.lb, { fs: w < 52 ? 13 : 16, c: s.q ? '#b45309' : P.ink, st: 1 });
        x += w;
      });
      if (r.ext) { const w = r.ext.v * sc; o += `<rect x="${x}" y="${y0}" width="${w}" height="${rh}" rx="4" fill="none" stroke="${P.red}" stroke-width="2" stroke-dasharray="5 4"/>`; if (r.ext.lb) o += V.T(x + w / 2, y0 + rh / 2, r.ext.lb, { fs: 16, c: P.red, st: 1 }) }
      if (r.tot) { const xe = LW + r.segs.reduce((a, s) => a + s.v, 0) * sc, yb = y0 - 6; o += `<path d="M${LW + 1} ${yb}v-8H${xe - 1}v8" fill="none" stroke="${P.ink}" stroke-width="2"/>` + V.T((LW + xe) / 2, yb - 18, r.tot, { fs: 16, c: r.tot === '?' ? '#b45309' : P.ink, st: 1 }) }
      y += rh + 14;
    });
    return V.svg(W, y - 10, o);
  };

  V.ext['3AB-uylar'] = (v, V) => {
    const l = v.l, s = 74, W = l.length * (s + 8); let o = '';
    l.forEach((t, i) => {
      const x = i * (s + 8) + 4, q = t === '?';
      o += `<path d="M${x + 4} 46L${x + s / 2} 8L${x + s - 4} 46z" fill="#f87171" stroke="#7f1d1d" stroke-width="2" stroke-linejoin="round"/>`;
      o += `<rect x="${x + 10}" y="46" width="${s - 20}" height="56" fill="#fde68a" stroke="#92400e" stroke-width="2"/>`;
      o += `<rect x="${x + s / 2 - 22}" y="56" width="44" height="26" rx="5" fill="${q ? '#fff7d6' : '#1d4ed8'}" stroke="${q ? P.gold : '#fff'}" stroke-width="2"${q ? ' stroke-dasharray="5 3"' : ''}/>`;
      o += V.T(x + s / 2, 69, t, { fs: t.length > 3 ? 13 : 16, c: q ? '#b45309' : '#fff' });
      o += `<rect x="${x + s / 2 - 7}" y="86" width="14" height="16" fill="#92400e"/>`;
    });
    return V.svg(W, 106, o, Math.min(W * 1.2, 560));
  };

  V.ext['3AB-rimsoat'] = (v, V) => {
    const R = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'], c = 100; let o = `<circle cx="${c}" cy="${c}" r="94" fill="#fffbeb" stroke="#92400e" stroke-width="6"/>`;
    for (let i = 0; i < 60; i++) { const a = i * Math.PI / 30, r1 = i % 5 ? 86 : 82; o += `<line x1="${c + r1 * Math.sin(a)}" y1="${c - r1 * Math.cos(a)}" x2="${c + 90 * Math.sin(a)}" y2="${c - 90 * Math.cos(a)}" stroke="#78350f" stroke-width="${i % 5 ? 1 : 2.5}"/>` }
    R.forEach((s, i) => { const a = i * Math.PI / 6; o += V.T(c + 69 * Math.sin(a), c - 69 * Math.cos(a), s, { fs: s.length > 2 ? 13 : 16, c: '#78350f' }) });
    const hA = ((v.h % 12) * 30 + v.m / 2) * Math.PI / 180, mA = v.m * 6 * Math.PI / 180;
    o += `<line x1="${c}" y1="${c}" x2="${c + 38 * Math.sin(hA)}" y2="${c - 38 * Math.cos(hA)}" stroke="#1e3a8a" stroke-width="8" stroke-linecap="round"/>`;
    o += `<line x1="${c}" y1="${c}" x2="${c + 54 * Math.sin(mA)}" y2="${c - 54 * Math.cos(mA)}" stroke="#2563eb" stroke-width="4.5" stroke-linecap="round"/><circle cx="${c}" cy="${c}" r="6" fill="#1e3a8a"/>`;
    return V.svg(200, 200, o, 210);
  };
  V.ext['3AB-piramida'] = (v, V) => {
    const rows = v.rows, n = rows.length, bw = 84, bh = 42, W = n * bw + 4; let o = '';
    rows.forEach((r, i) => { const x0 = (W - r.length * bw) / 2; r.forEach((c, j) => { const x = x0 + j * bw, y = i * bh + 2, q = c === '?';
      o += `<rect x="${x + 2}" y="${y}" width="${bw - 4}" height="${bh - 4}" rx="6" fill="${q ? '#fff7d6' : P.fills[(i + j) % 7] + '55'}" stroke="${q ? P.gold : '#1e3a8a'}" stroke-width="2"${q ? ' stroke-dasharray="6 4"' : ''}/>` + V.T(x + bw / 2, y + bh / 2 - 2, c, { fs: 17, c: q ? '#b45309' : P.ink }) }) });
    return V.svg(W, n * bh + 4, o, Math.min(W * 1.15, 420));
  };
})();

// 3C guruhi (3-sinf: ko‘paytirish va bo‘lish) uchun qo‘shimcha rasm turlari.
//  '3C-massiv'  — doirachalar massivi: {r, c, rem: ortib qolgan doirachalar, rows: true (har qator ramkada — teng guruhlar)}
//  '3C-jadval'  — ko‘paytirish jadvali bo‘lagi: {rows:[6,7], cols:[3,4,5], q:[[i,j]], blank:[[i,j]], cells:[[..]]}
//  '3C-ustun'   — ustun ko‘rinishida ko‘paytirish (· belgisi bilan): {a:'247', b:'3', r:'7?1'} ('?' — bo‘sh katak)
//  '3C-daraxt'  — sonni qulay qismlarga ajratish: {top:'72', parts:['60','12'], op:': 3', res:['20','4'], total:'24'}
//  '3C-model'   — chizma model (teng bo‘laklar): {rows:[{lb:'Anvar', n:3, s:'8'}], rt:['= ?', ''] (qator oxiridagi yozuv)}
//  '3C-ifoda'   — uzun ifoda (kichikroq shrift, kerak bo‘lsa qatorga bo‘linadi): {s:'(6 + 2) · 7 = ☐'}
//  '3C-tarozi'  — katta pallali tarozi: {l:[{img,n}|{s:'5 kg'}], r:[...], tilt:-1|0|1}
//  '3C-guruh'   — teng guruhlar va ortib qolganlar: {k: guruhlar soni, q: har guruhda, rem: ortib qolgan, img (ixtiyoriy)}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, Q = '#fff7d6', QS = '#f5b301', QC = '#b45309';

  V.ext['3C-massiv'] = v => {
    const r = v.r, c = v.c, rem = v.rem || 0, s = v.s || (c > 8 ? 30 : 34), pd = 10, gap = v.rows ? 8 : 0; let o = '';
    const W = Math.max(c, rem) * s + pd * 2, H = r * s + (r - 1) * gap + pd * 2 + (rem ? s + 14 : 0);
    if (!v.rows) o += `<rect x="1" y="1" width="${c * s + pd * 2 - 2}" height="${r * s + pd * 2 - 2}" rx="12" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"/>`;
    for (let i = 0; i < r; i++) {
      const y0 = pd + i * (s + gap);
      if (v.rows) o += `<rect x="${pd - 6}" y="${y0 - 3}" width="${c * s + 12}" height="${s + 6}" rx="${s / 2}" fill="#eff6ff" stroke="#3b82f6" stroke-width="2"/>`;
      for (let j = 0; j < c; j++) o += `<circle cx="${pd + j * s + s / 2}" cy="${y0 + s / 2}" r="${s / 2 - 5}" fill="${v.fill || '#60a5fa'}" stroke="#1e3a8a" stroke-width="1.5"/>`;
    }
    if (rem) { const y0 = pd + r * (s + gap) + 10; for (let j = 0; j < rem; j++) o += `<circle cx="${pd + j * s + s / 2}" cy="${y0 + s / 2}" r="${s / 2 - 5}" fill="#fbbf24" stroke="#92400e" stroke-width="1.5"/>` }
    return V.svg(W, H, o, Math.min(W * 1.1, 380));
  };

  V.ext['3C-jadval'] = v => {
    const rows = v.rows, cols = v.cols, s = v.s || 44, W = (cols.length + 1) * s + 4, H = (rows.length + 1) * s + 4; let o = '';
    const has = (L, i, j) => (L || []).some(e => e[0] === i && e[1] === j);
    const cell = (x, y, fill, txt, col) => `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${fill}" stroke="#3b82f6" stroke-width="2"/>` + (txt === '' ? '' : T(x + s / 2, y + s / 2 + 1, txt, { fs: String(txt).length > 2 ? 16 : 19, c: col || P.ink }));
    o += cell(2, 2, '#1d4ed8', '·', '#fff');
    cols.forEach((c, j) => { o += cell(2 + (j + 1) * s, 2, '#dbeafe', c) });
    rows.forEach((r, i) => {
      o += cell(2, 2 + (i + 1) * s, '#dbeafe', r);
      cols.forEach((c, j) => {
        const isq = has(v.q, i, j); let t = v.cells ? v.cells[i][j] : r * c; if (isq) t = '?'; if (has(v.blank, i, j)) t = '';
        o += cell(2 + (j + 1) * s, 2 + (i + 1) * s, isq ? Q : has(v.hl, i, j) ? '#dcfce7' : '#fff', t == null ? '' : t, isq ? QC : P.ink);
      });
    });
    return V.svg(W, H, o, Math.min(W * 1.15, 380));
  };

  V.ext['3C-ustun'] = v => {
    const a = String(v.a), b = String(v.b), r = v.r == null ? '' : String(v.r), w = Math.max(a.length, b.length + 1, r.length) + 1;
    const row = s => `<div class="cr">${[...s.padStart(w, ' ')].map(ch => `<span>${ch === ' ' ? '' : ch === '?' ? '<i class="bx">?</i>' : V.esc(ch)}</span>`).join('')}</div>`;
    const op = v.op || '·';
    return `<div class="vc"><b class="op"${op === '·' ? ' style="font-size:48px;top:8px;left:8px"' : ''}>${V.esc(op)}</b>${row(a)}${row(b)}<div class="ln"></div>${row(r)}</div>`;
  };

  V.ext['3C-daraxt'] = v => {
    const W = 320; let o = '';
    const box = (cx, cy, s, w) => { const q = s === '?'; w = w || Math.max(56, String(s).length * 14 + 22); return `<rect x="${cx - w / 2}" y="${cy - 19}" width="${w}" height="38" rx="10" fill="${q ? Q : '#eff6ff'}" stroke="${q ? QS : '#3b82f6'}" stroke-width="2.5"${q ? ' stroke-dasharray="6 4"' : ''}/>` + T(cx, cy + 1, s, { fs: 20, c: q ? QC : P.ink }) };
    const n = v.parts.length, xs = v.parts.map((_, i) => W / 2 + (i - (n - 1) / 2) * (n > 2 ? 100 : 130));
    o += xs.map(x => `<line x1="${W / 2}" y1="40" x2="${x}" y2="82" stroke="${P.line}" stroke-width="2.5"/>`).join('');
    o += box(W / 2, 24, v.top);
    v.parts.forEach((p, i) => { o += box(xs[i], 96, p) });
    let H = 120;
    if (v.res) {
      v.parts.forEach((_, i) => { o += `<line x1="${xs[i]}" y1="116" x2="${xs[i]}" y2="150" stroke="${P.blue}" stroke-width="2.5"/><path d="M${xs[i]} 156l-6 -9h12z" fill="${P.blue}"/>` + T(xs[i] + 10, 134, v.op, { fs: 16, a: 'start', c: P.blue, st: 1 }) });
      v.res.forEach((p, i) => { o += box(xs[i], 176, p) });
      for (let i = 1; i < n; i++) o += T((xs[i - 1] + xs[i]) / 2, 176, '+', { fs: 22 });
      H = 200;
      if (v.total != null) { o += `<path d="M${xs[0]} 198V214H${xs[n - 1]}V198M${W / 2} 214V226" fill="none" stroke="${P.line}" stroke-width="2.5"/>` + box(W / 2, 246, v.total); H = 270 }
    }
    return V.svg(W, H, o, 340);
  };

  V.ext['3C-model'] = v => {
    const rows = v.rows, hasLb = rows.some(r => r.lb), L = hasLb ? Math.max(...rows.map(r => String(r.lb || '').length)) * 11.5 + 14 : 10, mx = Math.max(...rows.map(r => r.n)), rtw = Math.max(10, ...(v.rt || []).map(x => x ? String(x).length * 10 + 14 : 0));
    const u = Math.min(52, (440 - L - rtw) / mx), rh = 40, gap = 16; let o = '', y = 6;
    rows.forEach((r, i) => {
      if (r.lb) o += T(L - 8, y + rh / 2, r.lb, { fs: 16, a: 'end' });
      for (let k = 0; k < r.n; k++) { const q = r.s === '?' && k === 0; o += `<rect x="${L + k * u}" y="${y}" width="${u}" height="${rh}" rx="3" fill="${q ? Q : P.fills[i % 7] + '55'}" stroke="#1e3a8a" stroke-width="2"/>`; if (r.s != null && (k === 0 || r.all)) o += T(L + k * u + u / 2, y + rh / 2, r.s, { fs: String(r.s).length > 2 ? 14 : 17, c: r.s === '?' ? QC : P.ink }) }
      if (v.rt && v.rt[i]) o += T(L + r.n * u + 8, y + rh / 2, v.rt[i], { fs: 17, a: 'start', c: v.rt[i].includes('?') ? QC : P.ink });
      y += rh + gap;
    });
    return V.svg(L + mx * u + rtw, y - gap + 6, o, 460);
  };

  V.ext['3C-ifoda'] = v => `<div class="vx" style="font-size:${v.fs || 22}px;letter-spacing:0;line-height:1.6">${V.esc(v.s).replace(/☐/g, '<i class="bx" style="min-width:30px;height:32px;line-height:32px"></i>').replace(/\?/g, '<i class="bx" style="min-width:30px;height:32px;line-height:32px">?</i>')}</div>`;

  V.ext['3C-guruh'] = v => {
    const k = v.k, q = v.q, rem = v.rem || 0, s = 26, per = q <= 5 ? q : Math.ceil(q / 2), gw = per * s + 14, gh = Math.ceil(q / per) * s + 14;
    const items = []; for (let i = 0; i < k; i++) items.push({ n: q, w: gw, h: gh }); if (rem) items.push({ n: rem, w: Math.min(rem, 4) * s + 14, h: Math.ceil(rem / 4) * s + 14, rem: true });
    const maxW = 360; let x = 0, y = 0, rowH = 0, W = 0; const pos = [];
    for (const it of items) { if (x && x + it.w > maxW) { x = 0; y += rowH + 10; rowH = 0 } pos.push([x, y]); x += it.w + 10; rowH = Math.max(rowH, it.h + (it.rem ? 18 : 0)); W = Math.max(W, x - 10) }
    let o = '';
    items.forEach((it, i) => {
      const [bx, by] = pos[i], pr = it.rem ? 4 : per;
      o += `<rect x="${bx + 1}" y="${by + 1}" width="${it.w - 2}" height="${it.h - 2}" rx="12" fill="${it.rem ? '#fff' : '#eff6ff'}" stroke="${it.rem ? QS : '#3b82f6'}" stroke-width="2"${it.rem ? ' stroke-dasharray="6 4"' : ''}/>`;
      for (let j = 0; j < it.n; j++) {
        const cx = bx + 7 + (j % pr) * s, cy = by + 7 + Math.floor(j / pr) * s;
        o += v.img ? V.im(v.img, cx + 1, cy + 1, s - 2) : `<circle cx="${cx + s / 2}" cy="${cy + s / 2}" r="${s / 2 - 4}" fill="${it.rem ? '#fbbf24' : '#60a5fa'}" stroke="#1e3a8a" stroke-width="1.5"/>`;
      }
      if (it.rem) o += T(bx + it.w / 2, by + it.h + 9, 'ortib qoldi', { fs: 12, c: QC });
    });
    return V.svg(W + 2, y + rowH + 2, o, Math.min((W + 2) * 1.2, 400));
  };
  V.ext['3C-tarozi'] = (v, V) => {
    const W = 380, cx = W / 2, t = v.tilt || 0, sh = t < 0 ? 14 : t > 0 ? -14 : 0; // chap palla siljishi (tilt=-1 -> pastga)
    const yL = 180 + sh, yR = 180 - sh;
    const bL = 70 + sh, bR = 70 - sh;
    let o = `<path d="M${cx - 60} 250h120l-18 -18h-84z" fill="#64748b"/><rect x="${cx - 7}" y="66" width="14" height="168" rx="5" fill="#94a3b8"/>`;
    o += `<line x1="30" y1="${bL}" x2="${W - 30}" y2="${bR}" stroke="#475569" stroke-width="10" stroke-linecap="round"/><circle cx="${cx}" cy="70" r="9" fill="#334155"/>`;
    const pan = (x, by, py, list) => {
      let s = `<line x1="${x}" y1="${by}" x2="${x - 70}" y2="${py}" stroke="#64748b" stroke-width="2.5"/><line x1="${x}" y1="${by}" x2="${x + 70}" y2="${py}" stroke="#64748b" stroke-width="2.5"/>`;
      s += `<path d="M${x - 84} ${py}h168a84 22 0 0 1 -168 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2.5"/>`;
      const all = []; list.forEach(e => { if (e.s) all.push(e); else for (let i = 0; i < e.n; i++) all.push({ img: e.img }) });
      const per = all.length > 6 ? 4 : 3, sz = all.length > 6 ? 38 : 48;
      all.forEach((e, i) => {
        const row = Math.floor(i / per), inRow = Math.min(per, all.length - row * per), col = i % per;
        const xx = x - inRow * sz / 2 + col * sz, yy = py - sz - row * (sz * .82);
        if (e.img) s += V.im(e.img, xx + 1, yy, sz - 2);
        else s += V.im('gir', xx - 2, yy - 6, sz + 4) + V.T(xx + sz / 2, yy + sz * .58, e.s, { fs: e.s.length > 4 ? 12 : 15, c: '#0b2a6f', st: 1 });
      });
      return s;
    };
    o += pan(80, bL, yL, v.l) + pan(W - 80, bR, yR, v.r);
    return V.svg(W, 256, o, 400);
  };

})();

// 3C guruhi (ko‘paytirish va bo‘lish, 3-sinf) uchun qo‘shimcha rasm turlari.
//  '3C9-burchak' — burchakli bo‘lish: {a: bo‘linuvchi, b: bo‘luvchi, n: nechta qadam ko‘rsatiladi (yo‘q bo‘lsa — hammasi; 0 — faqat yozuv),
//                  qs: bo‘linma yozuvi ('?' — yashirin raqam; '' — bo‘sh), hide: ['p0','c1','r', ...] (p — ayriluvchi, c — tushirilgan son, r — qoldiq)}
//  '3C9-ustun'   — ustun ko‘paytirish (· belgisi bilan): {a, b, res: natija yozuvi ('?' bilan), pp: to‘liqmas ko‘paytmalar yozuvi ['?..'], parts: false — oraliq qatorsiz}
//  '3C9-maydon'  — to‘g‘ri to‘rtburchak (maydon) modeli: {cols:['20','4'], rows:['3'] yoki ['10','3'], vals:[['60','12']] ('?' bo‘lishi mumkin)}
//  '3C9-massiv'  — doirachalar massivi: {r, c, split:[ustun indekslari], rsplit:[qator indekslari]}
//  '3C9-sonlar'  — sonlar jadvali: {from, to, cols, hl:[bo‘yalgan sonlar]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T;
  const QF = '#fff7d6', QS = '#f5b301', QC = '#b45309';

  // burchakli bo‘lish qadamlari
  const divSteps = (a, b) => {
    const s = String(a), n = s.length; let i = 0, cur = 0; const st = []; let q = '';
    while (i < n && cur < b) { cur = cur * 10 + +s[i]; i++ }
    let end = i - 1;
    for (;;) {
      if (cur >= b) { const d = Math.floor(cur / b); st.push({ cur, end, prod: d * b }); q += d; cur -= d * b }
      else if (st.length) q += '0';
      if (i >= n) break;
      cur = cur * 10 + +s[i]; end = i; i++;
    }
    return { st, fin: { cur, end }, q: q || '0' };
  };
  V.divSteps = divSteps;

  V.ext['3C9-burchak'] = v => {
    const a = v.a, b = v.b, s = String(a), n = s.length, cw = 24, lh = 32, L = 22;
    const { st, fin, q } = divSteps(a, b);
    const show = v.n == null ? st.length : v.n, hide = new Set(v.hide || []);
    const qs = v.qs == null ? q : v.qs;
    const X = c => L + c * cw + cw / 2; let o = '';
    const num = (str, endCol, row, hid) => {
      const k = str.length, y = 18 + row * lh;
      if (hid) { const x0 = X(endCol - k + 1) - cw / 2 + 1; return `<rect x="${x0}" y="${y - 14}" width="${k * cw - 2}" height="28" rx="7" fill="${QF}" stroke="${QS}" stroke-width="2" stroke-dasharray="5 3"/>` + T(x0 + (k * cw - 2) / 2, y + 1, '?', { fs: 18, c: QC }) }
      return [...str].map((ch, j) => T(X(endCol - k + 1 + j), y, ch, { fs: 22 })).join('');
    };
    // bo‘linuvchi
    o += num(s, n - 1, 0, false);
    let row = 0;
    for (let k = 0; k < Math.min(show, st.length); k++) {
      const e = st[k], cs = String(e.cur), ps = String(e.prod);
      if (k > 0) { row++; o += num(cs, e.end, row, hide.has('c' + k)) }
      row++; o += num(ps, e.end, row, hide.has('p' + k));
      const w = Math.max(cs.length, ps.length), x0 = X(e.end - w + 1) - cw / 2, y = 18 + row * lh;
      o += T(x0 - 9, y - (lh / 2) - 1, '−', { fs: 20 });
      o += `<line x1="${x0}" y1="${y + 15}" x2="${x0 + w * cw}" y2="${y + 15}" stroke="${P.ink}" stroke-width="2"/>`;
    }
    if (show >= st.length && st.length) { row++; o += num(String(fin.cur), fin.end, row, hide.has('r')) }
    // burchak
    const lx = L + n * cw + 8, bs = String(b), rw = Math.max(bs.length, String(q).length, qs.length) * cw + 14;
    o += `<line x1="${lx}" y1="2" x2="${lx}" y2="${18 + lh + 16}" stroke="${P.ink}" stroke-width="2.5"/><line x1="${lx}" y1="${18 + 16}" x2="${lx + rw}" y2="${18 + 16}" stroke="${P.ink}" stroke-width="2.5"/>`;
    [...bs].forEach((ch, j) => { o += T(lx + 10 + j * cw + cw / 2, 18, ch, { fs: 22 }) });
    [...qs].forEach((ch, j) => {
      const x = lx + 10 + j * cw + cw / 2, y = 18 + lh + 4;
      o += ch === '?' ? `<rect x="${x - cw / 2 + 1}" y="${y - 13}" width="${cw - 2}" height="26" rx="6" fill="${QF}" stroke="${QS}" stroke-width="2" stroke-dasharray="4 3"/>` + T(x, y + 1, '?', { fs: 17, c: QC }) : T(x, y, ch, { fs: 22, c: P.blue });
    });
    const W = lx + rw + 6, H = 18 + Math.max(row, 1) * lh + 22;
    return `<div style="display:inline-block;background:#fff;border:2px solid #dbeafe;border-radius:12px;padding:4px 8px">` + V.svg(W, H, o, W) + '</div>';
  };

  V.ext['3C9-ustun'] = v => {
    const a = String(v.a), b = String(v.b), res = v.res == null ? String(v.a * v.b) : v.res;
    const ds = [...b].reverse(); const parts = [];
    ds.forEach((d, j) => { if (+d) parts.push({ s: String(v.a * +d), j }) });
    const showP = v.parts !== false && parts.length > 1;
    const pp = v.pp || parts.map(p => p.s);
    const rowsTxt = [[a, 0], [b, 0]]; if (showP) parts.forEach((p, k) => rowsTxt.push([pp[k], p.j]));
    const w = Math.max(...rowsTxt.map(([t, j]) => t.length + j), res.length) + 1;
    const cw = 24, lh = 34, L = 6; let o = '', y = 20;
    const X = c => L + c * cw + cw / 2;
    const put = (t, shift, yy, col) => [...t].forEach((ch, i) => {
      const c = w - shift - t.length + i, x = X(c);
      o += ch === '?' ? `<rect x="${x - cw / 2 + 1}" y="${yy - 14}" width="${cw - 2}" height="28" rx="6" fill="${QF}" stroke="${QS}" stroke-width="2" stroke-dasharray="4 3"/>` + T(x, yy + 1, '?', { fs: 17, c: QC }) : T(x, yy, ch, { fs: 22, c: col || P.ink });
    });
    put(a, 0, y); y += lh; put(b, 0, y); o += T(X(w - Math.max(a.length, b.length) - 1), y - lh / 2, '·', { fs: 30 });
    const line = yy => { o += `<line x1="${X(w - Math.max(a.length, b.length, res.length) - 1) - cw / 2}" y1="${yy}" x2="${X(w - 1) + cw / 2}" y2="${yy}" stroke="${P.ink}" stroke-width="2.5"/>` };
    line(y + 17); y += lh + 2;
    if (showP) {
      parts.forEach((p, k) => { put(pp[k], p.j, y, '#334155'); y += lh });
      o += T(X(w - Math.max(...parts.map(p => p.s.length + p.j), res.length) - 1), y - lh * parts.length / 2 - lh / 2 + 2, '+', { fs: 22 });
      line(y - lh / 2 + 1); y += 2;
    }
    put(res, 0, y, P.blue);
    const W = L * 2 + w * cw, H = y + 20;
    return `<div style="display:inline-block;background:#fff;border:2px solid #dbeafe;border-radius:12px;padding:4px 10px">` + V.svg(W, H, o, W) + '</div>';
  };

  V.ext['3C9-maydon'] = v => {
    const cols = v.cols, rows = v.rows, cwt = v.cw || cols.map(() => 1), rwt = v.rw || rows.map(() => 1);
    const ct = cwt.reduce((x, y) => x + y, 0), rt = rwt.reduce((x, y) => x + y, 0);
    const WW = 280, HH = rows.length > 1 ? 150 : 90, L = 46, top = 28; let o = '';
    const FL = [['#bfdbfe', '#bbf7d0', '#ddd6fe'], ['#fbcfe8', '#c7d2fe', '#a7f3d0']];
    let y = top;
    rows.forEach((r, i) => {
      const h = HH * rwt[i] / rt; let x = L;
      cols.forEach((c, j) => {
        const w = WW * cwt[j] / ct, val = v.vals ? v.vals[i][j] : '';
        o += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${val === '?' ? QF : FL[i % 2][j % 3]}" stroke="${P.ink}" stroke-width="2.5"/>`;
        if (val !== '') o += T(x + w / 2, y + h / 2, val, { fs: 18, c: val === '?' ? QC : P.ink });
        if (i === 0) o += T(x + w / 2, top - 14, c, { fs: 16 });
        x += w;
      });
      o += T(L - 22, y + h / 2, r, { fs: 16 });
      y += h;
    });
    return V.svg(L + WW + 10, top + HH + 6, o, 360);
  };

  V.ext['3C9-massiv'] = v => {
    const r = v.r, c = v.c, s = v.s || (c > 10 ? 26 : c > 8 ? 30 : 34), pd = 10; let o = '';
    const FILL = ['#60a5fa', '#34d399', '#fbbf24', '#f472b6'];
    const W = c * s + pd * 2, H = r * s + pd * 2, sp = v.split || [], rs = v.rsplit || [];
    o += `<rect x="1" y="1" width="${W - 2}" height="${H - 2}" rx="12" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"/>`;
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) {
      let k = 0; for (const x of sp) if (j >= x) k++; for (const x of rs) if (i >= x) k++;
      o += `<circle cx="${pd + j * s + s / 2}" cy="${pd + i * s + s / 2}" r="${s / 2 - 4}" fill="${FILL[k % 4]}" stroke="#1e3a8a" stroke-width="1.5"/>`;
    }
    for (const x of sp) o += `<line x1="${pd + x * s}" y1="4" x2="${pd + x * s}" y2="${H - 4}" stroke="${P.ink}" stroke-width="2.5" stroke-dasharray="6 4"/>`;
    for (const x of rs) o += `<line x1="4" y1="${pd + x * s}" x2="${W - 4}" y2="${pd + x * s}" stroke="${P.ink}" stroke-width="2.5" stroke-dasharray="6 4"/>`;
    return V.svg(W, H, o, Math.min(W * 1.1, 380));
  };

  V.ext['3C9-sonlar'] = v => {
    const a = v.from, b = v.to, cols = v.cols || 10, s = 34, n = b - a + 1, rws = Math.ceil(n / cols), hl = new Set(v.hl || []); let o = '';
    for (let k = 0; k < n; k++) {
      const x = 2 + (k % cols) * s, y = 2 + Math.floor(k / cols) * s, num = a + k;
      o += `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${hl.has(num) ? '#fde68a' : '#fff'}" stroke="#93c5fd" stroke-width="1.5"/>` + T(x + s / 2, y + s / 2 + 1, num, { fs: 13 });
    }
    const W = cols * s + 4, H = rws * s + 4;
    return V.svg(W, H, o, Math.min(W * 1.1, 380));
  };
})();

// 3D/3F (3-sinf: ifodalar va ulushlar) uchun qo‘shimcha rasm turlari.
// '3DF-ulush' — teng (yoki ataylab teng bo‘lmagan) bo‘laklarga bo‘lingan shakllar qatori:
//   {t:'3DF-ulush', s:96, l:[{f:'doira'|'tort'|'kvadrat'|'diag'|'plitka'|'uch', n:4, k:1, sh:[0,2], w:[1,1,2], r:2, c:'#..', lb:'A'}]}
//   f: doira — markazdan bo‘lingan doira; tort — to‘rtburchak (tik bo‘laklar); kvadrat — kvadrat (tik bo‘laklar);
//      diag — kvadrat diagonallar bo‘yicha (n=2 yoki 4); plitka — r qator × (n/r) ustun katakli to‘rtburchak (shokolad);
//      uch — teng tomonli uchburchak (n=2 — balandlik bo‘yicha, n=4 — o‘rta chiziqlar bo‘yicha).
//   n — bo‘laklar soni, k — nechta bo‘lak bo‘yalgan (birinchilari), sh — bo‘yalgan bo‘laklar raqami (k o‘rniga),
//   w — bo‘laklar "og‘irligi" (teng bo‘lmagan bo‘lish uchun; berilmasa hammasi teng). lb — tagidagi yozuv.
// '3DF-tasma' — chizma model (tasma, Singapur usuli): bir xil uzunlikdagi tasmalar ustma-ust:
//   {t:'3DF-tasma', W:300, bars:[{n:4, k:1, sh:[...], c:'#..', lb:'1/4', top:'24', parts:['6','','',''], bq:'?', bqn:1}]}
//   cols — har bo‘lak rangi (ixtiyoriy, k/sh o‘rniga). top — butun tasma ustidagi qavs yozuvi; parts — har bo‘lak ichidagi yozuv; bq — birinchi bqn ta bo‘lak ostidagi qavs yozuvi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const SH = '#60a5fa', BG = '#ffffff', LN = '#1e3a8a';
  const shadedSet = e => new Set(e.sh || Array.from({ length: e.k || 0 }, (_, i) => i));
  const f1 = x => +x.toFixed(2);

  function one(e, x0, y0, s) {
    const n = e.n, w = e.w || Array(n).fill(1), tot = w.reduce((a, b) => a + b, 0), on = shadedSet(e), col = e.c || SH;
    let o = '';
    const fill = i => on.has(i) ? col : BG;
    if (e.f === 'doira') {
      const cx = x0 + s / 2, cy = y0 + s / 2, r = s / 2 - 3;
      if (n === 1) return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill(0)}" stroke="${LN}" stroke-width="2.5"/>`;
      let a = -Math.PI / 2;
      for (let i = 0; i < n; i++) {
        const b = a + w[i] / tot * 2 * Math.PI, big = b - a > Math.PI ? 1 : 0;
        o += `<path d="M${cx} ${cy}L${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}A${r} ${r} 0 ${big} 1 ${f1(cx + r * Math.cos(b))} ${f1(cy + r * Math.sin(b))}Z" fill="${fill(i)}" stroke="${LN}" stroke-width="2" stroke-linejoin="round"/>`;
        a = b;
      }
      return o + `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
    }
    if (e.f === 'tort' || e.f === 'kvadrat') {
      const W = e.f === 'tort' ? s * 1.35 : s - 6, H = e.f === 'tort' ? s * .62 : s - 6, x = x0 + (e.f === 'tort' ? 0 : 3), y = y0 + (s - H) / 2;
      let xx = x;
      for (let i = 0; i < n; i++) { const ww = w[i] / tot * W; o += `<rect x="${f1(xx)}" y="${f1(y)}" width="${f1(ww)}" height="${f1(H)}" fill="${fill(i)}" stroke="${LN}" stroke-width="2"/>`; xx += ww }
      return o + `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(W)}" height="${f1(H)}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
    }
    if (e.f === 'plitka') {
      const r = e.r || 2, c = n / r, W = s * 1.35, H = s * .78, x = x0, y = y0 + (s - H) / 2, cw = W / c, ch = H / r;
      for (let i = 0; i < n; i++) { const rr = Math.floor(i / c), cc = i % c; o += `<rect x="${f1(x + cc * cw)}" y="${f1(y + rr * ch)}" width="${f1(cw)}" height="${f1(ch)}" fill="${on.has(i) ? col : '#fde68a'}" stroke="${LN}" stroke-width="2"/>` }
      return o + `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(W)}" height="${f1(H)}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
    }
    if (e.f === 'diag') {
      const x = x0 + 3, y = y0 + 3, S = s - 6, cx = x + S / 2, cy = y + S / 2;
      const P = n === 2 ? [[[x, y], [x + S, y], [x + S, y + S]], [[x, y], [x + S, y + S], [x, y + S]]]
        : [[[x, y], [x + S, y], [cx, cy]], [[x + S, y], [x + S, y + S], [cx, cy]], [[x + S, y + S], [x, y + S], [cx, cy]], [[x, y + S], [x, y], [cx, cy]]];
      P.forEach((p, i) => { o += `<path d="M${p.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L')}Z" fill="${fill(i)}" stroke="${LN}" stroke-width="2" stroke-linejoin="round"/>` });
      return o + `<rect x="${x}" y="${y}" width="${S}" height="${S}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
    }
    if (e.f === 'uch') {
      const h = (s - 6) * .87, A = [x0 + s / 2, y0 + (s - h) / 2], B = [x0 + 3, A[1] + h], Cc = [x0 + s - 3, A[1] + h];
      const m = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], AB = m(A, B), BC = m(B, Cc), AC = m(A, Cc);
      const P = n === 2 ? [[A, B, BC], [A, BC, Cc]] : [[A, AB, AC], [AB, B, BC], [AC, BC, Cc], [AB, BC, AC]];
      P.forEach((p, i) => { o += `<path d="M${p.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L')}Z" fill="${fill(i)}" stroke="${LN}" stroke-width="2" stroke-linejoin="round"/>` });
      return o;
    }
    return '';
  }
  const width = (e, s) => (e.f === 'tort' || e.f === 'plitka') ? s * 1.35 : s;

  V.ext['3DF-ulush'] = (v, V) => {
    const s = v.s || 96, gap = 22, hasLb = v.l.some(e => e.lb); let x = 6, o = '';
    for (const e of v.l) {
      const w = width(e, s); o += one(e, x, 4, s);
      if (e.lb) o += V.T(x + w / 2, s + 20, e.lb, { fs: 17, c: e.lc || V.P.red });
      x += w + gap;
    }
    const W = x - gap + 6;
    return V.svg(f1(W), s + (hasLb ? 36 : 8), o);
  };

  V.ext['3DF-tasma'] = (v, V) => {
    const bars = v.bars, hasLb = bars.some(b => b.lb), L = hasLb ? (v.lw || 58) : 8, W = v.W || 300, bh = 38;
    let y = 6, o = '';
    const brace = (x1, x2, yy, up, txt) => {
      const d = up ? -1 : 1, m = (x1 + x2) / 2;
      let s = `<path d="M${f1(x1)} ${yy}q0 ${7 * d} 8 ${7 * d}H${f1(m - 6)}q6 0 6 ${7 * d}q0 ${-7 * d} 6 ${-7 * d}H${f1(x2 - 8)}q8 0 8 ${-7 * d}" fill="none" stroke="${V.P.red}" stroke-width="2.2"/>`;
      return s + V.T(m, yy + d * 25, txt, { fs: 16, c: V.P.red });
    };
    for (const b of bars) {
      if (b.top) y += 34;
      const on = shadedSet(b), uw = W / b.n;
      for (let i = 0; i < b.n; i++) {
        o += `<rect x="${f1(L + i * uw)}" y="${y}" width="${f1(uw)}" height="${bh}" fill="${b.cols ? b.cols[i] : on.has(i) ? (b.c || SH) : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
        if (b.parts && b.parts[i]) o += V.T(L + (i + .5) * uw, y + bh / 2, b.parts[i], { fs: b.n > 8 ? 13 : 16 });
      }
      o += `<rect x="${L}" y="${y}" width="${W}" height="${bh}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
      if (b.lb) o += V.T(L - 8, y + bh / 2, b.lb, { fs: 16, a: 'end' });
      if (b.top) o += brace(L, L + W, y - 4, true, b.top);
      y += bh;
      if (b.bq) { o += brace(L, L + (b.bqn || 1) * uw, y + 4, false, b.bq); y += 34 }
      y += 10;
    }
    return V.svg(L + W + 8, y, o, L + W + 8);
  };
})();

// 3E (3-sinf matnli masalalar) uchun rasm turlari:
//  '3E-chizma' — Singapur "chizma model" (bar model):
//     {t:'3E-chizma', rows:[{lb:'Anvar', seg:[{n:24, s:'24'}, {n:8, s:'?', dash:true, c:'#..'}], r:'?', top:{a:0,b:1,s:'?'}, bot:{a:0,b:1,s:'45'}}],
//      vbr:{a:0, b:1, s:'Jami: ?'}, cap:'1 bo‘lak = ?', max:..., bw:...}
//     n — bo‘lak uzunligi (masshtab), s — bo‘lak ichidagi yozuv, dash — punktir (farq / noma’lum qism),
//     r — qator oxiridagi yozuv, top/bot — qator ustidagi/ostidagi qavs (a..b bo‘laklar), vbr — o‘ngdagi tik qavs (a..b qatorlar),
//     cap — chizma ostidagi izoh.
//  '3E-yol' — harakat sxemasi (yo‘l):
//     {t:'3E-yol', n:4, a:'Uy', b:'Bog‘', seg:[{s:'60 km', t:'1 soat'}, ...] (n ta teng bo‘lak, yoki seg[i].k — bo‘lak uzunligi),
//      tot:'?', who:'Avtomobil', dir:1|-1 (strelka yo‘nalishi), hl:[bo‘lak indekslari — boshqa rang], mid:[{i:2, lb:'Dam'}]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T;
  const ink = '#1e3a8a', qc = '#b45309';
  const isQ = s => /\?/.test(String(s));
  const tw = (s, fs = 15) => String(s == null ? '' : s).length * fs * 0.6;
  // gorizontal qavs: x1..x2, y — asos, up=true — yuqoriga
  const hbr = (x1, x2, y, up, s) => {
    const d = up ? -1 : 1, m = (x1 + x2) / 2, r = Math.min(8, (x2 - x1) / 4);
    const p = `M${x1} ${y}q0 ${d * 7} ${r} ${d * 7}H${m - 6}q6 0 6 ${d * 7}q0 ${-d * 7} 6 ${-d * 7}H${x2 - r}q${r} 0 ${r} ${-d * 7}`;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + (s != null && s !== '' ? T(m, y + d * 24, s, { fs: 15, c: isQ(s) ? qc : P.ink, st: 1 }) : '');
  };
  // tik qavs: y1..y2, x — asos, o‘ngga qaraydi
  const vbr = (y1, y2, x, s) => {
    const m = (y1 + y2) / 2;
    const p = `M${x} ${y1}q7 0 7 7V${m - 6}q0 6 7 6q-7 0 -7 6V${y2 - 7}q0 7 -7 7`;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + T(x + 20, m, s, { fs: 15, a: 'start', c: isQ(s) ? qc : P.ink });
  };
  const COL = ['#93c5fd', '#fcd34d', '#86efac', '#f9a8d4', '#c4b5fd', '#fdba74'];

  V.ext['3E-chizma'] = (v) => {
    const rows = v.rows, bh = 34;
    const sum = r => r.seg.reduce((a, s) => a + s.n, 0);
    const max = v.max || Math.max(...rows.map(sum));
    const lbw = rows.some(r => r.lb) ? Math.max(...rows.map(r => tw(r.lb) * 1.12)) + 16 : 4;
    const BW = v.bw || 280, k = BW / max;
    let y = 6, o = '', W = 0; const ys = [];
    rows.forEach((r, i) => {
      if (r.top) y += 34;
      let x = lbw; const xs = [x];
      if (r.lb) o += T(lbw - 8, y + bh / 2, r.lb, { fs: 15, a: 'end' });
      r.seg.forEach((s, j) => {
        const w = Math.max(s.n * k, s.s != null && s.s !== '' ? tw(s.s, 12) + 8 : 4), col = s.c || COL[(r.ci != null ? r.ci : i) % COL.length];
        if (s.hl) o += `<rect x="${x - 4}" y="${y - 4}" width="${w + 8}" height="${bh + 8}" rx="7" fill="#fef08a" stroke="#f59e0b" stroke-width="3"/>`; // Ustoz ko‘rsatuvi: shu bo‘lak yonib turadi
        o += s.dash
          ? `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="#fffbeb" stroke="${qc}" stroke-width="2" stroke-dasharray="6 4"/>`
          : `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="${col}" stroke="${ink}" stroke-width="2"/>`;
        if (s.s != null && s.s !== '') {
          const q = isQ(s.s), fs = w >= tw(s.s) + 6 ? 15 : w >= tw(s.s, 12) + 4 ? 12 : 0;
          if (fs) o += T(x + w / 2, y + bh / 2, s.s, { fs, c: q ? qc : P.ink, st: q ? 0 : 1 });
          else o += T(x + w / 2, r.top ? y + bh + 11 : y - 9, s.s, { fs: 12, c: q ? qc : P.ink, st: 1 });
        }
        x += w; xs.push(x);
      });
      if (r.top) o += hbr(xs[r.top.a], xs[r.top.b + 1], y - 3, true, r.top.s);
      if (r.bot) o += hbr(xs[r.bot.a], xs[r.bot.b + 1], y + bh + 3, false, r.bot.s);
      let xe = x;
      if (r.r != null && r.r !== '') { o += T(x + 8, y + bh / 2, r.r, { fs: 15, a: 'start', c: isQ(r.r) ? qc : P.ink }); xe = x + 12 + tw(r.r) }
      if (r.top) xe = Math.max(xe, (xs[r.top.a] + xs[r.top.b + 1]) / 2 + tw(r.top.s) / 2 + 4);
      if (r.bot) xe = Math.max(xe, (xs[r.bot.a] + xs[r.bot.b + 1]) / 2 + tw(r.bot.s) / 2 + 4);
      W = Math.max(W, xe);
      ys.push([y, y + bh, r.r != null && r.r !== '' ? x + 12 + tw(r.r) : x]);
      y += bh + (r.bot ? 36 : 0) + 14;
    });
    if (v.vbr) { // bitta yoki bir nechta tik qavs (massiv bo‘lsa, har biri o‘ngroqda)
      const base = Math.max(...ys.map(q => q[2])) + 10; let xx = base;
      [].concat(v.vbr).forEach(br => { const a = ys[br.a], b = ys[br.b]; o += vbr(a[0], b[1], xx, br.s); W = Math.max(W, xx + 24 + tw(br.s)); xx += 30 + tw(br.s) });
    }
    let H = y - 14 + 6;
    if (v.cap) { o += T(lbw + BW / 2, H + 12, v.cap, { fs: 15, c: isQ(v.cap) ? qc : P.ink }); W = Math.max(W, lbw + BW / 2 + tw(v.cap) / 2); H += 28 }
    return V.svg(W + 4, H, o, Math.min(540, (W + 4) * 1.2));
  };

  // harakat sxemasi
  V.ext['3E-yol'] = (v) => {
    const segs = v.seg, L = 34, BW = 340, tot = segs.reduce((a, s) => a + (s.k || 1), 0), k = BW / tot, y = 62;
    let o = '', x = L; const xs = [x];
    segs.forEach(s => { x += (s.k || 1) * k; xs.push(x) });
    o += `<line x1="${L}" y1="${y}" x2="${L + BW}" y2="${y}" stroke="#cbd5e1" stroke-width="10" stroke-linecap="round"/>`;
    segs.forEach((s, i) => {
      const hl = (v.hl || []).includes(i);
      o += `<line x1="${xs[i] + 2}" y1="${y}" x2="${xs[i + 1] - 2}" y2="${y}" stroke="${s.c || (hl ? '#f59e0b' : P.blue)}" stroke-width="6" stroke-linecap="round"${s.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
      if (s.s != null && s.s !== '') o += hbr(xs[i] + 3, xs[i + 1] - 3, y - 12, true, s.s);
      if (s.t) o += T((xs[i] + xs[i + 1]) / 2, y + 22, s.t, { fs: 13, c: '#475569' });
    });
    xs.forEach((xx, i) => { if (i > 0 && i < xs.length - 1) o += `<line x1="${xx}" y1="${y - 9}" x2="${xx}" y2="${y + 9}" stroke="${P.line}" stroke-width="2"/>` });
    (v.mid || []).forEach(m => { o += `<circle cx="${xs[m.i]}" cy="${y}" r="7" fill="${P.gold}" stroke="#fff" stroke-width="2"/>` + T(xs[m.i], y + 40, m.lb, { fs: 13, c: '#92400e', st: 1 }) });
    o += `<circle cx="${L}" cy="${y}" r="9" fill="${P.green}" stroke="#fff" stroke-width="2.5"/><circle cx="${L + BW}" cy="${y}" r="9" fill="${P.red}" stroke="#fff" stroke-width="2.5"/>`;
    const lbY = segs.some(s => s.t) ? y + 40 : y + 26;
    if (v.a) o += T(L, lbY, v.a, { fs: 14, st: 1, a: 'start' }); if (v.b) o += T(L + BW, lbY, v.b, { fs: 14, st: 1, a: 'end' });
    // harakatlanuvchi va strelka
    if (v.who) {
      const d = v.dir === -1 ? -1 : 1, x0 = d === 1 ? L : L + BW;
      o += `<path d="M${x0 + d * 4} ${y - 52}h${d * 40}" stroke="${P.red}" stroke-width="3"/><path d="M${x0 + d * 50} ${y - 52}l${-d * 10} -6v12z" fill="${P.red}"/>`;
      o += T(x0 + d * 58, y - 52, v.who, { fs: 14, a: d === 1 ? 'start' : 'end', c: P.red, st: 1 });
    }
    let H = lbY + 14;
    if (v.tot) { o += hbr(L, L + BW, H, false, v.tot); H += 40 }
    return V.svg(L * 2 + BW, H, o, 460);
  };
})();

// '3E-karta' — masala shartlari kartochkalarda: {t:'3E-karta', l:['1-gap', '2-gap', ...], q:'Savol?'}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['3E-karta'] = (v) => {
    const card = (n, s, last) => `<div style="display:flex;gap:8px;align-items:flex-start;text-align:left;margin:6px 0;padding:8px 10px;border-radius:12px;border:2px solid ${last ? '#f5b301' : '#93c5fd'};background:${last ? '#fff7d6' : '#eff6ff'};font:800 16px/1.35 Nunito,system-ui,sans-serif;color:#0b2a6f">`
      + `<b style="flex:0 0 26px;height:26px;border-radius:50%;display:grid;place-items:center;background:${last ? '#f5b301' : '#2563eb'};color:#fff;font-size:14px">${n}</b><span>${V.esc(s)}</span></div>`;
    return `<div style="max-width:520px;margin:6px auto">${v.l.map((s, i) => card(i + 1, s)).join('')}${v.q ? card('?', v.q, true) : ''}</div>`;
  };
})();

// 3G guruhi (3-sinf: kattaliklar) uchun qo‘shimcha rasm turlari. Turlar nomi '3G-' bilan boshlanadi.
//  '3G-mm'      — millimetrli chizg‘ich: {t:'3G-mm', n:8 (sm), seg:[a_mm, b_mm], lb:'?'}  (kesma mm larda beriladi)
//  '3G-idish'   — o‘lchov idishlari (litr shkalasi): {t:'3G-idish', l:[{max:10, val:7, step:1, lb:'A', show:true}]}
//                 show:false — suv sathi yozuvsiz. step — shkala bo‘limi (l).
//  '3G-shkala'  — strelkali (siferblatli) tarozi: {t:'3G-shkala', max:5 (kg), div:10 (1 kg dagi bo‘lim), val:2300 (g), lb:'?'}
//  '3G-raqamli' — elektron soat(lar): {t:'3G-raqamli', l:['08:45','10:20'], lb:['Boshlandi','Tugadi']}
//  '3G-yol'     — yo‘l sxemasi: {t:'3G-yol', p:['uy','maktab'], d:['650 m'], w:[650], tot:'?'}
//  '3G-tarozi'  — muvozanatdagi tarozi: {t:'3G-tarozi', l:[{img:'qovun',n:1},{s:'1 kg'}], r:[{s:'5 kg'}]}
//  '3G-quti'    — o‘lchamlari yozilgan quti (parallelepiped): {t:'3G-quti', a:'5 sm', b:'3 sm', c:'2 sm'} (a — eni, b — chuqurligi, c — balandligi)
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P;

  V.ext['3G-mm'] = (v, V) => {
    const n = v.n, u = Math.min(56, 520 / n), L = 16, W = L * 2 + n * u, y0 = 44; let o = `<rect x="4" y="${y0}" width="${W - 8}" height="58" rx="8" fill="#fde68a" stroke="#d97706" stroke-width="2"/>`;
    for (let i = 0; i <= n * 10; i++) {
      const x = L + i * u / 10, big = i % 10 === 0, mid = i % 5 === 0;
      o += `<line x1="${x}" y1="${y0}" x2="${x}" y2="${y0 + (big ? 24 : mid ? 18 : 12)}" stroke="#78350f" stroke-width="${big ? 2.4 : 1.3}"/>`;
      if (big) o += V.T(x, y0 + 38, i / 10, { fs: 14, c: '#78350f' });
    }
    if (v.seg) {
      const [a, b] = v.seg, xa = L + a * u / 10, xb = L + b * u / 10;
      o += `<line x1="${xa}" y1="${y0}" x2="${xa}" y2="20" stroke="${P.red}" stroke-width="1.2" stroke-dasharray="3 3"/><line x1="${xb}" y1="${y0}" x2="${xb}" y2="20" stroke="${P.red}" stroke-width="1.2" stroke-dasharray="3 3"/>`;
      o += `<line x1="${xa}" y1="24" x2="${xb}" y2="24" stroke="${P.blue}" stroke-width="6" stroke-linecap="round"/><circle cx="${xa}" cy="24" r="4.5" fill="${P.ink}"/><circle cx="${xb}" cy="24" r="4.5" fill="${P.ink}"/>`;
      if (v.lb) o += V.T((xa + xb) / 2, 9, v.lb, { fs: 17, c: P.red });
    }
    return V.svg(W, 108, o);
  };

  V.ext['3G-idish'] = (v, V) => {
    const l = v.l, cw = 74, gap = 34, H = 170, top = 14; let o = '', x = 30;
    l.forEach((e, i) => {
      const st = e.step || 1, n = Math.round(e.max / st), h = H / n, bottom = top + H, lab = e.lab || (n > 10 ? 2 : 1);
      const fh = e.val / e.max * H;
      o += `<rect x="${x}" y="${bottom - fh}" width="${cw}" height="${fh}" fill="#93c5fdcc"/>`;
      o += `<path d="M${x} ${top - 8}V${bottom}H${x + cw}V${top - 8}" fill="none" stroke="#1e3a8a" stroke-width="3" stroke-linejoin="round"/>`;
      for (let k = 1; k <= n; k++) {
        const y = bottom - k * h, big = k % lab === 0;
        o += `<line x1="${x}" y1="${y}" x2="${x + (big ? 16 : 9)}" y2="${y}" stroke="#1e3a8a" stroke-width="${big ? 2 : 1.2}"/>`;
        if (big) o += V.T(x - 6, y, k * st, { fs: 12, a: 'end' });
      }
      o += V.T(x - 6, bottom + 2, '0', { fs: 12, a: 'end' }) + V.T(x + cw / 2, top - 2, 'l', { fs: 13, c: '#475569' });
      if (e.lb) o += V.T(x + cw / 2, bottom + 18, e.lb, { fs: 15, c: P.red });
      x += cw + gap + 26;
    });
    return V.svg(x - gap - 10, top + H + (l.some(e => e.lb) ? 32 : 10), o, Math.min(420, (x - gap) * 1.25));
  };

  V.ext['3G-shkala'] = (v, V) => {
    const cx = 150, cy = 150, R = 98, max = v.max, div = v.div || 10, n = max * div; let o = '';
    o += `<rect x="30" y="${cy + 12}" width="240" height="44" rx="12" fill="#64748b"/><rect x="50" y="0" width="200" height="10" rx="5" fill="#94a3b8"/>`;
    o += `<path d="M${cx - R - 36} ${cy + 6}A${R + 36} ${R + 36} 0 0 1 ${cx + R + 36} ${cy + 6}Z" fill="#f8fafc" stroke="#1e3a8a" stroke-width="3"/>`;
    for (let k = 0; k <= n; k++) {
      const a = Math.PI - k / n * Math.PI, big = k % div === 0, mid = div % 2 === 0 && k % (div / 2) === 0, r1 = R - (big ? 16 : mid ? 11 : 7);
      o += `<line x1="${cx + R * Math.cos(a)}" y1="${cy - R * Math.sin(a)}" x2="${cx + r1 * Math.cos(a)}" y2="${cy - r1 * Math.sin(a)}" stroke="#1e3a8a" stroke-width="${big ? 2.6 : 1.3}"/>`;
      if (big) o += V.T(cx + (R + 17) * Math.cos(a), cy - (R + 17) * Math.sin(a) - (k === 0 || k === n ? 8 : 0), k / div, { fs: 18 });
    }
    o += V.T(cx, cy - 34, 'kg', { fs: 15, c: '#475569' });
    const a = Math.PI - v.val / (max * 1000) * Math.PI;
    o += `<line x1="${cx}" y1="${cy}" x2="${cx + (R - 4) * Math.cos(a)}" y2="${cy - (R - 4) * Math.sin(a)}" stroke="${P.red}" stroke-width="4" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="8" fill="${P.ink}"/>`;
    if (v.lb) o += V.T(cx, cy + 34, v.lb, { fs: 18, c: '#fff' });
    return V.svg(300, cy + 60, o, 320);
  };

  V.ext['3G-raqamli'] = (v, V) => {
    const w = 150, g = 18; let o = '';
    v.l.forEach((s, i) => {
      const x = i * (w + g);
      o += `<rect x="${x + 2}" y="2" width="${w}" height="62" rx="12" fill="#0f172a" stroke="#475569" stroke-width="3"/><rect x="${x + 10}" y="10" width="${w - 16}" height="46" rx="6" fill="#052e16"/>`;
      o += `<text x="${x + 2 + w / 2}" y="34" font-size="34" font-weight="700" fill="${s.includes('?') ? '#fbbf24' : '#4ade80'}" text-anchor="middle" dominant-baseline="central" font-family="'Courier New',monospace">${V.esc(s)}</text>`;
      if (v.lb) o += V.T(x + 2 + w / 2, 82, v.lb[i], { fs: 15 });
    });
    const W = v.l.length * (w + g) - g + 4;
    return V.svg(W, v.lb ? 96 : 68, o, Math.min(W, 360));
  };

  V.ext['3G-quti'] = (v, V) => {
    const w = 150, h = 90, d = 50, x = 76, y = 64; let o = '';
    o += `<path d="M${x} ${y}h${w}v${h}h${-w}z" fill="#93c5fd" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
    o += `<path d="M${x} ${y}l${d} ${-d * .8}h${w}l${-d} ${d * .8}z" fill="#dbeafe" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
    o += `<path d="M${x + w} ${y}l${d} ${-d * .8}v${h}l${-d} ${d * .8}z" fill="#60a5fa" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
    if (v.a) o += V.T(x + w / 2, y + h + 17, v.a, { fs: 18 });
    if (v.b) o += V.T(x + w + d / 2 + 18, y + h - d * .4 + 8, v.b, { fs: 18, a: 'start' });
    if (v.c) o += V.T(x - 8, y + h / 2, v.c, { fs: 18, a: 'end' });
    return V.svg(x + w + d + 90, y + h + 30, o, 320);
  };
  // --- yo‘l sxemasi: {t:'3G-yol', p:['uy','maktab','bog‘'], d:['650 m','?'], w:[650,540] (nisbat, ixtiyoriy), tot:'?' (pastda umumiy qavs)}
  V.ext['3G-yol'] = (v, V) => {
    const W = 420, L = 44, Rr = W - 44, n = v.p.length - 1, w = v.w || v.p.slice(1).map(() => 1), S = w.reduce((a, b) => a + b, 0); let o = '', x = L; const xs = [L];
    w.forEach(k => { x += (Rr - L) * k / S; xs.push(x) });
    for (let i = 0; i < n; i++) {
      o += `<line x1="${xs[i]}" y1="40" x2="${xs[i + 1]}" y2="40" stroke="${P.fills[i % 7]}" stroke-width="6" stroke-linecap="round"/>`;
      const q = v.d[i] === '?';
      o += V.T((xs[i] + xs[i + 1]) / 2, 64, v.d[i], { fs: q ? 20 : 17, c: q ? '#b45309' : P.ink });
    }
    xs.forEach((x, i) => { o += `<circle cx="${x}" cy="40" r="7" fill="${P.ink}" stroke="#fff" stroke-width="2"/>` + V.T(x, 15, v.p[i], { fs: 17, c: P.red }) });
    let H = 76;
    if (v.tot) { o += `<path d="M${L} 80v8H${Rr}v-8" fill="none" stroke="${P.ink}" stroke-width="2"/>` + V.T((L + Rr) / 2, 104, v.tot, { fs: 19, c: v.tot === '?' ? '#b45309' : P.ink }); H = 116 }
    return V.svg(W, H, o);
  };
  // --- muvozanatdagi tarozi (katta narsalar va yozuvli toshlar): {t:'3G-tarozi', l:[{img,n}|{s:'2 kg'}], r:[...]}
  V.ext['3G-tarozi'] = (v, V) => {
    const panY = 150, maxW = 150;
    const side = (list, cx) => {
      const el = []; list.forEach(e => { if (e.s) el.push({ s: e.s }); else for (let i = 0; i < e.n; i++) el.push({ img: e.img }) });
      const nImg = el.filter(e => e.img).length, sz = nImg <= 1 ? 62 : nImg <= 2 ? 52 : nImg <= 4 ? 40 : 32;
      el.forEach(e => { e.w = e.img ? sz : 54; e.h = e.img ? sz : 34 });
      const rows = [[]]; let x = 0; el.forEach(e => { if (x + e.w > maxW && rows[rows.length - 1].length) { rows.push([]); x = 0 } rows[rows.length - 1].push(e); x += e.w + 2 });
      let o = `<line x1="${cx}" y1="44" x2="${cx - 70}" y2="${panY}" stroke="#64748b" stroke-width="2"/><line x1="${cx}" y1="44" x2="${cx + 70}" y2="${panY}" stroke="#64748b" stroke-width="2"/>`;
      let y = panY;
      rows.forEach(r => { const rw = r.reduce((a, e) => a + e.w + 2, -2), rh = Math.max(...r.map(e => e.h)); let xx = cx - rw / 2;
        r.forEach(e => { const yy = y - e.h; if (e.img) o += V.im(e.img, xx, yy, e.w); else o += `<path d="M${xx + 8} ${yy}h${e.w - 16}l8 ${e.h}h${-e.w}z" fill="#475569" stroke="#1e293b" stroke-width="1.5"/>` + V.T(xx + e.w / 2, yy + e.h / 2 + 1, e.s, { fs: 14, c: '#fff' }); xx += e.w + 2 });
        y -= rh + 2 });
      o += `<path d="M${cx - 80} ${panY}h160a80 16 0 0 1 -160 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>`;
      return { o, top: y };
    };
    const L = side(v.l, 95), R = side(v.r, 325), top = Math.min(L.top, R.top, 30) - 6;
    let o = `<path d="M180 ${panY + 66}h60l-12 -14h-36z" fill="#64748b"/><rect x="204" y="40" width="12" height="${panY + 14 - 40}" rx="4" fill="#94a3b8"/><rect x="85" y="36" width="250" height="10" rx="5" fill="#475569"/><path d="M210 30l-8 10h16z" fill="#ef4444"/>`;
    o += L.o + R.o;
    return `<svg class="vs" viewBox="0 ${top} 420 ${panY + 70 - top}" style="width:100%;max-width:420px" xmlns="http://www.w3.org/2000/svg" font-family="Nunito,system-ui,sans-serif">${o}</svg>`;
  };
})();

// 3H (3-sinf geometriya) uchun qo‘shimcha rasm turi.
// '3H-jism' — fazoviy shakllar qatori, har birining tagida yozuv: {t:'3H-jism', l:[{s:'kub'|'par'|'shar'|'silindr'|'konus'|'piramida', lb:'A'}], h:70, maxW:430}
//   Har shakl vis.js dagi 'solid' chizmasidan olinadi va bitta SVG ichiga kichraytirib joylanadi; sig‘masa keyingi qatorga o‘tadi.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  V.ext['3H-jism'] = (v, V) => {
    const H = v.h || 70, gap = 14, maxW = v.maxW || 430, hasLb = v.l.some(e => e.lb), rowH = H + (hasLb ? 28 : 6);
    let x = 4, y = 2, o = '', W = 0;
    for (const e of v.l) {
      const s = V.render({ t: 'solid', s: e.s });
      const vb = s.match(/viewBox="0 0 ([\d.]+) ([\d.]+)"/); const w0 = +vb[1], h0 = +vb[2];
      const inner = s.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '');
      const k = H / h0, w = w0 * k;
      if (x > 4 && x + w > maxW) { x = 4; y += rowH + 4 }
      o += `<g transform="translate(${x.toFixed(1)} ${y}) scale(${k.toFixed(4)})">${inner}</g>`;
      if (e.lb) o += V.T(x + w / 2, y + H + 14, e.lb, { fs: 16, c: e.c || V.P.red });
      x += w + gap; W = Math.max(W, x - gap + 4);
    }
    return V.svg(W, y + rowH, o);
  };
})();

// 3H (Geometriya) va 3I (Ma’lumotlar) uchun qo‘shimcha rasm turlari. Turlar nomi '3HI-' bilan boshlanadi.
//  '3HI-koord' — koordinata burchagi (o‘qlari raqamlangan katakli chizma)
//  '3HI-yoy'   — kub/parallelepiped yoyilmalari (to‘g‘ri to‘rtburchaklar)
//  '3HI-quti'  — o‘lchamlari yozilgan parallelepiped/kub (ixtiyoriy: birlik kubchalarga bo‘lingan)
//  '3HI-chop'  — cho‘plar (tally) jadvali
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg;

  // --- koordinata burchagi: {w,h,u, pts:[{x,y,lb,c}], polys:[{pts:[[x,y]],fill,c}], segs:[{a,b,c,dash}], cells:[{x,y,fill}], vax:k (simmetriya o‘qi x=k), hax:k}
  V.ext['3HI-koord'] = v => {
    const w = v.w, h = v.h, u = v.u || Math.min(34, Math.floor(330 / (w + 1))), L = 34, Tp = 22, R = 24, B = 30;
    const X = x => L + x * u, Y = y => Tp + (h - y) * u, W = L + w * u + R, H = Tp + h * u + B; let o = '';
    (v.cells || []).forEach(c => o += `<rect x="${X(c.x) + 1}" y="${Y(c.y + 1) + 1}" width="${u - 2}" height="${u - 2}" rx="3" fill="${c.fill || '#93c5fd'}"/>`);
    for (let i = 0; i <= w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#bfdbfe" stroke-width="1"/>`;
    for (let j = 0; j <= h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#bfdbfe" stroke-width="1"/>`;
    o += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(w) + 16}" y2="${Y(0)}" stroke="${P.line}" stroke-width="2.5"/><path d="M${X(w) + 18} ${Y(0)}l-10 -5v10z" fill="${P.line}"/>`;
    o += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(0)}" y2="${Y(h) - 14}" stroke="${P.line}" stroke-width="2.5"/><path d="M${X(0)} ${Y(h) - 16}l-5 10h10z" fill="${P.line}"/>`;
    const fs = u < 26 ? 12 : 14;
    for (let i = 1; i <= w; i++) o += T(X(i), Y(0) + 14, i, { fs });
    for (let j = 1; j <= h; j++) o += T(X(0) - 9, Y(j), j, { fs, a: 'end' });
    o += T(X(0) - 9, Y(0) + 12, '0', { fs, a: 'end' });
    if (v.vax != null) o += `<line x1="${X(v.vax)}" y1="${Y(0) + 4}" x2="${X(v.vax)}" y2="${Y(h) - 4}" stroke="${P.red}" stroke-width="3" stroke-dasharray="8 6"/>`;
    if (v.hax != null) o += `<line x1="${X(0) - 4}" y1="${Y(v.hax)}" x2="${X(w) + 4}" y2="${Y(v.hax)}" stroke="${P.red}" stroke-width="3" stroke-dasharray="8 6"/>`;
    (v.polys || []).forEach(p => o += `<polygon points="${p.pts.map(q => X(q[0]) + ',' + Y(q[1])).join(' ')}" fill="${p.fill || '#bfdbfe99'}" stroke="${p.c || P.blue}" stroke-width="3" stroke-linejoin="round"/>`);
    (v.segs || []).forEach(s => o += `<line x1="${X(s.a[0])}" y1="${Y(s.a[1])}" x2="${X(s.b[0])}" y2="${Y(s.b[1])}" stroke="${s.c || P.blue}" stroke-width="3"${s.dash ? ' stroke-dasharray="6 5"' : ''}/>`);
    (v.pts || []).forEach(p => { o += `<circle cx="${X(p.x)}" cy="${Y(p.y)}" r="5.5" fill="${p.c || P.red}" stroke="#fff" stroke-width="1.5"/>`; if (p.lb) o += T(X(p.x) + 11, Y(p.y) - 12, p.lb, { fs: 15, c: p.c || P.red, st: 1 }) });
    return svg(W, H, o, Math.min(380, W * 1.15));
  };

  // --- paletka: shakl ustiga shaffof katakli varaq qo‘yilgan. {w,h,u, polys:[{pts,fill}], txt:[[x,y,matn]]} (y pastga)
  V.ext['3HI-pal'] = v => {
    const u = v.u || Math.min(30, Math.floor(320 / v.w)), pd = 10, X = x => pd + x * u, W = v.w * u + pd * 2, H = v.h * u + pd * 2; let o = '';
    const pp = p => p.pts.map(q => X(q[0]) + ',' + X(q[1])).join(' ');
    (v.polys || []).forEach((p, i) => o += `<polygon points="${pp(p)}" fill="${p.fill || ['#fde047', '#86efac', '#f9a8d4'][i % 3]}" stroke="none"/>`);
    o += `<rect x="${pd}" y="${pd}" width="${v.w * u}" height="${v.h * u}" fill="#e0f2fe55" stroke="#38bdf8" stroke-width="2" rx="3"/>`;
    for (let i = 1; i < v.w; i++) o += `<line x1="${X(i)}" y1="${pd}" x2="${X(i)}" y2="${H - pd}" stroke="#0284c7" stroke-width="1.3" opacity=".75"/>`;
    for (let j = 1; j < v.h; j++) o += `<line x1="${pd}" y1="${X(j)}" x2="${W - pd}" y2="${X(j)}" stroke="#0284c7" stroke-width="1.3" opacity=".75"/>`;
    (v.polys || []).forEach(p => o += `<polygon points="${pp(p)}" fill="none" stroke="#9a3412" stroke-width="2.5" stroke-linejoin="round"/>`);
    (v.txt || []).forEach(t => o += T(X(t[0]), X(t[1]), t[2], { fs: 17, c: P.red, st: 1 }));
    return svg(W, H, o, Math.min(360, W * 1.15));
  };

  // --- yoyilmalar: {u, nets:[{r:[[x,y,w,h,lab,fill]], t:[[x,y,matn]], name}]} (birlik — katak)
  V.ext['3HI-yoy'] = v => {
    const many = v.nets.length > 1, gap = 24; const sizes = v.nets.map(n => [Math.max(...n.r.map(r => r[0] + r[2])), Math.max(...n.r.map(r => r[1] + r[3]))]);
    const u = v.u || (many ? Math.min(24, Math.floor(150 / Math.max(...sizes.map(s => s[0])))) : Math.min(44, Math.floor(320 / sizes[0][0])));
    const maxW = v.maxW || 340; let o = '', x = 0, y = 0, rowH = 0, W = 0;
    v.nets.forEach((n, i) => {
      const [mx, my] = sizes[i], w = mx * u + 4, h = my * u + 4 + (n.name ? 24 : 0);
      if (x && x + w > maxW) { x = 0; y += rowH + gap; rowH = 0 }
      n.r.forEach(r => {
        const [rx, ry, rw, rh, lab, f] = r, cx = x + rx * u + 2, cy = y + ry * u + 2;
        o += `<rect x="${cx}" y="${cy}" width="${rw * u}" height="${rh * u}" fill="${f || '#dbeafe'}" stroke="#1e3a8a" stroke-width="2"/>`;
        if (lab != null && lab !== '') o += T(cx + rw * u / 2, cy + rh * u / 2 + 1, lab, { fs: Math.min(Math.max(u * .5, 13), 16), c: lab === '?' ? '#b45309' : P.ink });
      });
      (n.t || []).forEach(t => o += T(x + t[0] * u + 2, y + t[1] * u + 2, t[2], { fs: 13, c: P.red, st: 1 }));
      if (n.name) o += T(x + w / 2, y + my * u + 18, n.name, { fs: 17, c: P.red });
      x += w + gap; rowH = Math.max(rowH, h); W = Math.max(W, x - gap);
    });
    return svg(W + 4, y + rowH + 4, o, Math.min(380, (W + 4) * 1.1));
  };

  // --- parallelepiped: {a (eni), b (chuqurligi), c (balandligi), la, lb, lc, grid:true (birlik kubchalarga bo‘lingan), hid:true (ko‘rinmas qirralar)}
  V.ext['3HI-quti'] = v => {
    const a = v.a, b = v.b, c = v.c, s = v.s || Math.min(38, Math.floor(230 / (a + b * .6)), Math.floor(170 / (c + b * .45)));
    const ddx = s * .6, ddy = -s * .45, ox = v.lc ? 62 : 24, oy = 20 + b * -ddy + c * s;
    const F = (i, k, j) => [ox + i * s + k * ddx, oy - j * s + k * ddy]; // i — eni, k — chuqurlik, j — balandlik
    const pt = p => p[0].toFixed(1) + ' ' + p[1].toFixed(1); let o = '';
    const face = (pts, fill) => `<path d="M${pts.map(pt).join('L')}z" fill="${fill}" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
    o += face([F(0, 0, 0), F(a, 0, 0), F(a, 0, c), F(0, 0, c)], v.f1 || '#93c5fd');
    o += face([F(0, 0, c), F(a, 0, c), F(a, b, c), F(0, b, c)], v.f2 || '#dbeafe');
    o += face([F(a, 0, 0), F(a, b, 0), F(a, b, c), F(a, 0, c)], v.f3 || '#60a5fa');
    const ln = (p, q) => `<line x1="${p[0].toFixed(1)}" y1="${p[1].toFixed(1)}" x2="${q[0].toFixed(1)}" y2="${q[1].toFixed(1)}" stroke="#1e3a8a" stroke-width="1.2" opacity=".7"/>`;
    if (v.grid) {
      for (let i = 1; i < a; i++) { o += ln(F(i, 0, 0), F(i, 0, c)); o += ln(F(i, 0, c), F(i, b, c)) }
      for (let j = 1; j < c; j++) { o += ln(F(0, 0, j), F(a, 0, j)); o += ln(F(a, 0, j), F(a, b, j)) }
      for (let k = 1; k < b; k++) { o += ln(F(0, k, c), F(a, k, c)); o += ln(F(a, k, 0), F(a, k, c)) }
    }
    if (v.hid) { const H0 = F(0, b, 0); [F(a, b, 0), F(0, 0, 0), F(0, b, c)].forEach(q => o += `<line x1="${H0[0]}" y1="${H0[1]}" x2="${q[0]}" y2="${q[1]}" stroke="#1e3a8a" stroke-width="1.8" stroke-dasharray="6 5"/>`) }
    if (v.la) { const p = F(a / 2, 0, 0); o += T(p[0], p[1] + 15, v.la, { fs: 15, c: P.red, st: 1 }) }
    if (v.lc) { const p = F(0, 0, c / 2); o += T(p[0] - 6, p[1], v.lc, { fs: 15, c: P.red, st: 1, a: 'end' }) }
    if (v.lb) { const p = F(a, b / 2, 0); o += T(p[0] + 8, p[1] + 8, v.lb, { fs: 15, c: P.red, st: 1, a: 'start' }) }
    (v.vl || []).forEach(q => { const p = F(q[0], q[1], q[2]); o += `<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="${P.ink}"/>` + T(p[0] + (q[4] || 0), p[1] + (q[5] || -12), q[3], { fs: 14, c: P.red, st: 1 }) });
    const W = ox + a * s + b * ddx + 70, H = oy + 26;
    return svg(W, H, o, Math.min(340, W * 1.2));
  };

  // --- cho‘plar jadvali: {h:['Meva','Cho‘plar'], rows:[[nomi, son]], num:true (son ustuni ham)}
  V.ext['3HI-chop'] = v => {
    const rh = 40, lw = 118, mw = 9, gw = 5 * mw + 12; const maxN = Math.max(...v.rows.map(r => r[1]), 5);
    const tw = Math.max(150, Math.ceil(maxN / 5) * gw + 16), nw = v.num ? 56 : 0, W = lw + tw + nw, H = rh * (v.rows.length + 1); let o = '';
    o += `<rect x="1" y="1" width="${W - 2}" height="${H - 2}" rx="12" fill="#fff" stroke="#93c5fd" stroke-width="2"/><path d="M2 ${rh}H${W - 2}" stroke="#93c5fd" stroke-width="2"/>`;
    o += `<rect x="2" y="2" width="${W - 4}" height="${rh - 3}" rx="10" fill="#dbeafe"/>`;
    o += T(lw / 2, rh / 2 + 1, v.h[0], { fs: 15 }) + T(lw + tw / 2, rh / 2 + 1, v.h[1], { fs: 15 }); if (v.num) o += T(lw + tw + nw / 2, rh / 2 + 1, v.h[2] || 'Soni', { fs: 15 });
    o += `<path d="M${lw} 2V${H - 2}" stroke="#93c5fd" stroke-width="2"/>` + (v.num ? `<path d="M${lw + tw} 2V${H - 2}" stroke="#93c5fd" stroke-width="2"/>` : '');
    v.rows.forEach((r, i) => {
      const y = rh * (i + 1); if (i) o += `<path d="M2 ${y}H${W - 2}" stroke="#dbeafe" stroke-width="1.5"/>`;
      o += T(lw / 2, y + rh / 2 + 1, r[0], { fs: 15 });
      const n = r[1];
      for (let g = 0; g * 5 < n; g++) {
        const k = Math.min(5, n - g * 5), x0 = lw + 12 + g * gw;
        for (let m = 0; m < Math.min(k, 4); m++) o += `<line x1="${x0 + m * mw + 3}" y1="${y + 9}" x2="${x0 + m * mw + 3}" y2="${y + rh - 9}" stroke="${P.ink}" stroke-width="2.6" stroke-linecap="round"/>`;
        if (k === 5) o += `<line x1="${x0 - 3}" y1="${y + rh - 12}" x2="${x0 + 3 * mw + 9}" y2="${y + 12}" stroke="${P.red}" stroke-width="2.6" stroke-linecap="round"/>`;
      }
      if (v.num) o += T(lw + tw + nw / 2, y + rh / 2 + 1, r[2] == null ? '' : r[2], { fs: 16, c: r[2] === '?' ? '#b45309' : P.ink });
    });
    return svg(W, H, o, Math.min(380, W * 1.1));
  };
})();

// 3J (3-sinf, Mantiq va olimpiada) uchun qo‘shimcha rasm turlari. Turlar nomi '3J-' bilan boshlanadi.
//  '3J-venn'  — Eyler–Venn doiralari: {sets:['Futbol','Shaxmat'(,'Suzish')], n:{a,b,ab,o} yoki {a,b,c,ab,ac,bc,abc,o}, U:'Sinf'}
//  '3J-pir'   — sonli piramida (g‘ishtlar): {rows:[[pastki qator...],[...],...,[cho‘qqi]]} ('?' — so‘roq)
//  '3J-kross' — sonli krossvord: {cells:[['', '', null], ...] (null — qora katak), nums:[[r,c,'1'],...]}
//  '3J-mat'   — 3×3 mantiqiy jadval (Raven): {cells:[[{s,c,n,rot},...],...] ('?' — so‘roq), opts:[{...}] (A–D variantlar)}
//  '3J-ustun' — ustunlar/daraxtlar qatori: {n, img, gap:'5 m', len:'...', rect:[a,b]} (rect — to‘g‘ri to‘rtburchak atrofida)
//  '3J-xoda'  — xoda/lenta: {cuts:[0.3,..] (0..1), marks:[{x,c}], lb, rope:true}
//  '3J-model' — chizma model (yoshlar): {rows:[{lb, parts:[{w, s, c}], tail}]}
//  '3J-reja'  — kublar qurilmasining ustidan rejasi: {cells:[[2,1],[0,3]], front:true}
//  '3J-qator' — shakllar qatori (rang, burilgan strelka, nuqtali shakllar): {l:[{s,c,n,rot,lb}], s}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg, esc = V.esc;
  const Q = '#fff7d6', QS = '#f5b301', QT = '#b45309';

  // --- Venn
  V.ext['3J-venn'] = v => {
    const n = v.n, three = v.sets.length === 3; let o = '';
    const W = 380, H = three ? 330 : 230;
    o += `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="16" fill="#f8fafc" stroke="#94a3b8" stroke-width="2"/>`;
    if (v.U) o += T(14, 20, v.U, { fs: 14, a: 'start', c: '#475569' });
    const val = (x, y, s) => s == null ? '' : (s === '?' ? `<rect x="${x - 17}" y="${y - 14}" width="34" height="28" rx="7" fill="${Q}" stroke="${QS}" stroke-width="2"/>` + T(x, y, '?', { fs: 18, c: QT }) : T(x, y, s, { fs: 19, st: 1 }));
    if (!three) {
      o += `<circle cx="140" cy="125" r="85" fill="#93c5fd55" stroke="${P.blue}" stroke-width="3"/><circle cx="240" cy="125" r="85" fill="#fcd34d55" stroke="#d97706" stroke-width="3"/>`;
      o += T(110, 50, v.sets[0], { fs: 15, c: P.blue, st: 1 }) + T(270, 50, v.sets[1], { fs: 15, c: '#b45309', st: 1 });
      o += val(100, 128, n.a) + val(190, 128, n.ab) + val(280, 128, n.b) + val(345, 205, n.o);
    } else {
      o += `<circle cx="145" cy="120" r="82" fill="#93c5fd55" stroke="${P.blue}" stroke-width="3"/><circle cx="235" cy="120" r="82" fill="#fcd34d55" stroke="#d97706" stroke-width="3"/><circle cx="190" cy="200" r="82" fill="#86efac55" stroke="${P.green}" stroke-width="3"/>`;
      o += T(95, 40, v.sets[0], { fs: 15, c: P.blue, st: 1 }) + T(285, 40, v.sets[1], { fs: 15, c: '#b45309', st: 1 }) + T(190, 302, v.sets[2], { fs: 15, c: P.green, st: 1 });
      o += val(110, 100, n.a) + val(270, 100, n.b) + val(190, 240, n.c) + val(190, 88, n.ab) + val(140, 175, n.ac) + val(240, 175, n.bc) + val(190, 148, n.abc) + val(345, 305, n.o);
    }
    return svg(W, H, o, 380);
  };

  // --- piramida
  V.ext['3J-pir'] = v => {
    const R = v.rows, n = R[0].length, bw = v.bw || 64, bh = 40; let o = '';
    R.forEach((row, L) => row.forEach((s, j) => {
      const x = 2 + L * bw / 2 + j * bw, y = 2 + (n - 1 - L) * bh, q = s === '?';
      o += `<rect x="${x + 1}" y="${y + 1}" width="${bw - 2}" height="${bh - 2}" rx="5" fill="${q ? Q : (L % 2 ? '#fde68a' : '#fed7aa')}" stroke="${q ? QS : '#b45309'}" stroke-width="2"/>`;
      if (s !== '') o += T(x + bw / 2, y + bh / 2 + 1, s, { fs: 18, c: q ? QT : P.ink });
    }));
    return svg(n * bw + 4, n * bh + 4, o, Math.min(380, n * bw * 1.1));
  };

  // --- krossvord
  V.ext['3J-kross'] = v => {
    const u = v.u || 52, C = v.cells, h = C.length, w = C[0].length; let o = '';
    C.forEach((r, i) => r.forEach((s, j) => {
      const x = 2 + j * u, y = 2 + i * u;
      if (s === null) { o += `<rect x="${x}" y="${y}" width="${u}" height="${u}" fill="#334155" stroke="#1e293b" stroke-width="2"/>`; return }
      const q = s === '?';
      o += `<rect x="${x}" y="${y}" width="${u}" height="${u}" fill="${q ? Q : '#fff'}" stroke="${P.blue}" stroke-width="2.5"/>`;
      if (s !== '') o += T(x + u / 2, y + u / 2 + 3, s, { fs: u * .46, c: q ? QT : P.ink });
    }));
    (v.nums || []).forEach(([i, j, s]) => { o += T(2 + j * u + 4, 2 + i * u + 9, s, { fs: 12, a: 'start', c: P.red }) });
    return svg(w * u + 4, h * u + 4, o, Math.min(360, (w * u + 4) * 1.1));
  };

  // --- shakl chizish (bitta katak ichida): s (shakl nomi yoki 'strelka'), c rang, n soni, rot burilish
  const ARROW = (cx, cy, s, rot, c) => `<g transform="translate(${cx} ${cy}) rotate(${rot || 0})"><path d="M${-s * .38} ${-s * .1}H${s * .08}V${-s * .26}L${s * .4} 0L${s * .08} ${s * .26}V${s * .1}H${-s * .38}z" fill="${c}" stroke="#1e3a8a" stroke-width="2" stroke-linejoin="round"/></g>`;
  const one = (e, x, y, s) => {
    if (e.s === 'strelka') return ARROW(x + s / 2, y + s / 2, s, e.rot, e.c || P.blue);
    if (e.s === 'nuqta') return `<circle cx="${x + s / 2}" cy="${y + s / 2}" r="${s * .28}" fill="${e.c || P.ink}" stroke="#1e3a8a" stroke-width="1.5"/>`;
    if (e.rot) return `<g transform="rotate(${e.rot} ${x + s / 2} ${y + s / 2})">${V.shp(e.s, x, y, s, e.c || P.fills[0])}</g>`;
    return V.shp(e.s, x, y, s, e.c || P.fills[0]);
  };
  const cell = (e, x, y, u) => {
    if (e === '?') return `<rect x="${x + 4}" y="${y + 4}" width="${u - 8}" height="${u - 8}" rx="10" fill="${Q}" stroke="${QS}" stroke-width="2.5" stroke-dasharray="6 4"/>` + T(x + u / 2, y + u / 2, '?', { fs: u * .45, c: QT });
    if (!e) return '';
    const n = e.n || 1;
    if (n === 1) return one(e, x + u * .15, y + u * .15, u * .7);
    const k = n <= 4 ? 2 : 3, s = u * .8 / k; let o = '';
    for (let i = 0; i < n; i++) o += one(e, x + u * .1 + (i % k) * s, y + u * .1 + Math.floor(i / k) * s + (n <= 2 ? s / 2 : 0), s * .95);
    return o;
  };
  V.ext['3J-mat'] = v => {
    const u = v.u || 78, C = v.cells, h = C.length, w = C[0].length; let o = '';
    C.forEach((r, i) => r.forEach((e, j) => { const x = 2 + j * u, y = 2 + i * u; o += `<rect x="${x}" y="${y}" width="${u}" height="${u}" fill="#fff" stroke="${P.blue}" stroke-width="2.5"/>` + cell(e, x, y, u) }));
    let H = h * u + 4, W = w * u + 4;
    if (v.opts) {
      const ou = 70, y0 = H + 16; const ow = v.opts.length * (ou + 12);
      const x0 = Math.max(2, (W - ow) / 2); W = Math.max(W, ow + 4);
      v.opts.forEach((e, k) => { const x = x0 + k * (ou + 12); o += `<rect x="${x}" y="${y0}" width="${ou}" height="${ou}" rx="10" fill="#f8fafc" stroke="#94a3b8" stroke-width="2"/>` + cell(e, x, y0, ou) + T(x + ou / 2, y0 + ou + 14, 'ABDEF'[k], { fs: 16, c: P.red }) });
      H = y0 + ou + 28;
    }
    return svg(W, H, o, Math.min(380, W * 1.05));
  };
  V.ext['3J-qator'] = v => {
    const s = v.s || 50, l = v.l; let o = '';
    l.forEach((e, i) => { const x = 2 + i * (s + 8); o += e === '?' || e.s === '?' ? cell('?', x, 2, s) : (e.n ? cell(e, x, 2, s) : one(e, x + 2, 4, s - 4)); if (e.lb) o += T(x + s / 2, s + 16, e.lb, { fs: 14, c: P.red }) });
    const W = l.length * (s + 8) + 4;
    return svg(W, s + (l.some(e => e.lb) ? 28 : 6), o, Math.min(380, W * 1.1));
  };

  // --- ustunlar / daraxtlar
  V.ext['3J-ustun'] = v => {
    let o = ''; const post = (x, y) => v.img ? V.im(v.img, x - 18, y - 40, 36) : `<rect x="${x - 4}" y="${y - 34}" width="8" height="38" rx="3" fill="#92400e" stroke="#451a03" stroke-width="1.5"/><circle cx="${x}" cy="${y - 36}" r="5" fill="#fbbf24" stroke="#92400e" stroke-width="1.5"/>`;
    if (v.rect) {
      const [a, b] = v.rect, u = Math.min(56, 300 / a, 180 / b), x0 = 30, y0 = 48; o += `<rect x="${x0}" y="${y0}" width="${a * u}" height="${b * u}" fill="#dcfce7" stroke="#16a34a" stroke-width="2.5" stroke-dasharray="7 5"/>`;
      const pts = []; for (let i = 0; i <= a; i++) { pts.push([i, 0]); pts.push([i, b]) } for (let j = 1; j < b; j++) { pts.push([0, j]); pts.push([a, j]) }
      pts.sort((p, q) => p[1] - q[1]).forEach(([i, j]) => { o += post(x0 + i * u, y0 + j * u + 4) });
      if (v.gap) o += T(x0 + u / 2, y0 + b * u + 22, v.gap, { fs: 13, c: P.blue });
      if (v.lbA) o += T(x0 + a * u / 2, y0 + b * u + 40, v.lbA, { fs: 15 }); if (v.lbB) o += T(x0 + a * u + 22, y0 + b * u / 2, v.lbB, { fs: 15, a: 'start' });
      return svg(x0 + a * u + 90, y0 + b * u + 50, o, 380);
    }
    const n = v.n, u = Math.min(64, 330 / Math.max(1, n - 1)), x0 = 24, y = 70, W = x0 * 2 + (n - 1) * u;
    o += `<rect x="0" y="${y}" width="${W}" height="10" rx="4" fill="#d6d3d1"/>`;
    for (let i = 0; i < n; i++) { o += post(x0 + i * u, y + 2); if (v.num) o += T(x0 + i * u, y + 24, i + 1, { fs: 12, c: '#475569' }) }
    if (v.gap) o += `<path d="M${x0} ${y + 38}H${x0 + u}" stroke="${P.blue}" stroke-width="2"/><path d="M${x0} ${y + 33}v10M${x0 + u} ${y + 33}v10" stroke="${P.blue}" stroke-width="2"/>` + T(x0 + u / 2, y + 52, v.gap, { fs: 13, c: P.blue });
    if (v.len) o += T(W / 2, y + 74, v.len, { fs: 15 });
    return svg(W, y + (v.len ? 86 : 64), o, 380);
  };

  // --- xoda / lenta
  V.ext['3J-xoda'] = v => {
    const L = 340, x0 = 16, y0 = 30, h = v.rope ? 12 : 34; let o = '';
    o += v.rope ? `<rect x="${x0}" y="${y0 + 11}" width="${L}" height="${h}" rx="6" fill="#f472b6" stroke="#9d174d" stroke-width="2"/>` : `<rect x="${x0}" y="${y0}" width="${L}" height="${h}" rx="10" fill="#d97706" stroke="#78350f" stroke-width="2.5"/><ellipse cx="${x0 + L}" cy="${y0 + h / 2}" rx="7" ry="${h / 2 - 1}" fill="#fcd34d" stroke="#78350f" stroke-width="2"/>`;
    (v.cuts || []).forEach(t => { const x = x0 + t * L; o += `<path d="M${x} ${y0 - 10}V${y0 + 46}" stroke="${P.red}" stroke-width="3" stroke-dasharray="5 4"/>` });
    (v.marks || []).forEach(m => { const x = x0 + m.x * L; o += `<rect x="${x - 2.5}" y="${y0 - 2}" width="5" height="${38}" fill="${m.c}"/>` });
    if (v.lb) o += T(x0 + L / 2, y0 + 64, v.lb, { fs: 15 });
    return svg(L + 2 * x0 + 4, y0 + (v.lb ? 76 : 52), o, 380);
  };

  // --- chizma model
  V.ext['3J-model'] = v => {
    const LW = 78, u = v.u || 26, rh = 40; let o = '', W = 0;
    v.rows.forEach((r, i) => {
      const y = 4 + i * (rh + 10); let x = LW;
      o += T(LW - 8, y + rh / 2, r.lb, { fs: 15, a: 'end' });
      r.parts.forEach(p => { const w = p.w * u; o += `<rect x="${x}" y="${y}" width="${w}" height="${rh}" rx="4" fill="${p.c || '#93c5fd'}" stroke="#1e3a8a" stroke-width="2"${p.dash ? ' stroke-dasharray="6 4"' : ''}/>`; if (p.s) o += T(x + w / 2, y + rh / 2 + 1, p.s, { fs: 15, c: p.s === '?' ? QT : P.ink }); x += w });
      if (r.tail) o += T(x + 8, y + rh / 2, r.tail, { fs: 15, a: 'start', c: P.red });
      W = Math.max(W, x + (r.tail ? 12 + r.tail.length * 8.5 : 6));
    });
    return svg(W, v.rows.length * (rh + 10) + 4, o, Math.min(380, W * 1.05));
  };

  // --- reja (ustidan ko‘rinish)
  V.ext['3J-reja'] = v => {
    const C = v.cells, h = C.length, w = C[0].length, u = 46, x0 = 30, y0 = 8; let o = '';
    C.forEach((r, i) => r.forEach((s, j) => { const x = x0 + j * u, y = y0 + i * u, e = s === 0 || s === '' ; o += `<rect x="${x}" y="${y}" width="${u}" height="${u}" fill="${e ? '#f8fafc' : '#dbeafe'}" stroke="${P.blue}" stroke-width="2"/>`; if (!e) o += T(x + u / 2, y + u / 2 + 1, s, { fs: 20, c: s === '?' ? QT : P.ink }) }));
    let H = y0 + h * u + 6;
    if (v.front) { o += `<path d="M${x0 + w * u / 2} ${H + 30}V${H + 6}" stroke="${P.green}" stroke-width="4"/><path d="M${x0 + w * u / 2} ${H + 2}l-8 10h16z" fill="${P.green}"/>` + T(x0 + w * u / 2 + 12, H + 26, 'oldi', { fs: 14, a: 'start', c: P.green }); H += 36 }
    if (v.side) { const X = x0 + w * u + 6; o += `<path d="M${X + 32} ${y0 + h * u / 2}H${X + 8}" stroke="#d97706" stroke-width="4"/><path d="M${X + 4} ${y0 + h * u / 2}l10 -8v16z" fill="#d97706"/>` + T(X + 18, y0 + h * u / 2 + 20, 'o‘ng', { fs: 14, c: '#b45309' }) }
    return svg(x0 + w * u + 60, H, o, Math.min(320, (x0 + w * u + 60) * 1.1));
  };

  // --- bir qatorda bir nechta kichik soat: {l:[{h,m}], q:true (oxirida so‘roq)}
  V.ext['3J-soatlar'] = v => {
    const s = 110, g = 10; let o = ''; const n = v.l.length + (v.q ? 1 : 0);
    v.l.forEach((c, i) => {
      const x = i * (s + g), k = s / 200, cx = x + s / 2, cy = s / 2, mA = c.m * 6, hA = (c.h % 12) * 30 + c.m / 2;
      const hand = (nm, a, kk) => `<image href="${V.src(nm)}" x="${cx - 99 * kk * k}" y="${cy - 97 * kk * k}" width="${200 * kk * k}" height="${200 * kk * k}" transform="rotate(${a} ${cx} ${cy})"/>`;
      o += V.im('soat-yuz', x, 0, s) + hand('soat-qisqa', hA, .56) + hand('soat-uzun', mA, .8);
    });
    if (v.q) { const x = v.l.length * (s + g); o += `<circle cx="${x + s / 2}" cy="${s / 2}" r="${s / 2 - 4}" fill="${Q}" stroke="${QS}" stroke-width="3" stroke-dasharray="7 5"/>` + T(x + s / 2, s / 2, '?', { fs: 40, c: QT }) }
    const W = n * (s + g) - g; return svg(W, s, o, Math.min(380, W));
  };
})();

// 3J11–3J20 (3-sinf, Mantiq va olimpiada) uchun qo‘shimcha rasm turlari. Turlar nomi '3J11-' bilan boshlanadi.
// 3J11-lab (xarita/labirint, koordinatali), 3J11-graf (yo‘llar xaritasi), 3J11-blok (blok-sxema), 3J11-figs (katakli shakllar qatori),
// 3J11-seg7 (raqamli soat / ko‘zgu), 3J11-teng (shakl/meva tenglamalari), 3J11-qop (rangli sharlar qutisi),
// 3J11-gap (gapirayotganlar), 3J11-mash (son mashinasi zanjiri), 3J11-kart (raqamli kartochkalar, 180° burish), 3J11-jad (shakllar jadvali, qator/ustun yig‘indilari).
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg, esc = V.esc;
  const LET = 'ABDEFGHIJK'; // o‘zbek alifbosida C yo‘q

  // --- xarita / labirint: {w,h,u, coords:true (ustunlar A,B,..; qatorlar pastdan 1,2,..), open:true | rw:['0101'], bw:['...'],
  //   marks:[{x,y,img|s|fill|lb}], path:[[x,y],...], block:[[x,y]], ent:[{x,y,s:'t'|'b'|'l'|'r',lb}]}
  V.ext['3J11-lab'] = v => {
    const w = v.w, h = v.h, u = v.u || (w > 6 ? 38 : 46), pd = 30, X = i => pd + i * u, Y = j => pd + j * u; let o = '';
    o += `<rect x="${pd}" y="${pd}" width="${w * u}" height="${h * u}" fill="${v.bg || '#f8fbff'}"/>`;
    (v.block || []).forEach(b => o += `<rect x="${X(b[0]) + 1}" y="${Y(b[1]) + 1}" width="${u - 2}" height="${u - 2}" rx="4" fill="#64748b"/>`);
    (v.marks || []).forEach(m => { if (m.fill) o += `<rect x="${X(m.x) + 2}" y="${Y(m.y) + 2}" width="${u - 4}" height="${u - 4}" rx="6" fill="${m.fill}"/>` });
    if (v.open) { for (let i = 1; i < w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#94a3b8" stroke-width="1.5"/>`; for (let j = 1; j < h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#94a3b8" stroke-width="1.5"/>` }
    else if (v.faint) { for (let i = 1; i < w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#e2e8f0" stroke-width="1"/>`; for (let j = 1; j < h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#e2e8f0" stroke-width="1"/>` }
    if (v.path) o += `<polyline points="${v.path.map(p => (X(p[0]) + u / 2) + ',' + (Y(p[1]) + u / 2)).join(' ')}" fill="none" stroke="${P.red}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>`;
    (v.marks || []).forEach(m => {
      const cx = X(m.x) + u / 2, cy = Y(m.y) + u / 2;
      if (m.img) o += V.im(m.img, X(m.x) + u * .12, Y(m.y) + u * .12, u * .76);
      if (m.s != null) o += `<circle cx="${cx}" cy="${cy}" r="${u * .36}" fill="${m.c || '#fde68a'}" stroke="#b45309" stroke-width="2"/>` + T(cx, cy + 1, m.s, { fs: u * (String(m.s).length > 2 ? .3 : .4), c: '#7c2d12' });
      if (m.n != null) o += T(cx, cy + 1, m.n, { fs: u * .42 });
      if (m.lb) o += T(m.img || m.s != null ? X(m.x) + 9 : cx, m.img || m.s != null ? Y(m.y) + 10 : cy + 1, m.lb, { fs: m.img || m.s != null ? 13 : u * .42, c: P.red, st: 1 });
    });
    let walls = '';
    if (!v.open && v.rw) for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      if (i < w - 1 && v.rw[j][i] === '1') walls += `M${X(i + 1)} ${Y(j)}V${Y(j + 1)}`;
      if (j < h - 1 && v.bw[j][i] === '1') walls += `M${X(i)} ${Y(j + 1)}H${X(i + 1)}`;
    }
    const gapAt = (s, k) => (v.ent || []).some(e => e.s === s && (s === 't' || s === 'b' ? e.x : e.y) === k);
    for (let i = 0; i < w; i++) { if (!gapAt('t', i)) walls += `M${X(i)} ${Y(0)}H${X(i + 1)}`; if (!gapAt('b', i)) walls += `M${X(i)} ${Y(h)}H${X(i + 1)}` }
    for (let j = 0; j < h; j++) { if (!gapAt('l', j)) walls += `M${X(0)} ${Y(j)}V${Y(j + 1)}`; if (!gapAt('r', j)) walls += `M${X(w)} ${Y(j)}V${Y(j + 1)}` }
    o += `<path d="${walls}" stroke="#1e3a8a" stroke-width="${v.open ? 3 : 5}" stroke-linecap="round" fill="none"/>`;
    (v.axis || []).forEach(a => { o += a.v != null ? `<line x1="${X(a.v)}" y1="${pd - 12}" x2="${X(a.v)}" y2="${Y(h) + 12}" stroke="${P.red}" stroke-width="3" stroke-dasharray="9 6"/>` : `<line x1="${pd - 12}" y1="${Y(a.h)}" x2="${X(w) + 12}" y2="${Y(a.h)}" stroke="${P.red}" stroke-width="3" stroke-dasharray="9 6"/>` });
    (v.ent || []).forEach(e => {
      const [x, y] = e.s === 't' ? [X(e.x) + u / 2, pd - 14] : e.s === 'b' ? [X(e.x) + u / 2, Y(h) + 15] : e.s === 'l' ? [pd - 15, Y(e.y) + u / 2] : [X(w) + 15, Y(e.y) + u / 2];
      o += T(x, y, e.lb, { fs: 15, c: e.c || P.red, st: 1 });
    });
    if (v.coords) {
      for (let i = 0; i < w; i++) o += T(X(i) + u / 2, Y(h) + 15, LET[i], { fs: 15, c: P.blue });
      for (let j = 0; j < h; j++) o += T(pd - 14, Y(j) + u / 2, h - j, { fs: 15, c: P.blue });
    }
    return svg(w * u + pd * 2, h * u + pd * 2, o, Math.min(390, (w * u + pd * 2) * 1.1));
  };

  // --- yo‘llar xaritasi (graf): {w,h,u, nodes:[{x,y,lb,c}], edges:[{a,b,lb,k (egrilik)}], dir:false}
  V.ext['3J11-graf'] = v => {
    const u = v.u || 80, pd = 28, X = x => pd + x * u, Y = y => pd + y * u, N = v.nodes; let o = '', lab = '';
    v.edges.forEach(e => {
      const A = N[e.a], B = N[e.b], x1 = X(A.x), y1 = Y(A.y), x2 = X(B.x), y2 = Y(B.y), dx = x2 - x1, dy = y2 - y1, d = Math.hypot(dx, dy), k = (e.k || 0) * 26;
      const mx = (x1 + x2) / 2 - dy / d * k, my = (y1 + y2) / 2 + dx / d * k;
      o += `<path d="M${x1} ${y1}Q${2 * mx - (x1 + x2) / 2} ${2 * my - (y1 + y2) / 2} ${x2} ${y2}" fill="none" stroke="${e.c || '#64748b'}" stroke-width="4" stroke-linecap="round"${e.dash ? ' stroke-dasharray="8 6"' : ''}/>`;
      if (v.dir) { const ang = Math.atan2(y2 - my, x2 - mx) * 180 / Math.PI, ax = mx + (x2 - mx) * .45, ay = my + (y2 - my) * .45; o += `<path d="M7 0l-13 -7v14z" fill="#334155" transform="translate(${ax} ${ay}) rotate(${ang})"/>` }
      if (e.lb != null) { const w = Math.max(28, String(e.lb).length * 9 + 10); lab += `<rect x="${mx - w / 2}" y="${my - 11}" width="${w}" height="22" rx="6" fill="#fff" stroke="#cbd5e1"/>` + T(mx, my + 1, e.lb, { fs: 14, c: '#7c2d12' }) }
    });
    N.forEach(n => { o += `<circle cx="${X(n.x)}" cy="${Y(n.y)}" r="17" fill="${n.c || '#dbeafe'}" stroke="#1e3a8a" stroke-width="2.5"/>` + T(X(n.x), Y(n.y) + 1, n.lb, { fs: 16 }) });
    return svg(v.w * u + pd * 2, v.h * u + pd * 2, o + lab, Math.min(390, (v.w * u + pd * 2) * 1.05));
  };

  // --- blok-sxema: {l:[{k:'oval'|'rect'|'para'|'dia', s, yes, no}]} — ketma-ket pastga; romb: yes/no — qaysi blokka (indeks).
  //   Rombdan bitta tarmoq keyingi blokka (pastga), ikkinchisi o‘ng tomondan aylanib boradi.
  V.ext['3J11-blok'] = v => {
    const L = v.l, cx = 150, bw = 216, gap = 26; let o = '', y = 8; const pos = [];
    const hgt = b => b.k === 'dia' ? 66 : b.k === 'oval' ? 36 : 40;
    L.forEach(b => { pos.push({ y, h: hgt(b) }); y += hgt(b) + gap });
    const H = y - gap + 8; let lane = 0;
    const arrow = (x, yy, dir) => dir === 'd' ? `<path d="M${x} ${yy}l-6 -10h12z" fill="#334155"/>` : `<path d="M${x} ${yy}l10 -6v12z" fill="#334155"/>`;
    L.forEach((b, i) => {
      const p = pos[i], top = p.y, mid = p.y + p.h / 2, fs = String(b.s).length > 22 ? 13 : 15;
      if (b.k === 'oval') o += `<rect x="${cx - 70}" y="${top}" width="140" height="${p.h}" rx="18" fill="#dcfce7" stroke="#15803d" stroke-width="2.5"/>`;
      else if (b.k === 'rect') o += `<rect x="${cx - bw / 2}" y="${top}" width="${bw}" height="${p.h}" rx="4" fill="#dbeafe" stroke="#1d4ed8" stroke-width="2.5"/>`;
      else if (b.k === 'para') o += `<path d="M${cx - bw / 2 + 14} ${top}H${cx + bw / 2 + 6}L${cx + bw / 2 - 14} ${top + p.h}H${cx - bw / 2 - 6}z" fill="#fef3c7" stroke="#b45309" stroke-width="2.5"/>`;
      else if (b.k === 'dia') o += `<path d="M${cx} ${top}L${cx + bw / 2 + 4} ${mid}L${cx} ${top + p.h}L${cx - bw / 2 - 4} ${mid}z" fill="#fce7f3" stroke="#be185d" stroke-width="2.5"/>`;
      o += T(cx, mid + 1, b.s, { fs });
      // pastga strelka
      const down = b.k === 'dia' ? (b.down || 'yes') : null;
      const nextIdx = i + 1;
      if (i < L.length - 1 && !b.stop) {
        o += `<line x1="${cx}" y1="${top + p.h}" x2="${cx}" y2="${pos[nextIdx].y - 2}" stroke="#334155" stroke-width="2.5"/>` + arrow(cx, pos[nextIdx].y, 'd');
        if (down) o += T(cx + 22, top + p.h + 10, down === 'yes' ? 'Ha' : 'Yo‘q', { fs: 13, c: down === 'yes' ? P.green : P.red });
      }
      if (b.k === 'dia') {
        const side = down === 'yes' ? 'no' : 'yes', tg = b[side];
        if (tg != null) {
          const lx = cx + bw / 2 + 22 + lane * 22; lane++;
          const ty = pos[tg].y + pos[tg].h / 2, tx = cx + (L[tg].k === 'oval' ? 70 : L[tg].k === 'dia' ? bw / 2 + 4 : bw / 2) + 2;
          if (L[tg].k === 'dia' && tg < i && tg > 0) { // orqaga — rombga: o‘ng uchi chiqish uchun band, shuning uchun romb ustidagi kiruvchi chiziqqa qo‘shiladi
            const jy = pos[tg].y - gap / 2;
            o += `<path d="M${cx + bw / 2 + 4} ${mid}H${lx}V${jy}H${cx + 12}" fill="none" stroke="#334155" stroke-width="2.5"/>` + arrow(cx + 3, jy, 'l');
          } else
          o += `<path d="M${cx + bw / 2 + 4} ${mid}H${lx}V${ty}H${tx + 9}" fill="none" stroke="#334155" stroke-width="2.5"/>` + arrow(tx, ty, 'l');
          o += T(cx + bw / 2 + 14, mid - 11, side === 'yes' ? 'Ha' : 'Yo‘q', { fs: 13, c: side === 'yes' ? P.green : P.red });
        }
      }
    });
    if (v.loopBack != null) { /* zaxira */ }
    return svg(cx + bw / 2 + 56 + lane * 22, H, o, 390);
  };

  // --- katakli shakllar qatori: {figs:[{w,h,cells:[[x,y]],lb,fill}], u, axis:{v:k}|{h:k}}
  V.ext['3J11-figs'] = v => {
    const u = v.u || 18, gap = 18; let o = '', x = 4, W = 0; const Hm = Math.max(...v.figs.map(f => f.h * u));
    v.figs.forEach((f, i) => {
      const fw = f.w * u, fh = f.h * u;
      for (let a = 0; a <= f.w; a++) o += `<line x1="${x + a * u}" y1="4" x2="${x + a * u}" y2="${4 + fh}" stroke="#cbd5e1" stroke-width="1"/>`;
      for (let b = 0; b <= f.h; b++) o += `<line x1="${x}" y1="${4 + b * u}" x2="${x + fw}" y2="${4 + b * u}" stroke="#cbd5e1" stroke-width="1"/>`;
      f.cells.forEach(c => { o += `<rect x="${x + c[0] * u + 1}" y="${4 + c[1] * u + 1}" width="${u - 2}" height="${u - 2}" rx="2" fill="${(f.col && f.col[c[0] + ',' + c[1]]) || f.fill || '#60a5fa'}"/>` });
      if (f.dot) o += `<circle cx="${x + f.dot[0] * u + u / 2}" cy="${4 + f.dot[1] * u + u / 2}" r="${u * .22}" fill="#fff"/>`;
      if (f.lb) o += T(x + fw / 2, 4 + Hm + 16, f.lb, { fs: 16, c: f.lbc || P.red });
      x += fw + gap; W = x - gap;
    });
    return svg(W + 6, Hm + 30, o, Math.min(390, (W + 6) * 1.25));
  };

  // --- raqamli soat (7 segment): {s:'12:51', mir:true (ko‘zgudagi aks), cap}
  const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abged', 3: 'abgcd', 4: 'fgbc', 5: 'afgcd', 6: 'afgedc', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg' };
  V.ext['3J11-seg7'] = v => {
    const dw = 40, dh = 70, th = 8; let o = '', x = 18; const y = 18;
    const seg = (s, x0) => { const m = { a: [x0 + th, y, dw - 2 * th, th], d: [x0 + th, y + dh - th, dw - 2 * th, th], g: [x0 + th, y + dh / 2 - th / 2, dw - 2 * th, th], f: [x0, y + th, th, dh / 2 - th * 1.5], b: [x0 + dw - th, y + th, th, dh / 2 - th * 1.5], e: [x0, y + dh / 2 + th / 2, th, dh / 2 - th * 1.5], c: [x0 + dw - th, y + dh / 2 + th / 2, th, dh / 2 - th * 1.5] }; return Object.keys(m).map(k => { const [a, b, c, d] = m[k]; return `<rect x="${a}" y="${b}" width="${c}" height="${d}" rx="3" fill="${s.includes(k) ? '#ef4444' : '#2a1a1a'}"/>` }).join('') };
    for (const ch of v.s) {
      if (ch === ':') { o += `<circle cx="${x + 6}" cy="${y + dh * .3}" r="4.5" fill="#ef4444"/><circle cx="${x + 6}" cy="${y + dh * .7}" r="4.5" fill="#ef4444"/>`; x += 14; }
      else { o += seg(SEG[ch], x); x += dw + 12; }
    }
    const W = x + 6, H = dh + 36;
    let body = `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="14" fill="#111827" stroke="${v.mir ? '#38bdf8' : '#475569'}" stroke-width="4"/>` + (v.mir ? `<g transform="translate(${W} 0) scale(-1 1)">${o}</g>` : o);
    if (v.mir) body = `<rect x="-8" y="-8" width="${W + 16}" height="${H + 16}" rx="20" fill="#e0f2fe" stroke="#7dd3fc" stroke-width="3"/>` + body;
    return svg(W, H + (v.cap ? 26 : 0), `<g transform="translate(0 0)">${body}</g>` + (v.cap ? T(W / 2, H + 14, v.cap, { fs: 15 }) : ''), Math.min(300, W));
  };

  // --- tenglamalar: {rows:[['doira','+',{img:'olma'},'=','12'], ...]} — shakl nomi, {img:'<rasm>'} yoki matn
  const SC = { doira: '#60a5fa', uchburchak: '#34d399', kvadrat: '#fbbf24', yulduz: '#f472b6', romb: '#a78bfa', olti: '#fb923c', tortburchak: '#2dd4bf' };
  V.ext['3J11-teng'] = v => {
    const s = v.s || 40, rh = s + 12; let o = '', W = 0;
    v.rows.forEach((r, j) => {
      let x = 4; const y = 6 + j * rh;
      r.forEach(t => {
        if (t && t.img) { o += V.im(t.img, x, y, s); x += s + 4; return } // {img:'olma'} — sahifa rasmni shu nomdan topadi
        t = String(t);
        if (SC[t]) { o += V.shp(t, x, y, s, SC[t]); x += s + 4 }
        else if (t.startsWith('img:')) { o += V.im(t.slice(4), x, y, s); x += s + 4 }
        else { const w = Math.max(16, [...t].length * s * .34) + 6; o += T(x + w / 2, y + s / 2 + 1, t, { fs: s * .6, c: t === '?' ? '#b45309' : P.ink }); x += w + 4 }
      });
      W = Math.max(W, x);
    });
    let bg = ''; v.rows.forEach((r, j) => { if (j % 2 === 0) bg += `<rect x="0" y="${j * rh + 1}" width="${W + 4}" height="${rh - 2}" rx="6" fill="#f1f5f9"/>` });
    return svg(W + 4, v.rows.length * rh + 4, bg + o, Math.min(380, (W + 4) * 1.1));
  };

  // --- shakllar jadvali: {g:[['doira','kvadrat',..],..], rs:['15','?',null], cs:[...], s} — o‘ngda qator yig‘indisi, pastda ustun yig‘indisi
  V.ext['3J11-jad'] = v => {
    const s = v.s || 44, n = v.g.length, m = v.g[0].length, pd = 4, sw = 52; let o = '';
    const X = j => pd + j * s, Y = i => pd + i * s;
    o += `<rect x="${pd}" y="${pd}" width="${m * s}" height="${n * s}" fill="#f8fbff"/>`;
    v.g.forEach((r, i) => r.forEach((t, j) => { if (SC[t]) o += V.shp(t, X(j) + 4, Y(i) + 4, s - 8, SC[t]); else if (t != null) o += T(X(j) + s / 2, Y(i) + s / 2 + 1, t, { fs: s * .5 }) }));
    for (let i = 0; i <= n; i++) o += `<line x1="${pd}" y1="${Y(i)}" x2="${X(m)}" y2="${Y(i)}" stroke="#475569" stroke-width="2"/>`;
    for (let j = 0; j <= m; j++) o += `<line x1="${X(j)}" y1="${pd}" x2="${X(j)}" y2="${Y(n)}" stroke="#475569" stroke-width="2"/>`;
    const lab = (cx, cy, t) => t == null ? '' : t === '?' ? V.shp('?', cx - s * .4, cy - s * .4, s * .8) : `<rect x="${cx - 22}" y="${cy - 15}" width="44" height="30" rx="8" fill="#fef3c7" stroke="#d97706" stroke-width="1.5"/>` + T(cx, cy + 1, t, { fs: 18 });
    (v.rs || []).forEach((t, i) => o += lab(X(m) + sw / 2 + 4, Y(i) + s / 2, t));
    (v.cs || []).forEach((t, j) => o += lab(X(j) + s / 2, Y(n) + sw / 2 + 2, t));
    const W = X(m) + sw + 8, H = Y(n) + sw + 4;
    return svg(W, H, o, Math.min(300, W * 1.1));
  };

  // --- rangli sharlar qutisi: {l:[{c,n,lb}], title} — har rang qatorda: shar + "n ta qizil"
  V.ext['3J11-qop'] = v => {
    const rows = v.l, rh = 34; let o = ''; const W = 330, H = rows.length * rh + 26;
    o += `<path d="M10 14H${W - 10}V${H - 6}a8 8 0 0 1 -8 8H18a8 8 0 0 1 -8 -8z" fill="#fff7ed" stroke="#b45309" stroke-width="3"/><rect x="4" y="6" width="${W - 8}" height="12" rx="4" fill="#fdba74" stroke="#b45309" stroke-width="2"/>`;
    rows.forEach((r, i) => {
      const y = 30 + i * rh, k = r.n, sp = Math.min(20, 165 / Math.max(k, 1)), rr = Math.min(9, sp / 2 + 1.5);
      for (let a = 0; a < k; a++) o += `<circle cx="${28 + a * sp}" cy="${y + 10}" r="${rr}" fill="${r.c}" stroke="#334155" stroke-width="1.5"/>`;
      o += T(W - 22, y + 11, r.lb, { fs: 16, a: 'end' });
    });
    return svg(W, H + 6, o, 360);
  };

  // --- gapirayotganlar: {l:[{who:'A', s:'...', c}]} — HTML pufakchalar (telefonda o‘raladi)
  V.ext['3J11-gap'] = v => `<div style="display:flex;flex-direction:column;gap:7px;margin:8px 0;text-align:left">${v.l.map((p, i) => `<div style="display:flex;align-items:flex-start;gap:8px"><span style="flex:0 0 auto;min-width:36px;height:36px;padding:0 6px;border-radius:18px;background:${p.c || P.fills[i % 7]};color:#fff;display:grid;place-items:center;font:900 16px Nunito,system-ui,sans-serif">${esc(p.who)}</span><span style="background:#fff;border:2px solid #93c5fd;border-radius:4px 14px 14px 14px;padding:7px 10px;font:800 16px/1.35 Nunito,system-ui,sans-serif;color:#0b2a6f">${esc(p.s)}</span></div>`).join('')}</div>`;

  // --- son mashinasi: {l:['5','×3','+4','?']} — birinchi va oxirgi — son (doira), o‘rtadagilar — amal (mashina)
  V.ext['3J11-mash'] = v => `<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:4px;margin:8px 0">${v.l.map((x, i) => { const end = i === 0 || i === v.l.length - 1, q = x === '?'; const st = end ? `min-width:48px;height:48px;border-radius:24px;background:${q ? '#fff7d6' : '#dcfce7'};border:2.5px ${q ? 'dashed #f5b301' : 'solid #16a34a'};color:${q ? '#b45309' : '#14532d'}` : `min-width:56px;height:44px;border-radius:10px;background:${q ? '#fff7d6' : '#1e3a8a'};border:2.5px ${q ? 'dashed #f5b301' : 'solid #1e3a8a'};color:${q ? '#b45309' : '#fff'}`; return (i ? '<span style="font:900 20px sans-serif;color:#334155">→</span>' : '') + `<span style="${st};padding:0 8px;display:grid;place-items:center;font:900 20px Nunito,system-ui,sans-serif">${esc(x)}</span>` }).join('')}</div>`;

  // --- tarozi (toshlari aniq yoziladigan): {l:[{img,n}|{s:'500 g'}], r:[...], tilt: -1 chap og‘ir, 0 teng, 1 o‘ng og‘ir}
  V.ext['3J11-tarozi'] = v => {
    const t = (v.tilt || 0) * 9, cx = 210; let o = `<path d="M${cx - 50} 236h100l-20 -16h-60z" fill="#64748b"/><rect x="${cx - 6}" y="70" width="12" height="156" rx="4" fill="#94a3b8"/>`;
    o += `<g transform="rotate(${t} ${cx} 74)"><rect x="40" y="68" width="340" height="10" rx="5" fill="#475569"/>`;
    const pan = (x, list) => {
      let s = `<line x1="${x}" y1="78" x2="${x - 70}" y2="160" stroke="#64748b" stroke-width="2"/><line x1="${x}" y1="78" x2="${x + 70}" y2="160" stroke="#64748b" stroke-width="2"/><g transform="rotate(${-t} ${x} 160)"><path d="M${x - 84} 160h168a84 18 0 0 1 -168 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>`;
      const all = []; list.forEach(e => { if (e.s) all.push({ s: e.s, w: Math.max(34, String(e.s).length * 9 + 12) }); else for (let i = 0; i < e.n; i++) all.push({ img: e.img, w: 0 }) });
      const n = all.filter(e => e.img).length, sz = n > 10 ? 22 : n > 5 ? 26 : 32; all.forEach(e => { if (e.img) e.w = sz });
      // qatorlarga terish (pastdan yuqoriga), eni 160
      const rows = []; let cur = [], cw = 0; for (const e of all) { if (cur.length && cw + e.w > 160) { rows.push(cur); cur = []; cw = 0 } cur.push(e); cw += e.w + 2 } if (cur.length) rows.push(cur);
      let y = 160; rows.forEach(r => { const h = Math.max(...r.map(e => e.img ? sz : 26)); const W = r.reduce((a, e) => a + e.w + 2, -2); let xx = x - W / 2; y -= h; r.forEach(e => {
        if (e.img) s += V.im(e.img, xx, y + h - sz, sz);
        else s += `<path d="M${xx + 5} ${y + h - 24}h${e.w - 10}l5 24h${-e.w}z" fill="#475569" stroke="#1e293b" stroke-width="1.5"/><rect x="${xx + e.w / 2 - 5}" y="${y + h - 30}" width="10" height="7" rx="3" fill="none" stroke="#1e293b" stroke-width="2.5"/>` + T(xx + e.w / 2, y + h - 11, e.s, { fs: 13, c: '#fff' });
        xx += e.w + 2 }); y -= 2 });
      return s + '</g>';
    };
    o += pan(95, v.l) + pan(325, v.r) + '</g>';
    return svg(420, 240, o, 400);
  };

  // --- raqamli kartochkalar (180° burish uchun): {l:['1','8','6'], rot:true}
  V.ext['3J11-kart'] = v => {
    const s = 56, n = v.l.length, W = n * (s + 8) + 4; let o = '';
    v.l.forEach((c, i) => { const x = 4 + i * (s + 8); o += `<rect x="${x}" y="4" width="${s}" height="${s * 1.25}" rx="8" fill="#fff" stroke="#1e3a8a" stroke-width="2.5"/>` + T(x + s / 2, 4 + s * .62, c, { fs: 40, c: P.ink }) });
    const body = v.rot ? `<g transform="rotate(180 ${W / 2} ${(s * 1.25 + 8) / 2})">${o}</g>` : o;
    return svg(W, s * 1.25 + 8, body, Math.min(340, W * 1.2));
  };
})();

// 3K (Tanqidiy fikrlash, 3-sinf) uchun rasm turlari. Turlar nomi '3K-' bilan boshlanadi.
//  3K-venn   — doira-diagramma (2 yoki 3 to‘plam): {sets:['Futbol','Shaxmat'], reg:{a:'5', b:'3', ab:'2', o:'1'}, sh:['ab'], title}
//              hududlar: a, b, c, ab, ac, bc, abc, o (tashqari). sh — bo‘yalgan hududlar. reg qiymati matn yoki matnlar ro‘yxati.
//  3K-gap    — bolalar gapi (nutq pufakchalari): {l:[{n:'Ali', s:'Men olmani yemadim.'}]}
//  3K-shkala — ikki qutb orasidagi shkala: {l:['sovuq','?','issiq'], c:['#60a5fa','#ef4444']}
//  3K-navbat — bolalar qatori: {l:[{n:'Ali', h:1, c:'#..'}], q:[2], dir:'oldi'} (h — bo‘y koeffitsiyenti, '?' — noma’lum)
//  3K-anal   — shakl o‘xshashligi: {a:[F,F], b:[F,'?'], ans:[F,F,F,F]} F = {s:'doira', c:'#..', z:1, n:1, e:0 (bo‘sh)}
//  3K-kompas — yo‘nalishlar: {hl:'Shimol'}
//  3K-munos — uch to‘plam munosabati rasmlari: {l:[0..4 ×4]}
//  3K-quti  — yozuvli qutilar: {l:['Sovg‘a shu qutida', ...]}
//  3K-uylar — qatordagi raqamli uylar: {l:['?', 'Ali', ...]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg, esc = V.esc;
  let uid = 0;

  // ---------- doira-diagramma
  V.ext['3K-venn'] = v => {
    const k = v.sets.length, id = 'k3v' + (++uid);
    const G = k === 2
      ? { W: 340, H: 230, c: [[130, 118, 84], [210, 118, 84]], lab: [[78, 22], [262, 22]], pos: { a: [92, 118], b: [248, 118], ab: [170, 118], o: [24, 212] } }
      : { W: 340, H: 300, c: [[132, 112, 76], [208, 112, 76], [170, 178, 76]], lab: [[70, 22], [270, 22], [170, 288]],
          pos: { a: [104, 96], b: [236, 96], c: [170, 214], ab: [170, 82], ac: [128, 162], bc: [212, 162], abc: [170, 136], o: [22, 284] } };
    const col = ['#2563eb', '#16a34a', '#db2777'], fill = ['#dbeafe80', '#dcfce780', '#fce7f380'];
    const keys = ['a', 'b', 'c'].slice(0, k);
    let defs = `<defs>${G.c.map((c, i) => `<clipPath id="${id}c${i}"><circle cx="${c[0]}" cy="${c[1]}" r="${c[2]}"/></clipPath>`).join('')}`;
    let o = `<rect x="3" y="3" width="${G.W - 6}" height="${G.H - 6}" rx="14" fill="#fff" stroke="#94a3b8" stroke-width="2"/>`;
    // bo‘yalgan hududlar
    (v.sh || []).forEach((r, j) => {
      const inn = r === 'o' ? [] : r.split(''), out = keys.filter(x => !inn.includes(x));
      const mid = `${id}m${j}`;
      defs += `<mask id="${mid}"><rect width="${G.W}" height="${G.H}" fill="#fff"/>${out.map(x => { const c = G.c[keys.indexOf(x)]; return `<circle cx="${c[0]}" cy="${c[1]}" r="${c[2]}" fill="#000"/>` }).join('')}</mask>`;
      let body = `<rect x="5" y="5" width="${G.W - 10}" height="${G.H - 10}" rx="12" fill="#fde68a" mask="url(#${mid})"/>`;
      inn.forEach(x => { body = `<g clip-path="url(#${id}c${keys.indexOf(x)})">${body}</g>` });
      o += body;
    });
    G.c.forEach((c, i) => { o += `<circle cx="${c[0]}" cy="${c[1]}" r="${c[2]}" fill="${(v.sh || []).length ? 'none' : fill[i]}" stroke="${col[i]}" stroke-width="3"/>` });
    v.sets.forEach((s, i) => { o += T(G.lab[i][0], G.lab[i][1], s, { fs: 15, c: col[i], st: 1 }) });
    for (const r in (v.reg || {})) {
      const val = [].concat(v.reg[r]), p = G.pos[r]; if (!p) continue;
      if (r === 'o') { o += T(p[0], p[1] - 4, val.join(', '), { fs: 14, a: 'start', c: val[0] === '?' ? '#b45309' : P.ink, st: 1 }); continue }
      const lh = 17, y0 = p[1] - (val.length - 1) * lh / 2;
      val.forEach((t, j) => {
        if (t === '?') o += `<rect x="${p[0] - 15}" y="${y0 + j * lh - 14}" width="30" height="28" rx="8" fill="#fff7d6" stroke="${P.gold}" stroke-width="2" stroke-dasharray="5 3"/>` + T(p[0], y0 + j * lh, '?', { fs: 17, c: '#b45309' });
        else o += T(p[0], y0 + j * lh, t, { fs: String(t).length > 3 ? 13 : 18, st: 1 });
      });
    }
    if (v.title) o += T(G.W - 12, G.H - 16, v.title, { fs: 13, a: 'end', c: '#64748b' });
    return svg(G.W, G.H, defs + '</defs>' + o, 360);
  };

  // ---------- nutq pufakchalari
  const AVC = ['#2563eb', '#db2777', '#16a34a', '#d97706', '#7c3aed', '#0891b2'];
  V.ext['3K-gap'] = v => `<div style="display:flex;flex-direction:column;gap:8px;margin:8px auto;max-width:440px;text-align:left">${v.l.map((e, i) => `<div style="display:flex;align-items:flex-start;gap:8px"><div style="flex:0 0 58px;text-align:center"><div style="width:40px;height:40px;margin:0 auto;border-radius:50%;background:${e.c || AVC[i % AVC.length]};color:#fff;font:900 20px/40px Nunito,system-ui,sans-serif">${esc(e.n[0])}</div><div style="font:800 12px Nunito,system-ui,sans-serif;color:#0b2a6f;margin-top:2px">${esc(e.n)}</div></div><div style="position:relative;flex:1;background:#fff;border:2px solid ${e.c || AVC[i % AVC.length]};border-radius:14px;padding:8px 10px;font:800 15px/1.35 Nunito,system-ui,sans-serif;color:#0b2a6f">${esc(e.s)}</div></div>`).join('')}</div>`;

  // ---------- qutblar shkalasi
  V.ext['3K-shkala'] = v => {
    const c = v.c || ['#3b82f6', '#ef4444'];
    return `<div style="margin:10px auto;max-width:460px"><div style="height:12px;border-radius:6px;background:linear-gradient(90deg,${c[0]},${c[1]});margin:0 6px 8px"></div><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px">${v.l.map((x, i) => `<span style="flex:1 0 auto;padding:6px 4px;border-radius:10px;text-align:center;font:900 ${v.l.length > 4 ? 12 : 14}px Nunito,system-ui,sans-serif;${x === '?' ? 'background:#fff7d6;border:2.5px dashed #f5b301;color:#b45309' : `background:#fff;border:2px solid ${i === 0 ? c[0] : i === v.l.length - 1 ? c[1] : '#cbd5e1'};color:#0b2a6f`}">${esc(x)}</span>`).join('')}</div></div>`;
  };

  // ---------- bolalar qatori
  V.ext['3K-navbat'] = v => {
    const n = v.l.length, w = 58, H = 128; let o = '';
    v.l.forEach((e, i) => {
      const x = 8 + i * w + w / 2, h = e.h || 1, top = H - 26 - 80 * h, c = e.c || AVC[i % AVC.length], q = e.n === '?';
      o += `<circle cx="${x}" cy="${top + 11}" r="11" fill="${q ? '#fff7d6' : '#fde7c8'}" stroke="${q ? P.gold : '#92400e'}" stroke-width="2"/>`;
      o += `<rect x="${x - 13}" y="${top + 24}" width="26" height="${Math.max(20, H - 26 - top - 24)}" rx="9" fill="${q ? '#fff7d6' : c}" stroke="${q ? P.gold : 'none'}" stroke-width="2" ${q ? 'stroke-dasharray="5 3"' : ''}/>`;
      o += T(x, H - 12, e.n, { fs: 13, c: q ? '#b45309' : P.ink });
      if (e.k != null) o += T(x, top + 11, e.k, { fs: 11 });
    });
    if (v.dir) o += T(8 + n * w + 4, H - 60, v.dir, { fs: 13, a: 'start', c: P.red });
    return svg(8 + n * w + (v.dir ? 70 : 8), H, `<line x1="4" y1="${H - 25}" x2="${8 + n * w + 4}" y2="${H - 25}" stroke="#cbd5e1" stroke-width="3"/>` + o, 400);
  };

  // ---------- shakl o‘xshashligi
  const fig = (f, x, y, s) => {
    if (f === '?') return V.shp('?', x, y, s, '');
    const n = f.n || 1, z = f.z || 1, col = f.e ? '#fff' : f.c;
    if (n === 1) { const ss = s * z; return V.shp(f.s, x + (s - ss) / 2, y + (s - ss) / 2, ss, col) }
    const ss = s * .46; let o = '';
    for (let k = 0; k < n; k++) o += V.shp(f.s, x + (k % 2) * ss * 1.08 + s * .02, y + Math.floor(k / 2) * ss * 1.08 + (n <= 2 ? s * .26 : 0), ss, col);
    return o;
  };
  V.ext['3K-anal'] = v => {
    const s = 56, box = (x, y, f) => `<rect x="${x}" y="${y}" width="${s + 8}" height="${s + 8}" rx="10" fill="#f8fafc" stroke="#cbd5e1" stroke-width="1.5"/>` + fig(f, x + 4, y + 4, s);
    let o = box(4, 6, v.a[0]) + T(90, 38, '→', { fs: 24 }) + box(106, 6, v.a[1]);
    o += box(190, 6, v.b[0]) + T(276, 38, '→', { fs: 24 }) + box(292, 6, v.b[1]);
    o += `<line x1="180" y1="6" x2="180" y2="${s + 14}" stroke="#94a3b8" stroke-width="2" stroke-dasharray="4 4"/>`;
    let H = s + 22;
    if (v.ans) { v.ans.forEach((f, i) => { o += box(16 + i * 90, H + 8, f) + T(16 + i * 90 + (s + 8) / 2, H + s + 30, 'ABDEFG'[i], { fs: 16, c: P.red }) }); H += s + 44 }
    return svg(368, H, o, 368);
  };

  // ---------- kartochkalar (old tomoni): {l:[{sh:'doira'}|{c:'#ef4444'}|{n:'7'}], lb:['A','B',...]}
  V.ext['3K-karta'] = v => {
    const w = 64, h = 84; let o = '';
    v.l.forEach((e, i) => {
      const x = 6 + i * (w + 16), y = 4;
      o += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="10" fill="${e.c || '#fff'}" stroke="#1e3a8a" stroke-width="2.5"/>`;
      if (e.sh) o += V.shp(e.sh, x + 10, y + 20, w - 20, '#fff');
      if (e.n != null) o += T(x + w / 2, y + h / 2, e.n, { fs: 32 });
      if (v.lb) o += T(x + w / 2, y + h + 16, v.lb[i], { fs: 16, c: P.red });
    });
    return svg(12 + v.l.length * (w + 16) - 16, h + (v.lb ? 30 : 8), o, 360);
  };

  // ---------- kompas
  V.ext['3K-kompas'] = v => {
    const c = 110, L = [['Shimol', c, 20], ['Janub', c, 200], ['Sharq', 196, c], ['G‘arb', 24, c]]; let o = '';
    o += `<circle cx="${c}" cy="${c}" r="62" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"/>`;
    o += `<path d="M${c} ${c - 58}L${c + 9} ${c}L${c} ${c + 58}L${c - 9} ${c}z" fill="#ef4444"/><path d="M${c} ${c}L${c + 9} ${c}L${c} ${c + 58}L${c - 9} ${c}z" fill="#64748b"/>`;
    o += `<path d="M${c - 58} ${c}L${c} ${c - 9}L${c + 58} ${c}L${c} ${c + 9}z" fill="#94a3b833"/>`;
    L.forEach(([s, x, y]) => { o += T(x, y, s, { fs: 15, c: v.hl === s ? P.red : P.ink }) });
    return svg(220, 220, o, 220);
  };
  // ---------- to‘plamlar munosabati: {l:[0..4,...]} har biri kichik rasm, 1, 2, 3, 4 raqamli
  // 0 — zanjir (biri ichida biri, uning ichida yana biri), 1 — katta ichida ikkita alohida, 2 — uchtasi alohida,
  // 3 — biri ikkinchisi ichida, uchinchisi alohida, 4 — katta ichida bir-biriga kesishgan ikkita
  V.ext['3K-munos'] = v => {
    const cc = ['#2563eb', '#16a34a', '#db2777'], fl = ['#dbeafe', '#dcfce7', '#fce7f3'];
    const C3 = (x, y, r, i) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${fl[i]}" fill-opacity=".55" stroke="${cc[i]}" stroke-width="3"/>`;
    const D = [
      (x, y) => C3(x, y, 46, 0) + C3(x + 6, y + 10, 30, 1) + C3(x + 10, y + 20, 14, 2),
      (x, y) => C3(x, y, 46, 0) + C3(x - 20, y + 4, 17, 1) + C3(x + 20, y + 4, 17, 2),
      (x, y) => C3(x - 42, y + 8, 20, 0) + C3(x, y - 18, 20, 1) + C3(x + 42, y + 8, 20, 2),
      (x, y) => C3(x - 18, y, 36, 0) + C3(x - 12, y + 10, 16, 1) + C3(x + 42, y, 18, 2),
      (x, y) => C3(x, y, 46, 0) + C3(x - 13, y + 4, 22, 1) + C3(x + 13, y + 4, 22, 2),
    ];
    let o = ''; const W = 160, H = 130;
    v.l.forEach((k, i) => {
      const px = (i % 2) * W, py = Math.floor(i / 2) * H;
      o += `<rect x="${px + 4}" y="${py + 4}" width="${W - 8}" height="${H - 8}" rx="12" fill="#fff" stroke="#cbd5e1" stroke-width="2"/>`;
      o += D[k](px + W / 2 + 6, py + H / 2 + 4);
      o += `<circle cx="${px + 20}" cy="${py + 20}" r="11" fill="#0b2a6f"/>` + T(px + 20, py + 20, i + 1, { fs: 14, c: '#fff' });
    });
    return svg(2 * W, Math.ceil(v.l.length / 2) * H, o, 340);
  };
  // ---------- yozuvli qutilar: {l:['Sovg‘a shu qutida', ...]} — 1, 2, 3-qutilar
  V.ext['3K-quti'] = v => `<div style="display:flex;gap:8px;justify-content:center;margin:8px auto;max-width:440px">${v.l.map((s, i) => `<div style="flex:1;min-width:0;text-align:center">${svg(90, 70, `<rect x="6" y="22" width="78" height="44" rx="6" fill="#f59e0b" stroke="#b45309" stroke-width="2"/><rect x="2" y="12" width="86" height="14" rx="4" fill="#d97706" stroke="#b45309" stroke-width="2"/><rect x="38" y="12" width="14" height="54" fill="#dc2626"/>` + T(22, 46, i + 1, { fs: 20, c: '#fff' }), 80)}<div style="margin-top:4px;background:#fff;border:2px dashed #b45309;border-radius:10px;padding:6px 4px;font:800 13px/1.3 Nunito,system-ui,sans-serif;color:#0b2a6f">${esc(s)}</div></div>`).join('')}</div>`;
  // ---------- qatordagi uylar: {l:['?', 'Ali', ...]} — 1, 2, 3 … raqamli uylar, ostida yozuv
  V.ext['3K-uylar'] = v => {
    const n = v.l.length, w = 84; let o = '';
    v.l.forEach((s, i) => {
      const x = 8 + i * w, q = s === '?';
      o += `<path d="M${x + 6} 46L${x + 38} 14L${x + 70} 46z" fill="#dc2626" stroke="#7f1d1d" stroke-width="2"/><rect x="${x + 12}" y="46" width="52" height="44" fill="#fde68a" stroke="#92400e" stroke-width="2"/><rect x="${x + 31}" y="64" width="14" height="26" fill="#92400e"/>`;
      o += T(x + 38, 36, i + 1, { fs: 15, c: '#fff' });
      o += T(x + 38, 110, s, { fs: String(s).length > 6 ? 12 : 14, c: q ? '#b45309' : P.ink });
    });
    return svg(16 + n * w, 122, o, 360);
  };
})();

// 3M (to‘plamlar va mulohazalar) va 3Y (3-sinf yakuni) uchun qo‘shimcha rasm turlari. Turlar nomi '3MY-' bilan boshlanadi.
//  '3MY-venn'    — Eyler–Venn diagrammasi (1, 2 yoki 3 doira, yoki ichma-ich 2 doira):
//                  {t:'3MY-venn', n:1|2|3, nest:true (B doira A ichida), lb:['A','B','C'], box:'Sinf' (tashqi to‘rtburchak),
//                   r:{a:[..], b:[..], ab:[..], c:[..], ac:[..], bc:[..], abc:[..], o:[..]}, big:true (sanoq — katta son), hl:['ab']}
//                  Hudud kaliti — shu hududni o‘z ichiga oladigan doiralar harflari ('a' — faqat A, 'ab' — A va B, lekin C emas; 'o' — tashqarida).
//                  Element: son/matn ('12'), '?' (savol katagi), {img:'olma'} (rasm), {tag:'1'} (hudud raqami — dumaloq belgi).
//  '3MY-model'   — Singapur "chizma model": {rows:[{lb, segs:[{n, s, dash, c}], top:{s,i0,i1}, bot:{s,i0,i1}}], right:{s,r0,r1}}
//  '3MY-burchak' — burchakli bo‘lish: {lines:[{s:' 856', m:1 (minus), ul:1 (ostiga chiziq)}], b:'4', q:'214'} (s — teng enli qator, '?' — bo‘sh katak).
//                  V.long3MY(a, b) — shu tavsifni (yashirinmagan holda) tayyorlab beradi.
//  '3MY-quti'    — o‘lchamlari yozilgan quti (to‘g‘ri burchakli parallelepiped): {a:'5 sm', b:'3 sm', c:'2 sm', cube:true (kub ko‘rinishi)}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, INK = '#0b2a6f', LINE = '#1e3a8a', QF = '#fff7d6', QS = '#f5b301', QC = '#b45309';
  let UID = 0;
  const CCOL = ['#3b82f6', '#16a34a', '#db2777'], CFILL = ['#3b82f61f', '#16a34a1f', '#db27771f'];

  // ---------------- Venn ----------------
  const geom = v => {
    const n = v.n || 2, W = 440;
    let cs;
    if (v.nest) cs = [{ x: 205, y: 160, r: 128 }, { x: 255, y: 172, r: 66 }];
    else if (n === 1) cs = [{ x: 220, y: 140, r: 108 }];
    else if (n === 2) cs = [{ x: 160, y: 145, r: 108 }, { x: 280, y: 145, r: 108 }];
    else cs = [{ x: 165, y: 140, r: 100 }, { x: 275, y: 140, r: 100 }, { x: 220, y: 230, r: 100 }];
    const top = 36, bottom = n === 3 && !v.nest ? 360 : (v.nest ? 312 : 280);
    const box = v.box ? { x: 6, y: 6, w: W - 12, h: bottom - 2 + (n === 3 ? 18 : 10) } : null;
    if (box) cs.forEach(c => { c.y += 14 });
    const H = box ? box.y + box.h + 6 : bottom + 6;
    return { n: v.nest ? 2 : n, cs, W, H, box };
  };
  const KEYS = 'abc';
  const inReg = (G, key, x, y, m) => {
    for (let i = 0; i < G.cs.length; i++) {
      const c = G.cs[i], d = Math.hypot(x - c.x, y - c.y), want = key !== 'o' && key.includes(KEYS[i]);
      if (want && d > c.r - m) return false;
      if (!want && d < c.r + m) return false;
    }
    if (key === 'o') { if (!G.box) return false; const b = G.box; if (x < b.x + m || x > b.x + b.w - m || y < b.y + 30 + m * .6 || y > b.y + b.h - m) return false }
    return true;
  };
  // hududga k ta joy topadi (topilmasa — xato)
  const spots = (G, key, k, s, taken) => {
    if (!k) return [];
    const fine = []; for (let x = 0; x < G.W; x += 4) for (let y = 0; y < G.H; y += 4) if (inReg(G, key, x, y, 2)) fine.push([x, y]);
    if (!fine.length) throw new Error('venn: hudud yo‘q ' + key);
    let cx = fine.reduce((a, p) => a + p[0], 0) / fine.length, cy = fine.reduce((a, p) => a + p[1], 0) / fine.length;
    if (key === 'o') { cx = G.box.x + G.box.w - 30; cy = G.box.y + G.box.h - 26 }
    for (const step of [s, s * .9, s * .8]) {
      const m = step * .5; const cand = [];
      for (let ox = 0; ox < step; ox += step / 3) for (let oy = 0; oy < step; oy += step / 3) {
        const pts = [];
        for (let x = ox; x < G.W; x += step) for (let y = oy; y < G.H; y += step) if (inReg(G, key, x, y, m) && !taken.some(t => Math.abs(t[0] - x) < step * .9 && Math.abs(t[1] - y) < step * .9)) pts.push([x, y]);
        if (pts.length >= k) { pts.sort((p, q) => Math.hypot(p[0] - cx, p[1] - cy) - Math.hypot(q[0] - cx, q[1] - cy)); const sel = pts.slice(0, k); const sc = sel.reduce((a, p) => a + Math.hypot(p[0] - cx, p[1] - cy), 0); cand.push({ sel, sc }) }
      }
      if (cand.length) { cand.sort((a, b) => a.sc - b.sc); return cand[0].sel }
    }
    throw new Error('venn: "' + key + '" hududiga ' + k + ' ta element sig‘madi');
  };
  const hlPath = (G, key, id) => {
    // hududni bo‘yash: kiradigan doiralar — clip, kirmaydiganlari — mask
    let defs = '', inner = `<rect x="0" y="0" width="${G.W}" height="${G.H}" fill="#fde68a"/>`;
    const msk = `m${id}${key}`; let mb = `<rect x="0" y="0" width="${G.W}" height="${G.H}" fill="#fff"/>`;
    G.cs.forEach((c, i) => { if (key === 'o' || !key.includes(KEYS[i])) mb += `<circle cx="${c.x}" cy="${c.y}" r="${c.r}" fill="#000"/>` });
    defs += `<mask id="${msk}">${mb}</mask>`;
    let g = `<g mask="url(#${msk})">${key === 'o' && G.box ? `<rect x="${G.box.x}" y="${G.box.y}" width="${G.box.w}" height="${G.box.h}" rx="16" fill="#fde68a"/>` : inner}</g>`;
    G.cs.forEach((c, i) => { if (key !== 'o' && key.includes(KEYS[i])) { const cid = `c${id}${key}${i}`; defs += `<clipPath id="${cid}"><circle cx="${c.x}" cy="${c.y}" r="${c.r}"/></clipPath>`; g = `<g clip-path="url(#${cid})">${g}</g>` } });
    return { defs, g };
  };
  V.ext['3MY-venn'] = v => {
    const G = geom(v), id = 'v' + (++UID) + Math.floor(Math.random() * 1e6); let defs = '', o = '';
    const lb = v.lb || ['A', 'B', 'C'];
    if (G.box) o += `<rect x="${G.box.x}" y="${G.box.y}" width="${G.box.w}" height="${G.box.h}" rx="16" fill="#f8fafc" stroke="#64748b" stroke-width="2"/>` + T(G.box.x + 14, G.box.y + 17, v.box === true ? '' : v.box, { fs: 15, a: 'start', c: '#334155' });
    for (const k of v.hl || []) { const h = hlPath(G, k, id); defs += h.defs; o += h.g }
    G.cs.forEach((c, i) => { o += `<circle cx="${c.x}" cy="${c.y}" r="${c.r}" fill="${(v.hl || []).length ? 'none' : CFILL[i]}" stroke="${CCOL[i]}" stroke-width="3"/>` });
    // doira nomlari
    G.cs.forEach((c, i) => {
      if (i >= G.n) return; const s = lb[i]; if (s == null || s === '') return;
      let x, y, a = 'middle';
      if (v.nest) { if (i === 0) { x = c.x - c.r * .62; y = c.y - c.r * .86 } else { x = c.x; y = c.y - c.r - 13 } }
      else if (G.n === 3 && i === 2) { x = c.x; y = c.y + c.r + 15 }
      else if (G.n === 2 || G.n === 3) { x = i === 0 ? c.x - c.r * .55 : c.x + c.r * .55; y = c.y - c.r * .86 - 14 }
      else { x = c.x; y = c.y - c.r - 14 }
      o += T(x, y, s, { fs: String(s).length > 10 ? 14 : 17, c: CCOL[i], a, st: 1 });
    });
    // elementlar
    const taken = []; const R = Object.assign({}, v.r || {});
    if (v.nest && R.b) { R.ab = (R.ab || []).concat(R.b); delete R.b } // ichma-ich: B doira butunlay A ichida
    const order = Object.keys(R).sort((p, q) => (p === 'o') - (q === 'o') || q.length - p.length);
    for (const key of order) {
      const items = R[key] || []; if (!items.length) continue;
      const isImg = items.some(e => e && e.img), s = v.big ? 44 : isImg ? (v.isz || 52) : Math.max(38, ...items.map(e => String(e && e.tag ? e.tag : e).length * 13 + 10));
      const pts = spots(G, key, items.length, s, taken);
      items.forEach((e, j) => {
        const [x, y] = pts[j]; taken.push([x, y]);
        if (e && e.img) o += V.im(e.img, x - s / 2 + 3, y - s / 2 + 3, s - 6);
        else if (e && e.tag) o += `<circle cx="${x}" cy="${y}" r="14" fill="#fff" stroke="${INK}" stroke-width="2"/>` + T(x, y + 1, e.tag, { fs: 16, c: INK });
        else if (e === '?') o += `<rect x="${x - 17}" y="${y - 16}" width="34" height="32" rx="8" fill="${QF}" stroke="${QS}" stroke-width="2.5" stroke-dasharray="5 4"/>` + T(x, y + 1, '?', { fs: 20, c: QC });
        else o += T(x, y + 1, e, { fs: v.big ? 28 : 21, c: INK, st: 1 });
      });
    }
    return V.svg(G.W, G.H, (defs ? `<defs>${defs}</defs>` : '') + o, v.mw || 420);
  };

  // ---------------- chizma model ----------------
  const hbrace = (x1, x2, y0, dir) => {
    const m = (x1 + x2) / 2, a = y0 + dir * 7, t = y0 + dir * 13, r = Math.min(8, (x2 - x1) / 4);
    return `<path d="M${x1} ${y0}Q${x1} ${a} ${x1 + r} ${a}L${m - r} ${a}Q${m} ${a} ${m} ${t}Q${m} ${a} ${m + r} ${a}L${x2 - r} ${a}Q${x2} ${a} ${x2} ${y0}" fill="none" stroke="${INK}" stroke-width="2.2"/>`;
  };
  const vbrace = (x0, y1, y2) => {
    const m = (y1 + y2) / 2, a = x0 + 7, t = x0 + 13, r = Math.min(8, (y2 - y1) / 4);
    return `<path d="M${x0} ${y1}Q${a} ${y1} ${a} ${y1 + r}L${a} ${m - r}Q${a} ${m} ${t} ${m}Q${a} ${m} ${a} ${m + r}L${a} ${y2 - r}Q${a} ${y2} ${x0} ${y2}" fill="none" stroke="${INK}" stroke-width="2.2"/>`;
  };
  const tw = (s, fs) => String(s).length * fs * 0.58;
  const FILL = ['#bfdbfe', '#fde68a', '#bbf7d0', '#fbcfe8', '#ddd6fe', '#fed7aa'];
  V.ext['3MY-model'] = v => {
    const rows = v.rows, maxLen = Math.max(...rows.map(r => r.segs.reduce((a, s) => a + s.n, 0)));
    const right = v.right, L = Math.max(60, ...rows.map(r => tw(r.lb || '', 15) + 14)), W = 440, RW = right ? Math.max(60, tw(right.s, 15) + 26) : 8;
    const k = (W - L - RW) / maxLen, BH = 34; let y = 6, o = ''; const pos = [];
    rows.forEach((r, ri) => {
      if (r.top) y += 32;
      const yb = y; let x = L; const xs = [];
      r.segs.forEach(s => {
        const w = s.n * k; xs.push([x, x + w]);
        const fill = s.dash ? QF : FILL[(s.c != null ? s.c : ri) % FILL.length];
        o += `<rect x="${x}" y="${yb}" width="${w}" height="${BH}" fill="${fill}" stroke="${s.dash ? '#d97706' : LINE}" stroke-width="2"${s.dash ? ' stroke-dasharray="6 4"' : ''}/>`;
        if (s.s) { const fs = tw(s.s, 15) < w - 4 ? 15 : tw(s.s, 12) < w - 2 ? 12 : 10; o += T(x + w / 2, yb + BH / 2, s.s, { fs, c: s.dash || s.s.includes('?') ? QC : INK }) }
        x += w;
      });
      o += T(L - 8, yb + BH / 2, r.lb || '', { fs: 15, a: 'end' });
      const br = (b, dir) => { const i0 = b.i0 || 0, i1 = b.i1 != null ? b.i1 : r.segs.length - 1, x1 = xs[i0][0], x2 = xs[i1][1], y0 = dir < 0 ? yb - 2 : yb + BH + 2; return hbrace(x1, x2, y0, dir) + T((x1 + x2) / 2, y0 + dir * 23, b.s, { fs: 15, c: b.s.includes('?') ? QC : INK, st: 1 }) };
      if (r.top) o += br(r.top, -1);
      if (r.bot) o += br(r.bot, 1);
      pos.push([yb, yb + BH]);
      y = yb + BH + (r.bot ? 36 : 0) + 14;
    });
    if (right) {
      const r0 = right.r0 || 0, r1 = right.r1 != null ? right.r1 : rows.length - 1, x0 = L + maxLen * k + 6, y1 = pos[r0][0], y2 = pos[r1][1];
      o += vbrace(x0, y1, y2) + T(x0 + 18, (y1 + y2) / 2, right.s, { fs: 15, a: 'start', c: right.s.includes('?') ? QC : INK });
    }
    return V.svg(W, y - 6, o);
  };

  // ---------------- burchakli bo‘lish ----------------
  // a : b ning to‘liq yozuvi. Qatorlar teng enli (a uzunligi), har qatorda raqamlar o‘ngga tekislangan joyda.
  V.long3MY = (a, b) => {
    const A = String(a), L = A.length, lines = [{ s: A, m: 1 }]; let q = '', i = 0, cur = +A[0];
    while (cur < b && i < L - 1) { i++; cur = cur * 10 + +A[i] } // birinchi to‘liqsiz bo‘linuvchi
    let first = true;
    for (; ;) {
      const d = Math.floor(cur / b), p = d * b; q += d;
      if (d > 0 || first) {
        if (!first) lines.push({ s: String(cur).padStart(i + 1, ' ').padEnd(L, ' '), m: 1 });
        lines.push({ s: String(p).padStart(i + 1, ' ').padEnd(L, ' '), ul: 1 });
      }
      first = false;
      const r = cur - p;
      if (i >= L - 1) { lines.push({ s: String(r).padStart(L, ' '), last: 1 }); break }
      i++; cur = r * 10 + +A[i];
    }
    if (lines.length >= 3 && lines[1].ul) lines[0].m = 1;
    return { lines, q, b: String(b), a: A, r: +lines[lines.length - 1].s.trim() };
  };
  V.ext['3MY-burchak'] = v => {
    const lines = v.lines, L = Math.max(...lines.map(l => l.s.length)), cw = 22, lh = 30, x0 = 30, y0 = 8; let o = '';
    const cell = (x, y, ch) => ch === '?' ? `<rect x="${x + 1}" y="${y + 2}" width="${cw - 2}" height="${lh - 4}" rx="5" fill="${QF}" stroke="${QS}" stroke-width="2" stroke-dasharray="4 3"/>` + T(x + cw / 2, y + lh / 2, '?', { fs: 16, c: QC }) : ch === ' ' ? '' : T(x + cw / 2, y + lh / 2 + 1, ch, { fs: 22, c: INK });
    lines.forEach((l, k) => {
      const y = y0 + k * lh, s = l.s.padEnd(L, ' ');
      [...s].forEach((ch, j) => { o += cell(x0 + j * cw, y, ch) });
      const f = s.search(/\S/), e = s.length - s.trimEnd().length;
      if (l.m) o += T(x0 + f * cw - 10, y + lh / 2 - 2, '−', { fs: 20, c: INK });
      if (l.ul) o += `<line x1="${x0 + f * cw - 2}" y1="${y + lh}" x2="${x0 + (L - e) * cw + 2}" y2="${y + lh}" stroke="${INK}" stroke-width="2"/>`;
    });
    const bx = x0 + L * cw + 8, bw = Math.max(v.b.length, v.q.length) * cw + 16;
    o += `<line x1="${bx}" y1="${y0}" x2="${bx}" y2="${y0 + lh * 2}" stroke="${INK}" stroke-width="2.5"/><line x1="${bx}" y1="${y0 + lh}" x2="${bx + bw}" y2="${y0 + lh}" stroke="${INK}" stroke-width="2.5"/>`;
    [...v.b].forEach((ch, j) => { o += cell(bx + 8 + j * cw, y0, ch) });
    [...v.q].forEach((ch, j) => { o += cell(bx + 8 + j * cw, y0 + lh, ch) });
    const W = bx + bw + 10, H = y0 + lines.length * lh + 8;
    return V.svg(W, H, o, Math.min(W * 1.25, 380));
  };

  // ---------------- quti ----------------
  V.ext['3MY-quti'] = v => {
    const w = v.cube ? 110 : 150, h = v.cube ? 110 : 90, d = v.cube ? 46 : 50, x = 30, y = 20 + d; const st = `stroke="${LINE}" stroke-width="2.5" stroke-linejoin="round"`;
    let o = `<path d="M${x} ${y}h${w}v${h}h${-w}z" fill="#93c5fd" ${st}/><path d="M${x} ${y}l${d} ${-d}h${w}l${-d} ${d}z" fill="#dbeafe" ${st}/><path d="M${x + w} ${y}l${d} ${-d}v${h}l${-d} ${d}z" fill="#60a5fa" ${st}/>`;
    o += `<path d="M${x + d} ${y - d + h}v${-h}M${x + d} ${y - d + h}h${w}M${x + d} ${y - d + h}l${-d} ${d}" stroke="${LINE}" stroke-width="1.6" stroke-dasharray="6 5" fill="none"/>`;
    if (v.a) o += T(x + w / 2, y + h + 16, v.a, { fs: 15, c: v.a.includes('?') ? QC : INK });
    if (v.b) o += T(x + w + d / 2 + 22, y + h - d / 2 + 4, v.b, { fs: 15, a: 'start', c: v.b.includes('?') ? QC : INK });
    if (v.c) o += T(x - 8, y + h / 2, v.c, { fs: 15, a: 'end', c: v.c.includes('?') ? QC : INK });
    const left = v.c ? Math.max(0, String(v.c).length * 9 - x + 14) : 0;
    return V.svg(x + w + d + 90 + left, y + h + 30, `<g transform="translate(${left} 0)">${o}</g>`, 330);
  };
})();

// 4A, 4B guruhlari (4-sinf: ko‘p xonali sonlar, qo‘shish va ayirish) uchun qo‘shimcha rasm turlari:
//  '4AB-xona'    — sinflar va xonalar jadvali (12 xonagacha): {t:'4AB-xona', d:'4052300' (raqamlar, chapdan o‘ngga), q:[indeks] ("?"), hl:[indeks] (sariq)}
//  '4AB-nur'     — katta sonlar nuri: {t:'4AB-nur', a:340000, b:350000, n:10 (bo‘linmalar soni), lab:[indekslar] (yozuvli bo‘linmalar; yo‘q bo‘lsa a va b),
//                   pts:[{x:347200, lb:'A'}], q:[indeks] (shu bo‘linma ostida "?")}
//  '4AB-model'   — chizma model (Singapur): {t:'4AB-model', rows:[{lb:'Ali', segs:[{v:300,lb:'300'},{v:200,lb:'?',q:1}], tot:'?'}], max}
//  '4AB-tablo'   — hisoblagich (odometr) tablosi: {t:'4AB-tablo', s:'0129999', lb:'km'}
//  '4AB-shkala'  — o‘lchov asbobi shkalasi: {t:'4AB-shkala', a:0, step:2 (kichik bo‘linma qiymati), n:20 (bo‘linmalar), big:5 (har nechta bo‘linmada son), ptr:14 (strelka), unit:'kg'}
//  '4AB-chizgich'— millimetrli chizg‘ich: {t:'4AB-chizgich', cm:10, seg:[mmA, mmB], lb:'?'}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P;
  const F = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  V.ext['4AB-xona'] = (v, V) => {
    const d = [...String(v.d)], k = d.length, cw = 40, gap = 10, CL = ['birlar', 'minglar', 'millionlar', 'milliardlar'], PL = ['yuz', 'o‘n', 'bir'];
    const ncl = Math.ceil(k / 3), first = k - (ncl - 1) * 3; let o = '', x = 4;
    const cols = []; // har ustun: x, sinf, xona
    for (let i = 0; i < k; i++) { const fromR = k - 1 - i, cls = Math.floor(fromR / 3), pl = 2 - fromR % 3; if (i && fromR % 3 === 2) x += gap; cols.push({ x, cls, pl }); x += cw }
    const W = x + 4, y1 = 4, y2 = 34, y3 = 60, h3 = 46;
    const CC = ['#bbf7d0', '#fde68a', '#bfdbfe', '#fbcfe8'];
    for (let c = 0; c < ncl; c++) {
      const cs = cols.filter(z => z.cls === c); const x0 = cs[0].x, x1 = cs[cs.length - 1].x + cw;
      o += `<rect x="${x0}" y="${y1}" width="${x1 - x0}" height="26" rx="6" fill="${CC[c]}"/>` + V.T((x0 + x1) / 2, y1 + 13, cs.length < 2 ? ['bir.', 'ming', 'mln', 'mlrd'][c] : CL[c], { fs: 12 });
    }
    cols.forEach((z, i) => {
      o += `<rect x="${z.x}" y="${y2}" width="${cw}" height="22" fill="#eff6ff" stroke="#bfdbfe"/>` + V.T(z.x + cw / 2, y2 + 11, PL[z.pl], { fs: 11, c: '#475569' });
      const q = (v.q || []).includes(i), hl = (v.hl || []).includes(i);
      o += `<rect x="${z.x}" y="${y3}" width="${cw}" height="${h3}" fill="${q ? '#fff7d6' : hl ? '#fde68a' : '#fff'}" stroke="${q ? P.gold : '#93c5fd'}" stroke-width="2"${q ? ' stroke-dasharray="5 3"' : ''}/>`;
      o += V.T(z.x + cw / 2, y3 + h3 / 2, q ? '?' : d[i], { fs: 24, c: q ? '#b45309' : P.ink });
    });
    return V.svg(W, y3 + h3 + 4, o, Math.min(W * 1.15, 560));
  };

  V.ext['4AB-nur'] = (v, V) => {
    const a = v.a, b = v.b, n = v.n || 10, W = 560, L = 56, R = W - 56, y = 70, u = (R - L) / n, X = x => L + (x - a) / (b - a) * (R - L);
    let o = `<line x1="${L - 18}" y1="${y}" x2="${R + 20}" y2="${y}" stroke="${P.line}" stroke-width="3"/><path d="M${R + 24} ${y}l-10 -6v12z" fill="${P.line}"/>`;
    const lab = v.lab || [0, n];
    for (let i = 0; i <= n; i++) {
      const xx = L + i * u, big = lab.includes(i);
      o += `<line x1="${xx}" y1="${y - (big ? 10 : 6)}" x2="${xx}" y2="${y + (big ? 10 : 6)}" stroke="${P.line}" stroke-width="${big ? 2.5 : 1.5}"/>`;
      if (big) o += V.T(xx, y + 30, F(a + (b - a) / n * i), { fs: 20 });
      if ((v.q || []).includes(i)) o += `<rect x="${xx - 16}" y="${y + 14}" width="32" height="26" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + V.T(xx, y + 27, '?', { fs: 16, c: '#b45309' });
    }
    (v.pts || []).forEach(p => { o += `<path d="M${X(p.x)} ${y - 9}l-7 -14h14z" fill="${p.c || P.red}"/><circle cx="${X(p.x)}" cy="${y}" r="6" fill="${p.c || P.red}" stroke="#fff" stroke-width="2"/>`; if (p.lb) o += V.T(Math.min(Math.max(X(p.x), 50), W - 50), y - 36, p.lb, { fs: 20, c: p.c || P.red, st: 1 }) });
    return V.svg(W, 112, o);
  };

  V.ext['4AB-model'] = (v, V) => {
    const rows = v.rows, LW = rows.some(r => r.lb) ? 104 : 4, W = 540, bw = W - LW - 10, rh = 46, tH = 38;
    const max = v.max || Math.max(...rows.map(r => r.segs.reduce((s, z) => s + z.v, 0)));
    const sc = bw / max; let o = '', y = 4;
    rows.forEach((r, i) => {
      if (r.tot) y += tH;
      let x = LW; const y0 = y;
      if (r.lb) o += V.T(LW - 8, y0 + rh / 2, r.lb, { fs: 17, a: 'end' });
      const ws = r.segs.map(s => s.v * sc), need = r.segs.map(s => s.lb ? String(s.lb).length * 10.5 + 14 : 6), tot = ws.reduce((a, b) => a + b, 0);
      { const tight = ws.map((w, j) => w < need[j]), nSum = need.reduce((a, n, j) => a + (tight[j] ? n : 0), 0), rest = ws.reduce((a, w, j) => a + (tight[j] ? 0 : w), 0);
        if (tight.some(Boolean) && rest > 0 && tot - nSum > 0) { const k = (tot - nSum) / rest; if (ws.every((w, j) => tight[j] || w * k >= need[j])) ws.forEach((w, j) => { ws[j] = tight[j] ? need[j] : w * k }) } }
      r.segs.forEach((s, j) => {
        const w = ws[j];
        o += s.q ? `<rect x="${x}" y="${y0}" width="${w}" height="${rh}" rx="4" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="6 4"/>`
          : `<rect x="${x}" y="${y0}" width="${w}" height="${rh}" rx="4" fill="${s.c || P.fills[(i * 2 + j) % 7]}" stroke="#1e3a8a" stroke-width="2"/>`;
        if (s.lb) o += V.T(x + w / 2, y0 + rh / 2, s.lb, { fs: 18, c: s.q ? '#b45309' : P.ink, st: 1 });
        x += w;
      });
      if (r.tot) { const xe = x, yb = y0 - 6; o += `<path d="M${LW + 1} ${yb}v-8H${xe - 1}v8" fill="none" stroke="${P.ink}" stroke-width="2"/>` + V.T((LW + xe) / 2, yb - 20, r.tot, { fs: 19, c: r.tot === '?' ? '#b45309' : P.ink, st: 1 }) }
      y += rh + 14;
    });
    return V.svg(W, y - 8, o);
  };

  V.ext['4AB-tablo'] = (v, V) => {
    const s = [...String(v.s)], cw = 38, ch = 54, W = s.length * (cw + 4) + 16 + (v.lb ? 50 : 0); let o = `<rect x="0" y="0" width="${W}" height="${ch + 16}" rx="12" fill="#1e293b"/>`;
    s.forEach((c, i) => { const x = 8 + i * (cw + 4); o += `<rect x="${x}" y="8" width="${cw}" height="${ch}" rx="5" fill="#f8fafc"/><line x1="${x}" y1="${8 + ch / 2}" x2="${x + cw}" y2="${8 + ch / 2}" stroke="#cbd5e1"/>` + V.T(x + cw / 2, 8 + ch / 2 + 1, c, { fs: 30, c: c === '?' ? '#b45309' : '#0f172a' }) });
    if (v.lb) o += V.T(W - 28, (ch + 16) / 2, v.lb, { fs: 18, c: '#fde68a' });
    return V.svg(W, ch + 16, o, Math.min(W * 1.05, 520));
  };

  V.ext['4AB-shkala'] = (v, V) => {
    const n = v.n, big = v.big || 5, W = 560, L = 40, R = W - 40, u = (R - L) / n, y = 50; let o = `<rect x="${L - 18}" y="${y - 6}" width="${R - L + 36}" height="70" rx="10" fill="#f1f5f9" stroke="#94a3b8" stroke-width="2"/>`;
    for (let i = 0; i <= n; i++) {
      const xx = L + i * u, bg = i % big === 0;
      o += `<line x1="${xx}" y1="${y - 6}" x2="${xx}" y2="${y + (bg ? 22 : 12)}" stroke="${P.line}" stroke-width="${bg ? 2.5 : 1.4}"/>`;
      if (bg) o += V.T(xx, y + 42, F(v.a + i * v.step), { fs: 20 });
    }
    if (v.ptr != null) { const xx = L + (v.ptr - v.a) / v.step * u; o += `<path d="M${xx} ${y + 10}L${xx - 9} ${y - 24}H${xx + 9}z" fill="${P.red}" stroke="#7f1d1d" stroke-width="1.5"/>` }
    if (v.unit) o += V.T(W - 6, 14, v.unit, { fs: 19, a: 'end', c: '#475569' });
    if (v.title) o += V.T(8, 14, v.title, { fs: 14, a: 'start', c: '#475569' });
    return V.svg(W, y + 72, o);
  };

  V.ext['4AB-chizgich'] = (v, V) => {
    const cm = v.cm, u = Math.min(4.4, 500 / (cm * 10)), L = 18, W = L * 2 + cm * 10 * u; let o = `<rect x="4" y="44" width="${W - 8}" height="54" rx="8" fill="#fde68a" stroke="#d97706" stroke-width="2"/>`;
    for (let i = 0; i <= cm * 10; i++) { const xx = L + i * u, c = i % 10 === 0, h = i % 5 === 0; o += `<line x1="${xx}" y1="44" x2="${xx}" y2="${44 + (c ? 20 : h ? 13 : 8)}" stroke="#78350f" stroke-width="${c ? 1.8 : 1}"/>`; if (c) o += V.T(xx, 82, i / 10, { fs: 17, c: '#78350f' }) }
    if (v.seg) { const [a, b] = v.seg; o += `<line x1="${L + a * u}" y1="26" x2="${L + b * u}" y2="26" stroke="${P.blue}" stroke-width="7" stroke-linecap="butt"/><line x1="${L + a * u}" y1="16" x2="${L + a * u}" y2="44" stroke="${P.ink}" stroke-width="1.5" stroke-dasharray="3 2"/><line x1="${L + b * u}" y1="16" x2="${L + b * u}" y2="44" stroke="${P.ink}" stroke-width="1.5" stroke-dasharray="3 2"/>`; if (v.lb) o += V.T(L + (a + b) / 2 * u, 9, v.lb, { fs: 14 }) }
    return V.svg(W, 104, o);
  };
})();

// 4C guruhi (4-sinf: ko‘paytirish va bo‘lish) uchun qo‘shimcha rasm turlari.
//  '4C-ifoda' — uzun ifoda, sonlar bo‘linib ketmaydi, shrift uzunlikka qarab kichrayadi: {s:'12 345 · 6 = ☐'} ('?' va ☐ — bo‘sh katak)
//  '4C-model' — chizma model: {rows:[{lb:'1-kun', n:3, s:'1 248', rem:'?'}], rt:['= ?'], tot:'jami ?'}
//               har qator n ta teng bo‘lak (har birida s yozuvi), rem — oxirida "ortib qolgan" sariq bo‘lak, rt — qator o‘ngidagi yozuv, tot — pastdagi qavs yozuvi
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, Q = '#fff7d6', QS = '#f5b301', QC = '#b45309';
  const F = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  V.ext['4C-ifoda'] = v => {
    const s = String(v.s), L = s.length, fs = v.fs || (L <= 14 ? 28 : L <= 19 ? 25 : L <= 24 ? 22 : L <= 30 ? 19 : 17);
    const bx = q => `<i class="bx" style="min-width:${Math.round(fs * 1.1)}px;height:${Math.round(fs * 1.25)}px;line-height:${Math.round(fs * 1.25)}px;font-size:${Math.round(fs * .8)}px">${q}</i>`;
    // sonlar ichidagi bo‘shliqni bo‘linmaydigan qilamiz, amal belgilari atrofida bo‘linishi mumkin
    const tok = V.esc(s).replace(/(\d) (?=\d{3}(?!\d))/g, '$1 ').replace(/☐/g, bx('')).replace(/\?/g, bx('?'));
    return `<div class="vx" style="font-size:${fs}px;letter-spacing:0;line-height:1.5;word-spacing:1px">${tok}</div>`;
  };

  V.ext['4C-model'] = v => {
    const rows = v.rows, hasLb = rows.some(r => r.lb);
    const L = hasLb ? Math.max(...rows.map(r => String(r.lb || '').length)) * 9 + 14 : 6;
    const rtw = Math.max(8, ...(v.rt || []).map(x => x ? String(x).length * 9.5 + 14 : 0));
    const mx = Math.max(...rows.map(r => r.n + (r.rem ? 0.7 : 0)));
    const u = Math.min(70, (360 - L - rtw) / mx), rh = 38, gap = 14; let o = '', y = 6;
    const top = rows.some(r => r.s != null && !r.all && F(r.s).length * 9 > u - 4) ? 18 : 0; y += top;
    rows.forEach((r, i) => {
      if (i && top) y += top;
      if (r.lb) o += T(L - 8, y + rh / 2, r.lb, { fs: 15, a: 'end' });
      for (let k = 0; k < r.n; k++) {
        const q = r.s === '?' && k === 0, show = r.s != null && (k === 0 || r.all);
        o += `<rect x="${L + k * u}" y="${y}" width="${u}" height="${rh}" rx="3" fill="${q ? Q : P.fills[i % 7] + '55'}" stroke="#1e3a8a" stroke-width="2"/>`;
        if (show) { const t = F(r.s), fs = t.length > 6 ? 12 : t.length > 4 ? 14 : 16; if (t.length * fs * 0.62 > u - 4 && !r.all) o += T(L + k * u + 2, y - 9, t, { fs: 14, a: 'start', c: r.s === '?' ? QC : P.ink }); else o += T(L + k * u + u / 2, y + rh / 2, t, { fs: t.length * fs * 0.62 > u - 4 ? 11 : fs, c: r.s === '?' ? QC : P.ink }) }
      }
      let xe = L + r.n * u;
      if (r.rem) { const w = u * 0.7; o += `<rect x="${xe + 3}" y="${y}" width="${w}" height="${rh}" rx="3" fill="${Q}" stroke="${QS}" stroke-width="2" stroke-dasharray="5 3"/>` + T(xe + 3 + w / 2, y + rh / 2, F(r.rem), { fs: 13, c: QC }); xe += w + 3 }
      if (v.rt && v.rt[i]) o += T(xe + 7, y + rh / 2, F(v.rt[i]), { fs: 15, a: 'start', c: String(v.rt[i]).includes('?') ? QC : P.ink });
      y += rh + gap;
    });
    let H = y - gap + 6;
    if (v.tot) {
      const x1 = L, x2 = L + Math.max(...rows.map(r => r.n)) * u, yb = y - gap + 6;
      o += `<path d="M${x1} ${yb}q0 10 10 10H${(x1 + x2) / 2 - 8}l8 8l8 -8H${x2 - 10}q10 0 10 -10" fill="none" stroke="${P.blue}" stroke-width="2.5"/>`;
      o += T((x1 + x2) / 2, yb + 34, F(v.tot), { fs: 16, c: String(v.tot).includes('?') ? QC : P.blue });
      H = yb + 46;
    }
    const W = L + mx * u + rtw + 6;
    return V.svg(W, H, o, Math.min(W * 1.15, 400));
  };

})();

// 4D (ifodalar, tenglamalar) va 4I (ma’lumotlar) uchun qo‘shimcha rasm turlari. Turlar nomi '4DI-' bilan boshlanadi.
// Hamma SVG eni ~340 birlik: telefonda (karta ichi ~338 px) deyarli 1:1 chiqadi, yozuvlar 15–17 px (kamida 14 px).
//  '4DI-bar'   — ustunli diagramma: {lb:[], val:[] | ser:[{nm,val,c}], step, max, title, unit, showv, hide:[i] ('?' ustun)}
//  '4DI-hbar'  — chiziqli diagramma (gorizontal tasmalar): {lb:[], val:[], step, max, title, unit, showv, hide:[i]}
//  '4DI-line'  — grafik (siniq chiziq): {lb:[x yozuvlari], val:[] | ser:[{nm,val,c}], step, min, max, title, xt, yt, showv, q:[i] ('?' nuqta)}
//  '4DI-pie'   — doiraviy diagramma: {parts:[{lb, w, t, c}], den, title, ticks:true} — w: bo‘lak og‘irligi (den ning qismi)
//  '4DI-pies'  — bir nechta kichik doiraviy diagramma: {l:[{parts:[{w}], lb:'A'}], den, names:[...] (umumiy rang izohi)}
//  '4DI-venn'  — Venn diagrammasi: {sets:[{lb},{lb}(,{lb})], r:{a,b,ab,o | a,b,c,ab,ac,bc,abc,o}, title} — r qiymatlari matn yoki ro‘yxat
//  '4DI-tally' — chiziqchalar (chastota) jadvali: {h:[3 sarlavha], rows:[{lb, n, f ('?'|son|'' — chastota katagi)}]}
//  '4DI-dot'   — nuqtali diagramma: {a, b, cnt:{qiymat: soni}, xt, title}
//  '4DI-model' — chizma model (tasmalar): {rows:[{lb, parts:[{w, t, c, dash}]}], tot:'540', top:{t, row, from, to}}
//  '4DI-ifoda' — ifoda, amallar ustida tartib raqamlari: {s:'…', ord:[1,3,2] | null, hl:[amal indekslari]}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, svg = V.svg, esc = V.esc;
  const f1 = x => +(+x).toFixed(1);
  const T = (x, y, s, o = {}) => V.T(f1(x), f1(y), s, Object.assign({ fs: 15 }, o));
  const COL = ['#60a5fa', '#f59e0b', '#34d399', '#f472b6', '#a78bfa', '#fb923c', '#2dd4bf', '#f87171'];
  const W = 340;
  const ticks = (max, step) => { const top = Math.ceil(max / step) * step; const a = []; for (let y = 0; y <= top; y += step) a.push(y); return a };
  const nice = m => [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000].find(s => m / s <= 6) || 20000;
  const fmtN = n => { n = String(n); return n.length >= 5 ? n.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : n };

  // ---------- ustunli diagramma
  V.ext['4DI-bar'] = v => {
    const ser = v.ser || [{ val: v.val, c: null }], n = v.lb.length, k = ser.length;
    const all = ser.flatMap(s => s.val), max = v.max || Math.max(...all), step = v.step || nice(max), tk = ticks(max, step), top = tk[tk.length - 1];
    const lw = Math.max(...tk.map(t => String(fmtN(t)).length)) * 9 + 14, L = Math.max(34, lw), Tp = (v.title ? 34 : 16) + (v.unit ? 14 : 0), H = 170, ev = tk.length > 11 ? 2 : 1, B = Tp + H, R = W - 8;
    const gap = (R - L) / n, bw = Math.min(k > 1 ? 24 : 40, gap * .72 / k); let o = '';
    if (v.title) o += T(W / 2, 13, v.title, { fs: 16 });
    if (v.unit) o += T(4, Tp - 20, v.unit, { a: 'start', fs: 14, c: '#475569' });
    tk.forEach((t, i) => { const y = B - t / top * H; o += `<line x1="${L}" y1="${f1(y)}" x2="${R}" y2="${f1(y)}" stroke="#cbd5e1" stroke-width="1.3"/>` + (i % ev ? '' : T(L - 6, y, fmtN(t), { a: 'end' })) });
    if (v.half) tk.slice(1).forEach(t => { const y = B - (t - step / 2) / top * H; o += `<line x1="${L}" y1="${f1(y)}" x2="${R}" y2="${f1(y)}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="4 4"/>` });
    for (let i = 0; i < n; i++) {
      const cx = L + gap * (i + .5);
      ser.forEach((s, j) => {
        const x = cx - bw * k / 2 + j * bw, val = s.val[i], h = val / top * H, c = s.c || (k > 1 ? COL[j] : (v.c && v.c[i]) || COL[i % 8]);
        if ((v.hide || []).includes(i) && k === 1) { o += `<rect x="${f1(x + 2)}" y="${B - H * .35}" width="${f1(bw - 4)}" height="${H * .35}" rx="5" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="6 4"/>` + T(x + bw / 2, B - H * .175, '?', { fs: 20, c: '#b45309' }); return }
        o += `<rect x="${f1(x + 1)}" y="${f1(B - h)}" width="${f1(bw - 2)}" height="${f1(h)}" rx="4" fill="${c}" stroke="#1e3a8a" stroke-width="1.2"/>`;
        if (v.showv) o += T(x + bw / 2, B - h - 10, fmtN(val), { fs: 15, st: 1 });
      });
      o += T(cx, B + 15, v.lb[i], { fs: 15 });
    }
    o += `<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/><line x1="${L}" y1="${B}" x2="${L}" y2="${Tp - 6}" stroke="${P.line}" stroke-width="2.5"/>`;
    let Hh = B + 30;
    if (k > 1) { let x = L; ser.forEach((s, j) => { o += `<rect x="${x}" y="${Hh}" width="16" height="16" rx="3" fill="${s.c || COL[j]}" stroke="#1e3a8a" stroke-width="1"/>` + T(x + 22, Hh + 8, s.nm, { a: 'start' }); x += 32 + s.nm.length * 9 }); Hh += 24 }
    return svg(W, Hh, o);
  };

  // ---------- chiziqli diagramma (gorizontal)
  V.ext['4DI-hbar'] = v => {
    const n = v.lb.length, max = v.max || Math.max(...v.val), step = v.step || nice(max), tk = ticks(max, step), top = tk[tk.length - 1];
    const L = Math.min(118, Math.max(...v.lb.map(s => s.length)) * 9 + 14), R = W - 18, Tp = (v.title ? 30 : 4) + 22, rh = 34; let o = '';
    if (v.title) o += T(W / 2, 13, v.title, { fs: 16 });
    const X = x => L + x / top * (R - L), B = Tp + n * rh + 4;
    const lwid = Math.max(...tk.map(t => String(fmtN(t)).length)) * 8.5 + 3, gapx = (R - L) / (tk.length - 1), ev = Math.ceil(lwid / gapx);
    tk.forEach((t, i) => { o += `<line x1="${f1(X(t))}" y1="${Tp - 4}" x2="${f1(X(t))}" y2="${B}" stroke="#cbd5e1" stroke-width="1.3"/>` + (i % ev ? '' : T(X(t), Tp - 15, fmtN(t), { fs: 15 })) });
    if (v.half) tk.slice(1).forEach(t => o += `<line x1="${f1(X(t - step / 2))}" y1="${Tp - 4}" x2="${f1(X(t - step / 2))}" y2="${B}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="4 4"/>`);
    v.lb.forEach((l, i) => {
      const y = Tp + 6 + i * rh, c = (v.c && v.c[i]) || COL[i % 8];
      o += T(L - 8, y + 11, l, { a: 'end' });
      if ((v.hide || []).includes(i)) o += `<rect x="${L}" y="${y}" width="${f1((R - L) * .3)}" height="22" rx="5" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="6 4"/>` + T(L + (R - L) * .15, y + 11, '?', { fs: 18, c: '#b45309' });
      else { o += `<rect x="${L}" y="${y}" width="${f1(X(v.val[i]) - L)}" height="22" rx="5" fill="${c}" stroke="#1e3a8a" stroke-width="1.2"/>`; if (v.showv) o += T(X(v.val[i]) + 6, y + 11, fmtN(v.val[i]), { a: 'start', st: 1 }) }
    });
    o += `<line x1="${L}" y1="${Tp - 4}" x2="${L}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/>`;
    let Hh = B + 6; if (v.unit) { o += T(R, Hh + 10, v.unit, { a: 'end', fs: 14, c: '#475569' }); Hh += 22 }
    return svg(W, Hh, o);
  };

  // ---------- grafik (siniq chiziq)
  V.ext['4DI-line'] = v => {
    const ser = v.ser || [{ val: v.val }], n = v.lb.length, all = ser.flatMap(s => s.val).filter(y => y != null);
    const mn = v.min || 0, max = v.max || Math.max(...all), step = v.step || nice(max - mn);
    const tk = []; for (let y = mn; y <= Math.ceil((max - mn) / step) * step + mn; y += step) tk.push(y); const top = tk[tk.length - 1];
    const L = Math.max(...tk.map(t => String(t).length)) * 9 + 16, R = W - 14, Tp = (v.title ? 34 : 14) + (v.yt ? 18 : 0), H = 170, B = Tp + H, ev = tk.length > 11 ? 2 : 1; let o = '';
    if (v.title) o += T(W / 2, 13, v.title, { fs: 16 });
    if (v.yt) o += T(4, Tp - 20, v.yt, { a: 'start', fs: 14, c: '#475569' });
    const X = i => L + 14 + i * (R - L - 28) / (n - 1), Y = y => B - (y - mn) / (top - mn) * H;
    tk.forEach((t, i) => o += `<line x1="${L}" y1="${f1(Y(t))}" x2="${R}" y2="${f1(Y(t))}" stroke="#cbd5e1" stroke-width="1.3"/>` + (i % ev ? '' : T(L - 6, Y(t), t, { a: 'end' })));
    if (v.half) tk.slice(1).forEach(t => o += `<line x1="${L}" y1="${f1(Y(t - step / 2))}" x2="${R}" y2="${f1(Y(t - step / 2))}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="4 4"/>`);
    for (let i = 0; i < n; i++) o += `<line x1="${f1(X(i))}" y1="${Tp - 4}" x2="${f1(X(i))}" y2="${B}" stroke="#e2e8f0" stroke-width="1.3"/>` + T(X(i), B + 15, v.lb[i]);
    o += `<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/><line x1="${L}" y1="${B}" x2="${L}" y2="${Tp - 8}" stroke="${P.line}" stroke-width="2.5"/>`;
    ser.forEach((s, j) => {
      const c = s.c || [P.blue, '#ea580c', P.green][j];
      // null — yashirilgan nuqta: chiziq uziladi, o‘rniga '?' belgisi
      const runs = [[]]; s.val.forEach((y, i) => { if (y == null) runs.push([]); else runs[runs.length - 1].push(f1(X(i)) + ',' + f1(Y(y))) });
      runs.filter(r => r.length > 1).forEach(r => o += `<polyline points="${r.join(' ')}" fill="none" stroke="${c}" stroke-width="3.5" stroke-linejoin="round"${j === 1 ? ' stroke-dasharray="9 5"' : ''}/>`);
      s.val.forEach((y, i) => { if (y == null) { o += `<rect x="${f1(X(i) - 14)}" y="${f1(B - H / 2 - 14)}" width="28" height="28" rx="7" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.5" stroke-dasharray="5 3"/>` + T(X(i), B - H / 2, '?', { fs: 18, c: '#b45309' }); return }
        o += `<circle cx="${f1(X(i))}" cy="${f1(Y(y))}" r="5.5" fill="${c}" stroke="#fff" stroke-width="2"/>`; if (v.showv) o += T(X(i), Y(y) - 15, y, { st: 1 }) });
    });
    (v.q || []).forEach(i => { const s = ser[0]; o += `<circle cx="${f1(X(i))}" cy="${f1(Y(s.val[i]))}" r="10" fill="none" stroke="${P.red}" stroke-width="3"/>` });
    let Hh = B + 30;
    if (v.xt) { o += T(R, Hh + 2, v.xt, { a: 'end', fs: 14, c: '#475569' }); Hh += 18 }
    if (ser.length > 1) { let x = L; ser.forEach((s, j) => { const c = s.c || [P.blue, '#ea580c', P.green][j]; o += `<line x1="${x}" y1="${Hh + 8}" x2="${x + 24}" y2="${Hh + 8}" stroke="${c}" stroke-width="3.5"${j === 1 ? ' stroke-dasharray="7 4"' : ''}/>` + T(x + 30, Hh + 8, s.nm, { a: 'start' }); x += 44 + s.nm.length * 9 }); Hh += 24 }
    return svg(W, Hh, o);
  };

  // ---------- doiraviy diagramma
  const pieBody = (cx, cy, r, parts, den, tks, showT) => {
    let o = '', a = -Math.PI / 2;
    parts.forEach((p, i) => {
      const b = a + p.w / den * 2 * Math.PI, c = p.c || COL[i % 8];
      if (p.w >= den) o += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${c}"/>`;
      else o += `<path d="M${cx} ${cy}L${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}A${r} ${r} 0 ${b - a > Math.PI ? 1 : 0} 1 ${f1(cx + r * Math.cos(b))} ${f1(cy + r * Math.sin(b))}Z" fill="${c}"/>`;
      p._m = (a + b) / 2; a = b;
    });
    if (tks) for (let k = 0; k < den; k++) { const t = -Math.PI / 2 + k / den * 2 * Math.PI; o += `<line x1="${cx}" y1="${cy}" x2="${f1(cx + r * Math.cos(t))}" y2="${f1(cy + r * Math.sin(t))}" stroke="#ffffff" stroke-width="1.3" stroke-dasharray="4 3"/>` }
    a = -Math.PI / 2;
    parts.forEach(p => { if (p.w < den) o += `<line x1="${cx}" y1="${cy}" x2="${f1(cx + r * Math.cos(a))}" y2="${f1(cy + r * Math.sin(a))}" stroke="#1e3a8a" stroke-width="2.2"/>`; a += p.w / den * 2 * Math.PI });
    o += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#1e3a8a" stroke-width="2.5"/>`;
    if (showT) parts.forEach(p => { if (p.t != null && p.t !== '') { const rr = p.w / den <= 1 / 8 ? r * .68 : r * .58; o += T(cx + rr * Math.cos(p._m), cy + rr * Math.sin(p._m), p.t, { fs: 16, st: 1 }) } });
    return o;
  };
  V.ext['4DI-pie'] = v => {
    const den = v.den || v.parts.reduce((s, p) => s + p.w, 0), Tp = v.title ? 30 : 6, r = 84, cx = 96, cy = Tp + r + 4; let o = '';
    if (v.title) o += T(W / 2, 13, v.title, { fs: 16 });
    o += pieBody(cx, cy, r, v.parts, den, v.ticks, true);
    const lh = 30, y0 = cy - (v.parts.length * lh) / 2 + lh / 2;
    v.parts.forEach((p, i) => { const y = y0 + i * lh; o += `<rect x="198" y="${f1(y - 9)}" width="18" height="18" rx="4" fill="${p.c || COL[i % 8]}" stroke="#1e3a8a" stroke-width="1.2"/>` + T(222, y, p.lb, { a: 'start' }) });
    return svg(W, cy + r + 8, o);
  };
  V.ext['4DI-pies'] = v => {
    const den = v.den, m = v.l.length, cw = W / 2, r = 58, rh = 2 * r + 34; let o = '';
    v.l.forEach((e, i) => { const cx = cw * (i % 2) + cw / 2, cy = Math.floor(i / 2) * rh + r + 6; o += pieBody(cx, cy, r, e.parts.map(p => Object.assign({}, p)), den, v.ticks, false) + T(cx, cy + r + 16, e.lb, { fs: 17, c: P.red }) });
    let Hh = Math.ceil(m / 2) * rh + 4;
    if (v.names) { let x = 8, y = Hh + 8; v.names.forEach((nm, j) => { const w = 34 + nm.length * 9; if (x + w > W) { x = 8; y += 24 } o += `<rect x="${x}" y="${y - 8}" width="16" height="16" rx="3" fill="${COL[j % 8]}" stroke="#1e3a8a" stroke-width="1"/>` + T(x + 22, y, nm, { a: 'start' }); x += w }); Hh = y + 16 }
    return svg(W, Hh, o);
  };

  // ---------- Venn diagrammasi
  const lines = (s, per) => { const a = String(s).split(/\s*,\s*/).filter(x => x !== ''); const out = []; for (let i = 0; i < a.length; i += per) out.push(a.slice(i, i + per).join(', ')); return out };
  const block = (x, y, s, per, o2 = {}) => { if (s == null || s === '') return ''; const L = lines(s, per), lh = 19; return L.map((l, i) => T(x, y - (L.length - 1) * lh / 2 + i * lh, l, Object.assign({ fs: 16 }, o2))).join('') };
  V.ext['4DI-venn'] = v => {
    const r = v.r || {}, three = v.sets.length === 3; let o = '';
    const qc = s => String(s).trim() === '?' ? { c: '#b45309', fs: 20 } : {};
    if (!three) {
      const H = 236, R = 86, c1 = 124, c2 = 216, cy = 132;
      o += `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="12" fill="#f8fafc" stroke="#64748b" stroke-width="2"/>`;
      if (v.title) o += T(W / 2, 17, v.title, { fs: 15, c: '#475569' });
      o += `<circle cx="${c1}" cy="${cy}" r="${R}" fill="#60a5fa40" stroke="#2563eb" stroke-width="2.5"/><circle cx="${c2}" cy="${cy}" r="${R}" fill="#f59e0b40" stroke="#d97706" stroke-width="2.5"/>`;
      o += T(c1 - 30, cy - R - 10, v.sets[0].lb, { c: '#1d4ed8', fs: 16, st: 1 }) + T(c2 + 30, cy - R - 10, v.sets[1].lb, { c: '#b45309', fs: 16, st: 1 });
      o += block(c1 - 44, cy, r.a, 2, qc(r.a)) + block(170, cy, r.ab, 2, qc(r.ab)) + block(c2 + 44, cy, r.b, 2, qc(r.b));
      if (r.o != null && r.o !== '') { const L = lines(r.o, 1); if (L.length <= 2) o += block(318, H - 30, r.o, 1, qc(r.o)); else { o += block(20, H - 40, L.slice(0, Math.ceil(L.length / 2)).join(', '), 1, qc(r.o)) + block(318, H - 40, L.slice(Math.ceil(L.length / 2)).join(', '), 1) } }
      return svg(W, H, o);
    }
    const H = 300, R = 74, A = [126, 116], Bc = [214, 116], Cc = [170, 190];
    o += `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="12" fill="#f8fafc" stroke="#64748b" stroke-width="2"/>`;
    if (v.title) o += T(W / 2, 17, v.title, { fs: 15, c: '#475569' });
    o += `<circle cx="${A[0]}" cy="${A[1]}" r="${R}" fill="#60a5fa3a" stroke="#2563eb" stroke-width="2.5"/><circle cx="${Bc[0]}" cy="${Bc[1]}" r="${R}" fill="#f59e0b3a" stroke="#d97706" stroke-width="2.5"/><circle cx="${Cc[0]}" cy="${Cc[1]}" r="${R}" fill="#34d3993a" stroke="#059669" stroke-width="2.5"/>`;
    o += T(A[0] - 40, 30, v.sets[0].lb, { c: '#1d4ed8', fs: 16, st: 1 }) + T(Bc[0] + 40, 30, v.sets[1].lb, { c: '#b45309', fs: 16, st: 1 }) + T(Cc[0], H - 16, v.sets[2].lb, { c: '#047857', fs: 16, st: 1 });
    o += block(92, 100, r.a, 1, qc(r.a)) + block(248, 100, r.b, 1, qc(r.b)) + block(170, 228, r.c, 2, qc(r.c));
    o += block(170, 84, r.ab, 1, qc(r.ab)) + block(122, 168, r.ac, 1, qc(r.ac)) + block(218, 168, r.bc, 1, qc(r.bc)) + block(170, 145, r.abc, 1, qc(r.abc));
    if (r.o != null && r.o !== '') o += block(310, H - 26, r.o, 1, qc(r.o));
    return svg(W, H, o);
  };

  // ---------- chiziqchalar (tally) jadvali
  const tally = (x, y, n) => { let o = ''; for (let g = 0; g * 5 < n; g++) { const m = Math.min(5, n - g * 5), gx = x + g * 38; for (let k = 0; k < Math.min(m, 4); k++) o += `<line x1="${gx + k * 7}" y1="${y - 11}" x2="${gx + k * 7}" y2="${y + 11}" stroke="#0b2a6f" stroke-width="2.6" stroke-linecap="round"/>`; if (m === 5) o += `<line x1="${gx - 4}" y1="${y + 8}" x2="${gx + 25}" y2="${y - 8}" stroke="#dc2626" stroke-width="2.6" stroke-linecap="round"/>` } return o };
  V.ext['4DI-tally'] = v => {
    const rows = v.rows, mx = Math.max(...rows.map(r => r.n)), tw = Math.max(110, Math.ceil(mx / 5) * 38 + 10), fw = v.noF ? 0 : Math.max(74, ((v.h || [])[2] || 'Soni').length * 9.5 + 14), lw = W - 4 - tw - fw, rh = 36, hh = 32; let o = '';
    const Hh = hh + rows.length * rh;
    o += `<rect x="2" y="2" width="${W - 4}" height="${Hh}" rx="10" fill="#fff" stroke="#93c5fd" stroke-width="2"/><rect x="2" y="2" width="${W - 4}" height="${hh}" rx="10" fill="#dbeafe"/><rect x="2" y="${hh - 8}" width="${W - 4}" height="10" fill="#dbeafe"/>`;
    const h = v.h || ['', 'Chiziqchalar', 'Soni'];
    o += T(2 + lw / 2, 2 + hh / 2, h[0]) + T(2 + lw + tw / 2, 2 + hh / 2, h[1]) + (fw ? T(2 + lw + tw + fw / 2, 2 + hh / 2, h[2]) : '');
    rows.forEach((r, i) => {
      const y = 2 + hh + i * rh;
      o += `<line x1="2" y1="${y}" x2="${W - 2}" y2="${y}" stroke="#dbeafe" stroke-width="1.5"/>` + T(10, y + rh / 2, r.lb, { a: 'start' }) + tally(2 + lw + 12, y + rh / 2, r.n);
      if (fw) { const f = r.f == null ? String(r.n) : String(r.f); o += f === '?' ? `<rect x="${2 + lw + tw + fw / 2 - 15}" y="${y + 5}" width="30" height="26" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + T(2 + lw + tw + fw / 2, y + rh / 2, '?', { c: '#b45309', fs: 17 }) : T(2 + lw + tw + fw / 2, y + rh / 2, f, { fs: 16 }) }
    });
    o += `<line x1="${2 + lw}" y1="2" x2="${2 + lw}" y2="${Hh + 2}" stroke="#93c5fd" stroke-width="1.5"/>` + (fw ? `<line x1="${2 + lw + tw}" y1="2" x2="${2 + lw + tw}" y2="${Hh + 2}" stroke="#93c5fd" stroke-width="1.5"/>` : '');
    return svg(W, Hh + 4, o);
  };

  // ---------- nuqtali diagramma
  V.ext['4DI-dot'] = v => {
    const a = v.a, b = v.b, n = b - a, L = 22, R = W - 22, u = (R - L) / n, mx = Math.max(1, ...Object.values(v.cnt)), Tp = v.title ? 30 : 8, B = Tp + mx * 22 + 10; let o = '';
    if (v.title) o += T(W / 2, 13, v.title, { fs: 16 });
    o += `<line x1="${L - 8}" y1="${B}" x2="${R + 8}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/>`;
    for (let x = a; x <= b; x++) { const X = L + (x - a) * u; o += `<line x1="${f1(X)}" y1="${B - 6}" x2="${f1(X)}" y2="${B + 6}" stroke="${P.line}" stroke-width="2"/>` + T(X, B + 18, x, { fs: 16 }); for (let k = 0; k < (v.cnt[x] || 0); k++) o += `<circle cx="${f1(X)}" cy="${B - 16 - k * 22}" r="8.5" fill="${P.blue}" stroke="#1e3a8a" stroke-width="1.2"/>` }
    let Hh = B + 32; if (v.xt) { o += T(W / 2, Hh + 2, v.xt, { fs: 14, c: '#475569' }); Hh += 18 }
    return svg(W, Hh, o);
  };

  // ---------- chizma model (tasmalar)
  V.ext['4DI-model'] = v => {
    const rows = v.rows, L = Math.max(...rows.map(r => r.lb.length)) * 9 + 14, totW = v.tot ? 66 : 8, Rx = W - totW, tot = Math.max(...rows.map(r => r.parts.reduce((s, p) => s + p.w, 0))), u = (Rx - L) / tot, rh = 44, Tp = v.top ? 30 : 6; let o = '';
    rows.forEach((r, i) => {
      const y = Tp + i * rh; let x = L; o += T(L - 8, y + 16, r.lb, { a: 'end' });
      r.parts.forEach((p, j) => { const w = p.w * u; o += `<rect x="${f1(x)}" y="${y}" width="${f1(w)}" height="32" fill="${p.dash ? '#fff7d6' : p.c || COL[i % 8] + '99'}" stroke="${p.dash ? P.gold : '#1e3a8a'}" stroke-width="2"${p.dash ? ' stroke-dasharray="6 4"' : ''}/>`; if (p.t) o += T(x + w / 2, y + 16, p.t, { fs: 15, c: p.t === '?' ? '#b45309' : P.ink }); x += w });
    });
    if (v.top) { const y = Tp - 6, r = rows[v.top.row || 0]; let x1 = L, x2 = L; r.parts.forEach((p, j) => { if (j < v.top.from) x1 += p.w * u; if (j <= v.top.to) x2 += p.w * u }); o += `<path d="M${f1(x1)} ${y + 2}v-6h${f1(x2 - x1)}v6" fill="none" stroke="${P.red}" stroke-width="2"/>` + T((x1 + x2) / 2, y - 14, v.top.t, { c: P.red, st: 1 }) }
    const Hh = Tp + rows.length * rh - 6;
    if (v.tot) o += `<path d="M${Rx + 4} ${Tp}h6v${Hh - Tp}h-6" fill="none" stroke="${P.red}" stroke-width="2"/>` + T(Rx + 14, (Tp + Hh) / 2, v.tot, { a: 'start', c: P.red, fs: 16 });
    return svg(W, Hh + 6, o);
  };

  // ---------- ifoda: amallar ustida tartib raqamlari
  V.ext['4DI-ifoda'] = v => {
    const tk = v.s.match(/\d[\d\u00a0 ]*\d|\d|[+−·:()=☐?<>]|[a-z]/g) || []; let k = 0; const nr = v.ord ? '<b style="height:28px"></b>' : '';
    const box = 'display:inline-flex;flex-direction:column;align-items:center;margin:0 1px';
    const items = tk.map(t => {
      if ('+−·:'.includes(t)) { const i = k++; const n = v.ord ? v.ord[i] : null, hl = (v.hl || []).includes(i);
        return `<span style="${box}"><b style="display:inline-block;min-width:24px;height:24px;line-height:24px;border-radius:50%;font-size:15px;${!v.ord ? 'display:none' : n != null ? `background:${hl ? '#fde68a' : '#dbeafe'};color:#0b2a6f;border:2px solid ${hl ? '#f59e0b' : '#60a5fa'}` : 'visibility:hidden'}">${n == null ? '0' : esc(n)}</b><span style="padding:0 5px;${hl ? 'color:#dc2626' : ''}">${t}</span></span>` }
      if ('=<>'.includes(t)) return `<span style="${box}">${nr}<span style="padding:0 6px">${esc(t)}</span></span>`;
      if (t === '☐' || t === '?') return `<span style="${box}">${nr}<i class="bx">${t === '?' ? '?' : ''}</i></span>`;
      return `<span style="${box}">${nr}<span>${esc(t.replace(/ /g, ' '))}</span></span>`;
    });
    return `<div style="display:flex;flex-wrap:wrap;justify-content:center;align-items:flex-end;font:900 ${v.s.length > 22 ? 21 : 25}px Nunito,system-ui,sans-serif;color:#0b2a6f;margin:6px 0">${items.join('')}</div>`;
  };
})();

// 4E (4-sinf matnli masalalar) uchun rasm turlari. Hammasi telefon kengligiga (≈340 px) mo‘ljallangan, yozuvlar 14–16 px.
//  '4E-harakat' — harakat sxemasi (yo‘l, jismlar, strelkalar, masofa):
//     {t:'4E-harakat', A:'Toshkent', B:'Samarqand',
//      bodies:[{lb:'Avtobus', v:'60 km/soat', at:0, dir:1, to:0.5, ic:'avto'|'avtobus'|'yuk'|'poyezd'|'odam'|'velo'|'moto', s:'3 soat'}],
//      meet:{x:0.6, s:'?'}, br:[{a:0, b:1, s:'360 km', lv:0}], cap:'...'}
//     at/to/meet.x/br.a/b — yo‘l bo‘yicha ulush (0 — A, 1 — B). dir: 1 — o‘ngga, −1 — chapga.
//     to bo‘lsa — strelka shu joygacha (bosib o‘tgan yo‘li), s — strelka ustidagi yozuv.
//  '4E-chizma' — Singapur "chizma model":
//     {t:'4E-chizma', rows:[{lb:'Ali', seg:[{n:24, s:'24'}, {n:8, s:'?', dash:true}], r:'?', top:{a:0,b:1,s:'?'}, bot:{a,b,s}}],
//      vbr:{a:0, b:1, s:'Jami 45'}, cap:'...', max}
//  '4E-ustun' — ustunli diagramma: {t:'4E-ustun', lb:['Du',...], val:[...], hide:[indeks], avg:'?'|son, title, step}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T;
  const ink = '#1e3a8a', qc = '#b45309', W0 = 340;
  const isQ = s => /\?/.test(String(s));
  const tw = (s, fs = 15) => String(s == null ? '' : s).length * fs * 0.64;
  const BC = ['#2563eb', '#ea580c', '#16a34a', '#9333ea'];
  // gorizontal qavs
  const hbr = (x1, x2, y, up, s, fs = 15) => {
    const d = up ? -1 : 1, m = (x1 + x2) / 2, r = Math.min(8, (x2 - x1) / 4);
    const p = `M${x1} ${y}q0 ${d * 7} ${r} ${d * 7}H${m - 6}q6 0 6 ${d * 7}q0 ${-d * 7} 6 ${-d * 7}H${x2 - r}q${r} 0 ${r} ${-d * 7}`;
    let tx = m; const half = tw(s, fs) / 2; if (tx - half < 2) tx = half + 2; if (tx + half > W0 - 2) tx = W0 - 2 - half;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + (s != null && s !== '' ? T(tx, y + d * 24, s, { fs, c: isQ(s) ? qc : P.ink, st: 1 }) : '');
  };
  const vbr = (y1, y2, x, s) => {
    const m = (y1 + y2) / 2;
    const p = `M${x} ${y1}q7 0 7 7V${m - 6}q0 6 7 6q-7 0 -7 6V${y2 - 7}q0 7 -7 7`;
    return `<path d="${p}" fill="none" stroke="${P.line}" stroke-width="2"/>` + T(x + 20, m, s, { fs: 15, a: 'start', c: isQ(s) ? qc : P.ink });
  };

  // ---- harakatlanuvchi belgisi (oddiy chizma), x — markaz, y — g‘ildirak ostidagi chiziq, d — yo‘nalish
  const glyph = (ic, x, y, c, d) => {
    const st = `stroke="${ink}" stroke-width="1.6" stroke-linejoin="round"`;
    const wh = (cx, r = 4) => `<circle cx="${cx}" cy="${y - r}" r="${r}" fill="#334155" stroke="#fff" stroke-width="1"/>`;
    const f = v => x + d * v; // yo‘nalishga qarab ko‘zgu
    switch (ic) {
      case 'odam': return `<g stroke="${c}" stroke-width="3" stroke-linecap="round" fill="none"><circle cx="${x}" cy="${y - 24}" r="4.5" fill="${c}"/><path d="M${x} ${y - 19}V${y - 9}M${x} ${y - 9}L${f(-5)} ${y}M${x} ${y - 9}L${f(5)} ${y}M${x} ${y - 16}L${f(6)} ${y - 11}M${x} ${y - 16}L${f(-5)} ${y - 12}"/></g>`;
      case 'velo': case 'moto': return `<g fill="none" stroke="${c}" stroke-width="2.4" stroke-linecap="round"><circle cx="${f(-9)}" cy="${y - 6}" r="6"/><circle cx="${f(9)}" cy="${y - 6}" r="6"/><path d="M${f(-9)} ${y - 6}L${f(-2)} ${y - 15}L${f(7)} ${y - 15}L${f(9)} ${y - 6}M${f(-2)} ${y - 15}L${x} ${y - 6}M${f(-3)} ${y - 15}L${f(0)} ${y - 22}"/>${ic === 'moto' ? `<path d="M${f(-6)} ${y - 15}h${d * 12}" stroke-width="5"/>` : ''}<circle cx="${f(1)}" cy="${y - 27}" r="3.6" fill="${c}"/></g>`;
      case 'avtobus': return `<rect x="${x - 18}" y="${y - 22}" width="36" height="16" rx="4" fill="${c}" ${st}/><path d="M${x - 14} ${y - 19}h${28}" stroke="#fff" stroke-width="4" stroke-dasharray="5 2"/>${wh(x - 10)}${wh(x + 10)}`;
      case 'yuk': return `<rect x="${f(-18) - (d > 0 ? 0 : 22)}" y="${y - 24}" width="22" height="18" rx="2" fill="${c}" ${st}/><path d="M${f(4)} ${y - 6}V${y - 18}H${f(12)}L${f(16)} ${y - 12}V${y - 6}z" fill="#e2e8f0" ${st}/>${wh(f(-11))}${wh(f(10))}`;
      case 'poyezd': return `<rect x="${x - 20}" y="${y - 22}" width="40" height="16" rx="5" fill="${c}" ${st}/><rect x="${x - 15}" y="${y - 19}" width="7" height="6" rx="1" fill="#fff"/><rect x="${x - 4}" y="${y - 19}" width="7" height="6" rx="1" fill="#fff"/><rect x="${x + 7}" y="${y - 19}" width="7" height="6" rx="1" fill="#fff"/>${wh(x - 12, 3.5)}${wh(x, 3.5)}${wh(x + 12, 3.5)}`;
      default: return `<path d="M${f(-16)} ${y - 7}V${y - 14}L${f(-9)} ${y - 15}L${f(-4)} ${y - 22}H${f(7)}L${f(12)} ${y - 14}L${f(16)} ${y - 13}V${y - 7}z" fill="${c}" ${st}/>${wh(f(-9))}${wh(f(9))}`;
    }
  };

  V.ext['4E-harakat'] = (v) => {
    const L = 22, R = W0 - 22, X = f => L + f * (R - L), bs = v.bodies || [];
    let o = '', y = 4;
    // 1) belgilar va uchrashuv yozuvi
    const gy = y + 32; const rd = gy + 14;
    const used = [];
    bs.forEach((b, i) => {
      if (b.noic) return;
      let gx = X(b.at); const d = b.dir === -1 ? -1 : 1;
      const opp = bs.some((c, j) => j !== i && Math.abs(c.at - b.at) < 0.08 && (c.dir === -1 ? -1 : 1) !== d);
      if (opp) gx += d * 24; else if (used.some(u => Math.abs(u - gx) < 40)) gx += d * 44;
      gx = Math.max(L + 8, Math.min(R - 8, gx)); used.push(gx);
      o += glyph(b.ic || 'avto', gx, gy, b.c || BC[i % 4], b.dir === -1 ? -1 : 1);
    });
    if (v.meet) { const mx = X(v.meet.x); o += `<path d="M${mx} ${rd - 2}V${gy - 26}" stroke="${qc}" stroke-width="2.5"/><path d="M${mx} ${gy - 26}l14 5l-14 5z" fill="${P.gold}" stroke="${qc}" stroke-width="1.5"/>`; if (v.meet.s) o += T(mx + (mx > W0 - 60 ? -10 : 20), gy - 16, v.meet.s, { fs: 15, c: qc, st: 1, a: mx > W0 - 60 ? 'end' : 'start' }) }
    // 2) yo‘l
    o += `<rect x="${L - 6}" y="${rd}" width="${R - L + 12}" height="12" rx="6" fill="#94a3b8"/><path d="M${L} ${rd + 6}H${R}" stroke="#fff" stroke-width="2" stroke-dasharray="8 6"/>`;
    o += `<circle cx="${L}" cy="${rd + 6}" r="6" fill="${P.green}" stroke="#fff" stroke-width="2"/><circle cx="${R}" cy="${rd + 6}" r="6" fill="${P.red}" stroke="#fff" stroke-width="2"/>`;
    (v.marks || []).forEach(m => { o += `<circle cx="${X(m)}" cy="${rd + 6}" r="5" fill="#fff" stroke="${ink}" stroke-width="2"/>` });
    y = rd + 12;
    // 3) shahar nomlari
    if (v.A || v.B) { y += 18; if (v.A) o += T(L - 6, y, v.A, { fs: 15, a: 'start' }); if (v.B) o += T(R + 6, y, v.B, { fs: 15, a: 'end' }); y += 8 }
    // 4) yo‘laklar: har jism uchun strelka va yozuv
    const y0 = y;
    bs.forEach((b, i) => {
      const c = b.c || BC[i % 4], d = b.dir === -1 ? -1 : 1, x1 = X(b.at), x2 = b.to != null ? X(b.to) : Math.max(L, Math.min(R, x1 + d * 70));
      y += b.s ? 30 : 16; const ay = y;
       o += `<path d="M${x1} ${(x1 < L + 60 || x1 > R - 60) ? y0 : rd + 12}V${ay}" stroke="${c}" stroke-width="1.5" stroke-dasharray="3 3"/>`;
      o += `<path d="M${x1} ${ay}H${x2 - d * 9}" stroke="${c}" stroke-width="3.5"/><path d="M${x2} ${ay}l${-d * 11} -6v12z" fill="${c}"/>`;
      if (b.s) o += T((x1 + x2) / 2, ay - 14, b.s, { fs: 14, c: isQ(b.s) ? qc : P.ink, st: 1 });
      const txt = b.lb + (b.v ? ': ' + b.v : ''), w = tw(txt, 15);
      let tx = d === 1 ? x1 : x1, a = d === 1 ? 'start' : 'end';
      if (a === 'start' && tx + w > W0 - 2) { tx = Math.min(W0 - 2, x2 + 0); a = 'end'; if (tx - w < 2) { tx = 2; a = 'start' } }
      if (a === 'end' && tx - w < 2) { tx = 2; a = 'start' }
      y += 20; o += T(tx, y, txt, { fs: 15, c, a, st: 1 });
      y += 8;
    });
    // 5) qavslar
    const lvls = {}; (v.br || []).forEach(b => { (lvls[b.lv || 0] = lvls[b.lv || 0] || []).push(b) });
    Object.keys(lvls).sort().forEach(k => { y += 8; lvls[k].forEach(b => { o += hbr(X(b.a), X(b.b), y, false, b.s) }); y += 34 });
    if (v.cap) { y += 14; o += T(W0 / 2, y, v.cap, { fs: 15, c: isQ(v.cap) ? qc : P.ink }); y += 12 }
    return V.svg(W0, y + 4, o, W0);
  };

  // ---- chizma model
  const COL = ['#93c5fd', '#fcd34d', '#86efac', '#f9a8d4', '#c4b5fd', '#fdba74'];
  V.ext['4E-chizma'] = (v) => {
    const rows = v.rows, bh = 34;
    const sum = r => r.seg.reduce((a, s) => a + s.n, 0);
    const max = v.max || Math.max(...rows.map(sum));
    const lbw = rows.some(r => r.lb) ? Math.max(...rows.map(r => tw(r.lb))) + 10 : 2;
    const rw = Math.max(0, ...rows.map(r => (r.r != null && r.r !== '' ? tw(r.r) + 12 : 0))) + (v.vbr ? 26 + tw(v.vbr.s) : 0);
    const BW = Math.max(130, (v.bw || W0 - 6) - lbw - rw), k = BW / max;
    let y = 4, o = '', W = 0; const ys = [];
    rows.forEach((r, i) => {
      if (r.top) y += 32;
      let x = lbw; const xs = [x];
      if (r.lb) o += T(lbw - 7, y + bh / 2, r.lb, { fs: 15, a: 'end' });
      r.seg.forEach((s) => {
        const lab = s.s != null && s.s !== '' ? String(s.s) : '';
        const w = Math.max(s.n * k, lab ? tw(lab, 14) + 8 : 4), col = s.c || COL[(r.ci != null ? r.ci : i) % COL.length];
        o += s.dash
          ? `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="#fffbeb" stroke="${qc}" stroke-width="2" stroke-dasharray="6 4"/>`
          : `<rect x="${x}" y="${y}" width="${w}" height="${bh}" rx="4" fill="${col}" stroke="${ink}" stroke-width="2"/>`;
        if (lab) { const q = isQ(lab), fs = w >= tw(lab, 15) + 6 ? 15 : 14; o += T(x + w / 2, y + bh / 2, lab, { fs, c: q ? qc : P.ink, st: q ? 0 : 1 }) }
        x += w; xs.push(x);
      });
      if (r.top) o += hbr(xs[r.top.a], xs[r.top.b + 1], y - 3, true, r.top.s);
      if (r.bot) o += hbr(xs[r.bot.a], xs[r.bot.b + 1], y + bh + 3, false, r.bot.s);
      let xe = x;
      if (r.r != null && r.r !== '') { o += T(x + 8, y + bh / 2, r.r, { fs: 15, a: 'start', c: isQ(r.r) ? qc : P.ink }); xe = x + 12 + tw(r.r) }
      W = Math.max(W, xe);
      ys.push([y, y + bh, xe]);
      y += bh + (r.bot ? 34 : 0) + 12;
    });
    if (v.vbr) {
      const a = ys[v.vbr.a], b = ys[v.vbr.b], xx = Math.max(...ys.slice(v.vbr.a, v.vbr.b + 1).map(q => q[2])) + 8;
      o += vbr(a[0], b[1], xx, v.vbr.s); W = Math.max(W, xx + 24 + tw(v.vbr.s));
    }
    let H = y - 12 + 6;
    if (v.cap) { o += T(Math.max(W, 200) / 2, H + 12, v.cap, { fs: 15, c: isQ(v.cap) ? qc : P.ink }); W = Math.max(W, tw(v.cap) + 4); H += 28 }
    return V.svg(W + 4, H, o, W + 4);
  };

  // ---- ustunli diagramma (telefon uchun)
  V.ext['4E-ustun'] = (v) => {
    const n = v.lb.length, vals = v.val.map(Number), max = Math.max(...vals);
    const step = v.step || [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000].find(s => max / s <= 6) || 10000;
    const top = Math.ceil(max / step) * step, L = 46, Rr = W0 - 6, B = (v.title ? 34 : 14) + 170, Hh = 170;
    const gap = (Rr - L) / n, bw = Math.min(46, gap * 0.62); let o = '';
    if (v.title) o += T(W0 / 2, 12, v.title, { fs: 15 });
    for (let s = 0; s <= top; s += step) { const yy = B - s / top * Hh; o += `<line x1="${L}" y1="${yy}" x2="${Rr}" y2="${yy}" stroke="#e2e8f0" stroke-width="1.5"/>` + T(L - 6, yy, s, { fs: 14, a: 'end' }) }
    vals.forEach((x, i) => {
      const cx = L + gap * (i + .5), h = x / top * Hh, hid = (v.hide || []).includes(i);
      if (hid) o += `<rect x="${cx - bw / 2}" y="${B - Hh}" width="${bw}" height="${Hh}" rx="5" fill="#fffbeb" stroke="${qc}" stroke-width="2" stroke-dasharray="6 4"/>` + T(cx, B - Hh / 2, '?', { fs: 22, c: qc });
      else o += `<rect x="${cx - bw / 2}" y="${B - h}" width="${bw}" height="${h}" rx="5" fill="${P.fills[i % 7]}"/>` + T(cx, B - h - 11, x, { fs: 15, st: 1 });
      o += T(cx, B + 16, v.lb[i], { fs: 14 });
    });
    o += `<line x1="${L}" y1="${B}" x2="${Rr}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/><line x1="${L}" y1="${B}" x2="${L}" y2="${B - Hh - 6}" stroke="${P.line}" stroke-width="2.5"/>`;
    if (v.avg != null) { const a = typeof v.avg === 'number' ? v.avg : null; if (a != null) { const yy = B - a / top * Hh; o = `<line x1="${L}" y1="${yy}" x2="${Rr}" y2="${yy}" stroke="${P.red}" stroke-width="2.5" stroke-dasharray="8 5"/>` + o + `<path d="M${L + 10} ${B + 44}h34" stroke="${P.red}" stroke-width="2.5" stroke-dasharray="8 5"/>` + T(L + 52, B + 44, 'o‘rtacha: ' + a, { fs: 15, c: P.red, a: 'start' }) } }
    return V.svg(W0, B + (v.avg != null ? 58 : 30), o, W0);
  };
})();

// 4E8–4E13 (4-sinf matnli masalalar: karrali nisbat, daryo oqimi, proporsiya, sarf, ekologiya, kechikishli harakat) uchun rasm turlari.
//  '4E8-model' — chizma model (Singapur): {rows:[{lb:'Anvar', n:3, s:'?', ex:'+4', exq, rt:'?'}], tot:'96 ta'}
//                har qator n ta teng bo‘lak; s — birinchi bo‘lakdagi yozuv (sig‘masa qator ustida); ex — qator oxiridagi qo‘shimcha (sariq) bo‘lak yozuvi;
//                rt — qator o‘ngidagi yozuv; tot — o‘ngdagi katta qavs yonidagi jami.
//  '4E8-daryo' — daryo sxemasi: {flow:'3 km/soat', dist:'60 km', A:'A', B:'B', boats:[{dir:1|-1, lb:'15 km/soat', kind:'qayiq'|'sol', x:0.5}]}
//                oqim doim chapdan o‘ngga; dir 1 — oqim bo‘ylab (o‘ngga), −1 — oqimga qarshi.
//  '4E8-ustun' — ustunli diagramma (pastda).
//  '4E8-yol'   — harakat sxemasi, qatorlar yuqoridan pastga: {rows:[{seg:[a,b], lb, c, dash, q}, {mv:x, dir, lb, c}, {track:1, pts:[{x, lb, sub}]}]}
//                x, a, b — 0..1 oralig‘idagi ulush (chap uchi 0, o‘ng uchi 1). pts[].dot:false — nuqtasiz, faqat yozuv.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, Q = '#fff7d6', QS = '#f5b301', QC = '#b45309';
  const tw = (s, fs) => String(s).length * fs * 0.56; // taxminiy matn eni
  const qc = s => String(s).includes('?') ? QC : P.ink;

  V.ext['4E8-model'] = v => {
    const rows = v.rows, W = 340, fs = 15;
    const L = rows.some(r => r.lb) ? Math.max(...rows.map(r => tw(r.lb || '', fs))) + 12 : 4;
    const rtw = Math.max(0, ...rows.map(r => r.rt ? tw(r.rt, fs) + 12 : 0));
    const totw = v.tot ? Math.max(tw(v.tot, 16), 30) + 30 : 0;
    const exw = rows.some(r => r.ex) ? Math.max(...rows.map(r => r.ex ? Math.max(tw(r.ex, 14) + 10, 34) : 0)) + 4 : 0;
    const mx = Math.max(...rows.map(r => r.n));
    const u = Math.min(60, (W - L - rtw - totw - exw - 6) / mx), rh = 34;
    let o = '', y = 4; const ys = [];
    rows.forEach((r, i) => {
      const above = r.s != null && tw(r.s, fs) > u - 6;
      if (above) y += 20;
      ys.push(y);
      if (r.lb) o += T(L - 8, y + rh / 2, r.lb, { fs, a: 'end' });
      for (let k = 0; k < r.n; k++) {
        const isq = r.s === '?' && k === 0;
        o += `<rect x="${L + k * u}" y="${y}" width="${u}" height="${rh}" rx="3" fill="${isq ? Q : P.fills[i % 7] + '66'}" stroke="#1e3a8a" stroke-width="2"/>`;
      }
      if (r.s != null) {
        if (above) { const x1 = L, x2 = L + r.n * u; o += `<path d="M${x1 + 1} ${y - 3}v-6H${x2 - 1}v6" fill="none" stroke="${P.blue}" stroke-width="2"/>` + T((x1 + x2) / 2, y - 16, r.s, { fs: 14, c: qc(r.s) }) }
        else o += T(L + u / 2, y + rh / 2, r.s, { fs, c: qc(r.s) });
      }
      let xe = L + r.n * u;
      if (r.ex) { const w = Math.max(tw(r.ex, 14) + 10, 34); o += `<rect x="${xe + 2}" y="${y}" width="${w}" height="${rh}" rx="3" fill="${Q}" stroke="${QS}" stroke-width="2" stroke-dasharray="5 3"/>` + T(xe + 2 + w / 2, y + rh / 2, r.ex, { fs: 14, c: QC }); xe += w + 2 }
      if (r.rt) o += T(xe + 6, y + rh / 2, r.rt, { fs, a: 'start', c: qc(r.rt) });
      y += rh + 12;
    });
    const H = y - 12 + 4;
    if (v.tot) {
      const xr = L + mx * u + exw + rtw + 8, y1 = ys[0], y2 = y - 12, ym = (y1 + y2) / 2;
      o += `<path d="M${xr} ${y1}q8 0 8 8V${ym - 8}l7 8l-7 8V${y2 - 8}q0 8 -8 8" fill="none" stroke="${P.blue}" stroke-width="2.5"/>`;
      o += T(xr + 20, ym, v.tot, { fs: 16, a: 'start', c: String(v.tot).includes('?') ? QC : P.blue });
    }
    return V.svg(W, H, o, W);
  };

  const boat = (x, y, kind, dir, c) => {
    if (kind === 'sol') { let s = ''; for (let i = 0; i < 5; i++) s += `<rect x="${x - 25 + i * 10}" y="${y - 7}" width="9" height="14" rx="3" fill="#d6a46b" stroke="#7c4a03" stroke-width="1.5"/>`; return s }
    const f = dir < 0 ? -1 : 1;
    return `<g transform="translate(${x} ${y}) scale(${f} 1)"><path d="M-28 -6H26l-10 14H-22z" fill="${c || '#f97316'}" stroke="#7c2d12" stroke-width="2" stroke-linejoin="round"/><rect x="-12" y="-17" width="18" height="11" rx="2" fill="#fff" stroke="#7c2d12" stroke-width="1.5"/></g>`;
  };
  V.ext['4E8-daryo'] = v => {
    const W = 340, top = v.dist ? 38 : 8, rv = top + 24, rb = rv + 104; let o = '';
    o += `<rect x="0" y="${top}" width="${W}" height="24" fill="#bbf7d0"/><rect x="0" y="${rb}" width="${W}" height="22" fill="#bbf7d0"/>`;
    o += `<rect x="0" y="${rv}" width="${W}" height="${rb - rv}" fill="#bfdbfe"/>`;
    for (let k = 0; k < 3; k++) for (let x = 10 + k * 30; x < W - 30; x += 110) o += `<path d="M${x} ${rv + 18 + k * 30}q8 -6 16 0t16 0" fill="none" stroke="#60a5fa" stroke-width="2"/>`;
    const pA = 28, pB = W - 28;
    const pier = (x, l) => `<rect x="${x - 6}" y="${top + 2}" width="12" height="30" rx="2" fill="#78716c"/>` + T(x, top + 12, l, { fs: 16, c: '#fff', st: 0 });
    if (v.A) o += pier(pA, v.A); if (v.B) o += pier(pB, v.B);
    if (v.dist) { o += `<path d="M${pA} 22H${pB}M${pA} 15v14M${pB} 15v14" stroke="${P.ink}" stroke-width="2" fill="none"/>` + `<rect x="${W / 2 - tw(v.dist, 16) / 2 - 8}" y="10" width="${tw(v.dist, 16) + 16}" height="24" rx="6" fill="#fff"/>` + T(W / 2, 22, v.dist, { fs: 16, c: qc(v.dist) }) }
    // oqim strelkasi
    const fy = rb - 18; o += `<path d="M${W / 2 - 70} ${fy}H${W / 2 + 64}" stroke="#1d4ed8" stroke-width="3"/><path d="M${W / 2 + 72} ${fy}l-11 -6v12z" fill="#1d4ed8"/>`;
    if (v.flow) o += T(W / 2, fy - 14, 'oqim: ' + v.flow, { fs: 15, c: '#1e3a8a', st: 1 });
    (v.boats || []).forEach((b, i) => {
      const n = v.boats.length, x = (b.x != null ? b.x : (i + 1) / (n + 1)) * W, y = rv + 36 + (n > 1 && b.kind !== 'sol' ? 0 : 0);
      o += boat(x, y, b.kind, b.dir, b.c);
      const ax = x + (b.dir < 0 ? -34 : 34); o += `<path d="M${ax} ${y}h${b.dir < 0 ? -26 : 26}" stroke="${P.red}" stroke-width="3"/><path d="M${ax + (b.dir < 0 ? -32 : 32)} ${y}l${b.dir < 0 ? 9 : -9} -5v10z" fill="${P.red}"/>`;
      if (b.lb) o += T(Math.min(Math.max(x, tw(b.lb, 15) / 2 + 4), W - tw(b.lb, 15) / 2 - 4), y - 26, b.lb, { fs: 15, c: qc(b.lb), st: 1 });
    });
    return V.svg(W, rb + 22, o, W);
  };

  V.ext['4E8-yol'] = v => {
    const W = 340, L = 22, R = W - 22, X = f => L + f * (R - L); let o = '', y = 4;
    const clampT = (x, s, fs) => Math.min(Math.max(x, tw(s, fs) / 2 + 3), W - tw(s, fs) / 2 - 3);
    for (const r of v.rows) {
      if (r.seg) {
        const [a, b] = r.seg, c = r.c || P.blue, x1 = X(a), x2 = X(b), yy = y + 26;
        o += `<path d="M${x1} ${yy - 7}v7H${x2}v-7" fill="none" stroke="${c}" stroke-width="3"${r.dash ? ' stroke-dasharray="6 4"' : ''}/>`;
        o += T(clampT((x1 + x2) / 2, r.lb, 15), yy - 14, r.lb, { fs: 15, c: String(r.lb).includes('?') ? QC : c, st: 1 });
        y += 34;
      } else if (r.mv != null) {
        const x = X(r.mv), c = r.c || P.red, d = r.dir < 0 ? -1 : 1, yy = y + 14;
        o += `<circle cx="${x}" cy="${yy}" r="7" fill="${c}"/><path d="M${x + d * 9} ${yy}h${d * 38}" stroke="${c}" stroke-width="3"/><path d="M${x + d * 54} ${yy}l${-d * 10} -6v12z" fill="${c}"/>`;
        if (r.lb) { const lx = d > 0 ? x + 60 : x - 60; const fits = d > 0 ? lx + tw(r.lb, 15) < W : lx - tw(r.lb, 15) > 0; o += fits ? T(lx, yy, r.lb, { fs: 15, a: d > 0 ? 'start' : 'end', c }) : T(d > 0 ? x - 12 : x + 12, yy, r.lb, { fs: 15, a: d > 0 ? 'end' : 'start', c }) }
        y += 30;
      } else if (r.track) {
        const yy = y + 10;
        o += `<line x1="${L}" y1="${yy}" x2="${R}" y2="${yy}" stroke="${P.line}" stroke-width="4" stroke-linecap="round"/>`;
        (r.pts || []).forEach(p => { const x = X(p.x); if (p.dot !== false) o += `<circle cx="${x}" cy="${yy}" r="6" fill="${p.c || P.ink}"/>`; if (p.lb) o += T(clampT(x, p.lb, 16), yy + 20, p.lb, { fs: 16, c: p.c || P.red }); if (p.sub) o += T(clampT(x, p.sub, 14), yy + 40, p.sub, { fs: 14, c: P.ink }) });
        y += (r.pts || []).some(p => p.sub) ? 58 : 38;
      }
    }
    return V.svg(W, y + 2, o, W);
  };

  // '4E8-ustun' — telefon uchun ustunli diagramma (yozuvlar 14–15px): {lb:[], val:[], step, unit:'s/ga', hide:[indeks], c:[ranglar]}
  V.ext['4E8-ustun'] = v => {
    const W = 340, n = v.lb.length, st = v.step, top = Math.ceil(Math.max(...v.val) * 1.12 / st) * st;
    const L = Math.max(...[0, top].map(x => tw(x, 14))) + 12, B = 196, H = 160, gap = (W - L - 4) / n, bw = Math.min(46, gap * .62); let o = '';
    if (v.unit) o += T(L - 4, 10, v.unit, { fs: 14, a: 'start', c: P.ink });
    for (let y = 0; y <= top; y += st) { const yy = B - y / top * H; o += `<line x1="${L}" y1="${yy}" x2="${W - 4}" y2="${yy}" stroke="#e2e8f0" stroke-width="1.5"/>` + T(L - 6, yy, y, { fs: 14, a: 'end' }) }
    v.val.forEach((x, i) => { const cx = L + gap * (i + .5), h = x / top * H; o += `<rect x="${cx - bw / 2}" y="${B - h}" width="${bw}" height="${h}" rx="5" fill="${(v.c && v.c[i]) || P.fills[i % 7]}"/>`; if (!(v.hide || []).includes(i)) o += T(cx, B - h - 11, x, { fs: 15 }); o += T(cx, B + 16, v.lb[i], { fs: 15 }) });
    o += `<line x1="${L}" y1="${B}" x2="${W - 4}" y2="${B}" stroke="${P.line}" stroke-width="2.5"/><line x1="${L}" y1="${B}" x2="${L}" y2="${B - H - 6}" stroke="${P.line}" stroke-width="2.5"/>`;
    return V.svg(W, B + 30, o, W);
  };
})();

// 4F (4-sinf: kasrlar) uchun qo‘shimcha rasm turlari. Turlar nomi '4F-' bilan boshlanadi.
// Hamma SVG eni 336 birlikdan oshmaydi: telefonda (karta ichi ~338 px) 1:1 chiqadi, yozuvlar kamida 15 px.
//  '4F-ifoda' — kasrli ifoda (surat, chiziq, maxraj ustma-ust): {l:['3/4','+','1/4','=','?'], fs}
//               element: '3/4' — kasr, '2 1/5' — aralash kasr, '?/8' yoki '3/☐' — bo‘sh katakli kasr, '?' / '☐' — katak, boshqasi — matn.
//  '4F-doira'  — teng bo‘laklarga bo‘lingan doiralar (pitsa, tort): {l:[{n, k, k2, x:[i], lb}], s, c, c2}
//               n — bo‘laklar, k — bo‘yalgan (12 dan soat yo‘nalishida), k2 — keyingi bo‘laklar 2-rangda, x — chizib tashlangan bo‘laklar.
//  '4F-plitka' — shokolad plitkasi (r qator × c ustun): {l:[{r, c, k, lb}], eat:true|false}
//               eat — k ta katak yeyilgan (bo‘sh, uzuq chiziq); aks holda k ta katak bo‘yalgan.
//  '4F-nur'    — kasrli sonlar nuri: {n (birlik nechaga bo‘lingan), m (nechta birlik), lab:'int'|'all', ilab:['0','24'], pts:[{p, lb}], q:[p], jumps:[{f, t, lb}]}
//               p — boshidan nechta 1/n qadam. ilab — butun bo‘linmalar yozuvi o‘rniga matn.
//  '4F-model'  — chizma model (Singapur tasmasi): {rows:[{lb, n, k, k2, x:[i], t:['','6'], top:'48 km', bot:{a, b, t:'?'} | [{a, b, t}, …], c}]}
//               bo‘laklar teng; top — butun tasma ustidagi qavs; bot — a..b-1 bo‘laklar ostidagi qavs.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, LN = '#1e3a8a', SH = '#60a5fa', SH2 = '#fbbf24', W = 336;
  const f1 = x => +(+x).toFixed(1);
  const T = (x, y, s, o = {}) => V.T(f1(x), f1(y), s, Object.assign({ fs: 16 }, o));
  const tw = (s, fs) => String(s).length * fs * .62; // taxminiy matn eni

  // ---------- kasrli ifoda
  const box = (x, y, w, h, fs) => `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" rx="7" fill="#fff7d6" stroke="${P.gold}" stroke-width="2.2" stroke-dasharray="5 4"/>` + T(x + w / 2, y + h / 2 + 1, '?', { fs, c: '#b45309' });
  function tok(s, k) {
    const ff = 25 * k, fn = 30 * k, fo = 28 * k; s = String(s);
    let m = s.match(/^(\d+) (\S+)\/(\S+)$/);
    if (m) { const a = tok(m[1], k), b = tok(m[2] + '/' + m[3], k); return { w: a.w + 4 + b.w, d: (x, y) => a.d(x, y) + b.d(x + a.w + 4, y) } }
    m = s.match(/^(\d+|\?|☐)\/(\d+|\?|☐)$/);
    if (m) {
      const part = t => /^[?☐]$/.test(t) ? { w: 26 * k, d: (cx, cy) => box(cx - 13 * k, cy - 15 * k, 26 * k, 30 * k, 19 * k) } : { w: tw(t, ff), d: (cx, cy) => T(cx, cy, t, { fs: ff, fw: 900 }) };
      const a = part(m[1]), b = part(m[2]), w = Math.max(a.w, b.w) + 10 * k;
      return { w, d: (x, y) => a.d(x + w / 2, y - 19 * k) + `<line x1="${f1(x + 2)}" y1="${y}" x2="${f1(x + w - 2)}" y2="${y}" stroke="${P.ink}" stroke-width="${f1(3 * k)}" stroke-linecap="round"/>` + b.d(x + w / 2, y + 19 * k) };
    }
    if (s === '?' || s === '☐') return { w: 38 * k, d: (x, y) => box(x, y - 22 * k, 38 * k, 44 * k, 24 * k) };
    const isOp = /^[+−=·:<>?]$/.test(s) || s.length === 1 && !/\d/.test(s), fs = /^\d+$/.test(s) ? fn : isOp ? fo : 22 * k;
    return { w: tw(s, fs) + (isOp ? 4 : 0), d: (x, y) => T(x + (tw(s, fs) + (isOp ? 4 : 0)) / 2, y, s, { fs, fw: 900, c: isOp ? P.blue : P.ink }) };
  }
  V.ext['4F-ifoda'] = v => {
    let k = v.fs || 1, ts, tot;
    for (let it = 0; it < 6; it++) { ts = v.l.map(s => tok(s, k)); tot = ts.reduce((a, t) => a + t.w, 0) + (ts.length - 1) * 10 * k + 16; if (tot <= W) break; k *= W / tot * .98 }
    let x = 8, o = ''; const y = 50 * Math.max(k, .8);
    ts.forEach(t => { o += t.d(x, y); x += t.w + 10 * k });
    return V.svg(f1(tot), f1(y * 2), o);
  };

  // ---------- doiralar (teng sektorlar)
  function circle(e, cx, cy, r, c1, c2) {
    const n = e.n, k = e.k || 0, k2 = e.k2 || 0, xs = new Set(e.x || []); let o = '';
    const fill = i => i < k ? c1 : i < k + k2 ? c2 : '#fff';
    if (n === 1) o += `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r)}" fill="${fill(0)}" stroke="${LN}" stroke-width="2"/>`;
    else for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + i * 2 * Math.PI / n, b = a + 2 * Math.PI / n;
      o += `<path d="M${f1(cx)} ${f1(cy)}L${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}A${f1(r)} ${f1(r)} 0 ${n === 1 ? 1 : 0} 1 ${f1(cx + r * Math.cos(b))} ${f1(cy + r * Math.sin(b))}Z" fill="${fill(i)}" stroke="${LN}" stroke-width="2" stroke-linejoin="round"/>`;
    }
    for (const i of (false ? xs : [])) { const a = -Math.PI / 2 + (i + .5) * 2 * Math.PI / n, mx = cx + r * .6 * Math.cos(a), my = cy + r * .6 * Math.sin(a), d = Math.min(9, r * .5 * Math.sin(Math.PI / n) + 3); o += `<path d="M${f1(mx - d)} ${f1(my - d)}L${f1(mx + d)} ${f1(my + d)}M${f1(mx + d)} ${f1(my - d)}L${f1(mx - d)} ${f1(my + d)}" stroke="${P.red}" stroke-width="3.2" stroke-linecap="round"/>` }
    return o + `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r)}" fill="none" stroke="${LN}" stroke-width="2.8"/>`;
  }
  V.ext['4F-doira'] = v => {
    const L = v.l, hasLb = L.some(e => e.lb); let s = v.s || (L.length === 1 ? 130 : L.length === 2 ? 112 : L.length === 3 ? 96 : 74); const gap = 12;
    const per = Math.max(1, Math.floor((W + gap) / (s + gap))), rows = Math.ceil(L.length / per), lh = hasLb ? 26 : 4;
    const cols = Math.min(per, L.length), Wd = cols * s + (cols - 1) * gap + 4; let o = '';
    L.forEach((e, i) => {
      const rr = Math.floor(i / per), cc = i % per, x = 2 + cc * (s + gap), y = 2 + rr * (s + lh + 8);
      o += circle(e, x + s / 2, y + s / 2, s / 2 - 2, e.c || v.c || SH, e.c2 || v.c2 || SH2);
      if (e.lb) o += T(x + s / 2, y + s + 14, e.lb, { fs: 16, c: e.lc || P.ink });
    });
    return V.svg(f1(Wd), f1(rows * (s + lh + 8) - 4), o);
  };

  // ---------- shokolad plitkasi
  V.ext['4F-plitka'] = v => {
    const L = v.l, hasLb = L.some(e => e.lb), gap = 14, lh = hasLb ? 26 : 2;
    const maxC = Math.max(...L.map(e => e.c)), uRow = Math.floor(((W - gap * (L.length - 1)) / L.length - 8) / maxC), u = v.u || Math.min(44, uRow >= 22 ? uRow : Math.floor((W - 8) / maxC));
    let x = 2, y = 2, rowH = 0, Wd = 0, o = '';
    L.forEach(e => {
      const bw = e.c * u + 8, bh = e.r * u + 8; if (x > 2 && x + bw > W) { x = 2; y += rowH + lh + 8; rowH = 0 }
      o += `<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="6" fill="${v.eat ? '#5b3416' : '#e2e8f0'}" stroke="${v.eat ? '#3b1f0b' : LN}" stroke-width="2"/>`;
      for (let i = 0; i < e.r * e.c; i++) {
        const cx = x + 4 + (i % e.c) * u, cy = y + 4 + Math.floor(i / e.c) * u, on = i < (e.k || 0);
        if (v.eat) o += on ? `<rect x="${cx + 1.5}" y="${cy + 1.5}" width="${u - 3}" height="${u - 3}" rx="3" fill="#fff" stroke="#b08968" stroke-width="1.6" stroke-dasharray="4 3"/>`
          : `<rect x="${cx + 1.5}" y="${cy + 1.5}" width="${u - 3}" height="${u - 3}" rx="3" fill="#8b5a2b" stroke="#3b1f0b" stroke-width="1.2"/><rect x="${cx + 5}" y="${cy + 5}" width="${u - 10}" height="${u - 10}" rx="2" fill="#a0683a"/>`;
        else o += `<rect x="${cx + 1}" y="${cy + 1}" width="${u - 2}" height="${u - 2}" rx="2" fill="${on ? (e.cl || SH) : '#fff'}" stroke="${LN}" stroke-width="1.6"/>`;
      }
      if (e.lb) o += T(x + bw / 2, y + bh + 14, e.lb, { fs: 16 });
      x += bw + gap; rowH = Math.max(rowH, bh); Wd = Math.max(Wd, x - gap);
    });
    return V.svg(f1(Wd + 2), f1(y + rowH + lh + 2), o);
  };

  // ---------- kasrli sonlar nuri
  const fracLbl = (x, y, a, b, c) => T(x, y, a, { fs: 15, c }) + `<line x1="${f1(x - 8)}" y1="${y + 10}" x2="${f1(x + 8)}" y2="${y + 10}" stroke="${c || P.ink}" stroke-width="1.8"/>` + T(x, y + 20, b, { fs: 15, c });
  V.ext['4F-nur'] = v => {
    const n = v.n, m = v.m || 1, N = n * m, L = 20, R = W - 26, u = (R - L) / N, hasJ = (v.jumps || []).length, y = hasJ ? 66 + 20 * (hasJ - 1) : (v.pts || []).some(p => p.lb) ? 40 : 22;
    const X = p => L + p * u; let o = `<line x1="${L - 10}" y1="${y}" x2="${R + 16}" y2="${y}" stroke="${P.line}" stroke-width="3"/><path d="M${R + 20} ${y}l-10 -6v12z" fill="${P.line}"/>`;
    const q = v.q || [];
    for (let p = 0; p <= N; p++) {
      const big = p % n === 0; o += `<line x1="${f1(X(p))}" y1="${y - (big ? 11 : 7)}" x2="${f1(X(p))}" y2="${y + (big ? 11 : 7)}" stroke="${P.line}" stroke-width="${big ? 2.8 : 1.8}"/>`;
      if (q.includes(p)) { o += `<rect x="${f1(X(p) - 15)}" y="${y + 15}" width="30" height="${v.lab === 'all' ? 44 : 28}" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + T(X(p), y + (v.lab === 'all' ? 37 : 29), '?', { fs: 18, c: '#b45309' }); continue }
      if (big) o += T(X(p), y + (v.lab === 'all' ? 34 : 27), v.ilab ? v.ilab[p / n] : String(p / n), { fs: 18 });
      else if (v.lab === 'all') o += fracLbl(X(p), y + 22, p, n);
    }
    let lbs = ''; (v.jumps || []).forEach((j, i) => {
      const x1 = X(j.f), x2 = X(j.t), h = Math.min(38, 14 + Math.abs(x2 - x1) / 3) + i * 13, c = j.c || [P.green, '#d946ef', '#ea580c', P.blue][i % 4];
      o += `<path d="M${f1(x1)} ${y - 8}Q${f1((x1 + x2) / 2)} ${f1(y - 8 - h * 1.6)} ${f1(x2)} ${y - 10}" fill="none" stroke="${c}" stroke-width="3"/><path d="M${f1(x2)} ${y - 9}l${x2 > x1 ? -9 : 9} -6l${x2 > x1 ? 1 : -1} 10z" fill="${c}"/>`;
      if (j.lb) lbs += T((x1 + x2) / 2, y - 14 - h * .8, j.lb, { fs: 16, c, st: 1 });
    }); o += lbs;
    (v.pts || []).forEach(p => { o += `<circle cx="${f1(X(p.p))}" cy="${y}" r="7" fill="${p.c || P.red}" stroke="#fff" stroke-width="2"/>`; if (p.lb) o += T(X(p.p), y - 22, p.lb, { fs: 18, c: p.c || P.red, st: 1 }) });
    return V.svg(W, y + (v.lab === 'all' ? 62 : 46), o);
  };

  // ---------- chizma model (tasma)
  const brace = (x1, x2, yy, up, txt) => {
    const d = up ? -1 : 1, m = (x1 + x2) / 2;
    return `<path d="M${f1(x1)} ${yy}q0 ${7 * d} 8 ${7 * d}H${f1(m - 6)}q6 0 6 ${7 * d}q0 ${-7 * d} 6 ${-7 * d}H${f1(x2 - 8)}q8 0 8 ${-7 * d}" fill="none" stroke="${P.red}" stroke-width="2.2"/>` + T(m, yy + d * 24, txt, { fs: 17, c: P.red, st: 1 });
  };
  V.ext['4F-model'] = v => {
    const rows = v.rows, lw = Math.max(0, ...rows.map(r => r.lb ? tw(r.lb, 16) + 12 : 0)), L = lw + 4, Rr = W - 6, bh = 40; let y = 4, o = '';
    for (const r of rows) {
      if (r.top) y += 38;
      const bw = (Rr - L) * (r.w || 1), uw = bw / r.n, xs = new Set(r.x || []), c1 = r.c || SH;
      for (let i = 0; i < r.n; i++) {
        const fill = i < (r.k || 0) ? c1 : i < (r.k || 0) + (r.k2 || 0) ? (r.c2 || SH2) : '#fff';
        o += `<rect x="${f1(L + i * uw)}" y="${y}" width="${f1(uw)}" height="${bh}" fill="${fill}" stroke="${LN}" stroke-width="2"/>`;
        if (false && xs.has(i)) o += `<path d="M${f1(L + i * uw + 5)} ${y + 5}L${f1(L + (i + 1) * uw - 5)} ${y + bh - 5}M${f1(L + (i + 1) * uw - 5)} ${y + 5}L${f1(L + i * uw + 5)} ${y + bh - 5}" stroke="${P.red}" stroke-width="3" stroke-linecap="round"/>`;
        if (r.t && r.t[i]) o += T(L + (i + .5) * uw, y + bh / 2, r.t[i], { fs: 15, st: 1 });
      }
      o += `<rect x="${f1(L)}" y="${y}" width="${f1(bw)}" height="${bh}" fill="none" stroke="${LN}" stroke-width="2.8"/>`;
      if (r.lb) o += T(L - 8, y + bh / 2, r.lb, { fs: 16, a: 'end' });
      if (r.top) o += brace(L, L + bw, y - 4, true, r.top);
      y += bh;
      if (r.bot) { [].concat(r.bot).forEach(b => { o += brace(L + b.a * uw + (b.a ? 2 : 0), L + b.b * uw - (b.b < r.n ? 2 : 0), y + 4, false, b.t) }); y += 38 }
      y += 12;
    }
    return V.svg(W, y, o);
  };
})();

// 4F7–4F11, 4G1–4G5 (4-sinf: aralash kasrlar, o‘nli kasr, foiz, kattaliklar) uchun qo‘shimcha rasm turlari.
//  '4FG-ifoda' — katta ifoda, kasrlar ustma-ust yoziladi: {s:'2¹⁄₄ + 1 3/4 = ?'}  ('a b/c' yoki 'a¹⁄₄' — aralash son, '?' va ☐ — bo‘sh katak, '?/7' ham bo‘ladi)
//  '4FG-kasr'  — kasr/aralash son chizmasi: {g:[{w:2, n:4, k:3, x:1, lb:'A'}], f:'tasma'|'doira'}
//                w — to‘liq bo‘yalgan butunlar, n — bo‘laklar soni, k — oxirgi butunda bo‘yalgan bo‘laklar, x — bo‘yalganlardan oxirgi x tasi chizib tashlangan
//  '4FG-yuz'   — o‘ndan/yuzdan bir katakli kvadrat: {g:[{n:100|10, k:37, lb:'...'}]} (k ta katak bo‘yalgan)
//  '4FG-nur'   — shkala/nur: {n:10, lab:{0:'0', 10:'1 m'}, big:[0,5,10], pts:[{i:3, lb:'A'}], q:[7], jumps:[{f:0,t:3,lb:'+...'}]}
//  '4FG-tasma' — foiz/chizma model tasmasi: {n:10, k:3, top:'100% — 80 000 so‘m', parts:['10%',...], bot:'?', bk:3}
//  '4FG-quti'  — to‘g‘ri burchakli parallelepiped (quti): {a:'6 sm', b:'4 sm', c:'3 sm'} (a — bo‘yi, b — eni, c — balandligi)
//  '4FG-idish' — o‘lchov idishi: {n:10, lab:{0:'0', 5:'1 l', 10:'2 l'}, lvl:7}
//  '4FG-tarozi'— muvozanatdagi tarozi: chapda narsa rasmi, o‘ngda yozuvli toshlar: {img:'tarvuz', w:['2 kg','500 g']}
//  '4FG-maydon'— to‘g‘ri to‘rtburchak maydon: {w:5, h:2, lw:'500 m', lh:'200 m', s:'?', c:'#bbf7d0'}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, esc = V.esc, LN = '#1e3a8a', Q = '#fff7d6', QS = '#f5b301', QC = '#b45309';
  const f1 = x => +x.toFixed(1);

  // ---------- ifoda: kasrlar ustma-ust
  V.ext['4FG-ifoda'] = v => {
    const s = String(v.s), fs = v.fs || (s.length <= 16 ? 28 : s.length <= 24 ? 24 : 20);
    const bx = q => `<i class="bx" style="min-width:${Math.round(fs * .9)}px;height:${Math.round(fs * 1.05)}px;line-height:${Math.round(fs * 1.05)}px;font-size:${Math.round(fs * .7)}px;margin:0 2px">${q}</i>`;
    const part = p => p === '?' ? bx('?') : p === '☐' ? bx('') : esc(p);
    const frac = (a, b) => `<span style="display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;font-size:.78em;line-height:1.15;margin:0 3px"><span style="padding:0 3px;border-bottom:3px solid #0b2a6f">${part(a)}</span><span style="padding:0 3px">${part(b)}</span></span>`;
    let out = '';
    const SP = '⁰¹²³⁴⁵⁶⁷⁸⁹', SB = '₀₁₂₃₄₅₆₇₈₉', un = t => t.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹₀₁₂₃₄₅₆₇₈₉]/g, c => SP.includes(c) ? SP.indexOf(c) : SB.indexOf(c));
    const re = /(\d+)([⁰¹²³⁴⁵⁶⁷⁸⁹]+)⁄([₀₁₂₃₄₅₆₇₈₉]+)|(\d+)[ \u00a0](\d+|\?|☐)\/(\d+)|(\d+|\?|☐)\/(\d+|\?|☐)/g; let last = 0, m;
    const plain = t => esc(t).replace(/(\d) (?=\d{3}(?!\d))/g, '$1\u00a0').replace(/ ([·:=+−×]) /g, '\u00a0$1\u00a0').replace(/☐/g, bx('')).replace(/\?/g, bx('?'));
    while ((m = re.exec(s))) {
      out += plain(s.slice(last, m.index));
      if (m[1]) out += `<span style="white-space:nowrap">${esc(m[1])}${frac(un(m[2]), un(m[3]))}</span>`;
      else if (m[4]) out += `<span style="white-space:nowrap">${esc(m[4])}${frac(m[5], m[6])}</span>`;
      else out += frac(m[7], m[8]);
      last = re.lastIndex;
    }
    out += plain(s.slice(last));
    return `<div class="vx" style="font-size:${fs}px;letter-spacing:0;line-height:1.6">${out}</div>`;
  };

  // ---------- kart: harfli kartochkalar, ichida katta son (aralash son ustma-ust kasr bilan)
  //  {t:'4FG-kart', l:[{lb:'A', s:'3²⁄₆'}, ...], fs:30}
  V.ext['4FG-kart'] = v => {
    const fs = v.fs || 30;
    const card = c => `<div style="display:inline-flex;flex-direction:column;align-items:center;justify-content:center;min-width:72px;margin:4px;padding:5px 8px 4px;background:#fff;border:2.5px solid #93c5fd;border-radius:14px;box-shadow:0 2px 0 #bfdbfe">`
      + `<div style="font:900 15px Nunito,system-ui,sans-serif;color:#fff;background:#3b82f6;border-radius:8px;padding:0 10px;line-height:22px">${esc(c.lb)}</div>`
      + V.ext['4FG-ifoda']({ s: c.s, fs }).replace('class="vx" style="', 'class="vx" style="margin:2px 0;') + `</div>`;
    return `<div style="display:flex;flex-wrap:wrap;justify-content:center;max-width:380px;margin:0 auto">${v.l.map(card).join('')}</div>`;
  };

  // ---------- kasr: tasma yoki doira bo‘laklari
  function unit(f, x, y, s, n, k, xk, col) {
    let o = '';
    if (f === 'doira') {
      const cx = x + s / 2, cy = y + s / 2, r = s / 2 - 3;
      if (n === 1) return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${k ? col : '#fff'}" stroke="${LN}" stroke-width="2.5"/>`;
      for (let i = 0; i < n; i++) {
        const a = -Math.PI / 2 + i * 2 * Math.PI / n, b = a + 2 * Math.PI / n, big = (b - a) > Math.PI ? 1 : 0;
        o += `<path d="M${cx} ${cy}L${f1(cx + r * Math.cos(a))} ${f1(cy + r * Math.sin(a))}A${r} ${r} 0 ${big} 1 ${f1(cx + r * Math.cos(b))} ${f1(cy + r * Math.sin(b))}Z" fill="${i < k ? col : '#fff'}" stroke="${LN}" stroke-width="2" stroke-linejoin="round"/>`;
        if (i < k && i >= k - xk) { const m = (a + b) / 2, px = cx + r * .55 * Math.cos(m), py = cy + r * .55 * Math.sin(m); o += `<path d="M${f1(px - 7)} ${f1(py - 7)}l14 14m0 -14l-14 14" stroke="${P.red}" stroke-width="3.5" stroke-linecap="round"/>` }
      }
      return o;
    }
    const h = Math.min(s * .42, 56), cw = s / n;
    for (let i = 0; i < n; i++) {
      o += `<rect x="${f1(x + i * cw)}" y="${y}" width="${f1(cw)}" height="${h}" fill="${i < k ? col : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
      if (false && i < k && i >= k - xk) o += `<path d="M${f1(x + i * cw + cw * .2)} ${y + h * .2}L${f1(x + i * cw + cw * .8)} ${y + h * .8}M${f1(x + i * cw + cw * .8)} ${y + h * .2}L${f1(x + i * cw + cw * .2)} ${y + h * .8}" stroke="${P.red}" stroke-width="3" stroke-linecap="round"/>`;
    }
    return o;
  }
  V.ext['4FG-kasr'] = v => {
    const f = v.f || 'tasma', gs = v.g, maxU = Math.max(...gs.map(g => (g.w || 0) + (g.k || !g.w ? 1 : 0)));
    const W = 380, gap = 8, perRow = f === 'doira' ? Math.min(maxU, 4) : Math.min(maxU, 3);
    const s = Math.min(f === 'doira' ? 84 : perRow === 1 ? 300 : perRow === 2 ? 175 : 120, (W - (perRow - 1) * gap) / perRow), uh = f === "doira" ? s : Math.min(s * .42, 56);
    let o = '', y = 4;
    gs.forEach((g, gi) => {
      const col = g.c || P.fills[gi % 7], list = [];
      for (let i = 0; i < (g.w || 0); i++) list.push([g.n, g.n, 0]);
      if (g.k || !g.w) list.push([g.n, g.k || 0, g.x || 0]);
      if (g.x && !g.k) list[list.length - 1][2] = g.x;
      if (g.lb) { o += T(4, y + 10, g.lb, { fs: 15, a: 'start' }); y += 22 }
      list.forEach((u, i) => { const c = i % perRow, r = Math.floor(i / perRow); o += unit(f, c * (s + gap) + 2, y + r * (uh + gap), s, u[0], u[1], u[2], col) });
      y += Math.ceil(list.length / perRow) * (uh + gap) + 6;
    });
    const w = perRow * (s + gap) - gap + 4;
    return V.svg(w, y, o, Math.min(420, w * 1.15));
  };

  // ---------- yuz: 10x10 yoki 1x10 katak
  V.ext['4FG-yuz'] = v => {
    const gs = v.g; let o = '', x = 2; const c = 15, H = gs.some(g => g.n === 100) ? 10 * c : 34;
    gs.forEach((g, gi) => {
      const col = g.c || P.fills[gi % 7];
      if (g.n === 100) {
        for (let i = 0; i < 100; i++) { const cc = Math.floor(i / 10), rr = i % 10; o += `<rect x="${x + cc * c}" y="${2 + rr * c}" width="${c}" height="${c}" fill="${i < g.k ? col : '#fff'}" stroke="#64748b" stroke-width="1"/>` }
        o += `<rect x="${x}" y="2" width="${10 * c}" height="${H}" fill="none" stroke="${LN}" stroke-width="2.5"/>`;
        if (g.lb) o += T(x + 5 * c, H + 16, g.lb, { fs: 14 });
        x += 10 * c + 16;
      } else {
        const cw = 30, ch = 30, y0 = 2 + (H - ch) / 2;
        for (let i = 0; i < g.n; i++) o += `<rect x="${x + i * cw}" y="${y0}" width="${cw}" height="${ch}" fill="${i < g.k ? col : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
        if (g.lb) o += T(x + g.n * cw / 2, H + 16, g.lb, { fs: 14 });
        x += g.n * cw + 16;
      }
    });
    const hasLb = gs.some(g => g.lb);
    return V.svg(x - 14, H + (hasLb ? 30 : 6), o, Math.min(440, (x - 14) * 1.3));
  };

  // ---------- nur: shkala
  V.ext['4FG-nur'] = v => {
    const n = v.n, W = 420, L = 26, R = W - 30, u = (R - L) / n, y = 84, lab = v.lab || {}, big = v.big ? new Set(v.big) : null;
    let o = `<line x1="${L - 12}" y1="${y}" x2="${R + 14}" y2="${y}" stroke="${P.line}" stroke-width="3"/><path d="M${R + 18} ${y}l-10 -6v12z" fill="${P.line}"/>`;
    const X = i => L + i * u;
    for (let i = 0; i <= n; i++) {
      const b = big ? big.has(i) : lab[i] != null;
      o += `<line x1="${f1(X(i))}" y1="${y - (b ? 11 : 6)}" x2="${f1(X(i))}" y2="${y + (b ? 11 : 6)}" stroke="${P.line}" stroke-width="${b ? 2.6 : 1.5}"/>`;
      if (lab[i] != null && !(v.q || []).includes(i)) o += T(f1(X(i)), y + 30, lab[i], { fs: v.fs || 19 });
      if ((v.q || []).includes(i)) o += `<rect x="${f1(X(i) - 16)}" y="${y + 16}" width="32" height="26" rx="6" fill="${Q}" stroke="${QS}" stroke-width="2"/>` + T(f1(X(i)), y + 29, '?', { fs: 16, c: QC });
    }
    (v.jumps || []).forEach((j, k) => { const x1 = X(j.f), x2 = X(j.t), h = Math.min(46, 16 + Math.abs(x2 - x1) / 5), c = P.fills[k % 7]; o += `<path d="M${f1(x1)} ${y - 9}Q${f1((x1 + x2) / 2)} ${f1(y - 9 - h * 1.6)} ${f1(x2)} ${y - 11}" fill="none" stroke="${c}" stroke-width="3"/><path d="M${f1(x2)} ${y - 10}l${x2 > x1 ? -9 : 9} -5l${x2 > x1 ? 1 : -1} 9z" fill="${c}"/>`; if (j.lb) o += T(f1((x1 + x2) / 2), f1(y - 14 - h * .85), j.lb, { fs: 15, st: 1 }) });
    (v.pts || []).forEach(p => { o += `<circle cx="${f1(X(p.i))}" cy="${y}" r="7" fill="${p.c || P.red}" stroke="#fff" stroke-width="2"/>`; if (p.lb) o += T(f1(X(p.i)), y - 22, p.lb, { fs: 17, c: p.c || P.red, st: 1 }) });
    if (v.title) o += T(W / 2, 12, v.title, { fs: 15 });
    return V.svg(W, 124, o);
  };

  // ---------- tasma: foiz modeli
  V.ext['4FG-tasma'] = v => {
    const n = v.n, W = 360, L = 10, u = (W - 2 * L) / n, y = v.top ? 40 : 10, h = 44; let o = '';
    if (v.top) o += `<path d="M${L} ${y - 6}v-8h${W - 2 * L}v8" fill="none" stroke="${LN}" stroke-width="2"/>` + T(W / 2, y - 26, v.top, { fs: 15 });
    for (let i = 0; i < n; i++) {
      o += `<rect x="${f1(L + i * u)}" y="${y}" width="${f1(u)}" height="${h}" fill="${i < (v.k || 0) ? (v.c || '#60a5fa') : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
      if (v.parts && v.parts[i]) o += T(f1(L + i * u + u / 2), y + h / 2, v.parts[i], { fs: u < 40 ? 11 : 14 });
    }
    let H = y + h + 6;
    if (v.bot) { const bk = v.bk || v.k; o += `<path d="M${L} ${y + h + 6}v8h${f1(bk * u)}v-8" fill="none" stroke="${QC}" stroke-width="2"/>` + T(f1(Math.min(W - String(v.bot).length * 4.5 - 4, Math.max(L + bk * u / 2, String(v.bot).length * 4.5 + 4))), y + h + 30, v.bot, { fs: 15, c: QC }); H = y + h + 44 }
    return V.svg(W, H, o);
  };

  // ---------- quti
  V.ext['4FG-quti'] = v => {
    const w = 170, h = 100, d = 56, x = 76, y = 30 + d * .6; let o = '';
    const st = `stroke="${LN}" stroke-width="2.5" stroke-linejoin="round"`;
    o += `<path d="M${x} ${y}h${w}v${h}h${-w}z" fill="#93c5fd" ${st}/>`;
    o += `<path d="M${x} ${y}l${d} ${-d * .6}h${w}l${-d} ${d * .6}z" fill="#dbeafe" ${st}/>`;
    o += `<path d="M${x + w} ${y}l${d} ${-d * .6}v${h}l${-d} ${d * .6}z" fill="#60a5fa" ${st}/>`;
    o += `<path d="M${x + d} ${y - d * .6 + h}v${-h}M${x + d} ${y - d * .6 + h}h${w}M${x + d} ${y - d * .6 + h}l${-d} ${d * .6}" stroke="${LN}" stroke-width="1.6" stroke-dasharray="6 5" fill="none"/>`;
    if (v.a) o += T(x + w / 2, y + h + 18, v.a, { fs: 16 });
    if (v.c) o += T(x - 8, y + h / 2, v.c, { fs: 16, a: 'end' });
    if (v.b) o += T(x + w + d / 2 + 12, y + h - d * .3 + 14, v.b, { fs: 16, a: 'start' });
    return V.svg(x + w + d + 70, y + h + 34, o, 360);
  };

  // ---------- idish: o‘lchov idishi
  V.ext['4FG-idish'] = v => {
    const n = v.n, lab = v.lab || {}, x = 70, w = 120, top = 20, H = 200, u = H / n, yb = top + H; let o = '';
    const lv = v.lvl || 0;
    o += `<rect x="${x}" y="${f1(yb - lv * u)}" width="${w}" height="${f1(lv * u)}" fill="#7dd3fc"/>`;
    o += `<path d="M${x} ${top - 10}V${yb}h${w}V${top - 10}" fill="none" stroke="${LN}" stroke-width="3.5" stroke-linejoin="round"/><path d="M${x + w} ${top + 10}c26 0 30 10 30 34v40c0 20 -10 26 -30 26" fill="none" stroke="${LN}" stroke-width="3.5"/>`;
    for (let i = 1; i <= n; i++) { const yy = f1(yb - i * u), b = lab[i] != null; o += `<line x1="${x}" y1="${yy}" x2="${x + (b ? 26 : 14)}" y2="${yy}" stroke="${LN}" stroke-width="${b ? 2.5 : 1.5}"/>`; if (b) o += T(x - 8, yy, lab[i], { fs: 14, a: 'end' }) }
    return V.svg(x + w + 50, yb + 10, o, 260);
  };

  // ---------- maydon
  V.ext['4FG-maydon'] = v => {
    const k = Math.min(300 / v.w, 160 / v.h), w = v.w * k, h = v.h * k, x = 60, y = 14; let o = '';
    o += `<rect x="${x}" y="${y}" width="${f1(w)}" height="${f1(h)}" fill="${v.c || '#bbf7d0'}" stroke="#166534" stroke-width="3"/>`;
    for (let yy = y + 12; yy < y + h - 4; yy += 14) o += `<line x1="${x + 6}" y1="${f1(yy)}" x2="${f1(x + w - 6)}" y2="${f1(yy)}" stroke="#16a34a55" stroke-width="2"/>`;
    if (v.s) o += `<rect x="${f1(x + w / 2 - 44)}" y="${f1(y + h / 2 - 15)}" width="88" height="30" rx="8" fill="#fff" stroke="#166534" stroke-width="1.5"/>` + T(f1(x + w / 2), f1(y + h / 2), v.s, { fs: 15 });
    if (v.lw) o += T(f1(x + w / 2), f1(y + h + 18), v.lw, { fs: 15 });
    if (v.lh) o += T(x - 8, f1(y + h / 2), v.lh, { fs: 15, a: 'end' });
    return V.svg(f1(x + w + 16), f1(y + h + 34), o, 380);
  };

  // ---------- tarozi: chapda rasm, o‘ngda yozuvli toshlar (yozuv tosh ichiga sig‘adi)
  V.ext['4FG-tarozi'] = v => {
    const cx = 200; let o = `<path d="M${cx - 50} 222h100l-20 -16h-60z" fill="#64748b"/><rect x="${cx - 6}" y="80" width="12" height="130" rx="4" fill="#94a3b8"/><rect x="30" y="76" width="340" height="10" rx="5" fill="#475569"/><circle cx="${cx}" cy="81" r="9" fill="#334155"/>`;
    const pan = x => `<line x1="${x}" y1="86" x2="${x - 70}" y2="160" stroke="#64748b" stroke-width="2"/><line x1="${x}" y1="86" x2="${x + 70}" y2="160" stroke="#64748b" stroke-width="2"/><path d="M${x - 84} 160h168a84 20 0 0 1 -168 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>`;
    o += pan(90) + pan(310);
    o += V.im(v.img, 90 - 40, 82, 80);
    // toshlar ko‘p bo‘lsa (4 va undan ko‘p) ikki qavat qilib qo‘yiladi — yozuvlar mayda bo‘lib, chetdan chiqib ketmasin
    const all = v.w.map(t => ({ t, w: Math.max(44, String(t).length * 11 + 16) })), half = all.length > 3 ? Math.ceil(all.length / 2) : all.length;
    [all.slice(0, half), all.slice(half)].forEach((ws, row) => {
      if (!ws.length) return;
      const tot = ws.reduce((a, b) => a + b.w + 4, -4), sc = tot > 176 ? 176 / tot : 1, h = 34, yb = 160 - row * (h + 12); let x = Math.min(310 - tot * sc / 2, 396 - tot * sc);
      ws.forEach(b => { const w = b.w * sc; o += `<path d="M${f1(x + 4)} ${yb}l4 ${-h}h${f1(w - 16)}l4 ${h}z" fill="#475569"/><rect x="${f1(x + w / 2 - 7)}" y="${yb - h - 8}" width="14" height="10" rx="4" fill="#475569"/>` + T(f1(x + w / 2), yb - h / 2 + 1, b.t, { fs: Math.round(15 * Math.max(sc, .78)), c: '#fff' }); x += w + 4 * sc });
    });
    return V.svg(400, 180, `<g transform="translate(0 -48)">${o}</g>`, 400);
  };
})();

// 4H (4-sinf geometriya) uchun qo‘shimcha rasm turlari. Turlar nomi '4H-' bilan boshlanadi.
//  '4H-fig'   — tekis chizma (birlik — sm yoki katak), o‘lchamga mutanosib; tomon yozuvlari shakldan tashqarida,
//               o‘lcham chiziqlari (dim), burchak yoylari, aylanalar, masshtab chizg‘ichi (sbar), pastki yozuv (cap).
//  '4H-koord' — koordinata burchagi (x o‘ngga, y yuqoriga), o‘q qadami st (1, 2, 5, 10 ...).
//  '4H-katak' — harf-raqamli katakli maydon (A1, B3 ...), kataklarda rasm/rang/yozuv.
//  '4H-quti'  — to‘g‘ri burchakli parallelepiped(lar) o‘lchamlari bilan; birlik kubchalar to‘ri, suv sathi.
// Hamma yozuvlar kamida 14–15 px; chizma eni 336 px dan oshmaydi (telefonda kichraymaydi).
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg;
  const FS = 15, RED = '#dc2626', MAXW = 336;
  const tw = (s, fs = FS) => String(s).length * fs * .56;
  const f1 = n => Math.round(n * 10) / 10;
  const inside = (pt, poly) => { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const a = poly[i], b = poly[j]; if ((a[1] > pt[1]) !== (b[1] > pt[1]) && pt[0] < (b[0] - a[0]) * (pt[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c } return c };
  const arrowHead = (x, y, ang, c, s = 10) => `<path d="M0 0l${-s} ${-s * .5}v${s}z" fill="${c}" transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(ang)})"/>`;

  // ---------- '4H-fig' ----------
  // {w,h (birlikda), u?, grid?, gs?, el:[...], cap?}
  // el: {p:'poly', pts, fill, sc, dash, lb:[tomon yozuvlari], vl:[uch nomlari], lin:true (yozuv ichkarida)}
  //     {p:'seg', a,b, lb, ls:1|-1, c, dash, sw, ends:'pt'|'none'|'arr'|'ray'}
  //     {p:'dim', a,b, lb, off (birlikda, normal tomonga), ls}
  //     {p:'txt', a, s, fs, c, an}   {p:'pt', a, lb, ld:[dx,dy], c}
  //     {p:'circ', c, r, fill, ring, sc, dash}   {p:'cells', list, fill}
  //     {p:'ang', a,b,c (uch — b), right, lb, r (px), arcs (1|2)}
  //     {p:'sbar', a (chap uchi), k (bo‘lak uzunligi, birlikda), n, labs:[...]}
  V.ext['4H-fig'] = v => {
    const w = v.w, h = v.h;
    let ml = 0; for (const e of v.el) { (e.lb && Array.isArray(e.lb) ? e.lb : [e.lb]).forEach(l => { if (l != null) ml = Math.max(ml, tw(l)) }) }
    const pad = Math.max(30, Math.ceil(14 + ml));
    const pl = v.pl != null ? v.pl : pad, pr = v.pr != null ? v.pr : pad, pt = v.pt != null ? v.pt : 30, pb = v.pb != null ? v.pb : 30;
    const u = v.u || Math.max(4, Math.min(v.umax || 34, Math.floor((v.maxW || (MAXW - pl - pr)) / w), Math.floor((v.maxH || 230) / h)));
    const capH = v.cap ? 32 : 0;
    let W = w * u + pl + pr; if (v.cap) W = Math.max(W, tw(v.cap) + 24); W = Math.min(W, MAXW);
    const H = h * u + pt + pb + capH, ox = (W - w * u - pl - pr) / 2 + pl;
    const X = x => ox + x * u, Y = y => pt + y * u, XY = p => [X(p[0]), Y(p[1])];
    let o = '', top = '';
    if (v.grid) { const gs = v.gs || 1; for (let i = 0; i <= w + 1e-9; i += gs) o += `<line x1="${f1(X(i))}" y1="${Y(0)}" x2="${f1(X(i))}" y2="${Y(h)}" stroke="#bfdbfe" stroke-width="1"/>`; for (let j = 0; j <= h + 1e-9; j += gs) o += `<line x1="${X(0)}" y1="${f1(Y(j))}" x2="${X(w)}" y2="${f1(Y(j))}" stroke="#bfdbfe" stroke-width="1"/>` }
    const LB = [], SG = [], FX = [];
    const lab = (mx, my, nx, ny, s, o2 = {}) => { const fs = o2.fs || FS, d = 6 + Math.abs(nx) * tw(s, fs) / 2 + Math.abs(ny) * fs * .62; LB.push({ mx, my, d, len: o2.len || 0, x: mx + nx * d, y: my + ny * d, nx, ny, s, fs, c: o2.c || P.ink, w: tw(s, fs) + 4, h: fs + 2 }); return '' };
    for (const e of v.el) {
      if (e.p === 'cells') for (const q of e.list) o += `<rect x="${f1(X(q[0]) + 1)}" y="${f1(Y(q[1]) + 1)}" width="${u - 2}" height="${u - 2}" rx="2" fill="${q[2] || e.fill || '#93c5fd'}"/>`;
      else if (e.p === 'poly') {
        const pts = e.pts; pts.forEach((p, i) => { const q = pts[(i + 1) % pts.length]; SG.push([X(p[0]), Y(p[1]), X(q[0]), Y(q[1])]) });
        o += `<polygon points="${pts.map(p => f1(X(p[0])) + ',' + f1(Y(p[1]))).join(' ')}" fill="${e.fill || '#bfdbfe99'}" stroke="${e.sc || P.blue}" stroke-width="${e.sw || 3}" stroke-linejoin="round"${e.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
        (e.lb || []).forEach((l, i) => {
          if (l == null || l === '') return; const p = pts[i], q = pts[(i + 1) % pts.length]; const dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy) || 1;
          let nx = dy / L, ny = -dx / L; const m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], eps = Math.min(.05, L / 10);
          const inn = inside([m[0] + nx * eps, m[1] + ny * eps], pts); if (inn !== !!e.lin) { nx = -nx; ny = -ny }
          top += lab(X(m[0]), Y(m[1]), nx, ny, l, { c: l === '?' ? '#b45309' : P.ink, len: L * u });
        });
        if (e.vl) { const cx = pts.reduce((a, p) => a + p[0], 0) / pts.length, cy = pts.reduce((a, p) => a + p[1], 0) / pts.length; e.vl.forEach((l, i) => { if (!l) return; const p = pts[i], n = pts.length, a = pts[(i + n - 1) % n], b = pts[(i + 1) % n]; let dx = (p[0] - a[0]) / (Math.hypot(p[0] - a[0], p[1] - a[1]) || 1) + (p[0] - b[0]) / (Math.hypot(p[0] - b[0], p[1] - b[1]) || 1), dy = (p[1] - a[1]) / (Math.hypot(p[0] - a[0], p[1] - a[1]) || 1) + (p[1] - b[1]) / (Math.hypot(p[0] - b[0], p[1] - b[1]) || 1); let L = Math.hypot(dx, dy); if (L < 1e-6) { dx = p[0] - cx; dy = p[1] - cy; L = Math.hypot(dx, dy) || 1 } if (inside([p[0] + dx / L * .05, p[1] + dy / L * .05], pts)) { dx = -dx; dy = -dy } top += T(f1(X(p[0]) + dx / L * 15), f1(Y(p[1]) + dy / L * 15), l, { fs: 16, c: RED, st: 1 }) }) }
      }
      else if (e.p === 'seg') {
        const [x1, y1] = XY(e.a), [x2, y2] = XY(e.b), c = e.c || P.blue; SG.push([x1, y1, x2, y2]); let bx = x2, by = y2; const ang = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        if (e.ends === 'ray') { const L = Math.hypot(x2 - x1, y2 - y1) || 1; bx = x2 + (x2 - x1) / L * 22; by = y2 + (y2 - y1) / L * 22 }
        o += `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(bx)}" y2="${f1(by)}" stroke="${c}" stroke-width="${e.sw || 3.5}" stroke-linecap="round"${e.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
        if (e.ends === 'arr' || e.ends === 'ray') o += arrowHead(bx + Math.cos(ang * Math.PI / 180) * 2, by + Math.sin(ang * Math.PI / 180) * 2, ang, c);
        if (e.ends === 'pt' || e.ends == null) o += `<circle cx="${f1(x1)}" cy="${f1(y1)}" r="4.5" fill="${P.ink}"/>` + (e.ends === 'pt' || e.ends == null ? `<circle cx="${f1(x2)}" cy="${f1(y2)}" r="4.5" fill="${P.ink}"/>` : '');
        if (e.lb) { const L = Math.hypot(x2 - x1, y2 - y1) || 1, s = e.ls || 1; top += lab((x1 + x2) / 2, (y1 + y2) / 2, s * (y2 - y1) / L, -s * (x2 - x1) / L, e.lb, { c: e.lc || P.ink }) }
      }
      else if (e.p === 'dim') {
        const s = e.ls || 1, off = e.off == null ? .8 : e.off; const dx = e.b[0] - e.a[0], dy = e.b[1] - e.a[1], L = Math.hypot(dx, dy) || 1; const nx = s * dy / L, ny = -s * dx / L;
        const A = [e.a[0] + nx * off, e.a[1] + ny * off], B = [e.b[0] + nx * off, e.b[1] + ny * off]; const [x1, y1] = XY(A), [x2, y2] = XY(B), ang = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        o += `<line x1="${f1(X(e.a[0]))}" y1="${f1(Y(e.a[1]))}" x2="${f1(x1 + nx * 6)}" y2="${f1(y1 + ny * 6)}" stroke="#64748b" stroke-width="1.3"/><line x1="${f1(X(e.b[0]))}" y1="${f1(Y(e.b[1]))}" x2="${f1(x2 + nx * 6)}" y2="${f1(y2 + ny * 6)}" stroke="#64748b" stroke-width="1.3"/>`;
        SG.push([x1, y1, x2, y2]); o += `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}" stroke="#475569" stroke-width="1.8"/>` + arrowHead(x2, y2, ang, '#475569', 9) + arrowHead(x1, y1, ang + 180, '#475569', 9);
        if (e.lb) top += lab((x1 + x2) / 2, (y1 + y2) / 2, nx, ny, e.lb, { c: e.lb === '?' ? '#b45309' : (e.c || P.ink) });
      }
      else if (e.p === 'circ') o += `<circle cx="${f1(X(e.c[0]))}" cy="${f1(Y(e.c[1]))}" r="${f1(e.r * u)}" fill="${e.ring ? 'none' : (e.fill || '#bfdbfe99')}" stroke="${e.sc || P.blue}" stroke-width="${e.sw || 3}"${e.dash ? ' stroke-dasharray="7 6"' : ''}/>`;
      else if (e.p === 'pt') { o += `<circle cx="${f1(X(e.a[0]))}" cy="${f1(Y(e.a[1]))}" r="5" fill="${e.c || P.ink}"/>`; if (e.lb) { const d = e.ld || [12, -13]; top += T(f1(X(e.a[0]) + d[0]), f1(Y(e.a[1]) + d[1]), e.lb, { fs: 16, c: e.lc || RED, st: 1 }) } }
      else if (e.p === 'txt') FX.push({ x: X(e.a[0]), y: Y(e.a[1]), w: tw(e.s, e.fs || FS), h: (e.fs || FS) + 2 }), top += T(f1(X(e.a[0])), f1(Y(e.a[1])), e.s, { fs: e.fs || FS, c: e.c || P.ink, st: e.nost ? 0 : 1, a: e.an || 'middle' });
      else if (e.p === 'ang') {
        const [a, b, c] = [XY(e.a), XY(e.b), XY(e.c)], a1 = Math.atan2(a[1] - b[1], a[0] - b[0]), a2 = Math.atan2(c[1] - b[1], c[0] - b[0]), r = e.r || 22;
        if (e.rays) { o += `<line x1="${f1(b[0])}" y1="${f1(b[1])}" x2="${f1(a[0])}" y2="${f1(a[1])}" stroke="${P.blue}" stroke-width="3.5" stroke-linecap="round"/><line x1="${f1(b[0])}" y1="${f1(b[1])}" x2="${f1(c[0])}" y2="${f1(c[1])}" stroke="${P.blue}" stroke-width="3.5" stroke-linecap="round"/>` }
        let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; const mid = a1 + d / 2;
        if (e.right) { const k = 13, p1 = [b[0] + Math.cos(a1) * k, b[1] + Math.sin(a1) * k], p3 = [b[0] + Math.cos(a2) * k, b[1] + Math.sin(a2) * k], p2 = [p1[0] + p3[0] - b[0], p1[1] + p3[1] - b[1]]; o += `<path d="M${f1(p1[0])} ${f1(p1[1])}L${f1(p2[0])} ${f1(p2[1])}L${f1(p3[0])} ${f1(p3[1])}" fill="none" stroke="${RED}" stroke-width="2.5"/>` }
        else for (let k = 0; k < (e.arcs || 1); k++) { const rr = r + k * 5, p1 = [b[0] + Math.cos(a1) * rr, b[1] + Math.sin(a1) * rr], p2 = [b[0] + Math.cos(a2) * rr, b[1] + Math.sin(a2) * rr]; o += `<path d="M${f1(p1[0])} ${f1(p1[1])}A${rr} ${rr} 0 0 ${d > 0 ? 1 : 0} ${f1(p2[0])} ${f1(p2[1])}" fill="none" stroke="${e.col || RED}" stroke-width="2.5"/>` }
        if (e.lb) { const R2 = (e.lr || Math.min(130, Math.max(r + 8 + tw(e.lb) * .45, (Math.hypot(tw(e.lb) / 2, FS / 2) + 4) / Math.max(.05, Math.sin(Math.abs(d) / 2))))); top += T(f1(b[0] + Math.cos(mid) * R2), f1(b[1] + Math.sin(mid) * R2), e.lb, { fs: FS, c: e.lb.includes('?') ? '#b45309' : RED, st: 1 }) }
        if (e.dot !== false) o += `<circle cx="${f1(b[0])}" cy="${f1(b[1])}" r="4" fill="${P.ink}"/>`;
      }
      else if (e.p === 'sbar') {
        const x0 = X(e.a[0]), y0 = Y(e.a[1]), k = e.k * u;
        for (let i = 0; i < e.n; i++) o += `<rect x="${f1(x0 + i * k)}" y="${f1(y0 - 5)}" width="${f1(k)}" height="10" fill="${i % 2 ? '#fff' : '#334155'}" stroke="#334155" stroke-width="1.5"/>`;
        (e.labs || []).forEach((l, i) => { if (l !== '' && l != null) top += T(f1(x0 + i * k), f1(y0 + 18), l, { fs: 14, st: 1 }) });
      }
    }
    // yozuvlar ustma-ust tushmasin: to‘qnashganini o‘z normali bo‘ylab tashqariga suramiz
    // har yozuv uchun nomzod joylar: chiziqlarni va boshqa yozuvlarni kesmaydigan birinchisi tanlanadi
    const segHit = (q, x, y) => { const x0 = x - q.w / 2 + 1, x1 = x + q.w / 2 - 1, y0 = y - q.h / 2 + 2, y1 = y + q.h / 2 - 2; return SG.some(([ax, ay, bx, by]) => { let t0 = 0, t1 = 1; const dx = bx - ax, dy = by - ay; for (const [pp, qq] of [[-dx, ax - x0], [dx, x1 - ax], [-dy, ay - y0], [dy, y1 - ay]]) { if (pp === 0) { if (qq < 0) return false } else { const r = qq / pp; if (pp < 0) { if (r > t1) return false; if (r > t0) t0 = r } else { if (r < t0) return false; if (r < t1) t1 = r } } } return true }) };
    const boxHit = (q, x, y, list) => list.some(b => Math.abs(x - b.x) < (q.w + b.w) / 2 && Math.abs(y - b.y) < (q.h + b.h) / 2);
    const placed = FX.slice();
    LB.slice().sort((a, b) => a.len - b.len).forEach(q => {
      const tx = -q.ny, ty = q.nx, cands = [];
      for (const ex of [0, 4, 9, 15, 22]) for (const sh of [0, .25, -.25, .42, -.42]) cands.push([q.mx + q.nx * (q.d + ex) + tx * sh * q.len, q.my + q.ny * (q.d + ex) + ty * sh * q.len]);
      const ok = cands.find(c => !segHit(q, c[0], c[1]) && !boxHit(q, c[0], c[1], placed) && c[0] - q.w / 2 > 0 && c[0] + q.w / 2 < W && c[1] - q.h / 2 > 0 && c[1] + q.h / 2 < H) || cands.find(c => !boxHit(q, c[0], c[1], placed)) || cands[0];
      q.x = ok[0]; q.y = ok[1]; placed.push(q);
    });
    LB.forEach(q => top += T(f1(q.x), f1(q.y), q.s, { fs: q.fs, st: 1, c: q.c }));
    if (v.gridTop) { let gl = ''; for (let i = 0; i <= w; i++) gl += `<line x1="${f1(X(i))}" y1="${Y(0)}" x2="${f1(X(i))}" y2="${Y(h)}"/>`; for (let j = 0; j <= h; j++) gl += `<line x1="${X(0)}" y1="${f1(Y(j))}" x2="${X(w)}" y2="${f1(Y(j))}"/>`; top = `<g stroke="#475569" stroke-width="1" opacity=".35">${gl}</g>` + top }
    if (v.cap) top += T(W / 2, H - 16, v.cap, { fs: FS, c: v.capc || '#7c2d12' });
    return svg(f1(W), f1(H), o + top, f1(W));
  };

  // ---------- '4H-koord' ----------
  // {w,h (kataklar soni), st (bitta katak necha birlik, 1), lab (har nechta katakda son yozilsin), pts:[{x,y,lb,c,ld}],
  //  polys:[{pts,fill,c}], segs:[{a,b,c,dash,arr}], cells:[{x,y,fill}] (haqiqiy koordinatada chap-past burchak), nm (o‘q nomlari)}
  V.ext['4H-koord'] = v => {
    const w = v.w, h = v.h, st = v.st || 1, u = v.u || Math.min(30, Math.floor(258 / w), Math.floor(250 / h)), L = 40, Tp = 26, R = 30, B = 32;
    const X = x => L + x / st * u, Y = y => Tp + (h - y / st) * u, W = L + w * u + R, H = Tp + h * u + B; let o = '', top = '';
    (v.cells || []).forEach(c => o += `<rect x="${f1(X(c.x) + 1)}" y="${f1(Y(c.y + st) + 1)}" width="${u - 2}" height="${u - 2}" rx="2" fill="${c.fill || '#93c5fd'}"/>`);
    for (let i = 0; i <= w; i++) o += `<line x1="${f1(L + i * u)}" y1="${Tp}" x2="${f1(L + i * u)}" y2="${Tp + h * u}" stroke="#bfdbfe" stroke-width="1"/>`;
    for (let j = 0; j <= h; j++) o += `<line x1="${L}" y1="${f1(Tp + j * u)}" x2="${L + w * u}" y2="${f1(Tp + j * u)}" stroke="#bfdbfe" stroke-width="1"/>`;
    o += `<line x1="${L}" y1="${Tp + h * u}" x2="${L + w * u + 18}" y2="${Tp + h * u}" stroke="${P.line}" stroke-width="2.5"/>` + arrowHead(L + w * u + 20, Tp + h * u, 0, P.line);
    o += `<line x1="${L}" y1="${Tp + h * u}" x2="${L}" y2="${Tp - 16}" stroke="${P.line}" stroke-width="2.5"/>` + arrowHead(L, Tp - 18, -90, P.line);
    const lb = v.lab || (String(w * st).length * 9 > u ? 2 : 1), fs = 14;
    for (let i = lb; i <= w; i += lb) top += T(f1(L + i * u), Tp + h * u + 15, i * st, { fs });
    for (let j = lb; j <= h; j += lb) top += T(L - 7, f1(Tp + (h - j) * u), j * st, { fs, a: 'end' });
    top += T(L - 7, Tp + h * u + 13, '0', { fs, a: 'end' });
    if (v.nm !== false) { top += T(L + w * u + 22, Tp + h * u - 13, 'x', { fs: 16, c: P.line }); top += T(L + 14, Tp - 16, 'y', { fs: 16, c: P.line }) }
    (v.polys || []).forEach(p => o += `<polygon points="${p.pts.map(q => f1(X(q[0])) + ',' + f1(Y(q[1]))).join(' ')}" fill="${p.fill || '#bfdbfe99'}" stroke="${p.c || P.blue}" stroke-width="3" stroke-linejoin="round"${p.dash ? ' stroke-dasharray="7 6"' : ''}/>`);
    (v.segs || []).forEach(s => { o += `<line x1="${f1(X(s.a[0]))}" y1="${f1(Y(s.a[1]))}" x2="${f1(X(s.b[0]))}" y2="${f1(Y(s.b[1]))}" stroke="${s.c || P.blue}" stroke-width="3.5" stroke-linecap="round"${s.dash ? ' stroke-dasharray="7 6"' : ''}/>`; if (s.arr) o += arrowHead(X(s.b[0]), Y(s.b[1]), Math.atan2(Y(s.b[1]) - Y(s.a[1]), X(s.b[0]) - X(s.a[0])) * 180 / Math.PI, s.c || P.blue) });
    (v.pts || []).forEach(p => { o += `<circle cx="${f1(X(p.x))}" cy="${f1(Y(p.y))}" r="5.5" fill="${p.c || RED}" stroke="#fff" stroke-width="1.5"/>`; if (p.lb) { const d = p.ld || [11, -13]; top += T(f1(X(p.x) + d[0]), f1(Y(p.y) + d[1]), p.lb, { fs: 16, c: p.c || RED, st: 1 }) } });
    return svg(W, H, o + top, W);
  };

  // ---------- '4H-katak' ----------
  // {cols, rows, items:[{c (ustun 0..), r (qator 0.. pastdan), img, fill, s}], hl:[[c,r]]} — ustunlar harf bilan, qatorlar raqam bilan (pastdan)
  const ABC = ['A', 'B', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'];
  V.ext['4H-katak'] = v => {
    const n = v.cols, m = v.rows, u = v.u || Math.min(38, Math.floor(270 / n), Math.floor(270 / m)), L = 30, Tp = 8, B = 28;
    const W = L + n * u + 10, H = Tp + m * u + B, X = c => L + c * u, Y = r => Tp + (m - 1 - r) * u; let o = '';
    (v.items || []).forEach(it => { if (it.fill) o += `<rect x="${X(it.c) + 1}" y="${Y(it.r) + 1}" width="${u - 2}" height="${u - 2}" rx="3" fill="${it.fill}"/>` });
    for (let i = 0; i <= n; i++) o += `<line x1="${X(i)}" y1="${Tp}" x2="${X(i)}" y2="${Tp + m * u}" stroke="#60a5fa" stroke-width="1.5"/>`;
    for (let j = 0; j <= m; j++) o += `<line x1="${L}" y1="${Tp + j * u}" x2="${L + n * u}" y2="${Tp + j * u}" stroke="#60a5fa" stroke-width="1.5"/>`;
    for (let i = 0; i < n; i++) o += T(X(i) + u / 2, Tp + m * u + 15, ABC[i], { fs: 15, c: P.ink });
    for (let j = 0; j < m; j++) o += T(L - 12, Y(j) + u / 2, j + 1, { fs: 15, c: P.ink });
    (v.items || []).forEach(it => { if (it.img) o += V.im(it.img, X(it.c) + 3, Y(it.r) + 3, u - 6); if (it.s) o += T(X(it.c) + u / 2, Y(it.r) + u / 2 + 1, it.s, { fs: it.fs || Math.max(15, Math.min(22, u * .55)), c: it.c2 || P.ink }) });
    (v.hl || []).forEach(q => o += `<rect x="${X(q[0]) + 2}" y="${Y(q[1]) + 2}" width="${u - 4}" height="${u - 4}" rx="4" fill="none" stroke="${RED}" stroke-width="3"/>`);
    return svg(W, H, o, W);
  };
  V.ABC = ABC;

  // ---------- '4H-ruler' ----------
  // chizg‘ich (telefonga sig‘adi, raqamlar 14 px): {n (sm), seg:[a,b], lb (kesma ustidagi yozuv), la, lbb (uchlar nomi)}
  V.ext['4H-ruler'] = v => {
    const n = v.n, u = Math.min(32, Math.floor(296 / n)), L = 18, W = L * 2 + n * u, top = v.lb ? 58 : 34; let o = '';
    o += `<rect x="4" y="${top}" width="${W - 8}" height="50" rx="8" fill="#fde68a" stroke="#d97706" stroke-width="2"/>`;
    const every = u >= 20 ? 1 : 2;
    for (let i = 0; i <= n; i++) { o += `<line x1="${L + i * u}" y1="${top}" x2="${L + i * u}" y2="${top + 18}" stroke="#78350f" stroke-width="2"/>`; if (i % every === 0) o += T(L + i * u, top + 33, i, { fs: 14, c: '#78350f' }); if (i < n) o += `<line x1="${L + (i + .5) * u}" y1="${top}" x2="${L + (i + .5) * u}" y2="${top + 10}" stroke="#78350f" stroke-width="1.3"/>` }
    if (v.seg) { const [a, b] = v.seg, y = top - 14; o += `<line x1="${L + a * u}" y1="${y}" x2="${L + b * u}" y2="${y}" stroke="${P.blue}" stroke-width="6" stroke-linecap="round"/><circle cx="${L + a * u}" cy="${y}" r="5.5" fill="${P.ink}"/><circle cx="${L + b * u}" cy="${y}" r="5.5" fill="${P.ink}"/>`;
      if (v.lb) o += T(L + (a + b) / 2 * u, y - 20, v.lb, { fs: 15, st: 1 }); if (v.la) o += T(L + a * u - 2, y - 18, v.la, { fs: 16, c: RED, st: 1, a: 'end' }); if (v.lbb) o += T(L + b * u + 2, y - 18, v.lbb, { fs: 16, c: RED, st: 1, a: 'start' }) }
    if (v.cap) o += T(W / 2, top + 72, v.cap, { fs: 15, c: '#7c2d12' });
    return svg(W, top + (v.cap ? 86 : 56), o, W);
  };

  // ---------- '4H-quti' ----------
  // {boxes:[{x,y,z,a,b,c,f:[old,yuqori,o‘ng]}] yoki a,b,c (bitta quti), la,lb,lc (o‘lcham yozuvlari), grid (birlik kubchalar), hid, water (suv balandligi),
  //  lbl:[[i,k,j,matn,dx,dy]] — qo‘shimcha yozuvlar}  (i — eni (o‘ngga), k — chuqurlik (orqaga), j — balandlik (yuqoriga))
  V.ext['4H-quti'] = v => {
    const boxes = v.boxes || [{ x: 0, y: 0, z: 0, a: v.a, b: v.b, c: v.c }];
    const A = Math.max(...boxes.map(q => q.x + q.a)), Bd = Math.max(...boxes.map(q => q.y + q.b)), Cc = Math.max(...boxes.map(q => q.z + q.c));
    const s = v.s || Math.min(46, (v.maxW || 196) / (A + Bd * .55), (v.maxH || 160) / (Cc + Bd * .42));
    const ddx = s * .55, ddy = -s * .42, ox = v.ox || 70, oy = 24 + Bd * -ddy + Cc * s;
    const F = (i, k, j) => [ox + i * s + k * ddx, oy - j * s + k * ddy];
    const pt = p => f1(p[0]) + ' ' + f1(p[1]); let o = '', top = '';
    const face = (pts, fill, op) => `<path d="M${pts.map(pt).join('L')}z" fill="${fill}" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"${op ? ` fill-opacity="${op}"` : ''}/>`;
    const ln = (p, q, sw = 1.2, op = .7) => `<line x1="${f1(p[0])}" y1="${f1(p[1])}" x2="${f1(q[0])}" y2="${f1(q[1])}" stroke="#1e3a8a" stroke-width="${sw}" opacity="${op}"/>`;
    const order = boxes.slice().sort((p, q) => (q.y - p.y) || (p.z - q.z) || (p.x - q.x));
    for (const q of order) {
      const { x, y, z, a, b, c } = q, f = q.f || [v.f1 || '#93c5fd', v.f2 || '#dbeafe', v.f3 || '#60a5fa'];
      const G = (i, k, j) => F(x + i, y + k, z + j);
      if (v.water) { o += face([G(0, 0, 0), G(a, 0, 0), G(a, 0, c), G(0, 0, c)], '#e0f2fe', .55) + face([G(a, 0, 0), G(a, b, 0), G(a, b, c), G(a, 0, c)], '#e0f2fe', .45) + face([G(0, 0, c), G(a, 0, c), G(a, b, c), G(0, b, c)], '#f0f9ff', .4) }
      else { o += face([G(0, 0, 0), G(a, 0, 0), G(a, 0, c), G(0, 0, c)], f[0]); o += face([G(0, 0, c), G(a, 0, c), G(a, b, c), G(0, b, c)], f[1]); o += face([G(a, 0, 0), G(a, b, 0), G(a, b, c), G(a, 0, c)], f[2]) }
      if (v.grid || q.grid) {
        for (let i = 1; i < a; i++) { o += ln(G(i, 0, 0), G(i, 0, c)); o += ln(G(i, 0, c), G(i, b, c)) }
        for (let j = 1; j < c; j++) { o += ln(G(0, 0, j), G(a, 0, j)); o += ln(G(a, 0, j), G(a, b, j)) }
        for (let k = 1; k < b; k++) { o += ln(G(0, k, c), G(a, k, c)); o += ln(G(a, k, 0), G(a, k, c)) }
      }
      if (v.water) {
        const hw = v.water, wf = (pp) => face(pp, '#38bdf8', .55);
        o += `<path d="M${[G(0, b, 0), G(0, b, hw)].map(pt).join('L')}" stroke="#1e3a8a" stroke-width="1.5" stroke-dasharray="6 5" fill="none"/>`;
        o += wf([G(0, 0, 0), G(a, 0, 0), G(a, 0, hw), G(0, 0, hw)]) + wf([G(a, 0, 0), G(a, b, 0), G(a, b, hw), G(a, 0, hw)]) + face([G(0, 0, hw), G(a, 0, hw), G(a, b, hw), G(0, b, hw)], '#7dd3fc', .6);
        o += face([G(0, 0, 0), G(a, 0, 0), G(a, 0, c), G(0, 0, c)], 'none') + face([G(a, 0, 0), G(a, b, 0), G(a, b, c), G(a, 0, c)], 'none') + face([G(0, 0, c), G(a, 0, c), G(a, b, c), G(0, b, c)], 'none');
      }
    }
    if (v.hid) { const H0 = F(0, Bd, 0); [F(A, Bd, 0), F(0, 0, 0), F(0, Bd, Cc)].forEach(q => o += `<line x1="${f1(H0[0])}" y1="${f1(H0[1])}" x2="${f1(q[0])}" y2="${f1(q[1])}" stroke="#1e3a8a" stroke-width="1.8" stroke-dasharray="6 5"/>`) }
    const lbs = (v.lbl || []).slice();
    if (v.la) lbs.push([A / 2, 0, 0, v.la, 0, 15]);
    if (v.lc) lbs.push([0, 0, Cc / 2, v.lc, -8 - tw(v.lc) / 2, 0]);
    if (v.lb) lbs.push([A, Bd / 2, 0, v.lb, 10 + tw(v.lb) / 2, 8]);
    let minX = 1e9, maxX = -1e9;
    lbs.forEach(q => { const p = F(q[0], q[1], q[2]), x = p[0] + (q[4] || 0), y = p[1] + (q[5] || 0); minX = Math.min(minX, x - tw(q[3]) / 2); maxX = Math.max(maxX, x + tw(q[3]) / 2); top += T(f1(x), f1(y), q[3], { fs: FS, c: q[6] || RED, st: 1 }) });
    const right = Math.max(F(A, Bd, 0)[0], maxX) + 8, left = Math.min(ox, minX) - 6, H = oy + 26;
    const W = right - left; return svg(f1(W), f1(H), `<g transform="translate(${f1(-left)} 0)">${o}${top}</g>`, f1(Math.min(W, MAXW)));
  };
})();

// 4H7–4H11 (4-sinf geometriya) uchun qo‘shimcha rasm turlari. Turlar nomi '4H7-' bilan boshlanadi.
//  '4H7-tr'   — transportir (gradus shkalasi: ko‘k — o‘ngdan, qizil — chapdan) va burchak nurlari
//  '4H7-ang'  — bir uchdan chiqqan nurlar, haqiqiy gradusda; yoylar va yozuvlar
//  '4H7-poly' — ko‘pburchak (uchburchak) burchak yozuvlari bilan, haqiqiy shaklda
//  '4H7-grid' — katakli maydon: kataklar, ko‘pburchaklar, kesmalar, cho‘zilgan to‘g‘ri chiziqlar, nuqtalar, to‘g‘ri burchak belgisi
//  '4H7-nl'   — sonli nur (shkala, nuqtalar, sakrashlar, kesmalar, harakat strelkalari)
//  '4H7-sol'  — fazoviy shakllar qatori: prizma/piramida (n burchakli asos), shar, silindr, konus, kub
//  '4H7-net'  — yoyilmalar: prizma, piramida, silindr, konus (bir yoki bir nechta, harfli)
// Yozuvlar telefonda (≈340px kenglik) kamida 14px bo‘lishi uchun viewBox kengligi 340–420 atrofida, shrift 15–18.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg;
  const rad = d => d * Math.PI / 180, r1 = n => Math.round(n * 10) / 10;
  const INK = '#1e3a8a';

  // ---------- transportir ----------
  // {rays:[gradus (ko‘k shkala bo‘yicha, 0 — o‘ngda)], lb:['A','B'] nur uchlari, vx:'O', arc:[i,j] (yoy), arcLb:'?', lab:20, one:false}
  V.ext['4H7-tr'] = v => {
    const W = 400, cx = 200, R = 160, cy = 206, H = 238, lab = v.lab || 20; let o = '', nums = '';
    const pt = (d, r) => [cx + r * Math.cos(rad(d)), cy - r * Math.sin(rad(d))];
    o += `<path d="M${cx - R} ${cy}A${R} ${R} 0 0 1 ${cx + R} ${cy}Z" fill="#e0f2fe" fill-opacity=".85" stroke="#0369a1" stroke-width="2.5"/>`;
    o += `<path d="M${cx - 62} ${cy}A62 62 0 0 1 ${cx + 62} ${cy}" fill="none" stroke="#7dd3fc" stroke-width="1.5"/>`;
    for (let d = 0; d <= 180; d += 5) {
      const L = d % 10 === 0 ? 15 : 8, a = pt(d, R), b = pt(d, R - L);
      o += `<line x1="${r1(a[0])}" y1="${r1(a[1])}" x2="${r1(b[0])}" y2="${r1(b[1])}" stroke="#0c4a6e" stroke-width="${d % 10 === 0 ? 2 : 1.2}"/>`;
      if (!v.one && d % 10 === 0) { const c1 = pt(d, 66), c2 = pt(d, 74); o += `<line x1="${r1(c1[0])}" y1="${r1(c1[1])}" x2="${r1(c2[0])}" y2="${r1(c2[1])}" stroke="#0c4a6e" stroke-width="1.2"/>` }
    }
    for (let d = 0; d <= 180; d += lab) {
      const up = (d === 0 || d === 180) ? 11 : 0, p = pt(d, R - 31); nums += T(r1(p[0]), r1(p[1] - up), d, { fs: 17, c: '#1d4ed8', st: 1 });
      if (!v.one) { const q = pt(d, R - 64); nums += T(r1(q[0]), r1(q[1] - up), 180 - d, { fs: 17, c: '#dc2626', st: 1 }) }
    }
    o += `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#0369a1" stroke-width="2"/>`;
    const rays = v.rays || [];
    if (v.arc) {
      const [i, j] = v.arc, a = Math.min(rays[i], rays[j]), b = Math.max(rays[i], rays[j]), r = 40, p = pt(a, r), q = pt(b, r);
      o += `<path d="M${cx} ${cy}L${r1(p[0])} ${r1(p[1])}A${r} ${r} 0 0 0 ${r1(q[0])} ${r1(q[1])}Z" fill="#fde68a" stroke="${P.red}" stroke-width="2.5"/>`;
      if (v.arcLb) { const m = pt((a + b) / 2, b - a < 30 ? 52 : 26); o += T(r1(m[0]), r1(m[1]), v.arcLb, { fs: 16, c: '#b45309', st: 1 }) }
    }
    rays.forEach((d, i) => {
      const e = pt(d, R + 22), l = pt(d, R + 34); o += `<line x1="${cx}" y1="${cy}" x2="${r1(e[0])}" y2="${r1(e[1])}" stroke="${INK}" stroke-width="3.5" stroke-linecap="round"/>`;
      if (v.lb && v.lb[i]) o += T(r1(Math.min(W - 10, Math.max(10, l[0]))), r1(Math.min(cy - 10, l[1])), v.lb[i], { fs: 18, c: P.red, st: 1 });
    });
    o += nums + `<circle cx="${cx}" cy="${cy}" r="5" fill="${INK}"/>`;
    if (v.vx) o += T(cx, cy + 19, v.vx, { fs: 18, c: P.red, st: 1 });
    return svg(W, H, o, 400);
  };

  // ---------- nurlar: {rays:[{d,lb,c,dash}], vx, arcs:[{f,t,lb,r,c}], right:[[i,j]], len, line:[i,j] (to‘g‘ri chiziq belgisi shart emas)}
  V.ext['4H7-ang'] = v => {
    const L = v.len || 130, rays = v.rays; const ends = rays.map(r => [Math.cos(rad(r.d)) * L, -Math.sin(rad(r.d)) * L]);
    const xs = [0, ...ends.map(e => e[0])], ys = [0, ...ends.map(e => e[1])], pad = 34;
    (v.arcs || []).forEach((a, k) => { if (!a.lb) return; let d1 = rays[a.f].d, d2 = rays[a.t].d; if (d2 < d1) d2 += 360; const r = (a.lr || (a.r || (30 + k % 3 * 12)) + 26) + 10, m = (d1 + d2) / 2; xs.push(Math.cos(rad(m)) * r); ys.push(-Math.sin(rad(m)) * r) });
    if (v.vx) { const dd = v.vxd != null ? v.vxd : 270; xs.push(Math.cos(rad(dd)) * 22); ys.push(-Math.sin(rad(dd)) * 22) }
    const minx = Math.min(...xs) - pad, maxx = Math.max(...xs) + pad, miny = Math.min(...ys) - pad, maxy = Math.max(...ys) + pad;
    const W = Math.max(260, maxx - minx), H = maxy - miny, ox = -minx + (W - (maxx - minx)) / 2, oy = -miny; let o = '';
    const P2 = (d, r) => [ox + Math.cos(rad(d)) * r, oy - Math.sin(rad(d)) * r];
    (v.arcs || []).forEach((a, k) => {
      let d1 = rays[a.f].d, d2 = rays[a.t].d; if (d2 < d1) d2 += 360; const r = a.r || (30 + k % 3 * 12), p = P2(d1, r), q = P2(d2, r), big = d2 - d1 > 180 ? 1 : 0;
      o += `<path d="M${ox} ${oy}L${r1(p[0])} ${r1(p[1])}A${r} ${r} 0 ${big} 0 ${r1(q[0])} ${r1(q[1])}Z" fill="${a.fill || ['#fde68a', '#bbf7d0', '#fbcfe8', '#ddd6fe'][k % 4]}" fill-opacity=".8" stroke="none"/>`;
      o += `<path d="M${r1(p[0])} ${r1(p[1])}A${r} ${r} 0 ${big} 0 ${r1(q[0])} ${r1(q[1])}" fill="none" stroke="${a.c || P.red}" stroke-width="2.5"/>`;
      if (a.lb) { const m = (d1 + d2) / 2, rr = r + (d2 - d1 < 35 ? 26 : 20); const t = P2(m, a.lr || rr); o += T(r1(t[0]), r1(t[1]), a.lb, { fs: 16, c: a.lb === '?' ? '#b45309' : P.ink, st: 1 }) }
    });
    (v.right || []).forEach(([i, j]) => { const s = 15, a = P2(rays[i].d, s), b = P2(rays[j].d, s), c = [a[0] + b[0] - ox, a[1] + b[1] - oy]; o += `<path d="M${r1(a[0])} ${r1(a[1])}L${r1(c[0])} ${r1(c[1])}L${r1(b[0])} ${r1(b[1])}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` });
    rays.forEach((r, i) => {
      const e = P2(r.d, L); o += `<line x1="${ox}" y1="${oy}" x2="${r1(e[0])}" y2="${r1(e[1])}" stroke="${r.c || INK}" stroke-width="3.5" stroke-linecap="round"${r.dash ? ' stroke-dasharray="8 6"' : ''}/>`;
      if (!v.noArrow) o += `<path d="M0 0l-11 -6v12z" fill="${r.c || INK}" transform="translate(${r1(e[0])} ${r1(e[1])}) rotate(${-r.d})"/>`;
      if (r.lb) { const t = P2(r.d, L + 18); o += T(r1(t[0]), r1(t[1]), r.lb, { fs: 17, c: P.red, st: 1 }) }
    });
    o += `<circle cx="${ox}" cy="${oy}" r="5" fill="${INK}"/>`;
    if (v.vx) { const dd = v.vxd != null ? v.vxd : 270; const t = P2(dd, 20); o += T(r1(t[0]), r1(t[1]), v.vx, { fs: 17, c: P.red, st: 1 }) }
    return svg(r1(W), r1(H), o, Math.min(380, W));
  };

  // ---------- ko‘pburchak: {pts:[[x,y]] (y yuqoriga), vl:[uch harflari], al:[burchak yozuvlari], sl:[tomon yozuvlari], fill, box:[w,h]}
  V.ext['4H7-poly'] = v => {
    const pts = v.pts, n = pts.length, bw = (v.box || [300, 190])[0], bh = (v.box || [300, 190])[1], pad = 30;
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]); const mnx = Math.min(...xs), mxx = Math.max(...xs), mny = Math.min(...ys), mxy = Math.max(...ys);
    const k = Math.min(bw / ((mxx - mnx) || 1), bh / ((mxy - mny) || 1)); const W = (mxx - mnx) * k + pad * 2, H = (mxy - mny) * k + pad * 2;
    const Q = p => [pad + (p[0] - mnx) * k, pad + (mxy - p[1]) * k]; const S = pts.map(Q); let o = '';
    const cx = S.reduce((a, p) => a + p[0], 0) / n, cy = S.reduce((a, p) => a + p[1], 0) / n;
    o += `<polygon points="${S.map(p => r1(p[0]) + ',' + r1(p[1])).join(' ')}" fill="${v.fill || '#dbeafe'}" stroke="${P.blue}" stroke-width="3" stroke-linejoin="round"/>`;
    (v.segs || []).forEach(s => { const a = Q(s[0]), b = Q(s[1]); o += `<line x1="${r1(a[0])}" y1="${r1(a[1])}" x2="${r1(b[0])}" y2="${r1(b[1])}" stroke="${P.blue}" stroke-width="2.5"${s[2] ? ' stroke-dasharray="7 5"' : ''}/>` });
    S.forEach((p, i) => {
      const a = S[(i + n - 1) % n], b = S[(i + 1) % n]; const u1 = Math.atan2(a[1] - p[1], a[0] - p[0]), u2 = Math.atan2(b[1] - p[1], b[0] - p[0]);
      let d = u2 - u1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
      const ang = Math.abs(d) * 180 / Math.PI, mid = u1 + d / 2; const lab = v.al && v.al[i];
      if (lab) {
        if (Math.abs(ang - 90) < .5 && v.rt !== false) { const s = 14, q1 = [p[0] + Math.cos(u1) * s, p[1] + Math.sin(u1) * s], q3 = [p[0] + Math.cos(u2) * s, p[1] + Math.sin(u2) * s]; o += `<path d="M${r1(q1[0])} ${r1(q1[1])}L${r1(q1[0] + q3[0] - p[0])} ${r1(q1[1] + q3[1] - p[1])}L${r1(q3[0])} ${r1(q3[1])}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` }
        else { const r = 22, q1 = [p[0] + Math.cos(u1) * r, p[1] + Math.sin(u1) * r], q2 = [p[0] + Math.cos(u2) * r, p[1] + Math.sin(u2) * r]; o += `<path d="M${r1(q1[0])} ${r1(q1[1])}A${r} ${r} 0 0 ${d > 0 ? 1 : 0} ${r1(q2[0])} ${r1(q2[1])}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` }
        const rr = ang < 40 ? 58 : ang < 70 ? 44 : 36; o += T(r1(p[0] + Math.cos(mid) * rr), r1(p[1] + Math.sin(mid) * rr), lab, { fs: 16, c: lab === '?' ? '#b45309' : P.ink, st: 1 });
      }
      if (v.vl && v.vl[i]) { const dx = p[0] - cx, dy = p[1] - cy, dd = Math.hypot(dx, dy) || 1; o += T(r1(p[0] + dx / dd * 17), r1(p[1] + dy / dd * 17), v.vl[i], { fs: 17, c: P.red, st: 1 }) }
      if (v.sl && v.sl[i]) { const q = S[(i + 1) % n], mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2, dx = mx - cx, dy = my - cy, dd = Math.hypot(dx, dy) || 1; o += T(r1(mx + dx / dd * 16), r1(my + dy / dd * 16), v.sl[i], { fs: 15, st: 1 }) }
    });
    return svg(r1(W), r1(H), o, Math.min(360, W));
  };

  // ---------- katakli maydon (y pastga, tugunlar butun): {w,h,u, cells:[{x,y,fill,s}], polys:[{pts,fill,c,dash}], segs:[{a,b,c,dash,lb,w,ends}],
  //   lines:[{a,b,c,lb,dash}] (chegaragacha cho‘ziladi), pts:[{a,lb,c,dx,dy}], rt:[{p,d1,d2}], ctr:[x,y] (simmetriya markazi), txt:[{a,s,c,fs}]}
  V.ext['4H7-grid'] = v => {
    const w = v.w, h = v.h, pd = 14, pl = v.axes ? 30 : 14, pb = v.axes ? 28 : 14, u = v.u || Math.min(32, Math.floor((344 - pl - pd) / w)), X = x => r1(pl + x * u), Y = y => r1(pd + y * u); let o = '';
    if (v.axes) { for (let i = 0; i <= w; i++) o += T(X(i), Y(h) + 15, i, { fs: 15, c: '#475569' }); for (let j = 0; j <= h; j++) if (h - j) o += T(X(0) - 9, Y(j), h - j, { fs: 15, c: '#475569', a: 'end' }) }
    (v.cells || []).forEach(c => { o += `<rect x="${X(c.x) + 1}" y="${Y(c.y) + 1}" width="${u - 2}" height="${u - 2}" rx="3" fill="${c.fill || '#93c5fd'}"/>`; if (c.s) o += T(X(c.x + .5), Y(c.y + .5), c.s, { fs: 15, c: c.tc || P.ink }) });
    if (!v.nogrid) { for (let i = 0; i <= w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#bfdbfe" stroke-width="1"/>`;
    for (let j = 0; j <= h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#bfdbfe" stroke-width="1"/>` }
    (v.polys || []).forEach(p => o += `<polygon points="${p.pts.map(q => X(q[0]) + ',' + Y(q[1])).join(' ')}" fill="${p.fill || '#bfdbfe99'}" stroke="${p.c || P.blue}" stroke-width="3" stroke-linejoin="round"${p.dash ? ' stroke-dasharray="7 5"' : ''}/>`);
    (v.lines || []).forEach(l => {
      const [px, py] = l.a, dx = l.b[0] - px, dy = l.b[1] - py, m = .15; let t0 = -1e9, t1 = 1e9;
      if (dx) { const a = (m - px) / dx, b = (w - m - px) / dx; t0 = Math.max(t0, Math.min(a, b)); t1 = Math.min(t1, Math.max(a, b)) }
      if (dy) { const a = (m - py) / dy, b = (h - m - py) / dy; t0 = Math.max(t0, Math.min(a, b)); t1 = Math.min(t1, Math.max(a, b)) }
      const A = [px + t0 * dx, py + t0 * dy], B = [px + t1 * dx, py + t1 * dy];
      o += `<line x1="${X(A[0])}" y1="${Y(A[1])}" x2="${X(B[0])}" y2="${Y(B[1])}" stroke="${l.c || P.blue}" stroke-width="${l.w || 3}" stroke-linecap="round"${l.dash ? ' stroke-dasharray="9 6"' : ''}/>`;
      if (l.lb) { const n = Math.hypot(dx, dy), tl = t1 - .8 / n; let lx = px + tl * dx - dy / n * .5, ly = py + tl * dy + dx / n * .5; if (l.lp) [lx, ly] = l.lp; o += T(X(lx), Y(ly), l.lb, { fs: 17, c: l.c || P.blue, st: 1 }) }
    });
    (v.segs || []).forEach(s => {
      o += `<line x1="${X(s.a[0])}" y1="${Y(s.a[1])}" x2="${X(s.b[0])}" y2="${Y(s.b[1])}" stroke="${s.c || P.blue}" stroke-width="${s.w || 3.5}" stroke-linecap="round"${s.dash ? ' stroke-dasharray="7 5"' : ''}/>`;
      if (s.ends) { o += `<circle cx="${X(s.a[0])}" cy="${Y(s.a[1])}" r="4.5" fill="${INK}"/><circle cx="${X(s.b[0])}" cy="${Y(s.b[1])}" r="4.5" fill="${INK}"/>` }
      if (s.lb) { const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1], n = Math.hypot(dx, dy) || 1, k = s.lo || .55; o += T(X((s.a[0] + s.b[0]) / 2 - dy / n * k), Y((s.a[1] + s.b[1]) / 2 + dx / n * k), s.lb, { fs: 15, c: s.lc || P.ink, st: 1 }) }
    });
    (v.rt || []).forEach(r => { const s = .38, a = [r.p[0] + r.d1[0] * s, r.p[1] + r.d1[1] * s], b = [r.p[0] + r.d2[0] * s, r.p[1] + r.d2[1] * s], c = [a[0] + b[0] - r.p[0], a[1] + b[1] - r.p[1]]; o += `<path d="M${X(a[0])} ${Y(a[1])}L${X(c[0])} ${Y(c[1])}L${X(b[0])} ${Y(b[1])}" fill="none" stroke="${P.red}" stroke-width="2.5"/>` });
    if (v.ctr) { const [x, y] = v.ctr; o += `<circle cx="${X(x)}" cy="${Y(y)}" r="7" fill="#fff" stroke="${P.red}" stroke-width="3"/><circle cx="${X(x)}" cy="${Y(y)}" r="2.5" fill="${P.red}"/>`; if (v.ctrLb) o += T(X(x) + 13, Y(y) - 13, v.ctrLb, { fs: 17, c: P.red, st: 1 }) }
    (v.pts || []).forEach(p => { o += `<circle cx="${X(p.a[0])}" cy="${Y(p.a[1])}" r="5.5" fill="${p.c || INK}" stroke="#fff" stroke-width="1.5"/>`; if (p.lb) o += T(X(p.a[0] + (p.dx != null ? p.dx : .42)), Y(p.a[1] + (p.dy != null ? p.dy : -.42)), p.lb, { fs: 17, c: p.lc || P.red, st: 1 }) });
    (v.txt || []).forEach(t => o += T(X(t.a[0]), Y(t.a[1]), t.s, { fs: t.fs || 16, c: t.c || P.ink, st: 1 }));
    return svg(pl + pd + w * u, pd + pb + h * u, o, Math.min(380, (pl + pd + w * u) * 1.1));
  };

  // ---------- sonli nur: {a,b,step, big (har nechta qadamda katta chiziq), labs:[yoziladigan sonlar] | lab (har nechta qadamda), pts:[{x,lb,c}], q:[x],
  //   jumps:[{f,t,lb,c}], segs:[{f,t,c,lb}], mv:[{x,dir,lb,c}] (harakat strelkasi), unit:'km'}
  V.ext['4H7-nl'] = v => {
    const a = v.a, b = v.b, st = v.step, n = Math.round((b - a) / st), W = 360, L = 22, R = W - 34, hasTop = (v.jumps || []).length || (v.segs || []).some(s => s.lb) || (v.mv || []).length;
    const y = hasTop ? 100 : 50, X = x => r1(L + (x - a) / (b - a) * (R - L)); let o = '';
    o += `<line x1="${L - 8}" y1="${y}" x2="${R + 22}" y2="${y}" stroke="${P.line}" stroke-width="3"/><path d="M${R + 26} ${y}l-11 -6v12z" fill="${P.line}"/>`;
    (v.segs || []).forEach(s => { o += `<line x1="${X(s.f)}" y1="${y}" x2="${X(s.t)}" y2="${y}" stroke="${s.c || '#f59e0b'}" stroke-width="8" stroke-linecap="round" opacity=".85"/>`; if (s.lb) o += T((X(s.f) + X(s.t)) / 2, y - 22, s.lb, { fs: 15, c: s.c || '#b45309', st: 1 }) });
    const big = v.big || 1, labs = v.labs || null, lab = v.lab || big, fm = x => String(x).length >= 5 ? String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : String(x), nearQ = x => (v.q || []).some(q => q !== x && Math.abs(X(q) - X(x)) < 36);
    for (let i = 0; i <= n; i++) {
      const x = a + i * st, bg = i % big === 0; o += `<line x1="${X(x)}" y1="${y - (bg ? 10 : 6)}" x2="${X(x)}" y2="${y + (bg ? 10 : 6)}" stroke="${P.line}" stroke-width="${bg ? 2.5 : 1.5}"/>`;
      const show = labs ? labs.includes(x) : i % lab === 0; if (show && !(v.q || []).includes(x) && !nearQ(x)) o += T(X(x), y + 27, fm(x), { fs: String(x).length > 3 ? 15 : 16 });
      if ((v.q || []).includes(x)) o += `<rect x="${X(x) - 16}" y="${y + 14}" width="32" height="26" rx="6" fill="#fff7d6" stroke="${P.gold}" stroke-width="2"/>` + T(X(x), y + 27, '?', { fs: 17, c: '#b45309' });
    }
    // yozuv yoy cho‘qqisidan (y − 8 − 0.8·hh) ~13px yuqorida — qisqa sakrashda ham yoyga tegmaydi; ikki yozuv ustma-ust tushsa, keyingisi yuqoriroqqa suriladi
    const jl = [];
    (v.jumps || []).forEach((j, k) => { const x1 = X(j.f), x2 = X(j.t), hh = Math.min(42, 14 + Math.abs(x2 - x1) / 4), c = j.c || ['#2563eb', '#16a34a', '#db2777', '#ea580c'][k % 4]; o += `<path d="M${x1} ${y - 8}Q${(x1 + x2) / 2} ${y - 8 - hh * 1.6} ${x2} ${y - 10}" fill="none" stroke="${c}" stroke-width="3"/><path d="M${x2} ${y - 9}l${x2 > x1 ? -9 : 9} -5l${x2 > x1 ? 1 : -1} 9z" fill="${c}"/>`;
      if (j.lb) { const lx = (x1 + x2) / 2, lw = String(j.lb).length * 9 + 6; let ly = y - 21 - hh * .8; while (ly > 12 && jl.some(q => Math.abs(q[0] - lx) < (q[2] + lw) / 2 && Math.abs(q[1] - ly) < 18)) ly -= 18; jl.push([lx, ly, lw]); o += T(lx, ly, j.lb, { fs: 15, c, st: 1 }) } });
    (v.mv || []).forEach((m, k) => { const x = X(m.x), d = m.dir || 1, c = m.c || P.green, prev = (v.mv || []).slice(0, k).some(q => (q.dir || 1) === d && Math.abs(X(q.x) - x) < 80), yy = y - 36 - (prev ? 36 : 0); o += `<line x1="${x}" y1="${yy}" x2="${x + d * 44}" y2="${yy}" stroke="${c}" stroke-width="3.5"/><path d="M${x + d * 50} ${yy}l${-d * 11} -6v12z" fill="${c}"/>`; if (m.lb) o += T(x + d * 24, yy - 16, m.lb, { fs: 15, c, st: 1 }) });
    (v.pts || []).forEach(p => { o += `<circle cx="${X(p.x)}" cy="${y}" r="7" fill="${p.c || P.red}" stroke="#fff" stroke-width="2"/>`; if (p.lb) o += T(X(p.x), y - 20, p.lb, { fs: 17, c: p.c || P.red, st: 1 }) });
    if (v.unit) o += T(R + 18, y + 27, v.unit, { fs: 15, c: '#64748b' });
    return svg(W, y + 46, o, 380);
  };

  // ---------- fazoviy shakllar: {l:[{s:'prizma'|'piramida'|'shar'|'silindr'|'konus'|'kub', n, cap, c}], cell}
  function solid1(e, x0, y0, S) { // S — katak kattaligi (kv)
    const st = `stroke="${INK}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"`, hd = `stroke="${INK}" stroke-width="1.6" stroke-dasharray="5 4" fill="none"`;
    const cx = x0 + S / 2, Rx = S * .33, Ry = S * (e.s === 'prizma' || e.s === 'piramida' || e.s === 'kub' ? .15 : .11), fc = e.c || '#93c5fd'; let o = '';
    const line = (p, q, vis) => `<line x1="${r1(p[0])}" y1="${r1(p[1])}" x2="${r1(q[0])}" y2="${r1(q[1])}" ${vis ? st : hd}/>`;
    if (e.s === 'prizma' || e.s === 'piramida' || e.s === 'kub') {
      const n = e.s === 'kub' ? 4 : e.n, pyr = e.s === 'piramida', yb = y0 + S * .8, Hh = pyr ? S * .62 : (e.s === 'kub' ? S * .42 : S * .5);
      const s0 = Math.PI / 2 + Math.PI / n + (e.rot != null ? e.rot : (n === 3 ? Math.PI + .25 : n === 4 ? .3 : .15)); const B = [], Tp = [];
      for (let k = 0; k < n; k++) { const t = s0 + 2 * Math.PI * k / n; B.push([cx + Rx * Math.cos(t), yb + Ry * Math.sin(t)]); Tp.push([cx + Rx * Math.cos(t), yb - Hh + Ry * Math.sin(t)]) }
      const apex = [cx, yb - Hh]; const fvis = k => Math.sin(s0 + 2 * Math.PI * (k + .5) / n) > 1e-6;
      // yuzlar
      for (let k = 0; k < n; k++) if (fvis(k)) { const q = (k + 1) % n; const pts = pyr ? [B[k], B[q], apex] : [B[k], B[q], Tp[q], Tp[k]]; o += `<polygon points="${pts.map(p => r1(p[0]) + ',' + r1(p[1])).join(' ')}" fill="${fc}" stroke="none"/>` }
      if (!pyr) o += `<polygon points="${Tp.map(p => r1(p[0]) + ',' + r1(p[1])).join(' ')}" fill="#dbeafe" stroke="none"/>`;
      let hid = '', vis = '';
      for (let k = 0; k < n; k++) {
        const q = (k + 1) % n, fv = fvis(k), sv = fvis(k) || fvis((k + n - 1) % n);
        (fv ? (vis += line(B[k], B[q], 1)) : (hid += line(B[k], B[q], 0)));
        if (pyr) sv ? (vis += line(B[k], apex, 1)) : (hid += line(B[k], apex, 0));
        else { vis += line(Tp[k], Tp[q], 1); sv ? (vis += line(B[k], Tp[k], 1)) : (hid += line(B[k], Tp[k], 0)) }
      }
      o += hid + vis;
    } else if (e.s === 'shar') {
      const r = S * .34, cy = y0 + S * .48; o += `<circle cx="${r1(cx)}" cy="${r1(cy)}" r="${r1(r)}" fill="${fc}" ${st}/><circle cx="${r1(cx - r * .35)}" cy="${r1(cy - r * .35)}" r="${r1(r * .22)}" fill="#fff" opacity=".6"/>`;
      o += `<path d="M${r1(cx - r)} ${r1(cy)}A${r1(r)} ${r1(r * .3)} 0 0 1 ${r1(cx + r)} ${r1(cy)}" ${hd}/><path d="M${r1(cx - r)} ${r1(cy)}A${r1(r)} ${r1(r * .3)} 0 0 0 ${r1(cx + r)} ${r1(cy)}" fill="none" stroke="${INK}" stroke-width="1.8"/>`;
    } else if (e.s === 'silindr') {
      const yt = y0 + S * .22, yb = y0 + S * .76;
      o += `<path d="M${r1(cx - Rx)} ${r1(yt)}V${r1(yb)}A${r1(Rx)} ${r1(Ry)} 0 0 0 ${r1(cx + Rx)} ${r1(yb)}V${r1(yt)}Z" fill="${fc}" ${st}/>`;
      o += `<ellipse cx="${r1(cx)}" cy="${r1(yt)}" rx="${r1(Rx)}" ry="${r1(Ry)}" fill="#dbeafe" ${st}/><path d="M${r1(cx - Rx)} ${r1(yb)}A${r1(Rx)} ${r1(Ry)} 0 0 1 ${r1(cx + Rx)} ${r1(yb)}" ${hd}/>`;
    } else if (e.s === 'konus') {
      const ya = y0 + S * .12, yb = y0 + S * .78;
      o += `<path d="M${r1(cx)} ${r1(ya)}L${r1(cx - Rx)} ${r1(yb)}A${r1(Rx)} ${r1(Ry)} 0 0 0 ${r1(cx + Rx)} ${r1(yb)}Z" fill="${fc}" ${st}/><path d="M${r1(cx - Rx)} ${r1(yb)}A${r1(Rx)} ${r1(Ry)} 0 0 1 ${r1(cx + Rx)} ${r1(yb)}" ${hd}/>`;
    }
    if (e.cap) o += T(r1(cx), r1(y0 + S + 12), e.cap, { fs: 18, c: P.red });
    return o;
  }
  V.ext['4H7-sol'] = v => {
    const l = v.l, k = l.length, S = v.cell || (k === 1 ? 200 : k === 2 ? 160 : k === 3 ? 125 : 100), capH = l.some(e => e.cap) ? 26 : 4;
    const cols = v.cols || Math.min(k, 4), rows = Math.ceil(k / cols); let o = '';
    l.forEach((e, i) => o += solid1(e, (i % cols) * S, Math.floor(i / cols) * (S + capH), S));
    return svg(cols * S, rows * (S + capH), o, Math.min(400, cols * S));
  };

  // ---------- yoyilmalar: {l:[{s:'prizma'|'piramida'|'silindr'|'konus', n, bad:'base'|'side'|'+side'|'circ'|'side3', cap, num:true}], cols}
  // bir birlik — asos tomoni (prizma: a=1, h); natijada har biri o‘z katagiga sig‘diriladi
  function netShapes(e) { // [{pts}|{circ:[cx,cy,r]}|{sec:[cx,cy,r,a1,a2]}] — y pastga
    const out = [], n = e.n || 4, reg = (cx, cy, r, s0, m) => Array.from({ length: m }, (_, k) => [cx + r * Math.cos(s0 + 2 * Math.PI * k / m), cy + r * Math.sin(s0 + 2 * Math.PI * k / m)]);
    if (e.s === 'prizma') {
      const h = e.h || 1.6, m = e.bad === 'side' ? n - 1 : e.bad === '+side' ? n + 1 : n; for (let k = 0; k < m; k++) out.push({ pts: [[k, 0], [k + 1, 0], [k + 1, h], [k, h]] });
      const bn = e.bad === 'base' ? (n === 3 ? 4 : n - 1) : n, rr = .5 / Math.sin(Math.PI / bn), ap = .5 / Math.tan(Math.PI / bn), j = e.at || 0, j2 = e.at2 != null ? e.at2 : j;
      const top = reg(j + .5, -ap, rr, Math.PI / 2 + Math.PI / bn, bn), bot = reg(j2 + .5, h + ap, rr, -Math.PI / 2 + Math.PI / bn, bn);
      // asos tomoni to‘g‘ri to‘rtburchak tomoniga tegsin: top uchun pastki tomon gorizontal y=0
      out.push({ pts: top, base: 1 }); if (e.bad !== 'onebase') out.push({ pts: bot, base: 1 });
    } else if (e.s === 'piramida') {
      const bn = n, rr = .5 / Math.sin(Math.PI / bn), ap = .5 / Math.tan(Math.PI / bn), sl = e.sl || (n >= 5 ? .95 : 1.2); const B = reg(0, 0, rr, Math.PI / 2 + Math.PI / bn, bn);
      out.push({ pts: B, base: 1 }); const tri = e.bad === 'side' ? bn - 1 : bn;
      for (let k = 0; k < tri; k++) { const p = B[k], q = B[(k + 1) % bn], mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2, d = Math.hypot(mx, my); out.push({ pts: [p, q, [mx + mx / d * sl, my + my / d * sl]] }) }
    } else if (e.s === 'silindr') {
      const w = e.w || 3.14, h = e.h || 2, r = .5; out.push({ pts: [[0, 0], [w, 0], [w, h], [0, h]] });
      const rb = e.bad === 'circ' ? .3 : r; out.push({ circ: [w / 2, -r, r], base: 1 }); out.push({ circ: [w / 2, h + rb, rb], base: 1 });
      if (e.bad === 'onebase') out.pop();
    } else if (e.s === 'konus') {
      const L = 2, a = e.bad === 'side3' ? 140 : 110, r = L * a / 360; out.push({ sec: [0, 0, L, 90 - a / 2, 90 + a / 2] });
      if (e.bad !== 'onebase') out.push({ circ: [0, L + r, r], base: 1 }); if (e.bad === 'two') out.push({ circ: [0, -r - .05, r], base: 1 });
    }
    return out;
  }
  V.ext['4H7-net'] = v => {
    const l = v.l, k = l.length, cols = v.cols || (k === 1 ? 1 : 2), cw = k === 1 ? 300 : 160, chh = k === 1 ? 220 : 150, capH = l.some(e => e.cap) ? 26 : 0; let o = '';
    l.forEach((e, i) => {
      const sh = netShapes(e); let mnx = 1e9, mny = 1e9, mxx = -1e9, mxy = -1e9;
      const upd = (x, y) => { mnx = Math.min(mnx, x); mxx = Math.max(mxx, x); mny = Math.min(mny, y); mxy = Math.max(mxy, y) };
      sh.forEach(s => { if (s.pts) s.pts.forEach(p => upd(p[0], p[1])); if (s.circ) { upd(s.circ[0] - s.circ[2], s.circ[1] - s.circ[2]); upd(s.circ[0] + s.circ[2], s.circ[1] + s.circ[2]) } if (s.sec) { const [x, y, r, a1, a2] = s.sec; upd(x, y); for (let t = a1; t <= a2; t += 5) upd(x + r * Math.cos(rad(t)), y + r * Math.sin(rad(t))) } });
      const sc = Math.min((cw - 20) / (mxx - mnx), (chh - 16) / (mxy - mny)), ox = (i % cols) * cw + (cw - (mxx - mnx) * sc) / 2 - mnx * sc, oy = Math.floor(i / cols) * (chh + capH) + (chh - (mxy - mny) * sc) / 2 - mny * sc;
      const Q = p => r1(ox + p[0] * sc) + ',' + r1(oy + p[1] * sc); let num = 1;
      sh.forEach(s => {
        const fill = s.base ? '#fde68a' : '#bfdbfe';
        if (s.pts) { o += `<polygon points="${s.pts.map(Q).join(' ')}" fill="${fill}" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>`; if (e.num) { const c = s.pts.reduce((a, p) => [a[0] + p[0] / s.pts.length, a[1] + p[1] / s.pts.length], [0, 0]); o += T(r1(ox + c[0] * sc), r1(oy + c[1] * sc), num++, { fs: 15 }) } }
        if (s.circ) { o += `<circle cx="${r1(ox + s.circ[0] * sc)}" cy="${r1(oy + s.circ[1] * sc)}" r="${r1(s.circ[2] * sc)}" fill="${fill}" stroke="${INK}" stroke-width="2.2"/>` }
        if (s.sec) { const [x, y, r, a1, a2] = s.sec, p = [x + r * Math.cos(rad(a1)), y + r * Math.sin(rad(a1))], q = [x + r * Math.cos(rad(a2)), y + r * Math.sin(rad(a2))]; o += `<path d="M${Q([x, y]).replace(',', ' ')}L${Q(p).replace(',', ' ')}A${r1(r * sc)} ${r1(r * sc)} 0 0 1 ${Q(q).replace(',', ' ')}Z" fill="#bfdbfe" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>` }
      });
      if (e.cap) o += T(r1((i % cols) * cw + cw / 2), r1(Math.floor(i / cols) * (chh + capH) + chh + 12), e.cap, { fs: 18, c: P.red });
    });
    const rows = Math.ceil(k / cols); return svg(cols * cw, rows * (chh + capH), o, Math.min(380, cols * cw));
  };
})();

// 4J (4-sinf, Mantiq va olimpiada) uchun qo‘shimcha rasm turlari. Turlar nomi '4J-' bilan boshlanadi.
//  '4J-oyna'  — kichik katakli maydonlar qatori (narsalar yuradi): {n (katak soni), u, frames:[{m:[{x,y,s,c}]} | '?'], lb:['1','2',..]}
//  '4J-sonfig'— sonli shakllar (uchburchak/kvadrat burchaklarida sonlar, o‘rtada natija): {l:[{k:'uch'|'kv', v:['3','5','2'], c:'10'}]}
//  '4J-tugun' — doirachalar va chiziqlar (sehrli uchburchak, kvadrat tomonlari): {w,h, nodes:[[x,y,'s']], edges:[[i,j]]}
//  '4J-karkas'— kubchalardan yasalgan quti karkasi (izometrik, cho‘plar): {a,b,c}
//  '4J-sud'   — sudoku katagi (qalin chegarali bloklar): {cells:[['1','',..],..], br, bc, hl:[[r,c]]}
//  '4J-jad'   — jadval usuli: {rows:[ismlar], groups:[[ustunlar],[ustunlar]], u}
//  '4J-gug'   — gugurt cho‘plari + katta yozuvlar ostida: {segs, w, h, hl, cap}
// Hamma yozuvlar telefonda kamida 14 px; chizma eni 330 px atrofida.
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg;
  const Q = '#fff7d6', QS = '#f5b301', QT = '#b45309';

  // ---------- '4J-oyna' ----------
  V.ext['4J-oyna'] = v => {
    const n = v.n || 3, u = v.u || (n > 3 ? 18 : 24), fw = n * u, gap = 14, lbH = v.lb ? 22 : 0, maxW = 336; let o = '', x = 2, y = 2, W = 0;
    v.frames.forEach((f, i) => {
      if (x > 2 && x + fw > maxW) { x = 2; y += fw + lbH + 10 }
      if (f === '?') {
        o += `<rect x="${x}" y="${y}" width="${fw}" height="${fw}" rx="8" fill="${Q}" stroke="${QS}" stroke-width="2.5" stroke-dasharray="6 4"/>` + T(x + fw / 2, y + fw / 2, '?', { fs: 30, c: QT });
      } else {
        o += `<rect x="${x}" y="${y}" width="${fw}" height="${fw}" fill="#fff" stroke="#1e3a8a" stroke-width="2.5"/>`;
        for (let k = 1; k < n; k++) o += `<line x1="${x + k * u}" y1="${y}" x2="${x + k * u}" y2="${y + fw}" stroke="#94a3b8" stroke-width="1.3"/><line x1="${x}" y1="${y + k * u}" x2="${x + fw}" y2="${y + k * u}" stroke="#94a3b8" stroke-width="1.3"/>`;
        (f.m || []).forEach(m => { o += V.shp(m.s, x + m.x * u + 1, y + m.y * u + 1, u - 2, m.c || P.fills[0]) });
      }
      if (v.lb) o += T(x + fw / 2, y + fw + 13, v.lb[i], { fs: 15, c: P.red });
      x += fw + gap; W = Math.max(W, x - gap);
    });
    const H = y + fw + lbH + 2;
    return svg(W + 2, H, o, W + 2);
  };

  // ---------- '4J-sonfig' ----------
  const circ = (x, y, s, r) => { const q = s === '?'; return `<circle cx="${x}" cy="${y}" r="${r}" fill="${q ? Q : '#fff'}" stroke="${q ? QS : '#1e3a8a'}" stroke-width="2.2"/>` + T(x, y + 1, s, { fs: String(s).length > 2 ? 14 : 16, c: q ? QT : P.ink }) };
  V.ext['4J-sonfig'] = v => {
    const s = 104, gap = 6; let o = '';
    v.l.forEach((f, i) => {
      const x0 = 2 + i * (s + gap), y0 = 2, col = P.fills[i % 7];
      if (f.k === 'kv') {
        o += `<rect x="${x0 + 16}" y="${y0 + 16}" width="${s - 32}" height="${s - 32}" fill="${col}55" stroke="#1e3a8a" stroke-width="2.5"/>`;
        const pts = [[x0 + 16, y0 + 16], [x0 + s - 16, y0 + 16], [x0 + s - 16, y0 + s - 16], [x0 + 16, y0 + s - 16]];
        pts.forEach((p, k) => { o += circ(p[0], p[1], f.v[k], 15) });
      } else {
        const pts = [[x0 + s / 2, y0 + 16], [x0 + s - 15, y0 + s - 15], [x0 + 15, y0 + s - 15]];
        o += `<path d="M${pts.map(p => p.join(' ')).join('L')}z" fill="${col}55" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
        pts.forEach((p, k) => { o += circ(p[0], p[1], f.v[k], 15) });
      }
      const cy = f.k === 'kv' ? y0 + s / 2 : y0 + s * .62, q = f.c === '?';
      o += `<rect x="${x0 + s / 2 - 19}" y="${cy - 14}" width="38" height="28" rx="7" fill="${q ? Q : '#fff'}" stroke="${q ? QS : '#16a34a'}" stroke-width="2.2"/>` + T(x0 + s / 2, cy + 1, f.c, { fs: String(f.c).length > 2 ? 14 : 16, c: q ? QT : '#14532d' });
    });
    const W = v.l.length * (s + gap) - gap + 4;
    return svg(W, s + 4, o, W);
  };

  // ---------- '4J-tugun' ----------
  V.ext['4J-tugun'] = v => {
    const N = v.nodes; let o = '';
    (v.edges || []).forEach(([a, b]) => { o += `<line x1="${N[a][0]}" y1="${N[a][1]}" x2="${N[b][0]}" y2="${N[b][1]}" stroke="#60a5fa" stroke-width="5" stroke-linecap="round"/>` });
    N.forEach(nd => { o += circ(nd[0], nd[1], nd[2], 19) });
    (v.txt || []).forEach(t => { o += T(t[0], t[1], t[2], { fs: 15, c: t[3] || P.ink, st: 1 }) });
    return svg(v.w, v.h, o, v.w);
  };

  // ---------- '4J-karkas' ----------
  V.ext['4J-karkas'] = v => { // qiyshiq (oblique) proyeksiya: old yoq to‘g‘ri, chuqurlik yuqori-o‘ngga
    const { a, b, c } = v, s = v.s || Math.min(58, 290 / (a + b * .5), 200 / (c + b * .38)), dx = s * .5, dy = s * .38; let o = '';
    const ox = 14, oy = 14 + b * dy + c * s;
    const P2 = (i, j, k) => [ox + i * s + j * dx, oy - k * s - j * dy];
    const poly = (pts, f) => `<polygon points="${pts.map(p => P2(...p).join(',')).join(' ')}" fill="${f}" stroke="none"/>`;
    // yengil to‘ldirilgan ko‘rinadigan yoqlar: old, tepa, o‘ng
    o += poly([[0, 0, 0], [a, 0, 0], [a, 0, c], [0, 0, c]], '#fef3c7') + poly([[0, 0, c], [a, 0, c], [a, b, c], [0, b, c]], '#fde68a') + poly([[a, 0, 0], [a, b, 0], [a, b, c], [a, 0, c]], '#fcd34d');
    const vis = (p, q) => [p, q].every(([i, j, k]) => j === 0) || [p, q].every(([i, j, k]) => k === c) || [p, q].every(([i, j, k]) => i === a);
    const ln = (p, q, front) => { const [x1, y1] = P2(...p), [x2, y2] = P2(...q); return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${front ? '#92400e' : '#d6a35c'}" stroke-width="${front ? 3.4 : 1.6}" stroke-linecap="round"${front ? '' : ' stroke-dasharray="5 3"'}/>` };
    const E = []; for (let j = b; j >= 0; j--) for (let k = 0; k <= c; k++) for (let i = 0; i <= a; i++) {
      if (i < a) E.push([[i, j, k], [i + 1, j, k]]);
      if (k < c) E.push([[i, j, k], [i, j, k + 1]]);
      if (j > 0) E.push([[i, j, k], [i, j - 1, k]]);
    }
    E.filter(e => !vis(...e)).forEach(e => { o += ln(...e, false) }); // ichki va orqa cho‘plar — ingichka, punktir
    E.filter(e => vis(...e)).forEach(e => { o += ln(...e, true) }); // tashqi ko‘rinadigan cho‘plar — qalin
    for (let j = 0; j <= b; j++) for (let k = 0; k <= c; k++) for (let i = 0; i <= a; i++) if (j === 0 || k === c || i === a) { const [x, y] = P2(i, j, k); o += `<circle cx="${x}" cy="${y}" r="3" fill="#dc2626"/>` }
    const W = ox * 2 + a * s + b * dx, H = oy + 14;
    return svg(W, H, o, Math.min(330, W));
  };

  // ---------- '4J-sud' ----------
  V.ext['4J-sud'] = v => {
    const C = v.cells, n = C.length, m = C[0].length, u = v.u || (m > 4 ? 44 : 52), br = v.br || 2, bc = v.bc || 2; let o = '';
    C.forEach((r, i) => r.forEach((s, j) => {
      const x = 3 + j * u, y = 3 + i * u, q = s === '?', hl = (v.hl || []).some(h => h[0] === i && h[1] === j);
      o += `<rect x="${x}" y="${y}" width="${u}" height="${u}" fill="${q ? Q : hl ? '#dcfce7' : '#fff'}" stroke="#93c5fd" stroke-width="1.5"/>`;
      if (s !== '' && s != null) o += T(x + u / 2, y + u / 2 + 1, s, { fs: u * .46, c: q ? QT : P.ink });
    }));
    for (let i = 0; i <= n; i += br) o += `<line x1="3" y1="${3 + i * u}" x2="${3 + m * u}" y2="${3 + i * u}" stroke="#1e3a8a" stroke-width="3.5"/>`;
    for (let j = 0; j <= m; j += bc) o += `<line x1="${3 + j * u}" y1="3" x2="${3 + j * u}" y2="${3 + n * u}" stroke="#1e3a8a" stroke-width="3.5"/>`;
    return svg(m * u + 6, n * u + 6, o, m * u + 6);
  };

  // ---------- '4J-gug' ----------
  V.ext['4J-gug'] = v => {
    const u = v.u || 40, pd = 12; let o = '';
    v.segs.forEach((s, i) => { const [x1, y1, x2, y2] = s.map(z => z * u + pd), a = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI, L = Math.hypot(x2 - x1, y2 - y1); o += `<g transform="translate(${x1} ${y1}) rotate(${a})"><rect x="4" y="-3.5" width="${L - 8}" height="7" rx="3" fill="${(v.hl || []).includes(i) ? '#fca5a5' : '#fcd34d'}" stroke="#b45309" stroke-width="1.4"/><ellipse cx="${L - 7}" cy="0" rx="6" ry="5" fill="#dc2626"/></g>` });
    (v.lbs || []).forEach(l => { o += T(l[0] * u + pd, l[1] * u + pd, l[2], { fs: 16, c: P.red, st: 1 }) });
    const W = v.w * u + pd * 2, H = v.h * u + pd * 2 + (v.cap ? 24 : 0);
    if (v.cap) o += T(W / 2, H - 12, v.cap, { fs: 15 });
    return svg(W, H, o, Math.min(336, W));
  };
  // ---------- '4J-jad' ----------  jadval usuli uchun bo‘sh katakli jadval, ustun nomlari tik yozilgan
  V.ext['4J-jad'] = v => {
    const u = v.u || 32, nw = 88, G = v.groups, cols = G.flat(), hh = Math.max(...cols.map(c => c.length)) * 9.4 + 12; let o = '';
    const W = nw + cols.length * u + 4, H = hh + v.rows.length * u + 4;
    v.rows.forEach((r, i) => { const y = hh + i * u; o += `<rect x="2" y="${y}" width="${nw}" height="${u}" fill="#eef2ff" stroke="#1e3a8a" stroke-width="1.5"/>` + T(nw - 6, y + u / 2, r, { fs: 15, a: 'end' }) });
    let k = 0; G.forEach((g, gi) => g.forEach((c, j) => { const x = nw + 2 + k * u; k++;
      o += `<g transform="translate(${x + u / 2} ${hh - 6}) rotate(-90)">${T(0, 0, c, { fs: 15, a: 'start', c: gi ? P.red : '#1e3a8a' })}</g>`;
      v.rows.forEach((_, i) => { o += `<rect x="${x}" y="${hh + i * u}" width="${u}" height="${u}" fill="#fff" stroke="#94a3b8" stroke-width="1.3"/>` }) }));
    let x0 = nw + 2; G.forEach(g => { o += `<rect x="${x0}" y="${hh}" width="${g.length * u}" height="${v.rows.length * u}" fill="none" stroke="#1e3a8a" stroke-width="3"/>`; x0 += g.length * u });
    return svg(W, H, o, Math.min(336, W));
  };
})();

// 4J11–4J21 (4-sinf, Mantiq va olimpiada) uchun qo‘shimcha rasm turlari. Turlar nomi '4J11-' bilan boshlanadi.
// Hamma SVG eni 340 birlik atrofida: telefonda (≈338 px) deyarli 1:1, yozuvlar 15–18 px.
//  '4J11-idish'    — idishlar: {l:[{cap:8, val:5, lb:'A', q:false}]} (cap — sig‘imi, val — ichidagi suv, q — suv miqdori o‘rniga '?')
//  '4J11-gildirak' — aylanma g‘ildirak (strelkali): {sec:['#ef4444', ...], txt:['1', ...] (ixtiyoriy)}
//  '4J11-zar'      — o‘yin zarlari: {l:[1..6], lb:['A', ...]}
//  '4J11-tarozi'   — pallali tarozi: {l:[{img,n}|{s:'200 g'}|{f:'doira'|'kvadrat'|'uchburchak', n}], r:[...], tilt:-1|0|1}
//  '4J11-figs'     — katakli shakllar (yozuvi bilan): {figs:[{cells:[[x,y]], lb, fill}], u}
//  '4J11-panjara'  — ko‘chalar panjarasi: {w,h, A:[x,y], B:[x,y], block:[[x,y]], must:[[x,y]], lbl:[{a:[x,y],s}]} (y pastdan)
//  '4J11-qutilar'  — rangli sharlar solingan qutilar: {l:[{lb:'A', n:[[rang,son],...]}]}
//  '4J11-tanga'    — tangalar qatori (gerb/raqam): {l:['G','R',...]}
//  '4J11-sjadval'  — shakllar jadvali: {cells:[['doira','kvadrat',...],...], rs:[qator yig‘indilari], cs:[ustun yig‘indilari]} ('?' — so‘roq, '' — yo‘q)
//  '4J11-pul'      — tangalar (1-qator) va qog‘oz pullar (2-qator), telefonda yirik yozuv bilan: {v:[100, 200, 500, 1000, 2000, ...], coin:1000 (shu qiymatgacha tanga)}
//  '4J11-katak'    — katakli maydon: {w,h, marks:[{x,y,img|lb|fill}], axis:[{v:k}|{h:k}], dot:[x,y] (tugundagi qizil nuqta)} (y pastga)
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg;
  const RC = { qizil: '#ef4444', 'ko‘k': '#3b82f6', yashil: '#22c55e', sariq: '#facc15', oq: '#ffffff', qora: '#1f2937', pushti: '#f472b6', binafsha: '#a855f7', jigarrang: '#a16207' };
  const col = c => RC[c] || c;

  // --- idishlar
  V.ext['4J11-idish'] = v => {
    const L = v.l, n = L.length, maxc = Math.max(...L.map(e => e.cap)), Hm = 130, gap = 18;
    const ws = L.map(e => 54 + Math.min(40, e.cap * 2)); const W = ws.reduce((a, b) => a + b, 0) + gap * (n - 1) + 8; let o = '', x = 4;
    L.forEach((e, i) => {
      const w = ws[i], h = 30 + (Hm - 30) * e.cap / maxc, top = 8 + Hm - h, base = 8 + Hm;
      const wh = e.val ? h * e.val / e.cap : 0;
      if (wh) o += `<rect x="${x + 3}" y="${base - wh}" width="${w - 6}" height="${wh - 3}" rx="4" fill="#7dd3fc"/>`;
      o += `<path d="M${x} ${top}V${base - 8}q0 8 8 8H${x + w - 8}q8 0 8 -8V${top}" fill="none" stroke="#1e3a8a" stroke-width="3"/>`;
      for (let k = 1; k < e.cap; k++) { const yy = base - h * k / e.cap; o += `<line x1="${x}" y1="${yy}" x2="${x + 8}" y2="${yy}" stroke="#1e3a8a" stroke-width="1.5"/>` }
      const t = e.q ? '?' : (e.val || 0) + ' l';
      o += T(x + w / 2, base - Math.max(wh, 26) / 2 - (wh ? 0 : 0), t, { fs: 17, c: e.q ? '#b45309' : P.ink, st: 1 });
      o += T(x + w / 2, base + 16, (e.lb ? e.lb + ': ' : '') + e.cap + ' l', { fs: 16, c: P.red });
      x += w + gap;
    });
    return svg(W, Hm + 34, o, Math.min(340, W * 1.3));
  };

  // --- aylanma g‘ildirak
  V.ext['4J11-gildirak'] = v => {
    const n = v.sec.length, cx = 120, cy = 118, r = 100; let o = '';
    for (let i = 0; i < n; i++) {
      const a1 = -Math.PI / 2 + i * 2 * Math.PI / n, a2 = a1 + 2 * Math.PI / n;
      o += `<path d="M${cx} ${cy}L${(cx + r * Math.cos(a1)).toFixed(1)} ${(cy + r * Math.sin(a1)).toFixed(1)}A${r} ${r} 0 0 1 ${(cx + r * Math.cos(a2)).toFixed(1)} ${(cy + r * Math.sin(a2)).toFixed(1)}z" fill="${col(v.sec[i])}" stroke="#1e3a8a" stroke-width="2.5"/>`;
      if (v.txt) { const am = (a1 + a2) / 2; o += T(cx + r * .66 * Math.cos(am), cy + r * .66 * Math.sin(am), v.txt[i], { fs: 18, st: 1 }) }
    }
    o += `<circle cx="${cx}" cy="${cy}" r="9" fill="#1e3a8a"/><path d="M${cx} ${cy}L${cx + 52} ${cy - 40}" stroke="#1e3a8a" stroke-width="6" stroke-linecap="round"/><path d="M${cx + 60} ${cy - 46}l-16 2l8 10z" fill="#1e3a8a"/>`;
    return svg(240, 236, o, 240);
  };

  // --- zarlar
  const PIP = { 1: [[1, 1]], 2: [[0, 0], [2, 2]], 3: [[0, 0], [1, 1], [2, 2]], 4: [[0, 0], [2, 0], [0, 2], [2, 2]], 5: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]], 6: [[0, 0], [2, 0], [0, 1], [2, 1], [0, 2], [2, 2]] };
  V.ext['4J11-zar'] = v => {
    const s = 64, g = 18, n = v.l.length, W = n * s + (n - 1) * g + 8; let o = '';
    v.l.forEach((k, i) => {
      const x = 4 + i * (s + g), y = 4; o += `<rect x="${x}" y="${y}" width="${s}" height="${s}" rx="12" fill="${(v.c && v.c[i]) || '#fff'}" stroke="#1e3a8a" stroke-width="3"/>`;
      (PIP[k] || []).forEach(p => o += `<circle cx="${x + 15 + p[0] * 17}" cy="${y + 15 + p[1] * 17}" r="6" fill="#1e3a8a"/>`);
      if (v.lb) o += T(x + s / 2, y + s + 16, v.lb[i], { fs: 16, c: P.red });
    });
    return svg(W, s + (v.lb ? 34 : 10), o, Math.min(340, W * 1.2));
  };

  // --- tarozi
  V.ext['4J11-tarozi'] = v => {
    const t = (v.tilt || 0) * 7, cx = 170; let o = `<path d="M${cx - 40} 222h80l-16 -14h-48z" fill="#64748b"/><rect x="${cx - 5}" y="64" width="10" height="148" rx="4" fill="#94a3b8"/>`;
    o += `<g transform="rotate(${t} ${cx} 68)"><rect x="18" y="62" width="304" height="9" rx="4" fill="#475569"/>`;
    const pan = (x, list) => {
      let s = `<line x1="${x}" y1="70" x2="${x - 66}" y2="150" stroke="#64748b" stroke-width="2"/><line x1="${x}" y1="70" x2="${x + 66}" y2="150" stroke="#64748b" stroke-width="2"/><g transform="rotate(${-t} ${x} 150)"><path d="M${x - 78} 150h156a78 16 0 0 1 -156 0z" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>`;
      const all = []; list.forEach(e => { if (e.s) all.push({ s: e.s, w: Math.max(40, String(e.s).length * 10 + 12) }); else for (let i = 0; i < e.n; i++) all.push({ img: e.img, f: e.f, w: 0 }) });
      const k = all.filter(e => !e.s).length, sz = k > 8 ? 22 : k > 4 ? 27 : 33; all.forEach(e => { if (!e.s) e.w = sz });
      const rows = []; let cur = [], cw = 0; for (const e of all) { if (cur.length && cw + e.w > 150) { rows.push(cur); cur = []; cw = 0 } cur.push(e); cw += e.w + 2 } if (cur.length) rows.push(cur);
      let y = 150; rows.forEach(r => {
        const h = Math.max(...r.map(e => e.s ? 28 : sz)); const Wr = r.reduce((a, e) => a + e.w + 2, -2); let xx = x - Wr / 2; y -= h; r.forEach(e => {
          if (e.img) s += V.im(e.img, xx, y + h - sz, sz);
          else if (e.f) s += V.shp(e.f, xx, y + h - sz, sz, { doira: '#60a5fa', kvadrat: '#fbbf24', uchburchak: '#34d399', yulduz: '#f472b6', romb: '#a78bfa' }[e.f] || '#60a5fa');
          else s += `<path d="M${xx + 5} ${y + h - 26}h${e.w - 10}l5 26h${-e.w}z" fill="#475569" stroke="#1e293b" stroke-width="1.5"/>` + T(xx + e.w / 2, y + h - 12, e.s, { fs: 15, c: '#fff' });
          xx += e.w + 2;
        }); y -= 2;
      });
      return s + '</g>';
    };
    o += pan(90, v.l) + pan(250, v.r) + '</g>';
    return svg(340, 226, o, 340);
  };

  // --- katakli shakllar
  V.ext['4J11-figs'] = v => {
    const F = v.figs, bb = F.map(f => [Math.max(...f.cells.map(c => c[0])) + 1, Math.max(...f.cells.map(c => c[1])) + 1]);
    const n = F.length, gap = 16, totU = bb.reduce((a, b) => a + b[0], 0); let u = v.u || Math.min(30, Math.floor((330 - gap * (n - 1)) / totU));
    let rows = [F.map((_, i) => i)];
    if (u < 22 && n > 2) { const h = Math.ceil(n / 2); rows = [F.map((_, i) => i).slice(0, h), F.map((_, i) => i).slice(h)]; u = Math.min(30, Math.floor((330 - gap * (h - 1)) / Math.max(...rows.map(r => r.reduce((a, i) => a + bb[i][0], 0))))) }
    let o = '', y = 4, W = 0;
    rows.forEach(r => {
      const Hm = Math.max(...r.map(i => bb[i][1])) * u; let x = 4;
      r.forEach(i => {
        const f = F[i], [w, h] = bb[i];
        for (let a = 0; a <= w; a++) o += `<line x1="${x + a * u}" y1="${y}" x2="${x + a * u}" y2="${y + h * u}" stroke="#cbd5e1" stroke-width="1"/>`;
        for (let b = 0; b <= h; b++) o += `<line x1="${x}" y1="${y + b * u}" x2="${x + w * u}" y2="${y + b * u}" stroke="#cbd5e1" stroke-width="1"/>`;
        f.cells.forEach(c => o += `<rect x="${x + c[0] * u + 1}" y="${y + c[1] * u + 1}" width="${u - 2}" height="${u - 2}" rx="2" fill="${f.fill || '#60a5fa'}" stroke="#1e3a8a" stroke-width="1"/>`);
        if (f.dot) o += `<circle cx="${x + f.dot[0] * u + u / 2}" cy="${y + f.dot[1] * u + u / 2}" r="${u * .25}" fill="#fff"/>`;
        if (f.lb) o += T(x + w * u / 2, y + Hm + 15, f.lb, { fs: 17, c: f.lbc || P.red });
        x += w * u + gap; W = Math.max(W, x - gap);
      });
      y += Hm + (r.some(i => F[i].lb) ? 32 : 10);
    });
    return svg(W + 6, y, o, Math.min(340, (W + 6) * 1.3));
  };

  // --- ko‘chalar panjarasi (tugunlar bo‘ylab)
  V.ext['4J11-panjara'] = v => {
    const w = v.w, h = v.h, u = Math.min(56, Math.floor(290 / Math.max(w, 1))), pd = 26, X = x => pd + x * u, Y = y => pd + (h - y) * u; let o = '';
    for (let i = 0; i <= w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#94a3b8" stroke-width="4" stroke-linecap="round"/>`;
    for (let j = 0; j <= h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#94a3b8" stroke-width="4" stroke-linecap="round"/>`;
    for (let i = 0; i <= w; i++) for (let j = 0; j <= h; j++) o += `<circle cx="${X(i)}" cy="${Y(j)}" r="4" fill="#475569"/>`;
    (v.must || []).forEach(p => o += `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="11" fill="#22c55e" stroke="#14532d" stroke-width="2"/>`);
    (v.block || []).forEach(p => o += `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="12" fill="#fff" stroke="${P.red}" stroke-width="3"/><path d="M${X(p[0]) - 6} ${Y(p[1]) - 6}l12 12m0 -12l-12 12" stroke="${P.red}" stroke-width="3.5" stroke-linecap="round"/>`);
    const lab = (p, s, c) => `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="12" fill="${c}"/>` + T(X(p[0]), Y(p[1]) + 1, s, { fs: 16, c: '#fff' });
    if (v.A) o += lab(v.A, 'A', P.blue); if (v.B) o += lab(v.B, 'B', P.red);
    (v.lbl || []).forEach(l => o += T(X(l.a[0]), Y(l.a[1]), l.s, { fs: 15, st: 1 }));
    return svg(w * u + pd * 2, h * u + pd * 2, o, Math.min(340, (w * u + pd * 2) * 1.2));
  };

  // --- rangli sharlar solingan qutilar
  V.ext['4J11-qutilar'] = v => {
    const L = v.l, n = L.length, bw = n > 3 ? 76 : 96, gap = 8, W = n * bw + (n - 1) * gap + 4; let o = '';
    const mx = Math.max(...L.map(b => b.n.reduce((a, e) => a + e[1], 0))); const per = bw > 80 ? 5 : 4, rr = 7;
    const H = 30 + Math.ceil(mx / per) * 17 + 34;
    L.forEach((b, i) => {
      const x = 2 + i * (bw + gap); o += `<path d="M${x} 10H${x + bw}V${H - 30}a8 8 0 0 1 -8 8H${x + 8}a8 8 0 0 1 -8 -8z" fill="#fff7ed" stroke="#b45309" stroke-width="2.5"/>`;
      let k = 0; b.n.forEach(([c, m]) => { for (let j = 0; j < m; j++, k++) { const cx = x + 12 + (k % per) * ((bw - 24) / (per - 1)), cy = H - 40 - Math.floor(k / per) * 17; o += `<circle cx="${cx}" cy="${cy}" r="${rr}" fill="${col(c)}" stroke="#334155" stroke-width="1.5"/>` } });
      o += T(x + bw / 2, H - 10, b.lb, { fs: 17, c: P.red });
    });
    return svg(W, H, o, Math.min(340, W * 1.3));
  };

  // --- tangalar
  V.ext['4J11-tanga'] = v => {
    const s = 54, g = 10, n = v.l.length, W = n * s + (n - 1) * g + 6; let o = '';
    v.l.forEach((k, i) => { const x = 3 + i * (s + g) + s / 2; o += `<circle cx="${x}" cy="${s / 2 + 3}" r="${s / 2}" fill="${k === 'G' ? '#fde68a' : '#fcd34d'}" stroke="#b45309" stroke-width="3"/>` + T(x, s / 2 + 4, k === 'G' ? 'Gerb' : k === 'R' ? '1' : k, { fs: k === 'G' ? 14 : 20, c: '#7c2d12' }) });
    return svg(W, s + 8, o, Math.min(340, W * 1.2));
  };
  // --- katakli maydon (simmetriya o‘qlari, markaz nuqtasi)
  V.ext['4J11-katak'] = v => {
    const w = v.w, h = v.h, u = Math.min(46, Math.floor(300 / w)), pd = 16, X = i => pd + i * u, Y = j => pd + j * u; let o = `<rect x="${pd}" y="${pd}" width="${w * u}" height="${h * u}" fill="#f8fbff"/>`;
    (v.marks || []).forEach(m => { if (m.fill) o += `<rect x="${X(m.x) + 1}" y="${Y(m.y) + 1}" width="${u - 2}" height="${u - 2}" rx="3" fill="${m.fill}"/>` });
    for (let i = 0; i <= w; i++) o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(h)}" stroke="#94a3b8" stroke-width="${i % w ? 1.5 : 2.5}"/>`;
    for (let j = 0; j <= h; j++) o += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(w)}" y2="${Y(j)}" stroke="#94a3b8" stroke-width="${j % h ? 1.5 : 2.5}"/>`;
    (v.marks || []).forEach(m => { if (m.img) o += V.im(m.img, X(m.x) + u * .12, Y(m.y) + u * .12, u * .76); if (m.lb) o += T(X(m.x) + u / 2, Y(m.y) + u / 2 + 1, m.lb, { fs: Math.max(16, u * .45), c: '#7c2d12' }) });
    (v.axis || []).forEach(a => { o += a.v != null ? `<line x1="${X(a.v)}" y1="${pd - 12}" x2="${X(a.v)}" y2="${Y(h) + 12}" stroke="${P.red}" stroke-width="3.5" stroke-dasharray="9 6"/>` : `<line x1="${pd - 12}" y1="${Y(a.h)}" x2="${X(w) + 12}" y2="${Y(a.h)}" stroke="${P.red}" stroke-width="3.5" stroke-dasharray="9 6"/>` });
    if (v.dot) o += `<circle cx="${X(v.dot[0])}" cy="${Y(v.dot[1])}" r="7" fill="${P.red}" stroke="#fff" stroke-width="2"/>`;
    return svg(w * u + pd * 2, h * u + pd * 2, o, Math.min(340, w * u + pd * 2));
  };
  // --- shakllar jadvali (qator va ustun yig‘indilari bilan)
  const SCOL = { doira: '#60a5fa', uchburchak: '#34d399', kvadrat: '#fbbf24', yulduz: '#f472b6', romb: '#a78bfa', olti: '#fb923c' };
  V.ext['4J11-sjadval'] = v => {
    const R = v.cells.length, K = v.cells[0].length, u = 54, sw = 58, W = K * u + sw + 8, H = R * u + (v.cs ? 44 : 0) + 8; let o = '';
    const box = (x, y, s) => { const q = s === '?'; return `<rect x="${x + 4}" y="${y + 8}" width="${sw - 8}" height="${u - 16}" rx="8" fill="${q ? '#fff7d6' : '#dcfce7'}" stroke="${q ? '#f5b301' : '#16a34a'}" stroke-width="2"/>` + T(x + sw / 2, y + u / 2 + 1, s, { fs: 18, c: q ? '#b45309' : '#14532d' }) };
    v.cells.forEach((r, i) => r.forEach((c, j) => { o += `<rect x="${4 + j * u}" y="${4 + i * u}" width="${u}" height="${u}" fill="#fff" stroke="#93c5fd" stroke-width="2"/>`; if (c) o += V.shp(c, 4 + j * u + 7, 4 + i * u + 7, u - 14, SCOL[c] || '#60a5fa') }));
    (v.rs || []).forEach((s, i) => { if (s !== '') o += box(4 + K * u, 4 + i * u, String(s)) });
    (v.cs || []).forEach((s, j) => { if (s !== '') o += `<g transform="translate(${4 + j * u - 2} ${4 + R * u - 4})">` + box(0, 0, String(s)).replace(`width="${sw - 8}"`, `width="${u - 4}"`).replace(`x="${sw / 2}"`, `x="${u / 2}"`) + '</g>' });
    return svg(W, H, o, Math.min(340, W * 1.25));
  };
  // --- tangalar va qog‘oz pullar (ikki qatorda, eni 340)
  const NOTE = { 1000: '#a7f3d0', 2000: '#bae6fd', 5000: '#fecaca', 10000: '#ddd6fe', 20000: '#fde68a', 50000: '#fbcfe8', 100000: '#c7d2fe' };
  const SP = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  V.ext['4J11-pul'] = v => {
    const lim = v.coin || 500, coins = v.v.filter(a => a <= lim), notes = v.v.filter(a => a > lim); let o = '', y = 2;
    if (coins.length) { const s = 72, g = (340 - coins.length * s) / Math.max(1, coins.length); coins.forEach((a, i) => { const x = g / 2 + i * (s + g); o += V.im('tanga', x, y, s) + T(x + s / 2, y + s / 2 + 1, SP(a), { fs: a >= 1000 ? 17 : 20, c: '#7c4a03' }) }); y += 80 }
    if (notes.length) { const w = Math.min(130, (340 - 8 * (notes.length - 1)) / notes.length), h = 62, g = (340 - notes.length * w) / notes.length; notes.forEach((a, i) => { const x = g / 2 + i * (w + g); o += `<rect x="${x}" y="${y + 2}" width="${w}" height="${h}" rx="8" fill="${NOTE[a] || '#e0f2fe'}" stroke="#0f766e" stroke-width="2"/><rect x="${x + 6}" y="${y + 8}" width="${w - 12}" height="${h - 12}" rx="5" fill="none" stroke="#0f766e88" stroke-width="1.5" stroke-dasharray="4 3"/>` + T(x + w / 2, y + 24, SP(a), { fs: 20, c: '#134e4a' }) + T(x + w / 2, y + 46, 'so‘m', { fs: 15, fw: 700, c: '#134e4a' }) }); y += h + 6 }
    return svg(340, y, o, 340);
  };
})();

// 4K (Tanqidiy fikrlash, 4-sinf) uchun rasm turlari. Turlar nomi '4K-' bilan boshlanadi.
//  4K-matn    — raqamlangan gaplar (kartochkalar): {l:['...','...'], lb:['1','2'] (ixtiyoriy), title, mk:['v','x',''] (belgi)}
//  4K-zanjir  — sabab-oqibat zanjiri (bloklar va strelkalar): {l:['A','B','C'], q:[2] ('?' bloklar), dir:'col'|'row'}
//  4K-mashina — "agar… bo‘lsa" son mashinasi: {inp:'14', ask:'Son juftmi?', yes:': 2', no:'+ 5', out:'?'}
//  4K-panjara — moslik jadvali (✓/✗): {rows:['Ali','Vali'], cols:['futbol','suzish'], m:{'0,1':'x','1,0':'v'}}
//  4K-uylar   — bir qatordagi uylar/o‘rinlar: {n:5, lb:['Ali','','?'...], num:true, hl:[2]}
//  4K-qutilar — yorliqli qutilar: {l:[{lb:'1-quti', s:'Olma'}], c:['#..']}
//  4K-karta   — stol ustidagi kartochkalar (bir tomoni): {l:[{s:'4'} | {c:'#ef4444'}], lb:['1','2',...]}
//  4K-kubik   — o‘yin kubiklari (yuqori, old, o‘ng yoqlar): {l:[{t:'5',f:'3',r:'1'}], stack:true (ustma-ust)}
//  4K-davra   — davra bo‘ylab teng oraliqda nuqtalar: {n:12, lb:{1:'1',7:'?'}, hl:[1,7], all:true (hamma raqam), only:true (faqat yozuvli nuqtalar)}
//  4K-qavat   — ko‘p qavatli uy (lift masalalari): {n:9, hl:[3], q:[7], lb:{3:'Ali'}}
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, T = V.T, svg = V.svg, esc = V.esc;
  const F = 'Nunito,system-ui,sans-serif';
  const AVC = ['#2563eb', '#db2777', '#16a34a', '#d97706', '#7c3aed', '#0891b2'];

  // ---------- raqamlangan gaplar
  V.ext['4K-matn'] = v => {
    const MK = { v: ['✓', '#16a34a', '#dcfce7'], x: ['✗', '#dc2626', '#fee2e2'], q: ['?', '#b45309', '#fff7d6'] };
    return `<div style="max-width:460px;margin:8px auto;text-align:left">${v.title ? `<div style="font:900 15px ${F};color:#1d4ed8;margin:0 0 6px 4px">${esc(v.title)}</div>` : ''}${v.l.map((s, i) => {
      const lb = v.lb ? v.lb[i] : String(i + 1), m = v.mk && MK[v.mk[i]];
      return `<div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:6px;background:#fff;border:2px solid #bfdbfe;border-radius:12px;padding:7px 9px"><span style="flex:0 0 auto;min-width:26px;height:26px;padding:0 4px;border-radius:13px;background:#2563eb;color:#fff;font:900 14px/26px ${F};text-align:center">${esc(lb)}</span><span style="flex:1;font:800 15px/1.35 ${F};color:#0b2a6f">${esc(s)}</span>${m ? `<span style="flex:0 0 26px;height:26px;border-radius:13px;background:${m[2]};color:${m[1]};font:900 17px/26px ${F};text-align:center">${m[0]}</span>` : ''}</div>`;
    }).join('')}</div>`;
  };

  // ---------- zanjir
  V.ext['4K-zanjir'] = v => {
    const col = v.dir === 'col', q = v.q || [];
    const box = (s, i) => `<span style="display:inline-block;max-width:${col ? 330 : 150}px;padding:7px 10px;border-radius:12px;font:800 14px/1.3 ${F};${q.includes(i) || s === '?' ? 'background:#fff7d6;border:2.5px dashed #f5b301;color:#b45309' : `background:#fff;border:2px solid ${AVC[i % AVC.length]};color:#0b2a6f`}">${esc(s)}</span>`;
    const arr = `<span style="font:900 20px ${F};color:#64748b;${col ? 'display:block;line-height:20px' : ''}">${col ? '↓' : '→'}</span>`;
    return `<div style="margin:8px auto;max-width:460px;display:flex;${col ? 'flex-direction:column;align-items:center' : 'flex-wrap:wrap;justify-content:center;align-items:center'};gap:4px">${v.l.map((s, i) => (i ? arr : '') + box(s, i)).join('')}</div>`;
  };

  // ---------- son mashinasi
  V.ext['4K-mashina'] = v => {
    let o = '';
    const rb = (x, y, w, h, s, c, bg, fs) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="10" fill="${bg}" stroke="${c}" stroke-width="2.5"/>` + T(x + w / 2, y + h / 2, s, { fs: fs || 16, c: s === '?' ? '#b45309' : P.ink });
    const ar = (x1, y1, x2, y2) => { const a = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI; return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#475569" stroke-width="2.5"/><path d="M0 0l-9 -5v10z" fill="#475569" transform="translate(${x2} ${y2}) rotate(${a})"/>` };
    o += rb(120, 4, 100, 34, v.inp, '#2563eb', '#dbeafe', 18);
    o += ar(170, 38, 170, 56);
    o += `<path d="M170 58L290 92L170 126L50 92z" fill="#fef3c7" stroke="#d97706" stroke-width="2.5"/>` + T(170, 92, v.ask, { fs: 14 });
    o += ar(50, 92, 50, 150) + T(36, 120, 'Ha', { fs: 14, c: P.green, a: 'end' }) + ar(290, 92, 290, 150) + T(304, 120, 'Yo‘q', { fs: 14, c: P.red, a: 'start' });
    o += rb(6, 152, 92, 34, v.yes, P.green, '#dcfce7') + rb(244, 152, 92, 34, v.no, P.red, '#fee2e2');
    o += ar(52, 186, 140, 222) + ar(290, 186, 200, 222);
    o += rb(120, 222, 100, 34, v.out == null ? '?' : v.out, v.out == null || v.out === '?' ? P.gold : '#2563eb', v.out == null || v.out === '?' ? '#fff7d6' : '#dbeafe', 18);
    return svg(342, 262, o, 342);
  };

  // ---------- moslik jadvali
  V.ext['4K-panjara'] = v => {
    const m = v.m || {}, cell = (i, j) => { const x = m[i + ',' + j]; return x === 'v' ? '<b style="color:#16a34a;font-size:20px">✓</b>' : x === 'x' ? '<b style="color:#dc2626;font-size:20px">✗</b>' : x === '?' ? '<b style="color:#b45309">?</b>' : '' };
    const th = 'padding:5px 4px;font-size:13px;line-height:1.15;max-width:84px;white-space:normal';
    return `<table class="vt" style="font-size:13px;max-width:100%"><thead><tr><th style="${th}"></th>${v.cols.map(c => `<th style="${th}">${esc(c)}</th>`).join('')}</tr></thead><tbody>${v.rows.map((r, i) => `<tr><th style="${th};white-space:nowrap;max-width:none">${esc(r)}</th>${v.cols.map((_, j) => `<td style="min-width:34px;padding:5px 3px">${cell(i, j)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  };

  // ---------- uylar qatori
  V.ext['4K-uylar'] = v => {
    const n = v.n, w = Math.min(64, 330 / n), H = 120; let o = '';
    for (let i = 0; i < n; i++) {
      const x = 4 + i * w, hl = (v.hl || []).includes(i), lb = (v.lb || [])[i] || '', q = lb === '?';
      const c = hl ? '#fde68a' : q ? '#fff7d6' : '#dbeafe';
      o += `<path d="M${x + 4} 44L${x + w / 2} ${18}L${x + w - 4} 44z" fill="${hl ? '#f59e0b' : '#ef4444'}" stroke="#7f1d1d" stroke-width="1.5"/>`;
      o += `<rect x="${x + 8}" y="44" width="${w - 16}" height="36" fill="${c}" stroke="#1e3a8a" stroke-width="2"/><rect x="${x + w / 2 - 5}" y="62" width="10" height="18" fill="#92400e"/>`;
      if (v.num !== false) o += T(x + w / 2, 8, (v.top || [])[i] != null ? v.top[i] : i + 1, { fs: 13, c: '#64748b' });
      if (lb) o += T(x + w / 2, 98, lb, { fs: lb.length > 6 ? 11 : 13, c: q ? '#b45309' : P.ink });
    }
    return svg(8 + n * w, H - 8, `<line x1="0" y1="81" x2="${8 + n * w}" y2="81" stroke="#94a3b8" stroke-width="3"/>` + o, Math.min(400, 8 + n * w + 40));
  };

  // ---------- yorliqli qutilar
  V.ext['4K-qutilar'] = v => `<div style="display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:8px auto;max-width:460px">${v.l.map((e, i) => `<div style="width:${v.l.length > 3 ? 96 : 120}px;text-align:center"><div style="font:900 13px ${F};color:#64748b;margin-bottom:3px">${esc(e.lb)}</div><div style="position:relative;height:74px;border-radius:8px;background:${(v.c && v.c[i]) || '#fcd34d'};border:2.5px solid #92400e;display:flex;align-items:center;justify-content:center;padding:4px"><span style="background:#fff;border:1.5px solid #92400e;border-radius:6px;padding:3px 5px;font:800 13px/1.2 ${F};color:#0b2a6f">${esc(e.s)}</span></div></div>`).join('')}</div>`;

  // ---------- ko‘p qavatli uy
  V.ext['4K-qavat'] = v => {
    const n = v.n, h = Math.min(26, 250 / n), W = 200, top = 6; let o = `<rect x="50" y="${top}" width="100" height="${n * h}" fill="#e0e7ff" stroke="#1e3a8a" stroke-width="2.5"/>`;
    for (let k = 1; k <= n; k++) {
      const y = top + (n - k) * h, hl = (v.hl || []).includes(k), q = (v.q || []).includes(k);
      if (hl || q) o += `<rect x="51" y="${y + 1}" width="98" height="${h - 2}" fill="${hl ? '#fde68a' : '#fff7d6'}"/>`;
      o += `<line x1="50" y1="${y}" x2="150" y2="${y}" stroke="#94a3b8" stroke-width="1"/>` + T(40, y + h / 2, k, { fs: 12, a: 'end', c: '#64748b' });
      o += `<rect x="62" y="${y + h * .25}" width="12" height="${h * .5}" fill="#93c5fd"/><rect x="126" y="${y + h * .25}" width="12" height="${h * .5}" fill="#93c5fd"/>`;
      if (q) o += T(100, y + h / 2, '?', { fs: 14, c: '#b45309' });
      const lb = (v.lb || {})[k]; if (lb) o += T(158, y + h / 2, lb, { fs: 12, a: 'start' });
    }
    return svg(W + 30, top + n * h + 8, o, 240);
  };

  // ---------- kartochkalar
  V.ext['4K-karta'] = v => `<div style="display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin:8px auto;max-width:440px">${v.l.map((e, i) => `<div style="text-align:center"><div style="width:64px;height:88px;border-radius:10px;border:2.5px solid #1e3a8a;background:${e.c || '#fff'};display:flex;align-items:center;justify-content:center;font:900 30px ${F};color:#0b2a6f;box-shadow:0 3px 0 #1e3a8a33">${e.s != null ? esc(e.s) : ''}</div>${v.lb ? `<div style="font:900 14px ${F};color:#dc2626;margin-top:3px">${esc(v.lb[i])}</div>` : ''}</div>`).join('')}</div>`;

  // ---------- o‘yin kubiklari
  V.ext['4K-kubik'] = v => {
    const s = 64, dx = s * .5, dy = s * .32; let o = '', W = 0, H = 0;
    const one = (x, y, d, top) => {
      let g = '';
      if (top) g += `<path d="M${x} ${y}l${dx} ${-dy}h${s}l${-dx} ${dy}z" fill="#fef3c7" stroke="#1e3a8a" stroke-width="2"/>` + T(x + s / 2 + dx / 2, y - dy / 2, d.t || '', { fs: 18, c: d.t === '?' ? '#b45309' : P.ink });
      g += `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="#fff" stroke="#1e3a8a" stroke-width="2"/>` + T(x + s / 2, y + s / 2, d.f || '', { fs: 24, c: d.f === '?' ? '#b45309' : P.ink });
      g += `<path d="M${x + s} ${y}l${dx} ${-dy}v${s}l${-dx} ${dy}z" fill="#dbeafe" stroke="#1e3a8a" stroke-width="2"/>` + T(x + s + dx / 2, y + s / 2 - dy / 2, d.r || '', { fs: 17, c: d.r === '?' ? '#b45309' : P.ink });
      return g;
    };
    if (v.stack) { const n = v.l.length; v.l.forEach((d, i) => { o += one(10, dy + 6 + i * s, d, i === 0) }); W = 10 + s + dx + 8; H = dy + 6 + n * s + 6 }
    else { v.l.forEach((d, i) => { o += one(10 + i * (s + dx + 24), dy + 6, d, true) }); W = 10 + v.l.length * (s + dx + 24); H = dy + s + 14 }
    return svg(W, H, o, Math.min(340, W * 1.3));
  };
  // ---------- davra
  V.ext['4K-davra'] = v => {
    const n = v.n, R = 110, c = 135; let o = `<circle cx="${c}" cy="${c}" r="${R}" fill="none" stroke="#cbd5e1" stroke-width="2" stroke-dasharray="4 5"/>`;
    for (let k = 1; k <= n; k++) {
      const a = -Math.PI / 2 + (k - 1) * 2 * Math.PI / n, x = c + R * Math.cos(a), y = c + R * Math.sin(a), hl = (v.hl || []).includes(k), lb = (v.lb || {})[k] != null ? v.lb[k] : v.all ? String(k) : '';
      if (v.only && !lb) continue;
      o += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${hl ? 13 : 9}" fill="${lb === '?' ? '#fff7d6' : hl ? '#fde68a' : '#dbeafe'}" stroke="${hl ? '#d97706' : '#2563eb'}" stroke-width="2"/>`;
      if (lb) o += T(x, y, lb, { fs: hl ? 13 : 11, c: lb === '?' ? '#b45309' : P.ink });
    }
    if (v.line) { const [p, q] = v.line.map(k => -Math.PI / 2 + (k - 1) * 2 * Math.PI / n); o = `<line x1="${c + R * Math.cos(p)}" y1="${c + R * Math.sin(p)}" x2="${c + R * Math.cos(q)}" y2="${c + R * Math.sin(q)}" stroke="#d97706" stroke-width="2.5" stroke-dasharray="6 4"/>` + o }
    return svg(270, 270, o, 270);
  };
  // ---------- soatlar yonma-yon (kichik): {l:[{h,m},...], q:true (oxirida '?' soat), lb:['1','2',...]}
  V.ext['4K-soatlar'] = v => {
    const n = v.l.length + (v.q ? 1 : 0), w = Math.min(110, Math.floor(340 / n));
    const cap = i => `<div style="font:900 13px ${F};color:#64748b;margin-top:2px">${esc((v.lb || [])[i] || (i + 1) + '-soat')}</div>`;
    const one = (c, i) => `<div style="flex:0 1 ${w}px;max-width:${w}px;text-align:center">${V.render({ t: 'clock', h: c.h, m: c.m })}${cap(i)}</div>`;
    const qc = v.q ? `<div style="flex:0 1 ${w}px;max-width:${w}px;text-align:center"><div style="width:${w - 6}px;height:${w - 6}px;max-width:100%;margin:0 auto;border-radius:50%;border:2.5px dashed #f5b301;background:#fff7d6;display:flex;align-items:center;justify-content:center;font:900 ${Math.round(w / 3)}px ${F};color:#b45309;box-sizing:border-box">?</div>${cap(v.l.length)}</div>` : '';
    return `<div style="display:flex;justify-content:center;align-items:flex-start;gap:6px;margin:8px auto;max-width:460px">${v.l.map(one).join('')}${qc}</div>`;
  };
})();

// 4Y (4-sinf yakuni: eng qiyin mavzular) uchun qo‘shimcha rasm turlari. Turlar nomi '4Y-' bilan boshlanadi.
// Hamma SVG eni 336 birlikdan oshmaydi (telefonda karta ichi ~338 px — 1:1), yozuvlar kamida 15 px.
//  '4Y-yoyilma' — kub yoyilmalari: {l:[{cells:[[x,y],...], lab:['1',...] (har katak yozuvi), hl:[i] (sariq katak), nm:'A'}]}
//  '4Y-nurlar'  — bir nuqtadan chiqqan nurlar: {deg:[0,40,...] (gradus, 0 — o‘ngga, 180 — chapga), lb:['A','B',...], O:'O',
//                  arcs:[{i,j,lb}] (i va j nurlar orasidagi yoy yozuvi)}
//  '4Y-aylana'  — aylana yo‘lak: {L:'400 m', run:[{lb:'Ali', v:'250 m/min', dir:1|-1}]} — ikkalasi S nuqtadan; dir 1 — soat strelkasi bo‘yicha
//  '4Y-poyezd'  — poyezd va ko‘prik (tunnel): {tr:'300 m', br:'600 m', v:'20 m/s', kind:'ko‘prik'|'tunnel'}
//  '4Y-zar'     — ustma-ust qo‘yilgan zarlar (old ko‘rinish): {n:3, top:4} — eng ustki yoqda top ta nuqta
//  '4Y-tasma2'  — "qolganining qismi" chizma modeli (nisbat saqlanadi): {n, a, m, b, top, l1, l2, rest}
//                  1-tasma n bo‘lak (a tasi bo‘yalgan); 2-tasma aynan qolgan (n − a) bo‘lak ostida, m bo‘lakka bo‘lingan (b tasi bo‘yalgan).
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  const P = V.P, MW = 336;
  const f1 = x => Math.round(x * 10) / 10;
  const T = (x, y, s, o = {}) => V.T(f1(x), f1(y), s, Object.assign({ fs: 16 }, o));

  V.ext['4Y-yoyilma'] = v => {
    const nets = v.l, k = nets.length, perRow = k === 1 ? 1 : 2, colW = MW / perRow;
    const dims = nets.map(n => [Math.max(...n.cells.map(c => c[0])) + 1, Math.max(...n.cells.map(c => c[1])) + 1]);
    const u = Math.min(k === 1 ? 46 : 32, ...dims.map(d => (colW - 16) / d[0]));
    const maxH = Math.max(...dims.map(d => d[1])) * u, lbH = nets.some(n => n.nm) ? 26 : 0, rowH = maxH + lbH + 14;
    let o = '';
    nets.forEach((n, i) => {
      const [w] = dims[i], cx = (i % perRow) * colW + colW / 2, x0 = cx - w * u / 2, y0 = Math.floor(i / perRow) * rowH + 6;
      n.cells.forEach((c, j) => {
        const hl = (n.hl || []).includes(j);
        o += `<rect x="${f1(x0 + c[0] * u)}" y="${f1(y0 + c[1] * u)}" width="${f1(u)}" height="${f1(u)}" fill="${hl ? '#fde68a' : '#bfdbfe'}" stroke="#1e3a8a" stroke-width="2"/>`;
        const s = (n.lab || [])[j]; if (s != null && s !== '') o += T(x0 + (c[0] + .5) * u, y0 + (c[1] + .5) * u, s, { fs: Math.max(15, Math.min(22, u * .48)), c: s === '?' ? '#b45309' : P.ink });
      });
      if (n.nm) o += T(cx, y0 + maxH + 16, n.nm, { fs: 18, c: P.red });
    });
    const H = Math.ceil(k / perRow) * rowH;
    return V.svg(MW, f1(H), o, MW);
  };

  V.ext['4Y-nurlar'] = v => {
    const cx = MW / 2, cy = 168, L = 130, R = a => a * Math.PI / 180;
    const pt = (a, r) => [cx + Math.cos(R(a)) * r, cy - Math.sin(R(a)) * r];
    let o = '';
    (v.arcs || []).forEach((a, k) => {
      const d1 = v.deg[a.i], d2 = v.deg[a.j], r = 42 + (k % 2) * 22, p1 = pt(d1, r), p2 = pt(d2, r), big = Math.abs(d2 - d1) > 180 ? 1 : 0;
      o += `<path d="M${f1(p1[0])} ${f1(p1[1])}A${r} ${r} 0 ${big} ${d2 > d1 ? 0 : 1} ${f1(p2[0])} ${f1(p2[1])}" fill="none" stroke="${P.red}" stroke-width="2.5"/>`;
      const m = pt((d1 + d2) / 2, r + 20); if (a.lb) o += T(m[0], m[1], a.lb, { fs: 16, c: a.lb.includes('?') ? '#b45309' : P.red, st: 1 });
    });
    v.deg.forEach((a, i) => {
      const e = pt(a, L), lp = pt(a, L + 16);
      o += `<line x1="${cx}" y1="${cy}" x2="${f1(e[0])}" y2="${f1(e[1])}" stroke="${P.blue}" stroke-width="3.5" stroke-linecap="round"/>`;
      o += `<circle cx="${f1(e[0])}" cy="${f1(e[1])}" r="4.5" fill="${P.ink}"/>`;
      if (v.lb && v.lb[i]) o += T(lp[0], lp[1], v.lb[i], { fs: 17, c: P.red, st: 1 });
    });
    o += `<circle cx="${cx}" cy="${cy}" r="5.5" fill="${P.ink}"/>` + T(cx, cy + 18, v.O || 'O', { fs: 17, c: P.red, st: 1 });
    return V.svg(MW, 196, o, MW);
  };


  V.ext['4Y-aylana'] = v => {
    const cx = 110, cy = 105, R = 78; let o = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#cbd5e1" stroke-width="16"/><circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6 6"/>`;
    o += `<rect x="${cx - 3}" y="${cy + R - 13}" width="6" height="26" fill="${P.red}"/>` + T(cx, cy + R - 28, 'S', { fs: 16, c: P.red });
    o += T(cx, cy, v.L, { fs: 17 });
    const COL = ['#2563eb', '#ea580c'];
    v.run.forEach((r, i) => {
      const rr = R + (i ? -24 : 24), a0 = Math.PI / 2, a1 = a0 + (r.dir || 1) * 1.1 * (i ? 1.2 : 1);
      const p = a => [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr];
      const [x0, y0] = p(a0), [x1, y1] = p(a1), sw = (r.dir || 1) > 0 ? 1 : 0;
      o += `<path d="M${f1(x0)} ${f1(y0)}A${rr} ${rr} 0 0 ${sw} ${f1(x1)} ${f1(y1)}" fill="none" stroke="${COL[i]}" stroke-width="3.5"/>`;
      const ang = a1 * 180 / Math.PI + ((r.dir || 1) > 0 ? 90 : -90);
      o += `<path d="M0 0l-11 -6v12z" fill="${COL[i]}" transform="translate(${f1(x1)} ${f1(y1)}) rotate(${f1(ang)})"/>`;
      o += `<rect x="222" y="${44 + i * 70}" width="16" height="16" rx="4" fill="${COL[i]}"/>` + T(244, 52 + i * 70, r.lb, { fs: 16, a: 'start' }) + T(222, 76 + i * 70, r.v, { fs: 15, a: 'start' });
    });
    return V.svg(MW, 215, o, MW);
  };

  V.ext['4Y-poyezd'] = v => {
    let o = ''; const y = 110, bx = 120, bw = 180;
    if (v.kind === 'tunnel') o += `<path d="M${bx} ${y}V${y - 62}a14 14 0 0 1 14 -14H${bx + bw - 14}a14 14 0 0 1 14 14V${y}" fill="#d6d3d1" stroke="#57534e" stroke-width="2.5"/><rect x="${bx + 8}" y="${y - 52}" width="${bw - 16}" height="52" fill="#44403c"/>`;
    else o += `<rect x="${bx - 6}" y="${y}" width="${bw + 12}" height="10" fill="#a16207"/><path d="M${bx} ${y + 10}v40M${bx + bw} ${y + 10}v40M${bx + bw / 2} ${y + 10}v40" stroke="#78350f" stroke-width="6"/><path d="M0 ${y + 50}H${MW}" stroke="#60a5fa" stroke-width="10" opacity=".5"/>`;
    o += `<line x1="0" y1="${y}" x2="${MW}" y2="${y}" stroke="#334155" stroke-width="3"/>`;
    const tx = 14, tl = 92; for (let k = 0; k < 3; k++) o += `<rect x="${tx + k * 31}" y="${y - 30}" width="28" height="24" rx="4" fill="${k === 2 ? '#dc2626' : '#2563eb'}" stroke="#1e3a8a" stroke-width="1.5"/><circle cx="${tx + k * 31 + 7}" cy="${y - 4}" r="4" fill="#334155"/><circle cx="${tx + k * 31 + 21}" cy="${y - 4}" r="4" fill="#334155"/>`;
    o += `<path d="M${tx} ${y - 40}h${tl - 6}" stroke="${P.ink}" stroke-width="2"/>` + T(tx + tl / 2 - 3, y - 54, v.tr, { fs: 15, c: v.tr.includes('?') ? '#b45309' : P.ink });
    o += `<path d="M${tx + tl + 4} ${y - 18}h18" stroke="${P.red}" stroke-width="3"/><path d="M${tx + tl + 26} ${y - 18}l-9 -5v10z" fill="${P.red}"/>`;
    o += `<path d="M${bx} ${y + (v.kind === 'tunnel' ? 18 : 62)}h${bw}" stroke="${P.ink}" stroke-width="2"/><path d="M${bx} ${y + (v.kind === 'tunnel' ? 12 : 56)}v12M${bx + bw} ${y + (v.kind === 'tunnel' ? 12 : 56)}v12" stroke="${P.ink}" stroke-width="2"/>` + T(bx + bw / 2, y + (v.kind === 'tunnel' ? 34 : 78), v.br, { fs: 15, c: String(v.br).includes('?') ? '#b45309' : P.ink });
    if (v.v) o += T(tx + tl / 2, y - 76, v.v, { fs: 15, c: P.red });
    return V.svg(MW, v.kind === 'tunnel' ? 156 : 200, o, MW);
  };

  V.ext['4Y-tasma2'] = v => {
    const L = 8, Rr = MW - 8, W = Rr - L, bh = 36, u1 = W / v.n, x2 = L + v.a * u1, W2 = Rr - x2, u2 = W2 / v.m, C1 = '#60a5fa', C2 = '#fbbf24', LN = '#1e3a8a';
    let o = '';
    const y = 40;
    o += `<path d="M${L} ${y - 6}v-10H${Rr}v10" fill="none" stroke="${P.ink}" stroke-width="2"/>` + T((L + Rr) / 2, y - 28, v.top || '?', { fs: 16, c: String(v.top || '?').includes('?') ? '#b45309' : P.ink });
    for (let i = 0; i < v.n; i++) o += `<rect x="${f1(L + i * u1)}" y="${y}" width="${f1(u1)}" height="${bh}" fill="${i < v.a ? C1 : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
    o += `<rect x="${L}" y="${y}" width="${f1(W)}" height="${bh}" fill="none" stroke="${LN}" stroke-width="2.8"/>`;
    const y2 = y + bh + 28;
    o += `<path d="M${f1(x2)} ${y + bh}V${y2}M${Rr} ${y + bh}V${y2}" stroke="#64748b" stroke-width="1.5" stroke-dasharray="4 4"/>`;
    for (let i = 0; i < v.m; i++) o += `<rect x="${f1(x2 + i * u2)}" y="${y2}" width="${f1(u2)}" height="${bh}" fill="${i < v.b ? C2 : '#fff'}" stroke="${LN}" stroke-width="2"/>`;
    o += `<rect x="${f1(x2)}" y="${y2}" width="${f1(W2)}" height="${bh}" fill="none" stroke="${LN}" stroke-width="2.8"/>`;
    const bx = x2 + v.b * u2 + 2, yb = y2 + bh + 6;
    o += `<path d="M${f1(bx)} ${yb}v10H${f1(Rr - 1)}v-10" fill="none" stroke="${P.ink}" stroke-width="2"/>`;
    o += T(Math.min(Math.max((bx + Rr) / 2, 62), MW - 62), yb + 28, v.rest, { fs: 16, c: P.red });
    const yl = yb + 56;
    o += `<rect x="${L}" y="${yl - 8}" width="16" height="16" rx="3" fill="${C1}" stroke="${LN}"/>` + T(L + 22, yl, v.l1, { fs: 15, a: 'start' });
    o += `<rect x="${L + 140}" y="${yl - 8}" width="16" height="16" rx="3" fill="${C2}" stroke="${LN}"/>` + T(L + 162, yl, v.l2, { fs: 15, a: 'start' });
    return V.svg(MW, yl + 14, o, MW);
  };

  // zar: old yoqlar oddiy, faqat eng ustki yoqdagi nuqtalar ko‘rinadi
  const PIPS = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] };
  V.ext['4Y-zar'] = v => {
    const n = v.n, s = Math.min(64, 150 / n), dx = s * .5, dy = s * .38, x0 = MW / 2 - (s + dx) / 2, H = n * s + dy + 12; let o = '';
    for (let i = 0; i < n; i++) {
      const y = H - 6 - (i + 1) * s;
      o += `<rect x="${f1(x0)}" y="${f1(y)}" width="${f1(s)}" height="${f1(s)}" rx="6" fill="#fff" stroke="#1e3a8a" stroke-width="2.2"/>`;
      o += `<path d="M${f1(x0 + s)} ${f1(y)}l${f1(dx)} ${f1(-dy)}v${f1(s)}l${f1(-dx)} ${f1(dy)}z" fill="#e2e8f0" stroke="#1e3a8a" stroke-width="2.2" stroke-linejoin="round"/>`;
      if (i === n - 1) {
        o += `<path d="M${f1(x0)} ${f1(y)}l${f1(dx)} ${f1(-dy)}h${f1(s)}l${f1(-dx)} ${f1(dy)}z" fill="#f8fafc" stroke="#1e3a8a" stroke-width="2.2" stroke-linejoin="round"/>`;
        const cx = x0 + s / 2 + dx / 2, cy = y - dy / 2;
        PIPS[v.top].forEach(([a, b]) => { o += `<ellipse cx="${f1(cx + a * s * .26 - b * dx * .26)}" cy="${f1(cy + b * dy * .26)}" rx="${f1(s * .07)}" ry="${f1(s * .05)}" fill="${P.ink}"/>` });
      }
    }
    o += `<rect x="${f1(x0 - 40)}" y="${f1(H - 6)}" width="${f1(s + dx + 80)}" height="6" rx="3" fill="#94a3b8"/>`;
    return V.svg(MW, f1(H + 2), o, MW);
  };
})();

// zz-rasm3d.js — ChatGPT rasmlari va barmoq bilan aylanadigan 3D (2-sinf bo‘limi, 09.11.2026).
// Fayl nomi "zz" bilan boshlanadi: boshqa vis-ext fayllaridan keyin yuklanadi.
// V.render ni o‘rab oladi va quyidagi turlarni qayta chizadi (misollar ma’lumoti o‘zgarmaydi):
//   tarozi, 2C-tarozi — haqiqiy tarozi rasmi (tarozi-teng / tarozi-chap / tarozi-ong), pallalarda narsalar va toshlar.
//   pul               — tanga va qog‘oz pul rasmi (pul-qogoz), qiymati ustida yoziladi, har pulning rangi boshqa. ham:1 — yonida hamyon.
//   obj (ct bilan)    — har guruh tepasida kichik idish rasmi (quti, likopcha, savat, guldon, akvarium, daraxt), narsalar ostida toza qatorda. ct yo‘q bo‘lsa — vis.js obj.
//   solid             — fazoviy shakl 3D da, o‘zi sekin aylanadi, barmoq bilan har tomonga buriladi.
//   cubes, 2F-kub     — kubiklar qurilmasi 3D da: boshlanishda eski rasmdagidek ko‘rinish, barmoq bilan aylantiriladi, ↺ — joyiga qaytaradi.
//   2F-kublar, 2F-jism, 3H-jism — bir nechta kichik 3D (har biri o‘z harfi bilan).
//   ming3d            — yangi tur: minglik kubi (10 ta yuzlik plita). {t:'ming3d', h:6} — 6 ta plita bor, qolgan 4 tasi xira (bo‘sh joy).
// Node'da (run.js) va 3D ishlamaydigan qurilmada eski tekis chizma ko‘rinadi. V.render0(v) — eski tekis chizma.
// RASMLAR: tarozi-teng tarozi-chap tarozi-ong pul-qogoz gir tanga likopcha-bosh savat-bosh quti daraxt akvarium guldon hamyon
// three.js: window.THREE bo‘lmasa cdnjs dan yuklanadi (window.THREE_SRC bilan boshqa manzil berish mumkin).
(function () {
  const V = typeof module !== 'undefined' ? require('../vis') : window.V;
  if (V.__rasm3d) return; V.__rasm3d = 1;
  const base = V.render; let STATIC = 0;
  V.render0 = v => { STATIC++; try { return base(v) } finally { STATIC-- } };
  const OV = {};
  V.render = v => (!STATIC && v && !Array.isArray(v) && OV[v.t]) ? OV[v.t](v) : base(v);
  const { svg, T, esc } = V, im = (n, x, y, w, h) => V.im(n, +x.toFixed(1), +y.toFixed(1), +w.toFixed(1), h == null ? undefined : +h.toFixed(1));
  const C = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  // ---------------- tarozi ----------------
  // pallalar markazi va ust cheti (rasm eniga nisbatan), rasmdan o‘lchangan
  const PAN = { 'tarozi-teng': [[.209, .552], [.790, .550]], 'tarozi-chap': [[.214, .617], [.786, .485]], 'tarozi-ong': [[.215, .469], [.785, .598]] };
  // tarozi toshi: rasm + ustida yozuv. "5 kg" — katta son, ostida kichik "kg" (haqiqiy toshlardagidek)
  function weight(lb, cx, bottom, g) {
    const m = lb.match(/^(\d+) ?(kg|g|t)$/); if (m && m[2] === 'kg') g *= Math.min(1.05, .8 + .22 * Math.log10(+m[1] || 1)); // og‘irroq tosh biroz kattaroq
    const x = cx - g / 2, y = bottom - g, ty = y + g * .6;
    const tx = (yy, str, fs) => `<text x="${cx.toFixed(1)}" y="${yy.toFixed(1)}" font-size="${fs}" font-weight="900" fill="#fff" stroke="#1f2937" stroke-width="${(fs / 5).toFixed(1)}" paint-order="stroke" text-anchor="middle" dominant-baseline="central">${esc(str)}</text>`;
    let o = im('gir', x, y, g);
    if (m) { const fs = Math.max(10, Math.round(g * (m[1].length > 2 ? .26 : .34))); o += tx(ty - fs * .28, m[1], fs) + tx(ty + fs * .62, m[2], Math.max(8, Math.round(fs * .62))) }
    else { const fs = Math.max(10, Math.round(g * (lb.length > 2 ? .24 : .36))); o += tx(ty, lb, fs) }
    return o;
  }
  function tarozi(v) {
    const W = 400, nm = v.tilt < 0 ? 'tarozi-chap' : v.tilt > 0 ? 'tarozi-ong' : 'tarozi-teng', P = PAN[nm];
    let o = im(nm, 0, 0, W, W), top = 52;
    const pan = (list, [px, py]) => {
      const all = []; list.forEach(e => { if (e.s != null) all.push(e); else for (let i = 0; i < e.n; i++) all.push({ img: e.img }) });
      const c = all.length, [sz, per] = c === 1 ? [72, 1] : c === 2 ? [58, 2] : c <= 3 ? [46, 3] : c <= 8 ? [36, 4] : c <= 15 ? [28, 5] : [23, 6];
      const cx = px * W, by = py * W + 6, rows = []; for (let i = 0; i < c; i += per) rows.push(all.slice(i, i + per));
      let s = '';
      for (let r = rows.length - 1; r >= 0; r--) { // yuqori qatorlar avval, pastki (oldingi) qator oxirida
        const row = rows[r], y = by - sz - r * sz * .78, x0 = cx - row.length * sz / 2;
        row.forEach((e, k) => {
          const x = x0 + k * sz;
          if (e.img) s += im(e.img, x, y, sz);
          else s += weight(String(e.s), x + sz / 2, y + sz, Math.min(sz * 1.08, 60));
        });
        top = Math.min(top, y - 8);
      }
      return s;
    };
    o += pan(v.l, P[0]) + pan(v.r, P[1]);
    const y0 = Math.floor(Math.min(top, 44)), y1 = 352;
    return `<svg class="vs" viewBox="0 ${y0} ${W} ${y1 - y0}" style="width:100%;max-width:${W}px" xmlns="http://www.w3.org/2000/svg" font-family="Nunito,system-ui,sans-serif">${o}</svg>`;
  }
  OV.tarozi = OV['2C-tarozi'] = tarozi;

  // ---------------- pul ----------------
  // pul-qogoz rasmida pul eni 0.042–0.958, bo‘yi 0.265–0.733 oralig‘ida. Har pul qiymati — boshqa rang (rangni aylantirish).
  const HUE = { 1000: 0, 2000: 95, 5000: 150, 10000: -55, 20000: 60, 50000: 200, 100000: 245, 200000: 25 };
  function pul(v) {
    const hx = v.ham ? 108 : 0; let o = '', x = 0, y = 0, rowH = 0, W = 0; const maxW = 540 - hx, used = new Set();
    for (const a of v.v) {
      const coin = a < 1000 || (v.coin1000 && a === 1000), w = coin ? 66 : 132, h = coin ? 66 : 66;
      if (x && x + w > maxW) { x = 0; y += rowH + 8; rowH = 0 }
      if (coin) o += im('tanga', x, y, 66) + T(x + 33, y + 34, C(a), { fs: a >= 1000 ? 15 : 18, c: '#7c4a03', st: 0 });
      else {
        const S = w / .916, hu = HUE[a] != null ? HUE[a] : 120; used.add(hu);
        o += `<g${hu ? ` filter="url(#pq${hu < 0 ? 'm' + -hu : hu})"` : ''}>${im('pul-qogoz', x - .042 * S, y + h / 2 - .499 * S, S)}</g>` +
          T(x + w / 2, y + h / 2 + 1, C(a), { fs: a >= 100000 ? 19 : 21, c: '#0b2a6f', st: 1 }) + T(x + w - 24, y + 14, 'so‘m', { fs: 9, c: '#0b2a6f' });
      }
      x += w + 8; rowH = Math.max(rowH, h); W = Math.max(W, x - 8);
    }
    const defs = [...used].filter(Boolean).map(hu => `<filter id="pq${hu < 0 ? 'm' + -hu : hu}" color-interpolation-filters="sRGB"><feColorMatrix type="hueRotate" values="${hu}"/></filter>`).join('');
    if (!hx) return svg(W + 2, y + rowH + 2, (defs ? `<defs>${defs}</defs>` : '') + o);
    const H = Math.max(y + rowH, 96); // hamyon chapda, pullar o‘ngda (ikkalasi o‘rtadan tekislanadi)
    return svg(hx + W + 2, H + 2, (defs ? `<defs>${defs}</defs>` : '') + im('hamyon', 0, H / 2 - 50, 100) + `<g transform="translate(${hx} ${((H - y - rowH) / 2).toFixed(1)})">${o}</g>`);
  }
  OV.pul = pul;

  // ---------------- idishlar: obj guruhida ct (quti, likopcha, savat, guldon, akvarium, daraxt) ----------------
  // Siroj qoidalari (09.11): matnda aytilgan idish rasmda ham ko‘rinsin; LEKIN narsalarni idish rasmi ichiga joylamaymiz
  // (qo‘lda yig‘ilgan sahna g‘uj, yopishtirilganday ko‘rinadi). Shuning uchun har guruh: tepada kichik tayyor idish rasmi,
  // ostida narsalar toza qatorlarda (bittalab sanaladi). {t:'obj', g:[{img:'olma', n:5, ct:'savat', lb:'1-savat'}]}
  // n: 0 — faqat idish rasmi (masalan, «savatlarga 5 tadan solishdi» da savat qanday ekanini ko‘rsatish uchun).
  const CT = { likopcha: { img: 'likopcha-bosh' }, savat: { img: 'savat-bosh' }, quti: { img: 'quti' }, daraxt: { img: 'daraxt' }, akvarium: { img: 'akvarium' }, guldon: { img: 'guldon' } };
  const ICON = 58;
  const HLR = (x, y, w, h) => `<rect x="${(x - 3).toFixed(1)}" y="${(y - 3).toFixed(1)}" width="${(w + 6).toFixed(1)}" height="${(h + 6).toFixed(1)}" rx="16" fill="#fef08a" stroke="#f59e0b" stroke-width="3"/>`; // Ustoz ko‘rsatuvi: g.hl — guruh sariq yonadi (vis.js obj dagidek)
  function ctBlock(g, cols, s) {
    const c = CT[g.ct], n = g.n || 0, cc = Math.max(1, Math.min(cols, n)), rr = n ? Math.ceil(n / cc) : 0, lbH = g.lb ? 24 : 0;
    const gw = n ? cc * s : 0, W = Math.max(ICON + 20, gw + 16, g.lb ? String(g.lb).length * 8.6 + 18 : 0), H = 6 + ICON + (n ? 4 + rr * s : 0) + 8 + lbH;
    return { w: W, h: H, d: (bx, by) => {
      let o = (g.hl ? HLR(bx, by, W, H) : '') + `<rect x="${bx}" y="${by}" width="${W.toFixed(1)}" height="${H.toFixed(1)}" rx="14" fill="#eff6ff" stroke="#93c5fd" stroke-width="2"${g.dash ? ' stroke-dasharray="6 5"' : ''}/>`;
      o += im(c.img, bx + W / 2 - ICON / 2, by + 6, ICON);
      const y0 = by + 6 + ICON + 4;
      if (g.closed) o += V.hatch(bx + 8, y0, W - 16, rr * s, '10 ta');
      else for (let i = 0; i < n; i++) {
        const row = Math.floor(i / cc), inRow = row < rr - 1 || n % cc === 0 ? cc : n % cc, x = bx + W / 2 - inRow * s / 2 + (i % cc) * s, y = y0 + row * s;
        o += im(g.img, x + 2, y + 2, s - 4);
        if (false && g.cross && i >= n - g.cross) o += `<path d="M${(x + 4).toFixed(1)} ${(y + 4).toFixed(1)}L${(x + s - 4).toFixed(1)} ${(y + s - 4).toFixed(1)}M${(x + s - 4).toFixed(1)} ${(y + 4).toFixed(1)}L${(x + 4).toFixed(1)} ${(y + s - 4).toFixed(1)}" stroke="${V.P.red}" stroke-width="4" stroke-linecap="round"/>`;
      }
      if (g.lb) o += T(bx + W / 2, by + H - 14, g.lb, { fs: 15 });
      return o } };
  }
  // oddiy guruh (eski obj dagidek): ramka, narsalar, chizib tashlash, raqam, yozuv
  function plainBlock(g, cols, s, many) {
    const c = Math.min(cols, g.n), r = Math.ceil(g.n / cols), w = Math.max(c, 1) * s + 16, h = Math.max(r, 1) * s + 16 + (g.lb ? 24 : 0);
    return { w, h, d: (bx, by) => { let o = g.hl ? HLR(bx, by, w, h) : '';
      if (many || g.box) o += `<rect x="${bx}" y="${by}" width="${w}" height="${h}" rx="14" fill="${g.box === 'none' ? 'none' : '#eff6ff'}" stroke="#93c5fd" stroke-width="2" ${g.dash ? 'stroke-dasharray="6 5"' : ''}/>`;
      for (let k = 0; k < g.n; k++) { const cx = bx + 8 + (k % cols) * s, cy = by + 8 + Math.floor(k / cols) * s; o += im(g.img, cx + 2, cy + 2, s - 4);
        if (false && g.cross && k >= g.n - g.cross) o += `<path d="M${cx + 4} ${cy + 4}L${cx + s - 4} ${cy + s - 4}M${cx + s - 4} ${cy + 4}L${cx + 4} ${cy + s - 4}" stroke="${V.P.red}" stroke-width="4" stroke-linecap="round"/>`;
        if (g.num) o += T(cx + s - 6, cy + 8, k + 1, { fs: 11, c: V.P.blue, st: 1 }) }
      if (g.lb) o += T(bx + w / 2, by + h - 13, g.lb, { fs: 15 });
      return o } };
  }
  OV.obj = v0 => {
    if (!v0.g || !v0.g.some(g => g && g.ct && CT[g.ct])) return base(v0);
    // Qoida (Siroj 09.11, vis.js obj dagidek): ≥2 ta to‘la o‘nlik guruh bo‘lsa — birinchisi ochiq, qolganlari yopiq «10 ta» (bittalab sanalmasin)
    const full = v0.g.filter(g => g.n === 10 && !g.cross && !g.dash && !g.num); let seen = false;
    const BOX = V.BOX10 || {}; // vis.js dagidek: to‘la «10 talik» guruh — haqiqiy idish rasmi (birinchisi ochiq, qolgani yopiq), rasmi yo‘q narsada (yoki matnda boshqa idish — savat, likopcha) shtrix
    const v = { ...v0, g: v0.g.map(g => { if (full.length >= 2 && full.includes(g)) { const bx = (!g.ct || g.ct === 'quti') && BOX[g.img]; const r = seen ? { ...g, closed: true, pic: bx && bx[1] } : { ...g, pic: bx && bx[0] }; seen = true; return r } return g }) };
    const cols = v.cols || 5, s = v.size || (v.g.reduce((a, g) => a + (g.closed || g.pic ? 0 : g.n || 0), 0) > 30 ? 30 : 36), maxW = v.maxW || 560;
    const tot = v.g.reduce((a, g) => a + (g.ct && !g.closed && !g.pic ? g.n || 0 : 0), 0), cs = v.ctSize || (tot > 24 ? 30 : 36), cc = v.ctCols || Math.min(cols, 5);
    const closedPlain = g => { const b = plainBlock(g, g.cols || cols, g.s || s, true), lbH = g.lb ? 24 : 0; return { w: b.w, h: b.h, d: (x, y) => V.hatch(x, y, b.w, b.h - lbH, '10 ta') + (g.lb ? T(x + b.w / 2, y + b.h - 13, g.lb, { fs: 15 }) : '') } };
    const PS = 112, picBlock = g => ({ w: PS, h: PS + (g.lb ? 24 : 0), d: (x, y) => (g.hl ? HLR(x, y, PS, PS) : '') + im(g.pic, x, y, PS) + (g.lb ? T(x + PS / 2, y + PS + 11, g.lb, { fs: 15 }) : '') });
    const bl = v.g.map(g => g.pic ? picBlock(g) : g.ct && CT[g.ct] ? ctBlock(g, cc, cs) : g.closed && V.hatch ? closedPlain(g) : plainBlock(g, g.cols || cols, g.s || s, v.g.length > 1)); // g.s, g.cols — shu guruh uchun alohida o‘lcham
    let W = 0, x = 0, y = 0, rowH = 0; const pos = [], rows = [[]];
    for (const b of bl) { if (x && x + b.w > maxW) { x = 0; y += rowH + 12; rowH = 0; rows.push([]) } pos.push([x, y]); rows[rows.length - 1].push(b); x += b.w + 12; rowH = Math.max(rowH, b.h); W = Math.max(W, x - 12) }
    // bir qatordagi bloklar pastki chetidan tekislanadi (idish va narsalar bir chiziqda tursin)
    let i = 0; const out = []; for (const r of rows) { const mh = Math.max(...r.map(b => b.h)); for (const b of r) { out.push(b.d(pos[i][0], pos[i][1] + mh - b.h)); i++ } }
    return svg(W + 2, y + rowH + 2, `<g transform="translate(1 1)">${out.join('')}</g>`);
  };
  // hamyon: {t:'pul', v:[...], ham:1} — pullar yonida hamyon rasmi (matnda «hamyonda» deyilganda)

  // ---------------- 3D (brauzerda) ----------------
  const enc = o => esc(JSON.stringify(o)).replace(/"/g, '&quot;');
  const HINT = '<div class="v3h"><svg viewBox="0 0 24 24"><path d="M7 8l-4 4 4 4M17 8l4 4-4 4M3 12h18"/></svg>Barmoq bilan suring — aylanadi</div>';
  const box3 = (spec, fallback, cls, extra) => `<div class="v3d ${cls || ''}" data-v3="${enc(spec)}"><div class="v3s">${fallback}</div>${extra || ''}</div>`;
  OV.solid = v => box3({ k: 'solid', s: v.s }, V.render0(v), 'v3-solid') + HINT;
  const CUBE_RESET = '<button class="v3r" type="button" aria-label="Boshidagi ko‘rinish">↺</button>';
  OV.cubes = v => box3({ k: 'cubes', hm: v.hm, mono: !!v.mono, view: 'iso' }, V.render0(v), 'v3-cubes', CUBE_RESET) + HINT;
  OV['2F-kub'] = v => box3({ k: 'cubes', hm: v.hm, mono: !!v.mono, view: 'front' }, V.render0(v), 'v3-cubes', CUBE_RESET) + HINT;
  OV['2F-kublar'] = v => '<div class="v3row">' + v.l.map(x => `<div class="v3cell">${box3({ k: 'cubes', hm: x.hm, mono: !!x.mono, view: 'front', small: 1 }, V.render0({ t: '2F-kub', hm: x.hm, mono: x.mono }), 'v3-small', CUBE_RESET)}<div class="v3lb">${esc(x.lb || '')}</div></div>`).join('') + '</div>' + HINT;
  const jism = v => '<div class="v3row">' + v.l.map(e => `<div class="v3cell v3j">${box3({ k: 'solid', s: e.s, small: 1 }, V.render0({ t: 'solid', s: e.s }), 'v3-small')}${e.lb ? `<div class="v3lb" style="color:${e.c || '#ef4444'}">${esc(e.lb)}</div>` : ''}</div>`).join('') + '</div>' + HINT;
  OV['2F-jism'] = OV['3H-jism'] = jism;
  // minglik: tekis zaxira — yuzlik rasmlari qatori
  OV.ming3d = v => box3({ k: 'ming', h: v.h == null ? 10 : v.h }, base({ t: 'b10', h: v.h == null ? 10 : v.h }), 'v3-ming') + HINT;
  V.TYPES && !V.TYPES.includes('ming3d') && V.TYPES.push('ming3d');

  V.CSS += `
.v3d{position:relative;margin:6px auto;max-width:340px;touch-action:pan-y}.v3d canvas{display:block;margin:0 auto;touch-action:none;cursor:grab;border-radius:14px;background:radial-gradient(circle at 50% 40%,#ffffff,#eef5ff)}
.v3d.on .v3s{display:none}.v3d:not(.on) canvas{display:none}.v3d.v3-small{max-width:150px;margin:2px auto}
.v3r{position:absolute;right:6px;top:6px;width:34px;height:34px;border-radius:50%;border:1.5px solid #93c5fd;background:#fff;color:#1d4ed8;font:900 18px/1 Nunito,system-ui,sans-serif;padding:0;display:none}.v3d.on.moved .v3r{display:block}
.v3h{display:flex;align-items:center;justify-content:center;gap:6px;font:800 12.5px Nunito,system-ui,sans-serif;color:#64748b;margin:2px 0 4px}.v3h svg{width:16px;height:16px;fill:none;stroke:#64748b;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.v3row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;align-items:flex-end}.v3cell{flex:1 1 0;min-width:96px;max-width:170px;text-align:center}.v3cell.v3j{min-width:70px;max-width:120px}
.v3lb{font:900 20px Nunito,system-ui,sans-serif;color:#ef4444;margin-top:2px}`;

  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  { const st = document.createElement('style'); st.textContent = V.CSS.slice(V.CSS.indexOf('.v3d{')); (document.head || document.documentElement).appendChild(st) } // page.js CSS ni Node'da oladi — bu yerda qo‘shamiz

  // ---- three.js yuklash ----
  let loading = 0; const waitQ = [];
  function need3(cb) {
    if (window.THREE) return cb(); waitQ.push(cb); if (loading) return; loading = 1;
    const s = document.createElement('script'); s.src = window.THREE_SRC || 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    s.onload = () => waitQ.splice(0).forEach(f => { try { f() } catch (e) { (window.ERR3 = window.ERR3 || []).push(e.message) } });
    s.onerror = () => { loading = 2 }; document.head.appendChild(s);
  }
  let RD = null; // bitta umumiy WebGL chizgich: brauzer cheklovidan oshmaslik uchun har rasm o‘z 2D kanvasiga ko‘chiriladi
  function renderer() {
    if (RD !== null) return RD;
    try { RD = new THREE.WebGLRenderer({ antialias: true, alpha: true }); RD.setClearColor(0x000000, 0) } catch (e) { RD = false }
    return RD;
  }
  const LIVE = new Set(); let raf = 0;

  const PAL = { kub: 0x60a5fa, par: 0x34d399, piramida: 0xf87171, shar: 0xf472b6, silindr: 0xa78bfa, konus: 0x2dd4bf };
  const CUBE_COLS = [0x60a5fa, 0xfbbf24, 0x34d399, 0xf472b6];
  const mat = (c, o) => new THREE.MeshLambertMaterial(Object.assign({ color: c }, o || {}));
  function poly(s) {
    if (s === 'piramida') { const a = .95, h = 1.7, V3 = [[-a, 0, a], [a, 0, a], [a, 0, -a], [-a, 0, -a], [0, h, 0]];
      return { V: V3, F: [[3, 2, 1, 0], [0, 1, 4], [1, 2, 4], [2, 3, 4], [3, 0, 4]], E: [[0, 1], [1, 2], [2, 3], [3, 0], [0, 4], [1, 4], [2, 4], [3, 4]], cy: h / 2.4 } }
    const [x, y, z] = s === 'par' ? [1.25, .62, .7] : [.8, .8, .8];
    const V3 = [[-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z], [-x, -y, -z], [x, -y, -z], [x, y, -z], [-x, y, -z]].map(p => [p[0], p[1] + y, p[2]]);
    return { V: V3, F: [[0, 1, 2, 3], [5, 4, 7, 6], [4, 0, 3, 7], [1, 5, 6, 2], [3, 2, 6, 7], [4, 5, 1, 0]], E: [[3, 2], [2, 6], [6, 7], [7, 3], [0, 1], [1, 5], [5, 4], [4, 0], [0, 3], [1, 2], [5, 6], [4, 7]], cy: y };
  }
  function stripe(c, n) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const x = cv.getContext('2d'), b = '#' + new THREE.Color(c).getHexString();
    const lt = '#' + new THREE.Color(c).lerp(new THREE.Color(0xffffff), .55).getHexString(); // och yo‘l oq emas: oq fonda shakl chegarasi yo‘qolmasin
    for (let k = 0; k < n; k++) { x.fillStyle = k % 2 ? lt : b; x.fillRect(k * 256 / n, 0, 256 / n + 1, 128) }
    return new THREE.CanvasTexture(cv);
  }
  function solidScene(s, g) {
    const col = PAL[s] || 0x60a5fa;
    if (s === 'kub' || s === 'par' || s === 'piramida') {
      const P = poly(s), VV = P.V.map(p => new THREE.Vector3(...p));
      for (const ix of P.F) { const pos = []; for (let k = 1; k < ix.length - 1; k++) for (const j of [ix[0], ix[k], ix[k + 1]]) pos.push(VV[j].x, VV[j].y, VV[j].z);
        const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.computeVertexNormals();
        g.add(new THREE.Mesh(geo, mat(col, { side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 }))) }
      for (const [a, b] of P.E) g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([VV[a], VV[b]]), new THREE.LineBasicMaterial({ color: 0x1e293b })));
      g.position.y = -P.cy; return;
    }
    const sm = o => new THREE.MeshPhongMaterial(Object.assign({ color: col, shininess: 60 }, o || {})), smT = o => new THREE.MeshPhongMaterial(Object.assign({ map: stripe(col, 8), shininess: 60 }, o || {}));
    if (s === 'shar') { g.add(new THREE.Mesh(new THREE.SphereGeometry(1.1, 48, 32), smT())); return }
    if (s === 'silindr') { g.add(new THREE.Mesh(new THREE.CylinderGeometry(.85, .85, 1.8, 48, 1, true), smT({ side: THREE.DoubleSide })));
      for (const y of [.9, -.9]) { const c = new THREE.Mesh(new THREE.CircleGeometry(.85, 48), sm()); c.rotation.x = y > 0 ? -Math.PI / 2 : Math.PI / 2; c.position.y = y; g.add(c) } return }
    if (s === 'konus') { g.add(new THREE.Mesh(new THREE.ConeGeometry(1, 1.9, 48, 1, true), smT({ side: THREE.DoubleSide })));
      const c = new THREE.Mesh(new THREE.CircleGeometry(1, 48), sm()); c.rotation.x = Math.PI / 2; c.position.y = -.95; g.add(c) }
  }
  function cubeScene(sp, g) {
    const hm = sp.hm, R = hm.length, Cn = hm[0].length, H = Math.max(1, ...hm.flat());
    const box = new THREE.BoxGeometry(.97, .97, .97), eg = new THREE.EdgesGeometry(box), lm = new THREE.LineBasicMaterial({ color: 0x1e3a8a });
    const mats = CUBE_COLS.map(c => mat(c, { polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 })); // qirra chiziqlari yaxlit ko‘rinsin
    for (let i = 0; i < R; i++) for (let j = 0; j < Cn; j++) {
      const fl = new THREE.Mesh(new THREE.PlaneGeometry(.98, .98), new THREE.MeshBasicMaterial({ color: 0xe2e8f0, side: THREE.DoubleSide }));
      fl.rotation.x = -Math.PI / 2; fl.position.set(j - (Cn - 1) / 2, -H / 2 - .002, i - (R - 1) / 2); g.add(fl);
      for (let k = 0; k < hm[i][j]; k++) {
        const m = new THREE.Mesh(box, sp.mono ? mats[0] : mats[(i + j + k) % 4]); m.add(new THREE.LineSegments(eg, lm));
        m.position.set(j - (Cn - 1) / 2, k + .5 - H / 2, i - (R - 1) / 2); g.add(m);
      }
    }
  }
  function mingScene(sp, g) {
    // 10 ta yuzlik plita (10 × 10 × 1), har biri ichida 100 ta kubcha chizig‘i
    const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d');
    x.fillStyle = '#a78bfa'; x.fillRect(0, 0, 256, 256); x.strokeStyle = '#5b21b6'; x.lineWidth = 2.2; for (let k = 0; k <= 10; k++) { x.beginPath(); x.moveTo(k * 25.6, 0); x.lineTo(k * 25.6, 256); x.moveTo(0, k * 25.6); x.lineTo(256, k * 25.6); x.stroke() }
    const top = new THREE.CanvasTexture(cv); const cv2 = document.createElement('canvas'); cv2.width = 256; cv2.height = 26; const y = cv2.getContext('2d');
    y.fillStyle = '#8b5cf6'; y.fillRect(0, 0, 256, 26); y.lineWidth = 3; y.strokeStyle = '#4c1d95'; y.lineWidth = 2; for (let k = 0; k <= 10; k++) { y.beginPath(); y.moveTo(k * 25.6, 0); y.lineTo(k * 25.6, 26); y.stroke() } y.strokeRect(0, 0, 256, 26);
    const side = new THREE.CanvasTexture(cv2);
    const S = .2, geo = new THREE.BoxGeometry(10 * S, S * .78, 10 * S); // plitalar orasida ozgina bo‘shliq — har biri alohida ko‘rinsin
    const full = [mat(0xffffff, { map: side }), mat(0xffffff, { map: side }), mat(0xffffff, { map: top }), mat(0xffffff, { map: top }), mat(0xffffff, { map: side }), mat(0xffffff, { map: side })];
    for (let k = 0; k < 10; k++) {
      const on = k < sp.h, m = on ? new THREE.Mesh(geo, full) : new THREE.Mesh(geo, mat(0xc4b5fd, { transparent: true, opacity: .16, depthWrite: false }));
      m.position.y = (k + .5) * S - 1; g.add(m);
      const e = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: on ? 0x4c1d95 : 0xa78bfa, transparent: !on, opacity: on ? 1 : .6 })); e.position.copy(m.position); g.add(e);
    }
  }
  const DEG = Math.PI / 180;
  function initQ(sp) {
    const q = new THREE.Quaternion(), qx = new THREE.Quaternion(), qy = new THREE.Quaternion();
    const [ay, ax] = sp.k === 'cubes' ? (sp.view === 'front' ? [-22, 24] : [-45, 30]) : sp.k === 'ming' ? [-35, 26] : [-32, 26];
    qy.setFromAxisAngle(new THREE.Vector3(0, 1, 0), ay * DEG); qx.setFromAxisAngle(new THREE.Vector3(1, 0, 0), ax * DEG);
    return q.multiplyQuaternions(qx, qy);
  }
  function mount(el) {
    const R3 = renderer(); if (!R3) { el.dataset.st = 'no'; return }
    let sp; try { sp = JSON.parse(el.dataset.v3) } catch (e) { el.dataset.st = 'no'; return }
    const small = !!sp.small, cw = Math.max(80, Math.min(el.clientWidth || 300, small ? 150 : 340));
    const W = Math.round(cw), H = Math.round(small ? cw : sp.k === 'solid' ? Math.min(220, cw * .72) : Math.min(250, cw * .78));
    const cv = document.createElement('canvas'), dpr = Math.min(window.devicePixelRatio || 1, 2); cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const sc = new THREE.Scene(); sc.add(new THREE.AmbientLight(0xffffff, .72)); const dl = new THREE.DirectionalLight(0xffffff, .42); dl.position.set(2, 5, 6); sc.add(dl); const dl2 = new THREE.DirectionalLight(0xffffff, .16); dl2.position.set(-4, 2, -3); sc.add(dl2); // yorug‘lik kamera tomonida: ranglar eski rasmdagidek yorqin
    const piv = new THREE.Group(), g = new THREE.Group(); piv.add(g); sc.add(piv);
    if (sp.k === 'solid') solidScene(sp.s, g); else if (sp.k === 'ming') mingScene(sp, g); else cubeScene(sp, g);
    // kamera: shakl qanday burilsa ham kadrdan chiqmasin (atrofidagi shar bo‘yicha)
    const bb = new THREE.Box3().setFromObject(g), cen = bb.getCenter(new THREE.Vector3()), rad = bb.getSize(new THREE.Vector3()).length() / 2;
    g.position.sub(cen);
    const fov = 30, cam = new THREE.PerspectiveCamera(fov, W / H, .1, 200), half = Math.min(fov / 2, Math.atan(Math.tan(fov / 2 * DEG) * W / H) / DEG) * DEG;
    cam.position.set(0, 0, rad / Math.sin(half) * 1.02); cam.lookAt(0, 0, 0);
    const q0 = initQ(sp); piv.quaternion.copy(q0);
    const ctx = cv.getContext('2d');
    const S = { el, cv, ctx, sc, cam, piv, W, H, dpr, auto: sp.k === 'solid' || sp.k === 'ming', dirty: true, vis: true, q0 };
    el.insertBefore(cv, el.firstChild); el.classList.add('on'); el.dataset.st = 'on'; el.__s = S;
    let drag = null; const AY = new THREE.Vector3(0, 1, 0), AX = new THREE.Vector3(1, 0, 0), QQ = new THREE.Quaternion();
    cv.addEventListener('pointerdown', e => { drag = [e.clientX, e.clientY]; S.auto = false; try { cv.setPointerCapture(e.pointerId) } catch (_) { } e.preventDefault() });
    cv.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag[0], dy = e.clientY - drag[1]; if (!dx && !dy) return;
      piv.quaternion.premultiply(QQ.setFromAxisAngle(AY, dx * .012)); piv.quaternion.premultiply(QQ.setFromAxisAngle(AX, dy * .012)); drag = [e.clientX, e.clientY]; el.classList.add('moved'); S.dirty = true; go() });
    const up = () => drag = null; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    const rb = el.querySelector('.v3r'); if (rb) rb.addEventListener('click', () => { piv.quaternion.copy(q0); el.classList.remove('moved'); S.dirty = true; go() });
    LIVE.add(S); go();
  }
  function draw(S) {
    const R3 = RD; R3.setPixelRatio(S.dpr); R3.setSize(S.W, S.H, false); R3.render(S.sc, S.cam);
    S.ctx.clearRect(0, 0, S.cv.width, S.cv.height); S.ctx.drawImage(R3.domElement, 0, 0, S.cv.width, S.cv.height);
  }
  function go() { if (!raf) raf = requestAnimationFrame(loop) }
  function loop() {
    raf = 0; let more = false;
    for (const S of LIVE) {
      if (!S.el.isConnected) { LIVE.delete(S); continue }
      if (!S.vis) continue;
      if (S.auto) { S.piv.rotateY(.008); S.dirty = true; more = true } // o‘z tik o‘qi atrofida: doim ozgina yuqoridan ko‘rinadi
      if (S.dirty) { try { draw(S) } catch (e) { (window.ERR3 = window.ERR3 || []).push(e.message) } S.dirty = false }
    }
    if (more) go();
  }
  const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => {
    for (const e of es) { const el = e.target;
      if (e.isIntersecting && el.dataset.st === 'wait') { el.dataset.st = 'load'; need3(() => { if (el.isConnected) try { mount(el) } catch (er) { el.dataset.st = 'no'; (window.ERR3 = window.ERR3 || []).push(er.message) } }) }
      if (el.__s) { el.__s.vis = e.isIntersecting; if (e.isIntersecting) { el.__s.dirty = true; go() } } }
  }, { rootMargin: '200px' }) : null;
  function scan() { for (const el of document.querySelectorAll('.v3d:not([data-st])')) { el.dataset.st = 'wait'; if (io) io.observe(el); else need3(() => mount(el)) } }
  let pend = 0; const later = () => { if (!pend) { pend = 1; requestAnimationFrame(() => { pend = 0; scan() }) } };
  new MutationObserver(later).observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState !== 'loading') later(); else document.addEventListener('DOMContentLoaded', later);
  window.R3D = { scan, LIVE, need3 };
})();

