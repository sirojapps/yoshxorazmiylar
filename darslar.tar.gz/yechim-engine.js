// ============ ANIMATSIYALI YECHIM PLEYERI (bank misollari uchun) ============
// Yechim fayli (y/<id>.js) beradi: ID, GR (sinf), TOPIC (mavzu nomi), Q (savol), OPTS ([...]), ANS (to'g'ri variant indeksi),
//   BASE() — sahnaning boshlang'ich holati, STEPS:[{h, t, go(fast), calc:[...] }], WHY:[{o:indeks, t:'odatiy xato'}], CHK (tekshirish matni, ixtiyoriy)
// go(fast): fast=true — darhol oxirgi holat (qayta chizish uchun); fast=false — animatsiya (Promise qaytarishi mumkin).
var Y={tok:0,k:0,busy:false,L:'ABCDEF'};
// ---- animatsiya yordamchilari ----
Y.alive=function(t){return t===Y.tok};
Y.anim=function(fast,ms,f){if(fast){f(1);return Promise.resolve()}var t=Y.tok;return tween(ms,function(p){if(Y.alive(t))f(p)})};
Y.pause=function(fast,ms){return fast?Promise.resolve():wait(ms)};
// son nuri: o={a,b,x0,x1,y,tick,lab,minor}
Y.nl=function(o){o=Object.assign({x0:22,x1:338,y:104,tick:1,lab:2,col:'#3a4a5a'},o);var g=S.g;
 o.X=function(v){return o.x0+(v-o.a)*(o.x1-o.x0)/(o.b-o.a)};
 E('line',{x1:o.x0-12,y1:o.y,x2:o.x1+14,y2:o.y,stroke:o.col,'stroke-width':2},g);
 E('path',{d:'M'+(o.x1+16)+' '+o.y+' l-8 -4 v8 z',fill:o.col},g);
 for(var v=o.a;v<=o.b+1e-9;v+=o.tick){var x=o.X(v),big=(Math.round(v-o.a)%o.lab===0)||v%o.lab===0;
  E('line',{x1:x,y1:o.y-(big?6:4),x2:x,y2:o.y+(big?6:4),stroke:o.col,'stroke-width':big?1.6:1.1},g);
  if(v%o.lab===0){o.labs=o.labs||[];var le=T(g,x,o.y+21,String(v),{'font-size':11,fill:'#4a5866'});le._v=v;o.labs.push(le)}}
 return o};
// nuqta harfi bilan
Y.dot=function(n,v,col,name,o){o=o||{};var x=n.X(v),g=E('g',{},o.p||S.fx),hy=o.hy||14;
 if(name&&hy>20)E('line',{x1:x,y1:n.y-7,x2:x,y2:n.y-hy+4,stroke:col||C.blue,'stroke-width':1.2,'stroke-dasharray':'2 2'},g);
 E('circle',{cx:x,cy:n.y,r:6.5,fill:col||C.blue,stroke:'#1d2b3a','stroke-width':1.2},g);
 if(name)T(g,x,n.y-hy,name,{'font-size':14,'font-weight':800,fill:'#1d2b3a'});return g};
// sonni nur ostida ajratib ko'rsatish (aylana ichida)
Y.mark=function(n,v,col){var x=n.X(v),g=E('g',{},S.fx);(n.labs||[]).forEach(function(le){if(le._v!==v&&Math.abs(n.X(le._v)-x)<20)le.setAttribute('opacity',0)});E('rect',{x:x-10,y:n.y+9,width:20,height:16,rx:8,fill:col||C.hi,opacity:.9},g);T(g,x,n.y+21,String(v),{'font-size':11.5,'font-weight':800,fill:'#1d2b3a'});return g};
// chumoli (kichik qo'ng'izcha) belgisi
Y.ant=function(x,y){var g=E('g',{},S.fx);E('ellipse',{cx:0,cy:0,rx:6,ry:4.2,fill:'#3a2a1a'},g);E('circle',{cx:6.5,cy:-1,r:3.2,fill:'#3a2a1a'},g);
 [-3,0,3].forEach(function(d){E('line',{x1:d,y1:2,x2:d-2,y2:7,stroke:'#3a2a1a','stroke-width':1.2},g)});E('line',{x1:8,y1:-3,x2:11,y2:-7,stroke:'#3a2a1a','stroke-width':1},g);
 g.set=function(xx,yy,flip){g.setAttribute('transform','translate('+xx+','+yy+')'+(flip?' scale(-1,1)':''))};g.set(x,y);return g};
// birlik-birlik sakrash: har sakrashda yoy + sanoq soni (hisob ko'rinadi)
Y.hops=async function(n,from,to,o){o=o||{};var fast=o.fast,col=o.col||C.a2,dir=to>from?1:-1,cnt=Math.abs(to-from),y=n.y,lift=o.lift||16,t=Y.tok,grp=E('g',{'class':o.cls||''},S.g),ant=fast?null:Y.ant(n.X(from),y-9);
 for(var i=0;i<cnt;i++){var a=from+i*dir,b=a+dir,xa=n.X(a),xb=n.X(b),mx=(xa+xb)/2;
  E('path',{d:'M'+xa+' '+(y-3)+' Q'+mx+' '+(y-3-lift)+' '+xb+' '+(y-3),fill:'none',stroke:col,'stroke-width':1.6},grp);
  if(o.count!==false)T(grp,mx,y-lift-4,String(i+1),{'font-size':8.5,fill:col,'font-weight':700});
  if(!fast){await tween(o.ms||260,function(p){if(!Y.alive(t))return;var xx=xa+(xb-xa)*p,yy=y-9-Math.sin(p*Math.PI)*lift*.9;ant.set(xx,yy,dir<0)});if(!Y.alive(t))return;
   if(o.onStep)o.onStep(b,i+1)}}
 if(ant)ant.remove();if(o.onStep&&fast)o.onStep(to,cnt)};
// bitta katta sakrash yorlig'i bilan
Y.jump=async function(n,from,to,label,o){o=o||{};var col=o.col||C.blue,xa=n.X(from),xb=n.X(to),up=o.up!==false,y=n.y+(up?-3:3),h=(o.h||26)*(up?-1:1),mx=(xa+xb)/2,g=E('g',{},S.g),
 p=E('path',{d:'M'+xa+' '+y+' Q'+mx+' '+(y+h*1.3)+' '+xb+' '+y,fill:'none',stroke:col,'stroke-width':2.2,'stroke-linecap':'round'},g),L=p.getTotalLength();
 p.setAttribute('stroke-dasharray',L);p.setAttribute('stroke-dashoffset',L);
 await Y.anim(o.fast,o.ms||650,function(q){p.setAttribute('stroke-dashoffset',L*(1-q))});
 E('path',{d:'M'+xb+' '+y+' l'+(to>from?-6:6)+' '+(up?-5:5)+' M'+xb+' '+y+' l'+(to>from?-7:7)+' '+(up?1:-1),stroke:col,'stroke-width':2,fill:'none'},g);
 if(label){var ly=y+h*0.65+(up?-6:14);E('rect',{x:mx-String(label).length*3.6-5,y:ly-11,width:String(label).length*7.2+10,height:15,rx:7,fill:'#fff',stroke:col,'stroke-width':1},g);T(g,mx,ly,label,{'font-size':11,'font-weight':800,fill:col})}
 return g};
// chiziqli (bar) model bo'lagi
Y.bar=function(x,y,w,h,col,label,o){o=o||{};var g=E('g',{},S.g);E('rect',{x:x,y:y,width:w,height:h,rx:4,fill:col,stroke:o.dash?'#8a96a3':'rgba(0,0,0,.25)','stroke-width':o.dash?1.4:1,'stroke-dasharray':o.dash?'4 3':''},g);
 if(label!=null)T(g,x+w/2,y+h/2+4.5,String(label),{'font-size':o.fs||13,'font-weight':800,fill:o.tc||'#1d2b3a'});return g};
Y.grow=function(el,fast){el.style.transformBox='fill-box';el.style.transformOrigin='left center';return Y.anim(fast,550,function(p){el.style.transform='scaleX('+p+')'})};
Y.fade=function(el,fast,ms){return Y.anim(fast,ms||400,function(p){el.setAttribute('opacity',p)})};
// ---- pleyer ----
(function(){
 var notes=document.getElementById('notes'),ttl=document.getElementById('ttl');
 ttl.textContent=(window.GR||2)+'-sinf · '+(window.TOPIC||'Yechim');document.title='Yechim · '+ID;
 var q=document.createElement('div');q.className='st yq';
 q.innerHTML='<div class="bd" style="padding-top:12px"><div class="ytag">Misol</div><div class="q"><div class="t">'+Q+'</div><div class="opts">'+OPTS.map(function(o,i){return '<button disabled data-i="'+i+'"><b>'+Y.L[i]+')</b> '+o+'</button>'}).join('')+'</div></div></div>';
 notes.appendChild(q);
 var list=document.createElement('div');notes.appendChild(list);
 var nb=document.createElement('button');nb.className='ynext';nb.textContent='▶ Yechimni boshlash';notes.appendChild(nb);
 var cards=[];
 async function rebuild(k){var t=++Y.tok;clear();BASE();for(var j=0;j<k;j++){await STEPS[j].go(true);if(!Y.alive(t))return}var c=null;for(var j2=k-1;j2>=0;j2--)if(STEPS[j2].calc){c=STEPS[j2].calc;break}
  if(c)calc(c);else strip.innerHTML=window.STRIP0||''}
 function mark(j){cards.forEach(function(c,i){c.classList.toggle('view',i===j)})}
 async function play(k){var s=STEPS[k];Y.busy=true;nb.disabled=true;await rebuild(k);mark(k);var t=Y.tok;
  try{await s.go(false)}catch(e){console.error(e)}
  if(!Y.alive(t))return;if(s.calc)calc(s.calc);Y.busy=false;nb.disabled=false}
 function addCard(k){var s=STEPS[k],d=document.createElement('div');d.className='st ystep reveal';
  d.innerHTML='<div class="hd"><div class="num">'+(k+1)+'</div><div class="ttl">'+s.h+'</div><span class="yre" title="Qayta ko‘rish">↻</span></div><div class="bd">'+s.t+'</div>';
  d.querySelector('.hd').onclick=function(){if(Y.busy)return;play(k).then(function(){if(Y.k<STEPS.length)nb.textContent='▶ Keyingi qadam ('+(Y.k+1)+'-qadam, jami '+STEPS.length+')'})};
  list.appendChild(d);cards.push(d);return d}
 async function finish(){Y.busy=true;await rebuild(STEPS.length);Y.busy=false;mark(-1);
  q.querySelectorAll('.opts button').forEach(function(b){if(+b.dataset.i===ANS)b.classList.add('ok')});
  var d=document.createElement('div');d.className='st yans reveal';
  d.innerHTML='<div class="bd" style="padding-top:12px"><div class="yres">✅ Javob: <b>'+OPTS[ANS]+'</b> ('+Y.L[ANS]+')</div>'+(window.CHK?'<p class="ychk">🔎 <b>Tekshiramiz:</b> '+window.CHK+'</p>':'')+
   (window.WHY&&WHY.length?'<div class="ywhy"><div class="yw-h">Nega boshqa javoblar xato?</div>'+WHY.map(function(w){return '<div class="yw"><span class="yl">'+Y.L[w.o]+') '+OPTS[w.o]+'</span> '+w.t+'</div>'}).join('')+'</div>':'')+
   '<div class="yend"><button onclick="location.reload()">↻ Boshidan</button><a href="yechim-namuna.html">☰ Boshqa misollar</a></div></div>';
  list.appendChild(d);nb.style.display='none';setTimeout(function(){d.scrollIntoView({behavior:'smooth',block:'nearest'})},60)}
 nb.onclick=function(){if(Y.busy)return;if(Y.k>=STEPS.length){finish();return}
  var k=Y.k++,c=addCard(k);play(k).then(function(){nb.textContent=Y.k<STEPS.length?'▶ Keyingi qadam ('+(Y.k+1)+'-qadam, jami '+STEPS.length+')':'✅ Javobni ko‘rish'});
  setTimeout(function(){c.scrollIntoView({behavior:'smooth',block:'nearest'})},60)};
 rebuild(0);
})();
// ---- kasrlarni ustma-ust ko'rsatish (dars dvigatelidagi qoida) ----
var FR_RE=/(^|[^\d\/\w])(\d{1,3})\/(\d{1,3})(?![\d\/])/;
function frNode(t){var m=FR_RE.exec(t.nodeValue);if(!m)return;var i=m.index+m[1].length,after=t.splitText(i);after.nodeValue=after.nodeValue.slice(m[2].length+1+m[3].length);
 var s=document.createElement('span');s.className='frc';s.innerHTML='<span>'+m[2]+'</span><span>'+m[3]+'</span>';t.parentNode.insertBefore(s,after);frNode(after)}
function frWalk(root){if(!root||root.nodeType!==1&&root.nodeType!==3)return;if(root.nodeType===3){if(FR_RE.test(root.nodeValue))frNode(root);return}
 var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:function(n){for(var p=n.parentNode;p&&p!==root.parentNode;p=p.parentNode){if(p.nodeName==='svg'||p.nodeName==='text'||(p.classList&&(p.classList.contains('frc')||p.classList.contains('nofr'))))return NodeFilter.FILTER_REJECT}return FR_RE.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}}),l=[];while(w.nextNode())l.push(w.currentNode);l.forEach(frNode)}
(function(){var busy=false,ob=new MutationObserver(function(ms){if(busy)return;busy=true;try{ms.forEach(function(m){if(m.type==='characterData')frWalk(m.target);else m.addedNodes.forEach(frWalk)})}finally{busy=false}});
 [document.getElementById('notes'),document.getElementById('strip')].forEach(function(r){if(r){frWalk(r);ob.observe(r,{childList:true,subtree:true,characterData:true})}})})();
