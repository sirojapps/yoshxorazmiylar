var ID=2421,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Kitob 90 sahifadan iborat. Ali birinchi kuni 27 sahifa, ikkinchi kuni 38 sahifa o‘qidi. O‘qish uchun necha sahifa qoldi?";
var OPTS=["25","35","63","52"],ANS=0;
var X0=30,W=300,K=W/90,BY=62,BH=34;
function BASE(){var g=S.g;T(g,180,24,'📖 Kitob — 90 sahifa',{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
var STRIP0="<div class='calc'><div class='nt'>Chizma model: butun kitobni uzun to‘rtburchak qilib chizamiz</div><div class='cl last'>90 = 1-kun + 2-kun + qolgani</div></div>";
var STEPS=[
{h:"Butun kitob — 90 sahifa",
 t:"Kitobni uzun to‘rtburchak (tasma) qilib chizamiz. Butun tasma — <b>90 sahifa</b>. Ali o‘qigan sahifalar tasmaning bir qismini egallaydi, qolgani — biz qidirayotgan son.",
 calc:["Butun tasma = <b>90</b>"],
 go:async function(f){var r=Y.bar(X0,BY,W,BH,'#fff',null,{dash:1});await Y.fade(r,f,400);Br(X0,X0+W,BY-4,'90',true,'#1d2b3a')}},
{h:"1-kun: 27 sahifa",
 t:"Birinchi kuni Ali <b>27</b> sahifa o‘qidi — tasmaning boshidan 27 lik bo‘lakni bo‘yaymiz.",
 calc:["1-kun: <b>27</b>"],
 go:async function(f){var b=Y.bar(X0,BY,27*K,BH,'#ffc98a','27');await Y.grow(b,f);T(S.g,X0+27*K/2,BY+BH+16,'1-kun',{'font-size':11,fill:'#a8601f'})}},
{h:"2-kun: 38 sahifa",
 t:"Ikkinchi kuni yana <b>38</b> sahifa — uni birinchi bo‘lakdan keyin bo‘yaymiz.",
 calc:["1-kun: 27 · 2-kun: <b>38</b>"],
 go:async function(f){var b=Y.bar(X0+27*K,BY,38*K,BH,'#a9d3f5','38');await Y.grow(b,f);T(S.g,X0+27*K+38*K/2,BY+BH+16,'2-kun',{'font-size':11,fill:C.blue})}},
{h:"Jami qancha o‘qidi?",
 t:"Ikki kunda o‘qiganini qo‘shamiz: 27 + 38. O‘nlikdan o‘tamiz: 38 ni <b>3 + 35</b> deb olamiz. 27 + 3 = <b>30</b> (butun o‘nlik), 30 + 35 = <b>65</b>.",
 calc:["27 + 38: 27 + 3 = 30, 30 + 35 = <b>65</b>","O‘qilgan: <b>65</b>"],
 go:async function(f){Br(X0,X0+65*K,BY+BH+22,'65 o‘qildi',false,'#7a3fb0')}},
{h:"Qolgan qismi: 90 − 65",
 t:"Qolgan bo‘lak = butun − o‘qilgan: 90 − 65. Avval 60 ni: 90 − 60 = <b>30</b>, keyin 5 ni: 30 − 5 = <b>25</b>. Demak <b>25 sahifa</b> qoldi.",
 calc:["90 − 60 = 30, 30 − 5 = <b>25</b>","Qoldi: <b>25</b> sahifa"],
 go:async function(f){var b=Y.bar(X0+65*K,BY,25*K,BH,'#bfe8cf','25');await Y.grow(b,f);T(S.g,X0+65*K+25*K/2,BY+BH+16,'qoldi',{'font-size':11,fill:C.ok,'font-weight':700})}}
];
var CHK="27 + 38 + 25 = 90. Uchala bo‘lak birga butun kitobni beradi — to‘g‘ri.";
var WHY=[
 {o:1,t:"27 + 38 ni 55 deb hisoblangan: 7 + 8 = 15 dagi o‘nlik qo‘shilmay qolgan. Shunda 90 − 55 = 35 chiqadi."},
 {o:2,t:"90 − 27 = 63 — bu faqat birinchi kundan keyin qolgan sahifalar. Ikkinchi kun o‘qigani ayirilmagan."},
 {o:3,t:"90 − 38 = 52 — faqat ikkinchi kun ayirilgan, birinchi kun unutilgan."}
];
