var ID=2852,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Kamayuvchi 83, ayriluvchi 47. Ayirmadan yana 9 ni ayirsak, nechchi qoladi?";
var OPTS=["27","36","45","37"],ANS=0;
var N1,EQ;
function BASE(){N1=Y.nl({a:20,b:90,y:130,lab:10,tick:5})}
var STRIP0="<div class='calc'><div class='nt'>Avval atamalarni tushunib olamiz</div><div class='cl last'>kamayuvchi − ayriluvchi = ayirma</div></div>";
var STEPS=[
{h:"Atamalar: kim kim?",
 t:"Ayirishda: <b>kamayuvchi</b> — kamayadigan son (83), <b>ayriluvchi</b> — undan olinadigan son (47), <b>ayirma</b> — natija. Demak avval 83 − 47 ni topamiz.",
 calc:["83 − 47 = ?"],
 go:async function(f){var g=E('g',{},S.fx),xs=[90,150,180,240,285];
  [['83',C.blue],['−','#1d2b3a'],['47',C.a2],['=','#1d2b3a'],['?',C.ok]].forEach(function(p,i){T(g,[95,140,185,230,275][i],34,p[0],{'font-size':22,'font-weight':800,fill:p[1]})});
  [['kamayuvchi',95,C.blue],['ayriluvchi',185,C.a2],['ayirma',275,C.ok]].forEach(function(p){T(g,p[1],54,p[0],{'font-size':11,'font-weight':700,fill:p[2]})});await Y.fade(g,f,600)}},
{h:"Ayirmani topamiz: 83 − 47",
 t:"47 = 40 + 7. 83 − 40 = <b>43</b>. Endi 43 dan 7: 43 da 3 birlik bor, 7 ni <b>3 + 4</b> qilamiz: 43 − 3 = <b>40</b>, 40 − 4 = <b>36</b>. Ayirma = <b>36</b>.",
 calc:["83 − 40 = 43","43 − 3 = 40, 40 − 4 = <b>36</b> (ayirma)"],
 go:async function(f){var d=Y.dot(N1,83,C.blue);Y.mark(N1,83,'#cfe3f7');await Y.fade(d,f,300);await Y.jump(N1,83,43,'−40',{fast:f,h:26,col:C.blue});await Y.jump(N1,43,40,'−3',{fast:f,h:46,col:C.blue});await Y.jump(N1,40,36,'−4',{fast:f,h:26,col:C.blue});Y.mark(N1,36,'#cfe3f7');
  var q=sv.querySelectorAll('text');q.forEach(function(t){if(t.textContent==='?'){t.textContent='36'}})}},
{h:"Ayirmadan yana 9 ni ayiramiz",
 t:"36 − 9: 36 da 6 birlik bor, 9 ni <b>6 + 3</b> qilamiz. 36 − 6 = <b>30</b>, 30 − 3 = <b>27</b>. Demak <b>27</b> qoladi.",
 calc:["9 = 6 + 3","36 − 6 = 30, 30 − 3 = <b>27</b>"],
 go:async function(f){S.g.querySelectorAll('g').forEach(function(g){if(g.querySelector('path'))g.setAttribute('opacity',.2)});
  await Y.jump(N1,36,30,'−6',{fast:f,h:62,col:C.a2});await Y.jump(N1,30,27,'−3',{fast:f,h:40,col:C.a2});var d=Y.dot(N1,27,C.ok);Y.mark(N1,27,'#bfe8cf');await Y.fade(d,f,300)}}
];
var CHK="27 + 9 = 36, 36 + 47 = 83 — kamayuvchiga qaytdik.";
var WHY=[
 {o:1,t:"36 — bu ayirmaning o‘zi. Masalada «yana 9 ni ayirsak» deyilgan — bu qadam unutilgan."},
 {o:2,t:"36 + 9 = 45 — ayirish o‘rniga qo‘shilgan."},
 {o:3,t:"83 − 47 ni 46 deb hisoblangan: o‘nlikdan o‘tganda olingan o‘nlik o‘nliklardan ayirilmay qolgan. 46 − 9 = 37. Tekshiruv: 46 + 47 = 93, 83 emas."}
];
