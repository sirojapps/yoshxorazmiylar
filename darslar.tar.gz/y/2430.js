var ID=2430,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Birinchi son 52 dan 17 ta kam, ikkinchi son 61 dan 28 ta kam. Qaysi biri katta va qanchaga?";
var OPTS=["ikkinchisi 2 ga katta","ular teng","birinchisi 11 ga katta","birinchisi 2 ga katta"],ANS=3;
var X0=62,K=4.4,R1=44,R2=114,BH=28;
function BASE(){var g=S.g;T(g,30,R1+19,'1-son',{'font-size':12,'font-weight':800,fill:'#a8601f'});T(g,30,R2+19,'2-son',{'font-size':12,'font-weight':800,fill:C.blue})}
var STRIP0="<div class='calc'><div class='nt'>«52 dan 17 ta kam» — 52 dan 17 ni olib tashlaymiz</div><div class='cl last'>1-son = 52 − 17 · 2-son = 61 − 28</div></div>";
function cut(x,y,w,lab,f){var g=E('g',{},S.fx);E('rect',{x:x,y:y,width:w,height:BH,rx:4,fill:'#fff',stroke:C.bad,'stroke-width':1.4,'stroke-dasharray':'4 3'},g);
 E('line',{x1:x+3,y1:y+3,x2:x+w-3,y2:y+BH-3,stroke:C.bad,'stroke-width':1.5},g);T(g,x+w/2,y+BH+13,lab,{'font-size':11,fill:C.bad,'font-weight':800});return Y.fade(g,f,450)}
var STEPS=[
{h:"Birinchi son: 52 dan 17 ta kam",
 t:"52 lik tasma chizamiz va oxiridan <b>17</b> ni kesib tashlaymiz. Qolgani — birinchi son.<br>52 − 17: 17 ni <b>12 + 5</b> deb bo‘lamiz. 52 − 12 = <b>40</b> (butun o‘nlik), 40 − 5 = <b>35</b>.",
 calc:["52 − 12 = 40, 40 − 5 = <b>35</b>","1-son = <b>35</b>"],
 go:async function(f){var b=Y.bar(X0,R1,52*K,BH,'#ffc98a','52');await Y.grow(b,f);Br(X0,X0+52*K,R1-3,'52',true,'#a8601f');await cut(X0+35*K,R1,17*K,'−17',f);
  var l=E('g',{},S.fx);E('rect',{x:X0,y:R1,width:35*K,height:BH,rx:4,fill:'#ffb46a'},l);T(l,X0+35*K/2,R1+BH/2+5,'35',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});await Y.fade(l,f,400)}},
{h:"Ikkinchi son: 61 dan 28 ta kam",
 t:"61 lik tasmadan <b>28</b> ni kesamiz. 61 − 28: 28 ni <b>21 + 7</b> deb bo‘lamiz. 61 − 21 = <b>40</b>, 40 − 7 = <b>33</b>.",
 calc:["61 − 21 = 40, 40 − 7 = <b>33</b>","2-son = <b>33</b>"],
 go:async function(f){var b=Y.bar(X0,R2,61*K,BH,'#a9d3f5','61');await Y.grow(b,f);Br(X0,X0+61*K,R2-3,'61',true,C.blue);await cut(X0+33*K,R2,28*K,'−28',f);
  var l=E('g',{},S.fx);E('rect',{x:X0,y:R2,width:33*K,height:BH,rx:4,fill:'#7fbcec'},l);T(l,X0+33*K/2,R2+BH/2+5,'33',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});await Y.fade(l,f,400)}},
{h:"Taqqoslaymiz",
 t:"Endi faqat qolgan bo‘laklarni solishtiramiz: <b>35</b> va <b>33</b>. Birinchi tasma uzunroq — <b>birinchi son katta</b>. Qanchaga? 35 − 33 = <b>2</b>.",
 calc:["35 > 33","35 − 33 = <b>2</b> · birinchisi 2 ga katta"],
 go:async function(f){var g=E('g',{},S.fx);var x=X0+33*K;E('line',{x1:x,y1:R1-6,x2:x,y2:R2+BH+4,stroke:'#7a3fb0','stroke-width':1.6,'stroke-dasharray':'3 3'},g);
  E('rect',{x:x,y:R1-3,width:2*K,height:BH+6,rx:3,fill:'none',stroke:'#7a3fb0','stroke-width':2.2},g);E('rect',{x:x+2*K+4,y:R1+5,width:16,height:18,rx:4,fill:'#fff'},g);T(g,x+2*K+12,R1+BH/2+5,'2',{'font-size':14,'font-weight':800,fill:'#7a3fb0'});await Y.fade(g,f,600)}}
];
var CHK="35 + 17 = 52 va 33 + 28 = 61 — ikkala son ham to‘g‘ri topilgan. 33 + 2 = 35.";
var WHY=[
 {o:0,t:"Farq (2) to‘g‘ri, lekin katta son adashtirilgan. 61 katta bo‘lgani bilan undan ko‘proq (28) ayirildi — natijada ikkinchi son kichik chiqdi."},
 {o:1,t:"35 va 33 — har xil sonlar. Hisoblamasdan taxmin qilingan."},
 {o:2,t:"28 − 17 = 11 — ayirilgan sonlar solishtirilgan. Bizga esa ayirishdan <b>keyin qolgan</b> sonlar kerak."}
];
