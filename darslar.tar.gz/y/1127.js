var ID=1127,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Sonlar nurida K nuqta 26 sonida turibdi. K dan 9 birlik o‘ngda M nuqta, M dan esa 14 birlik chapda N nuqta joylashgan. N nuqta qaysi sonda turibdi?";
var OPTS=["49","21","31","17"],ANS=1;
var N1;
function BASE(){N1=Y.nl({a:18,b:38,y:112,lab:2})}
var STRIP0="<div class='calc'><div class='nt'>Son nuri: chapda kichik sonlar, o‘ngda katta sonlar</div><div class='cl last'>K = 26 · M = ? · N = ?</div></div>";
var STEPS=[
{h:"K nuqtani joyiga qo‘yamiz",
 t:"Masalada aytilgan: <b>K nuqta 26 sonida</b>. Son nurida 26 ni topamiz: 26 — 24 bilan 28 ning o‘rtasida. K ni shu yerga qo‘yamiz.",
 calc:["K = <b>26</b>","M = ? · N = ?"],
 go:async function(f){var m=Y.mark(N1,26);Y.fade(m,f);await Y.pause(f,250);var d=Y.dot(N1,26,C.blue,'K',{hy:46});await Y.fade(d,f,450)}},
{h:"K dan 9 birlik o‘ngga — M nuqta",
 t:"<b>O‘ngga</b> yurganda sonlar <b>kattalashadi</b>. Chumoli 26 dan o‘ngga 9 marta sakraydi, har sakrashni sanaymiz: 27, 28, 29, 30, 31, 32, 33, 34, <b>35</b>.<br>Demak <b>M = 35</b>. Hisob bilan: 26 + 9 = 35 (avval 26 + 4 = 30 — butun o‘nlikka yetamiz, keyin 30 + 5 = 35).",
 calc:["26 + 9: 26 + <b>4</b> = 30, 30 + <b>5</b> = 35","M = <b>35</b>"],
 go:async function(f){await Y.hops(N1,26,35,{fast:f,col:C.blue,lift:16,cls:'h1',onStep:function(v,i){if(!f)calc(["Chumoli sakradi: <b>"+i+"</b> marta","Hozir: <b>"+v+"</b>"])}});
  var m=Y.mark(N1,35,'#bfe8cf');Y.fade(m,f);var d=Y.dot(N1,35,C.ok,'M',{hy:46});await Y.fade(d,f,450)}},
{h:"M dan 14 birlik chapga — N nuqta",
 t:"Endi <b>chapga</b> yuramiz — chapga yurganda sonlar <b>kichrayadi</b>. 35 dan 14 marta orqaga sakraymiz: 34, 33, 32, … , <b>21</b>.<br>Demak <b>N = 21</b>. Hisob bilan: 35 − 14: avval o‘nlikni ayiramiz 35 − 10 = 25, keyin birliklarni 25 − 4 = 21.",
 calc:["35 − 14: 35 − <b>10</b> = 25, 25 − <b>4</b> = 21","N = <b>21</b>"],
 go:async function(f){var o=sv.querySelector('.h1');if(o)Y.anim(f,300,function(p){o.setAttribute('opacity',1-.75*p)});
  await Y.hops(N1,35,21,{fast:f,col:C.bad,lift:30,ms:200,cls:'h2',onStep:function(v,i){if(!f)calc(["Orqaga sakradi: <b>"+i+"</b> marta","Hozir: <b>"+v+"</b>"])}});
  var m=Y.mark(N1,21,'#f6c7c7');Y.fade(m,f);var d=Y.dot(N1,21,C.bad,'N',{hy:46});await Y.fade(d,f,450)}},
{h:"Qisqa yo‘l: K dan N gacha",
 t:"Chumoli o‘ngga 9 yurdi, keyin chapga 14 yurdi. Chapga 14 − 9 = <b>5</b> ta ko‘proq yurdi. Demak N nuqta K dan <b>5 birlik chapda</b>: 26 − 5 = <b>21</b>. Javob ikki yo‘l bilan ham bir xil chiqdi.",
 calc:["14 − 9 = 5 (chapga ko‘proq)","26 − 5 = <b>21</b> ✓"],
 go:async function(f){['.h1','.h2'].forEach(function(c){var o=sv.querySelector(c);if(o)o.setAttribute('opacity',.18)});
  await Y.jump(N1,26,21,'−5',{fast:f,col:'#7a3fb0',up:true,h:44})}}
];
var CHK="21 dan o‘ngga 14 yursak: 21 + 14 = 35 (M). 35 dan chapga 9 yursak: 35 − 9 = 26 (K). Hammasi to‘g‘ri.";
var WHY=[
 {o:0,t:"35 + 14 = 49 — chapga yurganda ham qo‘shib yuborilgan. Chapga yurganda son kamayadi."},
 {o:2,t:"26 + 5 = 31 — farq 5 to‘g‘ri topilgan, lekin N o‘ngga qo‘yilgan. N chapda, chunki chapga ko‘proq yurildi."},
 {o:3,t:"26 − 9 = 17 — M ham chapga qo‘yilgan va ikkinchi yurish (14 birlik) unutilgan."}
];
