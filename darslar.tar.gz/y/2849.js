var ID=2849,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Hisoblang: 91 − 46";
var OPTS=["55","35","47","45"],ANS=3;
var N1;
function BASE(){N1=Y.nl({a:40,b:95,y:118,lab:10,tick:1});T(S.fx,180,24,'91 − 46',{'font-size':16,'font-weight':800,fill:'#1d2b3a'})}
var STRIP0="<div class='calc'><div class='nt'>91 dan 46 ta orqaga yuramiz — lekin bittalab emas, katta sakrashlar bilan</div><div class='cl last'>46 = 40 + 6</div></div>";
var STEPS=[
{h:"46 ni bo‘laklarga ajratamiz",
 t:"46 = <b>4 ta o‘nlik</b> va <b>6 ta birlik</b>: 46 = 40 + 6. Avval o‘nliklarni, keyin birliklarni ayiramiz. Son nurida 91 dan boshlaymiz.",
 calc:["46 = 40 + 6"],
 go:async function(f){var d=Y.dot(N1,91,C.blue);Y.mark(N1,91,'#cfe3f7');await Y.fade(d,f,400)}},
{h:"O‘nliklarni ayiramiz: −40",
 t:"91 dan 10 talab 4 marta orqaga sakraymiz: 81, 71, 61, <b>51</b>. Har sakrashda faqat o‘nliklar raqami kamayadi, birlik (1) o‘zgarmaydi.",
 calc:["91 − 40 = <b>51</b>","81 → 71 → 61 → 51"],
 go:async function(f){var v=91;for(var i=0;i<4;i++){await Y.jump(N1,v,v-10,'−10',{fast:f,h:28,col:C.blue,ms:420});v-=10}Y.mark(N1,51,'#cfe3f7')}},
{h:"Birliklar: o‘nlikdan o‘tib −6",
 t:"Endi 51 dan 6 ni ayirish kerak. 51 da faqat <b>1</b> ta birlik bor — 6 tasini birdan ayira olmaymiz. 6 ni <b>1 + 5</b> deb bo‘lamiz.<br>Avval 1 ni: 51 − 1 = <b>50</b> (butun o‘nlik). Keyin 5 ni: 50 − 5 = <b>45</b>.",
 calc:["6 = 1 + 5","51 − 1 = 50, 50 − 5 = <b>45</b>"],
 go:async function(f){var gs=S.g.querySelectorAll('g');gs.forEach(function(g){if(g.querySelector('path'))g.setAttribute('opacity',.3)});
  await Y.jump(N1,51,50,'−1',{fast:f,h:62,col:C.a2});await Y.jump(N1,50,45,'−5',{fast:f,h:36,col:C.a2});var d=Y.dot(N1,45,C.ok);Y.mark(N1,45,'#bfe8cf');await Y.fade(d,f,300)}}
];
var CHK="45 + 46 = 91. Qo‘shganda boshlagan sonimiz chiqdi — to‘g‘ri.";
var WHY=[
 {o:0,t:"Birliklarda 1 − 6 o‘rniga 6 − 1 = 5 olingan (kattasidan kichigi). O‘nlikdan o‘tish kerak edi. Tekshiruv: 55 + 46 = 101, 91 emas."},
 {o:1,t:"Bitta o‘nlik ortiqcha ayirilgan. Tekshiruv: 35 + 46 = 81, 91 emas."},
 {o:2,t:"Birliklarda adashilgan. Tekshiruv: 47 + 46 = 93, 91 emas."}
];
