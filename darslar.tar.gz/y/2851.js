var ID=2851,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Hisoblang: 100 − 37 − 28";
var OPTS=["91","35","45","25"],ANS=1;
var N1;
function BASE(){N1=Y.nl({a:30,b:100,y:100,lab:10,tick:5});T(S.fx,180,22,'100 − 37 − 28',{'font-size':16,'font-weight':800,fill:'#1d2b3a'})}
var STRIP0="<div class='calc'><div class='nt'>Qavs yo‘q, faqat ayirish — chapdan o‘ngga, birin-ketin</div><div class='cl last'>Avval 100 − 37, keyin natijadan 28</div></div>";
var STEPS=[
{h:"Avval 100 − 37",
 t:"Chapdan o‘ngga ishlaymiz. 37 = 30 + 7. 100 dan 30 orqaga: <b>70</b>. 70 dan 7: 70 − 7 = <b>63</b> (70 — butun o‘nlik, undan 7 ni olsak, 6 ta o‘nlik va 3 birlik qoladi).",
 calc:["100 − 30 = 70, 70 − 7 = <b>63</b>"],
 go:async function(f){var d=Y.dot(N1,100,C.blue);Y.mark(N1,100,'#cfe3f7');await Y.fade(d,f,300);await Y.jump(N1,100,70,'−30',{fast:f,h:30,col:C.blue});await Y.jump(N1,70,63,'−7',{fast:f,h:30,col:C.blue});Y.mark(N1,63,'#cfe3f7')}},
{h:"Endi 63 − 28 (o‘nlikdan o‘tib)",
 t:"28 = 20 + 8. Avval 63 − 20 = <b>43</b>. Endi 43 dan 8: 43 da faqat 3 birlik bor, shuning uchun 8 ni <b>3 + 5</b> qilamiz: 43 − 3 = <b>40</b>, 40 − 5 = <b>35</b>.",
 calc:["63 − 20 = 43","8 = 3 + 5: 43 − 3 = 40, 40 − 5 = <b>35</b>"],
 go:async function(f){S.g.querySelectorAll('g').forEach(function(g){if(g.querySelector('path'))g.setAttribute('opacity',.25)});
  await Y.jump(N1,63,43,'−20',{fast:f,h:62,col:C.a2});await Y.jump(N1,43,40,'−3',{fast:f,h:62,col:C.a2});await Y.jump(N1,40,35,'−5',{fast:f,h:40,col:C.a2});var d=Y.dot(N1,35,C.ok);Y.mark(N1,35,'#bfe8cf');await Y.fade(d,f,300)}},
{h:"Boshqa yo‘l: ikkalasini birga ayiramiz",
 t:"100 dan avval 37, keyin 28 ni olish — bu birdaniga <b>37 + 28</b> ni olish bilan bir xil. 37 + 28: 37 + 3 = 40, 40 + 25 = <b>65</b>. 100 − 65 = <b>35</b>. Javob yana 35!",
 calc:["37 + 28 = 65","100 − 65 = <b>35</b> ✓"],
 go:async function(f){S.g.querySelectorAll('g').forEach(function(g){if(g.querySelector('path'))g.setAttribute('opacity',.15)});(N1.labs||[]).forEach(function(l){if(l._v===40)l.setAttribute('opacity',0)});await Y.jump(N1,100,35,'−65',{fast:f,up:false,h:65,col:'#7a3fb0',ms:900})}}
];
var CHK="35 + 28 = 63, 63 + 37 = 100. Hammasi joyiga tushdi.";
var WHY=[
 {o:0,t:"63 + 28 = 91 — ikkinchi ayirish o‘rniga qo‘shib yuborilgan. Misolda ikkala amal ham ayirish."},
 {o:2,t:"63 − 28 da birliklarda 8 − 3 = 5 olingan (kattasidan kichigi) va o‘nlikdan o‘tilmagan: 45. Tekshiruv: 45 + 28 = 73, 63 emas."},
 {o:3,t:"100 − 37 ni 53 deb xato hisoblangan, keyin 53 − 28 = 25. Tekshiruv: 25 + 28 + 37 = 90, 100 emas."}
];
