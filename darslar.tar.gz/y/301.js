var ID=301,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Son o‘qida L va P nuqtalar orasidagi masofani toping.";
var OPTS=["26","15","17","16"],ANS=3;
var N1,PTS=[[4,'#2f6fd0','K'],[5,'#f08a1c','L'],[9,'#2f9e4f','M'],[15,'#dc3c3c','N'],[21,'#ffd23f','P']];
function BASE(){N1=Y.nl({a:0,b:24,y:104,lab:2});PTS.forEach(function(p){Y.dot(N1,p[0],p[1],p[2],{hy:p[2]==='L'?44:28})})}
var STRIP0="<div class='calc'><div class='nt'>Rasm — darslikdagidek. Har kichik chiziqcha — 1 birlik.</div><div class='cl last'>L = ? · P = ?</div></div>";
var STEPS=[
{h:"Son o‘qini o‘qiymiz",
 t:"Ostida faqat <b>juft</b> sonlar yozilgan: 0, 2, 4, 6 … Ikki yozuv orasida yana <b>bitta chiziqcha</b> bor — u yozilmagan toq son. Masalan, 4 bilan 6 orasidagi chiziqcha — <b>5</b>.",
 calc:["4 va 6 orasida — 5","20 va 22 orasida — 21"],
 go:async function(f){var g=E('g',{},S.fx);[5,21].forEach(function(v){var x=N1.X(v);E('path',{d:'M'+x+' '+(N1.y+30)+' l0 -10 m-3 4 l3 -4 l3 4',stroke:C.bad,'stroke-width':1.6,fill:'none'},g);T(g,x,N1.y+44,v+'?',{'font-size':11,fill:C.bad,'font-weight':800})});await Y.fade(g,f,500)}},
{h:"L va P qaysi sonlarda?",
 t:"<b>L</b> (to‘q sariq) — 4 dan keyingi chiziqchada, ya’ni <b>5</b> da.<br><b>P</b> (sariq) — 20 dan keyingi chiziqchada, ya’ni <b>21</b> da.",
 calc:["L = <b>5</b>","P = <b>21</b>"],
 go:async function(f){var a=Y.mark(N1,5,'#ffd9b0');await Y.fade(a,f,400);var b=Y.mark(N1,21,'#fff0a8');await Y.fade(b,f,400)}},
{h:"Masofa — nechta sakrash?",
 t:"Masofa — L dan P gacha <b>nechta birlik</b> yurish kerakligi. Chumoli L (5) dan P (21) gacha bir birlikdan sakraydi, sakrashlarni sanaymiz: 1, 2, 3, … <b>16</b>.",
 calc:["5 dan 21 gacha: <b>16</b> sakrash"],
 go:async function(f){await Y.hops(N1,5,21,{fast:f,col:'#7a3fb0',lift:13,ms:190,cls:'h1',onStep:function(v,i){if(!f)calc(["Sakrashlar: <b>"+i+"</b>","Chumoli hozir: "+v])}})}},
{h:"Tezroq yo‘l: ayirish",
 t:"Sanamasdan ham topsa bo‘ladi: <b>kattasidan kichigini ayiramiz</b>. 21 − 5 = 16.<br>Bo‘laklab tekshiramiz: 5 dan 15 gacha — <b>10</b>, 15 dan 21 gacha — <b>6</b>. 10 + 6 = <b>16</b>.",
 calc:["21 − 5 = <b>16</b>","5 → 15: 10, 15 → 21: 6 · 10 + 6 = 16"],
 go:async function(f){var o=sv.querySelector('.h1');if(o)o.setAttribute('opacity',.2);await Y.jump(N1,5,15,'+10',{fast:f,col:C.blue,h:82});await Y.jump(N1,15,21,'+6',{fast:f,col:C.ok,h:60})}}
];
var CHK="L dan o‘ngga 16 yursak: 5 + 16 = 21 — aynan P ga tushamiz.";
var WHY=[
 {o:0,t:"21 + 5 = 26 — sonlar qo‘shib yuborilgan. Masofa uchun kattasidan kichigini <b>ayiramiz</b>."},
 {o:1,t:"L va P <b>orasidagi chiziqchalar</b> sanalgan (6 dan 20 gacha — 15 ta). Masofa esa chiziqchalar emas, <b>sakrashlar</b> soni."},
 {o:2,t:"L va P ning o‘zi ham qo‘shib sanalgan (5 dan 21 gacha hammasi — 17 ta chiziqcha). Sakrashlar 1 ta kam bo‘ladi."}
];
