var ID=2850,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Qaysi ayirmaning qiymati eng kichik?";
var OPTS=["64 − 27","53 − 18","72 − 38","81 − 45"],ANS=2;
// har qator: kamayuvchi, ayriluvchi, to'ldirib sanash bo'laklari
var RW=[[64,27,[[27,30,'+3'],[30,60,'+30'],[60,64,'+4']],37],[53,18,[[18,20,'+2'],[20,50,'+30'],[50,53,'+3']],35],[72,38,[[38,40,'+2'],[40,70,'+30'],[70,72,'+2']],34],[81,45,[[45,50,'+5'],[50,80,'+30'],[80,81,'+1']],36]];
var RY=[34,74,113,151],LX0=104,LX1=300;
// bo'sh son o'qi (masshtabsiz): 4 ta nuqta qat'iy joylarda
var PX=[110,150,262,300];function rowX(r,v){var pts=[r[1],r[2][0][1],r[2][1][1],r[0]],i=pts.indexOf(v);return i<0?LX0:PX[i]}
function BASE(){var g=S.g;RW.forEach(function(r,i){var y=RY[i];T(g,10,y+4,'ABCD'[i]+')  '+r[0]+' − '+r[1],{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 E('line',{x1:LX0-6,y1:y,x2:LX1+6,y2:y,stroke:'#8a96a3','stroke-width':1.5},g)})}
var STRIP0="<div class='calc'><div class='nt'>To‘rtta ayirmani hisoblab, keyin solishtiramiz</div><div class='cl last'>Usul: kichik sondan kattasigacha «to‘ldirib sanaymiz»</div></div>";
async function rowGo(i,f){var r=RW[i],y=RY[i],g=E('g',{},S.g);
 [r[1],r[0]].forEach(function(v){var x=rowX(r,v);E('line',{x1:x,y1:y-5,x2:x,y2:y+5,stroke:'#1d2b3a','stroke-width':1.6},g);T(g,x,y+14,String(v),{'font-size':10,'font-weight':700,fill:'#3a4a5a'})});
 for(var k=0;k<r[2].length;k++){var p=r[2][k],xa=rowX(r,p[0]),xb=rowX(r,p[1]),mx=(xa+xb)/2,h=k===1?9:7,a=E('path',{d:'M'+xa+' '+(y-2)+' Q'+mx+' '+(y-2-h*1.6)+' '+xb+' '+(y-2),fill:'none',stroke:k===1?C.blue:C.a2,'stroke-width':1.8},g),L=a.getTotalLength();
  a.setAttribute('stroke-dasharray',L);a.setAttribute('stroke-dashoffset',L);await Y.anim(f,380,function(q){a.setAttribute('stroke-dashoffset',L*(1-q))});
  T(g,mx,y-15,p[2],{'font-size':9.5,'font-weight':800,fill:k===1?C.blue:C.a2});if(k<2)T(g,xb,y+14,String(p[1]),{'font-size':9,fill:'#8a96a3'})}
 var rg=E('g',{},S.fx);E('rect',{x:316,y:y-11,width:36,height:20,rx:10,fill:'#fff',stroke:'#1d2b3a','stroke-width':1.2},rg);T(rg,334,y+4,'= '+r[3],{'font-size':11.5,'font-weight':800,fill:'#1d2b3a'});await Y.fade(rg,f,300)}
function rowStep(i){var r=RW[i],p=r[2],s=p.map(function(q){return q[2].slice(1)});
 return {h:'ABCD'[i]+') '+r[0]+' − '+r[1],
  t:"Ayirmani topish uchun <b>"+r[1]+" dan "+r[0]+" gacha</b> qancha qo‘shish kerakligini sanaymiz: avval butun o‘nlikkacha "+p[0][0]+" → "+p[0][1]+" (<b>"+s[0]+"</b>), keyin o‘nliklar bilan "+p[1][0]+" → "+p[1][1]+" (<b>"+s[1]+"</b>), oxiri "+p[2][0]+" → "+p[2][1]+" (<b>"+s[2]+"</b>). Jami: "+s.join(' + ')+" = <b>"+r[3]+"</b>.",
  calc:[r[0]+" − "+r[1]+" = "+s.join(' + ')+" = <b>"+r[3]+"</b>"],
  go:function(f){return rowGo(i,f)}}}
var STEPS=[rowStep(0),rowStep(1),rowStep(2),rowStep(3),
{h:"Solishtiramiz",
 t:"Natijalar: A — 37, B — 35, C — <b>34</b>, D — 36. Kichikdan kattaga tartiblaymiz: <b>34</b> &lt; 35 &lt; 36 &lt; 37. Eng kichigi — <b>34</b>, u <b>C) 72 − 38</b> da.",
 calc:["34 < 35 < 36 < 37","Eng kichik: <b>72 − 38 = 34</b>"],
 go:async function(f){var g=E('g',{});S.g.insertBefore(g,S.g.firstChild);E('rect',{x:4,y:RY[2]-22,width:352,height:39,rx:9,fill:'#d9f2e2',stroke:C.ok,'stroke-width':1.2},g);await Y.fade(g,f,500)}}];
var CHK="72 − 38 = 34, chunki 34 + 38 = 72. Boshqalari: 37 + 27 = 64, 35 + 18 = 53, 36 + 45 = 81.";
var WHY=[
 {o:0,t:"64 − 27 = 37 — to‘rttasining ichida eng kattasi."},
 {o:1,t:"53 − 18 da sonlarning o‘zi eng kichik, shuning uchun ayirma ham kichik ko‘rinadi. Lekin 53 − 18 = 35, bu 34 dan katta. Sonlarga qarab emas, ayirmaga qarab solishtirish kerak."},
 {o:3,t:"81 − 45 = 36 — 34 dan 2 ta katta."}
];
