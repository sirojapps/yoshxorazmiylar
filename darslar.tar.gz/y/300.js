var ID=300,GR=2,TOPIC="O‘nlikdan o‘tib ayirish";
var Q="Hisoblang: (45 − 28) + 19";
var OPTS=["17","26","36","46"],ANS=2;
var N1;
function BASE(){N1=Y.nl({a:10,b:50,y:116,lab:5,tick:1});var g=E('g',{},S.fx);T(g,180,24,'(45 − 28) + 19',{'font-size':15,'font-weight':800,fill:'#1d2b3a'})}
var STRIP0="<div class='calc'><div class='nt'>Qavs bor — avval qavs ichidagi amal bajariladi</div><div class='cl last'>(45 − 28) = ? · keyin + 19</div></div>";
var STEPS=[
{h:"Avval qavs ichi: 45 dan 20 ni ayiramiz",
 t:"Qavs bor — <b>avval qavs ichini</b> hisoblaymiz: 45 − 28. 28 ni ikki bo‘lakka ajratamiz: <b>28 = 20 + 8</b>. Avval o‘nliklarni ayiramiz: 45 dan ikki marta 10 orqaga: 35, <b>25</b>.",
 calc:["28 = 20 + 8","45 − 20 = <b>25</b>"],
 go:async function(f){var d=Y.dot(N1,45,C.blue);Y.mark(N1,45,'#cfe3f7');await Y.fade(d,f,300);await Y.jump(N1,45,35,'−10',{fast:f,h:30,col:C.blue});await Y.jump(N1,35,25,'−10',{fast:f,h:30,col:C.blue});Y.mark(N1,25,'#cfe3f7')}},
{h:"O‘nlikdan o‘tib: 25 − 8",
 t:"Endi 25 dan 8 ni ayirish kerak. 25 da faqat 5 ta birlik bor — 8 tasini birdan ayira olmaymiz. Shuning uchun 8 ni bo‘lamiz: <b>8 = 5 + 3</b>.<br>Avval 5 ni ayirib, butun o‘nlikka tushamiz: 25 − 5 = <b>20</b>. Keyin qolgan 3 ni: 20 − 3 = <b>17</b>. Qavs ichi = 17.",
 calc:["8 = 5 + 3","25 − 5 = 20, 20 − 3 = <b>17</b>","(45 − 28) = <b>17</b>"],
 go:async function(f){await Y.jump(N1,25,20,'−5',{fast:f,h:30,col:C.a2});await Y.jump(N1,20,17,'−3',{fast:f,h:30,col:C.a2});var m=Y.mark(N1,17,'#ffd9b0');await Y.fade(m,f,300)}},
{h:"Endi 17 ga 19 ni qo‘shamiz",
 t:"19 ni ham bo‘laklaymiz: <b>19 = 3 + 16</b> — avval butun o‘nlikka yetamiz: 17 + 3 = <b>20</b>. Keyin 20 + 10 = 30, 30 + 6 = <b>36</b>.",
 calc:["19 = 3 + 10 + 6","17 + 3 = 20, 20 + 10 = 30, 30 + 6 = <b>36</b>"],
 go:async function(f){var gs=S.g.querySelectorAll('g');gs.forEach(function(g){if(g.querySelector('path'))g.setAttribute('opacity',.15)});
  await Y.jump(N1,17,20,'+3',{fast:f,h:70,col:C.ok});await Y.jump(N1,20,30,'+10',{fast:f,h:70,col:C.ok});await Y.jump(N1,30,36,'+6',{fast:f,h:70,col:C.ok});
  var d=Y.dot(N1,36,C.ok);Y.mark(N1,36,'#bfe8cf');await Y.fade(d,f,300)}}
];
var CHK="36 − 19 = 17, 17 + 28 = 45. Boshlagan sonimizga qaytdik — to‘g‘ri.";
var WHY=[
 {o:0,t:"17 — bu faqat qavs ichidagi natija. 19 ni qo‘shish unutilgan."},
 {o:1,t:"17 + 9 = 26 — 19 ning faqat birliklari (9) qo‘shilgan, o‘nligi (10) unutilgan."},
 {o:3,t:"Tekshirib ko‘ramiz: 46 − 19 = 27, qavs ichi esa 17 edi. Demak qo‘shishda bitta o‘nlik ortiqcha qo‘shilgan."}
];
