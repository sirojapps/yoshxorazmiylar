// ============ UMUMIY SAHNA KUTUBXONASI (yangi mavzular uchun) ============
function pad(n){return n<10?'0'+n:''+n}
function rnd(s){return function(){s=(s*16807)%2147483647;return (s-1)/2147483646}}
var NS='http://www.w3.org/2000/svg',sv=document.getElementById('sv'),strip=document.getElementById('strip');
function E(t,a,p){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
function T(p,x,y,txt,a){a=a||{};var m_=/^(\d{1,3})\/(\d{1,3})$/.exec(String(txt));if(m_&&!a.nofr){var fs=+(a['font-size']||12)*.8,g_=E('g',{},p),aa=Object.assign({},a,{'font-size':fs});delete aa.nofr;var n_=E('text',Object.assign({x:x,y:y-fs*.45,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);n_.textContent=m_[1];var d_=E('text',Object.assign({x:x,y:y+fs*.75,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);d_.textContent=m_[2];var w_=Math.max(m_[1].length,m_[2].length)*fs*.62+4,ax=(a['text-anchor']==='start')?x+w_/2-2:((a['text-anchor']==='end')?x-w_/2+2:x);n_.setAttribute('x',ax);d_.setAttribute('x',ax);E('line',{x1:ax-w_/2,y1:y-fs*.18,x2:ax+w_/2,y2:y-fs*.18,stroke:aa.fill||'#3a4a5a','stroke-width':Math.max(1.2,fs/9)},g_);g_.textContent;return g_}var e=E('text',Object.assign({x:x,y:y,'text-anchor':'middle','font-size':12,fill:'#3a4a5a','font-weight':600},a),p);e.textContent=txt;return e}
function tween(ms,f){return new Promise(function(res){var t0=performance.now();function s(n){var t=Math.min(1,(n-t0)/ms);f(t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2);if(t<1)requestAnimationFrame(s);else res()}requestAnimationFrame(s)})}
function wait(ms){return new Promise(function(r){setTimeout(r,ms)})}
var C={a:'#f0a040',a2:'#e07a2f',b:'#5aa9e6',c:'#f08aa8',x:'#e9e2d6',off:'#fff7ea',line:'#8a5a24',bad:'#d94b4b',ok:'#1e8e5a',blue:'#1f6fb2',grey:'#cfd6de',t1:'#a8601f',t2:'#e8a55d',u:'#12a39f',hi:'#ffd24d'};
var S={tok:0};
function clear(bg){S.tok++;sv.innerHTML='';E('rect',{x:2,y:2,width:356,height:170,rx:14,fill:bg||'#fffaf2',stroke:'#f0e4cc'},sv);S.g=E('g',{},sv);S.fx=E('g',{},sv)}
function Br(x1,x2,y,label,up,col){var g=S.g,d=up?-1:1,m=(x1+x2)/2;col=col||C.blue;
 E('path',{d:'M'+x1+' '+y+' q0 '+(6*d)+' 6 '+(6*d)+' L'+(m-6)+' '+(y+6*d)+' q6 0 6 '+(6*d)+' q0 '+(-6*d)+' 6 '+(-6*d)+' L'+(x2-6)+' '+(y+6*d)+' q6 0 6 '+(-6*d),fill:'none',stroke:col,'stroke-width':1.8},g);
 if(label)T(g,m,up?y-16:y+26,label,{'font-size':13,'font-weight':800,fill:col})}
function calc(lines,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+lines.map(function(l,i){return '<div class="cl'+(i===lines.length-1?' last':'')+'">'+l+'</div>'}).join('')+'</div>'}
function phaser(phases,label){return [label||'▶ Keyingi harakat',function(c,done,b){if(S.ph==null)S.ph=0;S.ph++;if(S.ph<phases.length){phases[S.ph]();if(S.ph===phases.length-1){b.disabled=true;b.textContent='✓ Tayyor';done()}else b.textContent=(label||'▶ Keyingi harakat')+' ('+(S.ph+1)+'/'+phases.length+')'}}]}
function startPh(phases){S.ph=0;phases[0]()}
function mvK(done,need){var c=STEPS[cur];c._m=(c._m||0)+1;if(c._m>=(need||3))done()}
// o'nlik tayoqchasi (10 ta nuqta ustun) va birlik nuqtasi
function rod(p,x,y,h,col){var g=E('g',{},p);E('rect',{x:x-6,y:y,width:12,height:h,rx:5,fill:'#fff',stroke:'#d9b98a','stroke-width':1.3},g);for(var i=0;i<10;i++)E('circle',{cx:x,cy:y+h/20+i*h/10,r:Math.min(4.6,h/24),fill:col||(i<5?C.t1:C.t2)},g);return g}
function unit(p,x,y,col){return E('circle',{cx:x,cy:y,r:5,fill:col||C.u,stroke:'rgba(0,0,0,.15)'},p)}
// sonni o'nlik tayoqchalari + birliklar bilan chizish (x0..x0+w oralig'ida)
function numPic(p,n,x0,y0,opt){opt=opt||{};var t=opt.t!=null?opt.t:Math.floor(n/10),u=opt.u!=null?opt.u:n%10,g=E('g',{},p),h=opt.h||96;
 for(var i=0;i<t;i++)rod(g,x0+8+i*15,y0,h,opt.tc);
 for(var k=0;k<u;k++)unit(g,x0+16+t*15+Math.floor(k/5)*13,y0+8+(k%5)*(h-8)/5,opt.uc);g.t=t;g.u=u;return g}
var TENS=['','o‘n','yigirma','o‘ttiz','qirq','ellik','oltmish','yetmish','sakson','to‘qson'],ONES=['','bir','ikki','uch','to‘rt','besh','olti','yetti','sakkiz','to‘qqiz'];
function word(n){if(n===0)return 'nol';if(n===100)return 'yuz';return (TENS[Math.floor(n/10)]+' '+ONES[n%10]).trim()}
