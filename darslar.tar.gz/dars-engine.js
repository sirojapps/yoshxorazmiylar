// ============ DARS DVIGATELI (hamma mavzular uchun bitta) ============
// Mavzu fayli quyidagilarni beradi: TITLE, STEPS, PROBS, PRACT_STAGE, PREP (yoki PREP_DATA)
document.getElementById('ttl').textContent=TITLE;document.title=TITLE;
if(typeof LOCK_SEC==='undefined')var LOCK_SEC=20;
if(typeof PRAISE==='undefined')var PRAISE=[["ok1","Barakalla!"],["ok2","Ha, aynan shunday!"],["ok3","Zo'r, topdingiz!"],["ok4","Juda yaxshi!"]];
(function(){var R=rnd(29);PROBS.forEach(function(p,i){if(p._sh)return;p._sh=1;p.a=p.a||('p'+pad(i+1));var idx=[0,1,2,3].slice(0,p.o.length);for(var j=idx.length-1;j>0;j--){var r=Math.floor(R()*(j+1));var t=idx[j];idx[j]=idx[r];idx[r]=t}var o=idx.map(function(x){return p.o[x]});p.k=idx.indexOf(p.k);p.o=o})})();
if(typeof PREP==='undefined'){var PD=PREP_DATA;var PREP='<div class="st prep"><div class="bd" style="padding-top:12px"><h3 style="margin-top:0">Darsga tayyorlanish</h3><ul>'+PD.teach.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ul><h3>Bolalar odatda qayerda adashadi</h3><ul>'+PD.mist.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ul>'+(PD.need?'<h3>Kerakli narsalar</h3><ul>'+PD.need.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ul>':'')+'<h3>Doskaga nima yoziladi</h3><ol>'+PD.board.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ol><button class="printbtn" onclick="window.print()">🖨 Chop etish</button><h3>Mashq varaqasi (javoblari bilan)</h3><ol class="plist">'+PROBS.map(function(p){return '<li>'+p.t+'<br><span class="pnum">'+p.o.map(function(o,j){return String.fromCharCode(65+j)+') '+o}).join(' &nbsp; ')+' — <b>'+String.fromCharCode(65+p.k)+'</b></span></li>'}).join('')+'</ol></div></div>'}
// ===================== OVOZ =====================
var AUD={};var ACTX=null,BUF={},CUR=null,PLAYID=0,lastA=null;
function unlock(){try{if(!ACTX){var AC=window.AudioContext||window.webkitAudioContext;ACTX=new AC();var s=ACTX.createBufferSource();s.buffer=ACTX.createBuffer(1,1,22050);s.connect(ACTX.destination);s.start(0)}if(ACTX.state==='suspended')ACTX.resume()}catch(e){}}
document.addEventListener('click',unlock,true);document.addEventListener('touchend',unlock,true);
function getBuf(n){if(BUF[n])return Promise.resolve(BUF[n]);var bin=atob(AUD[n]),u=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return new Promise(function(ok,no){ACTX.decodeAudioData(u.buffer,function(b){BUF[n]=b;ok(b)},no)})}
function stopAudio(){PLAYID++;try{CUR&&CUR.stop()}catch(e){}CUR=null}
function play(name,cb){stopAudio();var id=PLAYID,pb=document.getElementById('play');if(name)lastA=name;
 if(!name||!AUD[name]||!ACTX||document.body.classList.contains('teach')){pb.className='snd off';if(cb&&name&&!AUD[name])cb();return}
 if(ACTX.state==='suspended')ACTX.resume();
 getBuf(name).then(function(b){if(id!==PLAYID)return;var src=ACTX.createBufferSource();src.buffer=b;src.connect(ACTX.destination);CUR=src;pb.className='snd';src.onended=function(){if(id!==PLAYID)return;CUR=null;if(cb)cb()};src.start(0)}).catch(function(){pb.className='snd off'})}
function playCur(){play(lastA)}
// ===================== DVIGATEL =====================
var notes=document.getElementById('notes'),cur=-1,view=-1,cards=[],st={};
var prog=document.getElementById('prog');STEPS.concat([0]).forEach(function(){prog.appendChild(document.createElement('i'))});
function qHTML(s,i){if(!s.q)return '';return '<div class="q hid" id="q'+i+'"><div class="t">🤔 '+s.q.t+'</div><div class="opts">'+s.q.opts.map(function(o,j){return '<button onclick="ans('+i+','+j+')">'+o+'</button>'}).join('')+'</div><div class="fb"></div></div>'}
function mkCard(i){var s=STEPS[i],c=document.createElement('div');c.className='st';
 c.innerHTML='<div class="hd"><span class="num">'+(i+1)+'</span><span class="ttl">'+s.h+'</span></div><div class="sum">'+s.sum+'</div><div class="bd">'+s.html+(s.btns?'<div class="acts'+(s.g2?' g2':'')+(s.g3?' g3':'')+'"></div>':'')+'<div class="hint"></div>'+(s.after?'<div class="after hid">'+s.after+'</div>':'')+qHTML(s,i)+'<div class="tn"><b>O\'qituvchiga:</b> '+s.tn+'</div><button class="go hid">Davom etish ↓</button></div>';
 c.querySelector('.hd').onclick=function(){headTap(i)};
 c.querySelector('.go').onclick=function(){next()};
 if(s.btns){var box=c.querySelector('.acts');s.btns.forEach(function(b){var e=document.createElement('button');e.className='ab'+(b[2]?' '+b[2]:'');e.textContent=b[0];e.onclick=function(){if(view!==cur)backToCur();b[1](c,function(){actDone(i)},e)};box.appendChild(e)})}
 notes.appendChild(c);cards[i]=c;return c}
function headTap(i){var c=cards[i];if(i===cur){if(view!==cur)backToCur();return}
 if(c.classList.contains('col')){cards.forEach(function(x,k){if(k!==cur&&x)x.classList.add('col');x&&x.classList.remove('view')});c.classList.remove('col');c.classList.add('view');view=i;stopAudio();STEPS[i].fin()}
 else{c.classList.add('col');c.classList.remove('view');backToCur()}}
function backToCur(){cards.forEach(function(x,k){if(x&&k!==cur){x.classList.add('col');x.classList.remove('view')}});view=cur;
 var s=STEPS[cur];if(!s)return;if(st['a'+cur]){s.fin()}else{s.start();if(s.act)s.act(cards[cur],function(){actDone(cur)})}}
function open(i){cur=i;view=i;var c=cards[i]||mkCard(i);c.classList.remove('hid','col','view');var s=STEPS[i];s.start();
 if(s.act)s.act(c,function(){actDone(i)});if(!s.act&&!s.btns)actDone(i);
 [].forEach.call(prog.children,function(e,k){e.className=k<i?'on':''});
 play(s.a);setTimeout(function(){scrollToCard(c)},60)}
function scrollToCard(c){var stg=document.querySelector('.stage');var off=window.innerWidth>=820?12:stg.offsetHeight+8;var y=c.getBoundingClientRect().top+window.scrollY-off;window.scrollTo({top:y,behavior:'smooth'})}
function actDone(i){if(st['a'+i])return;st['a'+i]=1;var c=cards[i];[].forEach.call(c.querySelectorAll('.after,.q'),function(e){e.classList.remove('hid');e.classList.add('reveal')});
 var s=STEPS[i];if(AUD[s.a+'b'])play(s.a+'b');if(!s.q)showGo(i)}
function showGo(i){var g=cards[i].querySelector('.go');g.classList.remove('hid');g.classList.add('reveal');g.textContent=i===STEPS.length-1?'Mashqlarga o\'tish ↓':'Davom etish ↓'}
function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(x){}}function lsGet(k){try{return JSON.parse(localStorage.getItem(k)||'null')}catch(x){return null}}
function saveProg(s){lsSet('pr_'+CODE,{s:s,n:STEPS.length,t:TITLE,at:Date.now()});lsSet('last_lesson',{c:CODE,t:TITLE,at:Date.now()})}
function next(){var i=cur;cards[i].classList.add('col','done');saveProg(i+1);cards[i].querySelector('.go').classList.add('hid');if(i+1<STEPS.length)open(i+1);else openPractice()}
function ans(i,j){var s=STEPS[i],q=document.getElementById('q'+i),bs=q.querySelectorAll('button'),fb=q.querySelector('.fb');if(st[i])return;
 st[i+'t']=(st[i+'t']||0)+1;
 if(j===s.q.ok){st[i]=st[i+'t']===1?1:2;bs.forEach(function(b){b.disabled=true});bs[j].className='ok';var r=PRAISE[Math.floor(Math.random()*4)];fb.className='fb show ok';fb.innerHTML='✅ <b>'+(st[i]===1?r[1]:'To\'g\'ri, endi topdingiz!')+'</b> '+s.q.why;play(r[0],function(){play('w'+pad(i+1))});setTimeout(function(){showGo(i)},1200);return}
 flashBad(bs[j]);
 if(st[i+'t']===1){fb.className='fb show bad';fb.innerHTML='🤔 '+s.q.hint;play('h'+pad(i+1));bs.forEach(function(b){b.disabled=true});var t=LOCK_SEC;var w=document.createElement('div');w.className='hint';fb.appendChild(w);
  var iv=setInterval(function(){t--;w.textContent='Yana o\'ylab ko\'ring… '+t+' soniya';if(t<=0){clearInterval(iv);w.textContent='Endi yana tanlang.';bs.forEach(function(b){b.disabled=false})}},1000)}
 else{fb.className='fb show full';fb.innerHTML='📖 '+s.q.full+'<div class="hint" style="margin-top:6px;font-weight:600">Endi to\'g\'ri javobni o\'zingiz tanlang 👆</div>';play('f'+pad(i+1));bs.forEach(function(b){b.disabled=false})}}
// ===================== MASHQ =====================
var done=[];try{done=JSON.parse(localStorage.getItem('done_'+CODE)||'[]')}catch(e){}
var pc,set=[],pi=0,score=0;
function openPractice(){cur=STEPS.length;view=cur;PRACT_STAGE();[].forEach.call(prog.children,function(e,k){e.className=k<cur?'on':''});
 pc=document.createElement('div');pc.className='st';notes.appendChild(pc);startPractice();setTimeout(function(){scrollToCard(pc)},60)}
function startPractice(){var left=PROBS.map(function(p,i){return i}).filter(function(i){return done.indexOf(i)<0});if(left.length<10){done=[];left=PROBS.map(function(p,i){return i})}
 left.sort(function(){return Math.random()-.5});set=left.slice(0,10);pi=0;score=0;showProb()}
function showProb(){var p=PROBS[set[pi]];ptry=0;
 pc.innerHTML='<div class="hd"><span class="num">✎</span><span class="ttl">Mashq</span><span class="pnum">'+(pi+1)+' / 10 · to\'g\'ri: '+score+'</span></div><div class="bd"><p><b>'+p.t+'</b></p><div class="q" style="margin-top:6px"><div class="opts">'+p.o.map(function(o,j){return '<button onclick="pans('+j+')">'+String.fromCharCode(65+j)+') '+o+'</button>'}).join('')+'</div><div class="fb"></div></div><div class="sol hid" id="sol">💡 '+p.s+'</div><button class="go hid" id="pn" onclick="nextProb()">Keyingi misol →</button></div>';play(p.a)}
var ptry=0;
function flashBad(b){b.className='bad';clearTimeout(b._t);b._t=setTimeout(function(){if(b.className==='bad')b.className=''},2000)}
function pans(j){var p=PROBS[set[pi]],bs=pc.querySelectorAll('.opts button'),fb=pc.querySelector('.fb');
 if(j===p.k){if(ptry===0)score++;bs.forEach(function(b){b.disabled=true});bs[j].className='ok';var r=PRAISE[Math.floor(Math.random()*4)];fb.className='fb show ok';fb.innerHTML='✅ <b>'+(ptry===0?r[1]:'To\'g\'ri, endi topdingiz!')+'</b>'+(ptry?' <span class="pnum">(birinchi urinishda emas — ball qo\'shilmadi)</span>':'');play(r[0]);
  document.getElementById('sol').classList.remove('hid');document.getElementById('pn').classList.remove('hid');ptry=0}
 else{ptry++;flashBad(bs[j]);
  if(ptry===1){fb.className='fb show bad';fb.innerHTML='❌ Xato. Yana bir o\'ylab ko\'ring.';play('x1')}
  else{fb.className='fb show full';fb.innerHTML='💡 '+p.s+'<div class="hint" style="margin-top:6px;font-weight:600">Yechimni o\'qing va to\'g\'ri javobni o\'zingiz tanlang 👆</div>';play('s'+pad(set[pi]+1))}}
 pc.querySelector('.pnum').textContent=(pi+1)+' / 10 · to\'g\'ri: '+score}
function nextProb(){done.push(set[pi]);try{localStorage.setItem('done_'+CODE,JSON.stringify(done))}catch(e){}pi++;if(pi<10)showProb();else result()}
function result(){var b=lsGet('best_'+CODE)||0;if(score>b)lsSet('best_'+CODE,score);saveProg(STEPS.length);var stars=score>=9?'⭐⭐⭐':score>=7?'⭐⭐':score>=5?'⭐':'';
 pc.innerHTML='<div class="bd res" style="padding-top:12px"><div class="pnum">Natija</div><div class="big">'+score+' / 10</div><div class="stars">'+stars+'</div><p>'+(score>=9?'Ajoyib! Mavzuni to\'liq o\'zlashtirdingiz.':score>=7?'Yaxshi! Yana bir to\'plam yechib mustahkamlang.':'Mavzuni yana bir ko\'rib chiqing, keyin qayta urinib ko\'ring.')+'</p><button class="btn3" onclick="startPractice()">🔄 Yana 10 ta</button><button class="btn3" onclick="scrollTo({top:0,behavior:\'smooth\'})">📖 Mavzuga qaytish</button></div>';play(score>=7?'r1':'r2')}

notes.insertAdjacentHTML('afterbegin',PREP);
function mode(m){var t=m==='teach';document.body.classList.toggle('teach',t);document.getElementById('tb').classList.toggle('on',!t);document.getElementById('tt').classList.toggle('on',t);stopAudio();
 if(t){ // o'qituvchi: hamma qadamlar ochiq, javoblar ko'rinib turadi
  for(var i=0;i<STEPS.length;i++){if(!cards[i])mkCard(i);var c=cards[i];c.classList.remove('hid');[].forEach.call(c.querySelectorAll('.after,.q'),function(e){e.classList.remove('hid')});var s=STEPS[i];if(s.q){var bs=c.querySelectorAll('.q .opts button');bs[s.q.ok].className='ok'}}
  window.scrollTo({top:0})}else{cards.forEach(function(c,k){if(c&&k>cur)c.classList.add('hid')})}}

// ---- kasrlarni ustma-ust ko'rinishda yozish: «7/8» -> surat / chiziq / maxraj ----
var FR_RE=/(^|[^\d\/\w])(\d{1,3})\/(\d{1,4})(?![\d\/])/;
function frNode(t){var m=FR_RE.exec(t.nodeValue);if(!m)return;var i=m.index+m[1].length,after=t.splitText(i);after.nodeValue=after.nodeValue.slice(m[2].length+1+m[3].length);
 var s=document.createElement('span');s.className='frc';s.innerHTML='<span>'+m[2]+'</span><span>'+m[3]+'</span>';t.parentNode.insertBefore(s,after);frNode(after)}
function frWalk(root){if(!root||root.nodeType!==1&&root.nodeType!==3)return;if(root.nodeType===3){if(FR_RE.test(root.nodeValue))frNode(root);return}
 var tag=root.tagName;if(tag==='svg'||tag==='SCRIPT'||tag==='STYLE'||tag==='INPUT'||(root.classList&&(root.classList.contains('frc')||root.classList.contains('nofr'))))return;
 var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:function(n){for(var p=n.parentNode;p&&p!==root.parentNode;p=p.parentNode){if(p.nodeName==='svg'||p.nodeName==='text'||(p.classList&&(p.classList.contains('frc')||p.classList.contains('nofr'))))return NodeFilter.FILTER_REJECT}return FR_RE.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}}),l=[];while(w.nextNode())l.push(w.currentNode);l.forEach(frNode)}
(function(){var busy=false,ob=new MutationObserver(function(ms){if(busy)return;busy=true;try{ms.forEach(function(m){if(m.type==='characterData')frWalk(m.target);else m.addedNodes.forEach(frWalk)})}finally{busy=false}});
 [document.getElementById('notes'),document.getElementById('strip')].forEach(function(r){if(r){frWalk(r);ob.observe(r,{childList:true,subtree:true,characterData:true})}})})();
// ---- to'xtagan joydan davom etish ----
(function(){var p=lsGet('pr_'+CODE),k=p&&p.n===STEPS.length?p.s:0;lsSet('last_lesson',{c:CODE,t:TITLE,at:Date.now()});
 if(!k){open(0);return}
 for(var i=0;i<k&&i<STEPS.length;i++){var c=mkCard(i);c.classList.add('col','done');st['a'+i]=1;st[i]=1;[].forEach.call(c.querySelectorAll('.after,.q'),function(x){x.classList.remove('hid')});var s=STEPS[i];if(s.q){var bs=c.querySelectorAll('.q .opts button');bs.forEach(function(b){b.disabled=true});bs[s.q.ok].className='ok'}}
 var bar=document.createElement('div');bar.className='resume';bar.innerHTML='<span>↩️ To\'xtagan joyingizdan davom etyapsiz</span><button type="button">Boshidan boshlash</button>';bar.querySelector('button').onclick=function(){try{localStorage.removeItem('pr_'+CODE)}catch(x){}location.reload()};notes.insertBefore(bar,notes.querySelector('.st:not(.prep)'));
 if(k>=STEPS.length){cur=STEPS.length-1;openPractice()}else open(k)})();
