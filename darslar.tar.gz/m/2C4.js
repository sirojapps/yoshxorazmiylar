var CODE='2C4',TITLE='2-sinf · 4 va 5 ga ko‘paytirish va bo‘lish';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P3=[function(){cPlates(4,6,{lab:1,title:'4 · 6 = ?'});cMsg('4 — bu 2 ning ikki barobari. Avval 2 · 6…')},
 function(){cPlates(2,6,{lab:1,title:'2 · 6 = 12'});cMsg('2 · 6 = 6 + 6 = <b>12</b>')},
 function(){cPlates(4,6,{lab:1,title:'4 · 6 = 12 + 12'});cMsg('Yana ikkilantiramiz: 12 + 12 = <b>24</b>. Demak 4 · 6 = 24')}];
var P4=[function(){cDeal(28,1,0,{});cMsg('28 ta oyoq, har stulda 4 ta')},
 function(){clear();T(S.g,180,80,'28  →  14',{'font-size':30,'font-weight':800,fill:C.blue});T(S.g,180,120,'yarmi',{'font-size':13,fill:'#5b6b7b'});cMsg('4 ga bo‘lish = ikki marta yarmini olish. 28 ning yarmi 14')},
 function(){clear();T(S.g,180,80,'28  →  14  →  7',{'font-size':30,'font-weight':800,fill:C.ok});T(S.g,180,120,'yarmi      yarmi',{'font-size':13,fill:'#5b6b7b'});cMsg('14 ning yarmi 7. Demak 28 : 4 = <b>7</b> ta stul')}];
var P7=[function(){cPlates(4,4,{lab:1,title:'4 ta mashina — 4 tadan g‘ildirak',col:'#555'});cMsg('4 · 4 = 16 ta g‘ildirak')},
 function(){cPlates(5,2,{lab:1,title:'5 ta velosiped — 2 tadan g‘ildirak',col:'#555'});cMsg('2 · 5 = 10 ta g‘ildirak')},
 function(){clear();T(S.g,180,90,'16 − 10 = 6',{'font-size':34,'font-weight':800,fill:C.ok});cMsg('Mashinalarning g‘ildiraklari <b>6 ta</b> ko‘p')}];
var P8=[function(){clear();cBar(60,4,'x',null);E('rect',{x:320,y:60,width:28,height:30,fill:'#bfe9e3',stroke:C.line},S.g);T(S.g,334,80,'7',{'font-size':12,'font-weight':800});Br(40,348,56,'43',true);cMsg('x · 4 + 7 = 43: 4 ta bir xil quti va yana 7')},
 function(){clear();cBar(60,4,'x',null);Br(40,320,56,'43 − 7 = 36',true);cMsg('7 ni olib tashlaymiz: 4 ta quti = 36')},
 function(){clear();cBar(60,4,'9',null);Br(40,320,56,'36',true);cMsg('36 : 4 = 9. Demak x = <b>9</b>. Tekshiramiz: 9 · 4 + 7 = 43 ✓')}];
var STEPS=[
{h:"Beshtalab sanaymiz",sum:"5, 10, 15, 20, 25, 30, 35, 40, 45, 50 — qo'ldagi barmoqlar. 5 · 8 = 40.",a:"m01",
 start:function(){S.n=0;c4Hands()},fin:function(){S.n=8;c4Hands()},
 html:"<p>Bitta qo'lda <b>5 ta</b> barmoq. Qo'llarni qo'shib boring — 5 tadan sanaymiz:</p>",
 btns:[["🖐 + qo'l",function(c,done,b){if(S.n>=10)return;S.n++;c4Hands();if(S.n===8)done();if(S.n===10)b.disabled=true}]],
 after:"<p>5 ga sanash: 5, 10, 15, 20, 25, 30… Hamma javob <b>0 yoki 5</b> bilan tugaydi! Bu — tekshirish uchun qulay belgi.</p>",
 q:{t:"Har bir qo'lda 5 ta barmoq. 8 ta bolaning ikkala qo'lida jami nechta barmoq?",opts:["40","16","80","85"],ok:2,why:"Bitta bolada 10 ta: 10 · 8 = 80.",hint:"Bitta bolaning ikkala qo'lida nechta barmoq?",full:"Bitta bola — 2 qo'l, 5 · 2 = 10 barmoq. 8 bola: 10 · 8 = 80. «40» — faqat bitta qo'lni sanash xatosi."},
 tn:"Bolalar qo'llarini ko'tarib, beshtalab sanasin: 5, 10, 15…"},
{h:"5 jadvalining siri",sum:"5 ga ko'paytma doim 0 yoki 5 bilan tugaydi; 5 · juft son — 0 bilan.",a:"m02",
 start:function(){c4Five(0)},fin:function(){c4Five(10)},
 html:"<p>5 · 1 dan 5 · 10 gacha bosib chiqing va oxirgi raqamga qarang:</p><div class='digs' id='c4d'></div>",
 act:function(c,done){var box=c.querySelector('#c4d'),k=0;box.innerHTML='';for(var n=1;n<=10;n++)(function(n){var b=document.createElement('button');b.className='dg';b.textContent=n;b.onclick=function(){c4Five(n);if(++k===4)done()};box.appendChild(b)})(n)},
 after:"<p>5 · <b>juft</b> son — 0 bilan tugaydi (5 · 4 = 20), 5 · <b>toq</b> son — 5 bilan tugaydi (5 · 7 = 35). 5 · 6 — bu yarim o'nlikning 6 tasi: 6 · 10 ning yarmi = 30.</p>",
 q:{t:"Qaysi son 5 ga ko'paytirish jadvalida uchraydi?",opts:["32","35","48","54"],ok:1,why:"35 = 5 · 7, u 5 bilan tugaydi.",hint:"5 jadvalidagi sonlar qaysi raqam bilan tugaydi?",full:"5 ga ko'paytmalar 0 yoki 5 bilan tugaydi. Faqat 35 shunday: 5 · 7 = 35."},
 tn:"Soat siferblatini ko'rsating: minut mili har raqamda 5 minut — 5 jadvalining tayyor rasmi."},
{h:"4 ga ko'paytirish — ikki marta ikkilantirish",sum:"4 · 6 = 2 · 6 · 2: 6 + 6 = 12, 12 + 12 = 24.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>4 ga ko'paytirishni yod bilmasangiz ham bo'ladi: <b>4 = 2 + 2</b>. Avval ikkilantiring, keyin yana ikkilantiring. Kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p><b>«Ikki marta ikkilantir»</b>: 4 · 7 → 7 + 7 = 14 → 14 + 14 = 28. Bu usulni Yaponiya va Singapur darsliklari ham o'rgatadi.</p>",
 q:{t:"4 · 8 nechaga teng?",opts:["12","24","32","48"],ok:2,why:"8 + 8 = 16, 16 + 16 = 32.",hint:"8 ni ikkilantiring, natijani yana ikkilantiring.",full:"2 · 8 = 16, 4 · 8 = 16 + 16 = 32. «12» — qo'shish (4 + 8), «24» — 3 · 8."},
 tn:"«Ikkilantir-ikkilantir» usulini doskaga strelka bilan yozing: 7 →(×2) 14 →(×2) 28."},
{h:"4 ga bo'lish — ikki marta yarmi",sum:"28 : 4 = 7: 28 ning yarmi 14, 14 ning yarmi 7.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Masala: <i>«Har stulning 4 ta oyog'i bor. Xonadagi stullarning jami 28 ta oyog'i bor. Nechta stul?»</i> 28 : 4 ni ikki marta yarmini olib topamiz.</p>",
 btns:[phaser(P4)],
 after:"<p>4 ga bo'lish = <b>ikki marta yarmini olish</b>. Tekshiramiz: 7 · 4 = 28 ✓.</p>",
 q:{t:"36 : 4 nechaga teng?",opts:["9","8","18","32"],ok:0,why:"36 → 18 → 9.",hint:"36 ning yarmini toping, keyin yana yarmini.",full:"36 ning yarmi 18, 18 ning yarmi 9. 36 : 4 = 9. «18» — faqat bir marta yarmi olingan."},
 tn:"Bolalar qog'ozni ikki marta buklab, 4 ta teng bo'lak chiqishini ko'rsin."},
{h:"5 ga bo'lish",sum:"40 : 5 = 8 — 40 dan 5 ni 8 marta ayirish mumkin; chunki 8 · 5 = 40.",a:"m05",
 start:function(){S.j=0;cLine(40,5,0,{from:40,back:1});cMsg('40 sm lenta. 5 sm dan qirqamiz')},fin:function(){cLine(40,5,8,{from:40,back:1});cMsg('8 ta bo‘lak: 40 : 5 = <b>8</b>')},
 html:"<p>Masala: <i>«40 sm lentadan 5 sm lik nechta bo'lak qirqiladi?»</i> Orqaga 5 tadan sakrang:</p>",
 btns:[["✂ −5 sm",function(c,done,b){if(S.j>=8)return;S.j++;cLine(40,5,S.j,{from:40,back:1});cMsg(S.j<8?S.j+' ta bo‘lak, qoldi '+(40-5*S.j)+' sm':'8 ta bo‘lak: 40 : 5 = <b>8</b>');if(S.j===8){b.disabled=true;done()}}]],
 after:"<p>Tez usul: 5 ga bo'lish — «nechta beshlik?». 40 = 8 · 5, demak 8 ta. Yoki: 40 : 10 = 4 ta o'nlik, har o'nlikda 2 ta beshlik → 8.</p>",
 q:{t:"45 : 5 nechaga teng?",opts:["9","8","40","50"],ok:0,why:"9 · 5 = 45.",hint:"5 ga sanang: 5, 10, 15 … 45 gacha nechta sakrash?",full:"5, 10, 15, 20, 25, 30, 35, 40, 45 — 9 ta. 45 : 5 = 9. «40» — ayirish."},
 tn:"Pul bilan: 45 ming so'mni 5 minglik pulga maydalasak, nechta pul bo'ladi?"},
{h:"4 va 5 — massivda",sum:"5 ni 4 marta va 4 ni 5 marta qo'shish — 20 + 20 = 40; 4 · 5 = 5 · 4.",a:"m06",
 start:function(){cArr(4,5,{rowLab:1});cMsg('4 qator, 5 tadan: 5 · 4 = 20')},fin:function(){cArr(5,4,{rowLab:1});cMsg('5 qator, 4 tadan: 4 · 5 = 20 — teng!')},
 html:"<p>4 qator 5 tadan va 5 qator 4 tadan — qaysi biri ko'p? Burib ko'ring:</p>",
 btns:[["↻ Burish",function(c,done){var r=S.rot=!S.rot;if(r){cArr(5,4,{rowLab:1});cMsg('5 qator, 4 tadan: 4 · 5 = <b>20</b>')}else{cArr(4,5,{rowLab:1});cMsg('4 qator, 5 tadan: 5 · 4 = <b>20</b>')}mvK(done,2)}]],
 after:"<p>Burgandan keyin ham nuqtalar o'sha-o'sha — 20 ta. Demak <b>4 · 5 = 5 · 4</b>. 4 jadvalini bilsangiz, 5 jadvalining yarmini ham bilasiz.</p>",
 q:{t:"5 ni 4 marta va 4 ni 5 marta qo'shsak, jami nechchi chiqadi?",opts:["18","45","40","20"],ok:2,why:"5 · 4 = 20 va 4 · 5 = 20, jami 40.",hint:"Har birini alohida hisoblang va qo'shing.",full:"5 + 5 + 5 + 5 = 20, 4 + 4 + 4 + 4 + 4 = 20. Jami 40. «20» — faqat bittasi, «18» — 5 + 4 + 4 + 5."},
 tn:"Ikki bola massivni stol ustida qurib, partani burib ko'rsin."},
{h:"Tuzoq: ikki ko'paytmani solishtirish",sum:"4 mashina (16 g'ildirak) va 5 velosiped (10 g'ildirak): farq 16 − 10 = 6.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Masala: <i>«4 ta yengil mashinaning g'ildiraklari 5 ta velosipedning g'ildiraklaridan nechta ko'p?»</i> 5 − 4 = 1 deb shoshilmang!</p>",
 btns:[phaser(P7)],
 after:"<p>Avval <b>har birini</b> hisoblaymiz: mashinalar 4 · 4 = 16, velosipedlar 2 · 5 = 10. Keyin solishtiramiz: 16 − 10 = 6.</p>",
 q:{t:"Har bir yulduzchaning 5 ta uchi bor. 4 ta yulduzchaning uchlari 3 ta kvadratning uchlaridan nechta ko'p?",opts:["7","32","12","8"],ok:3,why:"5 · 4 = 20, 4 · 3 = 12, 20 − 12 = 8.",hint:"Avval yulduzchalar uchlarini, keyin kvadratlar uchlarini toping.",full:"Yulduzchalar: 5 · 4 = 20. Kvadratlar: 4 · 3 = 12. Farq: 20 − 12 = 8. «12» — kvadratlar uchlari, javob emas."},
 tn:"Ikki bosqichli taqqoslash: doskaga ikkita ustun chizib, har birining ko'paytmasini yozing."},
{h:"Tuzoq: chizma bilan tenglama",sum:"x · 4 + 7 = 43: avval 7 ni olib tashlaymiz (36), keyin 4 ga bo'lamiz — x = 9.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Tenglama: <b>x · 4 + 7 = 43</b>. x — noma'lum son. Uni 4 ta bir xil quti qilib chizamiz:</p>",
 btns:[phaser(P8)],
 after:"<p>Chizmada ko'rinadi: 4 ta quti va qo'shimcha 7 — jami 43. Avval qo'shimchani olib tashlaymiz, keyin teng bo'lamiz. Bu — Singapur «chizma model» usuli.</p>",
 q:{t:"Tenglamani yeching: 5 · x = 45 − 10",opts:["9","35","7","40"],ok:2,why:"45 − 10 = 35, x = 35 : 5 = 7.",hint:"Avval o'ng tomonni hisoblang.",full:"45 − 10 = 35. 5 · x = 35, demak x = 35 : 5 = 7. «9» — 45 : 5 (10 ni unutish)."},
 tn:"Har tenglamani avval chizma (qutilar) bilan ko'rsating, keyin yozing."},
{h:"Bilasizmi? Beshlik va o'nlik",sum:"Rim raqamlarida V — 5, X — 10. Odamlar qadimdan qo'ldagi 5 barmoq bilan sanagan.",a:"m09",
 start:function(){clear('#f6ead0');T(S.g,110,100,'V',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,250,100,'X',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,110,140,'5',{'font-size':16,'font-weight':800,fill:'#6b3d12'});T(S.g,250,140,'10',{'font-size':16,'font-weight':800,fill:'#6b3d12'});cMsg('Rim raqamlari')},fin:function(){STEPS[8].start()},
 html:"<p>🏛 Rim raqamlarida <b>V</b> — 5, <b>X</b> — 10. Soat siferblatlarida hozir ham uchraydi: V — beshinchi soat.</p><p>🖐 Odamlar qadimdan qo'ldagi <b>5 ta</b> barmoq bilan sanagan. Shuning uchun beshlik va o'nlik — eng qulay hisob birliklari. Pullarimiz ham 5 va 10 lik: 5 000, 10 000, 50 000 so'm.</p>",
 tn:"Pul namunalari bilan 5 va 10 ga ko'paytirishni mashq qildiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){cArr(4,5,{rowLab:1});cMsg('4 · 5 = 5 · 4 = 20')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>5 ga sanash: 5, 10, 15, … 50. 5 ga ko'paytma <b>0 yoki 5</b> bilan tugaydi.</li><li>4 ga sanash: 4, 8, 12, 16, 20, 24, 28, 32, 36, 40.</li><li>4 ga ko'paytirish — <b>ikki marta ikkilantirish</b>: 4 · 7 = 14 + 14 = 28.</li><li>4 ga bo'lish — <b>ikki marta yarmi</b>: 28 → 14 → 7.</li><li>5 ga bo'lish — «nechta beshlik?»: 40 : 5 = 8.</li><li>Ikki narsani solishtirishda avval har birini hisoblang: 16 − 10 = 6.</li><li>x · 4 + 7 = 43: avval 7 ni olib tashlang, keyin bo'ling.</li></ul></div>",
 tn:"Keyingi darsni «Soat mili 7 da — necha minut o'tdi?» (5 · 7 = 35) savoli bilan boshlang."}
];
function c4Hands(){var n=S.n;clear();var cols=5,sp=66;for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;T(S.g,48+c*sp,62+r*62,'🖐',{'font-size':38});T(S.g,48+c*sp,86+r*62,String(5*(i+1)),{'font-size':12,'font-weight':800,fill:C.blue})}
 if(!n)T(S.g,180,90,'Qo‘l qo‘shing',{'font-size':16,fill:'#9aa8b6'});cMsg(n?('5 · '+n+' = <b>'+5*n+'</b> ta barmoq'):'5 · 0 = 0')}
function c4Five(n){clear();for(var i=1;i<=10;i++){var x=24+(i-1)*34,on=i<=n;E('rect',{x:x-14,y:40,width:28,height:60,rx:6,fill:on?(i%2?'#ffe2b8':'#d8eefa'):'#f4f6f8',stroke:'#c9d3dd'},S.g);T(S.g,x,62,'5·'+i,{'font-size':9,fill:'#5b6b7b'});if(on)T(S.g,x,88,String(5*i),{'font-size':14,'font-weight':800,fill:i%2?C.a2:C.blue})}
 T(S.g,180,130,'toq · 5 → …5      juft · 5 → …0',{'font-size':12,'font-weight':700,fill:'#5b6b7b'});cMsg(n?'5 · '+n+' = <b>'+5*n+'</b>':'Sonlarni bosing')}
var PROBS=[
{t:"4 · 7 nechaga teng?",o:["28","24","11","32"],k:0,s:"7 + 7 = 14, 14 + 14 = 28."},
{t:"5 · 9 nechaga teng?",o:["45","40","14","54"],k:0,s:"5 ga sanash: … 40, 45."},
{t:"32 : 4 nechaga teng?",o:["8","16","28","9"],k:0,s:"32 → 16 → 8."},
{t:"35 : 5 nechaga teng?",o:["7","30","6","8"],k:0,s:"7 · 5 = 35."},
{t:"Har stulda 4 ta oyoq. Stullarning jami 28 ta oyog'i bor. Nechta stul?",o:["7","6","24","32"],k:0,s:"28 : 4 = 7."},
{t:"40 sm lentadan 5 sm lik nechta bo'lak qirqiladi?",o:["8","9","35","200"],k:0,s:"40 : 5 = 8."},
{t:"Har qo'lda 5 ta barmoq. 8 ta bolaning ikkala qo'lida jami nechta barmoq?",o:["80","40","16","85"],k:0,s:"Bitta bola 10 ta: 10 · 8 = 80."},
{t:"4 ta yengil mashinaning g'ildiraklari 5 ta velosipedning g'ildiraklaridan nechta ko'p?",o:["6","4","10","26"],k:0,s:"16 − 10 = 6."},
{t:"Har yulduzchaning 5 ta uchi bor. 4 ta yulduzchaning uchlari 3 ta kvadratning uchlaridan nechta ko'p?",o:["8","7","12","32"],k:0,s:"20 − 12 = 8."},
{t:"5 ni 4 marta va 4 ni 5 marta qo'shsak, jami nechchi chiqadi?",o:["40","20","18","45"],k:0,s:"20 + 20 = 40."},
{t:"Ikkita ko'paytmani qo'shing: 5 · 6 + 4 · 5",o:["50","45","54","70"],k:0,s:"30 + 20 = 50."},
{t:"Tenglamani yeching: x · 4 + 7 = 43",o:["9","8","36","50"],k:0,s:"43 − 7 = 36, 36 : 4 = 9."},
{t:"Tenglamani yeching: 5 · x = 45 − 10",o:["7","9","35","40"],k:0,s:"45 − 10 = 35, 35 : 5 = 7."},
{t:"Hisoblang: 20 · 4 + 13",o:["93","83","97","103"],k:0,s:"80 + 13 = 93."},
{t:"Hisoblang: 5 · 9 − 4 · 7 + 20",o:["37","17","53","93"],k:0,s:"45 − 28 + 20 = 37."},
{t:"(□ + 4) · 6 = 54 bo'lsa, □ nechaga teng?",o:["5","9","13","50"],k:0,s:"□ + 4 = 54 : 6 = 9, □ = 5."},
{t:"Qaysi son 5 ga ko'paytirish jadvalida YO'Q?",o:["42","30","45","25"],k:0,s:"5 ga ko'paytmalar 0 yoki 5 bilan tugaydi; 42 — yo'q."},
{t:"Tarozida 4 ta bir xil quti — 12 kg. Shunday 3 ta quti necha kg?",o:["9","12","16","36"],k:0,s:"Bitta quti: 12 : 4 = 3 kg. 3 ta: 3 · 3 = 9 kg."},
{t:"Soat mili 12 dan 7 gacha yurdi (har raqam 5 minut). Necha minut o'tdi?",o:["35","7","30","40"],k:0,s:"5 · 7 = 35 minut."},
{t:"4 · 9 va 5 · 7 dan qaysi biri katta va qanchaga?",o:["4 · 9 bittaga katta","5 · 7 bittaga katta","Teng","4 · 9 ikkitaga katta"],k:0,s:"36 va 35: 36 − 35 = 1."}
];
function PRACT_STAGE(){cArr(4,5,{rowLab:1});cMsg('4 — ikki marta ikkilantir, 5 — oxiri 0 yoki 5')}
var PREP_DATA={teach:["4 va 5 ga sanash; 5 jadvalining oxirgi raqami (0/5).","4 ga ko'paytirish — ikki marta ikkilantirish; 4 ga bo'lish — ikki marta yarmi.","5 ga bo'lish — «nechta beshlik»; 4 · 5 = 5 · 4.","Tuzoqlar: ikki ko'paytmani solishtirish, chizma bilan tenglama."],
 mist:["4 · 8 ni 12 deydi (qo'shadi).","36 : 4 da faqat bir marta yarmini oladi (18).","«Nechta ko'p» masalasida ko'paytmalarni emas, sonlarni ayiradi (5 − 4).","Tenglamada qo'shiluvchini olib tashlashni unutadi."],
 need:["Qo'llar (barmoqlar), soat siferblati.","Doskada son o'qi 0–40, massiv."],
 board:["<span class='w2'>5, 10, 15, … 50</span>; <span class='w2'>4, 8, 12, … 40</span>.","<span class='w2'>4 · 7: 7 → 14 → 28</span>.","<span class='w2'>28 : 4: 28 → 14 → 7</span>.","<span class='w2'>4 · 5 = 5 · 4 = 20</span>.","<span class='w2'>16 − 10 = 6</span>.","<span class='w2'>x · 4 + 7 = 43 → x = 9</span>."]};
