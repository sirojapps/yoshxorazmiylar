var CODE='2B5',TITLE='2-sinf · Noma‘lum qo‘shiluvchi, kamayuvchi va ayriluvchini topish';
var P1=[function(){bqBar(60,[{v:'35',w:35},{v:'?',w:25,q:1}],{title:'35 + □ = 60'});bqMsg('Butun — 60. Bitta qismi — 35. Ikkinchi qism noma‘lum')},
 function(){bqBar(60,[{v:'35',w:35,col:'#e9e2d6'},{v:'?',w:25,q:1}],{title:'35 + □ = 60'});bqMsg('Ma‘lum qismni butundan olib tashlaymiz: <b>60 − 35</b>')},
 function(){bqBar(60,[{v:'35',w:35},{v:'25',w:25,col:C.ok}],{title:'35 + 25 = 60'});bqMsg('60 − 35 = <b>25</b>. Tekshiramiz: 35 + 25 = 60 ✓')}];
var P2=[function(){bqScale(['x','50'],['43','57'],0);bqMsg('Tarozi teng turibdi: <b>x + 50 = 43 + 57</b>')},
 function(){bqScale(['x','50'],['100'],0);bqMsg('O‘ng pallani hisoblaymiz: 43 + 57 = <b>100</b>')},
 function(){bqScale(['x'],['50'],0);bqMsg('Ikkala palladan <b>50</b> ni olib tashlaymiz — muvozanat buzilmaydi: <b>x = 50</b>')}];
var P3=[function(){bqBar('?',[{v:'28',w:28,lab:'ayrildi'},{v:'45',w:45,lab:'qoldi'}],{title:'□ − 28 = 45',tq:1});bqMsg('Kamayuvchi — butun, u noma‘lum. Ayrilgani 28, qolgani 45')},
 function(){bqBar('73',[{v:'28',w:28,lab:'ayrildi'},{v:'45',w:45,lab:'qoldi'}],{title:'73 − 28 = 45'});bqMsg('Butun = ikki qism: 45 + 28 = <b>73</b>. Tekshiramiz: 73 − 28 = 45 ✓')}];
var P4=[function(){bqBar(63,[{v:'?',w:38,q:1,lab:'ayrildi'},{v:'25',w:25,lab:'qoldi'}],{title:'63 − □ = 25'});bqMsg('Butun — 63, qolgani — 25. Qancha ayrildi?')},
 function(){bqBar(63,[{v:'38',w:38,col:C.ok,lab:'ayrildi'},{v:'25',w:25,lab:'qoldi'}],{title:'63 − 38 = 25'});bqMsg('Butundan qolganini ayiramiz: 63 − 25 = <b>38</b>. Tekshiramiz: 63 − 38 = 25 ✓')}];
var P5=[function(){bqExpr(['x + 8 = 91 − 46']);bqMsg('O‘ng tomonda tayyor son yo‘q — avval uni hisoblaymiz')},
 function(){bqExpr(['x + 8 = [91 − 46]','x + 8 = [45]']);bqMsg('91 − 46 = 45')},
 function(){bqExpr(['x + 8 = 45','x = 45 − 8','x = [37]']);bqMsg('Noma‘lum qo‘shiluvchi: 45 − 8 = <b>37</b>. Tekshiramiz: 37 + 8 = 45 va 91 − 46 = 45 ✓')}];
var P6=[function(){bqBar('?',[{v:'15',w:15,lab:'ayrildi'},{v:'49',w:49,lab:'qoldi'}],{title:'(27 + x) − 15 = 49',tq:1});bqMsg('Qavsni <b>bitta narsa</b> deb qaraymiz: (27 + x) — bu kamayuvchi')},
 function(){bqBar('64',[{v:'15',w:15,lab:'ayrildi'},{v:'49',w:49,lab:'qoldi'}],{title:'27 + x = 64'});bqMsg('Kamayuvchi: 49 + 15 = <b>64</b>. Demak 27 + x = 64')},
 function(){bqBar('64',[{v:'27',w:27},{v:'37',w:37,col:C.ok}],{title:'27 + 37 = 64'});bqMsg('x = 64 − 27 = <b>37</b>. Tekshiramiz: (27 + 37) − 15 = 64 − 15 = 49 ✓')}];
var P7=[function(){bqBar(94,[{v:'35',w:35},{v:'24',w:24,col:C.b},{v:'?',w:35,q:1}],{title:'35 + 24 + □ = 94'});bqMsg('Uchta qism, bittasi noma‘lum')},
 function(){bqBar(94,[{v:'59',w:59,col:'#e9e2d6'},{v:'?',w:35,q:1}],{title:'59 + □ = 94'});bqMsg('Ma‘lum qismlarni birlashtiramiz: 35 + 24 = <b>59</b>')},
 function(){bqBar(94,[{v:'35',w:35},{v:'24',w:24,col:C.b},{v:'35',w:35,col:C.ok}],{title:'35 + 24 + 35 = 94'});bqMsg('94 − 59 = <b>35</b>. Tekshiramiz: 35 + 24 + 35 = 94 ✓')}];
var P8=[function(){bqScale(['x','7'],['10','7'],0);bqMsg('Ikkala tomonga bir xil narsa qo‘shilgan')},
 function(){bqScale(['x'],['10'],0);bqMsg('«Al-muqobala» — ikkala tomondan bir xilini olib tashlash: <b>x = 10</b>')}];
var STEPS=[
{h:"Qismlar va butun",sum:"Noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi: 35 + □ = 60 → 60 − 35 = 25.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har qanday qo'shish — bu <b>ikki qism birlashib butun bo'lishi</b>. Tepadagi chiziq — butun (60). Uning bir qismi 35, ikkinchisi — noma'lum. Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p><b>Qoida:</b> noma'lum qo'shiluvchini topish uchun <b>yig'indidan ma'lum qo'shiluvchini ayiramiz</b>. Chizmada: butundan ma'lum qismni olib tashlasak, noma'lum qism qoladi.</p>",
 q:{t:"□ + 18 = 45. Kvadrat o'rniga qaysi son?",opts:["63","27","37","17"],ok:1,why:"45 − 18 = 27.",hint:"Butun — 45, bir qism — 18. Ikkinchi qismni topish uchun nima qilamiz?",full:"Yig'indi 45, ma'lum qo'shiluvchi 18. Noma'lum: 45 − 18 = 27. Tekshiramiz: 27 + 18 = 45. «63» — 45 va 18 ni qo'shib yuborish xatosi."},
 tn:"Singapur darsliklaridagi «qism–butun» chizmasi. Bolalar har tenglamaga avval chizma chizsin: butun — uzun chiziq, qismlar — uning bo'laklari."},
{h:"Tarozi usuli",sum:"x + 50 = 43 + 57: avval o'ng tomon 100, keyin ikkala tomondan 50 ni olamiz → x = 50.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Tenglama — bu <b>teng turgan tarozi</b>. Ikkala pallaga bir xil ish qilsak, tarozi teng qoladi. Kuzating:</p>",
 btns:[phaser(P2)],
 after:"<p>Tenglamada «=» belgisi — tarozining o'rtasi. Chap va o'ng tomon <b>teng</b>. Ikkala tomondan bir xil son olsak yoki qo'shsak, tenglik buzilmaydi.</p>",
 q:{t:"Tarozida: chapda x va 20, o'ngda 35 va 25. x nechaga teng?",opts:["60","80","40","20"],ok:2,why:"35 + 25 = 60, x + 20 = 60, x = 40.",hint:"Avval o'ng pallani hisoblang. Keyin chapdagi 20 ni hisobga oling.",full:"O'ng palla: 35 + 25 = 60. Chapda x + 20 = 60. Ikkala tomondan 20 ni olsak: x = 40. «60» — o'ng tomonning o'zi, x emas."},
 tn:"Tarozi modeli — dunyoda tenglamani tushuntirishning eng keng tarqalgan usuli. Sinfda oddiy tarozi va bir xil og'irlikdagi kubiklar bilan ko'rsating."},
{h:"Noma'lum kamayuvchi",sum:"□ − 28 = 45: kamayuvchi — butun. Butun = ayrilgan + qolgan: 28 + 45 = 73.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Ayirishda <b>kamayuvchi — butun</b>: undan bir qism ayriladi (ayriluvchi), qolgani — ayirma. Kamayuvchi noma'lum bo'lsa-chi?</p>",
 btns:[phaser(P3)],
 after:"<p><b>Qoida:</b> noma'lum kamayuvchi = <b>ayirma + ayriluvchi</b>. Chunki ayrilgan va qolgan qism birgalikda butunni tashkil qiladi.</p>",
 q:{t:"x − 17 = 39. x nechaga teng?",opts:["22","56","46","66"],ok:1,why:"39 + 17 = 56.",hint:"x — butun. Ayrilgani 17, qolgani 39. Butunni qanday topamiz?",full:"Kamayuvchi butun: qolgan (39) + ayrilgan (17) = 56. Tekshiramiz: 56 − 17 = 39. «22» — ayirib yuborish xatosi: butun hech qachon qolgan qismdan kichik bo'lmaydi."},
 tn:"Bolalar ko'pincha «ayirish bor — ayiraman» deydi. Chizma ko'rsatadi: kamayuvchi butun, uni qo'shib topamiz."},
{h:"Noma'lum ayriluvchi",sum:"63 − □ = 25: butundan qolganini ayiramiz: 63 − 25 = 38.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Endi butun (63) va qolgani (25) ma'lum, <b>qancha ayrilgani</b> noma'lum.</p>",
 btns:[phaser(P4)],
 after:"<p><b>Qoida:</b> noma'lum ayriluvchi = <b>kamayuvchi − ayirma</b>. Butundan qolgan qismni olib tashlasak, ayrilgan qism chiqadi.</p>",
 q:{t:"80 − x = 47. x nechaga teng?",opts:["127","33","43","37"],ok:1,why:"80 − 47 = 33.",hint:"Butun — 80, qolgani — 47. Qancha ayrilgan?",full:"Ayriluvchi = kamayuvchi − ayirma: 80 − 47 = 33. Tekshiramiz: 80 − 33 = 47. «127» — qo'shib yuborilgan, ayriluvchi butundan katta bo'la olmaydi."},
 tn:"Uch qoidani doskaga chizma bilan yozing: butun noma'lum → qo'shamiz; qism noma'lum → ayiramiz."},
{h:"Avval tayyor sonni hisoblang",sum:"x + 8 = 91 − 46: o'ng tomon 45, keyin x = 45 − 8 = 37. Har doim tekshiring.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Ba'zan tenglamaning bir tomonida <b>ifoda</b> turadi. Avval uni bitta songa aylantiramiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Usul: <b>1)</b> ifodani hisoblang, <b>2)</b> qoidani qo'llang, <b>3)</b> javobni tenglamaga qo'yib <b>tekshiring</b>. Tekshirish — xatoni darhol ko'rsatadi.</p>",
 q:{t:"38 + x = 29 + 56. x nechaga teng?",opts:["85","47","57","123"],ok:1,why:"29 + 56 = 85, 85 − 38 = 47.",hint:"Avval o'ng tomonni hisoblang: 29 + 56.",full:"O'ng tomon: 29 + 56 = 85. 38 + x = 85, x = 85 − 38 = 47. Tekshiramiz: 38 + 47 = 85 ✓. «85» — o'ng tomonning o'zi."},
 tn:"Har tenglamadan keyin «tekshiruv qatori» yozishni odat qildiring — bu natijani tekshirish ko'nikmasi (2B8) bilan bog'lanadi."},
{h:"Tuzoq: qavs ichida noma'lum",sum:"(27 + x) − 15 = 49: qavs — kamayuvchi: 49 + 15 = 64; keyin x = 64 − 27 = 37.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Testlarda shunday tenglama keladi: <b>(27 + x) − 15 = 49</b>. Qavsni <b>bitta quti</b> deb tasavvur qiling va qobiq-qobiq ochamiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Qavsli tenglamani <b>tashqaridan ichkariga</b> yechamiz: avval qavs (butun quti) nimaga tengligini topamiz, keyin qavs ichini.</p>",
 q:{t:"83 − (x + 45) = 26. x nechaga teng?",opts:["38","12","57","64"],ok:1,why:"x + 45 = 83 − 26 = 57, x = 57 − 45 = 12.",hint:"Qavs — ayriluvchi. Avval qavs nimaga teng ekanini toping.",full:"Qavs (x + 45) — ayriluvchi: 83 − 26 = 57. Endi x + 45 = 57, x = 12. Tekshiramiz: 83 − (12 + 45) = 83 − 57 = 26 ✓. «57» — faqat qavsning qiymati."},
 tn:"Qavsni qog'oz kartochka bilan yoping: «bu quti — bitta son». Bola avval qutini topadi, keyin kartochkani ochadi."},
{h:"Uchta qo'shiluvchi",sum:"35 + 24 + □ = 94: ma'lumlarini birlashtiramiz 59 → 94 − 59 = 35.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>«Uchta sonning yig'indisi 94. Birinchisi 35, ikkinchisi 24. Uchinchisini toping.»</p>",
 btns:[phaser(P7)],
 after:"<p>Qo'shiluvchilar qancha bo'lsa ham qoida bir xil: <b>ma'lumlarini birlashtirib, yig'indidan ayiramiz</b>. Yoki ketma-ket ayirish ham mumkin: 94 − 35 − 24 = 35.</p>",
 q:{t:"45 + □ + 18 = 90. Kvadrat o'rniga qaysi son?",opts:["63","27","37","153"],ok:1,why:"45 + 18 = 63, 90 − 63 = 27.",hint:"Avval ma'lum qo'shiluvchilarni qo'shing.",full:"Ma'lumlari: 45 + 18 = 63. Noma'lum: 90 − 63 = 27. Tekshiramiz: 45 + 27 + 18 = 90 ✓."},
 tn:"Chizmani uchta rangli bo'lak qilib chizing; ma'lum ikkitasini bitta qavsga oling."},
{h:"Bilasizmi? «Al-jabr» nima degani",sum:"Al-Xorazmiy: «al-jabr» — to'ldirish, «al-muqobala» — ikkala tomondan bir xilini olib tashlash. «Algebra» shundan.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=1;P8[1]()},
 html:"<p>⭐ IX asrda vatandoshimiz <b>Muhammad al-Xorazmiy</b> «Al-jabr val-muqobala» kitobini yozdi. Unda tenglamani yechishning ikki amali bor. Ikkinchisini tarozida ko'ring:</p>",
 btns:[phaser(P8,'▶ Al-muqobala')],
 after:"<p><b>Al-jabr</b> — «to'ldirish, tiklash», <b>al-muqobala</b> — «qarama-qarshi qo'yish, tenglashtirish»: ikkala tomondagi bir xil narsani olib tashlash. Kitob nomidan butun dunyoda <b>«algebra»</b> so'zi paydo bo'lgan. Siz bugun al-Xorazmiy usulida ishladingiz!</p>",
 tn:"Bolalarga «algebra» so'zi bizning yurtdoshimiz kitobidan kelib chiqqanini aytib qo'ying — bu katta faxr va qiziqish uyg'otadi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li>Noma'lum <b>qo'shiluvchi</b> = yig'indi − ma'lum qo'shiluvchi: □ + 18 = 45 → 27.</li><li>Noma'lum <b>kamayuvchi</b> = ayirma + ayriluvchi: □ − 28 = 45 → 73.</li><li>Noma'lum <b>ayriluvchi</b> = kamayuvchi − ayirma: 63 − □ = 25 → 38.</li><li>Chizma: <b>butun noma'lum — qo'shamiz</b>, <b>qism noma'lum — ayiramiz</b>.</li><li>Tomonda ifoda bo'lsa — <b>avval hisoblang</b>.</li><li>Qavs ichida noma'lum — qavsni <b>bitta son</b> deb, tashqaridan ichkariga.</li><li>Har doim <b>tekshiring</b>: javobni o'rniga qo'ying.</li></ul></div>",
 tn:"Keyingi darsni «x − 25 = 25» (x = 50) savoli bilan boshlang: bolalar ko'pincha 0 deydi."}
];
var PROBS=[
{t:"x + 25 = 61. x nechaga teng?",o:["36","86","46","26"],k:0,s:"61 − 25 = 36."},
{t:"47 + x = 83. x nechaga teng?",o:["36","130","46","34"],k:0,s:"83 − 47 = 36."},
{t:"x − 19 = 54. x nechaga teng?",o:["73","35","63","45"],k:0,s:"Kamayuvchi = 54 + 19 = 73."},
{t:"72 − x = 38. x nechaga teng?",o:["34","110","44","36"],k:0,s:"Ayriluvchi = 72 − 38 = 34."},
{t:"x + 8 = 91 − 46. x nechaga teng?",o:["37","45","53","27"],k:0,s:"91 − 46 = 45, 45 − 8 = 37."},
{t:"38 + x = 29 + 56. x nechaga teng?",o:["47","85","57","123"],k:0,s:"29 + 56 = 85, 85 − 38 = 47."},
{t:"(27 + x) − 15 = 49. x nechaga teng?",o:["37","91","47","7"],k:0,s:"27 + x = 49 + 15 = 64, x = 64 − 27 = 37."},
{t:"83 − (x + 45) = 26. x nechaga teng?",o:["12","38","57","64"],k:0,s:"x + 45 = 83 − 26 = 57, x = 12."},
{t:"81 − (27 + x) = 38. x nechaga teng?",o:["16","43","6","54"],k:0,s:"27 + x = 81 − 38 = 43, x = 16."},
{t:"Uchta sonning yig'indisi 94. Birinchisi 35, ikkinchisi 24. Uchinchi son qaysi?",o:["35","34","36","59"],k:0,s:"35 + 24 = 59, 94 − 59 = 35."},
{t:"Tarozida: chapda x va 50, o'ngda 43 va 57. x nechaga teng?",o:["50","60","100","40"],k:0,s:"43 + 57 = 100, x = 100 − 50 = 50."},
{t:"O'ylagan sonimga 26 ni qo'shsam, 70 chiqdi. Qaysi sonni o'yladim?",o:["44","96","54","34"],k:0,s:"70 − 26 = 44."},
{t:"O'ylagan sonimdan 18 ni ayirsam, 37 qoldi. Qaysi sonni o'yladim?",o:["55","19","45","65"],k:0,s:"Kamayuvchi: 37 + 18 = 55."},
{t:"Savatda 64 ta olma bor edi. Bir nechtasi olingach, 29 ta qoldi. Nechta olma olindi?",o:["35","93","45","25"],k:0,s:"64 − □ = 29, □ = 64 − 29 = 35."},
{t:"y − 67 + 3 = 82 − 53. y nechaga teng?",o:["93","90","100","112"],k:0,s:"82 − 53 = 29. y − 67 + 3 = 29 → y − 67 = 26 → y = 93."},
{t:"Qaysi tenglamaning yechimi 20 ga teng?",o:["x + 15 = 35","x − 15 = 35","x − 20 = 35","35 − x = 25"],k:0,s:"x + 15 = 35 → x = 20. Qolganlarida: 50, 55, 10."},
{t:"a + 30 = 30 + 47. a nechaga teng?",o:["47","30","77","17"],k:0,s:"Qo'shiluvchilar o'rni almashgan: a = 47."},
{t:"100 − x = 63. x nechaga teng?",o:["37","163","47","27"],k:0,s:"100 − 63 = 37."},
{t:"(x − 12) + 20 = 50. x nechaga teng?",o:["42","18","62","38"],k:0,s:"x − 12 = 50 − 20 = 30, x = 30 + 12 = 42."},
{t:"x − 25 = 25. x nechaga teng?",o:["50","0","25","75"],k:0,s:"Kamayuvchi = 25 + 25 = 50."}
];
function PRACT_STAGE(){bqBar('butun',[{v:'qism',w:1},{v:'qism',w:1,col:C.b}]);bqMsg('Butun noma‘lum — qo‘shamiz, qism noma‘lum — ayiramiz')}
var PREP_DATA={teach:["Qism–butun g'oyasi: qo'shish — qismlar birlashishi, ayirish — butundan qism olish.","Noma'lum qo'shiluvchi, kamayuvchi, ayriluvchini topish qoidalari.","Tenglama — teng tarozi; avval ifodani hisoblash; javobni tekshirish.","Murakkab tur: qavs ichida noma'lum, uch qo'shiluvchi."],
 mist:["Noma'lum kamayuvchini ayirib topadi (x − 17 = 39 → 22).","Noma'lum ayriluvchini qo'shib topadi (80 − x = 47 → 127).","Qavsli tenglamada qavs qiymatini javob deb yozadi (57).","Tekshirmaydi."],
 need:["Oddiy tarozi va bir xil kubiklar (bo'lmasa — doskada chizma).","Qavsni yopish uchun kartochka."],
 board:["Chizma: <span class='w2'>[ 35 | ? ] = 60</span> → 60 − 35.","Tarozi: <span class='w2'>x + 50 = 43 + 57</span>.","<span class='w2'>□ − 28 = 45 → 45 + 28</span>.","<span class='w2'>63 − □ = 25 → 63 − 25</span>.","<span class='w2'>(27 + x) − 15 = 49 → 27 + x = 64</span>.","Tekshiruv qatori har doim."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
