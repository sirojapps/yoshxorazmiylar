
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G4',TITLE='3-sinf · Kalendar va hafta kunlari';
var G4D=['dushanba','seshanba','chorshanba','payshanba','juma','shanba','yakshanba'];
var G4M=[['yanvar',31],['fevral',28],['mart',31],['aprel',30],['may',31],['iyun',30],['iyul',31],['avgust',31],['sentabr',30],['oktabr',31],['noyabr',30],['dekabr',31]];
function g4wheel(a,b,lab){clear();var g=S.g,cx=180,cy=86,r=62;E('circle',{cx:cx,cy:cy,r:r,fill:'none',stroke:'#dde5ee','stroke-width':10},g);
 for(var i=0;i<7;i++){var an=-Math.PI/2+i*2*Math.PI/7,x=cx+r*Math.cos(an),y=cy+r*Math.sin(an),col=i===b?C.a:i===a?C.blue:'#fff';E('circle',{cx:x,cy:y,r:19,fill:col,stroke:C.line,'stroke-width':2},g);T(g,x,y+5,F3WD[i],{'font-size':13,'font-weight':800,fill:i===a||i===b?'#fff':(i>=5?C.bad:'#1d2b3a')})}
 T(g,cx,cy+5,lab||'7 kun',{'font-size':12,'font-weight':800,fill:'#33475b'})}
function g4go(n,done){S.g4b=(S.g4a+n)%7;g4wheel(S.g4a,S.g4b,'+'+n+' kun');f3calc(['Bugun <b>'+G4D[S.g4a]+'</b>. '+n+' kundan keyin — <b>'+G4D[S.g4b]+'</b>',n%7===0?'7 kundan keyin — yana o‘sha kun!':'Har 7 kunda hafta qaytadan boshlanadi'])
 S.g4a=S.g4b;mvK(done,3)}
function g4mon(sel){clear();var g=S.g;G4M.forEach(function(m,i){var x=14+i*28,h=(m[1]-26)*16,on=i===sel;E('rect',{x:x,y:120-h,width:24,height:h,rx:3,fill:on?C.a:m[1]===31?C.blue:m[1]===30?'#9fc7e8':'#e8b4a8'},g);T(g,x+12,116-h,String(m[1]),{'font-size':10,'font-weight':800,fill:'#33475b'});T(g,x+12,136,m[0].slice(0,3),{'font-size':10,'font-weight':700,fill:on?C.a:'#33475b'})});
 T(g,180,160,'31 kun — to‘q ko‘k, 30 kun — och ko‘k, fevral — 28 (yoki 29)',{'font-size':10,fill:'#3a4a5a'});f3calc([sel==null?'Oyni tanlang':'<b>'+G4M[sel][0]+'</b> — '+G4M[sel][1]+' kun'+(sel===1?' (kabisa yilda 29)':''),'Yilda 365 kun (kabisa yilda 366)'])}
function g4cal(hl,msg){clear();f3month(0,30,hl,function(d){if(d===19){var h={5:'#ffe2b8',12:'#ffe2b8',19:C.ok};g4cal(h);f3msg('✓ <b>19-sana</b> — 1-juma 5, 2-juma 12, 3-juma 19');S.g4ok&&S.g4ok()}else{var w=(d-1)%7;g4cal({},null);f3msg('<span style="color:#c0392b">✗</span> '+d+'-sana — '+G4D[w]+'. Avval 1-jumani toping')}},{y0:30});if(msg)f3calc(msg)}
var G4P4=[function(){g4wheel(5,null,'kecha');f3calc(['«Kecha shanba bo‘lgan. 5 kundan keyin qaysi kun?»'])},function(){g4wheel(6,null,'bugun');f3calc(['Kecha shanba → <b>bugun yakshanba</b>. Bugundan sanaymiz!'])},function(){g4wheel(6,4,'+5 kun');f3calc(['Yakshanba + 5: Du, Se, Ch, Pa, <b>Ju</b> — juma','Xato: shanbadan sanasak — payshanba chiqadi'])}];
var G4P5=[function(){clear();f3month(5,31,{1:C.blue},null,{y0:30});f3calc(['1-yanvar — shanba. 31-yanvar qaysi kun?'])},function(){clear();f3month(5,31,{1:C.blue,8:'#d6e8f8',15:'#d6e8f8',22:'#d6e8f8',29:'#d6e8f8'},null,{y0:30});f3calc(['Har 7 kunda shanba qaytadi: 1, 8, 15, 22, <b>29</b>'])},function(){clear();f3month(5,31,{1:C.blue,29:'#d6e8f8',30:'#ffe2b8',31:C.a},null,{y0:30});f3calc(['29 — shanba, 30 — yakshanba, 31 — <b>dushanba</b>','Hisob bilan: 31 − 1 = 30 kun = 4 hafta + 2 kun'])}];
var G4P6=[function(){clear();f3month(5,30,{12:C.blue,29:C.blue},null,{y0:30});f3calc(['12-sanadan 29-sanagacha, ikkala kun ham kiradi. Necha kun?'])},
 function(){var h={};for(var d=12;d<=29;d++)h[d]='#d6e8f8';h[12]=C.blue;h[29]=C.blue;clear();f3month(5,30,h,null,{y0:30});f3calc(['29 − 12 = 17 — bu oraliqlar. Kunlar esa bittaga ko‘p: <b>18 kun</b>'])},
 function(){var h={};for(var d=12;d<=29;d++)h[d]='#d6e8f8';[12,15,19,22,26,29].forEach(function(d){h[d]=C.a});clear();f3month(5,30,h,null,{y0:30});f3calc(['Har kuni kechqurun: 18 ta; Ch va Sh tushlikda ham: 12, 15, 19, 22, 26, 29 — 6 ta','Jami spektakl: 18 + 6 = <b>24</b>'])}];
var G4P7=[function(){g4mon(2);f3calc(['Iroda mart oyida 186 betli kitobni o‘qidi, har kuni bir xil bet.','Avval: martda necha kun?'])},function(){g4mon(2);f3calc(['Mart — <b>31 kun</b> (30 emas!)','186 : 31 = <b>6</b> bet har kuni'])}];
function g4pool(st){clear();var h={};for(var d=1;d<=30;d+=3)h[d]='#ffe2b8';if(st>=1){[1,8,15,22,29].forEach(function(d){h[d]=h[d]?C.ok:'#d6e8f8'})}h[1]=C.blue;f3month(0,30,h,null,{y0:30})}
var G4P8=[function(){g4pool(0);f3calc(['Ali har 3 kunda basseynga boradi. 1-sentabr (dushanba) bordi','To‘q sariq — basseyn kunlari: 1, 4, 7, 10, …'])},function(){g4pool(1);f3calc(['Dushanbalar: 1, 8, 15, 22, 29 (har 7 kunda)','Ikkalasi bir vaqtda: 1 dan keyin — <b>22-sentabr</b> (3 · 7 = 21 kundan keyin)'])}];
var STEPS=[
{h:"Hafta — 7 kunlik aylana",sum:"Haftada 7 kun: dushanba … yakshanba. 7 kundan keyin yana o'sha kun.",a:"m01",
 start:function(){S.g4a=0;g4wheel(0,null);f3calc(['Bugun dushanba. Tugmalarni bosing'])},fin:function(){g4wheel(0,0,'+7 kun');f3calc(['7 kundan keyin — yana o‘sha kun!'])},
 html:"<p>Hafta kunlari aylana bo'ylab takrorlanadi. Tugmalarni bosib, kunlar qanday almashishini kuzating (kamida 3 marta):</p>",
 btns:[["+1 kun",function(c,done){g4go(1,done)}],["+3 kun",function(c,done){g4go(3,done)}],["+7 kun",function(c,done){g4go(7,done)}]],g3:1,
 after:"<p>Haftaning tartibi: <b>dushanba, seshanba, chorshanba, payshanba, juma, shanba, yakshanba</b>. 7, 14, 21 … kundan keyin — <b>yana o'sha kun</b>.</p>",
 q:{t:"Bugun seshanba. 14 kundan keyin qaysi kun?",opts:["Seshanba","Chorshanba","Dushanba","Payshanba"],ok:0,why:"14 = 2 hafta — kun o'zgarmaydi.",hint:"14 kun — necha hafta?",full:"14 kun = 2 · 7, ya'ni roppa-rosa 2 hafta. Demak yana seshanba."},
 tn:"7 ta bolaga hafta kunlari kartochkasini bering, doira bo'lib tursin — «sakrash» o'yini."},
{h:"Oylar va kunlar",sum:"Yilda 12 oy, 365 kun. 31 kunlik oylar: yanvar, mart, may, iyul, avgust, oktabr, dekabr. Fevral — 28 (kabisa yilda 29).",a:"m02",
 start:function(){g4mon(null)},fin:function(){g4mon(1)},
 html:"<p>Oylarni bosib, unda necha kun borligini ko'ring (kamida 3 tasi):</p>",
 btns:G4M.map(function(m,i){return [m[0],function(c,done){g4mon(i);mvK(done,3)}]}),g3:1,
 after:"<p><b>Musht usuli:</b> qo'lni musht qiling. Bo'rtgan suyak — 31 kun, chuqurcha — 30 (fevral — 28/29). Yanvar — suyak, fevral — chuqurcha, mart — suyak … iyul — oxirgi suyak, avgust — yana birinchi suyakdan.</p>",
 q:{t:"Qaysi oyda 30 kun bor?",opts:["avgust","noyabr","dekabr","iyul"],ok:1,why:"Aprel, iyun, sentabr, noyabr — 30 kun.",hint:"Musht usulida chuqurchaga to'g'ri keladigan oylar.",full:"30 kunlik oylar: aprel, iyun, sentabr, noyabr. Iyul va avgust — ikkalasi ham 31 kun (yonma-yon ikkita 31)."},
 tn:"Musht usulini doskada chizing — bu butun dunyoda qo'llanadigan oson eslab qolish usuli."},
{h:"Kalendardan sana topish",sum:"1-sana dushanba bo'lsa, jumalar: 5, 12, 19, 26. Uchinchi juma — 19.",a:"m03",
 start:function(){g4cal({},['1-sana — dushanba. <b>Uchinchi juma</b>ni bosing'])},fin:function(){g4cal({5:'#ffe2b8',12:'#ffe2b8',19:C.ok},['Uchinchi juma — <b>19-sana</b>'])},
 html:"<p>Kalendarda oyning 1-sanasi <b>dushanba</b>. Shu oyning <b>uchinchi jumasi</b>ni toping va bosing:</p>",
 act:function(c,done){S.g4ok=done},
 after:"<p>Birinchi juma — 5, keyingilari 7 qo'shib: 12, 19, 26. Kalendarda bir ustun — bitta hafta kuni, pastga tushsak <b>+7</b>.</p>",
 q:{t:"Oyning 1-sanasi dushanba. Shu oyning ikkinchi yakshanbasi qaysi sana?",opts:["14","7","8","15"],ok:0,why:"1-yakshanba 7, ikkinchisi 14.",hint:"Dushanbadan yakshanbagacha nechta kun?",full:"Dushanba 1 bo'lsa, yakshanba 7. Ikkinchi yakshanba 7 + 7 = 14. «8» — keyingi dushanba bilan adashtirish."},
 tn:"Devor kalendaridan foydalaning: bolalar o'z tug'ilgan kunlari qaysi hafta kuniga to'g'ri kelishini topsin."},
{h:"Tuzoq: «kecha» va «ertaga»",sum:"Kecha shanba → bugun yakshanba → 5 kundan keyin juma.",a:"m04",
 start:function(){startPh(G4P4)},fin:function(){S.ph=2;G4P4[2]()},
 html:"<p><i>«Kecha shanba bo'lgan bo'lsa, 5 kundan keyin haftaning qaysi kuni bo'ladi?»</i></p>",btns:[phaser(G4P4)],
 after:"<p>«5 kundan keyin» — <b>bugundan</b> sanaladi. Shuning uchun avval bugun qaysi kunligini topamiz.</p>",
 q:{t:"Ertaga chorshanba. 3 kun oldin qaysi kun edi?",opts:["Shanba","Yakshanba","Juma","Dushanba"],ok:0,why:"Bugun seshanba; 3 kun oldin — shanba.",hint:"Avval bugungi kunni toping.",full:"Ertaga chorshanba → bugun seshanba. Orqaga: dushanba (1), yakshanba (2), shanba (3). «Yakshanba» — chorshanbadan 3 kun orqaga sanash."},
 tn:"«Kecha, bugun, ertaga, indinga» so'zlarini doskada vaqt nuri bilan ko'rsating."},
{h:"Tuzoq: oy oxiridagi kun",sum:"1-yanvar shanba: 29 ham shanba, 31-yanvar — dushanba (30 = 4 · 7 + 2).",a:"m05",
 start:function(){startPh(G4P5)},fin:function(){S.ph=2;G4P5[2]()},
 html:"<p><i>«1-yanvar shanba kuniga to'g'ri keldi. 31-yanvar haftaning qaysi kuni?»</i> Bittalab sanash uzoq — 7 lik sakraymiz!</p>",btns:[phaser(G4P5)],
 after:"<p>Usul: oraliq <b>31 − 1 = 30 kun</b>. 30 ichida 4 ta to'liq hafta (28) va <b>2 kun</b> qoladi. Shanba + 2 = dushanba.</p>",
 q:{t:"1-mart payshanba. 20-mart qaysi kun?",opts:["Seshanba","Chorshanba","Payshanba","Dushanba"],ok:0,why:"20 − 1 = 19 = 2 · 7 + 5; payshanba + 5 = seshanba.",hint:"Payshanbalar: 1, 8, 15, … 20 ga nechta kun qoladi?",full:"Payshanbalar: 1, 8, 15. 15 dan 20 gacha 5 kun: Ju, Sh, Ya, Du, Se. 20-mart — seshanba."},
 tn:"Bu — qoldiqli bo'lish bilan bog'lanish: 30 : 7 = 4 (qoldiq 2)."},
{h:"Tuzoq: «ikkala kun ham kiradi»",sum:"12-dan 29-gacha (ikkalasi ham) — 18 kun. Ch va Sh kunlari ikkita spektakl: jami 24.",a:"m06",
 start:function(){startPh(G4P6)},fin:function(){S.ph=2;G4P6[2]()},
 html:"<p><i>«Teatrda 12-sanadan (chorshanba) 29-sanagacha (shanba), ikkala kun ham kiradi, har kuni kechqurun spektakl qo'yiladi; chorshanba va shanba kunlari tushlikda ham. Jami nechta spektakl?»</i></p>",btns:[phaser(G4P6)],
 after:"<p>Kunlarni sanashda <b>29 − 12 + 1 = 18</b>. «+1» — chunki birinchi kun ham kiradi (xuddi 1 dan 5 gacha 5 ta son borligi kabi).</p>",
 q:{t:"Bayram ta'tili 5-sanadan 12-sanagacha (ikkala kun ham kiradi). Necha kun dam olishadi?",opts:["8","7","6","17"],ok:0,why:"12 − 5 + 1 = 8.",hint:"5, 6, 7, … 12 — sanab chiqing.",full:"5, 6, 7, 8, 9, 10, 11, 12 — 8 kun. 12 − 5 = 7 — bu oraliqlar soni, kunlar bittaga ko'p."},
 tn:"Bolalar barmoq bilan sanasin: «5-dan 12-gacha» — sanalar nechta?"},
{h:"Tuzoq: oyning uzunligi",sum:"Martda 31 kun: 186 : 31 = 6 bet har kuni.",a:"m07",
 start:function(){startPh(G4P7)},fin:function(){S.ph=1;G4P7[1]()},
 html:"<p><i>«Iroda mart oyida 186 betli kitobni o'qidi, har kuni bir xil sondagi bet. Har kuni necha bet o'qigan?»</i> Masalada kunlar soni yozilmagan!</p>",btns:[phaser(G4P7)],
 after:"<p>Yashirin ma'lumot: «mart» — <b>31 kun</b>. Agar 30 deb olsak, 186 : 30 butun chiqmaydi — bu ham ishora!</p>",
 q:{t:"Fevral oyida (kabisa emas) har kuni 3 tadan olma yeyildi. Jami nechta?",opts:["84","90","87","93"],ok:0,why:"28 · 3 = 84.",hint:"Oddiy yilda fevralda necha kun?",full:"Oddiy yilda fevral 28 kun: 28 · 3 = 84. «87» — 29 kun (kabisa yil), «90» — 30 kun deb olish."},
 tn:"Bolalar o'z tug'ilgan oyida necha kun borligini musht usulida topsin."},
{h:"Tuzoq: ikki takrorlanish",sum:"Har 3 kunda va har 7 kunda (dushanba) — birga 21 kundan keyin: 1 → 22-sentabr.",a:"m08",
 start:function(){startPh(G4P8)},fin:function(){S.ph=1;G4P8[1]()},
 html:"<p><i>«Ali har 3 kunda basseynga boradi. 1-sentabr dushanba kuni bordi. Qaysi sanada u yana dushanba kuni basseynga boradi?»</i></p>",btns:[phaser(G4P8)],
 after:"<p>Basseyn kunlari — 3 lik qadam, dushanbalar — 7 lik qadam. Ikkalasi <b>3 · 7 = 21</b> kundan keyin uchrashadi: 1 + 21 = 22-sentabr.</p>",
 q:{t:"Avtobus har 2 kunda, poyezd har 3 kunda keladi. Bugun ikkalasi keldi. Necha kundan keyin yana ikkalasi bir kunda keladi?",opts:["6","5","3","2"],ok:0,why:"2 va 3 ning eng kichik umumiy karralisi — 6.",hint:"2, 4, 6, 8 … va 3, 6, 9 … — birinchi umumiy son?",full:"Avtobus: 2, 4, 6; poyezd: 3, 6. Birinchi umumiy — 6. «5» — 2 + 3 qo'shish xatosi."},
 tn:"Kalendarda ikki xil rang bilan belgilatib ko'ring — bolalar uchrashish kunini o'zi topadi."},
{h:"Bilasizmi? «Hafta» so'zi",sum:"«Hafta» forscha «haft» — yetti so'zidan; kabisa yil har 4 yilda keladi.",a:"m09",
 start:function(){g4wheel(null,null,'haft = 7');f3msg('«Hafta» — forscha «haft» (yetti) so‘zidan')},fin:function(){g4wheel(null,null,'haft = 7');f3msg('«Hafta» — forscha «haft» (yetti) so‘zidan')},
 html:"<p>📖 <b>«Hafta»</b> so'zi fors tilidagi <b>«haft» — «yetti»</b> so'zidan olingan: haftada 7 kun. «Shanba», «yakshanba», «dushanba» nomlari ham fors tilidan kelgan.</p><p>📅 Yer Quyosh atrofini taxminan <b>365 kun va 6 soatda</b> aylanadi. Ortib qolgan 6 soatlar 4 yilda bir sutkaga yig'iladi — shuning uchun har <b>4 yilda bir</b> marta <b>kabisa yil</b> bo'ladi va fevralda 29 kun bo'ladi.</p>",
 tn:"Bolalardan so'rang: 29-fevralda tug'ilgan odam tug'ilgan kunini qanday nishonlaydi?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g4mon(null)},fin:function(){g4mon(null)},
 html:"<div class='memo'><ul><li>Haftada <b>7 kun</b>; 7, 14, 21 … kundan keyin — yana o'sha kun.</li><li>Yilda <b>12 oy, 365 kun</b> (kabisa yilda 366). Fevral — 28/29.</li><li>30 kunlik: aprel, iyun, sentabr, noyabr; qolganlari 31 (musht usuli).</li><li>Kalendarda pastga — <b>+7</b>.</li><li>«…kundan keyin» — <b>bugundan</b> sanaymiz.</li><li>«Ikkala kun ham kiradi»: oxirgi − birinchi <b>+ 1</b>.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring; sinf kalendarini har kuni bolalar to'ldirsin."}
];
var PROBS=[
{t:"Haftada necha kun bor?",o:["7","5","6","10"],k:0,s:"Du–Ya."},
{t:"Bugun payshanba. Ertaga qaysi kun?",o:["Juma","Chorshanba","Shanba","Seshanba"],k:0,s:"Payshanbadan keyin juma."},
{t:"Qaysi oyda 31 kun bor?",o:["avgust","aprel","iyun","noyabr"],k:0,s:"Iyul va avgust — 31."},
{t:"Oddiy yilda necha kun bor?",o:["365","366","360","356"],k:0,s:"Kabisa yilda 366."},
{t:"Bugun chorshanba. 7 kundan keyin qaysi kun?",o:["Chorshanba","Payshanba","Seshanba","Juma"],k:0,s:"7 kun — bir hafta."},
{t:"3 hafta necha kun?",o:["21","10","24","30"],k:0,s:"3 · 7."},
{t:"Kecha shanba bo'lgan. 5 kundan keyin qaysi kun?",o:["Juma","Payshanba","Shanba","Yakshanba"],k:0,s:"Bugun yakshanba + 5."},
{t:"Oyning 1-sanasi dushanba. Uchinchi juma qaysi sana?",o:["19","21","15","17"],k:0,s:"5, 12, 19."},
{t:"1-yanvar shanba. 31-yanvar qaysi kun?",o:["Dushanba","Shanba","Yakshanba","Seshanba"],k:0,s:"30 = 28 + 2."},
{t:"Iroda mart oyida 186 betli kitobni har kuni bir xil betdan o'qidi. Har kuni necha bet?",o:["6","62","7","5"],k:0,s:"186 : 31."},
{t:"5-sanadan 12-sanagacha (ikkala kun ham kiradi) necha kun?",o:["8","7","6","17"],k:0,s:"12 − 5 + 1."},
{t:"Teatrda 12-sanadan (chorshanba) 29-sanagacha (shanba), ikkalasi kiradi, har kuni kechqurun, Ch va Sh tushlikda ham spektakl. Jami?",o:["24","22","21","23"],k:0,s:"18 + 6."},
{t:"Ertaga chorshanba. 3 kun oldin qaysi kun edi?",o:["Shanba","Yakshanba","Juma","Dushanba"],k:0,s:"Bugun seshanba − 3."},
{t:"1-mart payshanba. 20-mart qaysi kun?",o:["Seshanba","Chorshanba","Payshanba","Dushanba"],k:0,s:"19 = 14 + 5."},
{t:"Oyning 1-sanasi dushanba. Shu oyda nechta dushanba bor, agar oyda 30 kun bo'lsa?",o:["5","4","6","3"],k:0,s:"1, 8, 15, 22, 29."},
{t:"Oddiy yilda fevral oyida har kuni 3 tadan olma yeyildi. Jami?",o:["84","87","90","93"],k:0,s:"28 · 3."},
{t:"Yoz oylari (iyun, iyul, avgust) jami necha kun?",o:["92","90","91","93"],k:0,s:"30 + 31 + 31."},
{t:"Ali har 3 kunda basseynga boradi. 1-sentabr (dushanba) bordi. Yana qachon dushanba kuni boradi?",o:["22-sentabr","8-sentabr","15-sentabr","21-sentabr"],k:0,s:"21 kundan keyin."},
{t:"Avtobus har 2 kunda, poyezd har 3 kunda keladi. Bugun ikkalasi keldi. Necha kundan keyin yana birga keladi?",o:["6","5","3","2"],k:0,s:"2 va 3 ga bo'linadigan eng kichik son 6."},
{t:"Bugun 25-may, yakshanba. 1-iyun haftaning qaysi kuni?",o:["Yakshanba","Shanba","Dushanba","Juma"],k:0,s:"Mayda 31 kun: 25 + 7 = 32 → 1-iyun, yana yakshanba."}
];
function PRACT_STAGE(){S.g4a=0;g4wheel(0,null)}
var PREP_DATA={teach:["Hafta kunlari tartibi va 7 kunlik takrorlanish.","Oylar va ulardagi kunlar soni (musht usuli), kabisa yil.","Kalendar bilan ishlash: ustun — bir hafta kuni, pastga +7.","Tuzoqlar: «kecha/ertaga», oy oxiri, «ikkala kun ham kiradi», ikki takrorlanish."],
 mist:["«5 kundan keyin»ni kechagi kundan sanaydi.","12-dan 29-gacha kunlarni 17 deb hisoblaydi (+1 ni unutadi).","Hamma oylarni 30 kun deb oladi.","7 kunlik qadam o'rniga bittalab sanab adashadi."],
 need:["Devor kalendari yoki chop etilgan oy jadvali (har bolaga).","Hafta kunlari kartochkalari (7 ta)."],
 board:["<span class='w2'>Du Se Ch Pa Ju Sh Ya</span> — aylana.","<span class='w2'>31 − 1 = 30 = 4 · 7 + 2</span>.","<span class='w2'>29 − 12 + 1 = 18</span>.","Musht usuli: <span class='w2'>suyak — 31, chuqurcha — 30/28</span>."]};
