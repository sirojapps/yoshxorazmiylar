// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4G3',TITLE='4-sinf · Vaqt: asr, yil, oy, sutka; vaqtni hisoblash';
// asrlar chizig'i
function g3cent(y){clear();var g=S.g,b0=(y&&y<1701)?Math.floor((y-1)/100):17,cs=[0,1,2,3].map(function(i){var c=b0+i;return [c+1,c*100+1]}),x0=20,w=80;
 T(g,180,22,'Har asr: …01-yildan …00-yilgacha (100 yil)',{'font-size':12,'font-weight':800,fill:C.blue});
 cs.forEach(function(c,i){var hit=y&&y>=c[1]&&y<=c[1]+99;E('rect',{x:x0+i*w,y:50,width:w-4,height:44,rx:8,fill:hit?C.hi:'#eef4fb',stroke:hit?C.a2:C.blue,'stroke-width':hit?2.6:1.2},g);
  T(g,x0+i*w+38,70,c[0]+'-asr',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});T(g,x0+i*w+38,86,c[1]+'–'+(c[1]+99),{'font-size':10.5,'font-weight':700,fill:'#5b6b7b'})});
 if(y){var i=cs.findIndex(function(c){return y>=c[1]&&y<=c[1]+99});if(i>=0){var px=x0+i*w+4+(y-cs[i][1])/100*(w-12);E('path',{d:'M'+px+' 98 l-7 12 h14 z',fill:C.bad},g);T(g,px,128,y+'-yil',{'font-size':14,'font-weight':800,fill:C.bad})}}}
function g3fist(part){clear();var g=S.g,M=['Yan','Fev','Mar','Apr','May','Iyun','Iyul','Avg','Sen','Okt','Noy','Dek'],D=[31,'28(29)',31,30,31,30,31,31,30,31,30,31],st=part===1?0:7,n=part===1?7:5,x0=40,dx=280/(n-1);
 var d='M'+(x0-14)+' 110';for(var i=0;i<n;i++){var x=x0+i*dx,top=i%2===0;d+=' Q'+x+' '+(top?40:120)+' '+(x+dx/2)+' '+(top?110:110)}
 E('path',{d:'M'+(x0-20)+' 140 L'+(x0-20)+' 100 '+Array.from({length:n},function(_,i){var x=x0+i*dx;return (i%2===0?'Q'+x+' 40 ':'Q'+x+' 120 ')+(x+dx/2)+' 96'}).join(' ')+' L'+(x0+(n-1)*dx+20)+' 140 Z',fill:'#f6d2b0',stroke:'#c58b5a','stroke-width':2},g);
 for(var j=0;j<n;j++){var m=st+j,x=x0+j*dx,big=D[m]===31;T(g,x,big?58:118,M[m],{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,x,big?32:150,String(D[m]),{'font-size':13,'font-weight':800,fill:big?C.bad:C.blue})}
 T(g,330,165,part===1?'Yanvar → Iyul':'Avgust → Dekabr',{'font-size':10,'font-weight':700,fill:'#7a6a50','text-anchor':'end'})}
// vaqt chizig'i: soatlar 8..12
function g3tl(k){clear();var g=S.g,x0=30,x1=330,h0=8.5,h1=11.5;function X(h){return x0+(h-h0)/(h1-h0)*(x1-x0)}
 E('line',{x1:x0,y1:100,x2:x1,y2:100,stroke:'#3a4a5a','stroke-width':2},g);[9,10,11].forEach(function(h){E('line',{x1:X(h),y1:94,x2:X(h),y2:106,stroke:'#3a4a5a','stroke-width':2},g);T(g,X(h),122,h+':00',{'font-size':11,'font-weight':700})});
 var a=8.75,b=11+1/3;E('circle',{cx:X(a),cy:100,r:5,fill:C.ok},g);T(g,X(a),140,'8:45',{'font-size':13,'font-weight':800,fill:C.ok});E('circle',{cx:X(b),cy:100,r:5,fill:C.bad},g);T(g,X(b),140,'11:20',{'font-size':13,'font-weight':800,fill:C.bad});
 var arcs=[[a,9,'+15 min',C.a2],[9,11,'+2 soat',C.blue],[11,b,'+20 min',C.a2]];
 for(var i=0;i<k&&i<3;i++){var r=arcs[i],xa=X(r[0]),xb=X(r[1]);E('path',{d:'M'+xa+' 96 Q'+((xa+xb)/2)+' '+(96-40-(i===1?14:0))+' '+xb+' 96',fill:'none',stroke:r[3],'stroke-width':2.4},g);T(g,(xa+xb)/2,(i===1?52:64),r[2],{'font-size':12,'font-weight':800,fill:r[3]})}
 if(k>=4)T(g,180,26,'15 min + 2 soat + 20 min = 2 soat 35 min',{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
var P5=[function(){g3tl(0);calc(['8:45 dan 11:20 gacha qancha vaqt o‘tdi?'])},function(){g3tl(1);calc(['8:45 → 9:00: <b>15 min</b> (yaxlit soatgacha)'])},function(){g3tl(2);calc(['15 min','9:00 → 11:00: <b>2 soat</b>'])},function(){g3tl(4);calc(['11:00 → 11:20: <b>20 min</b>','Jami: 15 min + 2 soat + 20 min = <b>2 soat 35 min</b>'])}];
function g3days(mode){clear();var g=S.g,x0=24;T(g,180,26,'May',{'font-size':14,'font-weight':800,fill:C.blue});
 for(var d=1;d<=12;d++){var x=x0+(d-1)*26.5,on=d>=3&&d<=10;E('rect',{x:x,y:48,width:24,height:30,rx:5,fill:on?(mode?C.hi:'#ffe9c7'):'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?1.8:1},g);T(g,x+12,68,String(d),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});
  if(mode===2&&on)T(g,x+12,98,String(d-2),{'font-size':12,'font-weight':800,fill:C.ok})}
 if(mode===1){T(g,180,120,'10 − 3 = 7 … lekin 3-may ham kiradi!',{'font-size':13,'font-weight':800,fill:C.bad})}
 if(mode===2){T(g,180,128,'Sanab chiqdik: 8 kun  (10 − 3 + 1 = 8)',{'font-size':13,'font-weight':800,fill:C.ok})}}
function g3ck(h,m,t){clear();g4m('Siferblatda: <b>'+t+'</b>');g4clock(h,m,110,84,62,'');var g=S.g;T(g,262,64,t,{'font-size':26,'font-weight':800,fill:'#1d2b3a'});var hh=h%12===0?12:h%12;T(g,262,100,(h<5?'tungi':h<12?'ertalabki':h<17?'kunduzgi':h<21?'kechki':'kechki')+' '+hh+':'+pad(m),{'font-size':13,'font-weight':800,fill:C.a2});T(g,262,122,h>=12?t.split(':')[0]+' − 12 = '+(h-12):'12 dan kichik',{'font-size':11,'font-weight':700,fill:'#5b6b7b'})}
var P3=[function(){clear();var g=S.g;E('circle',{cx:180,cy:90,r:20,fill:'#ffd24d',stroke:'#e0a800','stroke-width':2},g);E('ellipse',{cx:180,cy:90,rx:140,ry:56,fill:'none',stroke:'#9ab','stroke-dasharray':'5 4'},g);E('circle',{cx:320,cy:90,r:10,fill:'#5aa9e6'},g);T(g,180,24,'Yer Quyosh atrofida ≈ 365 kun 6 soatda aylanadi',{'font-size':12,'font-weight':800,fill:C.blue});calc(['Kalendar yilida esa 365 kun. 6 soat «ortib qoladi»'])},
 function(){P3[0]();calc(['1 yil: +6 soat','4 yil: 6 · 4 = <b>24 soat = 1 sutka</b>'])},
 function(){P3[0]();calc(['Har 4 yilda 1 kun qo‘shiladi: 29-fevral','Bu yil — <b>kabisa yili</b>: 366 kun. Yil soni 4 ga bo‘linadi: 2024, 2028…'])}];
var P8=[function(){g3cent(1483);calc(['Zahiriddin Muhammad Bobur 1483-yilda tug‘ilgan.','2026-yilda tavalludiga necha yil to‘ladi?'])},
 function(){g3cent(1483);calc(['2026 − 1483 = <b>543 yil</b>'])},
 function(){g3cent(1483);calc(['2026 − 1483 = 543 yil','1483 → 14 + 1 = <b>15-asr</b>'])}];
var STEPS=[
{h:"Vaqt birliklari",sum:"1 asr = 100 yil, 1 yil = 12 oy, 1 sutka = 24 soat, 1 soat = 60 min, 1 min = 60 s.",a:"m01",
 start:function(){g4lad(['sutka','soat','min','s'],[24,60,60],[],null,'Kichik vaqt birliklari');g4m('Tugmalarni bosing')},fin:function(){g4lad(['sutka','soat','min','s'],[24,60,60],[0,2],[0,2],'Kichik vaqt birliklari');g4m('1 sutka = 24 · 60 = 1440 min')},
 html:"<p>Vaqt birliklari 10 talab emas — <b>60, 24, 12, 100</b> talab bog'langan. Shuning uchun ehtiyot bo'lamiz:</p>",
 btns:[["asr → yil → oy",function(c,done){g4lad(['asr','yil','oy'],[100,12],[0,2],[0,2],'Katta vaqt birliklari');g4m('1 asr = 100 yil · 1 yil = 12 oy → 1 asr = <b>1200 oy</b>');mvK(done,3)}],["sutka → soat",function(c,done){g4lad(['sutka','soat','min','s'],[24,60,60],[0,1],[0,1],'Kichik vaqt birliklari');g4m('1 sutka = <b>24 soat</b> (kun + tun)');mvK(done,3)}],["soat → s",function(c,done){g4lad(['sutka','soat','min','s'],[24,60,60],[1,3],[1,3],'Kichik vaqt birliklari');g4m('1 soat = 60 min = 60 · 60 = <b>3600 s</b>');mvK(done,3)}]],g3:1,
 after:"<p>Asosiy bog'lanishlar: <b>1 asr = 100 yil</b>, <b>1 yil = 12 oy = 365 (366) kun</b>, <b>1 hafta = 7 kun</b>, <b>1 sutka = 24 soat</b>, <b>1 soat = 60 min</b>, <b>1 min = 60 s</b>.</p>",
 q:{t:"3 sutka necha soat?",opts:["36 soat","72 soat","300 soat","60 soat"],ok:1,why:"24 · 3 = 72 soat.",hint:"1 sutka necha soat?",full:"1 sutka = 24 soat, demak 3 sutka = 24 · 3 = 72 soat. «300» — sutkani 100 soat deb olish, «36» — 12 soat deb olish (faqat kunduz)."},
 tn:"Sekundomer bilan 1 minutda bolalar necha marta chapak chalishini sanang — «sekund» va «minut» ni his qilish uchun."},
{h:"Bu yil qaysi asrga tegishli?",sum:"1991 → 20-asr, 2000 → 20-asr, 2026 → 21-asr. Asr …01-yildan boshlanadi.",a:"m02",
 start:function(){g3cent(0);g4m('Yilni bosing va uning asrini toping')},fin:function(){g3cent(2000);g4m('2000-yil — 20-asrning oxirgi yili')},
 html:"<p>1-asr 1-yildan 100-yilgacha bo'lgan. Shuning uchun har asr <b>…01-yil</b>dan boshlanib, <b>…00-yil</b>da tugaydi. Yillarni bosing:</p>",
 btns:[["1991",function(c,done){g3cent(1991);g4m('1991 → 19 + 1 = <b>20-asr</b>');mvK(done,3)}],["2000",function(c,done){g3cent(2000);g4m('2000 — oxiri 00: 20-asrning <b>oxirgi</b> yili (21 emas!)');mvK(done,3)}],["2026",function(c,done){g3cent(2026);g4m('2026 → 20 + 1 = <b>21-asr</b>');mvK(done,3)}]],g3:1,
 after:"<p>Qoida: yilning oxirgi ikki raqamini olib tashlang va <b>1 qo'shing</b> (1991 → 19 + 1 = 20). Faqat yil <b>00</b> bilan tugasa, 1 qo'shilmaydi: 1900 — 19-asr, 2000 — 20-asr.</p>",
 q:{t:"1483-yil qaysi asr?",opts:["14-asr","15-asr","16-asr","148-asr"],ok:1,why:"14 + 1 = 15-asr.",hint:"Oxirgi ikki raqamni olib tashlab, 1 qo'shing.",full:"1483 → 14 + 1 = 15. 15-asr 1401-yildan 1500-yilgacha. «14-asr» — 1 ni qo'shishni unutish."},
 tn:"Doskaga «asrlar lentasi» chizing va bolalar tug'ilgan yilini, ota-onasi tug'ilgan yilini belgilasin."},
{h:"Kabisa yili",sum:"Yer Quyosh atrofini ≈ 365 kun 6 soatda aylanadi; 4 yilda +1 kun → 29-fevral, 366 kun.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Nega ba'zi yillarda fevral 29 kun? Bosqichlarni bosing:</p>",
 btns:[phaser(P3)],
 after:"<p>Yil soni <b>4 ga bo'linsa</b> — odatda kabisa yili: 366 kun, fevral 29 kun. Oddiy yil — 365 kun, fevral 28 kun.</p>",
 q:{t:"Qaysi yil kabisa yili?",opts:["2026","2027","2028","2030"],ok:2,why:"2028 : 4 = 507, qoldiqsiz.",hint:"Yil soni 4 ga qoldiqsiz bo'linishi kerak.",full:"2028 : 4 = 507 — qoldiqsiz bo'linadi. 2026 va 2030 — juft, lekin 4 ga bo'linmaydi (qoldiq 2). «Juft bo'lsa kabisa» degan fikr xato."},
 tn:"Bolalardan 29-fevralda tug'ilgan odam tug'ilgan kunini qanday nishonlashini so'rang — mavzuga qiziqish uyg'otadi."},
{h:"Oylarda nechta kun? Musht qoidasi",sum:"Musht suyagi — 31 kun, chuquri — 30 kun (fevral 28 (29)). Iyul va avgust — ikkalasi 31.",a:"m04",
 start:function(){g3fist(1);g4m('Mushtingizni tuting va suyaklarini sanang')},fin:function(){g3fist(2);g4m('Iyul va Avgust — ketma-ket ikki «suyak»: 31 + 31')},
 html:"<p>Mushtingizni tuting. Suyak bo'rtig'i — <b>31 kun</b>, orasidagi chuqurcha — <b>30 kun</b> (fevral — 28 yoki 29). Ikkala qismini ko'ring:</p>",
 btns:[["Yanvar → Iyul",function(c,done){g3fist(1);g4m('Yanvar 31, Fevral 28 (29), Mart 31, Aprel 30, May 31, Iyun 30, <b>Iyul 31</b>');mvK(done,2)}],["Avgust → Dekabr",function(c,done){g3fist(2);g4m('Yana boshidan: <b>Avgust 31</b>, Sentyabr 30, Oktyabr 31, Noyabr 30, Dekabr 31');mvK(done,2)}]],g2:1,
 after:"<p>Iyuldan keyin yana birinchi suyakdan boshlaymiz — shuning uchun <b>iyul ham, avgust ham 31 kun</b>. Yilda 7 ta oy 31 kunlik, 4 ta oy 30 kunlik, fevral 28 (29) kun.</p>",
 q:{t:"Iyul va avgust — jami nechta kun?",opts:["61","62","60","59"],ok:1,why:"31 + 31 = 62.",hint:"Iyul va avgust mushtda qayerga to'g'ri keladi?",full:"Iyul — 31 kun, avgust ham 31 kun: 31 + 31 = 62. «61» — oylarni navbat bilan 31, 30 deb olish xatosi."},
 tn:"Hamma bolalar mushtida birga sanasin: «Yanvar — suyak, fevral — chuqur…»."},
{h:"Vaqt oralig'i: yaxlit soat orqali",sum:"8:45 → 9:00 (15 min) → 11:00 (2 soat) → 11:20 (20 min) = 2 soat 35 min.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Avtobus 8:45 da jo'nab, 11:20 da yetib keldi. Yo'lda qancha vaqt? «Ayirib» emas, <b>yaxlit soatlar orqali</b> sakrab sanaymiz:</p>",
 btns:[phaser(P5,'▶ Sakrash')],
 after:"<p>Usul: avval <b>yaxlit soatgacha</b>, keyin butun soatlar, keyin qolgan minutlar. Shunda 60 orqali o'tishda adashmaysiz. (11:20 − 8:45 ni oddiy ayirsak, «2 soat 75 min» degan xato chiqadi.)</p>",
 q:{t:"Dars 13:50 da boshlanib, 15:05 da tugadi. Qancha davom etdi?",opts:["1 soat 15 min","2 soat 15 min","1 soat 55 min","1 soat 25 min"],ok:0,why:"13:50 → 14:00 (10 min) → 15:00 (1 soat) → 15:05 (5 min): 1 soat 15 min.",hint:"Avval 14:00 gacha necha minut?",full:"13:50 dan 14:00 gacha 10 min, 14:00 dan 15:00 gacha 1 soat, 15:00 dan 15:05 gacha 5 min. Jami 1 soat 15 min. «1 soat 55 min» — 05 − 50 ni teskari ayirish xatosi."},
 tn:"Doskada son o'qi (vaqt chizig'i) chizing va «sakrashlar» ni yoy bilan ko'rsating — Gollandiya usuli."},
{h:"24 soatli yozuv",sum:"15:30 — kunduzi 3:30, 21:15 — kechki 9:15. 12 dan katta bo'lsa, 12 ni ayiramiz.",a:"m06",
 start:function(){g3ck(15,30,'15:30')},fin:function(){g3ck(21,15,'21:15')},
 html:"<p>Telefon va poyezd jadvalida vaqt 0:00 dan 23:59 gacha yoziladi. Bosing va siferblatda ko'ring:</p>",
 btns:[["15:30",function(c,done){g3ck(15,30,'15:30');mvK(done,3)}],["21:15",function(c,done){g3ck(21,15,'21:15');mvK(done,3)}],["7:05",function(c,done){g3ck(7,5,'7:05');mvK(done,3)}]],g3:1,
 after:"<p>Soat 12 dan katta bo'lsa, siferblatda ko'rish uchun <b>12 ni ayiramiz</b>: 21:15 → 21 − 12 = 9, kechki 9:15. 00:00 — yarim tun, yangi sutka boshlanishi.</p>",
 q:{t:"Soat 19:45 — bu qachon?",opts:["kechki 9:45","ertalabki 7:45","kechki 7:45","kunduzgi 1:45"],ok:2,why:"19 − 12 = 7: kechki 7:45.",hint:"19 dan 12 ni ayiring.",full:"19 − 12 = 7, ya'ni kechki soat 7:45. «9:45» — 19 dagi 9 raqamini olish xatosi, «ertalabki 7:45» — 07:45 bo'lardi."},
 tn:"Kun tartibini 24 soatli yozuvda yozdiring: uyg'onish 7:00, dars 8:00 … uxlash 21:30."},
{h:"Tuzoq: kunlarni sanash",sum:"3-maydan 10-maygacha (ikkalasi ham kiradi): 10 − 3 + 1 = 8 kun.",a:"m07",
 start:function(){g3days(0);g4m('Lager <b>3-may</b>dan <b>10-may</b>gacha (ikkala kun ham). Necha kun?')},fin:function(){g3days(2);g4m('10 − 3 + 1 = <b>8 kun</b>')},
 html:"<p>Bolalar lageri <b>3-maydan 10-maygacha</b> ishladi (birinchi va oxirgi kun ham). Necha kun?</p>",
 btns:[["10 − 3 = 7 kun",function(c,done,b){b.style.background='#fde2e2';g3days(1);g4m('❌ Ayirma «oraliqlar» sonini beradi, kunlarni emas');setTimeout(function(){b.style.background=''},1600)}],["Kataklarni sanash",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g3days(2);g4m('To‘g‘ri! 3, 4, 5, 6, 7, 8, 9, 10 — <b>8 kun</b>');done()}]],g2:1,
 after:"<p>Ikkala chekka kun ham kirsa: <b>oxirgi − birinchi + 1</b>. Bu «panjara tuzog'i»: 10 m panjarada 1 m dan ustun qo'yilsa — 11 ta ustun.</p>",
 q:{t:"Ta'til 25-dekabrdan 8-yanvargacha (ikkalasi ham kiradi). Necha kun?",opts:["14","15","13","16"],ok:1,why:"Dekabr: 25…31 — 7 kun; yanvar: 1…8 — 8 kun; 7 + 8 = 15.",hint:"Dekabr 31 kun. Ikkala oyni alohida sanang.",full:"25-dekabrdan 31-dekabrgacha: 31 − 25 + 1 = 7 kun. 1-yanvardan 8-yanvargacha: 8 kun. Jami 15. «14» — +1 ni unutish."},
 tn:"Haqiqiy kalendardan foydalaning: bolalar kunlarni barmog'i bilan sanab, ayirma natijasi bilan solishtirsin."},
{h:"Tarix bilan masala",sum:"Bobur 1483-yilda tug'ilgan: 2026 − 1483 = 543 yil; 15-asr.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Tarixiy sanalar bilan hisoblaymiz:</p>",
 btns:[phaser(P8)],
 after:"<p>«Necha yil o'tdi?» — <b>katta yildan kichigini ayiramiz</b>. «Qaysi asr?» — oxirgi ikki raqamni tashlab, 1 qo'shamiz.</p>",
 q:{t:"Toshkent metrosi 1977-yilda ochilgan. 2027-yilda uning necha yilligi nishonlanadi?",opts:["50","40","51","60"],ok:0,why:"2027 − 1977 = 50.",hint:"Katta yildan kichigini ayiring.",full:"2027 − 1977 = 50 yil. «51» — kunlarni sanagandagi kabi +1 qo'shish; yillar farqida bunday qilinmaydi."},
 tn:"O'z oilangiz yoki mahallangizdan sanalar bering (maktab qurilgan yil va h.k.)."},
{h:"Bilasizmi? Sutka va yil qayerdan kelgan",sum:"Sutka — Yer o'z o'qi atrofida bir marta aylanishi; yil — Quyosh atrofida bir marta aylanishi.",a:"m09",
 start:function(){P3[0]();g4m('Sutka — o‘z o‘qi atrofida, yil — Quyosh atrofida')},fin:function(){P3[0]();g4m('Sutka — o‘z o‘qi atrofida, yil — Quyosh atrofida')},
 html:"<p>🌍 <b>Sutka</b> — Yer o'z o'qi atrofida bir marta aylanib chiqadigan vaqt: kun va tun almashadi.</p><p>☀️ <b>Yil</b> — Yer Quyosh atrofida bir marta aylanadigan vaqt: taxminan 365 kun 6 soat. Shu 6 soatlar to'planib, har 4 yilda kalendarga bitta kun — <b>29-fevral</b> qo'shiladi.</p><p>⏱ Soatda 60 minut bo'lishi qadimgi Bobil olimlarining 60 lik sanoqidan meros qolgan.</p>",
 tn:"Globus va chiroq bilan kun-tun almashinuvini ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g3cent(2026);g4m('2026-yil — 21-asr')},fin:function(){g3cent(2026);g4m('2026-yil — 21-asr')},
 html:"<div class='memo'><ul><li><b>1 asr = 100 yil</b>, 1 yil = 12 oy = 365 kun (kabisa — 366), 1 hafta = 7 kun.</li><li><b>1 sutka = 24 soat</b>, 1 soat = 60 min, 1 min = 60 s.</li><li>Asr: oxirgi ikki raqamni tashlab +1 (1991 → 20-asr); …00-yil — o'sha asrning oxiri (2000 → 20-asr).</li><li>Kabisa yili: yil soni 4 ga bo'linadi, fevral 29 kun.</li><li>Musht: suyak — 31, chuqur — 30; iyul va avgust — 31.</li><li>Vaqt oralig'i — yaxlit soat orqali sakrab sanang.</li><li>Ikkala chekka kun kirsa: oxirgi − birinchi + 1.</li></ul></div>",
 tn:"Uyga vazifa: oila a'zolarining tug'ilgan yillarini yozib, ular qaysi asrda tug'ilganini aniqlash."}
];
var PROBS=[
{t:"1 sutka necha soat?",o:["24 soat","12 soat","60 soat","100 soat"],k:0,s:"1 sutka = 24 soat."},
{t:"3 soat necha minut?",o:["180 min","300 min","36 min","90 min"],k:0,s:"60 · 3 = 180 min."},
{t:"2 asr necha yil?",o:["200 yil","20 yil","2000 yil","100 yil"],k:0,s:"1 asr = 100 yil; 2 · 100 = 200 yil."},
{t:"1991-yil qaysi asrga tegishli?",o:["20-asr","19-asr","21-asr","10-asr"],k:0,s:"19 + 1 = 20-asr."},
{t:"2000-yil qaysi asrga tegishli?",o:["20-asr","21-asr","19-asr","200-asr"],k:0,s:"…00-yil — asrning oxirgi yili: 20-asr (1901–2000)."},
{t:"5 minut necha sekund?",o:["300 s","50 s","500 s","3000 s"],k:0,s:"60 · 5 = 300 s."},
{t:"2028-yil fevralida necha kun bor?",o:["29","28","30","31"],k:0,s:"2028 : 4 = 507 — kabisa yili, fevral 29 kun."},
{t:"Ketma-ket 3 yilning bittasi kabisa. Jami necha kun?",o:["1096","1095","1098","1092"],k:0,s:"365 + 365 + 366 = 1096."},
{t:"8:45 dan 11:20 gacha qancha vaqt?",o:["2 soat 35 min","3 soat 25 min","2 soat 25 min","3 soat 35 min"],k:0,s:"15 min + 2 soat + 20 min = 2 soat 35 min."},
{t:"Soat 21:15 — siferblatda qancha?",o:["9:15","11:15","8:15","10:15"],k:0,s:"21 − 12 = 9 → kechki 9:15."},
{t:"3-maydan 10-maygacha (ikkalasi ham kiradi) necha kun?",o:["8","7","6","10"],k:0,s:"10 − 3 + 1 = 8."},
{t:"Bobur 1483-yilda tug'ilgan. 2026-yilda tavalludiga necha yil to'ladi?",o:["543","643","553","443"],k:0,s:"2026 − 1483 = 543."},
{t:"Iyul va avgust jami necha kun?",o:["62","61","60","59"],k:0,s:"31 + 31 = 62."},
{t:"150 minut — bu qancha?",o:["2 soat 30 min","1 soat 50 min","1 soat 30 min","2 soat 50 min"],k:0,s:"150 = 120 + 30 → 2 soat 30 min."},
{t:"Poyezd 22:40 da jo'nab, 9 soat 30 min yurdi. Qachon yetib keldi?",o:["Ertasi kuni 8:10","Ertasi kuni 7:10","Ertasi kuni 9:10","O'sha kuni 8:10"],k:0,s:"22:40 + 1 soat 20 min = 24:00; qolgan 8 soat 10 min → ertasi 8:10."},
{t:"Bugun dushanba. 100 kundan keyin haftaning qaysi kuni bo'ladi?",o:["Chorshanba","Seshanba","Payshanba","Dushanba"],k:0,s:"100 = 7 · 14 + 2. 14 hafta o'tib yana dushanba, +2 kun → chorshanba."},
{t:"1 sutka necha minut?",o:["1440 min","240 min","1200 min","2400 min"],k:0,s:"24 · 60 = 1440 min."},
{t:"Ali 2015-yil 1-martda tug'ilgan. 2026-yil 15-fevralda u necha yoshda?",o:["10 yosh","11 yosh","12 yosh","9 yosh"],k:0,s:"2026 − 2015 = 11, lekin tug'ilgan kuni (1-mart) hali kelmagan: 10 yosh."},
{t:"Soat 3:00 dan 6:00 gacha minut mili necha marta to'liq aylanadi?",o:["3 marta","6 marta","1 marta","36 marta"],k:0,s:"Minut mili har soatda 1 marta aylanadi: 3 soat — 3 marta."},
{t:"1 asrda necha oy bor?",o:["1200","120","100","12 000"],k:0,s:"100 · 12 = 1200 oy."}
];
function PRACT_STAGE(){g4lad(['sutka','soat','min','s'],[24,60,60],[],null,'Vaqt birliklari');g4m('1 asr = 100 yil · 1 yil = 12 oy · 1 sutka = 24 soat')}
var PREP_DATA={teach:["Vaqt birliklari va ular orasidagi bog'lanish (60, 24, 12, 100).","Asrni aniqlash; …00-yillar tuzog'i.","Kabisa yili; oylardagi kunlar (musht qoidasi).","Vaqt oralig'ini yaxlit soat orqali topish; 24 soatli yozuv; kunlarni sanash (+1)."],
 mist:["1 soat = 100 min deb hisoblaydi (11:20 − 8:45 = 2:75).","1991-yilni 19-asr deydi.","Kunlarni sanashda +1 ni unutadi.","21:15 ni «9:15» emas, «11:15» yoki «1:15» deb o'qiydi."],
 need:["Katta karton soat, kalendar.","Sekundomer (telefon).","Asrlar lentasi (doskada yoki qog'oz tasmada)."],
 board:["<span class='w2'>asr ×100 yil ×12 oy</span>; <span class='w2'>sutka ×24 soat ×60 min ×60 s</span>.","<span class='w2'>1991 → 19+1 = 20-asr</span>; <span class='w2'>2000 → 20-asr</span>.","Vaqt chizig'i: 8:45 → 9:00 → 11:00 → 11:20.","<span class='w2'>10 − 3 + 1 = 8 kun</span>."]};
