var CODE='2G3',TITLE='2-sinf · Saralash, ro‘yxat va jadval tuzish';
function g3Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var G3C={q:'#e65c5c',k:'#4a90d9',y:'#f2b632'},G3N={q:'qizil',k:'ko‘k',y:'sariq'};
// shakllar: [tur(d=doira,u=uchburchak,k=kvadrat), rang]
var SH=[['d','q'],['u','k'],['k','q'],['d','k'],['u','q'],['k','k'],['d','q'],['u','k'],['d','k'],['k','q']];
function g3Shape(g,t,c,x,y,r){var f=G3C[c];if(t==='d')E('circle',{cx:x,cy:y,r:r,fill:f,stroke:'#33475b','stroke-width':1},g);else if(t==='k')E('rect',{x:x-r,y:y-r,width:2*r,height:2*r,rx:2,fill:f,stroke:'#33475b','stroke-width':1},g);else E('polygon',{points:x+','+(y-r)+' '+(x+r)+','+(y+r)+' '+(x-r)+','+(y+r),fill:f,stroke:'#33475b','stroke-width':1},g)}
function g3Pile(){clear();var g=S.g;T(g,180,14,'Aralash shakllar',{'font-size':11,'font-weight':800,fill:C.blue});SH.forEach(function(s,i){g3Shape(g,s[0],s[1],34+(i%5)*72,58+Math.floor(i/5)*58,16)})}
function g3Sort(by){clear();var g=S.g,keys=by==='r'?['q','k']:['d','u','k'],nm=by==='r'?G3N:{d:'doira',u:'uchburchak',k:'kvadrat'},w=340/keys.length;
 keys.forEach(function(kk,j){var x=10+j*w;E('rect',{x:x+3,y:8,width:w-6,height:158,rx:8,fill:'#f7f9fb',stroke:'#c9d3dd'},g);var its=SH.filter(function(s){return (by==='r'?s[1]:s[0])===kk});T(g,x+w/2,24,nm[kk]+' — '+its.length,{'font-size':11,'font-weight':800});
  its.forEach(function(s,i){g3Shape(g,s[0],s[1],x+26+(i%3)*((w-40)/3),52+Math.floor(i/3)*40,13)})})}
function g3Grid(o){o=o||{};clear();var g=S.g,rs=['q','k'],cs=['d','u','k'],cn=['doira','uchburchak','kvadrat'],x0=70,cw=90,ch=44,y0=10;
 cs.forEach(function(c,j){E('rect',{x:x0+j*cw,y:y0,width:cw,height:26,fill:'#eef3f8',stroke:'#c9d3dd'},g);T(g,x0+j*cw+cw/2,y0+17,cn[j],{'font-size':11,'font-weight':800})});
 rs.forEach(function(r,i){var y=y0+26+i*ch;E('rect',{x:x0-60,y:y,width:60,height:ch,fill:'#eef3f8',stroke:'#c9d3dd'},g);T(g,x0-30,y+26,G3N[r],{'font-size':11,'font-weight':800,fill:G3C[r]});
  cs.forEach(function(c,j){var n=SH.filter(function(s){return s[0]===c&&s[1]===r}).length,on=o.hl&&o.hl[0]===i&&o.hl[1]===j;E('rect',{x:x0+j*cw,y:y,width:cw,height:ch,fill:on?C.hi:'#fff',stroke:'#c9d3dd'},g);g3Shape(g,c,r,x0+j*cw+24,y+ch/2,11);T(g,x0+j*cw+60,y+28,o.show||on?String(n):'?',{'font-size':15,'font-weight':800,fill:on?C.a2:'#1d2b3a'})})});
 T(g,180,y0+26+2*ch+22,o.note||'Har katak — ikki belgi: rang VA shakl',{'font-size':10,fill:'#5b6b7b'})}
// chiziqchalar
function g3Tally(g,x,y,n){for(var k=0;k<n;k++){var grp=Math.floor(k/5),p=k%5,bx=x+grp*34;if(p<4)E('line',{x1:bx+p*7,y1:y-10,x2:bx+p*7,y2:y+10,stroke:'#1d2b3a','stroke-width':2.2,'stroke-linecap':'round'},g);else E('line',{x1:bx-4,y1:y+6,x2:bx+25,y2:y-6,stroke:C.a2,'stroke-width':2.2,'stroke-linecap':'round'},g)}}
var TV=['olma','nok','olma','uzum','olma','nok','olma','uzum','olma','olma','nok','olma'];
function g3Votes(n){clear();var g=S.g,cnt={olma:0,nok:0,uzum:0};TV.slice(0,n).forEach(function(v){cnt[v]++});
 TV.forEach(function(v,i){var on=i<n;E('rect',{x:10+i*28.5,y:10,width:25,height:22,rx:4,fill:on?'#e8eef4':'#fff',stroke:'#c9d3dd'},g);T(g,22.5+i*28.5,25,v==='olma'?'🍎':v==='nok'?'🍐':'🍇',{'font-size':12,opacity:on?.35:1})});
 ['olma','nok','uzum'].forEach(function(f,i){var y=62+i*36;E('rect',{x:10,y:y-16,width:340,height:32,rx:6,fill:'#f7f9fb',stroke:'#e1e7ee'},g);T(g,50,y+4,f,{'font-size':12,'font-weight':800});g3Tally(g,100,y,cnt[f]);if(n===TV.length)T(g,336,y+5,String(cnt[f]),{'font-size':14,'font-weight':800,fill:C.a2,'text-anchor':'end'})})}
var NM=['Malika','Anvar','Zarina','Bobur','Dilshod'];
function g3Names(order,hl){clear();var g=S.g;order.forEach(function(n,i){var y=20+i*30,on=hl===i;E('rect',{x:90,y:y-12,width:180,height:26,rx:6,fill:on?C.hi:'#f7f9fb',stroke:'#c9d3dd'},g);T(g,110,y+5,String(i+1)+'.',{'font-size':11,fill:'#5b6b7b'});T(g,185,y+5,n,{'font-size':13,'font-weight':800});E('text',{x:262,y:y+5,'font-size':13,'font-weight':800,fill:C.a2,'text-anchor':'end'},g).textContent=n[0]})}
var P5=[function(){clear();var g=S.g;var it=[['d','q'],['d','k'],['d','q'],['k','q']];it.forEach(function(s,i){g3Shape(g,s[0],s[1],60+i*80,70,24)});T(g,180,140,'Qaysi biri ortiqcha?',{'font-size':12,'font-weight':800});g3Msg('Uchtasi doira, bittasi kvadrat → <b>kvadrat</b> ortiqcha?')},
 function(){clear();var g=S.g;var it=[['d','q'],['d','k'],['d','q'],['k','q']];it.forEach(function(s,i){g3Shape(g,s[0],s[1],60+i*80,70,24);if(i===1)E('circle',{cx:60+i*80,cy:70,r:32,fill:'none',stroke:C.a2,'stroke-width':3},g)});T(g,180,140,'Rang bo‘yicha esa…',{'font-size':12,'font-weight':800});g3Msg('Rang bo‘yicha: uchtasi qizil, bittasi ko‘k → <b>ko‘k doira</b> ortiqcha!')},
 function(){clear();var g=S.g;var it=[['d','q'],['d','k'],['d','q'],['k','q']];it.forEach(function(s,i){g3Shape(g,s[0],s[1],60+i*80,70,24)});T(g,180,130,'Ikkala javob ham to‘g‘ri bo‘lishi mumkin',{'font-size':12,'font-weight':800,fill:C.a2});T(g,180,150,'— qaysi belgi bo‘yicha ekanini ayting',{'font-size':11});g3Msg('Saralashda <b>belgini</b> aytish shart: «shakl bo‘yicha» yoki «rang bo‘yicha»')}];
var STEPS=[
{h:"Saralash nima?",sum:"Saralash — narsalarni bir xil belgi bo'yicha guruhlarga ajratish.",a:"m01",
 start:function(){g3Pile();g3Msg('10 ta aralash shakl. Ularni qanday guruhlarga ajratish mumkin?')},fin:function(){g3Sort('s');g3Msg('Shakl bo‘yicha: doira 4, uchburchak 3, kvadrat 3')},
 html:"<p>Stolda aralash shakllar. Ularni <b>saralaymiz</b> — bir xillarini bir joyga yig'amiz. Belgini tanlang:</p>",
 btns:[["🎨 Rang bo'yicha",function(c,done){g3Sort('r');g3Msg('Rang bo‘yicha: qizil 5, ko‘k 5');S.g3a=(S.g3a||0)|1;if(S.g3a===3)done()}],["🔷 Shakl bo'yicha",function(c,done){g3Sort('s');g3Msg('Shakl bo‘yicha: doira 4, uchburchak 3, kvadrat 3');S.g3a=(S.g3a||0)|2;if(S.g3a===3)done()},'u']],g2:1,
 after:"<p>Bir xil narsalarni <b>turli belgilar</b> bo'yicha saralash mumkin: rang, shakl, o'lcham… Ikkala usulda ham jami 10 ta: 5 + 5 = 10 va 4 + 3 + 3 = 10.</p>",
 q:{t:"Savatda 3 ta qizil olma, 2 ta yashil olma va 4 ta sariq nok bor. Rang bo'yicha nechta guruh?",opts:["2","3","9","4"],ok:1,why:"Qizil, yashil, sariq — 3 guruh.",hint:"Nechta xil rang bor?",full:"Ranglar: qizil, yashil, sariq — 3 guruh. Meva turi bo'yicha esa 2 guruh (olma, nok)."},
 tn:"Bolalar qalamdonlaridagi narsalarni rang, keyin o'lcham bo'yicha saralasin."},
{h:"Chiziqchalar bilan sanash",sum:"Har bir narsa uchun bitta chiziq. Beshinchisi — ustidan qiya chiziq: 5 lik dasta.",a:"m02",
 start:function(){S.g3v=0;g3Votes(0);g3Msg('12 bola sevimli mevasini aytdi. Har birini belgilaymiz')},fin:function(){S.g3v=TV.length;g3Votes(TV.length);g3Msg('olma 7 · nok 3 · uzum 2 — jami 12')},
 html:"<p>Sinfda so'rov: <i>«Sevimli mevangiz?»</i> Har javob uchun <b>bitta chiziqcha</b> qo'yamiz. Tugmani bosib, javoblarni birma-bir belgilang:</p>",
 btns:[["✏️ Keyingi javob",function(c,done){if(S.g3v<TV.length)S.g3v++;g3Votes(S.g3v);g3Msg(S.g3v+'-javob: <b>'+TV[S.g3v-1]+'</b>'+(S.g3v===TV.length?' — tayyor!':''));if(S.g3v===TV.length)done()}],["⏩ Hammasi",function(c,done){S.g3v=TV.length;g3Votes(S.g3v);g3Msg('olma 7 · nok 3 · uzum 2');done()},'u']],g2:1,
 after:"<p>Beshinchi chiziq to'rttasining <b>ustidan qiya</b> tortiladi — 5 lik «dasta». Keyin beshlab sanash oson: olma — 5 + 2 = <b>7</b>.</p>",
 q:{t:"Ikkita to'liq dasta va yana 3 ta chiziqcha. Nechta?",opts:["5","13","10","23"],ok:1,why:"5 + 5 + 3 = 13.",hint:"Har dasta — 5.",full:"2 dasta = 10, yana 3 → 13. «5» — dastalarni 1 dan sanagan."},
 tn:"Ovoz berish o'yini: bolalar navbat bilan doskaga chiziqcha qo'ysin."},
{h:"Ikki belgili jadval",sum:"Jadvalda qator — rang, ustun — shakl. Har katak ikki belgini birdan bildiradi.",a:"m03",
 start:function(){g3Grid({});g3Msg('Katakni bosing: masalan qizil doira nechta?');S.g3c=0},fin:function(){g3Grid({show:1});g3Msg('Qizil: 2 + 1 + 2 = 5 · Ko‘k: 2 + 2 + 1 = 5')},
 html:"<p>Shakllarni endi <b>ikki belgi</b> bo'yicha birdan saralaymiz: rang <b>va</b> shakl. Tugmalar bilan kataklarni to'ldiring:</p>",
 btns:[["🔴 Qizil doira",function(c,done){g3Grid({hl:[0,0]});g3Msg('Qizil <b>va</b> doira — 2 ta');S.g3c|=1;if(S.g3c===7)done()}],["🔵 Ko'k uchburchak",function(c,done){g3Grid({hl:[1,1]});g3Msg('Ko‘k <b>va</b> uchburchak — 2 ta');S.g3c|=2;if(S.g3c===7)done()}],["📋 Hammasi",function(c,done){g3Grid({show:1});g3Msg('Qatorlar yig‘indisi: 5 va 5 — jami 10');S.g3c|=4;if(S.g3c===7)done()},'u']],g3:1,
 after:"<p>Jadval bir qarashda ko'p savolga javob beradi: qizil shakllar — 5 (qator yig'indisi), doiralar — 4 (ustun yig'indisi), qizil kvadrat — 2 (katak).</p>",
 q:{t:"Jadvalga ko'ra ko'k kvadratlar nechta? (qizil: doira 2, uchburchak 1, kvadrat 2; ko'k: doira 2, uchburchak 2, kvadrat 1)",opts:["2","1","3","5"],ok:1,why:"Ko'k qatori va kvadrat ustuni — 1.",hint:"Ko'k qatorini, keyin kvadrat ustunini toping.",full:"Ko'k qatori: 2, 2, 1. Kvadrat — uchinchi ustun: 1. «3» — barcha kvadratlarni qo'shgan."},
 tn:"Polga lenta bilan 2×3 jadval chizib, bolalar shakllarni kataklarga qo'ysin."},
{h:"Alifbo tartibida ro'yxat",sum:"Ro'yxat ismning birinchi harfi bo'yicha tartiblanadi: A, B, D, M, Z.",a:"m04",
 start:function(){g3Names(NM);g3Msg('Sinf jurnali uchun ismlarni alifbo tartibida yozamiz')},fin:function(){g3Names(['Anvar','Bobur','Dilshod','Malika','Zarina']);g3Msg('A → B → D → M → Z')},
 html:"<p>Sinf jurnalida ismlar <b>alifbo tartibida</b> yoziladi. Birinchi harflarga qarang va tartiblang:</p>",
 btns:[["🔤 Tartibla",function(c,done){var a=['Anvar','Bobur','Dilshod','Malika','Zarina'];g3Names(a,0);g3Msg('O‘zbek alifbosi: A, B, D, E, F, G, H, I, J, K, L, M … Z');done()}]],
 after:"<p>Alifbo: <b>A B D E F G H I J K L M N O P Q R S T U V X Y Z O' G' Sh Ch Ng</b>. Birinchi harflar bir xil bo'lsa, <b>ikkinchi</b> harfga qaraymiz: Ali, Anvar (l oldin, n keyin).</p>",
 q:{t:"Qaysi ism alifbo tartibida birinchi turadi: Sardor, Kamola, Jasur, Nodira?",opts:["Kamola","Jasur","Nodira","Sardor"],ok:1,why:"J alifboda K, N, S dan oldin.",hint:"Birinchi harflarni solishtiring: S, K, J, N.",full:"Alifboda: J, K, N, S. Demak Jasur, Kamola, Nodira, Sardor. Birinchi — Jasur."},
 tn:"Bolalar o'z ismlari yozilgan kartochkalar bilan qatorga alifbo tartibida tursin."},
{h:"Tuzoq: qaysi biri ortiqcha?",sum:"Ortiqchani topishda belgini aytish kerak: shakl bo'yicha yoki rang bo'yicha.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>To'rtta shakl. Qaysi biri <b>ortiqcha</b>? Shoshilmang:</p>",
 btns:[phaser(P5)],
 after:"<p>Saralashda doim <b>qaysi belgi</b> bo'yicha ekanini aniq ayting. Bir to'plamda bir nechta to'g'ri javob bo'lishi mumkin.</p>",
 q:{t:"2, 4, 7, 8. Juft va toq bo'yicha qaysi son ortiqcha?",opts:["2","4","7","8"],ok:2,why:"7 — yagona toq son.",hint:"Qaysi son 2 ga bo'linmaydi?",full:"2, 4, 8 — juft, 7 — toq. Juft/toq belgisi bo'yicha 7 ortiqcha."},
 tn:"«Ortiqchasini top» o'yinida bola javobini «… bo'yicha» so'zi bilan aytishi shart."},
{h:"Tuzoq: ikki shartli sanash",sum:"«Qizil VA doira» — ikkala shart ham bajarilishi kerak: 2 ta, 5 ta emas.",a:"m06",
 start:function(){g3Pile();g3Msg('Nechta shakl ham qizil, ham doira?')},fin:function(){g3Grid({hl:[0,0],note:'Qizil VA doira — faqat bitta katak'});g3Msg('Qizil va doira — <b>2</b> ta')},
 html:"<p>Savol: <i>«Nechta shakl <b>qizil va doira</b>?»</i> Ko'pchilik barcha qizillarni (5) yoki barcha doiralarni (4) sanab yuboradi.</p>",
 btns:[["🔍 Tekshir",function(c,done){g3Grid({hl:[0,0],note:'Qizil VA doira — faqat bitta katak'});g3Msg('Qizil 5, doira 4, lekin <b>ikkalasi ham</b> — faqat 2');done()}]],
 after:"<p>«VA» — ikkala belgi bir vaqtda. Jadvalda bu <b>bitta katak</b>: qizil qatori va doira ustuni kesishmasi = <b>2</b>.</p>",
 q:{t:"Sinfda 6 qiz, 5 o'g'il. 4 qiz va 3 o'g'il ko'zoynak taqadi. Nechta qiz ko'zoynak taqmaydi?",opts:["4","2","7","6"],ok:1,why:"6 − 4 = 2.",hint:"Faqat qizlarni oling.",full:"Qizlar 6, ulardan ko'zoynakli 4. 6 − 4 = 2. «7» — barcha ko'zoynaklilar."},
 tn:"Ikki doira (Eyler-Venn) chizib, «qizil» va «doira» doiralari kesishmasini ko'rsating."},
{h:"Bilasizmi? Hamma narsani saralagan olim",sum:"1735-yilda Karl Linney barcha o'simlik va hayvonlarni guruhlarga saralagan.",a:"m07",
 start:function(){g3Sort('s');g3Msg('Saralash — fanning boshlanishi')},fin:function(){g3Sort('s');g3Msg('Saralash — fanning boshlanishi')},
 html:"<p>🌿 <b>1735</b>-yilda shved olimi <b>Karl Linney</b> o'sha davrda ma'lum bo'lgan barcha o'simlik va hayvonlarni <b>guruhlarga saraladi</b>: o'xshashlarini birga, farqlilarini alohida. Uning usulidan olimlar hozir ham foydalanadi.</p><p>📚 Kutubxonadagi kitoblar, do'kondagi mahsulotlar, telefoningizdagi kontaktlar ham saralangan.</p>",
 tn:"Bolalar kutubxonaga borib, kitoblar qanday saralanganini kuzatsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){g3Grid({show:1});g3Msg('Belgini tanlang → guruhlang → sanang')},fin:function(){g3Grid({show:1});g3Msg('Belgini tanlang → guruhlang → sanang')},
 html:"<div class='memo'><ul><li><b>Saralash</b>: bir xil belgili narsalarni bir guruhga.</li><li>Belgi: rang, shakl, o'lcham, juft/toq…</li><li><b>Chiziqchalar</b>: 4 tik + 1 qiya = 5.</li><li><b>Jadval</b>: qator × ustun — ikki belgi birdan.</li><li><b>Alifbo tartibi</b>: birinchi harf, keyin ikkinchisi.</li><li>«VA» — ikkala shart ham bajarilsin.</li></ul></div>",
 tn:"Yakunda bolalar o'z o'yinchoqlari bo'yicha 2×2 jadval tuzib kelsin."}
];
var PROBS=[
{t:"3 qizil, 2 yashil, 4 sariq koptok. Rang bo'yicha nechta guruh?",o:["3","9","2","4"],k:0,s:"Uch xil rang."},
{t:"Doira 4, uchburchak 3, kvadrat 3. Jami nechta shakl?",o:["10","7","9","11"],k:0,s:"4 + 3 + 3 = 10."},
{t:"Ikki to'liq dasta (5 lik) va 3 chiziqcha. Nechta?",o:["13","5","10","8"],k:0,s:"10 + 3."},
{t:"Uch dasta va 1 chiziqcha. Nechta?",o:["16","4","15","31"],k:0,s:"15 + 1."},
{t:"Olma 7, nok 3, uzum 2 ovoz. Eng ko'p ovozli meva?",o:["olma","nok","uzum","teng"],k:0,s:"7 eng katta."},
{t:"Olma 7, nok 3, uzum 2. Olma qolgan ikkitasidan birga nechta ko'p?",o:["2","4","5","12"],k:0,s:"7 − 5 = 2."},
{t:"Alifbo tartibida birinchisi: Sardor, Kamola, Jasur, Nodira?",o:["Jasur","Kamola","Nodira","Sardor"],k:0,s:"J < K < N < S."},
{t:"Alifbo tartibida oxirgisi: Anvar, Zarina, Malika, Bobur?",o:["Zarina","Malika","Bobur","Anvar"],k:0,s:"Z — oxirgi."},
{t:"Ali va Anvar — qaysi biri ro'yxatda oldin?",o:["Ali","Anvar","teng","bilib bo'lmaydi"],k:0,s:"Ikkinchi harf: l < n."},
{t:"2, 4, 7, 8. Juft/toq bo'yicha ortiqcha son?",o:["7","2","4","8"],k:0,s:"7 — toq."},
{t:"Mushuk, it, sigir, olma. Qaysi ortiqcha?",o:["olma","it","sigir","mushuk"],k:0,s:"Olma — hayvon emas."},
{t:"Qizil: doira 2, kvadrat 2. Ko'k: doira 2, kvadrat 1. Nechta qizil kvadrat?",o:["2","4","3","1"],k:0,s:"Qizil qatori, kvadrat ustuni."},
{t:"Qizil: doira 2, kvadrat 2. Ko'k: doira 2, kvadrat 1. Jami doiralar?",o:["4","2","5","7"],k:0,s:"2 + 2."},
{t:"6 qiz, 4 tasi ko'zoynakli. Nechta qiz ko'zoynaksiz?",o:["2","4","10","6"],k:0,s:"6 − 4."},
{t:"Bo'yi bo'yicha tartiblang (pastdan): Ali 130 sm, Vali 125 sm, Soli 128 sm. Birinchi kim?",o:["Vali","Ali","Soli","teng"],k:0,s:"125 eng kichik."},
{t:"5, 12, 3, 9 ni kichikdan kattaga tartiblasak, uchinchi son?",o:["9","12","5","3"],k:0,s:"3, 5, 9, 12."},
{t:"Rang bo'yicha qizil 5, ko'k 5. Shakl bo'yicha doira 4, uchburchak 3, kvadrat ?",o:["3","5","4","10"],k:0,s:"10 − 4 − 3 = 3."},
{t:"Bitta dasta chiziqcha nechta?",o:["5","4","10","1"],k:0,s:"4 tik + 1 qiya."},
{t:"Qalam, ruchka, daftar, olma. O'quv qurollari bo'yicha ortiqcha?",o:["olma","daftar","ruchka","qalam"],k:0,s:"Olma o'quv quroli emas."},
{t:"«Qizil VA doira» savolida nimani sanaymiz?",o:["Ham qizil, ham doira bo'lganlarni","Barcha qizillarni","Barcha doiralarni","Qizil va doiralarni qo'shib"],k:0,s:"Ikkala shart birdan."}
];
function PRACT_STAGE(){g3Grid({show:1});g3Msg('Belgini tanlang → guruhlang → sanang')}
var PREP_DATA={teach:["Saralash: rang, shakl va boshqa belgilar bo'yicha.","Chiziqchalar bilan sanash (5 lik dasta).","Ikki belgili jadval tuzish va o'qish.","Alifbo tartibi; ortiqchani topish; «VA» shart."],
 mist:["Saralashda belgini aytmaydi.","Beshinchi chiziqni tik qo'yadi.","«Qizil va doira» da barcha qizillarni sanaydi.","Alifboda ikkinchi harfga qaramaydi."],
 need:["Rangli shakllar (qog'ozdan), ism kartochkalari."],
 board:["Rang bo'yicha: <span class='w2'>5 + 5</span>; shakl bo'yicha: <span class='w2'>4 + 3 + 3</span>.","𝍸 = 5.","A B D … M … Z."]};
