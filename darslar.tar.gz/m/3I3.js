var CODE='3I3',TITLE='3-sinf · Ma‘lumot yig‘ish va diagramma tuzish';
function i3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var I3K=['Qizil','Ko‘k','Yashil'],I3C=['#e0584f','#2f6fb5','#5cb85c'];
var I3A=[0,1,0,2,1,0,2,0,1,1,0,2];// 12 bola javobi: qizil 5, ko'k 4, yashil 3
function i3tally(n){var s='';for(var i=0;i<Math.floor(n/5);i++)s+='<span style="text-decoration:line-through;letter-spacing:1px">||||</span> ';return s+'|'.repeat(n%5)}
function i3tabHTML(cnt,num){return '<table style="margin:auto;border-collapse:collapse;font-size:14px">'+I3K.map(function(k,i){return '<tr><td style="border:1px solid #cfd8e3;padding:2px 8px;font-weight:700;color:'+I3C[i]+'">'+k+'</td><td style="border:1px solid #cfd8e3;padding:2px 8px;min-width:80px;font-weight:800">'+i3tally(cnt[i])+'</td>'+(num?'<td style="border:1px solid #cfd8e3;padding:2px 8px;font-weight:800">'+(num[i]?cnt[i]:'')+'</td>':'')+'</tr>'}).join('')+'</table>'}
function i3cards(){clear();var g=S.g;I3A.forEach(function(a,i){var x=20+(i%6)*56,y=20+Math.floor(i/6)*70,on=S.got[i];var gg=E('g',{style:'cursor:pointer'},g);
 E('rect',{x:x,y:y,width:48,height:58,rx:8,fill:on?'#eef1f4':'#fff',stroke:on?'#cfd8e3':I3C[a],'stroke-width':2},gg);E('circle',{cx:x+24,cy:y+20,r:10,fill:on?'#cfd8e3':I3C[a]},gg);T(gg,x+24,y+48,on?'✓':(i+1)+'-bola',{'font-size':10,fill:'#5a6b7b'});
 gg.addEventListener('click',function(){if(S.got[i]||!S.d1)return;S.got[i]=1;S.cnt[a]++;i3cards();strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML(S.cnt)+'</div></div>';if(S.cnt[0]+S.cnt[1]+S.cnt[2]===12){var d=S.d1;S.d1=null;d()}})});
 T(g,180,166,'Javoblar: '+(S.cnt[0]+S.cnt[1]+S.cnt[2])+' / 12',{'font-size':12,'font-weight':800,fill:C.blue})}
function i3bars(v,o){o=o||{};clear();var g=S.g,x0=60,y0=146,sc=o.sc||20,mx=o.mx||6;for(var k=0;k<=mx;k++){var y=y0-k*sc;E('line',{x1:x0,y1:y,x2:330,y2:y,stroke:'#e6ebf0'},g);T(g,x0-8,y+4,''+k*(o.step||1),{'font-size':10,'text-anchor':'end'})}
 E('line',{x1:x0,y1:y0,x2:330,y2:y0,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0,y1:y0,x2:x0,y2:y0-mx*sc-4,stroke:'#33475b','stroke-width':2},g);
 I3K.forEach(function(k,i){var x=90+i*80,h=v[i]*sc/(o.step||1);if(o.tgt)E('rect',{x:x,y:y0-o.tgt[i]*sc,width:44,height:o.tgt[i]*sc,fill:'none',stroke:I3C[i],'stroke-dasharray':'4 3'},g);E('rect',{x:x,y:y0-h,width:44,height:h,rx:3,fill:I3C[i]},g);T(g,x+22,y0+14,k,{'font-size':11,'font-weight':700});if(v[i])T(g,x+22,y0-h-4,''+v[i],{'font-size':11,'font-weight':800})})}
function i3s4(i,done){var t=[5,4,3];if(S.b4[i]>=t[i]){i3bars(S.b4,{tgt:t});i3msg(I3K[i]+' ustuni allaqachon '+t[i]+' — jadvalga qarang');return}S.b4[i]++;i3bars(S.b4,{tgt:t});
 calc(['Qizil '+S.b4[0]+'/5 · Ko‘k '+S.b4[1]+'/4 · Yashil '+S.b4[2]+'/3']);if(S.b4[0]===5&&S.b4[1]===4&&S.b4[2]===3){calc(['✓ Diagramma jadvalga mos!']);done()}}
var P2=[function(){clear();var g=S.g;T(g,180,40,'Chiziqcha bilan sanash',{'font-size':14,'font-weight':800,fill:C.blue});[1,2,3,4].forEach(function(n,i){E('line',{x1:120+i*14,y1:70,x2:120+i*14,y2:110,stroke:'#33475b','stroke-width':4,'stroke-linecap':'round'},g)});T(g,250,96,'4',{'font-size':22,'font-weight':800});i3msg('Har javob — bitta tik chiziqcha')},
 function(){clear();var g=S.g;[0,1,2,3].forEach(function(i){E('line',{x1:120+i*14,y1:70,x2:120+i*14,y2:110,stroke:'#33475b','stroke-width':4,'stroke-linecap':'round'},g)});E('line',{x1:110,y1:104,x2:172,y2:76,stroke:C.bad,'stroke-width':4,'stroke-linecap':'round'},g);T(g,250,96,'5',{'font-size':22,'font-weight':800});i3msg('Beshinchi chiziqcha <b>ustidan</b> chiziladi — «beshtalik»')},
 function(){clear();var g=S.g;for(var b=0;b<2;b++){for(var i=0;i<4;i++)E('line',{x1:40+b*90+i*14,y1:70,x2:40+b*90+i*14,y2:110,stroke:'#33475b','stroke-width':4,'stroke-linecap':'round'},g);E('line',{x1:30+b*90,y1:104,x2:92+b*90,y2:76,stroke:C.bad,'stroke-width':4,'stroke-linecap':'round'},g)}
  for(var j=0;j<2;j++)E('line',{x1:220+j*14,y1:70,x2:220+j*14,y2:110,stroke:'#33475b','stroke-width':4,'stroke-linecap':'round'},g);T(g,300,96,'= 12',{'font-size':22,'font-weight':800,fill:C.ok});i3msg('5, 10, 11, 12 — beshtaliklar bilan tez sanaymiz: <b>12</b>')}];
function i3pic(k){clear();var g=S.g,v=[20,15,10],ok=k===5;T(g,300,18,'● = '+k,{'font-size':12,'font-weight':800,fill:C.blue});
 v.forEach(function(n,i){var y=44+i*40;T(g,40,y+5,I3K[i],{'font-size':12,'font-weight':700,fill:I3C[i]});var c=n/k,full=Math.floor(c);for(var j=0;j<Math.min(full,9);j++)E('circle',{cx:90+j*26,cy:y,r:10,fill:I3C[i]},g);if(full>9)T(g,330,y+5,'…',{'font-size':16,'text-anchor':'end'});if(c%1)T(g,90+full*26,y+5,'?',{'font-size':16,'font-weight':800,fill:C.bad})});
 return ok}
var P7=[function(){clear();var g=S.g;['Ali','Vali','Gul','Ali','Sora','Bek'].forEach(function(n,i){var x=30+i*54;E('rect',{x:x,y:40,width:46,height:40,rx:6,fill:n==='Ali'?'#fff3c4':'#fff',stroke:'#cfd8e3'},g);T(g,x+23,64,n,{'font-size':12,'font-weight':700})});i3msg('Ro‘yxatda 6 ta javob. Lekin nechta bola so‘raldi?')},
 function(){clear();var g=S.g;['Ali','Vali','Gul','Ali','Sora','Bek'].forEach(function(n,i){var x=30+i*54;E('rect',{x:x,y:40,width:46,height:40,rx:6,fill:i===3?'#f9d0d0':'#fff',stroke:i===3?C.bad:'#cfd8e3','stroke-width':2},g);T(g,x+23,64,n,{'font-size':12,'font-weight':700,fill:i===3?C.bad:'#33475b'})});E('line',{x1:192,y1:36,x2:230,y2:84,stroke:C.bad,'stroke-width':3},g);i3msg('Ali <b>ikki marta</b> yozilgan! Bitta bola — bitta javob')},
 function(){clear();var g=S.g;['Ali','Vali','Gul','Sora','Bek'].forEach(function(n,i){var x=50+i*56;E('rect',{x:x,y:40,width:46,height:40,rx:6,fill:'#dff3e3',stroke:C.ok},g);T(g,x+23,64,'✓ '+n,{'font-size':11,'font-weight':700})});T(g,180,120,'5 ta bola',{'font-size':16,'font-weight':800,fill:C.ok});i3msg('Takrorni olib tashladik: <b>5</b> ta bola. So‘ralganlarni belgilab boring!')}];
var STEPS=[
{h:"Ma'lumot yig'amiz",sum:"So'rovnoma: har bir bolaning javobini bittadan belgilab, chiziqcha bilan sanaymiz.",a:"m01",
 start:function(){S.got=[];S.cnt=[0,0,0];i3cards();strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML(S.cnt)+'</div></div>'},fin:function(){S.got=I3A.map(function(){return 1});S.cnt=[5,4,3];i3cards();strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML(S.cnt)+'</div></div>'},
 act:function(c,done){S.d1=done},
 html:"<p>12 bolaga «Sevimli rangingiz qaysi?» deb savol berdik. Har bir kartochkani <b>bittadan</b> bosing — javob jadvalga chiziqcha bo'lib tushadi.</p>",
 after:"<p>Ma'lumot yig'ishda har bir javobni <b>bir martadan</b> belgilaymiz (bosilgan kartochka ✓ bo'ladi). Chiziqchalar bilan sanash — tez va qulay.</p>",
 q:{t:"So'rovnomada 20 bola qatnashdi. Jadvaldagi barcha chiziqchalar soni qancha bo'lishi kerak?",opts:["20","Ranglar soniga teng","10","40"],ok:0,why:"Har bola — bitta javob — bitta chiziqcha.",hint:"Har bir bola nechta chiziqcha qo'shadi?",full:"Har bir bola bitta javob beradi, demak jami chiziqcha soni bolalar soniga teng: 20. Agar kam yoki ko'p chiqsa — kimdir tushib qolgan yoki ikki marta sanalgan."},
 tn:"Sinfning o'zida so'rovnoma o'tkazing: doskaga jadval chizib, har bola o'zi chiziqcha qo'ysin."},
{h:"Beshtalik bilan sanash",sum:"To'rtta chiziqcha, beshinchisi ustidan — beshtalik. Beshtaliklar bilan tez sanaladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Chiziqchalar ko'p bo'lsa, sanash qiyin. Ularni <b>beshtadan</b> guruhlaymiz:</p>",
 btns:[phaser(P2)],
 after:"<p>Har beshinchi chiziqcha qolgan to'rttasining <b>ustidan</b> chiziladi. Keyin beshtaliklab sanaymiz: 5, 10, … va qolganlarini qo'shamiz.</p>",
 q:{t:"Jadvalda 3 ta beshtalik va 2 ta yolg'iz chiziqcha. Nechta javob?",opts:["17","5","15","32"],ok:0,why:"3 × 5 + 2 = 17.",hint:"Bitta beshtalikda nechta chiziqcha?",full:"3 ta beshtalik — 15, yana 2 ta — 17. 5 — guruhlar soni, 15 — yolg'iz chiziqchalarni unutish."},
 tn:"Cho'plar bilan doskada beshtaliklar yasating — ruscha/o'zbekcha sanoq cho'plari bilan ham ishlaydi."},
{h:"Chastota jadvali",sum:"Chiziqchalarni sanab, songa aylantiramiz — bu chastota jadvali.",a:"m03",
 start:function(){S.n3=[0,0,0];strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML([5,4,3],S.n3)+'</div></div>';i3bars([0,0,0])},fin:function(){strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML([5,4,3],[1,1,1])+'</div></div>';i3bars([0,0,0])},
 html:"<p>Har bir rangni bosing — chiziqchalar <b>songa</b> aylanadi:</p>",
 btns:[["Qizil",function(c,done){S.n3[0]=1;strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML([5,4,3],S.n3)+'</div></div>';mvK(done,3)}],["Ko'k",function(c,done){S.n3[1]=1;strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML([5,4,3],S.n3)+'</div></div>';mvK(done,3)}],["Yashil",function(c,done){S.n3[2]=1;strip.innerHTML='<div class="calc"><div class="cl last">'+i3tabHTML([5,4,3],S.n3)+'</div></div>';mvK(done,3)}]],g3:1,
 after:"<p>Qizil — 5, Ko'k — 4, Yashil — 3. Jami 5 + 4 + 3 = <b>12</b> — so'ralgan bolalar soniga teng, demak hech kim tushib qolmagan ✓.</p>",
 q:{t:"Jadval: Olma 7, Nok 6, Uzum 9. 25 bola so'ralgan. Nima bo'lgan?",opts:["3 ta javob tushib qolgan","Hammasi to'g'ri","3 ta javob ortiqcha","Uzumni ko'p sanagan"],ok:0,why:"7 + 6 + 9 = 22 < 25.",hint:"Jadvaldagi sonlar yig'indisini 25 bilan solishtiring.",full:"7 + 6 + 9 = 22, lekin 25 bola so'ralgan — 3 ta javob yozilmay qolgan. Ortiqcha bo'lganda yig'indi 25 dan katta chiqardi."},
 tn:"Har so'rovnomadan keyin «jami = so'ralganlar» tekshiruvini odat qiling."},
{h:"Diagramma tuzamiz",sum:"Jadvaldagi har bir son — ustun balandligi.",a:"m04",
 start:function(){S.b4=[0,0,0];i3bars(S.b4,{tgt:[5,4,3]});calc(['Qizil 0/5 · Ko‘k 0/4 · Yashil 0/3'])},fin:function(){i3bars([5,4,3]);calc(['✓ Diagramma jadvalga mos!'])},
 html:"<p>Endi o'zingiz <b>ustunli diagramma</b> tuzing: har bir rang ustunini jadvaldagi songacha ko'taring.</p>",
 btns:[["+1 Qizil",function(c,done){i3s4(0,done)}],["+1 Ko'k",function(c,done){i3s4(1,done)}],["+1 Yashil",function(c,done){i3s4(2,done)}]],g3:1,
 after:"<p>Diagramma tuzish tartibi: 1) nomlarni pastga yozamiz; 2) shkalani tanlaymiz (bu yerda 1 tadan); 3) har ustunni songacha bo'yaymiz; 4) diagrammaga sarlavha beramiz.</p>",
 q:{t:"Jadvalda eng katta son 40. Shkalani qanday tanlash qulay?",opts:["10 tadan: 0, 10, 20, 30, 40","1 tadan: 0, 1, 2 … 40","20 tadan: 0, 20","Shkala kerak emas"],ok:0,why:"5 ta chiziq — o'qish oson va joy yetadi.",hint:"1 tadan bo'lsa nechta chiziq kerak bo'ladi?",full:"1 tadan shkala 40 ta chiziq — juda zich. 20 tadan — juda siyrak, oraliq qiymatlar o'qilmaydi. 10 tadan — qulay."},
 tn:"Katakli daftarda har bir katak = 1 javob qilib diagramma chizdiring."},
{h:"Piktogramma kalitini tanlaymiz",sum:"Kalitni shunday tanlaymizki, hamma sonlar unga bo'linsin (yoki yarim rasm chiqsin).",a:"m05",
 start:function(){i3pic(1);i3msg('Qizil 20, Ko‘k 15, Yashil 10. Qaysi kalit qulay?')},fin:function(){i3pic(5);calc(['● = 5: 20 : 5 = 4, 15 : 5 = 3, 10 : 5 = 2 ✓'])},
 html:"<p>Boshqa sinfda: Qizil 20, Ko'k 15, Yashil 10. Piktogramma uchun qaysi kalit qulay?</p>",
 btns:[["● = 1",function(c,done){i3pic(1);i3msg('20 ta rasm — juda ko‘p, chizish qiyin')}],["● = 3",function(c,done){i3pic(3);i3msg('20 va 10 soni 3 ga bo‘linmaydi — butun rasm chiqmaydi')}],["● = 5",function(c,done){i3pic(5);calc(['20 : 5 = 4, 15 : 5 = 3, 10 : 5 = 2 ✓']);done()}]],g3:1,
 after:"<p>Kalit sonlarning <b>umumiy bo'luvchisi</b> bo'lsa qulay: 20, 15 va 10 — hammasi 5 ga bo'linadi. Rasmlar kam va butun.</p>",
 q:{t:"Sonlar: 12, 8, 16. Qaysi kalit qulay?",opts:["● = 4","● = 3","● = 5","● = 6"],ok:0,why:"12, 8, 16 — hammasi 4 ga bo'linadi.",hint:"Qaysi son uchala songa qoldiqsiz bo'linadi?",full:"12 : 4 = 3, 8 : 4 = 2, 16 : 4 = 4. 3 ga 8 va 16 bo'linmaydi, 5 ga hech biri, 6 ga 8 va 16 bo'linmaydi."},
 tn:"2 ham mumkin bo'lgan holatlarni muhokama qiling: qaysi biri kamroq rasm beradi?"},
{h:"Ma'lumotdan xulosa",sum:"Xulosa faqat ma'lumot aytgan narsani aytadi.",a:"m06",
 start:function(){i3bars([5,4,3]);i3msg('Qaysi xulosa to‘g‘ri?')},fin:function(){i3bars([5,4,3]);i3msg('✓ Qizilni eng ko‘p bola tanlagan')},
 html:"<p>Diagramma bo'yicha qaysi xulosa <b>to'g'ri</b>?</p>",
 btns:[["Yashilni hech kim yoqtirmaydi",function(){i3msg('Yo‘q! Yashilni 3 bola tanlagan')}],["Qizil ko'kdan 4 marta ko'p",function(){i3msg('5 va 4 — atigi 1 ta farq, «4 marta» emas')}],["Sinfda 5 ta bola bor",function(){i3msg('5 — qizilni tanlaganlar. Bolalar 5 + 4 + 3 = 12')}],["Qizilni eng ko'p bola tanlagan",function(c,done){i3msg('✓ To‘g‘ri: qizil ustuni eng baland (5)');done()}]],g2:1,
 after:"<p>Yaxshi xulosa <b>ma'lumotga asoslanadi</b>: «qizil — eng ko'p (5)», «yashil — eng kam (3)», «qizil ko'kdan 1 ta ko'p». Ma'lumotda yo'q narsani (masalan, «hech kim yoqtirmaydi») aytmaymiz.</p>",
 q:{t:"Ob-havo kuzatuvi: 15 kun quyoshli, 10 kun bulutli, 5 kun yomg'irli. Qaysi xulosa to'g'ri?",opts:["Bulutli kunlar yomg'irlidan 2 marta ko'p","Yomg'irli kun yo'q","Quyoshli kun 3 ta","Bulutli kunlar eng ko'p"],ok:0,why:"10 : 5 = 2.",hint:"Har bir xulosani sonlar bilan tekshiring.",full:"10 : 5 = 2 — bulutli kunlar yomg'irlidan 2 marta ko'p. Eng ko'pi — quyoshli (15), yomg'irli 5 kun bor."},
 tn:"Bolalar o'z diagrammasi bo'yicha 3 ta xulosa yozsin, qo'shnisi tekshirsin."},
{h:"Tuzoq: ikki marta sanash",sum:"Bir kishining javobi faqat bir marta sanaladi. So'ralganlarni belgilab boring.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ro'yxatda 6 ta javob bor. Demak 6 bola so'raldimi? Tekshiramiz!</p>",
 btns:[phaser(P7)],
 after:"<p>Bir bola ikki marta yozilsa, natija <b>buziladi</b>. Shuning uchun: so'ralganlarni ro'yxatda belgilaymiz, oxirida «jami = bolalar soni» ni tekshiramiz.</p>",
 q:{t:"25 bolali sinfda so'rovnoma: jadval yig'indisi 27 chiqdi. Nima bo'lgan?",opts:["Kimdir ikki marta sanalgan","Hammasi to'g'ri","2 bola qatnashmagan","Jadvalda rang yetmagan"],ok:0,why:"27 > 25 — ortiqcha javoblar bor.",hint:"Yig'indi bolalar sonidan katta bo'lishi mumkinmi?",full:"Har bolada bitta javob, yig'indi 25 dan oshmasligi kerak. 27 — 2 ta ortiqcha, ya'ni kimdir ikki marta sanalgan (qatnashmaganlar bo'lsa, yig'indi kam chiqardi)."},
 tn:"So'rovnomani «qo'l ko'tarish» bilan o'tkazganda bir bola ikki marta qo'l ko'tarishi mumkin — shu holatni sahnalashtiring."},
{h:"Yaxshi so'rovnoma savoli",sum:"Savol aniq, javob variantlari tanish va hammaga tushunarli bo'lsin.",a:"m08",
 start:function(){i3bars([5,4,3])},fin:function(){i3msg('✓ Aniq savol + tayyor variantlar')},
 html:"<p>Sinfdoshlardan sevimli meva haqida so'ramoqchisiz. Qaysi savol <b>eng yaxshi</b>?</p>",
 btns:[["Nima yeysiz?",function(){i3msg('Juda noaniq — javoblar har xil: osh, non, meva…')}],["Olma foydali, uni yaxshi ko'rasizmi?",function(){i3msg('Bu savol javobni «olma» tomonga suradi')}],["Sevimli mevangiz: olma, nok, uzum yoki boshqa?",function(c,done){i3msg('✓ Aniq savol, tayyor variantlar va «boshqa» ham bor');done()}]],
 after:"<p>Yaxshi savol: <b>aniq</b> (nima so'ralayotgani tushunarli), <b>xolis</b> (javobni bir tomonga surmaydi), <b>variantli</b> («boshqa» bilan). Shunda javoblarni sanash oson.</p>",
 q:{t:"Nega variantlar orasiga «boshqa» qo'shiladi?",opts:["Ro'yxatda yo'q javob ham hisobga olinsin","Javoblar ko'p bo'lsin","Savol uzun bo'lsin","Hech kim tanlamasin"],ok:0,why:"Har bir bolaning javobi qayerdadir yozilishi kerak.",hint:"Sevimli mevasi anor bo'lgan bola qaysi variantni tanlaydi?",full:"Agar bola sevgan meva ro'yxatda bo'lmasa, u «boshqa» ni tanlaydi. Busiz u noto'g'ri variant tanlab qo'yishi yoki javob bermasligi mumkin."},
 tn:"Guruhlarga bo'lib, har guruh o'z so'rovnoma savolini tuzib, boshqa guruhda sinab ko'rsin."},
{h:"Bilasizmi? Ishango suyagi",sum:"Taxminan 20 000 yil oldin odamlar suyakka chiziqcha o'yib sanagan.",a:"m09",
 start:function(){S.ph=2;P2[2]()},fin:function(){P2[2]()},
 html:"<p>🦴 Afrikada (hozirgi Kongo Demokratik Respublikasi hududida) 1950-yilda topilgan <b>Ishango suyagi</b>da chiziqchalar o'yilgan. Olimlar uning yoshini taxminan <b>20 000 yil</b> deb hisoblaydi. Bu — sanashning eng qadimgi izlaridan biri.</p><p>📋 Bugun ham ob-havo kuzatuvchilari, shifokorlar va olimlar ma'lumotni jadvalga yozib, keyin diagramma tuzadi.</p>",
 tn:"Bolalar bir hafta davomida uyda biror narsani (masalan, ob-havo) kuzatib, chiziqchalar bilan yozib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){i3bars([5,4,3])},fin:function(){i3bars([5,4,3])},
 html:"<div class='memo'><ul><li>Tartib: <b>savol → yig'ish → jadval → diagramma → xulosa</b>.</li><li>Har javob — bitta chiziqcha; beshinchisi ustidan (beshtalik).</li><li>Tekshiruv: jadval yig'indisi = so'ralganlar soni.</li><li>Bir kishi — bir javob; ikki marta sanamang.</li><li>Diagrammada qulay shkala, piktogrammada qulay kalit tanlang.</li><li>Xulosa faqat ma'lumotga asoslanadi.</li><li>Yaxshi savol: aniq, xolis, variantli («boshqa» bilan).</li></ul></div>",
 tn:"Keyingi darsni sinf so'rovnomasi natijalarini (devorga osilgan diagramma) muhokama qilish bilan boshlang."}
];
var PROBS=[
{t:"Chiziqchalar: 2 ta beshtalik va 3 ta yolg'iz. Nechta?",o:["13","5","10","23"],k:0,s:"2 × 5 + 3 = 13."},
{t:"17 ni chiziqcha bilan yozish uchun nechta beshtalik kerak?",o:["3 ta va 2 ta yolg'iz","4 ta","17 ta","2 ta va 7 ta yolg'iz"],k:0,s:"17 = 15 + 2."},
{t:"Jadval: Futbol 8, Basketbol 5, Suzish 7. Nechta bola so'ralgan?",o:["20","8","3","13"],k:0,s:"8 + 5 + 7 = 20."},
{t:"30 bola so'raldi. Olma 12, Nok 9, qolgani uzum. Uzumni nechta bola tanlagan?",o:["9","21","12","18"],k:0,s:"30 − 12 − 9 = 9."},
{t:"28 bola so'raldi, jadval yig'indisi 26. Nima bo'lgan?",o:["2 ta javob tushib qolgan","2 kishi ikki marta sanalgan","Hammasi to'g'ri","Jadval to'liq"],k:0,s:"26 < 28 — 2 javob yo'q."},
{t:"24 bolali sinfda jadval yig'indisi 25. Nima bo'lgan?",o:["Kimdir ikki marta sanalgan","1 bola qatnashmagan","Hammasi to'g'ri","Sinfda 23 bola"],k:0,s:"25 > 24 — ortiqcha javob."},
{t:"Ob-havo: 18 kun quyoshli, 6 kun bulutli, 3 kun yomg'irli. Bulutli kunlar yomg'irlidan necha marta ko'p?",o:["2","3","6","9"],k:0,s:"6 : 3 = 2."},
{t:"Ob-havo: 18 kun quyoshli, 6 bulutli, 3 yomg'irli. Quyoshli kunlar bulutlidan necha marta ko'p?",o:["3","12","2","6"],k:0,s:"18 : 6 = 3."},
{t:"Sonlar: 30, 20, 25. Piktogramma uchun qaysi kalit qulay?",o:["● = 5","● = 3","● = 4","● = 20"],k:0,s:"Hammasi 5 ga bo'linadi: 6, 4, 5 rasm."},
{t:"Kalit ● = 5. 35 ni ko'rsatish uchun nechta ● kerak?",o:["7","35","5","30"],k:0,s:"35 : 5 = 7."},
{t:"Eng katta son 60. Qaysi shkala qulay?",o:["10 tadan","1 tadan","50 tadan","60 tadan"],k:0,s:"0, 10, … 60 — 7 ta chiziq."},
{t:"Qaysi savol so'rovnoma uchun eng yaxshi?",o:["Sevimli faslingiz: qish, bahor, yoz yoki kuz?","Yozni yaxshi ko'rasiz-a?","Nimani yoqtirasiz?","Yoz eng zo'r fasl, rozimisiz?"],k:0,s:"Aniq, xolis, hamma variant bor."},
{t:"Jadval: Qizil 9, Ko'k 6, Yashil 6. Qaysi xulosa to'g'ri?",o:["Ko'k va yashilni teng bola tanlagan","Qizilni hamma tanlagan","Yashil eng kam","Ko'k qizildan ko'p"],k:0,s:"6 = 6."},
{t:"Jadval: Olma 12, Nok 4. Qaysi xulosa to'g'ri?",o:["Olmani nokdan 3 marta ko'p bola tanlagan","Olmani 8 marta ko'p tanlagan","Nokni hech kim tanlamagan","Jami 8 bola"],k:0,s:"12 : 4 = 3."},
{t:"Sinfda «Sevimli rangingiz?» deb so'rashdi. Javob bergan bolalar ismi yozib borildi, lekin ba'zilar ikki marta yozilib qolgan: Ali, Gul, Ali, Bek, Gul, Sora. Aslida necha xil bola so'ralgan?",o:["4","6","5","3"],k:0,s:"Takrorlarni olib tashlaymiz: Ali, Gul, Bek, Sora."},
{t:"Diagramma: A 14, B 9, C 11. A va C birgalikda B dan nechta ko'p?",o:["16","25","5","34"],k:0,s:"14 + 11 = 25; 25 − 9 = 16."},
{t:"Bir hafta yomg'irli kunlar soni chiziqcha bilan: «||||/ |». Qolgan kunlar nechta?",o:["1","6","7","0"],k:0,s:"Yomg'irli 6 kun, haftada 7 kun: 7 − 6 = 1."},
{t:"So'rovnomada 32 bola. Qizil 10, Ko'k 8, Yashil 7, Sariq ?. Sariq nechta?",o:["7","25","8","10"],k:0,s:"32 − (10 + 8 + 7) = 7."},
{t:"Kalit ★ = 4. Qatorda 5 ta butun va yarim ★. Nechta?",o:["22","20","24","6"],k:0,s:"5 × 4 + 2 = 22."},
{t:"Sinf so'rovnomasi: Futbol 2 ta beshtalik + 1, Shaxmat 1 ta beshtalik + 4. Futbolni shaxmatdan nechta ko'p tanlagan?",o:["2","9","11","20"],k:0,s:"Futbol 11, shaxmat 9: 11 − 9 = 2."}
];
function PRACT_STAGE(){i3bars([5,4,3])}
var PREP_DATA={teach:["Ma'lumot yig'ish bosqichlari: savol → yig'ish → jadval → diagramma → xulosa.","Chiziqcha bilan sanash, beshtaliklar, chastota jadvali.","Diagramma tuzish: shkala va piktogramma kalitini tanlash.","Tuzoqlar: ikki marta sanash, ma'lumotsiz xulosa, yo'naltiruvchi savol."],
 mist:["Bir javobni ikki marta sanaydi yoki tashlab ketadi.","Beshtalikni 4 ta yoki 6 ta deb sanaydi.","Sonlar bo'linmaydigan kalit tanlaydi.","Ma'lumotda yo'q xulosa chiqaradi («hech kim yoqtirmaydi»)."],
 need:["Kartochkalar (rangli doiralar), cho'plar.","Katakli qog'oz, rangli qalam.","Doskada so'rovnoma jadvali."],
 board:["Savol → yig'ish → <span class='w2'>jadval</span> → diagramma → xulosa.","Beshtalik: |||| + ustidan 1.","5 + 4 + 3 = 12 = so'ralganlar ✓.","Shkala 1 tadan, ustunlar.","Kalit ● = 5: 20, 15, 10.","Xulosa: qizil eng ko'p.","Ali ×2 — xato!"]};
