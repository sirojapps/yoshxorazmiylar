var CODE='2E4',TITLE='2-sinf · Pul: so‘m bilan hisob-kitob';
var E4COL={100:'#d9c08a',200:'#c7c7c7',500:'#e0b35a',1000:'#c9a6e8',2000:'#9fd3a8',5000:'#f2a6a6',10000:'#a6c8f2',20000:'#f2d58a'};
function e4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
function e4Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// pullar qatori: list = [qiymat,...]
function e4Draw(list,o){o=o||{};clear();var g=S.g,x=14,y=24,row=0;list.forEach(function(v,i){var coin=v<1000,w=coin?40:72,h=coin?40:38;if(x+w>350){x=14;y+=52}
 if(coin){E('circle',{cx:x+20,cy:y+20,r:19,fill:E4COL[v],stroke:'#8a7a50','stroke-width':1.5},g);T(g,x+20,y+24,String(v),{'font-size':11,'font-weight':800,fill:'#3a3a3a'})}
 else{E('rect',{x:x,y:y,width:w,height:h,rx:5,fill:E4COL[v]||'#ddd',stroke:'#6b6b6b','stroke-width':1.2},g);E('circle',{cx:x+14,cy:y+19,r:8,fill:'rgba(255,255,255,.5)'},g);T(g,x+46,y+24,e4f(v),{'font-size':11,'font-weight':800,fill:'#1d2b3a'})}
 if(o.mark&&o.mark.indexOf(i)>=0)E('rect',{x:x-3,y:y-3,width:w+6,height:h+6,rx:7,fill:'none',stroke:C.ok,'stroke-width':3},g);x+=w+8});
 var s=list.reduce(function(a,b){return a+b},0);if(!o.nosum)T(g,180,166,'Jami: '+e4f(s)+' so‘m',{'font-size':14,'font-weight':800,fill:C.blue});return s}
var P3=[function(){e4Draw([10000],{nosum:1});e4Msg('Narsa <b>7 500</b> so‘m. 10 000 so‘m berdik. Qaytim qancha?')},
 function(){e4Draw([10000],{nosum:1});e4Count([7500,8000,10000]);e4Msg('Sotuvchi «qo‘shib» sanaydi: 7 500 dan 8 000 gacha — <b>500</b>, 8 000 dan 10 000 gacha — <b>2 000</b>')},
 function(){e4Draw([500,2000],{});e4Msg('Qaytim: 500 + 2 000 = <b>2 500 so‘m</b>. Tekshiramiz: 10 000 − 7 500 = 2 500 ✓')}];
function e4Count(pts){var g=S.g,x0=30,x1=330,k=(x1-x0)/(pts[pts.length-1]-pts[0]),X=function(v){return x0+(v-pts[0])*k};E('line',{x1:x0,y1:120,x2:x1,y2:120,stroke:'#33475b','stroke-width':2},g);
 pts.forEach(function(p,i){E('circle',{cx:X(p),cy:120,r:5,fill:i?C.ok:C.blue},g);T(g,X(p),142,e4f(p),{'font-size':11,'font-weight':800});if(i){E('path',{d:'M'+X(pts[i-1])+' 114 Q'+(X(pts[i-1])+X(p))/2+' 84 '+X(p)+' 114',fill:'none',stroke:C.ok,'stroke-width':2},g);T(g,(X(pts[i-1])+X(p))/2,90,'+'+e4f(p-pts[i-1]),{'font-size':11,'font-weight':800,fill:C.ok})}})}
var P4=[function(){clear();var g=S.g;T(g,180,40,'5 000 so‘m · daftar 1 500 so‘m',{'font-size':14,'font-weight':800});e4Msg('Nechta daftar olish mumkin?')},
 function(){clear();var g=S.g;T(g,180,30,'5 000 so‘m · daftar 1 500 so‘m',{'font-size':13,'font-weight':800});var sum=0;for(var i=0;i<3;i++){sum+=1500;E('rect',{x:30+i*80,y:52,width:70,height:50,rx:6,fill:'#a6c8f2',stroke:'#2b6ca3'},g);T(g,65+i*80,74,'📓',{'font-size':18});T(g,65+i*80,96,e4f(sum),{'font-size':11,'font-weight':800})}E('rect',{x:270,y:52,width:70,height:50,rx:6,fill:'#fdeaea',stroke:C.bad,'stroke-dasharray':'4 3'},g);T(g,305,82,'6 000?',{'font-size':12,'font-weight':800,fill:C.bad});
  T(g,180,140,'3 ta: 4 500, qoldi 500 · 4-si uchun yetmaydi',{'font-size':12,'font-weight':800,fill:C.ok});e4Msg('1 500, 3 000, 4 500 — <b>3 ta</b>. 4-si 6 000 bo‘lardi — 5 000 dan ko‘p')}];
var STEPS=[
{h:"Pul va uning qiymati",sum:"Tanga va qog'oz pullar har xil qiymatda; jami summani qo'shib topamiz.",a:"m01",
 start:function(){S.e4L=[];e4Draw([]);e4Msg('Hamyonga pul soling')},fin:function(){e4Draw([5000,2000,1000,500,200])},
 html:"<p>Bizning pulimiz — <b>so'm</b>. Qog'oz pullar va tangalar har xil qiymatda. Hamyonga pul soling va jami qancha bo'lganini kuzating:</p>",
 btns:[["+ 5 000",function(c,done){e4Add(5000,done)}],["+ 2 000",function(c,done){e4Add(2000,done)}],["+ 1 000",function(c,done){e4Add(1000,done)}],["+ 500",function(c,done){e4Add(500,done)},'u'],["+ 200",function(c,done){e4Add(200,done)},'u'],["+ 100",function(c,done){e4Add(100,done)},'u']],g3:1,
 after:"<p>Pulni sanashning qulay yo'li: avval <b>eng kattasidan</b> boshlab, keyin kichiklarini qo'shamiz. 5 000 + 2 000 + 1 000 = 8 000, yana 500 + 200 = 700 — jami <b>8 700 so'm</b>.</p>",
 q:{t:"Valida 10 000 so'mlik 2 ta va 5 000 so'mlik 3 ta pul bor. Unda jami qancha?",opts:["25 000 so'm","35 000 so'm","5 000 so'm","50 000 so'm"],ok:1,why:"20 000 + 15 000 = 35 000.",hint:"Avval 10 minglik pullarni, keyin 5 mingliklarni qo'shing.",full:"2 ta 10 000 — 20 000. 3 ta 5 000 — 15 000. Jami 20 000 + 15 000 = 35 000 so'm. «25 000» — pullar sonini emas, turini sanagan."},
 tn:"O'yin-do'kon tashkil qiling: qog'ozdan pul yasab, bolalar narsa «sotib olsin». Hayotiy kontekst — Gollandiya RME yondashuvining asosi."},
{h:"Kam pul bilan to'lash",sum:"7 000 so'mni eng kam pul bilan: 5 000 + 2 000 (2 ta qog'oz).",a:"m02",
 start:function(){S.e4P=[];e4Draw([],{nosum:1});e4Msg('<b>7 000 so‘m</b> to‘lash kerak. Eng kam pul bilan to‘lang')},fin:function(){e4Draw([5000,2000]);e4Msg('5 000 + 2 000 = 7 000 — atigi <b>2 ta</b> pul')},
 html:"<p>Do'konda narsa <b>7 000 so'm</b>. Uni <b>eng kam sonli</b> pul bilan to'lang:</p>",
 btns:[["5 000",function(c,done){e4Pay(5000,done)}],["2 000",function(c,done){e4Pay(2000,done)}],["1 000",function(c,done){e4Pay(1000,done)}],["↺",function(){S.e4P=[];e4Draw([],{nosum:1});e4Msg('Qaytadan: 7 000 so‘m')},'u']],g2:1,
 after:"<p>Usul: <b>eng katta</b> pulni oling (5 000), qolganini (2 000) yana eng katta pul bilan yoping. 7 000 = 5 000 + 2 000 — <b>2 ta</b> pul. 7 ta 1 000 lik bilan ham bo'ladi, lekin bu noqulay.</p>",
 q:{t:"9 000 so'mni eng kam pul bilan qanday to'lash mumkin?",opts:["9 ta 1 000","5 000 + 2 000 + 2 000","5 000 + 2 000 + 1 000 + 1 000","2 000 + 2 000 + 2 000 + 2 000 + 1 000"],ok:1,why:"3 ta pul — eng kami.",hint:"Avval eng katta pulni oling. Qolganini qanday yopasiz?",full:"9 000 = 5 000 + 4 000, 4 000 = 2 000 + 2 000. Jami 3 ta pul. Boshqa usullarda 4 tadan ko'p pul kerak."},
 tn:"«Eng kam tanga» masalasi — informatika (ochko'z algoritm) asosidagi g'oya. Kuchli bolalarga «nechta usul bilan to'lash mumkin?» deb ham so'rang."},
{h:"Qaytim: sanab qo'shish usuli",sum:"10 000 − 7 500: 7 500 → 8 000 (+500) → 10 000 (+2 000) = 2 500.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Narsa <b>7 500 so'm</b>, biz <b>10 000 so'm</b> berdik. Sotuvchi qaytimni qanday hisoblaydi? Kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p>Qaytimni <b>ayirib</b> ham (10 000 − 7 500), <b>narxdan yuqoriga qo'shib</b> sanab ham topish mumkin: 7 500 → 8 000 → 10 000. Ikkinchi usul og'zaki hisoblashda juda qulay — butun dunyoda sotuvchilar shunday sanaydi.</p>",
 q:{t:"Qalam 1 200 so'm. Alida 1 400 so'm bor edi. Qalamni olgach qancha qoldi?",opts:["2 600 so'm","200 so'm","400 so'm","1 200 so'm"],ok:1,why:"1 400 − 1 200 = 200.",hint:"1 200 dan 1 400 gacha qancha qo'shish kerak?",full:"1 200 + 200 = 1 400, demak 200 so'm qoldi. «2 600» — qo'shib yuborgan, ayirish kerak edi."},
 tn:"Bolalar o'yin-do'konda sotuvchi bo'lib, qaytimni «qo'shib sanash» usulida bersin."},
{h:"Nechta sotib olish mumkin?",sum:"5 000 so'mga 1 500 lik daftardan: 1 500, 3 000, 4 500 — 3 ta (500 qoladi).",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Masala: <i>«Daftar 1 500 so'm. Alida 5 000 so'm bor. U eng ko'pi bilan nechta daftar olishi mumkin?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Narxni <b>qo'shib boramiz</b>, puldan oshib ketguncha: 1 500, 3 000, 4 500 — 3 ta, 6 000 esa 5 000 dan oshadi. Javob: <b>3 ta</b>, 500 so'm ortib qoladi. «Eng ko'pi bilan» — pul yetadigan eng katta son.</p>",
 q:{t:"Olma 500 so'm. 3 000 so'mga nechta olma olish mumkin?",opts:["3","6","5","15"],ok:1,why:"500 · 6 = 3 000.",hint:"500 ni necha marta qo'shsak 3 000 bo'ladi? 1 000 da nechta 500 bor?",full:"1 000 so'mda ikkita 500. 3 000 da 3 · 2 = 6 ta. Demak 6 ta olma. «3» — mingliklar sonini sanagan."},
 tn:"Bank: «4 minglik muzqaymoqdan 2 ta olib, qolganiga 1 minglik konfetdan eng ko'pi bilan nechta?» — avval qoldiqni toping."},
{h:"Narx, miqdor, qiymat",sum:"Qiymat = narx · miqdor: 3 ta 2 000 lik = 6 000 so'm.",a:"m05",
 start:function(){S.e4q=0;e4Shop(0)},fin:function(){e4Shop(3)},
 html:"<p>Bitta muzqaymoq <b>2 000 so'm</b>. Bir nechtasini savatga soling:</p>",
 btns:[["+ 🍦",function(c,done){if(S.e4q<6){S.e4q++;e4Shop(S.e4q);mvK(done,3)}}]],
 after:"<p>Uchta muzqaymoq: 2 000 + 2 000 + 2 000 = <b>2 000 · 3 = 6 000 so'm</b>. Bitta narsaning narxi — <b>narx</b>, nechta olingani — <b>miqdor</b>, hammasi uchun to'langan pul — <b>qiymat</b>: <b>qiymat = narx · miqdor</b>.</p>",
 q:{t:"Kitob 12 ming so'm, daftar kitobdan 9 ming so'm arzon. 1 ta kitob va 2 ta daftar necha pul?",opts:["24 ming so'm","18 ming so'm","15 ming so'm","30 ming so'm"],ok:1,why:"Daftar 3 ming, 2 ta — 6 ming, 12 + 6 = 18.",hint:"Avval daftarning narxini toping: 12 − 9.",full:"Daftar: 12 − 9 = 3 ming. 2 ta daftar: 6 ming. Kitob bilan: 12 + 6 = 18 ming so'm. «15» — faqat 1 ta daftarni qo'shgan."},
 tn:"«Narx · miqdor = qiymat» jadvalini doskaga chizing — 3-sinfda bu mavzu chuqurlashadi (3E2)."},
{h:"Tuzoq: bir nechta qadamli xarid",sum:"10 ming: 2 ta 4 minglik muzqaymoq (8 ming) → 2 ming qoldi → 1 minglik konfetdan 2 ta.",a:"m06",
 start:function(){e4Steps(0)},fin:function(){e4Steps(3)},
 html:"<p>Masala: <i>«Alida 10 ming so'm bor. U 4 ming so'mlik muzqaymoqdan 2 ta oldi. Qolgan puliga 1 ming so'mlik konfetdan eng ko'pi bilan nechta oladi?»</i> Bosqichma-bosqich:</p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.e4s=(S.e4s||0)+1;e4Steps(S.e4s);if(S.e4s>=3){b.disabled=true;done()}}]],
 after:"<p>Usul: <b>pul qanday sarflanayotganini ketma-ket</b> kuzating. Avval muzqaymoqlar: 4 · 2 = 8 ming, qoldi 10 − 8 = 2 ming. Keyin konfet: 2 ming — <b>2 ta</b>. «6» deganlar bitta muzqaymoqni hisoblagan.</p>",
 q:{t:"Alida 3 ta 10 minglik va 2 ta 5 minglik pul bor. U 27 minglik o'yinchoq oldi. Qancha qoldi?",opts:["3 ming","13 ming","23 ming","17 ming"],ok:1,why:"Puli 40 ming, 40 − 27 = 13 ming.",hint:"Avval Alida jami qancha pul borligini toping.",full:"30 ming + 10 ming = 40 ming. 40 − 27 = 13 ming so'm. «3 ming» — faqat 10 mingliklarni hisoblagan."},
 tn:"Bunday masalalarda bolalar har qadamni alohida qatorga yozsin: «Bor edi», «Sarfladi», «Qoldi»."},
{h:"Bilasizmi? So'm va pul tarixi",sum:"O'zbekistonda so'm 1994-yildan. Qadimda tangalar oltin va kumushdan zarb qilingan.",a:"m07",
 start:function(){e4Draw([100,200,500,1000,5000,10000]);e4Msg('O\u2018zbekiston so\u2018mi — 1994-yildan')},fin:function(){e4Draw([100,200,500,1000,5000,10000]);e4Msg('O\u2018zbekiston so\u2018mi — 1994-yildan')},
 html:"<p>💰 Mustaqil O'zbekistonning milliy puli — <b>so'm</b> — 1994-yildan muomalada. «So'm» so'zi qadimgi turkiy tilda «sof, toza» (sof kumush) ma'nosini bergan.</p><p>🏺 Qadimda pul o'rnida mol, don, tuz almashilgan. Keyin oltin, kumush, mis <b>tangalar</b> zarb qilingan — Samarqand va Buxoroda ham tanga zarbxonalari bo'lgan.</p><p>📱 Bugun ko'pchilik telefon va plastik karta orqali to'laydi — lekin hisob-kitob qoidalari o'zgarmaydi!</p>",
 tn:"Bolalardan uyda qanday to'lov usullari borligini so'rang (naqd, karta, telefon). Hammasida qaytim va qoldiqni hisoblash kerak."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){e4Draw([5000,2000,500]);e4Msg('Kattasidan boshlab sanang')},fin:function(){e4Draw([5000,2000,500]);e4Msg('Kattasidan boshlab sanang')},
 html:"<div class='memo'><ul><li>Pulni sanash: <b>kattasidan</b> boshlab qo'shing.</li><li>Eng kam pul bilan to'lash: eng katta pulni oling, qolganini yana kattasi bilan yoping.</li><li><b>Qaytim</b> = berilgan pul − narx; yoki narxdan qo'shib sanang: 7 500 → 8 000 → 10 000.</li><li><b>Nechta olish mumkin</b>: narxni qo'shib boring, puldan oshmaguncha.</li><li><b>Qiymat = narx · miqdor</b>.</li><li>Ko'p qadamli xarid: «bor edi → sarfladi → qoldi» ni ketma-ket yozing.</li></ul></div>",
 tn:"Keyingi darsni «10 000 so'mga 3 500 lik va 4 000 lik ikki narsa olindi. Qaytim?» (2 500) savoli bilan boshlang."}
];
function e4Add(v,done){S.e4L=S.e4L||[];if(S.e4L.length>=9)S.e4L=[];S.e4L.push(v);S.e4L.sort(function(a,b){return b-a});var s=e4Draw(S.e4L);e4Msg('Jami: <b>'+e4f(s)+' so‘m</b>');mvK(done,4)}
function e4Pay(v,done){S.e4P=S.e4P||[];var s=S.e4P.reduce(function(a,b){return a+b},0);if(s+v>7000){e4Msg('Ko‘p bo‘lib ketadi! '+e4f(s)+' + '+e4f(v)+' > 7 000');return}S.e4P.push(v);s+=v;e4Draw(S.e4P);
 if(s===7000){if(S.e4P.length===2){e4Msg('7 000 — atigi <b>2 ta</b> pul bilan! Zo‘r');done()}else e4Msg('7 000 bo‘ldi, lekin '+S.e4P.length+' ta pul. Kamroq pul bilan bo‘ladimi? ↺ ni bosing')}else e4Msg('Hozircha '+e4f(s)+'. Yana '+e4f(7000-s)+' kerak')}
function e4Shop(q){clear();var g=S.g;T(g,60,40,'🍦',{'font-size':40});T(g,60,80,'2 000 so‘m',{'font-size':12,'font-weight':800});E('rect',{x:120,y:20,width:220,height:100,rx:12,fill:'#fff',stroke:'#c9d3dd'},g);T(g,230,38,'Savat',{'font-size':11,fill:'#5b6b7b'});
 for(var i=0;i<q;i++)T(g,145+i*36,84,'🍦',{'font-size':28});T(g,230,150,q+' · 2 000 = '+e4f(q*2000)+' so‘m',{'font-size':15,'font-weight':800,fill:C.blue});e4Msg('Narx 2 000 · miqdor '+q+' = qiymat <b>'+e4f(q*2000)+'</b>')}
function e4Steps(k){S.e4s=k;clear();var g=S.g,rows=[['Bor edi','10 ming'],['Muzqaymoq: 4 · 2','− 8 ming'],['Qoldi','2 ming'],['Konfet (1 ming)','2 ta']];for(var i=0;i<4;i++){var on=i<=k;E('rect',{x:30,y:14+i*38,width:300,height:32,rx:8,fill:on?(i===3?'#e6f6ee':'#fff'):'#f4f6f8',stroke:on?'#c9d3dd':'#eef1f4'},g);if(on){T(g,44,35+i*38,rows[i][0],{'font-size':13,'text-anchor':'start','font-weight':700});T(g,316,35+i*38,rows[i][1],{'font-size':14,'text-anchor':'end','font-weight':800,fill:i===3?C.ok:C.blue})}}
 e4Msg(['Alida 10 ming so‘m bor','2 ta muzqaymoq: 4 · 2 = 8 ming','10 − 8 = 2 ming qoldi','2 mingga 1 minglik konfetdan — <b>2 ta</b>'][k])}
var PROBS=[
{t:"5 000 + 2 000 + 500 so'm — jami qancha?",o:["7 500 so'm","5 700 so'm","2 750 so'm","7 000 so'm"],k:0,s:"5 000 + 2 000 = 7 000, + 500 = 7 500."},
{t:"Valida 2 ta 10 minglik va 3 ta 5 minglik pul bor. Jami?",o:["35 ming so'm","25 ming so'm","50 ming so'm","5 ming so'm"],k:0,s:"20 + 15 = 35 ming."},
{t:"Narsa 7 500 so'm. 10 000 so'm berildi. Qaytim?",o:["2 500 so'm","3 500 so'm","17 500 so'm","2 000 so'm"],k:0,s:"10 000 − 7 500 = 2 500."},
{t:"Daftar 1 500 so'm. 5 000 so'mga eng ko'pi bilan nechta daftar olinadi?",o:["3","4","2","5"],k:0,s:"1 500 · 3 = 4 500 ≤ 5 000, 1 500 · 4 = 6 000 > 5 000."},
{t:"Olma 500 so'm. 3 000 so'mga nechta olma?",o:["6","3","5","15"],k:0,s:"3 000 da 6 ta 500."},
{t:"Bitta qalam 2 000 so'm. 4 ta qalam necha so'm?",o:["8 000 so'm","6 000 so'm","2 004 so'm","24 000 so'm"],k:0,s:"2 000 · 4 = 8 000."},
{t:"4 ta bir xil qalam 20 ming so'm. 1 ta qalam va 7 minglik daftar birga necha pul?",o:["12 ming so'm","27 ming so'm","5 ming so'm","13 ming so'm"],k:0,s:"1 qalam 20 : 4 = 5 ming, + 7 = 12 ming."},
{t:"Kitob 12 ming so'm, daftar undan 9 ming arzon. 1 kitob va 2 daftar necha pul?",o:["18 ming so'm","24 ming so'm","15 ming so'm","30 ming so'm"],k:0,s:"Daftar 3 ming, 12 + 3 + 3 = 18 ming."},
{t:"Alida 10 ming bor. 4 minglik muzqaymoqdan 2 ta oldi. Qolganiga 1 minglik konfetdan eng ko'pi bilan nechta oladi?",o:["2","6","3","1"],k:0,s:"10 − 8 = 2 ming → 2 ta konfet."},
{t:"Alida 3 ta 10 minglik va 2 ta 5 minglik bor. 27 minglik o'yinchoq oldi. Qancha qoldi?",o:["13 ming","3 ming","23 ming","17 ming"],k:0,s:"40 − 27 = 13 ming."},
{t:"9 000 so'mni eng kam pul bilan to'lash uchun nechta pul kerak (5 000, 2 000, 1 000 lik bor)?",o:["3 ta","2 ta","4 ta","9 ta"],k:0,s:"5 000 + 2 000 + 2 000 — 3 ta."},
{t:"Qalam 1 200 so'm. Alida 1 400 so'm bor edi. Qalamni olgach qancha qoldi?",o:["200 so'm","400 so'm","2 600 so'm","300 so'm"],k:0,s:"1 400 − 1 200 = 200."},
{t:"Non 3 000 so'm, sut non narxidan 2 marta qimmat. Sut necha so'm?",o:["6 000 so'm","5 000 so'm","1 500 so'm","3 002 so'm"],k:0,s:"3 000 · 2 = 6 000."},
{t:"Ali 20 000 so'm bilan do'konga bordi. 6 500 va 8 000 so'mlik narsa oldi. Qancha qoldi?",o:["5 500 so'm","14 500 so'm","6 500 so'm","4 500 so'm"],k:0,s:"6 500 + 8 000 = 14 500; 20 000 − 14 500 = 5 500."},
{t:"Muzqaymoq 3 000 so'm. Vali 2 ta oldi va 10 000 so'm berdi. Qaytim?",o:["4 000 so'm","7 000 so'm","6 000 so'm","1 000 so'm"],k:0,s:"3 000 · 2 = 6 000; 10 000 − 6 000 = 4 000."},
{t:"Qaysi summa eng katta?",o:["2 ta 5 000 lik","3 ta 2 000 lik","9 ta 1 000 lik","1 ta 5 000 va 4 ta 1 000 lik"],k:0,s:"10 000; 6 000; 9 000; 9 000. Eng kattasi 10 000."},
{t:"Ruchka 2 500 so'm. 10 000 so'mga nechta ruchka olinadi?",o:["4","5","3","2"],k:0,s:"2 500 · 4 = 10 000."},
{t:"Ali 4 500 so'm tejadi, Vali undan 1 500 so'm kam. Ikkalasida jami qancha?",o:["7 500 so'm","10 500 so'm","3 000 so'm","6 000 so'm"],k:0,s:"Vali 3 000; 4 500 + 3 000 = 7 500."},
{t:"Do'konda tuxum 1 500 so'm, 10 tasi necha so'm?",o:["15 000 so'm","1 510 so'm","150 so'm","10 500 so'm"],k:0,s:"1 500 · 10 = 15 000."},
{t:"Hamyonda 5 000 lik, 2 000 lik va 500 lik bittadan bor. 6 000 so'mlik narsani qaytimsiz to'lash mumkinmi?",o:["Yo'q, aniq 6 000 yig'ilmaydi","Ha, 5 000 + 500","Ha, 2 000 + 5 000","Ha, 5 000 + 2 000 − 500"],k:0,s:"Mumkin bo'lgan summalar: 500, 2 000, 2 500, 5 000, 5 500, 7 000, 7 500 — 6 000 yo'q."}
];
function PRACT_STAGE(){e4Draw([5000,2000,500]);e4Msg('Qiymat = narx · miqdor; qaytim = berilgan − narx')}
var PREP_DATA={teach:["So'm: qog'oz pul va tangalar; summani sanash (kattasidan boshlab).","Eng kam pul bilan to'lash.","Qaytim: ayirish va «qo'shib sanash» usuli.","Nechta olish mumkin; qiymat = narx · miqdor; ko'p qadamli xarid."],
 mist:["Pullarning qiymatini emas, sonini qo'shadi.","«Eng ko'pi bilan nechta» da puldan oshib ketadi.","Ko'p qadamli masalada bir qadamni tashlab ketadi.","Qaytimni topishda qo'shib yuboradi."],
 need:["Qog'oz pullar va tangalar (o'yin-do'kon uchun).","Narx yozilgan kartochkalar."],
 board:["<span class='w2'>5 000 + 2 000 + 1 000 + 500 + 200 = 8 700</span>.","<span class='w2'>7 000 = 5 000 + 2 000</span> (2 ta pul).","Qaytim: <span class='w2'>7 500 → 8 000 → 10 000 = 2 500</span>.","<span class='w2'>5 000 : 1 500</span> → 3 ta, 500 qoladi.","<span class='w2'>qiymat = narx · miqdor</span>."]};
