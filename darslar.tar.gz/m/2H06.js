var CODE='2H06',TITLE="2-sinf · Mantiqiy masalalar: kim, qayerda, nima? (jadval usuli)";
// ---------- mantiqiy jadval ----------
var H6={};
function h6Grid(rows,cols,o){o=o||{};clear();var g=S.g,n=rows.length,m=cols.length,cw=Math.min(54,250/m),ch=Math.min(34,128/n),x0=360-cw*m-14,y0=34;
 H6.m=o.m||rows.map(function(){return cols.map(function(){return ''})});H6.rows=rows;H6.cols=cols;H6.cells=[];
 cols.forEach(function(c,j){T(g,x0+j*cw+cw/2,y0-10,c,{'font-size':11,'font-weight':800,fill:C.blue})});
 rows.forEach(function(r,i){T(g,x0-8,y0+i*ch+ch/2+4,r,{'font-size':12,'font-weight':800,fill:'#1d2b3a','text-anchor':'end'});H6.cells[i]=[];
  cols.forEach(function(c,j){var x=x0+j*cw,y=y0+i*ch;var rc=E('rect',{x:x,y:y,width:cw-2,height:ch-2,rx:5,fill:'#fff',stroke:'#c9d3dd','stroke-width':1.4},g);var t=T(g,x+cw/2-1,y+ch/2+6,'',{'font-size':17,'font-weight':800,'pointer-events':'none'});H6.cells[i][j]={r:rc,t:t};
   if(o.tap){rc.style.cursor='pointer';rc.addEventListener('click',function(){var v=H6.m[i][j];H6.m[i][j]=v===''?'✗':(v==='✗'?'✓':'');h6Paint();if(o.tap)o.tap()})}})});
 h6Paint()}
function h6Paint(hl){H6.m.forEach(function(row,i){row.forEach(function(v,j){var c=H6.cells[i][j];c.t.textContent=v;c.t.setAttribute('fill',v==='✓'?C.ok:C.bad);c.r.setAttribute('fill',hl&&hl[i+','+j]?'#fff3c4':(v==='✓'?'#e6f6ee':(v==='✗'?'#fdf1f1':'#fff')))})})}
function h6Set(list,v){list.forEach(function(p){H6.m[p[0]][p[1]]=v})}
function h6Ok(sol){for(var i=0;i<sol.length;i++)for(var j=0;j<sol.length;j++)if((H6.m[i][j]==='✓')!==(sol[i]===j))return false;return true}
function h6Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// 1-qadam jumbog'i: Ali, Vali, Soli — olma, nok, uzum
var J1={rows:['Ali','Vali','Soli'],cols:['olma','nok','uzum'],sol:[2,1,0]};
// 3-qadam: Zuhra, Gulnora, Shoira, Madina — ro'mollar
var J3={rows:['Zuhra','Gulnora','Shoira','Madina'],cols:['qizil','oq','ko‘k','yashil']};
var P3=[function(){h6Grid(J3.rows,J3.cols);h6Msg('Jadval bo‘sh. Shartlarni bittalab qo‘llaymiz')},
 function(){h6Grid(J3.rows,J3.cols);h6Set([[3,3]],'✓');h6Set([[3,0],[3,1],[3,2],[0,3],[1,3],[2,3]],'✗');h6Paint({'3,3':1});h6Msg('1) «Madinaning ro‘moli yashil» → ✓. Uning qatori va ustunining qolgani ✗')},
 function(){h6Grid(J3.rows,J3.cols,{m:H6.m});h6Set([[0,0],[0,1]],'✗');h6Set([[0,2]],'✓');h6Set([[1,2],[2,2]],'✗');h6Paint({'0,0':1,'0,1':1,'0,2':1});h6Msg('2) «Zuhraniki qizil ham, oq ham emas» → qolgan yagona joy — ko‘k ✓')},
 function(){h6Grid(J3.rows,J3.cols,{m:H6.m});h6Set([[1,1]],'✗');h6Set([[1,0]],'✓');h6Set([[2,0]],'✗');h6Set([[2,1]],'✓');h6Paint({'1,0':1,'1,1':1,'2,1':1});h6Msg('3) «Gulnoraniki oq emas» → Gulnora qizil. Shoiraga qolgani — <b>oq</b>')}];
// 6-qadam: almashtirish
var P5=[function(){h6Kids(0)},function(){h6Kids(1)},function(){h6Kids(2)}];
var P6=[function(){h6Trade(0);h6Msg('1 tarvuz = 3 qovun, 1 qovun = 2 olma. 1 tarvuz = ? olma')},function(){h6Trade(1);h6Msg('Tarvuzni 3 ta qovunga almashtiramiz')},function(){h6Trade(2);h6Msg('Har qovunni 2 tadan olmaga: 2 + 2 + 2 = <b>6</b> olma')}];
function h6Trade(k){clear();var g=S.g;function fruit(x,y,e,s){T(g,x,y,e,{'font-size':s||26})}
 if(k===0){fruit(180,90,'🍉',46)}
 if(k===1){[100,180,260].forEach(function(x){fruit(x,90,'🍈',36)});T(g,180,140,'1 🍉 = 3 🍈',{'font-size':15,'font-weight':800,fill:C.blue})}
 if(k===2){[90,180,270].forEach(function(x){fruit(x,60,'🍈',26);fruit(x-16,110,'🍎',22);fruit(x+16,110,'🍎',22);E('line',{x1:x,y1:70,x2:x-14,y2:92,stroke:'#9aa8b6'},g);E('line',{x1:x,y1:70,x2:x+14,y2:92,stroke:'#9aa8b6'},g)});T(g,180,160,'1 🍉 = 3 🍈 = 6 🍎',{'font-size':15,'font-weight':800,fill:C.ok})}}
// 7-qadam: oila daraxti
var P7=[function(){h6Tree(0);h6Msg('«Aziz — Sherzodning o‘g‘li. Sherzod — Muslimning o‘g‘li.» Aziz Muslimga kim?')},function(){h6Tree(1);h6Msg('Sherzod — Muslimning o‘g‘li: Muslim — ota, Sherzod — o‘g‘il')},function(){h6Tree(2);h6Msg('Aziz — Sherzodning o‘g‘li, ya’ni Muslimning <b>nabirasi</b>')}];
function h6Tree(k){clear();var g=S.g;function box(x,y,t,col){E('rect',{x:x-46,y:y-16,width:92,height:30,rx:8,fill:col||'#fff',stroke:C.line,'stroke-width':1.5},g);T(g,x,y+4,t,{'font-size':13,'font-weight':800})}
 box(180,30,'Muslim',k>=1?'#fde6c8':'#fff');if(k>=1){E('line',{x1:180,y1:45,x2:180,y2:70,stroke:C.line,'stroke-width':2},g);T(g,228,62,'o‘g‘li',{'font-size':10,fill:C.blue})}
 box(180,86,'Sherzod',k>=1?'#fdf0e1':'#fff');if(k>=2){E('line',{x1:180,y1:101,x2:180,y2:126,stroke:C.line,'stroke-width':2},g);T(g,228,118,'o‘g‘li',{'font-size':10,fill:C.blue});E('path',{d:'M126 30 Q60 90 126 142',fill:'none',stroke:C.ok,'stroke-width':2,'stroke-dasharray':'5 4'},g);T(g,52,92,'nabira',{'font-size':12,'font-weight':800,fill:C.ok})}
 box(180,142,'Aziz',k>=2?'#e1f4f2':'#fff')}
var STEPS=[
{h:"Jadval — eng yaxshi yordamchi",sum:"Mantiqiy masalada jadval chizamiz: ✓ — «ha», ✗ — «yo'q».",a:"m01",
 start:function(){h6Grid(J1.rows,J1.cols,{tap:function(){}});h6Msg('Kataklarni bosing: bir marta — ✗, ikki marta — ✓')},fin:function(){h6Grid(J1.rows,J1.cols,{m:[['✗','✗','✓'],['✗','✓','✗'],['✓','✗','✗']]});h6Msg('Ali — uzum, Vali — nok, Soli — olma')},
 html:"<p>Ali, Vali va Soli olma, nok va uzumdan <b>bittadan</b> yedi (har biri boshqa meva).</p><ul><li>Vali nok yedi.</li><li>Ali olma yemadi.</li></ul><p>Kim nima yedi? Jadvalni to'ldiring: katakni <b>bir marta</b> bossangiz — ✗ («yo'q»), <b>ikki marta</b> — ✓ («ha»). Keyin «Tekshirish»ni bosing.</p>",
 btns:[["✔ Tekshirish",function(c,done){if(h6Ok(J1.sol)){h6Msg('To‘g‘ri! Ali — uzum, Vali — nok, Soli — olma');done()}else h6Msg('Hali emas. Har qatorda va har ustunda bitta ✓ bo‘lishi kerak. Vali — nok, demak nok ustunida boshqalarga ✗')}]],
 after:"<p>Yechim: Vali — nok ✓. Demak, nokni boshqa hech kim yemagan, Vali ham boshqa meva yemagan — ular ✗. Ali olma yemagan (✗) va nok ham emas — demak Ali <b>uzum</b>. Soliga qolgani — <b>olma</b>.</p>",
 q:{t:"Uch qiz — Lola, Nigora, Oysha — qizil, ko'k, sariq sharlardan bittadan oldi. Lola ko'k oldi. Nigora qizil olmadi. Oysha qaysi sharni oldi?",opts:["qizil","ko'k","sariq","yashil"],ok:0,why:"Lola — ko'k, Nigora qizil emas → sariq, Oyshaga qizil qoladi.",hint:"Jadval chizing. Lola — ko'k. Nigora qizil emas va ko'k ham emas — u nima oladi?",full:"Lola ko'k oldi. Nigora qizil emas, ko'k ham band — Nigora sariq. Qolgani qizil — Oyshaniki."},
 tn:"«Mantiqiy jadval» usuli butun dunyoda (AQSh, Rossiya, Yaponiya olimpiada tayyorgarliklarida) asosiy usul. Doskada 3×3 jadval chizib, shartlarni bolalar navbat bilan ✓/✗ qilib belgilasin."},
{h:"Oltin qoida: bitta ✓ — qolgani ✗",sum:"Qatorda bitta ✓ bo'lsa, shu qator va shu ustundagi boshqa hamma kataklar ✗ bo'ladi.",a:"m02",
 start:function(){h6Grid(['Ali','Vali','Soli'],['olma','nok','uzum']);h6Set([[1,1]],'✓');h6Paint({'1,1':1});h6Msg('Vali — nok ✓')},fin:function(){h6Grid(['Ali','Vali','Soli'],['olma','nok','uzum']);h6Set([[1,1]],'✓');h6Set([[1,0],[1,2],[0,1],[2,1]],'✗');h6Paint();h6Msg('Bitta ✓ — 4 ta ✗')},
 html:"<p>Bitta ✓ qo'yganingiz zahoti bir nechta ✗ ham paydo bo'ladi. Tugmani bosib ko'ring:</p>",
 btns:[["✗ larni qo'yish",function(c,done){h6Set([[1,0],[1,2],[0,1],[2,1]],'✗');h6Paint({'1,0':1,'1,2':1,'0,1':1,'2,1':1});h6Msg('Vali boshqa meva yemagan (qatori), nokni boshqalar yemagan (ustuni)');done()}]],
 after:"<p>Shuning uchun har bir ✓ dan keyin darhol uning <b>qatori</b> va <b>ustunini</b> ✗ bilan to'ldiring. Ko'pincha shunda javob o'zi chiqib qoladi: qatorda bitta bo'sh katak qolsa — u ✓.</p>",
 q:{t:"4×4 jadvalda bitta ✓ qo'yildi. Shu ✓ tufayli nechta katakka ✗ qo'yish mumkin?",opts:["3","6","8","4"],ok:1,why:"Qatorda 3 ta, ustunda 3 ta boshqa katak: 3 + 3 = 6.",hint:"✓ turgan qatorda yana nechta katak bor? Ustunda-chi?",full:"4×4 jadvalda ✓ ning qatorida yana 3 ta, ustunida yana 3 ta katak bor. Ularning hammasi ✗: 3 + 3 = 6. «8» — ✓ ning o'zini ham ikki marta sanash xatosi."},
 tn:"Bolalarga ✓ qo'yganda «qator — ustun» deb ovoz chiqarib aytishni o'rgating. Bu xatoni ancha kamaytiradi."},
{h:"4 kishi, 4 rang: shartlarni ketma-ket",sum:"Madina — yashil; Zuhra qizil ham oq ham emas → ko'k; Gulnora oq emas → qizil; Shoira — oq.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[0]();P3[1]();P3[2]();P3[3]()},
 html:"<p>Zuhra, Gulnora, Shoira va Madina qizil, oq, ko'k va yashil ro'mol o'radi (har biri boshqa rang).</p><ul><li>Madinaning ro'moli yashil.</li><li>Zuhraning ro'moli qizil ham, oq ham emas.</li><li>Gulnoraning ro'moli oq emas.</li></ul><p>Shartlarni bittalab jadvalga qo'yamiz:</p>",
 btns:[phaser(P3,'▶ Keyingi shart')],
 after:"<p>Javob: Zuhra — ko'k, Gulnora — qizil, Shoira — <b>oq</b>, Madina — yashil. Har bir shartdan keyin «oltin qoida»ni ishlatdik — shuning uchun oxirgisi o'zi chiqdi.</p>",
 q:{t:"Mushuk, it, quyon va to'tiqushning ismlari: Mosh, Boy, Oppoq, Qora. To'tiqush — Qora. It Mosh ham, Oppoq ham emas. Quyon Mosh emas. Mushukning ismi nima?",opts:["Mosh","Boy","Oppoq","Qora"],ok:0,why:"To'tiqush — Qora, it — Boy, quyon — Oppoq, mushuk — Mosh.",hint:"Avval to'tiqushni qo'ying. It Mosh ham, Oppoq ham emas, Qora band — it kim?",full:"To'tiqush — Qora. It Mosh emas, Oppoq emas, Qora band — it Boy. Quyon Mosh emas, Boy va Qora band — quyon Oppoq. Mushukka qolgani — Mosh."},
 tn:"Shartlarni kartochkalarga yozib, «qaysi shartdan boshlasak oson?» deb so'rang. Eng aniq shart («Madina — yashil») dan boshlash odatini shakllantiring."},
{h:"Tuzoq: so'zni diqqat bilan o'qing",sum:"«8 tasidan boshqa hammasi uchib ketdi» — 8 tasi qoldi, ayirish shart emas.",a:"m04",
 start:function(){h6Birds(false)},fin:function(){h6Birds(true)},
 html:"<p><i>«Daraxtda 23 ta chumchuq o'tirgan edi. Mushuk kelganda <b>8 tasidan boshqa</b> hamma chumchuqlar uchib ketdi. Daraxtda nechta chumchuq qoldi?»</i></p><p>Ko'pchilik darhol 23 − 8 = 15 deydi. Tugmani bosib, nima bo'lganini ko'ring.</p>",
 btns:[["🐈 Mushuk keldi",function(c,done,b){b.disabled=true;h6Birds(true);done()}]],
 after:"<p>«8 tasidan <b>boshqa</b> hammasi uchib ketdi» — demak, aynan <b>8 tasi qoldi</b>! Bunday masalalarda hisoblashdan oldin <b>so'zlarni</b> tushunish kerak.</p>",
 q:{t:"Cho'ponning 15 ta qo'yi bor edi. 9 tasidan boshqa hammasi qochib ketdi. Nechta qo'y qoldi?",opts:["6","9","15","24"],ok:1,why:"«9 tasidan boshqa hammasi qochdi» — 9 tasi qoldi.",hint:"Qaysi qo'ylar qochmadi?",full:"«9 tasidan boshqa» — ya'ni 9 tasi qochmadi, qolgani qochdi. Demak 9 ta qoldi. «6» — 15 − 9 ni hisoblash xatosi."},
 tn:"Masala matnidagi kalit so'zlarni («boshqa», «faqat», «hammasi») chizib qo'yish odatini shakllantiring."},
{h:"Tuzoq: kim hisobga kiradi?",sum:"12 bola: 1 tasi qidiruvchi, 11 tasi bekindi. 5 tasi topildi → 6 tasi qoldi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;h6Kids(2)},
 html:"<p><i>«12 ta bola bekinmachoq o'ynamoqda. Aziza qidiruvchi, qolganlar bekindi. Aziza 5 ta bolani topdi. U nechta bolani hali topmadi?»</i></p>",
 btns:[phaser(P5,'▶ Keyingi')],
 after:"<p>Aziza o'zi ham 12 ta bolaning ichida! Bekinganlar: 12 − 1 = <b>11</b>. Topilmaganlar: 11 − 5 = <b>6</b>. «7» deganlar Azizani bekinganlar qatoriga qo'shib qo'ygan.</p>",
 q:{t:"Navbatda 10 kishi turibdi. Doniyor oldidan 4 kishi bor. Uning orqasida nechta kishi bor?",opts:["6","4","5","3"],ok:2,why:"10 − 4 (oldidagilar) − 1 (Doniyorning o'zi) = 5.",hint:"Doniyorning o'zini unutmang: u ham 10 kishining ichida.",full:"Oldida 4 kishi, keyin Doniyorning o'zi — bu 5 kishi. Orqada: 10 − 5 = 5 kishi. «6» — Doniyorni sanamaslik xatosi."},
 tn:"Rasm chizib yechish (doiracha — bola) bu turdagi xatolarni deyarli butunlay yo'qotadi. Bolalarni har safar chizishga undang."},
{h:"Almashtirish zanjiri",sum:"1 tarvuz = 3 qovun, 1 qovun = 2 olma → 1 tarvuz = 3 · 2 = 6 olma.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bozorda: <b>1 tarvuz = 3 qovun</b>, <b>1 qovun = 2 olma</b>. 1 tarvuzga nechta olma beriladi? Bosqichma-bosqich almashtiramiz.</p>",
 btns:[phaser(P6,'▶ Almashtirish')],
 after:"<p>Zanjirni bir xalqadan keyingisiga o'tib yechamiz: tarvuz → qovunlar → olmalar. Har qovun 2 ta olma, qovun esa 3 ta: 2 + 2 + 2 = <b>6</b>.</p>",
 q:{t:"1 mashina = 6 askarcha, 1 askarcha = 4 sharcha. 1 mashinaga nechta sharcha beriladi?",opts:["10","24","6","2"],ok:1,why:"6 askarcha, har biri 4 sharcha: 6 · 4 = 24.",hint:"Avval mashinani askarchalarga almashtiring, keyin har askarchani sharchalarga.",full:"1 mashina = 6 askarcha. Har askarcha 4 ta sharcha: 4 + 4 + 4 + 4 + 4 + 4 = 24. «10» — 6 va 4 ni qo'shish xatosi."},
 tn:"Haqiqiy narsalar (tugma, cho'p) bilan «bozor o'yini» o'ynang: bir bola sotuvchi, ikkinchisi xaridor."},
{h:"Qarindoshlik masalalari",sum:"Aziz — Sherzodning o'g'li, Sherzod — Muslimning o'g'li → Aziz Muslimning nabirasi.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p><i>«Aziz — Sherzodning o'g'li, Sherzod esa Muslimning o'g'li. Aziz Muslimga kim bo'ladi?»</i> Shajara (oila daraxti) chizamiz.</p>",
 btns:[phaser(P7,'▶ Shajarani chizish')],
 after:"<p>Shajarada ota — tepada, o'g'il — pastda. Aziz Muslimdan <b>ikki pog'ona</b> pastda — demak, <b>nabirasi</b>, Muslim esa uning <b>bobosi</b>.</p>",
 q:{t:"Lolaning onasi Malika, Malikaning onasi Zebo. Zebo Lolaga kim bo'ladi?",opts:["onasi","buvisi","opasi","xolasi"],ok:1,why:"Onaning onasi — buvi.",hint:"Shajara chizing: Zebo → Malika → Lola.",full:"Zebo — Malikaning onasi, Malika — Lolaning onasi. Zebo Loladan ikki pog'ona yuqorida — buvisi."},
 tn:"Bolalar o'z oilasining 3 avlodli shajarasini chizib kelsin — bu darsni hayotga bog'laydi."},
{h:"Bilasizmi? Detektivlar usuli",sum:"Jadval bilan «yo'q»larni o'chirib, qolgan yagona javobni topish — detektivlar va kompyuterlar usuli.",a:"m08",
 start:function(){h6Grid(J1.rows,J1.cols,{m:[['✗','✗','✓'],['✗','✓','✗'],['✓','✗','✗']]});h6Msg('Ortiqchasini o‘chir — qolgani javob')},fin:function(){h6Grid(J1.rows,J1.cols,{m:[['✗','✗','✓'],['✗','✓','✗'],['✓','✗','✗']]});h6Msg('Ortiqchasini o‘chir — qolgani javob')},
 html:"<p>🔍 Mashhur kitob qahramoni detektiv <b>Sherlok Xolms</b> shunday degan: «Imkonsiz narsalarni chiqarib tashlang — qolgani, qanchalik g'alati bo'lmasin, haqiqatdir». Biz jadvalda aynan shunday qildik: ✗ bilan imkonsizlarni o'chirib, qolgan ✓ ni topdik.</p><p>💻 Bugun kompyuterlar ham jumboq va jadvallarni xuddi shu «o'chirib chiqish» usuli bilan yechadi.</p>",
 tn:"Bolalarga o'zlari 3×3 jumboq tuzib, do'stiga yechishga berishni topshiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){h6Grid(J1.rows,J1.cols,{m:[['✗','✗','✓'],['✗','✓','✗'],['✓','✗','✗']]});h6Msg('Jadval: ✓ — ha, ✗ — yo‘q')},fin:function(){h6Grid(J1.rows,J1.cols,{m:[['✗','✗','✓'],['✗','✓','✗'],['✓','✗','✗']]});h6Msg('Jadval: ✓ — ha, ✗ — yo‘q')},
 html:"<div class='memo'><ul><li>Kim — nima masalasida <b>jadval</b> chizing: qatorlar — kishilar, ustunlar — narsalar.</li><li>✓ — «ha», ✗ — «yo'q». Har qator va ustunda <b>bitta</b> ✓.</li><li>✓ qo'ydingizmi — uning qatori va ustunini ✗ bilan to'ldiring.</li><li>Eng aniq shartdan boshlang («Madina — yashil»).</li><li>So'zlarni diqqat bilan o'qing: «8 tasidan <b>boshqa</b>…» — 8 tasi qoldi.</li><li>Kim hisobga kiradi? Qidiruvchi, navbatdagi bola o'zi ham sanaladi.</li><li>Almashtirish — zanjir bo'ylab: 1 🍉 = 3 🍈 = 6 🍎.</li><li>Qarindoshlik — shajara chizing.</li></ul></div>",
 tn:"Har dars boshida 1 ta qisqa mantiqiy jumboq bering — 2 oyda natija aniq seziladi."}
];
function h6Birds(fly){clear();var g=S.g,R=rnd(3);E('path',{d:'M40 165 Q60 60 180 50 Q300 60 320 165',fill:'#cfe8c5',stroke:'#7aa86a','stroke-width':2},g);E('rect',{x:172,y:120,width:16,height:50,fill:'#8a5a24'},g);
 for(var i=0;i<23;i++){var x=70+R()*220,y=70+R()*70;var stay=i<8;if(fly&&!stay){x=20+R()*320;y=10+R()*30}T(g,x,y,'🐦',{'font-size':fly&&!stay?12:16,opacity:fly&&!stay?.5:1})}
 if(fly){T(g,330,150,'🐈',{'font-size':28})}
 h6Msg(fly?'Qolganlar: <b>8 ta</b> — aynan «8 tasidan boshqa»si uchib ketdi':'23 ta chumchuq')}
function h6Kids(k){clear();var g=S.g;for(var i=0;i<12;i++){var x=30+(i%6)*58,y=i<6?50:120;var seek=i===0,found=i>=1&&i<=5;
  E('circle',{cx:x,cy:y,r:18,fill:seek?'#f7c6d0':(k>=2&&found?'#e6f6ee':(k>=1&&!seek?'#e8f1fb':'#fff')),stroke:seek?C.bad:C.line,'stroke-width':1.6},g);T(g,x,y+6,seek?'👧':'🧒',{'font-size':18});if(seek)T(g,x,y+32,'Aziza',{'font-size':10,'font-weight':800,fill:C.bad});if(k>=2&&found)T(g,x+14,y-12,'✓',{'font-size':12,'font-weight':800,fill:C.ok})}
 h6Msg(k===0?'12 ta bola. Aziza — qidiruvchi':(k===1?'Bekinganlar: 12 − 1 = <b>11</b> (Azizaning o‘zi bekinmagan!)':'Topildi 5 ta. Topilmagan: 11 − 5 = <b>6</b>'))}
var PROBS=[
{t:"Ali, Vali, Soli olma, nok, uzumdan bittadan yedi (har biri boshqa). Vali nok yedi, Ali olma yemadi. Soli nima yedi?",o:["olma","nok","uzum","uzum va olma"],k:0,s:"Vali — nok. Ali olma emas → uzum. Soli — olma."},
{t:"Ali, Vali, Sardor, G'ani: futbol, kurash, suzish, shaxmat (har biri boshqa). G'ani — shaxmat, Vali — futbol, Ali suzmaydi. Sardor nima bilan shug'ullanadi?",o:["suzish","kurash","futbol","shaxmat"],k:0,s:"G'ani — shaxmat, Vali — futbol, Ali suzish emas → kurash. Sardor — suzish."},
{t:"Daraxtda 23 ta chumchuq bor edi. 8 tasidan boshqasi uchib ketdi. Nechta qoldi?",o:["8","15","23","31"],k:0,s:"«8 tasidan boshqa» uchdi — 8 tasi qoldi."},
{t:"12 bola bekinmachoq o'ynadi: Aziza qidiradi, qolganlar bekindi. Aziza 5 tasini topdi. Nechtasi topilmadi?",o:["6","7","5","12"],k:0,s:"Bekinganlar 12 − 1 = 11. Topilmagan: 11 − 5 = 6."},
{t:"Aziz — Sherzodning o'g'li, Sherzod — Muslimning o'g'li. Aziz Muslimga kim?",o:["nabirasi","o'g'li","ukasi","jiyani"],k:0,s:"Ikki pog'ona pastda — nabira."},
{t:"1 mashina = 6 askarcha, 1 askarcha = 4 sharcha. 1 mashina = ? sharcha",o:["24","10","6","12"],k:0,s:"6 · 4 = 24."},
{t:"Zuhra, Gulnora, Shoira, Madina — qizil, oq, ko'k, yashil ro'mol. Madina — yashil, Zuhra qizil ham, oq ham emas, Gulnora oq emas. Shoiraning ro'moli?",o:["oq","qizil","ko'k","yashil"],k:0,s:"Madina — yashil, Zuhra — ko'k, Gulnora — qizil, Shoira — oq."},
{t:"Navbatda 9 kishi. Lola oldidan 3 kishi bor. Uning orqasida nechta kishi?",o:["5","6","3","4"],k:0,s:"9 − 3 − 1 = 5."},
{t:"Nilufar, Malika, Sevara qizil, ko'k, yashil qo'g'irchoqdan bittadan oldi. Nilufar — ko'k. Malika yashil olmadi. Sevaraniki qanday?",o:["yashil","qizil","ko'k","sariq"],k:0,s:"Nilufar — ko'k, Malika yashil emas → qizil, Sevara — yashil."},
{t:"Barno, Lola, Nigora 1-, 2-, 3-sinfda o'qiydi (har biri boshqa sinfda). Barno 1-sinfda, Lola Nigoradan yuqori sinfda. Nigora nechanchi sinfda?",o:["2-sinfda","3-sinfda","1-sinfda","4-sinfda"],k:0,s:"Barno — 1. Lola Nigoradan yuqori → Lola 3, Nigora 2."},
{t:"1 tarvuz = 2 qovun, 1 qovun = 3 olma. 2 tarvuz = ? olma",o:["12","6","5","10"],k:0,s:"1 tarvuz = 6 olma, 2 tarvuz = 12 olma."},
{t:"Lolaning onasi Malika, Malikaning onasi Zebo. Zebo Lolaga kim?",o:["buvisi","onasi","opasi","xolasi"],k:0,s:"Onaning onasi — buvi."},
{t:"Savatda 10 ta olma bor edi. 3 tasidan boshqa hammasini yeb qo'yishdi. Nechta qoldi?",o:["3","7","10","13"],k:0,s:"«3 tasidan boshqa» yeyildi — 3 tasi qoldi."},
{t:"Do'stlar Ali, Vali, G'ani: biri shifokor, biri haydovchi, biri o'qituvchi. Ali shifokor emas, Vali haydovchi, G'ani o'qituvchi emas. Ali kim?",o:["o'qituvchi","shifokor","haydovchi","dehqon"],k:0,s:"Vali — haydovchi. G'ani o'qituvchi emas → shifokor. Ali — o'qituvchi."},
{t:"Tosh, daraxt va kulbaga 1, 7, 9 raqamlari yashirildi. 1 toshda emas. 9 toshda ham, kulbada ham emas. Tosh, daraxt, kulba tartibida raqamlar qanday?",o:["791","179","719","917"],k:0,s:"9 — daraxtda. 1 toshda emas → kulbada. Toshda 7: 7, 9, 1."},
{t:"Sinfda 8 o'quvchi. Har biri navbatchilikda bir marta turdi, Akmal birinchi, Dilshod oxirgi bo'ldi. Ular orasida nechta o'quvchi navbatchilik qildi?",o:["6","8","7","5"],k:0,s:"8 − 2 = 6 (Akmal va Dilshod sanalmaydi)."},
{t:"Bobur Jasurdan katta. Doniyor Jasurdan kichik, lekin Sardordan katta. Eng kattasi kim?",o:["Bobur","Jasur","Doniyor","Sardor"],k:0,s:"Bobur > Jasur > Doniyor > Sardor."},
{t:"Uchta qutida qalam, ruchka, o'chirg'ich (bittadan). Yozuvlarning hammasi noto'g'ri: 1-quti «Qalam», 2-quti «Ruchka», 3-quti «Qalam yoki ruchka». O'chirg'ich qaysi qutida?",o:["3-qutida","1-qutida","2-qutida","hech birida"],k:0,s:"3-quti yozuvi noto'g'ri → unda qalam ham, ruchka ham emas → o'chirg'ich."},
{t:"1 olma = 2 nok, 1 nok = 3 o'rik. 1 olma va 1 nok birga = ? o'rik",o:["9","6","5","12"],k:0,s:"1 olma = 6 o'rik, 1 nok = 3 o'rik. 6 + 3 = 9."},
{t:"Oilada o'g'il bolaning bitta akasi va ikkita singlisi bor. Oilada nechta farzand?",o:["4","3","5","6"],k:0,s:"O'zi + akasi + 2 singlisi = 4."}
];
function PRACT_STAGE(){h6Grid(['A','B','C'],['1','2','3'],{tap:function(){}});h6Msg('Qoralama jadval: kataklarni bosib belgilang')}
var PREP_DATA={teach:["Mantiqiy masalalarni jadval (✓/✗) yordamida yechish.","«Oltin qoida»: bitta ✓ — qatori va ustuni ✗.","Shartni eng aniqidan boshlab ketma-ket qo'llash.","Matndagi tuzoq so'zlar («…dan boshqa»), kim hisobga kirishi, almashtirish zanjiri, qarindoshlik."],
 mist:["Jadvalsiz «boshda» yechishga urinadi va adashadi.","«8 tasidan boshqa uchib ketdi» da ayirib yuboradi.","Qidiruvchini, navbatdagi bolani o'zi sanamaydi.","Almashtirishda sonlarni qo'shib yuboradi (6 + 4)."],
 need:["Doskada 3×3 va 4×4 jadval.","Rangli kartochkalar (ism va narsalar)."],
 board:["Jadval: qatorlar — ismlar, ustunlar — narsalar.","✓ → qatori va ustuni ✗.","Shartlarni raqamlab yozing: 1), 2), 3).","«…dan boshqa» — chizib qo'ying.","Almashtirish: <span class='w2'>1 🍉 = 3 🍈 = 6 🍎</span>.","Shajara: bobo → ota → nabira."]};
