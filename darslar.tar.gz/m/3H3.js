var CODE='3H3',TITLE='3-sinf · Doira va aylana: radius, diametr';
function h3Pt(cx,cy,r,deg){var a=deg*Math.PI/180;return [cx+r*Math.cos(a),cy-r*Math.sin(a)]}
function h3Arc(cx,cy,r,from,to,o){o=o||{};var pts=[];for(var d=from;d<=to+0.01;d+=4)pts.push(h3Pt(cx,cy,r,d).join(','));return E('polyline',{points:pts.join(' '),fill:o.fill||'none',stroke:o.c||C.bad,'stroke-width':o.w||3,'stroke-linecap':'round'},S.g)}
function h3Circ(cx,cy,r,o){o=o||{};return E('circle',{cx:cx,cy:cy,r:r,fill:o.fill||'none',stroke:o.c||C.bad,'stroke-width':o.w||3,'stroke-dasharray':o.d||''},S.g)}
function h3O(cx,cy,l){g3Dot([cx,cy],'#33475b',3.5);T(S.g,cx-6,cy+15,l||'O',{'font-size':12,'font-weight':800})}
// sirkul bilan aylana chizish
function h3Draw(deg){clear('#ffffff');var cx=180,cy=92,r=60,g=S.g;if(deg>0)h3Arc(cx,cy,r,0,deg);
 var p=h3Pt(cx,cy,r,deg),hx=(cx+p[0])/2,hy=Math.min(cy,p[1])-48;g3Line([cx,cy],[hx,hy],{w:3,c:'#5b6b7b'});g3Line([hx,hy],p,{w:3,c:'#5b6b7b'});E('circle',{cx:hx,cy:hy,r:5,fill:'#33475b'},g);g3Dot(p,C.bad,4);h3O(cx,cy);
 g3Msg(deg===0?'Sirkul ignasini O nuqtaga qo‘ydik, oyoqlarini 3 sm ochdik':deg<360?'Sirkulni aylantirmoqdamiz: '+deg+'°':'<b>Aylana</b> tayyor! Hamma nuqtalari O dan 3 sm uzoqlikda')}
var P1=[function(){h3Draw(0)},function(){h3Draw(90)},function(){h3Draw(180)},function(){h3Draw(270)},function(){h3Draw(360)}];
function h3Kind(m){clear('#ffffff');var g=S.g;
 h3Circ(100,88,52,{c:m===1?C.bad:'#9aa8b6',w:m===1?4:2.5});T(g,100,160,'aylana — chiziq',{'font-size':12,'font-weight':800,fill:m===1?C.bad:'#5b6b7b'});
 h3Circ(260,88,52,{fill:m===2?'rgba(240,160,64,.6)':'rgba(240,160,64,.15)',c:C.line,w:2.5});T(g,260,160,'doira — tekislik qismi',{'font-size':12,'font-weight':800,fill:m===2?C.t1:'#5b6b7b'});
 g3Msg(['Ikkala shakl farqini toping',"<b>Aylana</b> — yopiq egri chiziq (uzuk, chambarak)","<b>Doira</b> — aylana va uning ichi (tanga, likopcha)"][m])}
var H3A=[35,150,235,300,90];
function h3Rad(n){clear('#ffffff');var cx=180,cy=88,r=60,g=S.g;h3Circ(cx,cy,r,{c:C.blue,w:2.5});
 for(var i=0;i<n;i++){var p=h3Pt(cx,cy,r,H3A[i]);g3Line([cx,cy],p,{w:3,c:C.bad});g3Dot(p,C.bad,3.5);var m=h3Pt(cx,cy,r*0.58,H3A[i]+24);T(g,m[0],m[1]+4,'3 sm',{'font-size':10,'font-weight':800,fill:C.bad})}
 h3O(cx,cy);g3Msg(n?'Radiuslar: <b>'+n+'</b> ta — hammasi <b>3 sm</b>':'Markazdan aylanagacha kesma o‘tkazing')}
function h3Dia(k){clear('#ffffff');var cx=180,cy=88,r=60,g=S.g;h3Circ(cx,cy,r,{c:C.blue,w:2.5});
 if(k>=1){g3Line([cx,cy],[cx+r,cy],{w:4,c:C.bad});T(g,cx+r/2,cy-8,'r = 3 sm',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(k>=2){g3Line([cx-r,cy],[cx,cy],{w:4,c:C.ok});T(g,cx-r/2,cy-8,'r = 3 sm',{'font-size':11,'font-weight':800,fill:C.ok})}
 if(k>=3){T(g,cx,cy+r+16,'d = 3 + 3 = 6 sm',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});g3Line([cx,cy-r],[cx+50,cy-33],{w:2,c:'#9aa8b6',d:'4 3'});T(g,cx+58,cy-38,'vatar (d dan qisqa)',{'font-size':10,fill:'#5b6b7b','text-anchor':'start'})}
 h3O(cx,cy);g3Msg(['Radius 3 sm. Markaz orqali o‘tuvchi kesma qancha?','Bir radius','Qarama-qarshi tomonga yana bir radius','<b>Diametr d = 2 · r</b> = 6 sm — aylanadagi eng uzun kesma'][k])}
var P4=[function(){h3Dia(0)},function(){h3Dia(1)},function(){h3Dia(2)},function(){h3Dia(3)}];
function h3Mm(m){clear('#ffffff');var g=S.g,cx=180,cy=86,r=56;h3Circ(cx,cy,r,{c:C.blue,w:2.5});g3Line([cx,cy],[cx+r,cy],{w:4,c:C.bad});T(g,cx+r/2,cy-8,'3 sm 5 mm',{'font-size':11,'font-weight':800,fill:C.bad});h3O(cx,cy);
 if(m)T(g,cx,cy+r+16,m,{'font-size':12,'font-weight':800,fill:m.indexOf('✓')>=0?C.ok:C.bad})}
function h3Sq(k){clear('#ffffff');var g=S.g,cx=100,cy=88,r=56;h3Circ(cx,cy,r,{c:C.blue,w:2.5,fill:'rgba(90,169,230,.12)'});g3Line([cx-r,cy],[cx+r,cy],{w:3.5,c:C.bad});T(g,cx,cy-8,'d = 14 sm',{'font-size':11,'font-weight':800,fill:C.bad});h3O(cx,cy);
 if(k>=1){g3Line([cx,cy],[cx+r,cy],{w:5,c:C.ok});T(g,cx+r/2,cy+18,'r = 7',{'font-size':11,'font-weight':800,fill:C.ok})}
 if(k>=2){g3Rect(220,60,r,r,{fill:'rgba(240,160,64,.25)',top:'7 sm',left:'7 sm'})}
 g3Msg(['Doira diametri 14 sm. Kvadrat tomoni shu doira <b>radiusiga</b> teng. Kvadrat perimetri?','r = 14 : 2 = <b>7 sm</b>','Kvadrat tomoni 7 sm','P = 7 · 4 = <b>28 sm</b>'][k])}
var P6=[function(){h3Sq(0)},function(){h3Sq(1)},function(){h3Sq(2)},function(){h3Sq(3)}];
function h3Row(k){clear('#ffffff');var g=S.g,r=30,x0=90,y0=58;E('rect',{x:x0,y:y0,width:6*r,height:2*r,fill:'rgba(240,160,64,.12)',stroke:k>=3?C.bad:C.line,'stroke-width':k>=3?4:2.2},g);
 for(var i=0;i<3;i++){var cx=x0+r+i*2*r,cy=y0+r;h3Circ(cx,cy,r,{c:C.blue,w:2.2,fill:'rgba(90,169,230,.18)'});g3Dot([cx,cy],'#33475b',2.5);if(k>=1){g3Line([cx-r,cy],[cx+r,cy],{w:2.5,c:C.bad});T(g,cx,cy-6,'4 sm',{'font-size':10,'font-weight':800,fill:C.bad})}}
 if(k===0){g3Line([x0+r,y0+r],[x0+r,y0+2*r],{w:3,c:C.bad});T(g,x0+r+6,y0+r+20,'2 sm',{'font-size':10,'font-weight':800,fill:C.bad,'text-anchor':'start'})}
 if(k>=2){T(g,x0+3*r,y0-6,'3 · 4 = 12 sm',{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0+r+4,'4 sm',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
 g3Msg(['Radiusi 2 sm bo‘lgan 3 ta doira to‘g‘ri to‘rtburchakka zich joylandi. Uning perimetri?','Har doira diametri: 2 · 2 = <b>4 sm</b>','Bo‘yi — 3 ta diametr: <b>12 sm</b>, eni — 1 diametr: <b>4 sm</b>','P = (12 + 4) · 2 = <b>32 sm</b>'][k])}
var P7=[function(){h3Row(0)},function(){h3Row(1)},function(){h3Row(2)},function(){h3Row(3)}];
function h3Rose(k){clear('#ffffff');var cx=180,cy=88,R=60,g=S.g;h3Circ(cx,cy,R,{c:C.blue,w:2.5});var pts=[];for(var i=0;i<6;i++)pts.push(h3Pt(cx,cy,R,90+i*60));
 if(k>=1)pts.forEach(function(p,i){g3Dot(p,C.bad,4);if(k===1&&i<6)T(g,p[0]+(p[0]-cx)*0.25,p[1]+(p[1]-cy)*0.25+4,String(i+1),{'font-size':11,'font-weight':800,fill:C.bad})});
 var n=k>=3?6:k===2?3:0;for(var j=0;j<n;j++){var ii=k===2?j*2:j,p=pts[ii],dir=Math.atan2(-(cy-p[1]),cx-p[0])*180/Math.PI;h3Arc(p[0],p[1],R,dir-60,dir+60,{c:['#e0713b','#2f8f5b','#1f6fb2','#c0392b','#8e44ad','#d68910'][ii],w:2.6})}
 h3O(cx,cy,' ');g3Msg(['Aylana chizdik (radius R)','Sirkulni o‘zgartirmay aylana bo‘ylab qadam tashlang: roppa-rosa <b>6</b> qadam!','Har nuqtadan shu radius bilan yoy chizamiz','<b>Olti bargli gul</b> — sirkul bilan chizilgan naqsh'][k])}
var P8=[function(){h3Rose(0)},function(){h3Rose(1)},function(){h3Rose(2)},function(){h3Rose(3)}];
function h3Wheel(m){clear('#ffffff');var g=S.g;g3Line([20,150],[340,150],{w:3,c:'#8a6d3b'});
 if(m===1){[70,180,290].forEach(function(x){h3Circ(x,110,40,{c:'#33475b',w:4,fill:'rgba(90,169,230,.15)'});g3Dot([x,110],C.bad,4)});g3Line([70,110],[290,110],{w:2,c:C.ok,d:'5 4'});g3Msg('Dumaloq g‘ildirak: o‘q doim <b>bir balandlikda</b> (radius) — silliq yuradi')}
 else if(m===2){[[70,0],[180,45],[290,0]].forEach(function(a){var x=a[0],rot=a[1];var e=E('g',{transform:'rotate('+rot+' '+x+' '+(rot?150-40*1.414:110)+')'},g);var cy=rot?150-40*1.414:110;E('rect',{x:x-40,y:cy-40,width:80,height:80,fill:'rgba(240,160,64,.2)',stroke:'#33475b','stroke-width':4},e);g3Dot([x,cy],C.bad,4)});g3Line([70,110],[180,93],{w:2,c:C.bad,d:'5 4'});g3Line([180,93],[290,110],{w:2,c:C.bad,d:'5 4'});g3Msg('Kvadrat g‘ildirak: o‘q goh pastga, goh tepaga — <b>silkinadi</b>')}
 else g3Msg('Nega g‘ildirak dumaloq? Solishtiring')}
var STEPS=[
{h:"Aylana yasash",sum:"Aylana — markazdan bir xil uzoqlikdagi nuqtalar chizig'i. Sirkul bilan chiziladi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=4;P1[4]()},
 html:"<p><b>Sirkul</b>ning ignasini bir nuqtaga (markaz <b>O</b>) qo'yib, qalamli oyog'ini aylantiramiz. Sirkulni aylantiring:</p>",
 btns:[phaser(P1,'↻ Aylantirish')],
 after:"<p>Hosil bo'lgan yopiq egri chiziq — <b>aylana</b>. Uning har bir nuqtasi markazdan <b>bir xil</b> masofada (sirkul ochilmasi). Sirkul bo'lmasa — ip va ikki qalam bilan ham chizsa bo'ladi.</p>",
 q:{t:"Sirkul oyoqlari 4 sm ochilgan. Chizilgan aylananing har bir nuqtasi markazdan qancha uzoqlikda?",opts:["2 sm","4 sm","8 sm","har xil"],ok:1,why:"Sirkul ochilmasi — markazdan masofa: 4 sm.",hint:"Sirkulning ochilmasi chizish davomida o'zgaradimi?",full:"Aylananing hamma nuqtasi markazdan bir xil — sirkul ochilmasi 4 sm. «8» — bu diametr bo'lardi, «har xil» — aylananing ta'rifiga zid."},
 tn:"Sirkul bo'lmasa: ipning bir uchini barmoq bilan bosib, ikkinchi uchidagi bo'r bilan doskada aylana chizing."},
{h:"Aylana va doira",sum:"Aylana — chiziq (uzuk); doira — aylana bilan chegaralangan tekislik qismi (tanga).",a:"m02",
 start:function(){h3Kind(0)},fin:function(){h3Kind(2)},
 html:"<p>Ikkalasi ham dumaloq, lekin farqi bor. Tugmalarni bosing:</p>",
 btns:[["◯ Aylana",function(c,done){h3Kind(1);mvK(done,2)}],["⬤ Doira",function(c,done){h3Kind(2);mvK(done,2)}]],g2:1,
 after:"<p><b>Aylana</b> — faqat chegara chizig'i: uzuk, chambarak, g'ildirak gardishi. <b>Doira</b> — chegara va ichi: tanga, likopcha, non.</p>",
 q:{t:"Qaysi narsa doiraga o'xshaydi?",opts:["Uzuk","Chambarak","Tanga","Bilaguzuk"],ok:2,why:"Tanga — ichi to'la, bu doira.",hint:"Qaysi narsaning o'rtasi bo'sh emas?",full:"Tanga ichi to'la — doira. Uzuk, chambarak, bilaguzuk — faqat chiziq, ya'ni aylana."},
 tn:"Bolalar sinfdan aylana va doiraga misol topsin: soat (doira), soat gardishi (aylana)."},
{h:"Radius",sum:"Radius (r) — markazni aylana nuqtasi bilan tutashtiruvchi kesma. Barcha radiuslar teng.",a:"m03",
 start:function(){S.rn=0;h3Rad(0)},fin:function(){h3Rad(5)},
 html:"<p>Markaz O dan aylananing istalgan nuqtasigacha kesma — <b>radius</b>. Bir nechta radius o'tkazing va o'lchang:</p>",
 btns:[["✏️ Radius o'tkazish",function(c,done,b){S.rn=(S.rn||0)+1;if(S.rn>5)S.rn=5;h3Rad(S.rn);if(S.rn>=3)done()}]],
 after:"<p>Radiuslar <b>cheksiz ko'p</b> o'tkazish mumkin, va ularning <b>hammasi teng</b>. Radius «r» harfi bilan belgilanadi.</p>",
 q:{t:"Bitta aylanada nechta radius o'tkazish mumkin?",opts:["Faqat bitta","Ikkita","To'rtta","Cheksiz ko'p"],ok:3,why:"Aylananing har bir nuqtasiga radius o'tkazsa bo'ladi.",hint:"Aylanada nechta nuqta bor?",full:"Aylananing har bir nuqtasi markaz bilan tutashtirilsa radius hosil bo'ladi — nuqtalar cheksiz ko'p, radiuslar ham. Hammasi teng."},
 tn:"Qog'oz doirani buklab markazini toping, keyin turli tomonlarga radius chizib chizg'ich bilan o'lchatib ko'ring."},
{h:"Diametr",sum:"Diametr (d) — markaz orqali o'tib, aylananing ikki nuqtasini tutashtiruvchi kesma: d = 2 · r.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Markaz orqali o'tib, aylananing ikki nuqtasini tutashtiradigan kesma — <b>diametr</b>. U nechta radiusdan iborat?</p>",
 btns:[phaser(P4)],
 after:"<p><b>d = r · 2</b>, <b>r = d : 2</b>. Diametr — aylanadagi <b>eng uzun</b> kesma; markazdan o'tmaydigan kesma (vatar) undan qisqa.</p>",
 q:{t:"Doiraning diametri 10 sm. Radiusi?",opts:["20 sm","5 sm","10 sm","15 sm"],ok:1,why:"10 : 2 = 5 sm.",hint:"Diametrda nechta radius bor?",full:"r = d : 2 = 5 sm. «20» — 2 ga ko'paytirilgan (r dan d ga o'tish qoidasi teskari qo'llangan)."},
 tn:"Doira shaklidagi qog'ozni ikki marta buklang — buklanish chiziqlari diametrlar, kesishgan nuqta markaz."},
{h:"Tuzoq: aralash birliklar",sum:"r = 3 sm 5 mm = 35 mm → d = 70 mm.",a:"m05",
 start:function(){h3Mm('');g3Msg('Radius 3 sm 5 mm. Diametri necha millimetr?')},fin:function(){h3Mm('d = 35 · 2 = 70 mm ✓');g3Msg('3 sm 5 mm = 35 mm')},
 html:"<p>Doiraning radiusi <b>3 sm 5 mm</b>. Diametri necha <b>millimetr</b>? Sinab ko'ring:</p>",
 btns:[["35",function(){h3Mm('35 mm — bu radius ✗');g3Msg('Diametr radiusdan 2 marta uzun')}],["70",function(c,done){h3Mm('d = 35 · 2 = 70 mm ✓');g3Msg('To‘g‘ri! 3 sm 5 mm = 35 mm');done()},'u'],["610",function(){h3Mm('6 sm 10 mm ≠ 610 mm ✗');g3Msg('6 sm 10 mm = 70 mm')}]],g3:1,
 after:"<p>Avval bitta birlikka: 3 sm 5 mm = <b>35 mm</b>. Keyin d = 35 · 2 = <b>70 mm</b> (= 7 sm).</p>",
 q:{t:"Diametr 1 dm. Radius necha mm?",opts:["5 mm","50 mm","100 mm","500 mm"],ok:1,why:"1 dm = 100 mm, 100 : 2 = 50.",hint:"1 dm necha mm?",full:"1 dm = 100 mm, r = 100 : 2 = 50 mm. «5» — 1 dm = 10 mm deb xato, «100» — diametr."},
 tn:"Chizg'ichda 3 sm 5 mm ni ko'rsatib, 35 ta mm bo'lagini sanattiring."},
{h:"Doira va kvadrat",sum:"d = 14 → r = 7 → kvadrat (tomoni r) P = 28 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Masala: <i>«Doiraning diametri 14 sm. Kvadratning tomoni shu doira radiusiga teng. Kvadrat perimetrini toping.»</i></p>",
 btns:[phaser(P6)],
 after:"<p>Zanjir: d → r (bo'lish) → kvadrat tomoni → P. 14 : 2 = 7, 7 · 4 = <b>28 sm</b>. Xato: 14 · 4 = 56 (diametr olingan).</p>",
 q:{t:"Kvadrat ichiga doira chizilgan, tomonlarga tegib turadi. Doira radiusi 3 sm. Kvadrat perimetri?",opts:["12 sm","24 sm","36 sm","9 sm"],ok:1,why:"Kvadrat tomoni = diametr = 6 sm, P = 24.",hint:"Kvadrat tomoni doiraning radiusiga tengmi yoki diametriga?",full:"Doira ikki qarama-qarshi tomonga tegadi, demak tomon = d = 6 sm. P = 6 · 4 = 24 sm. «12» — tomon 3 deb olingan."},
 tn:"Kvadrat qog'ozga doira chizdirib, kvadrat tomoni diametrga tengligini o'lchatib ko'ring."},
{h:"Tuzoq: qatordagi doiralar",sum:"3 ta doira (r = 2) qatorda: bo'yi 3 · 4 = 12, eni 4, P = 32 sm.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Masala: <i>«Radiusi 2 sm bo'lgan 3 ta doira to'g'ri to'rtburchakka zich joylandi. To'rtburchak perimetrini toping.»</i></p>",
 btns:[phaser(P7)],
 after:"<p>Kalit: to'rtburchak o'lchami <b>diametrlar</b> bilan o'lchanadi. Bo'yi = 3 · d = 12, eni = d = 4. P = <b>32 sm</b>. Ko'p uchraydigan xato — radius bilan hisoblash: (6 + 2) · 2 = 16.</p>",
 q:{t:"Radiusi 3 sm bo'lgan 3 ta doira qatorda bir-biriga tegib turibdi. Chetki doiralar markazlari orasidagi masofa?",opts:["18 sm","12 sm","6 sm","9 sm"],ok:1,why:"Qo'shni markazlar orasi 6 sm (2 radius), ikki oraliq: 12 sm.",hint:"Qo'shni doiralar markazlari orasi nechta radius?",full:"Tegib turgan doiralar markazlari orasi r + r = 6 sm. 1-dan 3-markazgacha 2 oraliq: 12 sm. «18» — to'liq uzunlik (chetdan chetgacha)."},
 tn:"Bir xil tangalarni qatorga terib, chizg'ich bilan uzunligini o'lchang: 3 ta tanga = 3 diametr."},
{h:"Naqsh: olti bargli gul",sum:"Sirkul ochilmasini o'zgartirmay aylana bo'ylab qo'ysak, roppa-rosa 6 qadam chiqadi — shundan gul naqshi chiziladi.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>Sirkul bilan chiroyli <b>naqsh</b> chizamiz. Aylana chizgandan so'ng, sirkul ochilmasini o'zgartirmay aylana bo'ylab qadam tashlaymiz:</p>",
 btns:[phaser(P8,'✏️ Chizish')],
 after:"<p>Radius aylanaga roppa-rosa <b>6 marta</b> joylashadi. Shu 6 nuqtadan yoylar chizilsa, <b>olti bargli gul</b> hosil bo'ladi. Nuqtalarni kesma bilan tutashtirsangiz — muntazam oltiburchak!</p>",
 q:{t:"Sirkul ochilmasi aylana radiusiga teng. Aylana bo'ylab nechta qadam tashlab, boshlang'ich nuqtaga qaytamiz?",opts:["4","6","8","3"],ok:1,why:"Radius aylanaga roppa-rosa 6 marta joylashadi.",hint:"Hozirgina gul chizganda nechta nuqta belgiladik?",full:"Radius bilan aylana bo'ylab 6 qadam — muntazam oltiburchak uchlari. Shuning uchun gul 6 bargli."},
 tn:"Bolalar daftarga sirkul bilan gul chizib, barglarni bo'yasin — geometriya va san'at birga."},
{h:"Bilasizmi? G'ildirak",sum:"G'ildirak dumaloq, chunki markazdan har bir nuqtagacha masofa (radius) bir xil — o'q bir tekis yuradi.",a:"m09",
 start:function(){h3Wheel(0)},fin:function(){h3Wheel(1)},
 html:"<p>🚲 Nima uchun g'ildiraklar doim <b>dumaloq</b>? Ikkala g'ildirakni solishtiring:</p>",
 btns:[["⭕ Dumaloq",function(c,done){h3Wheel(1);mvK(done,2)}],["⬜ Kvadrat",function(c,done){h3Wheel(2);mvK(done,2)}]],g2:1,
 after:"<p>Dumaloq g'ildirakda yerga tekkan nuqtadan o'qgacha masofa doim <b>radiusga</b> teng — arava silkinmaydi. Kvadratda bu masofa o'zgaradi. Quduq qopqoqlari ham ko'pincha dumaloq: dumaloq qopqoq hech qanday burilishda teshikka tushib ketmaydi.</p>",
 tn:"Karton doira va kvadratni stol ustida dumalatib ko'rsating, markaziga qalam teshib balandlikni kuzating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h3Dia(3)},fin:function(){h3Dia(3)},
 html:"<div class='memo'><ul><li><b>Aylana</b> — chiziq; <b>doira</b> — aylana va ichi.</li><li>O — markaz. <b>Radius</b> r — markazdan aylanagacha; hammasi teng.</li><li><b>Diametr</b> d — markaz orqali: <b>d = 2 · r</b>, r = d : 2.</li><li>Diametr — eng uzun kesma.</li><li>Birliklarni tenglang: 3 sm 5 mm = 35 mm.</li><li>Doiralar qatori: o'lchamlar <b>diametr</b>da.</li><li>Radius aylanaga <b>6 marta</b> qadam bo'ladi.</li></ul></div>",
 tn:"Keyingi darsda sirkul bilan o'z naqshingizni chizish tanlovini o'tkazing."}
];
var PROBS=[
{t:"Radius 4 sm. Diametr?",o:["8 sm","2 sm","4 sm","16 sm"],k:0,s:"4 · 2 = 8."},
{t:"Diametr 10 sm. Radius?",o:["5 sm","20 sm","10 sm","15 sm"],k:0,s:"10 : 2 = 5."},
{t:"Markazni aylana nuqtasi bilan tutashtiruvchi kesma nima deyiladi?",o:["Radius","Diametr","Perimetr","Yuz"],k:0,s:"Bu radius."},
{t:"Diametr nechta radiusga teng?",o:["2","1","3","4"],k:0,s:"d = 2 · r."},
{t:"Sirkul ochilmasi 4 sm. Chizilgan aylana diametri?",o:["8 sm","4 sm","2 sm","16 sm"],k:0,s:"r = 4, d = 8."},
{t:"Bitta aylanada nechta radius o'tkazish mumkin?",o:["Cheksiz ko'p","Bitta","Ikkita","To'rtta"],k:0,s:"Har nuqtaga bittadan."},
{t:"Radius 3 sm 5 mm. Diametr necha mm?",o:["70 mm","35 mm","60 mm","140 mm"],k:0,s:"35 · 2 = 70."},
{t:"Diametr 1 dm. Radius necha mm?",o:["50 mm","5 mm","100 mm","500 mm"],k:0,s:"100 : 2 = 50."},
{t:"Radius 6 sm. Doiraga sig'adigan eng uzun kesma?",o:["12 sm","6 sm","18 sm","3 sm"],k:0,s:"Diametr: 12 sm."},
{t:"1-doira diametri 12 sm. 2-doira diametri undan 2 marta qisqa. 2-doira radiusi?",o:["3 sm","6 sm","12 sm","24 sm"],k:0,s:"d = 6, r = 3."},
{t:"Doira diametri 14 sm. Kvadrat tomoni shu doira radiusiga teng. Kvadrat perimetri?",o:["28 sm","56 sm","49 sm","14 sm"],k:0,s:"r = 7, 7 · 4 = 28."},
{t:"Kvadrat ichiga doira chizilgan (tomonlarga tegadi). Kvadrat tomoni 10 sm. Doira radiusi?",o:["5 sm","10 sm","20 sm","40 sm"],k:0,s:"d = 10, r = 5."},
{t:"Doira kvadrat ichida tomonlarga tegib turibdi, radiusi 3 sm. Kvadrat perimetri?",o:["24 sm","12 sm","36 sm","9 sm"],k:0,s:"Tomon 6, P = 24."},
{t:"Radiusi 2 sm bo'lgan 3 ta doira to'g'ri to'rtburchakka zich joylandi. Perimetri?",o:["32 sm","16 sm","24 sm","48 sm"],k:0,s:"12 × 4: (12 + 4) · 2 = 32."},
{t:"Ikki bir xil doira tegib turibdi, markazlari orasi 10 sm. Radiusi?",o:["5 sm","10 sm","20 sm","2 sm"],k:0,s:"r + r = 10, r = 5."},
{t:"Radiusi 3 sm bo'lgan 3 ta doira qatorda tegib turibdi. Chetki markazlar orasi?",o:["12 sm","18 sm","6 sm","9 sm"],k:0,s:"6 + 6 = 12."},
{t:"Bir markazli ikki aylana radiuslari 5 sm va 3 sm. Ular orasidagi halqaning eni?",o:["2 sm","8 sm","4 sm","16 sm"],k:0,s:"5 − 3 = 2."},
{t:"Katta doira radiusi 8 sm. Ichida diametr bo'ylab 2 ta bir xil kichik doira tegib turibdi. Kichik doira radiusi?",o:["4 sm","8 sm","2 sm","16 sm"],k:0,s:"Katta d = 16 = 2 kichik d; kichik d = 8, r = 4."},
{t:"Radiusi 1 sm bo'lgan 4 ta doira kvadrat ichiga 2 × 2 zich joylandi. Kvadrat yuzi?",o:["16 sm²","4 sm²","8 sm²","64 sm²"],k:0,s:"Tomon 2 · 2 = 4 sm, S = 16."},
{t:"Sirkul ochilmasi radiusga teng. Aylana bo'ylab necha qadamda boshlang'ich nuqtaga qaytiladi?",o:["6","4","8","3"],k:0,s:"Radius aylanaga 6 marta joylashadi."}
];
function PRACT_STAGE(){h3Dia(3)}
var PREP_DATA={teach:["Sirkul bilan aylana yasash; aylana va doira farqi.","Markaz, radius, diametr; d = 2r.","Aralash birliklarda radius-diametr; doira va kvadrat/to'rtburchak birikmalari.","Sirkul bilan naqsh (olti bargli gul)."],
 mist:["Aylana va doirani adashtiradi.","Diametrdan radiusga o'tishda 2 ga ko'paytiradi.","3 sm 5 mm ni 35 deb, diametrni ham 35 deb yozadi.","Doiralar qatorida radius bilan hisoblaydi.","Kvadrat ichidagi doirada tomon = radius deb oladi."],
 need:["Sirkul, chizg'ich, ip, bo'r.","Bir xil tangalar, qog'oz doira."],
 board:["<span class='w2'>d = 2 · r</span>, <span class='w2'>r = d : 2</span>.","3 sm 5 mm = 35 mm → d = 70 mm.","Doiralar qatori: 3 · d = 12, P = 32.","Gul: radius 6 marta."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
