var CODE='2F3',TITLE='2-sinf · Burchak, to‘g‘ri burchak';
function f3_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3_type(d){return d<88?'o‘tkir':(d<=92?'to‘g‘ri':(d<179?'o‘tmas':'yoyiq'))}
function f3_col(d){return d<88?C.ok:(d<=92?C.blue:C.a2)}
// burchak: uchi O(cx,cy), bir tomoni gorizontal o'ngga, ikkinchisi d gradusga burilgan
function f3_ang(d,o){o=o||{};clear();var g=S.g,cx=o.cx||150,cy=o.cy||140,L1=o.L1||160,L2=o.L2||120;var r=d*Math.PI/180,ex=cx+L2*Math.cos(r),ey=cy-L2*Math.sin(r);
 E('line',{x1:cx,y1:cy,x2:cx+L1,y2:cy,stroke:'#1d2b3a','stroke-width':3.5,'stroke-linecap':'round'},g);E('line',{x1:cx,y1:cy,x2:ex,y2:ey,stroke:'#1d2b3a','stroke-width':3.5,'stroke-linecap':'round'},g);
 var col=f3_col(d);if(Math.abs(d-90)<=2)E('path',{d:'M'+(cx+18)+' '+cy+' L'+(cx+18)+' '+(cy-18)+' L'+cx+' '+(cy-18),fill:'none',stroke:col,'stroke-width':2.5},g);
 else{var rr=26,x1=cx+rr,y1=cy,x2=cx+rr*Math.cos(r),y2=cy-rr*Math.sin(r);E('path',{d:'M'+x1+' '+y1+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+x2+' '+y2,fill:'none',stroke:col,'stroke-width':2.5},g)}
 E('circle',{cx:cx,cy:cy,r:5,fill:C.bad},g);if(!o.nol){T(g,cx-12,cy+4,'O',{'font-size':13,'font-weight':800,fill:C.bad});T(g,cx+L1-6,cy+18,'tomon',{'font-size':10,fill:'#5b6b7b'});T(g,ex+(d>120?-20:14),ey-6,'tomon',{'font-size':10,fill:'#5b6b7b'})}
 if(o.tpl){E('path',{d:'M'+cx+' '+cy+' L'+(cx+70)+' '+cy+' L'+cx+' '+(cy-70)+' Z',fill:'rgba(31,111,178,.12)',stroke:C.blue,'stroke-width':1.5,'stroke-dasharray':'4 3'},g);T(g,cx-6,cy-76,'to‘g‘ri burchak andozasi',{'font-size':9,fill:C.blue,'text-anchor':'start'})}
 S.d=d;if(!o.nostrip)f3_msg('Bu <b style="color:'+col+'">'+f3_type(d)+'</b> burchak'+(d<88?' — to‘g‘ri burchakdan kichik':(d>92&&d<179?' — to‘g‘ri burchakdan katta':(d>=179?' — tomonlari bir to‘g‘ri chiziqda':' — kvadrat burchagidek'))))}
var F3_P2=[function(){f3_paper(0)},function(){f3_paper(1)},function(){f3_paper(2)},function(){f3_paper(3)}];
function f3_paper(k){clear();var g=S.g;
 if(k===0){E('path',{d:'M90 40 Q140 20 200 50 Q250 90 230 140 Q160 160 100 140 Q60 90 90 40 Z',fill:'#fffdf0',stroke:'#c9b28d','stroke-width':2},g);f3_msg('Qirrasi qiyshiq qog‘oz bo‘lagi. To‘g‘ri burchak yasaymiz');return}
 if(k===1){E('path',{d:'M90 40 Q140 20 200 50 Q250 90 230 140 Q160 160 100 140 Q60 90 90 40 Z',fill:'#fffdf0',stroke:'#c9b28d','stroke-width':2},g);E('line',{x1:70,y1:95,x2:250,y2:95,stroke:C.blue,'stroke-width':3},g);f3_msg('1) Qog‘ozni buklaymiz — buklam chizig‘i <b>to‘g‘ri</b> chiqadi');return}
 if(k===2){E('path',{d:'M90 95 Q60 90 90 40 Q140 20 200 50 Q250 90 240 95 Z',fill:'#fffdf0',stroke:'#c9b28d','stroke-width':2},g);E('line',{x1:70,y1:95,x2:250,y2:95,stroke:C.blue,'stroke-width':3},g);E('line',{x1:160,y1:95,x2:160,y2:30,stroke:C.a2,'stroke-width':3,'stroke-dasharray':'5 4'},g);f3_msg('2) Buklam chizig‘ining bir yarmini ikkinchisi ustiga <b>aniq</b> tushirib, yana buklaymiz');return}
 E('path',{d:'M160 95 L160 35 Q200 30 230 60 Q245 85 240 95 Z',fill:'#fffdf0',stroke:'#c9b28d','stroke-width':2},g);E('line',{x1:160,y1:95,x2:245,y2:95,stroke:C.blue,'stroke-width':3},g);E('line',{x1:160,y1:95,x2:160,y2:35,stroke:C.blue,'stroke-width':3},g);E('path',{d:'M178 95 L178 77 L160 77',fill:'none',stroke:C.bad,'stroke-width':2.5},g);T(g,200,130,'to‘g‘ri burchak andozasi!',{'font-size':13,'font-weight':800,fill:C.ok});f3_msg('3) Tayyor: bu — <b>to‘g‘ri burchak</b> andozasi. U bilan istalgan burchakni tekshiramiz')}
function f3_clock(h){clear();var g=S.g,cx=180,cy=86,R=72;E('circle',{cx:cx,cy:cy,r:R,fill:'#fff',stroke:'#33475b','stroke-width':3},g);for(var i=1;i<=12;i++){var a=(i*30-90)*Math.PI/180;T(g,cx+(R-14)*Math.cos(a),cy+(R-14)*Math.sin(a)+4,String(i),{'font-size':11,fill:'#33475b'})}
 var ah=(h*30-90)*Math.PI/180;E('line',{x1:cx,y1:cy,x2:cx+40*Math.cos(ah),y2:cy+40*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);E('line',{x1:cx,y1:cy,x2:cx,y2:cy-58,stroke:C.blue,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);
 var d=Math.abs(h*30)%360;if(d>180)d=360-d;var t=d===0?'burchak hosil qilmaydi (millar ustma-ust)':f3_type(d)+' burchak';f3_msg('Soat <b>'+h+':00</b> — millar orasida <b style="color:'+(d===0?C.bad:f3_col(d))+'">'+t+'</b>')}
function f3_cut(k){clear();var g=S.g;function mark(x,y,dx,dy){E('path',{d:'M'+(x+dx*12)+' '+y+' L'+(x+dx*12)+' '+(y+dy*12)+' L'+x+' '+(y+dy*12),fill:'none',stroke:C.bad,'stroke-width':2},g)}
 if(k===0){E('rect',{x:120,y:30,width:110,height:110,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2.5},g);mark(120,30,1,1);mark(230,30,-1,1);mark(120,140,1,-1);mark(230,140,-1,-1);f3_msg('Kvadratda <b>4 ta</b> to‘g‘ri burchak');return}
 if(k===1){E('polygon',{points:'110,30 220,30 110,140',fill:'#e8f1fb',stroke:C.blue,'stroke-width':2.5},g);E('polygon',{points:'250,30 250,140 140,140',fill:'#fdf0e1',stroke:C.a2,'stroke-width':2.5,transform:'translate(20,0)'},g);mark(110,30,1,1);E('path',{d:'M258 140 L258 128 L270 128',fill:'none',stroke:C.bad,'stroke-width':2},g);f3_msg('Diagonal bo‘ylab kesdik: har bir uchburchakda faqat <b>1 ta</b> to‘g‘ri burchak');return}
 E('rect',{x:60,y:40,width:110,height:90,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2.5},g);E('rect',{x:190,y:40,width:110,height:90,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2.5},g);[[60,40,1,1],[170,40,-1,1],[60,130,1,-1],[170,130,-1,-1],[190,40,1,1],[300,40,-1,1],[190,130,1,-1],[300,130,-1,-1]].forEach(function(m){mark(m[0],m[1],m[2],m[3])});f3_msg('To‘g‘ri to‘rtburchak o‘rtasidan kesildi: ikkala bo‘lakda <b>4 + 4 = 8</b> ta to‘g‘ri burchak')}
var F3_P6=[function(){f3_cut(0)},function(){f3_cut(1)},function(){f3_cut(2)}];
var STEPS=[
{h:"Burchak nima?",sum:"Burchak — bitta nuqtadan chiqqan ikkita nur. Nuqta — burchak uchi, nurlar — tomonlari.",a:"m01",
 start:function(){S.d=40;f3_ang(40);S.bm=0},fin:function(){f3_ang(60)},
 html:"<p>Bitta nuqtadan (O) <b>ikkita nur</b> chiqdi — bu <b>burchak</b>. Tugmalar bilan burchakni oching va yoping.</p>",
 btns:[["◀ Yopish",function(c,done){if(S.d>15)f3_ang(S.d-15);mvK(done,3)}],["Ochish ▶",function(c,done){if(S.d<165)f3_ang(S.d+15);mvK(done,3)}]],g2:1,
 after:"<p>O nuqta — burchakning <b>uchi</b>. Ikki nur — uning <b>tomonlari</b>. Burchak qancha ochiq bo'lsa — shuncha katta.</p><div class='life'><div>✂️<span>qaychi og'zi, kitob muqovasi, soat millari — hammasi burchak</span></div></div>",
 q:{t:"Burchakning nechta tomoni bor?",opts:["Bitta","Ikkita","Uchta","To'rtta"],ok:1,why:"Burchak ikkita nurdan tuzilgan — ikkita tomon.",hint:"Sahnada uchdan nechta chiziq chiqyapti?",full:"Burchak — bitta nuqtadan chiqqan ikkita nur. Har bir nur — tomon. Demak 2 ta tomon va 1 ta uch."},
 tn:"Bolalar ikki qalamni bir uchidan tutib, burchak «yasasin»: ochsin, yopsin. Qaychi ham yaxshi ko'rgazma."},
{h:"To'g'ri burchak yasaymiz",sum:"Qog'ozni ikki marta buklab, to'g'ri burchak andozasini yasaymiz.",a:"m02",
 start:function(){startPh(F3_P2)},fin:function(){S.ph=3;F3_P2[3]()},
 html:"<p>Chizg'ich ham, uchburchak ham kerak emas — oddiy qog'oz bo'lagidan <b>to'g'ri burchak</b> yasash mumkin. Kuzating va o'zingiz ham qiling.</p>",
 btns:[phaser(F3_P2,'▶ Keyingi buklash')],
 after:"<p>Ikki marta buklangan qog'ozning burchagi — <b>to'g'ri burchak</b>. Daftar, kitob, eshik, deraza burchaklari ham to'g'ri burchak. Chizmada u <b>kichik kvadratcha</b> bilan belgilanadi.</p>",
 q:{t:"Qog'ozni yarmiga buklab, keyin buklam chizig'ining bir yarmini ikkinchisi ustiga aniq tushirib yana buklasak, qanday burchak hosil bo'ladi?",opts:["To'g'ri burchak","O'tkir burchak","O'tmas burchak","Yoyiq burchak"],ok:0,why:"Ikki marta to'g'ri buklash to'g'ri burchak beradi.",hint:"Hozirgina sahnada nima yasadik?",full:"Birinchi buklash to'g'ri chiziq beradi, ikkinchisi uni teng ikkiga bo'ladi — burchak to'g'ri burchak bo'ladi."},
 tn:"Har bir bola o'z andozasini yasasin va sinfdagi narsalarning burchaklarini tekshirsin: parta, doska, kitob."},
{h:"O'tkir, to'g'ri, o'tmas",sum:"To'g'ri burchakdan kichik — o'tkir, katta — o'tmas. Tomonlari bir chiziqda bo'lsa — yoyiq.",a:"m03",
 start:function(){S.d=90;f3_ang(90,{tpl:1})},fin:function(){f3_ang(130,{tpl:1})},
 html:"<p>Burchakni andoza bilan solishtiramiz. Tugmalarni bosing va burchak turi qanday o'zgarishini kuzating.</p>",
 btns:[["◀ Yopish",function(c,done){if(S.d>15)f3_ang(S.d-15,{tpl:1});mvK(done,4)}],["Ochish ▶",function(c,done){if(S.d<180)f3_ang(Math.min(180,S.d+15),{tpl:1});mvK(done,4)}]],g2:1,
 after:"<div class='life'><div><b style='color:#1e8e5a'>∠</b><span><b>O'tkir</b> — to'g'ri burchakdan <b>kichik</b> (andoza ichiga sig'adi)</span></div><div><b style='color:#1f6fb2'>⦜</b><span><b>To'g'ri</b> — andoza bilan aynan mos</span></div><div><b style='color:#e07a2f'>∠</b><span><b>O'tmas</b> — to'g'ri burchakdan <b>katta</b> (andozadan chiqib turadi)</span></div></div>",
 q:{t:"O'tmas burchak to'g'ri burchakdan katta yoki kichikmi?",opts:["Kichik","Teng","Katta","Ba'zan katta, ba'zan kichik"],ok:2,why:"O'tmas burchak to'g'ri burchakdan doim katta.",hint:"Burchakni ochganingizda o'tmas burchak qachon paydo bo'ldi — to'g'ri burchakdan oldinmi, keyinmi?",full:"Burchakni ochib borsak: avval o'tkir, keyin to'g'ri, undan keyin o'tmas. Demak o'tmas burchak to'g'ri burchakdan katta, o'tkir esa kichik."},
 tn:"«O'tkir» — pichoqdek tor, «o'tmas» — keng. Bolalar qo'li bilan ko'rsatsin: tirsakni bukib o'tkir, ochib o'tmas burchak."},
{h:"Soat millaridagi burchaklar",sum:"3:00 va 9:00 da — to'g'ri burchak; 1:00, 2:00 — o'tkir; 4:00, 5:00 — o'tmas; 6:00 — yoyiq.",a:"m04",
 start:function(){f3_clock(3)},fin:function(){f3_clock(9)},
 html:"<p>Soat millari ham burchak hosil qiladi. Vaqtni tanlang va qanday burchak chiqishini ko'ring:</p>",
 btns:[["1:00",function(c,done){f3_clock(1);mvK(done,3)}],["3:00",function(c,done){f3_clock(3);mvK(done,3)}],["5:00",function(c,done){f3_clock(5);mvK(done,3)}],["6:00",function(c,done){f3_clock(6);mvK(done,3)}],["9:00",function(c,done){f3_clock(9);mvK(done,3)}],["12:00",function(c,done){f3_clock(12);mvK(done,3)}]],g3:1,
 after:"<p>Soat <b>3:00</b> va <b>9:00</b> da millar <b>to'g'ri burchak</b> hosil qiladi. 6:00 da millar bir to'g'ri chiziqda — <b>yoyiq</b> burchak. 12:00 da millar ustma-ust — burchak yo'q.</p>",
 q:{t:"Soat millari qaysi vaqtda to'g'ri burchak hosil qiladi?",opts:["4:00","3:00","6:00","12:00"],ok:1,why:"3:00 da soat mili 3 ga, minut mili 12 ga qaraydi — to'g'ri burchak.",hint:"Qaysi vaqtda millar «L» harfiga o'xshaydi?",full:"3:00 da kichik mil 3 da, katta mil 12 da — to'g'ri burchak. 4:00 — o'tmas, 6:00 — yoyiq, 12:00 da millar ustma-ust."},
 tn:"Karton soat yasab, millarni burab ko'rsating. «Soat 9 da qanday burchak?» kabi savollar bering."},
{h:"Tuzoq: tomonlar uzunligi",sum:"Burchakning kattaligi tomonlar uzunligiga bog'liq emas — faqat qancha ochilganiga bog'liq.",a:"m05",
 start:function(){f3_ang(50,{L1:90,L2:70,nostrip:1});f3_msg('Bu burchak tomonlarini uzaytirsak, burchak kattalashadimi?')},fin:function(){f3_ang(50,{L1:190,L2:150,nostrip:1});f3_msg('Tomonlar uzaydi, lekin burchak <b>o‘zgarmadi</b> — baribir o‘tkir')},
 html:"<p>Ko'pchilik o'ylaydi: «tomonlari uzun burchak — katta». Tekshiramiz! Tugmani bosib, tomonlarni uzaytiring.</p>",
 btns:[["↔ Tomonlarni uzaytirish",function(c,done,b){var k=0;var iv=setInterval(function(){k++;f3_ang(50,{L1:90+k*10,L2:70+k*8,nostrip:1});if(k>=10){clearInterval(iv);f3_msg('Tomonlar uzaydi, lekin burchak <b>o‘zgarmadi</b> — baribir o‘tkir');done()}},80);b.disabled=true}]],
 after:"<p>Burchakning kattaligi tomonlarining <b>uzunligiga bog'liq emas</b>, faqat ular <b>qancha ochilganiga</b> bog'liq. Kichik daftardagi to'g'ri burchak ham, katta doskadagi to'g'ri burchak ham — bir xil!</p>",
 q:{t:"Burchakning tomonlari 2 marta uzaytirildi. Burchak qanday o'zgaradi?",opts:["2 marta kattalashadi","O'zgarmaydi","Kichrayadi","To'g'ri burchakka aylanadi"],ok:1,why:"Burchak kattaligi tomonlar ochilishiga bog'liq, uzunligiga emas.",hint:"Sahnada tomonlar uzayganda burchak turi o'zgardimi?",full:"Tomonlarni uzaytirish nurlarni davom ettirish xolos — ular orasidagi ochilish o'zgarmaydi. Burchak o'sha-o'sha qoladi."},
 tn:"Doskada ikki xil uzunlikdagi, lekin bir xil burchakni chizing va «qaysi katta?» deb so'rang. Ko'pchilik xato qiladi — andoza bilan tekshiring."},
{h:"Tuzoq: shakldagi to'g'ri burchaklar",sum:"Kvadrat diagonal bo'ylab kesilsa — har uchburchakda 1 ta to'g'ri burchak. To'g'ri to'rtburchak o'rtasidan kesilsa — 8 ta.",a:"m06",
 start:function(){startPh(F3_P6)},fin:function(){S.ph=2;F3_P6[2]()},
 html:"<p>Shakl kesilganda to'g'ri burchaklar nechta bo'ladi? Testlarda shunday savollar keladi. Kuzating.</p>",
 btns:[phaser(F3_P6)],
 after:"<p>Kesganda to'g'ri burchak <b>yo'qolishi</b> ham (diagonal bo'ylab), <b>yangilari paydo bo'lishi</b> ham (tomonga parallel kesganda) mumkin. Shuning uchun har doim chizib, belgilab, keyin sanang.</p>",
 q:{t:"Uchburchakda eng ko'pi bilan nechta to'g'ri burchak bo'lishi mumkin?",opts:["0","1","2","3"],ok:1,why:"Ikkita to'g'ri burchak bo'lsa, tomonlar parallel bo'lib, uchburchak yopilmaydi.",hint:"Ikkita to'g'ri burchak chizib, uchburchak yasab ko'ring — tomonlari uchrashadimi?",full:"Bitta to'g'ri burchakli uchburchak bor (kvadratning yarmi). Agar ikkita to'g'ri burchak bo'lsa, ikki tomon bir xil yo'nalishda ketadi va hech qachon uchrashmaydi — uchburchak bo'lmaydi. Javob: 1."},
 tn:"Qog'oz kvadratni bolalar o'zi kesib, to'g'ri burchaklarni andoza bilan sanasin."},
{h:"Bilasizmi? Quruvchining burchagi",sum:"Quruvchilar «go'niya» (burchaklik) asbobi bilan devorlarning to'g'ri burchakda turishini tekshiradi.",a:"m07",
 start:function(){f3_build(false)},fin:function(){f3_build(true)},
 html:"<p>🏗 Uylar, partalar, kitoblar — hammasi to'g'ri burchaklar bilan quriladi. Ustalar buni qanday tekshiradi? Tugmani bosing.</p>",
 btns:[["📐 Tekshirish",function(c,done){f3_build(true);done()}]],
 after:"<p>Ustalarda <b>go'niya</b> (burchaklik) degan asbob bor — bu temirdan yasalgan to'g'ri burchak andozasi. Agar devor to'g'ri burchakda turmasa, uy qiyshayib qoladi. Qadimgi Samarqand va Buxoro masjid-madrasalarini qurgan ustalar ham to'g'ri burchaklarni juda aniq yasashgan.</p>",
 tn:"Bolalar sinfdagi eshik, deraza, parta burchaklarini o'z qog'oz andozasi bilan tekshirib, natijani aytsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){f3_ang(90)},fin:function(){f3_ang(90)},
 html:"<div class='memo'><ul><li><b>Burchak</b> — bitta nuqtadan chiqqan 2 ta nur. Nuqta — <b>uchi</b>, nurlar — <b>tomonlari</b>.</li><li><b>To'g'ri burchak</b> — qog'ozni ikki marta buklab yasaladi; chizmada kichik kvadratcha bilan belgilanadi.</li><li><b>O'tkir</b> — to'g'ri burchakdan kichik, <b>o'tmas</b> — katta, <b>yoyiq</b> — tomonlari bir chiziqda.</li><li>Soat 3:00 va 9:00 — to'g'ri burchak, 6:00 — yoyiq.</li><li>Burchak kattaligi tomonlar <b>uzunligiga bog'liq emas</b>.</li><li>Uchburchakda ko'pi bilan <b>1 ta</b> to'g'ri burchak bo'ladi.</li></ul></div>",
 tn:"Keyingi darsni «Kvadratda nechta to'g'ri burchak bor? Uchburchakda-chi?» savoli bilan boshlang."}
];
function f3_build(on){clear('#eef6ff');var g=S.g;E('rect',{x:20,y:150,width:320,height:16,fill:'#9aa8b6'},g);E('rect',{x:90,y:40,width:26,height:110,fill:'#d9a35a',stroke:'#8a5a24'},g);for(var y=50;y<150;y+=14)E('line',{x1:90,y1:y,x2:116,y2:y,stroke:'#8a5a24','stroke-width':.8},g);
 if(on){E('path',{d:'M116 150 L116 100 M116 150 L170 150',stroke:'#33475b','stroke-width':6,fill:'none'},g);E('path',{d:'M116 132 L134 132 L134 150',fill:'none',stroke:C.bad,'stroke-width':2.5},g);T(g,230,110,'go‘niya: devor va pol — to‘g‘ri burchak ✓',{'font-size':11,'font-weight':800,fill:C.ok})}
 f3_msg(on?'Devor va pol orasida <b>to‘g‘ri burchak</b> — uy mustahkam':'G‘isht devor. U pol bilan qanday burchak hosil qiladi?')}
var PROBS=[
{t:"Burchakning nechta tomoni bor?",o:["2","1","3","4"],k:0,s:"Burchak 2 ta nurdan tuzilgan."},
{t:"Burchakning nechta uchi bor?",o:["1","2","3","0"],k:0,s:"Ikkala nur bitta nuqtadan chiqadi — 1 ta uch."},
{t:"Soat millari qaysi vaqtda to'g'ri burchak hosil qiladi?",o:["3:00","4:00","6:00","12:00"],k:0,s:"3:00 da millar to'g'ri burchak hosil qiladi."},
{t:"Soat 9:00 da millar qanday burchak hosil qiladi?",o:["to'g'ri burchak","o'tkir burchak","o'tmas burchak","burchak hosil qilmaydi"],k:0,s:"9:00 da mil 9 ga, katta mil 12 ga — to'g'ri burchak."},
{t:"Soat 1:00 da millar qanday burchak hosil qiladi?",o:["o'tkir","to'g'ri","o'tmas","yoyiq"],k:0,s:"Millar orasi juda tor — o'tkir burchak."},
{t:"Soat 5:00 da millar qanday burchak hosil qiladi?",o:["o'tmas","o'tkir","to'g'ri","yoyiq"],k:0,s:"Millar orasi to'g'ri burchakdan keng — o'tmas."},
{t:"O'tmas burchak to'g'ri burchakdan katta yoki kichikmi?",o:["katta","kichik","teng","ba'zan katta, ba'zan kichik"],k:0,s:"O'tmas burchak to'g'ri burchakdan doim katta."},
{t:"O'tkir burchak to'g'ri burchakdan qanday?",o:["kichik","katta","teng","ikki marta katta"],k:0,s:"O'tkir burchak to'g'ri burchakdan kichik."},
{t:"Kvadratda nechta to'g'ri burchak bor?",o:["4","2","3","1"],k:0,s:"Kvadratning 4 ta burchagi ham to'g'ri."},
{t:"Uchburchakda eng ko'pi bilan nechta to'g'ri burchak bo'lishi mumkin?",o:["1","2","3","0"],k:0,s:"Ikkita to'g'ri burchak bo'lsa, uchburchak yopilmaydi. Javob: 1."},
{t:"Kvadrat bitta diagonal bo'ylab kesildi. Hosil bo'lgan har bir uchburchakda nechta to'g'ri burchak bor?",o:["1","2","0","3"],k:0,s:"Diagonal ikki burchakni kesadi, har uchburchakda 1 ta to'g'ri burchak qoladi."},
{t:"To'g'ri to'rtburchak tomonlariga parallel qilib o'rtasidan kesildi. Ikkala bo'lakda jami nechta to'g'ri burchak bor?",o:["8","4","6","2"],k:0,s:"Har bo'lak — to'g'ri to'rtburchak, 4 tadan: 4 + 4 = 8."},
{t:"Burchakning tomonlari 3 marta uzaytirildi. Burchak qanday o'zgaradi?",o:["o'zgarmaydi","3 marta kattalashadi","kichrayadi","to'g'ri burchakka aylanadi"],k:0,s:"Burchak kattaligi tomonlar uzunligiga bog'liq emas."},
{t:"Soat 6:00 da millar qanday joylashadi?",o:["bir to'g'ri chiziqda (yoyiq burchak)","to'g'ri burchakda","ustma-ust","o'tkir burchakda"],k:0,s:"6:00 da millar qarama-qarshi — bir to'g'ri chiziqda."},
{t:"Soat 12:00 da millar qanday burchak hosil qiladi?",o:["burchak hosil qilmaydi","to'g'ri","o'tkir","yoyiq"],k:0,s:"12:00 da millar ustma-ust turadi."},
{t:"Qaysi narsaning burchagi to'g'ri burchak?",o:["daftar varag'i","ochiq qaychi","tom (uy tepasi)","pichoq uchi"],k:0,s:"Daftar varag'ining burchaklari — to'g'ri burchak."},
{t:"To'g'ri burchak chizmada qanday belgilanadi?",o:["kichik kvadratcha bilan","yoy bilan","nuqta bilan","yulduzcha bilan"],k:0,s:"To'g'ri burchak kichik kvadratcha bilan belgilanadi."},
{t:"Bitta nuqtadan chiqqan ikkita nur nima hosil qiladi?",o:["burchak","kesma","uchburchak","to'g'ri chiziq"],k:0,s:"Bitta nuqtadan chiqqan ikki nur — burchak."},
{t:"To'g'ri to'rtburchakdan bitta burchagini to'g'ri chiziq bilan kesib olsak, qolgan shaklda nechta to'g'ri burchak qoladi?",o:["3","4","2","5"],k:0,s:"Kesilgan burchak yo'qoladi, qolgan 3 tasi to'g'ri qoladi (yangi 2 ta burchak o'tmas)."},
{t:"Ikkita to'g'ri burchakni yonma-yon qo'ysak (umumiy tomoni bilan), qanday burchak hosil bo'ladi?",o:["yoyiq","o'tkir","to'g'ri","o'tmas"],k:0,s:"Ikki to'g'ri burchak birga tomonlarni bir to'g'ri chiziqqa qo'yadi — yoyiq burchak."}
];
function PRACT_STAGE(){f3_ang(90,{tpl:1})}
var PREP_DATA={teach:["Burchak, uchi va tomonlari.","To'g'ri burchakni qog'ozni buklab yasash va tekshirish.","O'tkir, to'g'ri, o'tmas (va yoyiq) burchaklar.","Soat millaridagi burchaklar.","Tuzoqlar: tomonlar uzunligi, kesilgan shakldagi to'g'ri burchaklar."],
 mist:["Tomonlari uzun burchakni «katta» deb o'ylaydi.","O'tkir va o'tmasni aralashtiradi.","12:00 da ham burchak bor deb o'ylaydi.","Kesilgan shakllarda yangi paydo bo'lgan burchaklarni sanamaydi."],
 need:["Qog'oz (har bolaga to'g'ri burchak andozasi uchun).","Karton soat, qaychi, ikki qalam."],
 board:["Burchak: uchi O, tomonlari — nurlar.","Qog'ozni 2 marta buklab — to'g'ri burchak ⦜.","O'tkir < to'g'ri < o'tmas < yoyiq.","3:00, 9:00 — to'g'ri; 6:00 — yoyiq.","Uchburchakda ko'pi bilan 1 ta to'g'ri burchak."]};
