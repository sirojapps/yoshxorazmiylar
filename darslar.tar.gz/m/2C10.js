// --- k2c10_ yordamchilari ---
function k2c10_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c10_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c10_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c10_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C10',TITLE='2-sinf · Bo‘luvchilar va karralilar';
// n ta konfetni k guruhga teng bo'lish
function k2c10_groups(n,k){clear();var g=S.g,q=Math.floor(n/k),r=n%k,gw=Math.min(80,320/k),x0=180-gw*k/2;
 for(var i=0;i<k;i++){var x=x0+i*gw;E('rect',{x:x+3,y:20,width:gw-6,height:110,rx:10,fill:'#fff7ea',stroke:'#e6d0a8'},g);
  for(var j=0;j<q;j++){var cols=Math.max(1,Math.floor((gw-10)/12));E('circle',{cx:x+10+(j%cols)*12,cy:34+Math.floor(j/cols)*13,r:5,fill:C.c,stroke:'rgba(0,0,0,.15)'},g)}}
 for(var t=0;t<r;t++)E('circle',{cx:180-(r-1)*7+t*14,cy:150,r:5.5,fill:C.bad},g);
 k2c10_big(n+' : '+k+' = '+q+(r?' va <b style="color:#d94b4b">'+r+' ta ortib qoldi</b>':' — <b style="color:#1e8e5a">qoldiqsiz!</b>'),k+' ta guruh')}
function k2c10_rects(n,show){clear();var g=S.g,pairs=[];for(var a=1;a<=n;a++)if(n%a===0&&a<=n/a)pairs.push([a,n/a]);
 var x=14;pairs.slice(0,show).forEach(function(p){var s=Math.min(9,120/p[1]);for(var i=0;i<p[0];i++)for(var j=0;j<p[1];j++)E('rect',{x:x+i*s,y:14+j*s,width:s-1,height:s-1,fill:C.b},g);T(g,x+p[0]*s/2,150,p[0]+' · '+p[1],{'font-size':12,'font-weight':800,fill:C.blue});x+=Math.max(p[0]*s+22,50)});
 return pairs}
function k2c10_line(step,upto,marks){clear();var x0=16,x1=344,y=96,k=(x1-x0)/upto,X=function(v){return x0+v*k};E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':2},S.g);
 for(var v=0;v<=upto;v++){E('line',{x1:X(v),y1:y-4,x2:X(v),y2:y+4,stroke:'#33475b','stroke-width':1},S.g);if(v%step===0)T(S.g,X(v),y+20,String(v),{'font-size':10,fill:'#5b6b7b'})}
 for(var m=step;m<=marks;m+=step){E('path',{d:'M'+X(m-step)+' '+(y-6)+' Q'+X(m-step/2)+' '+(y-34)+' '+X(m)+' '+(y-6),fill:'none',stroke:C.ok,'stroke-width':2},S.g);E('circle',{cx:X(m),cy:y,r:5,fill:C.ok},S.g);T(S.g,X(m),y-36,String(m),{'font-size':11,'font-weight':800,fill:C.ok})}}
function k2c10_grid(div){clear();var x0=40,y0=8,c=28,h=16;for(var n=1;n<=100;n++){var r=Math.floor((n-1)/10),q=(n-1)%10,x=x0+q*c,y=y0+r*h,on=div&&n%div===0,two=on&&n>=10&&n<=99;
 E('rect',{x:x,y:y,width:c-1,height:h-1,rx:2,fill:two?C.hi:(on?'#ffe9b8':'#fff'),stroke:'#dde5ee'},S.g);T(S.g,x+c/2,y+12,String(n),{'font-size':9,'font-weight':on?800:500,fill:'#33475b'})}}
var STEPS=[
{h:"12 ta konfetni teng bo'lamiz",sum:"12 ni qoldiqsiz bo'ladigan sonlar — 12 ning bo'luvchilari: 1, 2, 3, 4, 6, 12.",a:"m01",
 start:function(){k2c10_groups(12,1)},fin:function(){k2c10_groups(12,4)},
 html:"<p>12 ta konfetni do'stlarga <b>teng</b> va <b>ortiqcha qoldirmasdan</b> bo'lmoqchimiz. Necha kishiga bo'lsa bo'ladi? Har xil sonni sinab ko'ring:</p>",
 btns:[["2",function(c,d){k2c10_groups(12,2);mvK(d,4)}],["3",function(c,d){k2c10_groups(12,3);mvK(d,4)}],["4",function(c,d){k2c10_groups(12,4);mvK(d,4)}],["5",function(c,d){k2c10_groups(12,5);mvK(d,4)}],["6",function(c,d){k2c10_groups(12,6);mvK(d,4)}],["7",function(c,d){k2c10_groups(12,7);mvK(d,4)}]],g3:1,
 after:"<p>12 ni <b>1, 2, 3, 4, 6, 12</b> kishiga ortiqchasiz bo'lsa bo'ladi. Bu sonlar <b>12 ning bo'luvchilari</b> deyiladi. 5 va 7 — bo'luvchi emas: konfet ortib qoladi.</p>",
 q:{t:"Qaysi son 12 ning bo'luvchisi EMAS?",opts:["3","5","6","4"],ok:1,why:"12 : 5 = 2 va 2 ta ortadi — qoldiqsiz bo'linmaydi.",hint:"Qaysi songa bo'lganda konfet ortib qoldi?",full:"12 : 3 = 4, 12 : 6 = 2, 12 : 4 = 3 — qoldiqsiz. 12 : 5 = 2, 2 ta ortib qoladi. Demak 5 — bo'luvchi emas."},
 tn:"Bolalarga 12 ta tugma bering, guruhlarga bo'lib ko'rsin. Har bir «qoldiqsiz» holatni doskaga yozing."},
{h:"Bo'luvchilar juft bo'lib keladi",sum:"12 = 1 · 12 = 2 · 6 = 3 · 4. Har bir to'g'ri to'rtburchak — bir juft bo'luvchi.",a:"m02",
 start:function(){S.r=1;k2c10_rects(12,1);k2c10_big('12 = 1 · 12')},fin:function(){k2c10_rects(12,3);k2c10_big('12 = 1 · 12 = 2 · 6 = 3 · 4')},
 html:"<p>12 ta kvadratchadan nechta xil to'g'ri to'rtburchak yasash mumkin? Har biri ikkita bo'luvchini beradi.</p>",
 btns:[["▶ Keyingi to'rtburchak",function(c,d,b){S.r=(S.r||1)+1;var p=k2c10_rects(12,S.r);k2c10_big(p.slice(0,S.r).map(function(x){return x[0]+' · '+x[1]}).join(' = ').replace(/^/,'12 = '));if(S.r>=3){b.disabled=true;d()}}]],
 after:"<p>Uchta to'rtburchak: 1 × 12, 2 × 6, 3 × 4. Bo'luvchilar <b>juft-juft</b>: (1, 12), (2, 6), (3, 4). Shuning uchun bo'luvchilarni juftlab qidirsangiz, birortasi ham qolib ketmaydi.</p>",
 q:{t:"18 ning bo'luvchilari nechta?",opts:["6","4","3","9"],ok:0,why:"1 · 18, 2 · 9, 3 · 6 → 1, 2, 3, 6, 9, 18 — 6 ta.",hint:"Juftlab qidiring: 1 · 18, 2 · ?, 3 · ?",full:"Juftlar: (1, 18), (2, 9), (3, 6). Bo'luvchilar: 1, 2, 3, 6, 9, 18 — 6 ta. Ko'pincha 1 va sonning o'zi unutiladi."},
 tn:"Massivlarni katakli qog'ozda chizdiring. Bu usul AQSh va Singapur darsliklarida «faktor juftlari» deb ataladi."},
{h:"Karralilar — sakrab sanash",sum:"3 ga karrali sonlar: 3, 6, 9, 12, … — 3 ga qoldiqsiz bo'linadi. Ular cheksiz ko'p.",a:"m03",
 start:function(){S.j=0;k2c10_line(3,30,0);k2c10_big('3 dan sakraymiz')},fin:function(){k2c10_line(3,30,30);k2c10_big('3, 6, 9, 12, 15, 18, 21, 24, 27, 30, …')},
 html:"<p>Chigirtka son o'qida har safar <b>3 qadam</b> sakraydi. U qo'nadigan sonlar — <b>3 ga karrali</b> sonlar. Sakrating:</p>",
 btns:[["🦗 +3 sakra",function(c,d,b){S.j=(S.j||0)+3;k2c10_line(3,30,S.j);var l=[];for(var v=3;v<=S.j;v+=3)l.push(v);k2c10_big(l.join(', '));if(S.j>=18)d();if(S.j>=30)b.disabled=true}]],
 after:"<p>3, 6, 9, 12, 15, 18 … — bu <b>3 ga karrali</b> sonlar: 3 ning ko'paytirish jadvali! Karralilar <b>cheksiz</b> davom etadi, bo'luvchilar esa sanoqli.</p>",
 q:{t:"Qaysi son 4 ga karrali?",opts:["30","18","28","14"],ok:2,why:"28 = 4 · 7.",hint:"4 ning jadvalini eslang: 4, 8, 12, … Qaysi biri unda bor?",full:"4 ga karralilar: 4, 8, 12, 16, 20, 24, 28, 32 … 28 bor (4 · 7). 30, 18, 14 — 4 ga qoldiqsiz bo'linmaydi (ular 2 ga karrali, xolos)."},
 tn:"Polda son o'qi bo'ylab bolalar «3 lik», «4 lik» sakrashsin. Karrali — sakrash izlari."},
{h:"Bo'luvchi va karrali — bir tanganing ikki tomoni",sum:"3 — 12 ning bo'luvchisi ⟺ 12 — 3 ga karrali. Chunki 3 · 4 = 12.",a:"m04",
 start:function(){k2c10_groups(12,3);k2c10_big('3 · 4 = 12')},fin:function(){k2c10_groups(12,3);k2c10_big('3 · 4 = 12 → 3 — 12 ning bo‘luvchisi, 12 — 3 ga karrali')},
 html:"<p>3 · 4 = 12. Bu tenglikdan ikki xulosa chiqadi. Tugmalarni bosing:</p>",
 btns:[["3 → 12 ning …",function(c,d){k2c10_big('<b>3</b> — 12 ning <b>bo‘luvchisi</b> (12 : 3 = 4, qoldiqsiz)');mvK(d,2)}],["12 → 3 ga …",function(c,d){k2c10_big('<b>12</b> — 3 ga <b>karrali</b> (3 ning jadvalida bor)');mvK(d,2)}]],g2:1,
 after:"<p>Kichik son — kattasining <b>bo'luvchisi</b>, katta son — kichigiga <b>karrali</b>. Har bir son 1 ga ham, o'ziga ham bo'linadi: 1 va sonning o'zi — doim bo'luvchi.</p>",
 q:{t:"7 · 6 = 42. Qaysi gap to'g'ri?",opts:["42 — 7 ga karrali","7 — 42 ga karrali","42 — 6 ning bo'luvchisi","6 — 7 ning bo'luvchisi"],ok:0,why:"Katta son (42) kichigiga (7) karrali.",hint:"Karrali — katta son, bo'luvchi — kichik son.",full:"42 = 7 · 6, demak 42 — 7 ga ham, 6 ga ham karrali; 7 va 6 — 42 ning bo'luvchilari. Qolgan gaplarda so'zlar teskari ishlatilgan."},
 tn:"So'zlarni aralashtirish eng ko'p uchraydigan xato. Doskaga ikki ustun: «bo'luvchi — kichik, ichiga sig'adi», «karrali — katta, ko'p marta oladi»."},
{h:"Tuzoq: 1 va sonning o'zi",sum:"Har bir sonning bo'luvchilari ichida 1 va sonning o'zi bor. 7 ning bo'luvchilari faqat 1 va 7.",a:"m05",
 start:function(){k2c10_rects(7,1);k2c10_big('7 = 1 · 7')},fin:function(){k2c10_rects(7,1);k2c10_big('7 ning bo‘luvchilari: 1 va 7 — boshqa yo‘q!')},
 html:"<p>7 ta kvadratdan nechta xil to'g'ri to'rtburchak yasaysiz? Sinab ko'ring:</p>",
 btns:[["🔍 Yana bormi?",function(c,d,b){b.disabled=true;k2c10_big('2, 3, 4, 5, 6 — hech biri 7 ni qoldiqsiz bo‘lmaydi. Faqat <b>1 · 7</b>!');d()}]],
 after:"<p>7 ning bo'luvchilari faqat <b>2 ta</b>: 1 va 7. Bunday sonlar (2, 3, 5, 7, 11, 13 …) — <b>tub sonlar</b> deyiladi. Ular haqida yuqori sinfda ko'p o'rganasiz.</p>",
 q:{t:"13 ning bo'luvchilari nechta?",opts:["1","2","13","0"],ok:1,why:"Faqat 1 va 13.",hint:"1 va sonning o'zi doim bo'luvchi. Yana bormi?",full:"13 ni 2, 3, 4 … 12 ga bo'lsak, qoldiq chiqadi. Bo'luvchilar: 1 va 13 — 2 ta. «1» — sonning o'zini unutgan."},
 tn:"«1 va o'zi» qoidasini ertalabki og'zaki mashqda takrorlang."},
{h:"Tuzoq: «necha xil usulda bo'lish mumkin?»",sum:"24 ta qalamni 2 dan 9 gacha bolaga teng: 2, 3, 4, 6, 8 — 5 xil.",a:"m06",
 start:function(){S.kk=2;k2c10_groups(24,2)},fin:function(){k2c10_big('24 ning 2–9 oralig‘idagi bo‘luvchilari: 2, 3, 4, 6, 8 — <b>5 xil</b>')},
 html:"<p>Bank savoli: «24 ta qalamni bolalarga ortiqcha qoldirmasdan teng bo'lish kerak. Bolalar soni <b>2 dan 9 gacha</b>. Necha xil usul bor?» Bolalar sonini o'zgartiring:</p>",
 btns:[["◀ kam bola",function(c,d){S.kk=Math.max(2,(S.kk||2)-1);k2c10_groups(24,S.kk);mvK(d,5)}],["ko'p bola ▶",function(c,d){S.kk=Math.min(9,(S.kk||2)+1);k2c10_groups(24,S.kk);mvK(d,5)}]],g2:1,
 after:"<p>Qoldiqsiz bo'ladi: <b>2, 3, 4, 6, 8</b> bola — 5 xil. 5, 7, 9 bolada qalam ortib qoladi. Savol aslida: «24 ning 2 dan 9 gacha bo'luvchilari nechta?»</p>",
 q:{t:"18 ta olmani 2 dan 9 gacha bolaga ortiqcha qoldirmay teng bo'lish kerak. Necha xil usul bor?",opts:["4","3","5","6"],ok:0,why:"18 ning bo'luvchilari 2–9 oralig'ida: 2, 3, 6, 9.",hint:"18 ning bo'luvchilarini yozing, 2 dan 9 gachasini sanang.",full:"18 ning bo'luvchilari: 1, 2, 3, 6, 9, 18. 2 dan 9 gacha: 2, 3, 6, 9 — 4 ta. «6» — barcha bo'luvchilar sanalgan."},
 tn:"Masaladagi chegaralarga («2 dan 9 gacha») e'tibor berishni o'rgating."},
{h:"Tuzoq: ikki xonali karralilarni sanash",sum:"Ikki xonali sonlar orasida 8 ga karralilar: 16, 24, …, 96 — 11 ta.",a:"m07",
 start:function(){k2c10_grid(0);k2c10_big('Ikki xonali sonlar orasida 8 ga karrali sonlar nechta?')},fin:function(){k2c10_grid(8);k2c10_big('16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96 — <b>11 ta</b> (8 — bir xonali!)')},
 html:"<p>Bank savoli: «<b>Ikki xonali</b> sonlar orasida 8 ga karrali sonlar nechta?» 100 jadvalida belgilaymiz.</p>",
 btns:[["🎨 8 ga karralilarni bo'ya",function(c,d){k2c10_grid(8);k2c10_big('Sariq — ikki xonali: 16 … 96 → <b>11 ta</b>. 8 — bir xonali, sanalmaydi');d()}]],
 after:"<p>8 ga karralilar: 8, 16, 24, … 96. Lekin <b>8 bir xonali</b> — uni sanamaymiz. Qoladi: 16 dan 96 gacha — <b>11 ta</b>. Hisoblab: 96 : 8 = 12 ta karrali, birinchisi (8) bir xonali → 12 − 1 = 11.</p>",
 q:{t:"Ikki xonali sonlar orasida 9 ga karrali sonlar nechta?",opts:["10","11","9","12"],ok:0,why:"18, 27, …, 99: 99 : 9 = 11 ta karrali, 9 bir xonali → 10.",hint:"9 ning ko'paytmalarini 99 gacha yozing. Qaysilari ikki xonali?",full:"9 ga karralilar 99 gacha: 9, 18, 27, 36, 45, 54, 63, 72, 81, 90, 99 — 11 ta. 9 bir xonali, demak ikki xonalilar 10 ta."},
 tn:"Ehtiyot qadam: birinchi karrali bir xonali bo'lishi mumkin. Bolalar ro'yxat yozib sanasin, keyin hisob usuliga o'tsin."},
{h:"Bilasizmi? Eratosfen elagi",sum:"2300 yil oldin Eratosfen karralilarni o'chirib, tub sonlarni topish usulini o'ylab topgan.",a:"m08",
 start:function(){k2c10_grid(0);k2c10_big('Eratosfen elagi')},fin:function(){k2c10_grid(0);k2c10_big('Eratosfen elagi')},
 html:"<p>🏛 Taxminan <b>2300 yil oldin</b> yunon olimi <b>Eratosfen</b> shunday o'yin o'ylab topgan: 1 dan 100 gacha sonlarni yozib, 2 ga karralilarni (2 dan tashqari), keyin 3 ga, 5 ga, 7 ga karralilarni o'chiradi. Qolganlari — <b>tub sonlar</b>: faqat 1 ga va o'ziga bo'linadi.</p><p>Bu usul «<b>Eratosfen elagi</b>» deb ataladi: elak ortiqchasini o'tkazib, keraklisini qoldiradi.</p>",
 tn:"Kuchli bolalar bilan 1–30 oralig'ida elakni qilib ko'ring: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 qoladi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c10_rects(12,3);k2c10_big('12 = 1 · 12 = 2 · 6 = 3 · 4')},fin:function(){k2c10_rects(12,3);k2c10_big('12 = 1 · 12 = 2 · 6 = 3 · 4')},
 html:"<div class='memo'><ul><li><b>Bo'luvchi</b> — sonni qoldiqsiz bo'ladigan son. 12 ning bo'luvchilari: 1, 2, 3, 4, 6, 12.</li><li>Bo'luvchilarni <b>juftlab</b> qidiring: 1·12, 2·6, 3·4.</li><li><b>Karrali</b> — songa qoldiqsiz bo'linadigan son: 3 ga karralilar 3, 6, 9, 12, … (cheksiz).</li><li>3 · 4 = 12 → 3 — 12 ning bo'luvchisi, 12 — 3 ga karrali.</li><li>1 va sonning o'zi — doim bo'luvchi. Faqat shu ikkitasi bo'lsa — <b>tub son</b> (2, 3, 5, 7, 11, 13 …).</li><li>Sanashda chegaralarni tekshiring: «ikki xonali», «2 dan 9 gacha».</li></ul></div>",
 tn:"Keyingi darsni «24 ning bo'luvchilarini juftlab toping» bilan boshlang (1,24; 2,12; 3,8; 4,6 → 8 ta)."}
];
var PROBS=[
{t:"Qaysi son 15 ning bo'luvchisi?",o:["5","4","6","10"],k:0,s:"15 : 5 = 3, qoldiqsiz."},
{t:"20 ning bo'luvchilari nechta?",o:["6","4","5","10"],k:0,s:"1, 2, 4, 5, 10, 20 — 6 ta."},
{t:"Qaysi son 6 ga karrali?",o:["42","40","26","16"],k:0,s:"42 = 6 · 7."},
{t:"Qaysi son 9 ga karrali EMAS?",o:["39","36","45","63"],k:0,s:"39 : 9 = 4 va 3 qoldiq. Qolganlari 9 ning jadvalida bor."},
{t:"8 ning bo'luvchilari qaysilar?",o:["1, 2, 4, 8","2, 4","1, 2, 4, 6, 8","8, 16, 24"],k:0,s:"Juftlar: 1·8, 2·4. «8, 16, 24» — bular karralilar."},
{t:"5 ga karrali eng kichik ikki xonali son qaysi?",o:["10","15","5","20"],k:0,s:"5 bir xonali, keyingisi 10."},
{t:"7 ga karrali eng katta ikki xonali son qaysi?",o:["98","97","91","99"],k:0,s:"7 · 14 = 98, 7 · 15 = 105 uch xonali."},
{t:"Qaysi son faqat ikkita bo'luvchiga ega?",o:["11","9","15","12"],k:0,s:"11: faqat 1 va 11. 9: 1,3,9; 15: 1,3,5,15; 12: oltita."},
{t:"24 ta qalamni 2 dan 9 gacha bolaga ortiqcha qoldirmay teng bo'lish mumkin. Necha xil usul?",o:["5","4","3","6"],k:0,s:"2, 3, 4, 6, 8 — 5 xil."},
{t:"Ikki xonali sonlar orasida 8 ga karrali sonlar nechta?",o:["11","12","10","13"],k:0,s:"16, 24, …, 96 — 11 ta."},
{t:"1 dan 30 gacha 4 ga karrali sonlar nechta?",o:["7","8","6","4"],k:0,s:"4, 8, 12, 16, 20, 24, 28 — 7 ta."},
{t:"Qaysi son ham 2 ga, ham 3 ga karrali?",o:["18","16","15","20"],k:0,s:"18 = 2 · 9 = 3 · 6. 16 va 20 — 3 ga, 15 — 2 ga bo'linmaydi."},
{t:"36 ta stulni teng qatorlarga terish kerak, har qatorda kamida 2 ta va qatorlar kamida 2 ta. Necha xil usul bor?",o:["7","9","5","6"],k:0,s:"Qatorlar soni: 2, 3, 4, 6, 9, 12, 18 — 7 xil."},
{t:"Qaysi gap to'g'ri?",o:["6 — 30 ning bo'luvchisi","30 — 6 ning bo'luvchisi","6 — 30 ga karrali","30 — 7 ga karrali"],k:0,s:"30 : 6 = 5, demak 6 — 30 ning bo'luvchisi, 30 esa 6 ga karrali."},
{t:"Bir son 4 ga ham, 6 ga ham karrali va 20 dan kichik. Bu qaysi son?",o:["12","8","18","24"],k:0,s:"4 ga va 6 ga karrali: 12, 24, … 20 dan kichigi — 12."},
{t:"Sonning bo'luvchilari: 1, 2, 3, 6. Bu qaysi son?",o:["6","3","12","9"],k:0,s:"Eng katta bo'luvchi — sonning o'zi: 6."},
{t:"10 dan 40 gacha (ikkalasi ham) 10 ga karrali sonlar yig'indisi?",o:["100","60","90","40"],k:0,s:"10 + 20 + 30 + 40 = 100."},
{t:"Qaysi sonning bo'luvchilari eng ko'p?",o:["12","13","9","10"],k:0,s:"12 — 6 ta, 10 — 4 ta, 9 — 3 ta, 13 — 2 ta."},
{t:"28 ta daftarni sinfdagi bolalarga teng bo'lishdi, har biriga 4 tadan ortiq tegdi va hech nima ortmadi. Bolalar 3 tadan ko'p. Nechta bola bor?",o:["4","7","14","28"],k:0,s:"28 ning bo'luvchilari: 1, 2, 4, 7, 14, 28. Bolalar 3 dan ko'p va har biriga 4 tadan ortiq: 4 bola (7 tadan). 7 bola bo'lsa, har biriga 4 ta — «ortiq» emas."},
{t:"Ikki xonali sonlar orasida 9 ga karrali sonlar nechta?",o:["10","11","9","12"],k:0,s:"18, 27, …, 99 — 10 ta."}
];
function PRACT_STAGE(){k2c10_grid(0);k2c10_msg('Kerak bo‘lsa, 100 jadvalidan foydalaning')}
var PREP_DATA={teach:["Bo'luvchi: sonni qoldiqsiz bo'ladigan son; bo'luvchilarni juftlab topish.","Karrali: songa qoldiqsiz bo'linadigan son; sakrab sanash.","Bo'luvchi va karrali o'rtasidagi bog'liqlik; 1 va sonning o'zi.","Tuzoqlar: chegaralangan sanash («2 dan 9 gacha», «ikki xonali»)."],
 mist:["Bo'luvchi va karrali so'zlarini almashtiradi.","1 ni yoki sonning o'zini bo'luvchilarga qo'shmaydi.","Karralilarni sanashda bir xonalisini ham qo'shadi.","Barcha bo'luvchilarni topishda juftini unutadi."],
 need:["12 va 24 ta tugma yoki konfet.","Katakli qog'oz (to'rtburchaklar uchun).","Devoriy 100 jadvali."],
 board:["<span class='w2'>12 : 1, 2, 3, 4, 6, 12</span> — bo'luvchilar.","Juftlar: <span class='w2'>1·12, 2·6, 3·4</span>.","Karralilar: <span class='w2'>3, 6, 9, 12, …</span>","<span class='w2'>3 · 4 = 12</span>: 3 — bo'luvchi, 12 — karrali.","Tub son: faqat 1 va o'zi (7, 13).","<span class='w2'>16 … 96</span> — 8 ga karrali ikki xonalilar, 11 ta."]};
