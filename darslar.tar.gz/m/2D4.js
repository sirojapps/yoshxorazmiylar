var CODE='2D4',TITLE='2-sinf · Ko‘paytirish va bo‘lishga oid masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function bm4eq(n,v,c,extra,w){var s=[];for(var i=0;i<n;i++)s.push({w:w||1,txt:v,c:c||'a'});return s.concat(extra||[])}
var STEPS=[
bmStep({h:"Teng guruhlar — ko'paytirish",sum:"4 ta skameyka, har birida 5 kishi: 5 · 4 = 20.",a:"m01",
 frames:[{t:'4 ta skameyka, har biriga 5 kishi sig‘adi. Jami nechta o‘rin?',bars:[{y:66,segs:bm4eq(4,'5','b')}],br:[{b:0,lab:'jami = ?',up:false}],note:'4 ta TENG bo‘lak, har biri 5 tadan'},
  {t:'4 ta skameyka, har biriga 5 kishi sig‘adi. Jami nechta o‘rin?',bars:[{y:66,segs:bm4eq(4,'5','b')}],br:[{b:0,lab:'5 · 4 = 20',up:false,col:C.ok}],calc:['Teng bo‘laklar qo‘shiladi: 5 + 5 + 5 + 5 = 20','Qisqasi: <b>5 · 4 = 20</b> o‘rin']}],
 html:"<p>Chizmada bo'laklar <b>teng</b> bo'lsa — bu ko'paytirish masalasi. Kuzating.</p>",
 after:"<p><b>Teng</b> bo'laklar soni va bitta bo'lak ma'lum, butun noma'lum → <b>ko'paytiramiz</b>: bitta bo'lak · bo'laklar soni.</p>",
 q:{t:"3 ta qutida 6 tadan qalam bor. Jami nechta qalam?",opts:["9","18","3","36"],ok:1,why:"6 · 3 = 18.",hint:"Bo'laklar tengmi? Teng bo'laklarni tez qo'shish — qaysi amal?",full:"3 ta teng bo'lak, har biri 6: 6 + 6 + 6 = 18 yoki 6 · 3 = 18. «9» — 6 + 3, bu teng bo'laklar emas."},
 tn:"Bolalar chizmadagi har bo'lakka sonni yozsin — teng bo'laklar ko'paytirishga olib kelishini o'zi ko'radi."}),
bmStep({h:"Teng bo'lish — har biriga nechtadan?",sum:"30 kitob 5 o'quvchiga teng: 30 : 5 = 6.",a:"m02",
 frames:[{t:'30 ta kitobni 5 o‘quvchi teng bo‘lib oldi. Har biriga nechtadan?',bars:[{y:66,segs:bm4eq(5,'?','q')}],br:[{b:0,lab:'30 kitob',up:false}],note:'Butun (30) va bo‘laklar soni (5) ma’lum'},
  {t:'30 ta kitobni 5 o‘quvchi teng bo‘lib oldi. Har biriga nechtadan?',bars:[{y:66,segs:bm4eq(5,'6','g')}],br:[{b:0,lab:'30 kitob',up:false}],calc:['Butun teng bo‘laklarga bo‘linadi → <b>bo‘lamiz</b>','30 : 5 = <b>6</b> ta kitob']}],
 html:"<p>Teskarisi: <b>butun</b> ma'lum, uni <b>teng</b> bo'laklarga bo'lamiz. Kuzating.</p>",
 after:"<p>Butun va bo'laklar soni ma'lum, bitta bo'lak noma'lum → <b>bo'lamiz</b>. Tekshirish: 6 · 5 = 30 ✓</p>",
 q:{t:"24 ta konfetni 4 bola teng bo'lishdi. Har biriga nechta tegdi?",opts:["20","6","28","8"],ok:1,why:"24 : 4 = 6.",hint:"Butunni teng bo'laklarga bo'lyapmiz — qaysi amal?",full:"24 ta konfet 4 ta teng bo'lakka: 24 : 4 = 6. Tekshiramiz: 6 · 4 = 24 ✓. «20» — ayirib yuborish xatosi."},
 tn:"Haqiqiy narsalarni (cho'p, tugma) bolalar o'zi teng bo'lib ko'rsin — «hammaga bittadan» usuli."}),
bmStep({h:"Nechta guruh chiqadi?",sum:"20 sm lenta 4 sm dan kesilsa: 20 : 4 = 5 bo'lak.",a:"m03",
 frames:[{t:'20 sm lentani 4 sm li bo‘laklarga kesamiz. Nechta bo‘lak?',bars:[{y:66,segs:[{w:4,txt:'4',c:'a'},{w:16,txt:'?',c:'q'}]}],br:[{b:0,lab:'20 sm',up:false}],note:'Bu safar bitta bo‘lak (4 sm) ma’lum, bo‘laklar SONI noma’lum'},
  {t:'20 sm lentani 4 sm li bo‘laklarga kesamiz. Nechta bo‘lak?',bars:[{y:66,segs:bm4eq(5,'4','a')}],br:[{b:0,lab:'20 sm',up:false}],calc:['20 da nechta 4 bor? 4, 8, 12, 16, 20 — 5 ta','<b>20 : 4 = 5</b> bo‘lak']}],
 html:"<p>Bo'lishning ikkinchi ma'nosi: bitta bo'lak ma'lum, <b>nechta</b> bo'lak chiqishini topamiz. Kuzating.</p>",
 after:"<p>Bo'lishning ikki ma'nosi bor: <b>1)</b> «har biriga nechtadan?» va <b>2)</b> «nechta guruh?». Ikkalasi ham bo'lish!</p>",
 q:{t:"18 ta tuxumni qutilarga 6 tadan soldik. Nechta quti kerak bo'ldi?",opts:["12","3","24","6"],ok:1,why:"18 : 6 = 3.",hint:"18 da nechta 6 bor?",full:"Har qutiga 6 ta: 6, 12, 18 — 3 ta quti. 18 : 6 = 3."},
 tn:"Ikkala ma'noni doskada yonma-yon chizing: «5 ta bo'lak — har biri ?» va «har biri 4 — nechta bo'lak?»."}),
bmStep({h:"Ikki amal: avval jamlaymiz, keyin bo'lamiz",sum:"27 + 3 = 30 kitob, 30 : 5 = 6.",a:"m04",
 frames:[{t:'27 kitob bor edi, yana 3 ta keltirildi. Hammasini 5 o‘quvchi teng bo‘lib oldi.',bars:[{y:44,segs:[{w:27,txt:'27',c:'b'},{w:3,txt:'3',c:'g'}]}],br:[{b:0,lab:'30',up:false}],calc:['1) 27 + 3 = 30 kitob']},
  {t:'27 kitob bor edi, yana 3 ta keltirildi. Hammasini 5 o‘quvchi teng bo‘lib oldi.',bars:[{y:44,segs:[{w:27,txt:'27',c:'b'},{w:3,txt:'3',c:'g'}]},{y:112,segs:bm4eq(5,'6','a',null,6)}],br:[{b:1,lab:'30',up:false}],calc:['1) 27 + 3 = 30','2) 30 : 5 = <b>6</b> ta kitob']}],
 html:"<p>Ikki amalli masala: avval butunni topamiz, keyin uni teng bo'lamiz.</p>",
 after:"<p>Xato yo'l: 27 : 5 — bo'linmaydi, yoki 3 ni unutish. Avval <b>hammasini</b> topamiz!</p>",
 q:{t:"Bir savatda 16 ta, ikkinchisida 14 ta olma. Hammasini 5 likopchaga teng terishdi. Har likopchada nechta?",opts:["30","6","3","8"],ok:1,why:"16 + 14 = 30, 30 : 5 = 6.",hint:"Avval jami olmalarni toping.",full:"1) 16 + 14 = 30. 2) 30 : 5 = 6. «30» — bu jami olmalar, bitta likopcha emas."},
 tn:"Bolalarga avval chizmani, keyin rejani yozdiring: «1) jami, 2) har biriga»."}),
bmStep({h:"Tuzoq: yetmaydigan o'rinlar",sum:"4 skameyka · 5 = 20 o'rin, 23 o'quvchi: 23 − 20 = 3 kishiga yetmaydi.",a:"m05",
 frames:[{t:'4 skameyka, har biriga 5 kishi. 23 o‘quvchi keldi.',bars:[{lab:'o‘rin',y:44,segs:bm4eq(4,'5','b',null,5)},{lab:'bolalar',y:106,segs:[{w:20,txt:'20',c:'a'},{w:3,txt:'?',c:'q'}]}],note:'Nechta o‘quvchiga o‘rin yetmaydi?'}],
 html:"<p>Bankdagi masala. To'g'ri javobni tanlang:</p>",
 btns:bmPick(["27","3","20"],1,{t:'4 skameyka, har biriga 5 kishi. 23 o‘quvchi keldi.',bars:[{lab:'o‘rin',y:44,segs:bm4eq(4,'5','b',null,5)},{lab:'bolalar',y:106,segs:[{w:20,txt:'20 o‘tirdi',c:'a'},{w:3,txt:'3',c:'c'}]}],calc:['1) O‘rinlar: 5 · 4 = 20','2) Yetmaydi: 23 − 20 = <b>3</b> kishiga']},["27 — barcha sonlarni qo‘shib yuborish (23 + 4). Ma’nosi yo‘q.","","20 — o‘rinlar soni, savol esa yetmaganlarni so‘rayapti."]),
 after:"<p>Avval nechta <b>o'rin</b> borligini topamiz (ko'paytirish), keyin bolalar bilan <b>solishtiramiz</b> (ayirish).</p>",
 q:{t:"Robot har daqiqada 4 ta quti tashiydi. 23 ta quti bor. 5 daqiqadan keyin nechta quti qoladi?",opts:["20","3","18","7"],ok:1,why:"5 daqiqada 4 · 5 = 20, qoldi 23 − 20 = 3.",hint:"Avval 5 daqiqada nechta quti tashilganini toping.",full:"1) 4 · 5 = 20 ta tashildi. 2) 23 − 20 = 3 ta qoldi. «18» — 23 − 5, daqiqani quti deb ayirish xatosi."},
 tn:"Sahnalashtiring: 4 ta stulga 5 tadan bola o'tirsin, qolganlari turib qolsin."}),
bmStep({h:"Teng guruhlar ikki joyda",sum:"Har qovun 4 kg; 20 + 30 = 50 ta qovun; 4 · 50 = 200 kg.",a:"m06",
 frames:[{t:'Har qovun 4 kg. 1-aravada 20 ta, 2-sida 30 ta qovun.',bars:[{y:56,segs:[{w:20,txt:'20 ta',c:'a'},{w:30,txt:'30 ta',c:'g'}]}],br:[{b:0,lab:'50 ta qovun',up:false}],calc:['1) Jami qovun: 20 + 30 = 50 ta']},
  {t:'Har qovun 4 kg. 1-aravada 20 ta, 2-sida 30 ta qovun.',bars:[{y:56,segs:[{w:20,txt:'20 ta',c:'a'},{w:30,txt:'30 ta',c:'g'}]}],br:[{b:0,lab:'50 · 4 = 200 kg',up:false,col:C.ok}],calc:['1) 20 + 30 = 50 ta','2) Massa: 50 · 4 = <b>200</b> kg']}],
 html:"<p>Ikki aravadagi qovunlar umumiy massasini topamiz. Ikki yo'l bor — bittasini kuzating.</p>",
 after:"<p>Ikkinchi yo'l: 20 · 4 = 80 kg, 30 · 4 = 120 kg, jami 80 + 120 = 200 kg. Ikkala yo'l bir xil javob beradi.</p>",
 q:{t:"Bir qutida 10 ta tuxum. Do'konga 3 quti, keyin yana 4 quti keltirildi. Jami nechta tuxum?",opts:["17","70","40","700"],ok:1,why:"3 + 4 = 7 quti, 7 · 10 = 70.",hint:"Avval qutilar sonini toping.",full:"1) 3 + 4 = 7 quti. 2) 7 · 10 = 70 ta tuxum. «17» — quti va tuxumni qo'shib yuborish."},
 tn:"Bolalardan ikkala yo'lni ham yozib, javobni solishtirishni so'rang."}),
bmStep({h:"Tuzoq: kesimlar va bo'laklar",sum:"Lentani 4 bo'lakka bo'lish uchun 3 ta kesim kerak.",a:"m07",
 frames:[{t:'Lentani 4 ta bo‘lakka bo‘lish uchun nechta kesim kerak?',bars:[{y:66,segs:bm4eq(4,'','a')}],txt:[[143,60,'✂',{'font-size':18}],[208,60,'✂',{'font-size':18}],[274,60,'✂',{'font-size':18}]],calc:['Bo‘laklar orasida kesim bor: 4 bo‘lak → <b>3</b> ta kesim']}],
 html:"<p>Olimpiada savoli: <i>«Lentani 4 ta bo'lakka kesish uchun nechta kesim kerak?»</i> Javobni tanlang:</p>",
 btns:bmPick(["4","3","5"],1,null,["Chizmani sanang: oxirgi bo‘lakdan keyin kesish kerak emas.","","Kesimlar bo‘laklardan ko‘p bo‘lmaydi."]),
 after:"<p>Kesimlar bo'laklar <b>orasida</b> bo'ladi, shuning uchun ular bitta kam. Har kesimga 2 daqiqa ketsa, 4 bo'lakka 3 · 2 = 6 daqiqa ketadi, 8 emas!</p>",
 q:{t:"Xodani 5 bo'lakka arraladilar. Har bir arralash 3 daqiqa. Hammasi necha daqiqa?",opts:["15","12","8","18"],ok:1,why:"5 bo'lak — 4 ta arralash: 4 · 3 = 12.",hint:"Avval nechta arralash kerakligini toping.",full:"5 bo'lak uchun 4 ta kesim. 4 · 3 = 12 daqiqa. «15» — bo'laklar sonini kesim deb olish xatosi."},
 tn:"Qog'oz tasmani bolalar o'zi kesib, kesimlarni sanasin."}),
bmStep({h:"Bilasizmi? Al-Xorazmiyning «Hind hisobi»",sum:"Al-Xorazmiy to'rt amalni (qo'shish, ayirish, ko'paytirish, bo'lish) yangi raqamlar bilan tushuntirgan.",a:"m08",
 frames:[{t:'Kitob: «Hind hisobi haqida»',bg:'#f6ead0',bars:[{y:56,h:60,segs:[{w:1,txt:'+',c:'#f2d39a',fs:26},{w:1,txt:'−',c:'#f2d39a',fs:26},{w:1,txt:'·',c:'#f2d39a',fs:26},{w:1,txt:':',c:'#f2d39a',fs:26}]}],note:'To‘rt arifmetik amal'}],
 html:"<p>📖 Vatandoshimiz <b>Muhammad al-Xorazmiy</b> IX asrda hind raqamlari bilan hisoblash haqida kitob yozgan. Unda qo'shish, ayirish, ko'paytirish va bo'lish qanday bajarilishi tushuntirilgan.</p><p>Bu kitob lotin tiliga tarjima qilinib, Yevropada asrlar davomida darslik bo'lgan. Bugun biz ishlatadigan hisoblash usullari shu kitob orqali tarqalgan.</p>",
 tn:"Loyiha nomi — «Yosh Xorazmiylar» — aynan shu olim sharafiga."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'Teng bo‘laklar',bars:[{y:66,segs:bm4eq(4,'5','b')}],br:[{b:0,lab:'5 · 4 = 20',up:false}]}],
 html:"<div class='memo'><ul><li>Chizmada <b>teng</b> bo'laklar → ko'paytirish yoki bo'lish.</li><li>Bitta bo'lak va bo'laklar soni ma'lum → <b>ko'paytiramiz</b>: 5 · 4 = 20.</li><li>Butun va bo'laklar soni ma'lum → <b>bo'lamiz</b> («har biriga nechtadan?»): 30 : 5 = 6.</li><li>Butun va bitta bo'lak ma'lum → <b>bo'lamiz</b> («nechta guruh?»): 20 : 4 = 5.</li><li>Ikki amalda avval <b>jamini</b> toping, keyin bo'ling.</li><li>Kesimlar bo'laklardan <b>bitta kam</b>.</li><li>Tekshirish: ko'paytirish ↔ bo'lish.</li></ul></div>",
 tn:"Keyingi darsni «20 ta olmani 3 tadan qopchaga solsak, nechta qopcha to'ladi va nechta olma ortadi?» savoli bilan boshlang."})
];
var PROBS=[
{t:"Sport zalida 4 ta skameyka, har biriga 5 kishi sig'adi. Zalga 23 o'quvchi keldi. Nechta o'quvchiga o'rin yetmaydi?",o:["3","27","2","20"],k:0,s:"5 · 4 = 20 o'rin, 23 − 20 = 3."},
{t:"Kutubxonada 27 ta ertak kitobi bor edi, yana 3 ta keltirildi. Hammasini 5 o'quvchi teng bo'lib oldi. Har biri nechtadan oldi?",o:["6","30","7","5"],k:0,s:"27 + 3 = 30, 30 : 5 = 6."},
{t:"Bir savatda 16 ta, ikkinchisida 14 ta olma. Hammasini 5 ta likopchaga teng terishdi. Har likopchada nechta olma?",o:["6","3","8","5"],k:0,s:"16 + 14 = 30, 30 : 5 = 6."},
{t:"Har bir qovun 4 kg. 1-aravada 20 ta, 2-aravada 30 ta qovun bor. Umumiy massasi necha kg?",o:["200 kg","50 kg","80 kg","120 kg"],k:0,s:"20 + 30 = 50, 50 · 4 = 200 kg."},
{t:"60 sm lentadan avval 15 sm kesildi, qolgani 3 ta teng bo'lakka kesildi. Har bo'lak necha sm?",o:["15","12","20","45"],k:0,s:"60 − 15 = 45, 45 : 3 = 15 sm."},
{t:"Robot har daqiqada 4 ta quti tashiydi. Unga 23 ta quti tashish kerak. 5 daqiqadan keyin nechta quti qoladi?",o:["3","18","7","20"],k:0,s:"4 · 5 = 20, 23 − 20 = 3."},
{t:"3 ta qutida 6 tadan qalam bor. Jami nechta qalam?",o:["18","9","3","36"],k:0,s:"6 · 3 = 18."},
{t:"24 ta konfetni 4 bola teng bo'lishdi. Har biriga nechta tegdi?",o:["6","20","8","28"],k:0,s:"24 : 4 = 6."},
{t:"18 ta tuxumni qutilarga 6 tadan soldik. Nechta quti kerak bo'ldi?",o:["3","12","24","6"],k:0,s:"18 : 6 = 3."},
{t:"Xodani 5 bo'lakka arraladilar. Har bir arralash 3 daqiqa. Hammasi necha daqiqa?",o:["12","15","8","18"],k:0,s:"4 ta arralash: 4 · 3 = 12."},
{t:"Bir qutida 10 ta tuxum. Avval 3 quti, keyin yana 4 quti keltirildi. Jami nechta tuxum?",o:["70","17","40","30"],k:0,s:"3 + 4 = 7 quti, 7 · 10 = 70."},
{t:"Bog'da 5 qator, har qatorda 8 tadan daraxt. 12 ta daraxt olma, qolgani o'rik. Nechta o'rik?",o:["28","40","25","52"],k:0,s:"8 · 5 = 40, 40 − 12 = 28."},
{t:"35 o'quvchini 5 tadan guruhlarga bo'lishdi. Nechta guruh chiqdi?",o:["7","30","5","40"],k:0,s:"35 : 5 = 7."},
{t:"Bir daftar 3 ming so'm. 4 ta daftar va 2 ming so'mlik ruchka olindi. Hammasi qancha?",o:["14 ming so'm","12 ming so'm","9 ming so'm","20 ming so'm"],k:0,s:"3 · 4 = 12, 12 + 2 = 14 ming so'm."},
{t:"20 ta olmani 3 tadan qopchaga soldik. Nechta qopcha to'ladi?",o:["6","7","3","17"],k:0,s:"3 · 6 = 18, 20 − 18 = 2 ta ortadi. 6 ta qopcha to'ladi."},
{t:"Avtobusda 9 qator, har qatorda 4 ta o'rin. 30 kishi o'tirdi. Nechta o'rin bo'sh?",o:["6","36","13","5"],k:0,s:"4 · 9 = 36, 36 − 30 = 6."},
{t:"Ali 2 ta stiker oldi, Vali Alidan 3 marta ko'p, Sardor esa Validan 2 ta kam oldi. Sardorda nechta?",o:["4","6","8","3"],k:0,s:"Vali 2 · 3 = 6, Sardor 6 − 2 = 4."},
{t:"16 ta sharni 2 tadan bog'lab, 4 do'stga teng bo'lishdi. Har biriga nechta bog'lam tegdi?",o:["2","4","8","6"],k:0,s:"16 : 2 = 8 bog'lam, 8 : 4 = 2."},
{t:"Zinapoyaning har bir pog'onasi 2 sm baland. 1-qavatdan 2-qavatgacha 10 pog'ona. Necha santimetr ko'tarildik?",o:["20","12","10","8"],k:0,s:"2 · 10 = 20 sm."},
{t:"Qatorda 6 ta ustun, ular orasidagi har oraliq 3 m. Birinchi ustundan oxirgisigacha necha metr?",o:["15","18","9","21"],k:0,s:"6 ustun — 5 oraliq: 3 · 5 = 15 m."}
];
function PRACT_STAGE(){bmDraw({t:'Teng bo‘laklarni chizing',bars:[{y:66,segs:bm4eq(4,'?','b')}],br:[{b:0,lab:'butun',up:false}],note:'Bo‘lak · son = butun · butun : son = bo‘lak'})}
var PREP_DATA={teach:["Teng bo'laklar chizmasi: ko'paytirish.","Bo'lishning ikki ma'nosi: «har biriga nechtadan?» va «nechta guruh?».","Ko'paytirish/bo'lish + qo'shish/ayirish ikki amalli masalalar.","Tuzoqlar: yetmagan o'rinlar, kesimlar soni."],
 mist:["Teng bo'laklarni ko'rmasdan qo'shib yuboradi.","Ikki amalli masalada jamini unutadi.","«4 bo'lak — 4 kesim» deb o'ylaydi.","Bo'lish o'rniga ayiradi (24 − 4)."],
 need:["Cho'p/tugmalar, qog'oz tasma va qaychi."],
 board:["<span class='w2'>[5|5|5|5] → 5 · 4 = 20</span>.","<span class='w2'>[?|?|?|?|?] = 30 → 30 : 5 = 6</span>.","<span class='w2'>20 : 4 = 5</span> bo'lak.","<span class='w2'>(27 + 3) : 5 = 6</span>.","Kesimlar: 4 bo'lak — 3 kesim."]};
