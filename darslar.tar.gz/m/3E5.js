var CODE='3E5',TITLE='3-sinf · Teskari masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w5u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
// strelkali zanjir: f.b — kataklar, f.o — oldinga amallar, f.r — orqaga amallar (ixtiyoriy), f.hl — {i:'q'|'ok'}
function w5ar(g,x1,x2,y,col,left){E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2},g);var h=left?x1:x2,d=left?6:-6;E('path',{d:'M'+h+' '+y+' l'+d+' -4 l0 8 z',fill:col},g)}
function w5ch(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,n=f.b.length,bw=n>4?44:50,gap=(340-n*bw)/(n-1),y=f.y||68,bh=40,hl=f.hl||{};
 f.b.forEach(function(v,i){var x=10+i*(bw+gap),c=hl[i],q=String(v)==='?';
  E('rect',{x:x,y:y,width:bw,height:bh,rx:8,fill:c==='ok'?'#e6f6ee':q?'#fff4d6':'#fff',stroke:c==='ok'?C.ok:q?'#e0b84a':'#9fb3c8','stroke-width':2,'stroke-dasharray':q?'5 4':''},g);
  T(g,x+bw/2,y+bh/2+5,String(v),{'font-size':v.length>4?12:15,'font-weight':800,fill:c==='ok'?C.ok:q?'#c98a00':'#1d2b3a'});
  if(i<n-1){var a=x+bw+3,b=x+bw+gap-3;if(f.o){w5ar(g,a,b,y+10,'#2f6fb0');T(g,(a+b)/2,y-4,f.o[i],{'font-size':12,'font-weight':800,fill:'#2f6fb0'})}
   if(f.r&&f.r[i]){w5ar(g,a,b,y+bh-10,'#e07a2f',true);T(g,(a+b)/2,y+bh+15,f.r[i],{'font-size':12,'font-weight':800,fill:'#e07a2f'})}}})}
function w5st(o){var P=o.frames.map(function(f){return function(){f.b?w5ch(f):bmDraw(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function w5pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)(okF.b?w5ch:bmDraw)(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
var STEPS=[
w5st({h:"Oxiridan boshlaymiz",sum:"? + 26 − 15 = 142. Orqaga: 142 + 15 = 157, 157 − 26 = 131 marka.",a:"m01",
 frames:[{t:'Javlon 26 ta marka qo‘shdi, keyin 15 tasini sovg‘a qildi. 142 ta qoldi. Dastlab nechta edi?',b:['?','?','142'],o:['+ 26','− 15'],note:'Faqat oxirgi son ma’lum — orqaga yuramiz'},
  {t:'Javlon 26 ta marka qo‘shdi, keyin 15 tasini sovg‘a qildi. 142 ta qoldi. Dastlab nechta edi?',b:['?','157','142'],o:['+ 26','− 15'],r:['','+ 15'],calc:['Sovg‘adan oldin: 142 + 15 = 157']},
  {t:'Javlon 26 ta marka qo‘shdi, keyin 15 tasini sovg‘a qildi. 142 ta qoldi. Dastlab nechta edi?',b:['131','157','142'],o:['+ 26','− 15'],r:['− 26','+ 15'],hl:{0:'ok'},calc:['1) 142 + 15 = 157','2) 157 − 26 = <b>131</b> marka']}],
 html:"<p>Bu masalada <b>boshi</b> noma'lum, <b>oxiri</b> ma'lum. Strelkalar ustida — Javlon qilgan ishlar. Biz esa <b>orqaga</b> yuramiz. Kuzating.</p>",
 after:"<p>Orqaga yurganda har bir amal <b>teskarisiga</b> almashadi: «− 15» → «+ 15», «+ 26» → «− 26». Tekshirish — oldinga: 131 + 26 − 15 = 142 ✓.</p>",
 q:{t:"Nodirada konfet bor edi. U 12 tasini yedi, keyin onasi 20 ta berdi. 45 ta bo'ldi. Dastlab nechta edi?",opts:["37","77","53","13"],ok:0,why:"45 − 20 = 25; 25 + 12 = 37.",hint:"Oxiridan: onasi bermasdan oldin nechta edi?",full:"Orqaga: 45 − 20 = 25 (onasi bermasdan oldin), 25 + 12 = 37 (yemasdan oldin). Tekshiruv: 37 − 12 + 20 = 45 ✓. «77» — amallar teskarisiga almashtirilmagan (45 + 20 + 12)."},
 tn:"Bank misoli (1352-id). Doskada strelkali zanjir: tepadagi ko'k strelkalar — voqea, pastdagi to'q sariq strelkalar — yechim yo'li. Bolalar «teskari amal»ni ovoz chiqarib aytsin."}),
w5st({h:"Qaysi amal birinchi?",sum:"? · 6 − 48 = 30. Oxirgi amaldan boshlaymiz: 30 + 48 = 78, keyin 78 : 6 = 13.",a:"m02",
 frames:[{t:'O‘ylangan son 6 ga ko‘paytirildi, natijadan 48 ayirildi va 30 chiqdi.',b:['?','?','30'],o:['· 6','− 48'],note:'Birinchi qaysi hisobni bajaramiz?'}],
 html:"<p>O'ylangan sonni topamiz. Qaysi hisobdan <b>boshlash</b> kerak?</p>",
 btns:w5pk(["30 + 48","30 : 6","30 − 48"],0,{t:'O‘ylangan son 6 ga ko‘paytirildi, natijadan 48 ayirildi va 30 chiqdi.',b:['13','78','30'],o:['· 6','− 48'],r:[': 6','+ 48'],hl:{0:'ok'},calc:['1) 30 + 48 = 78','2) 78 : 6 = <b>13</b>']},["","Oxirgi amal — «− 48», u birinchi bekor qilinadi. 6 ga ko‘paytirish undan oldin bo‘lgan.","«− 48» ning teskarisi — qo‘shish. Ayirsak, 30 dan 48 ni ayirib bo‘lmaydi."]),
 after:"<p>Qoida: <b>oxirgi amal birinchi</b> bekor qilinadi. «·» ning teskarisi «:», «−» ning teskarisi «+». Tekshiruv: 13 · 6 = 78, 78 − 48 = 30 ✓.</p>",
 q:{t:"Son 4 ga bo'lindi, natijaga 17 qo'shildi va 25 chiqdi. Qaysi son?",opts:["32","168","8","2"],ok:0,why:"25 − 17 = 8; 8 · 4 = 32.",hint:"Oxirgi amal — «+ 17».",full:"Orqaga: 25 − 17 = 8, keyin 8 · 4 = 32. Tekshiruv: 32 : 4 = 8, 8 + 17 = 25 ✓. «168» — (25 + 17) · 4, amal teskarisi olinmagan; «8» — faqat 1-qadam."},
 tn:"Bank misoli (3079-id). «Kiyim» o'xshatishi: ertalab avval ko'ylak, keyin kurtka kiyasiz; kechqurun avval kurtkani yechasiz — oxirgisi birinchi."}),
w5st({h:"Uzun zanjir",sum:"? + 27 − 45 + 18 − 9 = 64. Orqaga: 64 + 9 = 73, 73 − 18 = 55, 55 + 45 = 100, 100 − 27 = 73.",a:"m03",
 frames:[{t:'Boshlang‘ich sondan 4 ta amal bajarildi va 64 chiqdi',b:['?','?','?','?','64'],o:['+ 27','− 45','+ 18','− 9'],note:'Orqaga — to‘rt qadam'},
  {t:'Boshlang‘ich sondan 4 ta amal bajarildi va 64 chiqdi',b:['?','?','55','73','64'],o:['+ 27','− 45','+ 18','− 9'],r:['','','− 18','+ 9'],calc:['64 + 9 = 73,  73 − 18 = 55']},
  {t:'Boshlang‘ich sondan 4 ta amal bajarildi va 64 chiqdi',b:['73','100','55','73','64'],o:['+ 27','− 45','+ 18','− 9'],r:['− 27','+ 45','− 18','+ 9'],hl:{0:'ok'},calc:['55 + 45 = 100,  100 − 27 = <b>73</b>','Tekshiruv: 73 + 27 − 45 + 18 − 9 = 64 ✓']}],
 html:"<p>Zanjir uzun bo'lsa ham usul o'sha: o'ngdan chapga, har bir amalni teskarisiga almashtirib. Kuzating.</p>",
 after:"<p>Qiziq: boshlang'ich son ham 73, ikkinchi qadamdagi son ham 73! Shuning uchun har bir katakni <b>yozib</b> borish muhim — boshda chalkashmaslik uchun.</p>",
 q:{t:"? − 30 + 14 − 8 = 50. Boshlang'ich son nechaga teng?",opts:["74","26","102","66"],ok:0,why:"50 + 8 = 58, 58 − 14 = 44, 44 + 30 = 74.",hint:"Oxiridan: 50 + 8 = ?",full:"Orqaga: 50 + 8 = 58; 58 − 14 = 44; 44 + 30 = 74. Tekshiruv: 74 − 30 + 14 − 8 = 50 ✓. «26» — amallar teskarisiga almashtirilmagan, «102» — hammasi qo'shilgan."},
 tn:"Bank misoli (1351-id). Bolalar o'zi zanjir tuzib, bir-biriga topishmoq bersin."}),
w5st({h:"Tuzoq: ombor",sum:"? − 120 − 85 + 60 = 400. Orqaga: 400 − 60 + 85 + 120 = 545 kg.",a:"m04",
 frames:[{t:'1-kuni 120 kg, 2-kuni 85 kg olib ketildi, 3-kuni 60 kg keltirildi. 400 kg bo‘ldi.',b:['?','?','?','400'],o:['− 120','− 85','+ 60'],note:'Dastlab necha kg bo‘lgan? Tanlang:'}],
 html:"<p>«Olib ketildi» va «keltirildi» — qaysi biri qo'shish, qaysi biri ayirish? Orqaga yurganda-chi?</p>",
 btns:w5pk(["255 kg","665 kg","545 kg"],2,{t:'1-kuni 120 kg, 2-kuni 85 kg olib ketildi, 3-kuni 60 kg keltirildi. 400 kg bo‘ldi.',b:['545','425','340','400'],o:['− 120','− 85','+ 60'],r:['+ 120','+ 85','− 60'],hl:{0:'ok'},calc:['400 − 60 = 340,  340 + 85 = 425','425 + 120 = <b>545</b> kg']},["255 = 400 + 60 − 85 − 120: amallar teskarisiga almashtirilmagan.","665 = 400 + 60 + 85 + 120: «+ 60» ning teskarisi — ayirish.",""]),
 after:"<p>Orqaga: keltirilgan 60 kg — <b>ayiramiz</b>, olib ketilgan 85 va 120 kg — <b>qo'shamiz</b>. Har bir amal teskarisiga!</p>",
 q:{t:"Avtobusda yo'lovchilar bor edi. Bekatda 8 kishi tushdi, 15 kishi chiqdi. Keyingi bekatda 6 kishi tushdi. 31 kishi qoldi. Dastlab nechta edi?",opts:["30","60","32","14"],ok:0,why:"31 + 6 − 15 + 8 = 30.",hint:"Orqaga: tushganlar → qo'shamiz, chiqqanlar → ayiramiz.",full:"Orqaga: 31 + 6 = 37; 37 − 15 = 22; 22 + 8 = 30. Tekshiruv: 30 − 8 + 15 − 6 = 31 ✓. «60» — hammasi qo'shilgan, «32» — amallar teskarisiga almashtirilmagan."},
 tn:"Bank misoli (3080-id), 3-daraja. Ombor o'rniga sinfdagi kitob javoni bilan sahnalashtiring."}),
w5st({h:"Yarmi bilan: chizma yordam beradi",sum:"Ali pulining yarmiga kitob oldi, 5 ming qalam, 15 ming qoldi: yarmi = 5 + 15 = 20 → hammasi 40 ming.",a:"m05",
 frames:[{t:'Ali pulining yarmiga kitob oldi, keyin 5 ming so‘mga qalam oldi. 15 ming qoldi.',bars:[{lab:'pul',y:80,segs:[{w:20,txt:'kitob',c:'a'},{w:5,txt:'5',c:'b'},{w:15,txt:'15',c:'g'}]}],br:[{b:0,from:0,to:0,lab:'yarmi',up:true},{b:0,from:1,to:2,lab:'yarmi',up:true}],note:'Ikkala yarmi teng!'},
  {t:'Ali pulining yarmiga kitob oldi, keyin 5 ming so‘mga qalam oldi. 15 ming qoldi.',bars:[{lab:'pul',y:80,segs:[{w:20,txt:'20',c:'a'},{w:5,txt:'5',c:'b'},{w:15,txt:'15',c:'g'}]}],br:[{b:0,from:1,to:2,lab:'5 + 15 = 20',up:true},{b:0,lab:'40 ming',up:false,col:C.ok}],calc:['Ikkinchi yarmi: 5 + 15 = 20 ming','Hammasi: 20 · 2 = <b>40</b> ming so‘m']}],
 html:"<p>«Yarmi» so'zi bor bo'lsa — zanjir o'rniga <b>chizma</b> qulayroq. Kuzating.</p>",
 after:"<p>Orqaga zanjir bilan ham shunday: 15 + 5 = 20 (qalamgacha), 20 · 2 = 40 («yarmini sarfladi» ning teskarisi — 2 ga ko'paytirish).</p>",
 q:{t:"Dilnoza pulining yarmiga sharf oldi, keyin 3 ming so'mga muzqaymoq oldi, 7 ming qoldi. Dastlab qancha puli bor edi?",opts:["20 ming","10 ming","17 ming","14 ming"],ok:0,why:"Yarmi 3 + 7 = 10; hammasi 20.",hint:"Ikkinchi yarmi nimalardan iborat?",full:"Ikkinchi yarmi: muzqaymoq + qoldiq = 3 + 7 = 10 ming. Hammasi 10 · 2 = 20 ming. «10 ming» — faqat yarmi, «17 ming» — 7 · 2 + 3 (tartib buzilgan)."},
 tn:"Bank misoli (3078-id). Qog'oz tasmani o'rtasidan buklab, «yarmi»ni ko'rsating."}),
w5st({h:"Yarmining yarmi",sum:"1-kun yarmi, 2-kun qolganining yarmi, 30 bet qoldi: 30 · 2 = 60 (qolgani), 60 · 2 = 120 bet.",a:"m06",
 frames:[{t:'1-kuni kitobning yarmi, 2-kuni qolganining yarmi o‘qildi. 30 bet qoldi.',bars:[{lab:'kitob',y:80,segs:[{w:2,txt:'1-kun',c:'a'},{w:1,txt:'2-kun',c:'b'},{w:1,txt:'30',c:'g'}]}],br:[{b:0,from:1,to:2,lab:'qolgani',up:true}],note:'Qolganining yarmi — 30'},
  {t:'1-kuni kitobning yarmi, 2-kuni qolganining yarmi o‘qildi. 30 bet qoldi.',bars:[{lab:'kitob',y:80,segs:[{w:2,txt:'60',c:'a'},{w:1,txt:'30',c:'b'},{w:1,txt:'30',c:'g'}]}],br:[{b:0,from:1,to:2,lab:'60',up:true},{b:0,lab:'120 bet',up:false,col:C.ok}],calc:['1) 30 · 2 = 60 (1-kundan keyin qolgan)','2) 60 · 2 = <b>120</b> bet']}],
 html:"<p>«Qolganining yarmi» — butun kitobning yarmi emas! Chizmada ko'ring.</p>",
 after:"<p>Kitob 4 ta teng bo'lakka bo'lindi: 1-kun — 2 bo'lak, 2-kun — 1, qoldi — 1. Demak, 30 · 4 = 120 ✓. Xato javob 60 — «qolganining» so'zi e'tiborsiz qoldirilgan.</p>",
 q:{t:"Bog'bon 1-kuni olmalarning yarmini, 2-kuni qolganining yarmini terdi. 25 kg qoldi. Jami necha kg olma bor edi?",opts:["100","50","75","125"],ok:0,why:"25 · 2 = 50; 50 · 2 = 100.",hint:"2-kuni terishdan oldin nechta qolgan edi?",full:"2-kundan oldin: 25 · 2 = 50. Hammasi: 50 · 2 = 100 kg. «50» — faqat bir qadam, «75» — 25 · 3 (bo'laklar noto'g'ri sanalgan)."},
 tn:"Bank misoli (2253-id). Varaqni ikki marta buklab, 4 bo'lakni ko'rsating."}),
w5st({h:"Tuzoq: «yarmi va yana 2 ta»",sum:"Yarmini va yana 2 tasini berdi, 10 ta qoldi: ikkinchi yarmi = 2 + 10 = 12 → hammasi 24.",a:"m07",
 frames:[{t:'Ona olmalarning yarmini va yana 2 tasini qo‘shniga berdi. 10 ta qoldi. Nechta olma bor edi?',bars:[{lab:'olma',y:80,segs:[{w:12,txt:'yarmi',c:'a'},{w:2,txt:'2',c:'b'},{w:10,txt:'10',c:'g'}]}],br:[{b:0,from:0,to:1,lab:'berdi',up:true}],note:'Javobni tanlang:'}],
 html:"<p>Bu — olimpiada turidagi masala. Chizmaga qarab tanlang:</p>",
 btns:w5pk(["22 ta","24 ta","16 ta"],1,{t:'Ikkinchi yarmi = 2 + 10',bars:[{lab:'olma',y:80,segs:[{w:12,txt:'12',c:'a'},{w:2,txt:'2',c:'b'},{w:10,txt:'10',c:'g'}]}],br:[{b:0,from:1,to:2,lab:'yarmi = 12',up:true},{b:0,lab:'24 ta',up:false,col:C.ok}],calc:['1) 10 + 2 = 12 (ikkinchi yarmi)','2) 12 · 2 = <b>24</b> ta']},["22 = 10 · 2 + 2 — tartib teskari: avval 2 ni qo‘shib, keyin 2 ga ko‘paytiring.","","16 = (10 − 2) · 2 — «berdi» ning teskarisi qo‘shish."]),
 after:"<p>Tekshiruv: 24 ning yarmi 12, yana 2 ta — 14 berildi; 24 − 14 = 10 ✓. Teskari tartib: avval «+ 2», keyin «· 2».</p>",
 q:{t:"Bola konfetlarining yarmini va yana 1 tasini ukasiga berdi. 6 ta qoldi. Nechta konfet bor edi?",opts:["14","13","10","12"],ok:0,why:"6 + 1 = 7; 7 · 2 = 14.",hint:"Ikkinchi yarmi — 1 va 6.",full:"Ikkinchi yarmi: 1 + 6 = 7. Hammasi: 7 · 2 = 14. Tekshiruv: 14 : 2 + 1 = 8 berildi, 14 − 8 = 6 ✓. «13» — 6 · 2 + 1, «10» — (6 − 1) · 2."},
 tn:"Bu tur xalqaro olimpiadalarda (Kenguru) ko'p uchraydi. Bolalar chizmani o'zi chizib, tushuntirsin."}),
w5st({h:"Bilasizmi? «Oxiridan» usulining tarixi",sum:"Qadimgi yunon olimi Pappus (IV asr) «tahlil» usulini tasvirlagan; Pólya uni «oxiridan ishlash» deb atagan.",a:"m08",
 frames:[{t:'Yechim yo‘li: javobdan — shartga',b:['shart','…','…','javob'],r:['←','←','←'],note:'Labirintni ham chiqish joyidan boshlab yechish osonroq!'}],
 html:"<p>📜 Qadimgi Iskandariyalik olim <b>Pappus</b> (IV asr) masalani «oxiridan boshlab» yechish usulini batafsil yozib qoldirgan. XX asrda vengriyalik matematik <b>Jorj Pólya</b> «Masalani qanday yechish kerak» kitobida bu usulni «<b>orqaga ishlash</b>» deb atadi.</p>",
 after:"<p>Siz bugun ming yillik usulni qo'lladingiz! Qog'ozdagi labirintni chiqish joyidan boshlab yechib ko'ring — ko'pincha tezroq topiladi.</p>",
 tn:"Bolalarga oddiy labirint chizib bering: bir guruh kirishdan, ikkinchisi chiqishdan boshlasin — kim tezroq?"}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w5ch({t:'Oxiridan boshlaymiz',b:['?','?','?','natija'],o:['+ a','· b','− c'],r:['− a',': b','+ c']})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Oxiri ma'lum, boshi noma'lum → <b>oxiridan</b> boshlang.</li><li><b>Oxirgi amal birinchi</b> bekor qilinadi.</li><li>Teskari amallar: <b>+ ↔ −</b>, <b>· ↔ :</b>.</li><li>Har bir oraliq sonni katakka yozib boring.</li><li>«Yarmi» bo'lsa — <b>chizma</b>: ikkala yarmi teng.</li><li>«Qolganining yarmi» — butunning yarmi emas!</li><li>Doim <b>oldinga</b> tekshiring.</li></ul></div>",
 tn:"Keyingi dars boshida «o'ylangan son» o'yini: o'qituvchi zanjir aytadi, bolalar sonni topadi."}
];
var PROBS=[
{t:"Javlon 26 ta marka qo'shdi, 15 tasini sovg'a qildi, 142 ta qoldi. Dastlab nechta edi?",o:["131","183","153","101"],k:0,s:"142 + 15 − 26 = 131."},
{t:"Nodira 12 ta konfet yedi, onasi 20 ta berdi, 45 ta bo'ldi. Dastlab nechta edi?",o:["37","77","53","13"],k:0,s:"45 − 20 + 12 = 37."},
{t:"O'ylangan son 6 ga ko'paytirildi, 48 ayirildi, 30 chiqdi. Qaysi son?",o:["13","3","8","18"],k:0,s:"(30 + 48) : 6 = 13."},
{t:"Son 4 ga bo'lindi, 17 qo'shildi, 25 chiqdi. Qaysi son?",o:["32","168","8","2"],k:0,s:"(25 − 17) · 4 = 32."},
{t:"? + 27 − 45 + 18 − 9 = 64. Boshlang'ich son?",o:["73","55","91","37"],k:0,s:"64 + 9 − 18 + 45 − 27 = 73."},
{t:"? − 30 + 14 − 8 = 50. Boshlang'ich son?",o:["74","26","102","66"],k:0,s:"50 + 8 − 14 + 30 = 74."},
{t:"Ombordan 120 kg va 85 kg olib ketildi, 60 kg keltirildi, 400 kg bo'ldi. Dastlab necha kg edi?",o:["545","255","665","425"],k:0,s:"400 − 60 + 85 + 120 = 545."},
{t:"Avtobusdan 8 kishi tushdi, 15 kishi chiqdi, keyin 6 kishi tushdi, 31 kishi qoldi. Dastlab nechta edi?",o:["30","60","32","22"],k:0,s:"31 + 6 − 15 + 8 = 30."},
{t:"Ali pulining yarmiga kitob, 5 ming so'mga qalam oldi, 15 ming qoldi. Dastlab qancha edi?",o:["40 ming","20 ming","25 ming","35 ming"],k:0,s:"(15 + 5) · 2 = 40."},
{t:"Dilnoza pulining yarmiga sharf, 3 mingga muzqaymoq oldi, 7 ming qoldi. Dastlab qancha edi?",o:["20 ming","10 ming","17 ming","14 ming"],k:0,s:"(7 + 3) · 2 = 20."},
{t:"1-kuni kitobning yarmi, 2-kuni qolganining yarmi o'qildi, 30 bet qoldi. Kitob necha bet?",o:["120","60","90","150"],k:0,s:"30 · 2 · 2 = 120."},
{t:"Bog'bon 1-kuni olmalarning yarmini, 2-kuni qolganining yarmini terdi, 25 kg qoldi. Jami necha kg?",o:["100","50","75","125"],k:0,s:"25 · 4 = 100."},
{t:"Ona olmalarning yarmini va yana 2 tasini berdi, 10 ta qoldi. Nechta olma bor edi?",o:["24","22","16","12"],k:0,s:"(10 + 2) · 2 = 24."},
{t:"Bola konfetlarining yarmini va yana 1 tasini berdi, 6 ta qoldi. Nechta edi?",o:["14","13","10","12"],k:0,s:"(6 + 1) · 2 = 14."},
{t:"O'ylangan songa 15 qo'shildi, natija 3 ga ko'paytirildi va 81 chiqdi. Qaysi son?",o:["12","42","22","18"],k:0,s:"81 : 3 = 27; 27 − 15 = 12."},
{t:"Son 5 ga ko'paytirildi, 35 qo'shildi, 2 ga bo'lindi va 50 chiqdi. Qaysi son?",o:["13","27","3","65"],k:0,s:"50 · 2 = 100; 100 − 35 = 65; 65 : 5 = 13."},
{t:"Savatdan avval 18 ta olma olindi, keyin qolganining yarmi olindi, 14 ta qoldi. Savatda nechta olma bor edi?",o:["46","32","25","64"],k:0,s:"14 · 2 = 28; 28 + 18 = 46."},
{t:"Aziz 3 ming so'mga daftar oldi, qolgan pulining yarmiga ruchka oldi, 4 ming qoldi. Dastlab qancha edi?",o:["11 ming","14 ming","10 ming","7 ming"],k:0,s:"4 · 2 = 8; 8 + 3 = 11."},
{t:"Ota yoshini 2 ga bo'lsa va 5 ni ayirsa, o'g'lining yoshi 15 chiqadi. Ota necha yoshda?",o:["40","20","25","35"],k:0,s:"(15 + 5) · 2 = 40."},
{t:"Qushlar daraxtga qo'ndi. 7 tasi uchib ketdi, keyin 3 baravar ko'payib, 24 ta bo'ldi. Dastlab nechta qush bor edi?",o:["15","8","31","1"],k:0,s:"24 : 3 = 8; 8 + 7 = 15."}
];
function PRACT_STAGE(){w5ch({t:'Oxiridan boshlab yeching',b:['?','?','?','natija'],o:['amal','amal','amal'],r:['teskari','teskari','teskari']})}
var PREP_DATA={teach:["Oxiridan boshlab yechish (strelkali zanjir).","Teskari amallar: + ↔ −, · ↔ :; oxirgi amal birinchi bekor qilinadi.","«Yarmi», «qolganining yarmi», «yarmi va yana n ta» — chizma bilan.","Oldinga yurib tekshirish."],
 mist:["Amallarni teskarisiga almashtirmaydi.","Zanjirni chapdan boshlaydi.","«Qolganining yarmi» ni butunning yarmi deb oladi.","«Yarmi va yana 2» da tartibni buzadi: 10 · 2 + 2."],
 need:["Strelkali zanjir chizilgan doska (ko'k va to'q sariq bo'r).","Qog'oz tasmalar (buklab yarmini ko'rsatish uchun)."],
 board:["<span class='w2'>? +26 → ? −15 → 142</span>; orqaga: <span class='w2'>142 + 15 − 26 = 131</span>.","<span class='w2'>(30 + 48) : 6 = 13</span>.","<span class='w2'>400 − 60 + 85 + 120 = 545</span>.","<span class='w2'>(15 + 5) · 2 = 40</span>; <span class='w2'>30 · 2 · 2 = 120</span>.","<span class='w2'>(10 + 2) · 2 = 24</span>."]};
