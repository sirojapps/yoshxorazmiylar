var CODE='3C11',TITLE='3-sinf · 2, 5, 10 ga bo‘linish, karrali sonlar';
var P1=[function(){W3grid(null,{n:50});W3msg('1 dan 50 gacha sonlar')},
 function(){W3grid(function(n){return n%2?null:'#b9e3c6'},{n:50});W3msg('2 ga bo‘linadiganlar — <b>juft</b> sonlar. Ular qaysi ustunlarda?')},
 function(){W3grid(function(n){return n%2?null:'#b9e3c6'},{n:50});W3msg('Oxirgi raqami <b>0, 2, 4, 6, 8</b> bo‘lgan son 2 ga bo‘linadi','Qolganlari — toq: 1, 3, 5, 7, 9')}];
var P2=[function(){W3grid(function(n){return n%5?null:'#fde6c8'},{n:50});W3msg('5 ga bo‘linadiganlar — faqat ikki ustun!')},
 function(){W3grid(function(n){return n%10?(n%5?null:'#fde6c8'):'#f2b880'},{n:50});W3msg('Oxiri <b>0 yoki 5</b> — 5 ga bo‘linadi. Oxiri <b>0</b> — 10 ga ham bo‘linadi','To‘q rang — 10 ga bo‘linadiganlar')}];
var P4=[function(){W3grid(null,{n:60});W3msg('6 ning karralilarini topamiz: 6 dan sakrab boramiz')},
 function(){W3grid(function(n){return n%6?null:'#cfe3f7'},{n:60});W3msg('6, 12, 18, 24, 30, 36, 42, 48, 54, 60 — <b>6 ga karrali</b> sonlar')},
 function(){W3grid(function(n){return n%6?null:'#cfe3f7'},{n:60});W3msg('Karrali son = 6 ga <b>qoldiqsiz</b> bo‘linadi = 6 · (natural son)','Eng kichik karralisi — sonning o‘zi; eng kattasi yo‘q')}];
var P8=[function(){W3grid(function(n){return n%4?null:'#cfe3f7'},{n:40});W3msg('4 ga karralilar: 4, 8, 12, 16, 20, 24…')},
 function(){W3grid(function(n){return n%4==0&&n%6==0?'#f2b880':n%4==0?'#cfe3f7':n%6==0?'#fde6c8':null},{n:40});W3msg('6 ga karralilar ham: 6, 12, 18, 24… To‘q rang — <b>ikkalasiga</b> karrali')},
 function(){W3grid(function(n){return n%4==0&&n%6==0?'#f2b880':null},{n:40});W3msg('4 va 6 ning umumiy karralilari: <b>12</b>, 24, 36… Eng kichigi — <b>12</b> (24 emas!)')}];
function c11sort(n){var t=[];if(n%2==0)t.push('2');if(n%5==0)t.push('5');if(n%10==0)t.push('10');W3eq([String(n),t.length?'[: '+t.join(', ')+']':'hech biriga'],{fs:28});W3msg(t.length?n+' — '+t.join(', ')+' ga bo‘linadi':n+' — 2, 5, 10 ga bo‘linmaydi (oxiri '+(n%10)+')')}
var STEPS=[
{h:"2 ga bo'linish: juft sonlar",sum:"Oxirgi raqami 0, 2, 4, 6, 8 bo'lgan son 2 ga bo'linadi (juft).",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Sonlar jadvalida 2 ga bo'linadiganlarni bo'yaymiz.</p>",btns:[phaser(P1)],
 after:"<p>Faqat <b>oxirgi raqamga</b> qarash kifoya — son qancha katta bo'lmasin: 3 578 — juft (oxiri 8), 4 001 — toq.</p>",
 q:{t:"Qaysi son 2 ga bo'linadi?",opts:["5 274","3 427","8 001","6 665"],ok:0,why:"Oxiri 4 — juft.",hint:"Faqat oxirgi raqamga qarang.",full:"5 274 oxiri 4 — juft. 3 427 boshida 4 bo'lsa ham oxiri 7 — toq. Birinchi raqam ahamiyatsiz."},
 tn:"Sinf o'yini: o'qituvchi son aytadi — juft bo'lsa o'rnidan turadi, toq bo'lsa o'tiradi."},
{h:"5 va 10 ga bo'linish",sum:"Oxiri 0 yoki 5 — 5 ga bo'linadi; oxiri 0 — 10 ga bo'linadi.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>Endi 5 ga va 10 ga bo'linadiganlarni ko'ramiz.</p>",btns:[phaser(P2)],
 after:"<p><b>5 ga:</b> oxiri 0 yoki 5. <b>10 ga:</b> oxiri 0. 10 ga bo'linadigan har bir son 2 ga ham, 5 ga ham bo'linadi.</p>",
 q:{t:"Qaysi son 5 ga bo'linadi, lekin 10 ga bo'linmaydi?",opts:["735","730","753","700"],ok:0,why:"Oxiri 5.",hint:"Oxiri 5 bo'lishi kerak.",full:"735 oxiri 5 — 5 ga bo'linadi, 10 ga emas. 730 va 700 — ikkalasiga bo'linadi, 753 — hech biriga."},
 tn:"Pul bilan: 5 so'mlik va 10 so'mlik tangalar bilan qaysi summani to'liq yig'ish mumkin?"},
{h:"Saralash",sum:"340 — 2, 5, 10 ga; 275 — 5 ga; 618 — 2 ga; 143 — hech biriga.",a:"m03",start:function(){W3eq(['Sonni tanlang']);W3msg('Har sonni bosing: qaysi sonlarga bo‘linadi?')},fin:function(){W3eq(['340 → 2, 5, 10','275 → 5','618 → 2','143 → —'],{fs:20})},
 html:"<p>Har bir sonni bosib, 2, 5, 10 dan qaysilariga bo'linishini toping.</p>",
 btns:[["340",function(c,done){c11sort(340);mvK(done,4)}],["275",function(c,done){c11sort(275);mvK(done,4)}],["618",function(c,done){c11sort(618);mvK(done,4)}],["143",function(c,done){c11sort(143);mvK(done,4)}]],g2:1,
 after:"<p>Bitta son bir nechta songa bo'linishi mumkin (340), yoki hech biriga (143).</p>",
 q:{t:"Qaysi son 2 ga ham, 5 ga ham bo'linadi?",opts:["460","465","462","456"],ok:0,why:"Oxiri 0.",hint:"2 ga — juft, 5 ga — 0 yoki 5. Ikkalasi bir vaqtda?",full:"Juft va oxiri 0 yoki 5 bo'lishi uchun oxiri faqat 0 bo'ladi: 460. 465 — toq, 462 va 456 — 5 ga bo'linmaydi."},
 tn:"Doskada uch ustunli jadval chizing (:2, :5, :10) — bolalar sonlarni kerakli ustunlarga yozsin."},
{h:"Karrali sonlar",sum:"6 ga karrali: 6, 12, 18, … — 6 ga qoldiqsiz bo'linadigan sonlar.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p><b>Karrali son</b> — berilgan songa qoldiqsiz bo'linadigan son.</p>",btns:[phaser(P4)],
 after:"<p>6 ning karralilari — 6 ga ko'paytirish jadvalidagi javoblar: 6·1, 6·2, 6·3… Karralilar <b>cheksiz</b> ko'p.</p>",
 q:{t:"Qaysi son 7 ga karrali emas?",opts:["47","49","56","63"],ok:0,why:"47 : 7 = 6 (qoldiq 5).",hint:"7 ga ko'paytirish jadvalini eslang.",full:"49 = 7·7, 56 = 7·8, 63 = 7·9. 47 jadvalda yo'q: 47 = 7·6 + 5."},
 tn:"Son o'qida 6 dan sakrab yurish (Gollandiya usuli) — karralilarni ko'rinadigan qiladi."},
{h:"Karrali va bo'luvchi",sum:"24 — 6 ga karrali; 6 — 24 ning bo'luvchisi. Karrali ≥ son, bo'luvchi ≤ son.",a:"m05",start:function(){W3eq(['6 · 4 = 24']);W3msg('Qaysi so‘z qaysi songa tegishli?')},fin:function(){W3eq(['6 · 4 = 24','24 — 6 ga [karrali]','6 — 24 ning [bo‘luvchisi]'],{fs:20})},
 html:"<p>6 · 4 = 24. Har birini bosing:</p>",
 btns:[["24 — 6 ga …",function(c,done){W3eq(['6 · 4 = 24','24 — 6 ga [karrali]'],{fs:22});W3msg('24 ni 6 ga bo‘lsak, qoldiq 0. Karrali — <b>kattaroq</b> (yoki teng)');mvK(done,2)}],["6 — 24 ning …",function(c,done){W3eq(['6 · 4 = 24','6 — 24 ning [bo‘luvchisi]'],{fs:22});W3msg('24 ning bo‘luvchilari: 1, 2, 3, 4, 6, 8, 12, 24 — ular <b>kichikroq</b> (yoki teng)');mvK(done,2)}]],g2:1,
 after:"<p>«a son b ga karrali» = «b son a ning bo'luvchisi». Har sonning bo'luvchilari <b>sanoqli</b>, karralilari esa <b>cheksiz</b>.</p>",
 q:{t:"12 ning bo'luvchilari nechta?",opts:["6","4","12","5"],ok:0,why:"1, 2, 3, 4, 6, 12.",hint:"Juftlab toping: 1·12, 2·6, 3·4.",full:"1·12, 2·6, 3·4 → 1, 2, 3, 4, 6, 12 — 6 ta. Ko'pincha 1 va 12 ning o'zini unutishadi (4 ta)."},
 tn:"Bo'luvchilarni «juftlar» bilan topish: 12 ta tugmani to'g'ri to'rtburchak shaklida necha xil terish mumkin?"},
{h:"Tuzoq: raqamlardan son tuzish",sum:"3, 5, 0 dan 5 ga bo'linadigan eng katta uch xonali son — 530.",a:"m06",start:function(){W3eq(['3   5   0']);W3msg('Har raqam bir marta. 5 ga bo‘linadigan <b>eng katta</b> son?')},fin:function(){W3eq(['3   5   0','[530]'])},
 html:"<p>3, 5, 0 raqamlaridan (har biri bir marta) <b>5 ga bo'linadigan eng katta</b> uch xonali son tuzing.</p>",
 btns:[["530",function(c,done){W3eq(['3   5   0','[530]']);W3msg('To‘g‘ri: oxiri 0 — 5 ga bo‘linadi, qolgan 5 va 3 ni kamayish tartibida');done()}],["503",function(){W3eq(['503']);W3msg('Oxiri 3 — 5 ga bo‘linmaydi','Qayta tanlang')}],["350",function(){W3eq(['350']);W3msg('5 ga bo‘linadi, lekin eng kattasi emas','Qayta tanlang')}],["305",function(){W3eq(['305']);W3msg('5 ga bo‘linadi, lekin 530 dan kichik','Qayta tanlang')}]],g2:1,
 after:"<p>Avval <b>oxirgi raqamni</b> shartga moslab qo'yamiz (0 yoki 5), keyin qolganlarini <b>eng katta</b> qilib teramiz. 0 ni boshga qo'yib bo'lmaydi.</p>",
 q:{t:"4, 7, 5 raqamlaridan 2 ga bo'linadigan eng katta son?",opts:["754","574","745","475"],ok:0,why:"Oxiri 4, qolganlari 7, 5.",hint:"Juft raqam faqat bitta — u oxirga.",full:"Faqat 4 juft — u oxirda. Qolgan 7 va 5 dan kattasini boshiga: 754. 745 — toq."},
 tn:"Raqam kartochkalarini bolalar o'zi tersin; sinfda kim eng katta son tuzadi — musobaqa."},
{h:"Tuzoq: nechta son bo'linadi?",sum:"Qator: 5, 10, 15, … 100 — 20 ta son 5 ga bo'linadi (100 : 5).",a:"m07",start:function(){W3grid(function(n){return n%5?null:'#fde6c8'},{n:100});W3msg('1 dan 100 gacha nechta son 5 ga bo‘linadi?')},fin:function(){W3grid(function(n){return n%5?null:'#fde6c8'},{n:100});W3msg('Har 10 ta sonda — 2 ta (…0 va …5). 100 da: 10 · 2 = <b>20</b>')},
 html:"<p>1 dan 100 gacha <b>nechta</b> son 5 ga bo'linadi? Sanamasdan toping!</p>",
 btns:[["20",function(c,done){W3grid(function(n){return n%5?null:'#fde6c8'},{n:100});W3msg('To‘g‘ri: 100 : 5 = <b>20</b>. Har qatorda 2 ta, 10 qator');done()}],["10",function(){W3msg('Bu 10 ga bo‘linadiganlar soni. 5, 15, 25… ham bor','Qayta tanlang')}],["50",function(){W3msg('Bu juft sonlar soni','Qayta tanlang')}]],g3:1,
 after:"<p>1 dan N gacha k ga bo'linadiganlar soni — <b>N : k</b> (qoldig'i tashlanadi). 1–100: 2 ga — 50 ta, 5 ga — 20 ta, 10 ga — 10 ta.</p>",
 q:{t:"1 dan 60 gacha nechta son 5 ga bo'linadi?",opts:["12","6","30","11"],ok:0,why:"60 : 5 = 12.",hint:"60 ni 5 ga bo'ling.",full:"5, 10, …, 60 — bu 60 : 5 = 12 ta. «6» — 10 ga bo'linadiganlar, «30» — juftlar."},
 tn:"Bolalar jadvalda bo'yalgan kataklarni ustun bo'yicha sanab, formulani o'zi kashf etsin."},
{h:"Umumiy karrali",sum:"4 va 6 ning umumiy karralilari: 12, 24, 36…; eng kichigi 12.",a:"m08",start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Qaysi sonlar ham 4 ga, ham 6 ga karrali?</p>",btns:[phaser(P8)],
 after:"<p>Umumiy karralini topish: kattaroq sonning karralilarini yozib (6, 12, 18…), kichigiga bo'linadiganini qidiramiz. <b>4 · 6 = 24</b> ham umumiy karrali, lekin eng kichigi emas!</p>",
 q:{t:"Avtobus har 4 daqiqada, tramvay har 6 daqiqada keladi. Hozir ikkalasi keldi. Yana necha daqiqadan keyin birga keladi?",opts:["12","24","10","2"],ok:0,why:"4 va 6 ning eng kichik umumiy karralisi — 12.",hint:"4, 8, 12… va 6, 12… — birinchi uchrashuv?",full:"Avtobus: 4, 8, 12; tramvay: 6, 12. Birinchi umumiy — 12. «24» — 4 · 6, umumiy, lekin eng kichigi emas. «10» — 4 + 6."},
 tn:"Ikki bola son o'qida bir vaqtda sakraydi: biri 4 dan, biri 6 dan — qayerda uchrashishadi?"},
{h:"Bilasizmi? Eratosfen elagi",sum:"Miloddan avvalgi III asrda Eratosfen karralilarni o'chirib, tub sonlarni topish usulini o'ylab topgan.",a:"m09",start:function(){W3grid(function(n){var p=n>1;for(var d=2;d*d<=n;d++)if(n%d==0)p=false;return p?'#f2b880':null},{n:50});W3msg('Bo‘yalganlar — faqat 1 va o‘ziga bo‘linadigan sonlar')},fin:function(){STEPS[8].start()},
 html:"<p>🏛 Qadimgi yunon olimi <b>Eratosfen</b> (miloddan avvalgi III asr) sonlar jadvalidan 2 ning, 3 ning, 5 ning… karralilarini o'chirib chiqqan. Qolgan sonlar — <b>tub sonlar</b>: 2, 3, 5, 7, 11, 13… Ular faqat 1 ga va o'ziga bo'linadi. Bu usul «Eratosfen elagi» deb ataladi.</p>",
 tn:"Sinfda 1–50 jadvalida rangli qalam bilan «elak» o'tkazing — har rang bitta sonning karralilari."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3grid(function(n){return n%10?(n%5?(n%2?null:'#b9e3c6'):'#fde6c8'):'#f2b880'},{n:30});W3msg('Yashil — 2 ga, och sariq — 5 ga, to‘q — 10 ga (va 2, 5 ga)')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>2 ga:</b> oxiri 0, 2, 4, 6, 8 (juft).</li><li><b>5 ga:</b> oxiri 0 yoki 5. <b>10 ga:</b> oxiri 0.</li><li>2 ga ham, 5 ga ham bo'linsa — 10 ga bo'linadi (oxiri 0).</li><li><b>Karrali</b> — qoldiqsiz bo'linadigan son: 6 ga karralilar 6, 12, 18… (cheksiz).</li><li>24 — 6 ga karrali, 6 — 24 ning bo'luvchisi.</li><li>Eng kichik umumiy karrali: 4 va 6 → 12 (24 emas).</li></ul></div>",
 tn:"4-sinfda 3 va 9 ga bo'linish alomatlari o'rganiladi — bugungi qoidalar poydevor."}
];
var PROBS=[
{t:"Qaysi son juft?",o:["3 576","5 763","6 357","7 635"],k:0,s:"Oxiri 6."},
{t:"Qaysi son 5 ga bo'linadi?",o:["4 085","5 408","8 054","4 508"],k:0,s:"Oxiri 5."},
{t:"Qaysi son 10 ga bo'linadi?",o:["7 090","7 009","7 095","9 007"],k:0,s:"Oxiri 0."},
{t:"Qaysi son 5 ga bo'linadi, lekin 2 ga bo'linmaydi?",o:["345","340","344","342"],k:0,s:"Oxiri 5 — toq."},
{t:"Qaysi son 2 ga bo'linadi, lekin 5 ga bo'linmaydi?",o:["258","250","255","205"],k:0,s:"Juft, oxiri 0 emas."},
{t:"8 ga karrali sonni toping.",o:["56","44","60","38"],k:0,s:"8 · 7 = 56."},
{t:"9 ning karralisi emas:",o:["64","54","72","81"],k:0,s:"64 = 9·7 + 1."},
{t:"9 ning eng kichik karralisi?",o:["9","1","18","0"],k:0,s:"9 · 1 = 9."},
{t:"18 ning bo'luvchilari nechta?",o:["6","4","5","18"],k:0,s:"1, 2, 3, 6, 9, 18."},
{t:"20 dan 40 gacha (ikkalasi ham kiradi) 5 ga bo'linadigan sonlar nechta?",o:["5","4","20","8"],k:0,s:"20, 25, 30, 35, 40."},
{t:"1 dan 80 gacha 10 ga bo'linadigan sonlar nechta?",o:["8","10","16","80"],k:0,s:"80 : 10 = 8."},
{t:"2, 7, 0 raqamlaridan (bir martadan) 10 ga bo'linadigan eng katta son?",o:["720","702","270","207"],k:0,s:"Oxiri 0, keyin 7 va 2."},
{t:"1, 5, 8 raqamlaridan 5 ga bo'linadigan eng kichik son?",o:["185","815","158","518"],k:0,s:"Oxiri 5, boshida kichigi: 185."},
{t:"3 va 4 ning eng kichik umumiy karralisi?",o:["12","7","24","1"],k:0,s:"3, 6, 9, 12 — 12 = 4 · 3."},
{t:"6 va 9 ning eng kichik umumiy karralisi?",o:["18","54","15","3"],k:0,s:"9, 18 — 18 : 6 = 3."},
{t:"Konfetlarni 5 tadan ham, 2 tadan ham qoldiqsiz bo'lish mumkin. 30 dan ko'p, 50 dan kam. Nechta konfet?",o:["40","35","45","42"],k:0,s:"10 ga bo'linadi va 30 < □ < 50 → 40."},
{t:"34□ soni 5 ga bo'linadi va juft. □ = ?",o:["0","5","2","4"],k:0,s:"Oxiri 0 yoki 5 va juft → 0."},
{t:"27□ soni 2 ga bo'linadi. □ uchun nechta raqam mos?",o:["5","4","2","10"],k:0,s:"0, 2, 4, 6, 8."},
{t:"Bolalarni 2 tadan ham, 5 tadan ham qatorga tizsa, hech kim ortmaydi. Bolalar 25 dan ko'p, 35 dan kam. Nechta?",o:["30","25","32","35"],k:0,s:"10 ga karrali: 30."},
{t:"Qaysi tasdiq to'g'ri?",o:["10 ga bo'linadigan son 5 ga ham bo'linadi","5 ga bo'linadigan son 10 ga ham bo'linadi","Juft son 5 ga bo'linmaydi","Toq son 5 ga bo'linmaydi"],k:0,s:"10 = 2 · 5. 15 — 5 ga, 10 ga emas; 10 — juft va 5 ga; 15 — toq va 5 ga."}
];
function PRACT_STAGE(){W3grid(function(n){return n%10?(n%5?(n%2?null:'#b9e3c6'):'#fde6c8'):'#f2b880'},{n:30})}
var PREP_DATA={teach:["2, 5, 10 ga bo'linish alomatlari (oxirgi raqam).","Juft va toq sonlar.","Karrali son va bo'luvchi tushunchalari.","Eng kichik umumiy karrali (hayotiy masala)."],
 mist:["Birinchi raqamga qarab juftlikni aniqlaydi.","5 ga bo'linsa 10 ga ham bo'linadi deb o'ylaydi.","Umumiy karrali deb doim a · b ni oladi (4 va 6 → 24).","Bo'luvchilarda 1 va sonning o'zini unutadi."],
 need:["1–100 sonlar jadvali (har bolaga), rangli qalamlar.","Raqam kartochkalari."],
 board:["<span class='w2'>:2 — 0,2,4,6,8</span>","<span class='w2'>:5 — 0,5</span>, <span class='w2'>:10 — 0</span>","<span class='w2'>6 ga karrali: 6, 12, 18…</span>","<span class='w2'>4 va 6 → 12</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
