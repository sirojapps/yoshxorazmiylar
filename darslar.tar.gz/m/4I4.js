// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4I4',TITLE='4-sinf · Chastota';
var I4G=[5,4,5,3,4,5,5,4,2,5,4,5,3,5,4,5,4,3,5,5];
function i4tally(x,y,n,col,z){var g=S.g;z=z||1;col=col||'#1d2b3a';for(var k=0;k<n;k++){var grp=Math.floor(k/5),r=k%5,gx=x+grp*30*z;if(r<4)E('line',{x1:gx+r*6*z,y1:y,x2:gx+r*6*z,y2:y+16*z,stroke:col,'stroke-width':2*z},g);else E('line',{x1:gx-3*z,y1:y+14*z,x2:gx+22*z,y2:y+2*z,stroke:col,'stroke-width':2*z},g)}}
function i4grades(st){clear();y4title('20 o‘quvchining nazorat ishi baholari');var g=S.g;
 I4G.forEach(function(v,i){var x=20+(i%10)*18,y=34+Math.floor(i/10)*22,on=st>=1;y4T(g,x,y+12,String(v),{'font-size':13,'font-weight':800,fill:on?'#9aa6b2':'#1d2b3a'})});
 E('line',{x1:200,y1:28,x2:200,y2:166,stroke:'#dde5ee'},g);
 if(st>=1){var R=[[5,10],[4,6],[3,3],[2,1]];y4T(g,214,40,'baho',{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});y4T(g,320,40,'chastota',{'font-size':10,fill:'#3a4a5a'});
  R.forEach(function(r,i){var y=50+i*26;y4T(g,222,y+13,String(r[0]),{'font-size':13,'font-weight':800});i4tally(238,y,r[1],C.a2);if(st>=2)y4T(g,330,y+13,String(r[1]),{'font-size':14,'font-weight':800,fill:C.ok})});
  if(st>=2)y4T(g,280,164,'jami: 10 + 6 + 3 + 1 = 20 ✓',{'font-size':11,'font-weight':800,fill:C.ok})}
 if(st===0){y4T(g,100,96,'Bu ro‘yxatdan nimani tez',{'font-size':11,fill:'#3a4a5a'});y4T(g,100,112,'bilib olish mumkin?',{'font-size':11,fill:'#3a4a5a'})}}
var I4P1=[function(){i4grades(0);calc(['Baholar tartibsiz yozilgan — sanash qiyin'])},function(){i4grades(1);calc(['Har bahoni ko‘rib, o‘z qatoriga <b>cho‘p</b> qo‘yamiz. 5-cho‘p — qiya chiziq (beshlik)'])},function(){i4grades(2);calc(['Cho‘plar soni — <b>chastota</b>: shu qiymat necha marta uchragani','Tekshirish: chastotalar yig‘indisi = kuzatishlar soni (20)'])}];
function i4t13(sh){clear();y4title('Bekatdan bir soatda o‘tgan avtobuslar');i4tally(70,50,13,C.a2,2.2);if(sh)y4T(S.g,180,150,'5 + 5 + 3 = 13',{'font-size':16,'font-weight':800,fill:C.ok})}
function i4season(sh){clear();y4title('30 bola: sevimli fasl');var g=S.g,R=[['bahor',7],['yoz',sh?12:'?'],['kuz',5],['qish',6]];
 E('rect',{x:70,y:30,width:220,height:126,rx:6,fill:'#fff',stroke:'#c9d3dd'},g);y4T(g,130,48,'fasl',{'font-size':11,'font-weight':800,fill:'#3a4a5a'});y4T(g,240,48,'chastota',{'font-size':11,'font-weight':800,fill:'#3a4a5a'});
 R.forEach(function(r,i){var y=70+i*20;y4T(g,130,y,r[0],{'font-size':12});y4T(g,240,y,String(r[1]),{'font-size':13,'font-weight':800,fill:r[1]==='?'?C.bad:(sh&&i===1?C.ok:'#1d2b3a')})});
 E('line',{x1:80,y1:136,x2:280,y2:136,stroke:'#33475b'},g);y4T(g,130,151,'jami',{'font-size':12,'font-weight':800});y4T(g,240,151,'30',{'font-size':13,'font-weight':800})}
function i4shoe(sh){clear();y4title('Bir haftada sotilgan krossovkalar o‘lchami');y4bars({x0:44,x1:340,yb:146,yt:36,min:0,max:10,step:2,n:4,labels:['33','34','35','36'],unit:'juft'},[4,9,6,2],[C.b,sh?C.ok:C.b,C.b,C.b],true);y4T(S.g,192,168,'o‘lcham',{'font-size':10,fill:'#3a4a5a'})}
function i4dice(st){clear();y4title('Kub 40 marta tashlandi — «6» necha marta?');var g=S.g;for(var i=0;i<40;i++){var r=Math.floor(i/10),c=i%10,six=[3,7,12,18,21,27,33,38].indexOf(i)>=0;E('rect',{x:20+c*22,y:34+r*24,width:18,height:18,rx:3,fill:st>=1&&six?C.a:'#fff',stroke:'#8a99a8'},g);if(st>=1&&six)y4T(g,29+c*22,47+r*24,'6',{'font-size':11,'font-weight':800,fill:'#fff'})}
 if(st>=1)y4T(g,300,70,'«6»: 8 marta',{'font-size':13,'font-weight':800,fill:C.a2});if(st>=2){y4T(g,300,100,'8 / 40',{'font-size':15,'font-weight':800});y4T(g,300,140,'= 1/5',{'font-size':16,'font-weight':800,fill:C.ok})}}
var I4P5=[function(){i4dice(0);calc(['Har katak — bitta tashlash'])},function(){i4dice(1);calc(['«6» chiqqanlarini bo‘yaymiz: 8 ta'])},function(){i4dice(2);calc(['Ulush: 8 ta 40 tadan → 8/40 = <b>1/5</b> (har 5 tashlashdan 1 tasi)','40 : 8 = 5 — demak beshdan biri'])}];
var I4H=[128,135,141,132,129,138,145,130,136,140,127,133];
function i4height(st){clear();y4title('12 bolaning bo‘yi (sm)');var g=S.g;
 I4H.forEach(function(v,i){var grp=v<130?0:v<140?1:2,col=st>=1?[C.a,C.b,C.ok][grp]:'#1d2b3a';y4T(g,24+(i%6)*30,44+Math.floor(i/6)*20,String(v),{'font-size':12,'font-weight':800,fill:col})});
 if(st>=1){[['120–129',3,C.a],['130–139',6,C.b],['140–149',3,C.ok]].forEach(function(r,i){y4T(g,30,104+i*22,r[0],{'font-size':11,'font-weight':800,fill:r[2],'text-anchor':'start'});if(st>=2)y4T(g,120,104+i*22,'→ '+r[1],{'font-size':12,'font-weight':800,fill:r[2],'text-anchor':'start'})})}
 if(st>=3){var A=y4axes({x0:214,x1:346,yb:150,yt:40,min:0,max:6,step:2,n:3,labels:['120','130','140']});[3,6,3].forEach(function(v,i){var w=(346-214)/3;E('rect',{x:214+i*w,y:A.Y(v),width:w,height:150-A.Y(v),fill:[C.a,C.b,C.ok][i],stroke:'#fff'},g)})}}
var I4P6=[function(){i4height(0);calc(['Har bo‘y deyarli bir martadan — oddiy chastota foydasiz'])},function(){i4height(1);calc(['Bo‘ylarni <b>oraliq</b>larga (guruhlarga) ajratamiz: 120–129, 130–139, 140–149','<b>130</b> va <b>140</b> qayerga? Har biri o‘z oralig‘ining boshi!'])},function(){i4height(2);calc(['Guruh chastotalari: 3, 6, 3 → jami 12 ✓'])},function(){i4height(3);calc(['Ustunlar yopishgan diagramma — <b>gistogramma</b>'])}];
function i4box(sh){clear();y4title('10 ta qutidagi olmalar');var g=S.g,R=[[6,7],[4,1],[2,2]];
 E('rect',{x:30,y:30,width:180,height:108,rx:6,fill:'#fff',stroke:'#c9d3dd'},g);y4T(g,80,48,'qutida',{'font-size':11,'font-weight':800,fill:'#3a4a5a'});y4T(g,160,48,'nechta quti',{'font-size':11,'font-weight':800,fill:'#3a4a5a'});
 R.forEach(function(r,i){var y=72+i*22;y4T(g,80,y,r[0]+' ta olma',{'font-size':12});y4T(g,160,y,String(r[1]),{'font-size':13,'font-weight':800});if(sh)y4T(g,232,y,r[0]+' · '+r[1]+' = '+r[0]*r[1],{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'start'})});
 if(sh){y4T(g,280,140,'jami: 50 olma',{'font-size':12,'font-weight':800,fill:C.blue});y4T(g,180,164,'50 : 10 = 5',{'font-size':15,'font-weight':800,fill:C.ok})}}
function i4fam(sh){clear();y4title('20 oila: oilada nechta bola bor?');y4bars({x0:44,x1:340,yb:142,yt:42,min:0,max:8,step:2,n:4,labels:['1 bola','2 bola','3 bola','4 bola'],unit:'oila'},[5,8,4,3],[C.b,C.b,C.b,C.b],true);
 if(sh)y4T(S.g,192,166,'5·1 + 8·2 + 4·3 + 3·4 = 5 + 16 + 12 + 12 = 45',{'font-size':11,'font-weight':800,fill:C.ok})}
function i4sei(st){clear();y4title('Yaponiya va Xitoyda sanash belgisi');var g=S.g,S5=[['M150 50 L210 50'],['M180 50 L180 140'],['M180 95 L210 95'],['M150 85 L150 140'],['M130 140 L230 140']];
 for(var i=0;i<=Math.min(st*2+1,4);i++)E('path',{d:S5[i][0],stroke:C.a2,'stroke-width':7,'stroke-linecap':'round',fill:'none'},g);
 y4T(g,290,90,(Math.min(st*2+2,5))+' ta chiziq',{'font-size':13,'font-weight':800});if(st>=2)y4T(g,290,114,'正 = 5',{'font-size':16,'font-weight':800,fill:C.ok})}
var I4P9=[function(){i4sei(0);calc(['Biz beshlikni 4 ta tik va 1 ta qiya chiziq bilan yozamiz'])},function(){i4sei(1);calc(['Yaponlar «正» belgisini chiziqma-chiziq yozadi…'])},function(){i4sei(2);calc(['…u ham <b>5 ta</b> chiziqdan iborat! 正正正 = 15'])}];
function PRACT_STAGE(){clear();y4title('Chastota = necha marta uchragani');i4tally(40,56,7,C.a2,1.6);y4T(S.g,150,78,'= 7',{'font-size':15,'font-weight':800,fill:C.ok});
 y4T(S.g,180,120,'chastotalar yig‘indisi = jami kuzatishlar',{'font-size':12,'font-weight':800,fill:C.blue});calc(['Avval jadval tuzing — keyin hisoblang'])}
var STEPS=[
{h:"Chastota va cho'p belgilar",sum:"Chastota — qiymat necha marta uchragani. Cho'p belgilar beshlab guruhlanadi. Chastotalar yig'indisi = kuzatishlar soni.",a:"m01",
 start:function(){startPh(I4P1)},fin:function(){S.ph=2;I4P1[2]()},
 html:"<p>Sinfda 20 bolaning nazorat ishi baholari yozilgan. Qaysi baho ko'p? Sanash uchun <b>chastota jadvali</b> tuzamiz. Bosing:</p>",btns:[phaser(I4P1)],
 after:"<p>Qiymat necha marta uchragani — uning <b>chastota</b>si. Cho'p belgilar beshlikka guruhlanadi — sanash oson va adashmaysiz. Oxirida albatta tekshiring: chastotalar yig'indisi = jami kuzatishlar soni.</p>",
 q:{t:"Jadval bo'yicha: eng ko'p uchragan baho qaysi va uning chastotasi nechaga teng?",opts:["5 baho, 10 marta","10 baho, 5 marta","4 baho, 6 marta","5 baho, 5 marta"],ok:0,why:"«5» qatorida 10 ta cho'p — eng ko'p.",hint:"Eng uzun cho'p qatorini toping.",full:"«5» bahosi 10 marta uchragan — bu eng katta chastota. «10 baho» — chastota va qiymatni almashtirish; «5 marta» — faqat bitta beshlikni sanash."},
 tn:"Sinfning o'zida so'rov o'tkazing (sevimli meva) — doskada cho'p belgilar bilan birga sanang."},
{h:"Cho'p belgilarni o'qish",sum:"Har beshlik — 5 (4 tik + 1 qiya). 2 beshlik va 3 chiziq = 13.",a:"m02",
 start:function(){i4t13(0);calc(['Cho‘p belgilar bo‘yicha chastota nechaga teng?'])},fin:function(){i4t13(1);y4msg('5 + 5 + 3 = <b>13</b>')},
 html:"<p>Kuzatuvchi bekatdan o'tgan avtobuslarni cho'p bilan belgiladi. Nechta avtobus o'tgan?</p>",
 btns:y4pick(1,[["11","Har beshlikdagi qiya chiziqni sanamadingiz. U ham bitta avtobus!"],["13","Ikki beshlik (10) va yana 3 ta chiziq: 13."],["8","Har beshlikni bitta deb sanadingiz: beshlik — 5 ta."],["15","Oxirgi guruh to'liq emas — unda 3 ta chiziq."]],function(){i4t13(1)}),g2:1,
 after:"<p>Beshliklarni 5 dan sanang: 5, 10, 15… oxirida qolgan alohida chiziqlarni qo'shing. Qiya chiziq — beshlikning 5-belgisi, uni unutmang.</p>",
 q:{t:"Cho'p belgilarda 4 ta to'liq beshlik va yana 2 ta chiziq bor. Chastota nechaga teng?",opts:["22","18","6","42"],ok:0,why:"4 · 5 + 2 = 22.",hint:"Har beshlik nechaga teng?",full:"4 ta beshlik — 20, yana 2 ta — 22. «18» — beshlikni 4 dan sanash (qiya chiziq unutilgan), «6» — har guruhni bitta deb sanash."},
 tn:"Bolalar juft bo'lib: biri chapak chaladi, ikkinchisi cho'p belgi qo'yadi. Keyin almashadi."},
{h:"Yetishmagan chastotani topish",sum:"Jami 30: 30 − (7 + 5 + 6) = 12.",a:"m03",
 start:function(){i4season(0);calc(['«Yoz» qatoridagi chastota o‘chib ketgan. Toping'])},fin:function(){i4season(1);y4msg('30 − 18 = <b>12</b>')},
 html:"<p>Jadvalda bitta son o'chib ketgan, lekin jami ma'lum. Yozni nechta bola tanlagan?</p>",
 btns:y4pick(0,[["12","Ma'lumlari: 7 + 5 + 6 = 18. 30 − 18 = 12."],["18","Bu — qolgan uch faslning yig'indisi. Uni jamidan ayirish kerak."],["30","30 — hamma bolalar, faqat yozni tanlaganlar emas."],["6","Bu — qish. Yoz qatori boshqa."]],function(){i4season(1)}),g2:1,
 after:"<p>Chastotalar yig'indisi = jami. Demak, yetishmagan chastota = <b>jami − ma'lum chastotalar</b>. Bu tekshirish usuli ham: yig'indi jamiga teng chiqmasa — sanashda xato bor.</p>",
 q:{t:"Jami 40 bola so'raldi. Bahor — 9, yoz — 15, kuz — 7, qolganlari qishni tanladi. Qishni nechta bola tanlagan?",opts:["9","31","40","7"],ok:0,why:"9 + 15 + 7 = 31; 40 − 31 = 9.",hint:"Ma'lum chastotalarni qo'shib, jamidan ayiring.",full:"Ma'lumlari: 9 + 15 + 7 = 31. Qish: 40 − 31 = 9. «31» — ma'lumlarning yig'indisi."},
 tn:"Jadvalni doskaga yozib, bitta sonni o'chiring — bolalar «sirli son»ni topadi."},
{h:"Tuzoq: eng ko'p uchragan ≠ eng katta",sum:"Eng ko'p sotilgan o'lcham — 34 (9 juft). 36 — eng katta o'lcham, lekin kam sotilgan.",a:"m04",
 start:function(){i4shoe(0);calc(['Do‘kon qaysi o‘lchamdan ko‘proq olib kelishi kerak?'])},fin:function(){i4shoe(1);y4msg('Eng ko‘p sotilgani — <b>34</b>-o‘lcham (9 juft)')},
 html:"<p>Do'konchi diagrammaga qarab, keyingi haftaga qaysi o'lchamdan <b>ko'proq</b> krossovka buyurtma qilishi kerak?</p>",
 btns:y4pick(1,[["36-o'lcham","36 — eng katta o'lcham, lekin atigi 2 juft sotilgan. Eng baland ustunni qarang."],["34-o'lcham","34-o'lcham ustuni eng baland — 9 juft. Bu eng ko'p uchragan qiymat."],["9-o'lcham","9 — o'lcham emas, chastota (nechta juft sotilgani)."],["33-o'lcham","33-o'lcham — 4 juft. Undan baland ustun bor."]],function(){i4shoe(1)}),g2:1,
 after:"<p>Eng ko'p uchragan qiymat (eng baland ustun yoki eng katta chastota) — <b>moda</b>. Uni eng katta qiymat bilan (36) yoki chastotaning o'zi bilan (9) adashtirmang. Qiymat — o'qning pastida, chastota — ustun balandligi.</p>",
 q:{t:"Ko'ylak o'lchamlari: 28 — 3 ta, 30 — 11 ta, 32 — 7 ta, 34 — 2 ta sotildi. Eng ko'p sotilgan o'lcham?",opts:["30","34","11","32"],ok:0,why:"30-o'lcham chastotasi 11 — eng katta.",hint:"Qaysi o'lchamning chastotasi eng katta?",full:"Chastotalar: 3, 11, 7, 2. Eng kattasi 11 — u 30-o'lchamga tegishli. «34» — eng katta o'lcham, «11» — chastota."},
 tn:"Haqiqiy hayot misoli: do'konchi, oshxona (qaysi taom ko'p yeyiladi). Bolalar o'zi misol topsin."},
{h:"Chastotadan ulushga",sum:"40 tashlashdan 8 tasida «6»: 8/40 = 1/5 — har 5 tadan 1 tasi.",a:"m05",
 start:function(){startPh(I4P5)},fin:function(){S.ph=2;I4P5[2]()},
 html:"<p>Chastota «necha marta»ni aytadi. Lekin «qanchalik tez-tez?» degan savolga <b>ulush</b> javob beradi. Bosing:</p>",btns:[phaser(I4P5)],
 after:"<p>Ulush = <b>chastota / jami</b>. 8 ta 40 tadan — 8/40, ya'ni 1/5 (40 : 8 = 5). Ulush har xil sondagi tajribalarni taqqoslashga yordam beradi: 10 ta 20 dan (1/2) — 10 ta 100 dan (1/10) ga qaraganda ko'p.</p>",
 q:{t:"Kub 60 marta tashlanganda «6» 10 marta chiqdi. Bu tashlashlarning qanday qismi?",opts:["1/6","1/10","1/60","6/10"],ok:0,why:"60 : 10 = 6 → 10/60 = 1/6.",hint:"10 son 60 ning qanday qismi? 60 ni 10 ga bo'ling.",full:"60 : 10 = 6, demak 10 — 60 ning 1/6 qismi. «1/10» — chastotani maxraj qilish, «1/60» — bitta tashlash ulushi."},
 tn:"Har bola kubni 30 marta tashlab, chastota jadvalini to'ldiradi. Butun sinf natijasini birlashtiring — ulushlar 1/6 ga yaqinlashadi."},
{h:"Oraliqlar bo'yicha chastota",sum:"Bo'ylar guruhlanadi: 120–129 (3), 130–139 (6), 140–149 (3). 130 — 130–139 guruhida.",a:"m06",
 start:function(){startPh(I4P6)},fin:function(){S.ph=3;I4P6[3]()},
 html:"<p>Qiymatlar juda ko'p xil bo'lsa (bo'y, vazn), ularni <b>oraliq</b>larga bo'lamiz. Bosing:</p>",btns:[phaser(I4P6)],
 after:"<p>Oraliqlar bir-birini qoplamaydi: 120–129, 130–139… Chegaradagi son o'zi <b>boshlanadigan</b> oraliqqa yoziladi (130 → 130–139). Shunda har qiymat faqat bitta guruhga tushadi.</p>",
 q:{t:"Bo'ylar: 128, 135, 140, 139, 131, 142, 130. 130–139 oralig'ida nechta bola?",opts:["4","3","5","7"],ok:0,why:"135, 139, 131, 130 — 4 ta.",hint:"130 kiradi, 140 kirmaydi.",full:"130–139 ga: 135, 139, 131, 130 → 4 ta. 128 — 120–129 da, 140 va 142 — 140–149 da. «3» — 130 ni tashlab yuborish, «5» — 140 ni qo'shish."},
 tn:"Bolalarning o'z bo'yini o'lchab, doskada oraliqlar jadvalini to'ldiring. Ustunlar yopishgan diagramma chizing."},
{h:"Chastota jadvalidan o'rtacha",sum:"Qutilar: 6·7 + 4·1 + 2·2 = 50 olma; 50 : 10 = 5. «(6 + 4 + 2) : 3 = 4» — xato!",a:"m07",
 start:function(){i4box(0);calc(['O‘rtacha bir qutida nechta olma?'])},fin:function(){i4box(1);y4msg('O‘rtacha <b>5</b> ta olma')},
 html:"<p>10 ta qutidagi olmalar chastota jadvalida berilgan. O'rtacha bir qutida nechta olma bor?</p>",
 btns:y4pick(0,[["5","Jami olma: 6·7 + 4·1 + 2·2 = 42 + 4 + 4 = 50. 50 : 10 = 5."],["4","(6 + 4 + 2) : 3 — bu xato: 6 tadan olmali quti 7 ta, uni 7 marta hisoblash kerak."],["6","6 — eng ko'p uchragan qiymat (moda), o'rtacha emas."],["50","50 — hamma olma. Uni qutilar soniga bo'ling."]],function(){i4box(1)}),g2:1,
 after:"<p>Chastota jadvalida har qiymat <b>chastotasicha</b> marta qatnashadi. Shuning uchun: 1) qiymat · chastota; 2) hammasini qo'shamiz; 3) <b>chastotalar yig'indisiga</b> (kuzatishlar soniga) bo'lamiz.</p>",
 q:{t:"5 bola sakrash bo'yicha ball oldi: 4 ball — 2 bola, 9 ball — 3 bola. O'rtacha ball?",opts:["7 ball","6,5 ball","9 ball","35 ball"],ok:0,why:"4·2 + 9·3 = 8 + 27 = 35; 35 : 5 = 7.",hint:"Har ballni nechta bola olganini hisobga oling.",full:"Jami ball: 4·2 + 9·3 = 8 + 27 = 35. Bolalar 5 ta: 35 : 5 = 7. «6,5» — (4 + 9) : 2, ya'ni har ballni bir marta olish; «9» — eng ko'p uchragani; «35» — jami ball."},
 tn:"Ikki bosqichli hisobni doskada ustun qilib yozing: qiymat | chastota | ko'paytma."},
{h:"Diagrammadan ikki xil jami",sum:"Oilalar: 5 + 8 + 4 + 3 = 20; bolalar: 5 + 16 + 12 + 12 = 45.",a:"m08",
 start:function(){i4fam(0);calc(['Diagramma bo‘yicha: jami nechta BOLA bor?'])},fin:function(){i4fam(1);y4msg('Jami <b>45</b> bola (20 oilada)')},
 html:"<p>20 oiladan so'raldi: «Oilangizda nechta bola bor?» Diagramma bo'yicha bu oilalarda jami nechta <b>bola</b> bor?</p>",
 btns:y4pick(2,[["20","20 — oilalar soni (ustunlar yig'indisi). Savol bolalar haqida!"],["10","1 + 2 + 3 + 4 = 10 — bu faqat o'qdagi qiymatlar yig'indisi."],["45","Har ustun: bolalar · oilalar: 5 + 16 + 12 + 12 = 45."],["8","8 — eng baland ustun: 2 bolali oilalar soni."]],function(){i4fam(1)}),g2:1,
 after:"<p>Diagrammada ikki xil son bor: <b>qiymat</b> (oilada nechta bola — pastda) va <b>chastota</b> (nechta oila — ustun balandligi). «Nechta oila?» — chastotalar yig'indisi; «nechta bola?» — qiymat · chastota yig'indisi.</p>",
 q:{t:"Shu diagramma bo'yicha: nechta oilada bolalar soni 2 tadan KO'P?",opts:["7","15","3","12"],ok:0,why:"3 bolali — 4 oila, 4 bolali — 3 oila: 7.",hint:"«2 tadan ko'p» — 3 va 4 bolali oilalar.",full:"2 tadan ko'p — 3 va 4 ta bola. Oilalar: 4 + 3 = 7. «15» — 2 bolalilarni ham qo'shish (8 + 4 + 3), «12» — bolalar soni (3·4)."},
 tn:"«Qiymat» va «chastota»ni ikki rang bilan belgilang — har savolda bola qaysi biri so'ralayotganini aytsin."},
{h:"Bilasizmi? 正 — besh chiziq",sum:"Yaponiya va Xitoyda sanoq 正 belgisi bilan yuritiladi — u ham 5 ta chiziqdan iborat.",a:"m09",
 start:function(){startPh(I4P9)},fin:function(){S.ph=2;I4P9[2]()},
 html:"<p>Beshlab sanash — butun dunyoda bor odat. Sharqiy Osiyoda u boshqacha ko'rinadi. Bosing:</p>",btns:[phaser(I4P9)],
 after:"<p>🇯🇵 Yaponiyada saylov ovozlari yoki o'yin ochkolari 正 belgisi bilan sanaladi — har chiziq bitta ovoz. 🇫🇷 Fransiya va Ispaniyaning ayrim joylarida esa beshlik kvadrat va diagonal bilan chiziladi. Usul har xil — g'oya bitta: <b>beshlab guruhlash</b>.</p>",
 tn:"Bolalar o'z «beshlik» belgisini o'ylab topsin va sinfdoshlariga o'rgatsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>Chastota</b> — qiymat necha marta uchragani. Cho'p belgilar beshlab guruhlanadi.</li><li>Chastotalar yig'indisi = jami kuzatishlar. Yetishmagani = jami − ma'lumlari.</li><li>Eng ko'p uchragan qiymat (moda) — eng katta chastotali qiymat, eng katta qiymat emas.</li><li>Ulush = chastota / jami.</li><li>Oraliqlar: chegaradagi son boshlanadigan oraliqqa yoziladi (130 → 130–139).</li><li>Jadvaldan o'rtacha: (qiymat · chastota) larning yig'indisi : chastotalar yig'indisi.</li></ul></div>",
 tn:"Uyga: oila a'zolarining tug'ilgan oylari bo'yicha chastota jadvali."}
];
var PROBS=[
{t:"Cho'p belgilar: 4 ta to'liq beshlik va yana 3 ta chiziq. Chastota nechaga teng?",o:["23","19","7","43"],k:0,s:"4 · 5 + 3 = 23."},
{t:"Baholar: 5, 4, 5, 3, 5, 4, 5. «5» bahosining chastotasi nechaga teng?",o:["4","5","7","20"],k:0,s:"«5» to'rt marta yozilgan."},
{t:"Ranglar so'rovi: qizil — 8, ko'k — 12, yashil — 5, sariq — 7. Jami nechta bola so'ralgan?",o:["32","4","12","28"],k:0,s:"8 + 12 + 5 + 7 = 32."},
{t:"Ranglar so'rovi: qizil — 8, ko'k — 12, yashil — 5, sariq — 7. Eng kam tanlangan rang?",o:["Yashil","Sariq","Qizil","Ko'k"],k:0,s:"Eng kichik chastota — 5."},
{t:"Jami 40 bola. Bahor — 9, yoz — 15, kuz — 7, qolganlari qishni tanladi. Qishni nechta bola tanlagan?",o:["9","31","40","7"],k:0,s:"40 − 31 = 9."},
{t:"Kub 30 marta tashlandi, «3» 6 marta chiqdi. Bu tashlashlarning qanday qismi?",o:["1/5","1/6","1/3","1/30"],k:0,s:"30 : 6 = 5."},
{t:"Oyoq kiyim o'lchamlari: 32 — 3 juft, 33 — 8 juft, 34 — 5 juft, 35 — 1 juft sotildi. Eng ko'p sotilgan o'lcham?",o:["33","35","8","34"],k:0,s:"Eng katta chastota 8 — 33-o'lcham."},
{t:"Bo'ylar «130–139 sm» guruhiga yozilmoqda. Qaysi bo'y bu guruhga kirmaydi?",o:["140 sm","130 sm","139 sm","135 sm"],k:0,s:"140 — keyingi guruh boshi."},
{t:"Bo'ylar: 128, 135, 140, 139, 131, 142, 130. 130–139 guruhida nechta bola?",o:["4","3","5","7"],k:0,s:"135, 139, 131, 130."},
{t:"10 ta qutida: 6 tadan olma — 7 quti, 4 tadan — 1 quti, 2 tadan — 2 quti. O'rtacha bir qutida nechta olma?",o:["5","4","6","50"],k:0,s:"42 + 4 + 4 = 50; 50 : 10."},
{t:"Oilalar: 1 bolali — 5 oila, 2 bolali — 8 oila, 3 bolali — 4 oila, 4 bolali — 3 oila. Jami nechta bola?",o:["45","20","10","50"],k:0,s:"5 + 16 + 12 + 12 = 45."},
{t:"Oilalar: 1 bolali — 5, 2 bolali — 8, 3 bolali — 4, 4 bolali — 3 oila. Nechta oilada 2 tadan ko'p bola bor?",o:["7","15","3","12"],k:0,s:"4 + 3 = 7."},
{t:"So'rovda 50 bola qatnashdi. «Mushuk» javobi jamining 3/10 qismi. Nechta bola mushukni tanlagan?",o:["15","30","5","3"],k:0,s:"50 : 10 · 3 = 15."},
{t:"Tanga 20 marta tashlandi. «Gerb» «raqam»dan 4 taga ko'p chiqdi. «Gerb» necha marta chiqdi?",o:["12","16","8","10"],k:0,s:"(20 + 4) : 2 = 12."},
{t:"Baholar: «5» — 6 ta, «4» — 9 ta, «3» — 5 ta. «4» va «5» olganlar jami bolalarning qanday qismi?",o:["3/4","9/20","1/4","3/5"],k:0,s:"15 ta 20 tadan: 15/20 = 3/4."},
{t:"Cho'p belgilar: A — 3 ta beshlik va 2 chiziq, B — 2 ta beshlik va 4 chiziq. A B dan nechtaga ko'p?",o:["3","1","2","31"],k:0,s:"17 − 14 = 3."},
{t:"Kub 60 marta tashlandi: «1» — 9, «2» — 11, «3» — 10, «4» — 8, «5» — 12 marta, qolganida «6» chiqdi. «6» necha marta chiqdi?",o:["10","6","12","50"],k:0,s:"60 − 50 = 10."},
{t:"Jadvalda: A — 7, B — 14, C — ?, jami 35. C ning chastotasi A nikidan necha marta ko'p?",o:["2 marta","7 marta","14 marta","5 marta"],k:0,s:"C = 35 − 21 = 14; 14 : 7 = 2."},
{t:"Sinfda 28 bola. Ko'zoynak taqadiganlar taqmaydiganlardan 6 taga kam. Ko'zoynak taqadiganlar nechta?",o:["11","22","17","14"],k:0,s:"(28 − 6) : 2 = 11."},
{t:"Nishonga otishda: 10 ochko — 3 marta, 8 ochko — 5 marta, 5 ochko — 2 marta. Jami necha ochko?",o:["80","23","10","53"],k:0,s:"30 + 40 + 10 = 80."}
];
var PREP_DATA={teach:["Chastota tushunchasi, cho'p belgilar (beshlik).","Chastota jadvali va jami bilan tekshirish; yetishmagan chastota.","Eng ko'p uchragan qiymat (moda) — qiymat va chastotani farqlash.","Ulush = chastota / jami.","Oraliqlar bo'yicha chastota va gistogramma; jadvaldan o'rtacha."],
 mist:["Beshlikdagi qiya chiziqni sanamaydi.","Qiymat va chastotani almashtiradi.","Eng katta qiymatni eng ko'p uchragan deb oladi.","Chegaradagi qiymatni ikki guruhga yozadi yoki tashlab yuboradi.","Jadvaldan o'rtachada qiymatlarni chastotasiz o'rtachalaydi."],
 need:["Kub (o'yin soqqasi), tangalar.","Santimetr lenta (bo'y o'lchash uchun)."],
 board:["Chastota jadvali: <span class='w2'>qiymat | cho'p | chastota</span>.","Yig'indi = jami ✓.","Ulush: <span class='w2'>8 / 40 = 1/5</span>.","O'rtacha: <span class='w2'>(6·7 + 4·1 + 2·2) : 10 = 5</span>."]};
