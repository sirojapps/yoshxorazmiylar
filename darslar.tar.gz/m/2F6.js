var CODE='2F6',TITLE='2-sinf · Doira, aylana va fazoviy shakllar';
function f6_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f6_circ(k){clear();var g=S.g,cx=180,cy=88,R=62;
 if(k===0){var a=S.an||0;var p='M'+(cx+R)+' '+cy;for(var t=0;t<=a;t+=3){var r=t*Math.PI/180;p+=' L'+(cx+R*Math.cos(r))+' '+(cy-R*Math.sin(r))}E('path',{d:p,fill:'none',stroke:C.blue,'stroke-width':4},g);var rr=a*Math.PI/180;E('line',{x1:cx,y1:cy,x2:cx+R*Math.cos(rr),y2:cy-R*Math.sin(rr),stroke:'#8a5a24','stroke-width':2.5},g);E('circle',{cx:cx,cy:cy,r:4,fill:C.bad},g);T(g,cx+R*Math.cos(rr),cy-R*Math.sin(rr)-6,'✏️',{'font-size':14});f6_msg(a<360?'Sirkul aylanmoqda… ip uzunligi o‘zgarmaydi':'Chiziq yopildi — bu <b>aylana</b>');return}
 if(k===1){E('circle',{cx:cx,cy:cy,r:R,fill:'none',stroke:C.blue,'stroke-width':4},g);T(g,cx,cy+R+20,'aylana — faqat chiziq',{'font-size':12,'font-weight':800,fill:C.blue});f6_msg('<b>Aylana</b> — yopiq egri chiziq (halqa, uzuk)');return}
 E('circle',{cx:cx,cy:cy,r:R,fill:'rgba(240,160,64,.45)',stroke:C.a2,'stroke-width':4},g);T(g,cx,cy+R+20,'doira — chiziq va uning ichi',{'font-size':12,'font-weight':800,fill:C.a2});f6_msg('<b>Doira</b> — aylana va uning ichidagi hamma joy (tanga, likopcha)')}
function f6_rad(k){clear();var g=S.g,cx=180,cy=88,R=62;E('circle',{cx:cx,cy:cy,r:R,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:cx,cy:cy,r:4,fill:C.bad},g);T(g,cx-10,cy-8,'O',{'font-size':13,'font-weight':800,fill:C.bad});
 if(k>=1){E('line',{x1:cx,y1:cy,x2:cx+R,y2:cy,stroke:C.ok,'stroke-width':3.5},g);T(g,cx+R/2,cy-8,'3 sm',{'font-size':12,'font-weight':800,fill:C.ok})}
 if(k>=2){E('line',{x1:cx-R,y1:cy+1,x2:cx,y2:cy+1,stroke:C.a2,'stroke-width':3.5},g);T(g,cx-R/2,cy+18,'3 sm',{'font-size':12,'font-weight':800,fill:C.a2});Br(cx-R,cx+R,cy+R+4,'',false,C.a2);T(g,cx+R+8,cy+R+12,'d = 6 sm',{'font-size':12,'font-weight':800,fill:C.a2,'text-anchor':'start'})}
 f6_msg(k===0?'Aylananing o‘rtasidagi nuqta — <b>markaz</b> (O)':(k===1?'Markazdan aylanagacha kesma — <b>radius</b>. Hamma radiuslar teng':'Markazdan o‘tib, aylanani ikki joyda kesgan kesma — <b>diametr</b> = 2 ta radius'))}
// fazoviy shakllar
var F6_SH={kub:{n:'Kub',d:'6 ta yoq (hammasi kvadrat), 12 ta qirra, 8 ta uch. Dumalamaydi.',ex:'qand, o‘yin soqqasi'},
 quti:{n:'To‘g‘ri burchakli parallelepiped (quti)',d:'6 ta yoq (to‘g‘ri to‘rtburchaklar), 12 ta qirra, 8 ta uch.',ex:'g‘isht, kitob, quti'},
 shar:{n:'Shar',d:'Tekis yuzasi ham, uchi ham yo‘q. Har tomonga dumalaydi.',ex:'koptok, tarvuz, globus'},
 sil:{n:'Silindr',d:'2 ta tekis yuza (doira) va egri yon sirt. Yonboshlab dumalaydi, tik qo‘ysa turadi.',ex:'stakan, konserva bankasi'},
 kon:{n:'Konus',d:'1 ta tekis yuza (doira) va 1 ta uch. Aylanib dumalaydi.',ex:'muzqaymoq vafli, svetofor konusi'},
 pir:{n:'Piramida',d:'Asosi ko‘pburchak, yon yoqlari uchburchaklar, tepada bitta uch. Dumalamaydi.',ex:'Misr ehromlari'}};
function f6_draw(id,x,y,s){var g=S.g;s=s||1;
 if(id==='kub'||id==='quti'){var w=(id==='kub'?60:90)*s,h=60*s,d=24*s;E('path',{d:'M'+x+' '+y+' l'+d+' '+(-d*.6)+' h'+w+' l'+(-d)+' '+(d*.6)+' Z',fill:'#cfe3f7',stroke:C.blue,'stroke-width':2},g);E('path',{d:'M'+(x+w)+' '+y+' l'+d+' '+(-d*.6)+' v'+h+' l'+(-d)+' '+(d*.6)+' Z',fill:'#9fc6ea',stroke:C.blue,'stroke-width':2},g);E('rect',{x:x,y:y,width:w,height:h,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2},g)}
 if(id==='shar'){var r=36*s;E('circle',{cx:x+r,cy:y+r-6,r:r,fill:'#fde2c4',stroke:C.a2,'stroke-width':2},g);E('ellipse',{cx:x+r,cy:y+r-6,rx:r,ry:r*.3,fill:'none',stroke:C.a2,'stroke-width':1.2,'stroke-dasharray':'4 3'},g);E('circle',{cx:x+r*.6,cy:y+r*.5,r:r*.18,fill:'#fff',opacity:.7},g)}
 if(id==='sil'){var rx=32*s,ry=10*s,h2=62*s;E('rect',{x:x,y:y,width:rx*2,height:h2,fill:'#d4f0eb',stroke:'none'},g);E('line',{x1:x,y1:y,x2:x,y2:y+h2,stroke:C.u,'stroke-width':2},g);E('line',{x1:x+rx*2,y1:y,x2:x+rx*2,y2:y+h2,stroke:C.u,'stroke-width':2},g);E('ellipse',{cx:x+rx,cy:y+h2,rx:rx,ry:ry,fill:'#d4f0eb',stroke:C.u,'stroke-width':2},g);E('ellipse',{cx:x+rx,cy:y,rx:rx,ry:ry,fill:'#b6e6df',stroke:C.u,'stroke-width':2},g)}
 if(id==='kon'){var rx2=34*s,h3=70*s;E('path',{d:'M'+(x+rx2)+' '+(y-8)+' L'+x+' '+(y+h3)+' A'+rx2+' '+(10*s)+' 0 0 0 '+(x+rx2*2)+' '+(y+h3)+' Z',fill:'#fbe0e8',stroke:'#c2507a','stroke-width':2},g);E('ellipse',{cx:x+rx2,cy:y+h3,rx:rx2,ry:10*s,fill:'none',stroke:'#c2507a','stroke-width':1.5,'stroke-dasharray':'4 3'},g)}
 if(id==='pir'){var b=70*s;E('polygon',{points:(x)+','+(y+60*s)+' '+(x+b)+','+(y+60*s)+' '+(x+b*.5)+','+(y-10*s),fill:'#f6e7b3',stroke:'#a8861f','stroke-width':2},g);E('polygon',{points:(x+b)+','+(y+60*s)+' '+(x+b*1.3)+','+(y+44*s)+' '+(x+b*.5)+','+(y-10*s),fill:'#e6cf85',stroke:'#a8861f','stroke-width':2},g)}}
function f6_show(id){clear();f6_draw(id,id==='quti'?110:140,id==='shar'?50:60);var s=F6_SH[id];T(S.g,180,166,s.n,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+s.d+'<br><small style="color:#5b6b7b">Hayotda: '+s.ex+'</small></div></div>'}
function f6_cube(k){clear();var g=S.g;var x=120,y=60,w=80,d=32;
 var F=[[x,y],[x+w,y],[x+w,y+w],[x,y+w]],B=F.map(function(p){return [p[0]+d,p[1]-d*.6]});
 E('path',{d:'M'+F[0]+' L'+B[0]+' L'+B[1]+' L'+F[1]+' Z',fill:k===1?'#ffd24d':'#cfe3f7',stroke:C.blue,'stroke-width':2},g);E('path',{d:'M'+F[1]+' L'+B[1]+' L'+B[2]+' L'+F[2]+' Z',fill:k===1?'#ffd24d':'#9fc6ea',stroke:C.blue,'stroke-width':2},g);E('polygon',{points:F.join(' '),fill:k===1?'#ffd24d':'#e8f1fb',stroke:C.blue,'stroke-width':2},g);
 E('path',{d:'M'+F[3]+' L'+B[3]+' L'+B[2]+' M'+B[3]+' L'+B[0],fill:'none',stroke:C.blue,'stroke-width':1.5,'stroke-dasharray':'4 3'},g);
 if(k===2){[[F[0],F[1]],[F[1],F[2]],[F[2],F[3]],[F[3],F[0]],[B[0],B[1]],[B[1],B[2]],[B[2],B[3]],[B[3],B[0]],[F[0],B[0]],[F[1],B[1]],[F[2],B[2]],[F[3],B[3]]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:C.bad,'stroke-width':3.5},g)})}
 if(k===3)F.concat(B).forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:6,fill:C.ok,stroke:'#fff','stroke-width':2},g)});
 f6_msg(k===0?'Kub. Biz 3 ta yog‘ini ko‘ryapmiz — orqasida yana bor!':(k===1?'<b>Yoqlar</b>: 6 ta (old, orqa, tepa, past, o‘ng, chap) — hammasi kvadrat':(k===2?'<b>Qirralar</b> (yoqlar tutashgan chiziqlar): 12 ta':'<b>Uchlar</b>: 8 ta — tepada 4, pastda 4')))}
var F6_P4=[function(){f6_cube(0)},function(){f6_cube(1)},function(){f6_cube(2)},function(){f6_cube(3)}];
function f6_roll(id){clear();var yy={kub:72,quti:72,shar:66,sil:60,kon:52,pir:72}[id];f6_draw(id,id==='quti'?120:145,yy);E('line',{x1:20,y1:133,x2:340,y2:133,stroke:'#8a6a3a','stroke-width':3},S.g);var r={kub:'turadi, dumalamaydi',quti:'turadi, dumalamaydi',shar:'har tomonga dumalaydi',sil:'yonboshlab qo‘ysa — dumalaydi, tik qo‘ysa — turadi',kon:'yonboshlab — aylanib dumalaydi',pir:'turadi, dumalamaydi'}[id];f6_msg('<b>'+F6_SH[id].n+'</b>: '+r)}
var STEPS=[
{h:"Aylanani chizamiz",sum:"Aylana — markazdan bir xil uzoqlikdagi nuqtalardan iborat yopiq egri chiziq. Sirkul yoki ip bilan chiziladi.",a:"m01",
 start:function(){S.an=0;f6_circ(0)},fin:function(){S.an=360;f6_circ(0)},
 html:"<p>Ipning bir uchini qadab, ikkinchi uchiga qalam bog'lab aylantirsak, nima hosil bo'ladi? Tugmani bosing.</p>",
 btns:[["✏️ Aylantirish",function(c,done,b){b.disabled=true;var iv=setInterval(function(){S.an+=12;f6_circ(0);if(S.an>=360){clearInterval(iv);done()}},40)}]],
 after:"<p>Qalam markazdan doim <b>bir xil uzoqlikda</b> yurdi — shuning uchun <b>aylana</b> chiqdi. Maktabda buni <b>sirkul</b> bilan chizamiz.</p>",
 q:{t:"Aylana chizish uchun qaysi asbob kerak?",opts:["Chizg'ich","Sirkul","Transportir","Qaychi"],ok:1,why:"Sirkulning bir oyog'i markazda turadi, ikkinchisi aylana chizadi.",hint:"Sahnada ipning bir uchi qimirlamay turdi. Qaysi asbob shunday ishlaydi?",full:"Sirkul — bir oyog'i markazga qadaladi, qalamli oyog'i esa doim bir xil uzoqlikda aylanadi. Chizg'ich to'g'ri chiziq uchun."},
 tn:"Sinfga ip va bo'r olib chiqing: bir bola ipni doskaga bosib tursin, ikkinchisi aylana chizsin."},
{h:"Aylana va doira — farqi",sum:"Aylana — faqat chiziq (halqa). Doira — aylana va uning ichi (tanga).",a:"m02",
 start:function(){f6_circ(1)},fin:function(){f6_circ(2)},
 html:"<p>«Aylana» va «doira» — bir xil narsami? Tugmalarni bosib solishtiring.</p>",
 btns:[["◯ Aylana",function(c,done){f6_circ(1);mvK(done,2)}],["⬤ Doira",function(c,done){f6_circ(2);mvK(done,2)},'u']],g2:1,
 after:"<div class='life'><div>💍<span><b>Aylana</b> — faqat chiziq: uzuk, halqa, gardish</span></div><div>🪙<span><b>Doira</b> — chiziq va ichi: tanga, likopcha, non</span></div></div>",
 q:{t:"Qaysi narsa doiraga o'xshaydi?",opts:["Uzuk","Tanga","Halqa","Bilaguzuk"],ok:1,why:"Tanganing ichi ham to'la — bu doira.",hint:"Qaysi narsaning ichi bo'sh emas, to'la?",full:"Uzuk, halqa, bilaguzuk — ichi bo'sh, ular aylanaga o'xshaydi. Tanga esa ichi to'la — doira."},
 tn:"Bolalar qog'ozdan doira qirqib olsin: qolgan teshik qirrasi — aylana, qirqilgan bo'lak — doira."},
{h:"Markaz, radius va diametr",sum:"Markaz — o'rtadagi nuqta. Radius — markazdan aylanagacha. Diametr — markaz orqali o'tuvchi kesma, 2 ta radiusga teng.",a:"m03",
 start:function(){startPh([function(){f6_rad(0)},function(){f6_rad(1)},function(){f6_rad(2)}])},fin:function(){f6_rad(2)},
 html:"<p>Aylananing o'z «a'zolari» bor. Ularni bittalab ko'ramiz.</p>",
 btns:[phaser([function(){f6_rad(0)},function(){f6_rad(1)},function(){f6_rad(2)}])],
 after:"<p><b>Radius</b> — markazdan aylanagacha bo'lgan kesma. Bitta aylanada hamma radiuslar <b>teng</b>. <b>Diametr</b> — markazdan o'tib, aylanani ikki joyda kesadi: u <b>ikkita radiusga</b> teng.</p>",
 q:{t:"Aylananing radiusi 4 sm. Diametri qancha?",opts:["4 sm","2 sm","8 sm","16 sm"],ok:2,why:"Diametr = 2 ta radius: 4 + 4 = 8 sm.",hint:"Diametr nechta radiusdan iborat?",full:"Diametr markaz orqali o'tadi va ikkita radiusdan iborat: 4 + 4 = 8 sm. «2 sm» — teskari qilingan (yarmi olingan)."},
 tn:"Qog'oz doirani ikki marta buklab, bolalar markazni o'zi topsin. Buklam chiziqlari — diametrlar."},
{h:"Fazoviy shakllar",sum:"Kub, quti (parallelepiped), shar, silindr, konus, piramida — ular tekislikda emas, fazoda: ularni ushlash mumkin.",a:"m04",
 start:function(){f6_show('kub')},fin:function(){f6_show('sil')},
 html:"<p>Doira, kvadrat — qog'ozda chiziladi. Lekin atrofimizdagi narsalar <b>hajmli</b>: ularni qo'lga olish mumkin. Ular <b>fazoviy shakllar</b> deyiladi. Har birini bosib ko'ring:</p>",
 btns:[["Kub",function(c,done){f6_show('kub');mvK(done,4)}],["Quti",function(c,done){f6_show('quti');mvK(done,4)}],["Shar",function(c,done){f6_show('shar');mvK(done,4)},'u'],["Silindr",function(c,done){f6_show('sil');mvK(done,4)},'u'],["Konus",function(c,done){f6_show('kon');mvK(done,4)}],["Piramida",function(c,done){f6_show('pir');mvK(done,4)}]],g3:1,
 after:"<p>Fazoviy shakllarning yuzalari ba'zan <b>tekis</b> (kub, quti), ba'zan <b>egri</b> (shar), ba'zan ikkalasi ham (silindr, konus). Silindrning tekis yuzalari — <b>doiralar</b>, kubning yoqlari — <b>kvadratlar</b>.</p>",
 q:{t:"Qaysi jismning birorta ham uchi yo'q va tekis yuzasi ham yo'q?",opts:["Kub","Piramida","Shar","Quti"],ok:2,why:"Sharning yuzasi butunlay egri, uchi yo'q.",hint:"Qaysi shaklni bosganingizda «tekis yuzasi ham, uchi ham yo'q» deb yozildi?",full:"Shar butunlay egri — uchi ham, qirrasi ham, tekis yuzasi ham yo'q. Kub, quti va piramidaning uchlari bor."},
 tn:"Sinfga haqiqiy narsalarni olib keling: koptok, stakan, quti, soqqa. Bolalar ko'zini yumib ushlab, shaklini topsin."},
{h:"Kubni o'rganamiz",sum:"Kubda 6 ta yoq (kvadrat), 12 ta qirra, 8 ta uch.",a:"m05",
 start:function(){startPh(F6_P4)},fin:function(){S.ph=3;F6_P4[3]()},
 html:"<p>Rasmda kubning faqat <b>3 ta</b> yog'i ko'rinadi. Lekin aslida nechta? Bittalab sanaymiz.</p>",
 btns:[phaser(F6_P4,'▶ Keyingisi')],
 after:"<p>Kubda: <b>6 ta yoq</b> (hammasi teng kvadratlar), <b>12 ta qirra</b> (yoqlar tutashgan chiziqlar), <b>8 ta uch</b>. Rasmda ko'rinmaydiganlarini <b>uzuq chiziq</b> bilan chizamiz.</p>",
 q:{t:"Kub shaklidagi qutining har bir yog'iga 3 tadan yulduzcha yopishtirildi. Jami nechta yulduzcha?",opts:["9","12","18","24"],ok:2,why:"Kubda 6 ta yoq: 3 + 3 + 3 + 3 + 3 + 3 = 18.",hint:"Kubning nechta yog'i bor? Rasmda ko'ringanlarini emas, hammasini sanang.",full:"Kubning 6 ta yog'i bor. Har biriga 3 tadan: 3 + 3 + 3 + 3 + 3 + 3 = 18. «9» — faqat ko'rinib turgan 3 ta yoq sanalgan."},
 tn:"Qog'oz kub yoki qand bo'lagini ushlatib, yoqlarini barmoq bilan sanatib chiqing."},
{h:"Dumalaydimi yoki turadimi?",sum:"Shar har tomonga dumalaydi; silindr yonboshlab dumalaydi, tik turadi; kub, quti, piramida dumalamaydi.",a:"m06",
 start:function(){f6_roll('shar')},fin:function(){f6_roll('sil')},
 html:"<p>Shakllarni stol ustiga qo'yib, turtib ko'ramiz. Qaysi biri dumalaydi?</p>",
 btns:[["Kub",function(c,done){f6_roll('kub');mvK(done,3)}],["Shar",function(c,done){f6_roll('shar');mvK(done,3)},'u'],["Silindr",function(c,done){f6_roll('sil');mvK(done,3)},'u'],["Konus",function(c,done){f6_roll('kon');mvK(done,3)}],["Piramida",function(c,done){f6_roll('pir');mvK(done,3)}],["Quti",function(c,done){f6_roll('quti');mvK(done,3)}]],g3:1,
 after:"<p><b>Egri</b> yuzasi bor shakllar dumalaydi (shar, silindr, konus). Faqat <b>tekis</b> yoqli shakllar (kub, quti, piramida) dumalamaydi — ular mustahkam turadi. Shuning uchun g'isht kub yoki quti shaklida, g'ildirak esa doira shaklida!</p>",
 q:{t:"Silindrning nechta tekis (yassi) yuzasi bor?",opts:["0","1","2","3"],ok:2,why:"Silindrning tepasi va pasti — 2 ta tekis doira.",hint:"Stakan yoki konserva bankasini tasavvur qiling: tepasi va pasti qanday?",full:"Silindrning tepasi va pastida ikkita tekis doira bor, yon tomoni esa egri. Shuning uchun u tik qo'yilsa turadi, yonboshlab qo'yilsa dumalaydi."},
 tn:"Haqiqiy narsalarni partada dumalatib ko'ring. «Nega g'ildirak to'rtburchak emas?» deb so'rang."},
{h:"Bilasizmi? Beruniyning globusi",sum:"Taxminan 1000 yil oldin vatandoshimiz Abu Rayhon Beruniy Yer shar shaklida ekanini isbotlab, globus yasagan.",a:"m07",
 start:function(){f6_globe(false)},fin:function(){f6_globe(true)},
 html:"<p>🌍 Yerimiz qanday shaklda? Bundan taxminan <b>1000 yil oldin</b> Xorazmlik buyuk olim <b>Abu Rayhon Beruniy</b> bu savolga javob izlagan. Tugmani bosing.</p>",
 btns:[["🌍 Ko'rsatish",function(c,done){f6_globe(true);done()}]],
 after:"<p>Beruniy Yer <b>shar</b> shaklida ekanini yozgan va o'lchashlar asosida uning kattaligini ham hisoblagan. U dunyodagi eng qadimgi <b>globus</b>lardan birini yasagan olimlardan biri hisoblanadi. Globus — Yerning kichik nusxasi, u ham shar!</p>",
 tn:"Sinfga globus olib kelib ko'rsating. «Qaysi fazoviy shakl?» deb so'rang."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){f6_rad(2)},fin:function(){f6_rad(2)},
 html:"<div class='memo'><ul><li><b>Aylana</b> — yopiq egri chiziq, sirkul bilan chiziladi. <b>Doira</b> — aylana va uning ichi.</li><li><b>Markaz</b> — o'rtadagi nuqta; <b>radius</b> — markazdan aylanagacha; <b>diametr</b> = 2 ta radius.</li><li>Fazoviy shakllar: <b>kub, quti, shar, silindr, konus, piramida</b>.</li><li><b>Kub</b>: 6 ta yoq (kvadrat), 12 ta qirra, 8 ta uch.</li><li>Shar — uchi ham, tekis yuzasi ham yo'q. Silindrda — 2 ta tekis doira.</li><li>Egri yuzasi bor shakllar dumalaydi.</li></ul></div>",
 tn:"Keyingi darsni «Xonadagi qaysi narsalar silindr shaklida?» o'yini bilan boshlang."}
];
function f6_globe(on){clear('#eaf4ff');var g=S.g,cx=180,cy=86,r=62;E('circle',{cx:cx,cy:cy,r:r,fill:'#6fb3e8',stroke:'#1f6fb2','stroke-width':2},g);E('path',{d:'M150 50 q20 -10 35 5 q10 15 -5 25 q-20 5 -30 -10 Z M195 95 q25 -5 30 15 q-5 20 -25 15 q-15 -10 -5 -30 Z M140 100 q10 5 5 20 q-15 5 -15 -10 Z',fill:'#7cc47a',stroke:'#3e8e3a','stroke-width':1},g);E('ellipse',{cx:cx,cy:cy,rx:r,ry:18,fill:'none',stroke:'#fff','stroke-width':1,opacity:.7},g);E('line',{x1:cx,y1:cy-r-8,x2:cx,y2:cy+r+8,stroke:'#8a5a24','stroke-width':3},g);
 if(on)T(g,cx,166,'Abu Rayhon Beruniy (973–1048)',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});f6_msg(on?'Yer — <b>shar</b> shaklida. Globus — uning kichik nusxasi':'Yer qanday shaklda?')}
var PROBS=[
{t:"Aylana chizish uchun qaysi asbob ishlatiladi?",o:["sirkul","chizg'ich","transportir","qaychi"],k:0,s:"Sirkulning bir oyog'i markazda turadi."},
{t:"Qaysi narsa doiraga o'xshaydi?",o:["tanga","uzuk","halqa","bilaguzuk"],k:0,s:"Tanganing ichi to'la — doira."},
{t:"Qaysi narsa aylanaga o'xshaydi?",o:["uzuk","tanga","likopcha","non"],k:0,s:"Uzukning ichi bo'sh — faqat chiziq, aylana."},
{t:"Aylananing radiusi 4 sm. Diametri qancha?",o:["8 sm","4 sm","2 sm","16 sm"],k:0,s:"Diametr = 2 ta radius: 4 + 4 = 8 sm."},
{t:"Aylananing diametri 10 sm. Radiusi qancha?",o:["5 sm","10 sm","20 sm","2 sm"],k:0,s:"Radius — diametrning yarmi: 5 + 5 = 10, radius 5 sm."},
{t:"Bitta aylanada radiuslar qanday?",o:["hammasi teng","har xil","faqat ikkitasi teng","diametrdan uzun"],k:0,s:"Aylananing hamma nuqtalari markazdan bir xil uzoqlikda."},
{t:"Kubning nechta yog'i bor?",o:["6","4","8","12"],k:0,s:"Old, orqa, tepa, past, o'ng, chap — 6 ta."},
{t:"Kubning nechta uchi bor?",o:["8","6","4","12"],k:0,s:"Tepada 4 ta, pastda 4 ta — 8 ta."},
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","4"],k:0,s:"Tepada 4, pastda 4, yon tomonda 4 — 12 ta."},
{t:"Kub shaklidagi qutining har bir yog'iga 3 tadan yulduzcha yopishtirildi. Jami nechta?",o:["18","12","24","9"],k:0,s:"6 ta yoq: 3 + 3 + 3 + 3 + 3 + 3 = 18."},
{t:"Shar, kub, silindr va konusdan qaysi biri dumalamaydi?",o:["kub","shar","silindr","konus"],k:0,s:"Kubning faqat tekis yoqlari bor — dumalamaydi."},
{t:"Qaysi jismning birorta ham uchi yo'q?",o:["shar","piramida","kub","quti"],k:0,s:"Shar butunlay egri — uchi yo'q."},
{t:"Silindrning nechta tekis yuzasi bor?",o:["2","0","1","3"],k:0,s:"Tepasi va pasti — 2 ta doira."},
{t:"Konusning nechta uchi bor?",o:["1","0","2","4"],k:0,s:"Konusning tepasida bitta uch bor."},
{t:"Stakan qaysi fazoviy shaklga o'xshaydi?",o:["silindr","konus","shar","kub"],k:0,s:"Stakan — silindr (yuqorisi ochiq)."},
{t:"Tarvuz qaysi fazoviy shaklga o'xshaydi?",o:["shar","silindr","kub","piramida"],k:0,s:"Tarvuz — shar shaklida."},
{t:"G'isht qaysi fazoviy shaklga o'xshaydi?",o:["to'g'ri burchakli parallelepiped (quti)","kub","silindr","piramida"],k:0,s:"G'ishtning yoqlari to'g'ri to'rtburchaklar — quti shakli."},
{t:"Ikkita kubning jami nechta yog'i bor?",o:["12","6","8","16"],k:0,s:"6 + 6 = 12."},
{t:"Kub stolda turibdi. Uning nechta yog'i stolga tegmaydi?",o:["5","6","4","3"],k:0,s:"6 ta yoqdan bittasi stolda — 5 tasi tegmaydi."},
{t:"Silindr va konusning jami nechta tekis yuzasi bor?",o:["3","2","4","1"],k:0,s:"Silindrda 2 ta, konusda 1 ta: 2 + 1 = 3."}
];
function PRACT_STAGE(){f6_show('kub')}
var PREP_DATA={teach:["Aylana va doira; ularning farqi.","Markaz, radius, diametr (diametr = 2 radius).","Fazoviy shakllar: kub, quti, shar, silindr, konus, piramida.","Kubning yoqlari, qirralari, uchlari.","Qaysi shakl dumalaydi va nega."],
 mist:["Aylana va doirani aralashtiradi.","Diametrni radiusning yarmi deb o'ylaydi.","Kubning faqat ko'rinib turgan 3 ta yog'ini sanaydi.","Fazoviy shaklni tekis shakl nomi bilan ataydi (kubni «kvadrat»)."],
 need:["Ip, bo'r, sirkul, qog'oz doiralar.","Haqiqiy narsalar: koptok, stakan, quti, soqqa, muzqaymoq konusi, globus."],
 board:["Aylana ◯ va doira ⬤.","Markaz O, radius r, diametr = r + r.","Kub: 6 yoq, 12 qirra, 8 uch.","Dumalaydi: shar, silindr, konus. Turadi: kub, quti, piramida."]};
