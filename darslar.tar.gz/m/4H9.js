var CODE='4H9',TITLE='4-sinf · Simmetriya: o‘q, to‘g‘ri chiziqqa nisbatan, markaziy';
function q9msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function q9X(i){return 30+30*i}function q9Y(j){return 156-24*j}
// o: ax [[x1,y1,x2,y2]] (o'q, kesik), polys [[pts,fill,st]], segs, pts [[x,y,lab,col,dx,dy]], tap
function q9grid(o){o=o||{};clear();var g=S.g,i,j;
 for(i=0;i<=10;i++)E('line',{x1:q9X(i),y1:q9Y(0),x2:q9X(i),y2:q9Y(6),stroke:'#e6ebf0','stroke-width':1},g);
 for(j=0;j<=6;j++)E('line',{x1:q9X(0),y1:q9Y(j),x2:q9X(10),y2:q9Y(j),stroke:'#e6ebf0','stroke-width':1},g);
 (o.ax||[]).forEach(function(a){E('line',{x1:q9X(a[0]),y1:q9Y(a[1]),x2:q9X(a[2]),y2:q9Y(a[3]),stroke:C.u,'stroke-width':2.5,'stroke-dasharray':'7 5'},g)});
 (o.polys||[]).forEach(function(q){E('polygon',{points:q[0].map(function(p){return q9X(p[0])+','+q9Y(p[1])}).join(' '),fill:q[1]||'rgba(240,160,64,.4)',stroke:q[2]||C.a2,'stroke-width':2.5,'stroke-linejoin':'round'},g)});
 (o.segs||[]).forEach(function(q){E('line',{x1:q9X(q[0]),y1:q9Y(q[1]),x2:q9X(q[2]),y2:q9Y(q[3]),stroke:q[4]||C.grey,'stroke-width':2,'stroke-dasharray':q[5]?'4 4':'none'},g)});
 (o.pts||[]).forEach(function(p){E('circle',{cx:q9X(p[0]),cy:q9Y(p[1]),r:5,fill:p[3]||C.bad,stroke:'#fff','stroke-width':1.5},g);if(p[2])T(g,q9X(p[0])+(p[4]==null?10:p[4]),q9Y(p[1])+(p[5]==null?-8:p[5]),p[2],{'font-size':12,'font-weight':800,fill:p[3]||C.bad})});
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var x=Math.max(0,Math.min(10,Math.round((p.x-30)/30))),y=Math.max(0,Math.min(6,Math.round((156-p.y)/24)));o.tap(x,y)})}}
function q9mir(a){return a.map(function(p){return [10-p[0],p[1]]})}
var Q9H=[[1,1],[4,1],[4,2],[2,2],[2,4],[4,4],[4,5],[1,5]];
var Q9P1=[function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9H]]});q9msg('O‘qning chap tomonida shakl. Varaqni o‘q bo‘ylab buklasak?')},
 function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9H],[q9mir(Q9H),'rgba(18,163,159,.18)',C.u]]});q9msg('Shakl o‘ng tomonga <b>ko‘zgudagidek</b> tushdi')},
 function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9H],[q9mir(Q9H),'rgba(18,163,159,.18)',C.u]],segs:[[1,1,9,1,C.bad,1],[2,4,8,4,C.bad,1]],pts:[[1,1,'',C.bad],[9,1,'',C.bad],[2,4,'',C.bad],[8,4,'',C.bad]]});q9msg('Mos nuqtalar o‘qdan <b>bir xil</b> uzoqlikda, tutashtiruvchi kesma o‘qqa <b>perpendikular</b>')}];
function q9shape(k){clear();var g=S.g;
 function ax(x1,y1,x2,y2){E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:C.u,'stroke-width':2,'stroke-dasharray':'6 4'},g)}
 var F='rgba(240,160,64,.35)';
 E('rect',{x:18,y:44,width:64,height:64,fill:k===0?F:'#f3f4f6',stroke:k===0?C.a2:C.grey,'stroke-width':2.5},g);
 E('rect',{x:100,y:52,width:76,height:48,fill:k===1?F:'#f3f4f6',stroke:k===1?C.a2:C.grey,'stroke-width':2.5},g);
 E('polygon',{points:'232,40 266,100 198,100',fill:k===2?F:'#f3f4f6',stroke:k===2?C.a2:C.grey,'stroke-width':2.5},g);
 E('circle',{cx:316,cy:76,r:32,fill:k===3?F:'#f3f4f6',stroke:k===3?C.a2:C.grey,'stroke-width':2.5},g);
 if(k===0){ax(50,34,50,118);ax(8,76,92,76);ax(10,36,90,116);ax(90,36,10,116)}
 if(k===1){ax(138,42,138,110);ax(92,76,184,76)}
 if(k===2){ax(232,32,232,108);ax(276,106,206,64);ax(188,106,258,64)}
 if(k===3){for(var i=0;i<6;i++){var t=i*Math.PI/6;ax(316+40*Math.cos(t),76+40*Math.sin(t),316-40*Math.cos(t),76-40*Math.sin(t))}}
 [['kvadrat',50],['to‘rtburchak',138],['uchburchak',232],['doira',316]].forEach(function(l,i){T(g,l[1],140,l[0],{'font-size':11,'font-weight':700,fill:i===k?C.a2:'#7a8794'})});
 var n=['4','2','3','cheksiz'];if(k>=0)T(g,[50,138,232,316][k],160,'o‘qlar: '+n[k],{'font-size':12,'font-weight':800,fill:C.ok})}
var Q9T4=[[1,1],[4,2],[2,5]];
function q9L(k){clear();var g=S.g;var L=[['A',40],['N',120],['T',200],['V',280]];L.forEach(function(l,i){E('text',{x:l[1]+20,y:118,'text-anchor':'middle','font-size':76,'font-weight':800,fill:i===k?(i===1?C.ok:C.bad):'#c3cbd4','font-family':'Arial,sans-serif'},g).textContent=l[0]});if(k===1){E('circle',{cx:140,cy:91,r:5,fill:C.bad},g);T(g,140,150,'markaz',{'font-size':11,'font-weight':800,fill:C.bad})}}
var Q9P8=[function(){q9H(0);q9msg('H harfi: tik o‘q bormi?')},function(){q9H(1);q9msg('Tik o‘q ham, yotiq o‘q ham bor — <b>2 ta o‘q</b>')},function(){q9H(2);q9msg('Markaz atrofida 180° bursak ham o‘zgarmaydi — <b>markaziy simmetriya</b> ham bor')}];
function q9H(k){clear();var g=S.g;function R(x,y,w,h){E('rect',{x:x,y:y,width:w,height:h,fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':2},g)}R(130,26,20,110);R(210,26,20,110);R(150,71,60,20);
 if(k>=1){E('line',{x1:180,y1:14,x2:180,y2:150,stroke:C.u,'stroke-width':2.5,'stroke-dasharray':'7 5'},g);E('line',{x1:110,y1:81,x2:250,y2:81,stroke:C.u,'stroke-width':2.5,'stroke-dasharray':'7 5'},g)}
 if(k>=2){E('circle',{cx:180,cy:81,r:6,fill:C.bad},g);E('path',{d:'M262 60 A 40 40 0 0 1 262 104',fill:'none',stroke:C.bad,'stroke-width':2.5},g);E('path',{d:'M262 104 l-8 -2 l6 -6 z',fill:C.bad},g);T(g,300,86,'180°',{'font-size':13,'font-weight':800,fill:C.bad})}}
var STEPS=[
{h:"O'q simmetriya: buklab ko'ramiz",sum:"Shakl to'g'ri chiziq bo'ylab buklanganda ikki yarmi ustma-ust tushsa, bu chiziq — simmetriya o'qi.",a:"m01",
 start:function(){startPh(Q9P1)},fin:function(){S.ph=2;Q9P1[2]()},
 html:"<p>Kapalak, barg, odam yuzi — chap va o'ng yarmi deyarli bir xil. Bunday shakllar <b>simmetrik</b> deyiladi. Varaqni buklab ko'ramiz.</p>",
 btns:[phaser(Q9P1)],
 after:"<p>Kesik chiziq — <b>simmetriya o'qi</b>. Mos nuqtalar: 1) o'qdan <b>bir xil uzoqlikda</b>; 2) ularni tutashtiruvchi kesma o'qqa <b>perpendikular</b>. Shakl o'lchami o'zgarmaydi, faqat «ko'zgu»dagidek teskari bo'ladi.</p>",
 q:{t:"A nuqta simmetriya o'qidan chapda 3 katak uzoqlikda. Uning simmetrigi A₁ qayerda?",opts:["O'qdan o'ngda 3 katak","O'qdan o'ngda 6 katak","O'qning ustida","O'qdan chapda 3 katak"],ok:0,why:"Simmetrik nuqtalar o'qdan bir xil uzoqlikda, qarama-qarshi tomonda.",hint:"Buklasak, A qayerga tushadi?",full:"Buklanganda A o'qning narigi tomoniga, xuddi shu 3 katak uzoqlikka tushadi. 6 katak — A dan A₁ gacha bo'lgan masofa, o'qdan emas."},
 tn:"Qog'ozni buklab, bukilgan joyga bo'yoq tomizib qayta yoying — «kapalak» chiqadi. Bu o'q simmetriyani qo'l bilan his qildiradi."},
{h:"Simmetriya o'qlari soni",sum:"Kvadratda 4 ta, to'g'ri to'rtburchakda 2 ta, teng tomonli uchburchakda 3 ta, doirada cheksiz ko'p o'q.",a:"m02",
 start:function(){q9shape(-1);q9msg('Har bir shaklni bosib, o‘qlarini ko‘ring')},fin:function(){q9shape(1);q9msg('To‘rtburchakning diagonali o‘q <b>emas</b>!')},
 btns:[["Kvadrat",function(c,done){q9shape(0);q9msg('Kvadrat: 2 ta o‘rta chiziq + 2 ta diagonal = <b>4</b>');mvK(done,4)}],["To'rtburchak",function(c,done){q9shape(1);q9msg('To‘g‘ri to‘rtburchak: faqat <b>2</b>. Diagonal bo‘yicha buklasak, ustma-ust tushmaydi');mvK(done,4)}],["Uchburchak",function(c,done){q9shape(2);q9msg('Teng tomonli uchburchak: har bir uchidan — <b>3</b>');mvK(done,4)}],["Doira",function(c,done){q9shape(3);q9msg('Doira: markazdan o‘tgan har bir to‘g‘ri chiziq — <b>cheksiz ko‘p</b>');mvK(done,4)}]],g2:1,
 html:"<p>Shakllarning simmetriya o'qlari nechta? To'rttala tugmani bosing.</p>",
 after:"<p>Kvadrat — <b>4</b>, to'g'ri to'rtburchak — <b>2</b> (diagonallari o'q emas!), teng tomonli uchburchak — <b>3</b>, doira — <b>cheksiz ko'p</b>. Eng ko'p xato: to'rtburchakning diagonalini o'q deb sanash.</p>",
 q:{t:"Eni 3 sm, bo'yi 5 sm bo'lgan to'g'ri to'rtburchakning nechta simmetriya o'qi bor?",opts:["2","4","1","0"],ok:0,why:"Faqat ikki o'rta chiziq. Diagonallar o'q emas.",hint:"Diagonal bo'yicha buklasak, burchaklar ustma-ust tushadimi?",full:"Ikki o'rta chiziq bo'yicha buklasak, ustma-ust tushadi — 2 ta o'q. Diagonal bo'yicha buklasak, burchaklar chiqib qoladi, shuning uchun 4 emas."},
 tn:"Qog'ozdan to'g'ri to'rtburchak qirqib, diagonal bo'yicha buklashni sinab ko'rsating — ustma-ust tushmaydi. Kvadrat bilan esa tushadi."},
{h:"Nuqtaning simmetrigini yasang",sum:"Tik o'qqa nisbatan simmetrik nuqtada y o'zgarmaydi, o'qgacha masofa saqlanadi.",a:"m03",
 start:function(){q9grid({tap:q9t3,ax:[[5,0,5,6]],pts:[[2,3,'A',C.bad,-16,-8]]});q9msg('A ning o‘qqa nisbatan simmetrigi A₁ ni bosing')},fin:function(){q9grid({ax:[[5,0,5,6]],segs:[[2,3,8,3,C.bad,1]],pts:[[2,3,'A',C.bad,-16,-8],[8,3,'A₁',C.ok]]});q9msg('✓ A o‘qdan 3 katak chapda, A₁ — 3 katak o‘ngda')},
 act:function(c,done){S.d3=done},
 html:"<p>Kesik chiziq — simmetriya o'qi. <b>A</b> nuqtaning simmetrigi <b>A₁</b> ni to'rdan toping va bosing.</p>",
 after:"<p>A o'qdan <b>3</b> katak chapda. A₁ — xuddi shu qatorda, o'qdan <b>3</b> katak o'ngda. AA₁ kesma o'qqa perpendikular va o'q uni teng ikkiga bo'ladi.</p>",
 q:{t:"O'q tik. B nuqta o'qdan 4 katak o'ngda va 2 katak yuqorida (o'qning pastki uchidan). B₁ qayerda?",opts:["O'qdan 4 katak chapda, 2 katak yuqorida","O'qdan 4 katak chapda, 2 katak pastda","O'qdan 2 katak chapda, 4 katak yuqorida","O'qning ustida"],ok:0,why:"Tik o'qda balandlik saqlanadi, tomoni almashadi.",hint:"Tik o'q bo'ylab buklaganda nuqta yuqoriga yoki pastga siljiydimi?",full:"Tik o'q bo'ylab buklaganda nuqta faqat chap-o'ngga o'tadi: o'qdan 4 katak chapda, balandligi esa o'sha-o'sha 2 katak."},
 tn:"Ko'zgu o'yini: bir bola o'ng qo'lini ko'taradi, «ko'zgu» bolasi qaysi qo'lini ko'tarishi kerak? (chapini)."},
{h:"Shaklning simmetrigi (tuzoq)",sum:"Shaklning simmetrigini yasash uchun har bir uchining simmetrigini topib, tutashtiramiz.",a:"m04",
 start:function(){q9grid({tap:q9t4,ax:[[5,0,5,6]],polys:[[Q9T4]],pts:[[9,1,'',C.ok],[6,2,'',C.ok],[1,1,'A',C.a2,-14,-6],[4,2,'B',C.a2,-14,-6],[2,5,'C',C.a2,-14,-2]]});q9msg('A₁ va B₁ tayyor. <b>C₁</b> ni bosing')},fin:function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9T4],[q9mir(Q9T4),'rgba(18,163,159,.2)',C.u]],pts:[[8,5,'C₁',C.ok]]});q9msg('✓ C o‘qdan 3 katak chapda → C₁ 3 katak o‘ngda: (8; 5)')},
 act:function(c,done){S.d4=done},
 html:"<p>ABC uchburchakning o'qqa nisbatan simmetrigini yasaymiz. A₁ va B₁ yashil bilan belgilangan. Endi <b>C₁</b> ni bosing.</p>",
 after:"<p>C nuqta o'qdan <b>3</b> katak chapda va 5 katak balandlikda. C₁ — o'qdan <b>3</b> katak o'ngda, xuddi shu balandlikda. Uchlarini tutashtirsak, ko'zgudagi uchburchak chiqadi. Tuzoq: C ni shunchaki o'ngga «siljitish» (9; 5) — bu simmetriya emas.</p>",
 q:{t:"Uchburchakning o'qqa eng yaqin uchi o'qdan 1 katak, eng uzoq uchi 4 katak uzoqda. Simmetrik uchburchakda bu uchlar o'qdan qancha uzoqda?",opts:["1 va 4 katak","4 va 1 katak","5 va 5 katak","2 va 8 katak"],ok:0,why:"Har bir nuqta o'z masofasini saqlaydi.",hint:"Simmetriyada har bir nuqtaning o'qgacha masofasi o'zgaradimi?",full:"Har bir uch o'qgacha masofasini saqlaydi: yaqini 1 katak, uzog'i 4 katak. «4 va 1» — ko'chirish emas, buklash ekanini unutish."},
 tn:"Doskada shaklni yasashda «har bir uch alohida» qoidasini ovoz chiqarib takrorlating: «C — 3 chapda, C₁ — 3 o'ngda»."},
{h:"Yotiq o'qqa nisbatan",sum:"Yotiq o'qqa nisbatan simmetriyada nuqta yuqori-pastga o'tadi, gorizontal joyi saqlanadi.",a:"m05",
 start:function(){q9grid({tap:q9t5,ax:[[0,3,10,3]],pts:[[4,5,'P',C.bad]]});q9msg('O‘q yotiq. P ning simmetrigi P₁ ni bosing')},fin:function(){q9grid({ax:[[0,3,10,3]],segs:[[4,5,4,1,C.bad,1]],pts:[[4,5,'P',C.bad],[4,1,'P₁',C.ok]]});q9msg('✓ P o‘qdan 2 yuqorida → P₁ 2 pastda')},
 act:function(c,done){S.d5=done},
 html:"<p>Endi simmetriya o'qi <b>yotiq</b>. Suv yuzasidagi aks kabi. <b>P</b> ning simmetrigi <b>P₁</b> ni bosing.</p>",
 after:"<p>P o'qdan <b>2</b> katak yuqorida, P₁ — <b>2</b> katak pastda, xuddi shu tik chiziqda. Ko'ldagi daraxtning aksi ham shunday: daraxt uchi suvdan qancha balandda bo'lsa, aksining uchi shuncha chuqurda ko'rinadi.</p>",
 q:{t:"Yotiq o'q y = 3 da. Q(6; 6) nuqtaning simmetrigi?",opts:["(6; 0)","(0; 6)","(6; 3)","(6; 9)"],ok:0,why:"Q o'qdan 3 yuqorida, Q₁ 3 pastda: y = 0.",hint:"Q o'qdan qancha yuqorida?",full:"Q o'qdan 6 − 3 = 3 katak yuqorida, demak Q₁ 3 katak pastda: y = 3 − 3 = 0, x o'zgarmaydi — (6; 0). (6; 9) — teskari tomonga emas, yuqoriga ko'chirish."},
 tn:"Ko'l bo'yidagi manzara rasmini ko'rsating (yoki stakan suvga qalam tushiring) — aks yotiq o'qqa nisbatan simmetrik."},
{h:"Markaziy simmetriya",sum:"O markazga nisbatan simmetrik nuqta: A dan O ga qanday borsak, O dan A₁ ga ham xuddi shunday boramiz.",a:"m06",
 start:function(){q9grid({tap:q9t6,pts:[[2,1,'A',C.bad,-14,-6],[5,3,'O',C.u,10,4]]});q9msg('A ning O nuqtaga nisbatan simmetrigini bosing')},fin:function(){q9grid({segs:[[2,1,8,5,C.bad,1]],pts:[[2,1,'A',C.bad,-14,-6],[5,3,'O',C.u,10,10],[8,5,'A₁',C.ok]]});q9msg('✓ A→O: o‘ngga 3, yuqoriga 2. O→A₁: yana o‘ngga 3, yuqoriga 2')},
 act:function(c,done){S.d6=done},
 html:"<p>Endi o'q emas, <b>nuqta</b> — markaz. A nuqtadan O orqali to'g'ri chiziq bo'ylab yurib, O dan xuddi shuncha narida A₁ ni bosing.</p>",
 after:"<p>A dan O ga: o'ngga 3, yuqoriga 2. O dan A₁ ga ham <b>xuddi shunday</b>: A₁(8; 5). O — AA₁ kesmaning <b>o'rtasi</b>. Markaziy simmetriya — shaklni markaz atrofida <b>180°</b> burish (yarim aylanish) bilan bir xil.</p>",
 q:{t:"O markaz (4; 4), B(1; 2). B ning O ga nisbatan simmetrigi?",opts:["(7; 6)","(4; 2)","(7; 2)","(3; 2)"],ok:0,why:"B→O: o'ngga 3, yuqoriga 2. O dan yana shunday: (7; 6).",hint:"B dan O ga qanday boriladi? Shu yo'lni O dan takrorlang.",full:"B(1; 2) → O(4; 4): o'ngga 3, yuqoriga 2. O dan yana o'ngga 3, yuqoriga 2: (7; 6). (7; 2) — faqat gorizontal bo'yicha ko'chirish, bu tik o'qqa nisbatan simmetriya bo'lardi."},
 tn:"Daftarni stolda markazidan barmoq bilan bosib, 180° buring — chap pastdagi rasm o'ng yuqoriga o'tadi."},
{h:"Qaysi harf markaziy simmetrik?",sum:"N, S, Z harflari markaziy simmetrik, lekin o'q simmetriyasi yo'q.",a:"m07",
 start:function(){q9L(-1);q9msg('Qaysi harf 180° burilganda o‘zgarmaydi, lekin o‘qi yo‘q?')},fin:function(){q9L(1);q9msg('✓ N: markaz atrofida 180° bursak — yana N. Lekin buklasak ustma-ust tushmaydi')},
 btns:[["A",function(c,done){q9L(0);q9msg('A — tik o‘qi bor, lekin 180° bursak teskari «∀» bo‘ladi')}],["N",function(c,done){STEPS[6].fin();done()}],["T",function(c,done){q9L(2);q9msg('T — tik o‘qi bor, 180° burilganda «⊥» bo‘ladi')}],["V",function(c,done){q9L(3);q9msg('V — tik o‘qi bor, 180° burilganda «Λ» bo‘ladi')}]],g2:1,
 html:"<p>Qaysi harf <b>markaziy simmetrik</b> (180° burilganda o'zgarmaydi), lekin <b>simmetriya o'qi yo'q</b>?</p>",
 after:"<p><b>N</b> harfini markazi atrofida 180° bursangiz, yana N chiqadi — u markaziy simmetrik. Lekin uni buklab ikki yarmini ustma-ust tushirib bo'lmaydi. A, T, V esa aksincha: o'qi bor, markaziy simmetriyasi yo'q. Bu ikki simmetriya — <b>har xil</b> narsalar.</p>",
 q:{t:"Qaysi raqam markaziy simmetrik (180° burilganda o'zgarmaydi)?",opts:["8","3","7","4"],ok:0,why:"8 ni 180° bursak, yana 8.",hint:"Raqamni teskari qilib (boshini pastga) ko'ring.",full:"8 — 180° burilganda yana 8. 3 ning gorizontal o'qi bor, lekin 180° burilganda «Ɛ» bo'ladi. 7 va 4 da hech qanday simmetriya yo'q."},
 tn:"Harf kartochkalarini bolalarga bering: «teskari aylantirganda o'zgarmaydiganlarini» bir guruhga, «buklasa ustma-ust tushadiganlarini» boshqa guruhga ajratsin."},
{h:"Ikkala simmetriya birga",sum:"Ikki perpendikular simmetriya o'qi bor shakl, albatta, markaziy simmetrik ham bo'ladi (H, O, X, kvadrat).",a:"m08",
 start:function(){startPh(Q9P8)},fin:function(){S.ph=2;Q9P8[2]()},
 html:"<p>H harfida nechta simmetriya bor? Bosqichma-bosqich ko'ring.</p>",
 btns:[phaser(Q9P8)],
 after:"<p>H da <b>tik</b> va <b>yotiq</b> o'q bor. Ikki o'q kesishgan nuqta — <b>simmetriya markazi</b>: 180° bursak ham H o'zgarmaydi. Qoida: shaklda o'zaro perpendikular <b>ikki</b> o'q bo'lsa, u markaziy simmetrik ham bo'ladi. Kvadrat, to'g'ri to'rtburchak, doira — shular jumlasidan.</p>",
 q:{t:"Qaysi shaklda o'q simmetriya ham, markaziy simmetriya ham bor?",opts:["To'g'ri to'rtburchak","Teng tomonli uchburchak","N harfi","Yurak shakli"],ok:0,why:"To'g'ri to'rtburchakda 2 ta perpendikular o'q bor — u markaziy simmetrik ham.",hint:"Shaklni 180° burib ko'ring.",full:"To'g'ri to'rtburchakda 2 ta perpendikular o'q, ular kesishgan joy — markaz. Teng tomonli uchburchakda 3 ta o'q bor, lekin 180° burilganda boshi pastga qaraydi — markaziy simmetriya yo'q. N — faqat markaziy, yurak — faqat o'q."},
 tn:"Mavzu oxirida jadval tuzing: «Faqat o'q», «Faqat markaz», «Ikkalasi», «Hech biri» — bolalar shakl va harflarni joylashtirsin."},
{h:"Bilasizmi? Tabiatdagi simmetriya",sum:"Qor parchasining 6 ta simmetriya o'qi bor; o'zbek naqshlari ham simmetriyaga asoslangan.",a:"m09",
 start:function(){q9shape(3);q9msg('Doira — cheksiz o‘q. Qor parchasi — 6 ta')},fin:function(){q9shape(3);q9msg('Doira — cheksiz o‘q. Qor parchasi — 6 ta')},
 html:"<p>❄ Har bir qor parchasi olti burchakli bo'lib o'sadi — uning <b>6 ta</b> simmetriya o'qi bor. Bunga suv molekulalarining muzlaganda olti burchakli tartibda joylashishi sabab.</p><p>🕌 Samarqand va Buxoro me'morchiligidagi <b>girih</b> naqshlari, gilam va so'zana bezaklari o'q va markaziy simmetriya qoidalari asosida chiziladi.</p><p>🦋 Kapalak, ko'p barglar va odam tanasi tashqi ko'rinishda deyarli o'q simmetriyaga ega.</p>",
 tn:"Bolalar qog'ozni 3 marta buklab, qirqib «qor parchasi» yasasin — ochganda simmetriyani ko'radi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9T4],[q9mir(Q9T4),'rgba(18,163,159,.2)',C.u]]});q9msg('Har bir uch — o‘qdan bir xil uzoqlikda, narigi tomonda')},fin:function(){q9grid({ax:[[5,0,5,6]],polys:[[Q9T4],[q9mir(Q9T4),'rgba(18,163,159,.2)',C.u]]});q9msg('Har bir uch — o‘qdan bir xil uzoqlikda, narigi tomonda')},
 html:"<div class='memo'><ul><li><b>O'q simmetriya</b>: buklaganda ustma-ust tushadi; mos nuqtalar o'qdan bir xil uzoqlikda, tutashtiruvchi kesma o'qqa perpendikular.</li><li>O'qlar soni: kvadrat 4, to'g'ri to'rtburchak 2, teng tomonli uchburchak 3, doira — cheksiz.</li><li>Shaklning simmetrigi — har bir uchini alohida aks ettirib tutashtiramiz.</li><li>Tik o'q: balandlik saqlanadi. Yotiq o'q: gorizontal joy saqlanadi.</li><li><b>Markaziy simmetriya</b>: O — AA₁ ning o'rtasi; 180° burish.</li><li>N, S, Z — faqat markaziy; A, T, V — faqat o'q; H, O, X — ikkalasi.</li></ul></div>",
 tn:"Uyga: katakli daftarda o'z ismingizning birinchi harfini chizib, uning simmetrigini (tik o'qqa nisbatan) yasash."}
];
function q9t3(x,y){if(x===8&&y===3){STEPS[2].fin();if(S.d3){var d=S.d3;S.d3=null;d()}}else if(S.d3){q9grid({tap:q9t3,ax:[[5,0,5,6]],pts:[[2,3,'A',C.bad,-16,-8],[x,y,'?',C.grey]]});q9msg(y!==3?'Balandlik o‘zgarmasligi kerak: A bilan bir qatorda':(x===5?'Bu o‘qning o‘zi. A₁ narigi tomonda':'O‘qgacha masofa: A da 3, bu nuqtada '+Math.abs(x-5)))}}
function q9t4(x,y){if(x===8&&y===5){STEPS[3].fin();if(S.d4){var d=S.d4;S.d4=null;d()}}else if(S.d4){q9grid({tap:q9t4,ax:[[5,0,5,6]],polys:[[Q9T4]],pts:[[9,1,'',C.ok],[6,2,'',C.ok],[1,1,'A',C.a2,-14,-6],[4,2,'B',C.a2,-14,-6],[2,5,'C',C.a2,-14,-2],[x,y,'?',C.grey]]});q9msg(x===9&&y===5?'Tuzoq! Bu C ni o‘ngga siljitish. C o‘qdan 3 katak chapda — C₁ 3 katak o‘ngda':'C o‘qdan 3 katak chapda, 5-qatorda. C₁ — o‘qdan 3 katak o‘ngda, shu qatorda')}}
function q9t5(x,y){if(x===4&&y===1){STEPS[4].fin();if(S.d5){var d=S.d5;S.d5=null;d()}}else if(S.d5){q9grid({tap:q9t5,ax:[[0,3,10,3]],pts:[[4,5,'P',C.bad],[x,y,'?',C.grey]]});q9msg(x!==4?'P₁ P bilan bir tik chiziqda bo‘ladi':'P o‘qdan 2 yuqorida. P₁ o‘qdan 2 pastda')}}
function q9t6(x,y){if(x===8&&y===5){STEPS[5].fin();if(S.d6){var d=S.d6;S.d6=null;d()}}else if(S.d6){q9grid({tap:q9t6,pts:[[2,1,'A',C.bad,-14,-6],[5,3,'O',C.u,10,4],[x,y,'?',C.grey]]});q9msg(x===8&&y===1?'Bu tik o‘qqa nisbatan simmetriya bo‘lardi. A, O, A₁ bitta to‘g‘ri chiziqda yotadi':'A→O: o‘ngga 3, yuqoriga 2. O dan ham shunday yuring')}}
var PROBS=[
{t:"Kvadratning nechta simmetriya o'qi bor?",o:["4","2","1","8"],k:0,s:"2 ta o'rta chiziq va 2 ta diagonal."},
{t:"Teng tomonli uchburchakning nechta simmetriya o'qi bor?",o:["3","1","6","0"],k:0,s:"Har bir uchidan qarshi tomon o'rtasiga — 3 ta."},
{t:"Qaysi shaklning simmetriya o'qlari cheksiz ko'p?",o:["Doira","Kvadrat","Olti burchak","Romb"],k:0,s:"Doiraning markazidan o'tgan har bir chiziq — o'q."},
{t:"Qaysi harfning tik simmetriya o'qi bor?",o:["M","F","L","G"],k:0,s:"M ning chap va o'ng yarmi bir xil."},
{t:"Qaysi harfning faqat yotiq simmetriya o'qi bor?",o:["B","A","H","N"],k:0,s:"B — yuqori va pastki yarmi bir xil. H ning ikkala o'qi bor."},
{t:"Tik o'q x = 5 da. A(1; 4) nuqtaning simmetrigi?",o:["(9; 4)","(1; 6)","(5; 4)","(4; 1)"],k:0,s:"A o'qdan 4 chapda, A₁ 4 o'ngda: 5 + 4 = 9."},
{t:"Tik o'q x = 4 da. B(7; 2) nuqtaning simmetrigi?",o:["(1; 2)","(7; 6)","(3; 2)","(11; 2)"],k:0,s:"B o'qdan 3 o'ngda, B₁ 3 chapda: 4 − 3 = 1."},
{t:"Yotiq o'q y = 2 da. C(3; 4) nuqtaning simmetrigi?",o:["(3; 0)","(3; 6)","(0; 4)","(3; 2)"],k:0,s:"C o'qdan 2 yuqorida, C₁ 2 pastda: (3; 0)."},
{t:"Yotiq o'q y = 3 da. D(2; 4) nuqtaning simmetrigi?",o:["(2; 2)","(4; 2)","(2; 3)","(2; 5)"],k:0,s:"D o'qdan 1 yuqorida, D₁ 1 pastda: (2; 2)."},
{t:"O(5; 5) markazga nisbatan A(3; 4) ning simmetrigi?",o:["(7; 6)","(7; 4)","(3; 6)","(8; 9)"],k:0,s:"A→O: o'ngga 2, yuqoriga 1. O dan yana: (7; 6)."},
{t:"O — AB kesmaning o'rtasi. A(2; 1), O(4; 3). B qayerda?",o:["(6; 5)","(6; 3)","(2; 5)","(8; 6)"],k:0,s:"A→O: (+2; +2). O→B: (6; 5)."},
{t:"Qaysi harf markaziy simmetrik?",o:["S","E","K","Y"],k:0,s:"S — 180° burilganda yana S."},
{t:"Qaysi harfda o'q simmetriya ham, markaziy simmetriya ham bor?",o:["X","N","Z","T"],k:0,s:"X: ikki o'q va markaz."},
{t:"Qaysi raqam 180° burilganda 6 raqamiga aylanadi?",o:["9","6","3","8"],k:0,s:"9 ni boshini pastga qilsak — 6."},
{t:"To'g'ri to'rtburchak markaz atrofida 180° burildi. Nima bo'ladi?",o:["O'z ustiga tushadi","90° ga burilgan holda turadi","Teskari bo'lib, ustma-ust tushmaydi","Kattalashadi"],k:0,s:"To'g'ri to'rtburchak markaziy simmetrik."},
{t:"Shakl uchlari (1; 1), (3; 1), (3; 4). Tik o'q x = 5 ga nisbatan simmetrik shakl uchlari?",o:["(9; 1), (7; 1), (7; 4)","(1; 9), (3; 9), (3; 6)","(6; 1), (8; 1), (8; 4)","(9; 9), (7; 9), (7; 6)"],k:0,s:"x → 10 − x: 9, 7, 7; y saqlanadi."},
{t:"Eni 4 sm, bo'yi 6 sm bo'lgan to'g'ri to'rtburchakning simmetriya o'qlari (shakl ichidagi qismi)?",o:["2 ta: 4 sm va 6 sm","4 ta","2 ta: ikkalasi 6 sm","1 ta: 6 sm"],k:0,s:"O'rta chiziqlar: biri enga, biri bo'yga teng."},
{t:"Ko'zguda soat 3:00 ni ko'rsatayotgandek ko'rinadi. Aslida soat necha?",o:["9:00","3:00","6:00","12:00"],k:0,s:"Ko'zgu tik o'qqa nisbatan aks ettiradi: o'ngdagi 3 chapdagi 9 ga o'tadi."},
{t:"Ko'zguda soat 2:00 ko'rinadi. Aslida soat necha?",o:["10:00","2:00","8:00","4:00"],k:0,s:"12 − 2 = 10."},
{t:"«OTA» so'zini tik ko'zguga tutdik. Ko'zguda qanday o'qiladi (bosma harflar)?",o:["ATO","OTA","TOA","AOT"],k:0,s:"Ko'zgu tartibni teskari qiladi; O, T, A ning tik o'qi bor — harflarning o'zi o'zgarmaydi."},
];
function PRACT_STAGE(){q9grid({ax:[[5,0,5,6]],polys:[[Q9T4],[q9mir(Q9T4),'rgba(18,163,159,.2)',C.u]]})}
var PREP_DATA={teach:["O'q simmetriya: buklash, mos nuqtalar xossalari.","Shakllarning simmetriya o'qlari soni.","Tik va yotiq o'qqa nisbatan nuqta va shaklning simmetrigini yasash.","Markaziy simmetriya (180° burish); harf va raqamlar; ikkala simmetriya birga."],
 mist:["To'g'ri to'rtburchak diagonalini simmetriya o'qi deb sanaydi.","Simmetriya o'rniga shaklni siljitadi (parallel ko'chiradi).","Markaziy simmetriyada faqat bitta koordinatani o'zgartiradi.","O'q va markaziy simmetriyani aralashtiradi."],
 need:["Qog'oz varaqlari, qaychi, bo'yoq.","Kichik ko'zgu.","Katakli daftar.","Harf kartochkalari."],
 board:["Simmetriya o'qi — buklash chizig'i.","Kvadrat 4, to'rtburchak 2, uchburchak 3, doira ∞.","A(2; 3) → A₁(8; 3) (o'q x = 5).","P(4; 5) → P₁(4; 1) (o'q y = 3).","Markaz: A→O = O→A₁.","N, S, Z — markaziy; H, O, X — ikkalasi."]};
