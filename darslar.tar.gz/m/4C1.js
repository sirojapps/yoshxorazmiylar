var CODE='4C1',TITLE='4-sinf · Bir xonali songa ko‘paytirish';
var P1=[function(){W3eq(['2 143 · 3 = ?']);W3msg('Ko‘p xonali sonni xona qo‘shiluvchilariga ajratamiz')},
 function(){W3area([2000,100,40,3],3,{lbl:'2 143 = 2000 + 100 + 40 + 3'})},
 function(){W3area([2000,100,40,3],3,{show:1,lbl:'Har bo‘lakni 3 ga'})},
 function(){W3area([2000,100,40,3],3,{show:2,lbl:'6000 + 300 + 120 + 9 = 6429'});W3msg('2 143 · 3 = <b>6 429</b>','Har xonani alohida ko‘paytirib, qo‘shdik')}];
var P2=[function(){C4col(['.3476','×...4','─────'],'Ustunda: birliklardan boshlaymiz')},
 function(){C4col(['.3476','×...4','─────','....[4]'],'6 · 4 = 24: <b>4</b> yozamiz, <b>2</b> o‘nlik xotirada',null,{carry:[[1,2]]})},
 function(){C4col(['.3476','×...4','─────','...[0]4'],'7 · 4 = 28, + 2 = 30: <b>0</b> yozamiz, <b>3</b> xotirada',null,{carry:[[2,3]]})},
 function(){C4col(['.3476','×...4','─────','..[9]04'],'4 · 4 = 16, + 3 = 19: <b>9</b> yozamiz, <b>1</b> xotirada',null,{carry:[[3,1]]})},
 function(){C4col(['.3476','×...4','─────','{13904}'],'3 · 4 = 12, + 1 = 13: <b>13</b> ni to‘liq yozamiz. Javob: <b>13 904</b>')}];
var P4=[function(){C4col(['.30405','×....7','──────'],'Ikki joyda nol bor. Birliklardan boshlaymiz')},
 function(){C4col(['.30405','×....7','──────','.....[5]'],'5 · 7 = 35: 5 yozamiz, 3 xotirada')},
 function(){C4col(['.30405','×....7','──────','....[3]5'],'0 · 7 = 0, + 3 = <b>3</b> — nolga xotira tushdi')},
 function(){C4col(['.30405','×....7','──────','...[8]35'],'4 · 7 = 28: 8 yozamiz, 2 xotirada')},
 function(){C4col(['.30405','×....7','──────','..[2]835'],'0 · 7 = 0, + 2 = <b>2</b>')},
 function(){C4col(['.30405','×....7','──────','{212835}'],'3 · 7 = 21. Javob: <b>212 835</b>')}];
var P8=[function(){W3eq(['4 999 · 5 = ?']);W3msg('Ustunda ko‘p ko‘chirish bor. Qulayroq yo‘l bormi?')},
 function(){W3eq(['4 999 = 5 000 − 1']);W3msg('4 999 — yaxlit songa juda yaqin')},
 function(){W3eq(['5 000 · 5 = 25 000','1 · 5 = 5','25 000 − 5 = [24 995]']);W3msg('4 999 · 5 = 5 000 · 5 − 1 · 5 = <b>24 995</b>','Yaxlitlab, keyin ortiqchasini ayiramiz')}];
var STEPS=[
{h:"Xonalarga ajratib ko'paytirish",sum:"2 143 · 3 = 6000 + 300 + 120 + 9 = 6 429.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Ko'p xonali sonni bir xonali songa ko'paytirish — aslida bir nechta oson ko'paytirish. Tugmani bosib kuzating.</p>",btns:[phaser(P1)],
 after:"<p>Har bir xona birligini alohida ko'paytirib, natijalarni qo'shamiz. Bu — <b>ko'paytirishning qo'shishga nisbatan taqsimot xossasi</b>: (2000 + 100 + 40 + 3) · 3.</p>",
 q:{t:"3 021 · 4 = ?",opts:["12 084","12 804","1 284","12 024"],ok:0,why:"12 000 + 0 + 80 + 4.",hint:"3000 · 4, 20 · 4 va 1 · 4 ni qo'shing.",full:"3 021 = 3000 + 20 + 1. 3000 · 4 = 12 000, 20 · 4 = 80, 1 · 4 = 4. Jami 12 084. «1 284» — 3000 dagi nollar yo'qolgan, «12 804» — 80 noto'g'ri xonaga yozilgan."},
 tn:"Singapur maydon modeli: daftarga uzun to'g'ri to'rtburchak chizib, 4 bo'lakka bo'ling. Bolalar har bo'lak ichiga ko'paytmani yozsin."},
{h:"Ustun usuli: xotiraga olish",sum:"3 476 · 4 = 13 904: har xonada ko'paytirib, xotiradagini qo'shamiz.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=4;P2[4]()},
 html:"<p>Maydon modelidagi bo'laklarni ustunda qisqa yozamiz. Ko'paytma 10 dan oshsa, o'nligi <b>keyingi xonaga</b> ko'chadi.</p>",btns:[phaser(P2)],
 after:"<p>Tartib: <b>ko'paytir → xotiradagini qo'sh → birligini yoz → o'nligini xotiraga ol</b>. Xotiradagi raqamni ustiga kichik qilib yozib qo'ying — unutilmaydi.</p>",
 q:{t:"2 657 · 3 = ?",opts:["7 971","7 961","7 871","6 971"],ok:0,why:"21 → 1 (2), 15 + 2 = 17 → 7 (1), 18 + 1 = 19 → 9 (1), 6 + 1 = 7.",hint:"Birliklardan boshlang: 7 · 3 = 21.",full:"7 · 3 = 21: 1 yoziladi, 2 xotirada. 5 · 3 = 15, + 2 = 17: 7 yoziladi, 1 xotirada. 6 · 3 = 18, + 1 = 19: 9, 1 xotirada. 2 · 3 = 6, + 1 = 7. Javob 7 971. «6 1521» — ko'paytmalar yonma-yon yozilgan."},
 tn:"Xotiradagi raqamni ko'paytirishdan OLDIN qo'shib qo'yish xatosi ko'p uchraydi (7 + 2 = 9, 9 · 4). Tartibni ovoz chiqarib aytdiring: «avval ko'paytiraman, keyin qo'shaman»."},
{h:"Tuzoq: xotira unutildi",sum:"2 058 · 6 = 12 348; xotira unutilsa 12 008 chiqadi.",a:"m03",start:function(){C4col(['.2058','×...6','─────','.?????'],'Qaysi javob to‘g‘ri? Bosib tanlang')},fin:function(){C4col(['.2058','×...6','─────','{12348}'])},
 html:"<p><b>2 058 · 6</b>. Bir bola 12 008, boshqasi 1 548 deb topdi. To'g'risini tanlang:</p>",
 btns:[["12 348",function(c,done){C4col(['.2058','×...6','─────','{12348}'],'48 → 8 (4); 30 + 4 = 34 → 4 (3); 0 + 3 = <b>3</b>; 12. Javob <b>12 348</b>');done()}],["12 008",function(){C4col(['.2058','×...6','─────','[12008]'],'Bu bola xotiradagi 4 va 3 ni qo‘shmagan. 5 · 6 = 30 ga 4 qo‘shilishi kerak edi','Qayta tanlang')}],["1 548",function(){C4col(['..258','×...6','─────','.[1548]'],'Bu — 258 · 6. Bola 0 ni tashlab yuborgan: 2 058 ≠ 258','Qayta tanlang')}]],g3:1,
 after:"<p>Nol bor xonada ko'paytma 0, lekin <b>xotiradagi son unga qo'shiladi</b>: 0 · 6 + 3 = 3. Tekshirish uchun chamalang: 2 058 · 6 ≈ 2 000 · 6 = 12 000 — 1 548 juda kichik.</p>",
 q:{t:"4 076 · 5 = ?",opts:["20 380","20 030","2 380","20 350"],ok:0,why:"30 → 0 (3); 35 + 3 = 38 → 8 (3); 0 + 3 = 3; 20.",hint:"6 · 5 = 30 dan boshlang.",full:"6 · 5 = 30: 0 yoziladi, 3 xotirada. 7 · 5 = 35, + 3 = 38: 8, 3 xotirada. 0 · 5 + 3 = 3. 4 · 5 = 20. Javob 20 380. «20 030» — xotiralar unutilgan, «2 380» — 0 tashlangan."},
 tn:"Xatoli ishlarni doskaga yozib, «Detektiv»: bola xatoni topib, bolaning qaysi qadamda adashganini aytsin."},
{h:"O'rtasida nollar",sum:"30 405 · 7 = 212 835.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=5;P4[5]()},
 html:"<p><b>30 405 · 7</b> — har bosishda bitta xona. Nol turgan xonalarga e'tibor bering!</p>",
 btns:[phaser(P4)],
 after:"<p>Nol turgan xonaga ko'paytmada <b>xotiradagi son</b> tushadi. Xotira bo'lmasa — 0 yoziladi: 20 301 · 3 = 60 903.</p>",
 q:{t:"50 208 · 4 = ?",opts:["200 832","200 032","20 832","200 822"],ok:0,why:"32 → 2 (3); 0 + 3 = 3; 8; 0; 20.",hint:"8 · 4 = 32 dan 3 xotiraga.",full:"8 · 4 = 32: 2, xotirada 3. 0 · 4 + 3 = 3. 2 · 4 = 8. 0 · 4 = 0. 5 · 4 = 20. Javob 200 832. «200 032» — xotira yo'qolgan, «20 832» — bitta 0 tashlangan."},
 tn:"Tugmalarni chapdan o'ngga emas, birliklardan boshlab bosish kerak — bola tartibni o'zi topadi."},
{h:"Chamalash: javob qancha atrofida?",sum:"4 987 · 6 ≈ 5 000 · 6 = 30 000; aniq javob 29 922.",a:"m05",start:function(){W3eq(['4 987 · 6 ≈ ?']);W3msg('Avval chamalaymiz: 4 987 ni yaxlitlang')},fin:function(){W3eq(['4 987 ≈ 5 000','5 000 · 6 = 30 000','4 987 · 6 = [29 922]'])},
 html:"<p>Hisoblashdan oldin javob <b>qancha atrofida</b> bo'lishini biling. Qaysi javob haqiqatga yaqin?</p>",
 btns:[["29 922",function(c,done){W3eq(['4 987 ≈ 5 000','5 000 · 6 = 30 000','4 987 · 6 = [29 922]']);W3msg('To‘g‘ri: 30 000 dan sal kam, chunki 4 987 &lt; 5 000');done()}],["2 992",function(){W3eq(['5 000 · 6 = 30 000','2 992 ≪ 30 000']);W3msg('Juda kichik — 10 marta kam!','Qayta tanlang')}],["299 922",function(){W3eq(['5 000 · 6 = 30 000','299 922 ≫ 30 000']);W3msg('Juda katta — 10 marta ko‘p!','Qayta tanlang')}]],g3:1,
 after:"<p>Chamalash — <b>xona xatosini</b> darhol ushlaydi. Javob chamadan 10 marta farq qilsa, qaysidir xona yo'qolgan yoki ortib ketgan.</p>",
 q:{t:"Qaysi javob 7 912 · 8 ga to'g'ri kelishi mumkin?",opts:["63 296","6 396","632 960","53 296"],ok:0,why:"≈ 8 000 · 8 = 64 000.",hint:"7 912 ≈ 8 000.",full:"7 912 · 8 ≈ 64 000. 6 396 va 632 960 — 10 marta xato. 53 296 — chama 64 000 dan uzoq (aniq: 2 · 8 = 16, oxirgi raqam 6 — lekin yuqori xonalar noto'g'ri). Aniq javob 63 296."},
 tn:"Har misoldan oldin «Mening chamam: …» deb doskaga yozdiring. Oxirida chama bilan aniq javobni solishtiring."},
{h:"Qulay usul: yaxlit songa yaqin",sum:"4 999 · 5 = 25 000 − 5 = 24 995.",a:"m06",start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Ba'zan ustun kerak emas — og'zaki tezroq.</p>",btns:[phaser(P8)],
 after:"<p>Son yaxlit songa yaqin bo'lsa: <b>yaxlit son bilan ko'paytirib, farqni ayiramiz</b>. 2 998 · 3 = 9 000 − 6 = 8 994.</p>",
 q:{t:"1 999 · 4 = ?",opts:["7 996","7 999","8 004","7 960"],ok:0,why:"8 000 − 4.",hint:"1 999 = 2 000 − 1.",full:"2 000 · 4 = 8 000, 1 · 4 = 4, 8 000 − 4 = 7 996. «7 999» — faqat 1 ayirilgan, lekin 1 ham 4 marta olinadi."},
 tn:"Bu — Yaponiya darsliklarida «moslashuvchan hisob» deb o'rgatiladi: bir misolni bir necha usulda hisoblab, eng qulayini tanlash."},
{h:"Tuzoq: yashirin raqam",sum:"1 3□5 · 4 = 5 500 → □ = 7, chunki 5 500 : 4 = 1 375.",a:"m07",start:function(){C4col(['.13□5','×...4','─────','.5500'],'Qaysi raqam yashiringan?')},fin:function(){C4col(['.13{7}5','×...4','─────','.5500'])},
 html:"<p><b>1 3□5 · 4 = 5 500</b>. Kvadratchaga qaysi raqam yoziladi?</p>",
 btns:[["7",function(c,done){C4col(['.13{7}5','×...4','─────','.5500'],'1 375 · 4: 20 → 0 (2); 28 + 2 = 30 → 0 (3); 12 + 3 = 15 → 5 (1); 4 + 1 = 5 ✓');done()}],["5",function(){C4col(['.13[5]5','×...4','─────','.5420'],'1 355 · 4 = 5 420 — 5 500 emas','Qayta tanlang')}],["8",function(){C4col(['.13[8]5','×...4','─────','.5540'],'1 385 · 4 = 5 540 — 5 500 emas','Qayta tanlang')}]],g3:1,
 after:"<p>Yashirin raqamni topishning ikki yo'li: <b>sinab ko'rish</b> yoki <b>teskari amal</b>: 5 500 : 4 = 1 375. Ko'paytirishni bo'lish bilan tekshirish — keyingi mavzularda ko'p kerak bo'ladi.</p>",
 q:{t:"□ 2 4 · 3 = 2 172. □ = ?",opts:["7","6","8","2"],ok:0,why:"724 · 3 = 2 172.",hint:"2 172 : 3 = ?",full:"Teskari amal: 2 172 : 3 = 724, demak □ = 7. Tekshiruv: 724 · 3 = 2 172. 624 · 3 = 1 872, 824 · 3 = 2 472."},
 tn:"Kriptarifm (raqamli jumboq) — mantiqiy fikrlashni o'stiradi. Bolalar bir-biriga o'zlari tuzib bersin."},
{h:"Masala: ko'p bosqichli",sum:"Bir haftada 1 250 · 7 = 8 750 ta; 4 haftada 35 000 ta.",a:"m08",start:function(){w3Bar([{lab:'1 kun',segs:[{w:1,t:'1 250',c:C.a}]},{lab:'7 kun',segs:[1,2,3,4,5,6,7].map(function(){return {w:1,t:'',c:C.b}}),br:'? ta'}],{top:30,gap:62,x0:62,W:270});W3msg('Fabrika kuniga 1 250 ta g‘isht chiqaradi')},fin:function(){w3Bar([{lab:'1 hafta',segs:[{w:1,t:'8 750',c:C.b}]},{lab:'4 hafta',segs:[1,2,3,4].map(function(){return {w:1,t:'8 750',c:C.c}}),br:'35 000'}],{top:30,gap:62,x0:62,W:270})},
 html:"<p>Fabrika kuniga <b>1 250</b> ta g'isht chiqaradi. <b>4 haftada</b> nechta g'isht chiqaradi?</p>",
 btns:[["1-qadam: 1 hafta",function(c,done,b){b.disabled=true;w3Bar([{lab:'1 kun',segs:[{w:1,t:'1 250',c:C.a}]},{lab:'7 kun',segs:[1,2,3,4,5,6,7].map(function(){return {w:1,t:'',c:C.b}}),br:'8 750'}],{top:30,gap:62,x0:62,W:270});W3msg('1 hafta = 7 kun: 1 250 · 7 = <b>8 750</b>')}],["2-qadam: 4 hafta",function(c,done){w3Bar([{lab:'1 hafta',segs:[{w:1,t:'8 750',c:C.b}]},{lab:'4 hafta',segs:[1,2,3,4].map(function(){return {w:1,t:'8 750',c:C.c}}),br:'35 000'}],{top:30,gap:62,x0:62,W:270});W3msg('8 750 · 4 = <b>35 000</b> ta g‘isht','Yoki: 4 hafta = 28 kun, 1 250 · 28');done()}]],
 after:"<p>Masalada <b>yashirin son</b> bor: «hafta» — 7 kun. Eng ko'p xato: 1 250 · 4 = 5 000 deb, kunni haftaga almashtirib yuborish.</p>",
 q:{t:"Do'kon kuniga 2 400 so'mlik non sotadi. 6 kunda necha so'm?",opts:["14 400","12 400","1 440","2 406"],ok:0,why:"2 400 · 6.",hint:"24 · 6 = 144.",full:"2 400 · 6 = 14 400 (24 · 6 = 144, ikkita 0). «1 440» — bitta 0 yo'qolgan, «2 406» — ko'paytirish o'rniga qo'shilgan."},
 tn:"Chizma model (Singapur): bolalar avval chizmani chizsin, keyin amalni tanlasin. «Nechta bo'lak — shuncha marta»."},
{h:"Bilasizmi? Birinchi bosma arifmetika",sum:"1478-yilda Italiyada bosilgan «Trevizo arifmetikasi» — Yevropadagi birinchi bosma arifmetika kitoblaridan biri; unda ustunda ko'paytirishning bir necha usuli bor.",a:"m09",start:function(){W3eq(['1478-yil · Trevizo','«Panjara» usuli'],{fs:20});W3msg('Ko‘paytirishning ko‘p usullari bo‘lgan')},fin:function(){STEPS[8].start()},
 html:"<p>📚 <b>1478-yilda</b> Italiyaning Trevizo shahrida nashr etilgan arifmetika kitobi — Yevropada bosilgan eng birinchi arifmetika kitoblaridan biri. Unda ko'paytirishning bir necha usuli ko'rsatilgan, jumladan katakchalarga yoziladigan <b>«panjara» usuli</b>.</p><p>⭐ Bugungi ustun usulimiz o'sha usullarning eng qisqasi bo'lib qolgan.</p>",
 tn:"Panjara usulini qiziqish uchun doskada bir marta ko'rsating: 34 · 6 — har katak o'z ko'paytmasini oladi, diagonal bo'yicha qo'shiladi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){C4col(['.3476','×...4','─────','{13904}'],'Ko‘paytir → xotirani qo‘sh → yoz → ko‘chir')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>2 143 · 3 = 6000 + 300 + 120 + 9 = 6 429 — xonalar bo'yicha.</li><li>Ustunda birliklardan boshlanadi; xotiradagi son <b>ko'paytmadan keyin</b> qo'shiladi.</li><li>Nol turgan xonaga xotiradagi son yoziladi: 2 058 · 6 = 12 348.</li><li>Avval chamalang: 4 987 · 6 ≈ 30 000.</li><li>Yaxlitga yaqin son: 4 999 · 5 = 25 000 − 5.</li><li>Masalada «hafta = 7 kun» kabi yashirin sonlarni unutmang.</li></ul></div>",
 tn:"Keyingi mavzu: ikki va uch xonali songa ko'paytirish — ustun usuli o'sha, faqat qatorlar ko'payadi."}
];
var PROBS=[
{t:"1 203 · 3 = ?",o:["3 609","3 690","369","3 600"],k:0,s:"3000 + 600 + 9."},
{t:"4 152 · 2 = ?",o:["8 304","8 314","8 204","83 104"],k:0,s:"8000 + 200 + 100 + 4."},
{t:"2 345 · 6 = ?",o:["14 070","12 070","14 060","1 470"],k:0,s:"30 → 0 (3); 24 + 3 = 27 → 7 (2); 18 + 2 = 20 → 0 (2); 12 + 2 = 14."},
{t:"6 789 · 7 = ?",o:["47 523","42 523","47 423","47 553"],k:0,s:"63 → 3 (6); 56 + 6 = 62 → 2 (6); 49 + 6 = 55 → 5 (5); 42 + 5 = 47."},
{t:"3 008 · 9 = ?",o:["27 072","27 702","2 772","27 008"],k:0,s:"72 → 2 (7); 0 + 7 = 7; 0; 27."},
{t:"40 506 · 8 = ?",o:["324 048","320 048","32 448","324 408"],k:0,s:"48 → 8 (4); 0 + 4 = 4; 40 → 0 (4); 0 + 4 = 4; 32."},
{t:"25 125 · 4 = ?",o:["100 500","100 050","10 500","100 400"],k:0,s:"25 000 · 4 = 100 000, 125 · 4 = 500."},
{t:"9 999 · 3 = ?",o:["29 997","29 999","30 003","29 990"],k:0,s:"30 000 − 3."},
{t:"Qaysi javob 6 103 · 5 ga to'g'ri kelishi mumkin?",o:["30 515","3 515","305 015","35 515"],k:0,s:"≈ 6 000 · 5 = 30 000."},
{t:"Bola 3 056 · 4 = 12 024 deb yozdi. To'g'ri javob?",o:["12 224","12 024","1 224","12 204"],k:0,s:"24 → 4 (2); 20 + 2 = 22 → 2 (2); 0 + 2 = 2; 12."},
{t:"□ 0 5 · 6 = 4 830. □ = ?",o:["8","7","9","4"],k:0,s:"4 830 : 6 = 805."},
{t:"2 4□6 · 3 = 7 458. □ = ?",o:["8","6","9","4"],k:0,s:"7 458 : 3 = 2 486."},
{t:"Bir kitob 12 500 so'm. 8 ta kitob necha so'm?",o:["100 000","96 000","10 000","12 508"],k:0,s:"12 500 · 8 = 100 000."},
{t:"Bir sutkada 1 440 minut. Bir haftada necha minut?",o:["10 080","1 440","7 080","10 008"],k:0,s:"1 440 · 7."},
{t:"Bir qopda 50 kg un. 2 ta qop 1 kunga yetadi. 9 kunda necha kg un kerak?",o:["900 kg","450 kg","100 kg","1 800 kg"],k:0,s:"2 · 50 = 100 kg kuniga; 100 · 9 = 900."},
{t:"Qaysi ko'paytma eng katta?",o:["2 505 · 4","3 333 · 3","1 999 · 5","4 990 · 2"],k:0,s:"10 020; 9 999; 9 995; 9 980."},
{t:"a · 7 = 21 049 bo'lsa, a · 14 = ?",o:["42 098","21 063","42 049","294 686"],k:0,s:"14 = 7 · 2: 21 049 · 2."},
{t:"Toq raqamli eng katta to'rt xonali sonni (barcha raqamlari har xil) 5 ga ko'paytiring.",o:["48 765","49 995","49 375","47 655"],k:0,s:"9 753 · 5 = 48 765."},
{t:"Qaysi ifoda 2 345 · 4 ga teng EMAS?",o:["2 345 · 2 + 2 345","2 345 · 2 · 2","2 000 · 4 + 345 · 4","9 380"],k:0,s:"2 345 · 2 + 2 345 = 2 345 · 3 = 7 035; qolganlari 9 380."},
{t:"Bir avtobus 1 kunda 3 marta 128 km yo'l yuradi. 5 kunda necha km?",o:["1 920 km","640 km","384 km","1 820 km"],k:0,s:"128 · 3 = 384; 384 · 5 = 1 920."}
];
function PRACT_STAGE(){C4col(['.3476','×...4','─────','{13904}'],'Ko‘paytir → xotirani qo‘sh → yoz')}
var PREP_DATA={teach:["Ko'p xonali sonni xonalarga ajratib ko'paytirish (taqsimot xossasi).","Ustun usuli: xotiraga olish.","O'rtasida nol bo'lgan sonlar.","Chamalash va qulay usul (4 999 · 5).","Yashirin raqam va ko'p bosqichli masalalar."],
 mist:["Xotiradagini qo'shishni unutadi: 2 058 · 6 = 12 008.","Xotirani ko'paytirishdan oldin qo'shadi: (7 + 2) · 4.","Nolni tashlaydi: 2 058 ni 258 deb oladi.","Hafta, sutka kabi yashirin sonlarni ko'rmaydi."],
 need:["Katakli daftar.","Rangli qalam — xotira raqami uchun."],
 board:["<span class='w2'>2 143 · 3 = 6000 + 300 + 120 + 9</span>","<span class='w2'>3 476 · 4 = 13 904</span>","<span class='w2'>2 058 · 6 = 12 348</span>","<span class='w2'>4 999 · 5 = 25 000 − 5</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
