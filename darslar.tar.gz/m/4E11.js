var CODE='4E11',TITLE='4-sinf · Sarf, hosildorlik va unumdorlik masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
function e11b(n,v,c){var s=[];for(var i=0;i<n;i++)s.push({w:v,txt:v,c:c||'g'});return s}
var STEPS=[
e4st({h:"Hosildorlik: 1 gektardan qancha?",sum:"Hosildorlik 32 s/ga, 15 ga: 32 · 15 = 480 sentner. Hosil = hosildorlik · maydon.",a:"m01",
 frames:[{t:'Har gektardan 32 sentner bug‘doy olindi. 15 gektardan jami qancha?',bars:[{lab:'1 ga',y:60,segs:[{w:32,txt:'32 s',c:'g'}]}],max:480,note:'1 gektardan olingan hosil — HOSILDORLIK'},
  {t:'Har gektardan 32 sentner bug‘doy olindi. 15 gektardan jami qancha?',bars:[{lab:'5 ga',y:60,segs:e11b(5,32)}],max:480,note:'Har gektar — yana 32 s'},
  {t:'Har gektardan 32 sentner bug‘doy olindi. 15 gektardan jami qancha?',bars:[{lab:'15 ga',y:60,segs:e11b(15,32).map(function(z){z.txt='';return z})}],max:480,br:[{b:0,lab:'480 sentner',col:C.ok}],calc:['Hosil = hosildorlik · maydon','32 · 15 = <b>480</b> s = 48 tonna']}],
 html:"<p><b>Hosildorlik</b> — 1 gektar yerdan olinadigan hosil. 1 sentner = 100 kg. Tugmani bosib, gektarlarni qo'shib boring.</p>",
 after:"<p>Yana o'sha oila: <b>hosil = hosildorlik · maydon</b>. 480 s = 48 000 kg = <b>48 t</b> (10 s = 1 t). Tuzoq: 1/4 qismi urug'likka qoldirilsa — 480 : 4 = 120 s.</p>",
 q:{t:"Har gektardan 32 s bug'doy olindi. 15 ga hosilining 1/4 qismi urug'likka qoldirildi. Urug'likka necha sentner qoldi?",opts:["120 s","480 s","360 s","8 s"],ok:0,why:"480 : 4 = 120.",hint:"Avval butun hosil, keyin uning 1/4 qismi.",full:"Hosil: 32 · 15 = 480 s. 1/4 qismi: 480 : 4 = 120 s. «360» — qolgan 3/4 qismi, «8» — 32 : 4 (faqat bir gektar)."},
 tn:"Bank: 2296. Sentner va tonna: 1 t = 10 s = 1000 kg. Doskada «hosil = hosildorlik · maydon» uchburchagi."}),
e4st({h:"Hosildorlikni topish",sum:"20 ga dan 700 s: hosildorlik 700 : 20 = 35 s/ga.",a:"m02",
 frames:[{t:'20 gektar daladan 700 sentner sholi olindi. Hosildorlik qancha?',bars:[{lab:'20 ga',y:60,segs:[{w:700,txt:'700 s',c:'g'}]}],note:'Butun hosilni gektarlar soniga bo‘lamiz'},
  {t:'20 gektar daladan 700 sentner sholi olindi. Hosildorlik qancha?',bars:[{lab:'20 ga',y:56,segs:e11b(20,35).map(function(z){z.txt='';return z})}],br:[{b:0,from:0,to:0,lab:'1 ga = 35 s',up:true,col:C.ok}],calc:['Hosildorlik = hosil : maydon','700 : 20 = <b>35</b> s/ga']}],
 html:"<p>Endi hosil va maydon ma'lum. Hosildorlik — bitta gektarga to'g'ri keladigan ulush.</p>",
 after:"<p><b>Hosildorlik = hosil : maydon.</b> Tekshiruv: 35 · 20 = 700 ✓. Hosildorlik yerning «unumi» — ishchining soatlik unumiga o'xshaydi.</p>",
 q:{t:"12 gektar bog'dan 960 s olma terildi. Hosildorlik?",opts:["80 s/ga","11 520 s/ga","948 s/ga","96 s/ga"],ok:0,why:"960 : 12 = 80.",hint:"Hosilni maydonga bo'ling.",full:"960 : 12 = 80 s/ga. «11 520» — ko'paytirilgan, «948» — ayirilgan. Tekshiruv: 80 · 12 = 960 ✓."},
 tn:"Fermer bolalari bo'lsa, o'z dalasining hosildorligini aytib bersin — hayotiy son."}),
e4st({h:"Sarf me’yori: bittasiga qancha ketadi",sum:"1 ko‘ylakka 3 m mato. 24 m dan 24 : 3 = 8 ta ko‘ylak.",a:"m03",
 frames:[{t:'Bitta ko‘ylakka 3 m mato ketadi. 24 m matodan nechta ko‘ylak tikish mumkin?',bars:[{lab:'24 m',y:60,segs:[{w:24,txt:'24 m',c:'b'}]}],note:'1 ko‘ylakka ketadigan mato — SARF'},
  {t:'Bitta ko‘ylakka 3 m mato ketadi. 24 m matodan nechta ko‘ylak tikish mumkin?',bars:[{lab:'24 m',y:60,segs:e11b(8,3,'b')}],br:[{b:0,lab:'8 ta ko‘ylak',col:C.ok}],calc:['Soni = jami : sarf','24 : 3 = <b>8</b> ta']}],
 html:"<p><b>Sarf</b> — bitta buyumga ketadigan material (yoki 1 km ga ketadigan benzin, 1 kunga ketadigan un). Tugmani bosing.</p>",
 after:"<p>Uchta kattalik: <b>sarf · soni = jami</b>. Sarf noma'lum bo'lsa: jami : soni. Masalan, 42 m dan 14 ta ko'ylak → 42 : 14 = 3 m.</p>",
 q:{t:"Bir qop unda 50 kg. Novvoyxona kuniga 8 kg un ishlatadi. Qop necha kunga yetadi va qancha qoladi?",opts:["6 kun, 2 kg qoladi","6 kun, qolmaydi","7 kun, 6 kg qoladi","5 kun, 10 kg qoladi"],ok:0,why:"50 : 8 = 6 (qoldiq 2).",hint:"Qoldiqli bo'lish.",full:"50 : 8 = 6 (qoldiq 2): 6 to'liq kun, 2 kg qoladi. 7-kunga 8 kg kerak, bor-yo'g'i 2 kg bor — yetmaydi."},
 tn:"Sarf masalasi — qoldiqli bo'lishni eslatish uchun yaxshi. «Yetadimi?» savoli bolani qoldiqni o'ylashga majbur qiladi."}),
e4st({h:"Yoqilg‘i sarfi: 100 km ga",sum:"100 km ga 8 l. 350 km ga: 350 : 100 = 3,5 marta... Birga keltiramiz: 50 km ga 4 l → 350 : 50 = 7; 4 · 7 = 28 l.",a:"m04",
 frames:[{road:1,L:350,t:'Mashina 100 km ga 8 l benzin sarflaydi. 350 km yo‘lga necha litr kerak?',marks:[[0,'0'],[100,'100'],[200,'200'],[300,'300'],[350,'350 km']],obj:[{p:0,ic:'🚗'}],seg:[{a:0,b:100,lab:'8 l',up:true,col:C.blue}],note:'Tanlang:'}],
 html:"<p>Mashinada sarf «100 km ga» hisoblanadi. 350 km — 100 ning butun karralisi emas. Nima qilamiz? Tanlang:</p>",
 btns:e4pk(["28 l","24 l","43 l"],0,{road:1,L:350,t:'50 km ga 4 l; 350 : 50 = 7 bo‘lak',marks:[[0,'0'],[50,''],[100,'100'],[150,''],[200,'200'],[250,''],[300,'300'],[350,'350']],obj:[{p:350,ic:'🚗'}],seg:[{a:0,b:50,lab:'4',up:true,col:C.blue},{a:50,b:100,lab:'4',up:true,col:C.blue},{a:100,b:150,lab:'4',up:true,col:C.blue},{a:150,b:200,lab:'4',up:true,col:C.blue},{a:200,b:250,lab:'4',up:true,col:C.blue},{a:250,b:300,lab:'4',up:true,col:C.blue},{a:300,b:350,lab:'4',up:true,col:C.blue}],calc:['50 km ga 8 : 2 = 4 l','350 : 50 = 7 bo‘lak → 4 · 7 = <b>28</b> l','Yoki: 300 km ga 24 l + 50 km ga 4 l = 28 l']},["","24 l — faqat 300 km uchun. Yana 50 km bor!","43 l — 350 : 8 deb bo‘lingan. Sarf 100 km ga 8 l, 1 km ga emas."]),
 after:"<p>Ikki yo'l: <b>mayda bo'lakka</b> keltirish (50 km → 4 l) yoki <b>bo'lib hisoblash</b> (300 km + 50 km). 1 km ga sarfni topish ham mumkin, lekin kasr chiqadi.</p>",
 q:{t:"Avtobus 100 km ga 25 l yoqilg'i sarflaydi. Bakda 90 l bor. 400 km yo'lga yetadimi?",opts:["Yo'q, 10 l yetmaydi","Ha, 10 l ortib qoladi","Ha, aniq yetadi","Yo'q, 25 l yetmaydi"],ok:0,why:"400 km ga 100 l kerak; 100 − 90 = 10.",hint:"400 km ga qancha kerak?",full:"400 km = 4 · 100 km → 25 · 4 = 100 l kerak. Bakda 90 l: 100 − 90 = 10 l yetmaydi. Yo'lda yoqilg'i quyish kerak."},
 tn:"Ota-onalar mashinasining sarfini so'rab kelsin (masalan 7 l / 100 km) va uyidan maktabgacha yo'lni hisoblasin."}),
e4st({h:"Tuzoq: hosildorlik yuqori ≠ hosil ko‘p",sum:"1-dala 12 ga · 30 s = 360 s; 2-dala 15 ga · 28 s = 420 s. Hosildorlik 1-dalada yuqori, lekin hosil 2-dalada ko‘p.",a:"m05",
 frames:[{head:['dala','maydon','hosildorlik','hosil'],rows:[['1-dala','12 ga','30 s/ga','?'],['2-dala','15 ga','28 s/ga','?']],t:'Qaysi daladan ko‘proq hosil olindi?',note:'Tanlang:'}],
 html:"<p>Hosildorlik 1-dalada yuqori (30 &gt; 28). Demak hosil ham 1-dalada ko'pmi? Tanlang:</p>",
 btns:e4pk(["1-dala, 2 s ko‘p","2-dala, 60 s ko‘p","Teng"],1,{head:['dala','maydon','hosildorlik','hosil'],rows:[['1-dala','12 ga','30 s/ga','360 s'],['2-dala','15 ga','28 s/ga','420 s']],hl:{1:3},t:'Hosilni hisoblab solishtiramiz',calc:['1-dala: 30 · 12 = 360 s','2-dala: 28 · 15 = 420 s','2-dala <b>60</b> s ko‘p — chunki maydoni katta']},["Hosildorlik 2 s ko‘p — lekin maydon kichik! Hosilni hisoblang.","","Hisoblamay «teng» deyish — taxmin."]),
 after:"<p><b>Hosildorlik</b> — yerning sifati, <b>hosil</b> — jami. Kichik lekin unumdor yer katta lekin kam unumli yerdan kamroq hosil berishi mumkin. Solishtirishdan oldin <b>hisoblang</b>.</p>",
 q:{t:"Akmal 4 soatda 60 ta, Botir 5 soatda 70 ta detal yasadi. Kimning unumi yuqori va kim ko'proq detal yasadi?",opts:["Unumi Akmalda yuqori, ko'p detal Botirda","Ikkalasi ham Botirda","Ikkalasi ham Akmalda","Unumi Botirda yuqori, ko'p detal Akmalda"],ok:0,why:"15 > 14; 70 > 60.",hint:"Unum = detal : soat.",full:"Akmal: 60 : 4 = 15 ta/soat, Botir: 70 : 5 = 14 ta/soat — unumi Akmalda yuqori. Lekin jami detal Botirda ko'p (70 > 60): u uzoqroq ishladi."},
 tn:"Bu farq — «sifat» va «miqdor» farqi. Sinfda muhokama: qaysi dalani ijaraga olgan ma'qul? (Javob: maydoni teng bo'lsa — hosildorligi yuqorisini.)"}),
e4st({h:"Ikki o‘lchov: ishchi ham, kun ham",sum:"3 ishchi 5 kunda 450 ta: 1 ishchi 1 kunda 450 : 3 : 5 = 30 ta. 4 ishchi 6 kunda 30 · 4 · 6 = 720 ta.",a:"m06",
 frames:[{head:['ishchi','kun','detal'],rows:[['3','5','450'],['1','1','?'],['4','6','?']],t:'3 ishchi 5 kunda 450 ta detal yasaydi. 4 ishchi 6 kunda nechta yasaydi?',note:'Ikki kattalik o‘zgaradi — ikkala tomondan ham birga keltiramiz'},
  {head:['ishchi','kun','detal'],rows:[['3','5','450'],['1','5','150'],['1','1','30'],['4','6','?']],hl:{2:2},t:'3 ishchi 5 kunda 450 ta detal yasaydi. 4 ishchi 6 kunda nechta yasaydi?',calc:['1 ishchi 5 kunda: 450 : 3 = 150','1 ishchi 1 kunda: 150 : 5 = <b>30</b> ta']},
  {head:['ishchi','kun','detal'],rows:[['3','5','450'],['1','1','30'],['4','1','120'],['4','6','720']],hl:{3:2},t:'3 ishchi 5 kunda 450 ta detal yasaydi. 4 ishchi 6 kunda nechta yasaydi?',calc:['4 ishchi 1 kunda: 30 · 4 = 120','4 ishchi 6 kunda: 120 · 6 = <b>720</b> ta']}],
 html:"<p>Bu yerda <b>ikkita</b> narsa o'zgaradi: ishchilar soni ham, kunlar ham. Qo'rqmang — «bitta ishchi bir kunda» ga keltiramiz. Tugmani bosing.</p>",
 after:"<p>«1 ishchi 1 kunda» — hamma narsaning o'lchov birligi. Undan istalgan ishchi va kun uchun hisoblash mumkin. Tuzoq: faqat ishchini o'zgartirib, kunni unutish (600 ta).</p>",
 q:{t:"2 ta traktor 3 kunda 48 ga yer haydaydi. 5 ta traktor 4 kunda necha gektar haydaydi?",opts:["160 ga","120 ga","96 ga","80 ga"],ok:0,why:"1 traktor 1 kunda 8 ga; 8 · 5 · 4 = 160.",hint:"Avval 1 traktor 1 kunda.",full:"1 traktor 1 kunda: 48 : 2 : 3 = 8 ga. 5 traktor 4 kunda: 8 · 5 · 4 = 160 ga. «120» — 5 traktor, 3 kun (kun unutilgan), «96» — 2 traktor 4 kun uchun emas... tekshiring."},
 tn:"Jadvalning har qatorida faqat BITTA kattalikni o'zgartiring — bolalar nima bo'layotganini ko'radi."}),
e4st({h:"Yetadimi? Qolganini hisoblash",sum:"240 l yoqilg‘i, kuniga 15 l: 240 : 15 = 16 kunga yetadi. 12 kun ishlatilsa, 240 − 180 = 60 l qoladi.",a:"m07",
 frames:[{t:'Omborda 240 l yoqilg‘i bor. Traktor kuniga 15 l sarflaydi. 12 kundan keyin qancha qoladi?',bars:[{lab:'240 l',y:52,segs:[{w:180,txt:'12 kun',c:'x'},{w:60,txt:'?',c:'q'}]}],max:240,note:'Tanlang:'}],
 html:"<p>Avval nima so'ralganini aniqlang: necha kunga yetishi emas, <b>qolgani</b>. Tanlang:</p>",
 btns:e4pk(["60 l","16 l","180 l"],0,{t:'12 kunda 15 · 12 = 180 l ketdi',bars:[{lab:'240 l',y:52,segs:[{w:180,txt:'180 l ketdi',c:'x'},{w:60,txt:'60 l',c:'g'}]}],max:240,calc:['Sarflandi: 15 · 12 = 180 l','Qoldi: 240 − 180 = <b>60</b> l','(Jami 240 : 15 = 16 kunga yetadi)']},["","16 — bu necha kunga yetishi (240 : 15). Litr so‘ralgan.","180 l — bu sarflangan yoqilg‘i, qolgani emas."]),
 after:"<p>Uch savol bir masalada: necha kunga yetadi (240 : 15 = 16), qancha sarflandi (15 · 12 = 180), qancha qoldi (240 − 180 = 60). Qaysi biri so'ralganini aniq ajrating.</p>",
 q:{t:"Oshxonada 90 kg guruch bor. Kuniga 6 kg ishlatiladi. 9 kundan keyin yana necha kunga yetadi?",opts:["6 kun","15 kun","9 kun","36 kun"],ok:0,why:"90 − 54 = 36; 36 : 6 = 6.",hint:"Avval qolganini toping.",full:"9 kunda: 6 · 9 = 54 kg ketdi. Qoldi: 90 − 54 = 36 kg. 36 : 6 = 6 kun. «15» — boshidan necha kunga yetishi, «36» — qolgan kg."},
 tn:"Hayotiy: sinf uchun bo'r, qog'oz sarfini bolalar bilan birga hisoblang — «yetadimi?» savoli ularni o'ziga qiziqtiradi."}),
e4st({h:"Urug‘ sarfi va tonna tuzog‘i",sum:"1 ga ga 200 kg urug‘. 15 ga: 200 · 15 = 3000 kg = 3 t (300 t emas!).",a:"m08",
 frames:[{head:['maydon','urug‘'],rows:[['1 ga','200 kg'],['15 ga','?']],t:'1 gektarga 200 kg bug‘doy urug‘i sepiladi. 15 ga uchun necha tonna urug‘ kerak?',note:'Tanlang:'}],
 html:"<p>Hisob oson, lekin javob <b>tonnada</b> so'ralgan. Tanlang:</p>",
 btns:e4pk(["3 t","30 t","300 t"],0,{head:['maydon','urug‘'],rows:[['1 ga','200 kg'],['15 ga','3000 kg = 3 t']],hl:{1:1},t:'200 · 15 = 3000 kg',calc:['200 · 15 = 3000 kg','1 t = 1000 kg → 3000 kg = <b>3</b> t']},["","30 t = 30 000 kg — 10 marta ko‘p.","300 t = 300 000 kg — bu butun tumanning urug‘i!"]),
 after:"<p>Birliklar: <b>1 t = 1000 kg = 10 s</b>, <b>1 s = 100 kg</b>. Javobni yozishdan oldin: «so'ralgan birlik qaysi?» Katta sonlarda nollarni sanang.</p>",
 q:{t:"Fermer 25 ga ga urug' sepdi, har gektarga 180 kg. Omborda 5 t urug' bor edi. Qancha qoldi?",opts:["500 kg","4 500 kg","4 t 820 kg","Yetmadi"],ok:0,why:"180 · 25 = 4500 kg; 5000 − 4500 = 500.",hint:"5 t ni kg ga o'tkazing.",full:"Sarf: 180 · 25 = 4500 kg. 5 t = 5000 kg. Qoldi: 5000 − 4500 = 500 kg. «4 500» — sarflangan miqdor, «4 t 820 kg» — 5000 − 180 (faqat 1 ga)."},
 tn:"Doskada birliklar zinapoyasi: kg → s (:100) → t (:10). Bolalar 3000 kg ni zinapoyadan ko'tarib ko'rsin."}),
e4st({h:"Bilasizmi? Gektar — bu qancha?",sum:"1 ga = 10 000 m² = 100 m × 100 m. Futbol maydoni ≈ 0,7 ga. «Gektar» = «hekto» (100) + «ar» (100 m²).",a:"m09",
 frames:[{t:'1 gektar = 100 m × 100 m kvadrat',bars:[{lab:'100 m',y:44,segs:[{w:100,txt:'100 m',c:'g'}]},{lab:'',y:74,segs:[{w:100,txt:'1 ga = 10 000 m²',c:'g'}]},{lab:'',y:104,segs:[{w:100,txt:'≈ 1,5 futbol maydoni',c:'g'}]}],max:100,note:'ar = 10 m × 10 m = 100 m²;  gektar = 100 ar'}],
 html:"<p>🌾 <b>Gektar</b> so'zi ikki qismdan: «<b>hekto</b>» — yunoncha «yuz» va «<b>ar</b>» — 10 m × 10 m = 100 m² li maydon. Demak 1 gektar = 100 ar = <b>10 000 m²</b>, ya'ni tomoni 100 m bo'lgan kvadrat. Katta futbol maydoni (105 m × 68 m = 7140 m²) taxminan <b>0,7 gektar</b>. O'zbekistonda yer maydoni gektarda, hosil esa sentner va tonnada o'lchanadi.</p>",
 after:"<p>Endi «32 s/ga» ni tasavvur qiling: 100 × 100 metrli maydondan 3200 kg bug'doy — bu 64 qop (50 kg dan)!</p>",
 tn:"Maktab hovlisini qadamlab o'lchang: necha ar? Bolalar gektarning kattaligini tanasi bilan his qilsin."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e4tab({head:['kattalik','1 taga','jami'],rows:[['hosildorlik','1 ga → 32 s','· maydon'],['sarf','1 ta → 3 m','· soni'],['unum','1 soat → 12 ta','· vaqt']],t:'Hammasi bitta oila: 1 taga · soni = jami',note:'1 t = 10 s = 1000 kg'})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Hosildorlik</b> (1 ga dan) · maydon = hosil. Hosildorlik = hosil : maydon.</li><li><b>Sarf</b> (1 taga, 100 km ga) · soni = jami. Soni = jami : sarf (qoldiqni unutmang).</li><li>Hosildorlik yuqori ≠ hosil ko'p — maydonni ham qarang.</li><li>Ikki o'lchov o'zgarsa — «1 ishchi 1 kunda» ga keltiring.</li><li>Yetadimi? Qoldi? — sarflanganini topib, ayiring.</li><li>Birliklar: 1 t = 10 s = 1000 kg; 1 ga = 10 000 m².</li></ul></div>",
 tn:"Keyingi dars (4E12) — shu usullar ekologiya va kundalik hayotda: suv, qog'oz, elektr sarfi."}
];
var PROBS=[
{t:"Har gektardan 32 s bug'doy olindi. 15 ga dan jami?",o:["480 s","47 s","320 s","4800 s"],k:0,s:"32 · 15 = 480."},
{t:"20 ga daladan 700 s sholi olindi. Hosildorlik?",o:["35 s/ga","14 000 s/ga","680 s/ga","70 s/ga"],k:0,s:"700 : 20 = 35."},
{t:"Bitta ko'ylakka 3 m mato ketadi. 24 m dan nechta ko'ylak?",o:["8 ta","72 ta","21 ta","6 ta"],k:0,s:"24 : 3 = 8."},
{t:"42 m matodan 14 ta bir xil ko'ylak tikildi. Bitta ko'ylakka necha metr ketgan?",o:["3 m","28 m","4 m","588 m"],k:0,s:"42 : 14 = 3."},
{t:"Mashina 100 km ga 8 l benzin sarflaydi. 350 km ga?",o:["28 l","24 l","43 l","32 l"],k:0,s:"50 km ga 4 l; 4 · 7 = 28."},
{t:"Har gektardan 32 s olindi. 15 ga hosilining 1/4 qismi urug'likka qoldirildi. Urug'likka qancha?",o:["120 s","480 s","360 s","8 s"],k:0,s:"480 : 4 = 120."},
{t:"1-dala 12 ga, hosildorlik 30 s/ga; 2-dala 15 ga, 28 s/ga. Qaysi dala necha sentner ko'p hosil berdi?",o:["2-dala, 60 s","1-dala, 2 s","1-dala, 60 s","Teng"],k:0,s:"360 va 420; 420 − 360 = 60."},
{t:"3 ishchi 5 kunda 450 ta detal yasaydi. 4 ishchi 6 kunda nechta?",o:["720 ta","600 ta","540 ta","450 ta"],k:0,s:"1 ishchi 1 kunda 30; 30 · 4 · 6 = 720."},
{t:"2 traktor 3 kunda 48 ga haydaydi. 5 traktor 4 kunda?",o:["160 ga","120 ga","96 ga","80 ga"],k:0,s:"8 · 5 · 4 = 160."},
{t:"Omborda 240 l yoqilg'i, traktor kuniga 15 l sarflaydi. 12 kundan keyin qancha qoladi?",o:["60 l","16 l","180 l","20 l"],k:0,s:"240 − 15 · 12 = 60."},
{t:"Oshxonada 90 kg guruch, kuniga 6 kg ishlatiladi. 9 kundan keyin yana necha kunga yetadi?",o:["6 kun","15 kun","9 kun","36 kun"],k:0,s:"(90 − 54) : 6 = 6."},
{t:"1 ga ga 200 kg urug' sepiladi. 15 ga uchun necha tonna?",o:["3 t","30 t","300 t","3 000 t"],k:0,s:"3000 kg = 3 t."},
{t:"Bir qop unda 50 kg. Novvoy kuniga 8 kg ishlatadi. Qop necha to'liq kunga yetadi?",o:["6 kun","7 kun","5 kun","8 kun"],k:0,s:"50 : 8 = 6 (qoldiq 2)."},
{t:"Avtobus 100 km ga 25 l sarflaydi. Bakda 90 l. 400 km ga yana necha litr kerak?",o:["10 l","25 l","0 l","100 l"],k:0,s:"100 − 90 = 10."},
{t:"Akmal 4 soatda 60 ta, Botir 5 soatda 70 ta detal yasadi. Kimning soatlik unumi nechta ko'p?",o:["Akmalniki 1 ta ko'p","Botirniki 10 ta ko'p","Botirniki 1 ta ko'p","Teng"],k:0,s:"15 − 14 = 1."},
{t:"Fermer 25 ga ga har gektarga 180 kg dan urug' sepdi. Omborda 5 t bor edi. Qancha qoldi?",o:["500 kg","4 500 kg","4 t 820 kg","1 t 500 kg"],k:0,s:"5000 − 4500 = 500."},
{t:"Bog'ning 8 ga idan 560 s, 12 ga idan 720 s olma olindi. Qaysi qismning hosildorligi yuqori va nechaga?",o:["1-qism, 10 s/ga","2-qism, 160 s","2-qism, 10 s/ga","Teng"],k:0,s:"70 va 60 s/ga; 70 − 60 = 10."},
{t:"Tikuvchi 5 ta ko'ylakka 15 m mato va 10 ta tugma ishlatadi. 40 m matodan nechta ko'ylak tikiladi va nechta tugma kerak?",o:["13 ta ko'ylak, 26 ta tugma","13 ta ko'ylak, 13 ta tugma","8 ta ko'ylak, 16 ta tugma","14 ta ko'ylak, 28 ta tugma"],k:0,s:"1 ko'ylak 3 m, 2 tugma; 40 : 3 = 13 (qoldiq 1); 13 · 2 = 26."},
{t:"Sigir kuniga 12 l sut beradi. 1 kg pishloq uchun 10 l sut ketadi. 5 ta sigirning haftalik sutidan necha kg pishloq chiqadi?",o:["42 kg","60 kg","420 kg","84 kg"],k:0,s:"12 · 5 · 7 = 420 l; 420 : 10 = 42."},
{t:"Dala 36 ga. Uning 1/3 qismiga hosildorligi 40 s/ga, qolganiga 25 s/ga bug'doy ekildi. Jami hosil necha tonna?",o:["108 t","1080 t","78 t","117 t"],k:0,s:"12 · 40 = 480; 24 · 25 = 600; 1080 s = 108 t."}
];
function PRACT_STAGE(){e4tab({head:['1 taga','soni','jami'],rows:[['hosildorlik · maydon','=','hosil'],['sarf · soni','=','jami']],t:'1 t = 10 s = 1000 kg',note:'Nima so‘ralgan: yetadimi, qoldimi, hosildorlikmi?'})}
var PREP_DATA={teach:["Hosildorlik, hosil, maydon — uch kattalik.","Sarf me'yori: 1 taga, 100 km ga; soni = jami : sarf (qoldiq).","Hosildorlik yuqori ≠ hosil ko'p — hisoblab solishtirish.","Ikki o'lchov (ishchi va kun) — 1 ishchi 1 kunda.","Yetadimi, qoldi? Birliklar: t, s, kg; ga."],
 mist:["Hosildorlik yuqori bo'lsa hosil ham ko'p deb o'ylaydi.","350 : 8 deb bo'ladi (sarf 100 km ga ekanini unutadi).","Qoldiqni e'tiborsiz qoldiradi (6,25 kun).","Faqat bitta o'lchovni o'zgartiradi (kunni unutadi).","3000 kg ni 30 t deb yozadi."],
 need:["Doskada jadval: 1 taga | soni | jami.","Birliklar zinapoyasi: kg → s → t.","Ota-onaning mashina sarfi (uy vazifasi)."],
 board:["<span class='w2'>32 · 15 = 480 s = 48 t</span>.","<span class='w2'>100 km → 8 l; 50 km → 4 l; 350 : 50 = 7; 4 · 7 = 28 l</span>.","<span class='w2'>30 · 12 = 360</span>, <span class='w2'>28 · 15 = 420</span>.","<span class='w2'>450 : 3 : 5 = 30; 30 · 4 · 6 = 720</span>."]};
