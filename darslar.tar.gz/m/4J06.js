var CODE='4J06',TITLE="4-sinf · Mantiqiy masalalar: rost-yolg'on, jadval usuli";
function m6Tab(rows,red,grn){var f={},c={};(red||[]).forEach(function(k){c[k]=C.bad});(grn||[]).forEach(function(k){c[k]=C.ok;f[k]='#e6f6ee'});j3Tab(rows,{hr:1,hc:1,cw:o6w(rows),ch:30,fs:15,fill:f,col:c})}
function o6w(r){return r[0].length>5?54:(r[0].length>4?62:76)}
var M6A=[['','futbol','shaxmat','suzish'],['Ali','','✗',''],['Bek','','',''],['Sora','','','']];
function m6S1(){var t=JSON.parse(JSON.stringify(M6A));t[1][3]='✗';t[3][2]='✗';m6Tab(t,['1,2','1,3','3,2'])}
function m6F1(){m6Tab([['','futbol','shaxmat','suzish'],['Ali','✓','✗','✗'],['Bek','✗','✓','✗'],['Sora','✗','✗','✓']],['1,2','1,3','2,1','2,3','3,1','3,2'],['1,1','2,2','3,3'])}
var M6B=[['','9','10','11','12'],['Ali','✗','','','✗'],['Bek','','','',''],['Doniyor','','','',''],['Eldor','','','','']];
function m6S2(){m6Tab(M6B,['1,1','1,4'])}
function m6F2(){m6Tab([['','9','10','11','12'],['Ali','✗','✓','✗','✗'],['Bek','✗','✗','✓','✗'],['Doniyor','✓','✗','✗','✗'],['Eldor','✗','✗','✗','✓']],['1,1','1,3','1,4','2,1','2,2','2,4','3,2','3,3','3,4','4,1','4,2','4,3'],['1,2','2,3','3,1','4,4'])}
var STEPS=[
J4({h:"Jadval usuli",sum:"Ism × sport jadvali. «Shaxmatchi ham, suzuvchi ham — Alining do'sti» → Ali shaxmat ham, suzish ham emas → Ali futbol. Sora shaxmat emas → Sora suzish, Bek shaxmat.",a:"m01",
 s:m6S1,m:"✗ — «bo‘lishi mumkin emas». Har qator va ustunda bittadan ✓",f:m6F1,fm:"Ali — futbol, Bek — shaxmat, Sora — suzish",
 html:"<p>Ali, Bek va Sora — har biri bitta sport bilan shug'ullanadi: futbol, shaxmat, suzish. 1) Shaxmatchi ham, suzuvchi ham — Alining do'sti. 2) Sora shaxmat o'ynamaydi. Jadvalda ✗ lar qo'yildi. <b>Kim shaxmatchi?</b></p>",
 ch:["Bek","Sora","Ali"],ok:0,bad:["","Sora shaxmat o‘ynamaydi — 2-shart","Shaxmatchi Alining do‘sti, demak u Ali emas"],
 after:"<p>1-shartdan: Ali shaxmatchi ham, suzuvchi ham emas (o'zi o'zining do'sti bo'lmaydi) → Ali qatorida ikkita ✗, demak Ali — <b>futbol</b>. Futbol ustunidagi boshqalarga ✗. Sora qatorida qoldi faqat suzish → Sora suzadi, Bek — shaxmat. Qoida: har qatorda va har ustunda aynan bitta ✓.</p>",
 q:{t:"Nilufar, Madina, Zarina — oq, qizil va ko'k ko'ylakda. Nilufar oqda emas. Madina oq ham, ko'k ham emas. Nilufar va Zarina qanday ko'ylakda?",opts:["Nilufar — ko'k, Zarina — oq","Nilufar — qizil, Zarina — oq","Nilufar — ko'k, Zarina — qizil","Nilufar — oq, Zarina — ko'k"],ok:0,why:"Madina — qizil; Nilufar oq emas → ko'k; Zarina — oq.",hint:"Avval ikki ✗ li qatorni toping.",full:"Madina oq ham, ko'k ham emas → qizil. Nilufar oq emas, qizil band → ko'k. Zarinaga oq qoladi."},
 tn:"Jadvalni doskaga chizing; har shartdan keyin bolalar o'zi ✗ qo'ysin. «Do'sti» degan so'z — yashirin ma'lumot: odam o'zining do'sti emas."}),
J4({h:"4×4 jadval: tartib shartlari",sum:"Ali eng kichik ham, eng katta ham emas; Bek Alidan katta; Eldor Bekdan katta → Ali 10, Bek 11, Eldor 12, Doniyor 9.",a:"m02",
 s:m6S2,m:"Ali — 9 ham, 12 ham emas",f:m6F2,fm:"Ali 11 bo‘lsa Bek 12, Eldorga joy qolmaydi → Ali 10",
 html:"<p>Ali, Bek, Doniyor, Eldor — 9, 10, 11 va 12 yoshda. Ali eng kichik ham, eng katta ham emas. Bek Alidan katta. Eldor Bekdan katta. <b>Doniyor necha yoshda?</b></p>",
 ch:["9","10","11","12"],ok:0,bad:["","10 — Alining yoshi bo‘lib chiqadi","Ali 10 yoki 11. Ali 11 bo‘lsa, Bek 12, Eldor-chi?","Eldor eng katta: u Bekdan, Bek Alidan katta"],
 after:"<p>Ali 10 yoki 11. Agar Ali 11 bo'lsa — Bek 12, Eldor Bekdan katta bo'lolmaydi ✗. Demak Ali 10. Bek 11 yoki 12, Eldor undan katta → Bek 11, Eldor 12. Doniyorga <b>9</b> qoladi. «Agar … bo'lsa» deb sinab, ziddiyat chiqsa — o'sha variant yo'q.</p>",
 q:{t:"Anvar Botirdan katta, Sardor Anvardan katta. Uchovidan eng kichigi kim?",opts:["Botir","Anvar","Sardor"],ok:0,why:"Sardor > Anvar > Botir.",hint:"Ularni yoshi bo'yicha qatorga tering.",full:"Sardor Anvardan, Anvar Botirdan katta: Sardor > Anvar > Botir. Eng kichigi — Botir."},
 tn:"«Agar … bo'lsa» usuli — farazni tekshirish. Bolalar ziddiyatni topganda «✗» deb baland aytsin."}),
J4({h:"Rostgo'y va yolg'onchi",sum:"A: «B yolg'onchi». B: «Ikkalamiz bir xilmiz». Faraz: A rostgo'y → B yolg'onchi, B ning gapi yolg'on ✓. Faraz: A yolg'onchi → B rostgo'y, lekin unda ular bir xil emas ✗.",a:"m03",
 s:['A: «B — yolg‘onchi»','B: «Ikkalamiz bir xilmiz»'],so:{fs:18,lh:42},m:"Rostgo‘y doim rost, yolg‘onchi doim yolg‘on gapiradi",
 f:['A rostgo‘y → B yolg‘onchi','B: «bir xilmiz» — yolg‘on ✓'],fso:{fs:18,lh:42},fm:"Ikkinchi faraz ziddiyatga olib keladi",
 html:"<p>Orolda rostgo'ylar (doim rost gapiradi) va yolg'onchilar (doim yolg'on gapiradi) yashaydi. A: «B — yolg'onchi». B: «Ikkalamiz bir xilmiz». Kim kim?</p>",
 ch:["A — rostgo‘y, B — yolg‘onchi","A — yolg‘onchi, B — rostgo‘y","ikkalasi rostgo‘y","ikkalasi yolg‘onchi"],ok:0,bad:["","Unda B rost gapiryapti: «bir xilmiz» — lekin A yolg‘onchi, B rostgo‘y. Ziddiyat!","A rost gapirsa, B yolg‘onchi bo‘ladi","A yolg‘on gapirsa, B rostgo‘y bo‘ladi"],
 after:"<p>Ikki faraz qilamiz. 1) A rostgo'y → uning gapi rost → B yolg'onchi → B ning «bir xilmiz» gapi yolg'on (haqiqatan har xil) ✓. 2) A yolg'onchi → B rostgo'y → B ning gapi rost bo'lishi kerak, lekin ular har xil ✗. Javob: A — rostgo'y, B — yolg'onchi.</p>",
 q:{t:"A: «Ikkimizdan kamida bittasi yolg'onchi». Kim kim?",opts:["A — rostgo'y, B — yolg'onchi","A — yolg'onchi, B — rostgo'y","ikkalasi rostgo'y","ikkalasi yolg'onchi"],ok:0,why:"A yolg'onchi bo'lsa, uning gapi rost bo'lib qoladi — ziddiyat. Demak A rostgo'y, unda B yolg'onchi.",hint:"A yolg'onchi bo'lishi mumkinmi?",full:"Agar A yolg'onchi bo'lsa, «kamida bittasi yolg'onchi» rost bo'ladi — yolg'onchi rost gapirolmaydi ✗. Demak A rostgo'y, gapi rost: kamida bittasi yolg'onchi — bu B."},
 tn:"Ikkita kartochka: «R» va «Y». Bolalar A va B ga navbatma-navbat qo'yib, gaplarni tekshirsin."}),
J4({h:"Faqat bittasi rost",sum:"Ali: «Men sindirmadim». Bek: «Ali sindirdi». Sora: «Men sindirmadim». Har bir aybdorni tekshiramiz: faqat Sora bo'lganda bitta gap rost.",a:"m04",
 s:['Ali: «Men sindirmadim»','Bek: «Ali sindirdi»','Sora: «Men sindirmadim»'],so:{fs:17,lh:36},m:"Faqat BITTA gap rost",
 f:function(){m6Tab([['aybdor','Ali','Bek','Sora','rost'],['Ali','✗','✓','✓','2'],['Bek','✓','✗','✓','2'],['Sora','✓','✗','✗','1 ✓']],['1,1','2,2','3,2','3,3'],['3,4'])},fm:"Har aybdor uchun gaplarni tekshirib, rostlarini sanaymiz",
 html:"<p>Vaza sindi. Ali: «Men sindirmadim». Bek: «Ali sindirdi». Sora: «Men sindirmadim». Ma'lumki, faqat <b>bittasi</b> rost gapirgan. Vazani kim sindirgan?</p>",
 ch:["Sora","Ali","Bek"],ok:0,bad:["","Ali bo‘lsa: Bek ham, Sora ham rost — 2 ta rost","Bek bo‘lsa: Ali ham, Sora ham rost — 2 ta"],
 after:"<p>Usul: <b>har bir aybdorni navbat bilan</b> tekshiramiz va rost gaplarni sanaymiz. Ali — 2 ta rost, Bek — 2 ta, Sora — faqat Alining gapi rost: 1 ta ✓. Javob — Sora. Jadval bilan tekshirish hech qanday holatni o'tkazib yubormaydi.</p>",
 q:{t:"Uchta quti. 1-quti: «Oltin 2-qutida». 2-quti: «Oltin shu yerda emas». 3-quti: «Oltin shu yerda emas». Faqat bitta yozuv rost. Oltin qayerda?",opts:["3-qutida","1-qutida","2-qutida"],ok:0,why:"3-qutida bo'lsa: faqat 2-quti yozuvi rost.",hint:"Oltinni har qutiga navbat bilan «qo'yib», rost yozuvlarni sanang.",full:"1-qutida: 2- va 3-quti yozuvlari rost (2 ta). 2-qutida: 1- va 3-quti rost (2 ta). 3-qutida: faqat 2-quti rost (1 ta) ✓."},
 tn:"Jadval: qatorlar — «agar aybdor …», ustunlar — har kishining gapi. Har katakka R yoki Y."}),
J4({h:"Tuzoq: gaplar bir-biriga bog'liq",sum:"A: «B yolg'onchi». B: «C yolg'onchi». C: «A ham, B ham yolg'onchi». C rostgo'y bo'lolmaydi → C yolg'onchi → B rostgo'y → A yolg'onchi.",a:"m05",
 s:['A: «B — yolg‘onchi»','B: «C — yolg‘onchi»','C: «A ham, B ham yolg‘onchi»'],so:{fs:17,lh:36},m:"Eng «kuchli» gapdan — C dan boshlang",
 f:['C rost bo‘lsa: A, B yolg‘onchi → B rost?! ✗','C — yolg‘onchi → B — [rostgo‘y]','A — yolg‘onchi'],fso:{fs:15,lh:36},fm:"Faqat B rostgo‘y",
 html:"<p>A: «B — yolg'onchi». B: «C — yolg'onchi». C: «A ham, B ham yolg'onchi». Ularning <b>nechtasi rostgo'y</b>?</p>",
 ch:["1","0","2","3"],ok:0,bad:["","Hammasi yolg‘onchi bo‘lsa, B ning «C yolg‘onchi» gapi rost bo‘lib qoladi","Qaysi ikkitasi? A va B bir-birini yolg‘onchi deyapti — ikkalasi rost bo‘lolmaydi","A «B yolg‘onchi» demoqda — hammasi rost bo‘lolmaydi"],
 after:"<p>C rostgo'y deb faraz qilaylik: unda A va B yolg'onchi; lekin A yolg'onchi bo'lsa, «B yolg'onchi» yolg'on, ya'ni B rostgo'y ✗. Demak C — yolg'onchi. B «C yolg'onchi» dedi — rost → B rostgo'y. A «B yolg'onchi» dedi — yolg'on → A yolg'onchi. Rostgo'y faqat <b>1 ta</b>.</p>",
 q:{t:"Orol aholisi (rostgo'y yoki yolg'onchi) hech qachon qaysi gapni ayta olmaydi?",opts:["«Men yolg'onchiman»","«Men rostgo'yman»","«Qo'shnim yolg'onchi»","«Bugun quyoshli kun»"],ok:0,why:"Rostgo'y buni aytsa — yolg'on gapirgan bo'ladi, yolg'onchi aytsa — rost gapirgan bo'ladi.",hint:"Gapni rostgo'y aytsa nima bo'ladi? Yolg'onchi aytsa-chi?",full:"«Men yolg'onchiman»: rostgo'y aytolmaydi (yolg'on bo'lardi), yolg'onchi ham aytolmaydi (rost bo'lardi). «Men rostgo'yman» ni ikkalasi ham aytadi."},
 tn:"Kuchli o'quvchilar uchun: «Ikkimiz ham yolg'onchimiz» degan A haqida o'ylashsin (A — yolg'onchi, B — rostgo'y)."}),
J4({h:"4 ta quti, bitta rost yozuv",sum:"1: «Oltin shu yerda». 2: «Oltin 1-qutida emas». 3: «Oltin 4-qutida». 4: «Oltin 2-qutida emas». Faqat bittasi rost → oltin 2-qutida.",a:"m06",
 s:['1: «Oltin shu yerda»','2: «Oltin 1-qutida emas»','3: «Oltin 4-qutida»','4: «Oltin 2-qutida emas»'],so:{fs:15,lh:32},m:"Oltinni navbat bilan har qutiga «qo‘yib» ko‘ring",
 f:function(){m6Tab([['oltin','1','2','3','4','rost'],['1-da','✓','✗','✗','✓','2'],['2-da','✗','✓','✗','✗','1 ✓'],['3-da','✗','✓','✗','✓','2'],['4-da','✗','✓','✓','✓','3']],[],['2,5'])},fm:"Faqat «2-qutida» holatida bitta yozuv rost",
 html:"<p>To'rtta quti, bittasida oltin. Yozuvlar: 1: «Oltin shu yerda». 2: «Oltin 1-qutida emas». 3: «Oltin 4-qutida». 4: «Oltin 2-qutida emas». Faqat <b>bitta</b> yozuv rost. Oltin qayerda?</p>",
 ch:["2-qutida","1-qutida","3-qutida","4-qutida"],ok:0,bad:["","1-qutida bo‘lsa: 1 va 4 yozuvlari rost — 2 ta","3-qutida bo‘lsa: 2 va 4 rost — 2 ta","4-qutida bo‘lsa: 2, 3 va 4 rost — 3 ta"],
 after:"<p>4 ta holat — 4 ta qator. Har qatorda rost yozuvlarni sanaymiz: 2, 1, 2, 3. Faqat oltin <b>2-qutida</b> bo'lganda bitta yozuv (2-qutiniki) rost. Jadvalsiz bunday masalada adashish oson.</p>",
 q:{t:"1: «Oltin 3-qutida». 2: «Oltin 1-qutida emas». 3: «Oltin shu yerda emas». 4: «Oltin 2-qutida». Faqat bitta yozuv rost. Oltin qayerda?",opts:["1-qutida","2-qutida","3-qutida","4-qutida"],ok:0,why:"Oltin 1-qutida bo'lsa, faqat 3-yozuv rost.",hint:"Har holat uchun rost yozuvlarni sanang.",full:"1-qutida: faqat 3-yozuv rost (1) ✓. 2-qutida: 2, 3, 4 rost (3). 3-qutida: 1, 2 rost (2). 4-qutida: 2, 3 rost (2)."},
 tn:"Haqiqiy 4 ta quti va «oltin» (tanga) bilan o'ynab ko'ring: bir bola yashiradi, qolganlar jadval bilan topadi."}),
J4info({h:"Bilasizmi? Rostgo'ylar oroli",a:"m07",s:['Rostgo‘y — doim rost','Yolg‘onchi — doim yolg‘on'],so:{fs:19,lh:44},m:"Raymond Smullyan jumboqlari",
 html:"<p>📚 Amerikalik matematik va mantiqchi <b>Raymond Smullyan</b> 1978-yilda «Bu kitobning nomi nima?» degan jumboqlar kitobini nashr etgan. Unda rostgo'ylar va yolg'onchilar yashaydigan orol haqidagi yuzlab masalalar bor. Bunday masalalar kompyuter dasturlari asosidagi «rost / yolg'on» mantiqini o'rgatadi.</p>",
 tn:"Bolalar o'zlari ikki kishilik rostgo'y–yolg'onchi jumbog'ini tuzib, javobini jadval bilan tekshirsin."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:m6F1,m:"Har qator va ustunda bittadan ✓",
 html:"<div class='memo'><ul><li>Jadval: qatorlar — odamlar, ustunlar — belgilar. ✗ va ✓.</li><li>Har qatorda va ustunda <b>bitta</b> ✓.</li><li>Yashirin ma'lumot: «do'sti», «undan katta» → o'zi emas.</li><li>Faraz qiling: «agar … bo'lsa» → ziddiyat chiqsa, ✗.</li><li>«Faqat bittasi rost» — har holatni tekshirib, rostlarni sanang.</li><li>«Men yolg'onchiman» — hech kim ayta olmaydi.</li></ul></div>",
 tn:"Uyga: oila a'zolari bilan 3×3 jadvalli jumboq tuzib kelish."})
];
var PROBS=[
{t:"Olim, Botir, Diyor — shifokor, quruvchi va o'qituvchi. Olim shifokor ham, o'qituvchi ham emas. Botir shifokor emas. Kim kim?",o:["Olim — quruvchi, Diyor — shifokor","Olim — quruvchi, Diyor — o'qituvchi","Olim — o'qituvchi, Diyor — shifokor","Olim — shifokor, Diyor — quruvchi"],k:0,s:"Olim — quruvchi; Botir shifokor emas → o'qituvchi; Diyor — shifokor."},
{t:"Gulnoza, Dilnoza, Feruza — sariq, yashil va pushti ro'molda. Gulnoza sariqda emas. Dilnoza sariq ham, pushti ham emas. Kim qaysi ro'molda?",o:["Gulnoza — pushti, Feruza — sariq","Gulnoza — yashil, Feruza — sariq","Gulnoza — pushti, Feruza — yashil","Gulnoza — sariq, Feruza — pushti"],k:0,s:"Dilnoza — yashil; Gulnoza sariq emas → pushti; Feruza — sariq."},
{t:"Jasur, Kamol, Laziz, Murod — 8, 9, 10, 11 yoshda. Jasur eng katta ham, eng kichik ham emas. Kamol Jasurdan katta. Murod Kamoldan katta. Laziz necha yoshda?",o:["8","9","10","11"],k:0,s:"Jasur 9 (10 bo'lsa Murodga joy yo'q), Kamol 10, Murod 11, Laziz 8."},
{t:"A: «B — yolg'onchi». B: «C — yolg'onchi». C: «A ham, B ham yolg'onchi». Nechtasi rostgo'y?",o:["1","0","2","3"],k:0,s:"C rost bo'lolmaydi → C yolg'onchi → B rostgo'y → A yolg'onchi."},
{t:"A: «Ikkimiz ham yolg'onchimiz». Kim kim?",o:["A — yolg'onchi, B — rostgo'y","A — rostgo'y, B — yolg'onchi","ikkalasi yolg'onchi","ikkalasi rostgo'y"],k:0,s:"A rostgo'y bo'lsa, o'zi yolg'onchi bo'lib qoladi ✗. A yolg'onchi → gap yolg'on → ikkalasi yolg'onchi emas → B rostgo'y."},
{t:"Vaza sindi. Anvar: «Men sindirmadim». Bobur: «Anvar sindirdi». Sardor: «Men sindirmadim». Doston: «Bobur sindirdi». Faqat bittasi rost gapirgan. Kim sindirgan?",o:["Sardor","Anvar","Bobur","Doston"],k:0,s:"Sardor bo'lsa, faqat Anvarning gapi rost. Boshqa holatlarda 2–3 ta rost."},
{t:"1: «Oltin shu yerda». 2: «Oltin 1-qutida emas». 3: «Oltin 4-qutida». 4: «Oltin 2-qutida emas». Faqat bitta yozuv rost. Oltin qayerda?",o:["2-qutida","1-qutida","3-qutida","4-qutida"],k:0,s:"2-qutida: faqat 2-yozuv rost."},
{t:"Ikki qorovul: biri doim rost, biri doim yolg'on gapiradi. Har biridan «Sen rostgo'ymisan?» deb so'raldi. Ular nima deydi?",o:["ikkalasi ham «ha» deydi","rostgo'y «ha», yolg'onchi «yo'q»","ikkalasi ham «yo'q» deydi","rostgo'y «yo'q», yolg'onchi «ha»"],k:0,s:"Rostgo'y rostini aytadi — «ha»; yolg'onchi yolg'on aytadi — u ham «ha»."},
{t:"Ali, Vali, G'ani, Soli — olma, nok, uzum, anor. Ali olma ham, nok ham yemaydi. Vali uzumni yaxshi ko'radi. G'ani nok ham, anor ham emas. Soli qaysi mevani yaxshi ko'radi?",o:["nok","olma","anor","uzum"],k:0,s:"Vali — uzum; G'ani — olma; Ali — anor; Soli — nok."},
{t:"Poygada Ali Bekdan oldin, Sora Alidan oldin keldi. Doston Bekdan keyin keldi. Kim 3-o'rinni oldi?",o:["Bek","Ali","Sora","Doston"],k:0,s:"Sora, Ali, Bek, Doston."},
{t:"Ali Bekdan baland. Bek Soradan past. Sora Alidan past. Doston hammadan past. Eng balandi kim?",o:["Ali","Sora","Bek","Doston"],k:0,s:"Ali > Sora > Bek > Doston."},
{t:"Ali: «Bugun dushanba». Bek: «Bugun seshanba». Sora: «Ertaga chorshanba». Faqat bittasi rost gapirdi. Bugun qaysi kun?",o:["dushanba","seshanba","chorshanba","yakshanba"],k:0,s:"Seshanba bo'lsa Bek va Sora ikkalasi rost. Dushanba bo'lsa — faqat Ali rost ✓."},
{t:"A: «B — rostgo'y». B: «Biz har xilmiz». Kim kim?",o:["ikkalasi yolg'onchi","ikkalasi rostgo'y","A — rostgo'y, B — yolg'onchi","A — yolg'onchi, B — rostgo'y"],k:0,s:"B rostgo'y bo'lsa, A yolg'onchi, lekin A ning gapi rost bo'lib qoladi ✗. B yolg'onchi → ular bir xil → A ham yolg'onchi ✓."},
{t:"Kitobni kimdir olgan. Ali: «Vali oldi». Vali: «G'ani oldi». G'ani: «Vali yolg'on gapiryapti». Soli: «Men olmadim». Faqat bittasi rost. Kim olgan?",o:["Soli","Ali","Vali","G'ani"],k:0,s:"Soli bo'lsa: faqat G'anining gapi rost. Boshqa holatlarda 2–3 ta rost."},
{t:"Ali, Bek, Sora — Toshkent, Buxoro, Xivada yashaydi. Ali Toshkentda emas. Bek Xivada ham, Toshkentda ham emas. Kim qayerda?",o:["Sora — Toshkent, Ali — Xiva","Sora — Xiva, Ali — Toshkent","Sora — Buxoro, Ali — Xiva","Sora — Toshkent, Ali — Buxoro"],k:0,s:"Bek — Buxoro; Ali Toshkentda emas → Xiva; Sora — Toshkent."},
{t:"To'rt kishi navbatda. Ali birinchi ham, oxirgi ham emas. Bek Alidan keyin, lekin oxirgi emas. Sora oxirgi emas. Doston nechanchi?",o:["4","1","2","3"],k:0,s:"Ali 2, Bek 3, Sora 1, Doston 4."},
{t:"A: «B ham, C ham rostgo'y». B: «A — yolg'onchi». C: «B — yolg'onchi». Kim rostgo'y?",o:["faqat B","faqat C","B va C","hech kim"],k:0,s:"A rost bo'lsa B ham rost, lekin B «A yolg'onchi» deydi ✗. A — yolg'onchi, B — rostgo'y, C — yolg'onchi."},
{t:"Ali, Bek, Sora, Doston yugurishdi. Bek — birinchi. Ali oxirgi emas. Sora ham oxirgi emas. Sora Alidan oldin keldi. Kim uchinchi?",o:["Ali","Bek","Sora","Doston"],k:0,s:"Bek 1, Doston 4 (Ali va Sora oxirgi emas), Sora 2, Ali 3."},
{t:"1: «Oltin 3-qutida». 2: «Oltin 1-qutida emas». 3: «Oltin shu yerda emas». 4: «Oltin 2-qutida». Faqat bitta yozuv rost. Oltin qayerda?",o:["1-qutida","2-qutida","3-qutida","4-qutida"],k:0,s:"1-qutida: faqat 3-yozuv rost."},
{t:"Ali, Bek, Sora, Doston — futbol, kurash, shaxmat, tennis. Bek kurashchi ham, futbolchi ham emas. Sora tennis o'ynaydi. Doston kurash bilan shug'ullanmaydi. Ali nima bilan shug'ullanadi?",o:["kurash","futbol","shaxmat","tennis"],k:0,s:"Sora — tennis; Bek — shaxmat; Doston — futbol; Ali — kurash."}
];
function PRACT_STAGE(){m6F2()}
var PREP_DATA={teach:["Jadval usuli: ✗ va ✓, har qator va ustunda bitta ✓.","Faraz va ziddiyat: «agar … bo'lsa».","Rostgo'y va yolg'onchi gaplari.","«Faqat bittasi rost»: har holatni tekshirish."],
 mist:["Shartdagi yashirin ma'lumotni («do'sti») ko'rmaydi.","Bitta holatni tekshirib, qolganlarini tashlab ketadi.","Yolg'onchining gapini «teskarisi» deb noto'g'ri tushunadi."],
 need:["Jadvalli varaqlar (3×3, 4×4).","«R» va «Y» kartochkalari.","4 ta quti va tanga."],
 board:["Jadval: ✗ ✗ → ✓","Faraz → ziddiyat → ✗","Har holat: rostlarni sanash","«Men yolg'onchiman» — hech kim aytolmaydi"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
