var CODE='4E3',TITLE='4-sinf · Qarama-qarshi va bir yo‘nalishdagi harakat';
function e3Car(x,y,col){var g=E('g',{transform:'translate('+(x-12)+','+(y-20)+')'},S.g);E('rect',{x:0,y:4,width:24,height:9,rx:3,fill:col},g);E('rect',{x:5,y:0,width:13,height:6,rx:2,fill:col},g);E('circle',{cx:6,cy:14,r:2.6,fill:'#33475b'},g);E('circle',{cx:18,cy:14,r:2.6,fill:'#33475b'},g)}
function e3S(L,step,a,b,jumps,marks){var X=w3Ray(0,L,step,marks||[],{all:1,y:116});(jumps||[]).forEach(function(j){w3Jump(j[0],j[1],j[2],j[3],116,j[4]||30)});if(a!=null)e3Car(X(a),116,C.blue);if(b!=null)e3Car(X(b),116,C.bad);return X}
var P1=[function(){e3S(300,50,0,300,[],[[0,'A',C.blue],[300,'B',C.bad]]);w3Msg('A va B oralig‘i 300 km. Ko‘k — 70 km/soat, qizil — 80 km/soat, bir-biriga qarab')},
 function(){e3S(300,50,70,220,[[0,70,'70',C.blue],[300,220,'80',C.bad]],[[0,'A',C.blue],[300,'B',C.bad]]);w3Msg('1 soatda ular 70 + 80 = <b>150 km</b> ga yaqinlashdi')},
 function(){e3S(300,50,140,140,[[0,70,'70',C.blue],[70,140,'70',C.blue],[300,220,'80',C.bad],[220,140,'80',C.bad]],[[0,'A',C.blue],[300,'B',C.bad]]);w3Msg('2 soatda: 150 · 2 = 300 km — <b>uchrashdi!</b>')},
 function(){e3S(300,50,140,140,[[0,140,'140 km',C.blue,40],[300,140,'160 km',C.bad,40]],[[0,'A',C.blue],[300,'B',C.bad]]);w3Msg('t = 300 : (70 + 80) = 2 soat. Ko‘k 140 km, qizil 160 km yurdi')}];
var P5=[function(){e3S(180,30,0,30,[],[[0,'',C.blue],[30,'',C.bad]]);w3Msg('Qizil 30 km oldinda, 50 km/soat. Ko‘k orqada, 60 km/soat — quvlaydi')},
 function(){e3S(180,30,60,80,[[0,60,'60',C.blue],[30,80,'50',C.bad]]);w3Msg('1 soatda: ko‘k 60 km, qizil 50 km. Oraliq 30 dan 20 ga qisqardi (−10)')},
 function(){e3S(180,30,120,130,[[0,120,'60 · 2',C.blue,46],[30,130,'50 · 2',C.bad,14]]);w3Msg('2 soatda oraliq yana 10 km qisqardi: 10 km qoldi')},
 function(){e3S(180,30,180,180,[[0,180,'60 · 3 = 180',C.blue,46],[30,180,'50 · 3',C.bad,14]]);w3Msg('3 soatda — yetib oldi! t = 30 : (60 − 50) = <b>3 soat</b>')}];
var P8=[function(){w3Bar([{lab:'',segs:[{w:420,t:'420 km'}],tot:420}],{top:60});w3Msg('420 km, bir vaqtda qarshi chiqishdi. 3 soatdan keyin 60 km qoldi')},
 function(){w3Bar([{lab:'',segs:[{w:360,t:'3 soatda yurildi: 360'},{w:60,t:'60',c:'#fff'}],tot:420,br:'420',brw:1}],{top:60});w3Msg('Ikkalasi birga 3 soatda: 420 − 60 = <b>360 km</b>')},
 function(){w3Expr(['yaqinlashish tezligi = 360 : 3 = {120}','1-chi = 120 − 50 = {70} km/soat']);w3Msg('Ikkinchisi 50 km/soat bo‘lsa, birinchisi 70 km/soat')}];
var STEPS=[
{h:"Qarama-qarshi harakat: uchrashuv",sum:"300 km, 70 va 80 km/soat: yaqinlashish tezligi 150 km/soat, uchrashuv 300 : 150 = 2 soatda.",a:"m01",
 start:w4St(P1),fin:w4Fin(P1),
 html:"<p>Ikki mashina A va B dan <b>bir vaqtda bir-biriga qarab</b> yo'lga chiqdi. Kuzating:</p>",btns:[phaser(P1)],
 after:"<p>Bir-biriga qarab harakatda har soatda oraliq ikkala tezlik yig'indisiga qisqaradi: <b>yaqinlashish tezligi = v₁ + v₂</b>. Uchrashuv vaqti: <b>t = s : (v₁ + v₂)</b>.</p>",
 q:{t:"Shaharlar oralig'i 300 km. Ikki mashina bir vaqtda bir-biriga qarab chiqdi: 70 va 80 km/soat. Necha soatdan keyin uchrashadi?",opts:["2 soat","30 soat","150 soat","4 soat"],ok:0,why:"300 : 150 = 2.",hint:"Avval yaqinlashish tezligi.",full:"70 + 80 = 150 km/soat, 300 : 150 = 2 soat. «30» — tezliklar farqiga bo'lish (bu quvlashda!)."},
 tn:"Ikki bola sinfning qarama-qarshi devorlaridan bir-biriga qarab qadam tashlaydi — har «soat»da (chapak) bittadan qadam."},
{h:"Uchrashuv vaqtini toping",sum:"360 km, 50 va 40 km/soat: 360 : 90 = 4 soat.",a:"m02",
 start:function(){e3S(360,60,0,360,[],[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('360 km, 50 va 40 km/soat')},fin:function(){e3S(360,60,200,200,[[0,200,'50 · 4',C.blue,36],[360,200,'40 · 4',C.bad,36]],[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('360 : (50 + 40) = 4 soat')},
 html:"<p>Ikki shahar oralig'i 360 km. Avtobus (50 km/soat) va yuk mashinasi (40 km/soat) bir vaqtda bir-biriga qarab chiqdi. Necha soatdan keyin uchrashadi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['4 soat','36 soat','9 soat'],'4 soat',function(){e3S(360,60,200,200,[[0,200,'50 · 4',C.blue,36],[360,200,'40 · 4',C.bad,36]],[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('To‘g‘ri: 360 : 90 = 4 soat');done()},{'36 soat':'360 : (50 − 40) = 36 — farq quvlashda ishlatiladi, bu yerda yig‘indi','9 soat':'360 : 40 = 9 — faqat bitta mashina hisobga olindi'})},
 after:"<p>Tekshiruv: 4 soatda avtobus 200 km, mashina 160 km — jami 360 km ✓. Bu tekshiruv bir yo'la keyingi savolga ham javob beradi: har biri qancha yo'l bosdi.</p>",
 q:{t:"Ikki piyoda bir-biriga qarab 5 va 4 km/soat tezlikda yurib, 2 soatdan keyin uchrashdi. Ular orasidagi masofa qancha edi?",opts:["18 km","2 km","9 km","40 km"],ok:0,why:"(5 + 4) · 2 = 18.",hint:"s = (v₁ + v₂) · t.",full:"Yaqinlashish tezligi 9 km/soat, 2 soatda 18 km. «2» — tezliklar farqi; «9» — vaqt unutilgan."},
 tn:"Yaqinlashish tezligini doskada ikki strelka (→ ←) bilan chizing, ustiga «+» qo'ying."},
{h:"Kim qancha yo'l bosdi?",sum:"4 soatda: avtobus 50 · 4 = 200 km, yuk mashinasi 40 · 4 = 160 km. 200 + 160 = 360 ✓.",a:"m03",
 start:function(){S.w4={};e3S(360,60,null,null,[],[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('Uchrashuvgacha 4 soat. Har biri qancha yurdi?')},fin:function(){e3S(360,60,200,200,[[0,200,'200 km',C.blue,40],[360,200,'160 km',C.bad,40]],[[0,'A',C.blue],[360,'B',C.bad],[200,'',C.ok]]);w3Msg('Uchrashuv joyi A dan 200 km, B dan 160 km')},
 html:"<p>Uchrashuvgacha 4 soat o'tdi. Ikkalasini ham bosib hisoblang:</p>",
 btns:[["Avtobus (50)",function(c,done){S.w4.a=1;e3S(360,60,200,S.w4.b?200:null,[[0,200,'50 · 4 = 200',C.blue,40]].concat(S.w4.b?[[360,200,'160',C.bad,40]]:[]),[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('Avtobus: 50 · 4 = <b>200 km</b>');if(S.w4.b)done()}],["Yuk mashina (40)",function(c,done){S.w4.b=1;e3S(360,60,S.w4.a?200:null,200,[[360,200,'40 · 4 = 160',C.bad,40]].concat(S.w4.a?[[0,200,'200',C.blue,40]]:[]),[[0,'A',C.blue],[360,'B',C.bad]]);w3Msg('Yuk mashinasi: 40 · 4 = <b>160 km</b>');if(S.w4.a)done()},'u']],g2:1,
 after:"<p>Tezroq mashina ko'proq yo'l bosadi, shuning uchun uchrashuv joyi <b>sekinroq</b> mashinaning shahriga yaqinroq. Tekshiruv: 200 + 160 = 360 ✓.</p>",
 q:{t:"Ikki shahar oralig'i 540 km. Ikki mashina bir vaqtda qarshi chiqib, 4 soatdan keyin uchrashdi. Birinchisining tezligi 75 km/soat. Ikkinchisining tezligi?",opts:["60 km/soat","135 km/soat","75 km/soat","465 km/soat"],ok:0,why:"540 : 4 = 135 — yig'indi; 135 − 75 = 60.",hint:"Avval yaqinlashish tezligi: 540 : 4.",full:"v₁ + v₂ = 540 : 4 = 135, v₂ = 135 − 75 = 60 km/soat. «135» — yig'indi, ikkinchisining tezligi emas."},
 tn:"Bolalar uchrashuv nuqtasini son nurida belgilasin va ikki tomondan masofalarni yozsin."},
{h:"Qarama-qarshi tomonga: uzoqlashish",sum:"Bir joydan qarama-qarshi tomonga 12 va 15 km/soat: har soatda 27 km uzoqlashadi, 3 soatda 81 km.",a:"m04",
 start:function(){var X=w3Ray(0,100,10,[[50,'',C.ok]],{all:0,every:5,y:116});e3Car(X(50),116,C.blue);e3Car(X(50),116,C.bad);w3Msg('Ikki velosipedchi bir joydan qarama-qarshi tomonga')},fin:function(){var X=w3Ray(0,100,10,[[50,'',C.ok]],{all:0,every:5,y:116});w3Jump(50,14,'12 · 3 = 36',C.blue,116,34);w3Jump(50,95,'15 · 3 = 45',C.bad,116,34);e3Car(X(14),116,C.blue);e3Car(X(95),116,C.bad);w3Msg('Oraliq: 36 + 45 = 81 km  yoki  (12 + 15) · 3 = 81')},
 html:"<p>Ikki velosipedchi bir joydan <b>qarama-qarshi tomonga</b> 12 va 15 km/soat tezlikda chiqdi. 3 soatdan keyin ular orasidagi masofa?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['81 km','9 km','27 km'],'81 km',function(){var X=w3Ray(0,100,10,[[50,'',C.ok]],{all:0,every:5,y:116});w3Jump(50,14,'12 · 3 = 36',C.blue,116,34);w3Jump(50,95,'15 · 3 = 45',C.bad,116,34);e3Car(X(14),116,C.blue);e3Car(X(95),116,C.bad);w3Msg('To‘g‘ri: (12 + 15) · 3 = 81 km');done()},{'9 km':'15 − 12 = 3, 3 · 3 = 9 — bu bir tomonga ketganda bo‘lardi','27 km':'27 km — 1 soatdagi uzoqlashish. 3 soat-chi?'})},
 after:"<p>Qarama-qarshi tomonga harakatda ham tezliklar <b>qo'shiladi</b>, faqat oraliq qisqarmaydi, aksincha <b>ortadi</b>: <b>uzoqlashish tezligi = v₁ + v₂</b>.</p>",
 q:{t:"Ikki poyezd bir stansiyadan qarama-qarshi tomonga 80 va 70 km/soat tezlikda chiqdi. Necha soatdan keyin ular orasidagi masofa 600 km bo'ladi?",opts:["4 soat","60 soat","8 soat","10 soat"],ok:0,why:"600 : 150 = 4.",hint:"Uzoqlashish tezligi: 80 + 70.",full:"80 + 70 = 150 km/soat; 600 : 150 = 4 soat. «60» — tezliklar farqiga bo'lish."},
 tn:"Ikki bola orqa-orqaga turib, qarama-qarshi tomonga yuradi — oradagi masofa qanday o'zgarishini butun sinf kuzatadi."},
{h:"Bir yo'nalishda: quvlash",sum:"Qizil 30 km oldinda (50 km/soat), ko'k quvlaydi (60 km/soat): har soatda 10 km yaqinlashadi, 3 soatda yetib oladi.",a:"m05",
 start:w4St(P5),fin:w4Fin(P5),
 html:"<p>Ikki mashina <b>bir yo'nalishda</b> harakatlanmoqda. Orqadagi tezroq. Kuzating:</p>",btns:[phaser(P5)],
 after:"<p>Bir yo'nalishda harakatda tezliklar <b>ayiriladi</b>: <b>yaqinlashish tezligi = v₁ − v₂</b> (tezroq − sekinroq). Yetib olish vaqti: <b>t = oraliq : (v₁ − v₂)</b> = 30 : 10 = 3 soat.</p>",
 q:{t:"Sichqon mushukdan 20 m oldinda. Mushuk 7 m/sek, sichqon 5 m/sek tezlikda yuguradi. Mushuk necha sekundda yetib oladi?",opts:["10 sek","20 sek","4 sek","2 sek"],ok:0,why:"20 : (7 − 5) = 10.",hint:"Har sekundda qancha yaqinlashadi?",full:"Har sekundda 7 − 5 = 2 m yaqinlashadi; 20 : 2 = 10 sek. «2» — tezliklar farqining o'zi; «4» — 20 : 5."},
 tn:"«Quvlashmachoq»: sekin bola oldinda, tez bola orqada. Har chapakda qadamlar soni bilan oraliqni o'lchang."},
{h:"Oldingi tezroq bo'lsa",sum:"Oldinda 60 km/soat, orqada 50 km/soat, boshda 30 km: har soatda oraliq 10 km ortadi, 2 soatda 50 km.",a:"m06",
 start:function(){e3S(180,30,0,30,[],[]);w3Msg('Endi oldindagi (qizil) tezroq: 60 km/soat, ko‘k 50 km/soat. Boshda 30 km')},fin:function(){e3S(180,30,100,150,[[0,100,'50 · 2',C.blue,46],[30,150,'60 · 2',C.bad,14]]);w3Msg('2 soatdan keyin: 30 + (60 − 50) · 2 = 50 km')},
 html:"<p>Ko'k mashina (50 km/soat) qizildan (60 km/soat) 30 km orqada, ikkalasi bir yo'nalishda. 2 soatdan keyin ular orasidagi masofa?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['50 km','10 km','250 km'],'50 km',function(){e3S(180,30,100,150,[[0,100,'50 · 2',C.blue,46],[30,150,'60 · 2',C.bad,14]]);w3Msg('To‘g‘ri: oraliq har soatda 10 km ortadi');done()},{'10 km':'Oraliq qisqarmaydi — oldindagi tezroq, u uzoqlashadi!','250 km':'(60 + 50) · 2 + 30 — bir yo‘nalishda tezliklar qo‘shilmaydi'})},
 after:"<p>Doim savol bering: <b>oraliq qisqaryaptimi yoki ortyaptimi?</b> Orqadagi tezroq — qisqaradi; oldindagi tezroq — ortadi. Ikkala holda ham o'zgarish tezligi = <b>tezliklar farqi</b>.</p>",
 q:{t:"Ikki velosipedchi bir joydan bir yo'nalishda 15 va 12 km/soat tezlikda chiqdi. 4 soatdan keyin ular orasidagi masofa?",opts:["12 km","108 km","3 km","27 km"],ok:0,why:"(15 − 12) · 4 = 12.",hint:"Har soatda oraliq qanchaga ortadi?",full:"15 − 12 = 3 km/soat, 3 · 4 = 12 km. «108» — tezliklar yig'indisi bilan (qarama-qarshi tomonga bo'lganda); «3» — vaqt unutilgan."},
 tn:"Jadval tuzdiring: soat | 1-chi | 2-chi | oraliq — har qatorda oraliq 10 ga ortishini bolalar o'zi ko'rsin."},
{h:"Tuzoq: qo'shish yoki ayirish?",sum:"80 km/soat 60 km/soatni quvlaydi, oraliq 40 km: 40 : (80 − 60) = 2 soat (qo'shish emas!).",a:"m07",
 start:function(){e3S(200,40,0,40,[],[]);w3Msg('Ko‘k 80 km/soat, qizil 60 km/soat, oraliq 40 km — bir yo‘nalishda')},fin:function(){e3S(200,40,160,160,[[0,160,'80 · 2',C.blue,46],[40,160,'60 · 2',C.bad,14]]);w3Msg('40 : 20 = 2 soat — yetib oldi')},
 html:"<p>Ko'k mashina (80 km/soat) 40 km oldindagi qizilni (60 km/soat) quvlayapti. Qaysi ifoda yetib olish vaqtini beradi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['40 : (80 − 60)','40 : (80 + 60)','40 · (80 − 60)'],'40 : (80 − 60)',function(){e3S(200,40,160,160,[[0,160,'80 · 2',C.blue,46],[40,160,'60 · 2',C.bad,14]]);w3Msg('To‘g‘ri: 40 : 20 = 2 soat');done()},{'40 : (80 + 60)':'Bir yo‘nalishda tezliklar qo‘shilmaydi — ular bir-biridan «qochadi»','40 · (80 − 60)':'Vaqt = masofa : tezlik, ko‘paytma emas'})},
 after:"<div class='life'><div>→ ←<span>bir-biriga qarab: <b>v₁ + v₂</b> (yaqinlashadi)</span></div><div>← →<span>qarama-qarshi tomonga: <b>v₁ + v₂</b> (uzoqlashadi)</span></div><div>→ →<span>bir yo'nalishda: <b>v₁ − v₂</b> (orqadagi tez — yaqinlashadi, oldindagi tez — uzoqlashadi)</span></div></div>",
 q:{t:"Ikki mashina bir yo'nalishda: orqadagisi 70 km/soat, oldingisi 40 km/soat, oraliq 90 km. 2 soatdan keyin oraliq qancha bo'ladi?",opts:["30 km","150 km","60 km","20 km"],ok:0,why:"90 − (70 − 40) · 2 = 30.",hint:"Har soatda 30 km yaqinlashadi.",full:"Yaqinlashish tezligi 30 km/soat, 2 soatda 60 km; 90 − 60 = 30 km. «60» — yaqinlashgan masofa; «150» — oraliq ortadi deb o'ylash."},
 tn:"Uchta strelkali jadvalni plakat qilib osing. Har masalada bola avval strelkalarni chizsin."},
{h:"Teskari masala: tezlikni toping",sum:"420 km, 3 soatdan keyin 60 km qoldi: 360 : 3 = 120 km/soat — yig'indi; ikkinchisi 50 bo'lsa, birinchisi 70.",a:"m08",
 start:w4St(P8),fin:w4Fin(P8),
 html:"<p>«Ikki shahar oralig'i 420 km. Ikki mashina bir vaqtda bir-biriga qarab chiqdi. 3 soatdan keyin ular orasida 60 km qoldi. Ikkinchisining tezligi 50 km/soat. Birinchisining tezligi?»</p>",btns:[phaser(P8)],
 after:"<p>Tuzoq: 420 : 3 = 140 deb, «qolgan 60 km» ni unutish. Ular hali uchrashmagan! Avval <b>birgalikda yurilgan</b> yo'lni topamiz: 420 − 60 = 360.</p>",
 q:{t:"Shaharlar oralig'i 420 km. Ikki mashina bir vaqtda qarshi chiqdi; 3 soatdan keyin orada 60 km qoldi. Ikkinchisining tezligi 50 km/soat. Birinchisiniki?",opts:["70 km/soat","90 km/soat","120 km/soat","50 km/soat"],ok:0,why:"(420 − 60) : 3 = 120; 120 − 50 = 70.",hint:"Avval birgalikda yurilgan yo'l.",full:"360 : 3 = 120 km/soat (yig'indi), 120 − 50 = 70. «90» — 420 : 3 − 50 (qolgan 60 km unutilgan); «120» — yig'indi."},
 tn:"Chizmada «qoldi» qismini boshqa rang bilan bo'yang — bolalar uni ko'rib turishi muhim."},
{h:"Bilasizmi? Axilles va toshbaqa",sum:"Qadimgi yunon faylasufi Zenon (mil. av. V asr) «Axilles toshbaqaga hech qachon yetolmaydi» degan jumboqni o'ylab topgan.",a:"m09",
 start:function(){e3S(100,10,0,50,[],[]);w3Msg('Axilles toshbaqadan 10 marta tez, toshbaqa 50 m oldinda')},fin:function(){e3S(100,10,0,50,[],[]);w3Msg('Quvlash tezligi = tezliklar farqi — Axilles albatta yetib oladi!')},
 html:"<p>📜 Qadimgi yunon faylasufi <b>Zenon</b> (miloddan avvalgi V asr) jumbog'i: «Tez yuguruvchi Axilles toshbaqaga yetolmaydi: u toshbaqa turgan joyga yetguncha, toshbaqa yana biroz oldinga o'tadi, va hokazo cheksiz…»</p><p>⭐ Bu jumboq matematiklarni 2000 yildan ortiq o'ylantirgan. Bugun biz bilamiz: quvlash tezligi = tezliklar farqi, demak Axilles aniq vaqtda yetib oladi. Siz buni hisoblay olasiz!</p>",
 tn:"Bolalar bilan tortishuv: «Zenon nimada adashgan?» — cheksiz ko'p bosqich chekli vaqtda tugashi mumkin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['→ ←  :  v₁ + v₂','← →  :  v₁ + v₂','→ →  :  v₁ − v₂']);w3Msg('Strelkalar qoidasi')},fin:function(){w3Expr(['→ ←  :  v₁ + v₂','← →  :  v₁ + v₂','→ →  :  v₁ − v₂']);w3Msg('Strelkalar qoidasi')},
 html:"<div class='memo'><ul><li>Bir-biriga qarab: yaqinlashish tezligi v₁ + v₂; uchrashuv vaqti t = s : (v₁ + v₂).</li><li>Qarama-qarshi tomonga: uzoqlashish tezligi v₁ + v₂.</li><li>Bir yo'nalishda: v₁ − v₂; quvlash vaqti t = oraliq : (v₁ − v₂).</li><li>Avval so'rang: oraliq qisqaryaptimi yoki ortyaptimi?</li><li>«Hali uchrashmadi, X km qoldi» — avval birgalikda yurilgan yo'lni toping.</li><li>Tekshiruv: har birining yo'lini alohida hisoblab, qo'shing.</li></ul></div>",
 tn:"Kartochka 4E9 (daryo oqimi) va 4E13 (kechikishli harakat) mavzulari uchun asos."}
];
var PROBS=[
{t:"Shaharlar oralig'i 300 km. Ikki mashina bir vaqtda bir-biriga qarab chiqdi: 70 va 80 km/soat. Necha soatdan keyin uchrashadi?",o:["2 soat","30 soat","150 soat","4 soat"],k:0,s:"300 : 150 = 2."},
{t:"Shaharlar oralig'i 360 km. Avtobus (50 km/soat) va mashina (40 km/soat) bir vaqtda qarshi chiqdi. Necha soatdan keyin uchrashadi?",o:["4 soat","36 soat","9 soat","8 soat"],k:0,s:"360 : 90 = 4."},
{t:"Oldingi masalada avtobus (50 km/soat) uchrashguncha qancha yo'l bosdi?",o:["200 km","160 km","180 km","90 km"],k:0,s:"50 · 4 = 200."},
{t:"Ikki velosipedchi bir joydan qarama-qarshi tomonga 12 va 15 km/soat tezlikda chiqdi. 3 soatdan keyin oraliq?",o:["81 km","9 km","27 km","45 km"],k:0,s:"27 · 3 = 81."},
{t:"Qizil mashina 30 km oldinda, 50 km/soat. Ko'k mashina orqadan 60 km/soat tezlikda quvlaydi. Necha soatda yetib oladi?",o:["3 soat","30 soat","10 soat","6 soat"],k:0,s:"30 : 10 = 3."},
{t:"Ko'k mashina (50 km/soat) qizildan (60 km/soat) 30 km orqada, bir yo'nalishda. 2 soatdan keyin oraliq?",o:["50 km","10 km","250 km","20 km"],k:0,s:"30 + 10 · 2 = 50."},
{t:"Shaharlar oralig'i 420 km. Ikki mashina bir vaqtda qarshi chiqdi; 3 soatdan keyin orada 60 km qoldi. Ikkinchisining tezligi 50 km/soat. Birinchisiniki?",o:["70 km/soat","90 km/soat","120 km/soat","50 km/soat"],k:0,s:"360 : 3 = 120; 120 − 50 = 70."},
{t:"Ikki piyoda bir-biriga qarab 5 va 4 km/soat tezlikda yurib, 2 soatdan keyin uchrashdi. Masofa qancha edi?",o:["18 km","2 km","9 km","40 km"],k:0,s:"9 · 2 = 18."},
{t:"Ikki poyezd bir stansiyadan qarama-qarshi tomonga 80 va 70 km/soat tezlikda chiqdi. Necha soatdan keyin oraliq 600 km bo'ladi?",o:["4 soat","60 soat","8 soat","10 soat"],k:0,s:"600 : 150 = 4."},
{t:"Sichqon mushukdan 20 m oldinda. Mushuk 7 m/sek, sichqon 5 m/sek. Mushuk necha sekundda yetib oladi?",o:["10 sek","20 sek","4 sek","2 sek"],k:0,s:"20 : 2 = 10."},
{t:"Ikki velosipedchi bir joydan bir yo'nalishda 15 va 12 km/soat tezlikda chiqdi. 4 soatdan keyin oraliq?",o:["12 km","108 km","3 km","27 km"],k:0,s:"3 · 4 = 12."},
{t:"Ikki shahardan bir vaqtda qarshi chiqishdi: birinchisi 65 km/soat, ikkinchisi undan 10 km/soat sekin. 5 soatda uchrashishdi. Shaharlar oralig'i?",o:["600 km","650 km","700 km","120 km"],k:0,s:"(65 + 55) · 5 = 600."},
{t:"Ali va Vali oralig'i 2 km. Ular bir-biriga qarab 60 va 40 m/min tezlikda yurdi. Necha minutda uchrashadi?",o:["20 min","100 min","50 min","2 min"],k:0,s:"2000 : 100 = 20."},
{t:"A dan piyoda 5 km/soat tezlikda chiqdi. 3 soatdan keyin shu yo'ldan velosipedchi 20 km/soat tezlikda chiqdi. Velosipedchi chiqqanidan necha soat o'tib piyodaga yetib oladi?",o:["1 soat","2 soat","3 soat","4 soat"],k:0,s:"Oraliq 15 km, yaqinlashish 15 km/soat → 1 soat."},
{t:"Ikki mashina qarshi kelib, 45 va 55 km/soat tezlikda uchrashdi va to'xtamay davom etdi. Uchrashuvdan 1 soat keyin ular orasidagi masofa?",o:["100 km","200 km","10 km","0 km"],k:0,s:"Endi uzoqlashadi: 45 + 55 = 100."},
{t:"Bir yo'nalishda: orqadagi mashina 70 km/soat, oldingisi 40 km/soat, oraliq 90 km. 2 soatdan keyin oraliq?",o:["30 km","150 km","60 km","20 km"],k:0,s:"90 − 30 · 2 = 30."},
{t:"Orqadagi mashina 80 km/soat, oldingisi 60 km/soat, oraliq 40 km, bir yo'nalishda. Necha soatda yetib oladi?",o:["2 soat","1 soat","4 soat","20 soat"],k:0,s:"40 : 20 = 2."},
{t:"Ikki kema bir portdan qarama-qarshi yo'nalishda 30 va 25 km/soat tezlikda chiqdi. 5 soatdan keyin oraliq?",o:["275 km","25 km","55 km","150 km"],k:0,s:"55 · 5 = 275."},
{t:"Shaharlar oralig'i 540 km. Ikki mashina bir vaqtda qarshi chiqib, 4 soatdan keyin uchrashdi. Birinchisining tezligi 75 km/soat. Ikkinchisiniki?",o:["60 km/soat","135 km/soat","75 km/soat","465 km/soat"],k:0,s:"135 − 75 = 60."},
{t:"Toshbaqa quyondan 100 m oldinda, minutiga 2 m yuradi. Quyon minutiga 12 m yuguradi. Quyon necha minutda yetib oladi?",o:["10 min","50 min","14 min","100 min"],k:0,s:"100 : (12 − 2) = 10."}
];
function PRACT_STAGE(){w3Expr(['→ ←  :  v₁ + v₂','← →  :  v₁ + v₂','→ →  :  v₁ − v₂']);w3Msg('Avval strelkalarni chizing')}
var PREP_DATA={teach:["Bir-biriga qarab harakat: yaqinlashish tezligi, uchrashuv vaqti.","Qarama-qarshi tomonga harakat: uzoqlashish tezligi.","Bir yo'nalishdagi harakat: quvlash, oraliq o'zgarishi.","Teskari masalalar: tezlik va masofani topish."],
 mist:["Quvlashda tezliklarni qo'shadi.","Qarama-qarshi harakatda tezliklar farqini oladi.","«Hali X km qoldi» ni unutadi.","Oraliq qisqaryaptimi yoki ortyaptimi — tekshirmaydi."],
 need:["Polga chizilgan son nuri, ikki o'yinchoq mashina.","Strelkalar plakati."],
 board:["<span class='w2'>300 : (70 + 80) = 2 soat</span>.","<span class='w2'>(12 + 15) · 3 = 81 km</span>.","<span class='w2'>30 : (60 − 50) = 3 soat</span>.","<span class='w2'>(420 − 60) : 3 − 50 = 70</span>.","<span class='w2'>→ ← va ← → : +; → → : −</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
