// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F10',TITLE='4-sinf · Uzunlik va massa o‘nli kasrlarda';
function f10ruler(st){clear();var x=30,w=300,y=60,g=S.g;E('rect',{x:x,y:y,width:w,height:30,fill:'#fff3cf',stroke:'#a8801f','stroke-width':1.6},g);
 for(var i=0;i<=100;i++){var X=x+i*w/100,big=i%10===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?16:(i%5===0?10:6)),stroke:'#7a5a12','stroke-width':big?1.6:.7},g);if(big&&i<100&&i>0)T(g,X,y+28,String(i),{'font-size':9,fill:'#7a5a12'})}
 f4t(180,40,'1 m = 10 dm = 100 sm',14);if(st>=1){E('rect',{x:x,y:y-6,width:w/10,height:6,fill:C.blue},g);f4t(x+15,y+52,'1 dm = 0,1 m',12,C.blue,'start')}
 if(st>=2){E('rect',{x:x+w/10,y:y-6,width:w/100,height:6,fill:C.bad},g);f4t(x+w,y+52,'1 sm = 0,01 m',12,C.bad,'end')}
 if(st>=3)f4t(180,160,'1 mm = 0,001 m',12,'#5b6b7b')}
var F10P1=[function(){f10ruler(0);f4c(['Metr chizg‘ichi: 10 dm, 100 sm'])},function(){f10ruler(1);f4c(['1 dm — metrning o‘ndan biri: <b>0,1 m</b>'])},function(){f10ruler(2);f4c(['1 sm — metrning yuzdan biri: <b>0,01 m</b>'])},function(){f10ruler(3);f4c(['1 mm — metrning mingdan biri: <b>0,001 m</b> (1 m = 1000 mm)'])}];
var F10H=['m','dm','sm'];
function f10tab(d,show,lab){clear();var x0=70,w=74,y=36;F10H.forEach(function(h,i){E('rect',{x:x0+i*w,y:y,width:w,height:26,fill:i?'#e8f2fb':'#fff2dc',stroke:'#9bb3c9'},S.g);f4t(x0+i*w+w/2,y+18,h,13,'#33475b');E('rect',{x:x0+i*w,y:y+26,width:w,height:46,fill:'#fff',stroke:'#9bb3c9'},S.g);if(i<show)f4t(x0+i*w+w/2,y+60,d[i],26,i?C.blue:C.a2)});E('circle',{cx:x0+w,cy:y+66,r:4,fill:C.bad},S.g);if(lab)f4t(180,142,lab,17,C.ok)}
var F10P2=[function(){f10tab(['3','4','5'],0);f4c(['3 m 45 sm — metrlarda qanday yoziladi?'])},function(){f10tab(['3','4','5'],1);f4c(['Butun metrlar: 3 — vergulgacha'])},function(){f10tab(['3','4','5'],3,'3 m 45 sm = 3,45 m');f4c(['45 sm = 45/100 m = 0,45 m. Demak <b>3,45 m</b>','Detsimetrlar — o‘ndan birlar, santimetrlar — yuzdan birlar xonasida'])}];
function f10km(st){clear();var x=30,w=300,y=70,g=S.g;E('line',{x1:x,y1:y,x2:x+w,y2:y,stroke:'#33475b','stroke-width':6,'stroke-linecap':'round'},g);for(var i=0;i<=4;i++){E('line',{x1:x+i*w/4,y1:y-10,x2:x+i*w/4,y2:y+10,stroke:'#33475b','stroke-width':2},g)}
 f4t(x,y+28,'0',12);f4t(x+w,y+28,'1 km = 1000 m',12,'#33475b','end');f4t(x+w/4,y+28,'250 m',11,C.blue);if(st>=1)f4t(x+w/4,y-18,'0,25 km',12,C.blue);
 if(st>=2)f4t(180,140,'4 km 250 m = 4,250 km = 4,25 km',15,C.ok);if(st>=1)f4t(180,24,'1 m = 0,001 km',13,'#5b6b7b')}
var F10P4=[function(){f10km(0);f4c(['1 km = 1000 m — mingta metr'])},function(){f10km(1);f4c(['1 m = 1/1000 km = <b>0,001 km</b>; 250 m = 250/1000 km = <b>0,25 km</b>'])},function(){f10km(2);f4c(['Metrlar — <b>mingdan birlar</b>: verguldan keyin 3 ta raqam','4 km 250 m = <b>4,250 km</b> = 4,25 km'])}];
function f10scale(kg,g_,lab){clear();var g=S.g;E('rect',{x:100,y:110,width:160,height:40,rx:8,fill:'#cfd6de',stroke:'#7b8794','stroke-width':1.5},g);E('rect',{x:120,y:96,width:120,height:14,rx:4,fill:'#e9eef3',stroke:'#7b8794'},g);
 var n=0;for(var i=0;i<kg;i++){E('rect',{x:128+n*30,y:66,width:26,height:30,rx:4,fill:'#5b6b7b'},g);T(g,141+n*30,86,'1kg',{'font-size':8,fill:'#fff','font-weight':800});n++}
 if(g_){E('rect',{x:128+n*30,y:76,width:30,height:20,rx:4,fill:'#e0a85b'},g);T(g,143+n*30,90,g_+'g',{'font-size':8,fill:'#fff','font-weight':800})}
 E('rect',{x:150,y:120,width:60,height:22,rx:4,fill:'#1d2b3a'},g);T(g,180,136,lab,{'font-size':12,fill:'#7CFC9A','font-weight':800});f4t(180,30,'1 kg = 1000 g',14)}
var F10P5=[function(){f10scale(2,300,'2 kg 300 g');f4c(['2 kg 300 g — kilogrammlarda qanday yoziladi?'])},function(){f10scale(2,300,'2,300 kg');f4c(['300 g = 300/1000 kg = 0,300 kg = <b>0,3 kg</b>','2 kg 300 g = <b>2,3 kg</b>'])},function(){f10scale(0,750,'0,750 kg');f4c(['750 g = <b>0,75 kg</b> (butun kilogramm yo‘q — 0 butun)'])}];
var F10P7=[function(){clear();f4t(180,40,'3,2 m = ? m ? sm',18);f4t(180,90,'0,6 kg = ? g',18);f4c(['Teskari: o‘nli kasrdan eski birliklarga'])},
 function(){clear();f4t(180,40,'3,2 m = 3,20 m = 3 m 20 sm',16,C.blue);f4t(180,90,'0,6 kg = 0,600 kg = 600 g',16,C.a2);f4t(180,136,'Kerakli xonalar sonigacha nol qo‘shamiz',12,'#33475b');f4c(['3,2 m = <b>3 m 20 sm</b> (2 sm emas!)','0,6 kg = <b>600 g</b> (6 g emas!)'])}];
function PRACT_STAGE(){clear();f4t(180,30,'1 m = 10 dm = 100 sm',14,C.blue);f4t(180,60,'1 km = 1000 m',14,C.blue);f4t(180,90,'1 kg = 1000 g',14,C.a2);f4t(180,124,'3 m 45 sm = 3,45 m;  2 m 5 sm = 2,05 m',13,C.ok);f4t(180,152,'2 kg 300 g = 2,3 kg;  1 kg 50 g = 1,05 kg',13,C.ok);f4c(['Birlik nechta raqam talab qilishini unutmang: sm — 2 ta, g va m (km da) — 3 ta'])}
var STEPS=[
{h:"Metrning ulushlari",sum:"1 m = 10 dm = 100 sm. 1 dm = 0,1 m; 1 sm = 0,01 m; 1 mm = 0,001 m.",a:"m01",
 start:function(){startPh(F10P1)},fin:function(){S.ph=3;F10P1[3]()},
 html:"<p>Metr chizg'ichiga qarang. Detsimetr va santimetrni metrlarda qanday yozamiz? Bosing:</p>",btns:[phaser(F10P1)],
 after:"<p>Metr <b>10</b> ta detsimetrga, <b>100</b> ta santimetrga, <b>1000</b> ta millimetrga bo'linadi. Shuning uchun: 1 dm = 1/10 m = <b>0,1 m</b>, 1 sm = 1/100 m = <b>0,01 m</b>, 1 mm = 1/1000 m = <b>0,001 m</b>.</p><p>Metrik birliklar o'nli kasr bilan juda qulay — hammasi 10 ga bog'langan!</p>",
 q:{t:"1 sm metrning qanday qismi?",opts:["0,1 m","0,01 m","0,001 m","1,0 m"],ok:1,why:"1 m = 100 sm, 1 sm = 1/100 m.",hint:"1 metrda nechta santimetr bor?",full:"1 m = 100 sm, demak 1 sm = 1/100 m = 0,01 m. «0,1 m» — bu detsimetr, «0,001 m» — millimetr."},
 tn:"Har bir bolaga metrli lenta bering: 1 dm, 1 sm ni topib, ostiga o'nli kasrni yozdiring. Metrik tizim — o'nli kasrning eng tabiiy qo'llanishi."},
{h:"Ikki birlikdan biriga: 3 m 45 sm",sum:"3 m 45 sm = 3,45 m: santimetrlar — yuzdan birlar xonasida.",a:"m02",
 start:function(){startPh(F10P2)},fin:function(){S.ph=2;F10P2[2]()},
 html:"<p>Bo'yingiz 1 m 35 sm. Uni metrlarda — bitta son bilan yozish mumkin. Masalan 3 m 45 sm:</p>",btns:[phaser(F10P2)],
 after:"<p>Xonalar jadvali bilan: metr — butun, <b>detsimetr — o'ndan birlar</b>, <b>santimetr — yuzdan birlar</b>. 3 m 45 sm = 3 m 4 dm 5 sm = <b>3,45 m</b>.</p>",
 q:{t:"4 m 7 dm necha metr?",opts:["4,07 m","4,7 m","47 m","0,47 m"],ok:1,why:"7 dm = 0,7 m.",hint:"Detsimetr — qaysi xona?",full:"7 dm = 7/10 m = 0,7 m; 4 m 7 dm = 4,7 m. «4,07 m» — bu 4 m 7 sm, «47 m» — vergulni unutish."},
 tn:"Bolalar bir-birining bo'yini o'lchab, ikki xil yozsin: 1 m 32 sm = 1,32 m. Sinf jadvali tuzing."},
{h:"Tuzoq: 2 m 5 sm",sum:"2 m 5 sm = 2,05 m (2,5 m emas!). Santimetrga 2 ta xona kerak: 05.",a:"m03",
 start:function(){clear();f4t(180,60,'2 m 5 sm = ? m',26);f4msg('To‘g‘ri yozuvni tanlang')},
 fin:function(){f10tab(['2','0','5'],3,'2 m 5 sm = 2,05 m');f4msg('Detsimetr yo‘q — o‘ndan birlar xonasida <b>0</b>')},
 html:"<p>2 m 5 sm ni metrlarda yozing. Ko'p bolalar adashadi:</p>",
 btns:f4pick(1,[["2,5 m","2,5 m = 2 m 50 sm! 5 sm — yuzdan birlar xonasida turishi kerak."],["2,05 m","To'g'ri! 5 sm = 5/100 m = 0,05 m."],["2,005 m","Bu 2 m 5 mm bo'lardi — mingdan birlar xonasi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p><b>Santimetr — doim 2 ta raqam</b> verguldan keyin: 5 sm → <b>05</b>, 45 sm → 45. Xuddi pul kabi: 5 tiyin = 0,05 so'm.</p>",
 q:{t:"6 m 8 sm necha metr?",opts:["6,8 m","6,08 m","6,008 m","68 m"],ok:1,why:"8 sm = 0,08 m.",hint:"Santimetrga 2 ta xona kerak.",full:"8 sm = 8/100 m = 0,08 m. Javob: 6,08 m. «6,8 m» = 6 m 80 sm — nolni tushirib qoldirish xatosi."},
 tn:"Bu xatoni tushuntirish uchun lentada 2,5 m va 2,05 m ni belgilang — farq 45 sm ekan ko'rinadi."},
{h:"Kilometr va metr",sum:"1 km = 1000 m. 1 m = 0,001 km. 4 km 250 m = 4,25 km — metrlarga 3 ta xona.",a:"m04",
 start:function(){startPh(F10P4)},fin:function(){S.ph=2;F10P4[2]()},
 html:"<p>Maktabdan uyingizgacha 1 km 250 m. Buni kilometrlarda yozamiz. Bosing:</p>",btns:[phaser(F10P4)],
 after:"<p>1 km da <b>1000</b> m — demak metr <b>mingdan birlar</b> xonasida, verguldan keyin <b>3 ta</b> raqam: 4 km 250 m = 4,250 km. Oxiridagi nolni tashlash mumkin: <b>4,25 km</b>.</p><p>4 km 25 m = 4,025 km; 4 km 5 m = 4,005 km — nollar bilan to'ldiramiz.</p>",
 q:{t:"3 km 40 m necha kilometr?",opts:["3,4 km","3,04 km","3,004 km","340 km"],ok:1,why:"40 m = 0,040 km = 0,04 km.",hint:"Metrlarga 3 ta xona: 40 → 040.",full:"40 m = 40/1000 km = 0,040 km. 3 km 40 m = 3,040 km = 3,04 km. «3,4 km» = 3 km 400 m."},
 tn:"Xarita masshtabi bilan ishlash: tuman markazidan maktabgacha masofani km va m da, keyin o'nli kasrda yozdiring."},
{h:"Kilogramm va gramm",sum:"1 kg = 1000 g. 2 kg 300 g = 2,3 kg; 750 g = 0,75 kg.",a:"m05",
 start:function(){startPh(F10P5)},fin:function(){S.ph=2;F10P5[2]()},
 html:"<p>Tarozida 2 kg 300 g olma. Elektron tarozi buni qanday ko'rsatadi? Bosing:</p>",btns:[phaser(F10P5,'⚖️ Tortish')],
 after:"<p>Gramm — kilogrammning <b>mingdan biri</b>: 1 g = 0,001 kg. Shuning uchun grammga ham <b>3 ta</b> xona: 2 kg 300 g = 2,300 kg = <b>2,3 kg</b>. Do'kondagi elektron tarozilar aynan shunday ko'rsatadi.</p>",
 q:{t:"5 kg 600 g necha kilogramm?",opts:["5,06 kg","5,6 kg","56 kg","5,006 kg"],ok:1,why:"600 g = 0,6 kg.",hint:"600 g = ?/1000 kg.",full:"600 g = 600/1000 kg = 0,600 kg = 0,6 kg. Javob: 5,6 kg. «5,06 kg» = 5 kg 60 g, «5,006 kg» = 5 kg 6 g."},
 tn:"Bozor narxlari bilan ishlang: «1,5 kg uzum», «0,75 kg pishloq» — necha gramm? Bolalar o'zi tarozida tortib ko'rsin."},
{h:"Tuzoq: 1 kg 50 g",sum:"1 kg 50 g = 1,05 kg = 1,050 kg (1,5 kg emas!). Grammga 3 ta xona: 050.",a:"m06",
 start:function(){clear();f4t(180,60,'1 kg 50 g = ? kg',26);f4msg('To‘g‘ri yozuvni tanlang')},
 fin:function(){f10scale(1,50,'1,050 kg');f4msg('50 g = 0,050 kg → <b>1,05 kg</b>')},
 html:"<p>Ona non uchun 1 kg 50 g un oldi. Buni kilogrammlarda yozing:</p>",
 btns:f4pick(1,[["1,5 kg","1,5 kg = 1 kg 500 g! 10 marta ko'p bo'lib ketdi."],["1,05 kg","To'g'ri! 50 g = 0,050 kg; 1,050 kg = 1,05 kg."],["1,005 kg","Bu 1 kg 5 g bo'lardi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Gramm — <b>mingdan birlar</b>, 3 ta xona: 50 g → <b>050</b>, 5 g → <b>005</b>, 500 g → <b>500</b>. Avval 3 ta xonani to'ldiring, keyin kerak bo'lsa oxiridagi nollarni tashlang.</p>",
 q:{t:"2 kg 8 g necha kilogramm?",opts:["2,8 kg","2,08 kg","2,008 kg","28 kg"],ok:2,why:"8 g = 0,008 kg.",hint:"Grammga 3 ta xona: 8 → 008.",full:"8 g = 8/1000 kg = 0,008 kg. Javob: 2,008 kg. «2,8 kg» = 2 kg 800 g, «2,08 kg» = 2 kg 80 g."},
 tn:"Kartochkalar o'yini: «1 kg 5 g», «1 kg 50 g», «1 kg 500 g» va «1,005», «1,05», «1,5» ni juftlang."},
{h:"Teskari: o'nli kasrdan birliklarga",sum:"3,2 m = 3 m 20 sm; 0,6 kg = 600 g. Kerakli xonalar sonigacha nol qo'shamiz.",a:"m07",
 start:function(){startPh(F10P7)},fin:function(){S.ph=1;F10P7[1]()},
 html:"<p>Endi teskari: 3,2 m — necha metr va necha santimetr? 0,6 kg — necha gramm? Bosing:</p>",btns:[phaser(F10P7)],
 after:"<p>Santimetrga 2 ta xona kerak: 3,2 = 3,<b>20</b> → 20 sm. Grammga 3 ta: 0,6 = 0,<b>600</b> → 600 g. Eng ko'p xato: «3,2 m = 3 m 2 sm» yoki «0,6 kg = 6 g».</p>",
 q:{t:"0,35 kg necha gramm?",opts:["35 g","350 g","3 500 g","3,5 g"],ok:1,why:"0,350 kg = 350 g.",hint:"Verguldan keyin 3 ta raqam bo'lsin.",full:"0,35 kg = 0,350 kg = 350 g. «35 g» — nolni qo'shmaslik xatosi (bu 0,035 kg)."},
 tn:"Ikki tomonlama mashq: bola sonni yozadi, sherigi birliklarga aylantiradi va tekshiradi."},
{h:"Taqqoslash va qo'shish",sum:"1,5 kg = 1 kg 500 g &gt; 1 kg 400 g. 1,2 m + 35 sm = 120 sm + 35 sm = 155 sm = 1,55 m.",a:"m08",
 start:function(){clear();f4t(100,60,'1,5 kg',24,C.blue);f4t(180,62,'?',24);f4t(270,60,'1 kg 400 g',22,C.a2);f4msg('Qaysi biri og‘ir?')},
 fin:function(){clear();f4t(180,36,'1,5 kg = 1 kg 500 g > 1 kg 400 g',15,C.ok);f4t(180,80,'1,2 m + 35 sm = ?',16);f4t(180,110,'120 sm + 35 sm = 155 sm',14,'#33475b');f4t(180,142,'= 1,55 m',18,C.ok);f4msg('Avval bir xil birlikka keltiramiz!')},
 html:"<p>Qaysi biri og'irroq: <b>1,5 kg</b> yoki <b>1 kg 400 g</b>?</p>",
 btns:f4pick(0,[["1,5 kg","To'g'ri! 1,5 kg = 1 kg 500 g, bu 400 g dan 100 g ko'p."],["1 kg 400 g","1,5 kg ni grammlarda yozing: 0,5 kg = ? g"],["Teng","1,5 kg = 1 kg 500 g. 500 va 400 tengmi?"]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Taqqoslash va hisoblashdan oldin <b>bir xil birlikka</b> keltiring. Kichik birlik (sm, g) ko'pincha qulay: butun sonlar bilan ishlaysiz, keyin javobni o'nli kasrga qaytarasiz.</p>",
 q:{t:"1,2 m + 35 sm = ?",opts:["1,55 m","1,235 m","36,2 sm","4,7 m"],ok:0,why:"120 sm + 35 sm = 155 sm = 1,55 m.",hint:"1,2 m ni santimetrlarda yozing.",full:"1,2 m = 120 sm. 120 + 35 = 155 sm = 1,55 m. «36,2 sm» — 1,2 ni santimetr deb qo'shish, «4,7 m» — 1,2 + 3,5 (35 sm ni 3,5 m deb olish)."},
 tn:"Haqiqiy narsalar bilan: ikki lentani yonma-yon qo'yib o'lchang, bir xil birlikka keltirib qo'shing."},
{h:"Bilasizmi? Metr va kilogramm qanday paydo bo'lgan",sum:"1791-yilda Fransiyada metr Yer meridianining (qutbdan ekvatorgacha) 10 milliondan bir qismi deb belgilangan. Kilogramm — 1 litr suvning massasi.",a:"m09",
 start:function(){clear('#e8f2fb');f4t(180,50,'Fransiya, XVIII asr oxiri',15,'#1f4f7a');f4msg('Metr va kilogramm qayerdan olingan?')},
 fin:function(){clear('#e8f2fb');var g=S.g;E('circle',{cx:90,cy:92,r:56,fill:'#bfe0f5',stroke:'#1f6fb2','stroke-width':2},g);E('path',{d:'M90 36 A56 56 0 0 1 146 92',fill:'none',stroke:C.bad,'stroke-width':4},g);f4t(90,30,'qutb',10,'#1f4f7a');f4t(152,108,'ekvator',10,'#1f4f7a','start');f4t(260,60,'qutb → ekvator',12,C.bad);f4t(260,84,'= 10 000 000 m',13,C.bad);f4t(260,124,'1 dm³ suv = 1 kg',13,C.blue);f4msg('Bir xil, o‘nga bog‘langan o‘lchovlar — butun dunyo uchun')},
 html:"<p>🌍 Ilgari har bir mamlakatda o'z o'lchovi bo'lgan: gaz, quloch, qadoq, pud… Savdo qilish juda qiyin edi. Fransuz olimlari umumiy o'lchov o'ylab topishdi. Bosing:</p>",
 btns:[["🌍 Ko'rsatish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>1791-yilda Fransiyada <b>metr</b> — Shimoliy qutbdan ekvatorgacha bo'lgan meridian masofasining <b>10 milliondan bir</b> qismi deb belgilandi. <b>Kilogramm</b> — 1 litr (1 dm³) suvning massasi. Hammasi o'nga bog'langani uchun o'nli kasrlar bilan hisoblash juda oson bo'ldi. Bugun metrik tizimdan dunyoning deyarli barcha mamlakatlari foydalanadi.</p>",
 tn:"Eski o'zbek o'lchovlari (gaz, qadoq, quloch) haqida bolalardan bobo-buvilaridan so'rab kelishni topshiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>1 m = 10 dm = 100 sm = 1000 mm; 1 dm = 0,1 m; 1 sm = 0,01 m.</li><li>3 m 45 sm = 3,45 m; <b>2 m 5 sm = 2,05 m</b> (santimetrga 2 ta xona).</li><li>1 km = 1000 m: 4 km 250 m = 4,25 km; 3 km 40 m = 3,04 km.</li><li>1 kg = 1000 g: 2 kg 300 g = 2,3 kg; <b>1 kg 50 g = 1,05 kg</b> (grammga 3 ta xona).</li><li>Teskari: 3,2 m = 3 m 20 sm; 0,6 kg = 600 g.</li><li>Taqqoslash va qo'shishdan oldin — bir xil birlikka keltiring.</li><li>1 t = 1000 kg; 1 sentner = 100 kg.</li></ul></div>",
 tn:"Keyingi dars — foiz: «1/100 qismning maxsus nomi bor» deb qiziqish uyg'oting."}
];
var PROBS=[
{t:"7 dm necha metr?",o:["0,7 m","0,07 m","7,0 m","70 m"],k:0,s:"1 dm = 0,1 m."},
{t:"3 sm necha metr?",o:["0,03 m","0,3 m","3,0 m","0,003 m"],k:0,s:"1 sm = 0,01 m."},
{t:"5 m 20 sm necha metr?",o:["5,2 m","5,02 m","52 m","5,002 m"],k:0,s:"20 sm = 0,20 m."},
{t:"8 m 9 sm necha metr?",o:["8,09 m","8,9 m","8,009 m","89 m"],k:0,s:"9 sm = 0,09 m."},
{t:"2 km 500 m necha kilometr?",o:["2,5 km","2,05 km","2,005 km","25 km"],k:0,s:"500 m = 0,500 km."},
{t:"7 km 35 m necha kilometr?",o:["7,035 km","7,35 km","7,0035 km","735 km"],k:0,s:"35 m = 0,035 km."},
{t:"4 kg 200 g necha kilogramm?",o:["4,2 kg","4,02 kg","4,002 kg","42 kg"],k:0,s:"200 g = 0,200 kg."},
{t:"900 g necha kilogramm?",o:["0,9 kg","0,09 kg","9 kg","0,009 kg"],k:0,s:"900/1000 = 0,9."},
{t:"1,6 m necha santimetr?",o:["160 sm","16 sm","106 sm","1 600 sm"],k:0,s:"1,60 m = 160 sm."},
{t:"2,5 kg necha gramm?",o:["2 500 g","250 g","25 g","2 005 g"],k:0,s:"2,500 kg = 2 500 g."},
{t:"Qaysi biri eng uzun?",o:["1,2 m","1 m 15 sm","118 sm","1,09 m"],k:0,s:"120 sm, 115 sm, 118 sm, 109 sm."},
{t:"Tarvuz 3,4 kg, qovun 2 kg 750 g. Tarvuz qovundan necha gramm og'ir?",o:["650 g","1 350 g","1,4 kg","750 g"],k:0,s:"3 400 − 2 750 = 650 g."},
{t:"Qaysi tenglik noto'g'ri?",o:["0,5 km = 50 m","1,5 m = 150 sm","0,25 kg = 250 g","3 dm = 0,3 m"],k:0,s:"0,5 km = 500 m."},
{t:"Lenta 2,4 m edi. Undan 65 sm kesildi. Necha metr qoldi?",o:["1,75 m","1,85 m","2,35 m","1,59 m"],k:0,s:"240 − 65 = 175 sm = 1,75 m."},
{t:"1 t = 1000 kg. 3,5 t necha kilogramm?",o:["3 500 kg","350 kg","35 kg","3 050 kg"],k:0,s:"3,500 t = 3 500 kg."},
{t:"Bir qadam 0,6 m. 5 qadam necha metr?",o:["3 m","0,30 m","30 m","3,6 m"],k:0,s:"60 sm · 5 = 300 sm = 3 m."},
{t:"1 kg ning 0,1 qismi necha gramm?",o:["100 g","10 g","1 g","1 000 g"],k:0,s:"1 000 g ning 1/10 qismi — 100 g."},
{t:"Uzunliklarni kamayish tartibida joylang: 1,05 m; 1 m 50 sm; 105,5 sm.",o:["1 m 50 sm; 105,5 sm; 1,05 m","1,05 m; 105,5 sm; 1 m 50 sm","105,5 sm; 1 m 50 sm; 1,05 m","1 m 50 sm; 1,05 m; 105,5 sm"],k:0,s:"150 sm > 105,5 sm > 105 sm."},
{t:"4 ta bir xil sumka birgalikda 10 kg. Bitta sumka necha kilogramm?",o:["2,5 kg","2,4 kg","25 kg","2 kg 50 g"],k:0,s:"10 000 g : 4 = 2 500 g = 2,5 kg."},
{t:"1 sentner = 100 kg. 0,3 sentner necha kilogramm?",o:["30 kg","3 kg","300 kg","0,3 kg"],k:0,s:"100 kg ning 3/10 qismi — 30 kg."}
];
var PREP_DATA={teach:["Metrning ulushlari: 0,1 m = 1 dm, 0,01 m = 1 sm, 0,001 m = 1 mm.","Ikki birlikdagi kattalikni bitta o'nli kasr bilan yozish: 3 m 45 sm = 3,45 m.","Km va m, kg va g — 3 ta xona.","Teskari aylantirish: 3,2 m = 3 m 20 sm.","Taqqoslash va qo'shishdan oldin bir xil birlikka keltirish."],
 mist:["2 m 5 sm = 2,5 m (nolni tushirish).","1 kg 50 g = 1,5 kg (grammga 3 ta xona kerakligini unutish).","3,2 m = 3 m 2 sm; 0,6 kg = 6 g.","Har xil birliklarni to'g'ridan-to'g'ri qo'shadi: 1,2 + 35."],
 need:["Metrli lenta, chizg'ich.","Tarozi (iloji bo'lsa elektron), qadoqlangan mahsulotlar."],
 board:["<span class='w2'>1 m = 10 dm = 100 sm = 1000 mm</span>.","<span class='w2'>3 m 45 sm = 3,45 m</span>; <span class='w2'>2 m 5 sm = 2,05 m</span>.","<span class='w2'>4 km 250 m = 4,25 km</span>.","<span class='w2'>2 kg 300 g = 2,3 kg</span>; <span class='w2'>1 kg 50 g = 1,05 kg</span>.","<span class='w2'>1,2 m + 35 sm = 155 sm = 1,55 m</span>."]};
f4fix();
