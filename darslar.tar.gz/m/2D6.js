var CODE='2D6',TITLE='2-sinf · Narx, miqdor, qiymat (pul) masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function bm6u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Uchta so'z: narx, miqdor, qiymat",sum:"Narx — 1 donasi; miqdor — nechta; qiymat — hammasi. Qiymat = narx · miqdor.",a:"m01",
 frames:[{t:'Daftar 4 ming so‘m. 6 ta daftar oldik.',bars:[{y:66,segs:bm6u(6,'4','a',4)}],br:[{b:0,from:0,to:0,lab:'narx',up:true},{b:0,lab:'qiymat = ?',up:false}],note:'Har bo‘lak — bitta daftarning NARXI. Bo‘laklar soni — MIQDOR'},
  {t:'Daftar 4 ming so‘m. 6 ta daftar oldik.',bars:[{y:66,segs:bm6u(6,'4','a',4)}],br:[{b:0,from:0,to:0,lab:'narx',up:true},{b:0,lab:'4 · 6 = 24 ming',up:false,col:C.ok}],calc:['<b>Qiymat = narx · miqdor</b>','4 · 6 = <b>24</b> ming so‘m']}],
 html:"<p>Do'kon masalalarida uchta so'z bor: <b>narx</b> — bitta narsaning puli, <b>miqdor</b> — nechta olindi, <b>qiymat</b> — hammasining puli. Kuzating.</p>",
 after:"<p>Chizmada bu — teng bo'laklar: har bo'lak narx, bo'laklar soni miqdor, butun — qiymat. Shuning uchun <b>qiymat = narx · miqdor</b>.</p>",
 q:{t:"Bir non 3 ming so'm. 5 ta non qancha turadi?",opts:["8 ming","15 ming","2 ming","35 ming"],ok:1,why:"3 · 5 = 15 ming so'm.",hint:"Narx va miqdor ma'lum — qiymatni qanday topamiz?",full:"Qiymat = narx · miqdor = 3 · 5 = 15 ming so'm. «8» — 3 + 5, narx va miqdorni qo'shib yuborish."},
 tn:"Sinfda «do'kon» o'yini o'ynang: o'yinchoq pul bilan sotib olish — hayotiy kontekst (Gollandiya RME usuli)."}),
bmStep({h:"Qaytim",sum:"50 ming berildi, xarid 24 ming: qaytim 50 − 24 = 26 ming.",a:"m02",
 frames:[{t:'6 daftar 24 ming so‘m. Sotuvchiga 50 ming so‘m berildi.',bars:[{y:70,segs:[{w:24,txt:'24 xarid',c:'a'},{w:26,txt:'?',c:'q'}]}],br:[{b:0,lab:'50 ming berildi',up:true}],note:'Berilgan pul — butun, xarid — qism, qaytim — ikkinchi qism'},
  {t:'6 daftar 24 ming so‘m. Sotuvchiga 50 ming so‘m berildi.',bars:[{y:70,segs:[{w:24,txt:'24 xarid',c:'a'},{w:26,txt:'26 qaytim',c:'g'}]}],br:[{b:0,lab:'50 ming berildi',up:true}],calc:['Qaytim = berilgan − qiymat','50 − 24 = <b>26</b> ming so‘m']}],
 html:"<p>Do'konda katta pul bersak, sotuvchi <b>qaytim</b> beradi. Kuzating.</p>",
 after:"<p><b>Qaytim = berilgan pul − qiymat</b>. Bu yerda ikki amal: avval qiymat (4 · 6), keyin qaytim (50 − 24).</p>",
 q:{t:"Azim 4 ming so'mdan 6 ta daftar oldi va 50 ming so'm berdi. Qancha qaytim oladi?",opts:["24 ming","26 ming","34 ming","46 ming"],ok:1,why:"4 · 6 = 24, 50 − 24 = 26.",hint:"Avval xarid qiymatini toping.",full:"1) 4 · 6 = 24 ming. 2) 50 − 24 = 26 ming qaytim. «46» — faqat bitta daftarni ayirish xatosi."},
 tn:"Qaytimni «to'ldirib sanash» bilan ham ko'rsating: 24 dan 30 gacha 6, 30 dan 50 gacha 20 — jami 26."}),
bmStep({h:"Narxni topish",sum:"3 ta kitob 27 ming → bittasi 27 : 3 = 9 ming.",a:"m03",
 frames:[{t:'3 ta bir xil kitob 27 ming so‘m. Bittasi qancha?',bars:[{y:66,segs:bm6u(3,'?','q',9)}],br:[{b:0,lab:'27 ming',up:false}],note:'Qiymat va miqdor ma’lum, narx noma’lum'},
  {t:'3 ta bir xil kitob 27 ming so‘m. Bittasi qancha?',bars:[{y:66,segs:bm6u(3,'9','g',9)}],br:[{b:0,lab:'27 ming',up:false}],calc:['<b>Narx = qiymat : miqdor</b>','27 : 3 = <b>9</b> ming so‘m']}],
 html:"<p>Endi narx noma'lum. Chizmada butun teng bo'laklarga bo'linadi — kuzating.</p>",
 after:"<p>Uchlikdan ikkitasi ma'lum bo'lsa, uchinchisi topiladi: <b>narx = qiymat : miqdor</b>, <b>miqdor = qiymat : narx</b>.</p>",
 q:{t:"5 ta bir xil ruchka 10 ming so'm. 1 ta ruchka qancha?",opts:["50 ming","2 ming","5 ming","15 ming"],ok:1,why:"10 : 5 = 2 ming.",hint:"Qiymatni miqdorga bo'ling.",full:"Narx = qiymat : miqdor = 10 : 5 = 2 ming. «50» — ko'paytirish xatosi: bitta ruchka hammasidan qimmat bo'lmaydi!"},
 tn:"Doskaga uchburchak chizing: tepasida «qiymat», pastida «narx · miqdor». Bittasini yopsangiz — qolganlaridan topiladi."}),
bmStep({h:"Nechta olsa bo'ladi?",sum:"40 ming bor, 25 ming krossovka; qoldi 15 ming → 6 minglik o'yinchoqdan 2 ta (3 ming ortadi).",a:"m04",
 frames:[{t:'Alida 40 ming. 25 minglik krossovka oldi. Qolganiga 6 minglik mashinadan nechta?',bars:[{y:62,segs:[{w:25,txt:'25 krossovka',c:'b'},{w:15,txt:'15 qoldi',c:'g'}]}],br:[{b:0,lab:'40 ming',up:true}],calc:['1) 40 − 25 = 15 ming qoldi']},
  {t:'Alida 40 ming. 25 minglik krossovka oldi. Qolganiga 6 minglik mashinadan nechta?',bars:[{y:62,segs:[{w:25,txt:'25 krossovka',c:'b'},{w:15,txt:'15 qoldi',c:'g'}]},{y:122,off:25,segs:[{w:6,txt:'6',c:'a'},{w:6,txt:'6',c:'a'},{w:3,txt:'3',c:'x'}]}],calc:['1) 40 − 25 = 15','2) 15 da nechta 6 bor? 6 + 6 = 12, yana 6 yetmaydi','<b>2 ta</b> mashina, 3 ming qoladi']}],
 html:"<p>Pul har doim ham bo'linib tushavermaydi. Kuzating.</p>",
 after:"<p>Uchinchi mashinaga pul yetmaydi — shuning uchun javob <b>2 ta</b>, 3 emas. Haqiqiy hayotda yarimta mashina sotib olinmaydi!</p>",
 q:{t:"Valida 20 ming so'm bor. Muzqaymoq 6 ming so'm. Ko'pi bilan nechta muzqaymoq oladi?",opts:["4","3","2","14"],ok:1,why:"6 · 3 = 18 ≤ 20, 6 · 4 = 24 > 20.",hint:"6, 12, 18, 24 — qaysi biri 20 dan oshib ketadi?",full:"3 ta — 18 ming (yetadi, 2 ming qoladi). 4 ta — 24 ming (yetmaydi). Javob: 3 ta. «14» — 20 − 6, bu qoldiq pul."},
 tn:"«Ko'pi bilan nechta?» savolida bolalar 6 ga qo'shib sanasin: 6, 12, 18 — keyingisi oshib ketadi."}),
bmStep({h:"Puli yetadimi?",sum:"50 ming; 23 + 15 = 38 ming kerak → yetadi, 12 ming qoladi.",a:"m05",
 frames:[{t:'Lolada 50 ming. 23 minglik o‘yinchoq va 15 minglik kitob olmoqchi.',bars:[{lab:'bor',y:44,segs:[{w:50,txt:'50',c:'g'}]},{lab:'kerak',y:104,segs:[{w:23,txt:'23',c:'a'},{w:15,txt:'15',c:'b'}]}],note:'Yetadimi? Qancha qoladi?'}],
 html:"<p>Chizmaga qarang va javobni tanlang:</p>",
 btns:bmPick(["yetmaydi","yetadi, 12 ming qoladi","yetadi, 27 ming qoladi"],1,{t:'Lolada 50 ming. 23 minglik o‘yinchoq va 15 minglik kitob olmoqchi.',bars:[{lab:'bor',y:44,segs:[{w:50,txt:'50',c:'g'}]},{lab:'kerak',y:104,segs:[{w:23,txt:'23',c:'a'},{w:15,txt:'15',c:'b'},{w:12,txt:'12',c:'x'}]}],calc:['1) Kerak: 23 + 15 = 38 ming','2) 38 < 50 → yetadi. Qoladi: 50 − 38 = <b>12</b> ming']},["Kerakli chiziq bor chiziqdan qisqa — demak yetadi.","","27 — faqat o‘yinchoqni ayirish (50 − 23). Kitobni unutmang!"]),
 after:"<p>«Yetadimi?» degan savolga javob — <b>taqqoslash</b>: kerakli pul bor puldan kammi? Chizmada kerakli chiziq qisqa bo'lsa — yetadi.</p>",
 q:{t:"Sardorda 30 ming bor. 18 minglik to'p va 14 minglik kepka olmoqchi. Puli yetadimi?",opts:["yetadi, 2 ming qoladi","yetmaydi, 2 ming kam","yetadi, 12 ming qoladi","yetmaydi, 12 ming kam"],ok:1,why:"18 + 14 = 32 > 30 — 2 ming yetmaydi.",hint:"Avval kerakli pulni toping va 30 bilan solishtiring.",full:"Kerak: 18 + 14 = 32 ming. 32 > 30, yetmaydi: 32 − 30 = 2 ming kam."},
 tn:"Bolalar oilada qilinadigan xaridni rejalashtirsin — moliyaviy savodxonlikning birinchi qadami."}),
bmStep({h:"Tuzoq: qadoq va dona",sum:"5 quti alohida 3 · 5 = 15 tanga, qadoq 13 tanga → 2 tanga tejaladi.",a:"m06",
 frames:[{t:'5 quti sharbatli QADOQ — 13 tanga. Bitta quti alohida — 3 tanga.',bars:[{lab:'alohida',y:44,segs:bm6u(5,'3','a',3)},{lab:'qadoq',y:104,segs:[{w:13,txt:'13',c:'b'}]}],note:'Qadoqni olsak, necha tanga tejaymiz?'},
  {t:'5 quti sharbatli QADOQ — 13 tanga. Bitta quti alohida — 3 tanga.',bars:[{lab:'alohida',y:44,segs:bm6u(5,'3','a',3)},{lab:'qadoq',y:104,segs:[{w:13,txt:'13',c:'b'},{w:2,txt:'2',c:'g'}]}],calc:['1) Alohida: 3 · 5 = 15 tanga','2) Tejaladi: 15 − 13 = <b>2</b> tanga']}],
 html:"<p>Do'konda ko'pincha «ko'p olsang arzon» degan takliflar bo'ladi. Bankdagi masala — kuzating.</p>",
 after:"<p>Solishtirish uchun ikkalasini <b>bir xil miqdorda</b> hisoblaymiz: 5 ta alohida va 5 ta qadoqda. Xato yo'l: 13 − 3 = 10.</p>",
 q:{t:"Bitta daftar 2 ming, 10 talik pachka 17 ming so'm. Pachka olsa, qancha tejaladi?",opts:["15 ming","3 ming","2 ming","7 ming"],ok:1,why:"10 · 2 = 20, 20 − 17 = 3 ming.",hint:"10 ta daftarni alohida olsa, qancha bo'ladi?",full:"Alohida: 2 · 10 = 20 ming. Pachka: 17 ming. Tejaladi: 20 − 17 = 3 ming. «15» — 17 − 2 ni hisoblash xatosi."},
 tn:"Haqiqiy do'kon cheklaridan foydalaning (ismlarsiz) — bolalar «qaysi foydali?» degan savolni o'zi bersin."}),
bmStep({h:"Tuzoq: ikki variantni solishtirish",sum:"Onlayn: 18 + 7 = 25 ming; do'kon: 18 + 4 = 22 ming → do'kon 3 ming arzon.",a:"m07",
 frames:[{t:'Kitob 18 ming. Onlayn: +7 ming yetkazish. Do‘konga borib-kelish: 4 ming.',bars:[{lab:'onlayn',y:44,segs:[{w:18,txt:'18',c:'a'},{w:7,txt:'+7',c:'c'}]},{lab:'do‘kon',y:104,segs:[{w:18,txt:'18',c:'a'},{w:4,txt:'+4',c:'b'}]}],calc:['Onlayn: 18 + 7 = 25 · Do‘kon: 18 + 4 = 22','Do‘kondan olish <b>3 ming</b> arzon']}],
 html:"<p>Qaysi yo'l arzon? Chizmani ko'ring va tanlang:</p>",
 btns:bmPick(["onlayn 3 ming arzon","teng","do‘kon 3 ming arzon","do‘kon 7 ming arzon"],2,null,["Onlayn chizig‘i uzun — demak qimmat.","Kitob narxi teng, lekin qo‘shimcha xarajatlar har xil.","","7 — bu faqat yetkazish narxi, farq emas."]),
 after:"<p>Kitob narxi bir xil — shuning uchun faqat <b>qo'shimcha xarajatlarni</b> solishtirsa ham bo'ladi: 7 − 4 = 3 ming. Bu — ayyor qisqa yo'l!</p>",
 q:{t:"Ikki kishi taksida borsa 15 ming so'm, avtobusda esa har biriga 3 ming so'm. Avtobusda borishsa, qancha tejashadi?",opts:["6 ming","9 ming","12 ming","3 ming"],ok:1,why:"Avtobus 6 ming, 15 − 6 = 9.",hint:"Avval avtobus narxini hisoblang.",full:"Avtobus: 3 · 2 = 6 ming. Tejaladi: 15 − 6 = 9 ming."},
 tn:"Moliyaviy savodxonlik: «arzon» va «qulay» farqini muhokama qiling."}),
bmStep({h:"Bilasizmi? So'm",sum:"O'zbekiston so'mi 1994-yil 1-iyulda muomalaga kiritilgan.",a:"m08",
 frames:[{t:'O‘zbekiston so‘mi',bg:'#eef6ee',bars:[{y:50,h:66,segs:[{w:1,txt:'1 000',c:'#cfe8d0',fs:20},{w:1,txt:'5 000',c:'#d9ecf7',fs:20},{w:1,txt:'10 000',c:'#f7e3cf',fs:20}]}],note:'1994-yil 1-iyuldan beri'}],
 html:"<p>💵 Bizning milliy pulimiz — <b>so'm</b> — 1994-yil 1-iyulda muomalaga kiritilgan.</p><p>Pulni to'g'ri hisoblashni bilgan odam — tejamkor va ishonchli bo'ladi.</p>",
 tn:"Bolalarga haqiqiy pul birliklarini (1 000, 5 000, 10 000) ko'rsatib, qaytim berishni mashq qildiring."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'Qiymat = narx · miqdor',bars:[{y:66,segs:bm6u(6,'4','a',4)}],br:[{b:0,from:0,to:0,lab:'narx',up:true},{b:0,lab:'qiymat',up:false}]}],
 html:"<div class='memo'><ul><li><b>Narx</b> — 1 donasi, <b>miqdor</b> — nechta, <b>qiymat</b> — hammasi.</li><li>Qiymat = narx · miqdor; narx = qiymat : miqdor; miqdor = qiymat : narx.</li><li><b>Qaytim</b> = berilgan pul − qiymat.</li><li>«Ko'pi bilan nechta?» — ortib qolgan pulga yana bittasi yetmasa, to'xtaymiz.</li><li>«Yetadimi?» — kerakli pulni bor pul bilan <b>solishtiring</b>.</li><li>Qadoq va dona — <b>bir xil miqdorda</b> solishtiring.</li></ul></div>",
 tn:"Keyingi darsni «20 ming bilan 7 minglik kitobdan nechta olsa bo'ladi va qancha qaytim?» (2 ta, 6 ming) savoli bilan boshlang."})
];
var PROBS=[
{t:"Azim donasi 4 000 so'mdan 6 ta daftar oldi va 50 000 so'm berdi. Qaytim qancha?",o:["26 000 so'm","24 000 so'm","34 000 so'm","46 000 so'm"],k:0,s:"4 000 · 6 = 24 000, 50 000 − 24 000 = 26 000."},
{t:"Alida 40 ming. 25 minglik krossovka olgach, qolganiga 6 minglik mashinadan nechta oladi?",o:["2","3","6","1"],k:0,s:"Qoldi 15 ming: 6 · 2 = 12, uchinchisiga yetmaydi."},
{t:"Lolada 50 ming. 23 minglik o'yinchoq va 15 minglik kitob olmoqchi. Puli yetadimi?",o:["yetadi, 12 ming qoladi","yetmaydi, 12 ming kam","yetadi, 27 ming qoladi","yetadi, 2 ming qoladi"],k:0,s:"23 + 15 = 38, 50 − 38 = 12."},
{t:"5 quti sharbatli qadoq 13 tanga, bitta quti alohida 3 tanga. Qadoq olinsa, qancha tejaladi?",o:["2 tanga","3 tanga","10 tanga","15 tanga"],k:0,s:"3 · 5 = 15, 15 − 13 = 2."},
{t:"Bir non 3 ming so'm. 5 ta non qancha?",o:["15 ming","8 ming","2 ming","35 ming"],k:0,s:"3 · 5 = 15 ming."},
{t:"3 ta bir xil kitob 27 ming so'm. Bitta kitob qancha?",o:["9 ming","24 ming","30 ming","81 ming"],k:0,s:"27 : 3 = 9 ming."},
{t:"Ruchka 2 ming so'm. 12 ming so'mga nechta ruchka olish mumkin?",o:["6","10","14","24"],k:0,s:"12 : 2 = 6."},
{t:"Valida 20 ming bor. Muzqaymoq 6 ming. Ko'pi bilan nechta muzqaymoq oladi?",o:["3","4","2","14"],k:0,s:"6 · 3 = 18 ≤ 20, 4 tasiga yetmaydi."},
{t:"Sardorda 30 ming. 18 minglik to'p va 14 minglik kepka olmoqchi. Puli yetadimi?",o:["yetmaydi, 2 ming kam","yetadi, 2 ming qoladi","yetadi, 12 ming qoladi","yetmaydi, 12 ming kam"],k:0,s:"18 + 14 = 32 > 30, 2 ming kam."},
{t:"Bitta daftar 2 ming, 10 talik pachka 17 ming. Pachka olinsa qancha tejaladi?",o:["3 ming","15 ming","2 ming","7 ming"],k:0,s:"2 · 10 = 20, 20 − 17 = 3 ming."},
{t:"Kitob 18 ming. Onlayn yetkazish 7 ming, do'konga borib-kelish 4 ming. Qaysi arzon?",o:["do'kon 3 ming arzon","onlayn 3 ming arzon","teng","do'kon 7 ming arzon"],k:0,s:"Onlayn 25, do'kon 22 — do'kon 3 ming arzon."},
{t:"Ona 4 ta non (har biri 3 ming) va 8 minglik sut oldi. Hammasi qancha?",o:["20 ming","15 ming","11 ming","32 ming"],k:0,s:"3 · 4 = 12, 12 + 8 = 20 ming."},
{t:"Olma 1 kg 9 ming so'm. 2 kg olma uchun 20 ming berildi. Qaytim qancha?",o:["2 ming","11 ming","18 ming","9 ming"],k:0,s:"9 · 2 = 18, 20 − 18 = 2 ming."},
{t:"4 ta bir xil o'yinchoq 32 ming so'm. 2 ta o'yinchoq qancha?",o:["16 ming","8 ming","64 ming","30 ming"],k:0,s:"Bittasi 32 : 4 = 8, ikkitasi 8 · 2 = 16 ming."},
{t:"Kitob 15 ming, daftar undan 3 marta arzon. Kitob va daftar birga qancha?",o:["20 ming","18 ming","45 ming","12 ming"],k:0,s:"Daftar 15 : 3 = 5, jami 15 + 5 = 20 ming."},
{t:"Ali 5 ta qalam uchun 10 ming to'ladi. Shunday 8 ta qalam qancha turadi?",o:["16 ming","13 ming","40 ming","80 ming"],k:0,s:"Bittasi 10 : 5 = 2, sakkiztasi 2 · 8 = 16 ming."},
{t:"Do'kon 3 ta olganga 1 ta bepul beradi. Bitta sharbat 4 ming. 4 ta sharbat qancha turadi?",o:["12 ming","16 ming","4 ming","8 ming"],k:0,s:"3 tasi pulli: 4 · 3 = 12 ming, to'rtinchisi bepul."},
{t:"Taksi 15 ming. Avtobus bir kishiga 3 ming. 2 kishi avtobusda borsa, qancha tejaydi?",o:["9 ming","6 ming","12 ming","3 ming"],k:0,s:"Avtobus 3 · 2 = 6, 15 − 6 = 9 ming."},
{t:"Zarina har kuni 2 ming so'm yig'adi. 18 minglik kitobga necha kunda yig'adi?",o:["9","16","20","36"],k:0,s:"18 : 2 = 9 kun."},
{t:"Ota 50 ming berdi. Bola 3 ta 8 minglik kitob va 12 minglik sumka oldi. Qancha qoldi?",o:["14 ming","26 ming","38 ming","30 ming"],k:0,s:"8 · 3 = 24, 24 + 12 = 36, 50 − 36 = 14 ming."}
];
function PRACT_STAGE(){bmDraw({t:'Narx · miqdor = qiymat',bars:[{y:66,segs:bm6u(5,'narx','a',4)}],br:[{b:0,lab:'qiymat',up:false}],note:'Qaytim = berilgan − qiymat'})}
var PREP_DATA={teach:["Narx, miqdor, qiymat va ularning bog'liqligi.","Qaytim; «ko'pi bilan nechta?»; «yetadimi?».","Qadoq va dona, ikki variantni solishtirish (moliyaviy savodxonlik)."],
 mist:["Narx va miqdorni qo'shib yuboradi.","«Ko'pi bilan nechta?» da yarim donani yaxlitlab ko'p qilib qo'yadi.","Qaytimda faqat bitta narsani ayiradi.","Qadoqni bitta dona bilan solishtiradi."],
 need:["O'yinchoq pullar (1, 5, 10 minglik), narx yorliqlari."],
 board:["Uchburchak: <span class='w2'>qiymat / narx · miqdor</span>.","<span class='w2'>4 · 6 = 24</span>, qaytim <span class='w2'>50 − 24 = 26</span>.","<span class='w2'>27 : 3 = 9</span>.","Ko'pi bilan: <span class='w2'>6, 12, 18 | 24 ✗</span>.","Qadoq: <span class='w2'>3 · 5 = 15 vs 13</span>."]};
