var CODE='3H11',TITLE='3-sinf · O‘q simmetriya, simmetrik shakllar';
function h11msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function h11pts(a){return a.map(function(p){return p[0]+','+p[1]}).join(' ')}
function h11mx(a,ax){return a.map(function(p){return [2*ax-p[0],p[1]]})}
function h11axis(g,x1,y1,x2,y2){E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'7 5'},g)}
var H11W=[[180,60],[160,22],[118,14],[104,44],[132,80],[110,110],[124,150],[160,140],[180,118]];
var P1=[function(){clear();var g=S.g;E('polygon',{points:h11pts(H11W),fill:'#f6b26b',stroke:'#33475b','stroke-width':2},g);E('circle',{cx:140,cy:48,r:9,fill:'#fff'},g);E('circle',{cx:142,cy:118,r:7,fill:'#fff'},g);h11axis(g,180,6,180,168);h11msg('Qog‘ozni buklab, kapalakning yarmini chizdik')},
 function(){clear();var g=S.g;E('polygon',{points:h11pts(H11W),fill:'#f6b26b',stroke:'#33475b','stroke-width':2},g);E('circle',{cx:140,cy:48,r:9,fill:'#fff'},g);E('circle',{cx:142,cy:118,r:7,fill:'#fff'},g);E('polygon',{points:h11pts(h11mx(H11W,180)),fill:'none',stroke:'#33475b','stroke-width':2,'stroke-dasharray':'4 4'},g);h11axis(g,180,6,180,168);h11msg('Qirqib, qog‘ozni ochamiz…')},
 function(){clear();var g=S.g;[H11W,h11mx(H11W,180)].forEach(function(w){E('polygon',{points:h11pts(w),fill:'#f6b26b',stroke:'#33475b','stroke-width':2},g)});[[140,48,9],[220,48,9],[142,118,7],[218,118,7]].forEach(function(c){E('circle',{cx:c[0],cy:c[1],r:c[2],fill:'#fff'},g)});E('ellipse',{cx:180,cy:86,rx:6,ry:40,fill:'#7a5230'},g);h11axis(g,180,6,180,168);h11msg('Ikki yarmi aynan bir xil! Bukish chizig‘i — <b>simmetriya o‘qi</b>')}];
// harflar
var H11L={M:{p:[[[150,140],[150,30],[180,90],[210,30],[210,140]]],ax:[[180,14,180,160]],t:'M — 1 ta o‘q (tik)'},E:{p:[[[210,30],[150,30],[150,140],[210,140]],[[150,85],[200,85]]],ax:[[124,85,236,85]],t:'E — 1 ta o‘q (yotiq)'},N:{p:[[[150,140],[150,30],[210,140],[210,30]]],ax:[],t:'N — simmetriya o‘qi <b>yo‘q</b>'},H:{p:[[[150,30],[150,140]],[[210,30],[210,140]],[[150,85],[210,85]]],ax:[[180,14,180,160],[124,85,236,85]],t:'H — <b>2 ta</b> o‘q (tik va yotiq)'}};
function h11let(k){clear();var g=S.g,L=H11L[k];L.p.forEach(function(q){E('polyline',{points:h11pts(q),fill:'none',stroke:'#2f6fb5','stroke-width':12,'stroke-linecap':'round','stroke-linejoin':'round'},g)});L.ax.forEach(function(a){h11axis(g,a[0],a[1],a[2],a[3])});h11msg(L.t)}
// kataklar
var H11C=[[4,0],[3,1],[4,1],[2,2],[4,3],[1,4],[3,5]];
function h11cells(on){clear();var g=S.g,x0=60,y0=15,s=24,i,j;for(i=0;i<10;i++)for(j=0;j<6;j++)E('rect',{x:x0+i*s,y:y0+j*s,width:s,height:s,fill:'#fff',stroke:'#dfe5ec'},g);
 H11C.forEach(function(c){E('rect',{x:x0+c[0]*s+1,y:y0+c[1]*s+1,width:s-2,height:s-2,fill:C.a2},g)});
 on.forEach(function(c){E('rect',{x:x0+c[0]*s+1,y:y0+c[1]*s+1,width:s-2,height:s-2,fill:c[2]||C.ok},g)});h11axis(g,180,8,180,166)}
function h11cDraw(){h11cells(S.cOn.concat(S.cBad?[S.cBad]:[]));var r=E('rect',{x:180,y:15,width:120,height:144,fill:'transparent',style:'cursor:pointer'},sv);
 r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var i=Math.floor((p.x-60)/24),j=Math.floor((p.y-15)/24);if(i<5||i>9||j<0||j>5||!S.d3)return;
  var need=H11C.some(function(c){return 9-c[0]===i&&c[1]===j}),had=S.cOn.some(function(c){return c[0]===i&&c[1]===j});S.cBad=null;
  if(need&&!had){S.cOn.push([i,j]);h11msg('✓ '+S.cOn.length+' / 7')}else if(!need){S.cBad=[i,j,'#f4b6b6'];var src=[9-i,j],d=4-src[0];h11msg('Bu katakka chap tomonda bo‘yalgan katak mos kelmaydi. O‘qdan bir xil uzoqlikni sanang')}
  h11cDraw();if(S.cOn.length===7){h11msg('✓ Barcha 7 katak! Shakl simmetrik');var d=S.d3;S.d3=null;d()}})}
// nuqta
function h11X(i){return 30+28*i}function h11Y(j){return 150-24*j}
function h11node(o){clear();var g=S.g,i,j;for(i=0;i<=11;i++)E('line',{x1:h11X(i),y1:h11Y(0),x2:h11X(i),y2:h11Y(5),stroke:'#e3e8ee'},g);for(j=0;j<=5;j++)E('line',{x1:h11X(0),y1:h11Y(j),x2:h11X(11),y2:h11Y(j),stroke:'#e3e8ee'},g);
 h11axis(g,h11X(5),6,h11X(5),168);T(g,h11X(5)+10,16,'o‘q',{'font-size':11,fill:C.bad,'text-anchor':'start'});
 (o.segs||[]).forEach(function(q){E('line',{x1:h11X(q[0]),y1:h11Y(q[1]),x2:h11X(q[2]),y2:h11Y(q[3]),stroke:C.blue,'stroke-width':2,'stroke-dasharray':'3 3'},g)});
 (o.pts||[]).forEach(function(p){E('circle',{cx:h11X(p[0]),cy:h11Y(p[1]),r:6,fill:p[3]||C.blue},g);T(g,h11X(p[0]),h11Y(p[1])-10,p[2],{'font-size':12,'font-weight':800,fill:p[3]||C.blue})});
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());o.tap(Math.max(0,Math.min(11,Math.round((p.x-30)/28))),Math.max(0,Math.min(5,Math.round((150-p.y)/24))))})}}
function h11t4(i,j){if(!S.d4)return;if(i===8&&j===3){STEPS[3].fin();var d=S.d4;S.d4=null;d();return}
 h11node({tap:h11t4,pts:[[2,3,'A'],[i,j,'?',C.grey]]});h11msg(i===11&&j===3?'Bu chetdan sanash! A o‘qdan <b>3</b> katak chapda — A′ o‘qdan 3 katak o‘ngda bo‘ladi':(j!==3?'A′ A bilan bir balandlikda bo‘lishi kerak':'O‘qdan A gacha 3 katak. A′ gacha ham 3 katak bo‘lsin'))}
// shakllar
function h11shape(k){clear();var g=S.g,t;
 if(k==='kv'){E('rect',{x:130,y:37,width:100,height:100,fill:'#cfe6f7',stroke:'#33475b','stroke-width':2.5},g);h11axis(g,180,22,180,152);h11axis(g,115,87,245,87);h11axis(g,122,29,238,145);h11axis(g,238,29,122,145);t='Kvadrat — <b>4 ta</b> o‘q'}
 if(k==='tt'){E('rect',{x:100,y:45,width:160,height:84,fill:'#fbe0b4',stroke:'#33475b','stroke-width':2.5},g);h11axis(g,180,30,180,144);h11axis(g,86,87,274,87);t='To‘g‘ri to‘rtburchak — <b>2 ta</b> o‘q'}
 if(k==='uch'){var A=[180,20],B=[102,155],D=[258,155];E('polygon',{points:h11pts([A,B,D]),fill:'#c9ecd2',stroke:'#33475b','stroke-width':2.5},g);[[A,[(B[0]+D[0])/2,(B[1]+D[1])/2]],[B,[(A[0]+D[0])/2,(A[1]+D[1])/2]],[D,[(A[0]+B[0])/2,(A[1]+B[1])/2]]].forEach(function(q){h11axis(g,q[0][0],q[0][1],q[1][0],q[1][1])});t='Teng tomonli uchburchak — <b>3 ta</b> o‘q'}
 if(k==='d'){E('circle',{cx:180,cy:87,r:62,fill:'#f6d5e5',stroke:'#33475b','stroke-width':2.5},g);for(var a=0;a<180;a+=30){var r=a*Math.PI/180;h11axis(g,180-74*Math.cos(r),87-74*Math.sin(r),180+74*Math.cos(r),87+74*Math.sin(r))}t='Doira — markazdan o‘tgan <b>har qanday</b> to‘g‘ri chiziq o‘q: cheksiz ko‘p'}
 h11msg(t)}
// diagonal tuzog'i
function h11refl(p,a,b){var dx=b[0]-a[0],dy=b[1]-a[1],t=((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy),fx=a[0]+t*dx,fy=a[1]+t*dy;return [2*fx-p[0],2*fy-p[1]]}
var H11R=[[110,50],[250,50],[250,124],[110,124]];
var P6=[function(){clear();var g=S.g;E('polygon',{points:h11pts(H11R),fill:'#fbe0b4',stroke:'#33475b','stroke-width':2.5},g);h11axis(g,104,128,256,46);h11msg('Diagonal to‘g‘ri to‘rtburchakni ikkita teng bo‘lakka bo‘ladi. U simmetriya o‘qimi?')},
 function(){clear();var g=S.g,a=[110,124],b=[250,50];E('polygon',{points:h11pts(H11R),fill:'#fbe0b4',stroke:'#33475b','stroke-width':2.5},g);E('polygon',{points:h11pts([a,[110,50],b]),fill:'rgba(47,111,181,.35)',stroke:C.blue,'stroke-width':2},g);h11axis(g,104,128,256,46);h11msg('Yuqori bo‘lakni diagonal bo‘ylab buklaymiz…')},
 function(){clear();var g=S.g,a=[110,124],b=[250,50],q=h11refl([110,50],a,b);E('polygon',{points:h11pts(H11R),fill:'#fbe0b4',stroke:'#33475b','stroke-width':2.5},g);E('polygon',{points:h11pts([a,q,b]),fill:'rgba(47,111,181,.35)',stroke:C.blue,'stroke-width':2},g);E('circle',{cx:q[0],cy:q[1],r:6,fill:C.bad},g);h11axis(g,104,128,256,46);h11msg('Burchak chetga chiqib ketdi — ustma-ust tushmadi! Diagonal — <b>o‘q emas</b>')}];
// suvdagi aks (yotiq o'q)
var H11H=[[120,80],[120,40],[160,12],[200,40],[200,80]];
function h11hy(a,ay){return a.map(function(p){return [p[0],2*ay-p[1]]})}
var P7=[function(){clear();var g=S.g;E('rect',{x:2,y:87,width:356,height:85,fill:'#d6ecf7'},g);E('polygon',{points:h11pts(H11H),fill:'#f6b26b',stroke:'#33475b','stroke-width':2},g);E('rect',{x:150,y:56,width:20,height:24,fill:'#7a5230'},g);E('polygon',{points:'250,80 270,30 290,80',fill:'#5cb85c'},g);E('line',{x1:2,y1:84,x2:358,y2:84,stroke:'#33475b','stroke-width':1.5},g);h11msg('Ko‘l bo‘yida uy va daraxt')},
 function(){clear();var g=S.g;E('rect',{x:2,y:84,width:356,height:88,fill:'#d6ecf7'},g);E('polygon',{points:h11pts(H11H),fill:'#f6b26b',stroke:'#33475b','stroke-width':2},g);E('rect',{x:150,y:56,width:20,height:24,fill:'#7a5230'},g);E('polygon',{points:'250,80 270,30 290,80',fill:'#5cb85c'},g);
  E('polygon',{points:h11pts(h11hy(H11H,82)),fill:'#f6b26b',opacity:.55},g);E('rect',{x:150,y:84,width:20,height:24,fill:'#7a5230',opacity:.55},g);E('polygon',{points:'250,84 270,134 290,84',fill:'#5cb85c',opacity:.55},g);h11axis(g,10,82,350,82);h11msg('Suvdagi aks: <b>yotiq</b> simmetriya o‘qi — suv chizig‘i. Tom pastga qaragan!')}];
var STEPS=[
{h:"Kapalak: simmetriya nima?",sum:"Shaklni bir chiziq bo'ylab buklaganda ikki yarmi ustma-ust tushsa, shakl simmetrik, chiziq — simmetriya o'qi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Qog'ozni ikkiga buklab, kapalakning yarmini qirqamiz. Ochsak nima bo'ladi?</p>",
 btns:[phaser(P1)],
 after:"<p>Kapalakning ikki yarmi <b>aynan bir xil</b>, faqat ko'zgudagidek teskari. Buklash chizig'i — <b>simmetriya o'qi</b>. Bunday shakl <b>simmetrik</b> deyiladi.</p>",
 q:{t:"Shakl qachon simmetrik bo'ladi?",opts:["Ikki yarmi bir xil rangda bo'lsa","O'q bo'ylab buklaganda yarmlari ustma-ust tushsa","Shakl katta bo'lsa","Shaklda to'g'ri burchak bo'lsa"],ok:1,why:"Simmetriyani buklash bilan tekshiramiz.",hint:"Kapalakni qanday tekshirdik?",full:"Simmetrik shaklni o'q bo'ylab buklasak, ikki yarmi bir-birining ustiga aniq tushadi. Rang, o'lcham yoki burchaklar bu yerda ahamiyatsiz."},
 tn:"Har bola qog'ozni buklab, kapalak, barg yoki yurak qirqsin — Montessori uslubida qo'l bilan his qilish."},
{h:"Harflarning simmetriya o'qlari",sum:"Ba'zi harflarning o'qi tik (M), ba'zilariniki yotiq (E), ba'zilarida ikkitasi (H), ba'zilarida yo'q (N).",a:"m02",
 start:function(){h11let('M')},fin:function(){h11let('H')},
 html:"<p>Har bir harfni bosib, uning simmetriya o'qlarini ko'ring:</p>",
 btns:[["M",function(c,done){h11let('M');mvK(done,4)}],["E",function(c,done){h11let('E');mvK(done,4)}],["N",function(c,done){h11let('N');mvK(done,4)}],["H",function(c,done){h11let('H');mvK(done,4)}]],g2:1,
 after:"<p>Simmetriya o'qi <b>tik</b> (M, A, T, Ш), <b>yotiq</b> (E, B, K) yoki ikkalasi (H, O, X) bo'lishi mumkin. N, S, Z harflarida o'q <b>yo'q</b> — buklasak, ustma-ust tushmaydi.</p>",
 q:{t:"Qaysi harfning simmetriya o'qi yo'q?",opts:["T","Z","O","Ш"],ok:1,why:"Z ni hech qaysi chiziq bo'ylab buklab ustma-ust tushirib bo'lmaydi.",hint:"Har bir harfni xayolan tik va yotiq buklab ko'ring.",full:"Z — o'qsiz harf: tik yoki yotiq buklasak, uchlar teskari tomonga qaraydi. T va Ш da tik o'q, O da ikkita (va undan ko'p) o'q bor."},
 tn:"Doskaga bosma harflarni yozib, bolalar bo'r bilan o'qlarini chizsin. Ko'zguni harf o'rtasiga qo'yib tekshirish mumkin."},
{h:"Simmetrik kataklarni bo'yang",sum:"Har bir katak o'qdan qancha uzoq bo'lsa, uning simmetrigi ham o'qning narigi tomonida shuncha uzoqda.",a:"m03",
 start:function(){S.cOn=[];S.cBad=null;h11cDraw();h11msg('O‘ng tomonda simmetrik 7 ta katakni bosing')},fin:function(){h11cells(H11C.map(function(c){return [9-c[0],c[1]]}));h11msg('✓ Shakl o‘qqa nisbatan simmetrik')},
 act:function(c,done){S.d3=done},
 html:"<p>Chap tomonda 7 ta katak bo'yalgan. Qizil o'qqa nisbatan <b>simmetrik</b> kataklarni o'ng tomonda bosing.</p>",
 after:"<p>Har bir katak uchun: o'qdan chapga necha katak bo'lsa, o'ngga ham shuncha katak sanaymiz, <b>qator o'zgarmaydi</b>. O'qqa yopishgan katakning simmetrigi ham o'qqa yopishgan.</p>",
 q:{t:"Katak o'qdan chapda 3-katakda turibdi. Uning simmetrigi qayerda?",opts:["O'qdan o'ngda 3-katakda, xuddi shu qatorda","O'qdan o'ngda 3-katakda, bir qator pastda","O'qning ustida","O'ng chetda"],ok:0,why:"O'qgacha masofa bir xil, qator ham bir xil.",hint:"Buklaganda katak qaysi qatorga tushadi?",full:"Tik o'q bo'ylab buklaganda katak faqat o'ngga «sakraydi»: o'qdan o'ngda 3-katakka, o'sha qatorning o'zida. Chetdan sanash xato — masofani o'qdan sanaymiz."},
 tn:"Katakli daftarda yarim shaklni chizib bering — bolalar ikkinchi yarmini o'zi chizsin, so'ng ko'zgu bilan tekshirsin."},
{h:"Nuqtaga simmetrik nuqta",sum:"A′ nuqta A bilan bir balandlikda, o'qdan A gacha bo'lgan masofada, o'qning narigi tomonida.",a:"m04",
 start:function(){h11node({tap:h11t4,pts:[[2,3,'A']]});h11msg('A nuqtaga simmetrik A′ ni bosing')},fin:function(){h11node({pts:[[2,3,'A'],[8,3,'A′',C.ok]],segs:[[2,3,8,3]]});h11msg('A — o‘qdan 3 katak chapda, A′ — 3 katak o‘ngda ✓')},
 act:function(c,done){S.d4=done},
 html:"<p>A nuqtaga qizil o'qqa nisbatan simmetrik <b>A′</b> nuqtani toping va bosing.</p>",
 after:"<p>A dan o'qqa <b>3</b> katak. A′ ham o'qdan <b>3</b> katak narida, xuddi shu balandlikda. AA′ kesma o'qqa <b>perpendikular</b> va o'q uni teng ikkiga bo'ladi.</p>",
 q:{t:"Nuqta o'qning o'zida yotibdi. Uning simmetrik nuqtasi qayerda?",opts:["O'zida (o'qda)","O'qdan 1 katak narida","O'qdan 2 katak narida","Bunday nuqta yo'q"],ok:0,why:"O'qgacha masofa 0 — simmetrik nuqta o'zi bilan ustma-ust.",hint:"Nuqtadan o'qqacha masofa qancha?",full:"O'qda yotgan nuqtadan o'qqacha masofa 0. Buklaganda u joyidan siljimaydi — o'zi o'ziga simmetrik."},
 tn:"Bolalar ko'pincha chetdan sanaydi. «O'qdan sanaymiz!» qoidasini doskaga yozib qo'ying."},
{h:"Shakllarning nechta o'qi bor?",sum:"Kvadrat — 4, to'g'ri to'rtburchak — 2, teng tomonli uchburchak — 3, doira — cheksiz ko'p o'q.",a:"m05",
 start:function(){h11shape('kv')},fin:function(){h11shape('d')},
 html:"<p>Har bir shaklni bosib, o'qlarini sanang:</p>",
 btns:[["Kvadrat",function(c,done){h11shape('kv');mvK(done,4)}],["To'g'ri to'rtburchak",function(c,done){h11shape('tt');mvK(done,4)}],["Uchburchak",function(c,done){h11shape('uch');mvK(done,4)}],["Doira",function(c,done){h11shape('d');mvK(done,4)}]],g2:1,
 after:"<p>Kvadratning <b>4</b> ta o'qi bor (2 ta o'rta chiziq + 2 ta diagonal). To'g'ri to'rtburchakning — <b>2</b> ta. Teng tomonli uchburchakning — <b>3</b> ta. Doiraning — <b>cheksiz ko'p</b>: markazdan o'tgan har bir to'g'ri chiziq.</p>",
 q:{t:"Kvadratning nechta simmetriya o'qi bor?",opts:["2","4","1","8"],ok:1,why:"2 ta o'rta chiziq va 2 ta diagonal.",hint:"Kvadratni diagonal bo'ylab buklasa bo'ladimi?",full:"Kvadratni tik va yotiq o'rta chiziq bo'ylab (2 ta) va ikki diagonal bo'ylab (2 ta) buklash mumkin — jami 4 ta. 2 — faqat o'rta chiziqlarni sanash."},
 tn:"Qog'oz kvadratni 4 xil buklab, har gal ustma-ust tushishini ko'rsating."},
{h:"Tuzoq: to'g'ri to'rtburchakning diagonali",sum:"Diagonal to'g'ri to'rtburchakni teng bo'laklarga bo'lsa ham, simmetriya o'qi emas.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Ko'pchilik «diagonal ham o'q» deb o'ylaydi. Tekshirib ko'ramiz — buklaymiz!</p>",
 btns:[phaser(P6)],
 after:"<p>Diagonal bo'ylab buklaganda uchburchak <b>chetga chiqib ketadi</b> — ustma-ust tushmaydi. Shuning uchun to'g'ri to'rtburchakning faqat <b>2</b> ta o'qi bor. Kvadratda esa tomonlar teng — diagonal o'q bo'ladi.</p>",
 q:{t:"Shakl ikki teng bo'lakka bo'lindi. Bo'lish chizig'i albatta simmetriya o'qimi?",opts:["Ha, albatta","Yo'q, buklaganda ustma-ust tushishi kerak","Ha, agar bo'laklar uchburchak bo'lsa","Ha, agar chiziq to'g'ri bo'lsa"],ok:1,why:"Teng bo'laklar — o'q uchun yetarli emas.",hint:"To'g'ri to'rtburchakning diagonali bilan nima bo'ldi?",full:"Diagonal to'g'ri to'rtburchakni ikki teng uchburchakka bo'ladi, lekin buklaganda ular ustma-ust tushmaydi. O'qni faqat buklash (ko'zgu) bilan tekshiramiz."},
 tn:"Qog'oz to'g'ri to'rtburchakni diagonal bo'ylab buklatib ko'ring — bolalar o'z ko'zi bilan ko'rsin."},
{h:"Yotiq o'q: suvdagi aks",sum:"O'q yotiq bo'lsa, simmetrik shakl yuqori-pastga ag'dariladi: ko'ldagi aks.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=1;P7[1]()},
 html:"<p>Tinch ko'lda uy va daraxtning aksi ko'rinadi. Aks qanday joylashadi?</p>",
 btns:[phaser(P7)],
 after:"<p>Suv chizig'i — <b>yotiq simmetriya o'qi</b>. Har bir nuqta o'qdan qancha <b>yuqorida</b> bo'lsa, aksi shuncha <b>pastda</b>. Shuning uchun aksda tom pastga qaraydi, lekin chap-o'ng o'zgarmaydi.</p>",
 q:{t:"Daraxt uchi suvdan 5 m balandda. Suvdagi aksida uchi qayerda ko'rinadi?",opts:["Suvdan 5 m pastda","Suvdan 10 m pastda","Suv chizig'ida","Suvdan 5 m balandda"],ok:0,why:"O'qdan masofa saqlanadi: 5 m yuqori → 5 m past.",hint:"Simmetrik nuqta o'qdan qancha uzoqda bo'ladi?",full:"Simmetriyada o'qgacha masofa saqlanadi: uch suvdan 5 m yuqorida — aksi 5 m pastda. 10 m — bu daraxt uchi va aks uchi orasidagi masofa."},
 tn:"Ko'zguni stolga yotqizib, ustiga o'yinchoq qo'ying — yotiq o'qli aksni sinf ko'radi."},
{h:"Bilasizmi? Simmetriya atrofimizda",sum:"Registon ansambli, qor parchasi va kapalak — simmetriyaning mashhur namunalari.",a:"m08",
 start:function(){P1[2]()},fin:function(){P1[2]()},
 html:"<p>🕌 Samarqanddagi <b>Registon</b> maydonida Ulug'bek madrasasi (XV asr) va Sherdor madrasasi (XVII asr) bir-biriga qarama-qarshi turadi, Tillakori madrasasi esa o'rtada. Ansambl deyarli simmetrik ko'rinadi.</p><p>❄ Qor parchasi odatda <b>6</b> ta nurli bo'ladi va bir nechta simmetriya o'qiga ega.</p><p>🦋 Kapalak, ko'pchilik barglar va odam yuzi taxminan tik o'qqa nisbatan simmetrik.</p>",
 tn:"Bolalar uydan simmetrik narsa rasmini (gilam naqshi, so'zana, idish) chizib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){h11shape('kv')},fin:function(){h11shape('kv')},
 html:"<div class='memo'><ul><li><b>Simmetrik shakl</b>: o'q bo'ylab buklaganda yarmlari ustma-ust tushadi.</li><li>O'q tik, yotiq yoki qiya bo'lishi mumkin; bir nechta o'q ham bo'ladi.</li><li>Simmetrik nuqta o'qdan <b>bir xil masofada</b>, narigi tomonda; masofa o'qdan sanaladi.</li><li>Kvadrat — 4, to'g'ri to'rtburchak — 2, teng tomonli uchburchak — 3, doira — cheksiz ko'p o'q.</li><li>To'g'ri to'rtburchakning diagonali — o'q <b>emas</b>.</li><li>N, S, Z harflarida o'q yo'q; H da 2 ta.</li></ul></div>",
 tn:"Keyingi darsda «Yarim rasmni to'ldir» mashqi: doskadagi yarim naqshni bolalar navbat bilan to'ldiradi."}
];
var PROBS=[
{t:"Qaysi harfning tik simmetriya o'qi bor?",o:["A","F","R","L"],k:0,s:"A ni tik buklasak, ikki yarmi ustma-ust tushadi."},
{t:"Qaysi harfning yotiq simmetriya o'qi bor?",o:["B","F","L","N"],k:0,s:"B ni yotiq buklasak, yuqori va pastki yarmi ustma-ust tushadi."},
{t:"To'g'ri to'rtburchak (kvadrat emas)ning nechta simmetriya o'qi bor?",o:["2","4","1","0"],k:0,s:"Faqat 2 ta o'rta chiziq; diagonallar o'q emas."},
{t:"Kvadratning nechta simmetriya o'qi bor?",o:["4","2","1","8"],k:0,s:"2 o'rta chiziq + 2 diagonal = 4."},
{t:"Teng tomonli uchburchakning nechta simmetriya o'qi bor?",o:["3","1","6","0"],k:0,s:"Har uchidan qarama-qarshi tomon o'rtasiga — 3 ta."},
{t:"Doiraning nechta simmetriya o'qi bor?",o:["Cheksiz ko'p","4","2","1"],k:0,s:"Markazdan o'tgan har bir to'g'ri chiziq — o'q."},
{t:"Qaysi harfda simmetriya o'qi yo'q?",o:["S","X","H","O"],k:0,s:"S ni hech qaysi chiziq bo'ylab buklab ustma-ust tushirib bo'lmaydi."},
{t:"Qaysi raqamning yotiq simmetriya o'qi bor?",o:["3","2","4","7"],k:0,s:"3 ning yuqori va pastki yarmi bir xil (bosma shaklda)."},
{t:"Qaysi raqamning ham tik, ham yotiq o'qi bor (bosma shaklda)?",o:["8","3","1","6"],k:0,s:"8 ni ham tik, ham yotiq buklash mumkin."},
{t:"Katak o'qdan chapda 4-katak. Simmetrik katak qayerda?",o:["O'qdan o'ngda 4-katak, o'sha qatorda","O'qdan o'ngda 5-katak","O'qdan chapda 4-katak","O'ng chetda"],k:0,s:"Masofa o'qdan sanaladi va qator o'zgarmaydi."},
{t:"A nuqta tik o'qdan 2 katak chapda. A va A′ orasida necha katak?",o:["4","2","3","6"],k:0,s:"2 + 2 = 4 katak."},
{t:"A va A′ simmetrik, ular orasida 10 katak. A o'qdan qancha uzoqda?",o:["5 katak","10 katak","20 katak","2 katak"],k:0,s:"O'q kesmani teng ikkiga bo'ladi: 10 : 2 = 5."},
{t:"Nuqta simmetriya o'qida yotibdi. Uning simmetrigi qayerda?",o:["O'zida","1 katak o'ngda","1 katak chapda","Bunday nuqta yo'q"],k:0,s:"O'qgacha masofa 0 — nuqta o'ziga simmetrik."},
{t:"Shakl tik o'qqa nisbatan simmetrik. Chap yarmining yuzi 12 katak. Butun shakl yuzi?",o:["24 katak","12 katak","6 katak","14 katak"],k:0,s:"Ikki yarmi teng: 12 + 12 = 24."},
{t:"Simmetrik shakl chegarasining uzunligi 30 sm. O'q chegarani ikki teng qismga bo'ladi. Bir qismi necha sm?",o:["15 sm","30 sm","60 sm","10 sm"],k:0,s:"Ikki yarmi teng: 30 : 2 = 15 sm."},
{t:"Qaysi so'zning barcha harflari yotiq simmetriya o'qiga ega (bosma bosh harflar)?",o:["BEK","BOR","KAM","XAT"],k:0,s:"B, E, K — har biri yotiq o'qqa ega. R, A, M, T da yotiq o'q yo'q."},
{t:"Daraxt uchi suvdan 4 m balandda. Daraxt uchi va uning suvdagi aksi orasida necha metr?",o:["8 m","4 m","2 m","16 m"],k:0,s:"4 m yuqori + 4 m past = 8 m."},
{t:"Qaysi shaklni diagonal bo'ylab buklasak, yarmlari ustma-ust tushadi?",o:["Kvadrat","To'g'ri to'rtburchak (kvadrat emas)","Har qanday to'rtburchak","Hech qaysi"],k:0,s:"Faqat kvadratda diagonal — simmetriya o'qi."},
{t:"Qaysi so'z tik o'qqa nisbatan simmetrik (bosma bosh harflar bilan)?",o:["OTO","OLO","ONA","OSH"],k:0,s:"O, T, O — har biri tik simmetrik va so'z ham o'rtaga nisbatan simmetrik."},
{t:"Kvadrat va teng tomonli uchburchakning simmetriya o'qlari jami nechta?",o:["7","6","5","8"],k:0,s:"4 + 3 = 7."}
];
function PRACT_STAGE(){P1[2]()}
var PREP_DATA={teach:["Simmetrik shakl va simmetriya o'qi (buklash bilan tekshirish).","Harflar va shakllarning o'qlari soni.","Katakli qog'ozda simmetrik katak/nuqtani yasash: masofa o'qdan sanaladi.","Tuzoq: to'g'ri to'rtburchak diagonali — o'q emas; yotiq o'q (suvdagi aks)."],
 mist:["Masofani o'qdan emas, chetdan sanaydi.","Teng bo'laklarga bo'lgan har qanday chiziqni o'q deb hisoblaydi.","To'g'ri to'rtburchakka 4 ta o'q chizadi.","Yotiq o'qda chap-o'ngni ham almashtiradi."],
 need:["A4 qog'oz, qaychi (kapalak, barg qirqish).","Kichik ko'zgu.","Katakli daftar, rangli qalam."],
 board:["Buklash → ustma-ust → <span class='w2'>simmetrik</span>.","Harflar: M (tik), E (yotiq), H (2), N (yo'q).","Katakda: o'qdan bir xil masofa.","A — 3 katak chapda, A′ — 3 katak o'ngda.","Kvadrat 4, to'g'ri to'rtburchak 2, uchburchak 3, doira ∞.","Diagonal — o'q emas!","Suvdagi aks — yotiq o'q."]};
