var CODE='4A1',TITLE='4-sinf · Ko‘p xonali sonlarni o‘qish va yozish';
var P1=[function(){a4table(3405028,{top:'3 405 028'});msg('Yetti xonali son. Uni qanday o‘qiymiz?')},
 function(){a4table(3405028,{hl:[0,1,2],top:'028 — birlar sinfi'});msg('O‘ngdan 3 ta raqam — <b>birlar sinfi</b>: 028')},
 function(){a4table(3405028,{hl:[3,4,5],top:'405 — minglar sinfi'});msg('Keyingi 3 ta — <b>minglar sinfi</b>: 405')},
 function(){a4table(3405028,{hl:[6],top:'3 — millionlar sinfi'});msg('Qolgani — <b>millionlar sinfi</b>: 3 (sinfda 1, 2 yoki 3 ta raqam bo‘lishi mumkin)')}];
var STEPS=[
{h:"Xonalar va sinflar",sum:"O'ngdan chapga uchtadan: birlar, minglar, millionlar sinfi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Har bir raqam o'z <b>xonasida</b> turadi: birlik, o'nlik, yuzlik, ming… Har uchta xona birga — bitta <b>sinf</b>. Sonni sinflarga ajratib ko'ring:</p>",
 btns:[phaser(P1)],
 after:"<p>Har sinf ichida yana uchta xona: <b>birlik, o'nlik, yuzlik</b>. Shuning uchun «ming» sinfida — birlik ming, o'n ming, yuz ming; «million» sinfida — million, o'n million, yuz million.</p>",
 q:{t:"86 400 352 sonida nechta sinf bor?",opts:["3","2","8","4"],ok:0,why:"86 | 400 | 352 — uchta sinf.",hint:"O'ngdan uchtadan ajrating: 352, 400, keyin qolgani.",full:"86 400 352 → 352 (birlar), 400 (minglar), 86 (millionlar) — 3 ta sinf. 8 — bu xonalar soni, sinflar emas."},
 tn:"Doskada jadval: ustunlar ustida xona nomlari, pastida sinflar yoyi. Rangli bo'r bilan sinflarni ajrating (Singapur — joy qiymati jadvali)."},
{h:"Katta sonni o'qish",sum:"Sinfni uch xonali son kabi o'qib, sinf nomini qo'shamiz.",a:"m02",
 start:function(){a4table(3405028,{top:'3 405 028'});msg('Qaysi o‘qilishi to‘g‘ri?')},fin:function(){a4table(3405028,{top:'3 405 028'});msg('<b>uch million to‘rt yuz besh ming yigirma sakkiz</b>')},
 html:"<p>3 405 028 qanday o'qiladi? Har sinfni alohida o'qib, nomini qo'shing:</p>",
 btns:a4ch(["uch million to'rt yuz besh ming yigirma sakkiz","uch million qirq besh ming yigirma sakkiz","o'ttiz to'rt million besh ming yigirma sakkiz"],0,function(){msg('3 <b>million</b> · 405 <b>ming</b> · 28 — to‘g‘ri!')},function(i){msg(i===1?'Minglar sinfi — 405, ya‘ni «to‘rt yuz besh» ming, «qirq besh» emas':'Millionlar sinfida faqat bitta raqam — 3. Sinflarni o‘ngdan ajrating!')}),
 after:"<p>Qoida: <b>chapdan</b> sinfma-sinf o'qiymiz, har biridan keyin sinf nomini aytamiz. Birlar sinfi nomi aytilmaydi. Sinf to'liq nol bo'lsa (000) — u umuman aytilmaydi: 7 000 015 — «yetti million o'n besh».</p>",
 q:{t:"7 000 015 qanday o'qiladi?",opts:["yetti million o'n besh","yetti million o'n besh ming","yetmish million o'n besh","yetti ming o'n besh"],ok:0,why:"Minglar sinfi 000 — aytilmaydi.",hint:"Minglar sinfida qaysi son turibdi?",full:"7 | 000 | 015: millionlar — 7, minglar — 0 (aytilmaydi), birlar — 15. «yetti million o'n besh». «…o'n besh ming» — 15 ni minglar sinfiga qo'yish."},
 tn:"Bolalar navbatma-navbat sonni o'qisin, qolganlar sinflar chizig'ini barmoq bilan ko'rsatsin."},
{h:"Nollar bilan yozish",sum:"«Besh million yetmish ming to'qqiz» = 5 070 009.",a:"m03",
 start:function(){a4table(0,{str:'???????',top:'besh million yetmish ming to‘qqiz'});msg('Har sinf uch xona — bo‘sh xonaga 0')},fin:function(){a4table(5070009,{top:'5 070 009'});msg('5 | 070 | 009')},
 html:"<p>«<b>Besh million yetmish ming to'qqiz</b>» sonini yozing. Tuzoq — sinflar ichida nollarni tushirib qoldirish:</p>",
 btns:a4ch(["5 070 009","5 700 009","570 009"],0,function(){a4table(5070009,{top:'5 070 009'});msg('Minglar: 070, birlar: 009 — har biri <b>uch xona</b>')},function(i){a4table(i===1?5700009:570009,{top:i===1?'5 700 009 ?':'570 009 ?'});msg(i===1?'5 700 009 — «besh million yetti yuz ming to‘qqiz»':'570 009 — bu «besh yuz yetmish ming to‘qqiz», million yo‘q!')}),g3:1,
 after:"<p>Usul: avval <b>sinflar skeletini</b> chizamiz: _ | _ _ _ | _ _ _. Keyin har sinfga son yozamiz: 70 → 070, 9 → 009. Bo'sh qolgan xonaga — 0.</p>",
 q:{t:"«Yigirma million uch yuz ming olti» qaysi son?",opts:["20 300 006","20 300 600","2 300 006","20 030 006"],ok:0,why:"20 | 300 | 006.",hint:"Birlar sinfiga «olti» qanday yoziladi?",full:"Millionlar — 20, minglar — 300, birlar — 006. 20 300 006. «20 300 600» — oltini yuzlik deb yozish; «20 030 006» — 300 ni 030 deb yozish."},
 tn:"Bo'sh skelet kartochkalari: _ | _ _ _ | _ _ _. Diktant: o'qituvchi aytadi, bola skeletga yozadi."},
{h:"Raqam qiymati xonaga bog'liq",sum:"7 384 526 da 8 — o'n minglar xonasida: qiymati 80 000.",a:"m04",
 start:function(){a4table(7384526,{top:'7 384 526'});msg('8 raqami qancha qiymatga ega?')},fin:function(){a4table(7384526,{hl:[4],top:'8 → 80 000'});msg('8 o‘n ming = <b>80 000</b>')},
 html:"<p>Bir xil raqam turli xonada turli qiymatga ega. 7 384 526 da <b>8</b> raqami nimani bildiradi?</p>",
 btns:a4ch(["8","80 000","8 000","800 000"],1,function(){a4table(7384526,{hl:[4],top:'8 → 80 000'});msg('O‘ngdan 5-xona — <b>o‘n minglar</b>: 8 · 10 000 = 80 000')},function(i){msg(i===0?'8 — bu raqamning o‘zi. Uning <b>qiymati</b> xonaga bog‘liq':'Xonani o‘ngdan sanang: birlik, o‘nlik, yuzlik, ming, o‘n ming…')}),g2:1,
 after:"<p>Raqam qiymati = raqam · xona birligi. 7 384 526 da: 7 — 7 000 000, 3 — 300 000, 8 — 80 000, 4 — 4 000. Shuning uchun 0 juda muhim: u xonani «band qilib» turadi.</p>",
 q:{t:"Qaysi sonda 5 raqamining qiymati 500 000 ga teng?",opts:["2 534 100","2 453 100","5 234 100","2 345 100"],ok:0,why:"2 534 100: 5 — yuz minglar xonasida.",hint:"Yuz minglar — o'ngdan 6-xona.",full:"2 534 100 da 5 o'ngdan 6-xonada → 500 000. 2 453 100 da 50 000, 5 234 100 da 5 000 000, 2 345 100 da 5 000."},
 tn:"Raqam kartochkasini jadvalda bir ustundan boshqasiga surib, qiymati qanday o'zgarishini so'rang."},
{h:"Tuzoq: jami nechta ming?",sum:"2 460 315 da minglar raqami — 0, jami minglar — 2 460.",a:"m05",
 start:function(){a4table(2460315,{top:'2 460 315'});msg('Bu sonda jami nechta to‘liq ming bor?')},fin:function(){a4table(2460315,{hl:[3,4,5,6],top:'jami 2 460 ta ming'});msg('Mingdan kichik qism (315) tashlanadi: <b>2 460</b> ming')},
 html:"<p>«Minglar xonasidagi raqam» va «<b>jami nechta ming</b>» — har xil savollar. 2 460 315 da jami nechta to'liq ming bor?</p>",
 btns:a4ch(["0","460","2 460","2 460 315"],2,function(){a4table(2460315,{hl:[3,4,5,6],top:'jami 2 460 ta ming'});msg('1 million = 1 000 ming, shuning uchun 2 million ham minglarga kiradi: <b>2 460</b>')},function(i){msg(i===0?'0 — minglar xonasidagi raqam. Savol — jami minglar!':i===1?'460 — faqat minglar sinfi. Millionlar ham minglardan tuzilgan!':'Bu birliklar soni. Mingdan kichik qismni tashlang')}),g2:1,
 after:"<p>Usul: kerakli xonadan <b>o'ngdagi</b> raqamlarni yopamiz — qolgani javob. Jami minglar: 2 460|315 → 2 460. Jami yuzliklar: 24 603|15 → 24 603. Jami o'n minglar: 246|0315 → 246.</p>",
 q:{t:"2 460 315 da jami nechta yuz ming bor?",opts:["24","4","2","246"],ok:0,why:"Oxirgi 5 raqamni yopamiz: 24.",hint:"Yuz minglardan o'ngdagi 5 ta raqamni yoping.",full:"24|60 315 → 24 ta yuz ming (2 400 000). «4» — yuz minglar xonasidagi raqam; «246» — o'n minglar soni; «2» — millionlar soni."},
 tn:"Qog'oz bilan raqamlarni o'ngdan yopib ko'rsatish — oddiy va ishonchli usul."},
{h:"Xona qo'shiluvchilari",sum:"4 030 607 = 4 000 000 + 30 000 + 600 + 7.",a:"m06",
 start:function(){a4table(4030607,{top:'4 030 607'});msg('Nol bo‘lmagan har bir raqam — bitta qo‘shiluvchi')},fin:function(){a4table(4030607,{hl:[6,4,2,0],top:'4 000 000 + 30 000 + 600 + 7'});msg('4 030 607 = 4 000 000 + 30 000 + 600 + 7')},
 html:"<p>4 030 607 ni xona qo'shiluvchilari yig'indisiga ajrating:</p>",
 btns:a4ch(["4 000 000 + 30 000 + 600 + 7","4 000 000 + 3 000 + 600 + 7","400 000 + 30 000 + 600 + 7"],0,function(){a4table(4030607,{hl:[6,4,2,0],top:'4 000 000 + 30 000 + 600 + 7',tfs:13});msg('4 — millionlar, 3 — o‘n minglar, 6 — yuzliklar, 7 — birliklar')},function(i){msg(i===1?'3 qaysi xonada? O‘ngdan 5-xona — o‘n minglar':'4 o‘ngdan 7-xonada — bu millionlar')}),
 after:"<p>Teskarisi ham muhim: 6 000 000 + 50 000 + 8 = ? Avval skelet: _ | _ _ _ | _ _ _, keyin joylaymiz: <b>6 050 008</b>.</p>",
 q:{t:"6 000 000 + 50 000 + 8 = ?",opts:["6 050 008","6 500 008","6 050 080","658"],ok:0,why:"6 | 050 | 008.",hint:"50 000 minglar sinfida qanday yoziladi?",full:"Millionlar — 6, minglar — 050, birlar — 008: 6 050 008. «6 500 008» — 50 000 ni 500 000 deb olish; «658» — nollarni tashlab yuborish."},
 tn:"Montessori raqam kartochkalari: 4 000 000, 30 000, 600, 7 ni ustma-ust qo'yib sonni «yig'ish»."},
{h:"Bitta raqam o'zgarsa…",sum:"3 405 028 da 4 ni 7 ga almashtirsak, son 300 000 ga oshadi.",a:"m07",
 start:function(){a4table(3405028,{top:'3 405 028'});msg('4 raqamini 7 ga almashtiramiz')},fin:function(){a4table(3705028,{hl:[5],top:'3 705 028'});msg('3 705 028 − 3 405 028 = <b>300 000</b>')},
 html:"<p>3 405 028 da <b>4</b> raqamini <b>7</b> ga almashtirdik. Son qanchaga oshdi?</p>",
 btns:a4ch(["3 ga","300 000 ga","3 000 ga","700 000 ga"],1,function(){a4table(3705028,{hl:[5],top:'3 705 028'});msg('Yuz minglar xonasida 4 → 7: (7 − 4) · 100 000 = <b>300 000</b>')},function(i){msg(i===0?'7 − 4 = 3, lekin bu raqamlar yuz minglar xonasida!':i===3?'700 000 — yangi raqam qiymati. Farqni toping: 700 000 − 400 000':'Xonani o‘ngdan sanang: 4 — 6-xonada')}),g2:1,
 after:"<p>O'zgarish = raqamlar farqi · xona birligi. Shu sababli <b>chapdagi</b> raqamdagi kichik o'zgarish ham sonni juda katta o'zgartiradi, oxirgi raqam esa juda kam.</p>",
 q:{t:"58 162 da 1 ni 9 ga almashtirsak son qanchaga oshadi?",opts:["800","8","8 000","900"],ok:0,why:"1 — yuzliklar xonasida: (9 − 1) · 100 = 800.",hint:"1 qaysi xonada turibdi?",full:"58 162: 1 o'ngdan 3-xonada — yuzlik. (9 − 1) · 100 = 800. 58 962 − 58 162 = 800. «900» — yangi raqam qiymati, farq emas."},
 tn:"Kalkulyator (yoki doskada) bilan tekshiring: 58 962 − 58 162."},
{h:"Bilasizmi?",sum:"Biz ishlatadigan o'nli yozuv Hindistonda paydo bo'lgan va al-Xorazmiy kitobi orqali Yevropaga tarqalgan.",a:"m08",
 start:function(){a4table(825,{top:'825-yillar · al-Xorazmiy'});msg('O‘nli pozitsion yozuv')},fin:function(){a4table(825,{top:'825-yillar · al-Xorazmiy'});msg('O‘nli pozitsion yozuv')},
 html:"<p>📜 Atigi <b>10 ta raqam</b> (0–9) bilan istalgan katta sonni yozish — Hindistonda o'ylab topilgan. Bu usulni Yevropaga bizning yurtdoshimiz <b>Muhammad al-Xorazmiy</b>ning hind hisobi haqidagi kitobi (IX asr) yetkazgan. Uning lotincha tarjimasi «Algoritmi dicit…» — «Al-Xorazmiy aytadi…» deb boshlangan, «algoritm» so'zi shundan.</p><p>🔢 Rim raqamlari bilan katta sonni yozish juda noqulay edi — xona qiymati yo'q edi.</p>",
 tn:"Loyiha nomi bilan bog'lang: «Yosh Xorazmiylar» — al-Xorazmiy merosi davomchilari."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){a4table(3405028,{top:'3 405 028'})},fin:function(){a4table(3405028,{top:'3 405 028'})},
 html:"<div class='memo'><ul><li>O'ngdan uchtadan — <b>sinflar</b>: birlar, minglar, millionlar.</li><li>O'qish: chapdan sinfma-sinf + sinf nomi; 000 sinf aytilmaydi.</li><li>Yozish: avval skelet _ | _ _ _ | _ _ _, bo'sh xonaga 0.</li><li>Raqam qiymati = raqam · xona birligi.</li><li>Jami minglar — o'ngdagi 3 raqamni yopib qolgan son.</li><li>Raqam o'zgarsa, son (farq · xona birligi) ga o'zgaradi.</li></ul></div>",
 tn:"Keyingi dars — taqqoslash va yaxlitlash."}
];
var PROBS=[
{t:"86 400 352 sonida nechta sinf bor?",o:["3","8","2","4"],k:0,s:"86 | 400 | 352."},
{t:"3 405 028 qanday o'qiladi?",o:["uch million to'rt yuz besh ming yigirma sakkiz","uch million qirq besh ming yigirma sakkiz","o'ttiz to'rt million besh ming yigirma sakkiz","uch million to'rt yuz besh ming ikki yuz sakkiz"],k:0,s:"3 | 405 | 028."},
{t:"7 000 015 qanday o'qiladi?",o:["yetti million o'n besh","yetti million o'n besh ming","yetmish million o'n besh","yetti ming o'n besh"],k:0,s:"Minglar sinfi 000 — aytilmaydi."},
{t:"«Besh million yetmish ming to'qqiz» qaysi son?",o:["5 070 009","5 700 009","570 009","5 070 900"],k:0,s:"5 | 070 | 009."},
{t:"«Yigirma million uch yuz ming olti» qaysi son?",o:["20 300 006","20 300 600","2 300 006","20 030 006"],k:0,s:"20 | 300 | 006."},
{t:"7 384 526 da 8 raqamining qiymati:",o:["80 000","8 000","800 000","8"],k:0,s:"O'n minglar xonasi."},
{t:"Qaysi sonda 5 raqamining qiymati 500 000?",o:["2 534 100","2 453 100","5 234 100","2 345 100"],k:0,s:"5 — yuz minglar xonasida."},
{t:"2 460 315 da jami nechta ming bor?",o:["2 460","460","0","2"],k:0,s:"O'ngdagi 3 raqamni yopamiz."},
{t:"2 460 315 da jami nechta yuz ming bor?",o:["24","4","246","2"],k:0,s:"24|60 315."},
{t:"4 030 607 = ?",o:["4 000 000 + 30 000 + 600 + 7","4 000 000 + 3 000 + 600 + 7","400 000 + 30 000 + 600 + 7","4 000 000 + 30 000 + 60 + 7"],k:0,s:"4 mln, 3 o'n ming, 6 yuz, 7 bir."},
{t:"6 000 000 + 50 000 + 8 = ?",o:["6 050 008","6 500 008","6 050 080","6 005 008"],k:0,s:"6 | 050 | 008."},
{t:"58 162 da 1 ni 9 ga almashtirsak son qanchaga oshadi?",o:["800","8","900","8 000"],k:0,s:"(9 − 1) · 100."},
{t:"Eng kichik yetti xonali son:",o:["1 000 000","1 111 111","999 999","100 000"],k:0,s:"1 va oltita nol."},
{t:"1 000 000 da nechta yuz ming bor?",o:["10","100","1 000","1"],k:0,s:"10 · 100 000 = 1 000 000."},
{t:"Sonda 3 ta million, 12 ta ming va 5 ta birlik bor. Bu qaysi son?",o:["3 012 005","3 120 005","312 005","3 012 500"],k:0,s:"3 000 000 + 12 000 + 5."},
{t:"Sonda 45 ta o'n ming va 7 ta yuzlik bor. Bu qaysi son?",o:["450 700","45 700","4 507 000","450 070"],k:0,s:"450 000 + 700."},
{t:"Qaysi sonda nollar eng ko'p?",o:["5 000 070","5 070 700","5 007 070","50 700"],k:0,s:"5 000 070 — 5 ta nol; 5 070 700 va 5 007 070 — 4 tadan; 50 700 — 3 ta."},
{t:"2 □ 06 315 sonida □ o'rniga qaysi raqam qo'yilsa, minglar sinfi 806 bo'ladi?",o:["8","0","6","2"],k:0,s:"2 | □06 | 315 → □ = 8."},
{t:"Raqamlari 9, 0, 0, 4, 1, 7, 2 (har biri bir marta) bo'lgan eng katta son:",o:["9 742 100","9 742 001","9 000 742","1 002 479"],k:0,s:"Raqamlarni kamayish tartibida: 9, 7, 4, 2, 1, 0, 0."},
{t:"Bir sonda 7 ta raqam bor, millionlar sinfida 2, minglar sinfida 15, birlar sinfida 9. Bu son qanday yoziladi?",o:["2 015 009","2 150 009","215 009","2 015 900"],k:0,s:"2 | 015 | 009."}
];
function PRACT_STAGE(){a4table(3405028,{top:'3 405 028'})}
var PREP_DATA={teach:["Xonalar va sinflar: birlar, minglar, millionlar.","Ko'p xonali sonlarni o'qish va nollar bilan yozish.","Raqam qiymati, jami minglar, xona qo'shiluvchilari, raqam o'zgarganda son o'zgarishi."],mist:["Sinflarni chapdan ajratadi (34 | 050 | 28).","«Besh million yetmish ming to'qqiz» ni 5 700 009 yoki 570 009 deb yozadi.","Jami minglar o'rniga minglar xonasidagi raqamni aytadi.","Raqam qiymatini raqamning o'zi deb biladi."],need:["Xonalar jadvali (7 ustun), raqam kartochkalari, bo'sh skelet kartochkalar."],board:["<span class='w2'>3 | 405 | 028</span> — millionlar | minglar | birlar.","<span class='w2'>5 070 009</span> — har sinf uch xona.","<span class='w2'>8 o'n ming = 80 000</span>.","<span class='w2'>2 460|315 → 2 460 ming</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
