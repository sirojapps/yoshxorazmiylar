// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F11',TITLE='4-sinf · Foiz';
function f11grid(x,y,s,n,col){var g=E('g',{},S.g);for(var c=0;c<10;c++)for(var r=0;r<10;r++){var k=r*10+c;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:k<n?(col||C.b):'#fff',stroke:'#c9d6e2','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:'#33475b','stroke-width':1.6},g);return g}
var F11P1=[function(){clear();f11grid(30,14,14.5,0);f4t(260,50,'1 butun',14);f4t(260,74,'= 100 katak',13,'#33475b');f4c(['Kvadrat — 100 ta teng katak'])},
 function(){clear();f11grid(30,14,14.5,1,C.a);f4t(260,40,'1 katak',14,C.a2);f4t(260,70,'1/100 = 0,01',15,C.a2);f4t(260,100,'= 1 %',22,C.bad);f4t(260,126,'«bir foiz»',12,'#33475b');f4c(['Yuzdan birning maxsus nomi — <b>foiz</b>. Belgisi: <b>%</b>'])},
 function(){clear();f11grid(30,14,14.5,25,C.a);f4t(260,50,'25 katak',14,C.a2);f4t(260,80,'25/100 = 0,25',15,C.a2);f4t(260,112,'= 25 %',22,C.bad);f4c(['25 ta yuzdan bir — <b>25 %</b>. Bu chorak!'])},
 function(){clear();f11grid(30,14,14.5,100,C.ok);f4t(260,60,'100 katak',14,C.ok);f4t(260,92,'= 100 %',22,C.ok);f4t(260,118,'= 1 butun',13,'#33475b');f4c(['Butun — <b>100 %</b>. Hamma narsa 100 % dan boshlanadi'])}];
var F11P2=[function(){clear();f4t(180,40,'1/2 = 50/100 = 50 %',18,C.blue);f11grid(130,56,10,50,C.b);f4c(['Yarim — 50 %'])},
 function(){clear();f4t(90,30,'1/2 = 50 %',15,C.blue);f11grid(45,44,9,50,C.b);f4t(270,30,'1/4 = 25 %',15,C.a2);f11grid(225,44,9,25,C.a);f4c(['Chorak — 25 %'])},
 function(){clear();f4t(70,24,'1/2 = 50 %',12,C.blue);f11grid(35,32,7,50,C.b);f4t(180,24,'1/4 = 25 %',12,C.a2);f11grid(145,32,7,25,C.a);f4t(290,24,'1/10 = 10 %',12,C.ok);f11grid(255,32,7,10,'#7bc47f');f4t(180,134,'3/4 = 75 %;  1/5 = 20 %;  1 = 100 %',14,'#1d2b3a');f4c(['Eng kerakli juftliklar: <b>1/2 = 50 %, 1/4 = 25 %, 3/4 = 75 %, 1/10 = 10 %, 1/5 = 20 %</b>'])}];
function f11bar(n,p,st){clear();var x=30,w=300,y=60;f4bar(x,y,w,40,10,st>=2?Math.round(p/10):0,C.b,st>=1?Array(10).fill(String(n/10)):null);f4Br(x,x+w,y-6,n+' = 100 %',true,'#33475b');if(st>=2)f4Br(x,x+w*p/100,y+44,p+' % = '+(n*p/100),false,C.blue)}
var F11P3=[function(){f11bar(300,30,0);f4c(['300 so‘mning 30 % i qancha? Tasma — 300 so‘m, bu 100 %'])},function(){f11bar(300,30,1);f4c(['1 % = 300 : 100 = <b>3</b>; 10 % = 30'])},function(){f11bar(300,30,2);f4c(['30 % = 3 · 30 = <b>90</b> so‘m','Qoida: <b>son : 100 · foiz</b>'])}];
function f11disc(st){clear();var g=S.g;E('rect',{x:30,y:30,width:130,height:110,rx:8,fill:'#fff',stroke:'#7b8794','stroke-width':1.5},g);f4t(95,52,'Kitob',13,'#33475b');f4t(95,80,'40 000',16,'#1d2b3a');if(st>=1){E('line',{x1:60,y1:76,x2:130,y2:76,stroke:C.bad,'stroke-width':2.5},g)}
 E('circle',{cx:150,cy:40,r:18,fill:C.bad},g);T(g,150,45,'−20%',{'font-size':10,fill:'#fff','font-weight':800});
 if(st>=1)f4t(260,50,'20 % = 40 000 : 100 · 20',11,'#33475b');if(st>=1)f4t(260,72,'= 8 000 so‘m chegirma',13,C.bad);if(st>=2){f4t(260,110,'40 000 − 8 000',13,'#33475b');f4t(260,136,'= 32 000 so‘m',18,C.ok);f4t(95,118,'32 000',18,C.ok)}}
var F11P5=[function(){f11disc(0);f4c(['Kitob 40 000 so‘m, chegirma 20 %. Endi necha so‘m?'])},function(){f11disc(1);f4c(['Chegirma: 40 000 : 100 · 20 = <b>8 000</b> so‘m'])},function(){f11disc(2);f4c(['Yangi narx: 40 000 − 8 000 = <b>32 000</b> so‘m','Yoki: qoladi 80 % → 40 000 : 100 · 80 = 32 000'])}];
function f11inv(st){clear();var x=30,w=300,y=62;f4bar(x,y,w,38,10,2,C.a,st>=1?['6','6','','','','','','','',''].map(function(v,i){return st>=2?'6':v}):null);f4Br(x,x+w*0.2,y+42,'20 % = 12',false,C.a2);f4Br(x,x+w,y-6,st>=2?'100 % = 60':'100 % = ?',true,'#33475b');if(st>=1)f4t(180,150,st>=2?'10 % = 6 → 100 % = 6 · 10 = 60':'20 % = 12 → 10 % = 12 : 2 = 6',13,st>=2?C.ok:'#33475b')}
var F11P6=[function(){f11inv(0);f4c(['Sinfning 20 % i — 12 o‘quvchi — a’lochi. Sinfda nechta o‘quvchi bor?'])},function(){f11inv(1);f4c(['20 % — 12 kishi. 10 % — <b>6</b> kishi (yarmi)'])},function(){f11inv(2);f4c(['100 % — 10 ta 10 %: 6 · 10 = <b>60</b> o‘quvchi','Qoida: <b>qism : foiz · 100</b> = 12 : 20 · 100 = 60'])}];
function f11tuz(st){clear();f4t(90,30,'Sinf A: 40 bola',13,C.blue);f4t(270,30,'Sinf B: 20 bola',13,C.a2);f4bar(20,44,140,30,10,5,C.b);f4bar(200,44,140,30,10,5,C.a);f4t(90,100,'50 % qiz',14,C.blue);f4t(270,100,'50 % qiz',14,C.a2);if(st){f4t(90,130,'= 20 ta qiz',16,C.blue);f4t(270,130,'= 10 ta qiz',16,C.a2);f4t(180,160,'Foiz teng, son — har xil!',13,C.bad)}}
function PRACT_STAGE(){F11P2[2]();f4c(['1 % = 1/100 = 0,01. <b>Sonning foizi: son : 100 · foiz</b>'])}
var STEPS=[
{h:"Yuzdan birning nomi — foiz",sum:"1 % = 1/100 = 0,01. 25 % = 25/100 — chorak. 100 % = butun.",a:"m01",
 start:function(){startPh(F11P1)},fin:function(){S.ph=3;F11P1[3]()},
 html:"<p>Do'konda «−20 %», telefonda «quvvat 45 %», sinfda «a'lochilar 30 %». Bu belgi nima? Bosing:</p>",btns:[phaser(F11P1)],
 after:"<p><b>Foiz</b> — yuzdan bir qismning maxsus nomi: <b>1 % = 1/100 = 0,01</b>. Butun narsa — <b>100 %</b>. So'z lotincha «pro centum» — «yuzga nisbatan» degani.</p><p>Foiz — ham oddiy kasr (yuzdan), ham o'nli kasr (0,01). Uchta yozuv — bir ma'no.</p>",
 q:{t:"37 % qaysi kasrga teng?",opts:["37/100","37/10","3,7","1/37"],ok:0,why:"1 % = 1/100.",hint:"Foiz — yuzdan bir qism.",full:"37 % = 37 ta yuzdan bir = 37/100 = 0,37. «37/10» — bu 3,7 (370 %), «1/37» — teskari."},
 tn:"100 katakli kvadrat — foizning eng yaxshi modeli. Bolalar 1 %, 10 %, 25 %, 50 % ni bo'yab, ostiga kasr va o'nli kasrni yozsin."},
{h:"Tanish kasrlar foizda",sum:"1/2 = 50 %, 1/4 = 25 %, 3/4 = 75 %, 1/10 = 10 %, 1/5 = 20 %, 1 = 100 %.",a:"m02",
 start:function(){startPh(F11P2)},fin:function(){S.ph=2;F11P2[2]()},
 html:"<p>Yarim — necha foiz? Chorak-chi? Bosing:</p>",btns:[phaser(F11P2)],
 after:"<p>Kasrni foizga aylantirish — maxrajni 100 ga keltirish: 1/2 = 50/100 = <b>50 %</b>, 1/4 = 25/100 = <b>25 %</b>, 1/5 = 20/100 = <b>20 %</b>. Bu juftliklarni yodlab oling — ular hayotda eng ko'p uchraydi.</p>",
 q:{t:"3/4 necha foiz?",opts:["34 %","75 %","25 %","43 %"],ok:1,why:"3/4 = 75/100.",hint:"1/4 = 25 %. 3/4 — uchta chorak.",full:"1/4 = 25 %, 3/4 = 3 · 25 % = 75 %. «34 %» — surat va maxrajni yonma-yon yozish, «25 %» — bu 1/4."},
 tn:"Kartochka o'yini: 1/2, 1/4, 3/4, 1/5, 1/10 va 50 %, 25 %, 75 %, 20 %, 10 % — juftlarni topish."},
{h:"Sonning foizini topish",sum:"300 ning 30 % i: 1 % = 300 : 100 = 3; 30 % = 3 · 30 = 90. Qoida: son : 100 · foiz.",a:"m03",
 start:function(){startPh(F11P3)},fin:function(){S.ph=2;F11P3[2]()},
 html:"<p>Bobo nabirasiga 300 so'mning 30 % ini berdi. Bu qancha? Bosing:</p>",btns:[phaser(F11P3)],
 after:"<p>Avval <b>1 %</b> ni topamiz — sonni 100 ga bo'lamiz: 300 : 100 = 3. Keyin kerakli foizga ko'paytiramiz: 3 · 30 = <b>90</b>.</p><p>Bu «sonning kasrini topish» bilan bir xil: 300 ning 30/100 qismi.</p>",
 q:{t:"500 ning 40 % i nechaga teng?",opts:["200","20","2 000","450"],ok:0,why:"500 : 100 · 40 = 200.",hint:"Avval 1 % ni toping: 500 : 100.",full:"1 % = 5, 40 % = 5 · 40 = 200. «20» — 10 marta kam, «2 000» — 100 ga bo'lishni unutish."},
 tn:"Singapur usuli: 100 % tasma chizib, 10 ta teng bo'lakka bo'ling (har biri 10 %). Ko'p masalalar 10 % orqali og'zaki yechiladi."},
{h:"Tez usullar: 10 %, 50 %, 25 %",sum:"10 % — 10 ga bo'lish; 50 % — yarmi; 25 % — chorak; 5 % — 10 % ning yarmi.",a:"m04",
 start:function(){clear();f4t(180,60,'800 ning 25 % i = ?',22);f4msg('Hisoblamasdan — tez usul bilan')},
 fin:function(){clear();f4bar(30,50,300,36,4,1,C.a,['200','200','200','200']);f4Br(30,330,44,'800 = 100 %',true,'#33475b');f4Br(30,105,90,'25 % = 200',false,C.a2);f4t(180,150,'25 % = chorak = 800 : 4 = 200',14,C.ok);f4msg('<b>200</b>')},
 html:"<p>800 ning 25 % i. 100 ga bo'lib ko'paytirmasdan — tezroq yo'li bormi? Tanlang:</p>",
 btns:f4pick(1,[["80","Bu 10 %. 25 % undan ko'p."],["200","To'g'ri! 25 % = chorak, 800 : 4 = 200."],["400","Bu 50 % — yarmi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p><b>Tez usullar:</b> 10 % — sonni 10 ga bo'ling; 50 % — yarmi; 25 % — choragi; 20 % — beshdan biri; 5 % — 10 % ning yarmi; 1 % — 100 ga bo'ling. Masalan, 800 ning 15 % i = 10 % + 5 % = 80 + 40 = 120.</p>",
 q:{t:"600 ning 15 % i nechaga teng?",opts:["90","60","15","900"],ok:0,why:"10 % = 60, 5 % = 30, 15 % = 90.",hint:"15 % = 10 % + 5 %.",full:"10 % = 600 : 10 = 60; 5 % — uning yarmi, 30. 15 % = 60 + 30 = 90. «60» — faqat 10 %."},
 tn:"Og'zaki hisob mashqi: 10 % dan boshlab 20 %, 30 %, 5 %, 15 % ni qurish. Bu usul hayotda eng ko'p ishlatiladi (chegirma, choy puli)."},
{h:"Chegirma",sum:"40 000 so'm, −20 %: chegirma 8 000, yangi narx 32 000 (yoki 80 % = 32 000).",a:"m05",
 start:function(){startPh(F11P5)},fin:function(){S.ph=2;F11P5[2]()},
 html:"<p>Kitob 40 000 so'm. Do'konda «−20 %» aksiyasi. Kitob endi necha so'm? Bosing:</p>",btns:[phaser(F11P5,'🏷 Hisoblash')],
 after:"<p>Ikki yo'l:</p><p>1) Chegirmani topib ayirish: 40 000 : 100 · 20 = 8 000; 40 000 − 8 000 = <b>32 000</b>.<br>2) Qolgan foizni topish: 100 % − 20 % = 80 %; 40 000 : 100 · 80 = <b>32 000</b>.</p><p>Tuzoq: savol «chegirma qancha?» emas, «endi necha so'm?» — ayirishni unutmang!</p>",
 q:{t:"Ko'ylak 60 000 so'm edi, 30 % chegirma e'lon qilindi. Ko'ylak endi necha so'm?",opts:["18 000 so'm","42 000 so'm","30 000 so'm","57 000 so'm"],ok:1,why:"Chegirma 18 000; 60 000 − 18 000 = 42 000.",hint:"Avval chegirmani toping, keyin narxdan ayiring.",full:"30 % = 60 000 : 100 · 30 = 18 000 so'm chegirma. Yangi narx: 60 000 − 18 000 = 42 000 so'm. «18 000» — chegirmaning o'zi, savol esa yangi narx haqida."},
 tn:"Do'kon reklamalarini olib keling: bolalar haqiqiy chegirmalarni hisoblasin. «Aksiya» so'zi matematikaga aylanadi."},
{h:"Foiziga ko'ra butunni topish",sum:"20 % = 12 o'quvchi → 1 % = 12 : 20 → 100 % = 60 o'quvchi. Qoida: qism : foiz · 100.",a:"m06",
 start:function(){startPh(F11P6)},fin:function(){S.ph=2;F11P6[2]()},
 html:"<p>Maktabning 20 % i — 12 o'quvchi — olimpiadada qatnashdi. Maktabda nechta o'quvchi bor? Teskari masala:</p>",btns:[phaser(F11P6)],
 after:"<p>Bu — «kasriga ko'ra sonni topish»: 20 % = 12. Demak 10 % = 6, 100 % = <b>60</b>. Yoki qoida bilan: 12 : 20 · 100 = 60.</p><p>Tekshirish: 60 ning 20 % i = 12 ✓. Butun doim qismdan katta chiqishi kerak.</p>",
 q:{t:"Sonning 25 % i 15 ga teng. Son nechaga teng?",opts:["60","40","375","3"],ok:0,why:"25 % — chorak; 15 · 4 = 60.",hint:"25 % — bu chorak. Butun — 4 ta chorak.",full:"25 % = 1/4. Chorak 15 bo'lsa, butun 15 · 4 = 60. Tekshirish: 60 : 100 · 25 = 15 ✓. «375» — 15 · 25, «3» — 15 ning 20 % i."},
 tn:"Ikki tur masalani chizma bilan ajrating: «butun ma'lum» va «qism ma'lum» — xuddi kasrlarda bo'lgani kabi."},
{h:"Tuzoq: foiz teng — son teng emas",sum:"40 bolaning 50 % i = 20, 20 bolaning 50 % i = 10. Foiz — nisbat, u butunga bog'liq.",a:"m07",
 start:function(){f11tuz(0);f4msg('Ikki sinfda ham qizlar 50 %. Qizlar soni tengmi?')},fin:function(){f11tuz(1);f4msg('50 % teng, lekin <b>20 ≠ 10</b>')},
 html:"<p>A sinfda 40 bola, B sinfda 20 bola. Ikkalasida ham qizlar <b>50 %</b>. Qizlar soni tengmi?</p>",
 btns:f4pick(1,[["Ha, teng — 50 % = 50 %","Foiz teng, lekin butunlar har xil! 40 ning yarmi va 20 ning yarmi."],["Yo'q, A da ko'p","To'g'ri! A: 40 ning 50 % i = 20, B: 20 ning 50 % i = 10."],["Yo'q, B da ko'p","B sinfda bolalar kam — demak yarmi ham kam."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Foiz — <b>butunga nisbatan</b> ulush. Butun katta bo'lsa, bir xil foiz ko'proq narsani bildiradi. «Kichik do'konda 50 % chegirma» va «katta do'konda 20 % chegirma» — qaysi biri ko'p so'm tejaydi? Narxga bog'liq!</p>",
 q:{t:"Ali pulining 10 % ini — 5 000 so'm, Vali pulining 20 % ini — 6 000 so'm sarfladi. Kimning puli ko'p edi?",opts:["Alining","Valining","Teng","Valining, chunki 20 % &gt; 10 %"],ok:0,why:"Ali: 50 000, Vali: 30 000.",hint:"Har birining 100 % ini toping.",full:"Ali: 10 % = 5 000 → 100 % = 50 000. Vali: 20 % = 6 000 → 10 % = 3 000 → 100 % = 30 000. Alining puli ko'p. Foiz katta bo'lgani bilan butun kichik bo'lishi mumkin."},
 tn:"Bu tushuncha gazetadagi «foiz» xabarlarini to'g'ri o'qishga o'rgatadi: foiz nimaning foizi ekanini doim so'rang."},
{h:"Foizlar yig'indisi 100 %",sum:"Sinfda 45 % o'g'il bola bo'lsa, qizlar 100 % − 45 % = 55 %. Qismlar yig'indisi — 100 %.",a:"m08",
 start:function(){clear();f4bar(30,50,300,40,20,9,C.b);f4Br(30,30+300*.45,94,'o‘g‘il bolalar 45 %',false,C.blue);f4Br(30,330,44,'sinf = 100 %',true,'#33475b');f4msg('Qizlar necha foiz?')},
 fin:function(){clear();f4barC(30,50,300,40,Array(20).fill(0).map(function(_,i){return i<9?C.b:C.c}));f4Br(30,30+300*.45,94,'45 %',false,C.blue);f4Br(30+300*.45,330,94,'55 %',false,'#c0396b');f4Br(30,330,44,'100 %',true,'#33475b');f4msg('Qizlar: 100 % − 45 % = <b>55 %</b>')},
 html:"<p>Sinfda o'g'il bolalar 45 %. Qizlar necha foiz? Tanlang:</p>",
 btns:f4pick(0,[["55 %","To'g'ri! Butun sinf — 100 %, 100 − 45 = 55."],["45 %","Unda sinf 90 % bo'lib qoladi. 10 % kim?"],["65 %","45 + 65 = 110 % — bu butundan ko'p, bo'lmaydi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Butunning barcha qismlari birgalikda <b>100 %</b>. Bir qism ma'lum bo'lsa, qolgani — 100 % dan ayirma. Bu diagrammalarni o'qishda ham kerak: doira — 100 %.</p>",
 q:{t:"Bog'da 30 % olma, 25 % nok, qolgani — o'rik daraxtlari. O'rik daraxtlari necha foiz?",opts:["45 %","55 %","35 %","5 %"],ok:0,why:"100 − 30 − 25 = 45.",hint:"Hamma daraxtlar — 100 %.",full:"Olma va nok: 30 + 25 = 55 %. O'rik: 100 − 55 = 45 %. «55 %» — olma va nokning yig'indisi, savol esa o'rik haqida."},
 tn:"Doira diagrammani 100 % deb chizing. Bolalar o'z sinfining «sevimli fan» so'rovini foizlarda ifodalasin."},
{h:"Bilasizmi? % belgisi qayerdan",sum:"«Foiz» — lotincha «pro centum» (yuzga). % belgisi italyan savdogarlarining «cento» so'zi qisqartmasidan paydo bo'lgan.",a:"m09",
 start:function(){clear('#f6ead0');f4t(180,50,'%',44,'#7a4a12');f4msg('Bu belgi qanday paydo bo‘lgan?')},
 fin:function(){clear('#f6ead0');f4t(70,60,'per cento',16,'#7a4a12');f4t(140,62,'→',16,'#7a4a12');f4t(190,60,'p c°',18,'#7a4a12');f4t(240,62,'→',16,'#7a4a12');f4t(290,60,'%',30,'#7a4a12');f4t(180,120,'Italiya savdogarlari, XV–XVII asrlar',12,'#5b6b7b');f4msg('«cento» so‘zi asta-sekin ikki nol va chiziqqa aylangan')},
 html:"<p>📜 Qadimgi Rimda soliqlar «yuzdan bir» hisobida olingan. «Foiz» so'zi lotincha <b>«pro centum»</b> — «yuzga nisbatan». Belgisi-chi? Bosing:</p>",
 btns:[["📜 Ko'rsatish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>O'rta asrlarda italyan savdogarlari «per cento» (yuzga) so'zini qisqartirib «p c°» deb yozgan. Yozuvda «cento» asta-sekin <b>ikki nol va qiya chiziq</b>ga aylandi — shunday qilib <b>%</b> belgisi paydo bo'ldi. O'zbek tilidagi «foiz» so'zi esa arabcha «ortiqcha, qo'shimcha» ma'nosidan kelgan.</p>",
 tn:"Bolalardan hayotda % belgisini qayerda ko'rganini so'rang: telefon quvvati, chegirma, imtihon natijasi, ob-havo (yog'ingarchilik ehtimoli)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>1 % = 1/100 = 0,01</b>. Butun = 100 %.</li><li>1/2 = 50 %, 1/4 = 25 %, 3/4 = 75 %, 1/10 = 10 %, 1/5 = 20 %.</li><li>Sonning foizi: <b>son : 100 · foiz</b>. 300 ning 30 % i = 90.</li><li>Tez: 10 % — 10 ga bo'l; 50 % — yarmi; 25 % — chorak; 5 % — 10 % ning yarmi.</li><li>Chegirma: narx − chegirma (yoki qolgan foizni top).</li><li>Foiziga ko'ra butun: <b>qism : foiz · 100</b>.</li><li>Foiz — nisbat: 40 ning 50 % i ≠ 20 ning 50 % i.</li><li>Qismlar yig'indisi 100 %.</li></ul></div>",
 tn:"Keyingi darslarda diagrammalarda foizlar uchraydi — doira 100 % ekanini eslating."}
];
var PROBS=[
{t:"1 % qaysi kasrga teng?",o:["1/100","1/10","1/1000","1/2"],k:0,s:"Foiz — yuzdan bir."},
{t:"50 % qaysi kasrga teng?",o:["1/2","1/5","5/100","1/50"],k:0,s:"50/100 = 1/2."},
{t:"200 ning 10 % i nechaga teng?",o:["20","2","10","2 000"],k:0,s:"200 : 10 = 20."},
{t:"400 ning 25 % i nechaga teng?",o:["100","25","40","1 600"],k:0,s:"400 : 4 = 100."},
{t:"1/5 necha foiz?",o:["20 %","15 %","5 %","50 %"],k:0,s:"1/5 = 20/100."},
{t:"Sinfda 30 o'quvchi bor, ularning 40 % i qizlar. Sinfda nechta o'g'il bola bor?",o:["18","12","40","60"],k:0,s:"Qizlar: 30 : 100 · 40 = 12; o'g'il bolalar: 30 − 12 = 18."},
{t:"700 ning 15 % i nechaga teng?",o:["105","70","35","15"],k:0,s:"10 % = 70, 5 % = 35, jami 105."},
{t:"Sumka 80 000 so'm, chegirma 25 %. Sumka endi necha so'm?",o:["60 000 so'm","20 000 so'm","55 000 so'm","75 000 so'm"],k:0,s:"Chegirma 20 000; 80 000 − 20 000 = 60 000."},
{t:"Sonning 10 % i 7 ga teng. Son nechaga teng?",o:["70","17","700","0,7"],k:0,s:"7 · 10 = 70."},
{t:"Sonning 50 % i 45 ga teng. Son nechaga teng?",o:["90","22","95","450"],k:0,s:"45 · 2 = 90."},
{t:"Bog'da 40 % olma, 35 % nok, qolgani gilos. Gilos necha foiz?",o:["25 %","75 %","35 %","5 %"],k:0,s:"100 − 40 − 35 = 25."},
{t:"Qaysi yozuv 0,07 ga teng?",o:["7 %","70 %","0,7 %","7/10"],k:0,s:"0,07 = 7/100 = 7 %."},
{t:"Telefon quvvati 100 % edi, 35 % sarflandi. Qancha quvvat qoldi?",o:["65 %","35 %","75 %","135 %"],k:0,s:"100 − 35 = 65."},
{t:"Ali 20 ta misoldan 15 tasini to'g'ri yechdi. Bu necha foiz?",o:["75 %","15 %","80 %","25 %"],k:0,s:"15/20 = 3/4 = 75 %."},
{t:"Narx 50 000 so'm edi, 10 % ga oshdi. Yangi narx?",o:["55 000 so'm","45 000 so'm","60 000 so'm","50 010 so'm"],k:0,s:"10 % = 5 000; 50 000 + 5 000 = 55 000."},
{t:"Sonning 25 % i 12 ga teng. Shu sonning 75 % i nechaga teng?",o:["36","48","3","60"],k:0,s:"75 % — 25 % ning 3 barobari: 12 · 3 = 36."},
{t:"Ikki do'konda bir xil kitob: birida 50 000 so'm, 20 % chegirma; ikkinchisida 45 000 so'm, 10 % chegirma. Qayerda arzon va qanchaga?",o:["1-do'konda, 500 so'mga","2-do'konda, 500 so'mga","1-do'konda, 5 000 so'mga","Narxlar teng"],k:0,s:"40 000 va 40 500."},
{t:"Maktabda 60 % o'quvchi — o'g'il bolalar, bu 240 kishi. Maktabda hammasi nechta o'quvchi bor?",o:["400","144","360","600"],k:0,s:"10 % = 40; 100 % = 400."},
{t:"Anvar pulining 30 % iga kitob oldi va unda 14 000 so'm qoldi. Anvarda qancha pul bor edi?",o:["20 000 so'm","18 200 so'm","4 200 so'm","42 000 so'm"],k:0,s:"Qoldi 70 % = 14 000 → 10 % = 2 000 → 20 000."},
{t:"Tarvuz 5 kg, uning 90 % i — suv. Tarvuzdagi suv necha gramm?",o:["4 500 g","450 g","500 g","4 000 g"],k:0,s:"5 000 : 100 · 90 = 4 500."}
];
var PREP_DATA={teach:["Foiz — yuzdan bir: 1 % = 1/100 = 0,01; butun = 100 %.","Tanish kasrlar foizda (50 %, 25 %, 75 %, 10 %, 20 %).","Sonning foizini topish: son : 100 · foiz; tez usullar (10 %, 50 %, 25 %).","Chegirma va oshish; foiziga ko'ra butunni topish.","Foiz — nisbat; qismlar yig'indisi 100 %."],
 mist:["Chegirma masalasida chegirmani topib to'xtaydi (yangi narxni hisoblamaydi).","Foizni songa aylantirmasdan ayiradi: 40 000 − 20.","3/4 = 34 % deb yozadi.","Bir xil foiz — bir xil son deb o'ylaydi.","Teskari masalada qismni 100 ga bo'ladi."],
 need:["100 katakli kvadratlar.","Do'kon reklamalari va cheklar (chegirmalar bilan)."],
 board:["<span class='w2'>1 % = 1/100 = 0,01; 100 % = 1</span>.","<span class='w2'>1/2 = 50 %, 1/4 = 25 %, 3/4 = 75 %, 1/10 = 10 %</span>.","<span class='w2'>300 ning 30 % i = 300 : 100 · 30 = 90</span>.","<span class='w2'>40 000, −20 %: 40 000 − 8 000 = 32 000</span>.","<span class='w2'>20 % = 12 → 100 % = 60</span>."]};
f4fix();
