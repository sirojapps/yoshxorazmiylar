var CODE='2H18',TITLE='2-sinf · Rost va yolg‘on mulohazalar';
// ---------- sahna: gap kartochkalari ----------
function h18Cards(list,o){o=o||{};clear();var g=S.g,n=list.length,h=Math.min(36,(150-(n-1)*6)/n);
 list.forEach(function(it,i){var y=12+i*(h+6),st=it.s;E('rect',{x:16,y:y,width:328,height:h,rx:9,fill:st===true?'#e6f6ee':(st===false?'#fdeaea':'#fff'),stroke:st===true?C.ok:(st===false?C.bad:'#c9d3dd'),'stroke-width':st==null?1.4:2.4},g);
  if(it.who)T(g,24,y+h/2+4,it.who,{'font-size':16,'text-anchor':'start'});
  T(g,it.who?48:26,y+h/2+4,it.t,{'font-size':12,'font-weight':700,'text-anchor':'start',fill:'#1d2b3a'});
  if(st!=null)T(g,334,y+h/2+5,st?'ROST':'YOLG‘ON',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:st?C.ok:C.bad})})}
function h18Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ---------- bosqichlar ----------
var Q1=[{t:'Qor oq rangda bo‘ladi.',a:true},{t:'Bir haftada 5 kun bor.',a:false},{t:'10 soni 7 dan katta.',a:true},{t:'Baliqlar daraxtda yashaydi.',a:false}];
var P2=[function(){h18Cards([{who:'👧',t:'Lola: «Bugun shanba EMAS».'}]);h18Msg('Bu gap <b>yolg‘on</b> ekan. Bugun qaysi kun?')},
 function(){h18Cards([{who:'👧',t:'«Bugun shanba emas» — yolg‘on',s:false},{t:'Demak, teskarisi rost: «Bugun shanba»',s:true}]);h18Msg('Yolg‘on gapning <b>teskarisi</b> — rost. Bugun — <b>shanba</b>')}];
var P3=[function(){h18Cards([{who:'👧',t:'Zarina: «Qalamim qizil YOKI ko‘k».'}]);h18Msg('Bu gap yolg‘on. Qalam qanday rangda?')},
 function(){h18Cards([{who:'👧',t:'«qizil yoki ko‘k» — yolg‘on',s:false},{t:'Qizil — bo‘lmaydi',s:false},{t:'Ko‘k — bo‘lmaydi',s:false}]);h18Msg('«Yoki» li gap yolg‘on bo‘lsa — <b>ikkalasi ham</b> noto‘g‘ri')},
 function(){h18Cards([{who:'👧',t:'«qizil yoki ko‘k» — yolg‘on',s:false},{t:'Qalam boshqa rangda: masalan, yashil',s:true}]);h18Msg('Javob: <b>yashil</b> (qizil ham, ko‘k ham emas)')}];
var P4=[function(){h18Cards([{who:'🧒',t:'Ali (har doim yolg‘on gapiradi):'},{t:'«Men 3-sinfda O‘QIMAYMAN».'}]);h18Msg('Ali 1–4-sinflardan birida o‘qiydi. Qaysi birida?')},
 function(){h18Cards([{who:'🧒',t:'«Men 3-sinfda o‘qimayman»',s:false},{t:'Teskarisi rost: «Men 3-sinfda o‘qiyman»',s:true}]);h18Msg('Yolg‘onchining gapini <b>teskari</b> qilamiz: Ali — <b>3-sinfda</b>')}];
function h18Try(k){var who=['Ali','Vali','Sardor'];if(k===0){h18Cards([{who:'🧒',t:'Ali: «Men yemadim».'},{who:'👦',t:'Vali: «Konfetni Ali yedi».'},{who:'🧑',t:'Sardor: «Men yemadim».'},{t:'Faqat BITTASI rost gapiryapti. Kim yedi?'}]);h18Msg('Har birini «yegan» deb faraz qilib tekshiramiz');return}
 var eat=who[k-1],r=[eat!=='Ali',eat==='Ali',eat!=='Sardor'],cnt=r.filter(Boolean).length;
 h18Cards([{who:'🧒',t:'Ali: «Men yemadim».',s:r[0]},{who:'👦',t:'Vali: «Konfetni Ali yedi».',s:r[1]},{who:'🧑',t:'Sardor: «Men yemadim».',s:r[2]},{t:'Faraz: '+eat+' yegan → rostlar: '+cnt+' ta '+(cnt===1?'✓':'✗'),s:cnt===1}]);
 h18Msg(cnt===1?'Faqat bittasi rost — mos keldi! Konfetni <b>'+eat+'</b> yegan':eat+' yegan bo‘lsa, '+cnt+' ta rost chiqadi — shartga zid')}
var STEPS=[
{h:"Rostmi, yolg'onmi?",sum:"Mulohaza — rost yoki yolg'on bo'ladigan gap. Uchinchisi yo'q.",a:"m01",
 start:function(){S.ans=[null,null,null,null];S.qi=0;h18Q1()},fin:function(){h18Cards(Q1.map(function(x){return {t:x.t,s:x.a}}));h18Msg('Har bir gap yo rost, yo yolg‘on')},
 html:"<p><b>Mulohaza</b> — rost yoki yolg'on deb aytish mumkin bo'lgan gap. Tepadagi gaplarni bittalab baholang:</p>",
 btns:[["✓ Rost",function(c,done){h18Ans(true,done)}],["✗ Yolg'on",function(c,done){h18Ans(false,done)},'u']],g2:1,
 after:"<p>Har bir mulohaza <b>yo rost, yo yolg'on</b> — o'rtasi yo'q. «Rostmi?» deb bo'lmaydigan gaplar (masalan, «Eshikni yoping!» yoki «Soat necha?») mulohaza emas.</p>",
 q:{t:"Qaysi gap mulohaza EMAS?",opts:["5 + 5 = 10","Daryo suvi shirin.","Kitobni olib kel!","Mushuk — hayvon."],ok:2,why:"Buyruqni rost yoki yolg'on deb bo'lmaydi.",hint:"Qaysi gapga «bu rost» yoki «bu yolg'on» deb javob berib bo'lmaydi?",full:"«5 + 5 = 10» — rost, «Daryo suvi shirin» — yolg'on, «Mushuk — hayvon» — rost. «Kitobni olib kel!» — buyruq, uni rost ham, yolg'on ham deb bo'lmaydi."},
 tn:"O'yin: siz gap aytasiz, bolalar «rost» bo'lsa qo'l ko'taradi, «yolg'on» bo'lsa o'tiradi."},
{h:"«Emas» — teskarisi",sum:"«Bugun shanba emas» yolg'on bo'lsa — bugun shanba. Yolg'on gapning teskarisi rost.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>Lola: «Bugun shanba <b>emas</b>», dedi. Lola <b>yolg'on</b> gapirdi. Bugun qaysi kun?</p>",
 btns:[phaser(P2)],
 after:"<p>Qoida: gap yolg'on bo'lsa — uning <b>teskarisi rost</b>. «Shanba emas» ning teskarisi — «shanba».</p>",
 q:{t:"Ali: «Mening mushugim oq emas», dedi. Bu yolg'on. Mushuk qanday?",opts:["qora","oq","kulrang","aytib bo'lmaydi, oq emas"],ok:1,why:"«Oq emas» yolg'on → teskarisi rost: mushuk oq.",hint:"Gapning teskarisini ayting: «oq emas» ning teskarisi nima?",full:"«Oq emas» — yolg'on. Demak teskarisi rost: «mushuk oq». Qora va kulrang — «oq emas» ga kiradi, ular bo'lishi mumkin emas."},
 tn:"«Emas» so'zini qo'shib-olib, gapning teskarisini yasashni mashq qiling."},
{h:"«Yoki» li gap yolg'on bo'lsa",sum:"«Qizil yoki ko'k» yolg'on → qizil ham, ko'k ham emas (masalan, yashil).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Zarina: «Mening qalamim qizil <b>yoki</b> ko'k», dedi. Bu gap <b>yolg'on</b>. Qalam qanday rangda bo'lishi mumkin?</p>",
 btns:[phaser(P3)],
 after:"<p>«A yoki B» — kamida bittasi to'g'ri bo'lsa rost. Yolg'on bo'lsa — <b>ikkalasi ham</b> noto'g'ri. Shuning uchun qalam na qizil, na ko'k.</p>",
 q:{t:"«Ali uyda yoki maktabda» degan gap yolg'on. Ali qayerda bo'lishi mumkin?",opts:["uyda","maktabda","bog'da","uyda yoki maktabda"],ok:2,why:"Uyda ham, maktabda ham emas — boshqa joyda.",hint:"«Yoki» li gap yolg'on bo'lsa, ikkala joy ham to'g'ri bo'ladimi?",full:"Gap yolg'on — demak Ali uyda ham emas, maktabda ham emas. Faqat boshqa joy bo'ladi: bog'da."},
 tn:"«Va» bilan ham solishtiring: «qizil va ko'k» yolg'on bo'lsa — kamida bittasi noto'g'ri."},
{h:"Har doim yolg'on gapiradigan",sum:"Yolg'onchi «3-sinfda o'qimayman» desa — u 3-sinfda o'qiydi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Ali <b>har doim yolg'on</b> gapiradi. U: «Men 3-sinfda o'qimayman», dedi. Ali 1–4-sinflardan birida o'qiydi. Qaysi sinfda?</p>",
 btns:[phaser(P4)],
 after:"<p>Yolg'onchining har bir gapini <b>teskari</b> qilib o'qiymiz. Rostgo'yning gapini esa — qanday bo'lsa, shunday.</p>",
 q:{t:"Vali har doim yolg'on gapiradi. U: «Mening ukam bor», dedi. To'g'risi qaysi?",opts:["Valining ukasi bor","Valining ukasi yo'q","Valining 2 ta ukasi bor","Valining opasi bor"],ok:1,why:"Yolg'on gapning teskarisi: ukasi yo'q.",hint:"Gapni teskari qiling.",full:"Vali yolg'onchi, demak «ukam bor» — yolg'on. Teskarisi: «ukam yo'q». Opasi bor-yo'qligini bu gap aytmaydi."},
 tn:"Rostgo'ylar va yolg'onchilar oroli jumboqlari — mantiqiy fikrlashning klassik mashqi."},
{h:"Tuzoq: «faqat bittasi rost»",sum:"Har bir boladan «yegan» deb faraz qilib, rostlar sonini sanaymiz: faqat Sardor varianti mos keladi.",a:"m05",
 start:function(){S.k5=0;h18Try(0)},fin:function(){h18Try(3)},
 html:"<p>Konfetni uch boladan bittasi yedi. <b>Ali</b>: «Men yemadim». <b>Vali</b>: «Konfetni Ali yedi». <b>Sardor</b>: «Men yemadim». Ulardan <b>faqat bittasi</b> rost gapiryapti. Kim yedi? Har birini faraz qilib tekshiramiz:</p>",
 btns:[["Faraz: Ali yegan",function(c,done){S.k5|=1;h18Try(1);if(S.k5===7)done()}],["Faraz: Vali yegan",function(c,done){S.k5|=2;h18Try(2);if(S.k5===7)done()}],["Faraz: Sardor yegan",function(c,done){S.k5|=4;h18Try(3);if(S.k5===7)done()}]],
 after:"<p>Usul: <b>har bir imkoniyatni faraz qilib</b>, shartni tekshiramiz. Ali yegan bo'lsa — 2 ta rost, Vali yegan bo'lsa — 2 ta rost, Sardor yegan bo'lsa — faqat 1 ta rost ✓. Javob: <b>Sardor</b>.</p>",
 q:{t:"Uch boladan biri vaza sindirdi. Anvar: «Bobur sindirdi». Bobur: «Men sindirmadim». Doston: «Men sindirmadim». Faqat bittasi rost gapirdi. Kim sindirgan?",opts:["Anvar","Bobur","Doston","Aytib bo'lmaydi"],ok:2,why:"Doston sindirgan bo'lsa, faqat Bobur rost gapirgan bo'ladi.",hint:"Har birini «sindirgan» deb faraz qiling va nechta rost chiqishini sanang.",full:"Anvar sindirgan bo'lsa: Bobur va Doston rost — 2 ta ✗. Bobur sindirgan bo'lsa: Anvar va Doston rost — 2 ta ✗. Doston sindirgan bo'lsa: faqat Bobur rost — 1 ta ✓. Javob: Doston."},
 tn:"Faraz qilish usuli (har bir holatni tekshirish) — olimpiada mantiqiy masalalarining asosiy usuli. Jadval chizib ishlang."},
{h:"Qaysi qutida tanga?",sum:"Faqat bitta yozuv rost bo'lsa — har bir qutini faraz qilib, rost yozuvlarni sanaymiz.",a:"m06",
 start:function(){S.k6=0;h18Box(0)},fin:function(){h18Box(4)},
 html:"<p>Uchta qutidan faqat bittasida tanga bor. Yozuvlar: <b>1-quti</b>: «Tanga shu yerda». <b>2-quti</b>: «Tanga shu yerda emas». <b>3-quti</b>: «Tanga 1-qutida emas». Yozuvlardan <b>faqat bittasi</b> rost. Tanga qayerda?</p>",
 btns:[["1-quti",function(c,done){S.k6|=1;h18Box(1);if(S.k6===7)done()}],["2-quti",function(c,done){S.k6|=2;h18Box(2);if(S.k6===7)done()}],["3-quti",function(c,done){S.k6|=4;h18Box(3);if(S.k6===7)done()}]],
 after:"<p>Tanga 1-qutida bo'lsa — 2 ta rost (1 va 2). 3-qutida bo'lsa — 2 ta rost (2 va 3). <b>2-qutida</b> bo'lsa — faqat 3-yozuv rost ✓. Javob: <b>2-quti</b>.</p>",
 q:{t:"Ikki qutidan birida olma bor. 1-quti: «Olma shu yerda». 2-quti: «Olma 1-qutida». Ikkala yozuv ham yolg'on. Olma qayerda?",opts:["1-qutida","2-qutida","ikkalasida","hech qaysisida"],ok:1,why:"1-qutidagi «shu yerda» yolg'on → olma 1-qutida emas → 2-qutida.",hint:"«Olma shu yerda» (1-quti) yolg'on bo'lsa, olma 1-qutidami?",full:"1-yozuv yolg'on → olma 1-qutida emas. 2-yozuv ham yolg'on → olma 1-qutida emas (mos). Demak olma 2-qutida."},
 tn:"Bankdagi 2231-masala shu turda (4 ta quti). Bolalar jadval to'ldirib yechsin: qator — faraz, ustun — yozuvlar."},
{h:"Bilasizmi? Mantiq fani",sum:"Mantiq fanining asoschisi — qadimgi yunon olimi Arastu (Aristotel). Kompyuterlar ham «rost/yolg'on» bilan ishlaydi.",a:"m07",
 start:function(){h18Cards([{t:'1 — rost',s:true},{t:'0 — yolg‘on',s:false}]);h18Msg('Kompyuter tili')},fin:function(){h18Cards([{t:'1 — rost',s:true},{t:'0 — yolg‘on',s:false}]);h18Msg('Kompyuter tili')},
 html:"<p>📜 Fikrni to'g'ri yuritish fani — <b>mantiq</b>. Uning asoschisi qadimgi yunon olimi <b>Arastu</b> (Aristotel) hisoblanadi. Sharqda <b>Forobiy</b> va <b>Ibn Sino</b> mantiq bo'yicha mashhur asarlar yozgan.</p><p>💻 Bugungi <b>kompyuterlar</b> ham faqat ikki narsani biladi: <b>1 — rost</b>, <b>0 — yolg'on</b>. Siz hozir o'rgangan «emas», «yoki», «va» — kompyuterning asosiy amallari!</p>",
 tn:"Bolalarga «kompyuter ham shunday o'ylaydi» deyish ularni juda qiziqtiradi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h18Cards(Q1.map(function(x){return {t:x.t,s:x.a}}));h18Msg('Rost yoki yolg‘on')},fin:function(){h18Cards(Q1.map(function(x){return {t:x.t,s:x.a}}));h18Msg('Rost yoki yolg‘on')},
 html:"<div class='memo'><ul><li><b>Mulohaza</b> — rost yoki yolg'on bo'ladigan gap (buyruq va savol — emas).</li><li>Gap yolg'on bo'lsa — <b>teskarisi rost</b>: «shanba emas» yolg'on → shanba.</li><li>«A <b>yoki</b> B» yolg'on → <b>ikkalasi ham</b> noto'g'ri.</li><li>Yolg'onchining gapini <b>teskari</b> o'qing.</li><li>«Faqat bittasi rost» → <b>har bir imkoniyatni faraz qilib</b>, rostlarni sanang.</li><li>Jadval chizing: qator — faraz, ustun — gaplar.</li></ul></div>",
 tn:"Keyingi darsni «Men har doim yolg'on gapiraman» degan gap haqida suhbat bilan boshlash mumkin (bu — mashhur paradoks)."}
];
function h18Q1(){var l=Q1.map(function(x,i){return {t:x.t,s:S.ans[i]}});h18Cards(l);h18Msg(S.qi<4?'«'+Q1[S.qi].t+'» — rostmi yoki yolg‘onmi?':'Hammasi baholandi ✓')}
function h18Ans(v,done){if(S.qi>=4)return;var ok=Q1[S.qi].a===v;if(!ok){h18Msg('Yana bir o‘ylang: «'+Q1[S.qi].t+'»');return}S.ans[S.qi]=v;S.qi++;h18Q1();if(S.qi===4)done()}
function h18Box(k){clear();var g=S.g,lab=['«Tanga shu yerda»','«Tanga shu yerda emas»','«Tanga 1-qutida emas»'];
 var tr=k>0?[k===1,k!==2,k!==1]:[null,null,null],cnt=tr.filter(function(x){return x===true}).length;
 for(var i=0;i<3;i++){var x=20+i*112;E('rect',{x:x,y:20,width:100,height:76,rx:10,fill:k===i+1?'#fff4d6':'#f6e7c8',stroke:'#a07d55','stroke-width':2},g);T(g,x+50,44,(i+1)+'-quti',{'font-size':12,'font-weight':800,fill:'#6b4a2a'});if(k===i+1)T(g,x+50,74,'🪙',{'font-size':22});
  var st=tr[i];E('rect',{x:x,y:104,width:100,height:40,rx:8,fill:st===true?'#e6f6ee':(st===false?'#fdeaea':'#fff'),stroke:st===true?C.ok:(st===false?C.bad:'#c9d3dd')},g);T(g,x+50,121,lab[i],{'font-size':8.5,'font-weight':700,fill:'#1d2b3a'});if(st!=null)T(g,x+50,137,st?'ROST':'YOLG‘ON',{'font-size':10,'font-weight':800,fill:st?C.ok:C.bad})}
 h18Msg(k===0?'Har bir qutini faraz qilib tekshiring':('Tanga '+k+'-qutida bo‘lsa: rostlar '+cnt+' ta '+(cnt===1?'✓ mos!':'✗')))}
var PROBS=[
{t:"Lola: «Bugun shanba emas», dedi. U yolg'on gapirdi. Bugun qaysi kun?",o:["shanba","yakshanba","dushanba","juma"],k:0,s:"Yolg'on gapning teskarisi: bugun shanba."},
{t:"Zarina: «Qalamim qizil yoki ko'k». Bu yolg'on. Qalam qanday rangda bo'lishi mumkin?",o:["yashil","qizil","ko'k","qizil yoki ko'k"],k:0,s:"Na qizil, na ko'k — masalan, yashil."},
{t:"Ali har doim yolg'on gapiradi. U: «Men 3-sinfda o'qimayman». Ali 1–4-sinflardan birida. Qaysi sinfda?",o:["3-sinfda","4-sinfda","2-sinfda","1-sinfda"],k:0,s:"Teskarisi: u 3-sinfda."},
{t:"Konfetni uch boladan biri yedi. Ali: «Men yemadim». Vali: «Ali yedi». Sardor: «Men yemadim». Faqat bittasi rost. Kim yedi?",o:["Sardor","Ali","Vali","Ali yoki Vali"],k:0,s:"Sardor yegan bo'lsa, faqat Ali rost."},
{t:"Qaysi gap mulohaza EMAS?",o:["Eshikni yoping!","Qor oq.","3 > 5","Quyosh — yulduz."],k:0,s:"Buyruqni rost-yolg'on deb bo'lmaydi."},
{t:"Qaysi mulohaza rost?",o:["Bir haftada 7 kun bor.","Bir yilda 10 oy bor.","5 + 4 = 10","Mushuk qushdir."],k:0,s:"Haftada 7 kun — rost."},
{t:"Qaysi mulohaza yolg'on?",o:["20 soni toq.","20 soni juft.","20 > 19","20 = 10 + 10"],k:0,s:"20 juft, shuning uchun «toq» — yolg'on."},
{t:"Vali har doim yolg'on gapiradi. U: «Mening ukam bor». To'g'risi?",o:["Valining ukasi yo'q","Valining ukasi bor","Valining 2 ta ukasi bor","Valining opasi bor"],k:0,s:"Teskarisi: ukasi yo'q."},
{t:"«Ali uyda yoki maktabda» — yolg'on. Ali qayerda bo'lishi mumkin?",o:["bog'da","uyda","maktabda","uyda yoki maktabda"],k:0,s:"Na uyda, na maktabda."},
{t:"Uchta qutidan birida tanga. 1-quti: «Tanga shu yerda». 2-quti: «Tanga shu yerda emas». 3-quti: «Tanga 1-qutida emas». Faqat bittasi rost. Tanga qayerda?",o:["2-qutida","1-qutida","3-qutida","hech qaysisida"],k:0,s:"2-qutida bo'lsa, faqat 3-yozuv rost."},
{t:"Ikki qutidan birida olma. 1-quti: «Olma shu yerda». 2-quti: «Olma 1-qutida». Ikkalasi ham yolg'on. Olma qayerda?",o:["2-qutida","1-qutida","ikkalasida","hech qaysisida"],k:0,s:"1-qutida emas — demak 2-qutida."},
{t:"Anvar har doim rost gapiradi. U: «Bugun yomg'ir yog'madi». To'g'risi?",o:["Bugun yomg'ir yog'madi","Bugun yomg'ir yog'di","Ertaga yomg'ir yog'adi","Aytib bo'lmaydi"],k:0,s:"Rostgo'yning gapi — o'zi rost."},
{t:"«Barcha mushuklar qora» degan gap yolg'on. Unda nima aniq?",o:["Qora bo'lmagan mushuk bor","Hech bir mushuk qora emas","Barcha mushuklar oq","Mushuklar yo'q"],k:0,s:"Kamida bitta qora bo'lmagan mushuk bor."},
{t:"Lola: «Men 8 yoshdaman». Gap yolg'on. Lola necha yoshda bo'lishi mumkin?",o:["9 yoshda","8 yoshda","faqat 7 yoshda","8 yoki 9 yoshda"],k:0,s:"8 dan boshqa istalgan yosh, masalan 9."},
{t:"Qaysi gap «3 soni 5 dan kichik» gapining teskarisi?",o:["3 soni 5 dan kichik emas","3 soni 5 ga teng","5 soni 3 dan kichik","3 soni 5 dan katta emas"],k:0,s:"Teskarisi — «emas» qo'shilgani."},
{t:"Rostgo'y Bobur: «Men olma yoki nok yedim». Bobur olma yemagan. U nima yegan?",o:["nok","olma","hech narsa","olma va nok"],k:0,s:"Kamida bittasi to'g'ri, olma emas — demak nok."},
{t:"Har doim yolg'on gapiradigan Toshmat: «Men futbol ham, shaxmat ham o'ynamayman». To'g'risi?",o:["U futbol yoki shaxmat o'ynaydi","U hech narsa o'ynamaydi","U faqat futbol o'ynaydi","U faqat shaxmat o'ynaydi"],k:0,s:"Teskarisi: kamida bittasini o'ynaydi."},
{t:"Ikki bola: biri har doim rost, biri har doim yolg'on gapiradi. Ali: «Vali yolg'onchi». Vali: «Biz ikkalamiz rostgo'ymiz». Kim yolg'onchi?",o:["Vali","Ali","Ikkalasi","Hech kim"],k:0,s:"Valining gapi yolg'on (ikkalasi rostgo'y bo'lishi mumkin emas) — Vali yolg'onchi, Ali rostgo'y."},
{t:"«Bugun dushanba yoki seshanba» — rost. «Bugun dushanba emas» — rost. Bugun qaysi kun?",o:["seshanba","dushanba","chorshanba","yakshanba"],k:0,s:"Dushanba emas, lekin ikkalasidan biri — seshanba."},
{t:"4 ta gap: «2 + 2 = 4», «Qor issiq», «Haftada 7 kun», «1 > 2». Nechtasi rost?",o:["2","1","3","4"],k:0,s:"Rost: 2 + 2 = 4 va haftada 7 kun — 2 ta."}
];
function PRACT_STAGE(){h18Cards(Q1.map(function(x){return {t:x.t,s:x.a}}));h18Msg('Har bir imkoniyatni tekshiring')}
var PREP_DATA={teach:["Mulohaza: rost yoki yolg'on bo'ladigan gap.","«Emas» — teskarisi; «yoki» li gapning yolg'onligi.","Har doim yolg'on gapiradigan odamning gapi.","«Faqat bittasi rost» — faraz qilib tekshirish; qutilar jumbog'i."],
 mist:["Yolg'on gapning teskarisini emas, boshqa narsani topadi.","«Yoki» li gap yolg'on bo'lsa, ulardan biri bo'lishi mumkin deb o'ylaydi.","Faraz qilishda bitta variantni tekshirib to'xtaydi.","Buyruq va savolni ham mulohaza deb hisoblaydi."],
 need:["«ROST» / «YOLG'ON» kartochkalari.","3 ta quti va tanga (qutilar o'yini)."],
 board:["<span class='w2'>«shanba emas» — yolg'on → shanba</span>.","<span class='w2'>«qizil yoki ko'k» — yolg'on → na qizil, na ko'k</span>.","Jadval: <span class='w2'>faraz | Ali | Vali | Sardor | rostlar soni</span>.","Qutilar: <span class='w2'>tanga 1 → 2 rost ✗, 2 → 1 rost ✓, 3 → 2 rost ✗</span>."]};
