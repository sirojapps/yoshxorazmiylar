var CODE='2D5',TITLE='2-sinf · «…marta ko‘p / …marta kam» masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function bm5u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"«2 marta ko'p» — nusxalar",sum:"Lola 7 ta; Zulfiya 2 marta ko'p — Lolaning chizig'i 2 marta: 7 · 2 = 14.",a:"m01",
 frames:[{t:'Lola 7 ta so‘z topdi. Zulfiya 2 MARTA ko‘p topdi.',bars:[{lab:'Lola',y:46,segs:[{w:7,txt:'7',c:'a'}]},{lab:'Zulfiya',y:106,segs:[{w:14,txt:'?',c:'q'}]}],note:'«2 marta ko‘p» — Lolaning chizig‘i 2 marta takrorlanadi'},
  {t:'Lola 7 ta so‘z topdi. Zulfiya 2 MARTA ko‘p topdi.',bars:[{lab:'Lola',y:46,segs:[{w:7,txt:'7',c:'a'}]},{lab:'Zulfiya',y:106,segs:bm5u(2,'7','g',7)}],calc:['Zulfiya = Lolaning 2 ta nusxasi','7 · 2 = <b>14</b> ta so‘z']}],
 html:"<p>«<b>Marta</b> ko'p» — bu «shuncha ta ko'p» emas! Bu — kichik chiziqni <b>bir necha marta takrorlash</b>. Kuzating.</p>",
 after:"<p>«2 marta ko'p» — kichik son 2 marta takrorlanadi → <b>ko'paytiramiz</b>: 7 · 2 = 14.</p>",
 q:{t:"Bir qutida 5 ta qalam, ikkinchisida 3 marta ko'p. Ikkinchi qutida nechta qalam?",opts:["8","15","2","53"],ok:1,why:"5 · 3 = 15.",hint:"«3 marta ko'p» — 5 ni necha marta takrorlaymiz?",full:"3 marta ko'p — birinchi qutining 3 ta nusxasi: 5 + 5 + 5 = 15 yoki 5 · 3 = 15. «8» — «3 ta ko'p» deb qo'shib yuborish xatosi."},
 tn:"Kartondan bir xil tasmalar kesing: «3 marta ko'p» — 3 ta tasma yonma-yon."}),
bmStep({h:"«3 marta kam» — teng bo'laklar",sum:"18 yuk kemasi; yo'lovchi kemasi 3 marta kam — 18 ni 3 teng bo'lakka: 18 : 3 = 6.",a:"m02",
 frames:[{t:'18 ta yuk kemasi. Yo‘lovchi kemalari 3 MARTA kam.',bars:[{lab:'yuk',y:60,segs:bm5u(3,'?','b',6)},{lab:'yo‘lovchi',y:118,segs:[{w:6,txt:'?',c:'q'}]}],br:[{b:0,lab:'18',up:true}],note:'Katta chiziq 3 ta teng bo‘lakka bo‘linadi, kichigi — bittasi'},
  {t:'18 ta yuk kemasi. Yo‘lovchi kemalari 3 MARTA kam.',bars:[{lab:'yuk',y:60,segs:bm5u(3,'6','b',6)},{lab:'yo‘lovchi',y:118,segs:[{w:6,txt:'6',c:'g'}]}],br:[{b:0,lab:'18',up:true}],calc:['Kichik = kattaning bitta bo‘lagi','18 : 3 = <b>6</b> ta kema']}],
 html:"<p>«3 marta kam» — katta son 3 ta teng bo'lakka bo'linadi, kichik son — shundan <b>bittasi</b>. Kuzating.</p>",
 after:"<p>«… marta kam» → <b>bo'lamiz</b>: 18 : 3 = 6. Tekshirish: 6 · 3 = 18 ✓</p>",
 q:{t:"Katta avtobusga 40 kishi sig'adi, kichigiga 2 marta kam. Kichik avtobusga nechta kishi sig'adi?",opts:["38","20","80","42"],ok:1,why:"40 : 2 = 20.",hint:"«2 marta kam» — 40 ni nechta teng bo'lakka bo'lamiz?",full:"40 ni 2 ta teng bo'lakka bo'lamiz: 40 : 2 = 20. «38» — «2 ta kam» deb ayirish xatosi."},
 tn:"«Marta kam» ni «teng bo'lishish» bilan bog'lang: katta narsa necha bo'lakka bo'linadi?"}),
bmStep({h:"«ta» va «marta» — farqi katta!",sum:"6 dan 4 ta ko'p = 10; 6 dan 4 marta ko'p = 24.",a:"m03",
 frames:[{t:'Alida 6 ta. Valida 4 TA ko‘p, Sardorda 4 MARTA ko‘p.',bars:[{lab:'Ali',y:34,segs:[{w:6,txt:'6',c:'a'}]},{lab:'Vali',y:82,segs:[{w:6,txt:'6',c:'a'},{w:4,txt:'+4',c:'c'}]},{lab:'Sardor',y:130,segs:bm5u(4,'6','g',6)}],calc:['Vali: 6 + 4 = 10 · Sardor: 6 · 4 = 24']}],
 html:"<p>Bitta so'z — butunlay boshqa javob. Chizmalarni solishtiring va Sardornikini toping:</p>",
 btns:bmPick(["10","24","2"],1,null,["10 — bu Valiniki («4 ta ko‘p»).","","2 — ayirma, bu yerda kerak emas."]),
 after:"<p><b>«… ta ko'p»</b> — bir bo'lak qo'shiladi (qo'shish). <b>«… marta ko'p»</b> — chiziq takrorlanadi (ko'paytirish). Shunga o'xshash: «… ta kam» — ayirish, «… marta kam» — bo'lish.</p>",
 q:{t:"Ukamda 3 ta mashina. Menda 3 marta ko'p. Menda nechta?",opts:["6","9","1","33"],ok:1,why:"3 · 3 = 9.",hint:"«Marta» — takrorlash. 3 ni 3 marta takrorlang.",full:"3 marta ko'p: 3 + 3 + 3 = 9. «6» — «3 ta ko'p» deb qo'shish xatosi."},
 tn:"To'rtta qoidani doskaga jadval qilib yozing: ta ko'p (+), ta kam (−), marta ko'p (·), marta kam (:)."}),
bmStep({h:"Jami bilan: ikki amal",sum:"Yuk 18, yo'lovchi 18 : 3 = 6, jami 18 + 6 = 24.",a:"m04",
 frames:[{t:'18 yuk kemasi, yo‘lovchi kemalari 3 marta kam. JAMI nechta kema?',bars:[{lab:'yuk',y:46,segs:bm5u(3,'6','b',6)},{lab:'yo‘lovchi',y:106,segs:[{w:6,txt:'6',c:'g'}]}],calc:['1) Yo‘lovchi: 18 : 3 = 6']},
  {t:'18 yuk kemasi, yo‘lovchi kemalari 3 marta kam. JAMI nechta kema?',bars:[{lab:'jami',y:76,segs:bm5u(3,'6','b',6).concat([{w:6,txt:'6',c:'g'}])}],br:[{b:0,lab:'24',up:false,col:C.ok}],calc:['1) 18 : 3 = 6','2) Jami: 18 + 6 = <b>24</b> ta kema']}],
 html:"<p>Savol <b>jami</b>ni so'rasa — yana bitta qadam kerak. Kuzating.</p>",
 after:"<p>Chizmada 4 ta teng bo'lak chiqdi: 3 tasi yuk, 1 tasi yo'lovchi kemasi. 4 · 6 = 24 — ikkinchi yo'l!</p>",
 q:{t:"Ustaxonada 48 ta piyola va undan 6 marta kam choynak bor. Piyola va choynak jami nechta?",opts:["8","56","42","54"],ok:1,why:"48 : 6 = 8 choynak, jami 48 + 8 = 56.",hint:"Avval choynaklarni toping, keyin jamini.",full:"1) Choynak: 48 : 6 = 8. 2) Jami: 48 + 8 = 56. «8» — faqat choynaklar."},
 tn:"Bolalar chizmadagi teng bo'laklarni sanab, ikkinchi yo'lni o'zi topsin."}),
bmStep({h:"Necha marta ko'p? — bo'lamiz",sum:"14 so'z 7 so'zdan necha marta ko'p? 14 : 7 = 2.",a:"m05",
 frames:[{t:'Lola 7 so‘z, Zulfiya Loladan 7 TA ko‘p o‘yladi. Zulfiya NECHA MARTA ko‘p?',bars:[{lab:'Lola',y:46,segs:[{w:7,txt:'7',c:'a'}]},{lab:'Zulfiya',y:106,segs:[{w:7,txt:'7',c:'g'},{w:7,txt:'+7',c:'c'}]}],calc:['Zulfiya: 7 + 7 = 14']},
  {t:'Lola 7 so‘z, Zulfiya Loladan 7 TA ko‘p o‘yladi. Zulfiya NECHA MARTA ko‘p?',bars:[{lab:'Lola',y:46,segs:[{w:7,txt:'7',c:'a'}]},{lab:'Zulfiya',y:106,segs:bm5u(2,'7','g',7)}],calc:['Zulfiya: 7 + 7 = 14','14 da nechta 7 bor? 14 : 7 = <b>2 marta</b>']}],
 html:"<p>Bankdagi ayyor savol: «7 ta ko'p» deyilgan, lekin savol «necha <b>marta</b> ko'p?» Kuzating.</p>",
 after:"<p>«Necha marta ko'p/kam?» → katta sonni kichik songa <b>bo'lamiz</b>. «7 marta» deb javob berish — eng ko'p xato!</p>",
 q:{t:"Akamda 24 ta, menda 8 ta marka. Akamda necha marta ko'p?",opts:["16","3","32","4"],ok:1,why:"24 : 8 = 3.",hint:"«Necha marta?» — 24 da nechta 8 bor?",full:"24 : 8 = 3 marta. «16» — bu «nechta ko'p?» savoliga javob (farq), «necha marta?» emas."},
 tn:"«Nechta ko'p?» va «necha marta ko'p?» savollarini juft qilib bering — bolalar farqni sezsin."}),
bmStep({h:"Zanjir: kesmalar",sum:"AB = 8; CD 2 marta kichik (4); MN CD dan 3 marta katta (12).",a:"m06",
 frames:[{t:'AB = 8 sm. CD AB dan 2 marta kichik. MN CD dan 3 marta katta.',bars:[{lab:'AB',y:34,segs:bm5u(2,'4','b',4)},{lab:'CD',y:82,segs:[{w:4,txt:'4',c:'a'}]},{lab:'MN',y:130,segs:[{w:12,txt:'?',c:'q'}]}],calc:['1) CD: 8 : 2 = 4 sm']},
  {t:'AB = 8 sm. CD AB dan 2 marta kichik. MN CD dan 3 marta katta.',bars:[{lab:'AB',y:34,segs:bm5u(2,'4','b',4)},{lab:'CD',y:82,segs:[{w:4,txt:'4',c:'a'}]},{lab:'MN',y:130,segs:bm5u(3,'4','g',4)}],calc:['1) CD: 8 : 2 = 4 sm','2) MN: 4 · 3 = <b>12</b> sm']}],
 html:"<p>MN qaysi kesma bilan taqqoslanyapti? Diqqat bilan o'qing va kuzating.</p>",
 after:"<p>MN — <b>CD</b> bilan taqqoslangan, AB bilan emas. Xato yo'l: 8 · 3 = 24.</p>",
 q:{t:"Ali 6 ta olma terdi. Vali Alidan 2 marta ko'p, Sardor Validan 3 marta kam terdi. Sardor nechta olma tergan?",opts:["36","4","2","18"],ok:1,why:"Vali 12, Sardor 12 : 3 = 4.",hint:"Avval Valinikini toping. Sardor kim bilan taqqoslangan?",full:"Vali: 6 · 2 = 12. Sardor Validan 3 marta kam: 12 : 3 = 4."},
 tn:"Kesmalarni daftarga chizg'ich bilan chizdiring — haqiqiy uzunlikda."}),
bmStep({h:"Tuzoq: «3 marta uzun» — 4 bo'lak",sum:"AB = 36; AC CB dan 3 marta uzun → AB = 4 bo'lak; CB = 36 : 4 = 9.",a:"m07",
 frames:[{t:'AB = 36 sm. C nuqta uni bo‘ldi: AC CB dan 3 marta uzun.',bars:[{y:70,segs:bm5u(3,'','a',9).concat([{w:9,txt:'CB',c:'g'}])}],br:[{b:0,from:0,to:2,lab:'AC',up:true},{b:0,lab:'36 sm',up:false}],note:'Nechta teng bo‘lak chiqdi?'},
  {t:'AB = 36 sm. C nuqta uni bo‘ldi: AC CB dan 3 marta uzun.',bars:[{y:70,segs:bm5u(3,'9','a',9).concat([{w:9,txt:'9',c:'g'}])}],br:[{b:0,from:0,to:2,lab:'AC = 27',up:true},{b:0,lab:'36 sm',up:false}],calc:['AC — 3 bo‘lak, CB — 1 bo‘lak: jami 4 bo‘lak','36 : 4 = <b>9</b> sm — CB; AC = 27 sm']}],
 html:"<p>Eng qiyin turi (bankdan). Ko'pchilik 36 : 3 = 12 deydi. Chizma boshqa narsani ko'rsatadi — kuzating.</p>",
 after:"<p>«AC CB dan 3 marta uzun» — CB bitta bo'lak, AC uchta bo'lak. Butun AB — <b>4 ta</b> bo'lak! Xato javob 12 — bo'laklarni noto'g'ri sanash.</p>",
 q:{t:"Ip 30 sm. U ikkiga kesildi: biri ikkinchisidan 2 marta uzun. Qisqa bo'lak necha sm?",opts:["15","10","20","28"],ok:1,why:"Uzun — 2 bo'lak, qisqa — 1 bo'lak, jami 3 bo'lak: 30 : 3 = 10.",hint:"Chizing: qisqa bo'lak — 1 ta, uzuni — 2 ta. Jami nechta teng bo'lak?",full:"Jami 3 ta teng bo'lak: 30 : 3 = 10 sm (qisqa), uzuni 20 sm. «15» — 30 ni 2 ga bo'lish xatosi."},
 tn:"Bu — Singapur chizma modelining eng kuchli tomoni: bolalar «bo'laklar soni» orqali tenglamasiz yechadi."}),
bmStep({h:"Bilasizmi? Shaxmat afsonasi",sum:"Har katakka oldingisidan 2 marta ko'p bug'doy — 64-katakda son aql bovar qilmas darajada katta.",a:"m08",
 frames:[{t:'Har katakda oldingisidan 2 marta ko‘p',bars:[{y:40,segs:[{w:1,txt:'1',c:'y'},{w:2,txt:'2',c:'y'},{w:4,txt:'4',c:'y'},{w:8,txt:'8',c:'y'},{w:16,txt:'16',c:'y'}]}],txt:[[180,120,'… 64-katakda — 9 223 372 036 854 775 808 ta!',{'font-size':11,fill:C.bad}]],note:'«2 marta ko‘p» juda tez o‘sadi'}],
 html:"<p>♟ Afsonaga ko'ra, shaxmatni o'ylab topgan donishmand podshohdan mukofot so'radi: shaxmat taxtasining 1-katagiga 1 dona bug'doy, 2-siga 2 ta, 3-siga 4 ta — har biriga oldingisidan <b>2 marta ko'p</b>.</p><p>Podsho kulib rozi bo'ldi… lekin 64-katakka kelib, butun dunyo bug'doyi ham yetmasligi ma'lum bo'ldi!</p>",
 tn:"Bolalar bilan birga 1, 2, 4, 8, 16, 32, 64, 128… ni davom ettiring — «marta» qanchalik kuchli ekanini his qilsin."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'«Marta» — takrorlash',bars:[{lab:'kichik',y:46,segs:[{w:7,txt:'7',c:'a'}]},{lab:'katta',y:106,segs:bm5u(3,'7','g',7)}]}],
 html:"<div class='memo'><ul><li>«… <b>marta ko'p</b>» → kichik chiziq takrorlanadi → <b>ko'paytiramiz</b>: 7 · 2 = 14.</li><li>«… <b>marta kam</b>» → katta chiziq teng bo'linadi → <b>bo'lamiz</b>: 18 : 3 = 6.</li><li>«<b>Necha marta</b> ko'p?» → <b>bo'lamiz</b>: 14 : 7 = 2.</li><li>«… <b>ta</b> ko'p/kam» bilan adashtirmang: 6 + 4 = 10, lekin 6 · 4 = 24.</li><li>Zanjirda: kim <b>kim bilan</b> taqqoslangan?</li><li>«AC CB dan 3 marta uzun» → jami <b>4</b> bo'lak!</li></ul></div>",
 tn:"Keyingi darsni «Ip 40 sm, biri ikkinchisidan 3 marta uzun. Bo'laklar necha sm?» (10 va 30) savoli bilan boshlang."})
];
var PROBS=[
{t:"Lola 7 ta so'z topdi, Zulfiya 2 marta ko'p. Zulfiya nechta so'z topdi?",o:["14","9","5","72"],k:0,s:"7 · 2 = 14."},
{t:"Katta avtobusga 40 kishi, kichigiga 2 marta kam sig'adi. Kattasiga kichigidan nechta ko'p kishi sig'adi?",o:["20","2","38","60"],k:0,s:"Kichigi 40 : 2 = 20, farq 40 − 20 = 20."},
{t:"Bandargohda 18 ta yuk kemasi, yo'lovchi kemalari 3 marta kam. Jami nechta kema?",o:["24","21","6","72"],k:0,s:"18 : 3 = 6, 18 + 6 = 24."},
{t:"AB kesma 36 sm. C nuqta uni ikkiga bo'ldi: AC CB dan 3 marta uzun. CB necha sm?",o:["9","12","27","18"],k:0,s:"Jami 4 bo'lak: 36 : 4 = 9."},
{t:"AB = 8 sm. CD AB dan 2 marta kichik, MN CD dan 3 marta katta. MN necha sm?",o:["12","24","16","32"],k:0,s:"CD = 4, MN = 4 · 3 = 12."},
{t:"Lola 7 so'z, Zulfiya Loladan 7 ta ko'p so'z o'yladi. Zulfiya Loladan necha marta ko'p o'ylagan?",o:["2 marta","7 marta","14 marta","1 marta"],k:0,s:"Zulfiya 14, 14 : 7 = 2 marta."},
{t:"Bir qutida 5 ta qalam, ikkinchisida 3 marta ko'p. Ikkinchi qutida nechta?",o:["15","8","2","53"],k:0,s:"5 · 3 = 15."},
{t:"Akamda 24 ta, menda 8 ta marka. Akamda necha marta ko'p?",o:["3","16","32","4"],k:0,s:"24 : 8 = 3."},
{t:"Alida 6 ta. Valida 4 marta ko'p. Valida nechta?",o:["24","10","2","64"],k:0,s:"6 · 4 = 24."},
{t:"Ustaxonada 48 ta piyola, undan 6 marta kam choynak bor. Jami nechta buyum?",o:["56","8","42","54"],k:0,s:"48 : 6 = 8, 48 + 8 = 56."},
{t:"Ip 30 sm. U ikkiga kesildi: biri ikkinchisidan 2 marta uzun. Qisqa bo'lak necha sm?",o:["10","15","20","28"],k:0,s:"3 bo'lak: 30 : 3 = 10."},
{t:"Ali 6 olma, Vali 2 marta ko'p, Sardor Validan 3 marta kam terdi. Sardor nechta tergan?",o:["4","36","2","18"],k:0,s:"Vali 12, Sardor 12 : 3 = 4."},
{t:"Otam 36 yoshda, men 4 marta kichikman. Men necha yoshdaman?",o:["9","32","40","144"],k:0,s:"36 : 4 = 9."},
{t:"Sinfda 5 ta qiz, o'g'il bolalar 3 marta ko'p. Sinfda jami nechta o'quvchi?",o:["20","15","8","10"],k:0,s:"O'g'illar 15, jami 5 + 15 = 20."},
{t:"Do'konda 40 ta olma, nok 5 marta kam. Olma nokdan nechta ko'p?",o:["32","8","35","200"],k:0,s:"Nok 40 : 5 = 8, farq 40 − 8 = 32."},
{t:"Ip 40 sm. U ikkiga kesildi: biri ikkinchisidan 3 marta uzun. Uzun bo'lak necha sm?",o:["30","10","20","13"],k:0,s:"4 bo'lak: 40 : 4 = 10 — qisqa, uzuni 10 · 3 = 30."},
{t:"Ukam 3 yoshda, men 3 marta kattaman. Men ukamdan necha yosh kattaman?",o:["6","9","3","12"],k:0,s:"Men 9 yoshda, farq 9 − 3 = 6."},
{t:"Ikki savatda jami 24 ta olma. Birinchisida ikkinchisidan 2 marta ko'p. Birinchida nechta?",o:["16","12","8","22"],k:0,s:"3 bo'lak: 24 : 3 = 8 (ikkinchi), birinchisi 8 · 2 = 16."},
{t:"Qalam 2 ming so'm, daftar undan 3 marta qimmat. Qalam va daftar birga qancha?",o:["8 ming so'm","6 ming so'm","5 ming so'm","9 ming so'm"],k:0,s:"Daftar 6 ming, jami 2 + 6 = 8 ming so'm."},
{t:"Ustaxonada 48 piyola, undan 6 marta kam choynak va bir nechta lagan bor. Jami 75 ta buyum. Nechta lagan?",o:["19","21","27","67"],k:0,s:"Choynak 8, 48 + 8 = 56, lagan 75 − 56 = 19."}
];
function PRACT_STAGE(){bmDraw({t:'«Marta» — takrorlash yoki teng bo‘lish',bars:[{lab:'kichik',y:46,segs:[{w:7,txt:'',c:'a'}]},{lab:'katta',y:106,segs:bm5u(3,'','g',7)}],note:'marta ko‘p → · · marta kam → : · necha marta → :'})}
var PREP_DATA={teach:["«Marta ko'p» — nusxalar (ko'paytirish), «marta kam» — teng bo'laklar (bo'lish).","«Ta» va «marta» farqi.","«Necha marta ko'p?» — bo'lish.","Tuzoqlar: zanjir, «AC CB dan 3 marta uzun» — 4 bo'lak."],
 mist:["«Marta» va «ta» ni adashtiradi (6 + 4 o'rniga 6 · 4).","«Necha marta?» savoliga farq bilan javob beradi.","Kesma masalasida bo'laklarni 3 deb sanaydi (36 : 3).","Zanjirda noto'g'ri kesma bilan taqqoslaydi."],
 need:["Bir xil uzunlikdagi karton tasmalar.","Chizg'ich."],
 board:["Jadval: <span class='w2'>ta ko'p +</span> · <span class='w2'>ta kam −</span> · <span class='w2'>marta ko'p ·</span> · <span class='w2'>marta kam :</span>.","<span class='w2'>[7] / [7|7] → 14</span>.","<span class='w2'>[6|6|6] = 18 → 6</span>.","Kesma: <span class='w2'>[9|9|9|9] = 36</span>."]};
