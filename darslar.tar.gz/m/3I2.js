var CODE='3I2',TITLE='3-sinf · Narxlar jadvali va xarid ro‘yxati';
function i2msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function i2f(n){return (''+n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// jadval: rows [[nom,narx,miqdor?]], o.cols, o.hl
function i2tab(rows,o){o=o||{};clear();var g=S.g,x0=17,w=[100,76,60,90],y0=14,h=24,heads=o.heads||['Mahsulot','Narxi','Soni','Qiymati'],nc=o.nc||4,X=[x0];for(var k=0;k<nc;k++)X.push(X[k]+w[k]);
 E('rect',{x:x0,y:y0,width:X[nc]-x0,height:h,fill:'#dbe9f6'},g);heads.slice(0,nc).forEach(function(t,k){T(g,(X[k]+X[k+1])/2,y0+16,t,{'font-size':11,'font-weight':800})});
 rows.forEach(function(r,i){var y=y0+h*(i+1);E('rect',{x:x0,y:y,width:X[nc]-x0,height:h,fill:o.hl===i?'#fff3c4':'#fff',stroke:'#e3e8ee'},g);
  var cells=[r[0],i2f(r[1]),r[2]!=null?''+r[2]:'',r[2]!=null&&o.val?i2f(r[1]*r[2]):''];cells.slice(0,nc).forEach(function(t,k){T(g,(X[k]+X[k+1])/2,y+16,t,{'font-size':12,'font-weight':k===3?800:600,fill:k===3?C.ok:'#33475b'})})});
 for(var k2=0;k2<=nc;k2++)E('line',{x1:X[k2],y1:y0,x2:X[k2],y2:y0+h*(rows.length+1),stroke:'#cfd8e3'},g);
 if(o.tot!=null){var yt=y0+h*(rows.length+1)+18;T(g,X[nc]-4,yt,'Jami: '+i2f(o.tot)+' so‘m',{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
 if(o.side)o.side(g,X[nc])}
var I2N=[['Daftar',2500],['Ruchka',1500],['Qalam',800]];
function i2s1(i,done){S.q1[i]++;var rows=I2N.map(function(r,k){return [r[0],r[1],S.q1[k]]}),t=rows.reduce(function(a,r){return a+r[1]*r[2]},0);i2tab(rows,{val:1,tot:t,hl:i});calc([I2N[i][0]+': '+i2f(I2N[i][1])+' × '+S.q1[i]+' = <b>'+i2f(I2N[i][1]*S.q1[i])+'</b> so‘m'],'Narx × Soni = Qiymat');mvK(done,3)}
var I2L=[['Daftar',2500,3],['Ruchka',1500,2],['Albom',12000,1]];
var P2=[function(){i2tab(I2L,{});i2msg('Xarid ro‘yxati: 3 ta daftar, 2 ta ruchka, 1 ta albom')},
 function(){i2tab(I2L,{val:1,hl:0});calc(['Daftar: 2 500 × 3 = <b>7 500</b>','Ruchka: 1 500 × 2 = <b>3 000</b>','Albom: 12 000 × 1 = <b>12 000</b>'])},
 function(){i2tab(I2L,{val:1,tot:22500});calc(['7 500 + 3 000 + 12 000 = <b>22 500</b> so‘m'])}];
function i2s3(v,done){i2tab(I2L,{val:1,tot:22500,side:function(g,x){E('rect',{x:x+10,y:40,width:70,height:36,rx:5,fill:'#c9ecd2',stroke:'#5cb85c'},g);T(g,x+45,63,'25 000',{'font-size':12,'font-weight':800})}});
 if(v===2500){calc(['25 000 − 22 500 = <b>2 500</b> so‘m qaytim ✓']);done()}else i2msg(v===3500?'Yana bir hisoblang: 25 000 − 22 500. Yuzliklarni tekshiring':v===22500?'22 500 — bu xarid qiymati, qaytim emas':'47 500 — qo‘shib yuborildi. Qaytim = berilgan − qiymat')}
function i2shop(a,b,hl){clear();var g=S.g;[[a,60,'1-do‘kon'],[b,220,'2-do‘kon']].forEach(function(s,k){E('rect',{x:s[1]-50,y:20,width:130,height:110,rx:10,fill:hl===k?'#dff3e3':'#fff',stroke:'#cfd8e3','stroke-width':2},g);T(g,s[1]+15,40,s[2],{'font-size':13,'font-weight':800,fill:C.blue});
  for(var i=0;i<s[0][0];i++)E('circle',{cx:s[1]-20+i*24,cy:70,r:10,fill:'#e0584f'},g);T(g,s[1]+15,100,s[0][0]+' kg — '+i2f(s[0][1])+' so‘m',{'font-size':12,'font-weight':700});if(hl!=null)T(g,s[1]+15,120,'1 kg = '+i2f(s[0][1]/s[0][0]),{'font-size':12,'font-weight':800,fill:C.ok})})}
function i2s4(k,done){i2shop([2,24000],[3,33000],1);if(k===1){calc(['1-do‘kon: 24 000 : 2 = 12 000','2-do‘kon: 33 000 : 3 = <b>11 000</b> — arzon ✓']);done()}else i2msg(k===0?'24 000 kamroq ko‘rinadi, lekin bu 2 kg narxi! 1 kg narxini solishtiring':'1 kg narxlarini hisoblab ko‘ring — ular teng emas')}
var P5=[function(){i2tab([['Daftar','?',4]],{nc:3});i2msg('4 ta daftar uchun 10 000 so‘m to‘landi. 1 ta daftar necha so‘m?')},
 function(){calc(['Narx × 4 = 10 000'])},function(){calc(['Narx × 4 = 10 000','Narx = 10 000 : 4 = <b>2 500</b> so‘m']);i2tab([['Daftar',2500,4]],{val:1,tot:10000})}];
var P6=[function(){i2tab([['Go‘sht (1 kg)',90000]],{nc:2});i2msg('1 kg go‘sht — 90 000 so‘m')},
 function(){calc(['1 kg = 1 000 g, 500 g — <b>yarim</b> kilogramm','500 g: 90 000 : 2 = <b>45 000</b> so‘m'])},
 function(){calc(['1 kg 500 g = 1 kg + 500 g','90 000 + 45 000 = <b>135 000</b> so‘m'])}];
var I2B=[['Kitob',18000],['O‘yinchoq',25000],['Albom',12000],['Bo‘yoq',7000]];
function i2bud(){var t=S.cart.reduce(function(a,i){return a+I2B[i][1]},0);i2tab(I2B.map(function(r,k){var n=S.cart.filter(function(i){return i===k}).length;return [r[0],r[1],n]}),{val:1,tot:t});return t}
function i2s7(i,done){var t=i2bud();if(t+I2B[i][1]>50000){calc(['Jami '+i2f(t)+' + '+i2f(I2B[i][1])+' = '+i2f(t+I2B[i][1])+' > 50 000','Pul yetmaydi — boshqasini tanlang']);return}S.cart.push(i);t=i2bud();var r=50000-t;
 if(r<7000){calc(['Sarf: <b>'+i2f(t)+'</b> so‘m, qoldi: <b>'+i2f(r)+'</b> so‘m','Qolgan pulga hech narsa sig‘maydi ✓']);done()}else calc(['Sarf: '+i2f(t)+', qoldi: <b>'+i2f(r)+'</b> so‘m'])}
var P8=[function(){clear();var g=S.g;[[60,'«Bahor»','1 ta — 6 000',['Aksiya: 2 ta olsangiz,','3-si bepul!']],[220,'«Tong»','1 ta — 5 000',['Aksiya yo‘q','']]].forEach(function(s){E('rect',{x:s[0]-50,y:16,width:130,height:120,rx:10,fill:'#fff',stroke:'#cfd8e3','stroke-width':2},g);T(g,s[0]+15,38,s[1],{'font-size':13,'font-weight':800,fill:C.blue});T(g,s[0]+15,64,s[2],{'font-size':12,'font-weight':700});T(g,s[0]+15,92,s[3][0],{'font-size':11,'font-weight':700,fill:C.bad});T(g,s[0]+15,108,s[3][1],{'font-size':11,'font-weight':700,fill:C.bad})});i2msg('3 ta muzqaymoq kerak. Qayerda arzon?')},
 function(){calc(['«Bahor»: 2 ta pullik, 1 tasi bepul','6 000 × 2 = <b>12 000</b> so‘m'])},
 function(){calc(['«Bahor»: 12 000','«Tong»: 5 000 × 3 = 15 000','«Bahor» <b>3 000</b> so‘m arzon — 1 ta narxi qimmat bo‘lsa ham!'])}];
var STEPS=[
{h:"Narx, soni, qiymat",sum:"Qiymat = narx × soni. Narx — bitta narsaning puli, qiymat — hammasining puli.",a:"m01",
 start:function(){S.q1=[0,0,0];i2tab(I2N.map(function(r){return [r[0],r[1],0]}),{val:1,tot:0});i2msg('Mahsulotlarni savatga soling')},fin:function(){S.q1=[2,1,1];i2tab(I2N.map(function(r,k){return [r[0],r[1],S.q1[k]]}),{val:1,tot:7300});calc(['2 500 × 2 + 1 500 + 800 = <b>7 300</b>'])},
 html:"<p>Do'konda narxlar jadvali. Tugmalarni bosib, savatga mahsulot qo'shing va <b>qiymat</b> qanday o'zgarishini kuzating:</p>",
 btns:[["+ Daftar",function(c,done){i2s1(0,done)}],["+ Ruchka",function(c,done){i2s1(1,done)}],["+ Qalam",function(c,done){i2s1(2,done)}]],g3:1,
 after:"<p><b>Narx</b> — 1 ta mahsulotning puli. <b>Soni</b> — nechta olinadi. <b>Qiymat</b> — hammasi uchun to'lanadigan pul: <b>Qiymat = Narx × Soni</b>.</p>",
 q:{t:"Ruchka narxi 1 500 so'm. 4 ta ruchkaning qiymati?",opts:["6 000 so'm","1 504 so'm","5 500 so'm","4 500 so'm"],ok:0,why:"1 500 × 4 = 6 000.",hint:"Qiymat formulasini eslang.",full:"Qiymat = narx × soni = 1 500 × 4 = 6 000 so'm. 1 504 — qo'shib yuborish, 4 500 — 3 ta ruchka qiymati."},
 tn:"Sinfda «do'kon» o'yini: narx yozilgan kartochkalar va qog'oz pullar. Bir bola sotuvchi, boshqasi xaridor."},
{h:"Xarid ro'yxati va jami",sum:"Har qatorda qiymatni topamiz, keyin hammasini qo'shamiz.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Onam xarid ro'yxati berdi. Hammasi necha so'm bo'ladi?</p>",
 btns:[phaser(P2)],
 after:"<p>Avval <b>har qator</b> uchun qiymat (narx × soni), keyin <b>jami</b> — qiymatlar yig'indisi: 7 500 + 3 000 + 12 000 = <b>22 500</b> so'm.</p>",
 q:{t:"2 ta albom (12 000 so'mdan) va 5 ta qalam (800 so'mdan). Jami?",opts:["28 000 so'm","12 800 so'm","64 000 so'm","24 800 so'm"],ok:0,why:"24 000 + 4 000 = 28 000.",hint:"Har bir qatorni alohida hisoblang.",full:"Albom: 12 000 × 2 = 24 000; qalam: 800 × 5 = 4 000; jami 28 000. 12 800 — sonlarni hisobga olmay narxlarni qo'shish."},
 tn:"Bolalar oilasining haqiqiy xarid ro'yxatini (taxminiy narxlar bilan) tuzib kelsin."},
{h:"Qaytim",sum:"Qaytim = berilgan pul − xarid qiymati.",a:"m03",
 start:function(){i2s3(0,function(){});i2msg('22 500 so‘mlik xarid uchun 25 000 so‘m berdik. Qaytim qancha?')},fin:function(){i2s3(2500,function(){})},
 html:"<p>Xarid 22 500 so'm. Kassaga <b>25 000</b> so'm berdik. Qancha qaytim olamiz?</p>",
 btns:[["3 500",function(c,done){i2s3(3500,done)}],["22 500",function(c,done){i2s3(22500,done)}],["2 500",function(c,done){i2s3(2500,done)}],["47 500",function(c,done){i2s3(47500,done)}]],g2:1,
 after:"<p><b>Qaytim = berilgan − qiymat</b>: 25 000 − 22 500 = <b>2 500</b> so'm. Tekshirish: 22 500 + 2 500 = 25 000 ✓.</p>",
 q:{t:"Lola 2 ta daftar (2 000 so'mdan), 3 ta ruchka (1 000 so'mdan) va 1 ta qalam (900 so'm) olib, 10 000 so'm berdi. Qaytim?",opts:["2 100 so'm","2 900 so'm","7 900 so'm","1 100 so'm"],ok:0,why:"4 000 + 3 000 + 900 = 7 900; 10 000 − 7 900 = 2 100.",hint:"Avval jami qiymatni toping.",full:"Qiymat: 2 000 × 2 + 1 000 × 3 + 900 = 7 900. Qaytim: 10 000 − 7 900 = 2 100. 7 900 — qiymatning o'zi, 2 900 — ayirishda o'nlikni unutish."},
 tn:"Qaytimni «to'ldirib sanash» usulida ham ko'rsating: 22 500 dan 25 000 gacha nechta yetmaydi?"},
{h:"Qayerda arzon? 1 kg narxi",sum:"Turli og'irlikdagi narxlarni solishtirish uchun 1 kg narxini topamiz.",a:"m04",
 start:function(){i2shop([2,24000],[3,33000]);i2msg('Qaysi do‘konda olma arzon?')},fin:function(){i2s4(1,function(){})},
 html:"<p>Ikki do'konda olma sotilmoqda. Qaysi birida <b>arzon</b>?</p>",
 btns:[["1-do'kon",function(c,done){i2s4(0,done)}],["2-do'kon",function(c,done){i2s4(1,done)}],["Teng",function(c,done){i2s4(2,done)}]],g3:1,
 after:"<p>To'g'ridan-to'g'ri 24 000 va 33 000 ni solishtirib bo'lmaydi — og'irliklari har xil! <b>1 kg narxi</b>ni topamiz: 24 000 : 2 = 12 000 va 33 000 : 3 = 11 000. 2-do'kon arzon.</p>",
 q:{t:"5 ta tuxum 6 000 so'm, 10 ta tuxum 11 000 so'm. 1 ta tuxum qayerda arzon?",opts:["10 talikda","5 talikda","Teng","Bilib bo'lmaydi, narxlar har xil"],ok:0,why:"6 000 : 5 = 1 200; 11 000 : 10 = 1 100.",hint:"1 ta tuxum narxini hisoblang.",full:"5 talikda 1 tasi 6 000 : 5 = 1 200 so'm, 10 talikda 11 000 : 10 = 1 100 so'm. 10 talik arzon, garchi umumiy narxi ko'p bo'lsa ham."},
 tn:"Do'kon cheklaridan (yoki o'ylab topilgan narxlardan) «katta qadoq arzonmi?» savolini muhokama qiling."},
{h:"Teskari masala: narxni topamiz",sum:"Narx = qiymat : soni; soni = qiymat : narx.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>4 ta daftar uchun 10 000 so'm to'landi. 1 ta daftar necha so'm?</p>",
 btns:[phaser(P5)],
 after:"<p>Qiymat va soni ma'lum bo'lsa, <b>narx = qiymat : soni</b> = 10 000 : 4 = 2 500. Narx va qiymat ma'lum bo'lsa, <b>soni = qiymat : narx</b>.</p>",
 q:{t:"Ruchka 1 500 so'm. 9 000 so'mga nechta ruchka olish mumkin?",opts:["6","7 500","10 500","5"],ok:0,why:"9 000 : 1 500 = 6.",hint:"Qaysi kattalikni topyapmiz: narxnimi, sonnimi?",full:"Soni = qiymat : narx = 9 000 : 1 500 = 6 ta. Tekshirish: 1 500 × 6 = 9 000. 7 500 — ayirib yuborish."},
 tn:"Uchburchak sxemasini doskaga chizing: tepada «Qiymat», pastda «Narx × Soni» — bittasini yopsangiz, qolgani qanday topilishi ko'rinadi."},
{h:"500 g — yarim kilogramm",sum:"500 g = 1 kg ning yarmi, narxi ham yarmi; 1 kg 500 g = 1 kg + yarim kg.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Go'sht 1 kg uchun 90 000 so'm. 500 g va 1 kg 500 g necha so'm?</p>",
 btns:[phaser(P6)],
 after:"<p>1 kg = 1 000 g, demak <b>500 g — yarim kg</b>: 90 000 : 2 = 45 000. 1 kg 500 g = 90 000 + 45 000 = 135 000 so'm. 250 g — chorak kg, narxning 4 dan biri.</p>",
 q:{t:"1 kg shirinlik 40 000 so'm. 250 g necha so'm?",opts:["10 000 so'm","20 000 so'm","250 so'm","4 000 so'm"],ok:0,why:"250 g — 1 kg ning to'rtdan biri: 40 000 : 4.",hint:"1 kg da nechta 250 g bor?",full:"1 000 g da 4 ta 250 g bor, demak 250 g narxi 40 000 : 4 = 10 000. 20 000 — yarim kg narxi."},
 tn:"Tarozi bo'lmasa, 1 litrlik idish va stakanlar bilan «yarmi», «choragi» ni ko'rsating."},
{h:"Byudjet: 50 000 so'm bor",sum:"Pul yetadimi? Har qo'shishda jami byudjetdan oshmasligini tekshiramiz.",a:"m07",
 start:function(){S.cart=[];i2bud();i2msg('50 000 so‘mga sovg‘alar tanlang. Pul tugaguncha')},fin:function(){S.cart=[0,1,3];var t=i2bud();calc(['18 000 + 25 000 + 7 000 = <b>50 000</b> ✓'])},
 html:"<p>Sizda <b>50 000</b> so'm bor. Do'stlaringizga sovg'a tanlang. Pul yetmasa, tanlab bo'lmaydi!</p>",
 btns:[["Kitob 18 000",function(c,done){i2s7(0,done)}],["O'yinchoq 25 000",function(c,done){i2s7(1,done)}],["Albom 12 000",function(c,done){i2s7(2,done)}],["Bo'yoq 7 000",function(c,done){i2s7(3,done)}]],g2:1,
 after:"<p>Har bir qo'shishdan oldin tekshiramiz: <b>jami + yangi narx ≤ 50 000</b>? Qolgan pul eng arzon narsadan (7 000) kam bo'lsa — xarid tugadi. Turli tanlov turli qoldiq beradi.</p>",
 q:{t:"30 000 so'm bor. Kitob 18 000, albom 12 000, bo'yoq 7 000. Qaysi to'plamni olsa bo'ladi?",opts:["Kitob va albom","Kitob, albom va bo'yoq","Kitob va 2 ta albom","Albom va 3 ta bo'yoq"],ok:0,why:"18 000 + 12 000 = 30 000.",hint:"Har bir to'plam jamini 30 000 bilan solishtiring.",full:"Kitob + albom = 30 000 — aynan yetadi. Kitob + albom + bo'yoq = 37 000, kitob + 2 albom = 42 000, albom + 3 bo'yoq = 33 000 — hammasi 30 000 dan ko'p."},
 tn:"Juftlikda: biri ro'yxat tuzadi, ikkinchisi byudjetdan oshmaganini tekshiradi."},
{h:"Tuzoq: aksiya haqiqatan foydalimi?",sum:"Aksiyada nechta narsa uchun pul to'lanishini hisoblab, so'ng solishtiramiz.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Ikki do'kon. «Bahor»da muzqaymoq qimmat, lekin aksiya bor. Qayerda <b>3 ta</b> muzqaymoq arzon?</p>",
 btns:[phaser(P8)],
 after:"<p>Aksiyada 3 tadan faqat <b>2 tasiga</b> pul to'laymiz: 6 000 × 2 = 12 000. «Tong»da: 5 000 × 3 = 15 000. «Bahor» arzon! Lekin <b>1 tagina</b> kerak bo'lsa — «Tong» arzon (5 000 < 6 000).</p>",
 q:{t:"«2 ta olsangiz, 3-si bepul» aksiyasida 1 tasi 4 000 so'm. 6 ta olsangiz, qancha to'laysiz?",opts:["16 000 so'm","24 000 so'm","20 000 so'm","8 000 so'm"],ok:0,why:"Har 3 tadan 2 tasi pullik: 6 tadan 4 tasi. 4 × 4 000 = 16 000.",hint:"6 tada nechta «uchlik» bor? Har uchlikda nechtasiga to'lanadi?",full:"6 = 3 + 3, ikki uchlik. Har birida 2 tasi pullik — jami 4 ta: 4 000 × 4 = 16 000. 24 000 — aksiyasiz narx, 8 000 — faqat bitta uchlik."},
 tn:"Haqiqiy do'kon reklamalarini (aksiyalarni) muhokama qiling — «arzon ko'rinadi» va «arzon» farqini topishsin."},
{h:"Bilasizmi? Kassa apparati va so'm",sum:"Birinchi kassa apparatini 1879-yilda Jeyms Ritti patentlagan. O'zbekistonda so'm 1994-yildan muomalada.",a:"m09",
 start:function(){P2[2]()},fin:function(){P2[2]()},
 html:"<p>🧾 Amerikalik Jeyms Ritti 1879-yilda birinchi mexanik kassa apparatini patentlagan. U sotuvchilar pulni to'g'ri hisoblashi uchun o'ylab topilgan.</p><p>💵 O'zbekistonning milliy valyutasi — <b>so'm</b> 1994-yil 1-iyuldan muomalaga kiritilgan.</p><p>🛒 Bugun do'konlarda shtrix-kod skaneri narxni bir zumda o'qiydi va kassa qiymatni o'zi hisoblaydi.</p>",
 tn:"Bolalar uydan haqiqiy chek olib kelsin (shaxsiy ma'lumotsiz) — undagi narx, soni, qiymat va jamini tekshirishsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P2[2]()},fin:function(){P2[2]()},
 html:"<div class='memo'><ul><li><b>Qiymat = Narx × Soni</b>.</li><li>Narx = Qiymat : Soni; Soni = Qiymat : Narx.</li><li>Jami — har qator qiymatining yig'indisi.</li><li><b>Qaytim = berilgan − jami</b>; tekshirish: jami + qaytim = berilgan.</li><li>Solishtirish uchun <b>1 kg (1 ta) narxini</b> toping.</li><li>500 g — yarim kg, 250 g — chorak kg.</li><li>Aksiyada nechtasiga pul to'lanishini hisoblang.</li></ul></div>",
 tn:"Keyingi darsni og'zaki «do'kon» bilan boshlang: «3 ta 1 500 lik — necha so'm?»"}
];
var PROBS=[
{t:"Daftar 3 000 so'm. 4 ta daftarning qiymati?",o:["12 000 so'm","7 000 so'm","3 004 so'm","9 000 so'm"],k:0,s:"3 000 × 4 = 12 000."},
{t:"5 ta qalam 4 000 so'm. 1 ta qalam narxi?",o:["800 so'm","20 000 so'm","1 000 so'm","3 995 so'm"],k:0,s:"4 000 : 5 = 800."},
{t:"Albom 9 000 so'm. 36 000 so'mga nechta albom?",o:["4","27 000","3","5"],k:0,s:"36 000 : 9 000 = 4."},
{t:"Xarid 13 600 so'm, 20 000 so'm berildi. Qaytim?",o:["6 400 so'm","7 400 so'm","33 600 so'm","6 600 so'm"],k:0,s:"20 000 − 13 600 = 6 400."},
{t:"1 kg nok 16 000 so'm, 1 kg shaftoli 18 000 so'm. Shaftoli nokdan qancha qimmat?",o:["2 000 so'm","34 000 so'm","1 000 so'm","8 000 so'm"],k:0,s:"18 000 − 16 000 = 2 000."},
{t:"2 ta albom (15 000 so'mdan) va 5 ta qalam (3 000 so'mdan). Jami?",o:["45 000 so'm","18 000 so'm","36 000 so'm","54 000 so'm"],k:0,s:"30 000 + 15 000 = 45 000."},
{t:"1 kg go'sht 80 000 so'm. 500 g necha so'm?",o:["40 000 so'm","80 500 so'm","20 000 so'm","400 000 so'm"],k:0,s:"500 g — yarim kg: 80 000 : 2."},
{t:"1 kg pishloq 60 000 so'm. 1 kg 500 g necha so'm?",o:["90 000 so'm","120 000 so'm","60 500 so'm","30 000 so'm"],k:0,s:"60 000 + 30 000 = 90 000."},
{t:"1 kg qand 12 000 so'm. 250 g necha so'm?",o:["3 000 so'm","6 000 so'm","4 000 so'm","250 so'm"],k:0,s:"250 g — chorak kg: 12 000 : 4."},
{t:"3 kg olma 27 000 so'm, 2 kg olma 20 000 so'm (boshqa do'kon). 1 kg qayerda arzon?",o:["3 kg lik do'konda","2 kg lik do'konda","Teng","Hech qaysida"],k:0,s:"27 000 : 3 = 9 000; 20 000 : 2 = 10 000."},
{t:"6 ta tuxum 9 000, 10 ta tuxum 14 000 so'm. 1 tasi qayerda arzon?",o:["10 talikda","6 talikda","Teng","Ikkalasida 1 000 so'm"],k:0,s:"1 500 va 1 400 so'm."},
{t:"Lola 3 ta daftar (2 500 dan) va 2 ta ruchka (1 500 dan) olib, 15 000 berdi. Qaytim?",o:["4 500 so'm","10 500 so'm","11 000 so'm","5 500 so'm"],k:0,s:"7 500 + 3 000 = 10 500; 15 000 − 10 500 = 4 500."},
{t:"Rasmdagi xarid: 2 kg guruch (14 000 dan), 1 l yog' (25 000), 3 ta non (4 000 dan). Jami?",o:["65 000 so'm","43 000 so'm","53 000 so'm","61 000 so'm"],k:0,s:"28 000 + 25 000 + 12 000 = 65 000."},
{t:"40 000 so'm bor. Kitob 15 000. Nechta kitob olib, qancha qoladi?",o:["2 ta, 10 000 qoladi","3 ta, qolmaydi","2 ta, 5 000 qoladi","1 ta, 25 000 qoladi"],k:0,s:"15 000 × 2 = 30 000 ≤ 40 000, 3 tasi 45 000 — yetmaydi."},
{t:"«2 ta olsangiz, 3-si bepul». 1 tasi 3 000 so'm. 9 ta uchun qancha to'lanadi?",o:["18 000 so'm","27 000 so'm","9 000 so'm","24 000 so'm"],k:0,s:"3 ta uchlik, har birida 2 ta pullik: 6 × 3 000."},
{t:"«Bahor»: 1 ta 7 000, aksiya «2 ta olsangiz, 3-si bepul». «Tong»: 1 ta 5 000. 3 ta qayerda arzon va qanchaga?",o:["«Bahor», 1 000 so'mga","«Tong», 2 000 so'mga","Teng","«Bahor», 7 000 so'mga"],k:0,s:"Bahor: 14 000; Tong: 15 000."},
{t:"Ruchka qalamdan 700 so'm qimmat. Qalam 800 so'm. 1 ta ruchka va 1 ta qalam birgalikda?",o:["2 300 so'm","1 500 so'm","100 so'm","2 200 so'm"],k:0,s:"Ruchka 1 500; 1 500 + 800 = 2 300."},
{t:"3 ta bir xil kitob va 1 ta albom (6 000) jami 33 000 so'm. 1 ta kitob necha so'm?",o:["9 000 so'm","11 000 so'm","27 000 so'm","13 000 so'm"],k:0,s:"33 000 − 6 000 = 27 000; 27 000 : 3 = 9 000."},
{t:"Narxi 1 200 so'mlik ruchkadan 5 ta olib, 10 000 so'm berildi. Qaytim?",o:["4 000 so'm","8 800 so'm","6 000 so'm","5 000 so'm"],k:0,s:"1 200 × 5 = 6 000; 10 000 − 6 000 = 4 000."},
{t:"Har kuni 2 ta non (3 000 dan) olinadi. Bir haftada nonga qancha pul ketadi?",o:["42 000 so'm","21 000 so'm","6 000 so'm","36 000 so'm"],k:0,s:"Kuniga 6 000, 7 kunda 42 000."}
];
function PRACT_STAGE(){P2[2]()}
var PREP_DATA={teach:["Narx, soni, qiymat: Qiymat = Narx × Soni va teskari masalalar.","Xarid ro'yxati bo'yicha jami va qaytim.","1 kg (1 ta) narxi bo'yicha solishtirish; 500 g va 250 g narxi.","Byudjet va aksiya tuzoqlari."],
 mist:["Narxlarni sonini hisobga olmay qo'shadi.","Qaytim o'rniga xarid qiymatini javob deb beradi.","Turli og'irlikdagi umumiy narxlarni to'g'ridan-to'g'ri solishtiradi.","Ayirishda nollar va o'nliklar bilan adashadi (25 000 − 22 500)."],
 need:["Narx kartochkalari, qog'oz pullar.","Do'kon cheklari (shaxsiy ma'lumotsiz).","Doskada jadval: Mahsulot | Narx | Soni | Qiymat."],
 board:["<span class='w2'>Qiymat = Narx × Soni</span>.","Ro'yxat: 7 500 + 3 000 + 12 000 = 22 500.","Qaytim: 25 000 − 22 500 = 2 500.","1 kg: 24 000 : 2 va 33 000 : 3.","Narx = 10 000 : 4.","500 g = yarim kg.","Aksiya: 3 tadan 2 tasi pullik."]};
