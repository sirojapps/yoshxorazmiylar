var CODE='2H12',TITLE="2-sinf · Labirint va yo'l topish";
function hCMsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli maydon va robot
function hCField(o){clear();var g=S.g,c=o.c||22,cols=o.cols||13,rows=o.rows||7,x0=180-cols*c/2,y0=6;S.hx=function(q){return x0+q*c+c/2};S.hy=function(r){return y0+r*c+c/2};
 for(var r=0;r<rows;r++)for(var q=0;q<cols;q++){var wall=o.walls&&o.walls[r+','+q];E('rect',{x:x0+q*c,y:y0+r*c,width:c-1,height:c-1,fill:wall?'#8a7a60':'#fff',stroke:'#dde5ee'},g)}
 if(o.path&&o.path.length>1)E('polyline',{points:o.path.map(function(p){return S.hx(p[0])+','+S.hy(p[1])}).join(' '),fill:'none',stroke:C.blue,'stroke-width':3,'stroke-linejoin':'round','stroke-dasharray':o.dash?'5 4':''},g);
 if(o.goal)T(g,S.hx(o.goal[0]),S.hy(o.goal[1])+6,'⭐',{'font-size':16});if(o.start)E('circle',{cx:S.hx(o.start[0]),cy:S.hy(o.start[1]),r:5,fill:C.ok},g);
 if(o.bot)T(g,S.hx(o.bot[0]),S.hy(o.bot[1])+6,'🤖',{'font-size':17})}
var W1={};['1,3','2,3','3,3','3,5','4,5','5,5','1,7','2,7','3,7','5,9','4,9','3,9','2,9'].forEach(function(k){W1[k]=1});
function hCMove(dx,dy,done){var nx=S.bp[0]+dx,ny=S.bp[1]+dy;if(nx<0||ny<0||nx>12||ny>6||W1[ny+','+nx]){hCMsg('Devor! Boshqa yo‘l tanlang');return}S.bp=[nx,ny];S.trail.push([nx,ny]);S.steps++;hCField({walls:W1,goal:[11,3],start:[1,3],bot:S.bp,path:S.trail});
 if(nx===11&&ny===3){hCMsg('Yetib keldingiz! <b>'+S.steps+'</b> qadam');done()}else hCMsg('Qadamlar: '+S.steps)}
var P2=[function(){hCField({start:[3,3],bot:[3,3]});hCMsg('Buyruqlar: 3 → , 2 ↑ , 1 ← , 4 ↓')},
 function(){hCField({start:[3,3],path:[[3,3],[6,3]],bot:[6,3]});hCMsg('3 o‘ngga')},
 function(){hCField({start:[3,3],path:[[3,3],[6,3],[6,1],[5,1]],bot:[5,1]});hCMsg('2 yuqoriga, 1 chapga')},
 function(){hCField({start:[3,3],path:[[3,3],[6,3],[6,1],[5,1],[5,5]],bot:[5,5]});E('line',{x1:S.hx(3),y1:S.hy(3),x2:S.hx(5),y2:S.hy(5),stroke:C.ok,'stroke-width':3},S.g);hCMsg('4 pastga. Boshidan: o‘ngga 3 − 1 = <b>2</b>, pastga 4 − 2 = <b>2</b>')}];
// eng qisqa yo'l: graf
var GN={U:[40,90],A:[140,30],B:[140,150],C:[240,90],M:[320,90]},GE=[['U','A',3,-8,-8],['U','B',2,-8,14],['A','C',4,0,16],['B','C',3,-6,-6],['A','M',6,6,-10],['C','M',2,0,16],['B','M',7,10,14]];
function hCGraph(hl){clear();var g=S.g;GE.forEach(function(e){var a=GN[e[0]],b=GN[e[1]],on=hl&&hl.indexOf(e[0]+e[1])>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#9aa8b6','stroke-width':on?5:3},g);T(g,(a[0]+b[0])/2+e[3],(a[1]+b[1])/2+e[4],e[2]+' km',{'font-size':11,'font-weight':800,fill:on?C.ok:'#5b6b7b'})});
 Object.keys(GN).forEach(function(k){var p=GN[k];E('circle',{cx:p[0],cy:p[1],r:15,fill:k==='U'?'#fde6c8':(k==='M'?'#e1f4f2':'#fff'),stroke:C.line,'stroke-width':1.6},g);T(g,p[0],p[1]+4,k==='U'?'🏠':(k==='M'?'🏫':k),{'font-size':k==='U'||k==='M'?14:12,'font-weight':800})})}
var ROUTES=[['Uy → A → Maktab','UA,AM',9],['Uy → B → Maktab','UB,BM',9],['Uy → A → C → Maktab','UA,AC,CM',9],['Uy → B → C → Maktab','UB,BC,CM',7]];
var P5=[function(){hCPas(0)},function(){hCPas(1)},function(){hCPas(2)}];
function hCPas(k){clear();var g=S.g,x0=110,y0=140,c=60;for(var i=0;i<=2;i++){E('line',{x1:x0,y1:y0-i*c,x2:x0+2*c,y2:y0-i*c,stroke:'#9aa8b6','stroke-width':3},g);E('line',{x1:x0+i*c,y1:y0,x2:x0+i*c,y2:y0-2*c,stroke:'#9aa8b6','stroke-width':3},g)}
 var N=[[1,1,1],[1,2,3],[1,3,6]];for(var a=0;a<=2;a++)for(var b=0;b<=2;b++){var show=k===0?(a===0||b===0):(k===1?(a<=1&&b<=1)||a===0||b===0:true);var x=x0+a*c,y=y0-b*c;E('circle',{cx:x,cy:y,r:12,fill:show?'#fff':'#eef2f6',stroke:C.line},g);if(show)T(g,x,y+4,String(N[a][b]),{'font-size':12,'font-weight':800,fill:a+b===4?C.ok:C.blue})}
 T(g,x0-18,y0+18,'A',{'font-size':13,'font-weight':800});T(g,x0+2*c+18,y0-2*c-6,'B',{'font-size':13,'font-weight':800});T(g,300,40,'faqat → va ↑',{'font-size':11,fill:C.blue,'font-weight':800});
 hCMsg(k===0?'Chetdagi har nuqtaga faqat <b>1</b> xil yo‘l bor':(k===1?'Ichki nuqta: chapdagi + pastdagi sonlar: 1 + 1 = <b>2</b>':'B ga: 3 + 3 = <b>6</b> xil yo‘l'))}
var STEPS=[
{h:"Robotni yulduzga olib boring",sum:"Buyruqlar: ↑ ↓ ← →, har biri 1 katak. Devorni aylanib o'tamiz.",a:"m01",
 start:function(){S.bp=[1,3];S.trail=[[1,3]];S.steps=0;hCField({walls:W1,goal:[11,3],start:[1,3],bot:S.bp});hCMsg('Strelkalar bilan robotni ⭐ ga olib boring')},fin:function(){hCField({walls:W1,goal:[11,3],start:[1,3],bot:[11,3]});hCMsg('Yetib keldi')},
 html:"<p>Robot katakli maydonda turibdi. Har buyruq — 1 katak. Kul rang — devor. Robotni <b>⭐</b> ga olib boring:</p>",
 btns:[["↑",function(c,done){hCMove(0,-1,done)}],["↓",function(c,done){hCMove(0,1,done)}],["←",function(c,done){hCMove(-1,0,done)}],["→",function(c,done){hCMove(1,0,done)},'u']],g2:1,
 after:"<p>Yo'lni oldindan rejalashtirsangiz, kamroq qadam bilan yetasiz. Devorni aylanib o'tishda doim «qaysi tomon ochiq?» deb qarang.</p>",
 q:{t:"Robot buyruqlari: o'ngga, o'ngga, yuqoriga, chapga, yuqoriga, o'ngga (har biri 1 katak). Robot boshlang'ich joyidan necha katak o'ngda?",opts:["3","1","2","4"],ok:2,why:"O'ngga 3 marta, chapga 1 marta: 3 − 1 = 2.",hint:"O'ngga necha marta va chapga necha marta yurdi?",full:"O'ngga: 1-, 2-, 6-buyruq — 3 marta. Chapga: 4-buyruq — 1 marta. 3 − 1 = 2 katak o'ngda."},
 tn:"Sinf polida bo'r bilan katak chizib, «robot» bolani buyruqlar bilan yurgizing — bu dasturlashning ham birinchi darsi."},
{h:"Buyruqlar natijasi",sum:"3 →, 2 ↑, 1 ←, 4 ↓ → oxirida 2 o'ngda, 2 pastda. Qarama-qarshi yo'nalishlar ayiriladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p><i>«Robot 3 katak o'ngga, 2 katak yuqoriga, 1 katak chapga va 4 katak pastga yurdi. U boshlang'ich joyiga nisbatan qayerda?»</i></p>",
 btns:[phaser(P2,'▶ Keyingi buyruq')],
 after:"<p>Tez usul: o'ngga va chapga — <b>ayiramiz</b> (3 − 1 = 2 o'ngda), yuqoriga va pastga — <b>ayiramiz</b> (4 − 2 = 2 pastda). Yo'l uzunligi esa boshqa: 3 + 2 + 1 + 4 = 10 qadam.</p>",
 q:{t:"Robot: yuqoriga, yuqoriga, o'ngga, o'ngga, pastga, o'ngga. Boshlang'ich joyga nisbatan qayerda?",opts:["3 o'ngda, 3 yuqorida","2 o'ngda, 1 yuqorida","3 o'ngda, 1 yuqorida","1 o'ngda, 3 yuqorida"],ok:2,why:"O'ngga 3; yuqoriga 2 − 1 = 1.",hint:"O'ngga necha marta? Yuqoriga va pastga necha martadan?",full:"O'ngga: 3 marta. Yuqoriga 2, pastga 1: 2 − 1 = 1 yuqorida. Javob: 3 o'ngda, 1 yuqorida."},
 tn:"«→ → ↑ ←» kabi buyruqlarni kartochkaga yozib, bolalar bir-biriga topishmoq bersin."},
{h:"Eng qisqa yo'l",sum:"Hamma yo'llarni hisoblab, eng kichigini tanlaymiz: Uy → B → C → Maktab = 2 + 3 + 2 = 7 km.",a:"m03",
 start:function(){S.rt={};hCGraph([]);hCMsg('Yo‘llarni bosib, uzunligini ko‘ring')},fin:function(){hCGraph(['UB','BC','CM']);hCMsg('Eng qisqasi: 2 + 3 + 2 = <b>7 km</b>')},
 html:"<p>Xaritada uydan maktabgacha yo'llar va ularning uzunligi bor. Har bir yo'lni bosib, uzunligini hisoblang:</p>",
 btns:ROUTES.map(function(r,i){return [r[0],function(c,done){hCGraph(r[1].split(','));hCMsg(r[0]+': <b>'+r[2]+' km</b>');S.rt[i]=1;if(Object.keys(S.rt).length===4)done()}]}),
 after:"<p>Uch yo'l 9 km, bittasi <b>7 km</b>: Uy → B → C → Maktab. Ko'rinishidan qisqa yo'l (to'g'ridan-to'g'ri, kam burilish) har doim ham qisqa bo'lavermaydi — <b>hisoblang</b>!</p>",
 q:{t:"Uydan do'konga ikki yo'l: 1) 4 km + 5 km; 2) 3 km + 3 km + 2 km. Qaysi yo'l qisqa va qanchaga?",opts:["1-yo'l, 1 km","2-yo'l, 1 km","2-yo'l, 2 km","ikkalasi teng"],ok:1,why:"1-yo'l 9 km, 2-yo'l 8 km: farq 1 km.",hint:"Har yo'lning qismlarini qo'shing.",full:"1-yo'l: 4 + 5 = 9 km. 2-yo'l: 3 + 3 + 2 = 8 km. 2-yo'l 1 km qisqa — qismlari ko'p bo'lsa ham."},
 tn:"Maktab atrofi xaritasini chizib, haqiqiy yo'llarni qadamlab o'lchating."},
{h:"Labirint: oxiridan yeching",sum:"Labirintda xazinadan orqaga qarab yursak, to'g'ri kirish tezroq topiladi.",a:"m04",
 start:function(){hCMaze(false)},fin:function(){hCMaze(true)},
 html:"<p>To'rt bola — A, B, C, D — labirintga kirmoqchi. Qaysi biri o'rtadagi xazinaga yetadi? Ayyorlik: <b>xazinadan orqaga</b> qarab yo'l izlang!</p>",
 btns:[["⭐ Xazinadan orqaga",function(c,done,b){b.disabled=true;hCMaze(true);done()}]],
 after:"<p>Xazinadan faqat <b>bitta</b> yo'l chiqadi va u <b>C</b> kirishiga olib boradi. Boshqa kirishlarning yo'llari boshi berk ko'chaga tushadi. Oxiridan yechish usuli ko'pincha tezroq!</p>",
 q:{t:"Labirintda 4 ta kirish bor, xazinaga faqat bitta yo'l olib boradi. Qaysi usul eng tez?",opts:["Har kirishni boshidan oxirigacha sinash","Xazinadan orqaga yo'l izlash","Tasodifiy tanlash","Eng yaqin kirishni olish"],ok:1,why:"Xazinadan chiqadigan yo'l bitta — uni kuzatsak, to'g'ri kirishni darhol topamiz.",hint:"Yo'llar qayerda kamroq tarmoqlanadi?",full:"Kirishlardan ko'p yo'l boshlanadi, xazina atrofida esa yo'l kam. Shuning uchun oxiridan boshlab yurish tezroq — bu «teskari yechish» usuli."},
 tn:"Gazeta labirintlarini avval qalam bilan oxiridan yechib ko'rsating, keyin boshidan — farqni bolalar o'zi sezadi."},
{h:"Nechta yo'l bor? (faqat → va ↑)",sum:"Har nuqtaga yo'llar soni = chapdagi + pastdagi. 2×2 to'rda A dan B ga 6 xil yo'l.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p><i>«Sichqoncha ko'chalar bo'ylab faqat o'ngga yoki yuqoriga yurib, A dan B ga bormoqchi. Nechta har xil yo'l bor?»</i> Har burchakka u yerga nechta yo'l kelishini yozamiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Qoida: har bir chorrahaga keladigan yo'llar soni = <b>chapdagi son + pastdagi son</b> (chunki unga faqat chapdan yoki pastdan kelish mumkin). Shunday qilib B ga <b>6</b> ta yo'l chiqadi. Bu usul juda katta to'rlarda ham ishlaydi!</p>",
 q:{t:"1 × 2 to'rda (o'ngga 2 katak, yuqoriga 1 katak) A dan B ga faqat → va ↑ bilan nechta yo'l bor?",opts:["2","3","4","6"],ok:1,why:"Pastki qator: 1, 1, 1; yuqori: 1, 2, 3.",hint:"Har chorrahaga son yozing: chapdagi + pastdagi.",full:"Pastki qatorda hamma joyga 1 ta yo'l. Yuqori qatorda: 1, 1 + 1 = 2, 2 + 1 = 3. B ga 3 ta yo'l: →→↑, →↑→, ↑→→."},
 tn:"Bu — «Paskal uchburchagi» g'oyasi. Bolalar yo'llarni rangli qalam bilan chizib, sanab, keyin qoida bilan tekshirsin."},
{h:"Yo'llar ko'paytmasi",sum:"Uydan maktabga 2 yo'l, maktabdan kutubxonaga 3 yo'l → 2 · 3 = 6 xil yo'l.",a:"m06",
 start:function(){S.ph=0;hCTree(0)},fin:function(){hCTree(2)},
 html:"<p><i>«Alining uyidan maktabgacha 2 xil, maktabdan kutubxonagacha 3 xil yo'l bor. Uydan maktab orqali kutubxonaga necha xil yo'l bilan borish mumkin?»</i></p>",
 btns:[phaser([function(){hCTree(0)},function(){hCTree(1)},function(){hCTree(2)}],'▶ Keyingi')],
 after:"<p>Uydan chiqishda 2 ta tanlov, <b>har biridan keyin</b> yana 3 ta: 3 + 3 = 2 · 3 = <b>6</b>. «5» deganlar qo'shib yuborgan (2 + 3).</p>",
 q:{t:"Buxorodan Samarqandga 3 ta avtobus, Samarqanddan Toshkentga 2 ta avtobus va 2 ta samolyot yo'nalishi bor. Samarqand orqali Buxorodan Toshkentga nechta usul?",opts:["7","12","5","4"],ok:1,why:"3 · (2 + 2) = 3 · 4 = 12.",hint:"Samarqanddan Toshkentga jami nechta yo'nalish bor?",full:"Samarqanddan Toshkentga 2 + 2 = 4 yo'nalish. Buxorodan 3 ta, har biridan keyin 4 ta: 3 · 4 = 12."},
 tn:"«Daraxt» chizish usuli — kombinatorikaning asosi. Har tarmoqni bolalar rangli qalam bilan chizsin."},
{h:"Kub qirralari bo'ylab",sum:"Kubning bir uchidan qarama-qarshi uchiga qirralar bo'ylab eng kami 3 ta qirra.",a:"m07",
 start:function(){hCCube(false)},fin:function(){hCCube(true)},
 html:"<p><i>«Chumoli kubning bir uchidan eng uzoq (qarama-qarshi) uchiga faqat qirralar bo'ylab bormoqda. U eng kami bilan nechta qirrani bosib o'tadi?»</i></p>",
 btns:[["🐜 Yo'lni ko'rsatish",function(c,done,b){b.disabled=true;hCCube(true);done()}]],
 after:"<p>Qarama-qarshi uch — boshqa <b>uchala</b> yo'nalishda ham (bo'yi, eni, balandligi) farq qiladi. Har qirra faqat bitta yo'nalishni o'zgartiradi — demak eng kami <b>3 ta</b> qirra.</p>",
 q:{t:"Kvadratning bir uchidan qarama-qarshi uchiga tomonlar bo'ylab eng kami nechta tomon bosib o'tiladi?",opts:["1","2","3","4"],ok:1,why:"Kvadratda qarama-qarshi uch 2 yo'nalishda farq qiladi — 2 ta tomon.",hint:"Kvadratda nechta yo'nalish bor: eni va bo'yi?",full:"Kvadratda qarama-qarshi uchga borish uchun bir marta eni bo'ylab, bir marta bo'yi bo'ylab yurish kerak — 2 ta tomon."},
 tn:"Qog'oz kub yoki gugurt qutisi ustida barmoq bilan yo'lni yurib chiqing."},
{h:"Bilasizmi? O'ng qo'l qoidasi",sum:"Ko'p labirintlardan chiqishning oddiy usuli: devorni bir qo'l bilan ushlab, qo'yib yubormay yurish.",a:"m08",
 start:function(){hCMaze(true)},fin:function(){hCMaze(true)},
 html:"<p>🏛 Labirintlar haqidagi eng qadimiy afsonalardan biri — qadimgi Yunonistondagi Krit orolidagi labirint haqida.</p><p>✋ Oddiy (devorlari tashqi devorga ulangan) labirintdan chiqishning ajoyib usuli bor: <b>o'ng qo'lingiz bilan devorni ushlang va qo'yib yubormay yuring</b>. Yo'l uzun bo'lishi mumkin, lekin albatta chiqasiz!</p>",
 tn:"Sinfda stullardan kichik labirint qurib, «o'ng qo'l qoidasi»ni sinab ko'ring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){P5[2]()},fin:function(){P5[2]()},
 html:"<div class='memo'><ul><li>Buyruqlar natijasi: o'ng − chap, yuqori − past.</li><li>Yo'l uzunligi — hamma qadamlar yig'indisi.</li><li>Eng qisqa yo'l — hamma variantni hisoblab, kichigini tanlang.</li><li>Labirintni <b>oxiridan</b> yeching.</li><li>Faqat → va ↑: har chorrahaga chapdagi + pastdagi son.</li><li>Ketma-ket tanlovlar ko'paytiriladi: 2 yo'l, keyin 3 yo'l → 2 · 3 = 6.</li><li>Kubda qarama-qarshi uchga — 3 qirra.</li></ul></div>",
 tn:"Keyingi darsni «Uydan maktabgacha qaysi yo'lingiz eng qisqa?» savoli bilan boshlang."}
];
function hCMaze(show){clear();var g=S.g;var L={A:[[20,30],[120,30],[120,70],[60,70],[60,125]],B:[[20,145],[100,145],[100,100],[150,100],[150,40],[215,40]],C:[[340,145],[260,145],[260,112],[205,112],[205,88],[185,88]],D:[[340,30],[285,30],[285,78],[235,78],[235,58]]};
 Object.keys(L).forEach(function(k){var on=show&&k==='C';E('polyline',{points:L[k].map(function(p){return p.join(',')}).join(' '),fill:'none',stroke:on?C.ok:'#8a6a45','stroke-width':on?6:5,'stroke-linejoin':'round','stroke-linecap':'round'},g);var e=L[k][L[k].length-1];if(k!=='C')T(g,e[0],e[1]+5,'✗',{'font-size':show?14:0,fill:C.bad,'font-weight':800});var s0=L[k][0];T(g,s0[0]+(s0[0]<100?-10:10),s0[1]+5,k,{'font-size':14,'font-weight':800,fill:C.blue})});
 T(g,175,95,'⭐',{'font-size':20});hCMsg(show?'Xazinadan orqaga: yagona yo‘l — <b>C</b> kirishiga, qolganlari boshi berk':'Qaysi kirish xazinaga olib boradi?')}
function hCTree(k){clear();var g=S.g;function nd(x,y,t){E('circle',{cx:x,cy:y,r:14,fill:'#fff',stroke:C.line,'stroke-width':1.5},g);T(g,x,y+5,t,{'font-size':13})}
 nd(40,90,'🏠');var n=0;[[150,50],[150,130]].forEach(function(m,i){if(k>=1){E('line',{x1:54,y1:90,x2:m[0]-14,y2:m[1],stroke:i?C.c:C.b,'stroke-width':3},g)}nd(m[0],m[1],'🏫');if(k>=2)[-28,0,28].forEach(function(d){E('line',{x1:m[0]+14,y1:m[1],x2:290,y2:m[1]+d*.7,stroke:i?C.c:C.b,'stroke-width':2.5},g);nd(304,m[1]+d*.7,'📚');n++})});
 hCMsg(k===0?'Uydan maktabga 2 yo‘l':(k===1?'2 xil yo‘l — ko‘k va pushti':'Har biridan 3 tadan: 3 + 3 = 2 · 3 = <b>6</b>'))}
function hCCube(on){var P=function(x,y,z){return [180+(x-y)*60*.87,100-z*60+(x+y)*60*.5]};clear();var g=S.g;var V={};[0,1].forEach(function(x){[0,1].forEach(function(y){[0,1].forEach(function(z){V[''+x+y+z]=P(x,y,z)})})});
 Object.keys(V).forEach(function(a){Object.keys(V).forEach(function(b){var d=0;for(var i=0;i<3;i++)if(a[i]!==b[i])d++;if(d===1&&a<b)E('line',{x1:V[a][0],y1:V[a][1],x2:V[b][0],y2:V[b][1],stroke:'#9aa8b6','stroke-width':2.5},g)})});
 if(on){var pth=['001','101','111','110'].map(function(k){return V[k]});E('polyline',{points:pth.map(function(p){return p.join(',')}).join(' '),fill:'none',stroke:C.ok,'stroke-width':5},g)}
 T(g,V['001'][0],V['001'][1]-8,'🐜',{'font-size':16});E('circle',{cx:V['110'][0],cy:V['110'][1],r:7,fill:C.bad},g);hCMsg(on?'1 → 2 → 3: <b>3 ta qirra</b>':'Chumolidan qizil nuqtagacha')}
var PROBS=[
{t:"Robot: 3 → , 2 ↑ , 1 ← , 4 ↓. Boshlang'ich joyga nisbatan qayerda?",o:["2 o'ngda, 2 pastda","2 o'ngda, 2 yuqorida","4 o'ngda, 6 pastda","1 o'ngda, 2 pastda"],k:0,s:"3 − 1 = 2 o'ngda; 4 − 2 = 2 pastda."},
{t:"Robot: ↑ ↑ → → ↓ →. Qayerda?",o:["3 o'ngda, 1 yuqorida","3 o'ngda, 3 yuqorida","2 o'ngda, 1 yuqorida","1 o'ngda, 3 yuqorida"],k:0,s:"O'ngga 3; yuqori 2 − 1 = 1."},
{t:"Robot: → → ↑ ← ↑ →. Necha katak o'ngda?",o:["2","3","4","1"],k:0,s:"O'ngga 3, chapga 1: 2."},
{t:"Robot 5 katak o'ngga, keyin 5 katak chapga yurdi. U qayerda?",o:["boshlang'ich joyda","10 katak o'ngda","5 katak chapda","5 katak o'ngda"],k:0,s:"5 − 5 = 0."},
{t:"Uydan maktabga 2 yo'l, maktabdan kutubxonaga 3 yo'l. Uydan maktab orqali kutubxonaga necha xil yo'l?",o:["6","5","3","2"],k:0,s:"2 · 3 = 6."},
{t:"Faqat o'ngga va yuqoriga yurib, 2 × 2 to'rda A dan B ga nechta yo'l?",o:["6","4","5","8"],k:0,s:"Chorrahalarda: 1, 2, 3 → B ga 6."},
{t:"Faqat o'ngga va yuqoriga: o'ngga 2, yuqoriga 1 katak. Nechta yo'l?",o:["3","2","4","6"],k:0,s:"→→↑, →↑→, ↑→→."},
{t:"Chumoli kubning bir uchidan qarama-qarshi uchiga qirralar bo'ylab eng kami nechta qirra o'tadi?",o:["3","2","4","12"],k:0,s:"3 yo'nalish — 3 qirra."},
{t:"1-yo'l: 4 + 5 km, 2-yo'l: 3 + 3 + 2 km. Qaysi qisqa va qanchaga?",o:["2-yo'l, 1 km","1-yo'l, 1 km","2-yo'l, 2 km","teng"],k:0,s:"9 va 8 km."},
{t:"Uy → A: 3 km, A → Maktab: 6 km; Uy → B: 2 km, B → C: 3 km, C → Maktab: 2 km. Eng qisqa yo'l?",o:["7 km","9 km","5 km","11 km"],k:0,s:"Uy → B → C → Maktab: 7 km."},
{t:"Buxoro → Samarqand 3 avtobus; Samarqand → Toshkent 2 avtobus va 2 samolyot. Necha usul?",o:["12","7","5","4"],k:0,s:"3 · 4 = 12."},
{t:"Robot 4 katak yuqoriga, 2 katak o'ngga, 4 katak pastga yurdi. Qayerda?",o:["2 o'ngda","4 yuqorida","2 chapda","boshlang'ich joyda"],k:0,s:"Yuqori va past teng — faqat 2 o'ngda."},
{t:"Robot 3 o'ngga, 2 pastga, 3 chapga, 2 yuqoriga yurdi. Necha qadam yurdi?",o:["10","0","5","6"],k:0,s:"3 + 2 + 3 + 2 = 10 (joyiga qaytdi)."},
{t:"Kvadratning bir uchidan qarama-qarshi uchiga tomonlar bo'ylab eng kami nechta tomon?",o:["2","1","3","4"],k:0,s:"Eni va bo'yi — 2."},
{t:"Oshxonada 3 xil sho'rva va 2 xil salat. Bitta sho'rva va bitta salat necha xil tanlanadi?",o:["6","5","3","9"],k:0,s:"3 · 2 = 6."},
{t:"Labirintda xazinaga yo'l topishning eng tez usuli?",o:["xazinadan orqaga yurish","tasodifiy yurish","eng uzun yo'lni tanlash","har yo'lni bir xil tezlikda"],k:0,s:"Oxiridan yechish."},
{t:"Robot buyruqlari: → ↑ → ↑ → ↑. Boshlang'ich joydan necha katak o'ngda va yuqorida?",o:["3 o'ngda, 3 yuqorida","6 o'ngda","3 o'ngda","2 o'ngda, 4 yuqorida"],k:0,s:"Har biridan 3 tadan."},
{t:"Bir uydan ikkinchisiga to'g'ri yo'l 5 km, aylanma yo'l 2 km + 2 km + 2 km. To'g'ri yo'l qanchaga qisqa?",o:["1 km","2 km","3 km","teng"],k:0,s:"6 − 5 = 1 km."},
{t:"Robot (5;3) katakda. U 2 o'ngga va 1 pastga yursa, ustun va qator raqami qanday bo'ladi (pastga qator ortadi)?",o:["(7;4)","(3;2)","(7;2)","(6;4)"],k:0,s:"Ustun 5 + 2 = 7, qator 3 + 1 = 4."},
{t:"Faqat o'ngga va yuqoriga: o'ngga 3, yuqoriga 1. Nechta yo'l?",o:["4","3","6","5"],k:0,s:"↑ ni 4 joyning biriga qo'yamiz: 4 ta."}
];
function PRACT_STAGE(){hCField({start:[2,3],bot:[2,3]});hCMsg('Qoralama maydon')}
var PREP_DATA={teach:["Katakli maydonda buyruqlar bilan yurish (algoritm).","Buyruqlar natijasi: qarama-qarshi yo'nalishlarni ayirish.","Eng qisqa yo'lni hisoblab topish; labirintni oxiridan yechish.","Yo'llar soni: «chap + past» qoidasi; ketma-ket tanlovlar ko'paytmasi."],
 mist:["Qarama-qarshi yo'nalishlarni qo'shib yuboradi.","Ko'rinishidan qisqa yo'lni hisoblamasdan tanlaydi.","Ketma-ket tanlovlarni qo'shadi (2 + 3) — ko'paytirish kerak.","«Faqat → ↑» masalasida yo'llarni tartibsiz sanab, takrorlaydi."],
 need:["Polda bo'r bilan katak.","Strelkali kartochkalar, gazeta labirintlari."],
 board:["<span class='w2'>→→→ ↑↑ ← ↓↓↓↓</span> → 2 o'ngda, 2 pastda.","Graf: yo'llar va km — hammasini hisoblang.","To'r: 1 1 1 / 1 2 3 / 1 3 6.","Daraxt: 2 tarmoq × 3 tarmoq = 6."]};
