var CODE='2F4',TITLE='2-sinf · Uchburchak, to‘rtburchak, kvadrat';
function f4_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4_ra(x,y,dx,dy,col){E('path',{d:'M'+(x+dx*11)+' '+y+' L'+(x+dx*11)+' '+(y+dy*11)+' L'+x+' '+(y+dy*11),fill:'none',stroke:col||C.bad,'stroke-width':2},S.g)}
function f4_tick(x1,y1,x2,y2,n,col){var mx=(x1+x2)/2,my=(y1+y2)/2,dx=x2-x1,dy=y2-y1,L=Math.sqrt(dx*dx+dy*dy),nx=-dy/L*6,ny=dx/L*6,tx=dx/L*3,ty=dy/L*3;for(var i=0;i<n;i++){var o=(i-(n-1)/2);E('line',{x1:mx+o*tx*2-nx,y1:my+o*ty*2-ny,x2:mx+o*tx*2+nx,y2:my+o*ty*2+ny,stroke:col||C.a2,'stroke-width':2},S.g)}}
function f4_poly(pts,fill,stroke){E('polygon',{points:pts.map(function(p){return p.join(',')}).join(' '),fill:fill||'#e8f1fb',stroke:stroke||C.blue,'stroke-width':3,'stroke-linejoin':'round'},S.g)}
function f4_pts(pts,labs){pts.forEach(function(p,i){E('circle',{cx:p[0],cy:p[1],r:4.5,fill:C.bad},S.g);if(labs)T(S.g,p[0]+(p[0]<180?-12:12),p[1]+(p[1]<90?-6:16),labs[i],{'font-size':13,'font-weight':800,fill:C.bad})})}
// to'rtburchak turlari
function f4_kind(k){clear();var names=['ixtiyoriy to‘rtburchak','to‘g‘ri to‘rtburchak','kvadrat','romb'];
 if(k===0){var p=[[90,140],[120,40],[270,60],[290,150]];f4_poly(p);f4_pts(p,['A','B','C','D']);f4_msg('<b>To‘rtburchak</b>: 4 tomon, 4 burchak, 4 uch. Tomonlari ham, burchaklari ham har xil bo‘lishi mumkin')}
 if(k===1){var p=[[70,45],[290,45],[290,135],[70,135]];f4_poly(p);f4_ra(70,45,1,1);f4_ra(290,45,-1,1);f4_ra(290,135,-1,-1);f4_ra(70,135,1,-1);f4_tick(70,45,290,45,1);f4_tick(70,135,290,135,1);f4_tick(70,45,70,135,2);f4_tick(290,45,290,135,2);f4_pts(p,['A','B','C','D']);f4_msg('<b>To‘g‘ri to‘rtburchak</b>: 4 ta burchagi <b>to‘g‘ri</b>, qarama-qarshi tomonlari <b>teng</b>')}
 if(k===2){var p=[[130,35],[230,35],[230,135],[130,135]];f4_poly(p,'#e6f6ee',C.ok);f4_ra(130,35,1,1);f4_ra(230,35,-1,1);f4_ra(230,135,-1,-1);f4_ra(130,135,1,-1);f4_tick(130,35,230,35,1);f4_tick(130,135,230,135,1);f4_tick(130,35,130,135,1);f4_tick(230,35,230,135,1);f4_pts(p,['A','B','C','D']);f4_msg('<b>Kvadrat</b>: 4 ta burchagi to‘g‘ri va <b>hamma tomonlari teng</b>')}
 if(k===3){var p=[[180,25],[270,88],[180,151],[90,88]];f4_poly(p,'#fdf0e1',C.a2);f4_tick(180,25,270,88,1);f4_tick(270,88,180,151,1);f4_tick(180,151,90,88,1);f4_tick(90,88,180,25,1);f4_pts(p);f4_msg('<b>Romb</b>: hamma tomonlari teng, lekin burchaklari to‘g‘ri <b>emas</b> (qiyshaygan kvadrat)')}
 S.k=k}
function f4_count(k){clear();var x0=40,w=280,y0=50,h=70,cuts=[x0,x0+90,x0+190,x0+w];var g=S.g;
 E('rect',{x:x0,y:y0,width:w,height:h,fill:'#fff',stroke:'#1d2b3a','stroke-width':3},g);E('line',{x1:cuts[1],y1:y0,x2:cuts[1],y2:y0+h,stroke:'#1d2b3a','stroke-width':3},g);E('line',{x1:cuts[2],y1:y0,x2:cuts[2],y2:y0+h,stroke:'#1d2b3a','stroke-width':3},g);
 var list=[[0,1],[1,2],[2,3],[0,2],[1,3],[0,3]],labs=['1','2','3','1+2','2+3','1+2+3'];
 for(var i=0;i<k&&i<6;i++){var a=list[i],last=i===k-1;if(last)E('rect',{x:cuts[a[0]]+3,y:y0+3,width:cuts[a[1]]-cuts[a[0]]-6,height:h-6,fill:'rgba(217,75,75,.25)',stroke:C.bad,'stroke-width':3},g)}
 [0,1,2].forEach(function(i){T(g,(cuts[i]+cuts[i+1])/2,y0+h/2+6,String(i+1),{'font-size':18,'font-weight':800,fill:'#5b6b7b'})});
 T(g,180,150,labs.slice(0,k).join(',  '),{'font-size':13,'font-weight':800,fill:C.bad});
 f4_msg(k<6?'To‘rtburchaklarni sanaymiz: avval kichiklari, keyin qo‘shnilari… <b>'+k+'</b> ta':'Hammasi <b>6 ta</b>: kichik 3 ta + ikkitalik 2 ta + butun 1 ta')}
var F4_P7=[function(){f4_sides(0)},function(){f4_sides(1)},function(){f4_sides(2)}];
function f4_sides(k){clear();var g=S.g;var tri=[[[20,130],[60,60],[100,130]],[[110,130],[150,60],[190,130]],[[200,130],[240,60],[280,130]]];
 tri.forEach(function(t){f4_poly(t,'#e8f1fb',C.blue)});E('rect',{x:288,y:62,width:30,height:30,fill:'#fdf0e1',stroke:C.a2,'stroke-width':3},g);E('rect',{x:288,y:100,width:30,height:30,fill:'#fdf0e1',stroke:C.a2,'stroke-width':3},g);
 if(k>=1){T(g,60,150,'3',{'font-size':14,'font-weight':800,fill:C.blue});T(g,150,150,'3',{'font-size':14,'font-weight':800,fill:C.blue});T(g,240,150,'3',{'font-size':14,'font-weight':800,fill:C.blue});T(g,334,82,'4',{'font-size':14,'font-weight':800,fill:C.a2});T(g,334,120,'4',{'font-size':14,'font-weight':800,fill:C.a2})}
 f4_msg(k===0?'3 ta uchburchak va 2 ta to‘rtburchak. Jami nechta tomon?':(k===1?'Uchburchakda — 3 ta, to‘rtburchakda — 4 ta tomon':'3 + 3 + 3 + 4 + 4 = <b>17</b> ta tomon'))}
var STEPS=[
{h:"Uchburchakni o'zingiz yasang",sum:"Uchburchak — bir to'g'ri chiziqda yotmaydigan 3 ta nuqtani tutashtirsak hosil bo'ladi: 3 tomon, 3 burchak, 3 uch.",a:"m01",
 start:function(){clear();S.tp=[];f4_msg('Sahnada 3 ta nuqta qo‘ying');var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},S.g);r.addEventListener('click',function(ev){var b=sv.getBoundingClientRect(),x=(ev.clientX-b.left)*360/b.width,y=(ev.clientY-b.top)*174/b.height;if(S.tp.length>=3)return;S.tp.push([x,y]);if(S.tp.length===3){f4_poly(S.tp);f4_pts(S.tp,['A','B','C']);f4_msg('<b>Uchburchak ABC</b>: 3 tomon, 3 burchak, 3 uch');if(S.d1)S.d1()}else f4_pts(S.tp)})},
 fin:function(){clear();var p=[[80,140],[170,30],[290,130]];f4_poly(p);f4_pts(p,['A','B','C']);f4_msg('<b>Uchburchak ABC</b>: 3 tomon, 3 burchak, 3 uch')},
 html:"<p>Sahnada istalgan <b>3 ta nuqta</b> qo'ying — ular o'zi tutashadi. Nima hosil bo'ladi?</p>",
 act:function(c,done){S.d1=function(){S.d1=null;done()};c.querySelector('.hint').textContent='Sahnani 3 marta bosing.'},
 after:"<p>Hosil bo'ldi <b>uchburchak</b>: uning <b>3 ta tomoni</b>, <b>3 ta burchagi</b> va <b>3 ta uchi</b> bor. Nomi uchlari bo'yicha: <b>ABC</b>. Faqat nuqtalar bir to'g'ri chiziqda yotmasligi kerak — aks holda uchburchak chiqmaydi.</p>",
 q:{t:"Uchburchak va to'rtburchakning birgalikda nechta uchi bor?",opts:["7","8","12","6"],ok:0,why:"3 + 4 = 7.",hint:"Uchburchakning uchlari nechta? To'rtburchakniki-chi?",full:"Uchburchakda 3 ta, to'rtburchakda 4 ta uch: 3 + 4 = 7. Nomi o'zi aytib turibdi: «uch-burchak», «to'rt-burchak»."},
 tn:"Bolalar 3 ta cho'p bilan uchburchak, 4 ta cho'p bilan to'rtburchak yasasin. Nomi burchaklar sonidan kelishini ta'kidlang."},
{h:"To'rtburchaklar oilasi",sum:"To'rtburchak → to'g'ri to'rtburchak (4 to'g'ri burchak) → kvadrat (+ hamma tomonlari teng). Romb — tomonlari teng, burchaklari to'g'ri emas.",a:"m02",
 start:function(){f4_kind(0)},fin:function(){f4_kind(2)},
 html:"<p>To'rtburchaklar har xil bo'ladi. Tugmalarni bosib, har birining <b>burchaklari</b> (qizil kvadratcha — to'g'ri burchak) va <b>tomonlariga</b> (bir xil chiziqcha — teng tomonlar) qarang.</p>",
 btns:[["To'rtburchak",function(c,done){f4_kind(0);mvK(done,3)}],["To'g'ri to'rtburchak",function(c,done){f4_kind(1);mvK(done,3)}],["Kvadrat",function(c,done){f4_kind(2);mvK(done,3)},'u'],["Romb",function(c,done){f4_kind(3);mvK(done,3)},'u']],g2:1,
 after:"<div class='life'><div>▭<span><b>To'g'ri to'rtburchak</b>: 4 ta to'g'ri burchak, qarama-qarshi tomonlar teng</span></div><div>◻<span><b>Kvadrat</b>: 4 ta to'g'ri burchak va <b>4 ta teng</b> tomon</span></div><div>◇<span><b>Romb</b>: 4 ta teng tomon, burchaklar to'g'ri emas</span></div></div>",
 q:{t:"Qaysi gap to'g'ri?",opts:["Har bir to'g'ri to'rtburchak kvadrat bo'ladi","Kvadratning burchaklari o'tkir","Kvadrat — hamma tomonlari teng bo'lgan to'g'ri to'rtburchak","Kvadrat to'g'ri to'rtburchak emas"],ok:2,why:"Kvadrat — to'g'ri to'rtburchakning alohida turi: tomonlari ham teng.",hint:"Kvadratda nechta to'g'ri burchak bor? Tomonlari qanday?",full:"Kvadratda 4 ta to'g'ri burchak bor — demak u to'g'ri to'rtburchak. Faqat uning hamma tomonlari teng. Lekin har to'g'ri to'rtburchak kvadrat emas: bo'yi va eni har xil bo'lishi mumkin."},
 tn:"Doskada «oila daraxti» chizing: To'rtburchak → To'g'ri to'rtburchak → Kvadrat. Bolalar sinfdan har biriga misol topsin."},
{h:"To'g'ri to'rtburchakning xossalari",sum:"Qarama-qarshi tomonlar teng; 4 ta burchak to'g'ri. Bo'yi 6 sm, eni 3 sm bo'lsa: 6, 3, 6, 3.",a:"m03",
 start:function(){f4_rect(0)},fin:function(){f4_rect(2)},
 html:"<p>To'g'ri to'rtburchakning tomonlarini chizg'ich bilan, burchaklarini andoza bilan tekshiramiz. Tugmalarni bosing.</p>",
 btns:[["📏 Tomonlarni o'lchash",function(c,done){f4_rect(1);mvK(done,2)}],["📐 Burchaklarni tekshirish",function(c,done){f4_rect(2);mvK(done,2)}]],g2:1,
 after:"<p>To'g'ri to'rtburchakda <b>qarama-qarshi tomonlar teng</b>: ikkita uzun (<b>bo'yi</b>) va ikkita qisqa (<b>eni</b>). Burchaklarning <b>hammasi</b> to'g'ri.</p>",
 q:{t:"To'g'ri to'rtburchakning bo'yi 8 sm, eni 5 sm. Uning tomonlari qanday?",opts:["8, 5, 8, 5 sm","8, 5, 5, 5 sm","8, 8, 8, 8 sm","8 va 5 sm — 2 ta tomon"],ok:0,why:"Qarama-qarshi tomonlar teng: ikkita 8 sm, ikkita 5 sm.",hint:"To'g'ri to'rtburchakning nechta tomoni bor? Qaysilari teng?",full:"To'g'ri to'rtburchakning 4 ta tomoni bor, qarama-qarshilari teng: bo'yi 8 sm ikkita, eni 5 sm ikkita."},
 tn:"Daftar varag'ini o'lchatib ko'ring: qarama-qarshi tomonlar teng ekanini bolalar o'zi aniqlasin."},
{h:"Katakli qog'ozda to'g'ri burchak",sum:"Katak chiziqlari bo'ylab chizilgan burchak — doim to'g'ri burchak. Shu yo'l bilan to'g'ri to'rtburchak va kvadrat chiziladi.",a:"m04",
 start:function(){S.cd=0;f4_draw(0)},fin:function(){f4_draw(4)},
 html:"<p>Katakli qog'ozda to'g'ri to'rtburchak chizamiz: 6 katak o'ngga, 3 katak pastga, 6 katak chapga, 3 katak yuqoriga. Tugmani bosing.</p>",
 btns:[["✏️ Keyingi tomon",function(c,done,b){if(S.cd<4){S.cd++;f4_draw(S.cd)}if(S.cd===4){b.disabled=true;done()}}]],
 after:"<p>Katak chiziqlari bir-biriga <b>to'g'ri burchak</b> ostida kesishadi. Shuning uchun katak bo'ylab burilsak — doim to'g'ri burchak chiqadi. Kvadrat chizish uchun hamma tomonni bir xil katak qiling: 4, 4, 4, 4.</p>",
 q:{t:"Katakli qog'ozda kvadrat chizmoqchisiz, bir tomoni 5 katak. Qolgan tomonlari necha katak bo'ladi?",opts:["5, 5, 5","5, 3, 5","10, 10, 10","4, 4, 4"],ok:0,why:"Kvadratning hamma tomonlari teng.",hint:"Kvadratda tomonlar qanday bo'ladi?",full:"Kvadratda 4 ta tomon teng: hammasi 5 katakdan. «5, 3, 5» — bu to'g'ri to'rtburchak bo'lardi, kvadrat emas."},
 tn:"Bolalar daftarda bo'yi 6, eni 3 katakli to'g'ri to'rtburchak va tomoni 4 katakli kvadrat chizsin, to'g'ri burchaklarni belgilasin."},
{h:"Tuzoq: nechta to'rtburchak bor?",sum:"3 qismga bo'lingan to'rtburchakda: 3 ta kichik + 2 ta ikkitalik + 1 ta butun = 6 ta.",a:"m05",
 start:function(){S.ck=0;f4_count(0)},fin:function(){f4_count(6)},
 html:"<p>To'g'ri to'rtburchak 3 bo'lakka bo'lingan. Unda nechta to'rtburchak bor? Ko'pchilik «3 ta» deydi. Tugmani bosib, hammasini toping.</p>",
 btns:[["🔍 Keyingisini topish",function(c,done,b){if(S.ck<6){S.ck++;f4_count(S.ck)}if(S.ck===6){b.disabled=true;done()}}]],
 after:"<p>Kichik to'rtburchaklar <b>birlashib</b>, katta to'rtburchaklar ham hosil qiladi. Tartibli sanash: <b>1 bo'lakli</b> — 3 ta, <b>2 bo'lakli</b> — 2 ta, <b>3 bo'lakli</b> — 1 ta: 3 + 2 + 1 = <b>6</b>.</p>",
 q:{t:"To'g'ri to'rtburchak bitta chiziq bilan 2 bo'lakka bo'lindi. Rasmda nechta to'rtburchak bor?",opts:["2","3","4","1"],ok:1,why:"2 ta kichik + 1 ta butun = 3.",hint:"Kichiklaridan tashqari, butun shaklni ham sanadingizmi?",full:"Ikkita kichik to'rtburchak va ular birga — butun to'rtburchak: 2 + 1 = 3. «2» — butun shakl sanalmagan."},
 tn:"Bu — kesmalarni sanashdagi 3 + 2 + 1 qoidasining o'zi! Bolalar o'xshashlikni o'zi topsin."},
{h:"Tuzoq: jami nechta tomon?",sum:"3 ta uchburchak va 2 ta to'rtburchak: 3 + 3 + 3 + 4 + 4 = 17 ta tomon.",a:"m06",
 start:function(){startPh(F4_P7)},fin:function(){S.ph=2;F4_P7[2]()},
 html:"<p>«3 ta uchburchak va 2 ta to'rtburchakning jami nechta tomoni bor?» — shakllar sonini emas, tomonlarini sanaymiz! Kuzating.</p>",
 btns:[phaser(F4_P7)],
 after:"<p>Shakllar 5 ta, lekin tomonlar <b>17 ta</b>. Har bir shakl uchun alohida sanab, keyin qo'shing: uchburchak — 3, to'rtburchak — 4.</p>",
 q:{t:"2 ta uchburchak va 3 ta kvadratning jami nechta burchagi bor?",opts:["5","18","12","15"],ok:1,why:"3 + 3 + 4 + 4 + 4 = 18.",hint:"Har uchburchakda nechta burchak? Har kvadratda-chi?",full:"Uchburchaklar: 3 + 3 = 6 burchak. Kvadratlar: 4 + 4 + 4 = 12 burchak. Jami 6 + 12 = 18. «5» — shakllar soni sanalgan."},
 tn:"Bolalar har shakl yoniga tomonlar sonini yozib, keyin qo'shsin."},
{h:"Bilasizmi? Eng mustahkam shakl",sum:"Uchburchak — eng mustahkam shakl: uni bosib qiyshaytirib bo'lmaydi. Ko'priklar va minoralar uchburchaklardan quriladi.",a:"m07",
 start:function(){f4_strong(0)},fin:function(){f4_strong(2)},
 html:"<p>🌉 Ko'priklar, minoralar, kranlar — ularning temir qismlari ko'pincha <b>uchburchak</b> shaklida. Nega? Tugmalar bilan tekshiring: shaklni yon tomondan bosamiz.</p>",
 btns:[["To'rtburchakni bosish",function(c,done){f4_strong(1);mvK(done,2)}],["Uchburchakni bosish",function(c,done){f4_strong(2);mvK(done,2)}]],g2:1,
 after:"<p>To'rtburchak bosilsa — <b>qiyshayib</b> ketadi. Uchburchak esa shaklini <b>saqlaydi</b>: uch tomoni uzunligi o'zgarmasa, uni boshqa shaklga keltirib bo'lmaydi. Shuning uchun Parijdagi mashhur Eyfel minorasi ham minglab uchburchaklardan iborat.</p>",
 tn:"Cho'p va plastilindan to'rtburchak va uchburchak yasab, bolalar o'zi bosib ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){f4_kind(1)},fin:function(){f4_kind(1)},
 html:"<div class='memo'><ul><li><b>Uchburchak</b> — 3 tomon, 3 burchak, 3 uch. <b>To'rtburchak</b> — 4 tomon, 4 burchak, 4 uch.</li><li><b>To'g'ri to'rtburchak</b>: 4 ta to'g'ri burchak, qarama-qarshi tomonlar teng (bo'yi va eni).</li><li><b>Kvadrat</b>: 4 ta to'g'ri burchak va hamma tomonlari teng. Kvadrat ham to'g'ri to'rtburchak!</li><li>Katak bo'ylab burilish — to'g'ri burchak.</li><li>Shakllarni sanash: kichiklari + birlashganlari (3 + 2 + 1).</li><li>Jami tomonlar: har shaklnikini alohida qo'shing.</li></ul></div>",
 tn:"Keyingi darsni «Daftar varag'i qanday shakl? Uning tomonlari qanday?» savoli bilan boshlang."}
];
function f4_rect(k){clear();var p=[[60,40],[300,40],[300,130],[60,130]];f4_poly(p);if(k>=1){T(S.g,180,32,'8 sm',{'font-size':13,'font-weight':800,fill:C.ok});T(S.g,180,150,'8 sm',{'font-size':13,'font-weight':800,fill:C.ok});T(S.g,40,90,'5 sm',{'font-size':13,'font-weight':800,fill:C.a2});T(S.g,322,90,'5 sm',{'font-size':13,'font-weight':800,fill:C.a2})}
 if(k>=2){f4_ra(60,40,1,1);f4_ra(300,40,-1,1);f4_ra(300,130,-1,-1);f4_ra(60,130,1,-1)}
 f4_msg(k===0?'To‘g‘ri to‘rtburchak ABCD':(k===1?'Qarama-qarshi tomonlar <b>teng</b>: 8 va 8, 5 va 5':'Tomonlar 8, 5, 8, 5 sm; hamma burchaklar <b>to‘g‘ri</b>'))}
function f4_draw(k){clear();var g=S.g;for(var x=20;x<=340;x+=20)E('line',{x1:x,y1:10,x2:x,y2:170,stroke:'#e3e9f0'},g);for(var y=10;y<=170;y+=20)E('line',{x1:20,y1:y,x2:340,y2:y,stroke:'#e3e9f0'},g);
 var P=[[100,50],[220,50],[220,110],[100,110],[100,50]];for(var i=0;i<k;i++)E('line',{x1:P[i][0],y1:P[i][1],x2:P[i+1][0],y2:P[i+1][1],stroke:C.blue,'stroke-width':3.5,'stroke-linecap':'round'},g);
 if(k>=2)f4_ra(220,50,-1,1);if(k>=3)f4_ra(220,110,-1,-1);if(k>=4){f4_ra(100,110,1,-1);f4_ra(100,50,1,1)}
 var t=['6 katak o‘ngga','3 katak pastga','6 katak chapga','3 katak yuqoriga'];f4_msg(k===0?'Boshlang‘ich nuqta tanlandi':(k<4?t[k-1]+' ✓':'Tayyor: to‘g‘ri to‘rtburchak, 4 ta to‘g‘ri burchak'))}
function f4_strong(k){clear();var g=S.g;if(k===1)f4_poly([[40,130],[80,50],[170,50],[130,130]],'#fdeaea',C.bad);else f4_poly([[40,130],[40,50],[130,50],[130,130]],'#e8f1fb',C.blue);
 f4_poly([[210,130],[265,45],[320,130]],k===2?'#e6f6ee':'#e8f1fb',k===2?C.ok:C.blue);
 if(k===1)T(g,90,155,'qiyshaydi!',{'font-size':12,'font-weight':800,fill:C.bad});if(k===2)T(g,265,155,'shaklini saqladi ✓',{'font-size':12,'font-weight':800,fill:C.ok});
 f4_msg(k===0?'Ikkala shaklni yon tomondan bosib ko‘ramiz':(k===1?'To‘rtburchak <b>qiyshaydi</b> — burchaklari o‘zgardi':'Uchburchak <b>o‘zgarmadi</b> — u eng mustahkam shakl'))}
var PROBS=[
{t:"Uchburchakning nechta burchagi bor?",o:["3","4","2","6"],k:0,s:"Uch-burchak — 3 ta burchak."},
{t:"Uchburchak va to'rtburchakning birgalikda nechta uchi bor?",o:["7","8","12","6"],k:0,s:"3 + 4 = 7."},
{t:"Uchta uchburchak va ikkita to'rtburchakning jami nechta tomoni bor?",o:["17","5","15","20"],k:0,s:"3 + 3 + 3 + 4 + 4 = 17."},
{t:"Qaysi gap to'g'ri?",o:["kvadrat — hamma tomonlari teng bo'lgan to'g'ri to'rtburchak","har bir to'g'ri to'rtburchak kvadrat","kvadratning burchaklari o'tkir","kvadrat to'g'ri to'rtburchak emas"],k:0,s:"Kvadratda 4 ta to'g'ri burchak va teng tomonlar bor."},
{t:"Uchburchakning uchala tomoni ham 4 sm. Bunday uchburchak qanday ataladi?",o:["teng tomonli uchburchak","to'g'ri burchakli uchburchak","kvadrat","to'rtburchak"],k:0,s:"Hamma tomonlari teng — teng tomonli uchburchak."},
{t:"Ikkita bir xil uchburchakdan qaysi shaklni yasab bo'lmaydi?",o:["doira","kvadrat","katta uchburchak","to'rtburchak"],k:0,s:"Uchburchaklarning tomonlari to'g'ri — doira hosil bo'lmaydi."},
{t:"To'g'ri to'rtburchakning bo'yi 7 sm, eni 4 sm. Qarama-qarshi tomonlar qanday?",o:["7 va 7, 4 va 4","7 va 4","7, 4, 4, 4","hammasi 7"],k:0,s:"To'g'ri to'rtburchakda qarama-qarshi tomonlar teng."},
{t:"Kvadratning bir tomoni 6 sm. Qolgan tomonlari qanday?",o:["6, 6, 6 sm","6, 3, 6 sm","12, 12, 12 sm","3, 3, 3 sm"],k:0,s:"Kvadratda hamma tomonlar teng."},
{t:"To'g'ri to'rtburchak bitta chiziq bilan 2 bo'lakka bo'lindi. Rasmda nechta to'rtburchak bor?",o:["3","2","4","1"],k:0,s:"2 ta kichik + 1 ta butun = 3."},
{t:"To'g'ri to'rtburchak ikki chiziq bilan 3 ta teng bo'lakka bo'lindi (yonma-yon). Nechta to'rtburchak bor?",o:["6","3","4","5"],k:0,s:"3 + 2 + 1 = 6."},
{t:"2 ta uchburchak va 3 ta kvadratning jami nechta burchagi bor?",o:["18","5","12","15"],k:0,s:"3 + 3 + 4 + 4 + 4 = 18."},
{t:"Romb bilan kvadratning farqi nimada?",o:["rombning burchaklari to'g'ri emas","rombning tomonlari teng emas","rombda 3 ta tomon bor","farqi yo'q"],k:0,s:"Ikkalasining tomonlari teng, lekin kvadratda burchaklar to'g'ri."},
{t:"Qaysi shaklda 4 ta to'g'ri burchak bor, lekin tomonlari teng emas?",o:["to'g'ri to'rtburchak (kvadrat emas)","kvadrat","romb","uchburchak"],k:0,s:"Bo'yi va eni har xil to'g'ri to'rtburchak."},
{t:"Bir to'g'ri chiziqda yotadigan 3 ta nuqtani tutashtirsak, uchburchak hosil bo'ladimi?",o:["yo'q, kesma hosil bo'ladi","ha","faqat kichik uchburchak","to'rtburchak hosil bo'ladi"],k:0,s:"Bir chiziqdagi nuqtalar tutashsa — kesma chiqadi."},
{t:"4 ta cho'p bilan qaysi shaklni yasash mumkin?",o:["kvadrat","uchburchak","beshburchak","doira"],k:0,s:"4 ta teng cho'p — kvadrat (4 tomon)."},
{t:"Kvadrat diagonal bo'yicha kesildi. Qanday shakllar hosil bo'ldi?",o:["2 ta uchburchak","2 ta kvadrat","2 ta to'g'ri to'rtburchak","4 ta uchburchak"],k:0,s:"Diagonal kvadratni ikkita uchburchakka bo'ladi."},
{t:"Kvadrat o'rtasidan (tomoniga parallel) kesildi. Qanday shakllar hosil bo'ldi?",o:["2 ta to'g'ri to'rtburchak","2 ta kvadrat","2 ta uchburchak","2 ta romb"],k:0,s:"Bo'laklarning burchaklari to'g'ri, lekin bo'yi enidan 2 marta uzun — to'g'ri to'rtburchaklar."},
{t:"5 ta uchburchakning jami nechta tomoni bor?",o:["15","5","8","20"],k:0,s:"3 + 3 + 3 + 3 + 3 = 15."},
{t:"Shakllar to'plamida 2 ta uchburchak va bir nechta to'rtburchak bor, jami 18 ta uch. To'rtburchaklar nechta?",o:["3","4","2","5"],k:0,s:"Uchburchaklarda 3 + 3 = 6 uch. Qolgan 18 − 6 = 12 uch: 4 + 4 + 4 — 3 ta to'rtburchak."},
{t:"Katakli qog'ozda bo'yi 6 katak, eni 2 katak bo'lgan to'g'ri to'rtburchak chizildi. Uning tomonlari necha katak?",o:["6, 2, 6, 2","6, 6, 6, 6","6, 2, 2, 2","2, 2, 2, 2"],k:0,s:"Qarama-qarshi tomonlar teng: 6 va 6, 2 va 2."}
];
function PRACT_STAGE(){f4_kind(1)}
var PREP_DATA={teach:["Uchburchak: tomonlar, burchaklar, uchlar; nomlanishi ABC.","To'rtburchak, to'g'ri to'rtburchak, kvadrat, romb — farqlari.","To'g'ri to'rtburchak xossalari: qarama-qarshi tomonlar teng, 4 to'g'ri burchak.","Katakli qog'ozda to'g'ri burchak va to'g'ri to'rtburchak chizish.","Tuzoqlar: shakllarni sanash, jami tomonlar/burchaklar."],
 mist:["Kvadratni to'g'ri to'rtburchak emas deb o'ylaydi.","Rombni kvadrat deb ataydi.","Shakllarni sanashda faqat kichiklarini sanaydi.","Tomonlar o'rniga shakllar sonini sanaydi."],
 need:["Cho'plar va plastilin.","Katakli qog'oz, chizg'ich, qog'oz to'g'ri burchak andozasi."],
 board:["Uchburchak ABC: 3 tomon, 3 burchak, 3 uch.","To'rtburchak → To'g'ri to'rtburchak → Kvadrat (oila).","To'g'ri to'rtburchak: <span class='w2'>8, 5, 8, 5 sm</span>.","Sanash: <span class='w2'>3 + 2 + 1 = 6</span>.","<span class='w2'>3 + 3 + 3 + 4 + 4 = 17</span> tomon."]};
