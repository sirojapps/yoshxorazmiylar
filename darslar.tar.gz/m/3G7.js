var CODE='3G7',TITLE='3-sinf · Yuz birliklari va ular orasidagi bog‘lanish';
// katta kvadratni qatorlab to'ldirish (10×10)
function g7Fill(rows,lab,unit,big){clear('#ffffff');var x0=110,y0=14,cs=14,g=S.g;
 for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs-1,height:cs-1,rx:1.5,fill:r<rows?(r%2?'#f0a040':'#f6c98a'):'#fff7ea',stroke:'#e6c9a0','stroke-width':.6},g);
 E('rect',{x:x0,y:y0,width:10*cs,height:10*cs,fill:'none',stroke:C.line,'stroke-width':2.2},g);
 T(g,x0+5*cs,y0+10*cs+14,big,{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-6,y0+5*cs+4,big,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 if(rows>0)for(var k=0;k<rows;k++)T(g,x0+10*cs+8,y0+k*cs+11,String((k+1)*10),{'font-size':9,'font-weight':800,fill:C.t1,'text-anchor':'start'});
 g3Msg(lab)}
var P2=[function(){g7Fill(0,'Kvadrat tomoni <b>1 dm = 10 sm</b>. Ichida nechta 1 sm² sig‘adi?','sm²','1 dm')},
 function(){g7Fill(1,'Bitta qatorda <b>10</b> ta sm²','sm²','1 dm')},
 function(){g7Fill(5,'5 qator: 5 · 10 = <b>50</b> sm²','sm²','1 dm')},
 function(){g7Fill(10,'10 qator: 10 · 10 = <b>100 sm²</b>. Demak <b>1 dm² = 100 sm²</b>','sm²','1 dm')}];
var P4=[function(){g7Fill(0,'Kvadrat tomoni <b>1 m = 10 dm</b>. Har bir katak — 1 dm²','dm²','1 m')},
 function(){g7Fill(10,'10 · 10 = <b>100 dm²</b> → <b>1 m² = 100 dm²</b>','dm²','1 m')},
 function(){g7Fill(10,'Har dm² da yana 100 sm²: 100 · 100 = <b>10 000 sm²</b>','dm²','1 m');T(S.g,330,90,'× 100',{'font-size':14,'font-weight':800,fill:C.bad})}];
var P5=[function(){clear('#ffffff');g3Rect(60,40,90,90,{fill:'#f6c98a',top:'1 sm',left:'1 sm',mid:'1 sm²'});g3Msg('1 sm² ni lupa bilan kattalashtiramiz')},
 function(){clear('#ffffff');var g=S.g,x0=200,y0=20,cs=13;for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs-1,height:cs-1,fill:(r+c)%2?'#f0a040':'#f6c98a'},g);E('rect',{x:x0,y:y0,width:130,height:130,fill:'none',stroke:C.line,'stroke-width':2},g);g3Rect(40,60,50,50,{fill:'#f6c98a',mid:'1 sm²',mfs:11});g3Line([90,60],[x0,y0],{d:'4 3',c:C.blue});g3Line([90,110],[x0,y0+130],{d:'4 3',c:C.blue});T(g,x0+65,y0+146,'1 sm = 10 mm',{'font-size':11,'font-weight':800,fill:C.blue});g3Msg('10 · 10 = <b>100 mm²</b> → <b>1 sm² = 100 mm²</b>')}];
var P7=[function(){clear('#f3fbe9');g3Rect(30,30,100,100,{fill:'#bfe3a6',stroke:'#3d8b2f',top:'10 m',left:'10 m',mid:'1 ar'});g3Msg('<b>1 ar</b> (xalq tilida «sotix») = 10 m × 10 m = <b>100 m²</b>')},
 function(){clear('#f3fbe9');var g=S.g,x0=180,y0=14,cs=14;for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs-1,height:cs-1,fill:'#bfe3a6',stroke:'#7fb86a','stroke-width':.5},g);E('rect',{x:x0,y:y0,width:140,height:140,fill:'none',stroke:'#3d8b2f','stroke-width':2.2},g);T(g,x0+70,y0+156,'100 m',{'font-size':11,'font-weight':800,fill:'#3d8b2f'});g3Rect(40,60,40,40,{fill:'#8cc96f',stroke:'#3d8b2f',mid:'1 ar',mfs:11});g3Msg('<b>1 gektar</b> = 100 m × 100 m = 100 ar = <b>10 000 m²</b>')}];
var STEPS=[
{h:"Kvadrat santimetr nima?",sum:"1 sm² — tomoni 1 sm bo'lgan kvadratning yuzi. Yuz — nechta shunday kvadrat sig'ishi.",a:"m01",
 start:function(){clear('#ffffff');g3Paper(20,20,10,16,8);g3Msg('Daftar katagi — 0,5 sm. Biz 1 sm × 1 sm kataklarni olamiz')},fin:function(){clear('#ffffff');g3Paper(20,20,10,16,8);g3Rect(60,30,120,80,{top:'6 sm',left:'4 sm',mid:'24 sm²'});g3Msg('6 · 4 = <b>24 sm²</b>')},
 html:"<p>Yuzni o'lchash uchun biror <b>kvadratcha</b> olib, shakl ichiga nechtasi sig'ishini sanaymiz. Tomoni <b>1 sm</b> bo'lgan kvadratning yuzi — <b>1 kvadrat santimetr</b> (1 sm²). Tugmani bosing.</p>",
 btns:[["▢ 1 sm² ni ko'rsat",function(c,done){clear('#ffffff');g3Paper(20,20,10,16,8);g3Rect(20,10,20,20,{fill:C.a,mid:''});T(S.g,52,26,'1 sm²',{'font-size':12,'font-weight':800,fill:C.t1,'text-anchor':'start'});g3Msg('Bitta katak — <b>1 sm²</b>');mvK(done,2)}],["▭ 6 × 4 to'rtburchak",function(c,done){clear('#ffffff');g3Paper(20,20,10,16,8);g3Rect(60,30,120,80,{top:'6 sm',left:'4 sm',mid:'24 sm²'});g3Msg('Qatorda 6 ta, 4 qator: 6 · 4 = <b>24 sm²</b>');mvK(done,2)},'u']],g2:1,
 after:"<p>Yuz — shakl ichiga nechta <b>birlik kvadrat</b> sig'ishi. To'g'ri to'rtburchakda: bo'yi × eni. 6 sm × 4 sm = <b>24 sm²</b>.</p>",
 q:{t:"Tomoni 5 sm bo'lgan kvadratning yuzi qancha?",opts:["20 sm²","25 sm²","10 sm²","25 sm"],ok:1,why:"5 · 5 = 25 sm².",hint:"Kvadratda bo'yi ham, eni ham 5 sm. Yuz = bo'yi × eni.",full:"Kvadratning yuzi = tomon × tomon = 5 · 5 = 25 sm². «20 sm» — bu perimetr (5 · 4). «25 sm» — birligi noto'g'ri: yuz kvadrat birlikda o'lchanadi."},
 tn:"Bolalarga 1 sm × 1 sm qog'oz kvadratchalar qirqtiring va daftar varag'ini qoplatib ko'ring."},
{h:"1 dm² = 100 sm²",sum:"Tomoni 1 dm = 10 sm kvadrat ichiga 10 qator × 10 ta = 100 sm² sig'adi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Tomoni <b>1 dm</b> bo'lgan kvadrat — <b>1 dm²</b>. Uning ichiga nechta 1 sm² sig'adi? Qatorlab to'ldiring.</p>",
 btns:[phaser(P2,'▶ Qator qo‘sh')],
 after:"<p>1 dm = 10 sm, lekin <b>1 dm² = 100 sm²</b>, chunki 10 qatorning har birida 10 tadan. Yuz birliklari <b>100 barobardan</b> o'zgaradi!</p>",
 q:{t:"3 dm² necha sm²?",opts:["30 sm²","300 sm²","3 000 sm²","13 sm²"],ok:1,why:"1 dm² = 100 sm², 3 · 100 = 300.",hint:"1 dm² da nechta sm² bor edi — 10 tami yoki 100 tami?",full:"Har 1 dm² da 100 sm². 3 dm² = 3 · 100 = 300 sm². «30» — uzunlikdagi qoida (1 dm = 10 sm) adashib qo'llangan."},
 tn:"Bu — eng katta xato: bolalar «1 dm = 10 sm» ni yuzga ham qo'llaydi. 10×10 kvadratni doskaga chizib, kataklarini sanatib ko'rsating."},
{h:"Tuzoq: uzunlik va yuz",sum:"Uzunlik birliklari 10 barobardan, yuz birliklari 100 barobardan o'zgaradi: 1 dm = 10 sm, 1 dm² = 100 sm².",a:"m03",
 start:function(){clear('#ffffff');g3Rect(40,40,100,100,{fill:'#f6c98a',top:'1 dm = 10 sm',mid:'?'});g3Msg('Qaysi qoida qayerda? Tugmalarni bosing')},fin:function(){clear('#ffffff');g3Rect(40,40,100,100,{fill:'#f6c98a',top:'1 dm = 10 sm',mid:'100 sm²'});g3Msg('uzunlik: ×10 · yuz: ×100')},
 html:"<p>Bir xil kvadratda ikki xil o'lchov bor: <b>tomon uzunligi</b> va <b>yuzi</b>. Ikkalasini ko'ring:</p>",
 btns:[["📏 Tomoni",function(c,done){clear('#ffffff');g3Rect(40,40,100,100,{fill:'#fff7ea',top:'1 dm = 10 sm'});for(var i=0;i<=10;i++)g3Line([40+i*10,36],[40+i*10,44],{w:1.5,c:C.bad});g3Msg('Tomon bo‘ylab 10 ta santimetr: <b>1 dm = 10 sm</b> (×10)');mvK(done,2)}],["▦ Yuzi",function(c,done){g7Fill(10,'Ichida 100 ta sm²: <b>1 dm² = 100 sm²</b> (×100)','sm²','1 dm');mvK(done,2)},'u']],g2:1,
 after:"<div class='life'><div>📏<span>uzunlik: 1 m = 10 dm = 100 sm — har qadam <b>×10</b></span></div><div>▦<span>yuz: 1 m² = 100 dm² = 10 000 sm² — har qadam <b>×100</b></span></div></div>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["1 dm² = 10 sm²","1 m² = 100 sm²","1 dm² = 100 sm²","1 m² = 10 dm²"],ok:2,why:"Yuz birliklari 100 barobardan o'zgaradi.",hint:"Yuz birliklari nechtadan o'zgaradi: 10 mi yoki 100 mi?",full:"1 dm² = 100 sm² — to'g'ri. 1 m² = 100 dm² (10 emas) va 10 000 sm² (100 emas). 10 barobar faqat uzunlikda."},
 tn:"Ikki ustunli jadval: «Uzunlik ×10» | «Yuz ×100». Bolalar har birini o'zi to'ldirsin."},
{h:"Kvadrat metr",sum:"1 m² = 100 dm² = 10 000 sm². Xona, devor, gilam — m² da o'lchanadi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Xona va hovli yuzini sm² da o'lchash noqulay — son juda katta bo'ladi. Buning uchun <b>kvadrat metr</b> (m²) bor: tomoni 1 m bo'lgan kvadrat.</p>",
 btns:[phaser(P4)],
 after:"<p><b>1 m² = 100 dm² = 10 000 sm²</b>. Taxminan: 1 m² ga ikki o'quvchi partasi sig'adi. Sinf xonasi — taxminan 50–60 m².</p>",
 q:{t:"Kvadratning perimetri 36 sm. Uning yuzi necha mm²?",opts:["81 mm²","810 mm²","8 100 mm²","1 296 mm²"],ok:2,why:"Tomoni 9 sm, yuzi 81 sm² = 8 100 mm² (1 sm² = 100 mm²).",hint:"Avval tomonni toping (36 : 4), keyin yuzni sm² da, so'ng mm² ga o'tkazing.",full:"Tomoni 36 : 4 = 9 sm. Yuzi 9 · 9 = 81 sm². 1 sm² = 100 mm², shuning uchun 81 · 100 = 8 100 mm². «81» — birligini o'tkazmagan, «1 296» — perimetrni kvadratga oshirgan."},
 tn:"Polga 1 m × 1 m kvadratni lenta bilan belgilang — bolalar nechtasi sig'ishini ko'rsin."},
{h:"Kvadrat millimetr",sum:"1 sm² = 100 mm². Juda kichik yuzlar (tugma, marka) mm² da.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Eng kichik birlik — <b>kvadrat millimetr</b>. 1 sm² ichiga nechta mm² sig'adi? Lupa bilan qarang.</p>",
 btns:[phaser(P5,'🔍 Kattalashtirish')],
 after:"<p>1 sm = 10 mm, shuning uchun <b>1 sm² = 10 · 10 = 100 mm²</b>. Zanjir: <b>mm² → sm² → dm² → m²</b>, har qadam ×100.</p>",
 q:{t:"5 sm² necha mm²?",opts:["50 mm²","500 mm²","5 000 mm²","105 mm²"],ok:1,why:"5 · 100 = 500 mm².",hint:"1 sm² = ? mm²",full:"1 sm² = 100 mm². 5 sm² = 5 · 100 = 500 mm². «50» — yana uzunlik qoidasi (×10) qo'llangan."},
 tn:"Millimetrli qog'oz bo'lsa, bolalar 1 sm² ichidagi mm² larni lupa bilan ko'rsin."},
{h:"Tuzoq: aralash birliklar",sum:"5 m² 8 dm² = 500 + 8 = 508 dm² (58 emas!).",a:"m06",
 start:function(){clear('#ffffff');T(S.g,180,60,'5 m² 8 dm² = ? dm²',{'font-size':24,'font-weight':800,fill:'#1d2b3a'});g3Msg('Javobni tanlang')},fin:function(){clear('#ffffff');T(S.g,180,60,'5 m² 8 dm² = 508 dm²',{'font-size':24,'font-weight':800,fill:C.ok});T(S.g,180,110,'500 + 8',{'font-size':18,'font-weight':800,fill:C.blue});g3Msg('5 m² = 500 dm²')},
 html:"<p>Testda shunday keladi: <b>5 m² 8 dm² necha dm²?</b> Uchta javobni sinab ko'ring:</p>",
 btns:[["58",function(c,done,b){clear('#ffffff');T(S.g,180,60,'5 m² 8 dm² ≠ 58 dm²',{'font-size':22,'font-weight':800,fill:C.bad});T(S.g,180,110,'5 m² = 50 dm² emas!',{'font-size':15,'font-weight':800,fill:C.bad});g3Msg('Bu — «×10» xatosi')}],["508",function(c,done){clear('#ffffff');T(S.g,180,60,'5 m² 8 dm² = 508 dm²',{'font-size':24,'font-weight':800,fill:C.ok});T(S.g,180,110,'5 · 100 + 8 = 500 + 8',{'font-size':18,'font-weight':800,fill:C.blue});g3Msg('To‘g‘ri! 5 m² = 500 dm²');done()},'u'],["580",function(c,done,b){clear('#ffffff');T(S.g,180,60,'5 m² 8 dm² ≠ 580 dm²',{'font-size':22,'font-weight':800,fill:C.bad});T(S.g,180,110,'8 dm² ni 80 qilib bo‘lmaydi',{'font-size':15,'font-weight':800,fill:C.bad});g3Msg('8 dm² — 8 ligicha qoladi')}]],g3:1,
 after:"<p>Usul: kattasini kichik birlikka o'tkazamiz (5 m² = 500 dm²), keyin qo'shamiz: 500 + 8 = <b>508 dm²</b>. 8 dm² o'zgarmaydi!</p>",
 q:{t:"3 dm² 5 sm² necha sm²?",opts:["35 sm²","305 sm²","350 sm²","3 005 sm²"],ok:1,why:"3 dm² = 300 sm², + 5 = 305.",hint:"Avval 3 dm² ni sm² ga o'tkazing.",full:"3 dm² = 300 sm². Unga 5 sm² qo'shamiz: 305 sm². «35» — ×10 xatosi, «350» — 5 ni ham ko'paytirib yuborgan."},
 tn:"Pulga o'xshatish yordam beradi: «5 ming va 8 so'm = 5 008 so'm», shunday xonada nol saqlanadi."},
{h:"Ar va gektar",sum:"1 ar = 100 m² (10 m × 10 m), 1 ga = 100 ar = 10 000 m² (100 m × 100 m).",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=1;P7[1]()},
 html:"<p>Dalalar va bog'lar uchun yanada katta birliklar bor: <b>ar</b> va <b>gektar</b>. Kuzating.</p>",
 btns:[phaser(P7)],
 after:"<p>Qishloqda «tomorqa 6 sotix» deyishadi — bu <b>6 ar = 600 m²</b>. Paxta va bug'doy dalalari <b>gektar</b>da o'lchanadi. Futbol maydoni — taxminan 70 ar.</p>",
 q:{t:"Eni 150 m, bo'yi 400 m bo'lgan dala necha gektar?",opts:["6 ga","60 ga","600 ga","60 000 ga"],ok:0,why:"150 · 400 = 60 000 m² = 6 ga.",hint:"Avval yuzni m² da toping, keyin 1 ga = 10 000 m² ekanini eslang.",full:"Yuz: 150 · 400 = 60 000 m². 1 ga = 10 000 m², 60 000 : 10 000 = 6 ga. «60 000» — bu m², gektar emas; «600» — bu ar."},
 tn:"Maktab hovlisini qadam bilan o'lchab, necha ar ekanini hisoblang — bolalar uchun juda qiziq amaliy ish."},
{h:"Qaysi birlik qachon?",sum:"Marka — mm², daftar — sm², stol — dm², xona — m², tomorqa — ar, dala — ga, viloyat — km².",a:"m08",
 start:function(){clear('#ffffff');g3Msg('Narsani bosing — mos birlik chiqadi')},fin:function(){g8Show(6)},
 html:"<p>Har bir narsaga o'z birligi mos. Tugmalarni bosing:</p>",
 btns:[["📮 Marka",function(c,done){g8Show(0);mvK(done,4)}],["📒 Daftar",function(c,done){g8Show(1);mvK(done,4)}],["🏠 Xona",function(c,done){g8Show(3);mvK(done,4)}],["🌱 Tomorqa",function(c,done){g8Show(4);mvK(done,4)}],["🌾 Dala",function(c,done){g8Show(5);mvK(done,4)}],["🗺 Viloyat",function(c,done){g8Show(6);mvK(done,4)}]],g3:1,
 after:"<p>Kichikdan kattaga: <b>mm² → sm² → dm² → m² → ar → ga → km²</b>. Birlikni to'g'ri tanlasak, son qulay bo'ladi: xona 24 m² — 240 000 sm² emas.</p>",
 q:{t:"Sinf xonasining yuzi qanday yoziladi?",opts:["56 m²","56 sm²","56 ga","56 m"],ok:0,why:"Xona yuzi kvadrat metrda.",hint:"Xona uchun qaysi birlik qulay? Va yuz qanday birlikda yoziladi?",full:"Xona — m² da: taxminan 56 m². 56 sm² — kaftdan ham kichik, 56 ga — katta dala. «56 m» — bu uzunlik, yuz emas."},
 tn:"Bolalar sinfdagi narsalarni nomlab, birligini aytsin: «parta usti — dm², doska — m²»."},
{h:"Bilasizmi? Yer o'lchash tarixi",sum:"«Geometriya» — «yer o'lchash». Al-Xorazmiy «Al-jabr» kitobida yuzni hisoblashga alohida bob ajratgan.",a:"m09",
 start:function(){clear('#f6ead0');g3Msg('Tugmani bosing')},fin:function(){g9Hist()},
 html:"<p>📜 Odamlar yer maydonini juda qadimdan o'lchashgan: dehqon necha don sepishini, qancha soliq to'lashini bilishi kerak edi.</p>",
 btns:[["📜 Tarix",function(c,done){g9Hist();done()}]],
 after:"<p>📐 Yunoncha <b>«geometriya»</b> so'zi aynan <b>«yer o'lchash»</b> degani. Misrda Nil daryosi toshgandan keyin dalalar chegarasi qayta o'lchangan.</p><p>⭐ Vatandoshimiz <b>al-Xorazmiy</b> «Al-jabr val-muqobala» kitobida shakllar yuzini hisoblashga alohida bob ajratgan — u yer va meros taqsimlashda kerak bo'lgan.</p><p>🌱 «Gektar» so'zidagi «gekto» — <b>yuz</b> degani: 1 gektar = 100 ar.</p>",
 tn:"Bolalarga uylari tomorqasi necha sotix ekanini so'rab kelish vazifasini bering."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g7Fill(10,'1 dm² = 100 sm²','sm²','1 dm')},fin:function(){g7Fill(10,'1 dm² = 100 sm²','sm²','1 dm')},
 html:"<div class='memo'><ul><li>Yuz — shakl ichiga nechta <b>birlik kvadrat</b> sig'ishi.</li><li><b>1 sm² = 100 mm²</b>, <b>1 dm² = 100 sm²</b>, <b>1 m² = 100 dm² = 10 000 sm²</b>.</li><li>Uzunlik ×10, yuz <b>×100</b>! 1 dm = 10 sm, lekin 1 dm² = 100 sm².</li><li><b>1 ar</b> (sotix) = 100 m² = 10 m × 10 m.</li><li><b>1 ga</b> = 100 ar = 10 000 m² = 100 m × 100 m.</li><li>Aralash: 5 m² 8 dm² = 500 + 8 = <b>508 dm²</b>.</li><li>Avval bir xil birlikka o'tkazing, keyin hisoblang.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring. Keyingi darsni «2 m² 5 dm² necha dm²?» savoli bilan boshlang (205)."}
];
var G8L=[['📮','Pochta markasi','mm²','taxminan 600 mm²'],['📒','Daftar varag‘i','sm²','taxminan 400 sm²'],['🪑','Stol usti','dm²','taxminan 60 dm²'],['🏠','Xona','m²','taxminan 24 m²'],['🌱','Tomorqa','ar (sotix)','taxminan 6 ar'],['🌾','Dala','ga','taxminan 40 ga'],['🗺','Viloyat','km²','Buxoro viloyati ~40 000 km²']];
function g8Show(i){clear('#ffffff');var x=G8L[i];T(S.g,180,62,x[0],{'font-size':46});T(S.g,180,104,x[1],{'font-size':16,'font-weight':800,fill:'#1d2b3a'});T(S.g,180,134,x[2],{'font-size':24,'font-weight':800,fill:C.blue});T(S.g,180,158,x[3],{'font-size':12,fill:'#5b6b7b'});g3Msg(x[1]+' — <b>'+x[2]+'</b>')}
function g9Hist(){clear('#f6ead0');var g=S.g;T(g,180,50,'γεωμετρία',{'font-size':26,'font-weight':800,fill:'#6b3d12'});T(g,180,80,'geo = yer · metria = o‘lchash',{'font-size':14,fill:'#6b3d12'});g3Rect(110,100,140,50,{fill:'rgba(140,201,111,.5)',stroke:'#3d8b2f',mid:'Nil bo‘yidagi dala'});g3Msg('«Geometriya» — «yer o‘lchash»')}
var PROBS=[
{t:"Bo'yi 8 sm, eni 3 sm bo'lgan to'g'ri to'rtburchakning yuzi qancha?",o:["24 sm²","22 sm²","11 sm²","24 sm"],k:0,s:"8 · 3 = 24 sm²."},
{t:"4 dm² necha sm²?",o:["400 sm²","40 sm²","4 000 sm²","14 sm²"],k:0,s:"1 dm² = 100 sm², 4 · 100 = 400."},
{t:"700 sm² necha dm²?",o:["7 dm²","70 dm²","700 dm²","0 dm²"],k:0,s:"100 sm² = 1 dm², 700 : 100 = 7."},
{t:"1 m² necha sm²?",o:["10 000 sm²","100 sm²","1 000 sm²","100 000 sm²"],k:0,s:"1 m² = 100 dm² = 100 · 100 sm² = 10 000 sm²."},
{t:"5 m² 8 dm² necha dm²?",o:["508 dm²","58 dm²","580 dm²","5 080 dm²"],k:0,s:"5 m² = 500 dm², 500 + 8 = 508."},
{t:"6 sm² necha mm²?",o:["600 mm²","60 mm²","6 000 mm²","106 mm²"],k:0,s:"1 sm² = 100 mm², 6 · 100 = 600."},
{t:"3 ar necha m²?",o:["300 m²","30 m²","3 000 m²","30 000 m²"],k:0,s:"1 ar = 100 m², 3 · 100 = 300."},
{t:"2 ga necha ar?",o:["200 ar","20 ar","2 000 ar","20 000 ar"],k:0,s:"1 ga = 100 ar, 2 · 100 = 200."},
{t:"Eni 150 m, bo'yi 400 m bo'lgan dala necha gektar?",o:["6 ga","60 ga","600 ga","6 000 ga"],k:0,s:"150 · 400 = 60 000 m² = 6 ga."},
{t:"Kvadratning perimetri 36 sm. Uning yuzi necha mm²?",o:["8 100 mm²","81 mm²","810 mm²","1 296 mm²"],k:0,s:"Tomon 9 sm, yuz 81 sm² = 8 100 mm²."},
{t:"Qaysi taqqoslash to'g'ri?",o:["2 dm² > 150 sm²","2 dm² < 150 sm²","2 dm² = 20 sm²","1 m² < 50 dm²"],k:0,s:"2 dm² = 200 sm² > 150 sm²."},
{t:"Tomoni 1 m bo'lgan kvadratga tomoni 1 dm bo'lgan nechta kvadrat sig'adi?",o:["100","10","1 000","40"],k:0,s:"Har tomonda 10 tadan: 10 · 10 = 100."},
{t:"Tomorqa 6 sotix. Bu necha m²?",o:["600 m²","60 m²","6 000 m²","6 m²"],k:0,s:"1 sotix = 1 ar = 100 m², 6 · 100 = 600 m²."},
{t:"3 dm² 5 sm² necha sm²?",o:["305 sm²","35 sm²","350 sm²","3 005 sm²"],k:0,s:"300 + 5 = 305 sm²."},
{t:"Xona bo'yi 6 m, eni 4 m. Polga 1 m² uchun 2 ta plitka kerak. Nechta plitka kerak?",o:["48","24","20","12"],k:0,s:"Yuz 6 · 4 = 24 m², 24 · 2 = 48 ta."},
{t:"Bo'yi 4 m 5 dm, eni 3 m bo'lgan devorning yuzi necha dm²?",o:["1 350 dm²","135 dm²","1 305 dm²","13 500 dm²"],k:0,s:"45 dm · 30 dm = 1 350 dm²."},
{t:"Qaysi birlik eng katta?",o:["1 ga","1 ar","1 m²","1 dm²"],k:0,s:"1 ga = 100 ar = 10 000 m²."},
{t:"Yuzi 54 dm² bo'lgan to'g'ri to'rtburchak 6 ta teng kvadratga bo'lindi. Har kvadratning tomoni necha dm?",o:["3 dm","9 dm","6 dm","48 dm"],k:0,s:"Bitta kvadrat 54 : 6 = 9 dm², tomoni 3 dm (3 · 3 = 9)."},
{t:"Bo'yi 1 m, eni 50 sm bo'lgan stol usti necha dm²?",o:["50 dm²","150 dm²","500 dm²","5 dm²"],k:0,s:"10 dm · 5 dm = 50 dm²."},
{t:"Kvadrat shaklidagi 1 ar yerning tomoni qancha?",o:["10 m","100 m","1 m","25 m"],k:0,s:"1 ar = 100 m² = 10 m × 10 m."}
];
function PRACT_STAGE(){g7Fill(10,'1 dm² = 100 sm² · 1 m² = 100 dm²','sm²','1 dm')}
var PREP_DATA={teach:["Yuz birliklari: mm², sm², dm², m², ar, ga, km².","Ular orasidagi bog'lanish: har qadam ×100 (uzunlikda ×10).","Aralash birliklarni o'tkazish: 5 m² 8 dm² = 508 dm².","Amaliy masalalar: dala gektarda, xona m² da."],
 mist:["1 dm² = 10 sm² deb yozadi (uzunlik qoidasini qo'llaydi).","5 m² 8 dm² ni 58 deb yozadi.","Yuz javobiga uzunlik birligini yozadi (24 sm).","Ar va gektarni adashtiradi."],
 need:["10 × 10 sm qog'oz kvadrat (1 dm²) va 1 × 1 sm kvadratchalar.","Polda lenta bilan 1 m × 1 m kvadrat.","Millimetrli qog'oz (ixtiyoriy)."],
 board:["<span class='w2'>1 sm² = 100 mm²</span>, <span class='w2'>1 dm² = 100 sm²</span>, <span class='w2'>1 m² = 100 dm²</span>.","Jadval: <span class='w2'>Uzunlik ×10 | Yuz ×100</span>.","<span class='w2'>5 m² 8 dm² = 500 + 8 = 508 dm²</span>.","<span class='w2'>1 ar = 100 m²</span>, <span class='w2'>1 ga = 100 ar = 10 000 m²</span>.","<span class='w2'>150 m · 400 m = 60 000 m² = 6 ga</span>."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
