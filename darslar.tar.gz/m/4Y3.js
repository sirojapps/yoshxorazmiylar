// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4Y3',TITLE='4-sinf · Bo‘linish alomatlari bilan jumboqlar';
function y3box(x,y,digs,hl,w){w=w||34;var g=S.g;digs.forEach(function(d,i){var on=hl&&hl.indexOf(i)>=0,q=d==='□'||d==='?';E('rect',{x:x+i*(w+4),y:y,width:w,height:w+8,rx:5,fill:q?'#fff3c4':on?'#ffe1b0':'#fff',stroke:on?C.a:'#8a99a8','stroke-width':on?2.2:1.4},g);y4T(g,x+i*(w+4)+w/2,y+w-4,String(d),{'font-size':w*.62,'font-weight':800,fill:q?C.bad:'#1d2b3a'})})}
function y3signs(st){clear();y4title('4 536 qaysi sonlarga bo‘linadi?');y3box(116,26,['4','5','3','6'],st===1?[3]:st===2?[0,1,2,3]:st===3?[2,3]:[],28);var g=S.g;
 var R=[[1,'2 ga: oxirgi raqam juft (6)','✓'],[1,'5 ga: oxiri 0 yoki 5','✗'],[2,'3 ga: yig‘indi 18 — 3 ga bo‘linadi','✓'],[2,'9 ga: yig‘indi 18 — 9 ga bo‘linadi','✓'],[3,'4 ga: oxirgi ikki raqam 36 — 4 ga bo‘linadi','✓'],[3,'6 ga: ham 2 ga, ham 3 ga','✓']];
 var row=0;R.forEach(function(r){if(r[0]>st)return;var y=82+row*15;y4T(g,40,y,r[1],{'font-size':11,'font-weight':700,'text-anchor':'start',fill:'#1d2b3a'});y4T(g,330,y,r[2],{'font-size':12,'font-weight':800,fill:r[2]==='✓'?C.ok:C.bad});row++})}
var Y3P1=[function(){y3signs(0);calc(['Bo‘lmasdan bilish mumkinmi? Ha — <b>alomatlar</b> bor'])},function(){y3signs(1);calc(['2, 5, 10 — faqat <b>oxirgi raqam</b>ga qaraymiz'])},function(){y3signs(2);calc(['3 va 9 — <b>raqamlar yig‘indisi</b>: 4 + 5 + 3 + 6 = 18'])},function(){y3signs(3);calc(['4 — <b>oxirgi ikki raqam</b>; 6 — 2 ga va 3 ga bir vaqtda'])}];
function y3hid(sh){clear();y4title('5□2 uch xonali son 3 ga bo‘linsin');y3box(124,34,['5',sh?'?':'□','2']);
 if(sh){var g=S.g;y4T(g,180,112,'5 + □ + 2 = 7 + □ → 9, 12 yoki 15',{'font-size':12,'font-weight':800});y4T(g,180,136,'□ = 2, 5, 8 → 522, 552, 582',{'font-size':13,'font-weight':800,fill:C.ok})}}
function y3six(sh){clear();y4title('47□ son 6 ga bo‘linsin');y3box(124,34,['4','7',sh?'4':'□']);var g=S.g;
 if(sh){y4T(g,180,108,'2 ga: □ juft → 0, 2, 4, 6, 8',{'font-size':12,'font-weight':700});y4T(g,180,128,'3 ga: 11 + □ → □ = 1, 4, 7',{'font-size':12,'font-weight':700});y4T(g,180,152,'ikkalasi ham: □ = 4 → 474',{'font-size':13,'font-weight':800,fill:C.ok})}}
function y3f45(st){clear();y4title('□34□ to‘rt xonali son 45 ga bo‘linsin');var g=S.g;
 if(st===0){y3box(106,32,['□','3','4','□']);y4T(g,180,112,'45 = 5 · 9 → ham 5 ga, ham 9 ga',{'font-size':13,'font-weight':800})}
 if(st>=1){y3box(40,32,[st>=2?'2':'□','3','4','0'],[3],26);y4T(g,98,106,'oxiri 0: □ + 7 = 9',{'font-size':11,'font-weight':700});if(st>=2)y4T(g,98,126,'□ = 2 → 2 340',{'font-size':12,'font-weight':800,fill:C.ok})}
 if(st>=3){y3box(210,32,['6','3','4','5'],[3],26);y4T(g,268,106,'oxiri 5: □ + 12 = 18',{'font-size':11,'font-weight':700});y4T(g,268,126,'□ = 6 → 6 345',{'font-size':12,'font-weight':800,fill:C.ok})}
 if(st>=3)y4T(g,180,158,'Jami 2 ta son',{'font-size':13,'font-weight':800,fill:C.blue})}
var Y3P4=[function(){y3f45(0);calc(['Murakkab bo‘luvchini oddiylarga ajratamiz: 45 = 5 · 9'])},function(){y3f45(1);calc(['5 ga: oxiri 0 yoki 5. Avval 0 ni sinaymiz'])},function(){y3f45(2);calc(['9 ga: □ + 3 + 4 + 0 = □ + 7 → 9 bo‘lishi uchun □ = 2 (16 bo‘lmaydi, □ ≤ 9)'])},function(){y3f45(3);calc(['Oxiri 5: □ + 12 → 18 bo‘lishi uchun □ = 6','Javob: <b>2 340</b> va <b>6 345</b>'])}];
function y3big(sh){clear();y4title('Raqamlari har xil, 9 ga bo‘linadigan eng katta uch xonali son');y3box(124,34,sh?['9','8','1']:['?','?','?']);if(sh){y4T(S.g,180,114,'9 + 8 + □ = 17 + □ → 18 → □ = 1',{'font-size':12,'font-weight':800});y4T(S.g,180,138,'981',{'font-size':16,'font-weight':800,fill:C.ok})}}
function y3four(sh){clear();y4title('Qaysi son 4 ga bo‘linadi?');var g=S.g,N=[['2 134','34'],['3 116','16'],['5 018','18'],['7 142','42']];
 N.forEach(function(n,i){var x=50+i*86;y4T(g,x,70,n[0],{'font-size':16,'font-weight':800});if(sh){y4T(g,x,100,n[1]+' : 4',{'font-size':12,'font-weight':700,fill:'#3a4a5a'});y4T(g,x,124,i===1?'✓ = 4':'✗',{'font-size':14,'font-weight':800,fill:i===1?C.ok:C.bad})}})}
function y3rem(st){clear();y4title('2, 3 va 5 ga bo‘lganda qoldiq 1. Eng kichik son (1 dan katta)?');var g=S.g;
 var row=function(n,y,col){y4T(g,40,y,n,{'font-size':14,'font-weight':800,'text-anchor':'start',fill:col||'#1d2b3a'})};
 if(st>=0)row('Qoldiq bir xil (1) → son = umumiy karrali + 1',60,'#3a4a5a');
 if(st>=1)row('2, 3, 5 ga bo‘linadigan eng kichik son: 30',92);if(st>=2){row('30 + 1 = 31',124,C.ok);row('Tekshirish: 31 = 2·15+1 = 3·10+1 = 5·6+1 ✓',152,C.blue)}}
var Y3P7=[function(){y3rem(0);calc(['Bittaga kamaytirsak — hammasiga bo‘linadi!'])},function(){y3rem(1);calc(['2 · 3 · 5 = 30'])},function(){y3rem(2);calc(['Javob: <b>31</b>. Keyingilari: 61, 91…'])}];
function y3cards(sh){clear();y4title('3, 0, 5, 7 kartochkalaridan 15 ga bo‘linadigan eng katta son');y3box(sh?96:96,30,sh?['7','5','3','0']:['3','0','5','7'],sh?[3]:[]);
 if(sh){y4T(S.g,180,110,'15 = 3 · 5: oxiri 0 yoki 5; yig‘indi 15 — 3 ga ✓',{'font-size':12,'font-weight':700});y4T(S.g,180,136,'oxiri 0 → qolgani kamayish tartibida: 7 530',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y3check(st){clear();y4title('Qo‘shishni 9 bilan tekshirish');var g=S.g;
 y4T(g,180,60,'234 + 567 = 801',{'font-size':18,'font-weight':800});
 if(st>=1){y4T(g,90,100,'2+3+4 = 9 → 0',{'font-size':12,'font-weight':700,fill:C.a2});y4T(g,210,100,'5+6+7 = 18 → 0',{'font-size':12,'font-weight':700,fill:C.blue})}
 if(st>=2){y4T(g,180,128,'8+0+1 = 9 → 0;   0 + 0 = 0 ✓',{'font-size':13,'font-weight':800,fill:C.ok})}}
var Y3P9=[function(){y3check(0);calc(['Javob to‘g‘rimi? Hisoblamasdan tekshirish mumkin'])},function(){y3check(1);calc(['Har sonni raqamlar yig‘indisi bilan almashtiramiz, 9 larni tashlaymiz'])},function(){y3check(2);calc(['Qoldiqlar mos — hisob to‘g‘ri bo‘lishi ehtimoli katta. Mos kelmasa — albatta xato bor!'])}];
function PRACT_STAGE(){clear();y4title('Jumboqda: murakkab bo‘luvchi → oddiylari');y3box(96,34,['?','?','?','?']);['6 = 2 · 3','15 = 3 · 5','45 = 5 · 9'].forEach(function(t,i){y4T(S.g,70+i*110,124,t,{'font-size':13,'font-weight':800,fill:C.blue})});calc(['Avval oxirgi raqam, keyin yig‘indi'])}
var STEPS=[
{h:"Alomatlar: takror va to'liq jadval",sum:"2, 5, 10 — oxirgi raqam; 3, 9 — raqamlar yig'indisi; 4 — oxirgi ikki raqam; 6 — 2 va 3.",a:"m01",
 start:function(){startPh(Y3P1)},fin:function(){S.ph=3;Y3P1[3]()},
 html:"<p>Katta sonni bo'lib o'tirmasdan, u biror songa bo'linishini bilish mumkin. 4 536 ni tekshiramiz. Bosing:</p>",btns:[phaser(Y3P1)],
 after:"<p>Alomatlar uch turda: <b>oxirgi raqam</b> (2, 5, 10), <b>oxirgi ikki raqam</b> (4, 25), <b>raqamlar yig'indisi</b> (3, 9). <b>Murakkab</b> bo'luvchi uchun uni o'zaro «do'st bo'lmagan» ko'paytuvchilarga ajratamiz: 6 = 2 · 3, 15 = 3 · 5, 45 = 5 · 9.</p>",
 q:{t:"Qaysi son 9 ga bo'linadi?",opts:["6 381","6 382","6 380","6 391"],ok:0,why:"6 + 3 + 8 + 1 = 18 — 9 ga bo'linadi.",hint:"Har sonning raqamlari yig'indisini toping.",full:"Yig'indilar: 6 381 → 18 ✓; 6 382 → 19; 6 380 → 17; 6 391 → 19. Faqat 18 — 9 ga bo'linadi."},
 tn:"Alomatlar jadvalini sinf devoriga osib qo'ying. O'yin: o'qituvchi son aytadi, bolalar bo'luvchilarini tez topadi."},
{h:"Yashirin raqam: nechta yechim?",sum:"5□2 3 ga bo'linsin: 7 + □ = 9, 12, 15 → □ = 2, 5, 8 — uchta yechim.",a:"m02",
 start:function(){y3hid(0);calc(['□ o‘rniga nechta raqam qo‘yish mumkin?'])},fin:function(){y3hid(1);y4msg('<b>3 ta</b>: 522, 552, 582')},
 html:"<p>Jumboqda raqam yashiringan: <b>5□2</b> son 3 ga bo'linishi kerak. □ o'rniga nechta xil raqam qo'yish mumkin?</p>",
 btns:y4pick(2,[["1 ta","Bitta topdingiz (masalan, 2), lekin boshqalari ham bor: yig'indi 9, 12 yoki 15 bo'lishi mumkin."],["4 ta","7 + □ ning qiymatlari: 9, 12, 15 — □ = 2, 5, 8. 18 uchun □ = 11 — raqam emas."],["3 ta","5 + □ + 2 = 7 + □. U 9, 12, 15 bo'lishi kerak: □ = 2, 5, 8."],["10 ta","Har raqam mos kelmaydi: 5 + 1 + 2 = 8 — 3 ga bo'linmaydi."]],function(){y3hid(1)}),g2:1,
 after:"<p>Yashirin raqamni topishda <b>barcha</b> yechimlarni izlang: □ 0 dan 9 gacha. 3 ga bo'linishda yechimlar har 3 da takrorlanadi (2, 5, 8). Ba'zan javob — «nechta son», ba'zan — «eng katta/kichik».</p>",
 q:{t:"7□4 son 9 ga bo'linsin. □ = ?",opts:["7","2","9","0"],ok:0,why:"7 + □ + 4 = 11 + □ → 18 → □ = 7.",hint:"11 + □ qaysi 9 ga karrali songa teng bo'lishi mumkin?",full:"Yig'indi 11 + □. 9 ga karrali: 18 (□ = 7) yoki 27 (□ = 16 — raqam emas). Javob: 7 → 774. «2» — 9 o'rniga 3 ga bo'linishni olish (11 + 2 = 13 ham emas)."},
 tn:"Bolalar o'zlari jumboq tuzsin: son yozib, bitta raqamini yopib, sinfdoshiga bersin."},
{h:"Ikki shart birga: 6 ga",sum:"47□ 6 ga: □ juft va 11 + □ 3 ga → □ = 4.",a:"m03",
 start:function(){y3six(0);calc(['6 ga = 2 ga VA 3 ga. Qaysi raqam ikkalasiga mos?'])},fin:function(){y3six(1);y4msg('□ = <b>4</b> → 474')},
 html:"<p><b>47□</b> son 6 ga bo'linsin. □ o'rniga qaysi raqam?</p>",
 btns:y4pick(0,[["4","Juft (2 ga ✓) va 4 + 7 + 4 = 15 (3 ga ✓)."],["1","4 + 7 + 1 = 12 — 3 ga bo'linadi, lekin 471 toq — 2 ga bo'linmaydi."],["7","477 — 3 ga bo'linadi (18), lekin toq."],["2","472 — juft, lekin 4 + 7 + 2 = 13 — 3 ga bo'linmaydi."]],function(){y3six(1)}),g2:1,
 after:"<p>Ikki shart bo'lsa — har biri bo'yicha mos raqamlar ro'yxatini tuzib, <b>umumiy</b>ini olamiz. Bu — Venn diagrammasidagi kesishma kabi!</p>",
 q:{t:"27□ son 15 ga bo'linsin. □ = ?",opts:["0","5","3","6"],ok:0,why:"15 = 3 · 5: oxiri 0 yoki 5. 270 → 9 ✓; 275 → 14 ✗.",hint:"Avval 5 ga bo'linish shartidan □ ning ikki variantini toping, keyin 3 ga tekshiring.",full:"5 ga: □ = 0 yoki 5. 3 ga: 2 + 7 + 0 = 9 ✓, 2 + 7 + 5 = 14 ✗. Javob: 0 (270 = 15 · 18). «5» — oxiri to'g'ri, lekin yig'indi 3 ga bo'linmaydi; «3» va «6» — 3 ga bo'linadi, lekin 5 ga emas."},
 tn:"Ikki rangli belgi: «2 ga mos» raqamlarni ko'k, «3 ga mos»ni qizil doiraga oling — ikkala rangdagi raqam javob."},
{h:"Murakkab jumboq: 45 ga",sum:"□34□: 45 = 5 · 9. Oxiri 0 → 2 340; oxiri 5 → 6 345. Ikkita son.",a:"m04",
 start:function(){startPh(Y3P4)},fin:function(){S.ph=3;Y3P4[3]()},
 html:"<p>Ikki raqam yashiringan: <b>□34□</b> to'rt xonali son 45 ga bo'linadi. Nechta shunday son bor? Bosing:</p>",btns:[phaser(Y3P4)],
 after:"<p>Tartib: 1) bo'luvchini alomatli ko'paytuvchilarga ajrat (45 = 5 · 9); 2) <b>oxirgi raqam</b> shartidan boshla — u kam variant beradi; 3) har variant uchun qolgan raqamni yig'indidan top. To'rt xonali son 0 bilan boshlanmaydi!</p>",
 q:{t:"□15□ to'rt xonali son 18 ga bo'linsin (18 = 2 · 9). Eng katta shunday son?",opts:["8 154","9 153","9 150","7 158"],ok:0,why:"Oxiri juft, yig'indi 9 ga: 8 + 1 + 5 + 4 = 18.",hint:"Birinchi raqamni iloji boricha katta oling va oxirgi raqam juft bo'lsin.",full:"Birinchi raqam 9: 9 + 6 + □ = 15 + □ → 18 da □ = 3 — toq ✗. Birinchi raqam 8: 14 + □ → 18 da □ = 4 — juft ✓. Javob 8 154. «9 153» — toq, «9 150» — yig'indi 15, «7 158» — yig'indi 21."},
 tn:"Daraxt chizmasi: «oxiri 0» va «oxiri 5» ikki shoxga bo'linadi — bolalar har shoxni alohida to'ldiradi."},
{h:"Eng katta son: tartib bilan",sum:"Har xil raqamli, 9 ga bo'linadigan eng katta uch xonali son — 981 (999 va 990 da takror raqam).",a:"m05",
 start:function(){y3big(0);calc(['Raqamlar takrorlanmasin!'])},fin:function(){y3big(1);y4msg('<b>981</b>')},
 html:"<p>Raqamlari <b>har xil</b> bo'lgan, 9 ga bo'linadigan eng katta uch xonali son qaysi?</p>",
 btns:y4pick(0,[["981","9 va 8 ni olamiz: 17 + □ = 18 → □ = 1. Raqamlar har xil ✓."],["999","999 9 ga bo'linadi, lekin raqamlari bir xil."],["990","990 da ikkita 9 — takror."],["972","972 to'g'ri, lekin 981 undan katta."]],function(){y3big(1)}),g2:1,
 after:"<p>«Eng katta» izlaganda <b>chapdan</b> boshlab har raqamni iloji boricha katta tanlaymiz, oxirgisini shartdan topamiz. Chiqmasa — oldingi raqamni bittaga kamaytiramiz.</p>",
 q:{t:"Raqamlari har xil, 3 ga bo'linadigan eng KICHIK to'rt xonali son?",opts:["1 023","1 002","1 230","1 032"],ok:0,why:"1, 0, 2 → 3 + □ → □ = 3: 1 023.",hint:"Chapdan iloji boricha kichik raqamlar: 1, 0, 2, …",full:"Eng kichik: 1, 0, 2 → yig'indi 3 + □ → □ = 0 (takror), 3 ✓ → 1 023. «1 002» — ikkita 0, «1 032» — kattaroq."},
 tn:"«Eng katta / eng kichik» uchun raqam kartochkalari bilan o'yin: bolalar kartochkani surib tekshiradi."},
{h:"Tuzoq: 4 ga — oxirgi raqam emas!",sum:"2 134 ning oxiri 4, lekin 34 : 4 qoldiqli. 3 116: 16 : 4 = 4 ✓.",a:"m06",
 start:function(){y3four(0);calc(['Qaysi son 4 ga bo‘linadi?'])},fin:function(){y3four(1);y4msg('<b>3 116</b>: oxirgi ikki raqam 16 — 4 ga bo‘linadi')},
 html:"<p>Ko'p bola «oxiri 4 bo'lsa — 4 ga bo'linadi» deb o'ylaydi. Tekshiring: qaysi son 4 ga bo'linadi?</p>",
 btns:y4pick(1,[["2 134","Oxiri 4, lekin oxirgi ikki raqam 34 — 4 ga bo'linmaydi (34 = 4 · 8 + 2)."],["3 116","Oxirgi ikki raqam 16 = 4 · 4 ✓."],["5 018","18 = 4 · 4 + 2 — bo'linmaydi."],["7 142","42 = 4 · 10 + 2 — bo'linmaydi."]],function(){y3four(1)}),g2:1,
 after:"<p>Nega oxirgi ikki raqam? Chunki 100 4 ga bo'linadi — yuzlar, minglar doim 4 ga bo'linadi; faqat <b>oxirgi ikki raqam</b> qoldiq beradi. Xuddi shunday 25 ga: oxirgi ikki raqam 00, 25, 50, 75.</p>",
 q:{t:"123□ son 4 ga bo'linsin. □ ning eng katta qiymati?",opts:["6","8","4","2"],ok:0,why:"3□ : 32 va 36 — 4 ga bo'linadi; eng kattasi 36.",hint:"Oxirgi ikki raqam 3□. Qaysilari 4 ga bo'linadi?",full:"30–39 orasida 4 ga bo'linadiganlar: 32, 36. Eng kattasi — 36, □ = 6. «8» — 38 = 4 · 9 + 2, «4» — 34 ham bo'linmaydi."},
 tn:"Bolalar 4 ga bo'linadigan ikki xonali sonlar ro'yxatini tuzsin (04, 08, 12, …, 96) — bu «kalit»."},
{h:"Bir xil qoldiq jumbog'i",sum:"2, 3, 5 ga qoldiq 1 → son = 30 + 1 = 31.",a:"m07",
 start:function(){startPh(Y3P7)},fin:function(){S.ph=2;Y3P7[2]()},
 html:"<p>Son 2 ga, 3 ga va 5 ga bo'linganda har gal 1 qoldiq qoladi. 1 dan katta eng kichik shunday son qaysi? Bosing:</p>",btns:[phaser(Y3P7)],
 after:"<p>Qoldiqlar <b>bir xil</b> bo'lsa: son − qoldiq barcha bo'luvchilarga bo'linadi. Demak son = umumiy karrali + qoldiq. Shunday sonlar har 30 da takrorlanadi: 31, 61, 91…</p>",
 q:{t:"Bolalarni 2, 3 va 4 tadan qatorga tursa, har gal 1 bola ortadi; 5 tadan tursa, ortmaydi. Bolalar 40 dan kam. Nechta bola?",opts:["25","13","37","30"],ok:0,why:"Son − 1 ga 2, 3, 4 bo'linadi → 12 ga: 13, 25, 37; 5 ga bo'linadigani — 25.",hint:"Son 1 ga kamaytirilsa, nimaga bo'linadi?",full:"Son − 1 ham 2, 3, 4 ga bo'linadi — demak 12 ga: son = 13, 25, 37. 5 ga bo'linadigani — 25 (oxiri 5). «13» va «37» — 5 ga bo'linmaydi."},
 tn:"Haqiqiy tajriba: sinf bolalarini 2, 3, 4 tadan saflab, ortganini sanang."},
{h:"Raqam kartochkalaridan son",sum:"3, 0, 5, 7 → 15 ga bo'linadigan eng katta: oxiri 0, qolgani kamayish tartibida → 7 530.",a:"m08",
 start:function(){y3cards(0);calc(['Har kartochka bir marta. Eng katta son?'])},fin:function(){y3cards(1);y4msg('<b>7 530</b>')},
 html:"<p>3, 0, 5, 7 kartochkalaridan (har biri bir martadan) 15 ga bo'linadigan <b>eng katta</b> to'rt xonali son tuzing.</p>",
 btns:y4pick(0,[["7 530","15 = 3 · 5. Yig'indi 15 — har tartibda 3 ga ✓. Oxiri 0 — qolgani 7, 5, 3."],["7 503","Oxiri 3 — 5 ga bo'linmaydi."],["7 350","15 ga bo'linadi, lekin 7 530 undan katta."],["7 305","15 ga bo'linadi, lekin eng kattasi emas."]],function(){y3cards(1)}),g2:1,
 after:"<p>Raqamlar yig'indisi tartibga bog'liq emas — 3 ga bo'linish doim bir xil. Shuning uchun faqat <b>oxirgi raqam</b>ni tanlaymiz, qolganlarini kamayish tartibida qo'yamiz. 0 oxirida 5 dan yaxshi: 5 ni oldinga qo'yamiz.</p>",
 q:{t:"1, 2, 4, 5 kartochkalaridan (har biri bir marta) 4 ga bo'linadigan eng katta son?",opts:["5 412","5 421","5 124","4 512"],ok:0,why:"Oxirgi ikki raqam 4 ga: 12, 24, 52. Eng katta boshlanish 54 → oxiri 12: 5 412.",hint:"Oxirgi ikki raqam qaysi juftlik bo'lishi mumkin?",full:"4 ga bo'linadigan oxirlar: 12, 24, 52. Oldinga katta raqamlar: 54|12 → 5 412; 51|24 → 5 124; 41|52 → 4 152. Eng kattasi 5 412. «5 421» — 21 4 ga bo'linmaydi."},
 tn:"Kartochkalarni bolalar qo'lida ushlab saf bo'lsin — sinf tekshiradi."},
{h:"Bilasizmi? 9 bilan tekshirish",sum:"Raqamlar yig'indisi orqali hisobni tekshirish usuli asrlar davomida ishlatilgan.",a:"m09",
 start:function(){startPh(Y3P9)},fin:function(){S.ph=2;Y3P9[2]()},
 html:"<p>Kalkulyator yo'q zamonlarda savdogarlar va olimlar hisobni qanday tekshirgan? Bosing:</p>",btns:[phaser(Y3P9)],
 after:"<p>Bu usul «to'qqizni tashlash» deb ataladi. U O'rta asrlarda Hindiston va Sharq olimlari asarlarida uchraydi va keyin Yevropaga tarqalgan. Sababi oddiy: son va uning raqamlari yig'indisi 9 ga bo'linganda bir xil qoldiq beradi.</p>",
 tn:"Bolalar o'z daftaridagi qo'shish misollarini shu usul bilan tekshirib ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>2, 5, 10 — oxirgi raqam; 4, 25 — oxirgi ikki raqam; 3, 9 — raqamlar yig'indisi.</li><li>Murakkab bo'luvchi: 6 = 2 · 3, 12 = 3 · 4, 15 = 3 · 5, 18 = 2 · 9, 45 = 5 · 9.</li><li>Yashirin raqam: □ ni 0–9 orasida <b>hammasini</b> tekshiring; to'rt xonali son 0 bilan boshlanmaydi.</li><li>Eng katta son: chapdan katta raqamlar, oxirgisini shartdan.</li><li>Bir xil qoldiq r: son = umumiy karrali + r.</li></ul></div>",
 tn:"Kartochkani daftarga yozdiring. Uyga: 3 ta o'z jumbog'ini tuzib kelish."}
];
var PROBS=[
{t:"Qaysi son 3 ga bo'linadi?",o:["4 512","4 513","2 222","1 004"],k:0,s:"4 + 5 + 1 + 2 = 12."},
{t:"Qaysi son 4 ga bo'linadi?",o:["7 316","2 134","5 018","6 222"],k:0,s:"16 : 4 = 4."},
{t:"Qaysi son 9 ga bo'linadi?",o:["6 381","6 382","6 380","6 391"],k:0,s:"Yig'indi 18."},
{t:"5□2 son 3 ga bo'linsin. □ o'rniga nechta xil raqam qo'yish mumkin?",o:["3 ta","1 ta","4 ta","10 ta"],k:0,s:"□ = 2, 5, 8."},
{t:"47□ son 6 ga bo'linsin. □ = ?",o:["4","1","7","2"],k:0,s:"Juft va 11 + □ 3 ga: 4."},
{t:"□34□ to'rt xonali son 45 ga bo'linadi. Nechta shunday son bor?",o:["2 ta","1 ta","4 ta","10 ta"],k:0,s:"2 340 va 6 345."},
{t:"Raqamlari har xil, 9 ga bo'linadigan eng katta uch xonali son?",o:["981","999","990","972"],k:0,s:"9 + 8 + 1 = 18."},
{t:"2, 3 va 5 ga bo'linganda qoldiq 1 bo'ladigan, 1 dan katta eng kichik son?",o:["31","61","30","11"],k:0,s:"30 + 1."},
{t:"3, 0, 5, 7 raqamlaridan (har biri bir martadan) 15 ga bo'linadigan eng katta to'rt xonali son?",o:["7 530","7 503","7 350","7 305"],k:0,s:"Oxiri 0, qolgani kamayish tartibida."},
{t:"123□ son 4 ga bo'linsin. □ ning eng katta qiymati?",o:["6","8","4","2"],k:0,s:"36 : 4 = 9."},
{t:"Bolalar 2, 3 va 4 tadan saflansa, har gal 1 bola ortadi; 5 tadan saflansa, ortmaydi. Bolalar 40 dan kam. Nechta bola?",o:["25","13","37","30"],k:0,s:"12k + 1 va 5 ga: 25."},
{t:"Ketma-ket uchta natural sonning yig'indisi har doim qaysi songa bo'linadi?",o:["3 ga","2 ga","6 ga","9 ga"],k:0,s:"(n − 1) + n + (n + 1) = 3n."},
{t:"Raqamlari bir xil ikki xonali son 6 ga bo'linadi. Bu qaysi son?",o:["66","33","44","99"],k:0,s:"Juft va 3 ga: 66."},
{t:"Raqamlari bir xil, 9 ga bo'linadigan to'rt xonali son qaysi?",o:["9 999","3 333","1 111","6 666"],k:0,s:"4 · a 9 ga bo'linishi uchun a = 9."},
{t:"2□□8 to'rt xonali son 9 ga bo'linadi. Ikki yashirin raqam yig'indisi eng kami bilan nechaga teng?",o:["8","17","9","6"],k:0,s:"10 + x = 18 → x = 8."},
{t:"Bolalar 2 tadan va 5 tadan saflanganda ortiqcha qolmaydi, 3 tadan saflanganda 2 ta ortadi. Bolalar 40 dan kam. Nechta?",o:["20","10","30","32"],k:0,s:"10, 20, 30 dan 3 ga bo'lganda qoldiq 2 — 20."},
{t:"1 dan 100 gacha nechta son 4 ga ham, 6 ga ham bo'linadi?",o:["8 ta","4 ta","16 ta","41 ta"],k:0,s:"12 ga karralilar: 12, 24, …, 96."},
{t:"□53□ to'rt xonali son 2 ga ham, 9 ga ham bo'linadi. Eng kattasi?",o:["8 532","9 531","8 530","7 534"],k:0,s:"9 bilan boshlansa oxiri toq chiqadi; 8 + 5 + 3 + 2 = 18."},
{t:"Ketma-ket ikki juft sonning ko'paytmasi har doim qaysi songa bo'linadi?",o:["8 ga","6 ga","16 ga","3 ga"],k:0,s:"2k · (2k + 2) = 4 · k · (k + 1), k(k + 1) juft."},
{t:"27□ son 15 ga bo'linsin. □ = ?",o:["0","5","3","6"],k:0,s:"Oxiri 0 yoki 5; 2 + 7 + 0 = 9 — 3 ga ✓."}
];
var PREP_DATA={teach:["Barcha alomatlar: 2, 3, 4, 5, 9, 10, 25 va murakkab bo'luvchilar (6, 15, 18, 45).","Yashirin raqamli jumboqlar: barcha yechimlarni topish.","Ikki va undan ortiq shart — umumiy yechim.","Eng katta / eng kichik son tuzish.","Bir xil qoldiqli masalalar; 9 bilan tekshirish."],
 mist:["4 ga bo'linishni oxirgi raqamga qarab aniqlaydi.","Faqat bitta yechim topib to'xtaydi.","To'rt xonali son 0 bilan boshlanishiga yo'l qo'yadi.","Raqamlar takrorlanmasin shartini unutadi.","6 ga bo'linishni «oxiri 6» deb tushunadi."],
 need:["Raqam kartochkalari (0–9).","Alomatlar jadvali plakati."],
 board:["2, 5, 10 → <span class='w2'>oxirgi raqam</span>; 4, 25 → <span class='w2'>oxirgi ikki</span>; 3, 9 → <span class='w2'>yig'indi</span>.","45 = 5 · 9: □34□ → 2 340, 6 345.","Qoldiq 1: <span class='w2'>30 + 1 = 31</span>."]};
