var CODE='4E4',TITLE='4-sinf · Narx, miqdor, qiymat';
function e4Tri(hi){clear();var g=S.g;E('path',{d:'M180 14 L290 150 L70 150 Z',fill:'#fff7e6',stroke:'#8a5a24','stroke-width':2.5},g);E('line',{x1:110,y1:100,x2:250,y2:100,stroke:'#8a5a24','stroke-width':2},g);E('line',{x1:180,y1:100,x2:180,y2:150,stroke:'#8a5a24','stroke-width':2},g);
 [['Q',180,78],['N',140,135],['M',220,135]].forEach(function(z){T(g,z[1],z[2],z[0],{'font-size':24,'font-weight':800,fill:hi===z[0]?C.bad:'#1d2b3a'})});T(g,180,135,'·',{'font-size':24,'font-weight':800,fill:'#1d2b3a'});
 T(g,8,30,'Q — qiymat',{'font-size':11,fill:'#5b6b7b','text-anchor':'start'});T(g,8,46,'N — narx',{'font-size':11,fill:'#5b6b7b','text-anchor':'start'});T(g,8,62,'M — miqdor',{'font-size':11,fill:'#5b6b7b','text-anchor':'start'})}
var P2=[function(){w3Bar([{lab:'4 kg',segs:[{w:1,t:''},{w:1,t:''},{w:1,t:''},{w:1,t:''}],tot:7,br:'36 000',brw:4/7}],{top:60});w3Msg('4 kg olma 36 000 so‘m. 7 kg qancha turadi?')},
 function(){w3Bar([{lab:'4 kg',segs:[{w:1,t:'9000',c:C.a},{w:1,t:'9000'},{w:1,t:'9000'},{w:1,t:'9000'}],tot:7,br:'36 000',brw:4/7}],{top:60});w3Msg('1) Birga keltiramiz: 1 kg = 36 000 : 4 = <b>9000</b> so‘m')},
 function(){w3Bar([{lab:'7 kg',segs:[{w:1,t:'9000',c:C.a},{w:1,t:''},{w:1,t:''},{w:1,t:''},{w:1,t:''},{w:1,t:''},{w:1,t:''}],tot:7,br:'63 000',brw:1}],{top:60});w3Msg('2) 7 kg = 9000 · 7 = <b>63 000</b> so‘m')}];
var P4=[function(){w3Expr(['3 kg olma × 12 000','2 kg uzum × 18 000','berildi: 100 000']);w3Msg('Qaytim qancha?')},
 function(){w3Expr(['olma: 12 000 · 3 = {36 000}','uzum: 18 000 · 2 = {36 000}']);w3Msg('1) Har bir mahsulot qiymati')},
 function(){w3Expr(['xarid: 36 000 + 36 000 = {72 000}']);w3Msg('2) Jami xarid')},
 function(){w3Expr(['qaytim: 100 000 − 72 000 = {28 000}']);w3Msg('3) Qaytim — <b>28 000</b> so‘m')}];
var P6=[function(){w3Bar([{lab:'D',segs:[{w:2,t:'2000'},{w:2,t:'2000'},{w:2,t:'…'}],tot:11},{lab:'R',segs:[{w:3,t:'3000',c:C.a},{w:3,t:'3000',c:C.a},{w:3,t:'…',c:C.a}],tot:11}]);w3Msg('D — daftar 2000, R — ruchka 3000. Ikkalasidan bir xil sonda, jami 25 000')},
 function(){w3Bar([{lab:'juft',segs:[{w:2,t:'2000'},{w:3,t:'3000',c:C.a}],tot:25,br:'5000',brw:5/25}],{top:60});w3Msg('Bitta daftar + bitta ruchka = bir «juftlik» = 5000 so‘m')},
 function(){w3Bar([{lab:'',segs:[{w:5,t:'5000'},{w:5,t:'5000',c:C.a},{w:5,t:'5000'},{w:5,t:'5000',c:C.a},{w:5,t:'5000'}],tot:25,br:'25 000',brw:1}],{top:60});w3Msg('25 000 : 5000 = <b>5</b> juftlik — 5 ta daftar va 5 ta ruchka')}];
var STEPS=[
{h:"Qiymat = narx · miqdor",sum:"Q = N · M; N = Q : M; M = Q : N. Narx — bittasining puli, miqdor — nechta, qiymat — hammasining puli.",a:"m01",
 start:function(){S.w4={};e4Tri();w3Msg('Narx — 1 donaning puli; miqdor — nechta; qiymat — hammasining puli')},fin:function(){e4Tri();w3Msg('Q = N · M,  N = Q : M,  M = Q : N')},
 html:"<p>Uchta kattalik — xuddi s, v, t kabi uchburchak hosil qiladi. Uchala holatni ham bosing:</p>",
 btns:[["Qiymat?",function(c,done){S.w4.q=1;e4Tri('Q');w3Msg('6 ta daftar, 3500 so‘mdan: Q = 3500 · 6 = <b>21 000</b> so‘m');if(S.w4.n&&S.w4.m)done()}],["Narx?",function(c,done){S.w4.n=1;e4Tri('N');w3Msg('7 ta daftar 17 500 so‘m: N = 17 500 : 7 = <b>2500</b> so‘m');if(S.w4.q&&S.w4.m)done()}],["Miqdor?",function(c,done){S.w4.m=1;e4Tri('M');w3Msg('48 000 so‘mga 6000 so‘mlikdan: M = 48 000 : 6000 = <b>8</b> ta');if(S.w4.q&&S.w4.n)done()},'u']],g3:1,
 after:"<p>Bu uchburchak — 4E2 dagi s = v · t ning «aka-ukasi»: tepadagisi (qiymat) — pastdagi ikkitasining ko'paytmasi. Ish unumi masalalarida ham xuddi shunday!</p>",
 q:{t:"7 ta bir xil daftar 17 500 so'm turadi. Bitta daftar necha so'm?",opts:["2500 so'm","122 500 so'm","17 493 so'm","3500 so'm"],ok:0,why:"17 500 : 7 = 2500.",hint:"N = Q : M.",full:"Narx = qiymat : miqdor = 17 500 : 7 = 2500 so'm. «122 500» — ko'paytirish xatosi."},
 tn:"Sinfda «do'kon» o'yini: narx yorliqlari, o'yinchoq pullar. Bolalar sotuvchi va xaridor bo'ladi."},
{h:"Birga keltirish",sum:"4 kg 36 000 → 1 kg 9000 → 7 kg 63 000.",a:"m02",
 start:w4St(P2),fin:w4Fin(P2),
 html:"<p>«4 kg olma 36 000 so'm. Shunday olmaning 7 kg i qancha turadi?» Asosiy usul — <b>birga keltirish</b>: avval 1 kg narxini topamiz.</p>",btns:[phaser(P2)],
 after:"<p>Birga keltirish — eng kuchli usullardan biri: «birinining narxi» ni topsangiz, istalgan miqdorning narxini topa olasiz. Xato: 36 000 · 7 (4 kg ning narxini 7 ga ko'paytirish).</p>",
 q:{t:"5 kg shakar 60 000 so'm. 3 kg shakar necha so'm?",opts:["36 000 so'm","20 000 so'm","180 000 so'm","12 000 so'm"],ok:0,why:"1 kg = 12 000, 3 kg = 36 000.",hint:"Avval 1 kg narxi.",full:"60 000 : 5 = 12 000 (1 kg), 12 000 · 3 = 36 000. «20 000» — 60 000 : 3; «12 000» — faqat 1 kg."},
 tn:"Singapur «unitary method»: chizmada avval bitta katakni bo'yab, uning qiymatini yozing."},
{h:"Qaysi xarid foydaliroq?",sum:"3 tasi 4500 (1 tasi 1500) yoki 5 tasi 7000 (1 tasi 1400): ikkinchisi arzonroq.",a:"m03",
 start:function(){w3Expr(['A: 3 dona — 4500 so‘m','B: 5 dona — 7000 so‘m']);w3Msg('Qaysi paket arzonroq?')},fin:function(){w3Expr(['A: 4500 : 3 = 1500','B: 7000 : 5 = {1400}','B arzonroq (100 so‘mga)']);w3Msg('Bir donaning narxini taqqoslaymiz')},
 html:"<p>Do'konda bir xil qalam ikki xil paketda: <b>A</b> — 3 donasi 4500 so'm, <b>B</b> — 5 donasi 7000 so'm. Qaysi biri arzonroq?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['A','B','Bir xil'],'B',function(){w3Expr(['A: 4500 : 3 = 1500','B: 7000 : 5 = {1400}','B arzonroq (100 so‘mga)']);w3Msg('To‘g‘ri! Dona narxi: 1400 &lt; 1500');done()},{'A':'A paket arzon turadi, lekin unda qalam ham kam. Bir donasini hisoblang','Bir xil':'Dona narxlarini hisoblang: 4500 : 3 va 7000 : 5'})},
 after:"<p>Umumiy narxni taqqoslash aldaydi — miqdorlar har xil! To'g'ri yo'l: <b>bir dona</b> (1 kg, 1 litr) narxini taqqoslash. Do'konlarda buni «birlik narxi» deyishadi.</p>",
 q:{t:"Paketda 6 ta sharbat 25 000 so'm, donasi 4500 so'm. 6 tani paketda olsa, donalab olishdan qancha arzon?",opts:["2000 so'm","20 500 so'm","500 so'm","4500 so'm"],ok:0,why:"4500 · 6 = 27 000; 27 000 − 25 000 = 2000.",hint:"6 tasini donalab olish narxi?",full:"Donalab: 27 000, paket: 25 000, farq 2000 so'm. «4500» — bitta sharbat narxi; «20 500» — 25 000 − 4500."},
 tn:"Haqiqiy do'kon chekidan yoki narx yorlig'idan foydalaning — bolalar «birlik narxi»ni topishsin."},
{h:"Xarid va qaytim",sum:"3 kg olma 12 000 dan va 2 kg uzum 18 000 dan: 72 000; 100 000 dan qaytim 28 000.",a:"m04",
 start:w4St(P4),fin:w4Fin(P4),
 html:"<p>«Onam 3 kg olma (kg i 12 000 so'm) va 2 kg uzum (kg i 18 000 so'm) olib, 100 000 so'm berdi. Qancha qaytim oladi?»</p>",btns:[phaser(P4)],
 after:"<p>Bitta ifoda: <b>100 000 − (12 000 · 3 + 18 000 · 2) = 28 000</b>. Qavs shart — aks holda uzum narxi pulga qo'shilib ketadi (4D1 dagi tuzoq!).</p>",
 q:{t:"Sut 9800 so'm, non 3500 so'm. 3 ta sut va 2 ta non olib, 50 000 so'm berildi. Qaytim?",opts:["13 600 so'm","36 400 so'm","23 600 so'm","3600 so'm"],ok:0,why:"29 400 + 7000 = 36 400; 50 000 − 36 400 = 13 600.",hint:"Avval jami xarid.",full:"Sut: 29 400, non: 7000, jami 36 400. Qaytim 13 600. «36 400» — xarid narxi, qaytim emas."},
 tn:"Haqiqiy chek namunasini ko'rsating: har qatorda narx × miqdor = qiymat, pastda jami."},
{h:"Bir xil pulga — boshqa mahsulot",sum:"8 ta 3000 lik daftar = 24 000. Shu pulga 4000 lik daftardan 24 000 : 4000 = 6 ta.",a:"m05",
 start:function(){w3Expr(['8 ta × 3000 so‘m','yoki ? ta × 4000 so‘m']);w3Msg('Pul bir xil')},fin:function(){w3Expr(['pul: 3000 · 8 = 24 000','24 000 : 4000 = {6} ta']);w3Msg('Narx oshdi → miqdor kamaydi')},
 html:"<p>Ali 3000 so'mlik daftardan 8 ta olishi mumkin edi. U shu pulga 4000 so'mlik daftardan nechta oladi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['6','8','12','32'],'6',function(){w3Expr(['pul: 3000 · 8 = 24 000','24 000 : 4000 = {6} ta']);w3Msg('To‘g‘ri! Avval pulni topdik');done()},{'8':'Qimmatroq daftardan o‘sha pulga kamroq olinadi','12':'Narx oshsa, miqdor oshmaydi — aksincha','32':'4000 · 8 = 32 000 — pul yetmaydi'})},
 after:"<p>Qiymat (pul) o'zgarmasa: narx necha marta oshsa — miqdor shuncha marta kamayadi. Usul: avval <b>umumiy pulni</b> toping, keyin yangi narxga bo'ling.</p>",
 q:{t:"Uchta ruchkaning narxi ikkita daftar narxiga teng. Daftar 4500 so'm. Ruchka necha so'm?",opts:["3000 so'm","6750 so'm","4500 so'm","13 500 so'm"],ok:0,why:"2 · 4500 = 9000; 9000 : 3 = 3000.",hint:"Avval ikki daftar narxi.",full:"Ikki daftar 9000 so'm, demak uch ruchka ham 9000; bittasi 3000. «6750» — 4500 · 3 : 2 (nisbatni teskari olish)."},
 tn:"Tarozida «muvozanat» ko'rinishida chizing: 3 ruchka = 2 daftar."},
{h:"Bir xil miqdorda ikki mahsulot",sum:"Bir xil sonda daftar (2000) va ruchka (3000), jami 25 000: juftlik 5000, 25 000 : 5000 = 5 tadan.",a:"m06",
 start:w4St(P6),fin:w4Fin(P6),
 html:"<p>«Ali bir xil sonda daftar (2000 so'm) va ruchka (3000 so'm) olib, 25 000 so'm to'ladi. Har biridan nechta oldi?»</p>",btns:[phaser(P6)],
 after:"<p>«Juftlik» usuli: miqdorlar teng bo'lsa, bitta daftar + bitta ruchkani bir «to'plam» deb olamiz. Tenglama: <b>x · 2000 + x · 3000 = 25 000 → x · 5000 = 25 000 → x = 5</b>.</p>",
 q:{t:"Kitob va albomdan bir xil sonda olindi: kitob 8000, albom 4000 so'm. Jami 60 000 so'm to'landi. Nechta kitob olindi?",opts:["5","7","15","10"],ok:0,why:"Juftlik 12 000; 60 000 : 12 000 = 5.",hint:"Bitta kitob + bitta albom = ?",full:"8000 + 4000 = 12 000; 60 000 : 12 000 = 5. «10» — kitob va albomlar birgalikdagi soni (5 + 5); «15» — 60 000 : 4000."},
 tn:"Daftar va ruchkalarni haqiqatdan juft-juft qilib qo'ydiring — har juftga 5000 yorlig'i."},
{h:"Narx o'zgarsa…",sum:"Pul o'zgarmasa, narx 2 marta oshganda miqdor 2 marta kamayadi; narx 2 marta kamaysa — miqdor 2 marta oshadi.",a:"m07",
 start:function(){w3Expr(['pul: 24 000','narx: 3000 → 6000']);w3Msg('Miqdor qanday o‘zgaradi?')},fin:function(){w3Expr(['24 000 : 3000 = 8 ta','24 000 : 6000 = {4} ta','narx ×2 → miqdor :2']);w3Msg('Teskari bog‘liqlik')},
 html:"<p>Pul miqdori o'sha-o'sha. Narx <b>2 marta oshdi</b>. Olinadigan mahsulot miqdori qanday o'zgaradi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['2 marta kamayadi','2 marta oshadi','o‘zgarmaydi'],'2 marta kamayadi',function(){w3Expr(['24 000 : 3000 = 8 ta','24 000 : 6000 = {4} ta','narx ×2 → miqdor :2']);w3Msg('To‘g‘ri!');done()},{'2 marta oshadi':'Qimmatlashsa — kamroq olinadi!','o‘zgarmaydi':'Pul o‘sha, narx oshdi — yetmay qoladi'})},
 after:"<p>Narx va miqdor — <b>teskari</b> bog'liq (qiymat o'zgarmasa). Narx va qiymat esa — <b>to'g'ri</b> bog'liq (miqdor o'zgarmasa): narx 2 marta oshsa, qiymat ham 2 marta oshadi.</p>",
 q:{t:"Mato 5 metri 75 000 so'm. Shunday matoning 8 metri necha so'm?",opts:["120 000 so'm","15 000 so'm","600 000 so'm","78 000 so'm"],ok:0,why:"1 m = 15 000, 8 m = 120 000.",hint:"Birga keltiring.",full:"75 000 : 5 = 15 000; 15 000 · 8 = 120 000. «600 000» — 75 000 · 8."},
 tn:"Ikki ustunli jadval: narx | miqdor (pul 24 000). Bolalar qatorlarni to'ldirib, qonuniyatni topsin."},
{h:"Aksiya tuzog'i",sum:"«2 tasini olsangiz, 3-si bepul», donasi 6000: 9 ta uchun 6 tasiga to'lanadi — 36 000.",a:"m08",
 start:function(){w3Expr(['aksiya: 2 ta + 1 bepul','dona: 6000 so‘m,  kerak: 9 ta']);w3Msg('Qancha to‘lanadi?')},fin:function(){w3Expr(['9 ta = 3 ta «to‘plam»','har to‘plamda 2 tasiga to‘lanadi','6 · 6000 = {36 000} so‘m']);w3Msg('Aksiya: 54 000 o‘rniga 36 000')},
 html:"<p>Do'konda aksiya: «<b>2 tasini olsangiz, 3-si bepul</b>». Bitta sharbat 6000 so'm. 9 ta sharbat uchun qancha to'lanadi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['36 000','54 000','18 000','48 000'],'36 000',function(){w3Expr(['9 ta = 3 ta «to‘plam»','har to‘plamda 2 tasiga to‘lanadi','6 · 6000 = {36 000} so‘m']);w3Msg('To‘g‘ri!');done()},{'54 000':'Bu aksiyasiz narx (9 · 6000)','18 000':'Faqat 3 tasiga to‘lanmaydi — har to‘plamda 2 tasiga to‘lanadi','48 000':'Bepullar 1 ta emas, 3 ta (har 3 tadan bittasi)'})},
 after:"<p>Aksiya masalalarida avval «to'plam»ni aniqlang (2 + 1 = 3 ta), so'ng nechta to'plam borligini va har to'plamda nechtasiga pul to'lanishini toping.</p>",
 q:{t:"Do'konchi olmaning 1 kg ini 7000 so'mdan 50 kg oldi va 1 kg ini 9000 so'mdan sotdi. Qancha foyda ko'rdi?",opts:["100 000 so'm","2000 so'm","450 000 so'm","350 000 so'm"],ok:0,why:"(9000 − 7000) · 50 = 100 000.",hint:"Har kg dan foyda?",full:"Har kg dan 2000 so'm foyda, 50 kg dan 100 000. «2000» — faqat 1 kg; «450 000» — tushum, foyda emas."},
 tn:"Haqiqiy aksiya reklamalaridan rasm olib, bolalar bilan «haqiqatan foydalimi?» tahlilini qiling."},
{h:"Bilasizmi? Shtrix-kod",sum:"Do'kondagi birinchi shtrix-kod 1974-yilda AQShda saqich paketidan skanerlangan.",a:"m09",
 start:function(){var g=S.g;clear();for(var i=0;i<34;i++){var w=[2,1,3,1,2,4][i%6];E('rect',{x:110+i*4,y:30,width:w,height:90,fill:'#1d2b3a'},S.g)}T(S.g,180,140,'4 780000 123456',{'font-size':13,'font-weight':700,fill:'#1d2b3a'});w3Msg('Har bir tovarning o‘z «pasporti»')},fin:function(){clear();for(var i=0;i<34;i++){var w=[2,1,3,1,2,4][i%6];E('rect',{x:110+i*4,y:30,width:w,height:90,fill:'#1d2b3a'},S.g)}T(S.g,180,140,'4 780000 123456',{'font-size':13,'font-weight':700,fill:'#1d2b3a'});w3Msg('Har bir tovarning o‘z «pasporti»')},
 html:"<p>📜 Do'konda birinchi marta <b>shtrix-kod</b> 1974-yil 26-iyunda AQShning Ogayo shtatidagi supermarketda skanerlangan — bu bir paket saqich edi.</p><p>⭐ Shtrix-kod ichida tovar raqami yashiringan. Kassa uni o'qiydi, narxni topadi va <b>narx · miqdor</b> ni o'zi hisoblaydi. Siz bugun o'rgangan formula har bir kassada sekundiga minglab marta ishlaydi!</p>",
 tn:"Bolalar uydan har xil mahsulot qutilarini olib kelib, shtrix-kod ostidagi raqamlarni solishtirishsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e4Tri();w3Msg('Q = N · M,  N = Q : M,  M = Q : N')},fin:function(){e4Tri();w3Msg('Q = N · M,  N = Q : M,  M = Q : N')},
 html:"<div class='memo'><ul><li>Qiymat = narx · miqdor; narx = qiymat : miqdor; miqdor = qiymat : narx.</li><li>Birga keltirish: avval 1 dona (1 kg) narxini toping.</li><li>Qaysi arzon? — bir donaning narxini taqqoslang.</li><li>Pul o'zgarmasa: narx necha marta oshsa, miqdor shuncha marta kamayadi.</li><li>Bir xil miqdorda ikki mahsulot — «juftlik» narxi bilan hisoblang.</li><li>Qaytim = berilgan pul − (barcha xarid), qavsni unutmang.</li></ul></div>",
 tn:"4E5 (ish unumi) va 4E10 (proporsional kattaliklar) mavzularida shu uchburchak qayta ishlatiladi."}
];
var PROBS=[
{t:"Daftar 3500 so'm. 6 ta daftar necha so'm?",o:["21 000 so'm","18 000 so'm","3506 so'm","24 500 so'm"],k:0,s:"3500 · 6 = 21 000."},
{t:"7 ta bir xil daftar 17 500 so'm. Bittasi necha so'm?",o:["2500 so'm","122 500 so'm","17 493 so'm","3500 so'm"],k:0,s:"17 500 : 7 = 2500."},
{t:"48 000 so'mga 6000 so'mlik kitobdan nechta olish mumkin?",o:["8","6","42 000","80"],k:0,s:"48 000 : 6000 = 8."},
{t:"4 kg olma 36 000 so'm. 7 kg olma necha so'm?",o:["63 000 so'm","252 000 so'm","9000 so'm","27 000 so'm"],k:0,s:"1 kg = 9000; 9000 · 7 = 63 000."},
{t:"A paketda 3 ta qalam 4500 so'm, B paketda 5 ta qalam 7000 so'm. Bir dona qalam narxlari qanchaga farq qiladi?",o:["100 so'm","2500 so'm","1500 so'm","1400 so'm"],k:0,s:"1500 − 1400 = 100."},
{t:"3 kg olma (12 000 so'mdan) va 2 kg uzum (18 000 so'mdan) olib, 100 000 so'm berildi. Qaytim?",o:["28 000 so'm","70 000 so'm","72 000 so'm","30 000 so'm"],k:0,s:"100 000 − 72 000 = 28 000."},
{t:"Ali 3000 so'mlik daftardan 8 ta olishi mumkin edi. Shu pulga 4000 so'mlik daftardan nechta oladi?",o:["6","8","12","32"],k:0,s:"24 000 : 4000 = 6."},
{t:"Bir xil sonda daftar (2000 so'm) va ruchka (3000 so'm) olinib, 25 000 so'm to'landi. Nechta daftar olindi?",o:["5","12","8","10"],k:0,s:"25 000 : 5000 = 5."},
{t:"Pul o'zgarmasa, narx 2 marta oshganda olinadigan miqdor qanday o'zgaradi?",o:["2 marta kamayadi","2 marta oshadi","O'zgarmaydi","2 taga kamayadi"],k:0,s:"Miqdor = pul : narx."},
{t:"Paketda 6 ta sharbat 25 000 so'm, donasi 4500 so'm. Paketda olish qancha arzon?",o:["2000 so'm","20 500 so'm","500 so'm","4500 so'm"],k:0,s:"27 000 − 25 000 = 2000."},
{t:"5 kg shakar 60 000 so'm. 3 kg shakar necha so'm?",o:["36 000 so'm","20 000 so'm","180 000 so'm","12 000 so'm"],k:0,s:"12 000 · 3 = 36 000."},
{t:"Ruchka 2500 so'm. 42 000 so'mga eng ko'p ruchka olinsa, qancha pul qoladi?",o:["2000 so'm","0 so'm","1000 so'm","500 so'm"],k:0,s:"16 · 2500 = 40 000; 42 000 − 40 000 = 2000."},
{t:"Olmaning kg i 9000 so'm, nok olmadan 3000 so'm qimmat. 2 kg olma va 3 kg nok necha so'm?",o:["54 000 so'm","45 000 so'm","63 000 so'm","36 000 so'm"],k:0,s:"18 000 + 12 000 · 3 = 54 000."},
{t:"Qizil qalam 1500, ko'k qalam 2000 so'm. Jami 10 ta qalam 17 000 so'm turdi. Nechta qizil qalam olingan?",o:["6","4","5","8"],k:0,s:"Hammasi ko'k bo'lsa 20 000; har qizil 500 ga arzon: 3000 : 500 = 6."},
{t:"Sutning 1 litri 9000 so'm. Oila kuniga 2 litr ichadi. Bir haftada (7 kun) sutga qancha ketadi?",o:["126 000 so'm","63 000 so'm","18 000 so'm","252 000 so'm"],k:0,s:"9000 · 2 · 7 = 126 000."},
{t:"3 ta daftar va 2 ta kitob 25 000 so'm. Bitta kitob 8000 so'm. Bitta daftar necha so'm?",o:["3000 so'm","9000 so'm","8000 so'm","5000 so'm"],k:0,s:"25 000 − 16 000 = 9000; 9000 : 3 = 3000."},
{t:"Mato 5 metri 75 000 so'm. 8 metri necha so'm?",o:["120 000 so'm","15 000 so'm","600 000 so'm","78 000 so'm"],k:0,s:"15 000 · 8 = 120 000."},
{t:"Aksiya: «2 tasini olsangiz, 3-si bepul». Bitta sharbat 6000 so'm. 9 ta sharbat uchun qancha to'lanadi?",o:["36 000 so'm","54 000 so'm","18 000 so'm","48 000 so'm"],k:0,s:"3 to'plam × 2 · 6000 = 36 000."},
{t:"Uchta ruchkaning narxi ikkita daftar narxiga teng. Daftar 4500 so'm. Ruchka necha so'm?",o:["3000 so'm","6750 so'm","4500 so'm","13 500 so'm"],k:0,s:"9000 : 3 = 3000."},
{t:"Do'konchi 1 kg olmani 7000 so'mdan 50 kg oldi, 1 kg ini 9000 so'mdan sotdi. Foydasi?",o:["100 000 so'm","2000 so'm","450 000 so'm","350 000 so'm"],k:0,s:"2000 · 50 = 100 000."}
];
function PRACT_STAGE(){e4Tri();w3Msg('Q = N · M')}
var PREP_DATA={teach:["Narx, miqdor, qiymat va ular orasidagi bog'lanish.","Birga keltirish usuli.","Birlik narxi orqali xaridlarni taqqoslash; xarid va qaytim.","Teskari bog'liqlik; bir xil miqdorli ikki mahsulot; aksiya masalalari."],
 mist:["Umumiy narxni taqqoslab «arzon»ni tanlaydi (miqdorni hisobga olmaydi).","Birga keltirmasdan 36 000 · 7 deb hisoblaydi.","Narx oshsa miqdor ham oshadi deb o'ylaydi.","Qaytimda qavsni unutadi."],
 need:["O'yinchoq pullar, narx yorliqlari («do'kon» o'yini).","Haqiqiy chek va aksiya reklamalari."],
 board:["<span class='w2'>Q = N · M</span>.","<span class='w2'>4 kg — 36 000 → 1 kg — 9000 → 7 kg — 63 000</span>.","<span class='w2'>4500 : 3 = 1500 > 7000 : 5 = 1400</span>.","<span class='w2'>100 000 − (36 000 + 36 000) = 28 000</span>.","<span class='w2'>25 000 : (2000 + 3000) = 5</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
