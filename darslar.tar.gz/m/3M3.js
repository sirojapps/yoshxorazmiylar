var CODE='3M3',TITLE="3-sinf · Mulohazalar: rost va yolg'on";
function M3card(t,y,badge,o){o=o||{};var g=S.g,w=o.w||300,x=180-w/2;E('rect',{x:x,y:y,width:w,height:o.h||34,rx:9,fill:o.fill||'#fff',stroke:'#c9d3dd','stroke-width':1.6},g);
 T(g,badge?x+(w-62)/2:180,y+(o.h||34)/2+5,t,{'font-size':o.fs||13,'font-weight':700,fill:'#1d2b3a'});
 if(badge){var cl=badge==='R'?C.ok:badge==='Y'?C.bad:'#8a96a3';E('rect',{x:x+w-62,y:y+5,width:56,height:(o.h||34)-10,rx:6,fill:cl},g);T(g,x+w-34,y+(o.h||34)/2+4,badge==='R'?'ROST':badge==='Y'?"YOLG'ON":'—',{'font-size':10,'font-weight':800,fill:'#fff'})}}
// ketma-ket savollar: items [{t,k}], labels — tugmalar
function M3run(items,labels,draw){return labels.map(function(l,i){return [l,function(c,done,b){if(S.i>=items.length){done();return}
 if(items[S.i].k===i){S.ans3=S.ans3||[];S.ans3[S.i]=i;S.i++;draw();if(S.i>=items.length)done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1100);Y3msg(items[S.i].w||'Yo‘q, yana o‘ylang',C.bad)}}]})}
var M3BD=['R','Y','N'];
var M3I1=[{t:'7 + 5 = 12',k:0},{t:'Kvadratning 3 ta burchagi bor',k:1},{t:'Eshikni yoping!',k:2,w:'Buyruq — na rost, na yolg‘on'},{t:'Toshkent — O‘zbekiston poytaxti',k:0},{t:'Siz nechanchi sinfdasiz?',k:2,w:'Savol — na rost, na yolg‘on'},{t:'100 — uch xonali son emas',k:1}];
function M3d1(){clear();M3I1.forEach(function(it,i){var y=4+i*28;var b=i<S.i?M3BD[it.k]:null;M3card(it.t,y,b,{h:25,fs:12,w:320,fill:i===S.i?'#fff4d6':'#fff'})});
 Y3msg(S.i<M3I1.length?'Sariq gap: <b>rost</b>, <b>yolg‘on</b> yoki <b>mulohaza emas</b>?':'Mulohaza — rost yoki yolg‘onligini aytish mumkin bo‘lgan gap')}
var M3NEG=[['13 — juft son','Y'],['13 — juft son emas','R'],['Kubning 6 ta yog‘i bor','R'],['Kubning 6 ta yog‘i yo‘q','Y']];
function M3d2(){clear();var a=M3NEG[S.n],b=M3NEG[S.n^1];M3card(a[0],40,a[1],{h:40,fs:14});T(S.g,180,112,'«emas» qo‘shilsa / olib tashlansa — qiymat teskari bo‘ladi',{'font-size':11,fill:'#5b6b7b'});
 Y3msg(a[1]==='R'?'Rost ✓':'Yolg‘on ✗')}
var M3I3=[{t:'A: 12 — juft son',k:0},{t:'B: 12 > 20',k:1},{t:'A va B',k:1,w:'«va» — ikkalasi ham rost bo‘lishi kerak'},{t:'A yoki B',k:0,w:'«yoki» — kamida bittasi rost bo‘lsa yetadi'}];
function M3d3(){clear();M3I3.forEach(function(it,i){M3card(it.t,8+i*40,i<S.i?M3BD[it.k]:null,{h:32,fs:13,fill:i===S.i?'#fff4d6':'#fff'})});
 Y3msg(S.i<M3I3.length?'Sariq mulohaza rostmi yoki yolg‘onmi?':'«va» — ikkalasi rost bo‘lsa rost. «yoki» — bittasi rost bo‘lsa yetadi')}
function M3bird(fin){clear();var g=S.g;for(var i=0;i<5;i++){var x=50+i*65;E('ellipse',{cx:x,cy:70,rx:20,ry:14,fill:i===4?'#2b2b2b':C.b,stroke:C.line},g);E('circle',{cx:x+16,cy:58,r:8,fill:i===4?'#2b2b2b':C.b,stroke:C.line},g);E('path',{d:'M'+(x+23)+' 57 l7 2 l-7 2 Z',fill:C.a},g);T(g,x,108,i===4?'pingvin':'qush',{'font-size':10,fill:'#5b6b7b'});if(i===4&&fin){E('path',{d:'M'+(x-22)+' 46 L'+(x+26)+' 92 M'+(x+26)+' 46 L'+(x-22)+' 92',stroke:C.bad,'stroke-width':3},g)}}
 M3card('Hamma qushlar ucha oladi',124,fin?'Y':null,{h:32,fs:13});Y3msg(fin?'Bitta pingvin yetadi: <b>ba‘zi qushlar ucha olmaydi</b>':'Bu mulohazaning inkori qaysi?')}
function M3isl(fin){clear();var g=S.g;[[110,'A'],[250,'B']].forEach(function(p,i){var x=p[0];E('circle',{cx:x,cy:96,r:16,fill:'#f6d3b0',stroke:C.line},g);E('rect',{x:x-16,y:114,width:32,height:40,rx:8,fill:fin?(i?C.ok:C.bad):'#8fb7dc',stroke:C.line},g);T(g,x,138,p[1],{'font-size':14,'font-weight':800,fill:'#fff'})});
 E('rect',{x:20,y:12,width:190,height:44,rx:12,fill:'#fff',stroke:C.line,'stroke-width':1.4},g);E('path',{d:'M100 56 l10 20 l6 -20 Z',fill:'#fff',stroke:C.line},g);T(g,115,40,'«Ikkalamiz ham yolg‘onchimiz»',{'font-size':12,'font-weight':700,fill:'#1d2b3a'});
 if(fin){T(g,110,170,"yolg'onchi",{'font-size':11,'font-weight':800,fill:C.bad});T(g,250,170,"rostgo'y",{'font-size':11,'font-weight':800,fill:C.ok})}
 Y3msg(fin?'A rostgo‘y bo‘lsa — o‘zini yolg‘onchi demasdi. Demak A yolg‘onchi, gapi yolg‘on → B <b>rostgo‘y</b>':'Rostgo‘ylar doim rost, yolg‘onchilar doim yolg‘on gapiradi')}
var M3SAY=[['Ali','«Men yemadim»'],['Vali','«Ali yedi»'],['Soli','«Vali yemadi»']];
function M3tv(h,ate){return h===0?ate!==0:h===1?ate===0:ate!==1}
function M3d6(ate){clear();var g=S.g;T(g,180,18,ate==null?'Olmani bittasi yedi. Faqat BITTASI rost gapirdi.':M3SAY[ate][0]+' yegan bo‘lsa:',{'font-size':12,'font-weight':800,fill:C.blue});var cnt=0;
 M3SAY.forEach(function(s,i){var y=32+i*38;var v=ate==null?null:M3tv(i,ate);if(v)cnt++;M3card(s[0]+': '+s[1],y,v==null?null:(v?'R':'Y'),{h:32,fs:13})});
 if(ate!=null)T(g,180,160,'Rost gaplar: '+cnt+(cnt===1?' ✓ — mos keladi!':' ✗ — shart bajarilmadi'),{'font-size':13,'font-weight':800,fill:cnt===1?C.ok:C.bad});
 Y3msg(ate==null?'Har bir «gumondor»ni sinab ko‘ring':(cnt===1?'<b>'+M3SAY[ate][0]+'</b> yegan — faqat shunda bitta gap rost':'Bu holda '+cnt+' ta gap rost — to‘g‘ri emas'))}
function M3box(fin){clear();var g=S.g,tx=[['«Tanga','2-qutida»'],['«Tanga 3-qutida','emas»'],['«Tanga shu','qutida emas»']],tv=['Y','R','R'];
 for(var i=0;i<3;i++){var x=18+i*116;E('rect',{x:x,y:44,width:100,height:70,rx:6,fill:'#e8c58e',stroke:'#9b6a2a','stroke-width':2},g);T(g,x+50,34,(i+1)+'-quti',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});
  E('rect',{x:x+4,y:70,width:92,height:38,rx:4,fill:'#fff'},g);T(g,x+50,85,tx[i][0],{'font-size':11,'font-weight':700,fill:'#1d2b3a'});T(g,x+50,101,tx[i][1],{'font-size':11,'font-weight':700,fill:'#1d2b3a'});
  if(fin){T(g,x+50,134,tv[i]==='R'?'ROST':"YOLG'ON",{'font-size':11,'font-weight':800,fill:tv[i]==='R'?C.ok:C.bad});if(i===0)E('circle',{cx:x+50,cy:57,r:9,fill:'#f2c230',stroke:'#a37b00','stroke-width':1.5},g)}}
 Y3msg(fin?'Tanga 1-qutida: faqat 1-yozuv yolg‘on ✓':'Bitta qutida tanga bor. Yozuvlardan <b>faqat bittasi yolg‘on</b>. Tanga qayerda?')}
function M3sil(k){clear();var L=['Hamma odamlar o‘qishni o‘rganishi mumkin.','Kamol — odam.','Demak, Kamol o‘qishni o‘rganishi mumkin.'];for(var i=0;i<k;i++)M3card(L[i],14+i*46,null,{h:36,fs:12,w:330,fill:i===2?'#e3f5ea':'#fff'});
 Y3msg(k<3?'Ikki rost mulohazadan…':'…yangi rost mulohaza kelib chiqadi — bu <b>mantiq</b>')}
var STEPS=[
{h:"Mulohaza nima?",sum:"Mulohaza — rost yoki yolg'onligini aytish mumkin bo'lgan gap. Savol va buyruq — mulohaza emas.",a:"m01",start:function(){S.i=0;M3d1()},fin:function(){S.i=M3I1.length;M3d1()},
 html:"<p><b>Mulohaza</b> — rost yoki yolg'on deb aytish mumkin bo'lgan gap. Har bir sariq gapni baholang.</p>",
 btns:M3run(M3I1,['✓ Rost',"✗ Yolg'on",'— Emas'],M3d1),g3:1,
 after:"<p>«7 + 5 = 12» — rost mulohaza, «Kvadratning 3 ta burchagi bor» — yolg'on mulohaza. «Eshikni yoping!» (buyruq) va «Siz nechanchi sinfdasiz?» (savol) — <b>mulohaza emas</b>: ularni rost yoki yolg'on deb bo'lmaydi.</p>",
 q:{t:"Qaysi gap mulohaza EMAS?",opts:["5 > 8","Daftaringizni oching!","Kubning 8 ta uchi bor","Quyosh — yulduz"],ok:1,why:"Buyruqni rost yoki yolg'on deb bo'lmaydi.",hint:"Qaysi gapga «rost» yoki «yolg'on» deb javob bera olmaysiz?",full:"«5 > 8» — yolg'on mulohaza (yolg'on ham mulohaza!). «Kubning 8 ta uchi bor», «Quyosh — yulduz» — rost. «Daftaringizni oching!» — buyruq, mulohaza emas."},
 tn:"Bolalar har gapga «rost» kartochkasi (yashil) yoki «yolg'on» (qizil) ko'tarsin. Savol yoki buyruqda hech narsa ko'tarmaydi."},
{h:"«Emas» — inkor",sum:"«emas» qo'shilsa mulohazaning qiymati teskarisiga almashadi: rost → yolg'on, yolg'on → rost.",a:"m02",start:function(){S.n=0;M3d2()},fin:function(){S.n=3;M3d2()},
 html:"<p>Mulohazaga <b>«emas»</b> so'zini qo'shsak, nima bo'ladi? Tugmani bosib ko'ring.</p>",
 btns:[["🔁 «emas» qo‘shish / olish",function(c,done){S.n=(S.n+1)%4;M3d2();S.t2=(S.t2||0)+1;if(S.t2>=3)done()}]],
 after:"<p>«13 — juft son» yolg'on, uning <b>inkori</b> «13 — juft son emas» — rost. Inkor har doim teskari qiymat beradi. Inkorning inkori — asl mulohazaning o'zi.</p>",
 q:{t:"«9 — toq son» mulohazasining inkori qaysi?",opts:["9 — juft son emas","9 — toq son emas","10 — toq son","9 — 3 ga bo'linadi"],ok:1,why:"Inkor — «emas» qo'shilgan gap: «9 — toq son emas».",hint:"Inkor asl gapga qarama-qarshi qiymatga ega bo'lishi kerak.",full:"Inkor — «9 — toq son emas» (yolg'on, chunki asl gap rost). «9 — juft son emas» esa rost — u asl gap bilan bir xil ma'noni bildiradi, inkor emas."},
 tn:"Juftlik o'yini: bir bola mulohaza aytadi, ikkinchisi inkorini aytadi va qaysi biri rostligini birga hal qiladi."},
{h:"«Va» hamda «yoki»",sum:"«A va B» — ikkalasi rost bo'lsa rost. «A yoki B» — kamida bittasi rost bo'lsa rost.",a:"m03",start:function(){S.i=0;M3d3()},fin:function(){S.i=M3I3.length;M3d3()},
 html:"<p>Ikki mulohazani <b>«va»</b>, <b>«yoki»</b> bilan birlashtirish mumkin. Har birini baholang.</p>",
 btns:M3run(M3I3,['✓ Rost',"✗ Yolg'on"],M3d3),g2:1,
 after:"<p>A rost, B yolg'on. <b>«A va B»</b> — yolg'on (ikkalasi rost bo'lishi shart). <b>«A yoki B»</b> — rost (bittasi rost bo'lsa yetadi).</p>",
 q:{t:"Qaysi mulohaza rost?",opts:["7 > 5 va 7 < 3","7 > 5 yoki 7 < 3","7 < 5 yoki 7 < 3","7 < 5 va 7 > 3"],ok:1,why:"7 > 5 rost, shuning uchun «yoki» bilan birlashma rost.",hint:"Har bo'lakni alohida tekshiring: 7 > 5? 7 < 3?",full:"7 > 5 — rost, 7 < 3 — yolg'on, 7 < 5 — yolg'on. «va» bilan: ikkalasi rost bo'lmagani uchun yolg'on. «7 > 5 yoki 7 < 3» — bittasi rost, demak rost. «7 < 5 yoki 7 < 3» — ikkalasi yolg'on."},
 tn:"Hayotiy misol: «Bugun matematika VA tarbiya darsi bor» va «Bugun matematika YOKI tarbiya bor» — jadvalga qarab tekshirish."},
{h:"«Hamma» va «ba'zi»",sum:"«Hamma … » ning inkori — «Ba'zi … emas». Rad etish uchun bitta misol yetadi.",a:"m04",start:function(){M3bird(0)},fin:function(){M3bird(1)},
 html:"<p>«<b>Hamma</b> qushlar ucha oladi» — yolg'on, chunki pingvin ucha olmaydi. Bu mulohazaning to'g'ri inkori qaysi?</p>",
 btns:Y3ch(["Hech bir qush ucha olmaydi","Ba'zi qushlar ucha olmaydi","Hamma qushlar ucha olmaydi"],1,function(){M3bird(1)},'Bitta pingvin «hech bir qush ucha olmaydi» degani emas!'),
 after:"<p>«Hamma … » ni rad etish uchun <b>bitta</b> qarshi misol yetadi. Inkori: «<b>Ba'zi</b> qushlar ucha olmaydi» (kamida bittasi). «Hech bir qush ucha olmaydi» — juda kuchli va yolg'on.</p>",
 q:{t:"«Sinfimizdagi hamma o'quvchilar shaxmat o'ynaydi» — yolg'on. Demak:",opts:["Hech kim shaxmat o'ynamaydi","Kamida bitta o'quvchi shaxmat o'ynamaydi","Ko'pchilik shaxmat o'ynamaydi","Faqat bitta o'quvchi o'ynamaydi"],ok:1,why:"«Hamma» yolg'on bo'lsa, kamida bitta istisno bor — bundan ortiq hech narsa bilmaymiz.",hint:"«Hamma» yolg'on bo'lishi uchun eng kamida nima kerak?",full:"«Hamma o'ynaydi» yolg'on → kamida bitta o'quvchi o'ynamaydi. Nechta ekanini bilmaymiz: bitta ham, ko'pchilik ham bo'lishi mumkin. «Hech kim» — juda kuchli xulosa."},
 tn:"«Hamma — ba'zi — hech biri» uchligini doskaga yozing. Har birini sinf haqidagi gap bilan tekshiring."},
{h:"Rostgo'ylar va yolg'onchilar oroli",sum:"A: «Ikkalamiz ham yolg'onchimiz». A rostgo'y bo'la olmaydi → A yolg'onchi → gapi yolg'on → B rostgo'y.",a:"m05",start:function(){M3isl(0)},fin:function(){M3isl(1)},
 html:"<p>Orolda <b>rostgo'ylar</b> doim rost, <b>yolg'onchilar</b> doim yolg'on gapiradi. A dedi: «Ikkalamiz ham yolg'onchimiz». A va B kimlar?</p>",
 btns:Y3ch(["A — rostgo'y, B — yolg'onchi","A — yolg'onchi, B — rostgo'y","Ikkalasi yolg'onchi","Ikkalasi rostgo'y"],1,function(){M3isl(1)},'Taxmin qilib tekshiring: A rostgo‘y bo‘lsa, gapi rost bo‘lardi — mumkinmi?'),
 after:"<p>Usul — <b>taxmin qilib tekshirish</b>. A rostgo'y bo'lsa, «men yolg'onchiman» degan bo'lardi — ziddiyat. Demak A yolg'onchi va gapi yolg'on: «ikkalasi yolg'onchi» emas → <b>B rostgo'y</b>.</p>",
 q:{t:"Orolda A: «B rostgo'y» dedi. B: «Men va A har xil turdamiz» dedi. Ular kim?",opts:["A rostgo'y, B yolg'onchi","Ikkalasi yolg'onchi","Ikkalasi rostgo'y","A yolg'onchi, B rostgo'y"],ok:1,why:"B rostgo'y bo'lsa, A yolg'onchi — lekin A ning «B rostgo'y» gapi rost bo'lib qoladi. Ziddiyat. Demak B yolg'onchi → ular bir xil → A ham yolg'onchi.",hint:"B rostgo'y deb taxmin qiling va A ning gapini tekshiring.",full:"B rostgo'y desak: A va B har xil → A yolg'onchi, lekin A «B rostgo'y» deb rost gapirgan bo'ladi — mumkin emas. Demak B yolg'onchi, gapi yolg'on: ular bir xil → A ham yolg'onchi. Tekshiruv: A «B rostgo'y» — yolg'on ✓."},
 tn:"Ikki o'quvchini «A» va «B» qilib sahnalashtiring. Sinf har taxminni jadvalda tekshirsin."},
{h:"Faqat bittasi rost",sum:"Har gumondor uchun gaplarni tekshirib, rost gaplar sonini sanaymiz: faqat Vali yegan holda bitta gap rost.",a:"m06",start:function(){S.d={};M3d6(null)},fin:function(){M3d6(1)},
 html:"<p>Olmani uch boladan biri yedi. Ali: «Men yemadim». Vali: «Ali yedi». Soli: «Vali yemadi». Ulardan <b>faqat bittasi rost</b> gapirdi. Har gumondorni sinab ko'ring:</p>",
 btns:[0,1,2].map(function(k){return [M3SAY[k][0]+'?',function(c,done){S.d[k]=1;M3d6(k);if(S.d[0]&&S.d[1]&&S.d[2])done()}]}),g3:1,
 after:"<p>Ali yegan bo'lsa — 2 gap rost ✗. Soli yegan bo'lsa — 2 gap rost ✗. Faqat <b>Vali</b> yegan bo'lsa — bitta gap (Alining gapi) rost ✓. Har holatni oxirigacha tekshirish — olimpiada masalalarining kaliti.</p>",
 q:{t:"Guldonni bittasi sindirdi. Anvar: «Botir sindirdi». Botir: «Men sindirmadim». Davron: «Men sindirmadim». Faqat bittasi rost gapirdi. Kim sindirgan?",opts:["Botir","Davron","Anvar","Botir yoki Anvar"],ok:1,why:"Davron sindirgan bo'lsa: Anvar — yolg'on, Botir — rost, Davron — yolg'on: bitta rost ✓.",hint:"Har birini sindirgan deb faraz qilib, rost gaplarni sanang.",full:"Anvar sindirgan bo'lsa: Botir va Davron rost — 2 ta ✗. Botir: Anvar va Davron rost — 2 ta ✗. Davron: faqat Botir rost — 1 ta ✓. Javob — Davron."},
 tn:"Doskada jadval: ustunlarda gumondorlar, qatorlarda gaplar; kataklarga R/Y yozing — eng ishonchli usul."},
{h:"Qutilar jumbog'i",sum:"Faqat bitta yozuv yolg'on: tanga 1-qutida bo'lsagina shunday bo'ladi.",a:"m07",start:function(){M3box(0)},fin:function(){M3box(1)},
 html:"<p>Uchta qutidan birida tanga bor. Qutilardagi yozuvlardan <b>faqat bittasi yolg'on</b>. Tanga qaysi qutida?</p>",
 btns:Y3ch(["1-quti","2-quti","3-quti"],0,function(){M3box(1)},'Shu qutida deb faraz qilib, nechta yozuv yolg‘on bo‘lishini sanang'),g3:1,
 after:"<p>Tanga 1-qutida: «2-qutida» — yolg'on, «3-qutida emas» — rost, «shu qutida emas» — rost. Bitta yolg'on ✓. 2-qutida bo'lsa — hammasi rost ✗; 3-qutida — hammasi yolg'on ✗.</p>",
 q:{t:"Uch qutidan birida sovg'a bor. 1: «Sovg'a shu yerda». 2: «Sovg'a shu yerda emas». 3: «Sovg'a 1-qutida emas». Faqat bitta yozuv rost. Sovg'a qayerda?",opts:["1-qutida","2-qutida","3-qutida","Hech qayerda"],ok:1,why:"2-qutida bo'lsa: 1 — yolg'on, 2 — yolg'on, 3 — rost: bitta rost ✓.",hint:"Har qutini sinab, rost yozuvlarni sanang.",full:"1-qutida: 1 va 2 rost — 2 ta ✗. 2-qutida: faqat 3-yozuv rost ✓. 3-qutida: 2 va 3 rost — 2 ta ✗. Javob: 2-quti."},
 tn:"Uchta haqiqiy quti va tanga bilan o'ynash mumkin: bir o'quvchi yashiradi va yozuvlarni qoida bo'yicha yozadi."},
{h:"Bilasizmi? Al-Forobiy",sum:"Abu Nasr al-Forobiy (IX–X asr) mantiq ilmini rivojlantirgan; «Ikkinchi muallim» deb atalgan.",a:"m08",start:function(){M3sil(1)},fin:function(){M3sil(3)},
 html:"<p>📜 Buyuk olim <b>Abu Nasr al-Forobiy</b> (870–950 yillar atrofida, Forob shahri) mantiq — to'g'ri fikrlash ilmi bo'yicha ko'plab asarlar yozgan. Uni Aristoteldan keyingi «<b>Ikkinchi muallim</b>» deb atashgan. Mantiq — rost mulohazalardan yangi rost xulosa chiqarishni o'rgatadi.</p>",
 btns:[["➕ Keyingi mulohaza",function(c,done){S.k3=(S.k3||1)+1;M3sil(Math.min(S.k3,3));if(S.k3>=3)done()}]],
 after:"<p>Ikki rost mulohazadan uchinchisi kelib chiqdi. Shunday zanjirlar orqali matematiklar teoremalarni isbotlaydi.</p>",
 tn:"Bolalar o'z «mantiq zanjiri»ni tuzsin: «Hamma … ; … ; demak …»."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){M3box(1)},fin:function(){M3box(1)},
 html:"<div class='memo'><ul><li><b>Mulohaza</b> — rost yoki yolg'on deb aytish mumkin bo'lgan gap. Savol, buyruq — mulohaza emas.</li><li><b>«emas»</b> — qiymatni teskarisiga almashtiradi.</li><li><b>«va»</b> — ikkalasi rost bo'lsa rost; <b>«yoki»</b> — bittasi rost bo'lsa yetadi.</li><li>«Hamma …» inkori — «Ba'zi … emas»; rad etish uchun bitta misol yetadi.</li><li>Jumboqlarda: har holatni <b>faraz qilib</b> tekshiring va rost gaplarni sanang.</li></ul></div>",
 tn:"Uyga: o'z «faqat bittasi rost» jumbog'ingizni tuzing va javobi yagona ekanini tekshiring."}
];
var PROBS=[
{t:"Qaysi gap mulohaza emas?",o:["Daftaringni och!","5 > 3","Kub — shar","Toshkent — shahar"],k:0,s:"Buyruqni rost yoki yolg'on deb bo'lmaydi."},
{t:"Qaysi mulohaza rost?",o:["8 · 7 = 56","9 · 6 = 56","7 · 7 = 48","6 · 8 = 46"],k:0,s:"8 · 7 = 56."},
{t:"«15 — toq son» mulohazasining inkori qaysi?",o:["15 — toq son emas","15 — juft son emas","16 — toq son","15 — 5 ga bo'linadi"],k:0,s:"Inkor — «emas» qo'shilgan gap."},
{t:"«Hamma mushuklar qora» mulohazasining inkori qaysi?",o:["Ba'zi mushuklar qora emas","Hech bir mushuk qora emas","Hamma mushuklar oq","Ba'zi mushuklar qora"],k:0,s:"«Hamma» ning inkori — «ba'zi … emas»."},
{t:"Qaysi mulohaza rost?",o:["Ba'zi uchburchaklarning to'g'ri burchagi bor","Hamma uchburchaklarning to'g'ri burchagi bor","Hech bir uchburchakning to'g'ri burchagi yo'q","Hamma to'rtburchaklar kvadrat"],k:0,s:"To'g'ri burchakli uchburchaklar bor, lekin hammasi emas."},
{t:"Qaysi mulohaza rost?",o:["7 > 5 yoki 7 < 3","7 > 5 va 7 < 3","7 < 5 yoki 7 < 3","7 < 5 va 7 > 3"],k:0,s:"«yoki» — bittasi rost bo'lsa yetadi."},
{t:"Qaysi son uchun «son juft va 3 ga bo'linadi» rost?",o:["18","16","15","21"],k:0,s:"18 juft va 18 : 3 = 6."},
{t:"Qaysi son uchun «son 10 dan katta yoki 5 ga bo'linadi» yolg'on?",o:["7","15","5","12"],k:0,s:"7 ≤ 10 va 5 ga bo'linmaydi — ikkalasi yolg'on."},
{t:"A: «20 — juft son», B: «20 > 30». «A va B» hamda «A yoki B» qanday?",o:["yolg'on; rost","rost; rost","yolg'on; yolg'on","rost; yolg'on"],k:0,s:"A rost, B yolg'on: «va» — yolg'on, «yoki» — rost."},
{t:"«Sinfdagi hamma o'quvchilar suzishni biladi» — yolg'on. Demak:",o:["Kamida bitta o'quvchi suzishni bilmaydi","Hech kim suzishni bilmaydi","Ko'pchilik suzishni bilmaydi","Faqat bitta o'quvchi suzishni bilmaydi"],k:0,s:"«Hamma» yolg'on → kamida bitta istisno."},
{t:"«Agar yomg'ir yog'sa, yo'l ho'l bo'ladi» — rost. Yo'l quruq. Demak:",o:["Yomg'ir yog'magan","Yomg'ir yoqqan","Yo'l ho'l","Ertaga yomg'ir yog'adi"],k:0,s:"Yomg'ir yoqqanida yo'l ho'l bo'lardi."},
{t:"Orolda rostgo'ylar doim rost, yolg'onchilar doim yolg'on gapiradi. Orol aholisidan hech kim qaysi gapni ayta olmaydi?",o:["Men yolg'onchiman","Men rostgo'yman","2 + 2 = 5","Osmon ko'k"],k:0,s:"Rostgo'y o'zini yolg'onchi demaydi, yolg'onchi aytsa — gapi rost bo'lib qoladi."},
{t:"Orolda A dedi: «Ikkalamiz ham yolg'onchimiz». A va B kimlar?",o:["A — yolg'onchi, B — rostgo'y","A — rostgo'y, B — yolg'onchi","Ikkalasi yolg'onchi","Ikkalasi rostgo'y"],k:0,s:"A rostgo'y bo'la olmaydi; gapi yolg'on → B rostgo'y."},
{t:"Aziz, Bek va Sardor — shifokor, o'qituvchi va haydovchi (har xil). Aziz shifokor emas, Bek — haydovchi. Qaysi to'g'ri?",o:["Aziz — o'qituvchi, Sardor — shifokor","Aziz — shifokor, Sardor — o'qituvchi","Aziz — haydovchi, Sardor — shifokor","Aziz — o'qituvchi, Sardor — haydovchi"],k:0,s:"Bek haydovchi; Aziz shifokor emas → o'qituvchi; Sardor — shifokor."},
{t:"Anvar: «Botir sindirdi». Botir: «Men sindirmadim». Davron: «Men sindirmadim». Faqat bittasi rost. Kim sindirgan?",o:["Davron","Botir","Anvar","Botir yoki Anvar"],k:0,s:"Faqat Davron sindirgan holda bitta gap (Botirniki) rost."},
{t:"1-quti: «Sovg'a shu yerda». 2-quti: «Sovg'a shu yerda emas». 3-quti: «Sovg'a 1-qutida emas». Faqat bitta yozuv rost. Sovg'a qayerda?",o:["2-qutida","1-qutida","3-qutida","Hech qayerda"],k:0,s:"2-qutida bo'lsa faqat 3-yozuv rost."},
{t:"Uch boladan biri tortni yedi. Nodir: «Olim yedi». Olim: «Said yedi». Said: «Men yemadim». Faqat bittasi yolg'on gapirdi. Kim yegan?",o:["Olim","Nodir","Said","Nodir yoki Said"],k:0,s:"Olim yegan bo'lsa: Nodir — rost, Olim — yolg'on, Said — rost: bitta yolg'on ✓."},
{t:"Qizil, ko'k, yashil qalamlar 3 qutida (har birida bitta rang). Yozuvlarning HAMMASI yolg'on: 1: «qizil», 2: «ko'k», 3: «qizil yoki ko'k». Qaysi to'g'ri?",o:["1 — ko'k, 2 — qizil, 3 — yashil","1 — yashil, 2 — qizil, 3 — ko'k","1 — ko'k, 2 — yashil, 3 — qizil","1 — qizil, 2 — ko'k, 3 — yashil"],k:0,s:"3-yozuv yolg'on → 3 — yashil; 1 qizil emas → ko'k; 2 — qizil."},
{t:"Orolda A: «B rostgo'y». B: «Men va A har xil turdamiz». Ular kim?",o:["Ikkalasi yolg'onchi","A rostgo'y, B yolg'onchi","Ikkalasi rostgo'y","A yolg'onchi, B rostgo'y"],k:0,s:"B rostgo'y bo'lsa ziddiyat; demak B yolg'onchi, ular bir xil — A ham yolg'onchi."},
{t:"Orolda A: «B yolg'onchi». B: «C yolg'onchi». C: «A ham, B ham yolg'onchi». Kim rostgo'y?",o:["Faqat B","Faqat C","A va C","Faqat A"],k:0,s:"C rostgo'y bo'lsa A, B yolg'onchi, lekin unda B rostgo'y bo'lib chiqadi — ziddiyat. C yolg'onchi → B rost gapirgan → A yolg'on gapirgan."}
];
function PRACT_STAGE(){M3box(1)}
var PREP_DATA={teach:["Mulohaza va mulohaza bo'lmagan gaplar.","Inkor («emas»), «va», «yoki».","«Hamma», «ba'zi», «hech biri» va ularning inkori.","Rostgo'ylar va yolg'onchilar, «faqat bittasi rost» jumboqlari.","Al-Forobiy va mantiq."],
 mist:["Yolg'on gapni «mulohaza emas» deb o'ylaydi.","«Hamma» ning inkorini «hech biri» deb oladi.","«yoki» da ikkalasi rost bo'lishi shart deb hisoblaydi.","Jumboqda bitta holatni tekshirib, qolganlarini tekshirmaydi."],
 need:["Yashil va qizil kartochkalar (R/Y).","3 ta quti va tanga.","Doskada R/Y jadval."],
 board:["<span class='w2'>A va B</span>: R faqat R+R.","<span class='w2'>A yoki B</span>: Y faqat Y+Y.","«Hamma» ↔ «Ba'zi … emas».","Jadval: gumondor | gaplar | R soni."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
