var CODE='4C3',TITLE='4-sinf · Nol bilan tugaydigan sonlarni ko‘paytirish va bo‘lish';
var P1=[function(){W3eq(['340 · 60 = ?']);W3msg('Ikkala sonning oxirida nol bor')},
 function(){W3eq(['340 = 34 · 10','60 = 6 · 10']);W3msg('Nollarni «o‘nlar» sifatida ajratamiz')},
 function(){W3eq(['34 · 6 = 204','10 · 10 = 100']);W3msg('Raqamli qismini ko‘paytiramiz, nollar alohida')},
 function(){W3eq(['204 · 100 = [20 400]']);W3msg('340 · 60 = <b>20 400</b>','Qoida: nollarsiz ko‘paytirib, oxiriga ikkala sondagi nollarni yozamiz (1 + 1 = 2 ta)')}];
var P3=[function(){W3eq(['4 800 : 600 = ?']);W3msg('Ikkala sonda ham nollar bor')},
 function(){W3eq(['4 800 = 48 yuz','600 = 6 yuz']);W3msg('Ikkalasini <b>yuzlik</b>larda o‘lchaymiz')},
 function(){W3eq(['48 yuz : 6 yuz = [8]']);W3msg('48 ta yuzlikda 6 ta yuzlik <b>8</b> marta bor','Bo‘linuvchi va bo‘luvchidan bir xil sondagi nollarni o‘chirsak, bo‘linma o‘zgarmaydi')}];
var P5=[function(){W3eq(['36 000 : 400 = ?'])},
 function(){W3eq(['36 0[00] : 4[00]']);W3msg('Ikkalasidan <b>ikkitadan</b> nol o‘chiramiz')},
 function(){W3eq(['360 : 4 = [90]']);W3msg('36 000 : 400 = <b>90</b>','Bo‘linuvchida qolgan nol javobga o‘tdi: 36 : 4 = 9, 360 : 4 = 90')}];
var P7=[function(){W3eq(['1 soatda 450 ta']);W3msg('Zavod soatiga 450 ta detal chiqaradi. Smena — 8 soat. 30 kunda?')},
 function(){W3eq(['450 · 8 = 3 600']);W3msg('Bir smenada: 45 · 8 = 360, + 0 → <b>3 600</b>')},
 function(){W3eq(['450 · 8 = 3 600','3 600 · 30 = [108 000]']);W3msg('36 · 3 = 108, nollar 2 + 1 = 3 → <b>108 000</b> ta')}];
var STEPS=[
{h:"Ko'paytirish: nollar alohida",sum:"340 · 60 = 34 · 6 · 100 = 20 400.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Nol bilan tugaydigan sonlar — eng tez hisoblanadigan sonlar. Tugmani bosing.</p>",btns:[phaser(P1)],
 after:"<p><b>Qoida:</b> nollarni chetga qo'yib, qolgan sonlarni ko'paytiramiz, keyin oxiriga ikkala sondagi <b>barcha nollarni</b> yozamiz.</p>",
 q:{t:"520 · 300 = ?",opts:["156 000","15 600","1 560 000","15 6000"],ok:0,why:"52 · 3 = 156, nollar 1 + 2 = 3.",hint:"Nechta nol bor jami?",full:"52 · 3 = 156. 520 da bitta, 300 da ikkita nol — jami 3 ta: 156 000. «15 600» — bitta nol yo'qolgan."},
 tn:"O'nlik bloklar bilan: 34 o'nlik · 6 o'nlik = 204 yuzlik. Bolalar «o'nlik · o'nlik = yuzlik»ni o'zi aytsin."},
{h:"Tuzoq: natijaning o'z noli",sum:"2 500 · 40 = 25 · 4 · 1 000 = 100 · 1 000 = 100 000.",a:"m02",start:function(){C4col(['.2500','×..40','─────','..???'],'2 500 · 40 = ?')},fin:function(){C4col(['..2500','×....40','──────','{100}000'])},
 html:"<p><b>2 500 · 40</b>. Bolalar uch xil javob topishdi. Qaysi biri to'g'ri?</p>",
 btns:[["100 000",function(c,done){C4col(['..2500','×....40','──────','{100}000'],'25 · 4 = <b>100</b> — o‘zida 2 ta nol bor! Yana 3 ta nol: <b>100 000</b>');done()}],["10 000",function(){W3eq(['25 · 4 = 1[0]0','+ 000 → 10 000?']);W3msg('Bu bola 25 · 4 = 10 deb o‘ylagan. 25 · 4 = 100!','Qayta tanlang')}],["1 000",function(){W3eq(['25 · 4 = 100','+ nollar?']);W3msg('2 500 va 40 dagi 3 ta nol ham qo‘shilishi kerak','Qayta tanlang')}]],g3:1,
 after:"<p>Ko'paytmada nollar soni sondagi nollardan <b>ko'p</b> bo'lishi mumkin: 25 · 4 = 100, 5 · 2 = 10, 50 · 20 = 1 000. Shuning uchun «nollarni sanash» emas, <b>qoidani</b> to'liq bajaring.</p>",
 q:{t:"5 000 · 60 = ?",opts:["300 000","30 000","3 000 000","56 000"],ok:0,why:"5 · 6 = 30, + 4 ta nol.",hint:"5 · 6 = 30 — bu yerda ham nol bor.",full:"5 · 6 = 30, sonlarda 3 + 1 = 4 ta nol: 30 + 0000 = 300 000. «30 000» — 30 ning nolini nollarga qo'shib sanagan."},
 tn:"Doskaga «25 · 4 = 100, 125 · 8 = 1 000, 5 · 2 = 10» — «do'st juftlar»ni yozib qo'ying."},
{h:"Bo'lish: nollarni qisqartirish",sum:"4 800 : 600 = 48 : 6 = 8.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Bo'lishda nollar boshqacha ishlaydi. Kuzating.</p>",btns:[phaser(P3)],
 after:"<p>Bo'linuvchi va bo'luvchining <b>ikkalasidan</b> bir xil sondagi nolni o'chirsak, bo'linma o'zgarmaydi. Sababi: ikkalasi bir xil «birlik»da (o'nlik, yuzlik) o'lchanadi.</p>",
 q:{t:"6 300 : 700 = ?",opts:["9","90","900","63"],ok:0,why:"63 : 7 = 9.",hint:"Ikkalasidan ikkitadan nol.",full:"6 300 = 63 yuz, 700 = 7 yuz. 63 : 7 = 9. «90» — bo'linuvchidan bitta nol o'chirilmay qolgan."},
 tn:"Pul bilan: 4 800 so'm 600 so'mdan — 48 ta yuz so'mlik 6 tadan guruhga."},
{h:"Tuzoq: nechta nol o'chiriladi?",sum:"72 000 : 90 = 7 200 : 9 = 800 — faqat bittadan nol o'chiriladi.",a:"m04",start:function(){W3eq(['72 000 : 90 = ?']);W3msg('Bo‘luvchida nechta nol bor?')},fin:function(){W3eq(['72 00[0] : 9[0]','7 200 : 9 = [800]'])},
 html:"<p><b>72 000 : 90</b>. Qaysi javob to'g'ri?</p>",
 btns:[["800",function(c,done){W3eq(['72 00[0] : 9[0]','7 200 : 9 = [800]']);W3msg('90 da <b>bitta</b> nol — ikkalasidan bittadan o‘chiramiz: 7 200 : 9 = <b>800</b>');done()}],["8",function(){W3eq(['72 : 9 = 8 ?']);W3msg('72 000 dan uchta nol o‘chirildi, 90 dan esa bitta. Bir xil sondagi nol o‘chiriladi!','Qayta tanlang')}],["8 000",function(){W3eq(['72 000 : 9 = 8 000']);W3msg('Bu — 9 ga bo‘lish. 90 ga bo‘lsak 10 marta kam chiqadi','Qayta tanlang')}]],g3:1,
 after:"<p>O'chiriladigan nollar soni = <b>bo'luvchidagi</b> nollar soni (bo'linuvchida undan ko'p bo'lishi mumkin). Tekshiruv: 800 · 90 = 72 000 ✓</p>",
 q:{t:"48 000 : 80 = ?",opts:["600","60","6 000","6"],ok:0,why:"4 800 : 8 = 600.",hint:"80 da bitta nol.",full:"Bittadan nol o'chiramiz: 4 800 : 8 = 600. Tekshiruv: 600 · 80 = 48 000. «60» — ikkita nol o'chirilgan."},
 tn:"Har bo'lishdan keyin ko'paytirish bilan tekshirishni odat qildiring."},
{h:"Bo'linmada nol qoladi",sum:"36 000 : 400 = 360 : 4 = 90.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bo'linuvchida nollar ko'p bo'lsa — qolgani javobga o'tadi.</p>",btns:[phaser(P5)],
 after:"<p>Shuningdek: 5 600 : 7 = 800 (56 : 7 = 8, ikkita nol javobga). <b>Nollarni o'chirgandan keyin</b> qolgan sonni oddiy bo'lamiz.</p>",
 q:{t:"240 000 : 600 = ?",opts:["400","40","4 000","4"],ok:0,why:"2 400 : 6 = 400.",hint:"Ikkitadan nol o'chiring.",full:"240 000 va 600 dan ikkitadan nol: 2 400 : 6 = 400. Tekshiruv: 400 · 600 = 240 000."},
 tn:"Bolalar o'chirilgan nollarni ustidan chizib qo'ysin — qancha qolgani ko'rinadi."},
{h:"Murakkab tuzoq: qoldiq",sum:"1 750 : 400 = 4 (qoldiq 150). Nol qisqartirilsa, qoldiqni ham o'n marta oshirish kerak.",a:"m06",start:function(){W3eq(['1 750 : 400 = ? (qoldiq ?)']);W3msg('Nollarni qisqartirib bo‘lsak: 175 : 40 = 4 (qoldiq 15). Qoldiq 15 mi?')},fin:function(){W3eq(['400 · 4 = 1 600','1 750 − 1 600 = [150]'])},
 html:"<p>Bola 1 750 : 400 ni 175 : 40 = 4 (qoldiq 15) deb yechdi. Asl qoldiq qancha?</p>",
 btns:[["150",function(c,done){W3eq(['400 · 4 = 1 600','1 750 − 1 600 = [150]']);W3msg('Qoldiq <b>150</b>. 15 — bu 15 <b>o‘nlik</b> edi (nolni o‘chirgan edik)');done()}],["15",function(){W3eq(['400 · 4 + 15 = 1 615 ≠ 1 750']);W3msg('Tekshiring: 1 615 chiqdi. Demak 15 noto‘g‘ri','Qayta tanlang')}],["1",function(){W3eq(['17 : 4 = 4 (qoldiq 1)']);W3msg('Bu — 17 : 4. 1 750 da faqat bitta nol bor, ikkitasini o‘chirib bo‘lmaydi','Qayta tanlang')}]],g3:1,
 after:"<p>Qisqartirilgan sonlarda bo'linma <b>o'zgarmaydi</b>, lekin qoldiq <b>shuncha marta kichrayadi</b>. Shuning uchun qoldiqli bo'lishda tekshiruv shart: 400 · 4 + 150 = 1 750 ✓</p>",
 q:{t:"5 300 : 600 = ?",opts:["8 (qoldiq 500)","8 (qoldiq 5)","9 (qoldiq 1)","8 (qoldiq 50)"],ok:0,why:"600 · 8 = 4 800, 5 300 − 4 800 = 500.",hint:"53 : 6 = 8 (q. 5) — 5 qanday birlik edi?",full:"53 : 6 = 8 (qoldiq 5), lekin 5 — bu 5 yuzlik = 500. Tekshiruv: 600 · 8 + 500 = 5 300."},
 tn:"Bu — olimpiada darajasidagi tuzoq. Pul misolida ko'rsating: 1 750 so'mni 400 so'mdan — 4 ta, 150 so'm qoladi."},
{h:"Masala: ko'p bosqichli",sum:"450 · 8 = 3 600 detal; 3 600 · 30 = 108 000.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Zavod soatiga <b>450</b> ta detal chiqaradi. Smena <b>8</b> soat. <b>30</b> kunda (kuniga bir smena) nechta detal?</p>",btns:[phaser(P7)],
 after:"<p>Oraliq natijani topib, keyin davom etamiz. Nollar bilan ishlaganda har qadamda nol sonini tekshiring.</p>",
 q:{t:"Bir mashina 6 000 kg yuk tashiydi. 300 000 kg yukni tashish uchun 10 ta mashina necha marta qatnashi kerak?",opts:["5 marta","50 marta","500 marta","30 marta"],ok:0,why:"10 · 6 000 = 60 000 kg bir qatnovda; 300 000 : 60 000 = 5.",hint:"Avval 10 mashina birga qancha tashiydi?",full:"10 mashina bir qatnovda 60 000 kg tashiydi. 300 000 : 60 000 = 30 : 6 = 5 marta. «50» — bitta mashina uchun hisoblangan."},
 tn:"Ko'p bosqichli masalada har qadamni alohida qatorga yozdirib, birligini (kg, ta, marta) qo'shtirib yozdiring."},
{h:"Noma'lumni topish",sum:"600 · □ = 48 000 → □ = 48 000 : 600 = 80.",a:"m08",start:function(){W3eq(['600 · □ = 48 000']);W3msg('□ ga qaysi son mos?')},fin:function(){W3eq(['□ = 48 000 : 600','□ = 480 : 6 = [80]'])},
 html:"<p><b>600 · □ = 48 000</b>. Kvadratchaga qaysi son yoziladi?</p>",
 btns:[["80",function(c,done){W3eq(['600 · 80 = 48 000 ✓']);W3msg('6 · 8 = 48, nollar 2 + 1 = 3 ✓ <b>□ = 80</b>');done()}],["8",function(){W3eq(['600 · 8 = 4 800']);W3msg('4 800 chiqdi — 10 marta kam','Qayta tanlang')}],["800",function(){W3eq(['600 · 800 = 480 000']);W3msg('480 000 — 10 marta ko‘p','Qayta tanlang')}]],g3:1,
 after:"<p>Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi. 48 000 : 600 = 480 : 6 = 80.</p>",
 q:{t:"□ : 50 = 3 200. □ = ?",opts:["160 000","64","16 000","1 600 000"],ok:0,why:"3 200 · 50.",hint:"Bo'linuvchi = bo'linma · bo'luvchi.",full:"□ = 3 200 · 50 = 32 · 5 = 160, nollar 2 + 1 = 3 → 160 000. «64» — 3 200 : 50 hisoblangan."},
 tn:"Tenglamani nollar bilan sinab ko'rish — chamalashni mashq qildiradi."},
{h:"Bilasizmi? Nol qayerdan kelgan",sum:"Hind matematigi Braxmagupta 628-yilda nol bilan amallar qoidalarini yozib qoldirgan.",a:"m09",start:function(){W3eq(['628-yil · Hindiston','Braxmagupta: 0'],{fs:20});W3msg('Nolsiz 20 400 ni yozib bo‘lmasdi')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Nolni haqiqiy <b>son</b> sifatida qo'llash va u bilan amallar qoidalarini yozib qoldirgan olimlardan biri — hind matematigi <b>Braxmagupta</b> (628-yil). Keyinroq nol bilan birga o'nli sanoq al-Xorazmiy asarlari orqali Yaqin Sharq va Yevropaga tarqaldi.</p><p>⭐ Nol — «bo'sh joy» belgisi. Usiz 2 040 va 24 ni farqlab bo'lmasdi.</p>",
 tn:"Bolalardan so'rang: «Nol bo'lmasa, 20 400 ni qanday yozardik?» — Rim raqamlarida: XXCD."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3eq(['340 · 60 = 20 400','72 000 : 90 = 800'])},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Ko'paytirish: nollarsiz ko'paytirib, oxiriga <b>barcha</b> nollarni yozamiz: 340 · 60 = 20 400.</li><li>Ko'paytmaning o'z noli bo'lishi mumkin: 25 · 4 = 100 → 2 500 · 40 = 100 000.</li><li>Bo'lish: ikkalasidan <b>bir xil sondagi</b> nolni o'chiramiz: 72 000 : 90 = 7 200 : 9 = 800.</li><li>Qoldiqli bo'lishda qoldiqni qayta tekshiring: 1 750 : 400 = 4 (q. 150).</li><li>Tekshiruv: 800 · 90 = 72 000.</li></ul></div>",
 tn:"Keyingi mavzu: bir xonali songa bo'lish (burchak usuli)."}
];
var PROBS=[
{t:"230 · 40 = ?",o:["9 200","920","92 000","2 340"],k:0,s:"23 · 4 = 92, ikkita 0."},
{t:"700 · 800 = ?",o:["560 000","56 000","5 600 000","1 500"],k:0,s:"7 · 8 = 56, to'rtta 0."},
{t:"1 200 · 50 = ?",o:["60 000","6 000","600 000","1 250"],k:0,s:"12 · 5 = 60, uchta 0."},
{t:"250 · 400 = ?",o:["100 000","10 000","1 000 000","1 000"],k:0,s:"25 · 4 = 100, uchta 0."},
{t:"3 040 · 20 = ?",o:["60 800","6 080","608 000","60 080"],k:0,s:"304 · 2 = 608, ikkita 0."},
{t:"5 600 : 80 = ?",o:["70","700","7","7 000"],k:0,s:"560 : 8."},
{t:"81 000 : 900 = ?",o:["90","9","900","9 000"],k:0,s:"810 : 9."},
{t:"420 000 : 7 000 = ?",o:["60","600","6","6 000"],k:0,s:"420 : 7."},
{t:"64 000 : 800 = ?",o:["80","8","800","8 000"],k:0,s:"640 : 8."},
{t:"30 000 : 50 = ?",o:["600","60","6 000","6"],k:0,s:"3 000 : 5."},
{t:"500 · 600 = ?",o:["300 000","30 000","3 000 000","1 100"],k:0,s:"5 · 6 = 30 — o'zida nol bor; + to'rtta 0."},
{t:"□ · 70 = 35 000. □ = ?",o:["500","50","5 000","5"],k:0,s:"35 000 : 70 = 3 500 : 7."},
{t:"□ : 300 = 40. □ = ?",o:["12 000","1 200","120 000","340"],k:0,s:"40 · 300."},
{t:"2 900 : 400 = ?",o:["7 (qoldiq 100)","7 (qoldiq 1)","7 (qoldiq 10)","8 (qoldiq 100)"],k:0,s:"400 · 7 = 2 800, qoldiq 100."},
{t:"3 500 : 800 = ?",o:["4 (qoldiq 300)","4 (qoldiq 3)","4 (qoldiq 30)","5 (qoldiq 500)"],k:0,s:"800 · 4 = 3 200."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["400 · 300","60 · 1 500","20 · 5 000","90 000 + 10 000"],k:0,s:"120 000; 90 000; 100 000; 100 000."},
{t:"1 ta daftar 2 500 so'm. 40 ta daftar olib, 100 000 so'm berildi. Qaytim?",o:["0 so'm","10 000 so'm","1 000 so'm","75 000 so'm"],k:0,s:"2 500 · 40 = 100 000."},
{t:"Ombordagi 24 000 kg unni 40 kg li qoplarga solishdi. Nechta qop kerak?",o:["600","60","6 000","960"],k:0,s:"2 400 : 4."},
{t:"Velosipedchi soatiga 15 km yuradi. 900 km ni necha soatda yuradi, kuniga 6 soat yursa — necha kunda?",o:["10 kunda","60 kunda","6 kunda","100 kunda"],k:0,s:"900 : 15 = 60 soat; 60 : 6 = 10 kun."},
{t:"(36 000 : 90) · 30 = ?",o:["12 000","1 200","120 000","400"],k:0,s:"36 000 : 90 = 400; 400 · 30."}
];
function PRACT_STAGE(){W3eq(['340 · 60 = 34 · 6 · 100','72 000 : 90 = 7 200 : 9'])}
var PREP_DATA={teach:["Nol bilan tugaydigan sonlarni ko'paytirish.","Ko'paytmaning o'z noli (25 · 4 = 100).","Bo'lishda bir xil sondagi nollarni o'chirish.","Qoldiqli bo'lishda nollar tuzog'i.","Noma'lum ko'paytuvchi/bo'linuvchini topish."],
 mist:["2 500 · 40 = 10 000 (25 · 4 ni 10 deb oladi yoki nollarni noto'g'ri sanaydi).","72 000 : 90 = 8 (bo'linuvchidan ko'proq nol o'chiradi).","1 750 : 400 = 4 (q. 15) — qoldiqni qisqartirilgan holda qoldiradi.","Bo'lishda nollarni qo'shib qo'yadi: 4 800 : 600 = 800."],
 need:["Pul kartochkalari (100, 1 000 so'mlik) yoki o'nlik bloklar."],
 board:["<span class='w2'>340 · 60 = 20 400</span>","<span class='w2'>2 500 · 40 = 100 000</span>","<span class='w2'>72 000 : 90 = 7 200 : 9 = 800</span>","<span class='w2'>1 750 : 400 = 4 (q. 150)</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
