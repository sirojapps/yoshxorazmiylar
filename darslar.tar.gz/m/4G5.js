// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4G5',TITLE='4-sinf · Hajm va sig‘im birliklari: sm³, dm³, litr';
function g5cube(a,b,c,lab,msg){var r=g4box(a,b,c,{cubes:true,lab:false,s:Math.min(13,150/(a+b*.6),110/(c+b*.4))});if(lab)T(S.g,300,40,lab,{'font-size':14,'font-weight':800,fill:C.a2});return r}
var P1=[function(){clear();g4box(1,1,1,{lab:false,s:40});T(S.g,290,60,'1 sm³',{'font-size':18,'font-weight':800,fill:C.a2});T(S.g,290,84,'qirrasi 1 sm',{'font-size':12,'font-weight':700,fill:'#5b6b7b'});calc(['1 sm³ — qirrasi 1 sm bo‘lgan kubik'])},
 function(){g5cube(10,1,1,'10 ta');calc(['1 sm³','Bir qatorda: <b>10</b> ta kubik (10 sm = 1 dm)'])},
 function(){g5cube(10,10,1,'10 · 10 = 100');calc(['Bir qatlamda: 10 · 10 = <b>100</b> ta'])},
 function(){g5cube(10,10,10,'100 · 10 = 1000');calc(['10 qatlam: 100 · 10 = <b>1000 sm³</b>','1 dm³ = 1000 sm³'])}];
function g5jar(x,cap,lev,lab,col){var g=S.g,h=cap*16,w=44,y0=150;E('rect',{x:x,y:y0-h,width:w,height:h,rx:4,fill:'#fff',stroke:'#5b6b7b','stroke-width':2},g);
 if(lev>0)E('rect',{x:x+2,y:y0-lev*16,width:w-4,height:lev*16-2,fill:col||'#7cc2f0'},g);for(var i=1;i<cap;i++)E('line',{x1:x,y1:y0-i*16,x2:x+8,y2:y0-i*16,stroke:'#5b6b7b'},g);
 T(g,x+w/2,y0-h-8,lab,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,x+w/2,y0+16,lev+' l',{'font-size':13,'font-weight':800,fill:C.blue})}
function g5two(a,b,msg){clear();g5jar(110,3,a,'3 l');g5jar(210,5,b,'5 l');g4m(msg)}
var P6=[function(){g5two(0,0,'Ikkala idish bo‘sh. Maqsad: roppa-rosa <b>4 l</b>')},
 function(){g5two(0,5,'1) 5 litrlikni to‘ldiramiz')},
 function(){g5two(3,2,'2) Undan 3 litrlikni to‘ldiramiz: 5 − 3 = <b>2 l</b> qoldi')},
 function(){g5two(0,2,'3) 3 litrlikni to‘kib tashlaymiz')},
 function(){g5two(2,0,'4) 2 l ni 3 litrlikka quyamiz')},
 function(){g5two(2,5,'5) 5 litrlikni yana to‘ldiramiz')},
 function(){g5two(3,4,'6) 3 litrlikka 1 l sig‘adi — 5 litrlikda <b>4 l</b> qoldi! ✓')}];
var P5=[function(){g4box(5,3,4,{la:'50 sm',lb:'30 sm',lc:'40 sm',s:20,ff:['#cfe7f7','#a8d4f0','#e4f3fc']});calc(['Akvariumga necha litr suv sig‘adi?'])},
 function(){P5[0]();calc(['V = 50 · 30 · 40 = <b>60 000 sm³</b>'])},
 function(){P5[0]();calc(['60 000 sm³','1 l = 1000 sm³ → 60 000 : 1000 = <b>60 l</b>'])}];
var P8=[function(){g4box(4,2,2,{la:'2 m',lb:'1 m',lc:'1 m',s:30,ff:['#cfe7f7','#a8d4f0','#e4f3fc']});calc(['Bak to‘la. Jo‘mrakdan har minutda 40 l oqadi. Bak qancha vaqtda bo‘shaydi?'])},
 function(){P8[0]();calc(['V = 2 · 1 · 1 = <b>2 m³</b> = 2000 dm³ = <b>2000 l</b>'])},
 function(){P8[0]();calc(['2000 l','2000 : 40 = <b>50 min</b>'])}];
function g5grow(n){var r=g4box(n,n,n,{cubes:true,lab:false,s:Math.min(30,90/n+8),y0:150});T(S.g,300,50,'qirra '+n,{'font-size':14,'font-weight':800,fill:C.blue});T(S.g,300,74,n+'·'+n+'·'+n+' = '+(n*n*n),{'font-size':15,'font-weight':800,fill:C.a2});g4m('Qirrasi '+n+' → hajmi <b>'+(n*n*n)+'</b> ta kubik')}
function g5stone(k){clear();var g=S.g,lv=k?110:90;[[100,0],[230,1]].forEach(function(p,i){var x=p[0],up=i===1;E('rect',{x:x,y:30,width:60,height:120,rx:4,fill:'#fff',stroke:'#5b6b7b','stroke-width':2},g);E('rect',{x:x+2,y:150-(up?lv:90),width:56,height:(up?lv:90)-2,fill:'#9fd3f5'},g);
 if(up)E('ellipse',{cx:x+30,cy:136,rx:16,ry:10,fill:'#8a8a8a'},g);T(g,x+30,24,up?(k?'1 l 450 ml':'?'):'1 l 200 ml',{'font-size':12,'font-weight':800,fill:C.blue})});T(g,180,94,'→',{'font-size':22,'font-weight':800,fill:C.a2})}
var STEPS=[
{h:"1 dm³ ichida nechta sm³?",sum:"1 sm³ — qirrasi 1 sm kubik. 1 dm³ = 10 · 10 · 10 = 1000 sm³.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Hajm birligi — kubik. Qirrasi 1 dm (10 sm) bo'lgan katta kubni kichik 1 sm³ li kubiklardan teramiz:</p>",
 btns:[phaser(P1,'▶ Terish')],
 after:"<p>Qator — 10, qatlam — 100, kub — <b>1000</b>. Uzunlikda ×10, yuzada ×100, hajmda <b>×1000</b>: chunki uchta o'lcham ko'paytiriladi.</p>",
 q:{t:"1 dm³ necha sm³?",opts:["100 sm³","10 sm³","1000 sm³","30 sm³"],ok:2,why:"10 · 10 · 10 = 1000 sm³.",hint:"Bir qatlamda nechta kubik va nechta qatlam bor?",full:"Qatlamda 10 · 10 = 100 ta, qatlamlar 10 ta: 100 · 10 = 1000 sm³. «100» — faqat bitta qatlam (bu yuza: 1 dm² = 100 sm²)."},
 tn:"Sinfda 1 dm³ li kubni kartondan yasang va ichiga 1 sm³ li kubiklarni (yoki shakar bo'laklarini) bir qatlam terib ko'rsating."},
{h:"Litr va millilitr",sum:"1 l = 1 dm³ = 1000 sm³; 1 ml = 1 sm³; 1 l = 1000 ml.",a:"m02",
 start:function(){clear();g4box(1,1,1,{lab:false,s:80,x0:70,ff:['#cfe7f7','#a8d4f0','#e4f3fc']});T(S.g,290,60,'1 dm³ = 1 l',{'font-size':18,'font-weight':800,fill:C.blue});g4m('Tugmalarni bosing')},fin:function(){clear();g4box(1,1,1,{lab:false,s:80,x0:70,ff:['#cfe7f7','#a8d4f0','#e4f3fc']});T(S.g,290,60,'1 dm³ = 1 l',{'font-size':18,'font-weight':800,fill:C.blue});g4m('1 l = 1 dm³ = 1000 sm³ = 1000 ml')},
 html:"<p>Suyuqlik hajmini — <b>sig'imni</b> — litrda o'lchaymiz. Litr bilan kub birliklari qanday bog'langan? Bosing:</p>",
 btns:[["1 litr",function(c,done){g4m('Qirrasi 1 dm kubga roppa-rosa <b>1 litr</b> suv sig‘adi: 1 l = 1 dm³');mvK(done,3)}],["1 millilitr",function(c,done){g4m('1 ml = <b>1 sm³</b> — bir chimdim suv (dori qoshig‘i ≈ 5 ml)');mvK(done,3)}],["l → ml",function(c,done){g4m('1 l = 1000 sm³ = <b>1000 ml</b>. Piyola ≈ 250 ml');mvK(done,3)}]],g3:1,
 after:"<p><b>1 l = 1 dm³</b>, <b>1 ml = 1 sm³</b>, <b>1 l = 1000 ml</b>. Shuning uchun suv shishasidagi «500 ml» — bu yarim litr.</p>",
 q:{t:"250 ml necha sm³?",opts:["25 sm³","250 sm³","2500 sm³","2 sm³ 50 mm³"],ok:1,why:"1 ml = 1 sm³, demak 250 ml = 250 sm³.",hint:"1 ml qancha sm³?",full:"1 ml = 1 sm³, shuning uchun 250 ml = 250 sm³ — son o'zgarmaydi, faqat nomi."},
 tn:"Shprits yoki o'lchov stakanida 1 ml, 10 ml, 100 ml suvni ko'rsating."},
{h:"Kub metr: 1 m³ = 1000 l",sum:"1 m³ = 10 · 10 · 10 = 1000 dm³ = 1000 l. 100 emas!",a:"m03",
 start:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[],null,'Hajm birliklari: har qadam ×1000');g4m('Bosing')},fin:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[0,1],[0,1],'Hajm birliklari: har qadam ×1000');g4m('1 m³ = 1000 l')},
 html:"<p>Katta hajmlar (xona, basseyn, bak) <b>m³</b> da o'lchanadi. 1 m = 10 dm bo'lgani uchun:</p>",
 btns:[["m³ → dm³",function(c,done){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[0,1],[0,1],'Hajm birliklari: har qadam ×1000');g4m('10 · 10 · 10 = <b>1000 dm³</b> = 1000 l');mvK(done,2)}],["dm³ → sm³",function(c,done){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[1,2],[1,2],'Hajm birliklari: har qadam ×1000');g4m('1 dm³ = <b>1000 sm³</b>; 1 l = 1000 ml');mvK(done,2)}]],g2:1,
 after:"<p>Hajm birliklari orasida ko'paytuvchi <b>1000</b>. Bir kub metrga 1000 litr — besh vannaga yaqin suv sig'adi.</p>",
 q:{t:"2 m³ necha litr?",opts:["200 l","20 l","2000 l","20 000 l"],ok:2,why:"1 m³ = 1000 l; 2 · 1000 = 2000 l.",hint:"1 m³ = 1000 dm³, 1 dm³ = 1 l.",full:"1 m³ = 1000 dm³ = 1000 l, shuning uchun 2 m³ = 2000 l. «200» — ×100 deb o'ylash (yuza birliklari bilan aralashtirish)."},
 tn:"Uchta zinapoyani yonma-yon yozing: uzunlik ×10, yuza ×100, hajm ×1000 — bolalar qonuniyatni o'zi topsin."},
{h:"Tuzoq: ikki nomli hajm",sum:"3 dm³ 40 sm³ = 3040 sm³: sm³ ga 3 ta xona.",a:"m04",
 start:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[1,2],[1,2],'Hajm birliklari');g4m('<b>3 dm³ 40 sm³</b> = ? sm³')},fin:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[1,2],[1,2],'Hajm birliklari');g4m('3 dm³ 40 sm³ = 3000 + 40 = <b>3040 sm³</b>')},
 html:"<p>To'g'ri yozuvni bosing:</p>",
 btns:[["340 sm³",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 3 dm³ = 3000 sm³, 300 emas');setTimeout(function(){b.style.background=''},1600)}],["3040 sm³",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g4m('To‘g‘ri! 3000 + 40 = <b>3040 sm³</b>');done()}],["3400 sm³",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 40 sm³ ni 400 deb yozdingiz');setTimeout(function(){b.style.background=''},1600)}],["30 040 sm³",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 1 dm³ = 1000 sm³ (10 000 emas)');setTimeout(function(){b.style.background=''},1600)}]],g2:1,
 after:"<p>Ko'paytuvchi 1000 — kichik birlikka <b>3 ta xona</b>: 3 dm³ 40 sm³ = 3 <b>040</b> sm³, 5 l 8 ml = 5 <b>008</b> ml.</p>",
 q:{t:"5 l 8 ml necha ml?",opts:["58 ml","508 ml","5008 ml","5080 ml"],ok:2,why:"5000 + 8 = 5008 ml.",hint:"1 l = 1000 ml — nechta xona?",full:"5 l = 5000 ml, 5000 + 8 = 5008 ml. «508» — 1 l = 100 ml deb o'ylash, «5080» — 8 ni 80 deb yozish."},
 tn:"Xonalar jadvali: [l | yuz ml | o'n ml | ml]."},
{h:"Akvarium necha litr?",sum:"50 · 30 · 40 = 60 000 sm³ = 60 dm³ = 60 l.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Akvarium: bo'yi 50 sm, eni 30 sm, balandligi 40 sm. Unga necha litr suv sig'adi?</p>",
 btns:[phaser(P5)],
 after:"<p>Usul: o'lchamlar <b>sm</b> da bo'lsa — hajmni sm³ da topib, <b>1000 ga bo'lamiz</b> (litr). Yoki avval o'lchamlarni dm ga o'tkazamiz: 5 · 3 · 4 = 60 dm³ = 60 l — tezroq!</p>",
 q:{t:"Quti 20 sm × 10 sm × 5 sm. Hajmi necha dm³?",opts:["1 dm³","100 dm³","10 dm³","35 dm³"],ok:0,why:"20 · 10 · 5 = 1000 sm³ = 1 dm³.",hint:"Avval sm³ da toping.",full:"20 · 10 · 5 = 1000 sm³ = 1 dm³. «35» — o'lchamlarni qo'shish xatosi, «100» — 1000 ni 10 ga bo'lish."},
 tn:"Haqiqiy idishni (qutini) o'lchab, hajmini hisoblang, keyin suv quyib tekshiring."},
{h:"Ikki idish bilan 4 litr o'lchash",sum:"3 l va 5 l idish: 5 → 3 ga (2 qoldi) → to'k → 2 ni quy → 5 ni to'ldir → 3 ga 1 l quy → 4 l.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=6;P6[6]()},
 html:"<p>Qadimiy jumboq: faqat <b>3 litrlik</b> va <b>5 litrlik</b> idish bor. Buloqdan roppa-rosa <b>4 litr</b> suv qanday olib kelasiz?</p>",
 btns:[phaser(P6,'▶ Quyish')],
 after:"<p>Kalit fikr: 5 − 3 = <b>2</b>, keyin 5 − 1 = <b>4</b>. Idishlar ayirmasidan foydalanib, «yo'q» o'lchovni hosil qildik.</p>",
 q:{t:"Bu usulda 5 litrlik idish buloqdan necha marta to'ldirildi?",opts:["1 marta","2 marta","3 marta","4 marta"],ok:1,why:"1-qadamda va 5-qadamda — 2 marta.",hint:"«To'ldiramiz» degan qadamlarni sanang.",full:"5 litrlik idish 1-qadamda va 5-qadamda to'ldirildi — 2 marta. Boshqa qadamlarda suv idishdan idishga quyildi."},
 tn:"Ikki plastik idish va suv bilan sinfda amalda bajaring — bolalar juda qiziqadi."},
{h:"Tuzoq: qirra 2 marta — hajm 8 marta",sum:"Qirrasi 1, 2, 3 bo'lgan kub hajmi: 1, 8, 27.",a:"m07",
 start:function(){clear();g5grow(1)},fin:function(){clear();g5grow(3)},
 html:"<p>Kub qirrasini oshiring. Hajm qanday o'zgaradi?</p>",
 btns:[["Qirra 1",function(c,done){clear();g5grow(1);mvK(done,3)}],["Qirra 2",function(c,done){clear();g5grow(2);mvK(done,3)}],["Qirra 3",function(c,done){clear();g5grow(3);mvK(done,3)}]],g3:1,
 after:"<p>Qirra <b>2 marta</b> oshsa — hajm <b>2 · 2 · 2 = 8</b> marta; <b>3 marta</b> oshsa — <b>27</b> marta. Shuning uchun 1 dm³ = 1000 sm³: qirra 10 marta, hajm 10 · 10 · 10 marta.</p>",
 q:{t:"Kub qirrasi 3 marta oshirildi. Hajmi necha marta oshdi?",opts:["3 marta","9 marta","27 marta","6 marta"],ok:2,why:"3 · 3 · 3 = 27.",hint:"Qirrasi 1 va 3 bo'lgan kublarni solishtiring.",full:"Qirra 1 → hajm 1; qirra 3 → hajm 27. «9 marta» — yuz shunday o'zgaradi (3 · 3), hajm emas."},
 tn:"Kubiklardan 1, 2, 3 qirrali kub yasang — bolalar kubiklar sonini sanasin."},
{h:"Masala: bak qachon bo'shaydi?",sum:"2 · 1 · 1 = 2 m³ = 2000 l; 2000 : 40 = 50 min.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Bak: bo'yi 2 m, eni 1 m, balandligi 1 m. U to'la. Jo'mrakdan har minutda 40 l suv oqadi.</p>",
 btns:[phaser(P8)],
 after:"<p>Reja: hajm (m³) → litr (×1000) → bo'lish. Birliklarni bir xil qilmasdan bo'lish — eng ko'p xato.</p>",
 q:{t:"Hovuz 25 m × 10 m × 2 m. Nasos soatiga 50 m³ suv quyadi. Hovuz qancha vaqtda to'ladi?",opts:["5 soat","10 soat","37 soat","100 soat"],ok:1,why:"25 · 10 · 2 = 500 m³; 500 : 50 = 10 soat.",hint:"Avval hovuz hajmini toping.",full:"Hajm 25 · 10 · 2 = 500 m³. 500 : 50 = 10 soat. «37» — o'lchamlarni qo'shish xatosi, «5 soat» — 250 : 50 (balandlikni unutish)."},
 tn:"Bolalar «reja» ni 3 qatorga yozsin: 1) hajm; 2) birlik; 3) vaqt."},
{h:"Bilasizmi? Toshning hajmini qanday topamiz",sum:"Suv 1 l 200 ml dan 1 l 450 ml ga ko'tarildi → tosh hajmi 250 sm³.",a:"m09",
 start:function(){g5stone(1);g4m('1450 − 1200 = 250 ml → tosh hajmi <b>250 sm³</b>')},fin:function(){g5stone(1);g4m('1450 − 1200 = 250 ml → tosh hajmi <b>250 sm³</b>')},
 html:"<p>🪨 Toshning shakli notekis — uning hajmini chizg'ich bilan o'lchab bo'lmaydi. Lekin uni suvga solsak, suv sathi ko'tariladi: tosh <b>o'z hajmicha</b> suvni siqib chiqaradi.</p><p>🛁 Rivoyatga ko'ra, qadimgi yunon olimi <b>Arximed</b> bu g'oyani vannaga tushganda topgan va «Evrika!» («Topdim!») deb qichqirgan.</p><p>💧 1 litr suvning massasi taxminan <b>1 kg</b>.</p>",
 tn:"O'lchov stakanida suvga tosh yoki kalit solib, hajmini o'lchang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[0,1,2],null,'Hajm birliklari: har qadam ×1000');g4m('1 m³ = 1000 l · 1 l = 1000 ml')},fin:function(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[0,1,2],null,'Hajm birliklari: har qadam ×1000');g4m('1 m³ = 1000 l · 1 l = 1000 ml')},
 html:"<div class='memo'><ul><li><b>1 dm³ = 1000 sm³</b>, <b>1 m³ = 1000 dm³</b>.</li><li><b>1 l = 1 dm³</b>, <b>1 ml = 1 sm³</b>, 1 l = 1000 ml, 1 m³ = 1000 l.</li><li>Uzunlik ×10 → yuza ×100 → hajm ×1000.</li><li>Bo'sh xonaga 0: 3 dm³ 40 sm³ = 3040 sm³, 5 l 8 ml = 5008 ml.</li><li>Idish sig'imi: V = a · b · c (sm³ → : 1000 → l).</li><li>Qirra 2 marta → hajm 8 marta; 3 marta → 27 marta.</li><li>Notekis jism hajmi = suv sathining ko'tarilishi.</li></ul></div>",
 tn:"Uyga vazifa: oshxonadagi 5 ta idishning yorlig'idan sig'imini yozib, ml da va l da ifodalash."}
];
var PROBS=[
{t:"1 dm³ necha sm³?",o:["1000 sm³","100 sm³","10 sm³","10 000 sm³"],k:0,s:"10 · 10 · 10 = 1000."},
{t:"1 l necha ml?",o:["1000 ml","100 ml","10 ml","10 000 ml"],k:0,s:"1 l = 1000 ml."},
{t:"1 m³ necha dm³?",o:["1000 dm³","100 dm³","10 000 dm³","1 000 000 dm³"],k:0,s:"10 · 10 · 10 = 1000 dm³."},
{t:"5 l necha sm³?",o:["5000 sm³","500 sm³","50 sm³","50 000 sm³"],k:0,s:"1 l = 1000 sm³; 5 · 1000 = 5000."},
{t:"3 dm³ 40 sm³ necha sm³?",o:["3040 sm³","340 sm³","3400 sm³","30 040 sm³"],k:0,s:"3000 + 40 = 3040."},
{t:"2 l 300 ml + 1 l 900 ml = ?",o:["4 l 200 ml","3 l 1200 ml","3 l 200 ml","4 l 1200 ml"],k:0,s:"300 + 900 = 1200 ml = 1 l 200 ml; 2 + 1 + 1 = 4 l."},
{t:"Kubning qirrasi 2 dm. Unga necha litr suv sig'adi?",o:["8 l","6 l","4 l","24 l"],k:0,s:"2 · 2 · 2 = 8 dm³ = 8 l."},
{t:"Akvarium 50 sm × 30 sm × 40 sm. Necha litr?",o:["60 l","600 l","6 l","120 l"],k:0,s:"50 · 30 · 40 = 60 000 sm³ = 60 l."},
{t:"1 m³ necha litr?",o:["1000 l","100 l","10 000 l","10 l"],k:0,s:"1 m³ = 1000 dm³ = 1000 l."},
{t:"Choynakda 1 l 500 ml choy. 250 ml li piyolalarga nechta to'ladi?",o:["6","4","5","60"],k:0,s:"1500 : 250 = 6."},
{t:"Bak 2 m × 1 m × 1 m to'la; har minutda 40 l oqadi. Qachon bo'shaydi?",o:["50 min","5 min","500 min","20 min"],k:0,s:"2 m³ = 2000 l; 2000 : 40 = 50 min."},
{t:"Qirrasi 3 sm kubning hajmi?",o:["27 sm³","9 sm³","18 sm³","54 sm³"],k:0,s:"3 · 3 · 3 = 27 sm³."},
{t:"Kub qirrasi 2 marta oshirildi. Hajmi necha marta oshdi?",o:["8 marta","2 marta","4 marta","6 marta"],k:0,s:"2 · 2 · 2 = 8."},
{t:"Idishda 7 l suv. 500 ml li nechta butilka to'ladi?",o:["14","7","70","35"],k:0,s:"7000 : 500 = 14."},
{t:"Hovuz 25 m × 10 m × 2 m. Hajmi?",o:["500 m³","37 m³","250 m³","5000 m³"],k:0,s:"25 · 10 · 2 = 500 m³."},
{t:"2 l 400 ml sharbat 4 ta stakanga teng quyildi. Har birida?",o:["600 ml","6 ml","1 l 100 ml","60 ml"],k:0,s:"2400 : 4 = 600 ml."},
{t:"Qaysi katta: 3 l yoki 2900 sm³?",o:["3 l","2900 sm³","Teng"],k:0,s:"3 l = 3000 sm³ > 2900 sm³."},
{t:"Quti 20 sm × 10 sm × 5 sm. Hajmi necha dm³?",o:["1 dm³","100 dm³","10 dm³","35 dm³"],k:0,s:"20 · 10 · 5 = 1000 sm³ = 1 dm³."},
{t:"Bak 80 sm × 50 sm × 60 sm. Necha litr suv sig'adi?",o:["240 l","2400 l","24 l","190 l"],k:0,s:"8 · 5 · 6 = 240 dm³ = 240 l."},
{t:"Suvga tosh solindi: sath 1 l 200 ml dan 1 l 450 ml ga ko'tarildi. Tosh hajmi?",o:["250 sm³","1450 sm³","2650 sm³","25 sm³"],k:0,s:"1450 − 1200 = 250 ml = 250 sm³."}
];
function PRACT_STAGE(){g4lad(['m³','dm³ (l)','sm³ (ml)'],[1000,1000],[],null,'Hajm birliklari: har qadam ×1000');g4m('1 l = 1 dm³ · 1 ml = 1 sm³')}
var PREP_DATA={teach:["1 dm³ = 1000 sm³ — kubiklar bilan qatlamlab.","Litr va millilitr; 1 l = 1 dm³, 1 ml = 1 sm³.","1 m³ = 1000 l; almashtirish va bo'sh xonaga 0.","Sig'im masalalari; idishlar jumbog'i; qirra o'zgarsa hajm."],
 mist:["1 dm³ = 100 sm³ deb o'ylaydi (yuza bilan aralashtiradi).","1 m³ = 100 l deydi.","Hajmni o'lchamlar yig'indisi deb hisoblaydi.","Qirra 2 marta → hajm 2 (yoki 4) marta deydi."],
 need:["Kartondan 1 dm³ kub, 1 sm³ kubiklar.","O'lchov stakani, shprits, 1 l shisha.","3 l va 5 l plastik idish, suv."],
 board:["<span class='w2'>1 dm³ = 1000 sm³</span>, <span class='w2'>1 m³ = 1000 dm³</span>.","<span class='w2'>1 l = 1 dm³</span>, <span class='w2'>1 ml = 1 sm³</span>.","<span class='w2'>50 · 30 · 40 = 60 000 sm³ = 60 l</span>.","Idishlar: (0,5) → (3,2) → (0,2) → (2,0) → (2,5) → (3,4)."]};
