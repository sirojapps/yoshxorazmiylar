var CODE='2C1',TITLE='2-sinf · Ko‘paytirish ma’nosi (teng qo‘shiluvchilar)';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P7=[function(){cPlates(5,7,{lab:1});cMsg('7 + 7 + 7 + 7 + 7 − 7 = ?','5 ta likopcha, har birida 7 ta')},
 function(){cPlates(5,7,{lab:1,hl:[4]});cMsg('«− 7» — bitta likopchani olib qo‘yamiz')},
 function(){cPlates(4,7,{lab:1});cMsg('Qoldi 4 ta yettilik: 7 · 4 = <b>28</b>')}];
var P8=[function(){cPlates(5,5,{lab:1,hl:[0,1,2]});cMsg('3 ta qutida 5 tadan va yana 2 ta qutida 5 tadan')},
 function(){cPlates(5,5,{lab:1});cMsg('Hammasi bir xil — 5 tadan! Qutilar: 3 + 2 = 5 ta')},
 function(){cPlates(5,5,{lab:1});cMsg('5 · 5 = <b>25</b> ta qalam')}];
var STEPS=[
{h:"Teng guruhlar",sum:"4 ta likopchada 3 tadan olma — teng guruhlar. Sanaymiz: 3, 6, 9, 12.",a:"m01",
 start:function(){cPlates(4,3,{title:'Har likopchada nechta?'});cMsg('Hammasi nechta olma?')},fin:function(){cPlates(4,3,{lab:function(i){return String(3*(i+1))}});cMsg('3, 6, 9, 12 — jami <b>12</b> ta')},
 html:"<p>Dasturxonda <b>4 ta likopcha</b>, har birida <b>3 tadan</b> olma. Hammasi nechta? Bittalab sanash shart emas — likopchalab sanaymiz. Tugmani bosing.</p>",
 btns:[["▶ Likopchalab sanash",function(c,done,b){b.disabled=true;var tok=S.tok,k=0;(function nx(){if(tok!==S.tok)return;k++;cPlates(4,3,{hl:[k-1],lab:function(i){return i<k?String(3*(i+1)):''}});cMsg(k<4?'… '+3*k:'3, 6, 9, 12 — jami <b>12</b> ta');if(k<4)(tok=S.tok,setTimeout(nx,750));else{b.disabled=false;b.textContent='↻ Yana';done()}})()}]],
 after:"<p>Har likopchada <b>bir xil</b> — 3 tadan. Bunday guruhlar <b>teng guruhlar</b> deyiladi. Teng guruhlarni sanash juda tez: 3, 6, 9, 12.</p>",
 q:{t:"5 ta likopchada 2 tadan nok bor. Hammasi nechta?",opts:["7","10","25","52"],ok:1,why:"2, 4, 6, 8, 10 — jami 10 ta.",hint:"Likopchalab sanang: har biri 2 tadan.",full:"Har likopcha 2 ta: 2, 4, 6, 8, 10. Jami 10 ta. «7» — likopchalar va noklar sonini qo'shib yuborish xatosi (5 + 2)."},
 tn:"Bolalarga 4 ta likopcha va 12 ta tugma bering, o'zlari teng bo'lib qo'ysin. «Teng guruh» so'zini doskaga yozing."},
{h:"Qo'shishdan ko'paytirishga",sum:"3 + 3 + 3 + 3 = 3 · 4: bir xil son necha marta qo'shilsa, shuncha marta ko'paytiriladi.",a:"m02",
 start:function(){S.n=4;c2Show()},fin:function(){S.n=4;c2Show()},
 html:"<p>4 ta likopchani yig'indi bilan yozsak: <b>3 + 3 + 3 + 3</b>. Likopcha qo'shib boring — yig'indi qanchalik uzayishini ko'ring.</p>",
 btns:[["+ likopcha",function(c,done){if(S.n<9){S.n++;c2Show();mvK(done)}}],["− likopcha",function(c,done){if(S.n>1){S.n--;c2Show();mvK(done)}}]],g2:1,
 after:"<p>Uzun yig'indini qisqa yozish uchun <b>ko'paytirish</b> o'ylab topilgan: <b>3 · 4</b> — «3 ni 4 marta olamiz». Bu ham 12. Birinchi son — <b>nimani</b> qo'shamiz (3), ikkinchisi — <b>necha marta</b> (4).</p>",
 q:{t:"5 + 5 + 5 + 5 + 5 + 5 yig'indini ko'paytma bilan yozing.",opts:["5 · 5","6 · 6","5 · 6","5 + 6"],ok:2,why:"5 soni 6 marta qo'shilgan: 5 · 6.",hint:"Qaysi son qo'shilgan? Necha marta?",full:"Qo'shiluvchi — 5, u 6 marta yozilgan. Ko'paytma: 5 · 6 = 30. «5 · 5» — necha marta ekanini noto'g'ri sanash."},
 tn:"Doskada uzun yig'indini yozing (7 + 7 + 7 + 7 + 7 + 7 + 7) va bolalardan qisqa yozishni so'rang — ko'paytirishga ehtiyojni o'zlari his qilsin."},
{h:"Faqat teng bo'lsa",sum:"3 + 3 + 4 ni ko'paytma bilan yozib bo'lmaydi — qo'shiluvchilar teng emas.",a:"m03",
 start:function(){cPlates(3,[3,3,4],{lab:1});cMsg('3 + 3 + 4 = 3 · 3 ?')},fin:function(){cPlates(3,[3,3,4],{lab:1,hl:[2]});cMsg('Teng emas — ko‘paytma bilan yozib bo‘lmaydi')},
 html:"<p>Bu yerda likopchalarda 3, 3 va 4 ta. Uni «3 · 3» deb yozsa bo'ladimi? Tanlang:</p>",
 btns:[["Ha, 3 · 3",function(c){cPlates(3,[3,3,4],{lab:1,hl:[2]});cMsg('Yo‘q: 3 · 3 = 9, lekin bu yerda 10 ta. Oxirgisi 4 ta!')}],["Yo'q, teng emas",function(c,done){cPlates(3,[3,3,4],{lab:1,hl:[2]});cMsg('To‘g‘ri! Ko‘paytirish faqat <b>teng</b> guruhlar uchun');done()}]],g2:1,
 after:"<p>Ko'paytirish — <b>bir xil</b> sonlarni qo'shishning qisqa yozuvi. Agar guruhlar har xil bo'lsa, oddiy qo'shamiz: 3 + 3 + 4 = 10.</p>",
 q:{t:"Qaysi yig'indini ko'paytma bilan yozib bo'lmaydi?",opts:["4 + 4 + 4","2 + 2 + 3","6 + 6","9 + 9 + 9 + 9"],ok:1,why:"2, 2, 3 — teng emas.",hint:"Qaysi yig'indida qo'shiluvchilar har xil?",full:"4 + 4 + 4 = 4 · 3, 6 + 6 = 6 · 2, 9 + 9 + 9 + 9 = 9 · 4. Faqat 2 + 2 + 3 da sonlar teng emas — uni ko'paytma qilib yozib bo'lmaydi."},
 tn:"Kontrmisol muhim: bolalar har qanday yig'indini ko'paytmaga aylantirishga urinadi."},
{h:"Ko'paytma qanday o'qiladi",sum:"3 · 4 = 12: «uchni to'rtga ko'paytiramiz, o'n ikki». Nuqta (·) yoki × — ko'paytirish belgisi.",a:"m04",
 start:function(){cPlates(4,3,{lab:1});cMsg('3 · 4 = 12')},fin:function(){cPlates(4,3,{lab:1});cMsg('3 · 4 = 12 — «uchni to‘rtga ko‘paytiramiz»')},
 html:"<p>Ko'paytirish belgisi — <b>nuqta (·)</b> yoki <b>×</b>. Yozuvni o'qish: <b>3 · 4 = 12</b> — «uchni to'rtga ko'paytiramiz, o'n ikki chiqadi». Ko'paytirish natijasi — <b>ko'paytma</b>. Tugmalarni bosib o'qing:</p>",
 btns:[["2 · 5",function(c,done){cPlates(5,2,{lab:1});cMsg('2 · 5 = 2 + 2 + 2 + 2 + 2 = <b>10</b> — «ikkini beshga ko‘paytiramiz»');mvK(done,2)}],["4 · 3",function(c,done){cPlates(3,4,{lab:1});cMsg('4 · 3 = 4 + 4 + 4 = <b>12</b> — «to‘rtni uchga ko‘paytiramiz»');mvK(done,2)}],["6 · 2",function(c,done){cPlates(2,6,{lab:1});cMsg('6 · 2 = 6 + 6 = <b>12</b> — «oltini ikkiga ko‘paytiramiz»');mvK(done,2)}]],
 after:"<p>Ko'paytmani yig'indi bilan tekshirish mumkin: 2 · 5 = 2 + 2 + 2 + 2 + 2 = 10.</p>",
 q:{t:"4 + 4 + 4 + 4 + 4 yig'indisi ko'paytma bilan qanday yoziladi?",opts:["4 × 4","4 × 5","5 + 4","4 + 5"],ok:1,why:"4 soni 5 marta qo'shilgan.",hint:"Nechta to'rtlik yozilgan? Sanang.",full:"4 lar soni — 5 ta. Demak 4 × 5 = 20. «4 × 4» — sanashda bittasini tashlab ketish."},
 tn:"Ikki belgi (· va ×) teng ekanini ayting; darslikda nuqta ishlatiladi."},
{h:"Qatorlar — massiv",sum:"3 qator, har qatorda 6 tadan: 6 · 3 = 18 (yoki 6 + 6 + 6).",a:"m05",
 start:function(){cArr(3,6,{title:'Stendda yulduzchalar'});cMsg('Nechta?')},fin:function(){cArr(3,6,{rowLab:1});cMsg('6 + 6 + 6 = 6 · 3 = <b>18</b>')},
 html:"<p>Narsalar ko'pincha <b>qator</b> qilib teriladi: o'rindiqlar, daraxtlar, tuxum qutisi. Qatorlab sanaymiz — tugmani bosing.</p>",
 btns:[["▶ Qatorlab sanash",function(c,done,b){b.disabled=true;var tok=S.tok,k=0;(function nx(){if(tok!==S.tok)return;k++;cArr(3,6,{hr:[k-1],rowLab:1});cMsg(['6','6 + 6 = 12','6 + 6 + 6 = 18 = 6 · 3'][k-1]);if(k<3)(tok=S.tok,setTimeout(nx,800));else{b.disabled=false;b.textContent='↻ Yana';done()}})()}]],
 after:"<p>Har qatorda 6 tadan, 3 ta qator: <b>6 · 3 = 18</b>. Bunday terilgan narsalar <b>massiv</b> deyiladi — ko'paytirishning eng aniq rasmi.</p>",
 q:{t:"Anorlar 3 qator qilib terilgan, har qatorda 6 tadan. Qaysi ifoda anorlar sonini NOTO'G'RI ko'rsatadi?",opts:["6 · 3","3 · 6","6 + 6 + 6","3 + 6"],ok:3,why:"3 + 6 = 9 — bu qator va ustunlarni qo'shish.",hint:"Qaysi ifoda 18 chiqmaydi?",full:"6 · 3, 3 · 6 va 6 + 6 + 6 — hammasi 18. «3 + 6» esa 9 — bu qatorlar soniga bitta qatordagi sonni qo'shish, xato."},
 tn:"Massiv (qator×ustun) — Singapur va Yaponiya darsliklarining asosiy rasmi. Tuxum qutisi, o'quvchilar partasi — sinfdagi tayyor massivlar."},
{h:"Hayotdagi ko'paytirish",sum:"Har bir narsada teng miqdor: velosipedda 2 g'ildirak, mushukda 4 oyoq, qo'lda 5 barmoq.",a:"m06",
 start:function(){cMsg('Tanlang: nimani sanaymiz?');clear();T(S.g,180,90,'🚲  🐈  🖐',{'font-size':40})},fin:function(){cPlates(6,4,{lab:1,title:'6 ta mushuk — 4 tadan oyoq'});cMsg('4 · 6 = <b>24</b> ta oyoq')},
 html:"<p>Ko'paytirish hayotda har qadamda: har bir velosipedda — 2 ta g'ildirak, har bir mushukda — 4 ta oyoq, har qo'lda — 5 ta barmoq. Bosib ko'ring:</p>",
 btns:[["🚲 7 velosiped",function(c,done){cPlates(7,2,{lab:1,title:'7 ta velosiped — 2 tadan g‘ildirak',col:'#555'});cMsg('2 · 7 = <b>14</b> ta g‘ildirak');mvK(done,2)}],["🐈 6 mushuk",function(c,done){cPlates(6,4,{lab:1,title:'6 ta mushuk — 4 tadan oyoq',col:'#e8a55d'});cMsg('4 · 6 = <b>24</b> ta oyoq');mvK(done,2)}],["🖐 4 qo'l",function(c,done){cPlates(4,5,{lab:1,title:'4 ta qo‘l — 5 tadan barmoq',col:'#f2c19b'});cMsg('5 · 4 = <b>20</b> ta barmoq');mvK(done,2)}]],
 after:"<p>Doim savol bering: <b>«har birida nechta?»</b> va <b>«nechta shunday?»</b>. Birinchisi — qo'shiluvchi, ikkinchisi — necha marta.</p>",
 q:{t:"Hovlida 6 ta mushuk bor. Ularning oyoqlari va quloqlari birgalikda nechta?",opts:["12","24","36","30"],ok:2,why:"Har mushukda 4 oyoq + 2 quloq = 6. 6 · 6 = 36.",hint:"Bitta mushukda oyoq va quloq birga nechta?",full:"Bitta mushuk: 4 oyoq va 2 quloq — 6 ta. 6 ta mushuk: 6 · 6 = 36. «24» — faqat oyoqlar, «12» — faqat quloqlar."},
 tn:"Bolalar o'zlari misol topsin: «uchburchakda 3 ta uch», «stulda 4 ta oyoq»."},
{h:"Tuzoq: qo'shib, keyin ayirish",sum:"7 + 7 + 7 + 7 + 7 − 7: bitta yettilik olib tashlanadi → 7 · 4 = 28.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Misol: <b>7 + 7 + 7 + 7 + 7 − 7</b>. Shoshilib hammasini sanab o'tirmang — likopchalar bilan ko'ring.</p>",
 btns:[phaser(P7)],
 after:"<p>5 ta yettilikdan bittasi olindi — <b>4 ta</b> qoldi: 7 · 4 = 28. Bu fikr bilan uzun ifodalar ham bir zumda hisoblanadi.</p>",
 q:{t:"(y + y + y + … + y) − y. Qavs ichida 25 ta bir xil qo'shiluvchi. Ifoda qaysi ko'paytmaga teng?",opts:["y · 25","y · 26","24 + y","y · 24"],ok:3,why:"25 ta y dan bittasi olinadi — 24 ta qoladi.",hint:"Qavsda nechta y bor? Bittasi olinsa, nechta qoladi?",full:"Qavs ichida 25 ta y — bu y · 25. Bitta y ni ayiramiz: 24 ta y qoladi, ya'ni y · 24. «y · 26» — ayirish o'rniga qo'shib qo'yish."},
 tn:"Harfli misollar bolalarni qo'rqitadi — likopcha rasmini chizing: harf faqat «noma'lum son»."},
{h:"Tuzoq: guruhlarni birlashtirish",sum:"3 qutida 5 tadan va 2 qutida 5 tadan → 5 qutida 5 tadan: 5 · 5 = 25.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Masala: <i>«3 ta qutida 5 tadan va yana 2 ta qutida 5 tadan qalam bor. Jami nechta?»</i> Ikki marta hisoblash shart emas!</p>",
 btns:[phaser(P8)],
 after:"<p>Qutilar bir xil (5 tadan) — demak ularni birlashtirib sanaymiz: 3 + 2 = 5 ta quti, 5 · 5 = 25. Tekshiramiz: 15 + 10 = 25 ✓.</p>",
 q:{t:"6 + 6 + 6 yig'indisiga yana bitta 6 qo'shilsa, nechchi bo'ladi?",opts:["36","24","18","12"],ok:1,why:"4 ta oltilik: 6 · 4 = 24.",hint:"Endi nechta oltilik bo'ldi?",full:"6 + 6 + 6 — 3 ta oltilik (18). Yana bittasi — 4 ta: 6 · 4 = 24. «36» — 6 · 6 deb o'ylash xatosi."},
 tn:"«Guruhlarni birlashtirish» — keyingi mavzudagi taqsimot xossasining (2C15) boshlanishi."},
{h:"Bilasizmi? Belgining tarixi",sum:"«×» belgisini 1631-yilda Uilyam Otred, nuqta «·» ni Gotfrid Leybnits taklif qilgan.",a:"m09",
 start:function(){clear('#f6ead0');T(S.g,110,100,'×',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,250,100,'·',{'font-size':90,'font-weight':800,fill:'#6b3d12'});T(S.g,110,140,'Otred, 1631',{'font-size':12,fill:'#6b3d12'});T(S.g,250,140,'Leybnits',{'font-size':12,fill:'#6b3d12'});cMsg('Ko‘paytirish belgilari')},fin:function(){STEPS[8].start()},
 html:"<p>📜 Ingliz matematigi <b>Uilyam Otred</b> 1631-yilda chop etilgan kitobida <b>×</b> belgisini ishlatgan. Nemis olimi <b>Gotfrid Leybnits</b> esa × ni «x» harfi bilan adashtirmaslik uchun <b>nuqta (·)</b> ni taklif qilgan. Shuning uchun darsligimizda nuqta ishlatiladi.</p><p>🏺 Qadimgi Misrliklar esa ko'paytirishni <b>ikkilantirish</b> orqali bajarishgan: 3 · 4 = 3 + 3 = 6, 6 + 6 = 12.</p>",
 tn:"Bolalarga ikkala belgini yozdiring va «x harfi» bilan farqini ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){cPlates(4,3,{lab:1});cMsg('3 + 3 + 3 + 3 = 3 · 4 = 12')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>Ko'paytirish</b> — bir xil sonlarni qo'shishning qisqa yozuvi: 3 + 3 + 3 + 3 = <b>3 · 4</b> = 12.</li><li>Birinchi son — <b>nimani</b> qo'shamiz, ikkinchisi — <b>necha marta</b>.</li><li>Faqat <b>teng</b> guruhlar ko'paytiriladi: 3 + 3 + 4 ni ko'paytma qilib bo'lmaydi.</li><li>Massiv: 3 qator, har birida 6 tadan → 6 · 3 = 18.</li><li>Savol bering: «har birida nechta?», «nechta shunday?».</li><li>7 + 7 + 7 + 7 + 7 − 7 = 7 · 4 = 28.</li><li>Belgilar: <b>·</b> yoki <b>×</b>. Natija — <b>ko'paytma</b>.</li></ul></div>",
 tn:"Keyingi darsni «Velosipedlarning 14 ta g'ildiragi bor. Nechta velosiped?» savoli bilan boshlang — bu bo'lishga ko'prik."}
];
function c2Show(){var n=S.n;cPlates(n,3,{lab:1});cMsg(Array(n).fill('3').join(' + ')+' = <b>3 · '+n+'</b> = '+3*n)}
var PROBS=[
{t:"3 ta likopchada 4 tadan olma. Hammasi nechta?",o:["12","7","34","10"],k:0,s:"4 · 3 = 4 + 4 + 4 = 12."},
{t:"2 + 2 + 2 + 2 + 2 + 2 + 2 ko'paytma bilan qanday yoziladi?",o:["2 · 7","2 · 6","7 · 7","2 + 7"],k:0,s:"2 soni 7 marta qo'shilgan: 2 · 7."},
{t:"Qaysi yig'indi 3 · 6 ko'paytmaga teng EMAS?",o:["3 + 3 + 3 + 3 + 3 + 3 + 3","6 + 6 + 6","9 + 9","3 + 3 + 3 + 3 + 3 + 3"],k:0,s:"3 · 6 = 18. Yetti marta 3 — 21, bu teng emas."},
{t:"Velosipedlarning jami 14 ta g'ildiragi bor, har birida 2 tadan. Nechta velosiped bor?",o:["7","12","16","28"],k:0,s:"2, 4, 6, 8, 10, 12, 14 — 7 ta ikkilik, 7 ta velosiped."},
{t:"Bitta stol atrofida 6 kishi o'tiradi. 7 ta stol atrofida nechta kishi o'tiradi?",o:["42","13","36","48"],k:0,s:"6 · 7 = 42."},
{t:"Mashina 1 minutda 9 quti qadoqlaydi. 6 minutda nechta quti qadoqlaydi?",o:["54","45","48","15"],k:0,s:"9 · 6 = 54."},
{t:"7 + 7 + 7 + 7 + 7 − 7 ifodaning qiymatini toping.",o:["28","35","42","21"],k:0,s:"5 ta yettilikdan bittasi olinadi: 7 · 4 = 28."},
{t:"Hovlida 6 ta mushuk. Ularning oyoqlari va quloqlari birgalikda nechta?",o:["36","24","12","30"],k:0,s:"Bitta mushuk: 4 + 2 = 6. 6 · 6 = 36."},
{t:"3 ta qutida 5 tadan va yana 2 ta qutida 5 tadan qalam bor. Jami nechta?",o:["25","15","10","30"],k:0,s:"5 ta quti, har birida 5 tadan: 5 · 5 = 25."},
{t:"Uchta teng qo'shiluvchining yig'indisi 21. Shu qo'shiluvchilardan bittasini 4 ga ko'paytirsak, nechchi chiqadi?",o:["28","84","24","7"],k:0,s:"Bitta qo'shiluvchi: 7 (7 + 7 + 7 = 21). 7 · 4 = 28."},
{t:"Qaysi yig'indini ko'paytma bilan yozib bo'lmaydi?",o:["5 + 5 + 6","8 + 8 + 8","1 + 1 + 1 + 1","10 + 10"],k:0,s:"5, 5, 6 — teng emas."},
{t:"6 + 6 + 6 yig'indisiga yana 6 qo'shilsa, nechchi bo'ladi?",o:["24","36","18","12"],k:0,s:"4 ta oltilik: 6 · 4 = 24."},
{t:"Stendga yulduzchalar 4 qator qilib yopishtirildi, har qatorda 7 tadan. Nechta yulduzcha?",o:["28","11","21","24"],k:0,s:"7 · 4 = 28."},
{t:"Har bir stolga likopchalar 2 qator qilib, har qatorga 5 tadan qo'yilgan. 4 ta stolda jami nechta likopcha?",o:["40","20","10","80"],k:0,s:"Bitta stol: 5 · 2 = 10. 4 ta stol: 10 · 4 = 40."},
{t:"Sinfda 17 juft navbatchi tuzildi (har juftda 2 kishi, hamma bir martadan). Sinfda nechta o'quvchi?",o:["34","19","36","17"],k:0,s:"2 · 17 = 34."},
{t:"Qaysi ko'paytma 5 + 5 + 5 + 5 ga teng?",o:["5 · 4","4 · 4","5 · 5","5 + 4"],k:0,s:"5 soni 4 marta: 5 · 4 = 20."},
{t:"Har bir qo'lda 5 ta barmoq. 3 ta bolaning ikkala qo'lida jami nechta barmoq?",o:["30","15","10","25"],k:0,s:"Bitta bola: 5 · 2 = 10. 3 ta bola: 10 · 3 = 30."},
{t:"8 + 8 + 8 + 8 − 8 + 8 qaysi ko'paytmaga teng?",o:["8 · 4","8 · 5","8 · 6","8 · 3"],k:0,s:"5 ta sakkizlik qo'shildi, bittasi ayirildi: 4 ta qoladi."},
{t:"Bog'da 4 qator olma daraxti, har qatorda 9 tadan. Yana 1 qator qo'shilsa, jami nechta daraxt bo'ladi?",o:["45","36","40","13"],k:0,s:"5 qator, 9 tadan: 9 · 5 = 45."},
{t:"Qaysi yozuv to'g'ri?",o:["4 + 4 + 4 = 4 · 3","4 + 4 + 4 = 4 · 4","4 + 4 + 4 = 3 + 4","4 + 4 + 4 = 4 + 3"],k:0,s:"4 soni 3 marta qo'shilgan: 4 · 3 = 12."}
];
function PRACT_STAGE(){cPlates(4,3,{lab:1});cMsg('Har birida nechta? Nechta shunday?')}
var PREP_DATA={teach:["Teng guruhlar va ularni guruhlab sanash.","Ko'paytirish — teng qo'shiluvchilar yig'indisining qisqa yozuvi; belgilar · va ×; ko'paytma.","Massiv (qator × ustun) va hayotiy misollar.","Tuzoqlar: teng bo'lmagan qo'shiluvchilar, «− 7» li yig'indi, guruhlarni birlashtirish."],
 mist:["Guruhlar sonini va har biridagi sonni qo'shib yuboradi (5 likopcha, 2 tadan → 7).","Har qanday yig'indini ko'paytma qiladi (3 + 3 + 4 = 3 · 3).","Qo'shiluvchilarni sanashda adashadi (5 ta to'rtlik → 4 · 4).","Massivda qator va ustunni qo'shadi (3 + 6)."],
 need:["Likopchalar (qog'oz doira) va tugma/loviya.","Tuxum qutisi yoki doskada nuqtali massiv."],
 board:["<span class='w2'>3 + 3 + 3 + 3 = 3 · 4 = 12</span>.","«Nimani qo'shamiz?» · «Necha marta?»","<span class='w2'>3 + 3 + 4 ≠ 3 · 3</span>.","Massiv: <span class='w2'>●●●●●● ×3 = 6 · 3</span>.","<span class='w2'>7 + 7 + 7 + 7 + 7 − 7 = 7 · 4</span>."]};
