
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G2',TITLE='3-sinf · Massa (g, kg, sentner, tonna) va sig‘im (l)';
function g2bal(){var R=S.g2R;clear();T(S.g,14,18,'Tarozini muvozanatga keltiring',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});f3scale(1000,R,'1 kg 🍉',R?R+' g':'');
 f3calc([R===1000?'✓ <b>1000 g = 1 kg</b> — tarozi muvozanatda':R>1000?'O‘ng tomon og‘ir: '+R+' g. Keyingi toshdan qaytadan boshlaymiz':'O‘ngda '+R+' g — hali yengil'])}
function g2add(v,done){if(S.g2R>1000)S.g2R=0;S.g2R+=v;g2bal();if(S.g2R===1000)done()}
var G2U=[['g','1 g — bitta qog‘oz qisqich og‘irligiga yaqin'],['kg','1 kg = 1000 g'],['s','1 sentner = 100 kg'],['t','1 t = 10 s = 1000 kg']];
function g2lad(sel){clear();var g=S.g,xs=[45,135,225,315];T(g,180,20,'kichikdan kattaga →',{'font-size':11,fill:'#3a4a5a'});
 G2U.forEach(function(u,i){var on=i===sel,y=118-i*24;E('rect',{x:xs[i]-30,y:y-24,width:60,height:38,rx:8,fill:on?C.a:'#fff',stroke:on?C.a:C.line,'stroke-width':2},g);T(g,xs[i],y+2,u[0],{'font-size':17,'font-weight':800,fill:on?'#fff':'#1d2b3a'});
  if(i<3)T(g,xs[i]+56,y-30,['×1000','×100','×10'][i],{'font-size':12,'font-weight':800,'text-anchor':'end',fill:C.blue})});
 f3calc([sel==null?'Birlikni tanlang':'<b>'+G2U[sel][1]+'</b>','g → kg: 1000; kg → s: 100; s → t: 10'])}
function g2tab(st){clear();var g=S.g;T(g,14,20,'1) 7 kg 40 g = ? g',{'font-size':12,'font-weight':800,'text-anchor':'start'});T(g,14,104,'2) 1 t 25 s = ? s',{'font-size':12,'font-weight':800,'text-anchor':'start'});
 if(st>=1){T(g,262,52,'7 kg = 7000 g;  7000 + 40 =',{'text-anchor':'end','font-size':14,'font-weight':700,fill:'#33475b'});T(g,268,52,'7040 g',{'text-anchor':'start','font-size':15,'font-weight':800,fill:C.ok});T(g,180,74,'(740 g emas! 40 g — yuzliklar xonasida 0)',{'font-size':11,fill:C.bad})}
 if(st>=2){T(g,262,136,'1 t = 10 s;  10 + 25 =',{'text-anchor':'end','font-size':14,'font-weight':700,fill:'#33475b'});T(g,268,136,'35 s',{'text-anchor':'start','font-size':15,'font-weight':800,fill:C.ok});T(g,180,158,'(1 t = 100 s emas — 100 kg emas, 1000 kg)',{'font-size':11,fill:C.bad})}}
var G2P3=[function(){g2tab(0);f3calc(['Ismli sonni bitta birlikka keltiramiz'])},function(){g2tab(1);f3calc(['7 kg 40 g = <b>7040 g</b>'])},function(){g2tab(2);f3calc(['7 kg 40 g = 7040 g','1 t 25 s = <b>35 s</b>'])}];
function g2buck(){var L=S.g2L,g;clear();g=S.g;E('path',{d:'M200 40 L290 40 L280 150 L210 150 Z',fill:'#fff',stroke:'#33475b','stroke-width':3},g);var h=L/10*108;if(L)E('path',{d:'M'+(210-10*h/110+0)+' '+(150-h)+' L'+(280+10*h/110)+' '+(150-h)+' L280 150 L210 150 Z',fill:'#7cc3f0'},g);
 for(var i=2;i<=10;i+=2){var y=150-i/10*108;E('line',{x1:282+i,y1:y,x2:292+i,y2:y,stroke:'#33475b'},g);T(g,310+i,y+4,i+' l',{'font-size':10,fill:'#33475b'})}
 E('path',{d:'M60 70 L120 70 L125 150 L55 150 Z',fill:'#bfe3f8',stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M120 82 q22 4 18 34',fill:'none',stroke:'#33475b','stroke-width':3},g);T(g,90,116,'2 l',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});T(g,245,168,'chelak 10 l',{'font-size':11,'font-weight':700,fill:'#33475b'});
 f3calc([L<10?'Chelakda '+L+' l. Quyildi: '+L/2+' marta':'✓ 5 marta 2 litrdan: <b>2 · 5 = 10 l</b>'])}
var G2P5=[function(){g2pack(0);f3calc(['3 kg shakar, paket 450 g. Nechta paket to‘ladi?'])},function(){g2pack(1);f3calc(['3 kg = <b>3000 g</b>. 450 · 6 = 2700 — 6 ta paket','3000 − 2700 = <b>300 g</b> qoldi'])},function(){g2pack(2);f3calc(['7-paket uchun: 450 − 300 = <b>150 g</b> yetmaydi'])}];
function g2pack(st){clear();var g=S.g;for(var i=0;i<7;i++){var x=18+i*48,full=st>=1&&i<6,part=st>=1&&i===6;E('rect',{x:x,y:50,width:40,height:70,rx:5,fill:'#fff',stroke:C.line,'stroke-width':1.5},g);
 if(full)E('rect',{x:x+2,y:52,width:36,height:66,rx:4,fill:'#f4e3c3'},g);if(part){E('rect',{x:x+2,y:52+66*150/450,width:36,height:66*300/450,rx:4,fill:'#f4e3c3'},g);if(st>=2){E('rect',{x:x+2,y:52,width:36,height:22,fill:'#ffd9d4'},g);T(g,x+20,68,'150',{'font-size':11,'font-weight':800,fill:C.bad})}}
 T(g,x+20,136,full?'450 g':part?'300 g':'',{'font-size':10,'font-weight':700,fill:'#6b4c1e'})}T(g,180,30,'Har paket 450 g',{'font-size':11,fill:'#3a4a5a'})}
var G2P6=[function(){g2jar(0);f3calc(['Bo‘sh banka 300 g, to‘la banka 1 kg 500 g. Yarmigacha to‘ldirilgani?'])},function(){g2jar(1);f3calc(['Asalning o‘zi: 1500 − 300 = <b>1200 g</b>'])},function(){g2jar(2);f3calc(['Asalning yarmi: 1200 : 2 = 600 g','Banka bilan: 600 + 300 = <b>900 g</b>','Xato: 1500 : 2 = 750 — bankani ham yarimlab yubordik'])}];
function g2jar(st){clear();var g=S.g;function jar(x,lvl,lab){E('rect',{x:x,y:42,width:80,height:100,rx:10,fill:'#fff',stroke:'#33475b','stroke-width':3},g);if(lvl)E('rect',{x:x+4,y:138-92*lvl,width:72,height:92*lvl,rx:6,fill:'#f2b535'},g);T(g,x+40,160,lab,{'font-size':11,'font-weight':800,fill:'#33475b'})}
 jar(30,0,'bo‘sh: 300 g');jar(140,1,'to‘la: 1500 g');jar(250,st>=2?.5:0,st>=2?'yarim: 900 g':'yarim: ?');if(st>=1)T(g,180,96,'asal 1200 g',{'font-size':12,'font-weight':800,fill:'#7a4b00'});if(st>=2)T(g,290,118,'600 g',{'font-size':12,'font-weight':800,fill:'#7a4b00'})}
var G2P7=[function(){clear();f3scale(1,1,'🍎🍎🍎 + 100 g','700 g');f3calc(['Tarozi muvozanatda: 3 ta olma va 100 g tosh = 700 g'])},function(){clear();f3scale(1,1,'🍎🍎🍎','600 g');f3calc(['Ikkala tomondan 100 g olib tashlaymiz — muvozanat saqlanadi','3 ta olma = 700 − 100 = <b>600 g</b>'])},function(){clear();f3scale(1,1,'🍎','200 g');f3calc(['1 ta olma = 600 : 3 = <b>200 g</b>','Tekshirish: 200 · 3 + 100 = 700 ✓'])}];
var G2P8=[function(){g2fruit(0);f3calc(['4 ta bir xil behi = 1 kg. Bittasi 180 g anorga almashtirildi'])},function(){g2fruit(1);f3calc(['1 kg = 1000 g. Bitta behi: 1000 : 4 = <b>250 g</b>'])},function(){g2fruit(2);f3calc(['3 behi + anor: 250 · 3 + 180 = 750 + 180 = <b>930 g</b>','Xato: 1000 + 180 = 1180 — behini olib tashlashni unutdik'])}];
function g2fruit(st){clear();var g=S.g;for(var i=0;i<4;i++){var an=st>=2&&i===3,x=60+i*80;E('circle',{cx:x,cy:80,r:28,fill:an?'#d6334a':'#f3d34a',stroke:'#8a6a12','stroke-width':2},g);T(g,x,85,an?'anor':'behi',{'font-size':11,'font-weight':800,fill:an?'#fff':'#5a4600'});
 if(st>=1)T(g,x,130,an?'180 g':'250 g',{'font-size':12,'font-weight':800,fill:an?C.bad:C.blue})}}
function g2hist(){clear('#eaf4fb');var g=S.g;E('path',{d:'M70 50 h50 v90 h-50 Z',fill:'#bfe3f8',stroke:'#33475b','stroke-width':2.5},g);T(g,95,100,'1 l',{'font-size':15,'font-weight':800});T(g,180,100,'≈',{'font-size':24,'font-weight':800,fill:C.blue});
 E('rect',{x:230,y:70,width:70,height:56,rx:6,fill:'#9aa7b4',stroke:'#33475b','stroke-width':2.5},g);T(g,265,104,'1 kg',{'font-size':15,'font-weight':800,fill:'#fff'});f3msg('1 litr suvning massasi taxminan 1 kg')}
var STEPS=[
{h:"Tarozi: gramm va kilogramm",sum:"1 kg = 1000 g. Tarozi muvozanatda bo'lsa, ikkala tomonning massasi teng.",a:"m01",
 start:function(){S.g2R=0;g2bal()},fin:function(){S.g2R=1000;g2bal()},
 html:"<p>Chap pallada <b>1 kg</b> qovun. O'ng pallaga toshlarni qo'yib, tarozini <b>muvozanatga</b> keltiring:</p>",
 btns:[["500 g",function(c,done){g2add(500,done)}],["200 g",function(c,done){g2add(200,done)}],["100 g",function(c,done){g2add(100,done)}]],g3:1,
 after:"<p>Muvozanat 1000 g da: <b>1 kg = 1000 g</b>. Masalan: 500 + 200 + 200 + 100 = 1000.</p>",
 q:{t:"3 kg necha gramm?",opts:["300 g","3000 g","30 g","1003 g"],ok:1,why:"3 · 1000 = 3000.",hint:"1 kg da necha gramm?",full:"1 kg = 1000 g, 3 kg = 3000 g. «300» — 1 kg ni 100 g deb o'ylash xatosi."},
 tn:"Sinfga uy tarozisi yoki pallali tarozi olib keling: 1 kg shakarni 100 g lik paketlar bilan muvozanatlang."},
{h:"Massa birliklari zinapoyasi",sum:"1 kg = 1000 g; 1 s = 100 kg; 1 t = 10 s = 1000 kg.",a:"m02",
 start:function(){g2lad(null)},fin:function(){g2lad(3)},
 html:"<p>Massa birliklarini bosib, ular orasidagi bog'lanishni ko'ring (kamida 3 tasi):</p>",
 btns:G2U.map(function(u,i){return [u[0]==='s'?'sentner':u[0]==='t'?'tonna':u[0],function(c,done){g2lad(i);mvK(done,3)}]}),g2:1,
 after:"<p>Diqqat: zinapoya qadamlari <b>har xil</b>: g → kg — 1000 marta, kg → sentner — 100 marta, sentner → tonna — 10 marta. Uzunlikdagidek hammasi 10 emas!</p>",
 q:{t:"4 t necha sentner?",opts:["400 s","4000 s","40 s","14 s"],ok:2,why:"1 t = 10 s.",hint:"1 tonnada nechta sentner?",full:"1 t = 10 s, 4 t = 40 s. «400» — 1 t ni 100 s deb o'ylash, «4000» — kg bilan aralashtirish (4 t = 4000 kg)."},
 tn:"Hayotiy misollar: bola 30 kg, qop un 50 kg (yarim sentner), avtomobil 1 tonnadan og'irroq."},
{h:"Bitta birlikka keltirish",sum:"7 kg 40 g = 7040 g; 1 t 25 s = 35 s.",a:"m03",
 start:function(){startPh(G2P3)},fin:function(){S.ph=2;G2P3[2]()},
 html:"<p>Ikki namuna — ikkalasida ham ko'p uchraydigan tuzoq bor:</p>",btns:[phaser(G2P3)],
 after:"<p>Kilogramdan grammga — 1000 ga ko'paytiramiz va qo'shamiz. 40 g ni yozganda yuzliklar xonasi bo'sh — <b>0</b>: 7040.</p>",
 q:{t:"5 kg 8 g necha gramm?",opts:["58 g","508 g","5008 g","5080 g"],ok:2,why:"5000 + 8 = 5008.",hint:"5 kg = 5000 g. Unga 8 ni qo'shing.",full:"5 kg = 5000 g, + 8 g = 5008 g. «508» va «58» — nollar tushib qolgan, «5080» — 8 ni o'nlikka yozish."},
 tn:"Jadval: kg | yuz g | o'n g | g — bo'sh xonalarga 0 yozishni mashq qiling."},
{h:"Sig'im: litr",sum:"Sig'im litrda o'lchanadi. 10 l li chelakni 2 l li choynak bilan to'ldirish uchun 5 marta quyamiz.",a:"m04",
 start:function(){S.g2L=0;g2buck()},fin:function(){S.g2L=10;g2buck()},
 html:"<p>Idishga qancha suyuqlik sig'ishi — <b>sig'im</b>. U <b>litr</b> (l) da o'lchanadi. 2 litrli idish bilan 10 litrli chelakni to'ldiring:</p>",
 btns:[["💧 2 l quyish",function(c,done){if(S.g2L<10)S.g2L+=2;g2buck();if(S.g2L===10)done()}]],
 after:"<p>2 · 5 = 10 l. Sut, suv, benzin litrda o'lchanadi. Suyuqlikni bir idishdan boshqasiga quysak — <b>litrlar soni o'zgarmaydi</b>, faqat shakli o'zgaradi.</p>",
 q:{t:"Bochkada 60 l suv. Uni 3 l li bankalarga quyishdi. Nechta banka kerak?",opts:["20","63","57","180"],ok:0,why:"60 : 3 = 20.",hint:"60 litrda nechta 3 litr bor?",full:"60 : 3 = 20 ta banka. «180» — ko'paytirish xatosi, «57» — ayirish."},
 tn:"Sinfda 1 litrli shisha va stakanlar bilan: 1 litrga nechta stakan sig'adi? (Taxminan 4–5 ta.)"},
{h:"Tuzoq: qoldiqli qadoqlash",sum:"3000 g : 450 g = 6 paket, qoldiq 300 g; 7-paketga 150 g yetmaydi.",a:"m05",
 start:function(){startPh(G2P5)},fin:function(){S.ph=2;G2P5[2]()},
 html:"<p><i>«3 kg shakar 450 g dan paketlarga solindi. Iloji boricha ko'p paket to'ldirildi. Yana bitta paketni to'ldirish uchun necha gramm shakar yetmaydi?»</i></p>",btns:[phaser(G2P5)],
 after:"<p>Uchta qadam: kg → g; qoldiqli bo'lish (3000 : 450 = 6, qoldiq 300); <b>yetmagan qism</b> = 450 − 300 = 150. Ko'pchilik 300 ni javob qiladi — bu qolgani, yetmagani emas!</p>",
 q:{t:"2 kg guruch 300 g dan paketlarga solindi. Nechta paket to'ladi va necha gramm ortib qoldi?",opts:["6 paket, 200 g","7 paket, 100 g","6 paket, 100 g","66 paket"],ok:0,why:"300 · 6 = 1800, 2000 − 1800 = 200.",hint:"2 kg = 2000 g. 300 ni necha marta olish mumkin?",full:"2000 : 300 = 6 (qoldiq 200). 300 · 7 = 2100 — 2000 dan ko'p, demak 7 ta paket to'lmaydi."},
 tn:"Masala shartidagi «yetmaydi» va «qoldi» so'zlarining farqini doskada ajrating."},
{h:"Tuzoq: idish va ichidagi",sum:"To'la banka 1500 g, bo'sh 300 g: asal 1200 g, yarmi 600 g, yarim banka 900 g.",a:"m06",
 start:function(){startPh(G2P6)},fin:function(){S.ph=2;G2P6[2]()},
 html:"<p><i>«Bo'sh bankaning massasi 300 g. Asal bilan to'la banka 1 kg 500 g. Yarmigacha asal to'ldirilgan banka qancha keladi?»</i></p>",btns:[phaser(G2P6)],
 after:"<p>Bankaning o'zi yarimlanmaydi! Avval <b>ichidagini</b> ajratamiz, keyin yarmini olamiz va bankani qaytarib qo'shamiz.</p>",
 q:{t:"Murabbo to'la banka 750 g, yarmigacha to'lgani 450 g. Bo'sh banka necha gramm?",opts:["300 g","375 g","150 g","200 g"],ok:2,why:"Yarim murabbo = 750 − 450 = 300 g; to'la murabbo 600 g; banka 750 − 600 = 150 g.",hint:"750 va 450 ning farqi — murabboning qaysi qismi?",full:"To'la va yarim banka farqi — murabboning yarmi: 300 g. Butun murabbo 600 g. Banka: 750 − 600 = 150 g. «300» — bu murabbo yarmi, «375» — 750 ning yarmi."},
 tn:"Bu bankdagi eng qiyin turlardan. Haqiqiy idish va suv bilan ko'rsatsangiz, bolalar tezda tushunadi."},
{h:"Tuzoq: tarozi tenglamasi",sum:"3 olma + 100 g = 700 g → 3 olma = 600 g → 1 olma = 200 g.",a:"m07",
 start:function(){startPh(G2P7)},fin:function(){S.ph=2;G2P7[2]()},
 html:"<p>Tarozi — tenglamaning eng yaxshi modeli. Ikkala tomondan bir xil narsani olsak, muvozanat buzilmaydi:</p>",btns:[phaser(G2P7)],
 after:"<p>Qadamlar: 1) ikkala tomondan 100 g olamiz; 2) 3 ga bo'lamiz. Bu — keyinroq o'rganadigan <b>tenglama</b> yechishning o'zi: 3 · x + 100 = 700.</p>",
 q:{t:"Tarozida: 2 ta bir xil qovun va 1 kg tosh = 9 kg. Bitta qovun necha kg?",opts:["4 kg","5 kg","4 kg 500 g","8 kg"],ok:0,why:"9 − 1 = 8, 8 : 2 = 4.",hint:"Avval toshni ikkala tomondan olib tashlang.",full:"2 qovun = 9 − 1 = 8 kg. 1 qovun = 8 : 2 = 4 kg. «4 kg 500 g» — 9 ni 2 ga bo'lish (toshni unutish), «8» — 2 ga bo'lmaslik."},
 tn:"AQSh va Singapurda tarozi modeli tenglamalarga tayyorlashda ishlatiladi. Plastilin va toshlar bilan sinab ko'ring."},
{h:"Tuzoq: almashtirish",sum:"4 behi = 1 kg → 1 behi 250 g; 3 behi + 180 g anor = 930 g.",a:"m08",
 start:function(){startPh(G2P8)},fin:function(){S.ph=2;G2P8[2]()},
 html:"<p><i>«4 ta bir xil behining massasi 1 kg. Bitta behi 180 g li anorga almashtirildi. Mevalar endi qancha keladi?»</i></p>",btns:[phaser(G2P8)],
 after:"<p>Almashtirishda bitta narsa <b>chiqadi</b> (−250 g), boshqasi <b>kiradi</b> (+180 g): 1000 − 250 + 180 = 930 g.</p>",
 q:{t:"Bitta quyon kuniga 150 g sabzi yeydi. 3 ta quyon 6 kunda qancha yeydi?",opts:["2 kg 700 g","900 g","2 kg 400 g","27 kg"],ok:0,why:"150 · 3 · 6 = 2700 g.",hint:"Avval bir kunda 3 quyon qancha yeydi?",full:"Bir kunda: 150 · 3 = 450 g. 6 kunda: 450 · 6 = 2700 g = 2 kg 700 g. «900» — faqat bitta quyon 6 kunda, «27 kg» — birlik xatosi."},
 tn:"Bolalar o'z masalasini tuzsin: «bittasini boshqasiga almashtirdik…»."},
{h:"Bilasizmi? Litr va kilogramm",sum:"1 litr suvning massasi taxminan 1 kg; «sentner» so'zi lotincha «centum» — yuz so'zidan.",a:"m09",
 start:function(){g2hist()},fin:function(){g2hist()},
 html:"<p>💧 <b>1 litr</b> toza suvning massasi taxminan <b>1 kilogramm</b>. Shuning uchun 10 litrli chelak suv taxminan 10 kg keladi (chelakning o'zi hisobga kirmaydi!).</p><p>📖 <b>Sentner</b> so'zi lotincha <b>«centum» — «yuz»</b> so'zidan kelib chiqqan: 1 sentner = 100 kg. «Santimetr» (metrning yuzdan biri) ham shu so'zdan.</p>",
 tn:"Bolalar 1 litrli shishani suvga to'ldirib, uy tarozisida tortsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g2lad(3)},fin:function(){g2lad(3)},
 html:"<div class='memo'><ul><li><b>1 kg = 1000 g</b>, <b>1 s = 100 kg</b>, <b>1 t = 10 s = 1000 kg</b>.</li><li>Sig'im — <b>litr</b> (l). 1 l suv ≈ 1 kg.</li><li>Bir birlikka: 7 kg 40 g = <b>7040 g</b> (bo'sh xonaga 0).</li><li>Qadoqlashda: qoldiqli bo'lish; «yetmaydi» ≠ «qoldi».</li><li>Idishli masalada avval <b>idishni ayiring</b>.</li><li>Tarozi: ikkala tomondan bir xil olsak — muvozanat saqlanadi.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring."}
];
var PROBS=[
{t:"6 kg necha gramm?",o:["6000 g","600 g","60 g","60 000 g"],k:0,s:"6 · 1000."},
{t:"5 s necha kilogramm?",o:["500 kg","50 kg","5000 kg","105 kg"],k:0,s:"1 s = 100 kg."},
{t:"3 t necha sentner?",o:["30 s","300 s","3000 s","13 s"],k:0,s:"1 t = 10 s."},
{t:"7 kg 40 g necha gramm?",o:["7040 g","740 g","70 400 g","70 040 g"],k:0,s:"7000 + 40."},
{t:"1 t 25 s = ? s",o:["35","1250","45","1025"],k:0,s:"10 + 25 = 35."},
{t:"1700 g + 2600 g + 1300 g + 2400 g = ? kg",o:["8","7","80","800"],k:0,s:"8000 g = 8 kg."},
{t:"Qaysi biri og'irroq: 2 kg 50 g yoki 2050 g?",o:["Teng","2 kg 50 g","2050 g","Taqqoslab bo'lmaydi"],k:0,s:"2 kg 50 g = 2050 g."},
{t:"Qaysi massa eng katta?",o:["3 t","25 s","2900 kg","29 s 90 kg"],k:0,s:"3000 kg > 2990 > 2900 > 2500."},
{t:"Bochkada 60 l suv. 3 l li bankalarga quyildi. Nechta banka?",o:["20","180","57","63"],k:0,s:"60 : 3 = 20."},
{t:"Choynakka 2 l sig'adi. 10 l li chelakni to'ldirish uchun choynak bilan necha marta quyish kerak?",o:["5","20","8","12"],k:0,s:"10 : 2 = 5."},
{t:"3 kg shakar 450 g dan paketlarga solindi. Yana bitta paketni to'ldirish uchun necha gramm yetmaydi?",o:["150 g","300 g","50 g","450 g"],k:0,s:"6 paket, qoldi 300, yetmaydi 150."},
{t:"5 paket kashnich (120 g dan) va 4 paket sabzi urug'i (150 g dan) olindi. Qaysi urug' ko'p?",o:["Teng","Kashnich","Sabzi","Kashnich 30 g ko'p"],k:0,s:"600 g = 600 g."},
{t:"4 ta bir xil behi 1 kg. Bittasi 180 g li anorga almashtirildi. Endi necha gramm?",o:["930","1180","750","820"],k:0,s:"750 + 180."},
{t:"Suv bilan to'la idish 450 g, bo'sh idish 150 g. Yarmigacha suv quyilgan idish qancha?",o:["300 g","225 g","375 g","150 g"],k:0,s:"Suv 300, yarmi 150, + 150 = 300."},
{t:"Bo'sh banka 300 g, asal bilan to'la 1 kg 500 g. Yarmigacha to'lgani qancha?",o:["900 g","750 g","600 g","1 kg 200 g"],k:0,s:"1200 : 2 + 300."},
{t:"Murabbo to'la banka 750 g, yarmigacha to'lgani 450 g. Bo'sh banka?",o:["150 g","300 g","200 g","375 g"],k:0,s:"Yarim murabbo 300, butun 600, banka 150."},
{t:"Tarozida 3 ta bir xil olma va 100 g tosh 700 g ni tortadi. 1 olma?",o:["200 g","233 g","300 g","600 g"],k:0,s:"(700 − 100) : 3."},
{t:"Bitta quyon kuniga 150 g sabzi yeydi. 3 quyon 6 kunda?",o:["2 kg 700 g","900 g","2 kg 400 g","27 kg"],k:0,s:"150 · 18 = 2700 g."},
{t:"Yuk mashinasiga 3 t yuk sig'adi. Unga 50 kg li 50 ta qop ortildi. Yana necha kg yuk sig'adi?",o:["500 kg","2950 kg","2500 kg","250 kg"],k:0,s:"50 · 50 = 2500 kg, 3000 − 2500 = 500 kg."},
{t:"1 l suv ≈ 1 kg. Bo'sh chelak 1 kg. 8 l suvli chelak taxminan necha kg?",o:["9 kg","8 kg","7 kg","10 kg"],k:0,s:"8 + 1 = 9 kg."}
];
function PRACT_STAGE(){g2lad(null)}
var PREP_DATA={teach:["g, kg, sentner, tonna va ular orasidagi bog'lanish; tarozi.","Ismli sonlarni bitta birlikka keltirish.","Sig'im — litr.","Tuzoqlar: qoldiqli qadoqlash, idish va ichidagi, tarozi tenglamasi, almashtirish."],
 mist:["1 t = 100 s yoki 1 kg = 100 g deb o'ylaydi.","7 kg 40 g ni 740 g deb yozadi.","Idishli masalada idishni ham yarimlaydi.","«Yetmaydi» savoliga qoldiqni javob qiladi."],
 need:["Pallali yoki uy tarozisi, 100 g, 200 g, 500 g toshlar (yoki shakar paketlari).","1 l li shisha, stakanlar, chelak."],
 board:["<span class='w2'>1 kg = 1000 g; 1 s = 100 kg; 1 t = 10 s = 1000 kg</span>.","<span class='w2'>7 kg 40 g = 7040 g</span>; <span class='w2'>1 t 25 s = 35 s</span>.","<span class='w2'>3000 : 450 = 6 (q. 300)</span> → yetmaydi 150.","Banka: <span class='w2'>(1500 − 300) : 2 + 300 = 900</span>."]};
