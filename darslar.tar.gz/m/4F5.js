// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F5',TITLE='4-sinf · To‘g‘ri va noto‘g‘ri kasrlar';
var F5P1=[function(){clear();f4t(180,22,'3/4 — shokoladning bir qismi',13);f4bar(40,40,200,40,4,3,C.a);f4t(290,66,'1 dan kichik',12,C.blue);f4c(['3/4: surat 3 &lt; maxraj 4 — butunning <b>bir qismi</b>'])},
 function(){clear();f4t(180,22,'5/4 — bitta shokoladga sig‘maydi!',13,C.bad);f4bar(40,40,200,40,4,4,C.a);f4bar(40,100,200,40,4,1,C.a);f4t(290,66,'4/4 = 1',13,C.ok);f4t(290,126,'+ 1/4',13,C.a2);f4c(['5/4: surat 5 &gt; maxraj 4 — bitta butun + yana 1/4']) },
 function(){clear();f4t(90,22,'To‘g‘ri kasr',14,C.ok);f4t(270,22,'Noto‘g‘ri kasr',14,C.bad);f4bar(20,40,140,34,4,3,C.a);f4t(90,100,'3/4 &lt; 1',15,C.ok);f4bar(200,40,140,34,4,4,C.a);f4bar(200,80,140,34,4,1,C.a);f4t(270,140,'5/4 &gt; 1',15,C.bad);f4c(['<b>To‘g‘ri</b>: surat &lt; maxraj. <b>Noto‘g‘ri</b>: surat ≥ maxraj'])}];
// kartochkalar
var F5CARDS=[['2/5',0],['7/5',1],['9/9',1],['4/11',0],['11/6',1],['1/2',0]];
function f5cards(found){clear();S.cards=[];F5CARDS.forEach(function(c,i){var x=20+(i%3)*112,y=26+Math.floor(i/3)*70,on=found&&found.indexOf(i)>=0;
 var r=E('rect',{x:x,y:y,width:96,height:56,rx:10,fill:on?'#ffd9d9':'#fff',stroke:on?C.bad:'#c9b99a','stroke-width':on?2.5:1.6},S.g);T(S.g,x+48,y+34,c[0],{'font-size':20,'font-weight':800,fill:on?C.bad:'#1d2b3a'});
 var h=E('rect',{x:x,y:y,width:96,height:56,rx:10,fill:'transparent',style:'cursor:pointer'},S.g);h._i=i;S.cards.push({r:r,h:h,i:i})})}
var F5P3=[function(){clear();[3,5,8].forEach(function(n,j){f4bar(70,26+j*44,220,32,n,0,C.b);T(S.g,40,48+j*44,n+'/'+n,{'font-size':15,'font-weight':800})});f4c(['Surat maxrajga teng bo‘lsa-chi?'])},
 function(){clear();[3,5,8].forEach(function(n,j){f4bar(70,26+j*44,220,32,n,n,C.b);T(S.g,40,48+j*44,n+'/'+n,{'font-size':15,'font-weight':800});f4t(320,48+j*44,'= 1',14,C.ok)});f4c(['3/3 = 5/5 = 8/8 = <b>1</b> — butun shokoladning hammasi','Bunday kasrlar ham <b>noto‘g‘ri</b> kasr hisoblanadi (surat ≥ maxraj)'])}];
function f5nl(st){clear();var X=f4line(100,0,2,3,30,300,function(q,big){return big?String(q/3):''});
 var pts=[[2,'2/3',C.ok],[3,'3/3',C.blue],[5,'5/3',C.bad]];pts.forEach(function(p,i){if(i>=st)return;var x=X(p[0]/3);E('circle',{cx:x,cy:100,r:7,fill:p[2],stroke:'#fff','stroke-width':2},S.g);T(S.g,x,72,p[1],{'font-size':16,'font-weight':800,fill:p[2]})});
 if(st>=3){E('rect',{x:X(0),y:136,width:X(1)-X(0),height:8,rx:4,fill:C.ok,opacity:.5},S.g);E('rect',{x:X(1),y:136,width:X(2)-X(1)+10,height:8,rx:4,fill:C.bad,opacity:.4},S.g);f4t((X(0)+X(1))/2,162,'to‘g‘ri kasrlar',11,C.ok);f4t((X(1)+X(2))/2,162,'noto‘g‘ri kasrlar (1 va undan katta)',11,C.bad)}}
var F5P4=[function(){f5nl(0);f4c(['0 dan 2 gacha — har butunda 3 ta teng bo‘lak (1/3)'])},function(){f5nl(1);f4c(['2/3 — 1 gacha yetmaydi: to‘g‘ri kasr'])},function(){f5nl(2);f4c(['3/3 — aynan 1 da'])},function(){f5nl(3);f4c(['5/3 — 1 dan o‘ngda. <b>To‘g‘ri kasr &lt; 1 ≤ noto‘g‘ri kasr</b>'])}];
var F5P6=[function(){clear();f4t(180,20,'12/4 — 12 ta chorak',13);f4bar(20,34,320,30,12,12,C.a);f4c(['12 ta chorak bo‘lak bor'])},
 function(){clear();f4t(180,20,'Har 4 chorak — 1 butun',13);for(var j=0;j<3;j++){f4bar(20+j*110,40,100,40,4,4,C.a);f4t(70+j*110,104,'1',18,C.ok)}f4c(['12 : 4 = 3 — 3 ta butun shokolad'])},
 function(){clear();for(var j=0;j<3;j++)f4bar(20+j*110,30,100,40,4,4,C.a);f4t(180,110,'12/4 = 12 : 4 = 3',20,C.ok);f4t(180,146,'Kasr chizig‘i — bo‘lish belgisi!',13,C.blue);f4c(['Surat maxrajga qoldiqsiz bo‘linsa — kasr <b>butun songa</b> teng'])}];
function f5slide(a){clear();var n=7,y=44;f4t(180,27,a+'/7',17,a<n?C.ok:C.bad);
 if(a<=n){f4bar(30,y,300,34,n,a,a<n?C.a:C.b)}else{f4bar(30,y,145,34,n,n,C.b);f4bar(185,y,145,34,n,a-n,C.b)}
 f4t(180,112,a<n?'to‘g‘ri kasr (1 dan kichik)':(a===n?'noto‘g‘ri kasr (= 1)':'noto‘g‘ri kasr (1 dan katta)'),14,a<n?C.ok:C.bad);f4c(['surat '+a+(a<n?' &lt; ':(a===n?' = ':' &gt; '))+'maxraj 7'])}
function PRACT_STAGE(){F5P1[2]()}
var STEPS=[
{h:"Kasr butundan katta bo'la oladimi?",sum:"3/4 — butunning bir qismi (1 dan kichik). 5/4 — bitta butun va yana 1/4 (1 dan katta).",a:"m01",
 start:function(){startPh(F5P1)},fin:function(){S.ph=2;F5P1[2]()},
 html:"<p>Shokolad 4 ta teng bo'lakka bo'lingan. 3/4 ni ko'rdik. <b>5/4</b> chi? 4 ta bo'lakdan 5 tasini qanday olamiz? Bosing:</p>",btns:[phaser(F5P1)],
 after:"<p>5/4 uchun bitta shokolad yetmaydi — ikkinchisini ochamiz. Surati maxrajidan <b>kichik</b> kasr — <b>to'g'ri kasr</b> (1 dan kichik). Surati maxrajidan <b>katta yoki teng</b> kasr — <b>noto'g'ri kasr</b> (1 ga teng yoki undan katta).</p>",
 q:{t:"Qaysi kasr 1 dan kichik?",opts:["7/6","6/7","7/7","8/7"],ok:1,why:"Surat 6 &lt; maxraj 7.",hint:"Qaysi kasrda bo'laklar butunni to'ldirmaydi?",full:"6/7 — 7 ta bo'lakdan 6 tasi, butun to'lmaydi: 1 dan kichik. 7/7 = 1, 7/6 va 8/7 esa 1 dan katta."},
 tn:"«Noto'g'ri» so'zi bolani chalg'itadi — bu kasr xato degani emas! «Og'ir kasr» — butundan og'irroq deb tushuntiring. Ingliz tilida ham «improper» deyiladi."},
{h:"Noto'g'ri kasrlarni toping",sum:"Surat ≥ maxraj — noto'g'ri: 7/5, 9/9, 11/6. Surat &lt; maxraj — to'g'ri: 2/5, 4/11, 1/2.",a:"m02",
 start:function(){f5cards([]);f4c(['Noto‘g‘ri kasrlarni bosing (3 ta)'])},fin:function(){f5cards([1,2,4]);f4c(['Noto‘g‘ri: <b>7/5, 9/9, 11/6</b> (surat ≥ maxraj)'])},
 html:"<p>Kartochkalardan <b>noto'g'ri kasrlarni</b> bosing. Har biriga qarang: surat maxrajdan kichikmi?</p>",
 act:function(c,done){var f=[],h=c.querySelector('.hint');S.cards.forEach(function(o){o.h.addEventListener('click',function(){if(f.indexOf(o.i)>=0)return;if(F5CARDS[o.i][1]){f.push(o.i);o.r.setAttribute('fill','#ffd9d9');o.r.setAttribute('stroke',C.bad);f4c(['✓ '+F5CARDS[o.i][0]+': surat ≥ maxraj. Topildi: '+f.length+' / 3']);if(f.length===3){h.textContent='';done()}}else{o.r.setAttribute('fill','#e6f4ea');setTimeout(function(){o.r.setAttribute('fill','#fff')},900);f4c(['✗ '+F5CARDS[o.i][0]+' — surat maxrajdan kichik: bu to‘g‘ri kasr'])}})})},
 after:"<p>9/9 ni unutmang: surat maxrajga <b>teng</b> — bu ham noto'g'ri kasr. Qoidaning o'zi: <b>surat ≥ maxraj</b>.</p>",
 q:{t:"Nechta to'g'ri kasr bor: 3/8, 8/3, 5/5, 1/9, 10/11?",opts:["2","3","4","5"],ok:1,why:"3/8, 1/9, 10/11 — to'g'ri.",hint:"Har birida surat maxrajdan kichikmi? 5/5 ga e'tibor bering.",full:"To'g'ri kasrlar: 3/8, 1/9, 10/11 — 3 ta. 8/3 (surat katta) va 5/5 (teng) — noto'g'ri."},
 tn:"Kartochkalar bilan o'yin: sinfni ikki guruhga bo'ling — «to'g'ri» va «noto'g'ri» qutilar. 9/9, 12/12 kabi chegaradagilarni albatta qo'shing."},
{h:"Surat = maxraj bo'lsa",sum:"3/3 = 5/5 = 8/8 = 1. Bunday kasr ham noto'g'ri kasr.",a:"m03",
 start:function(){startPh(F5P3)},fin:function(){S.ph=1;F5P3[1]()},
 html:"<p>3/3, 5/5, 8/8 — bu kasrlar nimaga teng? Bo'yab ko'ring:</p>",btns:[phaser(F5P3,'🎨 Bo\'yash')],
 after:"<p>Shokoladning hamma bo'laklari olinsa — bu <b>butun shokolad</b>. Shuning uchun <b>surati maxrajiga teng kasr 1 ga teng</b>. U 1 dan kichik emas — shuning uchun to'g'ri kasrlar qatoriga kirmaydi.</p>",
 q:{t:"Qaysi kasr 1 ga teng?",opts:["1/12","12/1","12/12","11/12"],ok:2,why:"12 ta bo'lakdan 12 tasi — butun.",hint:"Hamma bo'laklar olingan kasrni toping.",full:"12/12 — butun 12 bo'lakka bo'linib, hammasi olindi: 1. «12/1» — bu 12 ta butun, «1/12» va «11/12» — 1 dan kichik."},
 tn:"Kasrning qiymatini doim 1 bilan solishtirtiring: «&lt; 1», «= 1», «&gt; 1». Bu taqqoslash va aralash sonlar uchun poydevor."},
{h:"Son o'qida: 1 — chegara",sum:"To'g'ri kasrlar 0 va 1 orasida, noto'g'ri kasrlar 1 da va undan o'ngda: 2/3 &lt; 3/3 = 1 &lt; 5/3.",a:"m04",
 start:function(){startPh(F5P4)},fin:function(){S.ph=3;F5P4[3]()},
 html:"<p>Kasrlarni son o'qiga joylaymiz. 1 nuqtasi — chegara. Bosing:</p>",btns:[phaser(F5P4,'📍 Joylash')],
 after:"<p>Son o'qi hammasini ko'rsatadi: <b>har qanday to'g'ri kasr har qanday noto'g'ri kasrdan kichik</b>, chunki to'g'ri kasr 1 gacha yetmaydi, noto'g'ri kasr esa 1 dan boshlanadi.</p>",
 q:{t:"13/10 son o'qida qayerda joylashgan?",opts:["0 va 1 orasida","1 va 2 orasida","2 dan keyin","Aynan 1 da"],ok:1,why:"10/10 = 1, 20/10 = 2; 13/10 ular orasida.",hint:"10/10 qayerda? 20/10 chi?",full:"10/10 = 1, 20/10 = 2. 13 soni 10 va 20 orasida — demak 13/10 son o'qida 1 va 2 orasida (1 dan 3/10 o'ngda)."},
 tn:"IES (AQSh) tavsiyasi: kasrlarni son o'qiga joylash — kasrni «son» deb tushunishning eng kuchli usuli. Doskada 0–3 o'qini chizib, bolalar kartochkalarni ilsin."},
{h:"Tuzoq: katta raqamlar aldaydi",sum:"99/100 &lt; 101/100: biri 1 dan kichik, biri 1 dan katta.",a:"m05",
 start:function(){clear();f4t(100,70,'99/100',26,C.ok);f4t(180,74,'?',26);f4t(260,70,'101/100',26,C.bad);f4msg('Qaysi biri katta? Raqamlar deyarli bir xil…')},
 fin:function(){clear();var X=f4line(110,0,2,1,40,280);E('circle',{cx:X(.99),cy:110,r:7,fill:C.ok},S.g);E('circle',{cx:X(1.01),cy:110,r:7,fill:C.bad},S.g);f4t(X(.99)-30,80,'99/100',14,C.ok);f4t(X(1.01)+34,80,'101/100',14,C.bad);f4t(180,30,'99/100 &lt; 1 &lt; 101/100',16);f4msg('To‘g‘ri kasr &lt; 1 &lt; noto‘g‘ri kasr')},
 html:"<p>Qaysi biri katta: <b>99/100</b> yoki <b>101/100</b>? Hisoblamasdan javob bering:</p>",
 btns:f4pick(1,[["99/100","99/100 — to'g'ri kasr, u 1 gacha yetmaydi."],["101/100","To'g'ri! 101/100 — noto'g'ri kasr, u 1 dan katta. 99/100 esa 1 dan kichik."],["Teng","Surat va maxrajni 1 bilan solishtiring: 99 &lt; 100, 101 &gt; 100."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Tez usul: ikkala kasrni <b>1 bilan</b> solishtiring. 1 dan kichigi (to'g'ri) — 1 dan kattasidan (noto'g'ri) doim kichik. Bu usul maxrajlar har xil bo'lsa ham ishlaydi: 99/100 &lt; 3/2.</p>",
 q:{t:"Qaysi biri katta: 8/9 yoki 9/8?",opts:["8/9","9/8","Teng","8/9, chunki 9 katta"],ok:1,why:"9/8 &gt; 1 &gt; 8/9.",hint:"Qaysi biri 1 dan katta?",full:"8/9 — to'g'ri kasr, 1 dan kichik. 9/8 — noto'g'ri kasr, 1 dan katta. Demak 9/8 &gt; 8/9, garchi raqamlar bir xil bo'lsa ham."},
 tn:"Testlarda «8/9 va 9/8» kabi juftliklar ko'p keladi. 1 bilan solishtirish — eng tez yo'l."},
{h:"Noto'g'ri kasr — butun son",sum:"12/4 = 12 : 4 = 3. Surat maxrajga qoldiqsiz bo'linsa, kasr butun songa teng. Kasr chizig'i — bo'lish belgisi.",a:"m06",
 start:function(){startPh(F5P6)},fin:function(){S.ph=2;F5P6[2]()},
 html:"<p>12/4 — 12 ta chorak. Ulardan nechta butun shokolad yig'iladi? Bosing:</p>",btns:[phaser(F5P6)],
 after:"<p>Har 4 ta chorak — 1 butun. 12 ta chorakda 12 : 4 = <b>3</b> butun. Demak <b>kasr chizig'i — bo'lish belgisi</b>: 12/4 = 12 : 4. Shuning uchun 20/5 = 4, 18/6 = 3, 7/1 = 7.</p>",
 q:{t:"20/5 nechaga teng?",opts:["4","15","25","100"],ok:0,why:"20 : 5 = 4.",hint:"Kasr chizig'i — bo'lish belgisi.",full:"20/5 = 20 : 5 = 4. «15» — ayirish (20 − 5), «25» — qo'shish, «100» — ko'paytirish."},
 tn:"Doskaga «a/b = a : b» deb yozing. Bu bog'lanish 5-sinfda o'nli kasr va bo'lishda juda kerak bo'ladi."},
{h:"Suratni o'zgartirib ko'ring",sum:"a/7 to'g'ri kasr: a = 1, 2, 3, 4, 5, 6 (6 ta). a = 7 dan boshlab noto'g'ri.",a:"m07",
 start:function(){S.a5=3;f5slide(3)},fin:function(){f5slide(8)},
 html:"<p>Maxraj 7. Suratni oshirib-kamaytiring va kasr qachon to'g'ri, qachon noto'g'ri bo'lishini kuzating:</p>",
 btns:[["− surat",function(c,done){if(S.a5>1){S.a5--;f5slide(S.a5);mvK(done,4)}}],["+ surat",function(c,done){if(S.a5<12){S.a5++;f5slide(S.a5);mvK(done,4)}}]],g2:1,
 after:"<p>Surat 1 dan 6 gacha — kasr to'g'ri: <b>1/7, 2/7, … 6/7</b> — jami <b>6 ta</b>. Surat 7 bo'lganda kasr 1 ga teng (noto'g'ri), undan katta bo'lsa — 1 dan katta.</p><p>Umumiy qoida: maxraji n bo'lgan to'g'ri kasrlar (surat natural son) — <b>n − 1 ta</b>.</p>",
 q:{t:"a/9 to'g'ri kasr bo'lsa, a eng ko'pi bilan nechaga teng bo'lishi mumkin?",opts:["9","8","10","1"],ok:1,why:"a &lt; 9, eng kattasi 8.",hint:"To'g'ri kasrda surat maxrajdan qanday bo'ladi?",full:"To'g'ri kasrda surat maxrajdan kichik: a &lt; 9, eng katta natural son 8. a = 9 da kasr 1 ga teng — noto'g'ri kasr."},
 tn:"Olimpiada savollari: «Maxraji 12 bo'lgan nechta to'g'ri kasr bor?» (11 ta). Bolalar formulani o'zi topsin."},
{h:"Tuzoq: chegaralar bilan",sum:"x/5 noto'g'ri va 2 dan kichik: 5/5, 6/5, 7/5, 8/5, 9/5 — 5 ta (10/5 = 2 kirmaydi).",a:"m08",
 start:function(){clear();var X=f4line(100,0,2,5,30,300,function(q,big){return big?String(q/5):''});E('rect',{x:X(1),y:94,width:X(2)-X(1),height:12,fill:C.bad,opacity:.25},S.g);f4t(180,30,'x/5 — noto‘g‘ri kasr va 2 dan kichik',14);f4msg('x nechta qiymat qabul qiladi? (x — natural son)')},
 fin:function(){clear();var X=f4line(100,0,2,5,30,300,function(q,big){return big?String(q/5):''});[5,6,7,8,9].forEach(function(q){E('circle',{cx:X(q/5),cy:100,r:6,fill:C.bad},S.g);T(S.g,X(q/5),76,q+'/5',{'font-size':12,'font-weight':800,fill:C.bad})});E('circle',{cx:X(2),cy:100,r:6,fill:'#fff',stroke:C.bad,'stroke-width':2},S.g);f4t(X(2),146,'10/5 = 2 — kirmaydi',11,'#5b6b7b');f4msg('5/5, 6/5, 7/5, 8/5, 9/5 — <b>5 ta</b>')},
 html:"<p>x/5 — noto'g'ri kasr, lekin u <b>2 dan kichik</b>. x nechta qiymat qabul qiladi? O'ylab tanlang:</p>",
 btns:f4pick(1,[["4 ta","Chegarani tekshiring: 5/5 — noto'g'ri kasrmi?"],["5 ta","To'g'ri! x = 5, 6, 7, 8, 9. 5/5 — noto'g'ri kasr (teng!), 10/5 = 2 — «2 dan kichik» emas."],["6 ta","10/5 = 2. «2 dan kichik» shartiga kiradimi?"]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Bunday masalada <b>ikkala chegarani</b> alohida tekshiring: pastki chegara — x = 5 (surat = maxraj, kasr noto'g'ri, kiradi); yuqori chegara — 10/5 = 2 (shart «kichik», kirmaydi).</p>",
 q:{t:"x/4 noto'g'ri kasr va x &lt; 7. x nechta natural qiymat qabul qiladi?",opts:["3","2","4","6"],ok:0,why:"x = 4, 5, 6.",hint:"Noto'g'ri kasr: x ≥ 4. Yana x &lt; 7.",full:"x ≥ 4 (noto'g'ri) va x &lt; 7: x = 4, 5, 6 — 3 ta. «2» — 4/4 ni unutish, «4» — 7 ni ham qo'shish."},
 tn:"Chegaralarni son o'qida bo'yab ko'rsatish odatini shakllantiring: to'ldirilgan nuqta — kiradi, bo'sh nuqta — kirmaydi."},
{h:"Bilasizmi? Kasr chizig'i Yevropaga qanday kelgan",sum:"Kasr chizig'ini arab olimlari ishlatgan; Yevropaga uni Fibonachchi 1202-yildagi «Liber Abaci» kitobi orqali keng tanitgan.",a:"m09",
 start:function(){clear('#f6ead0');f4t(180,40,'Leonardo Fibonachchi',16,'#7a4a12');f4t(180,66,'«Liber Abaci» — «Hisob kitobi», 1202-yil',12,'#7a4a12');f4msg('Kasrni chiziq bilan yozish qayerdan kelgan?')},
 fin:function(){clear('#f6ead0');f4t(180,34,'Arab olimlari → Fibonachchi (1202) → Yevropa',13,'#7a4a12');f4t(110,100,'5/4',30,'#7a4a12');f4t(250,100,'7/3',30,'#7a4a12');f4msg('Fibonachchi kasrlarni chiziq bilan yozgan va hind-arab raqamlarini Yevropaga tanitgan')},
 html:"<p>📚 Italiyalik savdogar o'g'li <b>Leonardo Fibonachchi</b> yoshligida Shimoliy Afrikada arab ustozlardan hisob o'rgangan. Tugmani bosing:</p>",
 btns:[["📖 Kitobni ochish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>1202-yilda Fibonachchi <b>«Liber Abaci»</b> kitobini yozdi. Unda Yevropaga <b>hind-arab raqamlari</b> (0, 1, 2 … 9) va kasrni <b>gorizontal chiziq</b> bilan yozish usuli keng tanitildi. Bu usulni u arab matematiklaridan o'rgangan — ular esa hind olimlari va al-Xorazmiy kabi allomalar asarlariga tayangan.</p>",
 tn:"Xaritada yo'lni ko'rsating: Hindiston → Bag'dod (al-Xorazmiy) → Shimoliy Afrika → Italiya. Matematika — xalqlar birga yaratgan meros."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>To'g'ri kasr</b>: surat &lt; maxraj, qiymati 1 dan kichik (3/4).</li><li><b>Noto'g'ri kasr</b>: surat ≥ maxraj, qiymati 1 ga teng yoki katta (5/4, 9/9).</li><li>n/n = 1: 3/3 = 8/8 = 1.</li><li>Har qanday to'g'ri kasr &lt; 1 ≤ har qanday noto'g'ri kasr: 99/100 &lt; 101/100.</li><li>Kasr chizig'i — bo'lish: 12/4 = 12 : 4 = 3.</li><li>Maxraji n bo'lgan to'g'ri kasrlar: n − 1 ta.</li><li>Chegaralarni tekshiring: «teng» kiradimi, kirmaydimi?</li></ul></div>",
 tn:"Keyingi dars — aralash kasrlar: «5/4 ni boshqacha qanday yozish mumkin?» savoli bilan boshlang."}
];
var PROBS=[
{t:"Qaysi kasr to'g'ri?",o:["5/9","9/5","9/9","10/9"],k:0,s:"Surat 5 < maxraj 9."},
{t:"Qaysi kasr noto'g'ri?",o:["8/8","1/8","7/8","3/8"],k:0,s:"8/8: surat maxrajga teng — noto'g'ri kasr (= 1)."},
{t:"Qaysi kasr 1 dan katta?",o:["13/12","12/13","1/12","12/12"],k:0,s:"Surat 13 > maxraj 12."},
{t:"24/6 nechaga teng?",o:["4","18","30","144"],k:0,s:"24 : 6 = 4."},
{t:"Nechta noto'g'ri kasr bor: 2/3, 5/4, 6/6, 7/9, 9/2?",o:["3","2","4","1"],k:0,s:"5/4, 6/6, 9/2."},
{t:"a/6 to'g'ri kasr. a qanday natural qiymatlar qabul qiladi?",o:["1, 2, 3, 4, 5","1, 2, 3, 4, 5, 6","6, 7, 8, 9","2, 3, 4, 5"],k:0,s:"a < 6: 1, 2, 3, 4, 5."},
{t:"Qaysi kasr butun songa teng?",o:["21/7","21/8","7/21","20/7"],k:0,s:"21 : 7 = 3."},
{t:"Kasrlarni o'sish tartibida joylang: 5/4, 3/4, 4/4.",o:["3/4, 4/4, 5/4","5/4, 4/4, 3/4","4/4, 3/4, 5/4","3/4, 5/4, 4/4"],k:0,s:"3/4 < 1 = 4/4 < 5/4."},
{t:"Qaysi kasr eng katta?",o:["11/10","9/10","10/10","1/10"],k:0,s:"11/10 > 1, qolganlari ≤ 1."},
{t:"Maxraji 7 bo'lgan nechta to'g'ri kasr bor (surat — natural son)?",o:["6","7","8","5"],k:0,s:"1/7, 2/7, …, 6/7."},
{t:"x/5 noto'g'ri kasr va x < 9. x nechta natural qiymat qabul qiladi?",o:["4","3","5","9"],k:0,s:"x = 5, 6, 7, 8."},
{t:"8/x to'g'ri kasr, x — bir xonali son. x nechaga teng?",o:["9","7","8","10"],k:0,s:"x > 8 va bir xonali: x = 9."},
{t:"Qaysi juftlikda ikkala kasr ham noto'g'ri?",o:["7/7 va 9/4","7/8 va 9/4","1/3 va 3/1","6/5 va 5/6"],k:0,s:"7/7 (=1) va 9/4 (>1)."},
{t:"a/8 ham, 8/a ham noto'g'ri kasr. a nechaga teng?",o:["8","7","9","16"],k:0,s:"a ≥ 8 va 8 ≥ a → a = 8."},
{t:"Maxraji 4 bo'lgan nechta noto'g'ri kasr 3 dan katta emas (surat — natural son)?",o:["9","8","12","3"],k:0,s:"4/4, 5/4, …, 12/4 — 9 ta."},
{t:"Qaysi tengsizlik to'g'ri?",o:["6/7 < 7/6","7/6 < 6/7","6/6 > 7/6","5/6 > 6/5"],k:0,s:"6/7 < 1 < 7/6."},
{t:"Maxraji 4, surati maxrajidan 3 ta katta kasr 1 dan qanchaga katta?",o:["3/4","3","7/4","1/4"],k:0,s:"7/4 = 4/4 + 3/4."},
{t:"35/5 kasr qaysi songa teng?",o:["7","30","40","175"],k:0,s:"35 : 5 = 7."},
{t:"Surati va maxrajining yig'indisi 10 ga teng nechta noto'g'ri kasr bor (surat va maxraj — natural sonlar)?",o:["5","4","9","6"],k:0,s:"9/1, 8/2, 7/3, 6/4, 5/5."},
{t:"Qaysi kasr 2 dan katta, lekin 3 dan kichik?",o:["11/5","9/5","15/5","16/5"],k:0,s:"10/5 = 2, 15/5 = 3; 11/5 ular orasida."}
];
var PREP_DATA={teach:["To'g'ri kasr (surat < maxraj) va noto'g'ri kasr (surat ≥ maxraj).","n/n = 1 — noto'g'ri kasr.","Son o'qida: to'g'ri kasrlar 0–1 orasida, noto'g'rilar 1 dan o'ngda.","1 bilan solishtirish; kasr chizig'i — bo'lish.","Chegaraviy masalalar (x/5 noto'g'ri va 2 dan kichik)."],
 mist:["«Noto'g'ri kasr» — xato yozilgan kasr deb o'ylaydi.","Surat = maxraj bo'lgan kasrni to'g'ri kasr deb hisoblaydi.","99/100 va 101/100 ni teng deb biladi.","Chegaradagi qiymatlarni (5/5, 10/5) noto'g'ri hisobga oladi."],
 need:["Kasr kartochkalari, qog'oz tasmalar.","Doskada 0–3 son o'qi."],
 board:["<span class='w2'>3/4 &lt; 1</span> — to'g'ri; <span class='w2'>5/4 &gt; 1</span>, <span class='w2'>9/9 = 1</span> — noto'g'ri.","<span class='w2'>to'g'ri &lt; 1 ≤ noto'g'ri</span>.","<span class='w2'>12/4 = 12 : 4 = 3</span>.","a/7 to'g'ri: a = 1…6 (6 ta)."]};
