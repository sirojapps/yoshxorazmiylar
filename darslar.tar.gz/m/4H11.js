var CODE='4H11',TITLE='4-sinf · Burchakning gradus o‘lchovi va transportir';
function qbmsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var QBX=180,QBY=148;
function qbpt(a,r){var t=a*Math.PI/180;return [QBX+r*Math.cos(t),QBY-r*Math.sin(t)]}
// transportir: o {pr:1, rays:[[gradus,col,lab]], arc:[a1,a2,col,lab], tap}
function qbdraw(o){o=o||{};clear();var g=S.g,R=118,i;
 if(o.pr){E('path',{d:'M'+(QBX-R)+' '+QBY+' A'+R+' '+R+' 0 0 1 '+(QBX+R)+' '+QBY+' Z',fill:'rgba(31,111,178,.07)',stroke:'#8fb3d6','stroke-width':1.5},g);
  for(i=0;i<=180;i+=5){var p1=qbpt(i,R),p2=qbpt(i,R-(i%10?5:9));E('line',{x1:p1[0],y1:p1[1],x2:p2[0],y2:p2[1],stroke:'#5a7fa6','stroke-width':i%10?0.8:1.3},g)}
  for(i=0;i<=180;i+=30){var ia=i===0?7:(i===180?173:i),q=qbpt(ia,R-18);T(g,q[0],q[1]+4,''+i,{'font-size':9,'font-weight':700,fill:C.blue});var q2=qbpt(i===0?11:(i===180?169:i),R-34);T(g,q2[0],q2[1]+4,''+(180-i),{'font-size':9,'font-weight':700,fill:C.bad})}
  E('circle',{cx:QBX,cy:QBY,r:3,fill:'#33475b'},g)}
 E('line',{x1:QBX-R-12,y1:QBY,x2:QBX+R+12,y2:QBY,stroke:o.pr?'#8fb3d6':'none','stroke-width':1},g);
 if(o.arc){var a=o.arc,r0=26,p=qbpt(a[0],r0),q=qbpt(a[1],r0);E('path',{d:'M'+p[0]+' '+p[1]+' A'+r0+' '+r0+' 0 0 0 '+q[0]+' '+q[1],fill:'none',stroke:a[2]||C.bad,'stroke-width':2.5},g);if(a[3]){var m=qbpt((a[0]+a[1])/2,r0+16);T(g,m[0],m[1]+4,a[3],{'font-size':12,'font-weight':800,fill:a[2]||C.bad})}}
 (o.rays||[]).forEach(function(r){var p=qbpt(r[0],132);E('line',{x1:QBX,y1:QBY,x2:p[0],y2:p[1],stroke:r[1]||C.a2,'stroke-width':3,'stroke-linecap':'round'},g);if(r[2]){var l=qbpt(r[0],144);T(g,l[0],Math.min(l[1]+4,166),r[2],{'font-size':12,'font-weight':800,fill:r[1]||C.a2})}});
 if(o.tap){var rr=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);rr.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var a=Math.atan2(QBY-p.y,p.x-QBX)*180/Math.PI;if(a<-20)return;a=Math.max(0,Math.min(180,Math.round(a/10)*10));o.tap(a)})}}
function qbkind(k){var A=[[40,'o‘tkir: 40°'],[90,'to‘g‘ri: 90°'],[130,'o‘tmas: 130°'],[180,'yoyiq: 180°']][k];qbdraw({rays:[[0,C.blue],[A[0],C.a2]],arc:[0,A[0],C.bad,A[1]]});if(k===1){E('path',{d:'M'+(QBX+14)+' '+QBY+' v-14 h-14',fill:'none',stroke:C.bad,'stroke-width':2},S.g)}}
var QBP2=[function(){qbdraw({rays:[[0,C.blue],[180,C.blue]],arc:[0,180,C.bad,'180°']});qbmsg('Yoyiq burchak — <b>180°</b>')},
 function(){qbdraw({rays:[[0,C.blue],[180,C.blue],[90,C.a2]],arc:[0,90,C.bad,'90°']});qbmsg('Uni teng ikkiga bo‘lsak — to‘g‘ri burchak: 180 : 2 = <b>90°</b>')},
 function(){qbdraw({rays:[[0,C.blue],[1,C.a2]]});T(S.g,180,60,'1° — yoyiq burchakning 180 dan biri',{'font-size':12,'font-weight':800,fill:C.bad});qbmsg('<b>1 gradus</b> (1°) — juda kichik burchak. To‘liq aylanish — 360°')}];
var QBP3=[function(){qbdraw({pr:1});qbmsg('Transportir — burchak o‘lchaydigan asbob')},
 function(){qbdraw({pr:1});E('circle',{cx:QBX,cy:QBY,r:7,fill:'none',stroke:C.bad,'stroke-width':2.5},S.g);T(S.g,QBX,QBY-14,'markaz',{'font-size':11,'font-weight':800,fill:C.bad});qbmsg('1) <b>Markazi</b> burchak uchiga qo‘yiladi')},
 function(){qbdraw({pr:1});T(S.g,QBX+110,QBY+18,'ko‘k: o‘ngdan',{'font-size':11,'font-weight':800,fill:C.blue});T(S.g,QBX-110,QBY+18,'qizil: chapdan',{'font-size':11,'font-weight':800,fill:C.bad});qbmsg('2) <b>Ikkita shkala</b>: biri o‘ngdagi 0 dan, biri chapdagi 0 dan boshlanadi')}];
var QBP7=[function(){qbdraw({rays:[[0,C.blue,'A'],[35,C.a2,'B'],[90,C.ok,'C']]});qbmsg('∠AOB = 35°, ∠BOC = 55°')},
 function(){qbdraw({rays:[[0,C.blue,'A'],[35,C.a2,'B'],[90,C.ok,'C']],arc:[0,35,C.a2,'35°']});qbmsg('∠AOB = 35°')},
 function(){qbdraw({rays:[[0,C.blue,'A'],[35,C.a2,'B'],[90,C.ok,'C']],arc:[0,90,C.ok,'90°']});qbmsg('∠AOC = 35° + 55° = <b>90°</b>')}];
function qbclock(h){clear();var g=S.g,cx=180,cy=86,R=70,i;E('circle',{cx:cx,cy:cy,r:R,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 for(i=1;i<=12;i++){var t=(90-30*i)*Math.PI/180;T(g,cx+(R-14)*Math.cos(t),cy-(R-14)*Math.sin(t)+4,''+i,{'font-size':11,'font-weight':800,fill:'#33475b'})}
 var th=(90-30*h)*Math.PI/180;E('line',{x1:cx,y1:cy,x2:cx,y2:cy-R+16,stroke:C.blue,'stroke-width':3,'stroke-linecap':'round'},g);E('line',{x1:cx,y1:cy,x2:cx+40*Math.cos(th),y2:cy-40*Math.sin(th),stroke:C.bad,'stroke-width':5,'stroke-linecap':'round'},g);
 if(h>0){var r0=24;E('path',{d:'M'+cx+' '+(cy-r0)+' A'+r0+' '+r0+' 0 '+(h>6?1:0)+' 1 '+(cx+r0*Math.cos(th))+' '+(cy-r0*Math.sin(th)),fill:'none',stroke:C.a2,'stroke-width':3},g);T(g,cx+120,cy+4,h+' soat → '+(30*h)+'°',{'font-size':13,'font-weight':800,fill:C.a2})}E('circle',{cx:cx,cy:cy,r:4,fill:'#33475b'},g)}
var STEPS=[
{h:"Burchak turlari",sum:"O'tkir < 90° < o'tmas < 180°. To'g'ri burchak — 90°, yoyiq burchak — 180°.",a:"m01",
 start:function(){qbdraw({rays:[[0,C.blue]]});qbmsg('Tugmalarni bosib, burchak turlarini ko‘ring')},fin:function(){qbkind(2);qbmsg('O‘tkir < 90° = to‘g‘ri < o‘tmas < 180° = yoyiq')},
 btns:[["O'tkir",function(c,done){qbkind(0);qbmsg('<b>O‘tkir</b> — to‘g‘ri burchakdan kichik: 0° dan 90° gacha');mvK(done,4)}],["To'g'ri",function(c,done){qbkind(1);qbmsg('<b>To‘g‘ri</b> — aynan 90°. Daftar burchagi');mvK(done,4)}],["O'tmas",function(c,done){qbkind(2);qbmsg('<b>O‘tmas</b> — 90° dan katta, 180° dan kichik');mvK(done,4)}],["Yoyiq",function(c,done){qbkind(3);qbmsg('<b>Yoyiq</b> — tomonlari bitta to‘g‘ri chiziq: 180°');mvK(done,4)}]],g2:1,
 html:"<p>3-sinfdan eslaymiz: burchaklar turlari. To'rttala tugmani bosing.</p>",
 after:"<p><b>O'tkir</b> — 90° dan kichik, <b>to'g'ri</b> — 90°, <b>o'tmas</b> — 90° dan katta va 180° dan kichik, <b>yoyiq</b> — 180°. Burchak kattaligi tomonlarining <b>uzunligiga bog'liq emas</b>, faqat ular qanchalik «ochilgani»ga bog'liq.</p>",
 q:{t:"Ikki burchak bor: birining tomonlari 2 sm, ikkinchisiniki 10 sm. Ochilishi bir xil. Qaysi burchak katta?",opts:["Teng","Tomonlari 10 sm bo'lgani","Tomonlari 2 sm bo'lgani","Aytish uchun gradus kerak emas — uzunini o'lchash kerak"],ok:0,why:"Burchak kattaligi tomonlar uzunligiga bog'liq emas.",hint:"Burchakni nima katta qiladi: tomonlar uzunligimi yoki ochilishimi?",full:"Burchakning kattaligi tomonlarining qanchalik ochilganiga bog'liq. Ochilish bir xil bo'lsa — burchaklar teng, tomonlar qanchalik uzun bo'lsa ham."},
 tn:"Ikki xil uzunlikdagi qaychini bir xil ochib ko'rsating: «Qaysi burchak katta?» — ko'p bolalar uzunini aytadi. Bu — eng muhim tuzoq."},
{h:"Gradus nima?",sum:"Yoyiq burchak 180 ta teng qismga bo'linsa, bitta qismi — 1 gradus (1°). To'g'ri burchak 90°, to'liq aylanish 360°.",a:"m02",
 start:function(){startPh(QBP2)},fin:function(){S.ph=2;QBP2[2]()},
 html:"<p>Burchakni o'lchash uchun ham o'lchov birligi kerak — <b>gradus</b>.</p>",
 btns:[phaser(QBP2)],
 after:"<p>Yoyiq burchakni 180 ta teng qismga bo'lsak, bitta qism — <b>1 gradus</b> (1°). Shunda: to'g'ri burchak = <b>90°</b>, yoyiq = <b>180°</b>, to'liq aylanish = <b>360°</b>. «Gradus» lotincha «qadam» degani.</p>",
 q:{t:"To'liq aylanishning choragi necha gradus?",opts:["90°","45°","180°","36°"],ok:0,why:"360 : 4 = 90.",hint:"To'liq aylanish necha gradus?",full:"To'liq aylanish 360°, choragi 360 : 4 = 90° — to'g'ri burchak. 180° — yarim aylanish, 36° — 10 ga bo'lish xatosi."},
 tn:"Bolalarni o'rnidan turg'izib aylantiring: «chorak burilish» — 90°, «yarim burilish» — 180°, «to'liq» — 360°. Sport va raqsda shu so'zlar ishlatiladi."},
{h:"Transportir",sum:"Transportir markazi burchak uchiga, 0 chizig'i bir tomonga qo'yiladi; o'sha 0 dan boshlangan shkala o'qiladi.",a:"m03",
 start:function(){startPh(QBP3)},fin:function(){S.ph=2;QBP3[2]()},
 html:"<p>Transportirni yaqindan ko'raylik: uning qismlari va ikki shkalasi.</p>",
 btns:[phaser(QBP3)],
 after:"<p>Burchakni o'lchash qoidasi: 1) transportir <b>markazi</b> — burchak uchida; 2) asosiy chiziq burchakning bir tomoni ustida; 3) shu tomon <b>0</b> ni ko'rsatgan shkala bo'yicha ikkinchi tomonni o'qiymiz. Ikki shkala bor, chunki burchak o'ngga ham, chapga ham ochilishi mumkin.</p>",
 q:{t:"Transportirning qaysi nuqtasi burchak uchiga qo'yiladi?",opts:["Markazi","Chap cheti","0 belgisi","180 belgisi"],ok:0,why:"Markaz — burchak uchida.",hint:"Hamma chiziqlar qaysi nuqtadan chiqadi?",full:"Transportir markazi (to'g'ri chiziq o'rtasidagi kichik belgi) burchak uchiga qo'yiladi. Chekka yoki 0 belgisini qo'ysak, o'lchov noto'g'ri chiqadi."},
 tn:"Har bir bolaning transportiri bo'lsin. Markazini barmoq bilan ko'rsatish mashqidan boshlang — ko'p bolalar uni chetidan qo'yadi."},
{h:"Tuzoq: qaysi shkala?",sum:"Burchak tomoni qaysi 0 dan o'tsa, o'sha 0 dan boshlangan shkala o'qiladi.",a:"m04",
 start:function(){qbdraw({pr:1,rays:[[0,C.blue],[50,C.a2]]});qbmsg('Burchak necha gradus?')},fin:function(){qbdraw({pr:1,rays:[[0,C.blue],[50,C.a2]],arc:[0,50,C.ok,'50°']});qbmsg('✓ Tomon o‘ngdagi 0 da — ko‘k shkala: <b>50°</b>')},
 btns:[["50°",function(c,done){STEPS[3].fin();done()}],["130°",function(c,done){qbmsg('130° — qizil shkala (chapdan). Lekin burchak tomoni <b>o‘ngdagi</b> 0 da. Burchak o‘tkirmi yoki o‘tmas?')}]],g2:1,
 html:"<p>Ikkinchi tomon ikki son orasida turibdi: <b>50</b> va <b>130</b>. Qaysi biri to'g'ri?</p>",
 after:"<p>Burchakning bir tomoni <b>o'ngdagi 0</b> dan o'tadi, demak o'ngdan boshlangan (ko'k) shkalani o'qiymiz: <b>50°</b>. Tekshirish: burchak <b>o'tkir</b> ko'rinadi, demak u 90° dan kichik — 130° bo'lishi mumkin emas. Har doim «ko'z bilan chamalab» tekshiring!</p>",
 q:{t:"O'tmas burchakni o'lchaganda shkalada 70 va 110 ko'rindi. Burchak necha gradus?",opts:["110°","70°","180°","40°"],ok:0,why:"O'tmas burchak 90° dan katta.",hint:"O'tmas burchak 90° dan katta yoki kichik?",full:"O'tmas burchak 90° dan katta, demak 110°. 70° — noto'g'ri shkalani o'qish, 180° — ikki sonni qo'shish."},
 tn:"Bolalarga «avval chamala, keyin o'lcha» qoidasini o'rgating: o'tkir ko'rinsa — kichik son, o'tmas ko'rinsa — katta son."},
{h:"Chap tomondan ochilgan burchak",sum:"Tomon chapdagi 0 da bo'lsa, ichki (qizil) shkala o'qiladi.",a:"m05",
 start:function(){qbdraw({pr:1,rays:[[180,C.blue],[60,C.a2]]});qbmsg('Bu burchak necha gradus?')},fin:function(){qbdraw({pr:1,rays:[[180,C.blue],[60,C.a2]],arc:[60,180,C.ok,'120°']});qbmsg('✓ Tomon chapdagi 0 da — qizil shkala: <b>120°</b>')},
 btns:[["60°",function(c,done){qbmsg('60° — ko‘k shkala. Lekin bir tomon <b>chapdagi</b> 0 da, burchak esa o‘tmas')}],["120°",function(c,done){STEPS[4].fin();done()}],["180°",function(c,done){qbmsg('180° — yoyiq burchak. Bu burchak undan kichik')}],["90°",function(c,done){qbmsg('90° — tik chiziq. Ikkinchi tomon tikdan o‘ngroqda')}]],g2:1,
 html:"<p>Endi burchakning bir tomoni <b>chap</b> tomonda. Uni o'lchang.</p>",
 after:"<p>Bir tomon chapdagi 0 dan o'tadi — chapdan boshlangan (qizil) shkala: <b>120°</b>. Burchak o'tmas ko'rinadi — to'g'ri. Ko'k shkaladagi 60 ham shu chiziqda, lekin u o'ngdagi 0 dan sanaladi. 60° + 120° = 180° — bu ikki burchak birga yoyiq burchak hosil qiladi.</p>",
 q:{t:"Burchak tomoni chapdagi 0 dan o'tadi, ikkinchi tomon tashqi shkalada 145, ichki shkalada 35 da. Burchak o'tkir. Necha gradus?",opts:["35°","145°","110°","180°"],ok:0,why:"Tomon chapdagi 0 da — chapdan boshlangan shkala; burchak o'tkir: 35°.",hint:"Burchak o'tkir bo'lsa, katta sonni olish mumkinmi?",full:"Chapdan boshlangan shkalada 35, va burchak o'tkir — demak 35°. 145° — boshqa shkala; 110° — sonlarni ayirish."},
 tn:"Daftarda ikkita burchak chizdiring: biri o'ngga, biri chapga ochilgan. Ikkalasini o'lchab, ikki shkalani ongli tanlashni mashq qildiring."},
{h:"Burchak yasang",sum:"Burchak yasash: nur chizamiz, transportir markazini uchiga qo'yamiz, kerakli gradusga nuqta qo'yib, uchi bilan tutashtiramiz.",a:"m06",
 start:function(){qbdraw({pr:1,rays:[[0,C.blue]],tap:qbt6});qbmsg('Transportir shkalasida <b>70°</b> ni bosing')},fin:function(){qbdraw({pr:1,rays:[[0,C.blue],[70,C.ok]],arc:[0,70,C.ok,'70°']});qbmsg('✓ ∠ = 70° — o‘tkir burchak')},
 act:function(c,done){S.d6=done},
 html:"<p>Ko'k nur — burchakning birinchi tomoni (o'ngdagi 0 da). Ikkinchi tomoni uchun shkalada <b>70°</b> belgisini bosing.</p>",
 after:"<p>Qadamlar: 1) nur chizamiz; 2) transportir markazini nur boshiga, 0 chizig'ini nur ustiga qo'yamiz; 3) <b>shu 0 dan</b> boshlangan shkalada 70 ni topib, nuqta qo'yamiz; 4) nuqtani nur boshi bilan tutashtiramiz. Natija o'tkir burchak — chamalash bilan tekshirdik.</p>",
 q:{t:"140° burchak yasaldi, lekin u o'tkir chiqdi. Qanday xato qilingan?",opts:["Boshqa shkala bo'yicha 40° belgilangan","Transportir katta","Chizg'ich qiyshiq","Hech qanday xato yo'q"],ok:0,why:"140° o'tmas bo'lishi kerak; o'tkir chiqsa — 180 − 140 = 40° belgilangan.",hint:"140° o'tkirmi yoki o'tmas?",full:"140° — o'tmas burchak. O'tkir chiqqan bo'lsa, noto'g'ri shkala bo'yicha 40° belgilangan (140 va 40 bitta chiziqda turadi)."},
 tn:"Juft bo'lib ishlating: biri burchak yasaydi, ikkinchisi o'lchaydi. Natijalar 1–2° farq qilsa ham yaxshi — chizish aniqligini muhokama qiling."},
{h:"Burchaklarni qo'shamiz",sum:"Agar OB nur ∠AOC ning ichidan o'tsa, ∠AOC = ∠AOB + ∠BOC.",a:"m07",
 start:function(){startPh(QBP7)},fin:function(){S.ph=2;QBP7[2]()},
 html:"<p>Burchak ichidan nur o'tsa, u burchakni ikki bo'lakka bo'ladi. Bo'laklardan butunni topamiz.</p>",
 btns:[phaser(QBP7)],
 after:"<p>OB nur ∠AOC ni ikkiga bo'ladi: <b>∠AOC = ∠AOB + ∠BOC</b> = 35° + 55° = 90°. Teskarisi ham to'g'ri: butundan bir bo'lakni ayirsak, ikkinchisi chiqadi: 90° − 35° = 55°. Yoyiq burchakni bo'lsak: bo'laklar yig'indisi 180°.</p>",
 q:{t:"Yoyiq burchakni nur ikkiga bo'ldi. Bir bo'lagi 64°. Ikkinchisi?",opts:["116°","26°","64°","296°"],ok:0,why:"180 − 64 = 116.",hint:"Yoyiq burchak necha gradus?",full:"Yoyiq burchak 180°, bo'laklar yig'indisi ham 180°: 180 − 64 = 116°. 26° — 90 dan ayirish (to'g'ri burchak bilan adashtirish), 296° — 360 dan ayirish."},
 tn:"Qog'ozdan yoyiq burchakni qirqib, ikki bo'lakka kesing: bo'laklarni o'lchab qo'shsa, 180° chiqadi."},
{h:"Soat strelkalari orasidagi burchak",sum:"Soat siferblati 12 bo'lak; har bir soat oralig'i 360 : 12 = 30°.",a:"m08",
 start:function(){S.h8=0;qbclock(0);qbmsg('Soat 12:00. «+1 soat» ni bosib, 4:00 ga yetkazing')},fin:function(){S.h8=4;qbclock(4);qbmsg('✓ 4:00 — strelkalar orasi 4 · 30° = <b>120°</b>')},
 btns:[["+1 soat",function(c,done){if(S.h8>=4)return;S.h8++;qbclock(S.h8);if(S.h8<4)qbmsg(S.h8+':00 — '+S.h8+' · 30° = '+(30*S.h8)+'°');else{STEPS[7].fin();done()}}]],
 html:"<p>Soat siferblati 12 ta teng bo'lakka bo'lingan. Soat strelkasini 12 dan 4 ga olib boring — ular orasidagi burchak qanday o'zgaradi?</p>",
 after:"<p>To'liq aylanish 360°, siferblatda 12 ta oraliq: <b>360 : 12 = 30°</b>. 4:00 da strelkalar orasida 4 ta oraliq: 4 · 30° = <b>120°</b>. 3:00 da — 90° (to'g'ri burchak), 6:00 da — 180° (yoyiq).</p>",
 q:{t:"Soat 5:00 da strelkalar orasidagi (kichik) burchak?",opts:["150°","50°","300°","120°"],ok:0,why:"5 · 30 = 150.",hint:"Bitta soat oralig'i necha gradus?",full:"5 ta oraliq · 30° = 150°. 50° — har oraliqni 10° deb olish, 300° — 10 ta oraliq (katta burchak va xato)."},
 tn:"Haqiqiy soat (yoki karton soat) bilan 3:00, 6:00, 9:00 ni ko'rsatib, burchak turini so'rang."},
{h:"Bilasizmi? Nima uchun 360?",sum:"360 ni qadimgi Bobil astronomlaridan meros olganmiz; Ulug'bek rasadxonasida ulkan sekstant bor edi.",a:"m09",
 start:function(){qbdraw({pr:1,rays:[[0,C.blue],[70,C.ok]],arc:[0,70,C.ok,'70°']});qbmsg('1 to‘liq aylanish = 360°')},fin:function(){qbdraw({pr:1,rays:[[0,C.blue],[70,C.ok]],arc:[0,70,C.ok,'70°']});qbmsg('1 to‘liq aylanish = 360°')},
 html:"<p>🌞 To'liq aylanishni <b>360</b> qismga bo'lishni qadimgi <b>Bobil</b> astronomlaridan meros olganmiz. Ular 60 lik sanoq tizimidan foydalanishgan. 360 soni 2, 3, 4, 5, 6, 8, 9, 10, 12 ga qoldiqsiz bo'linadi — hisoblash juda qulay.</p><p>🔭 <b>Mirzo Ulug'bek</b> XV asrda Samarqandda rasadxona qurdirgan. Uning yer ostiga qisman joylashgan ulkan yoysimon o'lchov asbobi (sekstant) qoldiqlarini bugun ham ko'rish mumkin. U bilan osmon jismlarining burchak balandliklari juda aniq o'lchangan.</p>",
 tn:"Ulug'bek rasadxonasi rasmini ko'rsating va so'rang: «Ulug'bekning asbobi bilan nimani o'lchashgan?» — yulduzlarning burchaklarini."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){qbdraw({pr:1,rays:[[0,C.blue],[50,C.a2]],arc:[0,50,C.ok,'50°']});qbmsg('Markaz — uchida, 0 — tomonida, o‘sha 0 dan o‘qiymiz')},fin:function(){qbdraw({pr:1,rays:[[0,C.blue],[50,C.a2]],arc:[0,50,C.ok,'50°']});qbmsg('Markaz — uchida, 0 — tomonida, o‘sha 0 dan o‘qiymiz')},
 html:"<div class='memo'><ul><li>O'tkir < 90°, to'g'ri = 90°, o'tmas: 90°–180°, yoyiq = 180°, to'liq aylanish = 360°.</li><li>Burchak kattaligi tomonlar uzunligiga bog'liq emas.</li><li>Transportir: <b>markaz</b> — burchak uchida, 0 chizig'i — bir tomonda, <b>o'sha 0 dan</b> boshlangan shkala o'qiladi.</li><li>Avval chamalang: o'tkir ko'rinsa — kichik son, o'tmas ko'rinsa — katta son.</li><li>∠AOC = ∠AOB + ∠BOC; yoyiq burchak bo'laklari yig'indisi 180°.</li><li>Soat: 1 soat oralig'i = 30°.</li></ul></div>",
 tn:"Uyga: daftarda 30°, 75°, 90°, 135° burchaklarni yasab, turini yozish."}
];
function qbt6(a){if(a===70){STEPS[5].fin();if(S.d6){var d=S.d6;S.d6=null;d()}}else if(S.d6){qbdraw({pr:1,rays:[[0,C.blue],[a,C.grey]],tap:qbt6,arc:[0,a,C.grey,a+'°']});qbmsg(a===110?'Bu — 110° (boshqa shkalada 70 turibdi). Burchak o‘tkir bo‘lishi kerak':'Bu '+a+'°. Kerak: o‘ngdagi 0 dan <b>70°</b>')}}
var PROBS=[
{t:"To'g'ri burchak necha gradus?",o:["90°","180°","45°","100°"],k:0,s:"To'g'ri burchak — 90°."},
{t:"Qaysi burchak o'tmas?",o:["125°","85°","90°","180°"],k:0,s:"90° dan katta va 180° dan kichik."},
{t:"Qaysi burchak o'tkir?",o:["89°","90°","91°","179°"],k:0,s:"90° dan kichik — 89°."},
{t:"Yarim aylanish necha gradus?",o:["180°","90°","360°","120°"],k:0,s:"360 : 2 = 180."},
{t:"To'g'ri burchakni teng uchga bo'lsak, har bir bo'lak?",o:["30°","60°","45°","20°"],k:0,s:"90 : 3 = 30."},
{t:"∠AOB = 40°, ∠BOC = 75°, OB burchak ichida. ∠AOC?",o:["115°","35°","105°","125°"],k:0,s:"40 + 75 = 115°."},
{t:"∠AOC = 130°, ∠AOB = 48°. ∠BOC (OB ichida)?",o:["82°","178°","92°","72°"],k:0,s:"130 − 48 = 82°."},
{t:"Yoyiq burchak ikki bo'lakka bo'lindi, biri ikkinchisidan 2 marta katta. Kattasi?",o:["120°","90°","60°","135°"],k:0,s:"3 qism = 180, 1 qism = 60, katta = 120°."},
{t:"Yoyiq burchakni nur ikkiga bo'ldi, bo'laklar teng. Har biri qanday burchak?",o:["To'g'ri (90°)","O'tkir (45°)","O'tmas","Yoyiq"],k:0,s:"180 : 2 = 90°."},
{t:"Transportirda tomon o'ngdagi 0 da, ikkinchi tomon 35 va 145 orasida chiziqda. Burchak o'tkir. Necha gradus?",o:["35°","145°","110°","180°"],k:0,s:"O'tkir — kichik son: 35°."},
{t:"Soat 3:00 da strelkalar orasidagi burchak?",o:["90°","30°","180°","60°"],k:0,s:"3 · 30 = 90°."},
{t:"Soat 2:00 da strelkalar orasidagi burchak?",o:["60°","20°","120°","30°"],k:0,s:"2 · 30 = 60°."},
{t:"Soat 8:00 da strelkalar orasidagi kichik burchak?",o:["120°","240°","80°","160°"],k:0,s:"8 oraliq — 240°, kichigi 360 − 240 = 120°."},
{t:"Daqiqa strelkasi 15 daqiqada necha gradus buriladi?",o:["90°","15°","45°","180°"],k:0,s:"60 daqiqa — 360°, 15 daqiqa — chorak: 90°."},
{t:"Daqiqa strelkasi 1 daqiqada necha gradus buriladi?",o:["6°","1°","60°","30°"],k:0,s:"360 : 60 = 6°."},
{t:"Odam shimolga qarab turibdi va o'ngga 90° burildi. U qayoqqa qaradi?",o:["Sharqqa","G'arbga","Janubga","Shimolga"],k:0,s:"Shimoldan o'ngga chorak burilish — sharq."},
{t:"Odam sharqqa qarab, 180° burildi. Endi qayoqqa qarab turibdi?",o:["G'arbga","Shimolga","Janubga","Sharqqa"],k:0,s:"Yarim burilish — teskari tomon: g'arb."},
{t:"To'g'ri burchak ichidan nur o'tkazildi: bo'laklardan biri 4 marta katta. Kichik bo'lak?",o:["18°","22,5°","72°","20°"],k:0,s:"5 qism = 90°, 1 qism = 18°."},
{t:"Ikki burchak birga yoyiq burchak hosil qiladi. Biri o'tkir 70°. Ikkinchisining turi?",o:["O'tmas, 110°","O'tkir, 20°","To'g'ri, 90°","O'tmas, 290°"],k:0,s:"180 − 70 = 110° — o'tmas."},
{t:"Uchta nur bir nuqtadan chiqib, to'liq aylanishni 3 ta teng burchakka bo'ldi. Har bir burchak?",o:["120°","60°","90°","180°"],k:0,s:"360 : 3 = 120°."}
];
function PRACT_STAGE(){qbdraw({pr:1,rays:[[0,C.blue],[50,C.a2]]})}
var PREP_DATA={teach:["Burchak turlari va burchak kattaligining tomonlar uzunligiga bog'liq emasligi.","Gradus: 90°, 180°, 360°.","Transportir tuzilishi, ikki shkala; burchakni o'lchash va yasash.","Burchaklarni qo'shish/ayirish; soat siferblatidagi burchaklar."],
 mist:["Uzun tomonli burchakni katta deb o'ylaydi.","Transportirni chetidan qo'yadi.","Noto'g'ri shkalani o'qiydi (50° o'rniga 130°).","Yoyiq burchak bo'laklarida 90 dan ayiradi.","Soat oralig'ini 10° yoki 5° deb oladi."],
 need:["Har bir bolaga transportir, chizg'ich.","Karton soat yoki haqiqiy soat.","Qog'oz burchaklar (qirqish uchun).","Doska transportiri."],
 board:["O'tkir < 90° = to'g'ri < o'tmas < 180° = yoyiq.","Markaz — uchida, 0 — tomonda.","Tomon o'ngdagi 0 da → tashqi shkala; chapdagi 0 da → ichki.","Avval chamala!","∠AOC = 35° + 55° = 90°.","Soat: 1 oraliq = 30°."]};
