var CODE='3Y3',TITLE="3-sinf · Murakkab harakat, narx va unumdorlik masalalari";
var Y3G='#d6f1e0';
function Y3car(x,y,col,dir){var g=S.g;E('rect',{x:x-16,y:y-10,width:32,height:14,rx:4,fill:col,stroke:C.line},g);E('rect',{x:x+(dir>0?0:-10),y:y-18,width:10,height:9,rx:2,fill:col,stroke:C.line},g);E('circle',{cx:x-9,cy:y+5,r:4,fill:'#333'},g);E('circle',{cx:x+9,cy:y+5,r:4,fill:'#333'},g)}
function Y3sp(fin){clear();var g=S.g,R=[['Ali',20,5],['Jasur',30,6],['Vali',24,6]];R.forEach(function(r,i){var y=30+i*44;T(g,34,y+5,r[0],{'font-size':13,'font-weight':800,fill:'#1d2b3a'});
  E('rect',{x:70,y:y-10,width:r[1]*5,height:20,rx:4,fill:fin?(i===1?C.ok:'#8fb7dc'):'#8fb7dc'},g);T(g,70+r[1]*5+6,y+5,r[1]+' m, '+r[2]+' s'+(fin?' → '+(r[1]/r[2])+' m/s':''),{'font-size':12,'font-weight':700,fill:'#1d2b3a','text-anchor':'start'})});
 Y3msg(fin?'Tezlik = masofa : vaqt. Jasur: 30 : 6 = <b>5 m/s</b> — eng tez':'Kim eng tez yugurdi? Masofa ham, vaqt ham har xil!')}
function Y3meet(t){clear();var g=S.g,L=40,Rr=320,k=(Rr-L)/708;E('line',{x1:L,y1:90,x2:Rr,y2:90,stroke:'#9aa9b8','stroke-width':3},g);E('circle',{cx:L,cy:90,r:6,fill:C.blue},g);E('circle',{cx:Rr,cy:90,r:6,fill:C.blue},g);T(g,L,112,'A',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,Rr,112,'B',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});
 var a=L+62*t*k,b=Rr-56*t*k;if(t>0){E('line',{x1:L,y1:90,x2:a,y2:90,stroke:C.a,'stroke-width':5},g);E('line',{x1:b,y1:90,x2:Rr,y2:90,stroke:C.c,'stroke-width':5},g)}Y3car(a,72,C.a,1);Y3car(b,72,C.c,-1);
 T(g,90,30,'62 km/soat →',{'font-size':12,'font-weight':800,fill:C.a});T(g,270,30,'← 56 km/soat',{'font-size':12,'font-weight':800,fill:C.c});
 if(t===1)T(g,180,144,'1 soatda yaqinlashadi: 62 + 56 = 118 km',{'font-size':13,'font-weight':800,fill:C.blue});if(t===6)T(g,180,144,'Masofa: 118 · 6 = 708 km',{'font-size':15,'font-weight':800,fill:C.ok})}
var P2=[function(){Y3meet(0);Y3msg('A va B dan bir vaqtda qarama-qarshi yo‘lga chiqishdi. 6 soatda uchrashishdi. AB = ?')},
 function(){Y3meet(1);Y3msg('Har soatda orasidagi masofa <b>118 km</b> ga kamayadi — bu <b>yaqinlashish tezligi</b>')},
 function(){Y3meet(6);Y3msg('6 soatda: 118 · 6 = <b>708 km</b> (yoki 62 · 6 + 56 · 6 = 372 + 336)')}];
function Y3tun(k){clear();var g=S.g;E('rect',{x:110,y:50,width:160,height:56,fill:'#9e8a74',stroke:'#5e4a34','stroke-width':2},g);E('rect',{x:110,y:66,width:160,height:40,fill:'#3a3a3a'},g);T(g,190,44,'tunnel 1600 m',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});
 var x=[20,70,270,270][k];var tw=40;if(k===2)x=270;E('line',{x1:0,y1:106,x2:360,y2:106,stroke:'#7a8a9a','stroke-width':2},g);
 tw=20;var hx=k===0?100:(k===1?110:310);for(var i=0;i<2;i++){E('rect',{x:hx-(i+1)*tw+1,y:84,width:tw-2,height:20,rx:4,fill:i===0?C.bad:'#e9a23b',stroke:C.line},g)}
 if(k>=2){E('line',{x1:110,y1:130,x2:310,y2:130,stroke:C.blue,'stroke-width':2},g);T(g,190,124,'1600',{'font-size':11,'font-weight':800,fill:C.blue});E('line',{x1:270,y1:140,x2:310,y2:140,stroke:C.ok,'stroke-width':3},g);T(g,292,156,'+400',{'font-size':11,'font-weight':800,fill:C.ok})}
 if(k===3)T(g,100,152,'2000 : 40 = 50 s',{'font-size':15,'font-weight':800,fill:C.ok})}
var P3=[function(){Y3tun(0);Y3msg('Poyezd uzunligi 400 m, tezligi 40 m/s. Tunneldan to‘liq o‘tishiga qancha vaqt?')},
 function(){Y3tun(1);Y3msg('Poyezdning <b>boshi</b> tunnelga kirdi — vaqtni boshlaymiz')},
 function(){Y3tun(2);Y3msg('<b>Oxirgi vagon</b> chiqqanda tugaydi: bosh 1600 + 400 = <b>2000 m</b> yurdi')},
 function(){Y3tun(3);Y3msg('2000 : 40 = <b>50 s</b> (40 s emas — poyezd uzunligini unutmang!)')}];
function Y3hill(fin){clear();var g=S.g;E('path',{d:'M20 150 L180 30 L340 150 Z',fill:'#cfe7c4',stroke:'#4a7a3a','stroke-width':2},g);T(g,62,52,'↗ 3 km/soat',{'font-size':12,'font-weight':800,fill:C.bad});T(g,298,52,'6 km/soat ↘',{'font-size':12,'font-weight':800,fill:C.ok});
 if(fin){T(g,110,138,'2 soat · 3 = 6 km',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,250,138,'1 soat · 6 = 6 km',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,180,168,'Jami: 6 + 6 = 12 km',{'font-size':13,'font-weight':800,fill:C.blue})}
 Y3msg(fin?'Tushish 2 marta tez → vaqt 2 marta kam: 3 soat = <b>2 + 1</b>':'Tepalikka chiqib, ortga tushdi. Hammasi 3 soat. Jami necha km yurdi?')}
function Y3pr(k){clear();var g=S.g,R=44,D=62,y1=26,y2=82;function bar(y,n){var x=20;for(var i=0;i<n[0];i++){E('rect',{x:x,y:y,width:R,height:30,fill:'#fde6c8',stroke:C.line},g);T(g,x+R/2,y+20,'R',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=R}for(var j=0;j<3;j++){E('rect',{x:x,y:y,width:D,height:30,fill:k>=2?Y3G:'#dcebf8',stroke:C.line},g);T(g,x+D/2,y+20,k>=2?'3000':'D',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=D}return x}
 var e1=bar(y1,[2]),e2=bar(y2,[1]);T(g,e1+8,y1+20,'13 000',{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,e2+8,y2+20,'11 000',{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'start'});
 if(k>=1){E('rect',{x:20,y:y1,width:R,height:30,fill:'rgba(217,75,75,.25)',stroke:C.bad,'stroke-width':2.5},g);T(g,42,138,'1 R = 13 000 − 11 000 = 2000',{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'})}
 if(k>=2)T(g,20,162,'3 D = 11 000 − 2000 = 9000 → D = 3000',{'font-size':13,'font-weight':800,fill:C.ok,'text-anchor':'start'})}
var P5=[function(){Y3pr(0);Y3msg('2 ruchka + 3 daftar = 13 000 so‘m; 1 ruchka + 3 daftar = 11 000 so‘m')},
 function(){Y3pr(1);Y3msg('Qatorlar farqi — <b>bitta ruchka</b>: 2000 so‘m')},
 function(){Y3pr(2);Y3msg('3 daftar = 9000 → 1 daftar = <b>3000</b> so‘m')}];
function Y3wk(h){clear();var g=S.g;for(var i=0;i<5;i++){var x=30+i*62,on=i<h;E('rect',{x:x,y:30,width:50,height:28,rx:4,fill:on?'#fde6c8':'#f4f6f8',stroke:'#c9d3dd'},g);E('rect',{x:x,y:58,width:50,height:20,rx:4,fill:on?'#d8efe9':'#f4f6f8',stroke:'#c9d3dd'},g);
  if(on){T(g,x+25,49,'6',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,x+25,73,'4',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}T(g,x+25,96,(i+1)+'-soat',{'font-size':10,fill:'#5b6b7b'})}
 T(g,12,49,'U',{'font-size':11,'font-weight':800,fill:C.a});T(g,12,73,'Sh',{'font-size':11,'font-weight':800,fill:C.c});
 T(g,180,130,h?'Bajarildi: 10 · '+h+' = '+(10*h)+' detal':'Usta soatiga 6, shogird 4 detal yasaydi',{'font-size':14,'font-weight':800,fill:h===5?C.ok:C.blue})}
function Y3pool(fin){clear();var g=S.g;E('rect',{x:110,y:40,width:140,height:90,fill:'#eef6fd',stroke:C.line,'stroke-width':2},g);if(fin)E('rect',{x:112,y:70,width:136,height:58,fill:'#8fc3ea'},g);
 E('path',{d:'M40 50 L110 50',stroke:C.ok,'stroke-width':8},g);T(g,64,36,'+30',{'font-size':13,'font-weight':800,fill:C.ok});E('path',{d:'M250 118 L320 118',stroke:C.bad,'stroke-width':8},g);T(g,296,104,'−10',{'font-size':13,'font-weight':800,fill:C.bad});T(g,180,90,'60 chelak',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});
 if(fin)T(g,180,160,'30 − 10 = 20 chelak/soat → 60 : 20 = 3 soat',{'font-size':13,'font-weight':800,fill:C.ok});Y3msg(fin?'Bir soatda hovuzda <b>20</b> chelak ko‘payadi':'Bir quvur soatiga 30 chelak quyadi, ikkinchisi 10 chelak chiqaradi')}
function Y3afr(k){clear();var g=S.g;E('rect',{x:20,y:50,width:k?250:6,height:24,rx:6,fill:'#1f6fb2'},g);T(g,24,40,'«Afrosiyob»: 250 km/soat',{'font-size':12,'font-weight':800,fill:'#1d2b3a','text-anchor':'start'});
 E('rect',{x:20,y:110,width:k?100:6,height:24,rx:6,fill:'#e9a23b'},g);T(g,24,100,'Avtomobil: 100 km/soat',{'font-size':12,'font-weight':800,fill:'#1d2b3a','text-anchor':'start'});
 if(k){T(g,280,67,'2 soatda 500 km',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,130,127,'2 soatda 200 km',{'font-size':11,'font-weight':800,fill:C.a,'text-anchor':'start'})}}
var STEPS=[
{h:"Tezlikni taqqoslash",sum:"Tezlik = masofa : vaqt. Ali 4, Jasur 5, Vali 4 m/s — Jasur eng tez.",a:"m01",start:function(){Y3sp(0)},fin:function(){Y3sp(1)},
 html:"<p>Uch bola yugurdi: masofalar ham, vaqtlar ham har xil. <b>Kim eng tez</b> yugurdi? Taqqoslash uchun har birining 1 soniyada necha metr yugurganini toping.</p>",
 btns:Y3ch(["Ali","Jasur","Vali"],1,function(){Y3sp(1)},'Eng uzoq yugurgan — eng tez degani emas. 1 soniyadagi masofani toping'),g3:1,
 after:"<p><b>Tezlik = masofa : vaqt</b>. Ali: 20 : 5 = 4, Jasur: 30 : 6 = 5, Vali: 24 : 6 = 4 (m/s). Masofa = tezlik · vaqt, vaqt = masofa : tezlik.</p>",
 q:{t:"Toshbaqa 12 m ni 4 daqiqada, salyangoz 10 m ni 2 daqiqada bosib o'tdi. Kim tezroq?",opts:["Toshbaqa","Salyangoz","Bir xil","Toshbaqa 2 marta"],ok:1,why:"Toshbaqa 3 m/daq, salyangoz 5 m/daq.",hint:"Har biri 1 daqiqada necha metr yuradi?",full:"Toshbaqa: 12 : 4 = 3 m/daq. Salyangoz: 10 : 2 = 5 m/daq. Salyangoz tezroq, garchi kamroq masofa bosgan bo'lsa ham."},
 tn:"«Tezlik uchburchagi»: tepada masofa, pastda tezlik × vaqt. Bolalar barmog'i bilan noma'lumni yopib, formulani o'qisin."},
{h:"Qarama-qarshi harakat",sum:"Yaqinlashish tezligi = 62 + 56 = 118 km/soat. 6 soatda: 118 · 6 = 708 km.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ikki shahardan bir vaqtda bir-biriga qarab ikki poyezd yo'lga chiqdi: tezliklari 62 va 56 km/soat. 6 soatdan keyin uchrashishdi. Shaharlar orasidagi masofa qancha?</p>",btns:[phaser(P2)],
 after:"<p>Qarama-qarshi harakatda <b>tezliklar qo'shiladi</b>: har soatda 118 km yaqinlashadi. Masofa = 118 · 6 = <b>708 km</b>. Uchrashish vaqti = masofa : (v₁ + v₂).</p>",
 q:{t:"Ikki piyoda orasida 24 km. Ular bir-biriga qarab 4 km/soat va 2 km/soat tezlikda yo'lga chiqdi. Necha soatda uchrashadi?",opts:["12","4","6","8"],ok:1,why:"Yaqinlashish tezligi 6 km/soat: 24 : 6 = 4.",hint:"Har soatda ular orasidagi masofa qanchaga kamayadi?",full:"Har soatda 4 + 2 = 6 km yaqinlashadi. 24 : 6 = 4 soat. «12» — faqat sekinroq piyoda hisobga olingan (24 : 2), «6» — faqat tezroq (24 : 4)."},
 tn:"Ikki o'quvchi sinf xonasining ikki chetidan bir-biriga qarab qadam tashlasin: har «soat»da ikkalasining qadami qo'shiladi."},
{h:"Poyezd va tunnel",sum:"Poyezd tunneldan to'liq o'tishi uchun tunnel + o'z uzunligini yuradi: (1600 + 400) : 40 = 50 s.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Uzunligi <b>400 m</b> bo'lgan poyezd <b>1600 m</b> li tunneldan 40 m/s tezlikda o'tadi. Poyezdning boshi kirgandan oxiri chiqquncha qancha vaqt o'tadi?</p>",btns:[phaser(P3)],
 after:"<p>Poyezd «nuqta» emas! Boshi tunnelga kirgandan oxirgi vagoni chiqquncha poyezd boshi <b>tunnel + poyezd</b> uzunligini yuradi: 2000 m. 2000 : 40 = <b>50 s</b>.</p>",
 q:{t:"Uzunligi 300 m bo'lgan poyezd ustun yonidan 15 soniyada o'tdi. Uning tezligi qancha?",opts:["15 m/s","20 m/s","285 m/s","4500 m/s"],ok:1,why:"Ustun yonidan o'tish — o'z uzunligini yurish: 300 : 15 = 20.",hint:"Ustun yonidan o'tishda poyezd qancha masofa yuradi?",full:"Ustun — nuqta. Poyezd boshi ustundan o'tgandan oxiri o'tguncha 300 m yuradi: 300 : 15 = 20 m/s. «4500» — ko'paytirilgan, «285» — ayirilgan."},
 tn:"Kitobni «poyezd», daftarni «tunnel» qilib stol ustida siljiting: kitobning burchagi qancha yo'l bosishini chizg'ich bilan o'lchang."},
{h:"Tepalikka chiqish",sum:"Chiqish 3, tushish 6 km/soat, jami 3 soat: tushish vaqti 2 marta kam → 2 + 1 soat → 6 + 6 = 12 km.",a:"m04",start:function(){Y3hill(0)},fin:function(){Y3hill(1)},
 html:"<p>Sayyoh tepalikka 3 km/soat tezlikda chiqdi va o'sha yo'ldan 6 km/soat tezlikda tushdi. Hammasi <b>3 soat</b> vaqt ketdi. U jami necha km yurdi?</p>",
 btns:Y3ch(["9 km","12 km","18 km","6 km"],1,function(){Y3hill(1)},'Chiqish va tushish yo‘li bir xil! Qaysi biriga ko‘proq vaqt ketadi?'),g2:1,
 after:"<p>Yo'l bir xil, tushish tezligi 2 marta katta → tushish vaqti 2 marta kam. 3 soatni 2 : 1 nisbatda bo'lamiz: chiqish 2 soat (6 km), tushish 1 soat (6 km). Jami <b>12 km</b>. «9» va «18» — bitta tezlik bilan 3 soat hisoblangan.</p>",
 q:{t:"Shu masalada sayyoh tepalikka chiqishga necha soat sarfladi?",opts:["1 soat","2 soat","1 yarim soat","3 soat"],ok:1,why:"Chiqish vaqti tushishdan 2 marta ko'p: 2 + 1 = 3 → 2 soat.",hint:"Vaqtlar nisbati tezliklar nisbatiga teskari.",full:"Tushish 2 marta tez, demak 2 marta kam vaqt. Chiqish — 2 qism, tushish — 1 qism, jami 3 qism = 3 soat. Chiqish 2 soat. «1 yarim» — vaqt teng bo'lingan."},
 tn:"Kesma modeli: 3 soatni 3 katakka bo'lib, 2 katakni «chiqish», 1 katakni «tushish» deb bo'yang."},
{h:"Narxlarni taqqoslash",sum:"2R + 3D = 13 000, R + 3D = 11 000 → R = 2000, D = 3000.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>2 ta ruchka va 3 ta daftar 13 000 so'm, 1 ta ruchka va 3 ta daftar 11 000 so'm turadi. Ruchka va daftar narxlarini toping. Chizma model yordam beradi.</p>",btns:[phaser(P5)],
 after:"<p>Ikki xarid bir-biridan faqat <b>bitta ruchka</b> bilan farq qiladi → ruchka 2000 so'm. Keyin 3 daftar = 9000, daftar = <b>3000</b>. Tekshiruv: 2 · 2000 + 3 · 3000 = 13 000 ✓.</p>",
 q:{t:"3 kitob va 2 albom 28 000 so'm, 3 kitob va 5 albom 43 000 so'm. Bitta kitob necha so'm?",opts:["5000","6000","9000","15 000"],ok:1,why:"3 albom = 15 000 → albom 5000; 3 kitob = 28 000 − 10 000 = 18 000 → 6000.",hint:"Ikki xarid farqi nimada?",full:"Farq — 3 ta albom: 43 000 − 28 000 = 15 000 → 1 albom 5000. 3 kitob = 28 000 − 2 · 5000 = 18 000 → 1 kitob 6000. «5000» — albom narxi, «15 000» — 3 albom narxi."},
 tn:"Singapur chizma modeli: ikki qatorni bir-birining tagiga chizing — farq ko'zga ko'rinib turadi."},
{h:"Narx, miqdor, qiymat",sum:"5 kg — 40 000 so'm → 1 kg — 8000 → 8 kg — 64 000 so'm.",a:"m06",start:function(){clear();Y3seq(['5 kg','40 000'],{y:30});Y3seq(['8 kg','?'],{y:96});Y3msg('5 kg olma 40 000 so‘m. 8 kg necha so‘m?')},fin:function(){clear();Y3seq(['1 kg','8000'],{y:30,hi:{1:Y3G}});Y3seq(['8 kg','64 000'],{y:96,hi:{1:Y3G}});Y3msg('Avval 1 kg: 40 000 : 5 = 8000; 8000 · 8 = <b>64 000</b>')},
 html:"<p>5 kg olma 40 000 so'm turadi. Shunday olmadan 8 kg necha so'm turadi?</p>",
 btns:Y3ch(["48 000","64 000","320 000","45 000"],1,function(){STEPS[5].fin()},'Avval 1 kg narxini toping'),g2:1,
 after:"<p><b>Qiymat = narx · miqdor</b>. Avval «birlikka keltiramiz»: 1 kg = 40 000 : 5 = 8000. So'ng 8 · 8000 = <b>64 000</b>. «48 000» — 40 000 ga 8000 qo'shilgan (3 kg emas, 1 kg qo'shilgan).</p>",
 q:{t:"6 ta qalam 9000 so'm. 10 ta qalam necha so'm?",opts:["13 000","15 000","90 000","10 500"],ok:1,why:"1 qalam = 1500, 10 · 1500 = 15 000.",hint:"Bitta qalam necha so'm?",full:"9000 : 6 = 1500 so'm. 10 · 1500 = 15 000. «13 000» — 9000 ga 4000 qo'shilgan (nisbat buzilgan). «90 000» — 9000 · 10."},
 tn:"Jadval tuzing: narx | miqdor | qiymat. Har masalada noma'lum katakni so'roq bilan belgilang."},
{h:"Birgalikda ishlash",sum:"Usta 6 + shogird 4 = 10 detal soatiga. 50 : 10 = 5 soat.",a:"m07",start:function(){S.n=0;Y3wk(0);Y3msg('50 ta detalni birgalikda necha soatda yasashadi?')},fin:function(){Y3wk(5);Y3msg('Birgalikdagi unumdorlik 10 detal/soat → 50 : 10 = <b>5 soat</b>')},
 html:"<p>Usta soatiga 6 ta, shogird 4 ta detal yasaydi. 50 ta detalni ular <b>birgalikda</b> necha soatda yasashadi? Soatlarni qo'shib boring.</p>",
 btns:[["➕ 1 soat",function(c,done){if(S.n<5){S.n++;Y3wk(S.n)}if(S.n>=5){Y3msg('Birgalikdagi unumdorlik 10 detal/soat → 50 : 10 = <b>5 soat</b>');done()}else Y3msg('Har soatda 6 + 4 = <b>10</b> detal')}]],
 after:"<p><b>Unumdorlik</b> — vaqt birligidagi ish. Birgalikda ishlaganda unumdorliklar qo'shiladi: 6 + 4 = 10. Vaqt = ish : unumdorlik = 50 : 10 = <b>5 soat</b>.</p>",
 q:{t:"1-quvur hovuzni 6 soatda, 2-quvur 3 soatda to'ldiradi. Ikkalasi birgalikda necha soatda to'ldiradi?",opts:["9 soat","2 soat","3 soat","4 soat"],ok:1,why:"Hovuz 6 chelak deylik: 1-quvur 1, 2-quvur 2 chelak/soat → 3 chelak/soat → 2 soat.",hint:"Hovuz hajmini qulay son bilan belgilang, masalan, 6 chelak.",full:"Hovuz 6 chelak bo'lsa, 1-quvur soatiga 6 : 6 = 1, 2-quvur 6 : 3 = 2 chelak quyadi. Birgalikda 3 chelak/soat → 6 : 3 = 2 soat. «9» — vaqtlar qo'shilgan, lekin birga ishlaganda tezroq bo'lishi kerak!"},
 tn:"Mantiqiy tekshiruv: birgalikda vaqt eng tez ishchining vaqtidan ham kam bo'lishi kerak — bolalar shu bilan javobni tekshirsin."},
{h:"Olimpiada: to'ldirish va bo'shatish",sum:"30 chelak quyiladi, 10 chiqadi: 20 chelak/soat ko'payadi → 60 : 20 = 3 soat.",a:"m08",start:function(){Y3pool(0)},fin:function(){Y3pool(1)},
 html:"<p>Hovuz 60 chelak suv sig'adi. Bir quvur soatiga 30 chelak quyadi, boshqasi bir vaqtda soatiga 10 chelak chiqarib turadi. Bo'sh hovuz necha soatda to'ladi?</p>",
 btns:Y3ch(["2 soat","3 soat","6 soat","1 soat"],1,function(){Y3pool(1)},'Ikkinchi quvur suvni chiqaradi — unumdorliklar qo‘shiladimi yoki ayiriladimi?'),g2:1,
 after:"<p>Bir quvur to'ldiradi, ikkinchisi bo'shatadi → unumdorliklar <b>ayiriladi</b>: 30 − 10 = 20 chelak/soat. 60 : 20 = <b>3 soat</b>. «2 soat» — chiqaruvchi quvur unutilgan.</p>",
 q:{t:"Ali bir yo'lda soatiga 5 km yuradi. Undan 6 km orqada Vali shu yo'nalishda soatiga 8 km tezlikda yo'lga chiqdi. Vali Alini necha soatda quvib yetadi?",opts:["6 soat","2 soat","1 soat","3 soat"],ok:1,why:"Har soatda Vali 8 − 5 = 3 km yaqinlashadi: 6 : 3 = 2.",hint:"Bir tomonga harakatda tezliklar qo'shiladimi yoki ayiriladimi?",full:"Bir yo'nalishda harakatlanganda yaqinlashish tezligi = 8 − 5 = 3 km/soat. 6 : 3 = 2 soat. «1 soat» — tezliklar qo'shilgan, «6 soat» — faqat 6 km olingan."},
 tn:"Hovuz va quvurni chelak va kosacha bilan ko'rsatish mumkin: biri quyadi, biri oladi."},
{h:"Bilasizmi? «Afrosiyob»",sum:"«Afrosiyob» tezyurar poyezdi 2011-yildan O'zbekistonda qatnaydi, tezligi soatiga 250 km gacha.",a:"m09",start:function(){Y3afr(0);Y3msg('2 soatda kim qancha yo‘l bosadi?')},fin:function(){Y3afr(1);Y3msg('250 · 2 = 500 km, 100 · 2 = 200 km')},
 html:"<p>🚄 2011-yildan Toshkent va Samarqand orasida <b>«Afrosiyob»</b> tezyurar poyezdi qatnaydi. Uning tezligi soatiga <b>250 km</b> gacha yetadi — bu oddiy avtomobildan ikki yarim marta tez!</p>",
 btns:[["⏱ 2 soat yurish",function(c,done){Y3afr(1);Y3msg('250 · 2 = 500 km, 100 · 2 = 200 km');done()}]],
 after:"<p>2 soatda poyezd 500 km, avtomobil 200 km yo'l bosadi. Farq: 300 km. Masofa = tezlik · vaqt.</p>",
 tn:"O'zbekiston xaritasida shaharlar orasidagi masofalarni topib, «Afrosiyob» bilan necha soat ketishini taxminan hisoblang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P5[2]()},fin:function(){P5[2]()},
 html:"<div class='memo'><ul><li><b>s = v · t</b>, v = s : t, t = s : v.</li><li>Qarama-qarshi harakat: tezliklar <b>qo'shiladi</b>; bir tomonga (quvish): <b>ayiriladi</b>.</li><li>Poyezd tunneldan o'tishi: tunnel + poyezd uzunligi.</li><li><b>Qiymat = narx · miqdor</b>; avval birlikka keltiring.</li><li>Ikki xarid farqi — bitta narsaning narxi (chizma model).</li><li>Birgalikda ish: unumdorliklar qo'shiladi; bo'shatuvchi quvur — ayiriladi.</li></ul></div>",
 tn:"Masalani jadvalga joylash odatini shakllantiring: tezlik | vaqt | masofa yoki narx | miqdor | qiymat."}
];
var PROBS=[
{t:"Velosipedchi 3 soatda 36 km yurdi. Uning tezligi qancha?",o:["12 km/soat","39 km/soat","33 km/soat","108 km/soat"],k:0,s:"36 : 3 = 12."},
{t:"Piyoda 5 km/soat tezlikda 4 soat yurdi. Qancha masofa bosdi?",o:["20 km","9 km","1 km","25 km"],k:0,s:"5 · 4 = 20."},
{t:"Avtomobil 240 km ni 60 km/soat tezlikda necha soatda bosib o'tadi?",o:["4","180","300","6"],k:0,s:"240 : 60 = 4."},
{t:"1 kg olma 9000 so'm. 4 kg olma necha so'm?",o:["36 000","13 000","32 000","45 000"],k:0,s:"9000 · 4 = 36 000."},
{t:"5 kg olma 40 000 so'm. 8 kg necha so'm?",o:["64 000","48 000","320 000","72 000"],k:0,s:"1 kg = 8000, 8 · 8000."},
{t:"Usta soatiga 12 ta detal yasaydi. 96 ta detalni necha soatda yasaydi?",o:["8","84","108","9"],k:0,s:"96 : 12 = 8."},
{t:"Uzunligi 300 m bo'lgan poyezd ustun yonidan 15 soniyada o'tdi. Tezligi qancha?",o:["20 m/s","285 m/s","4500 m/s","15 m/s"],k:0,s:"300 : 15 = 20."},
{t:"Ikki piyoda orasida 24 km. Ular bir-biriga qarab 4 va 2 km/soat tezlikda yo'lga chiqdi. Necha soatda uchrashadi?",o:["4","12","6","8"],k:0,s:"24 : (4 + 2) = 4."},
{t:"Ikki shahardan bir-biriga qarab 62 va 56 km/soat tezlikda poyezdlar chiqdi va 6 soatda uchrashdi. Shaharlar orasi qancha?",o:["708 km","372 km","336 km","118 km"],k:0,s:"(62 + 56) · 6 = 708."},
{t:"Bir joydan qarama-qarshi tomonlarga 15 va 12 km/soat tezlikda ikki velosipedchi yo'lga chiqdi. 3 soatdan keyin ular orasida qancha masofa bo'ladi?",o:["81 km","9 km","27 km","45 km"],k:0,s:"(15 + 12) · 3 = 81."},
{t:"Uzunligi 400 m bo'lgan poyezd 1600 m li tunneldan 40 m/s tezlikda o'tadi. Boshi kirgandan oxiri chiqquncha necha soniya?",o:["50","40","10","2000"],k:0,s:"(1600 + 400) : 40 = 50."},
{t:"2 ruchka va 3 daftar 13 000 so'm, 1 ruchka va 3 daftar 11 000 so'm. Ruchka necha so'm?",o:["2000","3000","4000","1000"],k:0,s:"Farq — 1 ruchka."},
{t:"Usta soatiga 6 ta, shogird 4 ta detal yasaydi. 50 ta detalni birgalikda necha soatda yasashadi?",o:["5","10","25","8"],k:0,s:"50 : (6 + 4) = 5."},
{t:"3 kitob va 2 albom 28 000 so'm, 3 kitob va 5 albom 43 000 so'm. Kitob necha so'm?",o:["6000","5000","9000","15 000"],k:0,s:"Albom 5000; 3 kitob = 18 000."},
{t:"Ali soatiga 5 km yuradi. Undan 6 km orqada Vali xuddi shu yo'nalishda 8 km/soat tezlikda yo'lga chiqdi. Necha soatda quvib yetadi?",o:["2","6","3","1"],k:0,s:"6 : (8 − 5) = 2."},
{t:"Sayyoh tepalikka 3 km/soat bilan chiqib, o'sha yo'ldan 6 km/soat bilan tushdi. Hammasi 3 soat. Jami necha km yurdi?",o:["12","9","18","6"],k:0,s:"Chiqish 2 soat (6 km), tushish 1 soat (6 km)."},
{t:"Hovuz 60 chelak. Bir quvur soatiga 30 chelak quyadi, ikkinchisi 10 chelak chiqaradi. Bo'sh hovuz necha soatda to'ladi?",o:["3","2","6","1"],k:0,s:"60 : (30 − 10) = 3."},
{t:"3 ishchi 3 soatda 3 ta stol yasaydi. 6 ishchi 6 soatda nechta stol yasaydi?",o:["12","6","3","36"],k:0,s:"1 ishchi 3 soatda 1 stol → 6 soatda 2 stol; 6 · 2 = 12."},
{t:"1-quvur hovuzni 6 soatda, 2-quvur 3 soatda to'ldiradi. Birgalikda necha soatda to'ldiradi?",o:["2","9","3","4"],k:0,s:"Hovuz 6 chelak: 1 + 2 = 3 chelak/soat → 2 soat."},
{t:"Daftar ruchkadan 1500 so'm qimmat. 2 daftar va 3 ruchka 13 000 so'm. Daftar necha so'm?",o:["3500","2000","5000","2600"],k:0,s:"5 ruchka + 3000 = 13 000 → ruchka 2000, daftar 3500."}
];
function PRACT_STAGE(){P5[2]()}
var PREP_DATA={teach:["Tezlik, vaqt, masofa; tezliklarni taqqoslash.","Qarama-qarshi va bir tomonga harakat: yaqinlashish tezligi.","Poyezd uzunligi hisobga olinadigan masalalar.","Har xil tezlikda bir xil yo'l (tepalik).","Narx, miqdor, qiymat; ikki xarid farqi.","Unumdorlik: birgalikda ish, to'ldirish va bo'shatish."],
 mist:["Masofasi katta bo'lgan — tezroq deb o'ylaydi.","Tunnel masalasida poyezd uzunligini unutadi.","Birgalikdagi ish vaqtlarini qo'shadi (6 + 3 = 9).","Bo'shatuvchi quvurni hisobga olmaydi.","Narx masalasida «birlikka keltirish»ni o'tkazib yuboradi."],
 need:["Ikki o'yinchoq mashina, chizg'ich.","Chelak va kosacha.","Kesma model uchun rangli qog'oz tasmalar."],
 board:["<span class='w2'>s = v · t</span>.","<span class='w2'>(62 + 56) · 6 = 708</span>.","<span class='w2'>(1600 + 400) : 40 = 50</span>.","<span class='w2'>50 : (6 + 4) = 5</span>.","<span class='w2'>60 : (30 − 10) = 3</span>."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
