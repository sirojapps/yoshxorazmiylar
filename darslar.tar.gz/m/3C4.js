var CODE='3C4',TITLE='3-sinf · Uch xonali sonni bir xonali songa ko‘paytirish';
var W3C4L=['birliklar','o‘nliklar','yuzliklar','minglar'];
function w3c4c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
function w3c4P(a,b,note){var r=a*b,sa=String(a),n=sa.length,P=[],c=0,msgs=[];
 for(var k=0;k<n;k++){var d=+sa[n-1-k],p=d*b+c,last=k===n-1;msgs.push(W3C4L[k]+': '+d+' · '+b+(c?' + '+c:'')+' = '+p+(last?' → '+p+' yozamiz':(p>9?' → '+(p%10)+' yozamiz, '+Math.floor(p/10)+' o‘tadi':' → '+p+' yozamiz')));c=Math.floor(p/10)}
 P.push(function(){w3Mul(a,b,0);bqMsg('Birliklardan boshlaymiz')});
 msgs.forEach(function(m,k){P.push(function(){var last=k===n-1;w3Mul(a,b,last?String(r).length:k+1,{hl:k});bqMsg(last?m+'<br><b>Javob: '+r+'</b>'+(note?' — '+note:''):m)})});return P}
var P2=[function(){w3Area([243],3);bqMsg('243 · 3 — maydon modeli')},function(){w3Area([200,40,3],3);bqMsg('243 = 200 + 40 + 3')},function(){w3Area([200,40,3],3,{show:1});bqMsg('600 + 120 + 9 = <b>729</b>')}];
var P3=w3c4P(367,4),P4=w3c4P(408,6,'o‘rtadagi 0 ga ham o‘tkazish qo‘shildi');
function w3c4S(P){return function(){startPh(P)}}
function w3c4F(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Yaxlit yuzliklarni ko'paytirish",sum:"300 · 4 = 3 yuzlik · 4 = 12 yuzlik = 1200. 240 · 3 = 24 o'nlik · 3 = 72 o'nlik = 720.",a:"m01",start:function(){bqExpr(['300 · 4 = ?']);bqMsg('300 — bu 3 ta yuzlik')},fin:function(){bqExpr(['300 · 4 = 12 yuzlik = 1200','240 · 3 = 72 o‘nlik = [720]']);bqMsg('Nolsiz ko‘paytirib, nollarni qaytaramiz')},
 html:"<p>300 — bu <b>3 ta yuzlik</b>. <b>300 · 4</b> = ?</p>",g3:1,
 btns:[["1200",function(c,d,b){bqExpr(['300 · 4 = 12 yuzlik = 1200','240 · 3 = 72 o‘nlik = [720]']);w3c4c(b,d,1,'12 yuzlik = 1200','')}],["120",function(c,d,b){w3c4c(b,d,0,'','120 = 12 o‘nlik. Bizda yuzliklar — ikkita 0 kerak')}],["12",function(c,d,b){w3c4c(b,d,0,'','12 — bu yuzliklar soni. 12 yuzlik = ?')}]],
 after:"<p>Qoida: <b>nollarsiz ko'paytirib, oxiriga shuncha nol qo'shamiz</b>. 300 · 4: 3 · 4 = 12, ikkita 0 → 1200. 240 · 3: 24 · 3 = 72, bitta 0 → 720.</p>",
 q:{t:"500 · 6 = ?",opts:["3000","300","30000","506"],ok:0,why:"5 · 6 = 30, ikkita 0: 3000.",hint:"5 · 6 = 30 yuzlik.",full:"5 · 6 = 30, 500 da ikkita nol bor: 30 + «00» = 3000. «300» — bitta nol yo'qolgan (30 ning o'z noli bilan adashtirilgan)."},
 tn:"Yuzlik kvadratlar (10 × 10 katakli qog'oz) bilan: 3 ta yuzlik 4 marta = 12 ta yuzlik."},
{h:"Xonalarga ajratish",sum:"243 · 3 = 200 · 3 + 40 · 3 + 3 · 3 = 600 + 120 + 9 = 729.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Uch xonali son — uch bo'lak: yuzliklar, o'nliklar, birliklar. Har birini ko'paytiramiz:</p>",btns:[phaser(P2)],
 after:"<p><b>(200 + 40 + 3) · 3 = 600 + 120 + 9</b>. Ikki xonali sondagi kabi — faqat bitta bo'lak ko'p. Og'zaki hisoblashda chapdan (yuzliklardan) boshlash qulay.</p>",
 q:{t:"312 · 4 = ?",opts:["1248","1208","12408","1148"],ok:0,why:"1200 + 40 + 8 = 1248.",hint:"300 · 4, 10 · 4, 2 · 4 — keyin qo'shing.",full:"300 · 4 = 1200, 10 · 4 = 40, 2 · 4 = 8. Jami 1248. «1208» — o'nliklar unutilgan; «12408» — qismlar yonma-yon yozilgan."},
 tn:"Maydon modelini doskada uch rangda chizish."},
{h:"Ustunda, o'tkazishlar bilan",sum:"367 · 4 = 1468: 28 → 8 (2 o'tadi); 24 + 2 = 26 → 6 (2 o'tadi); 12 + 2 = 14.",a:"m03",start:w3c4S(P3),fin:w3c4F(P3),
 html:"<p>Har xonada o'tkazish bor. Ketma-ket kuzating:</p>",btns:[phaser(P3)],
 after:"<p>Oxirgi xonada (yuzliklar) chiqqan son <b>to'liq yoziladi</b>: 14 → «14». Shuning uchun uch xonali son ko'paytmasi to'rt xonali bo'lishi mumkin: 1468.</p>",
 q:{t:"586 · 7 = ?",opts:["4102","3502","35562","4002"],ok:0,why:"6 · 7 = 42 → 2 (4); 8 · 7 + 4 = 60 → 0 (6); 5 · 7 + 6 = 41: 4102.",hint:"Har xonada o'tkazish bor: 4, keyin 6.",full:"42 → 2, 4 o'tadi; 56 + 4 = 60 → 0, 6 o'tadi; 35 + 6 = 41. Javob 4102. «3502» — o'tkazishlar unutilgan; «35562» — 35, 56, 42 aralash yozilgan; «4002» — o'nliklarda 0 dan keyin o'tkazish yo'qolgan."},
 tn:"Bola har qadamni ovoz chiqarib aytsin: «ko'paytiraman — qo'shaman — yozaman — o'tkazaman»."},
{h:"Tuzoq: o'rtada nol",sum:"408 · 6 = 2448: 0 · 6 = 0, lekin o'tkazilgan 4 qo'shiladi → 4.",a:"m04",start:w3c4S(P4),fin:w3c4F(P4),
 html:"<p>O'rtada nol bo'lsa — nol yozish shart emas! O'tkazilgan son <b>nolga ham qo'shiladi</b>:</p>",btns:[phaser(P4)],
 after:"<p>0 · 6 = 0, lekin birliklardan <b>4 o'tgan</b>: 0 + 4 = 4. Xato javob <b>2408</b> — o'tkazish «nolda yo'qolgan». Chama: 400 · 6 = 2400 — ikkala javob ham yaqin, shuning uchun bu xatoni faqat diqqat ushlaydi.</p>",
 q:{t:"705 · 8 = ?",opts:["5640","5600","5604","56040"],ok:0,why:"5 · 8 = 40 → 0 (4); 0 · 8 + 4 = 4; 7 · 8 = 56: 5640.",hint:"Birliklardan 4 o'tadi — uni o'nliklarga (0 · 8) qo'shing.",full:"40 → 0, 4 o'tadi; 0 · 8 + 4 = 4; 7 · 8 = 56. Javob 5640. «5600» — o'tkazilgan 4 yo'qolgan; «5604» — 0 · 8 = 0 deb, 4 birliklarga yozilgan."},
 tn:"Nol bor misollar uchun alohida mashq — bu xato eng uzoq yashaydi."},
{h:"Oxirida nol",sum:"350 · 7 = 35 · 7 o'nlik = 245 o'nlik = 2450.",a:"m05",start:function(){bqExpr(['350 · 7 = ?']);bqMsg('350 = 35 o‘nlik')},fin:function(){bqExpr(['35 · 7 = 245','350 · 7 = [2450]']);bqMsg('Nolni chetga qo‘yib, oxirida qaytaramiz')},
 html:"<p>350 — 35 ta o'nlik. 35 · 7 = 245. Unda <b>350 · 7</b> = ?</p>",g3:1,
 btns:[["2450",function(c,d,b){bqExpr(['35 · 7 = 245','350 · 7 = [2450]']);w3c4c(b,d,1,'245 o‘nlik = 2450','')}],["245",function(c,d,b){w3c4c(b,d,0,'','245 — o‘nliklar soni. Nolni qaytaring')}],["24500",function(c,d,b){w3c4c(b,d,0,'','350 da faqat bitta nol bor')}]],
 after:"<p>Oxirida nol bo'lsa: <b>nolni chetga qo'yib ko'paytiramiz, keyin qaytaramiz</b>. Ustunda bunday yozamiz: 7 ni 0 ostiga emas, <b>5 ostiga</b> qo'yamiz — nolni esa javobga darhol tushiramiz.</p>",
 q:{t:"460 · 5 = ?",opts:["2300","230","2030","23000"],ok:0,why:"46 · 5 = 230, nolni qaytaramiz: 2300.",hint:"46 · 5 = ?",full:"46 · 5 = 230 o'nlik = 2300. «230» — nol qaytarilmagan; «23000» — ortiqcha nol (230 ning o'z noli bor)."},
 tn:"Ustunda nolni «chiqarib qo'yish» usulini ko'rsating: 35|0 · 7."},
{h:"Xatolar galereyasi",sum:"296 · 5 = 1480. Xatolar: 1050 (o'tkazishlar unutilgan), 104530 (yonma-yon), 1380 (o'tkazish adashgan).",a:"m06",start:function(){bqExpr(['296 · 5 = ?','Ali: 1050   Vali: 104530','Sami: 1380   Lola: 1480']);bqMsg('Kim to‘g‘ri?')},fin:function(){w3Mul(296,5,null);bqMsg('30 → 0 (3); 45 + 3 = 48 → 8 (4); 10 + 4 = 14: <b>1480</b>')},
 html:"<p>To'rt o'quvchi <b>296 · 5</b> ni hisobladi. Chamalab va tekshirib, to'g'risini toping:</p>",g2:1,
 btns:[["Ali: 1050",function(c,d,b){w3c4c(b,d,0,'','O‘tkazishlar (3 va 4) qo‘shilmagan. Chama: 300 · 5 = 1500')}],["Vali: 104530",function(c,d,b){w3c4c(b,d,0,'','10, 45, 30 yonma-yon yozilgan. Chama 1500 — bu juda katta!')}],["Sami: 1380",function(c,d,b){w3c4c(b,d,0,'','Oxirgi xonaga 4 o‘rniga 3 qo‘shilgan (eski o‘tkazish)')}],["Lola: 1480",function(c,d,b){w3Mul(296,5,null);w3c4c(b,d,1,'Lola to‘g‘ri: 1480 ≈ 1500','')}]],
 after:"<p>Uch himoya: <b>1) chama</b> (300 · 5 = 1500); <b>2) oxirgi raqam</b> (6 · 5 = 30 → javob 0 bilan tugaydi); <b>3) har o'tkazishni ustunga yozish</b> va qo'shgandan keyin o'chirish.</p>",
 q:{t:"Qaysi javob 347 · 6 bo'lishi mumkin (oxirgi raqam va chamaga qarab)?",opts:["2082","2084","2482","1882"],ok:0,why:"7 · 6 = 42 → oxiri 2; chama 350 · 6 = 2100. 2082 mos.",hint:"Javobning oxirgi raqami 7 · 6 ning oxirgi raqami bilan bir xil.",full:"Oxirgi raqam 2 bo'lishi kerak (2084 chiqib ketadi). Chama ~2100: 2482 va 1882 juda uzoq. Aniq: 347 · 6 = 2082."},
 tn:"Bolalar juft bo'lib bir-birining yechimini «oxirgi raqam + chama» bilan tekshirsin."},
{h:"Masala: ko'paytirish va taqqoslash",sum:"Bir qopda 125 kg un. 6 qop = 750 kg. 8 qop = 1000 kg. Farq: 250 kg.",a:"m07",start:function(){bqBar(null,[{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a}],{title:'6 qop, har biri 125 kg'});bqMsg('Jami nechta kilogramm?')},fin:function(){bqBar(750,[{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a}],{title:'125 · 6 = 750 kg'});bqMsg('125 · 6 = 750 kg')},
 html:"<p>Bir qopda <b>125 kg</b> un. Novvoyxonaga 6 qop olib kelindi. Jami necha kilogramm?</p>",g3:1,
 btns:[["750 kg",function(c,d,b){bqBar(750,[{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a},{v:'125',w:1,col:C.a}],{title:'125 · 6 = 750 kg'});w3c4c(b,d,1,'5 · 6 = 30 → 0 (3); 2 · 6 + 3 = 15 → 5 (1); 1 · 6 + 1 = 7: 750','')}],["131 kg",function(c,d,b){w3c4c(b,d,0,'','125 + 6 — qo‘shish emas, 6 marta 125')}],["620 kg",function(c,d,b){w3c4c(b,d,0,'','O‘tkazishlar qo‘shilmagan: 2 · 6 = 12 ga 3 qo‘shing')}]],
 after:"<p>Teng qismlar → ko'paytirish. Endi bilasiz: <b>125 · 8 = 1000</b> (125 — 1000 ning sakkizdan biri). Demak 8 qop 6 qopdan 1000 − 750 = <b>250 kg</b> ko'p — ya'ni aynan 2 qop.</p>",
 q:{t:"Bir kitob 168 so'm. 5 ta kitob 800 so'mga yetadimi?",opts:["Yo'q, 40 so'm yetmaydi","Ha, 40 so'm ortadi","Ha, aynan yetadi","Yo'q, 140 so'm yetmaydi"],ok:0,why:"168 · 5 = 840 > 800.",hint:"168 · 5 ni hisoblang. Chama 170 · 5 = 850.",full:"8 · 5 = 40 → 0 (4); 6 · 5 + 4 = 34 → 4 (3); 1 · 5 + 3 = 8: 840. 840 − 800 = 40 so'm yetmaydi."},
 tn:"Haqiqiy narxlar bilan «bozor» masalalari — bolalar o'zi masala tuzsin."},
{h:"Bilasizmi? Neper tayoqchalari",sum:"1617-yilda shotland olimi Jon Neper ko'paytirish uchun raqamli tayoqchalar ixtiro qilgan: 367 · 4 → 12 | 24 | 28 → 1468.",a:"m08",start:function(){bqExpr(['3 · 4 = 1|2','6 · 4 = 2|4','7 · 4 = 2|8']);bqMsg('Har tayoqchada ko‘paytma ikki qismga bo‘lingan')},fin:function(){bqExpr(['1 | 2+2 | 4+2 | 8','= 1 | 4 | 6 | 8','= [1468]']);bqMsg('Diagonal bo‘ylab qo‘shamiz — 367 · 4 = 1468')},
 html:"<p>🎓 1617-yilda shotland matematigi <b>Jon Neper</b> «Neper tayoqchalari»ni tasvirlagan: har tayoqchada bitta raqamning ko'paytirish jadvali, o'nliklar va birliklar diagonal chiziq bilan ajratilgan. Tayoqchalarni yonma-yon qo'yib, uch xonali sonni ko'paytirish mumkin edi.</p>",
 btns:[["💡 367 · 4 ni tayoqchalarda hisoblang",function(c,done){bqExpr(['1 | 2+2 | 4+2 | 8','= 1 | 4 | 6 | 8','= [1468]']);bqMsg('12, 24, 28 — qo‘shni qismlarni qo‘shamiz');done()}]],
 after:"<p>12 | 24 | 28 dan: birliklar 8; o'nliklar 4 + 2 = 6; yuzliklar 2 + 2 = 4; minglar 1 → <b>1468</b>. Bu — ustundagi o'tkazishning «ko'rinadigan» shakli!</p>",
 tn:"Karton tayoqchalar yasab, 2–3 xonali sonlarni ko'paytirish — ajoyib sinf loyihasi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w3Mul(408,6,null);bqMsg('O‘rtadagi nolga ham o‘tkazish qo‘shiladi')},fin:function(){w3Mul(408,6,null);bqMsg('O‘rtadagi nolga ham o‘tkazish qo‘shiladi')},
 html:"<div class='memo'><ul><li>300 · 4 = 12 yuzlik = 1200; 350 · 7 = 245 o'nlik = 2450.</li><li><b>243 · 3 = 600 + 120 + 9</b>.</li><li>Ustunda: ko'paytir → o'tkazishni qo'sh → yoz → o'tkaz.</li><li>Oxirgi xonada son <b>to'liq</b> yoziladi: 14.</li><li><b>O'rtada 0</b>: 0 · 6 + 4 = 4 (o'tkazish yo'qolmaydi!).</li><li>Tekshiruv: chama + oxirgi raqam.</li></ul></div>",
 tn:"Keyingi mavzu oldidan: 5 ta misol, har birida bitta nol."}
];
var PROBS=[
{t:"400 · 3 = ?",o:["1200","120","12000","403"],k:0,s:"4 · 3 = 12 yuzlik."},
{t:"230 · 3 = ?",o:["690","69","6900","233"],k:0,s:"23 · 3 = 69 o'nlik = 690."},
{t:"213 · 3 = ?",o:["639","636","6309","216"],k:0,s:"600 + 30 + 9."},
{t:"146 · 4 = ?",o:["584","484","41624","544"],k:0,s:"24 → 4 (2); 16 + 2 = 18 → 8 (1); 4 + 1 = 5: 584."},
{t:"378 · 5 = ?",o:["1890","1540","1880","15340"],k:0,s:"40 → 0 (4); 35 + 4 = 39 → 9 (3); 15 + 3 = 18: 1890."},
{t:"609 · 4 = ?",o:["2436","2406","2416","24036"],k:0,s:"36 → 6 (3); 0 + 3 = 3; 24: 2436."},
{t:"807 · 9 = ?",o:["7263","7203","7236","72063"],k:0,s:"63 → 3 (6); 0 + 6 = 6; 72: 7263."},
{t:"520 · 6 = ?",o:["3120","312","31200","3012"],k:0,s:"52 · 6 = 312, nol: 3120."},
{t:"125 · 8 = ?",o:["1000","900","1040","8040"],k:0,s:"40 → 0 (4); 16 + 4 = 20 → 0 (2); 8 + 2 = 10: 1000."},
{t:"Qaysi ifoda 452 · 3 ga teng?",o:["1200 + 150 + 6","1200 + 15 + 6","400 + 50 + 6","1200 + 150 + 2"],k:0,s:"400 · 3 + 50 · 3 + 2 · 3 = 1356."},
{t:"Ali 504 · 7 = 3508 deb yozdi. Xatosi nimada?",o:["O'nliklarda o'tkazilgan 2 ni unutdi","Yuzliklarda xato","Birliklarda xato","Xato yo'q"],k:0,s:"4 · 7 = 28 → 8 (2); 0 + 2 = 2; 35: 3528."},
{t:"Qaysi javob 289 · 4 bo'lishi mumkin?",o:["1156","1154","1556","856"],k:0,s:"Oxiri 6 (9 · 4 = 36), chama 290 · 4 ≈ 1160: 1156."},
{t:"Bir sumka 256 so'm. 3 ta sumka va 140 so'mlik kamar — jami?",o:["908 so'm","768 so'm","1108 so'm","868 so'm"],k:0,s:"256 · 3 = 768, 768 + 140 = 908."},
{t:"Bir kunda 365 ta g'isht terildi. 7 kunda?",o:["2555","2155","21355","2545"],k:0,s:"35 → 5 (3); 42 + 3 = 45 → 5 (4); 21 + 4 = 25: 2555."},
{t:"Qaysi ko'paytma eng katta?",o:["198 · 6","235 · 5","301 · 4","149 · 8"],k:0,s:"1188, 1175, 1204? 301 · 4 = 1204! Tekshiring."},
{t:"□ · 7 = 1LLL: 143 · 7 = ?",o:["1001","991","1011","1043"],k:0,s:"21 → 1 (2); 28 + 2 = 30 → 0 (3); 7 + 3 = 10: 1001."},
{t:"Eng kichik uch xonali sonni 9 ga ko'paytiring.",o:["900","909","891","999"],k:0,s:"100 · 9 = 900."},
{t:"Qaysi son 4 ga ko'paytirilganda 1000 dan katta bo'ladi?",o:["251","250","249","199"],k:0,s:"250 · 4 = 1000, 251 · 4 = 1004 > 1000."},
{t:"3□6 · 3 = 1□68 (□ — turli raqamlar). Birinchi ko'paytuvchi?",o:["386","356","376","396"],k:0,s:"386 · 3 = 1158? Tekshiring."},
{t:"Kvadratning tomoni 245 mm. Perimetri?",o:["980 mm","940 mm","490 mm","8020 mm"],k:0,s:"245 · 4: 20 → 0 (2); 16 + 2 = 18 → 8 (1); 8 + 1 = 9: 980."}
];
PROBS[14]={t:"Qaysi ko'paytma eng katta?",o:["301 · 4","198 · 6","235 · 5","149 · 8"],k:0,s:"301 · 4 = 1204; 198 · 6 = 1188; 235 · 5 = 1175; 149 · 8 = 1192."};
PROBS[15]={t:"143 · 7 = ?",o:["1001","991","1011","7021"],k:0,s:"21 → 1 (2); 28 + 2 = 30 → 0 (3); 7 + 3 = 10: 1001."};
PROBS[18]={t:"3□6 · 3 = 1□68 (□ lar turli raqamlar bo'lishi mumkin). Birinchi ko'paytuvchi qaysi?",o:["356","386","376","396"],k:0,s:"Oxiri: 6 · 3 = 18 → 8 ✓ (hammasida). 356 · 3 = 1068 ✓; 386 · 3 = 1158; 376 · 3 = 1128; 396 · 3 = 1188 — o'nliklar raqami 6 emas."};
function PRACT_STAGE(){w3Mul(367,4,null);bqMsg('Chama → ustun → oxirgi raqam tekshiruvi')}
var PREP_DATA={teach:["Yaxlit yuzlik va o'nliklarni ko'paytirish.","Maydon modeli: 243 · 3 = 600 + 120 + 9.","Ustunda ko'paytirish, ketma-ket o'tkazishlar.","O'rtada va oxirida nol; chama va oxirgi raqam tekshiruvi; masalalar."],
 mist:["O'rtadagi nolda o'tkazishni yo'qotadi (2408).","Oxirgi xonadagi sonni to'liq yozmaydi.","Qisman ko'paytmalarni yonma-yon yozadi.","Oxirida nol bo'lsa ortiqcha nol qo'shadi."],
 need:["Yuzlik kvadratlar (10 × 10 katak).","Karton Neper tayoqchalari (ixtiyoriy)."],
 board:["<span class='w2'>300 · 4 = 1200</span>","<span class='w2'>243 · 3 = 600 + 120 + 9 = 729</span>","<span class='w2'>367 · 4 = 1468</span>","<span class='w2'>408 · 6 = 2448 (0 · 6 + 4 = 4)</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
