var CODE='4C4',TITLE='4-sinf · Bir xonali songa bo‘lish';
var P1=[function(){W3eq(['4 836 : 4 = ?']);W3msg('4 836 ta tangani 4 kishiga teng ulashamiz')},
 function(){W3eq(['4 000 : 4 = 1 000']);W3msg('Avval minglarni: har kishiga <b>1 000</b>')},
 function(){W3eq(['4 000 : 4 = 1 000','800 : 4 = 200']);W3msg('Yuzliklarni: har kishiga <b>200</b>')},
 function(){W3eq(['4 000 : 4 = 1 000','800 : 4 = 200','36 : 4 = 9']);W3msg('Qolgan 36 ni: har kishiga <b>9</b>')},
 function(){W3eq(['1 000 + 200 + 9 = [1 209]']);W3msg('4 836 : 4 = <b>1 209</b>','Katta xonalardan boshlab ulashdik')}];
var P2=w4LongPh(7365,5,'7 365 : 5 — burchak chizdik. Eng katta xonadan boshlaymiz');
var P4=w4LongPh(8024,4,'8 024 : 4 — bo‘linmada nollar chiqadi. Diqqat!');
var P6=w4LongPh(5640,8,'5 640 : 8 — oxirigacha davom etamiz');
var STEPS=[
{h:"Ulashish: katta xonalardan",sum:"4 836 : 4 = 1 000 + 200 + 9 = 1 209.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=4;P1[4]()},
 html:"<p>Bo'lishni pulni ulashishdek tasavvur qiling: avval katta pullar, keyin maydalari.</p>",btns:[phaser(P1)],
 after:"<p>Bo'lishda ko'paytirishdan farqli ravishda <b>eng katta xonadan</b> boshlaymiz. Bo'linmayotgan qismi keyingi xonaga «maydalab» o'tkaziladi.</p>",
 q:{t:"6 093 : 3 = ?",opts:["2 031","231","2 301","2 013"],ok:0,why:"6 000 : 3 = 2 000, 90 : 3 = 30, 3 : 3 = 1.",hint:"Har xonani alohida bo'ling.",full:"6 000 : 3 = 2 000, 0 : 3 = 0 (yuzliklar yo'q), 90 : 3 = 30, 3 : 3 = 1. Jami 2 031. «231» — yuzliklardagi 0 tashlab yuborilgan."},
 tn:"Pul kartochkalari (1 000, 100, 10, 1 so'mlik) bilan 4 ta bolaga ulashtiring. 100 so'mliklar yetmasa — maydalashadi."},
{h:"Burchak usuli",sum:"7 365 : 5 = 1 473: bo'l — ko'paytir — ayir — tushir.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=P2.length-1;P2[P2.length-1]()},
 html:"<p>Ulashishni qisqa yozish — <b>burchak usuli</b>. Har qadamni bosib kuzating.</p>",btns:[phaser(P2)],
 after:"<p>To'rt harakat aylanadi: <b>bo'l → ko'paytir → ayir → tushir</b>. Ayirmadan chiqqan son har doim <b>bo'luvchidan kichik</b> bo'lishi shart.</p>",
 q:{t:"5 418 : 6 = ?",opts:["903","93","9 003","930"],ok:0,why:"54 : 6 = 9, 1 : 6 = 0, 18 : 6 = 3.",hint:"Birinchi to'liqsiz bo'linuvchi — 54.",full:"54 : 6 = 9 (0 qoladi). 1 ni tushiramiz: 1 : 6 — sig'maydi, bo'linmaga 0. 8 ni tushiramiz: 18 : 6 = 3. Javob 903. «93» — 0 yozilmagan."},
 tn:"Doskada to'rt harakatni belgi bilan yozib qo'ying: ÷ × − ↓. Bolalar har qadamda qaysi harakatda ekanini aytsin."},
{h:"Bo'linmada nechta raqam?",sum:"2 568 : 6: birinchi to'liqsiz bo'linuvchi 25, shuning uchun bo'linma uch xonali: 428.",a:"m03",start:function(){W3eq(['2 568 : 6']);W3msg('Hisoblamasdan ayting: bo‘linmada nechta raqam bo‘ladi?')},fin:function(){W3eq(['[25]68 : 6','25 → yuzliklar','Javob: 428 (3 raqam)'],{fs:20})},
 html:"<p><b>2 568 : 6</b>. Bo'linmada nechta raqam bo'ladi? (Hisoblamang!)</p>",
 btns:[["3 ta",function(c,done){W3eq(['[25]68 : 6','25 → yuzliklar','Javob: 428 (3 raqam)'],{fs:20});W3msg('2 : 6 — sig‘maydi, shuning uchun 25 yuzlikdan boshlaymiz. Bo‘linma <b>yuzliklardan</b> boshlanadi: 3 raqam');done()}],["4 ta",function(){W3eq(['2 : 6 = ?']);W3msg('2 ming 6 ga bo‘linmaydi — minglar xonasi bo‘sh qoladi','Qayta tanlang')}],["2 ta",function(){W3eq(['6 · 99 = 594 < 2 568']);W3msg('Ikki xonali bo‘linma eng ko‘pi 99 · 6 = 594 beradi. Juda kam','Qayta tanlang')}]],g3:1,
 after:"<p><b>Birinchi to'liqsiz bo'linuvchi</b> qaysi xonada tugasa, bo'linma o'sha xonadan boshlanadi. Bu — eng yaxshi chamalash: xato «yo'qolgan nol»ni darhol ushlaydi.</p>",
 q:{t:"36 225 : 9 bo'linmasida nechta raqam bor?",opts:["4","5","3","2"],ok:0,why:"36 : 9 — birinchi to'liqsiz bo'linuvchi 36 ming.",hint:"3 : 9 — sig'maydi.",full:"3 o'n ming 9 ga bo'linmaydi, 36 ming esa bo'linadi. Bo'linma minglardan boshlanadi: 4 raqam (4 025)."},
 tn:"Har burchakli bo'lishdan oldin bo'linma raqamlari o'rniga nuqtalar qo'ydiring: «• • •» — keyin to'ldirishadi."},
{h:"Bo'linmada nollar",sum:"8 024 : 4 = 2 006: sig'masa — bo'linmaga 0 yozib, keyingi raqamni tushiramiz.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=P4.length-1;P4[P4.length-1]()},
 html:"<p>Ba'zan tushirilgan son bo'luvchidan kichik — unda nima qilamiz?</p>",btns:[phaser(P4)],
 after:"<p>Tushirilgan son bo'luvchiga sig'masa — <b>bo'linmaga 0 yozamiz</b> va yana bitta raqam tushiramiz. Har tushirilgan raqam uchun bo'linmada bitta raqam bo'lishi shart!</p>",
 q:{t:"9 036 : 9 = ?",opts:["1 004","104","14","1 040"],ok:0,why:"9 : 9 = 1, 0 → 0, 3 → 0, 36 : 9 = 4.",hint:"0 va 3 — 9 ga sig'maydi.",full:"9 : 9 = 1. 0 tushdi: 0 : 9 = 0. 3 tushdi: 3 : 9 — sig'maydi, 0. 6 tushdi: 36 : 9 = 4. Javob 1 004. «14» — ikkita 0 yo'qolgan."},
 tn:"Qoida: «Bitta raqam tushdimi — bo'linmaga bitta raqam yozildimi?» Bolalar har tushirishda tekshirsin."},
{h:"Tuzoq: yo'qolgan nol",sum:"4 218 : 6 = 703; bola 73 deb yozsa, tekshiruv: 73 · 6 = 438 ≠ 4 218.",a:"m05",start:function(){W3eq(['4 218 : 6 = ?']);W3msg('Uch bola uch xil javob topdi. Qaysi to‘g‘ri?')},fin:function(){w3Long(4218,6,99)},
 html:"<p><b>4 218 : 6</b>. Javoblar: 73, 703, 7 003. To'g'risini tanlang:</p>",
 btns:[["703",function(c,done){w3Long(4218,6,99);W3msg('42 : 6 = 7; 1 : 6 — <b>0</b>; 18 : 6 = 3. Tekshiruv: 703 · 6 = 4 218 ✓');done()}],["73",function(){W3eq(['73 · 6 = 438','438 ≠ 4 218']);W3msg('Tekshiruv ko‘rsatdi: 10 marta kam. Nol yo‘qolgan!','Qayta tanlang')}],["7 003",function(){W3eq(['7 003 · 6 = 42 018','≠ 4 218']);W3msg('Bu — ortiqcha nol. 10 marta ko‘p','Qayta tanlang')}]],g3:1,
 after:"<p><b>Ko'paytirish bilan tekshirish</b>: bo'linma · bo'luvchi = bo'linuvchi. Javob noto'g'ri bo'lsa, darhol ko'rinadi.</p>",
 q:{t:"Bola 6 342 : 6 = 157 deb yozdi. To'g'ri javob?",opts:["1 057","157","1 507","1 570"],ok:0,why:"6 : 6 = 1; 3 → 0; 34 : 6 = 5 (q. 4); 42 : 6 = 7.",hint:"3 : 6 — sig'maydi.",full:"6 : 6 = 1. 3 ni tushiramiz: 3 : 6 — 0. 4 ni tushiramiz: 34 : 6 = 5 (qoldiq 4). 2 ni tushiramiz: 42 : 6 = 7. Javob 1 057. Tekshiruv: 1 057 · 6 = 6 342."},
 tn:"Juftlikda ishlash: biri bo'ladi, ikkinchisi ko'paytirib tekshiradi, keyin almashishadi."},
{h:"Oxirida nol",sum:"5 640 : 8 = 705: oxirgi 0 ham tushiriladi — 40 : 8 = 5.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=P6.length-1;P6[P6.length-1]()},
 html:"<p>Bo'linuvchi nol bilan tugasa — u ham oddiy raqam. Oxirigacha boring!</p>",btns:[phaser(P6)],
 after:"<p>Eng ko'p xato: 56 : 8 = 7 dan keyin «40 qoldi» deb to'xtash yoki 4 ni tushirib, 0 ni unutish. Bo'linuvchida nechta raqam tushirilmagan bo'lsa — ish tugamagan.</p>",
 q:{t:"7 290 : 9 = ?",opts:["810","81","801","8 100"],ok:0,why:"72 : 9 = 8, 9 : 9 = 1, 0 : 9 = 0.",hint:"Oxirgi 0 ni ham tushiring.",full:"72 : 9 = 8, 9 : 9 = 1, 0 tushdi: 0 : 9 = 0. Javob 810. «81» — oxirgi raqam unutilgan; tekshiruv 81 · 9 = 729."},
 tn:"Bo'linuvchining har raqami ustiga tushirilganda belgi (✓) qo'ydiring."},
{h:"Chamalash: javob qancha atrofida?",sum:"3 942 : 9 ≈ 3 600 : 9 = 400 va 4 500 : 9 = 500 orasida; javob 438.",a:"m07",start:function(){W3eq(['3 942 : 9 ≈ ?']);W3msg('Yaqin qulay sonlar: 3 600 va 4 500 — 9 ga oson bo‘linadi')},fin:function(){W3eq(['3 600 : 9 = 400','4 500 : 9 = 500','3 942 : 9 = [438]'])},
 html:"<p><b>3 942 : 9</b> ga qaysi javob to'g'ri kelishi mumkin?</p>",
 btns:[["438",function(c,done){W3eq(['3 600 : 9 = 400','4 500 : 9 = 500','3 942 : 9 = [438]']);W3msg('400 va 500 orasida ✓ Tekshiruv: 438 · 9 = 3 942');done()}],["48",function(){W3eq(['400 < ? < 500','48 — juda kichik']);W3msg('Javob 400 dan katta bo‘lishi kerak','Qayta tanlang')}],["4 380",function(){W3eq(['400 < ? < 500','4 380 — juda katta']);W3msg('Bo‘linma bo‘linuvchidan ham katta chiqdi!','Qayta tanlang')}]],g3:1,
 after:"<p>Chamalash uchun bo'linuvchini <b>bo'luvchiga oson bo'linadigan</b> yaqin songa almashtiramiz (3 600 yoki 4 000 emas — 9 ga bo'linadigani).</p>",
 q:{t:"Qaysi javob 2 744 : 7 ga to'g'ri kelishi mumkin?",opts:["392","39","3 920","492"],ok:0,why:"2 800 : 7 = 400 — biroz kam.",hint:"2 744 ≈ 2 800.",full:"2 800 : 7 = 400, 2 744 undan sal kam — 392 ✓ (392 · 7 = 2 744). 492 · 7 = 3 444 — juda katta."},
 tn:"Chamalashni og'zaki tez mashq qildiring: «4 812 : 6 ≈ ?» — «800 atrofida»."},
{h:"Masala: ikki bosqich",sum:"3 528 kg : 8 kg = 441 yashik; 441 : 9 = 49 mashina.",a:"m08",start:function(){W3eq(['3 528 kg olma','8 kg lik yashiklar','har mashinaga 9 yashik'],{fs:19});W3msg('Nechta mashina kerak?')},fin:function(){W3eq(['3 528 : 8 = 441 yashik','441 : 9 = [49] mashina'])},
 html:"<p>Fermer <b>3 528 kg</b> olmani <b>8 kg</b> lik yashiklarga joyladi. Har mashinaga <b>9</b> ta yashik sig'adi. Nechta mashina kerak?</p>",
 btns:[["1: yashiklar",function(c,done,b){b.disabled=true;W3eq(['3 528 : 8 = 441 yashik']);W3msg('35 : 8 = 4 (q. 3); 32 : 8 = 4; 8 : 8 = 1 → <b>441</b>')}],["2: mashinalar",function(c,done){W3eq(['3 528 : 8 = 441 yashik','441 : 9 = [49] mashina']);W3msg('44 : 9 = 4 (q. 8); 81 : 9 = 9 → <b>49</b> ta mashina');done()}]],
 after:"<p>Tekshiruv: 49 · 9 = 441 yashik, 441 · 8 = 3 528 kg ✓. Ko'p bosqichli masalada har qadamning <b>birligini</b> yozing: kg, yashik, mashina.</p>",
 q:{t:"5 ta qutiga 2 360 ta qalam teng solindi. 3 ta qutida nechta qalam bor?",opts:["1 416","472","7 080","1 470"],ok:0,why:"2 360 : 5 = 472; 472 · 3.",hint:"Avval bitta qutidagini toping.",full:"Bitta qutida 2 360 : 5 = 472 ta. 3 ta qutida 472 · 3 = 1 416 ta. «472» — faqat bitta quti."},
 tn:"«Avval birini top» — Singapur chizma modelining asosiy g'oyasi. 5 bo'lakli lenta chizdiring."},
{h:"Bilasizmi? «Algoritm» so'zi",sum:"Al-Xorazmiy kitobining lotincha tarjimasi «Algoritmi de numero Indorum» deb boshlangan — «algoritm» so'zi shundan.",a:"m09",start:function(){W3eq(['Algoritmi','= al-Xorazmiy'],{fs:22});W3msg('Burchakli bo‘lish — haqiqiy algoritm')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Vatandoshimiz <b>al-Xorazmiy</b>ning hind raqamlari bilan hisoblash haqidagi kitobi XII asrda lotin tiliga tarjima qilingan. Tarjima «<i>Algoritmi de numero Indorum</i>» — «Al-Xorazmiy hind sonlari haqida» so'zlari bilan boshlangan. <b>«Algoritm»</b> so'zi aynan shundan kelib chiqqan.</p><p>⭐ Burchakli bo'lish — haqiqiy algoritm: bir xil to'rt qadam (bo'l, ko'paytir, ayir, tushir) takrorlanadi.</p>",
 tn:"Bolalar burchakli bo'lishni «robot uchun buyruqlar» shaklida yozib ko'rsin — algoritm tushunchasiga ko'prik."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Long(7365,5,99)},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Katta xonadan boshlanadi: 4 836 : 4 = 1 000 + 200 + 9.</li><li>Burchak usuli: <b>bo'l → ko'paytir → ayir → tushir</b>; qoldiq bo'luvchidan kichik.</li><li>Birinchi to'liqsiz bo'linuvchi bo'linma raqamlari sonini aytadi.</li><li>Sig'masa — bo'linmaga <b>0</b>: 8 024 : 4 = 2 006.</li><li>Oxirgi raqamgacha boring: 5 640 : 8 = 705.</li><li>Tekshiruv: 703 · 6 = 4 218.</li></ul></div>",
 tn:"Keyingi mavzu: ikki xonali songa bo'lish — bo'linma raqamini «tanlash» kerak bo'ladi."}
];
var PROBS=[
{t:"8 460 : 2 = ?",o:["4 230","423","4 203","4 320"],k:0,s:"8 000 : 2 + 400 : 2 + 60 : 2."},
{t:"9 675 : 5 = ?",o:["1 935","1 835","1 905","935"],k:0,s:"9 : 5 = 1 (q. 4); 46 : 5 = 9 (q. 1); 17 : 5 = 3 (q. 2); 25 : 5 = 5."},
{t:"7 504 : 8 = ?",o:["938","9 380","908","983"],k:0,s:"75 : 8 = 9 (q. 3); 30 : 8 = 3 (q. 6); 64 : 8 = 8."},
{t:"6 024 : 6 = ?",o:["1 004","104","1 040","14"],k:0,s:"6; 0; 2 → 0; 24 : 6 = 4."},
{t:"4 914 : 7 = ?",o:["702","72","720","7 002"],k:0,s:"49 : 7 = 7; 1 → 0; 14 : 7 = 2."},
{t:"3 270 : 3 = ?",o:["1 090","109","1 009","1 900"],k:0,s:"3; 2 → 0; 27 : 3 = 9; 0 → 0."},
{t:"25 515 : 5 = ?",o:["5 103","513","5 013","5 130"],k:0,s:"25 : 5 = 5; 5 : 5 = 1; 1 → 0; 15 : 5 = 3."},
{t:"48 096 : 8 = ?",o:["6 012","612","6 102","6 120"],k:0,s:"48 : 8 = 6; 0; 9 : 8 = 1 (q. 1); 16 : 8 = 2."},
{t:"72 108 : 9 bo'linmasida nechta raqam bor?",o:["4","5","3","2"],k:0,s:"72 ming : 9 — minglardan boshlanadi; 8 012."},
{t:"Bola 5 635 : 5 = 127 deb yozdi. To'g'ri javob?",o:["1 127","127","1 027","1 217"],k:0,s:"5; 6 : 5 = 1 (q. 1); 13 : 5 = 2 (q. 3); 35 : 5 = 7."},
{t:"Qaysi javob 6 552 : 8 ga to'g'ri kelishi mumkin?",o:["819","81","8 190","719"],k:0,s:"6 400 : 8 = 800 dan sal ko'p."},
{t:"□ · 7 = 5 642. □ = ?",o:["806","86","860","8 006"],k:0,s:"5 642 : 7: 56 : 7 = 8; 4 → 0; 42 : 7 = 6."},
{t:"□ : 6 = 1 209. □ = ?",o:["7 254","7 214","201","7 054"],k:0,s:"1 209 · 6."},
{t:"Qaysi bo'linmada nol bor?",o:["4 832 : 4","4 848 : 4","3 696 : 3","5 472 : 6"],k:0,s:"1 208; 1 212; 1 232; 912."},
{t:"6 ta avtobusda 1 914 kishi teng joylashdi. 4 ta avtobusda nechta kishi?",o:["1 276","319","957","1 314"],k:0,s:"1 914 : 6 = 319; 319 · 4."},
{t:"Kitobda 1 456 bet. Sardor kuniga bir xil bet o'qib, 8 kunda tugatdi. Kuniga necha bet o'qigan?",o:["182","172","1 448","812"],k:0,s:"1 456 : 8."},
{t:"Bir mashina 9 soatda 1 080 km yo'l yurdi. 1 soatda necha km yurgan?",o:["120 km","12 km","1 200 km","108 km"],k:0,s:"1 080 : 9 = 120."},
{t:"(8 412 : 4) − (3 615 : 5) = ?",o:["1 380","1 300","2 826","1 480"],k:0,s:"2 103 − 723."},
{t:"Qaysi son 7 ga bo'linganda bo'linma 1 005 chiqadi?",o:["7 035","7 005","1 012","7 350"],k:0,s:"1 005 · 7."},
{t:"4 kg uzum 4 kg olmadan 3 200 so'm qimmat. 1 kg uzum 1 kg olmadan necha so'm qimmat?",o:["800 so'm","3 200 so'm","12 800 so'm","400 so'm"],k:0,s:"3 200 : 4."}
];
function PRACT_STAGE(){w3Long(7365,5,99);W3msg('Bo‘l → ko‘paytir → ayir → tushir')}
var PREP_DATA={teach:["Bo'lish — katta xonalardan ulashish.","Burchak usuli: bo'l, ko'paytir, ayir, tushir.","Birinchi to'liqsiz bo'linuvchi va bo'linma raqamlari soni.","Bo'linmada nollar (o'rtada va oxirida).","Chamalash va ko'paytirish bilan tekshirish."],
 mist:["Bo'linmadagi nolni yozmaydi: 4 218 : 6 = 73.","Oxirgi raqamni tushirmaydi: 5 640 : 8 = 70.","Ayirma bo'luvchidan katta qoladi (bo'linma raqami kichik tanlangan).","Kichik raqamlardan (birliklardan) boshlaydi."],
 need:["Pul kartochkalari (1 000, 100, 10, 1).","Katakli daftar."],
 board:["<span class='w2'>7 365 : 5 = 1 473</span>","<span class='w2'>8 024 : 4 = 2 006</span>","<span class='w2'>5 640 : 8 = 705</span>","<span class='w2'>÷ × − ↓</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
