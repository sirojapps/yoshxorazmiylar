var CODE='2C3',TITLE='2-sinf · 2 va 3 ga ko‘paytirish va bo‘lish';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P7=[function(){clear();cMsg('3 · 8 + 2 · 9 − 3 · 4 = ?','Avval ko‘paytirishlar!');T(S.g,180,90,'3 · 8 + 2 · 9 − 3 · 4',{'font-size':26,'font-weight':800,fill:'#1d2b3a'})},
 function(){clear();T(S.g,180,70,'3 · 8 + 2 · 9 − 3 · 4',{'font-size':22,'font-weight':800,fill:'#9aa8b6'});T(S.g,180,115,'24  +  18  −  12',{'font-size':28,'font-weight':800,fill:C.blue});cMsg('3 · 8 = 24, 2 · 9 = 18, 3 · 4 = 12')},
 function(){clear();T(S.g,180,70,'24 + 18 − 12',{'font-size':22,'font-weight':800,fill:'#9aa8b6'});T(S.g,180,118,'42 − 12 = 30',{'font-size':30,'font-weight':800,fill:C.ok});cMsg('Keyin chapdan o‘ngga: 24 + 18 = 42, 42 − 12 = <b>30</b>')}];
var P8=[function(){clear();cBar(70,1,'?',null);T(S.g,180,40,'Son → ·3 → :2 → 9',{'font-size':18,'font-weight':800,fill:'#1d2b3a'});cMsg('Bir son 3 ga ko‘paytirildi, natija 2 ga bo‘lindi va 9 chiqdi')},
 function(){clear();T(S.g,180,40,'? → ·3 → 18 → :2 → 9',{'font-size':18,'font-weight':800,fill:'#1d2b3a'});T(S.g,180,100,'9 · 2 = 18',{'font-size':28,'font-weight':800,fill:C.blue});cMsg('Oxiridan: «2 ga bo‘lindi» ning teskarisi — 2 ga ko‘paytiramiz')},
 function(){clear();T(S.g,180,40,'6 → ·3 → 18 → :2 → 9',{'font-size':18,'font-weight':800,fill:C.ok});T(S.g,180,100,'18 : 3 = 6',{'font-size':28,'font-weight':800,fill:C.ok});cMsg('«3 ga ko‘paytirildi» ning teskarisi — 3 ga bo‘lamiz: son <b>6</b>')}];
var STEPS=[
{h:"Ikkitalab sanaymiz",sum:"2, 4, 6, 8, 10, 12, 14, 16, 18, 20 — 2 ga sanash. 2 · 7 = 14.",a:"m01",
 start:function(){S.j=0;cLine(20,2,0);cMsg('0 dan 2 tadan sakraymiz')},fin:function(){cLine(20,2,10);cMsg('2 · 10 = 20')},
 html:"<p>Son o'qida <b>2 tadan</b> sakraymiz. Har sakrash — bitta ikkilik. Tugmani bosib sakrang (kamida 7 marta):</p>",
 btns:[["▶ +2 sakrash",function(c,done,b){if(S.j>=10)return;S.j++;cLine(20,2,S.j);cMsg('2 · '+S.j+' = <b>'+2*S.j+'</b>');if(S.j===7)done();if(S.j===10)b.disabled=true}]],
 after:"<p>Biz bosgan sonlar: 2, 4, 6, 8, 10… — bular <b>juft sonlar</b>. 7 ta sakrash: <b>2 · 7 = 14</b>. 2 ga ko'paytirish jadvali — shu sakrashlarning o'zi.</p>",
 q:{t:"2 · 8 nechaga teng?",opts:["10","16","18","28"],ok:1,why:"2 tadan 8 marta: 16.",hint:"2, 4, 6 … deb 8 marta sanang.",full:"2, 4, 6, 8, 10, 12, 14, 16 — 8 ta sakrash. 2 · 8 = 16. «10» — qo'shish (2 + 8)."},
 tn:"Bolalar sanashni chapak bilan qilsin: har chapakda «2, 4, 6…». Ritm yodlashni osonlashtiradi."},
{h:"2 ga ko'paytirish — ikkilantirish",sum:"Sonni 2 ga ko'paytirish — o'ziga o'zini qo'shish: 2 · 6 = 6 + 6 = 12.",a:"m02",
 start:function(){cPlates(2,6,{lab:1});cMsg('6 · 2 = 6 + 6')},fin:function(){cPlates(2,6,{lab:1});cMsg('6 · 2 = 6 + 6 = <b>12</b>')},
 html:"<p>Ikkita bir xil likopcha — bu <b>ikkilantirish</b>: 6 · 2 = 6 + 6. Sonni tanlang:</p>",
 btns:[["7",function(c,done){cPlates(2,7,{lab:1});cMsg('7 · 2 = 7 + 7 = <b>14</b>');mvK(done,2)}],["8",function(c,done){cPlates(2,8,{lab:1});cMsg('8 · 2 = 8 + 8 = <b>16</b>');mvK(done,2)}],["9",function(c,done){cPlates(2,9,{lab:1});cMsg('9 · 2 = 9 + 9 = <b>18</b>');mvK(done,2)}]],
 after:"<p>Ikkilantirishni bolalar barmoq bilan bilishadi: 7 + 7 = 14. Demak <b>2 · 7</b> ham, <b>7 · 2</b> ham 14.</p>",
 q:{t:"Ali 3 ta qutiga 2 tadan olma, Vali 2 ta qutiga 3 tadan nok joyladi. Kim ko'proq meva joyladi?",opts:["Ali","Vali","Ikkalasi teng","Ali 1 ta ko'p"],ok:2,why:"2 · 3 = 6 va 3 · 2 = 6.",hint:"Har birini hisoblang: Ali — 2 + 2 + 2, Vali — 3 + 3.",full:"Ali: 2 · 3 = 6. Vali: 3 · 2 = 6. Teng! Ko'paytuvchilar o'rni almashsa, natija o'zgarmaydi."},
 tn:"«Ikkilar» (6 + 6, 7 + 7) yod bo'lsa, 2 ga ko'paytirish jadvali tayyor."},
{h:"2 ga bo'lish — yarmini olish",sum:"14 : 2 = 7 — 14 ni ikki teng bo'lakka bo'lsak, har biri 7. Juft — 2 ta bir xil narsa.",a:"m03",
 start:function(){cDeal(14,2,0,{who:'bola'});cMsg('14 ta — 2 ta bolaga')},fin:function(){cDeal(14,2,14,{who:'bola'});cMsg('14 : 2 = <b>7</b> — yarmi')},
 html:"<p>2 ga bo'lish — <b>teng ikkiga</b> ajratish, ya'ni <b>yarmini</b> olish. Tarqatib ko'ring:</p>",
 btns:[["▶ Ikkiga bo'lish",function(c,done,b){b.disabled=true;cDealAnim(14,2,{who:'bola',fast:1},function(){cMsg('14 : 2 = <b>7</b> — yarmi, chunki 7 · 2 = 14');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>Yarmi — ikkilantirishning teskarisi: 7 + 7 = 14, demak 14 ning yarmi 7. «Juft» — 2 ta bir xil narsa: bir juft paypoq, bir juft etik.</p>",
 q:{t:"Savatda 16 ta paypoq bor. Ulardan nechta juft hosil qilish mumkin?",opts:["32","14","8","16"],ok:2,why:"Juft — 2 ta: 16 : 2 = 8.",hint:"Bitta juftda nechta paypoq bor?",full:"Har juftda 2 ta paypoq. 16 : 2 = 8 juft. «32» — ko'paytirish, «14» — ayirish."},
 tn:"Bolalar paypoq/qalamlarni juftlab terib ko'rsin."},
{h:"Uchtalab sanaymiz",sum:"3, 6, 9, 12, 15, 18, 21, 24, 27, 30 — 3 ga sanash. 3 · 9 = 27.",a:"m04",
 start:function(){S.j=0;cLine(30,3,0);cMsg('0 dan 3 tadan sakraymiz')},fin:function(){cLine(30,3,10);cMsg('3 · 10 = 30')},
 html:"<p>Endi <b>3 tadan</b> sakraymiz. Har sakrash — bitta uchlik (masalan, uchburchakning 3 ta uchi). Kamida 9 marta sakrang:</p>",
 btns:[["▶ +3 sakrash",function(c,done,b){if(S.j>=10)return;S.j++;cLine(30,3,S.j);cMsg('3 · '+S.j+' = <b>'+3*S.j+'</b>');if(S.j===9)done();if(S.j===10)b.disabled=true}]],
 after:"<p>3 ga sanash: 3, 6, 9, 12, 15, 18, 21, 24, 27, 30. Qiziq qonuniyat: 12 → 1 + 2 = 3, 15 → 1 + 5 = 6, 18 → 1 + 8 = 9 — raqamlar yig'indisi ham 3, 6, 9 bo'lib takrorlanadi!</p>",
 q:{t:"Har bir uchburchakning 3 ta uchi bor. 9 ta uchburchakning jami nechta uchi bor?",opts:["12","18","27","30"],ok:2,why:"3 · 9 = 27.",hint:"3 tadan 9 marta sanang.",full:"3, 6, 9, 12, 15, 18, 21, 24, 27 — 9 ta sakrash. 3 · 9 = 27. «12» — qo'shish (3 + 9)."},
 tn:"3 ga sanashni qo'shiq/she'r qilib yodlatish mumkin."},
{h:"3 ga bo'lish",sum:"21 : 3 = 7 — uchta teng bo'lak; chunki 7 · 3 = 21.",a:"m05",
 start:function(){cDeal(21,3,0,{who:'bola'});cMsg('21 ta — 3 ta bolaga')},fin:function(){cDeal(21,3,21,{who:'bola'});cMsg('21 : 3 = <b>7</b>')},
 html:"<p>21 ta yong'oqni 3 ta bolaga teng bo'lamiz. Tarqating:</p>",
 btns:[["▶ Uchga bo'lish",function(c,done,b){b.disabled=true;cDealAnim(21,3,{who:'bola',fast:1},function(){cMsg('21 : 3 = <b>7</b>, chunki 7 · 3 = 21');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>Bo'lishni ko'paytirish jadvalidan topamiz: «qaysi sonni 3 ga ko'paytirsam 21 bo'ladi?» — 7. Shuning uchun 3 ga sanashni yaxshi bilish kerak.</p>",
 q:{t:"Qaysi misol XATO yechilgan?",opts:["18 : 3 = 6","16 : 2 = 8","24 : 3 = 9","12 : 2 = 6"],ok:2,why:"8 · 3 = 24, demak 24 : 3 = 8.",hint:"Har birini ko'paytirish bilan tekshiring.",full:"6 · 3 = 18 ✓, 8 · 2 = 16 ✓, 6 · 2 = 12 ✓. 9 · 3 = 27, 24 emas — xato. To'g'risi 24 : 3 = 8."},
 tn:"Har bo'lishni darhol ko'paytirish bilan tekshirish odatini shakllantiring."},
{h:"2 va 3 ning jadvali",sum:"2 · 1 … 2 · 10 va 3 · 1 … 3 · 10. 3 · n = 2 · n + n.",a:"m06",
 start:function(){c3Tab(0)},fin:function(){c3Tab(7)},
 html:"<p>Sonni tanlang — 2 ga va 3 ga ko'paytmasi massivda ko'rinadi. E'tibor bering: <b>3 qator = 2 qator + yana 1 qator</b>.</p><div class='digs' id='c3d'></div>",
 act:function(c,done){var box=c.querySelector('#c3d'),k=0;box.innerHTML='';for(var n=1;n<=10;n++)(function(n){var b=document.createElement('button');b.className='dg';b.textContent=n;b.onclick=function(){c3Tab(n);if(++k===3)done()};box.appendChild(b)})(n)},
 after:"<p>3 ga ko'paytirishni unutsangiz — 2 ga ko'paytirib, yana bir marta qo'shing: 3 · 7 = 2 · 7 + 7 = 14 + 7 = 21.</p>",
 q:{t:"3 · 7 − 2 · 7 nechaga teng?",opts:["7","14","21","35"],ok:0,why:"Uchta yettilikdan ikkita yettilik olinsa, bitta yettilik qoladi.",hint:"3 ta yettilikdan 2 ta yettilikni olsak, nechta yettilik qoladi?",full:"3 · 7 = 21, 2 · 7 = 14, 21 − 14 = 7. Yoki tezroq: 3 ta yettilik − 2 ta yettilik = 1 ta yettilik = 7."},
 tn:"Bu — taqsimot xossasining (2C15) boshlanishi. Massivni qog'ozda yopib-ochib ko'rsating."},
{h:"Tuzoq: amallar tartibi",sum:"3 · 8 + 2 · 9 − 3 · 4: avval ko'paytirish (24, 18, 12), keyin qo'shish-ayirish: 30.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ifodada ko'paytirish ham, qo'shish ham bor. Chapdan boshlab ketma-ket qilsak xato chiqadi! Kuzating:</p>",
 btns:[phaser(P7)],
 after:"<p><b>Qoida:</b> avval <b>ko'paytirish va bo'lish</b>, keyin <b>qo'shish va ayirish</b>. 3 · 8 + 2 · 9 − 3 · 4 = 24 + 18 − 12 = 30.</p>",
 q:{t:"Hisoblang: 2 · 6 + 3 · 3",opts:["21","45","27","39"],ok:0,why:"12 + 9 = 21.",hint:"Avval ikkala ko'paytmani toping.",full:"2 · 6 = 12, 3 · 3 = 9, 12 + 9 = 21. «45» — chapdan ketma-ket: (2 · 6 + 3) · 3 = 45 — xato tartib."},
 tn:"Ko'paytmalarni rangli bo'r bilan qavsga oling — bolalar ularni bitta «blok» deb ko'rsin."},
{h:"Tuzoq: oxiridan boshlang",sum:"Son · 3 : 2 = 9 → teskari: 9 · 2 = 18, 18 : 3 = 6.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Masala: <i>«Bir son 3 ga ko'paytirildi, natija 2 ga bo'lindi va 9 hosil bo'ldi. Bu qaysi son?»</i> Oxiridan, teskari amallar bilan yechamiz.</p>",
 btns:[phaser(P8)],
 after:"<p>Har amalning <b>teskarisi</b> bor: ko'paytirish ↔ bo'lish. Oxiridan boshlab teskari amallarni bajaramiz: 9 · 2 = 18, 18 : 3 = 6. Tekshiramiz: 6 · 3 = 18, 18 : 2 = 9 ✓.</p>",
 q:{t:"□ · 3 = 24 va △ · 2 = □. △ nechaga teng?",opts:["12","4","8","16"],ok:1,why:"□ = 24 : 3 = 8, △ = 8 : 2 = 4.",hint:"Avval □ ni toping: qaysi sonni 3 ga ko'paytirsak, 24?",full:"□ · 3 = 24 → □ = 8. △ · 2 = 8 → △ = 4. «8» — faqat birinchi qadam, «12» — 24 : 2."},
 tn:"Teskari amallar zanjiri — 4-sinfdagi tenglamalarga tayyorgarlik."},
{h:"Bilasizmi? Misrcha ko'paytirish",sum:"Qadimgi Misrda ko'paytirish ikkilantirish orqali bajarilgan: 3 · 6 = 6 + 12 = 18.",a:"m09",
 start:function(){clear('#f6ead0');T(S.g,180,40,'Misrcha: 6 · 3',{'font-size':16,'font-weight':800,fill:'#6b3d12'});T(S.g,180,80,'1 → 6      2 → 12',{'font-size':20,'font-weight':800,fill:'#6b3d12'});T(S.g,180,120,'1 + 2 = 3  →  6 + 12 = 18',{'font-size':18,'font-weight':800,fill:C.ok});cMsg('Ikkilantirib, keraklilarini qo‘shamiz')},fin:function(){STEPS[8].start()},
 html:"<p>🏺 Qadimgi Misrliklar faqat <b>ikkilantirish</b> va <b>qo'shish</b>ni bilishgan, lekin har qanday sonni ko'paytira olishgan! 6 · 3 ni topish uchun: 6 ning bittasi — 6, ikkitasi — 12; 1 + 2 = 3 bo'lgani uchun 6 + 12 = 18.</p><p>Shuning uchun <b>2 ga ko'paytirish</b> — eng muhim ko'nikma.</p>",
 tn:"Kuchli bolalarga misrcha 5 · 7 ni topishni bering: 1 → 7, 2 → 14, 4 → 28; 1 + 4 = 5 → 7 + 28 = 35."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){c3Tab(7)},fin:function(){c3Tab(7)},
 html:"<div class='memo'><ul><li>2 ga sanash: 2, 4, 6, 8, 10, 12, 14, 16, 18, 20.</li><li>3 ga sanash: 3, 6, 9, 12, 15, 18, 21, 24, 27, 30.</li><li>2 ga ko'paytirish = <b>ikkilantirish</b> (7 · 2 = 7 + 7); 2 ga bo'lish = <b>yarmini</b> olish.</li><li>3 · n = 2 · n + n: 3 · 7 = 14 + 7 = 21.</li><li>Bo'lishni ko'paytirish bilan tekshiring: 21 : 3 = 7, chunki 7 · 3 = 21.</li><li>Avval ko'paytirish/bo'lish, keyin qo'shish/ayirish.</li><li>Oxiridan yechish: teskari amallar (· ↔ :).</li></ul></div>",
 tn:"Keyingi darsni «2 · 9 + 3 · 9 = ?» bilan boshlang (5 ta to'qqizlik = 45)."}
];
function c3Tab(n){clear();if(!n){T(S.g,180,90,'Sonni tanlang',{'font-size':18,fill:'#9aa8b6'});cMsg('2 · n va 3 · n');return}
 var sp=Math.min(26,300/n),x0=180-(n-1)*sp/2;for(var r=0;r<3;r++)for(var c=0;c<n;c++)E('circle',{cx:x0+c*sp,cy:52+r*30,r:Math.min(8,sp*.33),fill:r<2?C.b:C.a,stroke:'rgba(0,0,0,.2)'},S.g);
 T(S.g,24,57,'2 ×',{'font-size':10,'font-weight':800,fill:C.blue});T(S.g,24,117,'+1',{'font-size':10,'font-weight':800,fill:C.a2});
 cMsg('2 · '+n+' = <b>'+2*n+'</b>  ·  3 · '+n+' = '+2*n+' + '+n+' = <b>'+3*n+'</b>')}
var PROBS=[
{t:"2 · 9 nechaga teng?",o:["18","11","16","29"],k:0,s:"9 + 9 = 18."},
{t:"3 · 6 nechaga teng?",o:["18","9","12","21"],k:0,s:"3, 6, 9, 12, 15, 18 — 18."},
{t:"16 : 2 nechaga teng?",o:["8","14","4","32"],k:0,s:"16 ning yarmi 8."},
{t:"27 : 3 nechaga teng?",o:["9","24","8","7"],k:0,s:"9 · 3 = 27."},
{t:"Har bir uchburchakning 3 ta uchi bor. 9 ta uchburchakning jami nechta uchi bor?",o:["27","12","18","30"],k:0,s:"3 · 9 = 27."},
{t:"Savatda 16 ta paypoq bor. Nechta juft hosil bo'ladi?",o:["8","32","14","16"],k:0,s:"16 : 2 = 8."},
{t:"Hisoblang: 3 · 8 + 2 · 9 − 3 · 4",o:["30","24","42","54"],k:0,s:"24 + 18 − 12 = 30."},
{t:"3 · 7 − 2 · 7 nechaga teng?",o:["7","14","21","35"],k:0,s:"Uchta yettilikdan ikkitasi olinsa — bitta yettilik: 7."},
{t:"Bir son 3 ga ko'paytirildi, natija 2 ga bo'lindi va 9 chiqdi. Bu qaysi son?",o:["6","27","9","12"],k:0,s:"Teskari: 9 · 2 = 18, 18 : 3 = 6."},
{t:"□ · 3 = 24 va △ · 2 = □. △ nechaga teng?",o:["4","12","8","16"],k:0,s:"□ = 8, △ = 8 : 2 = 4."},
{t:"Ali 3 qutiga 2 tadan, Vali 2 qutiga 3 tadan meva joyladi. Kim ko'p joyladi?",o:["Ikkalasi teng","Ali","Vali","Ali 1 ta ko'p"],k:0,s:"2 · 3 = 6 va 3 · 2 = 6."},
{t:"25 ta nok 3 ta vazaga teng solindi va 4 ta nok ortib qoldi. Har bir vazada nechtadan nok?",o:["7","8","6","9"],k:0,s:"25 − 4 = 21, 21 : 3 = 7."},
{t:"Tenglamani yeching: x · 2 = 3 · 6 + 30",o:["24","12","96","46"],k:0,s:"3 · 6 + 30 = 48, x = 48 : 2 = 24."},
{t:"Qaysi misol XATO?",o:["24 : 3 = 9","18 : 3 = 6","16 : 2 = 8","12 : 2 = 6"],k:0,s:"9 · 3 = 27, 24 emas. 24 : 3 = 8."},
{t:"2 · 4 + 2 · 6 nechaga teng?",o:["20","48","14","12"],k:0,s:"8 + 12 = 20 (yoki 10 ta ikkilik = 20)."},
{t:"Qaysi son 3 ga sanaganda uchramaydi?",o:["14","12","15","18"],k:0,s:"3, 6, 9, 12, 15, 18 — 14 yo'q."},
{t:"Bir juft etikda 2 ta etik. 7 juft etikda nechta etik?",o:["14","9","7","21"],k:0,s:"2 · 7 = 14."},
{t:"18 ta kitob 3 ta javonga teng terildi. Keyin har bir javondagi kitoblarning yarmi olindi. Har javonda nechta qoldi?",o:["3","6","9","12"],k:0,s:"18 : 3 = 6, yarmi — 3."},
{t:"3 · 4 + 3 qaysi ko'paytmaga teng?",o:["3 · 5","3 · 7","4 · 4","3 · 12"],k:0,s:"4 ta uchlikka yana bitta uchlik — 5 ta: 3 · 5 = 15."},
{t:"Bir son 2 ga ko'paytirilib, 3 qo'shilganda 17 chiqdi. Bu qaysi son?",o:["7","10","20","14"],k:0,s:"Oxiridan: 17 − 3 = 14, 14 : 2 = 7."}
];
function PRACT_STAGE(){c3Tab(7)}
var PREP_DATA={teach:["2 va 3 ga sanash (son o'qida sakrash).","2 ga ko'paytirish — ikkilantirish, 2 ga bo'lish — yarmini olish, juft.","3 ga ko'paytirish va bo'lish; 3 · n = 2 · n + n.","Tuzoqlar: amallar tartibi, oxiridan teskari amallar bilan yechish."],
 mist:["2 · 8 ni 10 deydi (qo'shib yuboradi).","Ifodani chapdan ketma-ket hisoblaydi (2 · 6 + 3 · 3 = 45).","Teskari zanjirda bitta qadamni unutadi.","24 : 3 ni 9 deydi (jadvalni bilmaydi)."],
 need:["Doskada son o'qi 0–30.","Juft narsalar (paypoq, qalam)."],
 board:["<span class='w2'>2, 4, 6, … 20</span> va <span class='w2'>3, 6, 9, … 30</span>.","<span class='w2'>7 · 2 = 7 + 7 = 14</span>.","<span class='w2'>14 : 2 = 7</span> — yarmi.","<span class='w2'>3 · 7 = 14 + 7 = 21</span>.","<span class='w2'>3 · 8 + 2 · 9 − 3 · 4 = 30</span>.","<span class='w2'>? ·3 :2 = 9 → 6</span>."]};
