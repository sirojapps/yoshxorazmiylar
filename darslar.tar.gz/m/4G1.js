// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4G1',TITLE='4-sinf · Uzunlik, massa birliklari va ularni almashtirish';
var G1L=['km','m','dm','sm','mm'],G1LF=[1000,10,10,10],G1M=['t','s','kg','g'],G1MF=[10,100,1000];
function g1len(hi,ar){g4lad(G1L,G1LF,hi,ar,'Uzunlik birliklari')}
function g1mas(hi,ar){g4lad(G1M,G1MF,hi,ar,'Massa birliklari (s — sentner)')}
// ustun shaklidagi hisob
function g1col(rows,res,note){clear();var g=S.g;rows.forEach(function(r,i){T(g,250,44+i*30,r,{'font-size':19,'font-weight':800,fill:'#1d2b3a','text-anchor':'end'})});
 E('line',{x1:110,y1:44+rows.length*30-20,x2:256,y2:44+rows.length*30-20,stroke:'#1d2b3a','stroke-width':2},S.g);
 if(res)T(g,250,44+rows.length*30+8,res,{'font-size':19,'font-weight':800,fill:C.ok,'text-anchor':'end'});
 if(note)T(g,180,164,note,{'font-size':11,'font-weight':700,fill:C.a2})}
function g1bars(a,b,la,lb,show){clear();var g=S.g,mx=Math.max(a,b);
 [[a,la,40],[b,lb,100]].forEach(function(r){var w=show?300*r[0]/mx:300;E('rect',{x:30,y:r[2],width:w,height:30,rx:6,fill:show?(r[0]===mx?C.hi:'#cfe3f6'):'#eef2f6',stroke:C.blue,'stroke-width':1.5},g);T(g,40,r[2]+20,r[1]+(show?'  =  '+r[0]+' m':'  =  ?'),{'font-size':13,'font-weight':800,fill:'#1d2b3a','text-anchor':'start'})})}
var P2=[function(){g1len([1,3]);g4m('<b>5 m 7 sm</b> — necha santimetr?')},
 function(){g1len([1,3],[1,3]);calc(['1 m = 100 sm','5 m = 5 · 100 = <b>500 sm</b>'])},
 function(){g1len([1,3],[1,3]);calc(['5 m = 500 sm','500 sm + 7 sm = <b>507 sm</b>  (57 emas!)'])}];
var P6=[function(){g1col(['3 m 45 sm','+ 2 m 70 sm'],'','Avval santimetrlarni qo‘shamiz');calc(['3 m 45 sm + 2 m 70 sm = ?'])},
 function(){g1col(['3 m 45 sm','+ 2 m 70 sm'],'5 m 115 sm','115 sm ≥ 100 sm — bu 1 metrdan ko‘p!');calc(['45 + 70 = 115 sm','115 sm = <b>1 m 15 sm</b>'])},
 function(){g1col(['3 m 45 sm','+ 2 m 70 sm'],'6 m 15 sm','Ortgan 1 m metrlarga qo‘shildi');calc(['3 + 2 + 1 = 6 m','Javob: <b>6 m 15 sm</b>'])}];
var P7=[function(){g1col(['10 m','− 3 m 25 sm'],'','10 m da santimetr yo‘q — nima qilamiz?');calc(['10 m − 3 m 25 sm = ?'])},
 function(){g1col(['9 m 100 sm','− 3 m 25 sm'],'','1 metrni «maydalaymiz»: 10 m = 9 m 100 sm');calc(['10 m = 9 m + 1 m = <b>9 m 100 sm</b>'])},
 function(){g1col(['9 m 100 sm','− 3 m 25 sm'],'6 m 75 sm','');calc(['100 − 25 = 75 sm,  9 − 3 = 6 m','Javob: <b>6 m 75 sm</b>'])}];
var P8=[function(){clear();var g=S.g;E('rect',{x:120,y:60,width:120,height:80,rx:6,fill:'#e8c08a',stroke:C.t1,'stroke-width':2},g);for(var i=0;i<5;i++)for(var j=0;j<3;j++)E('rect',{x:128+i*22,y:68+j*22,width:18,height:18,rx:3,fill:'#fff3dc',stroke:C.t1},g);T(g,180,40,'Yashik + 40 ta qadoq = 12 kg 500 g',{'font-size':13,'font-weight':800,fill:C.blue});T(g,180,160,'1 qadoq = 250 g',{'font-size':12,'font-weight':700,fill:C.a2});calc(['Bo‘sh yashik necha kg?'])},
 function(){P8[0]();calc(['40 · 250 g = <b>10 000 g</b> = 10 kg — qadoqlar'])},
 function(){P8[0]();calc(['40 · 250 g = 10 000 g = 10 kg','12 kg 500 g − 10 kg = <b>2 kg 500 g</b> — bo‘sh yashik'])}];
function g1globe(){clear();var g=S.g;E('circle',{cx:110,cy:90,r:62,fill:'#cfe7f7',stroke:C.blue,'stroke-width':2},g);E('path',{d:'M110 28 A62 62 0 0 1 172 90',fill:'none',stroke:C.bad,'stroke-width':5},g);E('line',{x1:48,y1:90,x2:172,y2:90,stroke:C.blue,'stroke-dasharray':'4 3'},g);
 T(g,110,20,'Qutb',{'font-size':11,'font-weight':800,fill:C.bad});T(g,110,104,'Ekvator',{'font-size':11,'font-weight':700,fill:C.blue});T(g,268,62,'≈ 10 000 km',{'font-size':15,'font-weight':800,fill:C.bad});T(g,268,90,'1 m — shuning',{'font-size':12,'font-weight':700,fill:'#3a4a5a'});T(g,268,108,'10 milliondan',{'font-size':12,'font-weight':700,fill:'#3a4a5a'});T(g,268,126,'bir qismi',{'font-size':12,'font-weight':700,fill:'#3a4a5a'})}
var STEPS=[
{h:"Uzunlik birliklari zinapoyasi",sum:"km → m: ×1000; m → dm → sm → mm: har qadam ×10. 1 m = 100 sm, 1 km = 1000 m.",a:"m01",
 start:function(){g1len([]);g4m('Tugmalarni bosib, birliklar orasidagi bog‘lanishni ko‘ring')},fin:function(){g1len([0,1],[0,1]);g4m('1 km = 1000 m · 1 m = 100 sm · 1 sm = 10 mm')},
 html:"<p>Uzunlik birliklari bir-biri bilan zinapoyadek bog'langan. Har bir tugmani bosing va qadamlarni sanang:</p>",
 btns:[["km → m",function(c,done){g1len([0,1],[0,1]);g4m('1 km = <b>1000 m</b> · 3 km = 3 · 1000 = 3000 m');mvK(done,3)}],["m → sm",function(c,done){g1len([1,3],[1,3]);g4m('m → dm → sm: ×10 · ×10 = ×100 → 1 m = <b>100 sm</b>');mvK(done,3)}],["sm → mm",function(c,done){g1len([3,4],[3,4]);g4m('1 sm = <b>10 mm</b> · 1 m = 1000 mm');mvK(done,3)}]],g3:1,
 after:"<p>Qo'shni birliklar orasida <b>×10</b> (m, dm, sm, mm), km va m orasida esa <b>×1000</b>. Bir necha qadam o'tsak, ko'paytuvchilar ham ko'paytiriladi: m → mm = 10 · 10 · 10 = <b>1000</b>.</p>",
 q:{t:"3 km 40 m necha metr?",opts:["340 m","3040 m","3400 m","30 040 m"],ok:1,why:"3 km = 3000 m; 3000 + 40 = 3040 m.",hint:"Avval 3 km ni metrga aylantiring.",full:"3 km = 3 · 1000 = 3000 m. Unga 40 m qo'shamiz: 3040 m. «340» — km ni 100 ga ko'paytirish xatosi, «3400» — 40 ni 400 deb olish."},
 tn:"Sinf xonasini qadamlab va metrli tasma bilan o'lchang: «metr» ni bolalar qo'li bilan his qilsin (qadam ≈ 50–60 sm)."},
{h:"Ikki nomli sonni bitta birlikka",sum:"5 m 7 sm = 500 + 7 = 507 sm. Bo'sh xonaga 0 yoziladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p><b>5 m 7 sm</b> — bu «ikki nomli» son. Uni faqat santimetrda yozamiz. Bosqichlarni bosing:</p>",
 btns:[phaser(P2)],
 after:"<p>Avval katta birlikni kichigiga aylantiramiz (5 m = 500 sm), keyin qolganini qo'shamiz. <b>Diqqat:</b> 5 m 7 sm = 507 sm, «57 sm» emas — 57 sm yarim metrdan ham qisqa!</p>",
 q:{t:"8 dm 3 mm necha millimetr?",opts:["83 mm","830 mm","803 mm","8003 mm"],ok:2,why:"8 dm = 800 mm; 800 + 3 = 803 mm.",hint:"1 dm necha mm? (dm → sm → mm)",full:"1 dm = 10 sm = 100 mm, demak 8 dm = 800 mm. 800 + 3 = 803 mm. «83» — raqamlarni yonma-yon yozish xatosi, «830» — 3 mm ni 30 deb olish."},
 tn:"Chizg'ichda 8 dm 3 mm ni ko'rsatib bo'lmaydi — metrli tasmada ko'rsating. «Bo'sh xonaga nol» qoidasini doskaga yozib qo'ying."},
{h:"Massa birliklari: t, s, kg, g",sum:"1 t = 10 s = 1000 kg; 1 s = 100 kg; 1 kg = 1000 g.",a:"m03",
 start:function(){g1mas([]);g4m('Tugmalarni bosing')},fin:function(){g1mas([0,2],[0,2]);g4m('1 t = 1000 kg · 1 s = 100 kg · 1 kg = 1000 g')},
 html:"<p>Massa (og'irlik) birliklari: tonna (t), sentner (s), kilogramm (kg), gramm (g). Har tugmani bosing:</p>",
 btns:[["t → kg",function(c,done){g1mas([0,2],[0,2]);g4m('t → s → kg: ×10 · ×100 → 1 t = <b>1000 kg</b>');mvK(done,3)}],["s → kg",function(c,done){g1mas([1,2],[1,2]);g4m('1 sentner = <b>100 kg</b> (bir qop un 50 kg — 2 qop = 1 s)');mvK(done,3)}],["kg → g",function(c,done){g1mas([2,3],[2,3]);g4m('1 kg = <b>1000 g</b> · non ≈ 500 g');mvK(done,3)}]],g3:1,
 after:"<p><b>1 t = 10 s = 1000 kg</b>, <b>1 s = 100 kg</b>, <b>1 kg = 1000 g</b>. Sentner — qishloq xo'jaligida hosilni o'lchashda ko'p ishlatiladi.</p>",
 q:{t:"2 t 5 s necha kilogramm?",opts:["2005 kg","2500 kg","2050 kg","25 kg"],ok:1,why:"2 t = 2000 kg, 5 s = 500 kg; 2000 + 500 = 2500 kg.",hint:"1 sentner necha kg?",full:"2 t = 2000 kg. 5 s = 5 · 100 = 500 kg. Jami 2500 kg. «2005» — sentnerni kilogramm deb olish xatosi, «2050» — 1 s = 10 kg deb o'ylash."},
 tn:"Tarozida 1 kg narsani (shakar) bolalar qo'lida ushlab ko'rsin. Sentner va tonnani «nechta bola og'irligi» bilan solishtiring (bola ≈ 30 kg)."},
{h:"Taqqoslash: avval bir xil birlikka",sum:"4 km 50 m = 4050 m < 4500 m. Taqqoslashdan oldin bir birlikka keltiramiz.",a:"m04",
 start:function(){g1bars(4050,4500,'4 km 50 m','4500 m',false);g4m('Qaysi yo‘l uzunroq? To‘g‘ri javobni bosing')},fin:function(){g1bars(4050,4500,'4 km 50 m','4500 m',true);g4m('4 km 50 m = 4050 m  <  4500 m')},
 html:"<p>Ikki yo'l: biri <b>4 km 50 m</b>, ikkinchisi <b>4500 m</b>. Qaysi biri uzunroq?</p>",
 btns:[["4 km 50 m uzun",function(c,done,b){b.style.background='#fde2e2';g4m('❌ «4 km 50 m» katta ko‘rinadi, lekin 4 km 50 m = 4050 m. Hisoblab ko‘ring');setTimeout(function(){b.style.background=''},1600)}],["4500 m uzun",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g1bars(4050,4500,'4 km 50 m','4500 m',true);g4m('To‘g‘ri! 4050 m < 4500 m');done()}],["Ikkalasi teng",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 4 km 50 m = 4000 + 50 = 4050 m, 4500 emas');setTimeout(function(){b.style.background=''},1600)}]],
 after:"<p>Har xil birlikdagi kattaliklarni solishtirishdan oldin <b>bitta birlikka</b> keltiramiz: 4 km 50 m = 4050 m. Endi 4050 &lt; 4500 — ko'rinib turibdi.</p>",
 q:{t:"Qaysi biri og'irroq: 3 kg 20 g yoki 3200 g?",opts:["3 kg 20 g","3200 g","Ikkalasi teng"],ok:1,why:"3 kg 20 g = 3020 g < 3200 g.",hint:"3 kg 20 g ni grammga aylantiring.",full:"3 kg = 3000 g, 3 kg 20 g = 3020 g. 3200 g undan 180 g og'ir. «Teng» deganlar 20 g ni 200 g deb o'qishgan."},
 tn:"Ikki ustunli jadval chizing: «ikki nomli» va «bir nomli». Bolalar har juftni avval bir xil birlikka keltirib, keyin belgi qo'ysin."},
{h:"Tuzoq: bo'sh xona — nol",sum:"6 kg 8 g = 6008 g. Grammlar uchun 3 ta xona: 008.",a:"m05",
 start:function(){g1mas([2,3],[2,3]);g4m('<b>6 kg 8 g</b> = ? g. To‘g‘ri yozuvni toping')},fin:function(){g1mas([2,3],[2,3]);g4m('6 kg 8 g = 6 <b>008</b> g')},
 html:"<p>Eng ko'p uchraydigan xato shu yerda! <b>6 kg 8 g</b> ni grammda qanday yozamiz?</p>",
 btns:[["68 g",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 68 g — bu bitta olmacha og‘irligi! 6 kg = 6000 g');setTimeout(function(){b.style.background=''},1600)}],["608 g",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 608 g — 1 kg dan ham kam. 1 kg = 1000 g, 100 emas');setTimeout(function(){b.style.background=''},1600)}],["6008 g",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g4m('To‘g‘ri! 6000 + 8 = <b>6008 g</b>');done()}],["6080 g",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 6080 g = 6 kg 80 g. Bizda esa 8 g');setTimeout(function(){b.style.background=''},1600)}]],g2:1,
 after:"<p>1 kg = 1000 g, shuning uchun grammlarga <b>3 ta xona</b> ajratiladi: 6 kg 8 g = 6 <b>008</b> g. Xuddi shunday 1 km = 1000 m: 4 km 7 m = 4 007 m.</p>",
 q:{t:"4 km 7 m necha metr?",opts:["4007 m","47 m","4070 m","407 m"],ok:0,why:"4 km = 4000 m; 4000 + 7 = 4007 m.",hint:"Metrlar uchun nechta xona ajratiladi? (1 km = 1000 m)",full:"4 km = 4000 m, 4000 + 7 = 4007. «47» va «407» — nollarni tushirib qoldirish, «4070» — 7 ni 70 deb yozish."},
 tn:"Doskada xonalar jadvali chizing: [km | yuz m | o'n m | m]. Bolalar 4 km 7 m ni jadvalga yozib, bo'sh kataklarga 0 qo'ysin."},
{h:"Ismli sonlarni qo'shish",sum:"3 m 45 sm + 2 m 70 sm = 5 m 115 sm = 6 m 15 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Ustunda qo'shamiz: avval kichik birlik, keyin katta birlik. Bosqichlarni bosing:</p>",
 btns:[phaser(P6)],
 after:"<p>Santimetrlar 100 dan oshsa, <b>100 sm = 1 m</b> ni metrlarga «o'tkazamiz» — xuddi o'nliklarga o'tkazgandek. Javobda «5 m 115 sm» qoldirib bo'lmaydi.</p>",
 q:{t:"4 kg 600 g + 2 kg 750 g = ?",opts:["6 kg 1350 g","7 kg 350 g","6 kg 350 g","7 kg 1350 g"],ok:1,why:"600 + 750 = 1350 g = 1 kg 350 g; 4 + 2 + 1 = 7 kg.",hint:"Grammlar 1000 dan oshdimi?",full:"Grammlar: 600 + 750 = 1350 g = 1 kg 350 g. Kilogrammlar: 4 + 2 + 1 = 7. Javob 7 kg 350 g. «6 kg 1350 g» — o'tkazmay qoldirilgan, «6 kg 350 g» — 1 kg yo'qolib qolgan."},
 tn:"Ustun yozuvini doskada bajaring: o'ng ustun sm (g), chap ustun m (kg). O'tkazilgan 1 ni kichik qilib ustiga yozing."},
{h:"Ismli sonlarni ayirish (qarz olib)",sum:"10 m − 3 m 25 sm: 10 m = 9 m 100 sm → 6 m 75 sm.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Arqon 10 m. Undan 3 m 25 sm kesildi. Qancha qoldi?</p>",
 btns:[phaser(P7)],
 after:"<p>Kichik birlik yetmasa, katta birlikdan <b>bittasini maydalaymiz</b>: 1 m = 100 sm, 1 kg = 1000 g, 1 t = 10 s. So'ng odatdagidek ayiramiz.</p>",
 q:{t:"5 t − 2 t 3 s = ?",opts:["3 t 3 s","2 t 7 s","2 t 3 s","3 t 7 s"],ok:1,why:"5 t = 4 t 10 s; 10 − 3 = 7 s; 4 − 2 = 2 t.",hint:"1 tonna necha sentner?",full:"5 t = 4 t 10 s. Sentnerlar: 10 − 3 = 7. Tonnalar: 4 − 2 = 2. Javob 2 t 7 s. «3 t 3 s» — sentnerlarni qo'shib yuborish, «3 t 7 s» — maydalangan tonnani unutish."},
 tn:"«Maydalash» ni pul bilan ko'rsating: 10 ming so'mlik kupyurani 10 ta 1 minglikka almashtirib, keyin ayirish."},
{h:"Masala: bo'sh yashik og'irligi",sum:"40 · 250 g = 10 kg; 12 kg 500 g − 10 kg = 2 kg 500 g.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p><i>«Yashikda 250 g dan 40 ta qadoq pechenye bor. Yashik pechenye bilan birga 12 kg 500 g keladi. Bo'sh yashik qancha?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Reja: 1) hamma qadoqlar massasi; 2) uni grammdan kilogrammga o'tkazish; 3) umumiy massadan ayirish. Birliklar bir xil bo'lmaguncha ayirmang!</p>",
 q:{t:"Bo'sh banka 300 g. Asal solingan banka 2 kg 100 g. Asal qancha?",opts:["1 kg 800 g","2 kg 400 g","1 kg 200 g","2 kg 700 g"],ok:0,why:"2100 − 300 = 1800 g = 1 kg 800 g.",hint:"Asal = (banka + asal) − bo'sh banka.",full:"2 kg 100 g = 2100 g. 2100 − 300 = 1800 g = 1 kg 800 g. «2 kg 400 g» — qo'shib yuborish, «1 kg 200 g» — 100 − 300 ni 300 − 100 deb olish."},
 tn:"«Tara» so'zini tushuntiring (idish massasi). Do'konda tarozi tarani hisobga olishini aytib bering."},
{h:"Bilasizmi? Metr va kilogramm qanday paydo bo'lgan",sum:"Metr — Shimoliy qutbdan ekvatorgacha masofaning 10 milliondan biri (1791). Kilogramm — 1 litr suv massasi.",a:"m09",
 start:function(){g1globe();g4m('Qutbdan ekvatorgacha ≈ 10 000 km = 10 000 000 m')},fin:function(){g1globe();g4m('Qutbdan ekvatorgacha ≈ 10 000 km = 10 000 000 m')},
 html:"<p>🌍 1791-yilda Fransiya olimlari yangi o'lchov taklif qildi: Shimoliy qutbdan ekvatorgacha bo'lgan masofaning <b>10 milliondan bir qismi</b> — <b>1 metr</b>. Shuning uchun qutbdan ekvatorgacha ≈ 10 000 km.</p><p>💧 <b>Kilogramm</b> dastlab 1 litr (1 dm³) suvning massasi deb olingan. Hozir esa kilogramm 2019-yildan fizikaning aniq doimiysi orqali belgilanadi.</p>",
 tn:"Globus olib keling: qutbdan ekvatorgacha ip bilan o'lchab, «bu 10 million metr» deb ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g1len([0,1,3,4]);g4m('km · m · dm · sm · mm   |   t · s · kg · g')},fin:function(){g1len([0,1,3,4]);g4m('km · m · dm · sm · mm   |   t · s · kg · g')},
 html:"<div class='memo'><ul><li><b>1 km = 1000 m</b>, 1 m = 10 dm = 100 sm = 1000 mm, 1 sm = 10 mm.</li><li><b>1 t = 10 s = 1000 kg</b>, 1 s = 100 kg, 1 kg = 1000 g.</li><li>Kattadan kichikka — <b>ko'paytiramiz</b>, kichikdan kattaga — <b>bo'lamiz</b>.</li><li>Bo'sh xonaga <b>0</b>: 6 kg 8 g = 6008 g, 4 km 7 m = 4007 m.</li><li>Taqqoslash va amallardan oldin — bitta birlikka keltiring.</li><li>Qo'shishda 100 sm (1000 g) to'plansa — katta birlikka o'tkazing; ayirishda yetmasa — bittasini maydalang.</li></ul></div>",
 tn:"Uyga vazifa: oiladagi 5 narsaning massasini yorliqdan yozib, grammda va kilogrammda ifodalash."}
];
var PROBS=[
{t:"7 km necha metr?",o:["7000 m","700 m","70 000 m","70 m"],k:0,s:"1 km = 1000 m; 7 · 1000 = 7000 m."},
{t:"4 m 5 sm necha santimetr?",o:["405 sm","45 sm","450 sm","4005 sm"],k:0,s:"4 m = 400 sm; 400 + 5 = 405 sm."},
{t:"3 t necha kilogramm?",o:["3000 kg","300 kg","30 kg","30 000 kg"],k:0,s:"1 t = 1000 kg; 3 · 1000 = 3000 kg."},
{t:"6 s (sentner) necha kilogramm?",o:["600 kg","60 kg","6000 kg","6 kg"],k:0,s:"1 s = 100 kg; 6 · 100 = 600 kg."},
{t:"2 kg 30 g necha gramm?",o:["2030 g","230 g","2300 g","20 030 g"],k:0,s:"2000 + 30 = 2030 g."},
{t:"5600 m ni km va m da yozing.",o:["5 km 600 m","56 km","5 km 60 m","560 km"],k:0,s:"5600 = 5000 + 600 → 5 km 600 m."},
{t:"9 dm 4 mm necha millimetr?",o:["904 mm","94 mm","940 mm","9004 mm"],k:0,s:"1 dm = 100 mm; 900 + 4 = 904 mm."},
{t:"Eng uzunini toping.",o:["3800 m","3 km 80 m","3 km 8 m","380 dm"],k:0,s:"3 km 80 m = 3080 m, 3 km 8 m = 3008 m, 380 dm = 38 m. Eng uzuni 3800 m."},
{t:"4 t 7 s necha kilogramm?",o:["4700 kg","4070 kg","47 kg","4007 kg"],k:0,s:"4000 + 7 · 100 = 4700 kg."},
{t:"Qaysi biri og'ir: 1 kg paxtami yoki 1 kg temirmi?",o:["Teng","Temir","Paxta","Temir 10 marta og'ir"],k:0,s:"Ikkalasi ham 1 kg — massasi teng; faqat paxta ko'p joy egallaydi."},
{t:"3 m 45 sm + 2 m 70 sm = ?",o:["6 m 15 sm","5 m 115 sm","5 m 15 sm","6 m 5 sm"],k:0,s:"45 + 70 = 115 sm = 1 m 15 sm; 3 + 2 + 1 = 6 m."},
{t:"10 m − 3 m 25 sm = ?",o:["6 m 75 sm","7 m 75 sm","7 m 25 sm","6 m 25 sm"],k:0,s:"10 m = 9 m 100 sm; 100 − 25 = 75; 9 − 3 = 6."},
{t:"1 km − 250 m = ?",o:["750 m","850 m","75 m","650 m"],k:0,s:"1000 − 250 = 750 m."},
{t:"Bir qop un 50 kg. 2 t unni nechta qopga solish mumkin?",o:["40","4","400","25"],k:0,s:"2 t = 2000 kg; 2000 : 50 = 40 ta."},
{t:"Bitta olma 150 g. 2 kg 400 g olmada nechta olma bor?",o:["16","24","160","14"],k:0,s:"2400 : 150 = 16."},
{t:"Yashikda 250 g dan 40 qadoq bor; hammasi birga 12 kg 500 g. Bo'sh yashik?",o:["2 kg 500 g","2 kg 250 g","10 kg","12 kg 250 g"],k:0,s:"40 · 250 = 10 000 g = 10 kg; 12 kg 500 g − 10 kg = 2 kg 500 g."},
{t:"10 m arqondan 2 m 35 sm dan 3 bo'lak kesildi. Qancha qoldi?",o:["2 m 95 sm","7 m 5 sm","3 m 5 sm","2 m 5 sm"],k:0,s:"3 · 235 = 705 sm; 1000 − 705 = 295 sm = 2 m 95 sm."},
{t:"Mashina 3 t 5 s yuk ko'taradi. Unga 50 kg li 70 qop ortishdi. To'g'ri gapni toping.",o:["Roppa-rosa sig'adi","500 kg ortiqcha","2 qop ortiqcha","Yana 10 qop sig'adi"],k:0,s:"3 t 5 s = 3500 kg; 70 · 50 = 3500 kg — aynan teng."},
{t:"1 km necha millimetr?",o:["1 000 000 mm","100 000 mm","10 000 mm","1000 mm"],k:0,s:"1 km = 1000 m, 1 m = 1000 mm; 1000 · 1000 = 1 000 000 mm."},
{t:"Qaysi tenglik noto'g'ri?",o:["1 m = 100 dm","1 dm = 100 mm","1 km = 10 000 dm","1 t = 10 s"],k:0,s:"1 m = 10 dm. Qolganlari to'g'ri: 1 dm = 100 mm, 1 km = 10 000 dm, 1 t = 10 s."}
];
function PRACT_STAGE(){g1len([]);g4m('km ×1000 m ×10 dm ×10 sm ×10 mm · t ×10 s ×100 kg ×1000 g')}
var PREP_DATA={teach:["Uzunlik birliklari: km, m, dm, sm, mm va ular orasidagi bog'lanish.","Massa birliklari: t, s, kg, g.","Ikki nomli sonni bir nomliga va aksincha almashtirish; bo'sh xonaga 0.","Taqqoslash, qo'shish (o'tkazish) va ayirish (maydalash); tara masalasi."],
 mist:["5 m 7 sm = 57 sm deb yozadi (nolni tushiradi).","1 kg = 100 g yoki 1 s = 10 kg deb o'ylaydi.","Har xil birlikdagi sonlarni to'g'ridan taqqoslaydi.","Qo'shishda «5 m 115 sm» ko'rinishida qoldiradi."],
 need:["Metrli tasma, chizg'ich, oshxona tarozisi.","1 kg shakar, 1 litr suv shishasi.","Xonalar jadvali chizilgan plakat."],
 board:["Zinapoya: <span class='w2'>km ×1000 m ×10 dm ×10 sm ×10 mm</span>.","<span class='w2'>t ×10 s ×100 kg ×1000 g</span>.","<span class='w2'>5 m 7 sm = 507 sm</span>, <span class='w2'>6 kg 8 g = 6008 g</span>.","<span class='w2'>3 m 45 sm + 2 m 70 sm = 6 m 15 sm</span>.","<span class='w2'>10 m − 3 m 25 sm = 6 m 75 sm</span>."]};
