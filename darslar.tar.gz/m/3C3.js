var CODE='3C3',TITLE='3-sinf · Ikki xonali sonni bir xonali songa ko‘paytirish';
var W3C3L=['birliklar','o‘nliklar','yuzliklar','minglar'];
function w3c3c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
function w3c3P(a,b){var r=a*b,sa=String(a),n=sa.length,P=[],c=0,msgs=[];
 for(var k=0;k<n;k++){var d=+sa[n-1-k],p=d*b+c,last=k===n-1;msgs.push(W3C3L[k]+': '+d+' · '+b+(c?' + '+c:'')+' = '+p+(last?' → '+p+' yozamiz':(p>9?' → '+(p%10)+' yozamiz, '+Math.floor(p/10)+' o‘tadi':' → '+p+' yozamiz')));c=Math.floor(p/10)}
 P.push(function(){w3Mul(a,b,0);bqMsg('Birliklardan boshlaymiz: har raqamni '+b+' ga ko‘paytiramiz')});
 msgs.forEach(function(m,k){P.push(function(){var last=k===n-1;w3Mul(a,b,last?String(r).length:k+1,{hl:k});bqMsg(last?m+'<br><b>Javob: '+r+'</b>':m)})});return P}
var P2=[function(){w3Area([23],4);bqMsg('23 · 4 — bo‘yi 23, eni 4 to‘rtburchak')},function(){w3Area([20,3],4);bqMsg('23 ni 20 va 3 ga ajratamiz')},function(){w3Area([20,3],4,{show:1});bqMsg('20 · 4 = 80, 3 · 4 = 12. Jami: 80 + 12 = <b>92</b>')}];
var P3=w3c3P(32,3),P4=w3c3P(47,6);
function w3c3S(P){return function(){startPh(P)}}
function w3c3F(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Yaxlit o'nliklarni ko'paytirish",sum:"30 · 4 = 3 o'nlik · 4 = 12 o'nlik = 120. Avval 3 · 4, keyin oxiriga 0.",a:"m01",start:function(){bqExpr(['30 · 4 = ?']);bqMsg('30 — bu 3 ta o‘nlik')},fin:function(){bqExpr(['30 · 4 = 3 o‘nlik · 4','= 12 o‘nlik','= [120]']);bqMsg('3 · 4 = 12, oxiriga 0')},
 html:"<p>30 — bu <b>3 ta o'nlik</b>. 3 ta o'nlikni 4 marta olsak — nechta o'nlik? <b>30 · 4</b> = ?</p>",g3:1,
 btns:[["120",function(c,d,b){bqExpr(['30 · 4 = 3 o‘nlik · 4','= 12 o‘nlik','= [120]']);w3c3c(b,d,1,'12 o‘nlik = 120','')}],["12",function(c,d,b){w3c3c(b,d,0,'','12 — bu o‘nliklar soni. 12 o‘nlik = ?')}],["34",function(c,d,b){w3c3c(b,d,0,'','30 + 4 — bu qo‘shish')}]],
 after:"<p>Yaxlit o'nlikni ko'paytirish: <b>nolsiz ko'paytirib, oxiriga 0 qo'shamiz</b>. 30 · 4 = 120, 70 · 8 = 560, 50 · 6 = 300 (5 · 6 = 30, oxiriga yana 0).</p>",
 q:{t:"50 · 8 = ?",opts:["400","40","4000","58"],ok:0,why:"5 · 8 = 40, oxiriga 0: 400.",hint:"5 o'nlik · 8 = ? o'nlik.",full:"5 · 8 = 40 o'nlik = 400. «40» — oxiriga 0 qo'shilmagan; «4000» — ortiqcha 0 qo'shilgan (40 ning o'z noli bor, yana bittasi kifoya)."},
 tn:"O'nlik bog'lamlar (10 talik cho'p bog'lami) bilan: 3 bog'lamni 4 marta qo'yib, 12 bog'lam sanash."},
{h:"Xonalarga ajratib ko'paytirish",sum:"23 · 4 = 20 · 4 + 3 · 4 = 80 + 12 = 92 (maydon modeli).",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ikki xonali sonni o'nliklar va birliklarga ajratamiz. Maydon modelida kuzating:</p>",btns:[phaser(P2)],
 after:"<p><b>(20 + 3) · 4 = 20 · 4 + 3 · 4</b>. Har qismni alohida ko'paytirib, natijalarni qo'shamiz. Bu — <b>taqsimot xossasi</b>, ustunda ko'paytirishning asosi.</p>",
 q:{t:"36 · 5 = ?",opts:["180","156","150","1530"],ok:0,why:"30 · 5 + 6 · 5 = 150 + 30 = 180.",hint:"36 = 30 + 6. Ikkala qismni ham 5 ga ko'paytiring.",full:"30 · 5 = 150, 6 · 5 = 30, jami 180. «156» — 6 ham 5 ga ko'paytirilishi unutilgan; «150» — birliklar tashlab ketilgan; «1530» — 150 va 30 yonma-yon yozilgan."},
 tn:"Katakli qog'ozda 23 × 4 to'rtburchak chizib, 20 va 3 chegarasidan chiziq tortish."},
{h:"Ustunda ko'paytirish",sum:"32 · 3 = 96: birliklar 2 · 3 = 6, o'nliklar 3 · 3 = 9.",a:"m03",start:w3c3S(P3),fin:w3c3F(P3),
 html:"<p>Ustunda yozamiz: bir xonali son <b>birliklar ostiga</b>. O'ngdan boshlaymiz:</p>",btns:[phaser(P3)],
 after:"<p>Ustunda ko'paytirish — maydon modelining qisqa yozuvi: 2 · 3 = 6 (birliklar), 3 · 3 = 9 (o'nliklar). Har xona bitta <b>bir xonali songa</b> ko'paytiriladi.</p>",
 q:{t:"43 · 2 = ?",opts:["86","83","46","816"],ok:0,why:"3 · 2 = 6, 4 · 2 = 8: 86.",hint:"Ikkala raqamni ham 2 ga ko'paytiring.",full:"3 · 2 = 6, 4 · 2 = 8: 86. «83» — faqat o'nliklar ko'paytirilgan; «816» — raqamlar noto'g'ri tartibda."},
 tn:"Ustunni rangli bo'yash: birliklar yashil, o'nliklar sariq — 3B7 dagi kabi."},
{h:"O'tkazish bilan ko'paytirish",sum:"47 · 6 = 282: 7 · 6 = 42 → 2 yozamiz, 4 o'tadi; 4 · 6 + 4 = 28.",a:"m04",start:w3c3S(P4),fin:w3c3F(P4),
 html:"<p>Ko'paytma 10 dan oshsa — o'nliklarini keyingi xonaga o'tkazamiz. Lekin ehtiyot bo'ling:</p>",btns:[phaser(P4)],
 after:"<p>O'tkazilgan son <b>ko'paytirilgandan keyin qo'shiladi</b>: 4 · 6 = 24, keyin + 4 = 28. Avval qo'shib, keyin ko'paytirish (4 + 4 = 8, 8 · 6 = 48) — eng tipik xato!</p>",
 q:{t:"58 · 7 = ?",opts:["406","356","4056","392"],ok:0,why:"8 · 7 = 56 → 6, 5 o'tadi; 5 · 7 + 5 = 40: 406.",hint:"8 · 7 = 56. 5 ni eslab qoling va 5 · 7 ga qo'shing.",full:"8 · 7 = 56: 6 yozamiz, 5 o'tadi. 5 · 7 = 35, 35 + 5 = 40. Javob 406. «356» — o'tkazish unutilgan; «4056» — 40 va 56 yonma-yon yozilgan; «392» — sonlar adashtirilgan (56 · 7)."},
 tn:"Bolalar o'tkazilgan sonni kichik qilib ustunning tepasiga yozsin va qo'shgandan keyin uni o'chirsin."},
{h:"Tuzoq: o'tkazishda adashish",sum:"38 · 4 = 152. Xatolar: 122 (o'tkazish unutilgan), 1232 (yonma-yon), 242 (avval qo'shib, keyin ko'paytirilgan).",a:"m05",start:function(){bqExpr(['38 · 4 = ?','Ali: 122   Vali: 1232','Sami: 242   Lola: 152']);bqMsg('Kim to‘g‘ri hisobladi?')},fin:function(){w3Mul(38,4,null);bqMsg('8 · 4 = 32 → 2, 3 o‘tadi; 3 · 4 + 3 = 15: <b>152</b>')},
 html:"<p>To'rt o'quvchi <b>38 · 4</b> ni hisobladi. Kim to'g'ri?</p>",g2:1,
 btns:[["Ali: 122",function(c,d,b){w3c3c(b,d,0,'','3 · 4 = 12, lekin o‘tgan 3 unutildi. 12 + 3 = 15 bo‘lishi kerak')}],["Vali: 1232",function(c,d,b){w3c3c(b,d,0,'','12 va 32 yonma-yon yozilgan — 32 dan faqat 2 yoziladi, 3 o‘tadi')}],["Sami: 242",function(c,d,b){w3c3c(b,d,0,'','(3 + 3) · 4 = 24 — avval qo‘shib, keyin ko‘paytirgan. Teskari!')}],["Lola: 152",function(c,d,b){w3Mul(38,4,null);w3c3c(b,d,1,'Lola to‘g‘ri: 3 · 4 + 3 = 15 → 152','')}]],
 after:"<p>Tekshirish uchun chamalang: 38 ≈ 40, <b>40 · 4 = 160</b>. Javob 160 ga yaqin bo'lishi kerak — 122 juda kam, 1232 juda ko'p, 242 ham uzoq. 152 — mos.</p>",
 q:{t:"Qaysi javob 69 · 3 ga chamaga ko'ra yaqin?",opts:["207","187","2027","247"],ok:0,why:"70 · 3 = 210 ≈ 207.",hint:"69 ≈ 70. 70 · 3 = ?",full:"Chama 210. Aniq: 9 · 3 = 27 → 7, 2 o'tadi; 6 · 3 + 2 = 20: 207. «187» — o'tkazish ayirilgan; «247» — avval qo'shib, keyin ko'paytirilgan: (6 + 2) · 3 = 24; «2027» — 20 va 27 yonma-yon yozilgan."},
 tn:"Xatolar galereyasi: doskaga 4 ta yechim, bolalar har xatoning sababini o'z so'zi bilan aytsin."},
{h:"Qulay ko'paytirish",sum:"25 · 4 = 100, 5 · 2 = 10: 25 · 7 · 4 = (25 · 4) · 7 = 700.",a:"m06",start:function(){bqExpr(['25 · 7 · 4 = ?']);bqMsg('Qaysi ikkitasini avval ko‘paytirish qulay?')},fin:function(){bqExpr(['25 · 7 · 4','= (25 · 4) · 7','= 100 · 7 = [700]']);bqMsg('Ko‘paytirishda ham o‘rin almashtirish va guruhlash mumkin')},
 html:"<p>Ko'paytirishda ham o'rin almashtirish va guruhlash mumkin. <b>25 · 7 · 4</b> ni qanday hisoblash qulay?</p>",g3:1,
 btns:[["(25 · 7) · 4",function(c,d,b){w3c3c(b,d,0,'','To‘g‘ri, lekin 175 · 4 — qiyin. Do‘st juftni qidiring')}],["(25 · 4) · 7",function(c,d,b){bqExpr(['25 · 7 · 4','= (25 · 4) · 7','= 100 · 7 = [700]']);w3c3c(b,d,1,'25 · 4 = 100 — do‘st juft! 100 · 7 = 700','')}],["25 · (7 + 4)",function(c,d,b){w3c3c(b,d,0,'','Bu boshqa ifoda — 7 va 4 qo‘shilmaydi, ko‘paytiriladi')}]],
 after:"<p>Ko'paytirishdagi «do'st juftlar»: <b>25 · 4 = 100</b>, <b>50 · 2 = 100</b>, <b>5 · 2 = 10</b>, <b>20 · 5 = 100</b>. Ularni avval ko'paytiring.</p>",
 q:{t:"5 · 13 · 2 = ?",opts:["130","65","26","1310"],ok:0,why:"(5 · 2) · 13 = 10 · 13 = 130.",hint:"5 va 2 — do'st juft.",full:"5 · 2 = 10, 10 · 13 = 130. «65» — faqat 5 · 13; «26» — faqat 13 · 2."},
 tn:"«Do'st ko'paytuvchilar» kartochkalari: 25 va 4, 50 va 2, 5 va 2, 20 va 5."},
{h:"Masalada ko'paytirish",sum:"1 ta daftar 24 so'm. 8 ta daftar = 24 · 8 = 192 so'm. 200 so'm berilsa, qaytim 8 so'm.",a:"m07",start:function(){bqBar(null,[{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a}],{title:'8 ta daftar, har biri 24 so‘m'});bqMsg('Jami narx? 200 so‘m yetadimi?')},fin:function(){bqBar(192,[{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a}],{title:'24 · 8 = 192 so‘m'});bqMsg('200 − 192 = 8 so‘m qaytim')},
 html:"<p>Bitta daftar <b>24 so'm</b>. Kamola 8 ta daftar uchun 200 so'm berdi. Qaytim qancha?</p>",g3:1,
 btns:[["8 so'm",function(c,d,b){bqBar(192,[{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a},{v:'24',w:1,col:C.a}],{title:'24 · 8 = 192 so‘m'});w3c3c(b,d,1,'24 · 8 = 192, 200 − 192 = 8 so‘m','')}],["168 so'm",function(c,d,b){w3c3c(b,d,0,'','200 − 32 = 168? 24 · 8 ni qayta hisoblang: 4 · 8 = 32, 2 · 8 + 3 = 19')}],["192 so'm",function(c,d,b){w3c3c(b,d,0,'','192 — bu daftarlar narxi. Savol — qaytim')}]],
 after:"<p>Ikki bosqich: <b>1) narx · soni = qiymat</b> (24 · 8 = 192); <b>2) berilgan − qiymat = qaytim</b> (200 − 192 = 8). Savolni oxirigacha o'qing — oraliq natija javob emas.</p>",
 q:{t:"Bir qutida 36 ta qalam. 7 ta qutidan 50 ta qalam tarqatildi. Nechta qoldi?",opts:["202","252","302","2102"],ok:0,why:"36 · 7 = 252, 252 − 50 = 202.",hint:"Avval jami qalamlarni toping.",full:"36 · 7: 6 · 7 = 42 → 2, 4 o'tadi; 3 · 7 + 4 = 25 → 252. 252 − 50 = 202. «252» — oraliq natija."},
 tn:"Bolalar o'zi narx-son-qiymat jadvalini chizsin."},
{h:"Bilasizmi? Misrcha ikkilantirish",sum:"Qadimgi Misrda ko'paytirish ikkilantirish orqali bajarilgan: 47 · 6 = 47 · 4 + 47 · 2 = 188 + 94 = 282.",a:"m08",start:function(){bqExpr(['47 · 1 = 47','47 · 2 = 94','47 · 4 = 188']);bqMsg('Faqat ikkilantiramiz')},fin:function(){bqExpr(['47 · 2 = 94','47 · 4 = 188','6 = 4 + 2','188 + 94 = [282]']);bqMsg('Ko‘paytirish jadvalisiz ko‘paytirish!')},
 html:"<p>🎓 Qadimgi Misr kotiblari (Rind papirusi, taxminan 3600 yil oldin) ko'paytirish jadvalini yodlamagan. Ular sonni <b>ikkilantirib</b> borib, kerakli qatorlarni qo'shgan.</p>",
 btns:[["💡 47 · 6 ni Misr usulida hisoblang",function(c,done){bqExpr(['47 · 2 = 94','47 · 4 = 188','6 = 4 + 2','188 + 94 = [282]']);bqMsg('Xuddi ustundagi javob: 282');done()}]],
 after:"<p>6 = 4 + 2, shuning uchun 47 · 6 = 47 · 4 + 47 · 2. Bu ham — taqsimot xossasi! Kompyuterlar ham ichida shunga o'xshash «ikkilantirish» bilan ko'paytiradi.</p>",
 tn:"Kuchli o'quvchilarga: 35 · 7 ni Misr usulida (7 = 4 + 2 + 1)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w3Mul(47,6,null);bqMsg('O‘ngdan chapga; o‘tkazishni ko‘paytirgandan keyin qo‘shing')},fin:function(){w3Mul(47,6,null);bqMsg('O‘ngdan chapga; o‘tkazishni ko‘paytirgandan keyin qo‘shing')},
 html:"<div class='memo'><ul><li>30 · 4 = 3 · 4 o'nlik = 120.</li><li><b>23 · 4 = 20 · 4 + 3 · 4</b> = 80 + 12 = 92.</li><li>Ustunda: o'ngdan chapga, har raqamni ko'paytiramiz.</li><li>O'tkazilgan son <b>ko'paytirilgandan keyin</b> qo'shiladi: 4 · 6 + 4.</li><li>Chamalang: 38 · 4 ≈ 40 · 4 = 160.</li><li>Do'st juftlar: 25 · 4 = 100, 5 · 2 = 10.</li></ul></div>",
 tn:"Uyga: 5 ta misol — har birida avval chama, keyin aniq javob."}
];
var PROBS=[
{t:"40 · 7 = ?",o:["280","28","2800","47"],k:0,s:"4 · 7 = 28 o'nlik = 280."},
{t:"21 · 4 = ?",o:["84","81","44","804"],k:0,s:"20 · 4 + 1 · 4 = 84."},
{t:"34 · 2 = ?",o:["68","64","38","618"],k:0,s:"68."},
{t:"26 · 3 = ?",o:["78","68","618","98"],k:0,s:"6 · 3 = 18 → 8, 1 o'tadi; 2 · 3 + 1 = 7: 78."},
{t:"45 · 6 = ?",o:["270","240","2430","300"],k:0,s:"5 · 6 = 30 → 0, 3 o'tadi; 4 · 6 + 3 = 27: 270."},
{t:"78 · 9 = ?",o:["702","632","6372","792"],k:0,s:"8 · 9 = 72 → 2, 7 o'tadi; 7 · 9 + 7 = 70: 702."},
{t:"Qaysi ifoda 37 · 5 ga teng?",o:["30 · 5 + 7 · 5","30 · 5 + 7","3 · 5 + 7 · 5","37 + 5 · 5"],k:0,s:"Taqsimot: 150 + 35 = 185."},
{t:"64 · 8 = ?",o:["512","482","4832","544"],k:0,s:"4 · 8 = 32 → 2, 3 o'tadi; 6 · 8 + 3 = 51: 512."},
{t:"Ali 29 · 4 ni 86 deb hisobladi. Qaysi xatoni qildi?",o:["O'tkazilgan 3 ni unutdi","Avval qo'shib, keyin ko'paytirdi","Yonma-yon yozdi","Xato qilmadi"],k:0,s:"To'g'ri: 9 · 4 = 36 → 6, 3 o'tadi; 2 · 4 + 3 = 11: 116. Ali 2 · 4 = 8 deb, 3 ni qo'shmagan."},
{t:"25 · 9 · 4 = ?",o:["900","225","100","925"],k:0,s:"(25 · 4) · 9 = 900."},
{t:"Bir avtobusda 48 o'rin. 6 ta avtobusda nechta o'rin?",o:["288","248","2448","54"],k:0,s:"48 · 6 = 288."},
{t:"Bir kitob 85 so'm. 5 ta kitob uchun 500 so'm berildi. Qaytim?",o:["75 so'm","425 so'm","85 so'm","415 so'm"],k:0,s:"85 · 5 = 425, 500 − 425 = 75."},
{t:"Qaysi ko'paytma eng katta?",o:["39 · 8","42 · 7","56 · 5","68 · 4"],k:0,s:"312, 294, 280, 272."},
{t:"□ · 6 = 96. □ = ?",o:["16","15","17","90"],k:0,s:"16 · 6 = 96."},
{t:"7□ · 3 = 2□4 (□ — bir xil raqam emas). 7□ = ?",o:["78","74","76","72"],k:0,s:"78 · 3 = 234. 74 · 3 = 222, 76 · 3 = 228, 72 · 3 = 216 — oxiri 4 emas."},
{t:"Bir tomoni 17 sm bo'lgan kvadratning perimetri?",o:["68 sm","34 sm","289 sm","51 sm"],k:0,s:"17 · 4 = 68."},
{t:"Lola har kuni 35 bet o'qiydi. Bir haftada nechta bet?",o:["245","215","2135","42"],k:0,s:"35 · 7 = 245."},
{t:"93 · 7 ning chamasi qancha (o'nliklargacha yaxlitlab)?",o:["630","700","560","900"],k:0,s:"90 · 7 = 630 (aniq 651)."},
{t:"(12 + 8) · 6 va 12 · 6 + 8 · 6 — taqqoslang.",o:["Teng: ikkalasi 120","Birinchisi katta","Ikkinchisi katta","Birinchisi 56"],k:0,s:"20 · 6 = 120; 72 + 48 = 120."},
{t:"Eng katta ikki xonali sonni eng katta bir xonali songa ko'paytiring.",o:["891","819","881","990"],k:0,s:"99 · 9 = 891."}
];
PROBS[14]={t:"7□ · 3 = 2□4 — □ o'rnida turli raqamlar bo'lishi mumkin. Birinchi ko'paytuvchi qaysi?",o:["78","74","76","72"],k:0,s:"78 · 3 = 234 ✓ (oxiri 4). 74 · 3 = 222, 76 · 3 = 228, 72 · 3 = 216."};
function PRACT_STAGE(){w3Mul(47,6,null);bqMsg('Avval chamalang, keyin ustunda hisoblang')}
var PREP_DATA={teach:["Yaxlit o'nliklarni ko'paytirish (30 · 4).","Maydon modeli va taqsimot xossasi: 23 · 4 = 80 + 12.","Ustunda ko'paytirish, o'tkazish bilan.","Chamalash, qulay guruhlash (25 · 4), ikki bosqichli masalalar."],
 mist:["O'tkazilgan sonni unutadi.","Avval o'tkazilganni qo'shib, keyin ko'paytiradi.","Qisman ko'paytmalarni yonma-yon yozadi (1232).","Faqat o'nliklarni ko'paytirib, birliklarni qo'shadi."],
 need:["O'nlik bog'lamlar (10 talik cho'p).","Katakli qog'oz maydon modeli uchun."],
 board:["<span class='w2'>30 · 4 = 120</span>","<span class='w2'>23 · 4 = 20 · 4 + 3 · 4 = 92</span>","<span class='w2'>47 · 6 = 282</span>","<span class='w2'>38 · 4 ≈ 40 · 4 = 160</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
