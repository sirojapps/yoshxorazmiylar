// --- k2c15_ yordamchilari ---
function k2c15_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c15_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c15_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c15_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C15',TITLE='2-sinf · Yig‘indini songa ko‘paytirish, taqsimot xossasi';
// maydon (area) modeli: r qator, a + b ustun
function k2c15_area(r,a,b,o){o=o||{};clear();var g=S.g,tot=a+b,W=280,u=Math.min(W/tot,110/r),x0=180-u*tot/2,y0=22;
 E('rect',{x:x0,y:y0,width:u*a,height:u*r,fill:o.ca||C.b,stroke:C.line,'stroke-width':1.5},g);E('rect',{x:x0+u*a,y:y0,width:u*b,height:u*r,fill:o.cb||C.a,stroke:C.line,'stroke-width':1.5},g);
 if(o.grid)for(var i=0;i<r;i++)for(var j=0;j<tot;j++)E('rect',{x:x0+j*u,y:y0+i*u,width:u,height:u,fill:'none',stroke:'rgba(0,0,0,.15)','stroke-width':.6},g);
 T(g,x0+u*a/2,y0-6,o.la||String(a),{'font-size':12,'font-weight':800,fill:'#2c5d8a'});T(g,x0+u*a+u*b/2,y0-6,o.lb||String(b),{'font-size':12,'font-weight':800,fill:C.a2});T(g,x0-12,y0+u*r/2+4,o.lr||String(r),{'font-size':12,'font-weight':800});
 if(o.ta)T(g,x0+u*a/2,y0+u*r/2+5,o.ta,{'font-size':13,'font-weight':800,fill:'#fff'});if(o.tb)T(g,x0+u*a+u*b/2,y0+u*r/2+5,o.tb,{'font-size':13,'font-weight':800,fill:'#fff'});
 if(o.cap)T(g,180,166,o.cap,{'font-size':13,'font-weight':800,fill:C.blue})}
var P1=[function(){k2c15_area(3,4,2,{grid:1,cap:'3 qator, har birida 4 + 2 ta'});k2c15_big('3 · (4 + 2) = ?')},
 function(){k2c15_area(3,4,2,{grid:1,ta:'12',tb:'6',cap:'ko‘k: 3 · 4 = 12, sariq: 3 · 2 = 6'});k2c15_big('3 · 4 + 3 · 2 = 12 + 6 = <b>18</b>','Usul 1: har bo‘lakni alohida')},
 function(){k2c15_area(3,4,2,{grid:1,cap:'butun: 3 · 6 = 18'});k2c15_big('3 · (4 + 2) = 3 · 6 = <b>18</b> ✓','Usul 2: avval qavs. Javob bir xil!')}];
var P3=[function(){k2c15_area(7,10,2,{la:'10',lb:'2',lr:'7',cap:'7 · 12 = ?'});k2c15_big('7 · 12 = ?','12 ni 10 va 2 ga ajratamiz')},
 function(){k2c15_area(7,10,2,{la:'10',lb:'2',lr:'7',ta:'70',tb:'14',cap:'7 · 10 = 70, 7 · 2 = 14'});k2c15_big('7 · 12 = 7 · 10 + 7 · 2 = 70 + 14 = <b>84</b>')}];
var P4=[function(){k2c15_area(9,20,0.001,{la:'20',lb:'',lr:'9',cap:'9 · 19 — 19 ga yaqin yaxlit son: 20'});k2c15_big('9 · 19 = ?','19 = 20 − 1')},
 function(){k2c15_area(9,19,1,{la:'19',lb:'1',lr:'9',cb:'#e9e2d6',ta:'?',tb:'9',cap:'9 · 20 = 180, ortiqcha 9 · 1 = 9'});k2c15_big('9 · 19 = 9 · 20 − 9 · 1 = 180 − 9 = <b>171</b>')}];
var P5=[function(){k2c15_big('4 · 7 + 4 · 13 + 4 · 20 = ?','Har bir hadda 4 bor!');k2c15_area3([7,13,20],false)},function(){k2c15_area3([7,13,20],true);k2c15_big('4 · (7 + 13 + 20) = 4 · 40 = <b>160</b>','Umumiy ko‘paytuvchini qavsdan tashqariga chiqaramiz')}];
var P6=[function(){k2c15_big('8 · 4 + 5 · 8 − 7 · 8 = ?','Uchala hadda 8 bor');clear();T(S.g,180,90,'8·4 + 5·8 − 7·8',{'font-size':26,'font-weight':800})},
 function(){clear();T(S.g,180,90,'8 · (4 + 5 − 7)',{'font-size':28,'font-weight':800,fill:C.blue});k2c15_big('= 8 · (4 + 5 − 7)','5 · 8 = 8 · 5, 7 · 8 = 8 · 7 — o‘rin almashtirdik')},
 function(){clear();T(S.g,180,90,'8 · 2 = 16',{'font-size':30,'font-weight':800,fill:C.ok});k2c15_big('8 · (4 + 5 − 7) = 8 · 2 = <b>16</b>')}];
var P7=[function(){clear();T(S.g,180,70,'34·18 − 33·18',{'font-size':22,'font-weight':800});T(S.g,180,120,'+ 16·14 − 14·14',{'font-size':22,'font-weight':800});k2c15_big('Juftlarga qarang!')},
 function(){clear();T(S.g,180,70,'18 · (34 − 33) = 18',{'font-size':22,'font-weight':800,fill:C.blue});T(S.g,180,120,'14 · (16 − 14) = 28',{'font-size':22,'font-weight':800,fill:C.a2});k2c15_big('18 · 1 = 18, &nbsp; 14 · 2 = 28')},
 function(){clear();T(S.g,180,96,'18 + 28 = 46',{'font-size':30,'font-weight':800,fill:C.ok});k2c15_big('Javob: <b>46</b> — katta ko‘paytirishlarsiz!')}];
function k2c15_area3(v,join){clear();var g=S.g,u=6.8,x=20,cols=[C.b,C.a,C.c];v.forEach(function(a,i){E('rect',{x:x,y:40,width:a*u,height:4*14,fill:cols[i],stroke:C.line},g);T(g,x+a*u/2,34,String(a),{'font-size':12,'font-weight':800});x+=a*u+(join?0:6)});T(g,12,72,'4',{'font-size':12,'font-weight':800});
 if(join)Br(20,20+40*u,100,'7 + 13 + 20 = 40',false)}
var STEPS=[
{h:"Yig'indini songa ko'paytirish",sum:"3 · (4 + 2) = 3 · 4 + 3 · 2 = 18. Massivni ikki rangga bo'lsak — natija o'zgarmaydi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Massiv: <b>3 qator</b>, har qatorda <b>4 ta ko'k + 2 ta sariq</b>. Hammasi nechta? Ikki xil hisoblaymiz.</p>",btns:[phaser(P1)],
 after:"<p>Ikki yo'l ham 18 berdi: <b>3 · (4 + 2) = 3 · 4 + 3 · 2</b>. Bu — <b>taqsimot xossasi</b>: ko'paytuvchi yig'indining har bir qo'shiluvchisiga «taqsimlanadi».</p>",
 q:{t:"5 · (3 + 4) ga qaysi ifoda teng?",opts:["5 · 3 + 5 · 4","5 · 3 + 4","5 + 3 + 4","5 · 3 · 4"],ok:0,why:"5 har ikki qo'shiluvchiga ko'paytiriladi.",hint:"Massivni ikki rangga ajrating: har rang nechta?",full:"5 · (3 + 4) = 5 · 3 + 5 · 4 = 15 + 20 = 35. «5 · 3 + 4» — 4 ni ko'paytirish unutilgan (19)."},
 tn:"Singapur va Yaponiyada taqsimot xossasi «maydon modeli» (to'rtburchak) bilan o'rgatiladi. Katakli qog'ozda bolalar to'rtburchakni rangli qilib bo'lsin."},
{h:"Ikki yo'l: qaysi biri qulay?",sum:"(5 + 3) · 4 = 8 · 4 = 32 yoki 5 · 4 + 3 · 4 = 20 + 12 = 32.",a:"m02",
 start:function(){k2c15_area(4,5,3,{grid:1,lr:'4'});k2c15_big('(5 + 3) · 4 = ?')},fin:function(){k2c15_area(4,5,3,{grid:1,lr:'4',ta:'20',tb:'12'});k2c15_big('20 + 12 = 32 = 8 · 4')},
 html:"<p>Yig'indini songa ko'paytirishning ikki yo'li bor. Ikkalasini sinab ko'ring:</p>",
 btns:[["Avval qavs",function(c,d){k2c15_area(4,5,3,{grid:1,lr:'4',cap:'8 · 4 = 32'});k2c15_big('(5 + 3) · 4 = 8 · 4 = <b>32</b>');mvK(d,2)}],["Har birini",function(c,d){k2c15_area(4,5,3,{grid:1,lr:'4',ta:'20',tb:'12',cap:'20 + 12 = 32'});k2c15_big('5 · 4 + 3 · 4 = 20 + 12 = <b>32</b>');mvK(d,2)}]],g2:1,
 after:"<p>Natija bir xil! Qaysi yo'l <b>osonroq</b> bo'lsa, o'shani tanlang. Ba'zan qavs ichini hisoblash oson (5 + 3 = 8), ba'zan esa — bo'laklab ko'paytirish.</p>",
 q:{t:"(6 + 4) · 7 ni eng oson usulda hisoblang.",opts:["70","46","42","28"],ok:0,why:"6 + 4 = 10, 10 · 7 = 70.",hint:"Qavs ichida 10 chiqmaydimi?",full:"Qavs ichi 10 — juda qulay: 10 · 7 = 70. «46» — faqat 6 · 7 + 4 (4 ko'paytirilmagan)."},
 tn:"Bolalarga «aqlli yo'lni tanla» deng — bu og'zaki hisob ko'nikmasini o'stiradi."},
{h:"Katta sonni bo'laklarga ajratamiz",sum:"7 · 12 = 7 · 10 + 7 · 2 = 70 + 14 = 84.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>7 · 12 jadvalda yo'q. Lekin 12 = 10 + 2! To'rtburchakni ikkiga bo'lamiz.</p>",btns:[phaser(P3)],
 after:"<p>Bu usul bilan istalgan ikki xonali sonni ko'paytirsa bo'ladi: <b>o'nliklar va birliklarga ajrat — ikkalasini ko'paytir — qo'sh</b>. 6 · 14 = 60 + 24 = 84.</p>",
 q:{t:"8 · 13 nechaga teng?",opts:["104","83","94","24"],ok:0,why:"8 · 10 = 80, 8 · 3 = 24, jami 104.",hint:"13 ni 10 va 3 ga ajrating.",full:"8 · 13 = 8 · 10 + 8 · 3 = 80 + 24 = 104. «83» — 80 + 3 (3 ko'paytirilmagan), «24» — faqat 8 · 3."},
 tn:"Bu 2C16 «ikki xonali sonni bir xonaliga ko'paytirish»ning asosi."},
{h:"Ayirma bilan ham ishlaydi",sum:"9 · 19 = 9 · 20 − 9 = 180 − 9 = 171.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>19 — bu 20 dan bitta kam. 9 · 20 ni hisoblash oson. Ortiqchasini ayiramiz.</p>",btns:[phaser(P4)],
 after:"<p>Taqsimot xossasi ayirmada ham ishlaydi: <b>a · (b − c) = a · b − a · c</b>. 9 · 19 = 180 − 9 = 171. 5 · 29 = 150 − 5 = 145.</p>",
 q:{t:"6 · 29 nechaga teng?",opts:["174","180","168","155"],ok:0,why:"6 · 30 = 180, 180 − 6 = 174.",hint:"29 = 30 − 1.",full:"6 · 29 = 6 · 30 − 6 = 180 − 6 = 174. «180» — 6 ayirilmagan, «168» — 12 ayirilgan."},
 tn:"«9 ga ko'paytirish = 10 ga ko'paytirib, bittasini ayirish» (2C9) — shu xossaning bir ko'rinishi."},
{h:"Teskarisi: umumiy ko'paytuvchi",sum:"4 · 7 + 4 · 13 + 4 · 20 = 4 · (7 + 13 + 20) = 4 · 40 = 160.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Bank savoli: <b>4 · 7 + 4 · 13 + 4 · 20</b> ni qulay usulda hisoblang. Uchta ko'paytirish o'rniga bitta!</p>",btns:[phaser(P5)],
 after:"<p>Har bir hadda bir xil son (4) bo'lsa, uni <b>qavsdan tashqariga chiqaramiz</b>: 4 · (7 + 13 + 20). Qavs ichi 40 — qulay! 4 · 40 = <b>160</b>.</p>",
 q:{t:"Qulay usulda: 6 · 15 + 6 · 5",opts:["120","90","30","180"],ok:0,why:"6 · (15 + 5) = 6 · 20 = 120.",hint:"Ikkala hadda qaysi son bor?",full:"6 · 15 + 6 · 5 = 6 · (15 + 5) = 6 · 20 = 120. «90» — faqat 6 · 15."},
 tn:"Bolalar har bir hadda umumiy sonni doiraga olsin — keyin qavsga chiqarsin."},
{h:"Tuzoq: o'rin almashgan ko'paytuvchilar",sum:"8 · 4 + 5 · 8 − 7 · 8 = 8 · (4 + 5 − 7) = 16.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bank savoli: <b>8 · 4 + 5 · 8 − 7 · 8</b>. 8 har joyda — lekin ba'zida oldinda, ba'zida orqada. Bu xalaqit beradimi?</p>",btns:[phaser(P6)],
 after:"<p>O'rin almashtirish xossasi tufayli 5 · 8 = 8 · 5. Demak 8 ni uchala haddan chiqarsa bo'ladi: 8 · (4 + 5 − 7) = 8 · 2 = <b>16</b>.</p>",
 q:{t:"Hisoblang: 9 · 7 + 3 · 9 − 9 · 10",opts:["0","90","9","63"],ok:0,why:"9 · (7 + 3 − 10) = 9 · 0 = 0.",hint:"9 ni qavsdan chiqaring. Qavs ichi nechaga teng?",full:"9 · 7 + 9 · 3 − 9 · 10 = 9 · (7 + 3 − 10) = 9 · 0 = 0. Tekshiruv: 63 + 27 − 90 = 0 ✓."},
 tn:"Javobni ikki usulda — to'g'ridan-to'g'ri va qavs bilan — tekshirish odatini shakllantiring."},
{h:"Tuzoq: ikki juft birdaniga",sum:"34 · 18 − 33 · 18 + 16 · 14 − 14 · 14 = 18 · 1 + 14 · 2 = 46.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Bank (qiyin) savoli: <b>34 · 18 − 33 · 18 + 16 · 14 − 14 · 14</b>. To'rtta katta ko'paytirish? Yo'q — juftlarni topamiz!</p>",btns:[phaser(P7)],
 after:"<p>Birinchi juftda 18 umumiy: 18 · (34 − 33) = 18. Ikkinchi juftda 14 umumiy: 14 · (16 − 14) = 28. Javob: <b>46</b>. Hech qanday katta ko'paytirishsiz!</p>",
 q:{t:"Qulay usulda: 25 · 13 − 25 · 9",opts:["100","25","325","4"],ok:0,why:"25 · (13 − 9) = 25 · 4 = 100.",hint:"25 ni qavsdan chiqaring.",full:"25 · 13 − 25 · 9 = 25 · (13 − 9) = 25 · 4 = 100. «4» — qavs ichi, lekin 25 ga ko'paytirish unutilgan."},
 tn:"Olimpiadalarda bunday misollar ko'p. Bolalar avval «qaysi son takrorlanyapti?» deb so'rasin."},
{h:"Bilasizmi? Misrliklarning ko'paytirishi",sum:"Qadimgi Misrda ko'paytirish ikkilantirish va qo'shish bilan bajarilgan — bu ham taqsimot xossasi.",a:"m08",
 start:function(){k2c15_egy(false)},fin:function(){k2c15_egy(true)},
 html:"<p>🏺 Qadimgi Misrda (3500 yil oldin) ko'paytirish jadvalini bilishmagan! 13 · 7 ni shunday hisoblashgan: 7 ni ikkilantirib borishgan va keraklilarini qo'shishgan. Tugmani bosing:</p>",
 btns:[["🏺 Misrcha ko'paytir",function(c,d){k2c15_egy(true);d()}]],
 after:"<p>13 = 8 + 4 + 1, shuning uchun 13 · 7 = 8 · 7 + 4 · 7 + 1 · 7 = 56 + 28 + 7 = <b>91</b>. Bu — aynan <b>taqsimot xossasi</b>! U 3500 yildan beri ishlaydi.</p>",
 tn:"Kuchli bolalar 11 · 6 ni misrcha hisoblab ko'rsin: 11 = 8 + 2 + 1."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c15_area(3,4,2,{grid:1,ta:'12',tb:'6'});k2c15_big('3 · (4 + 2) = 3 · 4 + 3 · 2')},fin:function(){k2c15_area(3,4,2,{grid:1,ta:'12',tb:'6'});k2c15_big('3 · (4 + 2) = 3 · 4 + 3 · 2')},
 html:"<div class='memo'><ul><li><b>Taqsimot xossasi:</b> a · (b + c) = a · b + a · c.</li><li>Ayirmada ham: a · (b − c) = a · b − a · c.</li><li>Katta sonni ajrating: 7 · 12 = 70 + 14 = 84.</li><li>Yaxlitga yaqin son: 9 · 19 = 180 − 9 = 171.</li><li><b>Teskarisi</b> — umumiy ko'paytuvchini qavsdan chiqaring: 4 · 7 + 4 · 13 + 4 · 20 = 4 · 40.</li><li>Ko'paytuvchi oldinda yoki orqada bo'lishi farqsiz: 5 · 8 = 8 · 5.</li></ul></div>",
 tn:"Keyingi darsni «12 · 11 + 12 · 9» bilan boshlang (12 · 20 = 240)."}
];
function k2c15_egy(on){clear('#f6ead0');var g=S.g,rows=[[1,7],[2,14],[4,28],[8,56]],use=[1,0,1,1];
 rows.forEach(function(r,i){var y=30+i*30,u=on&&use[i];T(g,120,y,String(r[0]),{'font-size':16,'font-weight':800,fill:u?C.ok:'#6b3d12'});T(g,220,y,String(r[1]),{'font-size':16,'font-weight':800,fill:u?C.ok:'#6b3d12'});if(u)T(g,270,y,'✓',{'font-size':16,'font-weight':800,fill:C.ok})});
 k2c15_big(on?'1 + 4 + 8 = 13 → 7 + 28 + 56 = <b>91</b>':'13 · 7 = ? Ikkilantiramiz: 7, 14, 28, 56')}
var PROBS=[
{t:"3 · (5 + 2) nechaga teng?",o:["21","17","30","10"],k:0,s:"3 · 7 = 21 yoki 15 + 6 = 21."},
{t:"4 · (10 + 3) nechaga teng?",o:["52","43","17","40"],k:0,s:"40 + 12 = 52."},
{t:"(7 + 3) · 6 nechaga teng?",o:["60","45","42","16"],k:0,s:"10 · 6 = 60."},
{t:"6 · 12 nechaga teng?",o:["72","62","18","612"],k:0,s:"6 · 10 + 6 · 2 = 60 + 12 = 72."},
{t:"5 · 19 nechaga teng?",o:["95","100","90","24"],k:0,s:"5 · 20 − 5 = 100 − 5 = 95."},
{t:"Qaysi ifoda 7 · (4 + 5) ga teng?",o:["7 · 4 + 7 · 5","7 · 4 + 5","7 + 4 · 5","7 · 4 · 5"],k:0,s:"7 har qo'shiluvchiga ko'paytiriladi."},
{t:"Qulay usulda: 4 · 7 + 4 · 13 + 4 · 20",o:["160","152","168","164"],k:0,s:"4 · (7 + 13 + 20) = 4 · 40 = 160."},
{t:"Hisoblang: 8 · 4 + 5 · 8 − 7 · 8",o:["16","8","32","24"],k:0,s:"8 · (4 + 5 − 7) = 8 · 2 = 16."},
{t:"Qulay usulda: 34 · 18 − 33 · 18 + 16 · 14 − 14 · 14",o:["46","44","32","48"],k:0,s:"18 · 1 + 14 · 2 = 18 + 28 = 46."},
{t:"Qulay usulda: 14 · 7 + 7 · 18 − 31 · 7 + 88 · 4",o:["359","345","366","352"],k:0,s:"7 · (14 + 18 − 31) = 7 · 1 = 7; 88 · 4 = 352; 7 + 352 = 359."},
{t:"Qulay usulda: 9 · 6 + 9 · 4",o:["90","54","36","81"],k:0,s:"9 · (6 + 4) = 9 · 10 = 90."},
{t:"Hisoblang: 7 · (60 + 20)",o:["560","440","540","630"],k:0,s:"7 · 80 = 560."},
{t:"Qulay usulda: 25 · 13 − 25 · 9",o:["100","25","325","4"],k:0,s:"25 · 4 = 100."},
{t:"Har bir qatorda 8 ta ko'k va 2 ta qizil stul. 6 qatorda nechta stul?",o:["60","48","16","50"],k:0,s:"6 · (8 + 2) = 6 · 10 = 60."},
{t:"3 · 99 ni qulay usulda hisoblang.",o:["297","300","303","299"],k:0,s:"3 · 100 − 3 = 297."},
{t:"Qaysi tenglik NOTO'G'RI?",o:["5 · (4 + 6) = 5 · 4 + 6","5 · (4 + 6) = 50","5 · (4 + 6) = 20 + 30","5 · (4 + 6) = 5 · 10"],k:0,s:"5 · 4 + 6 = 26, 50 emas — 6 ko'paytirilmagan."},
{t:"Hisoblang: 12 · 11 + 12 · 9",o:["240","132","108","228"],k:0,s:"12 · (11 + 9) = 12 · 20 = 240."},
{t:"Bir daftar 5 ming so'm, bir qalam 3 ming so'm. 7 ta daftar va 7 ta qalam necha ming so'm?",o:["56","35","21","15"],k:0,s:"7 · (5 + 3) = 7 · 8 = 56 ming so'm."},
{t:"6 · 14 ni qanday hisoblash to'g'ri?",o:["60 + 24","60 + 4","6 + 14","64 + 24"],k:0,s:"6 · 14 = 6 · 10 + 6 · 4 = 60 + 24 = 84."},
{t:"Hisoblang: 9 · 7 + 3 · 9 − 9 · 10",o:["0","90","9","63"],k:0,s:"9 · (7 + 3 − 10) = 9 · 0 = 0."}
];
function PRACT_STAGE(){k2c15_area(3,4,2,{grid:1,ta:'12',tb:'6'});k2c15_msg('a · (b + c) = a · b + a · c')}
var PREP_DATA={teach:["Yig'indini songa ko'paytirish: ikki yo'l.","Taqsimot xossasi maydon modeli bilan; ayirmada ham.","Katta sonni ajratib ko'paytirish (7 · 12), yaxlitga yaqin son (9 · 19).","Teskari: umumiy ko'paytuvchini qavsdan chiqarish; olimpiada tipidagi juftlar."],
 mist:["Faqat birinchi qo'shiluvchini ko'paytiradi: 5 · (4 + 6) = 20 + 6.","Ayirmada noto'g'ri sonni ayiradi.","Umumiy ko'paytuvchi orqada turganini ko'rmaydi (5 · 8).","Qavsdan chiqargach, ko'paytirishni unutadi."],
 need:["Katakli qog'oz va rangli qalam.","Maydon modeli chizmalari."],
 board:["Maydon: <span class='w2'>3 × (4 + 2) = 12 + 6 = 18</span>.","<span class='w2'>7 · 12 = 70 + 14 = 84</span>.","<span class='w2'>9 · 19 = 180 − 9 = 171</span>.","<span class='w2'>4·7 + 4·13 + 4·20 = 4 · 40 = 160</span>.","<span class='w2'>8 · (4 + 5 − 7) = 16</span>."]};
