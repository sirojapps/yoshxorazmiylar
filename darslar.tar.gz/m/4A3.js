var CODE='4A3',TITLE='4-sinf · Sonlar ketma-ketligi va xossalari';
var A43E=['3 457 218','90 005','12 340','708 663','5 000 001','64 896'];
function a43ev(sel){a4cards(A43E,{title:'Juft sonlarni bosing',cols:3,cw:112,fs:15,h:44,onTap:function(i,r){var n=+A43E[i].replace(/ /g,'');if(n%2===0){a4mark(r,true);S.a43s[i]=1;var k=Object.keys(S.a43s).length;msg('Oxirgi raqam '+(n%10)+' — juft. Topildi: '+k+' / 3');if(k===3&&S.a43d)S.a43d()}else{a4mark(r,false);msg('Oxirgi raqam '+(n%10)+' — toq. Faqat oxirgi raqamga qarang!')}}});(sel||[]).forEach(function(i){a4mark(S.cardEls[i],true)})}
function a43chain(nums,q,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(66,340/n),x0=180-n*cw/2,y=70;
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 nums.forEach(function(v,i){var isq=v==='?';E('rect',{x:x0+i*cw+4,y:y,width:cw-8,height:40,rx:8,fill:isq?'#fff':'#eef4fb',stroke:isq?C.bad:'#9fb3c8','stroke-width':isq?2:1.4,'stroke-dasharray':isq?'5 4':''},g);T(g,x0+i*cw+cw/2,y+26,String(v),{'font-size':cw<56?12:15,'font-weight':800,fill:isq?C.bad:'#1d2b3a'});
  if(i<n-1&&o.steps&&o.steps[i]){var xa=x0+i*cw+cw/2,xb=xa+cw;E('path',{d:'M'+(xa+6)+' '+(y-4)+' Q'+(xa+xb)/2+' '+(y-28)+' '+(xb-6)+' '+(y-4),fill:'none',stroke:C.ok,'stroke-width':1.8},g);T(g,(xa+xb)/2,y-26,o.steps[i],{'font-size':11,'font-weight':800,fill:C.ok})}})}
var STEPS=[
{h:"Oldingi va keyingi son",sum:"Keyingi son — 1 ta ko'p, oldingi — 1 ta kam. 1 000 000 dan oldingi: 999 999.",a:"m01",
 start:function(){a4table(1000000,{top:'1 000 000 dan oldingi son?'});msg('1 ni ayirsak, hamma nollar «qarz beradi»')},fin:function(){a4table(999999,{min:7,top:'999 999'});msg('1 000 000 − 1 = <b>999 999</b>')},
 html:"<p>Har bir natural sonning <b>keyingi</b> soni bor (+1). 1 dan boshqa har birining <b>oldingi</b> soni bor (−1). 1 000 000 dan oldingi son qaysi?</p>",
 btns:a4ch(["999 999","9 999 999","100 000","999 000"],0,function(){a4table(999999,{min:7,top:'999 999'});msg('Millionlar sinfi bo‘shab qoladi, olti xonali eng katta son: <b>999 999</b>')},function(i){msg(i===1?'Bu yetti xonali son — milliondan katta!':i===2?'100 000 — bu milliondan 900 000 kam':'999 000 — bu 1 000 kam')}),g2:1,
 after:"<p>Natural sonlar qatori 1, 2, 3, … — <b>cheksiz</b>: eng katta son yo'q, chunki istalgan songa 1 qo'shish mumkin. Ikki qo'shni son farqi doim 1.</p>",
 q:{t:"470 099 dan keyingi son:",opts:["470 100","470 000","471 000","470 0100"],ok:0,why:"99 + 1 = 100 → 470 100.",hint:"Birliklar va o'nliklarda 9 turibdi.",full:"470 099 + 1: 9 + 1 = 10 → o'nliklarga o'tadi, 9 + 1 = 10 → yuzliklarga: 470 100. «471 000» — mingga o'tib ketish; «470 0100» — son bunday yozilmaydi."},
 tn:"Hisoblagich (odometr) rasmi: 0999 → 1000 qanday o'zgaradi."},
{h:"Juft va toq — oxirgi raqam hal qiladi",sum:"Son juft, agar oxirgi raqami 0, 2, 4, 6, 8 bo'lsa.",a:"m02",
 start:function(){S.a43s={};a43ev();msg('Sondagi boshqa raqamlar ahamiyatsiz!')},fin:function(){S.a43s={0:1,2:1,5:1};a43ev([0,2,5]);msg('Juft: 3 457 218, 12 340, 64 896')},
 act:function(c,done){S.a43d=done},
 html:"<p>Qanchalik katta bo'lmasin, juft-toqlikni faqat <b>oxirgi raqam</b> aytadi. Sahnadagi barcha juft sonlarni bosing (3 ta):</p>",
 after:"<p>Nima uchun? Son = (o'nliklar) · 10 + birliklar. 10 — juft, shuning uchun o'nliklar qismi har doim juft; qolgan narsa — <b>oxirgi raqam</b>.</p>",
 q:{t:"5 □ 7 □ — to'rt xonali son juft. Oxirgi □ o'rniga nechta raqam qo'yish mumkin?",opts:["5 ta","4 ta","10 ta","1 ta"],ok:0,why:"0, 2, 4, 6, 8.",hint:"Faqat oxirgi raqam muhim.",full:"Oxirgi raqam juft bo'lishi kerak: 0, 2, 4, 6, 8 — 5 ta. Birinchi □ ixtiyoriy, u juftlikka ta'sir qilmaydi."},
 tn:"Juft sonlarni «juftlik» qilib ikkitadan chiziqcha bilan bog'lash — qoldiq qolmaydi."},
{h:"Juft va toq qo'shilsa…",sum:"juft + juft = juft, toq + toq = juft, juft + toq = toq.",a:"m03",
 start:function(){a4cards(['T + T','J + J','J + T'],{title:'T — toq, J — juft',cw:100});msg('Misol: 7 + 5 = 12, 4 + 6 = 10, 4 + 5 = 9')},fin:function(){a4cards(['T+T=J','J+J=J','J+T=T'],{title:'Natijalar',cw:100});[0,1,2].forEach(function(i){a4mark(S.cardEls[i],true)});msg('Ikki toqning «ortiqcha birligi» juft bo‘ladi')},
 html:"<p>Hisoblamasdan ayting: 135 + 247 + 389 — juftmi yoki toq?</p>",
 btns:a4ch(["toq","juft"],0,function(){a4cards(['T+T=J','J+J=J','J+T=T'],{title:'Natijalar',cw:100});[0,1,2].forEach(function(i){a4mark(S.cardEls[i],true)});msg('Uchta toq: T + T = J, keyin J + T = <b>T</b>. Tekshiring: 771')},function(){msg('Toqlarni juftlab sanang: ikkita toq → juft, uchinchisi qoladi')}),g2:1,
 after:"<p>Qoida: yig'indida <b>toq sonlar soni</b> juft bo'lsa — natija juft, toq bo'lsa — natija toq. Ko'paytmada: biror ko'paytuvchi juft bo'lsa — ko'paytma juft.</p>",
 q:{t:"1 + 3 + 5 + 7 + 9 + 11 — juftmi yoki toqmi?",opts:["juft","toq","0","aniq hisoblash kerak — 35"],ok:0,why:"6 ta toq son — juft son.",hint:"Nechta toq son qo'shilmoqda?",full:"6 ta toq son (juft miqdor) → yig'indi juft. Tekshiramiz: 36. «35» — hisob xatosi."},
 tn:"Bolalarga savol: «7 ta toq son yig'indisi 100 bo'lishi mumkinmi?» (Yo'q — toq bo'ladi)."},
{h:"Tuzoq: oraliqda nechta son?",sum:"2 350 va 2 360 orasida (ularsiz) 9 ta son bor, 10 ta emas.",a:"m04",
 start:function(){w3line(2350,2360,1,[[2350,C.blue],[2360,C.blue]],{big:5,y:96});T(S.g,180,26,'2 350 va 2 360 orasida nechta son?',{'font-size':13,'font-weight':800,fill:C.blue});msg('Chegaralar kirmaydi')},
 fin:function(){w3line(2350,2360,1,[[2350,C.blue],[2360,C.blue]],{big:5,y:96});for(var v=2351;v<2360;v++)E('circle',{cx:S.X(v),cy:96,r:5,fill:C.ok},S.g);T(S.g,180,26,'2 351 … 2 359 — 9 ta',{'font-size':13,'font-weight':800,fill:C.ok});msg('2 360 − 2 350 − 1 = <b>9</b>')},
 html:"<p>2 350 va 2 360 <b>orasida</b> nechta natural son bor (ularning o'zi kirmaydi)?</p>",
 btns:a4ch(["10","9","11"],1,function(){w3line(2350,2360,1,[[2350,C.blue],[2360,C.blue]],{big:5,y:96});for(var v=2351;v<2360;v++)E('circle',{cx:S.X(v),cy:96,r:5,fill:C.ok},S.g);msg('2 351, 2 352, …, 2 359 — <b>9 ta</b>')},function(i){msg(i===0?'2 360 − 2 350 = 10 — bu oraliqlar (qadamlar) soni, sonlar emas!':'Chegaralarni ham sanadingiz — ular kirmaydi')}),g3:1,
 after:"<p>Uchta holat (a &lt; b):<br>• a dan b gacha <b>ikkalasi bilan</b>: b − a + 1<br>• faqat bittasi bilan: b − a<br>• <b>orasida</b> (ikkalasisiz): b − a − 1.<br>«Qadamlar» va «nuqtalar»ni adashtirmang — daraxtlar va oraliqlar masalasi ham shu.</p>",
 q:{t:"Kitobning 48-betidan 75-betigacha (ikkalasi ham) nechta bet bor?",opts:["28","27","26","29"],ok:0,why:"75 − 48 + 1 = 28.",hint:"Ikkala chegara ham kiradi.",full:"75 − 48 = 27 — bu qadamlar. Betlar esa bittaga ko'p: 28. Tekshirish: 48 dan 50 gacha — 48, 49, 50 = 3 ta = 50 − 48 + 1."},
 tn:"Kichik sonlar bilan tekshirish: 1 dan 3 gacha — 3 ta, 3 − 1 = 2 emas. Bank 4A3-turi."},
{h:"Oraliqdagi juft sonlar",sum:"37 dan 63 gacha juft sonlar: 38, 40, …, 62 — 13 ta.",a:"m05",
 start:function(){w3line(36,64,1,[[37,C.blue],[63,C.blue]],{big:4,y:96,fs:10});T(S.g,180,26,'37 … 63: nechta juft son?',{'font-size':13,'font-weight':800,fill:C.blue});msg('Birinchi va oxirgi juft sonni toping')},
 fin:function(){w3line(36,64,1,[[37,C.blue],[63,C.blue]],{big:4,y:96,fs:10});for(var v=38;v<=62;v+=2)E('circle',{cx:S.X(v),cy:96,r:4.5,fill:C.ok},S.g);T(S.g,180,26,'(62 − 38) : 2 + 1 = 13',{'font-size':13,'font-weight':800,fill:C.ok});msg('38, 40, …, 62 — <b>13 ta</b>')},
 html:"<p>37 dan 63 gacha nechta juft son bor?</p>",
 btns:a4ch(["13","14","12","26"],0,function(){w3line(36,64,1,[[37,C.blue],[63,C.blue]],{big:4,y:96,fs:10});for(var v=38;v<=62;v+=2)E('circle',{cx:S.X(v),cy:96,r:4.5,fill:C.ok},S.g);msg('Birinchisi 38, oxirgisi 62: (62 − 38) : 2 + 1 = <b>13</b>')},function(i){msg(i===1?'(63 − 37) : 2 + 1 = 14 — lekin 37 va 63 toq, ular juft emas! 38 dan 62 gacha sanang':i===3?'Bu barcha sonlarning taxminiy soni. Juftlari — yarmi':'Birinchi va oxirgi juftni sanashni unutmang (+1)')}),g2:1,
 after:"<p>Usul: 1) birinchi va oxirgi kerakli sonni topamiz; 2) (oxirgi − birinchi) : qadam + 1. Bu har qanday qadamli qator uchun ishlaydi: 5 ga karralilar, 3 ga karralilar…</p>",
 q:{t:"100 dan 200 gacha (ikkalasi ham) 5 ga karrali nechta son bor?",opts:["21","20","19","100"],ok:0,why:"(200 − 100) : 5 + 1 = 21.",hint:"100, 105, 110, …, 200.",full:"Birinchisi 100, oxirgisi 200, qadam 5: 100 : 5 + 1 = 21. «20» — +1 ni unutish."},
 tn:"Bank 4A3 qiyin turi. Kichik misolda sinab ko'rish: 2 dan 6 gacha juftlar 2, 4, 6 = (6 − 2) : 2 + 1 = 3."},
{h:"Qonuniyatni topamiz",sum:"4 500, 4 250, 4 000, 3 750, … — har safar 250 kam: keyingisi 3 500.",a:"m06",
 start:function(){a43chain(['4 500','4 250','4 000','3 750','?'],null,{title:'Qadamni toping'});msg('Qo‘shni sonlar farqini hisoblang')},fin:function(){a43chain(['4 500','4 250','4 000','3 750','3 500'],null,{title:'Qadam: −250',steps:['−250','−250','−250','−250']});msg('Keyingisi <b>3 500</b>')},
 html:"<p>Qatorni davom ettiring: 4 500, 4 250, 4 000, 3 750, …</p>",
 btns:a4ch(["3 500","3 650","3 750","3 250"],0,function(){a43chain(['4 500','4 250','4 000','3 750','3 500'],null,{title:'Qadam: −250',steps:['−250','−250','−250','−250']});msg('4 500 − 4 250 = 250. Har safar <b>−250</b>')},function(i){msg(i===1?'Qadam −100 emas: 4 500 − 4 250 = ?':'Farqni aniq hisoblang: 4 500 − 4 250')}),g2:1,
 after:"<p>Qonuniyat topish: 1) qo'shni sonlarning <b>farqini</b> yozamiz; 2) farqlar bir xil bo'lmasa — farqlarning farqiga yoki bo'linishga (×2, :2) qaraymiz.</p>",
 q:{t:"Qatorning 10-hadi: 7, 12, 17, 22, …",opts:["52","57","47","50"],ok:0,why:"7 + 9 · 5 = 52.",hint:"1-haddan 10-hadgacha nechta qadam?",full:"Qadam 5. 1-haddan 10-hadga 9 ta qadam: 7 + 9 · 5 = 52. «57» — 10 ta qadam olish (10 · 5)."},
 tn:"Farqlarni sonlar ustiga yoy bilan yozish — vizual qonuniyat."},
{h:"Murakkab qonuniyat",sum:"2, 5, 10, 17, 26, … — farqlar 3, 5, 7, 9: keyingisi 37.",a:"m07",
 start:function(){a43chain(['2','5','10','17','26','?'],null,{title:'Farqlar bir xil emas!'});msg('Farqlar: 3, 5, 7, 9 …')},fin:function(){a43chain(['2','5','10','17','26','37'],null,{title:'Farqlar: +3, +5, +7, +9, +11',steps:['+3','+5','+7','+9','+11']});msg('26 + 11 = <b>37</b>')},
 html:"<p>2, 5, 10, 17, 26, … qatorining keyingi soni qaysi?</p>",
 btns:a4ch(["35","37","36","39"],1,function(){a43chain(['2','5','10','17','26','37'],null,{title:'Farqlar: +3, +5, +7, +9, +11',steps:['+3','+5','+7','+9','+11']});msg('Farqlar har safar 2 ga oshadi: keyingisi +11 → <b>37</b>')},function(i){msg(i===0?'Oxirgi farq 9 edi, keyingisi 9 emas — farqlar o‘syapti':'Farqlarni ketma-ket yozing: 3, 5, 7, 9, …')}),g2:1,
 after:"<p>Farqlar ham qonuniyatga bo'ysunadi: 3, 5, 7, 9, 11 — toq sonlar. (Qiziq: bu sonlar = 1·1+1, 2·2+1, 3·3+1, …)</p>",
 q:{t:"1, 3, 7, 15, 31, … keyingi son:",opts:["63","47","62","61"],ok:0,why:"Har safar ×2 + 1.",hint:"Farqlar: 2, 4, 8, 16 — ular qanday o'zgaradi?",full:"Farqlar 2, 4, 8, 16 — har safar 2 marta oshadi; keyingisi 32: 31 + 32 = 63. Yoki: 31 · 2 + 1 = 63."},
 tn:"Bolalar o'z qonuniyatini o'ylab, qo'shnisiga topishmoq qilsin."},
{h:"Ketma-ket sonlar topishmog'i",sum:"Ketma-ket uchta sonning yig'indisi 312: o'rtadagisi 312 : 3 = 104.",a:"m08",
 start:function(){bqBar(312,[{v:'?',q:1},{v:'? + 1',q:1},{v:'? + 2',q:1}],{title:'Ketma-ket uchta son: yig‘indisi 312'});msg('Uchta son deyarli teng')},fin:function(){bqBar(312,[{v:'103'},{v:'104'},{v:'105'}],{title:'103 + 104 + 105 = 312'});msg('O‘rtadagisi 312 : 3 = <b>104</b>')},
 html:"<p>Ketma-ket uchta natural sonning yig'indisi 312. Eng kattasi qaysi?</p>",
 btns:a4ch(["104","105","106","103"],1,function(){bqBar(312,[{v:'103'},{v:'104'},{v:'105'}],{title:'103 + 104 + 105 = 312'});msg('O‘rtadagisi 312 : 3 = 104, eng kattasi <b>105</b>')},function(i){msg(i===0?'104 — o‘rtadagisi. Savol — eng kattasi!':i===3?'103 — eng kichigi':'Tekshiring: 104 + 105 + 106 = 315')}),g2:1,
 after:"<p>Eng kichik sondan 1 ni oling, eng kattasiga bering — uchalasi ham o'rtadagiga teng bo'ladi. Shuning uchun o'rtadagi son = <b>yig'indi : 3</b>.</p>",
 q:{t:"Ketma-ket ikkita juft sonning yig'indisi 246. Kichigi qaysi?",opts:["122","123","124","121"],ok:0,why:"122 + 124 = 246.",hint:"Juft sonlar 2 ga farq qiladi.",full:"Ikki son farqi 2: (246 − 2) : 2 = 122, ikkinchisi 124. «123» — yarmi, lekin u toq va juft sonlar 2 ga farq qilishi kerak."},
 tn:"Kubiklar bilan: 3 ta ustun (n, n+1, n+2) ni tekislash."},
{h:"Bilasizmi?",sum:"Kungaboqar urug'lari spirallarining soni ko'pincha Fibonachchi qatoridagi sonlarga teng.",a:"m09",
 start:function(){a43chain(['1','1','2','3','5','8','13','21'],null,{title:'Fibonachchi qatori'});msg('Har bir son — oldingi ikkitasining yig‘indisi')},fin:function(){a43chain(['1','1','2','3','5','8','13','21'],null,{title:'Fibonachchi qatori'});msg('Har bir son — oldingi ikkitasining yig‘indisi')},
 html:"<p>🌻 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, … — bu <b>Fibonachchi qatori</b>: har bir son oldingi ikkitasining yig'indisi. Kungaboqar savatchasidagi urug'lar spirallarini sanasangiz, ko'pincha <b>34 va 55</b> yoki 55 va 89 chiqadi — qo'shni Fibonachchi sonlari. Ananas va qarag'ay qubbasi tangachalarida ham shunday!</p>",
 tn:"Qarag'ay qubbasi olib kelib, spirallarni sanash — tabiat va matematika."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a43chain(['4 500','4 250','4 000','3 750','3 500'],null,{title:'Qadam: −250',steps:['−250','−250','−250','−250']})},fin:function(){a43chain(['4 500','4 250','4 000','3 750','3 500'],null,{title:'Qadam: −250',steps:['−250','−250','−250','−250']})},
 html:"<div class='memo'><ul><li>Keyingi son +1, oldingi −1; natural sonlar cheksiz.</li><li>Juft-toq — faqat oxirgi raqam (0, 2, 4, 6, 8 — juft).</li><li>T + T = J, J + T = T; toqlar soni juft bo'lsa yig'indi juft.</li><li>Orasida: b − a − 1; ikkalasi bilan: b − a + 1.</li><li>Qadamli qatordagi sonlar: (oxirgi − birinchi) : qadam + 1.</li><li>Qonuniyat: farqlarni yozing; farqlarning farqiga qarang.</li><li>Ketma-ket 3 son: o'rtadagi = yig'indi : 3.</li></ul></div>",
 tn:"Keyingi dars — million va milliard sinflari."}
];
var PROBS=[
{t:"1 000 000 dan oldingi son:",o:["999 999","9 999 999","999 000","100 000"],k:0,s:"1 000 000 − 1."},
{t:"470 099 dan keyingi son:",o:["470 100","470 000","471 000","470 199"],k:0,s:"99 + 1 = 100."},
{t:"Qaysi son juft?",o:["5 000 008","3 456 789","1 000 001","24 683"],k:0,s:"Oxirgi raqam 8."},
{t:"135 + 247 + 389 yig'indisi:",o:["toq","juft","700 dan kichik","1 000 dan katta"],k:0,s:"3 ta toq → toq (771)."},
{t:"1 + 3 + 5 + 7 + 9 + 11 yig'indisi:",o:["juft","toq","5 ga karrali","100 dan katta"],k:0,s:"6 ta toq → juft (36)."},
{t:"2 350 va 2 360 orasida (ularsiz) nechta son bor?",o:["9","10","11","8"],k:0,s:"2 360 − 2 350 − 1."},
{t:"Kitobning 48-betidan 75-betigacha (ikkalasi ham) nechta bet?",o:["28","27","26","29"],k:0,s:"75 − 48 + 1."},
{t:"37 dan 63 gacha nechta juft son bor?",o:["13","14","12","26"],k:0,s:"(62 − 38) : 2 + 1."},
{t:"100 dan 200 gacha (ikkalasi ham) 5 ga karrali nechta son?",o:["21","20","19","22"],k:0,s:"100 : 5 + 1."},
{t:"4 500, 4 250, 4 000, 3 750, … keyingi son:",o:["3 500","3 650","3 250","3 600"],k:0,s:"Qadam −250."},
{t:"7, 12, 17, 22, … qatorning 10-hadi:",o:["52","57","47","50"],k:0,s:"7 + 9 · 5."},
{t:"2, 5, 10, 17, 26, … keyingi son:",o:["37","35","36","39"],k:0,s:"Farqlar 3, 5, 7, 9, 11."},
{t:"1, 3, 7, 15, 31, … keyingi son:",o:["63","47","62","61"],k:0,s:"×2 + 1."},
{t:"Ketma-ket uchta sonning yig'indisi 312. Eng kattasi:",o:["105","104","106","103"],k:0,s:"O'rtadagi 104."},
{t:"Ketma-ket ikkita juft sonning yig'indisi 246. Kichigi:",o:["122","123","124","120"],k:0,s:"(246 − 2) : 2."},
{t:"Bir qatorda 25 ta daraxt bor, orasidagi masofa 4 m. Birinchi va oxirgi daraxt orasidagi masofa:",o:["96 m","100 m","104 m","92 m"],k:0,s:"Oraliqlar 24 ta: 24 · 4."},
{t:"7 ta toq sonning yig'indisi 100 bo'lishi mumkinmi?",o:["Yo'q, yig'indi toq bo'ladi","Ha, masalan 7 ta 15","Ha, agar sonlar katta bo'lsa","Faqat 7 ta bir xil son bo'lsa"],k:0,s:"Toqlar soni toq → yig'indi toq, 100 — juft."},
{t:"1 dan 50 gacha barcha sonlar yozildi. Nechta raqam yozilgan?",o:["91","50","100","90"],k:0,s:"1–9: 9 ta, 10–50: 41 son · 2 = 82; jami 91."},
{t:"Qator: 3, 6, 12, 24, … Qaysi son bu qatorda uchraydi?",o:["192","180","200","150"],k:0,s:"3, 6, 12, 24, 48, 96, 192."},
{t:"Eng kichik va eng katta besh xonali juft sonlar orasidagi farq:",o:["89 998","89 999","90 000","99 998"],k:0,s:"99 998 − 10 000 = 89 998."}
];
function PRACT_STAGE(){a43chain(['2','5','10','17','26','37'],null,{title:'Qonuniyat',steps:['+3','+5','+7','+9','+11']})}
var PREP_DATA={teach:["Oldingi/keyingi son (nollar va to'qqizlar bilan).","Juft-toqlik va uning xossalari.","Oraliqdagi sonlarni sanash, qadamli qatorlar, qonuniyat topish, ketma-ket sonlar topishmoqlari."],mist:["Orasidagi sonlar sonini b − a deb oladi.","Juftlikni birinchi raqamga qarab aytadi.","Qatorning n-hadida n ta qadam oladi (n − 1 o'rniga).","Ketma-ket sonlarda o'rtadagini eng katta deb aytadi."],need:["Son o'qi, raqam kartochkalari, kubiklar."],board:["<span class='w2'>orasida: b − a − 1</span>, <span class='w2'>ikkalasi bilan: b − a + 1</span>.","<span class='w2'>T + T = J</span>, <span class='w2'>J + T = T</span>.","<span class='w2'>(62 − 38) : 2 + 1 = 13</span>.","<span class='w2'>103 + 104 + 105 = 312</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
