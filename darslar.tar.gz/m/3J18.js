var CODE='3J18',TITLE='3-sinf · Algoritmlar va blok-sxemalar';
var J18={};
// --- sonli mashina ---
function j18Mach(hist){clear();var g=S.g,cur=hist[hist.length-1];E('rect',{x:110,y:14,width:140,height:66,rx:12,fill:'#e8f0fb',stroke:'#4b8fd9','stroke-width':2.5},g);T(g,180,32,'⚙ MASHINA',{'font-size':12,'font-weight':800,fill:'#2a64a8'});
 T(g,180,52,'juft → : 2',{'font-size':12,'font-weight':800});T(g,180,70,'toq → + 1',{'font-size':12,'font-weight':800});
 T(g,60,54,cur,{'font-size':28,'font-weight':800,fill:cur===1?C.ok:C.bad});T(g,60,74,'hozir',{'font-size':10});E('line',{x1:84,y1:46,x2:106,y2:46,stroke:'#33475b','stroke-width':2.5},g);
 var n=hist.length,w=Math.min(44,320/n),x0=180-n*w/2;hist.forEach(function(v,i){E('rect',{x:x0+i*w+2,y:108,width:w-4,height:30,rx:6,fill:i===n-1?'#fff1c9':'#fff',stroke:'#c8d3de'},g);T(g,x0+i*w+w/2,129,v,{'font-size':14,'font-weight':800})});
 T(g,180,160,'qadamlar: '+(n-1),{'font-size':12,'font-weight':800,fill:'#5b6b7b'})}
// --- blok-sxema zanjiri ---
function j18Chain(cells,ops,o){o=o||{};clear();var g=S.g,n=cells.length,bw=46,gap=(340-n*bw)/(n-1),x0=10;
 cells.forEach(function(v,i){var x=x0+i*(bw+gap);E('rect',{x:x,y:58,width:bw,height:40,rx:i===0||i===n-1?20:6,fill:i===0?'#e1f4f2':(i===n-1?'#fde6e6':'#fff'),stroke:'#33475b','stroke-width':2},g);T(g,x+bw/2,85,v,{'font-size':16,'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(i<n-1){E('line',{x1:x+bw,y1:78,x2:x+bw+gap-4,y2:78,stroke:'#33475b','stroke-width':2},g);E('polygon',{points:(x+bw+gap-2)+',78 '+(x+bw+gap-9)+',73 '+(x+bw+gap-9)+',83',fill:'#33475b'},g);T(g,x+bw+gap/2,52,ops[i],{'font-size':13,'font-weight':800,fill:o.back?C.ok:C.blue});if(o.back)T(g,x+bw+gap/2,118,o.back[i],{'font-size':13,'font-weight':800,fill:C.ok})}});
 if(o.t)T(g,180,150,o.t,{'font-size':12,'font-weight':800,fill:o.tc||'#33475b'});T(g,x0+bw/2,40,'kirish',{'font-size':10});T(g,x0+(n-1)*(bw+gap)+bw/2,40,'chiqish',{'font-size':10})}
var P2=[function(){j18Chain(['10','?','?','?'],['× 3','− 4',': 2']);j2Msg('Blok-sxema: kirishdagi son strelka bo‘yicha har bir amaldan o‘tadi')},
 function(){j18Chain(['10','30','?','?'],['× 3','− 4',': 2']);j2Msg('10 · 3 = 30')},function(){j18Chain(['10','30','26','?'],['× 3','− 4',': 2']);j2Msg('30 − 4 = 26')},
 function(){j18Chain(['10','30','26','13'],['× 3','− 4',': 2']);j2Msg('26 : 2 = <b>13</b>. Tartib muhim: avval × 3, keyin − 4!')}];
// --- shartli sikl ---
function j18Loop(vals,stop){clear();var g=S.g;E('rect',{x:16,y:20,width:96,height:30,rx:15,fill:'#e1f4f2',stroke:'#2b8a7e','stroke-width':2},g);T(g,64,40,'Boshlash: 5',{'font-size':11,'font-weight':800});
 E('rect',{x:24,y:66,width:80,height:28,rx:5,fill:'#fff',stroke:'#33475b','stroke-width':2},g);T(g,64,85,'son × 2',{'font-size':12,'font-weight':800});
 E('polygon',{points:'64,104 116,124 64,144 12,124',fill:'#fff7d6',stroke:'#c9a35a','stroke-width':2},g);T(g,64,128,'> 100 ?',{'font-size':11,'font-weight':800});
 E('line',{x1:64,y1:50,x2:64,y2:66,stroke:'#33475b','stroke-width':2},g);E('line',{x1:64,y1:94,x2:64,y2:104,stroke:'#33475b','stroke-width':2},g);E('path',{d:'M12 124 L4 124 L4 80 L24 80',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,10,116,'yo‘q',{'font-size':9,fill:C.bad,'text-anchor':'start'});
 E('line',{x1:116,y1:124,x2:134,y2:124,stroke:C.ok,'stroke-width':2},g);T(g,124,118,'ha',{'font-size':9,fill:C.ok});E('rect',{x:134,y:112,width:52,height:24,rx:12,fill:'#e3f6ea',stroke:C.ok,'stroke-width':2},g);T(g,160,128,'Tamom',{'font-size':10,'font-weight':800,fill:C.ok});
 vals.forEach(function(v,i){var x=214+(i%3)*48,y=36+Math.floor(i/3)*42;E('rect',{x:x-20,y:y-16,width:40,height:28,rx:6,fill:i===vals.length-1?(stop?'#c8f0d8':'#fff1c9'):'#fff',stroke:'#c8d3de'},g);T(g,x,y+4,v,{'font-size':14,'font-weight':800})})}
var P4=[function(){j18Loop([5]);j2Msg('Romb — <b>shart</b>. «Yo‘q» bo‘lsa, strelka orqaga qaytadi — bu <b>sikl</b> (takrorlash)')},function(){j18Loop([5,10,20]);j2Msg('10 > 100? Yo‘q. 20 > 100? Yo‘q…')},
 function(){j18Loop([5,10,20,40,80]);j2Msg('40, 80 — hali ham 100 dan oshmadi')},function(){j18Loop([5,10,20,40,80,160],1);j2Msg('160 > 100 — <b>Ha</b>! Chiqish: <b>160</b>. Sikl 5 marta bajarildi')}];
// --- daryodan o'tish ---
var J18R=[['🐺🐐🥬','',0,''],['🐺🥬','',1,'🐐'],['🐺🥬','🐐',0,''],['🥬','🐐',1,'🐺'],['🥬','🐺',0,'🐐'],['🐐','🐺',1,'🥬'],['🐐','🐺🥬',0,''],['','🐺🥬',1,'🐐']];
function j18River(i){clear();var g=S.g,s=J18R[i];E('rect',{x:120,y:14,width:120,height:146,fill:'#bfe0f5'},g);E('rect',{x:10,y:14,width:110,height:146,rx:8,fill:'#d9f0c8'},g);E('rect',{x:240,y:14,width:110,height:146,rx:8,fill:'#d9f0c8'},g);
 T(g,65,96,s[0]||'—',{'font-size':26});T(g,295,96,s[1]||'—',{'font-size':26});var bx=s[2]?210:150;T(g,bx,70,'🧑‍🌾',{'font-size':22});T(g,bx,108,'⛵'+(s[3]||''),{'font-size':22});
 T(g,180,32,i?(i+'-safar'):'boshlanish',{'font-size':12,'font-weight':800,fill:'#2a64a8'})}
var J18T=['Dehqon bo‘ri 🐺, echki 🐐 va karamni 🥬 daryodan o‘tkazishi kerak. Qayiqqa faqat bittasini oladi. Bo‘ri echkini, echki karamni yeb qo‘yadi (dehqon yo‘qligida)',
 '1) Echkini olib o‘tadi (bo‘ri karamga tegmaydi)','2) Bo‘sh qaytadi','3) Bo‘rini olib o‘tadi…','4) …va <b>echkini qaytarib oladi</b>! Bu — asosiy hiyla','5) Karamni olib o‘tadi (bo‘ri karamni yemaydi)','6) Bo‘sh qaytadi','7) Echkini olib o‘tadi. ✓ Hammasi narida — <b>7 ta</b> qatnov'];
var P6=J18R.map(function(r,i){return function(){j18River(i);j2Msg(J18T[i])}});
// --- idishlar ---
function j18Jugs(a,b,t){clear();var g=S.g;[[a,5,90,'5 l'],[b,3,250,'3 l']].forEach(function(j){var h=j[1]*22,x=j[2]-30,y=140-h;E('rect',{x:x,y:y,width:60,height:h,rx:6,fill:'#fff',stroke:'#33475b','stroke-width':2.5},g);
  if(j[0])E('rect',{x:x+3,y:140-j[0]*22,width:54,height:j[0]*22-3,rx:3,fill:'#7cc3f0'},g);for(var k=1;k<j[1];k++)E('line',{x1:x,y1:140-k*22,x2:x+8,y2:140-k*22,stroke:'#33475b'},g);
  T(g,j[2],y-8,j[3],{'font-size':12,'font-weight':800});T(g,j[2],160,j[0]+' l',{'font-size':14,'font-weight':800,fill:C.blue})});if(t)T(g,180,24,t,{'font-size':12,'font-weight':800,fill:'#33475b'})}
var J18J=[[0,0,'Ikkala idish bo‘sh. 4 litr suv kerak'],[5,0,'1) 5 l idishni to‘ldiramiz'],[2,3,'2) 3 l idishga quyamiz → 5 l da 2 l qoldi'],[2,0,'3) 3 l idishni to‘kamiz'],[0,2,'4) 2 l ni 3 l idishga quyamiz'],[5,2,'5) 5 l idishni yana to‘ldiramiz'],[4,3,'6) 3 l idishni to‘ldirguncha quyamiz (1 l ketdi) → 4 l ✓']];
var P7=J18J.map(function(j){return function(){j18Jugs(j[0],j[1]);j2Msg(j[2])}});
var STEPS=[
{h:"Sonli mashina",sum:"Juft → : 2, toq → + 1. 13 → 14 → 7 → 8 → 4 → 2 → 1: 6 qadam.",a:"m01",
 start:function(){J18.h=[13];j18Mach(J18.h);j2Msg('Mashinaga 13 kiritildi. Chiqqan son yana kiritiladi. Nechta qadamda <b>1</b> chiqadi?')},
 fin:function(){j18Mach([13,14,7,8,4,2,1]);j2Msg('✓ 6 qadam')},
 html:"<p><b>Algoritm</b> — aniq qoidalar ketma-ketligi. Mashina har safar bitta qoidani bajaradi. Tugmani bosib, uni ishlating:</p>",
 btns:[["⚙ Mashinaga kiritish",function(c,done,b){var h=J18.h,x=h[h.length-1];if(x===1)return;var y=x%2?x+1:x/2;h.push(y);j18Mach(h);j2Msg(x+(x%2?' — toq → + 1 = ':' — juft → : 2 = ')+'<b>'+y+'</b>');if(y===1){b.disabled=true;b.textContent='✓ 1 chiqdi';done()}}]],
 after:"<p>13 → 14 → 7 → 8 → 4 → 2 → 1 — <b>6 qadam</b>. Har qadamda faqat bitta savol: «juftmi?». Kompyuter ham shunday ishlaydi — oddiy qoidalarni juda tez takrorlaydi.</p>",
 q:{t:"Shu mashinaga 9 kiritildi. Nechta qadamdan keyin 1 chiqadi?",opts:["7","6","8","5"],ok:0,why:"9 → 10 → 5 → 6 → 3 → 4 → 2 → 1.",hint:"Har qadamni yozib boring: 9 toq → 10…",full:"9 → 10 → 5 → 6 → 3 → 4 → 2 → 1: 7 ta strelka — 7 qadam. Ko'p xato: boshlang'ich sonni ham qadam deb sanash (8) yoki bittasini tushirib qoldirish (6)."},
 tn:"Bir bola «mashina» bo'lsin: sinf son aytadi, u qoidani bajarib natijani aytadi. Qoidani bolalar topishi ham mumkin."},
{h:"Blok-sxema: amallar zanjiri",sum:"10 → × 3 → − 4 → : 2 → 13. Amallar strelka tartibida bajariladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Blok-sxemada oval — boshlanish/tugash, to'rtburchak — amal, strelka — tartib. Kuzating:</p>",
 btns:[phaser(P2,'▶ Keyingi blok')],
 after:"<p>Tartib almashsa — natija ham o'zgaradi: 10 − 4 = 6, 6 · 3 = 18, 18 : 2 = 9 (13 emas!). Blok-sxema aynan <b>tartibni</b> ko'rsatish uchun kerak.</p>",
 q:{t:"Blok-sxema: 7 → + 5 → × 2 → − 9 → ? Chiqishda qaysi son?",opts:["15","24","12","3"],ok:0,why:"7 + 5 = 12, 12 · 2 = 24, 24 − 9 = 15.",hint:"Strelka bo'yicha birma-bir bajaring.",full:"12 → 24 → 15. «24» — oxirgi amal unutilgan, «12» — faqat birinchi amal bajarilgan, «3» — × 2 tushib qolgan (12 − 9)."},
 tn:"Doskada blok-sxemani chizib, kirishga har xil sonlar yozing — bolalar navbat bilan chiqishni topsin."},
{h:"Orqadan hisoblaymiz",sum:"? → + 7 → × 2 → − 6 → 20: teskari amallar bilan 20 + 6 = 26, 26 : 2 = 13, 13 − 7 = 6.",a:"m03",
 start:function(){j18Chain(['?','?','?','20'],['+ 7','× 2','− 6']);j2Msg('Chiqish ma’lum: 20. Kirish qaysi son edi?')},
 fin:function(){j18Chain(['6','13','26','20'],['+ 7','× 2','− 6'],{back:['− 7',': 2','+ 6'],t:'orqaga: 20 + 6 = 26 → 26 : 2 = 13 → 13 − 7 = 6',tc:C.ok});j2Msg('✓ Kirish: <b>6</b>')},
 html:"<p>Chiqish ma'lum bo'lsa, <b>oxiridan boshlab</b> har amalni <b>teskarisiga</b> almashtiramiz: + ↔ −, × ↔ :. Kirishni tanlang:</p>",
 g2:1,btns:j2Pick(["6","13","26","27"],0,function(){STEPS[2].fin()},function(i){j18Chain(['?','?','?','20'],['+ 7','× 2','− 6']);j2Msg(['','13 — bu ikkinchi katak. Yana bitta amal qoldi: 13 − 7','26 — faqat − 6 ni ochdingiz. Yana : 2 va − 7','27 — teskari amallar tartibi buzilgan: avval + 6, keyin : 2, keyin − 7'][i])}),
 after:"<p>Tekshiramiz: 6 + 7 = 13, 13 · 2 = 26, 26 − 6 = 20 ✓. Orqaga yurishda ham <b>tartib teskari</b>: oxirgi amal birinchi ochiladi.</p>",
 q:{t:"? → × 3 → − 4 → : 2 → 16. Kirishda qaysi son bo'lgan?",opts:["12","20","4","36"],ok:0,why:"16 · 2 = 32, 32 + 4 = 36, 36 : 3 = 12.",hint:"Oxiridan: : 2 ning teskarisi — × 2.",full:"16 · 2 = 32 → 32 + 4 = 36 → 36 : 3 = 12. Tekshirish: 12 · 3 = 36, 36 − 4 = 32, 32 : 2 = 16 ✓. «36» — oxirgi teskari amal (: 3) unutilgan."},
 tn:"«Men son o'yladim…» o'yini: o'qituvchi zanjir aytadi, bolalar orqadan hisoblab sonni topadi."},
{h:"Shart va sikl",sum:"Boshlash 5, × 2, «> 100 ?» yo'q bo'lsa takrorlash: 5, 10, 20, 40, 80, 160 → chiqish 160.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Romb — <b>savol</b> (shart). Javobga qarab yo'l tanlanadi. Agar strelka orqaga qaytsa — amallar <b>takrorlanadi</b>. Kuzating:</p>",
 btns:[phaser(P4,'▶ Keyingi aylanish')],
 after:"<p>Tuzoq: «100 dan oshguncha» degani 100 ning o'zi emas — 80 dan keyin <b>160</b> chiqadi. Sikl 5 marta bajarildi (5 ta ko'paytirish).</p>",
 q:{t:"Boshlash: 1. Amal: + 3. Shart: «natija 20 dan kattami?» Yo'q bo'lsa — takrorlash. Chiqishda qaysi son?",opts:["22","21","19","20"],ok:0,why:"1, 4, 7, 10, 13, 16, 19, 22 — 22 > 20.",hint:"19 > 20 mi? Yo'q — yana bir marta + 3.",full:"1 → 4 → 7 → 10 → 13 → 16 → 19 → 22. 19 hali 20 dan katta emas, shuning uchun yana bir aylanish: 22. «20» — shart sonini javob deb olish."},
 tn:"Sinfda sikl o'yini: «10 marta chapak chal» — bolalar sanab boradi, 10 da to'xtaydi."},
{h:"Tuzoq: bo'ri, echki va karam",sum:"Daryodan o'tkazish: echki →, bo'sh ←, bo'ri →, echki ←, karam →, bo'sh ←, echki → — 7 qatnov.",a:"m05",
 start:function(){startPh(P6)},fin:function(){S.ph=7;P6[7]()},
 html:"<p>Mashhur algoritm jumbog'i. Dehqon qayiqda faqat bittasini olib o'ta oladi. Qanday qilib hammasini butun o'tkazadi? Kuzating:</p>",
 btns:[phaser(P6,'▶ Keyingi qatnov')],
 after:"<p>Kalit hiyla — 4-qatnovda echkini <b>orqaga qaytarish</b>. Ba'zan maqsadga yetish uchun bir qadam orqaga ketish kerak. 7 tadan kam qatnov bilan bo'lmaydi.</p>",
 q:{t:"Nega dehqon birinchi qatnovda aynan echkini olib o'tadi?",opts:["Bo'ri karamni yemaydi — ularni qoldirish xavfsiz","Echki eng og'ir","Bo'ri suvdan qo'rqadi","Karam suzib keta oladi"],ok:0,why:"Faqat bo'ri + karam birga xavfsiz.",hint:"Qirg'oqda qolgan ikkisi bir-birini yemasligi kerak.",full:"Agar bo'rini olsa — echki karamni yeydi; karamni olsa — bo'ri echkini yeydi. Faqat echkini olib ketsa, qolgan bo'ri va karam xavfsiz."},
 tn:"Uchta kartochka (bo'ri, echki, karam) bilan partada o'ynab ko'rishsin. Qadamlarni daftarga yozib borishsin."},
{h:"Tuzoq: idishlar bilan o'lchash",sum:"5 l va 3 l idish bilan 4 l: to'ldir 5 → quy 3 → to'k 3 → quy 2 → to'ldir 5 → quy 3 gacha → 4 l.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=6;P7[6]()},
 html:"<p>Faqat 5 litrlik va 3 litrlik idish bor (bo'linmalari yo'q). Qanday qilib aniq <b>4 litr</b> suv o'lchash mumkin? Qadamlarni kuzating:</p>",
 btns:[phaser(P7,'▶ Keyingi harakat')],
 after:"<p>Hiyla: 5 − 3 = 2 litr «yasab», keyin uni 3 l idishga joylab, «1 litr bo'sh joy» qoldirdik. 5 − 1 = <b>4</b>.</p>",
 q:{t:"3 l idishni ikki marta to'ldirib, har safar bo'sh 5 l idishga quydik (5 l to'lgach, quyishni to'xtatdik). 3 l idishda necha litr qoldi?",opts:["1","2","0","3"],ok:0,why:"Birinchi safar 3 l ketdi; ikkinchi safar 5 l ga faqat 2 l sig'di — 1 l qoldi.",hint:"Birinchi quyishdan keyin 5 l idishda 3 l. Unga yana necha litr sig'adi?",full:"1) 3 l → 5 l idishda 3 l. 2) Yana 3 l, lekin 5 l idishga faqat 2 l sig'adi → 3 l idishda 3 − 2 = 1 l qoladi. «2» — sig'gan miqdorni javob deb olish."},
 tn:"Ikki shisha (0,5 va 0,3 l) va suv bilan amalda sinab ko'ring — bolalar uchun juda yorqin tajriba."},
{h:"Bilasizmi? «Algoritm» so'zi",sum:"«Algoritm» so'zi al-Xorazmiy nomidan kelib chiqqan — uning kitoblari lotinchaga «Algoritmi» deb tarjima qilingan.",a:"m07",
 start:function(){j2Lines([['al-Xorazmiy',C.blue,30],['↓',null,20],['Algoritmi → algoritm',C.ok,20]])},fin:function(){j2Lines([['al-Xorazmiy',C.blue,30],['↓',null,20],['Algoritmi → algoritm',C.ok,20]])},
 html:"<p>📚 IX asrda Bag'doddagi «Bayt ul-hikma» (Donishmandlar uyi)da ishlagan buyuk vatandoshimiz <b>Muhammad ibn Muso al-Xorazmiy</b> hisoblash qoidalari haqida kitob yozgan. Uning kitobi lotin tiliga tarjima qilinganda muallif nomi <b>«Algoritmi»</b> deb yozilgan — bugungi <b>«algoritm»</b> so'zi shundan. «Algebra» so'zi ham uning «al-jabr» kitobidan olingan.</p>",
 btns:[["Tushundim",function(c,done){j2Msg('Har dasturchi har kuni al-Xorazmiy nomini aytadi — «algoritm» deganda!');done()}]],
 after:"<p>Biz ham «Yosh Xorazmiylar» — al-Xorazmiy ishini davom ettiruvchilarmiz.</p>",
 tn:"Xaritada Xorazm va Bag'dodni ko'rsating. Bolalar uyda kundalik ishlaridan biri uchun algoritm yozib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j18Chain(['6','13','26','20'],['+ 7','× 2','− 6'],{back:['− 7',': 2','+ 6']})},fin:function(){j18Chain(['6','13','26','20'],['+ 7','× 2','− 6'],{back:['− 7',': 2','+ 6']})},
 html:"<div class='memo'><ul><li><b>Algoritm</b> — aniq qadamlar ketma-ketligi; tartib muhim.</li><li>Blok-sxema: oval — boshi/oxiri, to'rtburchak — amal, romb — shart.</li><li>Chiqishdan kirishga: oxiridan, <b>teskari</b> amallar bilan.</li><li>Sikl: shart bajarilguncha takrorla; «oshguncha» — chegaraning o'zi emas.</li><li>Qadamlarni sanashda <b>strelkalarni</b> sanang.</li><li>Ba'zan bir qadam orqaga qaytish kerak (echki!).</li></ul></div>",
 tn:"Keyingi dars: bolalar juftlikda bir-biriga blok-sxema tuzib berib, kirish/chiqishni topishsin."}
];
var PROBS=[
{t:"Mashina: son juft bo'lsa 2 ga bo'ladi, toq bo'lsa 1 qo'shadi. 13 kiritildi, natija yana kiritilaverdi. Necha qadamdan keyin 1 chiqadi?",o:["6","5","7","4"],k:0,s:"13 → 14 → 7 → 8 → 4 → 2 → 1."},
{t:"Shu mashinaga (juft — : 2, toq — + 1) 12 kiritildi. Necha qadamdan keyin 1 chiqadi?",o:["5","4","6","12"],k:0,s:"12 → 6 → 3 → 4 → 2 → 1."},
{t:"Shu mashinaga (juft — : 2, toq — + 1) 9 kiritildi. Necha qadamdan keyin 1 chiqadi?",o:["7","6","8","5"],k:0,s:"9 → 10 → 5 → 6 → 3 → 4 → 2 → 1."},
{t:"Blok-sxema: 10 → × 3 → − 4 → : 2 → ? Chiqishda qaysi son?",o:["13","26","30","9"],k:0,s:"30 → 26 → 13."},
{t:"Blok-sxema: 7 → + 5 → × 2 → − 9 → ? Chiqishda qaysi son?",o:["15","24","8","19"],k:0,s:"12 → 24 → 15."},
{t:"? → + 7 → × 2 → − 6 → 20. Kirishda qaysi son?",o:["6","13","26","27"],k:0,s:"20 + 6 = 26, 26 : 2 = 13, 13 − 7 = 6."},
{t:"? → × 3 → − 4 → : 2 → 16. Kirishda qaysi son?",o:["12","20","4","36"],k:0,s:"16 · 2 = 32, + 4 = 36, : 3 = 12."},
{t:"? → : 4 → + 9 → × 5 → 70. Kirishda qaysi son?",o:["20","5","56","14"],k:0,s:"70 : 5 = 14, − 9 = 5, · 4 = 20."},
{t:"Boshlash: 5. Amal: × 2. Natija 100 dan katta bo'lguncha takrorlanadi. Chiqishda qaysi son?",o:["160","80","100","320"],k:0,s:"5, 10, 20, 40, 80, 160."},
{t:"Boshlash: 1. Amal: + 3. Natija 20 dan katta bo'lguncha takrorlanadi. Chiqishda qaysi son?",o:["22","21","19","20"],k:0,s:"1, 4, 7, 10, 13, 16, 19, 22."},
{t:"Boshlash: 1. Amal: + 3. Natija 20 dan katta bo'lguncha takrorlanadi. Amal necha marta bajariladi?",o:["7","6","8","21"],k:0,s:"1 → 4 → 7 → 10 → 13 → 16 → 19 → 22: 7 ta qo'shish."},
{t:"Qoida: son 50 dan katta bo'lsa 20 ni ayir, aks holda 15 ni qo'sh. 38 dan boshlab qoida 2 marta bajarildi. Natija?",o:["33","53","18","68"],k:0,s:"38 → 53 → 33."},
{t:"Qoida: son 50 dan katta bo'lsa 20 ni ayir, aks holda 15 ni qo'sh. 61 dan boshlab qoida 3 marta bajarildi. Natija?",o:["36","41","56","21"],k:0,s:"61 → 41 → 56 → 36."},
{t:"Robot: «3 marta takrorla: 2 qadam o'ngga, 1 qadam yuqoriga». Robot boshlang'ich joydan qayerda?",o:["6 qadam o'ngda va 3 qadam yuqorida","3 qadam o'ngda va 6 qadam yuqorida","2 qadam o'ngda va 1 qadam yuqorida","9 qadam o'ngda"],k:0,s:"O'ngga 3 · 2 = 6, yuqoriga 3 · 1 = 3."},
{t:"Robot: «4 marta takrorla: 3 qadam oldinga yur, o'ngga buril». Robot oxirida qayerda?",o:["boshlang'ich joyida","12 qadam oldinda","3 qadam o'ngda","3 qadam orqada"],k:0,s:"U kvadrat bo'ylab aylanib, joyiga qaytadi."},
{t:"Dehqon bo'ri, echki va karamni daryodan o'tkazishi kerak (qayiqqa bittasini oladi). Eng kamida nechta qatnov (u yoqqa va bu yoqqa) kerak?",o:["7","5","3","9"],k:0,s:"Echki →, bo'sh ←, bo'ri →, echki ←, karam →, bo'sh ←, echki →."},
{t:"3 l idishni ikki marta to'ldirib, har safar bo'sh 5 l idishga quydik (5 l to'lgach, quyishni to'xtatdik). 3 l idishda necha litr qoldi?",o:["1","2","0","3"],k:0,s:"3 l, keyin faqat 2 l sig'adi → 1 l qoladi."},
{t:"Algoritm: «Ikki sondan kattasini kattasidan kichigini ayirgan songa almashtir. Sonlar tenglashguncha takrorla». 12 va 8 dan boshlansa, oxirida qaysi son chiqadi?",o:["4","2","8","20"],k:0,s:"(12, 8) → (4, 8) → (4, 4)."},
{t:"Shu algoritm (kattasini ayirmaga almashtirish) 15 va 9 dan boshlansa, oxirida qaysi son chiqadi?",o:["3","6","1","9"],k:0,s:"(15, 9) → (6, 9) → (6, 3) → (3, 3)."},
{t:"Ikki buyruq bor: «× 2» va «+ 3». 1 sonidan 11 ni olish uchun eng kamida nechta buyruq kerak?",o:["3","2","4","5"],k:0,s:"2 buyruqda faqat 4, 5, 7, 8 chiqadi. 3 ta: 1 + 3 = 4, · 2 = 8, + 3 = 11."}
];
function PRACT_STAGE(){j18Chain(['10','30','26','13'],['× 3','− 4',': 2'])}
var PREP_DATA={teach:["Algoritm — aniq qadamlar ketma-ketligi.","Blok-sxema belgilari: oval, to'rtburchak, romb, strelka.","Chiqishdan kirishni teskari amallar bilan topish.","Shart va sikl.","Mantiqiy algoritm jumboqlari: daryodan o'tish, idishlar."],
 mist:["Qadamlar o'rniga sonlarni sanaydi.","Amallar tartibini almashtirib yuboradi.","Teskari hisobda amallarni oldidan boshlaydi.","«Oshguncha» shartida chegaraning o'zida to'xtaydi.","Orqaga qaytish kerakligini ko'rmaydi."],
 need:["Kartochkalar: bo'ri, echki, karam.","Ikki idish va suv (ixtiyoriy).","Doskada blok-sxema."],
 board:["<span class='w2'>13 → 14 → 7 → 8 → 4 → 2 → 1 (6 qadam)</span>.","<span class='w2'>10 → ×3 → −4 → :2 → 13</span>.","<span class='w2'>? → +7 → ×2 → −6 → 20 ⇒ 6</span>.","<span class='w2'>5, 10, 20, 40, 80, 160</span>.","<span class='w2'>5 l, 3 l → 4 l (6 harakat)</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
