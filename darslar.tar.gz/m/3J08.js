var CODE='3J08',TITLE="3-sinf · Kesish, bo'laklash, ustun va oraliqlar";
function j8Log(n){clear();var g=S.g,L=280,gap=10,w=(L-(n-1)*gap)/n;for(var i=0;i<n;i++){var x=40+i*(w+gap);E('rect',{x:x,y:60,width:w,height:40,rx:8,fill:'#d9a35a',stroke:'#8a5a2b','stroke-width':2},g);E('ellipse',{cx:x+w-4,cy:80,rx:5,ry:16,fill:'#f0c98d',stroke:'#8a5a2b','stroke-width':1.4},g);T(g,x+w/2,86,String(i+1),{'font-size':15,'font-weight':800,fill:'#4a2d10'})}
 for(var k=1;k<n;k++){var cx=40+k*(w+gap)-gap/2;E('line',{x1:cx,y1:48,x2:cx,y2:112,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);T(g,cx,130,'✂'+k,{'font-size':13,'font-weight':800,fill:C.bad})}
 T(g,180,158,n+' bo‘lak · '+(n-1)+' kesish',{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
var P1=[function(){j8Log(1);j3Msg('Butun yog‘och: 1 bo‘lak, 0 kesish')},function(){j8Log(2);j3Msg('1 marta kesdik → 2 bo‘lak')},function(){j8Log(3);j3Msg('2 marta → 3 bo‘lak')},function(){j8Log(4);j3Msg('3 marta → 4 bo‘lak. Kesishlar doim bittaga kam!')}];
function j8Line(posts){clear();var g=S.g,x0=40,x1=320,y=90;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#8aa0b4','stroke-width':4,'stroke-linecap':'round'},g);
 for(var i=0;i<=4;i++){var x=x0+i*70;T(g,x,y+34,(i*5)+' m',{'font-size':12,'font-weight':700,fill:'#53687c'});if(i<4)T(g,x+35,y-10,'5 m',{'font-size':11,'font-weight':700,fill:C.blue});if(posts){E('rect',{x:x-5,y:y-46,width:10,height:46,rx:2,fill:'#8a5a2b'},g);E('circle',{cx:x,cy:y-48,r:7,fill:'#ffd34d',stroke:'#8a5a2b','stroke-width':1.4},g);T(g,x,y+54,String(i+1),{'font-size':13,'font-weight':800,fill:C.bad})}}}
function j8Ring(posts){clear();var g=S.g,cx=180,cy=86,r=60;E('circle',{cx:cx,cy:cy,r:r,fill:'none',stroke:'#8aa0b4','stroke-width':4},g);T(g,cx,cy+5,'20 m',{'font-size':14,'font-weight':800,fill:'#53687c'});
 for(var i=0;i<4;i++){var a=-Math.PI/2+i*Math.PI/2,x=cx+r*Math.cos(a),y=cy+r*Math.sin(a);var a2=a+Math.PI/4;T(g,cx+(r+16)*Math.cos(a2),cy+(r+16)*Math.sin(a2)+4,'5 m',{'font-size':11,'font-weight':700,fill:C.blue});if(posts){E('circle',{cx:x,cy:y,r:9,fill:'#ffd34d',stroke:'#8a5a2b','stroke-width':2},g);T(g,x,y+4,String(i+1),{'font-size':11,'font-weight':800,fill:'#4a2d10'})}}}
function j8Stairs(hl){clear();var g=S.g;for(var f=1;f<=6;f++){var y=160-(f-1)*26;E('rect',{x:110,y:y-6,width:90,height:6,rx:2,fill:hl&&f<=3?'#1e8e5a':'#8aa0b4'},g);T(g,96,y,f+'-qavat',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});if(f<6){E('line',{x1:200,y1:y-3,x2:236,y2:y-23,stroke:'#d9a35a','stroke-width':4},g);T(g,262,y-10,hl?'20 zina':(f<3?'? zina':''),{'font-size':11,'font-weight':800,fill:f<3?C.blue:'#53687c'})}}
 T(g,320,110,hl?'5 · 20':'1→3: 40',{'font-size':13,'font-weight':800,fill:C.bad})}
function j8Clock(n,sec){clear();var g=S.g,x0=50,x1=310,y=86,d=(x1-x0)/(n-1);E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#8aa0b4','stroke-width':3},g);for(var i=0;i<n;i++){var x=x0+i*d;E('circle',{cx:x,cy:y,r:10,fill:'#ffd34d',stroke:'#8a5a2b','stroke-width':2},g);T(g,x,y+4,'🔔',{'font-size':10});if(i<n-1)T(g,x+d/2,y-18,sec+' s',{'font-size':12,'font-weight':800,fill:C.blue})}
 T(g,180,140,n+' zarb · '+(n-1)+' oraliq',{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
var STEPS=[
{h:"Kesishlar va bo'laklar",sum:"To'g'ri yog'ochda: kesishlar = bo'laklar − 1.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Yog'ochni kesamiz. Har kesishda nechta bo'lak bo'lishini kuzating. Tugmani bosing.</p>",
 btns:[phaser(P1)],
 after:"<p>Qoida: <b>kesishlar soni = bo'laklar soni − 1</b>. 4 bo'lak uchun 3 kesish yetadi. Bu — «oraliq» masalalarining kaliti: nimani sanayapmiz — bo'laklarnimi yoki ular orasidagi chegaralarnimi?</p>",
 q:{t:"Yog'och 7 marta kesildi. Nechta bo'lak hosil bo'ldi?",opts:["7","8","6","14"],ok:1,why:"Bo'laklar = kesishlar + 1 = 8.",hint:"1 kesish nechta bo'lak beradi?",full:"1 kesish — 2 bo'lak, 2 kesish — 3 bo'lak. Har doim bo'lak bittaga ko'p: 7 + 1 = 8."},
 tn:"Qog'oz lentani qaychi bilan kesing: bolalar kesishlar va bo'laklarni alohida sanasin."},
{h:"Vaqt — kesishlarga sarflanadi",sum:"5 bo'lak = 4 kesish; har kesish 2 daqiqa → 8 daqiqa.",a:"m02",
 start:function(){j8Log(5);j3Msg('Har kesish 2 daqiqa. Yog‘ochni 5 bo‘lakka bo‘lish necha daqiqa?')},fin:function(){j8Log(5);j3Msg('4 kesish · 2 daqiqa = 8 daqiqa')},
 html:"<p>Usta yog'ochni bir kesishga 2 daqiqa sarflaydi. U yog'ochni <b>5 bo'lakka</b> necha daqiqada bo'ladi?</p>",
 btns:j3Ch(["10","8","12","5"],1,function(){j8Log(5);j3Msg('To‘g‘ri! 4 kesish · 2 = 8 daqiqa')},function(i){return ['10 = 5 · 2 — bo‘laklarni sanadingiz. Kesishlar nechta?','','12 = 6 · 2 — bunda 7 bo‘lak bo‘lardi','5 — bo‘laklar soni, daqiqa emas'][i]}),g2:1,
 after:"<p>Vaqt <b>kesishlarga</b> sarflanadi, bo'laklarga emas: 5 − 1 = 4 kesish, 4 · 2 = <b>8</b> daqiqa.</p>",
 q:{t:"Har kesish 3 daqiqa. 4 bo'lakka necha daqiqada bo'linadi?",opts:["12","9","15","6"],ok:1,why:"3 kesish · 3 = 9.",hint:"4 bo'lak uchun nechta kesish kerak?",full:"4 bo'lak → 3 kesish → 3 · 3 = 9 daqiqa. «12» — bo'laklarni ko'paytirish xatosi."},
 tn:"Doskaga «bo'lak | kesish | vaqt» jadvalini chizing va bolalar to'ldirsin."},
{h:"Yo'l bo'yidagi ustunlar",sum:"To'g'ri chiziqda, ikki uchida ham ustun bo'lsa: ustunlar = oraliqlar + 1 = 20 : 5 + 1 = 5.",a:"m03",
 start:function(){j8Line(0);j3Msg('20 m yo‘l, har 5 m da ustun (boshida va oxirida ham). Nechta ustun?')},fin:function(){j8Line(1);j3Msg('4 oraliq → 5 ustun')},
 html:"<p>20 metrli yo'l bo'yiga har 5 metrda ustun qo'yildi, yo'lning <b>boshida va oxirida ham</b>. Nechta ustun bor?</p>",
 btns:j3Ch(["4","5","6","20"],1,function(){j8Line(1);j3Msg('To‘g‘ri! 20 : 5 = 4 oraliq, ustunlar 4 + 1 = 5')},function(i){return ['4 — bu oraliqlar soni. Ustunlarni sanang: 0, 5, 10, 15, 20 m','','6 ustun bo‘lsa, 5 ta oraliq — 25 m kerak','20 — metrlar soni'][i]}),g2:1,
 after:"<p>Oraliqlar = 20 : 5 = 4. To'g'ri chiziqda ikki uchida ham ustun bo'lsa — <b>ustunlar oraliqlardan bittaga ko'p</b>: 5. Barmoqlaringizga qarang: 5 barmoq — 4 oraliq.</p>",
 q:{t:"Qatorda 10 ta ustun, har ikki ustun orasi 4 m. Birinchisidan oxirgisigacha necha metr?",opts:["40","36","44","32"],ok:1,why:"10 ustun → 9 oraliq · 4 = 36 m.",hint:"10 ta ustun orasida nechta oraliq bor?",full:"Oraliqlar ustunlardan bittaga kam: 9. 9 · 4 = 36 m. «40» — ustunlarni ko'paytirish."},
 tn:"Bolalar qo'lini yoyib turib, «barmoqlar va oraliqlar» ni sanasin — eng oson model."},
{h:"Yopiq chiziq: aylana",sum:"Yopiq chiziqda (aylana, perimetr) ustunlar = oraliqlar: 20 : 5 = 4.",a:"m04",
 start:function(){j8Ring(0);j3Msg('Doira shaklidagi 20 m to‘siq, har 5 m da ustun. Nechta ustun?')},fin:function(){j8Ring(1);j3Msg('Yopiq chiziq: 4 oraliq → 4 ustun')},
 html:"<p>Endi yo'l <b>yopiq</b>: doira shaklidagi 20 m to'siq bo'yiga har 5 m da ustun. Nechta ustun kerak?</p>",
 btns:j3Ch(["5","4","3","20"],1,function(){j8Ring(1);j3Msg('To‘g‘ri! Boshi va oxiri bir nuqtada — ustunlar = oraliqlar = 4')},function(i){return ['5 — to‘g‘ri yo‘lda shunday edi. Aylanada oxirgi ustun birinchisi bilan ustma-ust tushadi!','','3 ustun bo‘lsa, 3 oraliq — 15 m','20 — metrlar soni'][i]}),g2:1,
 after:"<p>Yopiq chiziqda (doira, kvadrat atrofi) boshlanish va tugash nuqtasi <b>bitta</b>. Shuning uchun <b>ustunlar = oraliqlar</b>. Kvadrat maydonda: perimetr : oraliq.</p>",
 q:{t:"Tomoni 12 m bo'lgan kvadrat maydon atrofiga har 3 m da ustun qo'yildi (burchaklarda ham). Nechta ustun?",opts:["16","20","12","17"],ok:0,why:"Perimetr 48 m, 48 : 3 = 16 (yopiq chiziq).",hint:"Kvadrat atrofi — yopiq chiziq. Perimetr qancha?",full:"Perimetr 4 · 12 = 48 m. Yopiq chiziqda ustunlar = oraliqlar = 48 : 3 = 16. «20» — har tomonga 5 tadan sanab, burchaklarni ikki marta hisoblash xatosi."},
 tn:"Arqonni halqa qilib, unga qisqichlar taqing — bolalar yopiq va ochiq chiziqni solishtirsin."},
{h:"Tuzoq: zinapoya va qavatlar",sum:"1-qavatdan 3-qavatga — 2 ta oraliq (40 zina → 20 dan). 1-dan 6-gacha — 5 oraliq = 100 zina.",a:"m05",
 start:function(){j8Stairs(0);j3Msg('1-qavatdan 3-qavatgacha 40 zina. 1-qavatdan 6-qavatgacha nechta?')},fin:function(){j8Stairs(1);j3Msg('Har oraliq 20 zina, 5 oraliq: 100 zina')},
 html:"<p>Uyda 1-qavatdan 3-qavatga chiqish uchun 40 ta zina bosib o'tiladi. 1-qavatdan <b>6-qavatga</b> chiqish uchun-chi?</p>",
 btns:j3Ch(["120","100","80","200"],1,function(){j8Stairs(1);j3Msg('To‘g‘ri! 1→3: 2 oraliq, har biri 20. 1→6: 5 oraliq · 20 = 100')},function(i){return ['120 = 40 · 3 — qavatlar 6 ta, lekin 1→3 da 3 ta oraliq emas, 2 ta!','','80 = 40 · 2 — 6-qavatga yetmaysiz','200 = 40 · 5 — 40 zina bitta oraliqqa tegishli emas'][i]}),g2:1,
 after:"<p>Zinalar qavatlar <b>orasida</b>. 1-dan 3-ga — 2 oraliq, demak bitta oraliqda 40 : 2 = 20 zina. 1-dan 6-ga — 5 oraliq: 5 · 20 = <b>100</b>. Eng ko'p uchraydigan xato — «3-qavat» ni «3 marta» deb o'ylash.</p>",
 q:{t:"1-qavatdan 3-qavatga ko'tarilish 2 daqiqa davom etadi. 1-qavatdan 9-qavatga necha daqiqa?",opts:["6","8","9","4"],ok:1,why:"Har oraliq 1 daqiqa, 8 oraliq — 8 daqiqa.",hint:"1→3 da nechta oraliq bor? 1→9 da-chi?",full:"1→3: 2 oraliq = 2 daqiqa, 1 oraliq = 1 daqiqa. 1→9: 8 oraliq = 8 daqiqa. «6» = 2 · 3 — 9 ni 3 ga bo'lish xatosi."},
 tn:"Maktab zinapoyasida o'lchab ko'ring: bolalar 1→2 va 1→3 zinalarini sanasin."},
{h:"Soat zarblari",sum:"3 zarb — 2 oraliq (6 s → 3 s). 6 zarb — 5 oraliq · 3 = 15 s.",a:"m06",
 start:function(){j8Clock(3,3);j3Msg('Soat 3 marta 6 sekundda uradi. 6 marta necha sekundda uradi?')},fin:function(){j8Clock(6,3);j3Msg('5 oraliq · 3 s = 15 s')},
 html:"<p>Devor soati «bom» deb 3 marta urishga 6 sekund sarflaydi (birinchi zarbdan oxirgisigacha). <b>6 marta</b> urishiga necha sekund ketadi?</p>",
 btns:j3Ch(["12","15","18","10"],1,function(){j8Clock(6,3);j3Msg('To‘g‘ri! 3 zarb = 2 oraliq → 1 oraliq 3 s. 6 zarb = 5 oraliq = 15 s')},function(i){return ['12 = 6 · 2 — vaqt zarblarga emas, ular orasiga ketadi','','18 = 6 · 3 — 6 zarb orasida 6 ta emas, 5 ta oraliq','10 = 5 · 2 — 1 oraliq necha sekund? 6 : 2 = ?'][i]}),g2:1,
 after:"<p>Vaqt zarblar <b>orasida</b> o'tadi. 3 zarb → 2 oraliq → 1 oraliq = 6 : 2 = 3 s. 6 zarb → 5 oraliq → 5 · 3 = <b>15 s</b>.</p>",
 q:{t:"Soat 4 marta urishga 6 sekund sarflaydi. 7 marta urishiga necha sekund?",opts:["12","14","10","18"],ok:0,why:"3 oraliq = 6 s → 2 s. 6 oraliq · 2 = 12.",hint:"4 zarb orasida nechta oraliq?",full:"4 zarb → 3 oraliq → 1 oraliq = 2 s. 7 zarb → 6 oraliq → 12 s. «14» = 7 · 2 — zarblarni sanash xatosi."},
 tn:"Stolni urib ko'rsating: «tak — tak — tak» — bolalar pauzalarni sanasin."},
{h:"Bilasizmi? «Bittaga adashish» xatosi",sum:"Dasturchilar ustun va oraliq xatosini «off-by-one» — bittaga adashish xatosi deb atashadi.",a:"m07",
 start:function(){j8Line(1);j3Msg('5 ustun — 4 oraliq')},fin:function(){j8Line(1);j3Msg('5 ustun — 4 oraliq')},
 html:"<p>💻 Bu xato faqat bolalarda emas! Dunyodagi dasturchilar uni <b>«off-by-one»</b> («bittaga adashish») xatosi yoki «ustun xatosi» (fencepost error) deb atashadi. Kompyuter dasturlarida bunday xato juda ko'p uchraydi: masalan, 1 dan 10 gacha nechta son bor deganda 9 deb hisoblash.</p><p>📅 Hayotda: dushanbadan jumagacha (ikkalasi bilan) — 5 kun, 4 emas. Kitobning 10-betidan 20-betigacha — 11 bet.</p>",
 tn:"«Ikkalasi ham kiradimi?» — har bir sanash masalasida bolalar shu savolni bersin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j8Log(4)},fin:function(){j8Log(4)},
 html:"<div class='memo'><ul><li>Yog'och: <b>kesishlar = bo'laklar − 1</b>.</li><li>Vaqt kesishlarga (oraliqlarga) sarflanadi.</li><li>To'g'ri chiziq, ikki uchida ham: <b>ustunlar = oraliqlar + 1</b>.</li><li>Yopiq chiziq (doira, perimetr): <b>ustunlar = oraliqlar</b>.</li><li>Zinapoya: 1-dan n-qavatga — <b>n − 1</b> oraliq.</li><li>Soat: n zarb — n − 1 oraliq.</li><li>«10-dan 20-gacha» ikkalasi bilan: 20 − 10 + 1 = 11.</li></ul></div>",
 tn:"Doskada ikki ustunli jadval: «nima sanalyapti — nuqtami yoki oraliqmi?»"}
];
var PROBS=[
{t:"Yog'ochni 6 bo'lakka bo'lish uchun nechta kesish kerak?",o:["5","6","7","3"],k:0,s:"6 − 1 = 5."},
{t:"Har kesish 3 daqiqa. Yog'ochni 4 bo'lakka necha daqiqada bo'lish mumkin?",o:["9","12","15","6"],k:0,s:"3 kesish · 3 = 9."},
{t:"To'g'ri yog'och 7 marta kesildi. Nechta bo'lak bo'ldi?",o:["8","7","6","14"],k:0,s:"7 + 1 = 8."},
{t:"10 m lentadan har safar 1 m kesib olinadi. Butun lentani 1 metrlik bo'laklarga bo'lish uchun nechta kesish kerak?",o:["9","10","11","8"],k:0,s:"10 bo'lak → 9 kesish (oxirgi bo'lak o'zi qoladi)."},
{t:"30 m yo'l bo'yi har 5 m da daraxt ekildi, boshida va oxirida ham. Nechta daraxt?",o:["7","6","5","8"],k:0,s:"30 : 5 = 6 oraliq, 7 daraxt."},
{t:"Qatorda 10 ta ustun, har ikki ustun orasi 4 m. Birinchisidan oxirgisigacha necha metr?",o:["36","40","44","32"],k:0,s:"9 oraliq · 4 = 36."},
{t:"Qatorda 8 ta daraxt, har ikki qo'shni daraxt orasiga 1 ta buta ekildi. Nechta buta?",o:["7","8","9","16"],k:0,s:"Oraliqlar 7 ta."},
{t:"Doira shaklidagi 40 m to'siq bo'yiga har 4 m da ustun qo'yildi. Nechta ustun?",o:["10","11","9","40"],k:0,s:"Yopiq chiziq: 40 : 4 = 10."},
{t:"Halqa shaklidagi yopiq ip 5 joyidan kesildi. Nechta bo'lak bo'ldi?",o:["5","6","4","10"],k:0,s:"Yopiq chiziqda bo'laklar = kesishlar."},
{t:"Tomoni 12 m kvadrat maydon atrofiga har 3 m da ustun qo'yildi (burchaklarda ham). Nechta ustun?",o:["16","20","12","17"],k:0,s:"48 : 3 = 16."},
{t:"Kvadratning har tomonida 5 tadan ustun bor (burchaklar bilan birga). Jami nechta ustun?",o:["16","20","15","12"],k:0,s:"4 · 5 = 20, burchaklar ikki marta sanaldi: 20 − 4 = 16."},
{t:"1-qavatdan 4-qavatga 48 ta zina. Ikki qo'shni qavat orasida nechta zina?",o:["16","12","24","48"],k:0,s:"3 oraliq: 48 : 3 = 16."},
{t:"1-qavatdan 3-qavatga ko'tarilish 2 daqiqa. 1-qavatdan 9-qavatga necha daqiqa?",o:["8","6","9","4"],k:0,s:"1 oraliq 1 daqiqa, 8 oraliq."},
{t:"Maktabda qavatlar orasi 18 ta zina. Bola 3-qavatdan 5-qavatga chiqdi. Nechta zina bosdi?",o:["36","54","18","72"],k:0,s:"2 oraliq · 18 = 36."},
{t:"Soat 4 marta urishga 6 sekund sarflaydi. 7 marta urishiga necha sekund?",o:["12","14","10","18"],k:0,s:"1 oraliq 2 s, 6 oraliq = 12 s."},
{t:"Kitobning 10-betidan 20-betigacha (ikkalasi ham) o'qildi. Nechta bet o'qildi?",o:["11","10","9","20"],k:0,s:"20 − 10 + 1 = 11."},
{t:"Ko'chaning ikkala tomonida 100 m bo'yi har 10 m da chiroq bor (boshida va oxirida ham). Jami nechta chiroq?",o:["22","20","11","24"],k:0,s:"Bir tomonda 11, ikki tomonda 22."},
{t:"Arra bir kesishni 1 daqiqada qiladi. 3 m yog'ochni 50 sm li bo'laklarga necha daqiqada bo'ladi?",o:["5","6","3","10"],k:0,s:"6 bo'lak → 5 kesish → 5 daqiqa."},
{t:"5 ta yog'ochning har biri 3 bo'lakka kesildi. Jami nechta kesish qilindi?",o:["10","15","5","12"],k:0,s:"Har biriga 2 kesish: 5 · 2 = 10."},
{t:"Poyezdda 10 ta vagon, har biri 20 m, qo'shni vagonlar orasidagi ulagich 1 m. Poyezd uzunligi (vagonlar va ulagichlar)?",o:["209 m","210 m","200 m","220 m"],k:0,s:"200 + 9 ulagich · 1 = 209."}
];
function PRACT_STAGE(){j8Log(4)}
var PREP_DATA={teach:["Kesish va bo'laklar: kesish = bo'lak − 1.","Ustun va oraliqlar: ochiq chiziqda +1, yopiq chiziqda teng.","Zinapoya va qavatlar, soat zarblari — yashirin oraliqlar.","«Ikkalasi ham» sanash: 20 − 10 + 1."],
 mist:["Vaqtni bo'laklar soniga ko'paytiradi.","Zinapoyada qavat raqamini oraliqlar soni deb oladi.","Yopiq chiziqda ham +1 qo'shadi, kvadrat burchaklarini ikki marta sanaydi."],
 need:["Qog'oz lenta va qaychi.","Arqon halqa, kiyim qisqichlari."],
 board:["<span class='w2'>kesish = bo'lak − 1</span>","Ochiq: <span class='w2'>ustun = oraliq + 1</span>","Yopiq: <span class='w2'>ustun = oraliq</span>","1→n qavat: <span class='w2'>n − 1</span> oraliq"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
