var CODE='3A4',TITLE='3-sinf · Sonlar ketma-ketligi. Juft va toq sonlar';
function a4big(txt,sub,col){clear();var g=S.g;T(g,180,76,txt,{'font-size':38,'font-weight':800,fill:col||'#1d2b3a'});if(sub)T(g,180,118,sub,{'font-size':16,'font-weight':700,fill:'#5b6b7b'})}
function a4nb(){var a=S.nb;w3line(496,503,1,[[499,C.blue]].concat(a.p?[[498,C.ok,'498']]:[]).concat(a.n?[[500,C.ok,'500']]:[]),{fs:12});var g=S.g;if(a.p)T(g,S.X(498),150,'oldingi',{'font-size':12,'font-weight':700,fill:C.ok});if(a.n)T(g,S.X(500),150,'keyingi',{'font-size':12,'font-weight':700,fill:C.ok})}
var A4L=[358,417,634,920,275,806];
function a4sort(){clear();var g=S.g,i=S.si;T(g,90,24,'JUFT',{'font-size':14,'font-weight':800,fill:C.blue});T(g,270,24,'TOQ',{'font-size':14,'font-weight':800,fill:C.a});E('line',{x1:180,y1:12,x2:180,y2:168,stroke:'#e6d6bd','stroke-width':2},g);
 var cj=0,ct=0;for(var k=0;k<i;k++){var v=A4L[k],j=v%2===0,x=j?90:270,y=48+(j?cj++:ct++)*26;T(g,x,y,String(v),{'font-size':18,'font-weight':800,fill:j?C.blue:C.a})}
 if(i<A4L.length){var s=String(A4L[i]);E('rect',{x:146,y:118,width:68,height:40,rx:8,fill:'#fff',stroke:C.blue,'stroke-width':2},g);T(g,172,146,s.slice(0,2),{'font-size':22,'font-weight':800,fill:'#1d2b3a'});T(g,197,146,s[2],{'font-size':22,'font-weight':800,fill:C.bad})}}
var P3=[function(){a4big('4 + 6 = 10','juft + juft = JUFT',C.blue);msg('Juftlarni juftlarga qo‘shsak — hammasi juft-juft bo‘lib qoladi')},
 function(){a4big('3 + 5 = 8','toq + toq = JUFT',C.blue);msg('Ikkita «ortiqcha» bittadan qo‘shilib, juft hosil qiladi')},
 function(){a4big('3 + 4 = 7','toq + juft = TOQ',C.a);msg('Bitta «ortiqcha» qoladi — natija toq')},
 function(){a4big('7 + 9 + 5 = 21','toq + toq + toq = TOQ',C.a);msg('Toq sonlar soni <b>toq</b> bo‘lsa — yig‘indi toq')}];
var P6=[function(){clear();var g=S.g;T(g,180,40,'1, 2, 3, …, 59, 60',{'font-size':22,'font-weight':800,fill:'#1d2b3a'});msg('1 dan 60 gacha yozilganda 5 raqami necha marta uchraydi?')},
 function(){clear();var g=S.g;T(g,180,32,'Birliklar xonasida 5:',{'font-size':14,'font-weight':800,fill:C.u});['5','15','25','35','45','55'].forEach(function(v,i){T(g,40+i*56,64,v,{'font-size':20,'font-weight':800,fill:'#1d2b3a'})});T(g,180,100,'6 marta',{'font-size':18,'font-weight':800,fill:C.ok});msg('Birliklar: <b>6</b> marta')},
 function(){clear();var g=S.g;T(g,180,32,'O‘nliklar xonasida 5:',{'font-size':14,'font-weight':800,fill:'#b07a33'});for(var i=0;i<10;i++)T(g,24+i*35,64,String(50+i),{'font-size':17,'font-weight':800,fill:i===5?C.bad:'#1d2b3a'});T(g,180,100,'10 marta',{'font-size':18,'font-weight':800,fill:C.ok});T(g,180,130,'55 da 5 raqami IKKI marta yozilgan!',{'font-size':13,'font-weight':700,fill:C.bad});msg('O‘nliklar: <b>10</b> marta (50 dan 59 gacha)')},
 function(){a4big('6 + 10 = 16','5 raqami 16 marta yozilgan',C.ok);msg('Javob: <b>16</b>. «15» — 55 ni bir marta sanash xatosi')}];
var STEPS=[
{h:"Qo'shni sonlar: oldingi va keyingi",sum:"Keyingi son — 1 ta ko'p, oldingi — 1 ta kam. 499 dan keyin 500, 600 dan oldin 599.",a:"m01",
 start:function(){S.nb={p:0,n:0};a4nb();msg('499 ning qo‘shnilarini toping')},fin:function(){S.nb={p:1,n:1};a4nb();msg('498 — 499 — 500')},
 html:"<p>Natural sonlar qatorida har bir son o'zidan oldingi sondan <b>1 ta ko'p</b>. 499 ning ikkala qo'shnisini toping:</p>",
 btns:[["◀ Oldingi",function(c,done){S.nb.p=1;a4nb();msg('499 − 1 = <b>498</b>');if(S.nb.n)done()}],["Keyingi ▶",function(c,done){S.nb.n=1;a4nb();msg('499 + 1 = <b>500</b> — 9 lar «to‘lib», yangi yuzlik ochildi');if(S.nb.p)done()},'u']],g2:1,
 after:"<p>Qiyin joylari — xona «to'lib qoladigan» sonlar: 499 → <b>500</b>, 709 → <b>710</b>. Teskarisi: 600 dan oldingi — <b>599</b>, 800 dan oldingi — <b>799</b>.</p>",
 q:{t:"700 dan oldingi son qaysi?",opts:["699","701","690","799"],ok:0,why:"700 − 1 = 699.",hint:"Oldingi son — 1 ta kam.",full:"700 − 1 = 699. 701 — keyingi son; 690 — o'nlik kamaytirildi; 799 — yuzlikni noto'g'ri o'zgartirish."},
 tn:"Son o'qi va «odimlash»: bola qo'li bilan 1 qadam chapga / o'ngga yuradi."},
{h:"Juft va toq: oxirgi raqamga qaraymiz",sum:"Oxirgi raqami 0, 2, 4, 6, 8 — juft; 1, 3, 5, 7, 9 — toq.",a:"m02",
 start:function(){S.si=0;a4sort();msg('Qizil raqamga qarang: juftmi, toqmi?')},fin:function(){S.si=6;a4sort();msg('Juft: 4 ta, toq: 2 ta')},
 html:"<p>Son katta bo'lsa ham, uning juft-toqligini faqat <b>oxirgi raqami</b> hal qiladi. Har bir sonni to'g'ri ustunga yuboring:</p>",
 btns:[["Juft",function(c,done){a4pick(true,done)}],["Toq",function(c,done){a4pick(false,done)},'u']],g2:1,
 after:"<p>358, 634, 920, 806 — juft (oxiri 8, 4, 0, 6). 417, 275 — toq. Juftlar toqlardan <b>4 − 2 = 2</b> ta ko'p. <b>0</b> ham juft raqam: 920 juft!</p>",
 q:{t:"Qaysi son toq?",opts:["970","586","1 004","789"],ok:3,why:"789 ning oxirgi raqami 9 — toq.",hint:"Faqat oxirgi raqamga qarang.",full:"970 (0), 586 (6), 1 004 (4) — juft. 789 (9) — toq. Birinchi raqamga qarash xato: 970 «9 bilan boshlangan» bo'lsa ham juft."},
 tn:"Bank (401) masalasi. Juft — «jufti bor»: cho'plarni ikkitadan juftlang — ortib qolsa toq."},
{h:"Juft va toq sonlarni qo'shish",sum:"juft + juft = juft, toq + toq = juft, juft + toq = toq.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Hisoblamasdan ham natija juft yoki toq bo'lishini aytish mumkin. Qoidalarni kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p>Qoida: yig'indida <b>toq sonlar soni</b> juft bo'lsa — yig'indi juft, toq bo'lsa — toq. Shu bilan hisobni tekshirish mumkin: 357 + 248 juft chiqsa — xato bor!</p>",
 q:{t:"Hisoblamasdan ayting: 375 + 128 + 449 yig'indisi qanday son?",opts:["Juft","Toq","Bir xonali","Yuzlik"],ok:0,why:"Ikkita toq (375, 449) va bitta juft — yig'indi juft (952).",hint:"Nechta toq qo'shiluvchi bor?",full:"375 toq, 128 juft, 449 toq. Toq qo'shiluvchilar 2 ta — juft soni, demak yig'indi juft. Tekshiruv: 375 + 128 + 449 = 952 — juft."},
 tn:"Kartochka: «J+J», «T+T», «J+T» — bolalar 3 tadan misol topib, qoidani o'zlari xulosalasin (Yapon usuli)."},
{h:"Ketma-ketlik qadami",sum:"Qo'shni hadlar ayirmasi — qadam: 305, 315, 325, 335 — qadam 10.",a:"m04",
 start:function(){w3line(295,345,5,[[305,C.blue],[315,C.blue],[325,C.blue]],{big:10,fs:11});msg('305, 315, 325, ? — keyingi son?')},fin:function(){w3line(295,345,5,[[305,C.blue],[315,C.blue],[325,C.blue],[335,C.ok]],{big:10,fs:11});msg('Qadam 10: 325 + 10 = <b>335</b>')},
 html:"<p>Ketma-ketlikning qoidasini topish uchun qo'shni sonlar <b>farqini</b> hisoblang. Keyingi sonni tanlang:</p>",
 btns:w3choose(["330","335","326"],1,function(){w3line(295,345,5,[[305,C.blue],[315,C.blue],[325,C.blue],[335,C.ok]],{big:10,fs:11});msg('315 − 305 = 10, 325 − 315 = 10 → 325 + 10 = <b>335</b>')},function(i){msg(i===0?'330 — o‘nliklarga yaxlitladingiz. Farqni hisoblang: 315 − 305 = ?':'326 — 1 ta qo‘shildi, qadam esa 1 emas')}),g3:1,
 after:"<p>Qadam doimiy bo'lmasligi ham mumkin: 4, 6, 10, 16, 24 — farqlar 2, 4, 6, 8, demak keyingi farq 10 va son <b>34</b>.</p>",
 q:{t:"Keyingi son: 1000, 975, 950, 925, …",opts:["900","915","875","950"],ok:0,why:"Har safar 25 kamayadi: 925 − 25 = 900.",hint:"Qo'shni sonlar farqi qancha?",full:"1000 − 975 = 25, 975 − 950 = 25. Kamayuvchi ketma-ketlik, qadam 25: 925 − 25 = 900. 915 — 10 ayirish, 875 — 50 ayirish xatosi."},
 tn:"Son o'qida sakrashlarni yoy bilan chizdirish."},
{h:"Tuzoq: oraliqda nechta juft son?",sum:"400 dan 420 gacha (ikkalasi ham kiradi) juft sonlar: 400, 402, …, 420 — 11 ta.",a:"m05",
 start:function(){S.ev=0;a4ev()},fin:function(){S.ev=1;a4ev()},
 html:"<p>«400 dan 420 gacha (ikkalasi ham kiradi) nechta juft son bor?» Ko'pchilik 20 : 2 = 10 deydi. Son o'qida tekshiring:</p>",
 btns:[["Juftlarni belgilash",function(c,done){S.ev=1;a4ev();done()}]],
 after:"<p>Juftlar: 400, 402, 404, …, 420. Sanash: (420 − 400) : 2 + 1 = <b>11</b>. «+1» — boshlang'ich sonning o'zi. Chegaralar juft bo'lmasa (401 dan 421 gacha) — juftlar 402…420: <b>10</b> ta.</p>",
 q:{t:"300 dan 330 gacha (ikkalasi ham kiradi) nechta toq son bor?",opts:["15","16","14","30"],ok:0,why:"301, 303, …, 329: (329 − 301) : 2 + 1 = 15.",hint:"Birinchi va oxirgi toq sonni toping.",full:"Birinchi toq — 301, oxirgisi — 329. (329 − 301) : 2 + 1 = 14 + 1 = 15. 16 — 300 yoki 330 ni ham sanash; 14 — «+1» ni unutish."},
 tn:"Bank (2233, 1203) turi. Kichik oraliqda (400–406) qo'lda sanab, qoidani tekshirtiring."},
{h:"Tuzoq: raqam necha marta yozilgan?",sum:"1 dan 60 gacha 5 raqami: birliklarda 6, o'nliklarda 10 marta — jami 16.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>«1 dan 60 gacha barcha sonlar ketma-ket yozildi. <b>5 raqami</b> necha marta yozilgan?» Xonalar bo'yicha alohida sanaymiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: har bir <b>xonani alohida</b> sanang — birliklar, keyin o'nliklar. 55 sonida 5 raqami ikki marta yozilgan, u ikki xil sanoqda ham hisoblanadi — bu to'g'ri, chunki raqamlarni sanayapmiz, sonlarni emas.</p>",
 q:{t:"1 dan 100 gacha yozilganda 0 raqami necha marta yoziladi?",opts:["11","10","9","12"],ok:0,why:"10, 20, …, 90 — 9 ta; 100 da — 2 ta: jami 11.",hint:"100 sonida nechta nol bor?",full:"Birliklarda 0: 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 — 10 ta. O'nliklarda 0: faqat 100 — 1 ta. Jami 11. «10» — 100 dagi ikkinchi nolni unutish, «9» — 100 ni umuman unutish."},
 tn:"Bank (1204, 1198, 1201). 1 dan 60 gacha sonlarni doskada 6 qatorga yozib, 5 larni rangli bo'r bilan belgilang."},
{h:"Bilasizmi? Juft va toq atrofimizda",sum:"Ko'chalarda uylar bir tomonda juft, boshqa tomonda toq raqamlanadi.",a:"m07",
 start:function(){a4house()},fin:function(){a4house()},
 html:"<p>🏠 Ko'p shaharlarda ko'chaning <b>bir tomonida juft</b>, ikkinchi tomonida <b>toq</b> raqamli uylar turadi. Shuning uchun 15-uyning qo'shnisi — 13 va 17, 14 emas!</p><p>🧦 «Juft» so'zining o'zi ham — ikkita, jufti bor degani: bir juft paypoq, bir juft etik.</p><p>0 — eng kichik juft son.</p>",
 tn:"Bolalar o'z uy raqamining juft-toqligini aytsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){a4big('2, 4, 6, 8, 0','juft raqamlar',C.blue)},fin:function(){a4big('2, 4, 6, 8, 0','juft raqamlar',C.blue)},
 html:"<div class='memo'><ul><li>Keyingi son = son + 1, oldingi = son − 1 (599 → 600 → 601).</li><li>Juft/toq — faqat <b>oxirgi raqamga</b> qarang; 0 — juft.</li><li>J + J = J, T + T = J, J + T = T.</li><li>Ketma-ketlik qoidasi — qo'shni hadlar farqi.</li><li>Oraliqdagi juft/toqlar: (oxirgi − birinchi) : 2 + 1.</li><li>Raqamni sanash: har bir xonani alohida.</li></ul></div>",
 tn:"Keyingi dars — xona qo'shiluvchilari."}
];
function a4pick(j,done){var v=A4L[S.si];if(v==null)return;if((v%2===0)===j){S.si++;a4sort();msg(S.si<6?(v+' — '+(j?'juft':'toq')+' ✓ (oxirgi raqam '+(v%10)+')'):'Juft: 4 ta, toq: 2 ta. Juftlar <b>2 ta</b> ko‘p');if(S.si>=6)done()}else{msg(v+' — oxirgi raqami <b>'+(v%10)+'</b>. U '+(v%2?'toq':'juft')+'!')}}
function a4ev(){w3line(398,422,2,S.ev?[[400,C.ok,'400'],[420,C.ok,'420']]:[[400,C.blue],[420,C.blue]],{big:10,fs:11});var g=S.g;if(S.ev){for(var v=402;v<420;v+=2)E('circle',{cx:S.X(v),cy:100,r:5,fill:C.ok},g);T(g,180,40,'11 ta juft son',{'font-size':18,'font-weight':800,fill:C.ok});msg('(420 − 400) : 2 + 1 = <b>11</b>')}else msg('Juft sonlarni belgilang')}
function a4house(){clear();var g=S.g;E('rect',{x:0,y:76,width:360,height:24,fill:'#cfd6dd'},g);for(var i=0;i<5;i++){var x=30+i*70;E('rect',{x:x,y:24,width:44,height:44,rx:4,fill:'#fdf0e1',stroke:'#b07a33'},g);T(g,x+22,52,String(2+i*2),{'font-size':16,'font-weight':800,fill:C.blue});E('rect',{x:x,y:108,width:44,height:44,rx:4,fill:'#e1f4f2',stroke:'#12a39f'},g);T(g,x+22,136,String(1+i*2),{'font-size':16,'font-weight':800,fill:C.a})}msg('Bir tomonda juft, bir tomonda toq')}
var PROBS=[
{t:"599 dan keyingi son:",o:["600","598","610","590"],k:0,s:"599 + 1 = 600."},
{t:"Qaysi son juft?",o:["538","417","275","999"],k:0,s:"Oxirgi raqami 8 — juft."},
{t:"Sonlar: 358, 417, 634, 920, 275, 806. Juftlar toqlardan nechta ko'p?",o:["2 ta","1 ta","3 ta","4 ta"],k:0,s:"Juft 4 ta, toq 2 ta: 4 − 2 = 2."},
{t:"Keyingi son: 305, 315, 325, …",o:["335","330","326","345"],k:0,s:"Qadam 10."},
{t:"Keyingi son: 1000, 975, 950, 925, …",o:["900","915","875","890"],k:0,s:"Qadam −25."},
{t:"Eng katta uch xonali juft son:",o:["998","999","990","988"],k:0,s:"999 toq, undan oldingisi 998."},
{t:"Eng kichik uch xonali toq son:",o:["101","100","111","103"],k:0,s:"100 juft, keyingisi 101."},
{t:"Hisoblamasdan: 375 + 128 + 449 yig'indisi qanday?",o:["Juft","Toq","1000 dan katta","100 dan kichik"],k:0,s:"Ikki toq va bir juft — juft (952)."},
{t:"Men uch xonali sonman: 400 dan kattaman, 420 dan kichikman, oxirgi raqamim 5, raqamlarim yig'indisi 10. Men qaysi sonman?",o:["415","425","405","514"],k:0,s:"4 + □ + 5 = 10 → □ = 1: 415."},
{t:"400 dan 420 gacha (ikkalasi ham kiradi) nechta juft son bor?",o:["11","10","20","21"],k:0,s:"(420 − 400) : 2 + 1 = 11."},
{t:"300 dan 330 gacha (ikkalasi ham kiradi) nechta toq son bor?",o:["15","16","14","30"],k:0,s:"301…329: (329 − 301) : 2 + 1 = 15."},
{t:"1 dan 60 gacha sonlar yozildi. 5 raqami necha marta yozilgan?",o:["16","15","6","11"],k:0,s:"Birliklarda 6, o'nliklarda 10 — 16."},
{t:"1 dan 100 gacha sonlar yozildi. 0 raqami necha marta yozilgan?",o:["11","10","9","12"],k:0,s:"10, 20, …, 90 — 9; 100 — 2. Jami 11."},
{t:"Keyingi son: 4, 6, 10, 16, 24, …",o:["34","32","36","40"],k:0,s:"Farqlar 2, 4, 6, 8, keyingisi 10: 24 + 10 = 34."},
{t:"Ketma-ket uchta juft sonning yig'indisi 642. Eng kattasi qaysi?",o:["216","214","212","218"],k:0,s:"O'rtadagisi 642 : 3 = 214, kattasi 216."},
{t:"Uchta ketma-ket sonning yig'indisi 87. Eng kattasi:",o:["30","29","28","31"],k:0,s:"O'rtasi 87 : 3 = 29, kattasi 30."},
{t:"Ko'chaning bir tomonida toq raqamli uylar. 37-uyning ikki qo'shnisi qaysi?",o:["35 va 39","36 va 38","36 va 37","33 va 41"],k:0,s:"Toq tomonda raqamlar 2 tadan o'zgaradi."},
{t:"Keyingi son: 312, 423, 534, 645, …",o:["756","746","656","757"],k:0,s:"Har safar 111 qo'shiladi: 645 + 111 = 756."},
{t:"Qaysi yig'indi albatta toq bo'ladi?",o:["juft + toq","toq + toq","juft + juft","toq + toq + juft"],k:0,s:"J + T = T; qolganlari juft."},
{t:"501 dan 599 gacha (ikkalasi ham kiradi) nechta juft son bor?",o:["49","50","99","48"],k:0,s:"502…598: (598 − 502) : 2 + 1 = 49."}
];
function PRACT_STAGE(){a4house()}
var PREP_DATA={teach:["Oldingi va keyingi son, xona to'lishi (499 → 500).","Juft-toqlik — oxirgi raqam; juft/toq yig'indisi qoidalari.","Ketma-ketlik qadami; oraliqdagi juft/toq sonlar soni; raqamni xonalab sanash."],mist:["600 dan oldingini 699 yoki 590 deydi.","Juft-toqni birinchi raqamga qarab aytadi; 0 ni juft deb bilmaydi.","Oraliqda «+1» ni unutadi (11 o'rniga 10).","55 dagi ikkinchi 5 ni yoki 100 dagi ikkinchi 0 ni sanamaydi."],need:["Son o'qi, cho'plar, 1–60 sonlar jadvali."],board:["<span class='w2'>499 → 500, 600 ← 599</span>.","<span class='w2'>juft: …0, 2, 4, 6, 8</span>.","<span class='w2'>J+J=J, T+T=J, J+T=T</span>.","<span class='w2'>(420 − 400) : 2 + 1 = 11</span>.","<span class='w2'>5 raqami 1–60: 6 + 10 = 16</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
