var CODE='2A8',TITLE='2-sinf · Yuzlik va uch xonali sonlar';
// ---------- sahna: yuzlik (kvadrat), o'nlik (tayoqcha), birlik (nuqta) ----------
var HW=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3(n){if(n===1000)return 'ming';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (HW[h]+(r?' '+word(r):'')).trim()}
function fPos(i){return [14+(i%3)*50,30+Math.floor(i/3)*46]}
function rPos(i){return [184+(i%10)*11,i<10?30:100]}
function uPos(i){return [306+(i%3)*16,36+Math.floor(i/3)*24]}
function flat(p,x,y,on){var g=E('g',{transform:'translate('+x+','+y+')'},p);E('rect',{x:0,y:0,width:40,height:40,rx:3,fill:on?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.6},g);
 for(var k=1;k<10;k++){E('line',{x1:k*4,y1:1,x2:k*4,y2:39,stroke:'#c98b45','stroke-width':.5},g);E('line',{x1:1,y1:k*4,x2:39,y2:k*4,stroke:'#c98b45','stroke-width':.5},g)}return g}
function rod2(p,x,y,h,on){var g=E('g',{transform:'translate('+x+','+y+')'},p);E('rect',{x:-4,y:0,width:8,height:h,rx:3,fill:on?C.hi:C.t2,stroke:C.t1,'stroke-width':1.2},g);for(var k=1;k<10;k++)E('line',{x1:-4,y1:k*h/10,x2:4,y2:k*h/10,stroke:C.t1,'stroke-width':.5},g);return g}
function pv3(h,t,u,o){o=o||{};clear();var g=S.g;S.H=[];S.T=[];S.U=[];
 E('rect',{x:4,y:4,width:164,height:166,rx:10,fill:'#fdf0dc',stroke:'#efd9b5'},g);E('rect',{x:172,y:4,width:120,height:166,rx:10,fill:'#fdf3e3',stroke:'#efd9b5'},g);E('rect',{x:296,y:4,width:60,height:166,rx:10,fill:'#e3f5f3',stroke:'#bfe6e1'},g);
 T(g,86,20,'Yuzliklar',{'font-size':11,'font-weight':800,fill:C.t1});T(g,232,20,'O‘nliklar',{'font-size':11,'font-weight':800,fill:'#b07a33'});T(g,326,20,'Birliklar',{'font-size':11,'font-weight':800,fill:C.u});
 var rh=t>10?60:120;for(var i=0;i<h;i++){var a=fPos(i);S.H.push(flat(g,a[0],a[1],o.hh&&o.hh.indexOf(i)>=0))}
 for(var j=0;j<t;j++){var b=rPos(j);S.T.push(rod2(g,b[0],b[1],rh,o.th))}
 for(var k=0;k<u;k++){var c=uPos(k);S.U.push(E('circle',{cx:c[0],cy:c[1],r:6,fill:o.uh?C.hi:C.u,stroke:'rgba(0,0,0,.2)'},g))}
 S.h=h;S.t=t;S.u=u;if(!o.nostrip)tab(h,t,u)}
function tab(h,t,u,note){var ok=t<10&&u<10,n=h*100+t*10+u;
 strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div style="display:flex;gap:6px;align-items:stretch"><div class="pt3 h"><span>Yuzliklar</span><b>'+h+'</b></div><div class="pt3 t"><span>O‘nliklar</span><b>'+t+'</b></div><div class="pt3 u"><span>Birliklar</span><b>'+u+'</b></div><div class="eq3">'+(ok?'<b>'+n+'</b><small>'+(h?h*100:'')+(t?(h?' + ':'')+t*10:'')+(u||(!h&&!t)?((h||t)?' + ':'')+u:'')+'<br>«'+w3(n)+'»</small>':'<b style="color:#d94b4b">?</b><small>'+(t>9?'o‘nliklar':'birliklar')+' 9 tadan ko‘p</small>')+'</div></div></div>'}
// ---------- bosqichlar ----------
var P7=[function(){pv3(6,14,7,{nostrip:1});tab(6,14,7,'6 yuzlik, 14 o‘nlik, 7 birlik — o‘nliklar 9 tadan ko‘p!')},
 function(){pv3(6,14,7,{nostrip:1});for(var i=0;i<10;i++)S.T[i].querySelector('rect').setAttribute('fill',C.hi);tab(6,14,7,'14 o‘nlikdan 10 tasi — bitta yangi yuzlik!')},
 function(){pv3(7,4,7);tab(7,4,7,'7 yuzlik, 4 o‘nlik, 7 birlik = 747')}];
var P6=[function(){pv3(3,4,2,{nostrip:1});tab(3,4,2,'Son — 342. Uni bo‘laklarga ajratamiz')},
 function(){pv3(3,4,2,{hh:[0,1,2]});arrowCards([300,40,2],false);},
 function(){pv3(3,4,2);arrowCards([300,40,2],true)}];
var P8=[function(){pv3(9,9,9);tab(9,9,9,'999 — eng katta uch xonali son. Yana 1 qo‘shamiz…')},
 function(){pv3(9,10,0,{nostrip:1,th:1});tab(9,10,0,'9 + 1 = 10 birlik → 1 o‘nlik. Endi o‘nliklar 10 ta!')},
 function(){pv3(10,0,0,{nostrip:1,hh:[9]});strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">10 o‘nlik → 1 yuzlik. Endi yuzliklar <b>10 ta</b>!</div></div>'},
 function(){clear();cube();strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center;font-size:18px">10 yuzlik = <b>1 ming</b> = 1000. Bu — <b>to‘rt xonali</b> son</div></div>'}];
var STEPS=[
{h:"O'nta o'nlik — bitta yuzlik",sum:"10 ta o'nlik birlashsa — 1 yuzlik (100). Yuzlikda 10 ta o'nlik, 100 ta birlik.",a:"m01",
 start:function(){pv3(0,10,0,{nostrip:1});tab(0,10,0,'O‘nliklar 10 ta bo‘ldi — 9 tadan ko‘p!')},fin:function(){pv3(1,0,0)},
 html:"<p>2A1 da 10 ta donani bitta o'nlikka yig'gan edik. Endi qarang: tepada <b>10 ta o'nlik</b> (tayoqcha) bor. O'nliklar ham 10 taga yetdi! Ular ham birlashadi. Tugmani bosing.</p>",
 btns:[["📦 10 ta o'nlikni birlashtirish",function(c,done,b){b.disabled=true;var tok=S.tok;var tg=S.T.slice();tween(900,function(k){tg.forEach(function(r,i){var p=rPos(i),x=p[0]+(14+i*4-p[0])*k,y=p[1]+(30-p[1])*k;r.setAttribute('transform','translate('+x+','+y+') scale(1,'+(1-k*.66)+')')})}).then(function(){if(tok!==S.tok)return;pv3(1,0,0);done()})}]],
 after:"<p>10 ta o'nlik birlashib, katta kvadrat — <b>yuzlik</b> bo'ldi. Unda 10 ta o'nlik bor, har o'nlikda 10 ta birlik. Demak, yuzlikda <b>100 ta</b> birlik.</p><div class='life'><div>💯<span><b>10 birlik = 1 o'nlik</b>, <b>10 o'nlik = 1 yuzlik</b> — qoida bir xil!</span></div></div>",
 q:{t:"1 ta yuzlikda nechta o'nlik bor?",opts:["1","10","100","9"],ok:1,why:"Yuzlik 10 ta o'nlikdan tuzilgan.",hint:"Yuzlik nimadan yig'ildi? Nechta tayoqcha birlashdi?",full:"Yuzlik 10 ta o'nlikni birlashtirib hosil bo'ldi. Demak 1 yuzlik = 10 o'nlik = 100 birlik."},
 tn:"Xalqaro amaliyotda «o'nlik bloklar» (Dienes) va Montessori «oltin munchoqlari» ishlatiladi. Bo'lmasa, qog'ozdan 10×10 kvadrat kesib, 10 ta tasmaga qirqing — bolalar yuzlik 10 ta o'nlik ekanini qo'li bilan ko'radi."},
{h:"Yuzlikni ochib ko'ring",sum:"Yuzlikda 10 qator, har qatorda 10 tadan — jami 100 ta.",a:"m02",
 start:function(){pv3(1,0,0);bigFlat(false)},fin:function(){bigFlat(true)},
 html:"<p>Yuzlik rostdan 100 tami? Tekshiramiz. Katta yuzlikni <b>bosing</b> — qatorlari sanaladi.</p>",
 act:function(c,done){c.querySelector('.hint').textContent='Rasmdagi katta kvadratni bosing.';S.onFlat=function(){S.onFlat=null;done()}},
 after:"<p>10 ta qator — har biri bitta o'nlik: 10, 20, 30, … 100. Yuzlik — <b>bitta narsa</b> emas, u <b>100 ta birlik</b>, tartib bilan yig'ilgan!</p>",
 q:{t:"4 ta yuzlik — bu nechta o'nlik?",opts:["4","400","40","14"],ok:2,why:"Har yuzlikda 10 ta o'nlik: 4 · 10 = 40.",hint:"1 yuzlikda 10 ta o'nlik. 4 ta yuzlikda-chi?",full:"Har bir yuzlik — 10 ta o'nlik. 4 ta yuzlik: 10 + 10 + 10 + 10 = 40 ta o'nlik. Birliklar esa 400 ta."},
 tn:"Sinfda 100 ta narsani (cho'p, qopqoq) 10 tadan bog'lab, 10 ta bog'lamni bitta qutiga soling. «Bu quti — yuzlik» deng."},
{h:"Uch xonali sonni yasaymiz",sum:"Uch xonali son: chapda yuzliklar, o'rtada o'nliklar, o'ngda birliklar. 342 = 3 yuzlik, 4 o'nlik, 2 birlik.",a:"m03",
 start:function(){pv3(3,4,2)},fin:function(){pv3(3,4,2)},
 html:"<p>Endi sonda <b>uch</b> xil narsa bor: yuzliklar, o'nliklar, birliklar. Tugmalar bilan o'zingiz son yasang — pastda son va uning nomi o'zgarib boradi.</p>",
 btns:[["+ yuzlik",function(c,done){if(S.h<9){pv3(S.h+1,S.t,S.u);mvK(done)}}],["+ o'nlik",function(c,done){if(S.t<9){pv3(S.h,S.t+1,S.u);mvK(done)}}],["+ birlik",function(c,done){if(S.u<9){pv3(S.h,S.t,S.u+1);mvK(done)}},'u'],["− yuzlik",function(c,done){if(S.h){pv3(S.h-1,S.t,S.u);mvK(done)}}],["− o'nlik",function(c,done){if(S.t){pv3(S.h,S.t-1,S.u);mvK(done)}}],["− birlik",function(c,done){if(S.u){pv3(S.h,S.t,S.u-1);mvK(done)}},'u']],g3:1,
 after:"<p>Uch xonali son yozilganda: <b>chapdagi</b> raqam — yuzliklar, <b>o'rtadagi</b> — o'nliklar, <b>o'ngdagi</b> — birliklar. 342 da: 3 ta yuzlik, 4 ta o'nlik, 2 ta birlik.</p>",
 q:{t:"5 ta yuzlik, 2 ta o'nlik va 8 ta birlik — qaysi son?",opts:["582","528","5208","258"],ok:1,why:"Chapga yuzliklar 5, o'rtaga o'nliklar 2, o'ngga birliklar 8: 528.",hint:"Raqamlarni joyiga qo'ying: yuzliklar — chapda, birliklar — o'ngda.",full:"Yuzliklar 5 — chapda, o'nliklar 2 — o'rtada, birliklar 8 — o'ngda: 528. «5208» — har biri alohida yozilgan, bu xato."},
 tn:"Doskaga uch ustunli jadval: «Yuzliklar | O'nliklar | Birliklar». Bolalar navbat bilan kubik/tayoqcha qo'shib, son yozib boradi."},
{h:"Uch xonali sonni o'qiymiz",sum:"Avval yuzliklar, keyin qolgan ikki xonali son: 342 — «uch yuz qirq ikki».",a:"m04",
 start:function(){pv3(3,4,2)},fin:function(){pv3(7,1,5)},
 html:"<p>Uch xonali son ikki bo'lakda o'qiladi: avval <b>yuzliklar</b> («uch yuz»), keyin qolgan ikki xonali son («qirq ikki»). Tasodifiy son chiqaring va o'qing:</p>",
 btns:[["🎲 Tasodifiy son",function(c,done){var h=1+Math.floor(Math.random()*9),t=Math.floor(Math.random()*10),u=Math.floor(Math.random()*10);pv3(h,t,u);mvK(done,3)}]],
 after:"<p>Diqqat: <b>«bir yuz»</b> ham, oddiy <b>«yuz»</b> ham deyiladi (100 — yuz). 715 — «yetti yuz o'n besh».</p>",
 q:{t:"«Besh yuz o'n yetti» qanday yoziladi?",opts:["5017","50017","517","571"],ok:2,why:"5 yuzlik, 1 o'nlik, 7 birlik: 517.",hint:"Nechta yuzlik? «O'n yetti» da nechta o'nlik va birlik bor?",full:"Besh yuz — 5 yuzlik. O'n yetti — 1 o'nlik va 7 birlik. Son: 517. «5017» — eshitganini bo'laklab yozish xatosi."},
 tn:"Eng ko'p xato: «besh yuz o'n yetti» ni «50017» yoki «5017» deb yozish. Har son uch xonali bo'lishini, uchta katak borligini eslating."},
{h:"Nol — bo'sh xona belgisi",sum:"305: o'nliklar yo'q — o'rtaga 0 yoziladi. 0 bo'lmasa 35 bo'lib qoladi.",a:"m05",
 start:function(){pv3(3,0,5)},fin:function(){pv3(3,0,5)},
 html:"<p>«Uch yuz besh» — bu yerda o'nliklar <b>yo'q</b>. Qanday yozamiz? Tugmalarni bosib solishtiring:</p>",
 btns:[["305",function(c,done){pv3(3,0,5);mvK(done,2)}],["350",function(c,done){pv3(3,5,0);mvK(done,2)}],["35",function(c,done){pv3(0,3,5);mvK(done,2)}]],
 after:"<p>305 da o'nliklar yo'q, lekin uning o'rni <b>bo'sh qolmaydi</b> — u yerga <b>0</b> yoziladi. 0 ni tashlab yuborsak, 35 bo'lib qoladi: yuzliklar o'nlikka aylanib ketadi!</p>",
 q:{t:"«To'rt yuz yetti» qanday yoziladi?",opts:["47","4007","407","470"],ok:2,why:"4 yuzlik, 0 o'nlik, 7 birlik: 407.",hint:"O'nliklar bormi? Bo'lmasa, uning o'rniga nima yoziladi?",full:"To'rt yuz — 4 yuzlik. O'nlik yo'q — 0. Yetti — 7 birlik. Son: 407. «470» — yetti o'nlik bo'lib qoladi, «47» — yuzlik yo'qolib qoladi."},
 tn:"«Bo'sh xona» uchun jadvalda bo'sh katak qoldiring va unga 0 yozdiring. Bolalar 0 ni «hech narsa» emas, «joy saqlovchi» deb tushunsin."},
{h:"Xona qo'shiluvchilari",sum:"342 = 300 + 40 + 2. Kartochkalar ustma-ust qo'yilsa — 342.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Har bir raqam o'z xonasida <b>alohida qiymatga</b> ega. Montessori kartochkalari bilan ko'raylik: sonni bo'laklarga ajratib, keyin yig'amiz.</p>",
 btns:[phaser(P6)],
 after:"<p>342 = <b>300 + 40 + 2</b>. 3 — bu 3 emas, <b>300</b>; 4 — bu 4 emas, <b>40</b>. Bu yozuv «xona qo'shiluvchilari yig'indisi» deyiladi.</p>",
 q:{t:"600 + 7 qaysi songa teng?",opts:["67","6007","670","607"],ok:3,why:"6 yuzlik, 0 o'nlik, 7 birlik: 607.",hint:"O'nliklar qo'shiluvchisi bormi? Yo'q bo'lsa, o'rtaga nima yoziladi?",full:"600 — 6 yuzlik, 7 — 7 birlik, o'nlik yo'q. Son: 607. Kartochkalarni ustma-ust qo'ysak, 7 600 ning oxirgi nolini yopadi."},
 tn:"Montessori «strelkali kartochkalar» (300, 40, 2) ni qog'ozdan yasang: ustma-ust qo'yilsa 342, ajratilsa 300 + 40 + 2 ko'rinadi."},
{h:"Tuzoq: o'nliklar 9 tadan ko'p bo'lsa",sum:"6 yuzlik + 14 o'nlik + 7 birlik: 10 o'nlik → 1 yuzlik. Javob: 747.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Testda shunday keladi: <b>□ = 6 yuzlik + 14 o'nlik + 7 birlik</b>. «6147» deb yozib qo'ymang! Kuzating.</p>",
 btns:[phaser(P7)],
 after:"<p>14 o'nlikdan 10 tasi — yana bitta <b>yuzlik</b>. Endi 7 yuzlik, 4 o'nlik, 7 birlik = <b>747</b>. Yoki hisoblab: 600 + 140 + 7 = 747.</p>",
 q:{t:"4 yuzlik + 12 o'nlik + 5 birlik — qaysi son?",opts:["4125","525","4215","515"],ok:1,why:"12 o'nlik = 1 yuzlik 2 o'nlik. 5 yuzlik, 2 o'nlik, 5 birlik: 525.",hint:"12 o'nlikdan 10 tasini yuzlikka aylantiring.",full:"400 + 120 + 5 = 525. Yoki: 12 o'nlikdan 10 tasi — 1 yuzlik, 2 o'nlik qoladi. 5 yuzlik, 2 o'nlik, 5 birlik — 525."},
 tn:"Bank va olimpiada testlarida tez-tez keladi. Bolalar avval xonalar bo'yicha qiymatini yozsin (600 + 140 + 7), keyin qo'shsin."},
{h:"999 dan keyin — ming!",sum:"999 + 1: 10 birlik → o'nlik, 10 o'nlik → yuzlik, 10 yuzlik → 1 ming (1000).",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>999 — eng katta uch xonali son. Unga 1 qo'shsak nima bo'ladi? Zanjirni kuzating.</p>",
 btns:[phaser(P8)],
 after:"<p>Hammasi bir xil qoida: <b>10 ta bo'lsa — bitta kattasiga aylanadi</b>. 10 birlik → o'nlik, 10 o'nlik → yuzlik, 10 yuzlik → <b>ming</b>. 1000 — to'rt xonali son, uni keyingi sinfda batafsil o'rganasiz.</p>",
 q:{t:"Ming nechta yuzlikdan iborat?",opts:["100","10","1000","9"],ok:1,why:"10 ta yuzlik = 1 ming.",hint:"999 + 1 da oxirida nechta yuzlik bo'ldi?",full:"Yuzliklar 10 taga yetdi va mingga aylandi. 1 ming = 10 yuzlik = 100 o'nlik = 1000 birlik."},
 tn:"«Ming» — darslikning 132-darsi. Bu yerda faqat tanishtiramiz: 10 yuzlik = 1 ming."},
{h:"Bilasizmi? Misrliklarning yuzligi",sum:"Qadimgi Misrda 100 — o'ralgan arqon belgisi. 342 = 3 arqon, 4 ∩, 2 |.",a:"m09",
 start:function(){egy3(false)},fin:function(){egy3(true)},
 html:"<p>🏺 2A1 da misrliklar o'nlikni <b>∩</b>, birlikni <b>|</b> bilan yozganini ko'rgan edik. Yuzlik uchun ular <b>o'ralgan arqon</b> belgisini chizishgan. 342 ni misrcha yozamiz:</p>",
 btns:[["🏺 Misrcha yozish",function(c,done){egy3(true);done()}]],
 after:"<p>342 misrcha — <b>9 ta belgi</b>, bizda esa atigi <b>3 ta raqam</b>. 999 ni yozish uchun misrliklarga 27 ta belgi kerak edi! Raqamning <b>o'rniga qarab</b> yozish usuli — dunyoga al-Xorazmiy kitobi orqali tarqalgan.</p>",
 tn:"Bolalar o'z tug'ilgan yilini yoki sinf raqamini misrcha yozib ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){pv3(3,4,2)},fin:function(){pv3(3,4,2)},
 html:"<div class='memo'><ul><li><b>10 birlik = 1 o'nlik</b>, <b>10 o'nlik = 1 yuzlik</b> (100), <b>10 yuzlik = 1 ming</b> (1000).</li><li>Uch xonali son: <b>yuzliklar | o'nliklar | birliklar</b>. 342 = 3 yuzlik, 4 o'nlik, 2 birlik.</li><li>O'qish: avval yuzliklar, keyin ikki xonali qism — «uch yuz qirq ikki».</li><li>Xona bo'sh bo'lsa — <b>0</b>: «uch yuz besh» = <b>305</b>.</li><li>Xona qo'shiluvchilari: 342 = 300 + 40 + 2; 607 = 600 + 7.</li><li>O'nliklar 9 tadan ko'p bo'lsa — yuzlikka aylantiring: 6 yuzlik + 14 o'nlik + 7 = <b>747</b>.</li><li>Eng kichik uch xonali son — <b>100</b>, eng kattasi — <b>999</b>.</li></ul></div>",
 tn:"Keyingi darsni «Eng kichik va eng katta uch xonali son qaysi? Ular orasida nechta son bor?» savoli bilan boshlang (100 va 999; 899 ta oraliq son, jami 900 ta uch xonali son)."}
];
// katta yuzlik (ochib ko'rish)
function bigFlat(open){clear();var g=S.g,x0=110,y0=14,s=14;var all=E('g',{style:'cursor:pointer'},g);
 for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*s,y:y0+r*s,width:s-1,height:s-1,rx:2,fill:open?(r%2?C.t2:'#f6c98a'):'#f2b766',stroke:C.t1,'stroke-width':.6},all);
 if(open)for(var r2=0;r2<10;r2++)T(g,x0-16,y0+r2*s+10,String((r2+1)*10),{'font-size':9,'font-weight':800,fill:C.t1});
 all.addEventListener('click',function(){if(!open){bigFlat(true);if(S.onFlat)S.onFlat()}});
 strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+(open?'10 qator × 10 = <b>100</b>. Har qator — bitta o‘nlik':'Kvadratni bosing')+'</div></div>'}
// strelkali kartochkalar
function arrowCards(vals,stack){var lay=E('g',{},S.g);E('rect',{x:20,y:40,width:320,height:90,rx:12,fill:'rgba(255,255,255,.94)',stroke:'#c9d3dd'},lay);
 var CW=17,cols=['#f2b766','#f6d9a8','#bfe9e3'],R=stack?[226,226,226]:[118,222,318];
 vals.forEach(function(v,i){var s=String(v),w=s.length*CW+10,r=R[i],x=r-w;E('rect',{x:x,y:62,width:w,height:46,rx:6,fill:cols[i],stroke:C.line,'stroke-width':1.5},lay);T(lay,r-6,96,s,{'font-size':28,'font-weight':800,fill:'#1d2b3a','text-anchor':'end','font-family':'ui-monospace,Menlo,Consolas,monospace'})});
 if(!stack){T(lay,135,94,'+',{'font-size':24,'font-weight':800});T(lay,240,94,'+',{'font-size':24,'font-weight':800})}
 strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center;font-size:18px">'+(stack?'Kartochkalar ustma-ust: <b>342</b> — nollar yopilib qoladi':'342 = <b>300</b> + <b>40</b> + <b>2</b>')+'</div></div>'}
function cube(){var g=S.g,x=130,y=40,s=70,d=28;E('path',{d:'M'+x+' '+y+' l'+d+' '+(-d*.6)+' h'+s+' l'+(-d)+' '+(d*.6)+' Z',fill:'#f6c98a',stroke:C.t1,'stroke-width':1.5},g);E('path',{d:'M'+(x+s)+' '+y+' l'+d+' '+(-d*.6)+' v'+s+' l'+(-d)+' '+(d*.6)+' Z',fill:'#d9954a',stroke:C.t1,'stroke-width':1.5},g);E('rect',{x:x,y:y,width:s,height:s,fill:'#f2b766',stroke:C.t1,'stroke-width':1.5},g);
 for(var k=1;k<10;k++){E('line',{x1:x+k*7,y1:y,x2:x+k*7,y2:y+s,stroke:'#c98b45','stroke-width':.4},g);E('line',{x1:x,y1:y+k*7,x2:x+s,y2:y+k*7,stroke:'#c98b45','stroke-width':.4},g)}T(g,x+s/2,y+s+30,'1 ming = 10 yuzlik',{'font-size':14,'font-weight':800,fill:C.t1})}
function egy3(on){clear('#f6ead0');var g=S.g;T(g,180,26,'342',{'font-size':22,'font-weight':800,fill:'#6b3d12'});if(!on){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">Misrliklar 342 ni qanday yozgan?</div></div>';return}
 var x=40;for(var i=0;i<3;i++){var cx=x+14,cy=100;E('path',{d:'M'+cx+' '+(cy+20)+' C'+(cx-16)+' '+(cy+18)+' '+(cx-16)+' '+(cy-14)+' '+cx+' '+(cy-14)+' C'+(cx+14)+' '+(cy-14)+' '+(cx+14)+' '+(cy+8)+' '+cx+' '+(cy+8)+' C'+(cx-6)+' '+(cy+8)+' '+(cx-6)+' '+(cy-2)+' '+cx+' '+(cy-2),fill:'none',stroke:'#6b3d12','stroke-width':4,'stroke-linecap':'round'},g);x+=38}
 x+=6;for(var j=0;j<4;j++){E('path',{d:'M'+x+' 124 L'+x+' 98 Q'+(x+10)+' 80 '+(x+20)+' 98 L'+(x+20)+' 124',fill:'none',stroke:'#6b3d12','stroke-width':4,'stroke-linecap':'round'},g);x+=28}
 x+=6;for(var k=0;k<2;k++){E('line',{x1:x,y1:90,x2:x,y2:124,stroke:'#6b3d12','stroke-width':4,'stroke-linecap':'round'},g);x+=13}
 T(g,180,156,'arqon = 100,  ∩ = 10,  | = 1',{'font-size':12,fill:'#6b3d12'});strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">342 misrcha — 9 ta belgi, bizda — 3 ta raqam</div></div>'}
var PROBS=[
{t:"3 ta yuzlik, 7 ta o'nlik va 1 ta birlik — qaysi son?",o:["371","317","173","3071"],k:0,s:"Yuzliklar 3, o'nliklar 7, birliklar 1: 371."},
{t:"«Olti yuz ellik» qanday yoziladi?",o:["650","6050","605","65"],k:0,s:"6 yuzlik, 5 o'nlik, 0 birlik: 650."},
{t:"«Sakkiz yuz uch» qanday yoziladi?",o:["803","830","8003","83"],k:0,s:"8 yuzlik, 0 o'nlik, 3 birlik: 803."},
{t:"485 sonida nechta o'nlik bor (o'nliklar xonasida qaysi raqam)?",o:["8","4","5","48"],k:0,s:"485: 4 yuzlik, 8 o'nlik, 5 birlik. O'nliklar xonasida 8."},
{t:"700 + 20 + 9 qaysi songa teng?",o:["729","7209","792","927"],k:0,s:"7 yuzlik, 2 o'nlik, 9 birlik: 729."},
{t:"508 ni xona qo'shiluvchilariga ajrating.",o:["500 + 8","50 + 8","500 + 80","5 + 0 + 8"],k:0,s:"508 = 5 yuzlik + 8 birlik = 500 + 8."},
{t:"6 yuzlik + 14 o'nlik + 7 birlik — qaysi son?",o:["747","6147","657","754"],k:0,s:"600 + 140 + 7 = 747."},
{t:"Eng kichik uch xonali son qaysi?",o:["100","101","999","10"],k:0,s:"Yuzliklar kamida 1 bo'lishi kerak: 100."},
{t:"Eng katta uch xonali son qaysi?",o:["999","990","1000","900"],k:0,s:"Har xonada eng katta raqam — 9: 999. 1000 — to'rt xonali."},
{t:"1 yuzlikda nechta birlik bor?",o:["100","10","1","1000"],k:0,s:"1 yuzlik = 10 o'nlik = 100 birlik."},
{t:"23 ta o'nlik — qaysi son?",o:["230","23","2030","320"],k:0,s:"23 o'nlik = 20 o'nlik + 3 o'nlik = 200 + 30 = 230."},
{t:"7 ta yuzlik, yuzliklardan 6 ta kam o'nlik va o'nliklardan 5 ta ko'p birlik — qaysi son?",o:["716","761","756","765"],k:0,s:"Yuzlik 7, o'nlik 7 − 6 = 1, birlik 1 + 5 = 6: 716."},
{t:"Uch xonali sonning yuzlar raqami 4, o'nlar raqami undan 3 ta katta, birlar raqami esa o'nlar va yuzlar raqamlari ayirmasiga teng. Sonni toping.",o:["473","471","743","437"],k:0,s:"Yuzlar 4, o'nlar 4 + 3 = 7, birlar 7 − 4 = 3: 473."},
{t:"Qaysi sonda yuzlar ham, o'nlar ham, birlar ham bir xil raqam?",o:["444","404","440","414"],k:0,s:"444: uchala xonada 4."},
{t:"999 dan keyin qaysi son keladi?",o:["1000","9910","990","10000"],k:0,s:"999 + 1 = 1000 — ming."},
{t:"Ming nechta yuzlikdan iborat?",o:["10","100","1000","9"],k:0,s:"1000 = 10 ta yuzlik."},
{t:"3, 0, 5 raqamlaridan (har biri bir marta) eng katta uch xonali son?",o:["530","503","350","305"],k:0,s:"Eng katta raqamni yuzliklarga: 5, keyin 3, oxirida 0: 530."},
{t:"3, 0, 5 raqamlaridan (har biri bir marta) eng kichik uch xonali son?",o:["305","035","350","503"],k:0,s:"0 birinchi tura olmaydi. Eng kichik: 3 _ _, keyin 0, keyin 5: 305."},
{t:"Raqamlari yig'indisi 3 ga teng uch xonali sonlar nechta?",o:["6","4","5","7"],k:0,s:"300, 210, 201, 120, 102, 111 — 6 ta."},
{t:"256 soniga 1 ta yuzlik qo'shilsa, qaysi son chiqadi?",o:["356","257","266","1256"],k:0,s:"Yuzliklar 2 dan 3 ga: 356."}
];
function PRACT_STAGE(){pv3(3,4,2)}
var PREP_DATA={teach:["10 o'nlik = 1 yuzlik; yuzlikda 100 ta birlik.","Uch xonali sonni yasash, o'qish, yozish; xonalar: yuzliklar, o'nliklar, birliklar.","Bo'sh xonada 0 (305); xona qo'shiluvchilari (342 = 300 + 40 + 2).","O'nliklar 9 tadan ko'p bo'lgan tuzoq (6 yuzlik + 14 o'nlik + 7); 999 + 1 = 1000."],
 mist:["«Besh yuz o'n yetti» ni 50017 yoki 5017 deb yozadi.","Bo'sh xonani tashlab yuboradi: 305 o'rniga 35.","Yuzlikni «bitta narsa» deb sanaydi.","6 yuzlik + 14 o'nlik + 7 ni 6147 deb yozadi."],
 need:["10×10 kvadrat (qog'ozdan) va 10 talik tasmalar.","100 ta cho'p yoki qopqoq.","Strelkali kartochkalar: 100–900, 10–90, 1–9."],
 board:["Jadval: <span class='w2'>Yuzliklar | O'nliklar | Birliklar</span>.","<span class='w2'>10 o'nlik = 1 yuzlik = 100</span>.","<span class='w2'>342 = 3 yuzlik 4 o'nlik 2 birlik</span>, «uch yuz qirq ikki».","<span class='w2'>305</span> — o'nlik yo'q, 0.","<span class='w2'>342 = 300 + 40 + 2</span>.","Tuzoq: <span class='w2'>600 + 140 + 7 = 747</span>.","<span class='w2'>999 + 1 = 1000</span>."]};
