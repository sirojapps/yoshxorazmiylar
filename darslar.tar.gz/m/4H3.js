// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4H3',TITLE='4-sinf · Burchaklar, uchburchaklar, chizmalar';
function h3ang(d,name){clear();g4ang(d>100?180:110,150,0,d,d>100?100:120,d===90?C.ok:d<90?C.blue:C.a2,d+'°');T(S.g,d>100?180:290,d>100?28:60,name,{'font-size':15,'font-weight':800,fill:'#1d2b3a'});T(S.g,d>100?180:290,d>100?46:80,d<90?'90° dan kichik':d===90?'roppa-rosa 90°':d<180?'90° dan katta, 180° dan kichik':'to‘g‘ri chiziq: 180°',{'font-size':11,'font-weight':700,fill:'#5b6b7b'})}
function h3tri(pts,fill,lab){var g=S.g;E('polygon',{points:pts.map(function(p){return p.join(',')}).join(' '),fill:fill||'#fbe0b4',stroke:C.t1,'stroke-width':2.2,'stroke-linejoin':'round'},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
function h3kind(k){clear();var g=S.g;
 if(k===0){h3tri([[90,140],[270,140],[200,30]],'#cfe7f7');T(g,180,164,'Hamma burchaklari o‘tkir',{'font-size':12,'font-weight':800,fill:C.blue})}
 if(k===1){h3tri([[100,140],[260,140],[100,36]],'#d6efc7');E('path',{d:'M100 126 h14 v14',fill:'none',stroke:C.ok,'stroke-width':2},g);T(g,180,164,'Bitta burchagi to‘g‘ri (90°)',{'font-size':12,'font-weight':800,fill:C.ok})}
 if(k===2){h3tri([[60,140],[230,140],[300,70]],'#fde2c4');E('path',{d:'M212 140 A18 18 0 0 1 243 127',fill:'none',stroke:C.a2,'stroke-width':2.4},g);T(g,180,164,'Bitta burchagi o‘tmas (> 90°)',{'font-size':12,'font-weight':800,fill:C.a2})}}
function h3side(k){clear();var g=S.g;
 if(k===0){h3tri([[110,140],[250,140],[180,19]],'#cfe7f7',[[132,84,'5','#1d2b3a'],[228,84,'5','#1d2b3a'],[180,158,'5','#1d2b3a']]);T(g,320,40,'Teng tomonli',{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
 if(k===1){h3tri([[120,140],[240,140],[180,24]],'#d6efc7',[[136,80,'6','#1d2b3a'],[226,80,'6','#1d2b3a'],[180,158,'4','#1d2b3a']]);T(g,320,40,'Teng yonli',{'font-size':13,'font-weight':800,fill:C.ok,'text-anchor':'end'});T(g,320,60,'2 tomoni teng',{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'})}
 if(k===2){h3tri([[80,140],[270,140],[130,40]],'#fde2c4',[[94,90,'4','#1d2b3a'],[212,84,'6','#1d2b3a'],[175,158,'7','#1d2b3a']]);T(g,330,40,'Turli tomonli',{'font-size':13,'font-weight':800,fill:C.a2,'text-anchor':'end'})}}
function h3sticks(a,b,c){clear();var g=S.g,s=22,ok=a+b>c&&a+c>b&&b+c>a;
 var L=Math.max(a,b,c),x0=180-L*s/2,y=140;E('line',{x1:x0,y1:y,x2:x0+L*s,y2:y,stroke:'#8a5a24','stroke-width':6,'stroke-linecap':'round'},g);T(g,180,y+18,String(L),{'font-size':13,'font-weight':800,fill:'#5b3b1c'});
 var o=[a,b,c].sort(function(p,q){return p-q}),p=o[0],q=o[1];
 if(ok){var X=(p*p-q*q+L*L)/(2*L),Y=Math.sqrt(Math.max(0,p*p-X*X));var tx=x0+X*s,ty=y-Y*s;E('line',{x1:x0,y1:y,x2:tx,y2:ty,stroke:C.blue,'stroke-width':6,'stroke-linecap':'round'},g);E('line',{x1:x0+L*s,y1:y,x2:tx,y2:ty,stroke:C.ok,'stroke-width':6,'stroke-linecap':'round'},g);T(g,(x0+tx)/2-12,(y+ty)/2,String(p),{'font-size':13,'font-weight':800,fill:C.blue});T(g,(x0+L*s+tx)/2+12,(y+ty)/2,String(q),{'font-size':13,'font-weight':800,fill:C.ok});g4m(p+' + '+q+' = '+(p+q)+' > '+L+' → <b>uchburchak bo‘ladi</b> ✓')}
 else{E('line',{x1:x0,y1:y-4,x2:x0+p*s*.9,y2:y-30,stroke:C.blue,'stroke-width':6,'stroke-linecap':'round'},g);E('line',{x1:x0+L*s,y1:y-4,x2:x0+L*s-q*s*.9,y2:y-30,stroke:C.ok,'stroke-width':6,'stroke-linecap':'round'},g);T(g,180,40,'Uchlari uchrashmaydi!',{'font-size':14,'font-weight':800,fill:C.bad});g4m(p+' + '+q+' = '+(p+q)+(p+q===L?' = ':' < ')+L+' → <b>uchburchak bo‘lmaydi</b> ✗')}}
var TR=[[100,140],[270,140],[150,40]];
var P5=[function(){clear();h3tri(TR,'#fbe0b4');var g=S.g;[[100,140,C.bad],[270,140,C.blue],[150,40,C.ok]].forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:13,fill:p[2],opacity:.45},g)});calc(['Uchburchak burchaklarini qaychi bilan qirqib olamiz…'])},
 function(){clear();var g=S.g;E('line',{x1:40,y1:120,x2:320,y2:120,stroke:'#1d2b3a','stroke-width':2},g);E('path',{d:'M180 120 L130 120 A50 50 0 0 1 152 79 Z',fill:'#f8b4b4',stroke:C.bad,'stroke-width':1.5},g);E('path',{d:'M180 120 L152 79 A50 50 0 0 1 220 90 Z',fill:'#bde7c4',stroke:C.ok,'stroke-width':1.5},g);calc(['…va bir nuqtaga yonma-yon qo‘yamiz'])},
 function(){clear();var g=S.g;E('line',{x1:40,y1:120,x2:320,y2:120,stroke:'#1d2b3a','stroke-width':2},g);E('path',{d:'M180 120 L130 120 A50 50 0 0 1 152 79 Z',fill:'#f8b4b4',stroke:C.bad,'stroke-width':1.5},g);E('path',{d:'M180 120 L152 79 A50 50 0 0 1 220 90 Z',fill:'#bde7c4',stroke:C.ok,'stroke-width':1.5},g);E('path',{d:'M180 120 L220 90 A50 50 0 0 1 230 120 Z',fill:'#bfdcf5',stroke:C.blue,'stroke-width':1.5},g);T(g,180,150,'Yoyiq burchak: 180°',{'font-size':15,'font-weight':800,fill:C.a2});calc(['Uchta burchak birga <b>yoyiq burchak</b> hosil qildi','Uchburchak burchaklari yig‘indisi = <b>180°</b>'])}];
function h3clock(h,deg){clear();g4clock(h,0,120,86,64,'');var g=S.g;T(g,270,70,h+':00',{'font-size':24,'font-weight':800,fill:'#1d2b3a'});T(g,270,100,deg+'°',{'font-size':22,'font-weight':800,fill:C.a2});T(g,270,124,(deg/30)+' · 30° = '+deg+'°',{'font-size':11,'font-weight':700,fill:'#5b6b7b'});g4m('Ikki raqam orasi: 360° : 12 = <b>30°</b>')}
function h3cnt(k){clear();var g=S.g,A=[180,22],B=[60,145],Cc=[300,145],D=[140,145],F=[220,145];
 var tri=[[A,B,D],[A,D,F],[A,F,Cc],[A,B,F],[A,D,Cc],[A,B,Cc]],cols=['#f8b4b4','#bde7c4','#bfdcf5','#ffe08a','#d9c6f2','#fbd0a6'];
 E('polygon',{points:[A,B,Cc].map(function(p){return p.join(',')}).join(' '),fill:'#fff',stroke:'#1d2b3a','stroke-width':2},g);
 for(var i=0;i<k&&i<6;i++)E('polygon',{points:tri[i].map(function(p){return p.join(',')}).join(' '),fill:cols[i],opacity:.6,stroke:'#1d2b3a','stroke-width':2},g);
 [[A,D],[A,F]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#1d2b3a','stroke-width':2},g)});
 T(g,100,162,'1',{'font-size':11,'font-weight':800,fill:C.blue});T(g,180,162,'2',{'font-size':11,'font-weight':800,fill:C.blue});T(g,260,162,'3',{'font-size':11,'font-weight':800,fill:C.blue})}
var P7=[function(){h3cnt(0);calc(['Rasmda nechta uchburchak bor? (Javob 3 emas!)'])},function(){h3cnt(3);calc(['Bitta bo‘lakli: 1, 2, 3 — <b>3 ta</b>'])},function(){h3cnt(5);calc(['3 ta','Ikki bo‘lakli: 1+2, 2+3 — <b>2 ta</b>'])},function(){h3cnt(6);calc(['3 + 2 = 5','Uch bo‘lakli (butun) — <b>1 ta</b>.  Jami: 3 + 2 + 1 = <b>6</b>'])}];
var P8=[function(){clear();h3tri([[110,140],[250,140],[180,30]],'#d6efc7');var g=S.g;T(g,180,58,'40°',{'font-size':13,'font-weight':800,fill:C.bad});T(g,132,132,'?',{'font-size':14,'font-weight':800,fill:C.blue});T(g,228,132,'?',{'font-size':14,'font-weight':800,fill:C.blue});calc(['Teng yonli uchburchak: uchidagi burchak 40°. Asosidagi burchaklar?'])},
 function(){P8[0]();calc(['Teng yonli uchburchakda asosidagi burchaklar <b>teng</b>','180° − 40° = <b>140°</b> — ikkalasiga'])},
 function(){clear();h3tri([[110,140],[250,140],[180,30]],'#d6efc7');var g=S.g;T(g,180,58,'40°',{'font-size':13,'font-weight':800,fill:C.bad});T(g,138,132,'70°',{'font-size':13,'font-weight':800,fill:C.blue});T(g,222,132,'70°',{'font-size':13,'font-weight':800,fill:C.blue});calc(['140° : 2 = <b>70°</b> har biri','Tekshiruv: 40 + 70 + 70 = 180 ✓'])}];
var STEPS=[
{h:"Burchak turlari",sum:"O'tkir < 90°, to'g'ri = 90°, o'tmas 90°–180°, yoyiq = 180°.",a:"m01",
 start:function(){h3ang(50,'O‘tkir burchak');g4m('Tugmalarni bosing')},fin:function(){h3ang(90,'To‘g‘ri burchak');g4m('To‘g‘ri burchak — 90°')},
 html:"<p>Burchak — bir nuqtadan chiqqan ikki nur. U <b>gradus</b> (°) bilan o'lchanadi. To'rt turini ko'ring:</p>",
 btns:[["O'tkir",function(c,done){h3ang(50,'O‘tkir burchak');g4m('<b>O‘tkir</b>: 90° dan kichik');mvK(done,3)}],["To'g'ri",function(c,done){h3ang(90,'To‘g‘ri burchak');g4m('<b>To‘g‘ri</b>: 90° — daftar varag‘ining burchagi');mvK(done,3)}],["O'tmas",function(c,done){h3ang(130,'O‘tmas burchak');g4m('<b>O‘tmas</b>: 90° dan katta, 180° dan kichik');mvK(done,3)}],["Yoyiq",function(c,done){h3ang(180,'Yoyiq burchak');g4m('<b>Yoyiq</b>: 180° — ikki nur bir to‘g‘ri chiziqda');mvK(done,3)}]],g2:1,
 after:"<p>Solishtirish uchun «o'lchov» — <b>to'g'ri burchak</b> (90°): daftar burchagini burchakka qo'ysangiz, kichik yoki katta ekani ko'rinadi. Yoyiq burchak — ikki to'g'ri burchak: 90 + 90 = 180°.</p>",
 q:{t:"Soat 3:00 da millar orasidagi burchak qanday?",opts:["O'tkir","To'g'ri","O'tmas","Yoyiq"],ok:1,why:"3:00 da millar 90° hosil qiladi.",hint:"12 va 3 raqamlari orasini tasavvur qiling.",full:"Soat 3:00 da minut mili 12 da, soat mili 3 da: siferblatning chorak qismi — 90°, to'g'ri burchak."},
 tn:"Qog'ozni ikki marta buklab «to'g'ri burchak o'lchagich» yasating — bolalar sinfdagi burchaklarni tekshirsin."},
{h:"Uchburchaklar: burchaklari bo'yicha",sum:"O'tkir burchakli, to'g'ri burchakli, o'tmas burchakli. Uchburchakda ko'pi bilan bitta to'g'ri yoki o'tmas burchak.",a:"m02",
 start:function(){h3kind(0);g4m('Bosing')},fin:function(){h3kind(2);g4m('O‘tmas burchakli uchburchak')},
 html:"<p>Uchburchak eng katta burchagiga qarab nomlanadi:</p>",
 btns:[["O'tkir burchakli",function(c,done){h3kind(0);g4m('Uchala burchak ham o‘tkir');mvK(done,3)}],["To'g'ri burchakli",function(c,done){h3kind(1);g4m('Bitta burchak 90°, qolgan ikkitasi o‘tkir');mvK(done,3)}],["O'tmas burchakli",function(c,done){h3kind(2);g4m('Bitta burchak o‘tmas, qolgan ikkitasi o‘tkir');mvK(done,3)}]],g3:1,
 after:"<p>Uchburchakda ikkita to'g'ri yoki ikkita o'tmas burchak bo'la olmaydi: ularning o'zi 180° yoki undan ko'p bo'lib ketadi, uchinchisiga joy qolmaydi.</p>",
 q:{t:"Uchburchakda eng ko'pi bilan nechta o'tmas burchak bo'lishi mumkin?",opts:["1","2","3","0"],ok:0,why:"Ikki o'tmas burchak yig'indisi 180° dan oshadi.",hint:"Uch burchak yig'indisi 180°.",full:"Faqat bitta. Ikkita o'tmas burchak (masalan 100° + 100° = 200°) 180° dan oshib ketadi — uchburchak bo'lmaydi."},
 tn:"Geobord (rezinkali taxta) bo'lsa, bolalar uch turdagi uchburchakni yasasin."},
{h:"Uchburchaklar: tomonlari bo'yicha",sum:"Teng tomonli (3 tomoni teng), teng yonli (2 tomoni teng), turli tomonli.",a:"m03",
 start:function(){h3side(0);g4m('Bosing')},fin:function(){h3side(1);g4m('Teng yonli: yon tomonlar teng, uchinchisi — asos')},
 html:"<p>Endi tomonlariga qaraymiz:</p>",
 btns:[["Teng tomonli",function(c,done){h3side(0);g4m('3 tomoni ham teng: P = 3 · tomon. Burchaklari ham teng — 60° dan');mvK(done,3)}],["Teng yonli",function(c,done){h3side(1);g4m('2 ta yon tomoni teng; uchinchisi — <b>asos</b>');mvK(done,3)}],["Turli tomonli",function(c,done){h3side(2);g4m('Hamma tomonlari har xil');mvK(done,3)}]],g3:1,
 after:"<p>Teng yonli uchburchakda teng tomonlar — <b>yon tomonlar</b>, uchinchisi — <b>asos</b>. Teng tomonli uchburchak — teng yonlining alohida holi.</p>",
 q:{t:"Teng yonli uchburchakning perimetri 20 sm, asosi 8 sm. Yon tomoni?",opts:["12 sm","6 sm","4 sm","14 sm"],ok:1,why:"(20 − 8) : 2 = 6 sm.",hint:"Asosni ayirgach qolgani ikkita teng yon tomon.",full:"20 − 8 = 12 sm — ikkala yon tomon birga. 12 : 2 = 6 sm. «12» — ikkiga bo'lishni unutish."},
 tn:"Bolalar qog'ozdan teng yonli uchburchak kesib, uni bukib, yon tomonlar ustma-ust tushishini ko'rsin."},
{h:"Tuzoq: har qanday uch kesmadan uchburchak bo'ladimi?",sum:"Ikki kichik tomon yig'indisi eng katta tomondan katta bo'lishi kerak: 3 + 4 > 5 ✓, 2 + 3 < 6 ✗.",a:"m04",
 start:function(){h3sticks(3,4,5)},fin:function(){h3sticks(4,4,8)},
 html:"<p>Cho'plardan uchburchak yasab ko'ring:</p>",
 btns:[["3, 4, 5",function(c,done){h3sticks(3,4,5);mvK(done,3)}],["2, 3, 6",function(c,done){h3sticks(2,3,6);mvK(done,3)}],["4, 4, 8",function(c,done){h3sticks(4,4,8);mvK(done,3)}]],g3:1,
 after:"<p><b>Uchburchak tengsizligi</b>: ikki kichik tomon yig'indisi eng katta tomondan <b>katta</b> bo'lishi shart. 4 + 4 = 8 bo'lsa — cho'plar yotib qoladi, uchburchak chiqmaydi.</p>",
 q:{t:"Qaysi uchta kesmadan uchburchak yasash mumkin?",opts:["5, 6, 12","4, 5, 8","3, 3, 6","2, 7, 4"],ok:1,why:"4 + 5 = 9 > 8.",hint:"Ikki kichigini qo'shib, eng kattasi bilan solishtiring.",full:"4 + 5 = 9 > 8 — bo'ladi. 5 + 6 = 11 < 12, 3 + 3 = 6 = 6, 2 + 4 = 6 < 7 — bo'lmaydi."},
 tn:"Har xil uzunlikdagi qog'oz tasmalar bering — bolalar o'zi tajriba qilsin."},
{h:"Burchaklar yig'indisi — 180°",sum:"Uchburchak burchaklarini qirqib yonma-yon qo'ysak — yoyiq burchak: 180°.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Har qanday uchburchakning burchaklari yig'indisi bir xil. Tekshiramiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Har qanday uchburchakda <b>A + B + C = 180°</b>. Ikki burchak ma'lum bo'lsa, uchinchisi: 180° − (birinchi + ikkinchi).</p>",
 q:{t:"Uchburchakning ikki burchagi 50° va 60°. Uchinchisi?",opts:["110°","70°","90°","80°"],ok:1,why:"180 − (50 + 60) = 70°.",hint:"Yig'indi 180°.",full:"50 + 60 = 110°. 180 − 110 = 70°. «110°» — ayirishni unutish, «90°» — har doim to'g'ri burchak bor deb o'ylash."},
 tn:"Har bir bola o'z uchburchagini chizib, burchaklarini qirqib qo'shsin — hamma uchun 180° chiqishi ta'sirli."},
{h:"Soat millari orasidagi burchak",sum:"Siferblatda ikki raqam orasi 360° : 12 = 30°. 2:00 — 60°, 4:00 — 120°, 6:00 — 180°.",a:"m06",
 start:function(){h3clock(3,90)},fin:function(){h3clock(6,180)},
 html:"<p>Aylana — 360°. Siferblat 12 ta teng bo'lakka bo'lingan. Bosing:</p>",
 btns:[["2:00",function(c,done){h3clock(2,60);mvK(done,3)}],["4:00",function(c,done){h3clock(4,120);mvK(done,3)}],["6:00",function(c,done){h3clock(6,180);mvK(done,3)}]],g3:1,
 after:"<p>Butun soatlarda: burchak = <b>raqamlar orasidagi bo'laklar soni · 30°</b>. 6:00 da yoyiq burchak (180°), 3:00 va 9:00 da to'g'ri burchak.</p>",
 q:{t:"Soat 4:00 da millar orasidagi (kichik) burchak?",opts:["90°","120°","100°","40°"],ok:1,why:"4 · 30° = 120°.",hint:"12 dan 4 gacha nechta bo'lak?",full:"12 dan 4 gacha 4 ta bo'lak: 4 · 30° = 120°. «40°» — har bo'lakni 10° deb olish."},
 tn:"Karton soatda millarni qo'yib, burchak turini aytish o'yini."},
{h:"Tuzoq: nechta uchburchak?",sum:"Uchidan 2 kesma: 3 + 2 + 1 = 6 ta uchburchak.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Katta uchburchak uchidan ikkita kesma tushirildi. Rasmda nechta uchburchak?</p>",
 btns:[phaser(P7,'▶ Sanash')],
 after:"<p>Tartib bilan sanaymiz: <b>1 bo'lakli</b>, <b>2 bo'lakli</b>, <b>3 bo'lakli</b>. Asos n bo'lakka bo'linsa: 1 + 2 + … + n ta uchburchak (3 bo'lak → 6, 4 bo'lak → 10).</p>",
 q:{t:"Uchburchak uchidan 3 ta kesma tushirildi (asos 4 bo'lakka bo'lindi). Nechta uchburchak?",opts:["10","4","7","8"],ok:0,why:"4 + 3 + 2 + 1 = 10.",hint:"1, 2, 3, 4 bo'lakli uchburchaklarni alohida sanang.",full:"1 bo'lakli — 4, 2 bo'lakli — 3, 3 bo'lakli — 2, 4 bo'lakli — 1: jami 10. «4» — faqat kichiklari."},
 tn:"Bolalar rangli qalamda har bir topgan uchburchagini alohida chizib chiqsin — tizimli sanash ko'nikmasi."},
{h:"Teng yonli uchburchak burchaklari",sum:"Asosdagi burchaklar teng: uchida 40° → (180 − 40) : 2 = 70°.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Teng yonli uchburchakda asosdagi burchaklar ham teng. Shundan foydalanamiz:</p>",
 btns:[phaser(P8)],
 after:"<p>Teng yonli uchburchak: <b>asosdagi burchak = (180° − uchidagi burchak) : 2</b>. Teskari: uchidagi = 180° − 2 · asosdagi.</p>",
 q:{t:"Teng yonli uchburchakda uchidagi burchak 100°. Asosidagi burchak?",opts:["80°","40°","50°","100°"],ok:1,why:"(180 − 100) : 2 = 40°.",hint:"Avval 180 dan ayiring, keyin 2 ga bo'ling.",full:"180 − 100 = 80° — ikkala asos burchagi birga. 80 : 2 = 40°. «80°» — 2 ga bo'lishni unutish."},
 tn:"Teng yonli uchburchakni bukib, asosdagi burchaklar ustma-ust tushishini ko'rsating."},
{h:"Bilasizmi? 12 tugunli arqon va 360°",sum:"Qadimda 12 tugunli arqondan 3-4-5 uchburchak yasab to'g'ri burchak olingan. 360° — Bobildan.",a:"m09",
 start:function(){h3sticks(3,4,5);g4m('3-4-5 uchburchak — to‘g‘ri burchakli!')},fin:function(){h3sticks(3,4,5);g4m('3-4-5 uchburchak — to‘g‘ri burchakli!')},
 html:"<p>🪢 Rivoyatlarga ko'ra, qadimgi quruvchilar arqonga 12 ta teng oraliqli tugun bog'lab, uni <b>3, 4 va 5</b> bo'lakli uchburchak qilib tortishgan — shunda roppa-rosa <b>to'g'ri burchak</b> hosil bo'ladi. Uy burchaklari shunday tekislangan.</p><p>🔵 Aylanani <b>360°</b> ga bo'lish qadimgi Bobildan qolgan — ular 60 lik sanoqdan foydalanishgan.</p>",
 tn:"Ip bilan 3-4-5 tajribasini sinfda qiling: 12 ta teng bo'lak belgilab, uchburchak torting va go'niya bilan tekshiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P5[2]()},fin:function(){P5[2]()},
 html:"<div class='memo'><ul><li>O'tkir &lt; 90° · to'g'ri = 90° · o'tmas 90°–180° · yoyiq = 180°.</li><li>Uchburchak: o'tkir/to'g'ri/o'tmas burchakli; teng tomonli/teng yonli/turli tomonli.</li><li>Burchaklar yig'indisi <b>180°</b>; ko'pi bilan bitta to'g'ri yoki o'tmas burchak.</li><li>Uchburchak tengsizligi: ikki kichik tomon yig'indisi &gt; eng katta tomon.</li><li>Teng yonli: asosdagi burchaklar teng; teng tomonli — har biri 60°.</li><li>Soat: raqamlar orasi 30°.</li><li>Uchburchaklarni sanash: 1, 2, 3 … bo'lakli — tartib bilan.</li></ul></div>",
 tn:"Uyga vazifa: atrofdagi narsalarda 3 ta o'tkir, 3 ta o'tmas burchak topib chizish."}
];
var PROBS=[
{t:"90° li burchak qanday ataladi?",o:["To'g'ri","O'tkir","O'tmas","Yoyiq"],k:0,s:"90° — to'g'ri burchak."},
{t:"120° li burchak qanday?",o:["O'tmas","O'tkir","To'g'ri","Yoyiq"],k:0,s:"90° dan katta, 180° dan kichik — o'tmas."},
{t:"Yoyiq burchak necha gradus?",o:["180°","90°","360°","100°"],k:0,s:"Yoyiq burchak — 180°."},
{t:"Uchburchakning ikki burchagi 50° va 70°. Uchinchisi?",o:["60°","120°","80°","50°"],k:0,s:"180 − 120 = 60°."},
{t:"To'g'ri burchakli uchburchakda bir o'tkir burchak 35°. Ikkinchisi?",o:["55°","145°","65°","45°"],k:0,s:"180 − 90 − 35 = 55°."},
{t:"Teng tomonli uchburchakning har bir burchagi?",o:["60°","90°","45°","180°"],k:0,s:"180 : 3 = 60°."},
{t:"Teng tomonli uchburchak perimetri 27 sm. Tomoni?",o:["9 sm","3 sm","24 sm","81 sm"],k:0,s:"27 : 3 = 9 sm."},
{t:"Teng yonli uchburchak: asosi 6 sm, yon tomoni 5 sm. Perimetri?",o:["16 sm","17 sm","11 sm","30 sm"],k:0,s:"6 + 5 + 5 = 16 sm."},
{t:"Teng yonli uchburchak perimetri 20 sm, asosi 8 sm. Yon tomoni?",o:["6 sm","12 sm","4 sm","14 sm"],k:0,s:"(20 − 8) : 2 = 6 sm."},
{t:"Qaysi uchta kesmadan uchburchak yasash mumkin?",o:["4, 5, 8","3, 3, 6","2, 4, 7","1, 2, 5"],k:0,s:"4 + 5 = 9 > 8. Qolganlarida ikki kichik tomon yig'indisi yetmaydi."},
{t:"Soat 4:00 da millar orasidagi burchak?",o:["120°","90°","100°","40°"],k:0,s:"4 · 30° = 120°."},
{t:"Soat 9:00 da millar orasidagi kichik burchak?",o:["90°","180°","270°","45°"],k:0,s:"3 bo'lak · 30° = 90°."},
{t:"Teng yonli uchburchakda uchidagi burchak 100°. Asosidagi burchak?",o:["40°","80°","50°","100°"],k:0,s:"(180 − 100) : 2 = 40°."},
{t:"Uchburchakda eng ko'pi bilan nechta o'tmas burchak bo'ladi?",o:["1","2","3","0"],k:0,s:"Ikkita o'tmas burchak 180° dan oshadi."},
{t:"To'g'ri burchakli uchburchakda bir o'tkir burchak ikkinchisidan 2 marta katta. Kichigi?",o:["30°","45°","60°","20°"],k:0,s:"x + 2x = 90 → 3x = 90 → x = 30°."},
{t:"Uchburchak uchidan 3 ta kesma tushirildi (asos 4 bo'lak). Nechta uchburchak?",o:["10","4","7","8"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"Uchburchak uchidan 2 ta kesma tushirildi. Nechta uchburchak?",o:["6","3","5","4"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Kvadratda ikkala diagonal o'tkazildi. Nechta uchburchak hosil bo'ldi?",o:["8","4","6","2"],k:0,s:"4 ta kichik + 4 ta yarim kvadrat (har diagonal 2 tadan) = 8."},
{t:"Yoyiq burchak ichidan nur o'tkazildi; bir qismi 130°. Ikkinchisi?",o:["50°","230°","40°","60°"],k:0,s:"180 − 130 = 50°."},
{t:"Tomoni 6 sm bo'lgan 3 ta teng tomonli uchburchak yonma-yon qo'yilib trapetsiya yasaldi. Perimetri?",o:["30 sm","54 sm","36 sm","24 sm"],k:0,s:"Pastki asos 12, ustki 6, yon tomonlar 6 + 6: 12 + 6 + 6 + 6 = 30 sm."}
];
function PRACT_STAGE(){P5[2]();g4m('A + B + C = 180°')}
var PREP_DATA={teach:["Burchak turlari va gradus.","Uchburchak turlari: burchaklari va tomonlari bo'yicha.","Uchburchak tengsizligi; burchaklar yig'indisi 180°.","Soat millari burchagi; teng yonli uchburchak burchaklari; uchburchaklarni sanash."],
 mist:["Har qanday uch kesmadan uchburchak bo'ladi deb o'ylaydi.","Uchinchi burchakni topishda 180 dan ayirishni unutadi.","Teng yonli uchburchakda 2 ga bo'lishni unutadi.","Rasmda faqat eng kichik uchburchaklarni sanaydi."],
 need:["Go'niya, chizg'ich, transportir (keyingi mavzu uchun).","Qog'oz uchburchaklar, qaychi.","Cho'plar/qog'oz tasmalar, karton soat."],
 board:["O'tkir &lt; 90° &lt; o'tmas &lt; 180°.","<span class='w2'>A + B + C = 180°</span>.","<span class='w2'>3 + 4 &gt; 5</span> ✓, <span class='w2'>2 + 3 &lt; 6</span> ✗.","Soat: <span class='w2'>4 · 30° = 120°</span>.","<span class='w2'>(180 − 40) : 2 = 70°</span>."]};
