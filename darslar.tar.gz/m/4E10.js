var CODE='4E10',TITLE='4-sinf · Proporsional kattaliklar (birga keltirish)';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
var STEPS=[
e4st({h:"Avval BITTASI qancha?",sum:"8 m mato 96 000 so‘m. 1 m = 96 000 : 8 = 12 000; 13 m = 12 000 · 13 = 156 000 so‘m.",a:"m01",
 frames:[{head:['mato','narx'],rows:[['8 m','96 000'],['1 m','?'],['13 m','?']],t:'8 m mato 96 000 so‘m turadi. 13 m necha so‘m?',note:'13 m ni 8 m dan to‘g‘ridan-to‘g‘ri topib bo‘lmaydi'},
  {head:['mato','narx'],rows:[['8 m','96 000'],['1 m','12 000'],['13 m','?']],hl:{1:1},t:'8 m mato 96 000 so‘m turadi. 13 m necha so‘m?',calc:['1-qadam: 1 m narxi 96 000 : 8 = <b>12 000</b> so‘m']},
  {head:['mato','narx'],rows:[['8 m','96 000'],['1 m','12 000'],['13 m','156 000']],hl:{2:1},t:'8 m mato 96 000 so‘m turadi. 13 m necha so‘m?',calc:['1) 96 000 : 8 = 12 000','2) 12 000 · 13 = <b>156 000</b> so‘m']}],
 html:"<p>13 m ni 8 m orqali to'g'ridan-to'g'ri topib bo'lmaydi. Lekin yo'l bor: avval <b>bitta</b> metrning narxini topamiz. Tugmani bosing.</p>",
 after:"<p>Bu usul <b>«birga keltirish»</b> deyiladi: ko'pdan → bittaga (bo'lamiz), bittadan → kerakli songa (ko'paytiramiz). Deyarli har qanday «shunday» masalasi shu ikki qadamda yechiladi.</p>",
 q:{t:"5 ta daftar 15 000 so'm. 9 ta daftar necha so'm?",opts:["27 000 so'm","19 000 so'm","135 000 so'm","24 000 so'm"],ok:0,why:"1 daftar 3 000; 3 000 · 9 = 27 000.",hint:"Avval 1 ta daftarning narxi.",full:"1 daftar: 15 000 : 5 = 3 000 so'm. 9 ta: 3 000 · 9 = 27 000 so'm. «19 000» — 15 000 + 4 000 deb qo'shib yuborilgan, «135 000» — 15 000 · 9."},
 tn:"Singapur: «unitary method». Doskada doim 3 qatorli jadval: ko'p → 1 → kerakli. Bolalar birinchi haftada 1-qatorni (bittasi) qalam bilan alohida yozsin."}),
e4st({h:"Karrali yo‘l: necha marta?",sum:"5 kg olma 40 000. 15 kg — 3 marta ko‘p, demak 40 000 · 3 = 120 000. Birga keltirsak ham shu: 8 000 · 15.",a:"m02",
 frames:[{t:'5 kg olma 40 000 so‘m. 15 kg necha so‘m?',bars:[{lab:'5 kg',y:46,segs:[{w:5,txt:'40 000',c:'a'}]},{lab:'15 kg',y:98,segs:[{w:5,txt:'?',c:'q'},{w:5,txt:'?',c:'q'},{w:5,txt:'?',c:'q'}]}],max:15,note:'15 kg ichida 5 kg necha marta bor?'},
  {t:'5 kg olma 40 000 so‘m. 15 kg necha so‘m?',bars:[{lab:'5 kg',y:46,segs:[{w:5,txt:'40 000',c:'a'}]},{lab:'15 kg',y:98,segs:[{w:5,txt:'40 000',c:'a'},{w:5,txt:'40 000',c:'a'},{w:5,txt:'40 000',c:'a'}]}],max:15,br:[{b:1,lab:'120 000 so‘m',col:C.ok}],calc:['15 : 5 = 3 marta','40 000 · 3 = <b>120 000</b> so‘m','Birga keltirib ham: 8 000 · 15 = 120 000 ✓']}],
 html:"<p>Ba'zan bitta­ga keltirmasdan ham bo'ladi: 15 kg — bu 5 kg ning <b>3 barobari</b>. Tugmani bosing.</p>",
 after:"<p>Ikki kattalik <b>birga</b> o'sadi: olma 3 marta ko'p — pul ham 3 marta ko'p. Bunday kattaliklar <b>to'g'ri proporsional</b>. Karrali yo'l tezroq, birga keltirish esa har doim ishlaydi (masalan 5 kg → 7 kg da).</p>",
 q:{t:"6 ta bir xil kitob 4 kg 800 g. 18 ta shunday kitob qancha?",opts:["14 kg 400 g","9 kg 600 g","28 kg 800 g","16 kg"],ok:0,why:"18 : 6 = 3 marta; 4 800 · 3 = 14 400 g.",hint:"18 ichida 6 necha marta bor?",full:"18 : 6 = 3 marta. 4 kg 800 g · 3 = 14 kg 400 g. «9 kg 600 g» — faqat 2 marta, «28 kg 800 g» — 6 marta ko'paytirilgan."},
 tn:"Ikki yo'lni yonma-yon doskaga yozing: «birga keltirish» va «necha marta». Bolalar qaysi biri qulayligini o'zi tanlasin — bu ham matematik fikrlash."}),
e4st({h:"Tuzoq: TESKARI proporsional",sum:"60 km/soat tezlikda 3 soat. 90 km/soat tezlikda — 180 : 90 = 2 soat. Tezlik oshsa, vaqt KAMAYADI.",a:"m03",
 frames:[{head:['tezlik','vaqt'],rows:[['60 km/soat','3 soat'],['90 km/soat','?']],t:'Mashina 60 km/soat tezlikda yo‘lni 3 soatda o‘tdi. 90 km/soat tezlikda necha soatda o‘tadi?',note:'Tanlang:'}],
 html:"<p>Ehtiyot bo'ling! Hamma kattalik ham birga o'smaydi. Tezlik <b>oshsa</b>, vaqt qanday o'zgaradi? Tanlang:</p>",
 btns:e4pk(["4 soat 30 daq","2 soat","3 soat"],1,{head:['tezlik','vaqt','yo‘l'],rows:[['60 km/soat','3 soat','180 km'],['90 km/soat','2 soat','180 km']],hl:{1:1},t:'Yo‘l o‘zgarmaydi: 60 · 3 = 180 km',calc:['Yo‘l: 60 · 3 = 180 km (o‘zgarmas)','Vaqt: 180 : 90 = <b>2</b> soat']},["Tezlik 1,5 marta OSHDI — vaqt ham oshadimi? Yo‘q, tezroq yursa, tezroq yetib boradi.","","Tezlik o‘zgardi — vaqt ham o‘zgaradi."]),
 after:"<p>Bu <b>teskari</b> proporsionallik: biri oshsa, ikkinchisi kamayadi. Usul boshqa: avval <b>o'zgarmas</b> kattalikni toping (yo'l = 180 km), keyin undan bo'ling. Shuningdek: ishchilar ko'p — kunlar kam; olma kattaroq — soni kam.</p>",
 q:{t:"4 ta ishchi devorni 9 kunda quradi. 6 ta ishchi necha kunda quradi?",opts:["6 kun","13 kun 12 soat","11 kun","7 kun"],ok:0,why:"Ish: 4 · 9 = 36 kishi-kun; 36 : 6 = 6.",hint:"Avval o'zgarmas narsani toping: butun ish nechta «kishi-kun»?",full:"Butun ish: 4 · 9 = 36 kishi-kun. 6 ishchi: 36 : 6 = 6 kun. «13 kun 12 soat» — to'g'ri proporsional deb 9 · 6 : 4 qilingan; ishchi ko'p bo'lsa kun kamayadi!"},
 tn:"AQSh IES tavsiyasi: avval «bu kattaliklar birga o'sadimi yoki teskarimi?» deb og'zaki so'rang, keyin hisob. Shu savol xatolarning yarmini oldini oladi."}),
e4st({h:"Darvozalar (ikki yo‘l)",sum:"15 darvozaga 630 kg. 1 darvoza = 42 kg; 210 : 42 = 5 ta. Yoki: 630 : 210 = 3 marta kam → 15 : 3 = 5.",a:"m04",
 frames:[{head:['darvoza','temir'],rows:[['15 ta','630 kg'],['1 ta','?'],['? ta','210 kg']],t:'15 ta bir xil darvozaga 630 kg temir ketadi. 210 kg temirdan nechta darvoza yasash mumkin?',note:'Tanlang:'}],
 html:"<p>Endi noma'lum — <b>soni</b>. Baribir avval bittasi. Tanlang:</p>",
 btns:e4pk(["5 ta","45 ta","3 ta"],0,{head:['darvoza','temir'],rows:[['15 ta','630 kg'],['1 ta','42 kg'],['5 ta','210 kg']],hl:{2:0},t:'1 darvoza 42 kg; 210 kg → 5 ta',calc:['1) 630 : 15 = 42 kg (1 darvoza)','2) 210 : 42 = <b>5</b> ta','Karrali yo‘l: 630 : 210 = 3 → 15 : 3 = 5 ✓']},["","45 ta — 15 · 3. Lekin temir 3 marta KAM, darvoza ham kam bo‘ladi.","3 — bu «necha marta kam», javob emas. 15 : 3 = 5."]),
 after:"<p>Ikkala yo'l ham 5 beradi. Javobni <b>tekshiring</b>: 5 · 42 = 210 ✓. Tekshirish — masala yechimining bir qismi, ortiqcha ish emas.</p>",
 q:{t:"12 ta bir xil stolga 84 m taxta ketadi. 35 m taxtadan nechta stol yasash mumkin?",opts:["5 ta","7 ta","3 ta","29 ta"],ok:0,why:"84 : 12 = 7 m; 35 : 7 = 5.",hint:"1 stolga necha metr?",full:"1 stol: 84 : 12 = 7 m. 35 : 7 = 5 ta stol. «7» — bu 1 stolga ketadigan metr, javob emas. «3» — 84 : 35 ni yaxlitlash."},
 tn:"Bank: 1735. Bolalar ikkala usulni ham yozsin va javob bir xil chiqishini o'zi ko'rsin."}),
e4st({h:"Tuzoq: qaysi bo‘lak so‘ralgan?",sum:"50 m sim 1200 g. 35 m qirqildi — QOLGANI 15 m. 1 m = 24 g; 15 · 24 = 360 g.",a:"m05",
 frames:[{t:'Uzunligi 50 m, massasi 1200 g sim. 35 m qirqib olindi. QOLGAN bo‘lakning massasi?',bars:[{lab:'50 m',y:76,segs:[{w:35,txt:'35 m qirqildi',c:'x'},{w:15,txt:'?',c:'q'}]}],max:50,br:[{b:0,lab:'1200 g',up:true,col:C.blue}],note:'Tanlang:'}],
 html:"<p>Shartni <b>oxirigacha</b> o'qing: nima so'ralgan — qirqilgan bo'lakmi, qolganimi? Tanlang:</p>",
 btns:e4pk(["840 g","360 g","24 g"],1,{t:'Qolgan: 50 − 35 = 15 m; 1 m = 24 g',bars:[{lab:'50 m',y:76,segs:[{w:35,txt:'840 g',c:'x'},{w:15,txt:'360 g',c:'g'}]}],max:50,br:[{b:0,lab:'1200 g',up:true,col:C.blue}],calc:['1) 50 − 35 = 15 m qoldi','2) 1200 : 50 = 24 g (1 m)','3) 24 · 15 = <b>360</b> g']},["840 g — bu QIRQILGAN 35 m ning massasi. Qolgani so‘ralgan!","","24 g — bu 1 metrning massasi, javob emas."]),
 after:"<p>Uch qadam: 1) qolgan uzunlik, 2) 1 m massasi, 3) ko'paytirish. Tekshirish: 840 + 360 = 1200 ✓ — ikkala bo'lak birga butun simni beradi.</p>",
 q:{t:"Uzunligi 40 m arqon 2 kg 800 g. Undan 12 m kesib olindi. Qolgan arqon qancha?",opts:["1 kg 960 g","840 g","2 kg 100 g","70 g"],ok:0,why:"1 m = 70 g; 28 · 70 = 1960 g.",hint:"Qolgan uzunlik 40 − 12.",full:"Qolgan: 40 − 12 = 28 m. 1 m: 2800 : 40 = 70 g. 28 · 70 = 1960 g = 1 kg 960 g. «840 g» — kesilgan 12 m massasi, «70 g» — 1 m."},
 tn:"Bank: 1736. Doskada simni chizib, «qirqilgan» va «qolgan» bo'laklarni rang bilan ajrating. Shart o'qilgach bolalar «nima so'ralgan?» deb bir og'iz aytsin."}),
e4st({h:"Bo‘linmasa — boshqacha «birga» keltiring",sum:"900 g xamirga 60 g shakar. 1 g xamirga — kasr chiqadi. Boshqacha: 60 g shakar 1 g ga 900 : 60 = 15 g xamir. 600 : 15 = 40 g.",a:"m06",
 frames:[{head:['xamir','shakar'],rows:[['900 g','60 g'],['600 g','?']],t:'Oshpaz 900 g xamirga 60 g shakar soladi. 600 g xamirga necha gramm shakar kerak?',note:'60 : 900 — butun chiqmaydi. Nima qilamiz?'},
  {head:['xamir','shakar'],rows:[['900 g','60 g'],['15 g','1 g'],['600 g','?']],hl:{1:0},t:'Oshpaz 900 g xamirga 60 g shakar soladi. 600 g xamirga necha gramm shakar kerak?',calc:['Teskarisiga «birga»: 1 g shakarga 900 : 60 = <b>15</b> g xamir']},
  {head:['xamir','shakar'],rows:[['900 g','60 g'],['15 g','1 g'],['600 g','40 g']],hl:{2:1},t:'Oshpaz 900 g xamirga 60 g shakar soladi. 600 g xamirga necha gramm shakar kerak?',calc:['1) 900 : 60 = 15 g xamirga 1 g shakar','2) 600 : 15 = <b>40</b> g shakar','Tekshiruv: 900 : 15 = 60 ✓']}],
 html:"<p>1 g xamirga qancha shakar? 60 : 900 — butun son chiqmaydi. Lekin <b>boshqa tomondan</b> birga keltirsa bo'ladi. Tugmani bosing.</p>",
 after:"<p>Qoida: birga keltirishda <b>qaysi kattalik bo'linsa</b>, o'shanini «1» qiling. Yana bir yo'l — <b>umumiy bo'lak</b>: 900 va 600 ikkalasi ham 300 ga bo'linadi: 300 g xamirga 20 g shakar → 600 g ga 40 g.</p>",
 q:{t:"4 kg olmadan 600 g quritilgan olma chiqadi. 10 kg olmadan qancha chiqadi?",opts:["1 kg 500 g","2 kg 400 g","150 g","1 kg 200 g"],ok:0,why:"1 kg → 150 g; 150 · 10 = 1500 g.",hint:"1 kg olmadan qancha?",full:"1 kg olmadan: 600 : 4 = 150 g. 10 kg: 150 · 10 = 1500 g = 1 kg 500 g. «150 g» — faqat 1 kg uchun, «2 kg 400 g» — 600 · 4."},
 tn:"Bank: 1740. Kuchli o'quvchilarga «umumiy bo'lak» (300 g) yo'lini ko'rsating — bu 5-sinfdagi nisbatga ko'prik."}),
e4st({h:"Vaqt bilan tuzoq: 150 daqiqa",sum:"400 km — 50 daqiqa. 1200 km — 3 marta ko‘p: 150 daq = 2 soat 30 daq (1 soat 50 daq emas!).",a:"m07",
 frames:[{road:1,L:1200,t:'Samolyot 400 km ni 50 daqiqada uchadi. 1200 km ni qancha vaqtda uchadi?',marks:[[0,'0'],[400,'400'],[800,'800'],[1200,'1200 km']],obj:[{p:0,ic:'✈️'}],seg:[{a:0,b:400,lab:'50 daq',up:true,col:C.blue}],note:'Tanlang:'}],
 html:"<p>Proporsiya oson, lekin javobni <b>soat va daqiqaga</b> o'tkazishda ko'pchilik adashadi. Tanlang:</p>",
 btns:e4pk(["1 soat 50 daq","2 soat 30 daq","3 soat"],1,{road:1,L:1200,t:'1200 : 400 = 3 marta → 50 · 3 = 150 daqiqa',marks:[[0,'0'],[400,'400'],[800,'800'],[1200,'1200 km']],obj:[{p:1200,ic:'✈️'}],seg:[{a:0,b:400,lab:'50',up:true,col:C.blue},{a:400,b:800,lab:'50',up:true,col:C.blue},{a:800,b:1200,lab:'50',up:true,col:C.blue}],calc:['50 · 3 = 150 daqiqa','150 daq = 120 + 30 = <b>2 soat 30 daq</b>']},["150 daqiqa ≠ 1 soat 50 daq! 1 soat = 60 daqiqa: 150 = 60 + 60 + 30.","","3 soat = 180 daqiqa — ko‘p."]),
 after:"<p>Daqiqani soatga o'tkazish: 150 : 60 = 2 (qoldiq 30) → <b>2 soat 30 daq</b>. «1 soat 50» xatosi — 100 daqiqa 1 soat deb o'ylash.</p>",
 q:{t:"Poyezd 90 km ni 40 daqiqada o'tadi. 270 km ni qancha vaqtda o'tadi?",opts:["2 soat","1 soat 20 daq","3 soat","2 soat 20 daq"],ok:0,why:"3 marta: 40 · 3 = 120 daq = 2 soat.",hint:"270 : 90 = ? marta.",full:"270 : 90 = 3 marta. 40 · 3 = 120 daqiqa = 2 soat. «1 soat 20 daq» — 120 ni «1 soat 20» deb o'qish xatosi."},
 tn:"Bank: 1738. Soat modelida 150 daqiqani ko'rsating: 2 to'liq aylana + yarim aylana."}),
e4st({h:"Ikki g‘ildirak: qaysi ko‘proq aylanadi?",sum:"Kichik g‘ildirak 1 aylanishda 2 m, katta — 5 m. 100 m yo‘lda: kichik 50 marta, katta 20 marta; farq 30.",a:"m08",
 frames:[{road:1,L:20,t:'Kichik g‘ildirak bir aylanishda 2 m, katta — 5 m yuradi. 100 m yo‘lda qaysi biri necha marta ko‘p aylanadi?',marks:[[0,'0'],[2,''],[4,''],[6,''],[8,''],[10,'10'],[12,''],[14,''],[16,''],[18,''],[20,'20 m']],obj:[{p:0,ic:'🛞'}],seg:[{a:0,b:2,lab:'2 m',up:true,col:C.blue},{a:0,b:5,lab:'5 m',col:'#12a39f'}],note:'20 m da kichik 10 marta, katta 4 marta aylanadi'},
  {head:['g‘ildirak','1 aylanish','100 m da'],rows:[['kichik','2 m','50 marta'],['katta','5 m','20 marta']],hl:{0:2},t:'100 m yo‘lda',calc:['Kichik: 100 : 2 = 50 marta','Katta: 100 : 5 = 20 marta','Kichik g‘ildirak <b>30</b> marta ko‘p aylanadi']}],
 html:"<p>Yo'l bir xil, lekin g'ildiraklar har xil. Kichik g'ildirak yo'lni <b>kichik qadamlar</b> bilan bosadi. Tugmani bosing.</p>",
 after:"<p>Yana teskari proporsionallik: g'ildirak <b>kichik</b> — aylanishlar soni <b>ko'p</b>. Tuzoq: «katta g'ildirak ko'p aylanadi» deb o'ylash. Aslida katta g'ildirak bir aylanishda ko'proq yo'l bosadi, shuning uchun kamroq aylanadi.</p>",
 q:{t:"Kichik g'ildirak bir aylanishda 3 m, katta — 4 m yuradi. Arava 120 m yurganda kichik g'ildirak kattasidan necha marta ko'p aylanadi?",opts:["10 marta","40 marta","30 marta","1 marta"],ok:0,why:"120 : 3 = 40; 120 : 4 = 30; 40 − 30 = 10.",hint:"Har birining aylanishlar sonini alohida toping.",full:"Kichik: 120 : 3 = 40 marta, katta: 120 : 4 = 30 marta. Farq 40 − 30 = 10. «40» va «30» — bu alohida sonlar, farq so'ralgan. «1» — 4 − 3."},
 tn:"Bank: 1737. Qo'lda ikki xil tanga yoki qopqoqni stol ustida dumalatib ko'rsating: kichigi ko'p aylanadi."}),
e4st({h:"Bilasizmi? Yer aylanasini proporsiya bilan o‘lchagan olim",sum:"Eratosfen (miloddan avvalgi III asr): 7° — 360° ning 1/50 qismi; shaharlar orasi 5000 stadiy → Yer aylanasi ≈ 250 000 stadiy.",a:"m09",
 frames:[{head:['burchak','masofa'],rows:[['7°','5000 stadiy'],['360°','?']],t:'Eratosfen hisobi (miloddan avvalgi 240-yil atrofida)',note:'360 : 7 ≈ 50 marta → 5000 · 50 = 250 000 stadiy'}],
 html:"<p>🌍 Qadimgi yunon olimi <b>Eratosfen</b> 2200 yildan ko'proq avval Yer sharining aylanasini o'lchagan — <b>birga keltirish</b> usuli bilan! U Siena shahrida yoz kuni quyosh tik tushishini, Iskandariyada esa soya burchagi <b>7°</b> atrofida bo'lishini bilgan. 7° — to'liq aylananing (360°) taxminan <b>1/50</b> qismi. Ikki shahar orasi <b>5000 stadiy</b> bo'lgani uchun butun aylana ≈ 5000 · 50 = <b>250 000 stadiy</b> — bu bugungi o'lchovga (taxminan 40 000 km) juda yaqin.</p>",
 after:"<p>Kichik bo'lakdan butunni topish — siz bugun o'rgangan usulning o'zi. Faqat Eratosfen uni butun sayyora uchun ishlatgan.</p>",
 tn:"Globus va fonar bilan ko'rsating: bir joyda soya yo'q, boshqasida bor. 7 ni 360 ichida necha marta borligini bolalar o'zi hisoblasin (≈ 51)."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e4tab({head:['ko‘p','1 ta','kerakli'],rows:[['8 m → 96 000','1 m → 12 000','13 m → 156 000']],t:'Birga keltirish: ko‘p → 1 → kerakli',note:'To‘g‘ri: birga o‘sadi · Teskari: biri oshsa, ikkinchisi kamayadi'})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Birga keltirish:</b> ko'p → <b>1 ta</b> (bo'lamiz) → kerakli (ko'paytiramiz).</li><li><b>Karrali yo'l:</b> «necha marta?» — shuncha marta ko'paytiring/bo'ling.</li><li><b>To'g'ri proporsional:</b> ikkalasi birga o'sadi (mato–narx, vaqt–yo'l).</li><li><b>Teskari:</b> biri oshsa, ikkinchisi kamayadi (tezlik–vaqt, ishchi–kun). Avval o'zgarmas kattalikni toping!</li><li>Bo'linmasa — boshqa tomondan «1» qiling yoki umumiy bo'lak toping.</li><li>Shartni oxirigacha o'qing: qaysi bo'lak so'ralgan? Javobni tekshiring.</li></ul></div>",
 tn:"Uyga: oilada 1 kunlik non, suv, yo'l sarfini aniqlab, 1 hafta va 1 oy uchun hisoblab kelsin — hayotiy proporsiya."}
];
var PROBS=[
{t:"3 ta ruchka 12 000 so'm. 7 ta ruchka necha so'm?",o:["28 000 so'm","16 000 so'm","84 000 so'm","21 000 so'm"],k:0,s:"1 ta 4 000; 4 000 · 7 = 28 000."},
{t:"8 m mato 96 000 so'm turadi. 13 m necha so'm?",o:["156 000 so'm","104 000 so'm","108 000 so'm","1 248 000 so'm"],k:0,s:"1 m 12 000; 12 000 · 13 = 156 000."},
{t:"5 kg olma 40 000 so'm. 15 kg necha so'm?",o:["120 000 so'm","80 000 so'm","50 000 so'm","200 000 so'm"],k:0,s:"3 marta: 40 000 · 3 = 120 000."},
{t:"6 ta bir xil kitob 4 kg 800 g. 18 ta kitob?",o:["14 kg 400 g","9 kg 600 g","28 kg 800 g","16 kg"],k:0,s:"3 marta: 4 800 · 3 = 14 400 g."},
{t:"4 ta ishchi devorni 9 kunda quradi. 6 ta ishchi necha kunda?",o:["6 kun","13 kun 12 soat","11 kun","7 kun"],k:0,s:"36 kishi-kun : 6 = 6."},
{t:"Mashina 60 km/soat tezlikda yo'lni 3 soatda o'tdi. 90 km/soat tezlikda?",o:["2 soat","4 soat 30 daq","3 soat","1 soat 30 daq"],k:0,s:"180 : 90 = 2."},
{t:"15 ta darvozaga 630 kg temir ketadi. 210 kg dan nechta darvoza?",o:["5 ta","45 ta","3 ta","7 ta"],k:0,s:"1 ta 42 kg; 210 : 42 = 5."},
{t:"12 ta stolga 84 m taxta ketadi. 35 m dan nechta stol?",o:["5 ta","7 ta","3 ta","29 ta"],k:0,s:"7 m ta; 35 : 7 = 5."},
{t:"50 m sim 1200 g. 35 m qirqib olindi. Qolgan bo'lak qancha?",o:["360 g","840 g","24 g","1165 g"],k:0,s:"15 m · 24 g = 360."},
{t:"40 m arqon 2 kg 800 g. 12 m kesildi. Qolgani qancha?",o:["1 kg 960 g","840 g","2 kg 100 g","70 g"],k:0,s:"28 · 70 = 1960 g."},
{t:"900 g xamirga 60 g shakar. 600 g xamirga necha gramm shakar?",o:["40 g","90 g","45 g","360 g"],k:0,s:"15 g xamirga 1 g; 600 : 15 = 40."},
{t:"4 kg olmadan 600 g quritilgan olma chiqadi. 10 kg dan?",o:["1 kg 500 g","2 kg 400 g","150 g","1 kg 200 g"],k:0,s:"150 · 10 = 1500 g."},
{t:"Samolyot 400 km ni 50 daqiqada uchadi. 1200 km ni?",o:["2 soat 30 daq","1 soat 50 daq","3 soat","1 soat 30 daq"],k:0,s:"150 daq = 2 soat 30 daq."},
{t:"Poyezd 90 km ni 40 daqiqada o'tadi. 270 km ni?",o:["2 soat","1 soat 20 daq","3 soat","2 soat 20 daq"],k:0,s:"120 daq = 2 soat."},
{t:"Kichik g'ildirak aylanishda 2 m, katta 5 m. 100 m da kichigi necha marta KO'P aylanadi?",o:["30 marta","50 marta","20 marta","3 marta"],k:0,s:"50 − 20 = 30."},
{t:"Nasos 6 daqiqada 90 l suv quyadi. 150 l ni necha daqiqada quyadi?",o:["10 daqiqa","15 daqiqa","9 daqiqa","25 daqiqa"],k:0,s:"1 daq 15 l; 150 : 15 = 10."},
{t:"Kitob 60 bet, har betda 32 qator, qatorda 30 harf. Shu matn betida 40 qator, qatorda 36 harf bo'lsa, necha bet bo'ladi?",o:["40 bet","48 bet","50 bet","75 bet"],k:0,s:"Harflar: 60 · 32 · 30 = 57 600; bir bet 40 · 36 = 1440; 57 600 : 1440 = 40."},
{t:"3 ta nasos hovuzni 8 soatda to'ldiradi. 4 ta nasos necha soatda to'ldiradi?",o:["6 soat","10 soat 40 daq","12 soat","7 soat"],k:0,s:"24 nasos-soat : 4 = 6."},
{t:"7 kg kartoshka 21 000 so'm. 35 000 so'mga necha kg olish mumkin? 35 kg olish uchun esa necha so'm kerak?",o:["Taxminan 11 kg; 105 000 so'm","5 kg; 105 000 so'm","11 kg; 35 000 so'm","5 kg; 70 000 so'm"],k:0,s:"1 kg 3 000; 35 000 : 3 000 = 11 (qoldiq 2 000); 35 · 3 000 = 105 000."},
{t:"Bir xil tezlikda 6 ta tikuv mashinasi 5 soatda 300 ta ko'ylak tikadi. 4 ta mashina 10 soatda nechta tikadi?",o:["400 ta","200 ta","300 ta","600 ta"],k:0,s:"1 mashina 1 soatda 300 : 6 : 5 = 10 ta; 10 · 4 · 10 = 400."}
];
function PRACT_STAGE(){e4tab({head:['ko‘p','1 ta','kerakli'],rows:[['?','?','?']],t:'Birga keltirish: ko‘p → 1 → kerakli',note:'To‘g‘rimi, teskarimi — avval shuni so‘rang'})}
var PREP_DATA={teach:["Birga keltirish: ko'p → 1 → kerakli (ikki amal).","Karrali yo'l: «necha marta?».","To'g'ri va teskari proporsionallik; teskarida avval o'zgarmas kattalik.","Birlik bo'linmasa — boshqa tomondan birga keltirish, umumiy bo'lak.","Vaqt birliklarini o'tkazish (150 daq = 2 soat 30 daq)."],
 mist:["Ko'pdan kerakliga to'g'ridan-to'g'ri o'tishga urinadi (96 000 + ...).","Teskari proporsionallikda ham ko'paytiradi (ishchi ko'p — kun ko'p).","Qirqilgan bo'lakni so'ralgan deb oladi.","100 daqiqani 1 soat deb hisoblaydi.","1 ta uchun topilgan sonni javob deb yozadi."],
 need:["Doskada 3 qatorli jadval shabloni: ko'p | 1 | kerakli.","Ikki xil tanga yoki qopqoq (g'ildirak tajribasi).","Soat modeli (daqiqalarni o'tkazish)."],
 board:["<span class='w2'>96 000 : 8 = 12 000</span>, <span class='w2'>12 000 · 13 = 156 000</span>.","Teskari: yo'l <span class='w2'>60 · 3 = 180</span>, vaqt <span class='w2'>180 : 90 = 2</span>.","<span class='w2'>630 : 15 = 42</span>, <span class='w2'>210 : 42 = 5</span>.","<span class='w2'>50 · 3 = 150 daq = 2 soat 30 daq</span>."]};
