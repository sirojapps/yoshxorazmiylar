var CODE='3E2',TITLE='3-sinf · Narx, miqdor, qiymat';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w2u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
function w2tab(rows,hl){var h='<div class="calc"><table style="width:100%;border-collapse:collapse;font-size:13px;text-align:center"><tr style="color:#5b6b7b"><td>Narx</td><td>Miqdor</td><td>Qiymat</td></tr>';rows.forEach(function(r){h+='<tr>'+r.map(function(c,i){return '<td style="border:1px solid #dde5ee;padding:3px;font-weight:800;'+(hl===i?'background:#fff4d6;color:#e07a2f':'')+'">'+c+'</td>'}).join('')+'</tr>'});return h+'</table></div>'}
var STEPS=[
bmStep({h:"Uch kattalik: narx, miqdor, qiymat",sum:"Narx — 1 ta narsa puli; miqdor — nechta; qiymat — hammasi uchun pul: 1300 · 3 = 3900.",a:"m01",
 frames:[{t:'Obinon 1300 so‘m. Dilshod 3 ta oldi. Necha so‘m to‘ladi?',bars:[{lab:'3 ta non',y:70,segs:w2u(3,'1300','a',1)}],br:[{b:0,lab:'? so‘m',up:true}],note:'Har bir bo‘lak — bitta nonning narxi'},
  {t:'Obinon 1300 so‘m. Dilshod 3 ta oldi. Necha so‘m to‘ladi?',bars:[{lab:'3 ta non',y:70,segs:w2u(3,'1300','g',1)}],br:[{b:0,lab:'3900 so‘m',up:true,col:C.ok}],calc:['Qiymat = narx · miqdor','1300 · 3 = <b>3900</b> so‘m']}],
 html:"<p>Do'kon masalalarida doim uchta kattalik bor: <b>narx</b> (1 ta narsa necha so'm), <b>miqdor</b> (nechta), <b>qiymat</b> (hammasi necha so'm). Kuzating.</p>",
 after:"<p><b>Qiymat = narx · miqdor</b>. Chizmada: qiymat — butun chiziq, narx — bitta bo'lak, miqdor — bo'laklar soni.</p>",
 q:{t:"Daftar 2500 so'm. 4 ta daftar necha so'm turadi?",opts:["2504 so'm","10 000 so'm","625 so'm","6500 so'm"],ok:1,why:"2500 · 4 = 10 000.",hint:"Qiymat = narx · miqdor.",full:"Narx 2500, miqdor 4. Qiymat: 2500 · 4 = 10 000 so'm. «2504» — qo'shib yuborilgan."},
 tn:"Doskaga uch ustunli jadval chizing: «Narx | Miqdor | Qiymat». Har masalada avval jadvalni to'ldirish — xalqaro amaliyotda keng qo'llaniladi."}),
bmStep({h:"Narxni topamiz",sum:"6 m tasma 4800 so'm → 1 m narxi 4800 : 6 = 800 so'm.",a:"m02",
 frames:[{t:'6 metr tasma uchun 4800 so‘m to‘landi. 1 metr necha so‘m?',bars:[{lab:'6 m',y:70,segs:w2u(6,'?','q',1)}],br:[{b:0,lab:'4800 so‘m',up:true}],note:'Butun chiziq ma’lum — bitta bo‘lakni topamiz'},
  {t:'6 metr tasma uchun 4800 so‘m to‘landi. 1 metr necha so‘m?',bars:[{lab:'6 m',y:70,segs:w2u(6,'800','g',1)}],br:[{b:0,lab:'4800 so‘m',up:true}],calc:['Narx = qiymat : miqdor','4800 : 6 = <b>800</b> so‘m']}],
 html:"<p>Endi qiymat va miqdor ma'lum, <b>narx</b> noma'lum. Chizmada butun chiziq bor — bitta bo'lagini topamiz.</p>",
 after:"<p><b>Narx = qiymat : miqdor</b>. Bitta bo'lakni topish uchun butunni bo'laklar soniga bo'lamiz.</p>",
 q:{t:"5 ta ruchka 6000 so'm turadi. Bitta ruchka necha so'm?",opts:["30 000 so'm","1200 so'm","5995 so'm","1000 so'm"],ok:1,why:"6000 : 5 = 1200.",hint:"Narx = qiymat : miqdor.",full:"6000 so'm — 5 ta ruchka. Bittasi: 6000 : 5 = 1200 so'm. «30 000» — ko'paytirib yuborish xatosi."},
 tn:"Bolalardan uchlikning uchala formulasini bitta chizmadan «o'qib» berishni so'rang."}),
bmStep({h:"Miqdorni topamiz",sum:"9000 so'mga 1500 so'mlik nechta? 9000 : 1500 = 6 ta.",a:"m03",
 frames:[{t:'Muzqaymoq 1500 so‘m. 9000 so‘mga nechta olsa bo‘ladi?',bars:[{lab:'pul',y:70,segs:[{w:1500,txt:'1500',c:'a'},{w:7500,txt:'?',c:'q'}]}],br:[{b:0,lab:'9000 so‘m',up:true}],note:'Nechta 1500 sig‘adi?'},
  {t:'Muzqaymoq 1500 so‘m. 9000 so‘mga nechta olsa bo‘ladi?',bars:[{lab:'pul',y:70,segs:w2u(6,'1500','g',1500)}],br:[{b:0,lab:'9000 so‘m',up:true},{b:0,lab:'6 ta',up:false,col:C.ok}],calc:['Miqdor = qiymat : narx','9000 : 1500 = <b>6</b> ta']}],
 html:"<p>Bu safar <b>miqdor</b> noma'lum: puldan nechta muzqaymoq «sig'adi»? Kuzating.</p>",
 after:"<p><b>Miqdor = qiymat : narx</b>. Bu — «necha marta sig'adi?» savoli.</p>",
 q:{t:"Bitta kitob 12 000 so'm. 48 000 so'mga nechta kitob olish mumkin?",opts:["4","36","60 000","12"],ok:0,why:"48 000 : 12 000 = 4.",hint:"48 000 ichida nechta 12 000 bor?",full:"Miqdor = qiymat : narx = 48 000 : 12 000 = 4 ta. «36» — ayirib yuborilgan (48 − 12)."},
 tn:"Uch formulani bitta uchburchakka joylang: tepada qiymat, pastda narx va miqdor. Bittasini yopsangiz, qolgan ikkitasi amalni ko'rsatadi."}),
bmStep({h:"Ikki xil narsa — bitta chek",sum:"3 qalam 700 dan + 2 ruchka 1200 dan = 2100 + 2400 = 4500 so'm.",a:"m04",
 frames:[{t:'Qalam 700 so‘m, ruchka 1200 so‘m. Lobar 3 ta qalam va 2 ta ruchka oldi.',bars:[{lab:'qalamlar',y:44,segs:w2u(3,'700','a',700)},{lab:'ruchkalar',y:96,segs:w2u(2,'1200','b',1200)}],calc:['Qalamlar: 700 · 3 = 2100','Ruchkalar: 1200 · 2 = 2400']},
  {t:'Qalam 700 so‘m, ruchka 1200 so‘m. Lobar 3 ta qalam va 2 ta ruchka oldi.',bars:[{lab:'chek',y:70,segs:[{w:2100,txt:'2100',c:'a'},{w:2400,txt:'2400',c:'b'}]}],br:[{b:0,lab:'4500 so‘m',up:false,col:C.ok}],calc:['2100 + 2400 = <b>4500</b> so‘m']}],
 html:"<p>Har xil narsa olinsa — har birining qiymatini <b>alohida</b> topamiz, keyin qo'shamiz.</p>",
 after:"<p>Xato yo'l: (700 + 1200) · 5 = 9500 — bu har bir narsadan 5 tadan olinganda bo'lardi. Har narsa — o'z miqdori bilan!</p>",
 q:{t:"Dilshod 1300 so'mdan 3 ta obinon va 1500 so'mdan 2 ta sharbat oldi. Jami necha so'm?",opts:["2800","6500","6900","7100"],ok:2,why:"3900 + 3000 = 6900.",hint:"Nonlar va sharbatlarni alohida hisoblang.",full:"Nonlar: 1300 · 3 = 3900. Sharbat: 1500 · 2 = 3000. Jami: 6900 so'm. «2800» — faqat narxlar qo'shilgan."},
 tn:"Bank misollari (726, 727-id). Chekni jadval qilib yozdiring: har qatorda narsa, narx, miqdor, qiymat; oxirida jami."}),
bmStep({h:"Birga keltirish: avval bittasini top",sum:"6 m — 4800 so'm → 1 m = 800 → 4 m = 3200 so'm.",a:"m05",
 frames:[{t:'6 metr tasma 4800 so‘m. Xuddi shunday 4 metri necha so‘m?',bars:[{lab:'6 m',y:58,segs:w2u(6,'?','q',1)},{lab:'4 m',y:108,segs:w2u(4,'?','q',1)}],br:[{b:0,lab:'4800',up:true}],calc:['1) 1 metr: 4800 : 6 = 800']},
  {t:'6 metr tasma 4800 so‘m. Xuddi shunday 4 metri necha so‘m?',bars:[{lab:'6 m',y:58,segs:w2u(6,'800','a',1)},{lab:'4 m',y:108,segs:w2u(4,'800','g',1)}],br:[{b:0,lab:'4800',up:true},{b:1,lab:'3200 so‘m',up:false,col:C.ok}],calc:['1) 4800 : 6 = 800','2) 800 · 4 = <b>3200</b> so‘m']}],
 html:"<p>«Xuddi shunday» — narx o'zgarmaydi. Avval <b>1 metr</b> narxini topamiz. Kuzating.</p>",
 after:"<p>Usul — «<b>birga keltirish</b>»: avval bitta birlikning narxi, keyin kerakli miqdor. Bu usul bilan istalgan miqdorni hisoblash mumkin.</p>",
 q:{t:"3 kg olma 7500 so'm. 5 kg olma necha so'm?",opts:["12 500","9500","37 500","2500"],ok:0,why:"7500 : 3 = 2500; 2500 · 5 = 12 500.",hint:"Avval 1 kg narxini toping.",full:"1 kg: 7500 : 3 = 2500 so'm. 5 kg: 2500 · 5 = 12 500 so'm. «2500» — faqat birinchi qadam, «9500» — 7500 + 2000 tasodifiy qo'shish."},
 tn:"Bank misoli (728-id). Bolalar «1 ta nechpul?» degan savolni har doim birinchi o'rinda qo'yishga o'rgansin."}),
bmStep({h:"Qaytim",sum:"10 000 so'm berildi, 3 ta 2400 dan = 7200; qaytim 10 000 − 7200 = 2800 so'm.",a:"m06",
 frames:[{t:'Ali 2400 so‘mlik 3 ta daftar oldi va kassaga 10 000 so‘m berdi. Qaytim qancha?',bars:[{lab:'10 000',y:70,segs:w2u(3,'2400','a',2400).concat([{w:2800,txt:'?',c:'q'}])}],br:[{b:0,lab:'10 000 so‘m berildi',up:true}],note:'Qaytimni tanlang:'}],
 html:"<p>Kassada nima bo'ladi? Chizmaga qarab qaytimni tanlang:</p>",
 btns:bmPick(["7200 so‘m","2800 so‘m","7600 so‘m"],1,{t:'Qaytim = berilgan pul − qiymat',bars:[{lab:'10 000',y:70,segs:w2u(3,'2400','a',2400).concat([{w:2800,txt:'2800',c:'g'}])}],br:[{b:0,lab:'10 000 so‘m',up:true}],calc:['1) 2400 · 3 = 7200','2) 10 000 − 7200 = <b>2800</b> so‘m qaytim']},["7200 — bu daftarlar qiymati, qaytim emas.","","7600 — faqat bitta daftar narxi ayirilgan."]),
 after:"<p><b>Qaytim = berilgan pul − qiymat</b>. Avval qiymatni topamiz, keyin ayiramiz. Pul yetadimi-yo'qmi — ham shunday tekshiriladi.</p>",
 q:{t:"Ona 50 000 so'm bilan bozorga bordi. 4 kg go'sht 9000 so'mdan oldi. Qancha pul qoldi?",opts:["41 000","14 000","36 000","46 000"],ok:1,why:"9000 · 4 = 36 000; 50 000 − 36 000 = 14 000.",hint:"Avval go'sht qiymatini toping.",full:"Go'sht: 9000 · 4 = 36 000 so'm. Qoldi: 50 000 − 36 000 = 14 000 so'm. «41 000» — faqat 1 kg narxi ayirilgan."},
 tn:"Sinfda «do'kon» o'yini: bolalar navbat bilan sotuvchi va xaridor bo'ladi, qaytimni og'zaki hisoblaydi."}),
bmStep({h:"Tuzoq: ikki xarid — ikki chek",sum:"2 ruchka + 3 daftar = 6800; 2 ruchka + 1 daftar = 4000 → 2 daftar = 2800 → daftar 1400, ruchka 1300.",a:"m07",
 frames:[{t:'2 ruchka + 3 daftar = 6800 so‘m.  2 ruchka + 1 daftar = 4000 so‘m.',bars:[{lab:'1-chek',y:58,segs:[{w:1300,txt:'R',c:'b'},{w:1300,txt:'R',c:'b'},{w:1400,txt:'D',c:'a'},{w:1400,txt:'D',c:'a'},{w:1400,txt:'D',c:'a'}]},{lab:'2-chek',y:114,segs:[{w:1300,txt:'R',c:'b'},{w:1300,txt:'R',c:'b'},{w:1400,txt:'D',c:'a'}]}],br:[{b:0,lab:'6800',up:true},{b:1,lab:'4000',up:false}],note:'Ikki chekni ustma-ust qo‘yib solishtiramiz'},
  {t:'2 ruchka + 3 daftar = 6800 so‘m.  2 ruchka + 1 daftar = 4000 so‘m.',bars:[{lab:'1-chek',y:58,segs:[{w:1300,txt:'R',c:'x'},{w:1300,txt:'R',c:'x'},{w:1400,txt:'D',c:'x'},{w:1400,txt:'D',c:'y'},{w:1400,txt:'D',c:'y'}]},{lab:'2-chek',y:114,segs:[{w:1300,txt:'R',c:'x'},{w:1300,txt:'R',c:'x'},{w:1400,txt:'D',c:'x'}]}],br:[{b:0,from:3,to:4,lab:'farq: 2800',up:true,col:C.bad}],calc:['Bir xil qismlar qisqaradi (kul rang)','Farq — 2 ta daftar: 6800 − 4000 = <b>2800</b>']},
  {t:'2 ruchka + 3 daftar = 6800 so‘m.  2 ruchka + 1 daftar = 4000 so‘m.',bars:[{lab:'2-chek',y:70,segs:[{w:1300,txt:'1300',c:'b'},{w:1300,txt:'1300',c:'b'},{w:1400,txt:'1400',c:'a'}]}],br:[{b:0,lab:'4000',up:true}],calc:['Daftar: 2800 : 2 = 1400','2 ruchka: 4000 − 1400 = 2600 → ruchka <b>1300</b> so‘m']}],
 html:"<p>Bankdagi eng qiyin xil: ikkita chek bor, narxlar yozilmagan. Singapur usuli — chiziqlarni <b>ustma-ust</b> qo'yib, farqiga qarash. Kuzating.</p>",
 after:"<p>Ikki chekning <b>bir xil qismi</b> qisqarib ketadi, farqi esa faqat o'zgargan narsani ko'rsatadi: 2 ta daftar = 2800. Tekshiring: 2 · 1300 + 3 · 1400 = 2600 + 4200 = 6800 ✓</p>",
 q:{t:"1 ta olma va 2 ta nok 3500 so'm, 1 ta olma va 4 ta nok 5500 so'm. Bitta olma necha so'm?",opts:["1000","1500","2000","500"],ok:1,why:"2 nok = 2000 → nok 1000; olma 3500 − 2000 = 1500.",hint:"Ikki xarid farqi — nechta nok?",full:"Farq: 5500 − 3500 = 2000 so'm — bu 2 ta nok, demak nok 1000 so'm. Olma: 3500 − 2 · 1000 = 1500 so'm. «1000» — nokning narxi, savol olma haqida."},
 tn:"Bank misoli (14-id), 3-daraja. Bu 7-sinfdagi «tenglamalar tizimi»ning boshlang'ich sinfdagi chizmali ko'rinishi."}),
bmStep({h:"Bilasizmi? Qaysi biri arzonroq?",sum:"2 l sharbat 9000 (1 l = 4500), 3 l sharbat 12 600 (1 l = 4200) — katta idish arzonroq.",a:"m08",
 frames:[{t:'Do‘konda: 2 litrli sharbat 9000 so‘m, 3 litrli sharbat 12 600 so‘m',bars:[{lab:'2 l',y:44,segs:w2u(2,'?','a',1)},{lab:'3 l',y:100,segs:w2u(3,'?','b',1)}],note:'Qaysi biri arzonroq? 1 litr narxini solishtiring:'}],
 html:"<p>🛒 Do'konlarda narx yorlig'ida ko'pincha <b>1 kg yoki 1 litr narxi</b> ham yoziladi — xaridor solishtirishi uchun. Qaysi sharbat arzonroq?</p>",
 btns:bmPick(["2 litrlik","3 litrlik","bir xil"],1,{t:'1 litr narxi bo‘yicha solishtiramiz',bars:[{lab:'2 l',y:44,segs:w2u(2,'4500','a',1)},{lab:'3 l',y:100,segs:w2u(3,'4200','g',1)}],calc:['9000 : 2 = 4500 so‘m/l','12 600 : 3 = <b>4200</b> so‘m/l — arzonroq']},["Umumiy narxi kichik, lekin 1 litr narxi qimmatroq: 9000 : 2 = 4500.","","Bir xil emas: 4500 va 4200."]),
 after:"<p>Umumiy narx emas, <b>birlik narxi</b> (1 litr, 1 kg) solishtiriladi! Bu — hayotiy matematika: aqlli xaridor pulini tejaydi.</p>",
 tn:"Bolalarga uyga vazifa: do'kondagi ikki xil o'ramdagi bir mahsulotning 1 kg narxini solishtirib kelish."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Narx · miqdor = qiymat',bars:[{lab:'qiymat',y:70,segs:w2u(4,'narx','a',1)}],br:[{b:0,lab:'qiymat',up:true},{b:0,lab:'miqdor = 4 ta',up:false}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Qiymat = narx · miqdor</b>.</li><li><b>Narx = qiymat : miqdor</b>; <b>miqdor = qiymat : narx</b>.</li><li>Har xil narsalar — qiymatini <b>alohida</b> topib, qo'shing.</li><li>«Xuddi shunday» → avval <b>1 ta</b>ning narxi (birga keltirish).</li><li><b>Qaytim = berilgan pul − qiymat</b>.</li><li>Ikki chek: ustma-ust qo'ying, <b>farq</b> — o'zgargan narsa.</li><li>Arzonini topish — <b>1 kg / 1 litr</b> narxini solishtiring.</li></ul></div>",
 tn:"Keyingi darsni «Narx | Miqdor | Qiymat» jadvalining bitta bo'sh katagini to'ldirish o'yini bilan boshlang."}
];
var PROBS=[
{t:"Daftar 2500 so'm. 6 ta daftar necha so'm?",o:["15 000","12 500","2506","8500"],k:0,s:"2500 · 6 = 15 000."},
{t:"5 ta ruchka 6000 so'm. Bitta ruchka necha so'm?",o:["1200","30 000","1000","5995"],k:0,s:"6000 : 5 = 1200."},
{t:"Muzqaymoq 1500 so'm. 9000 so'mga nechta muzqaymoq olsa bo'ladi?",o:["6","7500","5","8"],k:0,s:"9000 : 1500 = 6."},
{t:"Qalam 700, ruchka 1200 so'm. 3 ta qalam va 2 ta ruchka necha so'm?",o:["4500","3300","1900","9500"],k:0,s:"2100 + 2400 = 4500."},
{t:"Obinon 1300 so'mdan 3 ta, sharbat 1500 so'mdan 2 ta. Jami necha so'm?",o:["6900","2800","6500","7100"],k:0,s:"3900 + 3000 = 6900."},
{t:"6 m tasma 4800 so'm. Xuddi shunday 4 m tasma necha so'm?",o:["3200","2400","800","1200"],k:0,s:"4800 : 6 = 800; 800 · 4 = 3200."},
{t:"3 kg olma 7500 so'm. 5 kg olma necha so'm?",o:["12 500","2500","9500","37 500"],k:0,s:"7500 : 3 = 2500; 2500 · 5 = 12 500."},
{t:"Ali 2400 so'mlik 3 ta daftar oldi va 10 000 so'm berdi. Qaytim qancha?",o:["2800","7200","7600","3800"],k:0,s:"10 000 − 7200 = 2800."},
{t:"2 ruchka va 3 daftar 6800 so'm, 2 ruchka va 1 daftar 4000 so'm. Bitta ruchka necha so'm?",o:["1300","1400","1200","2600"],k:0,s:"2 daftar = 2800 → daftar 1400; 2 ruchka = 2600 → ruchka 1300."},
{t:"Shohruz 5 baho uchun 5 ming, 4 baho uchun 4 ming so'm oladi. Oyda 15 marta 5, 10 marta 4 oldi. Jami qancha?",o:["115 ming","120 ming","105 ming","110 ming"],k:0,s:"75 + 40 = 115 ming so'm."},
{t:"Sotuvchi qalamlarni 800 so'mdan oldi. Uchdan birini 900, qolganini 1000 so'mdan sotib, 3000 so'm foyda oldi. Nechta qalam bo'lgan?",o:["18","12","15","9"],k:0,s:"3 ta qalamda: 1 tasi 100, 2 tasi 200 dan foyda = 500. 3000 : 500 = 6 guruh → 18 ta."},
{t:"Bitta kitob 12 000 so'm. 48 000 so'mga nechta kitob?",o:["4","36","3","5"],k:0,s:"48 000 : 12 000 = 4."},
{t:"2 l sharbat 9000, 3 l sharbat 12 600 so'm. 1 litri arzon bo'lgani necha so'm?",o:["4200","4500","3600","300"],k:0,s:"9000 : 2 = 4500, 12 600 : 3 = 4200. Arzoni 4200."},
{t:"1 ta olma va 2 ta nok 3500, 1 ta olma va 4 ta nok 5500 so'm. Bitta nok necha so'm?",o:["1000","2000","1500","500"],k:0,s:"2 nok = 5500 − 3500 = 2000 → nok 1000."},
{t:"Ona 50 000 so'm bilan bozorga bordi, 4 kg go'sht 9000 dan oldi. Qancha pul qoldi?",o:["14 000","41 000","36 000","4000"],k:0,s:"50 000 − 36 000 = 14 000."},
{t:"8 ta bir xil to'p 96 000 so'm. 5 ta shunday to'p necha so'm?",o:["60 000","12 000","48 000","91 000"],k:0,s:"96 000 : 8 = 12 000; 12 000 · 5 = 60 000."},
{t:"Ali 20 000 so'mi bor. 3 500 so'mlik albomdan nechta olib, qancha qaytim oladi?",o:["5 ta, 2500 qaytim","6 ta, 0 qaytim","5 ta, 3500 qaytim","4 ta, 6000 qaytim"],k:0,s:"20 000 : 3500 = 5 (qoldiq 2500)."},
{t:"Kitob va daftar birga 15 000 so'm. Kitob daftardan 9000 so'm qimmat. Daftar necha so'm?",o:["3000","6000","12 000","9000"],k:0,s:"15 000 − 9000 = 6000 — ikki daftar narxi; daftar 3000."},
{t:"4 ta stul va 1 ta stol 260 000, 2 ta stul va 1 ta stol 180 000 so'm. Bitta stul necha so'm?",o:["40 000","80 000","100 000","20 000"],k:0,s:"2 stul = 80 000 → stul 40 000."},
{t:"Sinfga 30 ta daftar kerak. Do'konda daftar 10 tadan 18 000 so'mlik o'ramda sotiladi. Necha so'm ketadi?",o:["54 000","18 000","540 000","5400"],k:0,s:"30 : 10 = 3 o'ram; 18 000 · 3 = 54 000."}
];
function PRACT_STAGE(){bmDraw({t:'Narx · miqdor = qiymat',bars:[{lab:'qiymat',y:70,segs:w2u(4,'narx','a',1)}],br:[{b:0,lab:'qiymat',up:true},{b:0,lab:'miqdor',up:false}]})}
var PREP_DATA={teach:["Narx, miqdor, qiymat va ular orasidagi uchta formula.","Har xil narsalar qiymatini alohida topib qo'shish.","Birga keltirish (avval 1 ta narxi); qaytim.","Ikki chekni solishtirish (farq usuli); birlik narxi bo'yicha arzonini tanlash."],
 mist:["Narx va qiymatni almashtiradi.","Har xil narsalarda narxlarni qo'shib, umumiy miqdorga ko'paytiradi.","Birga keltirishda 1 ta narxini topmay, to'g'ridan-to'g'ri ko'paytiradi.","Arzonini umumiy narx bo'yicha tanlaydi."],
 need:["Chek namunalari, narx yorliqlari (do'kon o'yini uchun).","«Narx | Miqdor | Qiymat» jadvali chizilgan plakat."],
 board:["<span class='w2'>Qiymat = Narx · Miqdor</span>.","<span class='w2'>1300 · 3 = 3900</span>.","<span class='w2'>4800 : 6 = 800</span> (narx), <span class='w2'>9000 : 1500 = 6</span> (miqdor).","Ikki chek: <span class='w2'>6800 − 4000 = 2800 = 2 daftar</span>.","Arzoni: <span class='w2'>9000 : 2 = 4500 &gt; 12 600 : 3 = 4200</span>."]};
