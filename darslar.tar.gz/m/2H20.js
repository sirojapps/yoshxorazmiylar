var CODE='2H20',TITLE='2-sinf · Algoritm va ko‘rsatmalar zanjiri';
// ---------- sahna: «sehrli mashina» zanjiri ----------
// boxes: [{t:'+10'}...], vals: [kirish, 1-chiqish, ...] (null — noma'lum), back: orqaga yo'nalish
function h20Chain(boxes,vals,o){o=o||{};clear();var g=S.g,n=boxes.length,bw=56,cw=36,tot=n*bw+(n+1)*cw,x=180-tot/2,y=70;
 for(var i=0;i<=n;i++){var v=vals[i];E('rect',{x:x,y:y-18,width:cw,height:36,rx:8,fill:v==null?'#fff4d6':(o.hi===i?'#e6f6ee':'#fff'),stroke:v==null?'#e0b44c':(o.hi===i?C.ok:'#9aa8b6'),'stroke-width':2},g);T(g,x+cw/2,y+6,v==null?'?':String(v),{'font-size':v!=null&&String(v).length>2?13:16,'font-weight':800,fill:'#1d2b3a'});x+=cw;
  if(i<n){var b=boxes[i];E('path',{d:'M'+(x+2)+' '+y+' L'+(x+bw-8)+' '+y,stroke:o.back?C.bad:C.blue,'stroke-width':2.5,'marker-end':''},g);E('path',{d:o.back?'M'+(x+8)+' '+(y-6)+' L'+(x+2)+' '+y+' L'+(x+8)+' '+(y+6):'M'+(x+bw-14)+' '+(y-6)+' L'+(x+bw-8)+' '+y+' L'+(x+bw-14)+' '+(y+6),fill:'none',stroke:o.back?C.bad:C.blue,'stroke-width':2.5},g);
   E('rect',{x:x+6,y:y-44,width:bw-12,height:22,rx:6,fill:o.back?'#fdeaea':'#e8f1fb',stroke:o.back?C.bad:C.blue},g);T(g,x+bw/2,y-28,o.back&&b.r?b.r:b.t,{'font-size':12,'font-weight':800,fill:o.back?C.bad:C.blue});x+=bw}}
 if(o.note)T(g,180,140,o.note,{'font-size':12,'font-weight':800,fill:'#5b6b7b'})}
function h20Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// robot: katakli yo'l
function h20Robot(pos,trail,note){clear();var g=S.g,x0=14,c=24;for(var i=0;i<=13;i++){E('rect',{x:x0+i*c,y:80,width:c-2,height:26,rx:4,fill:trail&&trail.indexOf(i)>=0?'#e8f1fb':'#fff',stroke:'#c9d3dd'},g);T(g,x0+i*c+11,122,String(i),{'font-size':9,fill:'#5b6b7b'})}
 T(g,x0+pos*c+11,100,'🤖',{'font-size':18});if(note)T(g,180,56,note,{'font-size':12,'font-weight':800,fill:C.blue})}
// ---------- bosqichlar ----------
var B2=[{t:'+ 10'},{t:': 2'},{t:'− 3'}];
var P2=[function(){h20Chain(B2,[16,null,null,null]);h20Msg('Ko‘rsatma: +10, keyin :2, keyin −3. 16 dan boshlaymiz')},
 function(){h20Chain(B2,[16,26,null,null],{hi:1});h20Msg('16 + 10 = <b>26</b>')},
 function(){h20Chain(B2,[16,26,13,null],{hi:2});h20Msg('26 : 2 = <b>13</b>')},
 function(){h20Chain(B2,[16,26,13,10],{hi:3});h20Msg('13 − 3 = <b>10</b>. Tartib muhim: avval +10, keyin :2!')}];
var B3=[{t:'+ 5',r:'− 5'},{t:'· 2',r:': 2'},{t:'− 6',r:'+ 6'}];
var P3=[function(){h20Chain(B3,[null,null,null,20]);h20Msg('Songa 5 qo‘shildi, 2 ga ko‘paytirildi, 6 ayirildi — <b>20</b> chiqdi. Boshidagi son?')},
 function(){h20Chain(B3,[null,null,26,20],{back:1,hi:2});h20Msg('Oxiridan orqaga, <b>teskari amal</b> bilan: −6 ning teskarisi +6: 20 + 6 = <b>26</b>')},
 function(){h20Chain(B3,[null,13,26,20],{back:1,hi:1});h20Msg('·2 ning teskarisi :2: 26 : 2 = <b>13</b>')},
 function(){h20Chain(B3,[8,13,26,20],{back:1,hi:0});h20Msg('+5 ning teskarisi −5: 13 − 5 = <b>8</b>. Tekshiramiz: 8 + 5 = 13, 13 · 2 = 26, 26 − 6 = 20 ✓')}];
var P4=[function(){S.rb=0;h20Chain([{t:'qoida'},{t:'qoida'},{t:'qoida'}],[10,null,null,null]);h20Msg('Qoida: son <b>juft</b> bo‘lsa — :2, <b>toq</b> bo‘lsa — +3. 10 dan 3 marta')},
 function(){h20Chain([{t:': 2'},{t:'qoida'},{t:'qoida'}],[10,5,null,null],{hi:1});h20Msg('10 — juft → 10 : 2 = <b>5</b>')},
 function(){h20Chain([{t:': 2'},{t:'+ 3'},{t:'qoida'}],[10,5,8,null],{hi:2});h20Msg('5 — toq → 5 + 3 = <b>8</b>')},
 function(){h20Chain([{t:': 2'},{t:'+ 3'},{t:': 2'}],[10,5,8,4],{hi:3});h20Msg('8 — juft → 8 : 2 = <b>4</b>. Har qadamda qoidani <b>qaytadan</b> tekshiramiz')}];
var P5=[function(){h20Robot(0,[0],'Robot: 3 katak oldinga, 1 katak orqaga. 4 marta');h20Msg('Boshlanish — 0-katak')},
 function(){h20Robot(2,[0,1,2,3],'1-marta: 0 → 3 → 2');h20Msg('Bir marta takrorlansa: +3 − 1 = <b>2</b> katak oldinga')},
 function(){h20Robot(4,[0,1,2,3,4,5],'2-marta: 2 → 5 → 4');h20Msg('Har takrorda 2 katak oldinga')},
 function(){h20Robot(8,[0,1,2,3,4,5,6,7,8,9],'4-marta: 8-katak');h20Msg('4 marta · 2 katak = <b>8</b> katak. «12» — orqaga qadamni unutish xatosi')}];
var STEPS=[
{h:"Sehrli mashina",sum:"Mashina har doim bir xil ish qiladi: ·2, keyin +1. 7 kirsa — 15 chiqadi.",a:"m01",
 start:function(){S.tr=0;h20Chain([{t:'· 2'},{t:'+ 1'}],[null,null,null],{note:'Son tanlang va mashinaga tashlang'});h20Msg('Mashina: avval ·2, keyin +1')},fin:function(){h20Chain([{t:'· 2'},{t:'+ 1'}],[7,14,15]);h20Msg('7 → 14 → 15')},
 html:"<p>Sehrli mashina kirgan sonni <b>2 ga ko'paytiradi</b>, keyin <b>1 qo'shadi</b>. Son tanlab, mashinaga tashlang (kamida 3 ta sonni sinang):</p>",
 btns:[["3",function(c,done){h20Try(3,done)}],["5",function(c,done){h20Try(5,done)}],["7",function(c,done){h20Try(7,done)}],["10",function(c,done){h20Try(10,done)}]],g2:1,
 after:"<p><b>Algoritm</b> — aniq tartibdagi ko'rsatmalar. Mashina har doim bir xil ishlaydi: avval ·2, keyin +1. Tartibni almashtirsak (avval +1, keyin ·2), natija boshqacha chiqadi: 7 → 8 → 16!</p>",
 q:{t:"Mashina sonni 2 ga ko'paytirib, 1 qo'shadi. 9 kiritilsa, nima chiqadi?",opts:["20","19","11","18"],ok:1,why:"9 · 2 = 18, 18 + 1 = 19.",hint:"Avval qaysi amal? Keyin qaysi?",full:"9 · 2 = 18, keyin 18 + 1 = 19. «20» — tartib almashgan: (9 + 1) · 2."},
 tn:"Doskada «mashina» quti chizing: bola son aytadi, sinf natijani topadi. Keyin teskari: natijani aytib, kirgan sonni toptiring."},
{h:"Ko'rsatmalar zanjiri",sum:"16 → +10 → 26 → :2 → 13 → −3 → 10. Har qadamni tartib bilan bajaramiz.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ko'rsatma: «Songa 10 ni qo'shing, natijani 2 ga bo'ling, keyin 3 ni ayiring». 16 dan boshlasak, oxirida nima chiqadi?</p>",
 btns:[phaser(P2)],
 after:"<p>Har qadam <b>oldingi qadamning natijasi</b> bilan ishlaydi. Oraliq natijalarni yozib boring — shunda adashmaysiz.</p>",
 q:{t:"Songa 4 qo'shing, natijani 3 ga ko'paytiring. 6 dan boshlasak, nima chiqadi?",opts:["22","18","30","13"],ok:2,why:"6 + 4 = 10, 10 · 3 = 30.",hint:"Avval 6 + 4 ni toping, keyin natijani 3 ga ko'paytiring.",full:"6 + 4 = 10, 10 · 3 = 30. «18» — 6 · 3 avval bajarilgan (tartib buzilgan), «22» — 6 · 3 + 4."},
 tn:"Oraliq natijalarni «kataklarga» yozdirish — asosiy odat."},
{h:"Orqaga: teskari amallar",sum:"Oxiri ma'lum bo'lsa — oxiridan boshlab, teskari amallar bilan: 20 → +6 → 26 → :2 → 13 → −5 → 8.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>«Songa 5 qo'shildi, natija 2 ga ko'paytirildi, keyin 6 ayirildi va <b>20</b> hosil bo'ldi. Boshlang'ich son qaysi?» Bu yerda <b>boshi</b> noma'lum — orqaga yuramiz.</p>",
 btns:[phaser(P3,'▶ Orqaga qadam')],
 after:"<p>Orqaga yurishda har bir amal <b>teskarisiga</b> aylanadi: + ↔ −, · ↔ :. Va tartib ham teskari: oxirgi amaldan boshlaymiz.</p><div class='life'><div>🔁<span><b>+</b> ning teskarisi <b>−</b>, <b>·</b> ning teskarisi <b>:</b></span></div></div>",
 q:{t:"Dilnoza son o'yladi va undan 46 ni ayirdi. 38 chiqdi. U qaysi sonni o'ylagan?",opts:["8","84","74","94"],ok:1,why:"Orqaga: 38 + 46 = 84.",hint:"−46 ning teskari amali qaysi?",full:"? − 46 = 38. Teskari: 38 + 46 = 84. Tekshiramiz: 84 − 46 = 38 ✓. «8» — 46 − 38, bu teskari emas."},
 tn:"Kartochka o'yini: bola son o'ylaydi, amallar bajaradi va faqat natijani aytadi — sinf orqaga yechib topadi."},
{h:"Shartli qoida: «agar … bo'lsa»",sum:"Juft → :2, toq → +3. 10 → 5 → 8 → 4. Har qadamda shartni qaytadan tekshiramiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Qoida: «Son <b>juft</b> bo'lsa — 2 ga bo'ling; <b>toq</b> bo'lsa — 3 ni qo'shing». 10 dan boshlab qoidani 3 marta bajaramiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Bunday qoidada amal <b>songa qarab</b> tanlanadi. Har qadamda yangi sonni qaytadan tekshiramiz: juftmi, toqmi? Kompyuter dasturlari ham aynan shunday «agar … bo'lsa» deb ishlaydi.</p>",
 q:{t:"Qoida: juft bo'lsa :2, toq bo'lsa +3. 6 dan boshlab 3 marta bajarsak, nima chiqadi?",opts:["3","6","9","12"],ok:0,why:"6 → 3 → 6 → 3.",hint:"Har qadamda yangi sonning juft yoki toqligini tekshiring.",full:"6 juft → 6 : 2 = 3. 3 toq → 3 + 3 = 6. 6 juft → 6 : 2 = 3. Uch marta bajarilgach — 3."},
 tn:"Juft va toq (2A4) mavzusini shu yerda takrorlash mumkin."},
{h:"Takrorlanadigan harakat",sum:"3 oldinga, 1 orqaga — har takrorda 2 katak; 4 marta → 8 katak.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Robot <b>3 katak oldinga</b> yuradi, keyin <b>1 katak orqaga</b> qaytadi. U shuni <b>4 marta</b> takrorladi. Boshidan necha katak oldinda?</p>",
 btns:[phaser(P5,'▶ Robot yuradi')],
 after:"<p>Takrorlanadigan harakatda avval <b>bitta takror</b> natijasini topamiz (3 − 1 = 2), keyin takrorlar soniga ko'paytiramiz: 2 · 4 = 8.</p>",
 q:{t:"Robot 5 katak oldinga, 2 katak orqaga yuradi. Shuni 3 marta takrorladi. Boshidan necha katak oldinda?",opts:["15","9","21","6"],ok:1,why:"Bir takror: 5 − 2 = 3, 3 marta: 9.",hint:"Bitta takrorda robot necha katak oldinga siljiydi?",full:"Bir takror: 5 − 2 = 3 katak. 3 takror: 3 · 3 = 9. «15» — orqaga qadamlar unutilgan, «21» — qo'shib yuborilgan."},
 tn:"Polda yopishqoq lenta bilan katak chizib, bolalardan «robot» bo'lishni so'rang."},
{h:"Tuzoq: mashina ikki marta",sum:"−5 mashinasidan 2 marta o'tib 20 chiqdi → orqaga: 20 + 5 + 5 = 30.",a:"m06",
 start:function(){S.k6=0;h20Chain([{t:'− 5',r:'+ 5'},{t:'− 5',r:'+ 5'}],[null,null,20]);h20Msg('Mashina 5 ni ayiradi. Ali sonni 2 marta o‘tkazdi — 20 chiqdi')},fin:function(){h20Chain([{t:'− 5',r:'+ 5'},{t:'− 5',r:'+ 5'}],[30,25,20],{back:1});h20Msg('20 + 5 + 5 = <b>30</b>')},
 html:"<p>Mashina kirgan sondan <b>5 ni ayiradi</b>. Ali sonni mashinadan <b>ketma-ket 2 marta</b> o'tkazdi va <b>20</b> chiqdi. Ali qaysi sonni kiritgan?</p>",
 btns:[["▶ Orqaga qadam",function(c,done,b){S.k6++;if(S.k6===1){h20Chain([{t:'− 5',r:'+ 5'},{t:'− 5',r:'+ 5'}],[null,25,20],{back:1,hi:1});h20Msg('20 + 5 = <b>25</b> — 1-o‘tishdan keyin')}else{h20Chain([{t:'− 5',r:'+ 5'},{t:'− 5',r:'+ 5'}],[30,25,20],{back:1,hi:0});h20Msg('25 + 5 = <b>30</b>. Ali 30 ni kiritgan. «25» — bitta o‘tishni unutish xatosi');b.disabled=true;b.textContent='✓ Tayyor';done()}}]],
 after:"<p>«2 marta» — bu ikkita bir xil quti zanjiri. Orqaga ikki marta teskari amal: +5, +5. Javob <b>30</b> (25 emas!).</p>",
 q:{t:"Mashina sonni 2 ga ko'paytiradi. Son mashinadan 2 marta o'tib, 20 chiqdi. Qaysi son kiritilgan?",opts:["10","5","40","80"],ok:1,why:"Orqaga: 20 : 2 = 10, 10 : 2 = 5.",hint:"Orqaga ikki marta teskari amal (:2) bajaring.",full:"20 : 2 = 10 (1-o'tishdan keyin), 10 : 2 = 5 (boshida). Tekshiramiz: 5 · 2 = 10, 10 · 2 = 20 ✓. «10» — bitta o'tish unutilgan."},
 tn:"«Necha marta» ni rasmda qutilar bilan ko'rsatish xatoni yo'qotadi."},
{h:"Bilasizmi? «Algoritm» so'zi",sum:"«Algoritm» so'zi vatandoshimiz al-Xorazmiy nomining lotincha shaklidan (Algoritmi) kelib chiqqan.",a:"m07",
 start:function(){h20Chain([{t:'1'},{t:'2'},{t:'3'}],['👣','👣','👣','✓']);h20Msg('Qadam-baqadam')},fin:function(){h20Chain([{t:'1'},{t:'2'},{t:'3'}],['👣','👣','👣','✓']);h20Msg('Qadam-baqadam')},
 html:"<p>⭐ Al-Xorazmiyning hisob haqidagi kitobi Yevropada lotin tiliga tarjima qilinganda, uning ismi <b>«Algoritmi»</b> deb yozilgan. Shundan <b>«algoritm»</b> so'zi kelib chiqqan — ya'ni «Al-Xorazmiy usuli bilan, qadam-baqadam hisoblash».</p><p>💻 Bugun dunyodagi barcha kompyuterlar, telefonlar va robotlar <b>algoritmlar</b> bilan ishlaydi. Har gal o'yin o'ynaganingizda — vatandoshimiz nomini olgan narsadan foydalanasiz!</p>",
 tn:"Bolalarga choy damlash yoki tish yuvish algoritmini qadam-baqadam yozdiring — tartib buzilsa nima bo'lishini muhokama qiling."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h20Chain(B2,[16,26,13,10]);h20Msg('16 → 26 → 13 → 10')},fin:function(){h20Chain(B2,[16,26,13,10]);h20Msg('16 → 26 → 13 → 10')},
 html:"<div class='memo'><ul><li><b>Algoritm</b> — aniq tartibdagi ko'rsatmalar. Tartib o'zgarsa — natija o'zgaradi.</li><li>Zanjirda <b>oraliq natijalarni yozib</b> boring.</li><li>Oxiri ma'lum bo'lsa — <b>oxiridan</b>, teskari amallar bilan: + ↔ −, · ↔ :.</li><li>«Agar … bo'lsa» qoidasida har qadamda shartni <b>qaytadan</b> tekshiring.</li><li>Takrorlanadigan harakat: avval <b>bitta takror</b>, keyin ko'paytiring.</li><li>«2 marta» — 2 ta quti, orqaga ham 2 marta.</li><li>Oxirida <b>tekshiring</b>: topgan sonni boshidan zanjirdan o'tkazing.</li></ul></div>",
 tn:"Keyingi darsni «Son o'ylang, 3 qo'shing, 2 ga ko'paytiring, 6 ni ayiring, 2 ga bo'ling — o'ylagan soningiz chiqadi! Nega?» fokusi bilan boshlang."}
];
function h20Try(v,done){S.tr=(S.tr||0)+1;var a=v*2,b=a+1;h20Chain([{t:'· 2'},{t:'+ 1'}],[v,a,b],{hi:2});h20Msg(v+' · 2 = '+a+', '+a+' + 1 = <b>'+b+'</b>'+(S.tr>=3?' ✓':''));if(S.tr>=3)done()}
var PROBS=[
{t:"Mashina sonni 2 ga ko'paytirib, 1 qo'shadi. 7 kiritilsa, nima chiqadi?",o:["15","16","14","9"],k:0,s:"7 · 2 = 14, 14 + 1 = 15."},
{t:"Songa 10 ni qo'shing, 2 ga bo'ling, 3 ni ayiring. 16 dan boshlasak?",o:["10","23","5","13"],k:0,s:"16 + 10 = 26, 26 : 2 = 13, 13 − 3 = 10."},
{t:"Songa 5 qo'shildi, 2 ga ko'paytirildi, 6 ayirildi — 20 chiqdi. Boshlang'ich son?",o:["8","10","18","13"],k:0,s:"20 + 6 = 26, 26 : 2 = 13, 13 − 5 = 8."},
{t:"Mashina sondan 5 ni ayiradi. Son 2 marta o'tkazildi, 20 chiqdi. Qaysi son kiritilgan?",o:["30","25","15","10"],k:0,s:"20 + 5 + 5 = 30."},
{t:"Qoida: juft bo'lsa :2, toq bo'lsa +3. 10 dan boshlab 3 marta bajarsak?",o:["4","2","8","5"],k:0,s:"10 → 5 → 8 → 4."},
{t:"Retsept: 4 ta olma oling, har birini 2 bo'lakka kesing, 3 bo'lakni yeng. Nechta bo'lak qoladi?",o:["5","8","1","3"],k:0,s:"4 · 2 = 8, 8 − 3 = 5."},
{t:"Robot 3 katak oldinga, 1 katak orqaga yuradi. 4 marta takrorladi. Boshidan necha katak oldinda?",o:["8","12","16","4"],k:0,s:"(3 − 1) · 4 = 8."},
{t:"Dilnoza son o'yladi, undan 46 ni ayirdi — 38 chiqdi. U qaysi sonni o'ylagan?",o:["84","8","74","94"],k:0,s:"38 + 46 = 84."},
{t:"Mashina sonni 2 ga ko'paytiradi. Son 2 marta o'tib, 20 chiqdi. Qaysi son kiritilgan?",o:["5","10","40","80"],k:0,s:"20 : 2 = 10, 10 : 2 = 5."},
{t:"Songa 4 qo'shing, natijani 3 ga ko'paytiring. 6 dan boshlasak?",o:["30","18","22","13"],k:0,s:"(6 + 4) · 3 = 30."},
{t:"Robot 5 katak oldinga, 2 katak orqaga. 3 marta. Boshidan necha katak oldinda?",o:["9","15","21","6"],k:0,s:"(5 − 2) · 3 = 9."},
{t:"Son o'ylandi, unga 7 qo'shildi va 3 ga ko'paytirildi — 30 chiqdi. O'ylangan son?",o:["3","10","23","17"],k:0,s:"30 : 3 = 10, 10 − 7 = 3."},
{t:"Qoida: juft bo'lsa :2, toq bo'lsa +3. 6 dan boshlab 3 marta bajarsak?",o:["3","6","9","12"],k:0,s:"6 → 3 → 6 → 3."},
{t:"Mashina: avval +1, keyin ·2. 7 kiritilsa?",o:["16","15","14","9"],k:0,s:"7 + 1 = 8, 8 · 2 = 16."},
{t:"Ko'rsatma: 20 dan 4 ni ayiring, natijani 4 ga bo'ling, 5 ni qo'shing. Nima chiqadi?",o:["9","10","4","21"],k:0,s:"20 − 4 = 16, 16 : 4 = 4, 4 + 5 = 9."},
{t:"Mashina har gal 3 ni qo'shadi. 5 kiritildi va mashinadan 4 marta o'tkazildi. Nima chiqdi?",o:["17","12","20","8"],k:0,s:"5 + 3 · 4 = 17."},
{t:"Zinapoyaga Ali 2 pog'ona chiqib, 1 pog'ona tushadi. 5 marta takrorladi. U nechanchi pog'onada?",o:["5-chi","10-chi","15-chi","3-chi"],k:0,s:"(2 − 1) · 5 = 5."},
{t:"Son 2 ga bo'lindi, keyin 6 qo'shildi — 10 chiqdi. Boshlang'ich son?",o:["8","32","2","4"],k:0,s:"10 − 6 = 4, 4 · 2 = 8."},
{t:"Tish yuvish algoritmi: A — tishni cho'tkalang, B — cho'tkaga pasta suring, C — og'izni chaying. To'g'ri tartib?",o:["B, A, C","A, B, C","C, A, B","A, C, B"],k:0,s:"Avval pasta suriladi, keyin cho'tkalanadi, oxirida chayiladi: B, A, C."},
{t:"Mashina sonni 10 ga ko'paytiradi, keyin 10 ni ayiradi. Qaysi son kiritilsa, 40 chiqadi?",o:["5","4","3","50"],k:0,s:"40 + 10 = 50, 50 : 10 = 5."}
];
function PRACT_STAGE(){h20Chain(B2,[16,26,13,10]);h20Msg('Oraliq natijalarni yozing')}
var PREP_DATA={teach:["Algoritm — aniq tartibdagi ko'rsatmalar; «sehrli mashina».","Ko'rsatmalar zanjiri va oraliq natijalar.","Orqaga yechish: teskari amallar (+ ↔ −, · ↔ :).","Shartli qoida (juft/toq); takrorlanadigan harakat; «2 marta»."],
 mist:["Amallar tartibini almashtiradi.","Orqaga yechganda teskari amal o'rniga o'sha amalni bajaradi.","«2 marta» da bitta o'tishni unutadi.","Takrorlanadigan harakatda orqaga qadamni hisoblamaydi."],
 need:["Doskada «mashina» qutilari.","Polda katakli yo'lak (robot o'yini)."],
 board:["<span class='w2'>7 → ·2 → 14 → +1 → 15</span>.","<span class='w2'>16 → 26 → 13 → 10</span>.","Orqaga: <span class='w2'>20 → +6 → 26 → :2 → 13 → −5 → 8</span>.","<span class='w2'>10 → 5 → 8 → 4</span> (juft :2, toq +3).","Robot: <span class='w2'>(3 − 1) · 4 = 8</span>."]};
