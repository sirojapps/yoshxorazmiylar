var CODE='2H08',TITLE="2-sinf · Yosh masalalari";
function h8Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// yosh ustunlari: [{n,a,col}], yil: '+3 yil' kabi yozuv
function h8Ages(list,o){o=o||{};clear();var g=S.g,n=list.length,w=Math.min(60,260/n),gap=(320-n*w)/(n+1),base=150,k=o.k||(110/Math.max.apply(null,list.map(function(p){return p.a})).valueOf());
 E('line',{x1:20,y1:base,x2:340,y2:base,stroke:'#33475b','stroke-width':2},g);
 list.forEach(function(p,i){var x=20+gap+i*(w+gap),h=Math.max(4,p.a*k);E('rect',{x:x,y:base-h,width:w,height:h,rx:6,fill:p.col||C.b,stroke:C.line,'stroke-width':1.4},g);T(g,x+w/2,base-h-6,p.a+' yosh',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,x+w/2,base+16,p.n,{'font-size':11,'font-weight':800,fill:'#1d2b3a'})});
 if(o.top)T(g,180,18,o.top,{'font-size':13,'font-weight':800,fill:C.blue})}
var P2=[function(){h8Ages([{n:'Bobo',a:70,col:C.a},{n:'Ota',a:40}],{k:1.4,top:'Hozir'});h8Msg('Bobo 70 yoshda, ota 40 yoshda. Farq: 70 − 40 = 30')},
 function(){h8Ages([{n:'Bobo',a:50,col:C.a},{n:'Ota',a:20}],{k:1.4,top:'20 yil oldin'});h8Msg('20 yil oldin: 50 va 20 — farq yana 30')},
 function(){h8Ages([{n:'Bobo',a:30,col:C.a},{n:'Ota',a:0}],{k:1.4,top:'40 yil oldin — ota tug‘ildi'});h8Msg('Ota tug‘ilganda (0 yosh) bobo <b>30</b> yoshda edi — farqning o‘zi!')}];
var P3=[function(){h8Line(6,null,null);h8Msg('«Lola 2 yil oldin 6 yoshda edi»')},function(){h8Line(6,8,null);h8Msg('Hozir: 6 + 2 = <b>8</b>')},function(){h8Line(6,8,11);h8Msg('3 yildan keyin: 8 + 3 = <b>11</b>')}];
function h8Line(a,b,c){clear();var g=S.g,x0=30,k=26,y=100;E('line',{x1:20,y1:y,x2:345,y2:y,stroke:'#33475b','stroke-width':2},g);for(var v=4;v<=15;v++){E('line',{x1:x0+(v-4)*k,y1:y-5,x2:x0+(v-4)*k,y2:y+5,stroke:'#33475b'},g);T(g,x0+(v-4)*k,y+20,String(v),{'font-size':10,fill:'#5b6b7b'})}
 function pt(v,lab,col){var x=x0+(v-4)*k;E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},g);T(g,x,y-18,lab,{'font-size':11,'font-weight':800,fill:col})}
 pt(a,'2 yil oldin',C.c);if(b!=null){pt(b,'hozir',C.blue);arcH(a,b,'+2')}if(c!=null){pt(c,'3 yildan keyin',C.ok);arcH(b,c,'+3')}
 function arcH(p,q,l){var x1=x0+(p-4)*k,x2=x0+(q-4)*k;E('path',{d:'M'+x1+' '+(y+10)+' Q'+(x1+x2)/2+' '+(y+44)+' '+x2+' '+(y+10),fill:'none',stroke:C.blue,'stroke-width':1.6},g);T(g,(x1+x2)/2,y+46,l,{'font-size':11,'font-weight':800,fill:C.blue})}}
var P4=[function(){h8Ages([{n:'Aka',a:7,col:C.a},{n:'Nodir',a:5},{n:'Singil',a:3,col:C.c}],{k:9,top:'Hozir: yig‘indi 15'});h8Msg('Uchalasining yoshlari yig‘indisi hozir 15 (masalan, 7 + 5 + 3)')},
 function(){h8Ages([{n:'Aka',a:10,col:C.a},{n:'Nodir',a:8},{n:'Singil',a:6,col:C.c}],{k:9,top:'3 yildan keyin'});h8Msg('Har biri 3 yoshga ulg‘aydi: 3 kishi × 3 yil = 9 yosh qo‘shildi')},
 function(){h8Ages([{n:'Aka',a:10,col:C.a},{n:'Nodir',a:8},{n:'Singil',a:6,col:C.c}],{k:9,top:'15 + 9 = 24'});h8Msg('Yig‘indi: 15 + 9 = <b>24</b>. «18» deganlar faqat 3 ni qo‘shgan')}];
var P6=[function(){h8Bar(0);h8Msg('3 yildan keyin yig‘indi 24. Hozir-chi?')},function(){h8Bar(1);h8Msg('Har biri 3 yil yosh: hozirgi yig‘indi 24 − 3 − 3 = <b>18</b>')},function(){h8Bar(2);h8Msg('Akam 4 yosh katta: 18 − 4 = 14 — ikkita teng bo‘lak')},function(){h8Bar(3);h8Msg('14 : 2 = <b>7</b> — men. Akam 11. Tekshiramiz: (7+3) + (11+3) = 24 ✓')}];
function h8Bar(k){clear();var g=S.g,x0=40,u=12;
 if(k===0){E('rect',{x:x0,y:60,width:24*u,height:32,rx:4,fill:C.b,stroke:C.line},g);T(g,x0+12*u,82,'3 yildan keyin: 24',{'font-size':13,'font-weight':800});return}
 var me=7,ak=11;E('rect',{x:x0,y:40,width:me*u,height:28,rx:4,fill:C.b,stroke:C.line},g);T(g,x0-6,58,'Men',{'font-size':11,'font-weight':800,'text-anchor':'end'});
 E('rect',{x:x0,y:90,width:me*u,height:28,rx:4,fill:C.b,stroke:C.line},g);E('rect',{x:x0+me*u,y:90,width:4*u,height:28,rx:4,fill:k>=2?C.c:C.a,stroke:C.line},g);T(g,x0-6,108,'Akam',{'font-size':11,'font-weight':800,'text-anchor':'end'});T(g,x0+me*u+2*u,108,'+4',{'font-size':12,'font-weight':800});
 if(k>=3){T(g,x0+me*u/2,58,'7',{'font-size':14,'font-weight':800});T(g,x0+me*u/2,108,'7',{'font-size':14,'font-weight':800})}else{T(g,x0+me*u/2,58,'?',{'font-size':14,'font-weight':800});T(g,x0+me*u/2,108,'?',{'font-size':14,'font-weight':800})}
 Br(x0,x0+11*u,128,k>=2?'hozir jami 18':'hozir jami ?',false)}
var STEPS=[
{h:"Hamma bir xil ulg'ayadi",sum:"Har yili har kim 1 yoshga katta bo'ladi. Ikki kishining yosh farqi o'zgarmaydi.",a:"m01",
 start:function(){S.y=0;S.u={};h8Ages([{n:'Komil',a:19,col:C.a},{n:'Ukasi',a:13}],{k:4,top:'Hozir · farq 6'});h8Msg('Komil 19, ukasi 13. Yillarni o‘tkazing')},fin:function(){h8Ages([{n:'Komil',a:23,col:C.a},{n:'Ukasi',a:17}],{k:4,top:'+4 yil · farq 6'});h8Msg('4 yildan keyin: 23 va 17 — farq yana 6')},
 html:"<p>Komil 19 yoshda, ukasi undan 6 yosh kichik — 13 yoshda. Yillarni oldinga va orqaga o'tkazib ko'ring. Farq nima bo'ladi?</p>",
 btns:[["−1 yil",function(c,done){S.y--;h8y1(done)}],["+1 yil",function(c,done){S.y++;h8y1(done)},'u']],g2:1,
 after:"<p>Har yili <b>ikkalasi ham</b> 1 yoshga katta bo'ladi — shuning uchun ularning <b>farqi doim 6</b>. Ukasi hech qachon akasiga yetib ololmaydi!</p>",
 q:{t:"Hozir Komil 19 yoshda, ukasi undan 6 yosh kichik. 4 yildan keyin ukasi necha yoshda bo'ladi?",opts:["9","17","13","23"],ok:1,why:"Ukasi hozir 13, 4 yildan keyin 13 + 4 = 17.",hint:"Avval ukasining hozirgi yoshini toping.",full:"Ukasi hozir 19 − 6 = 13. 4 yildan keyin 13 + 4 = 17. «23» — Komilning yoshi, «9» — ayirib yuborish xatosi."},
 tn:"Bolalarga o'z yoshi va aka-ukasining yoshini yozdirib, «10 yildan keyin farq qancha bo'ladi?» deb so'rang."},
{h:"Farq — tug'ilgandagi yosh",sum:"Bobo 70, ota 40: farq 30. Ota tug'ilganda bobo 30 yoshda edi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p><i>«Bobom 70 yoshda, otam 40 yoshda. Otam tug'ilganda bobom necha yoshda bo'lgan?»</i> Vaqtni orqaga aylantiramiz.</p>",
 btns:[phaser(P2,'◀ Orqaga')],
 after:"<p>Ota tug'ilgan kuni u <b>0</b> yoshda edi, bobo esa farqcha — <b>30</b> yoshda. Farq o'zgarmagani uchun shunchaki 70 − 40 = 30.</p>",
 q:{t:"Onam 35 yoshda, men 9 yoshdaman. Men tug'ilganimda onam necha yoshda bo'lgan?",opts:["44","26","35","9"],ok:1,why:"Farq: 35 − 9 = 26.",hint:"Siz tug'ilganda 0 yoshda edingiz. Farq qancha?",full:"Farq doim bir xil: 35 − 9 = 26. Siz tug'ilganda (0 yosh) onangiz 26 yoshda edi. «44» — qo'shib yuborish xatosi."},
 tn:"«Farq — bu katta odamning kichigi tug'ilgandagi yoshi» qoidasini doskaga yozib qo'ying."},
{h:"O'tmish va kelajak",sum:"2 yil oldin 6 → hozir 8 → 3 yildan keyin 11. Avval «hozir»ni toping.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p><i>«Lola 2 yil oldin 6 yoshda edi. 3 yildan keyin u necha yoshda bo'ladi?»</i> Vaqt chizig'ida yuramiz.</p>",
 btns:[phaser(P3,'▶ Keyingi')],
 after:"<p>Eng ishonchli usul — avval <b>hozirgi</b> yoshni topish: 6 + 2 = 8. Keyin kelajakka: 8 + 3 = 11. Yoki birdan: 6 + 2 + 3 = 11.</p>",
 q:{t:"Opam mendan 5 yosh katta. 4 yil oldin opam 9 yoshda edi. Men hozir necha yoshdaman?",opts:["4","13","8","18"],ok:2,why:"Opa hozir 9 + 4 = 13, men 13 − 5 = 8.",hint:"Avval opaning hozirgi yoshini toping.",full:"Opa 4 yil oldin 9 — hozir 13. Men undan 5 yosh kichik: 13 − 5 = 8. «4» — 9 dan 5 ni ayirib, 4 yilni unutish xatosi."},
 tn:"Doskada vaqt chizig'i: «oldin ← hozir → keyin». Har masalada «hozir»ni doiraga oling."},
{h:"Tuzoq: yig'indi qanchaga ortadi?",sum:"3 kishi, 3 yil: har yili yig'indi 3 taga ortadi → 15 + 3·3 = 24.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p><i>«Nodir, akasi va singlisi — uchalasining yoshlari yig'indisi hozir 15. 3 yildan keyin yig'indi nechaga teng bo'ladi?»</i> Ko'pchilik «18» deydi. Kuzating!</p>",
 btns:[phaser(P4)],
 after:"<p>3 yilda <b>har bir</b> kishi 3 yoshga katta bo'ladi. 3 kishi — 3 · 3 = <b>9</b> yosh qo'shiladi: 15 + 9 = 24. Har bir odamni alohida o'ylang!</p>",
 q:{t:"Ali ukasidan 2 marta katta. Ukasi 5 yoshda. 3 yildan keyin ularning yoshlari yig'indisi nechaga teng bo'ladi?",opts:["15","18","21","24"],ok:2,why:"Ali 10, ukasi 5: yig'indi 15. 2 kishi × 3 yil = 6. 15 + 6 = 21.",hint:"Avval Alining yoshini toping. Keyin ikkalasiga 3 tadan qo'shing.",full:"Ali 5 · 2 = 10. Hozir 10 + 5 = 15. 3 yildan keyin: 13 + 8 = 21. «18» — faqat bitta 3 qo'shish xatosi."},
 tn:"Bolalarga sinfda 3 kishilik «oila» o'ynating: har «yil» da hamma bittadan kartochka oladi."},
{h:"Necha yildan keyin?",sum:"Ali 9, singlisi 5: yig'indi 14, har yili +2. 20 bo'lishi uchun 6 ortishi kerak → 3 yil.",a:"m05",
 start:function(){S.y=0;h8y5()},fin:function(){S.y=3;h8y5()},
 html:"<p><i>«Ali 9 yoshda, singlisi 5 yoshda. Necha yildan keyin ularning yoshlari yig'indisi 20 ga teng bo'ladi?»</i> Yillarni o'tkazing:</p>",
 btns:[["+1 yil",function(c,done){if(S.y<5)S.y++;h8y5();if(S.y===3)done()},'u']],
 after:"<p>Hozir yig'indi 14. Har yili <b>2 taga</b> ortadi (ikki kishi). 20 − 14 = 6 ortishi kerak: 6 : 2 = <b>3</b> yil.</p>",
 q:{t:"Ota 30, o'g'il 6 yoshda. Necha yildan keyin ularning yoshlari yig'indisi 50 bo'ladi?",opts:["14","7","20","10"],ok:1,why:"Hozir 36, har yili +2: (50 − 36) : 2 = 7.",hint:"Hozirgi yig'indi qancha? Har yili qanchaga ortadi?",full:"Hozir 30 + 6 = 36. 50 − 36 = 14 ortishi kerak. Har yili 2 ga: 14 : 2 = 7 yil. Tekshiramiz: 37 + 13 = 50 ✓. «14» — 2 ga bo'lishni unutish."},
 tn:"Jadval chizib, yil-yil to'ldirish — 2-sinf uchun eng tushunarli usul."},
{h:"Farq va yig'indi birga",sum:"Kelajakdagi yig'indi 24 → hozir 18 → farqni olib tashlaymiz 18 − 4 = 14 → 14 : 2 = 7.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p><i>«Akam mendan 4 yosh katta. 3 yildan keyin ikkalamizning yoshlarimiz yig'indisi 24 bo'ladi. Men hozir necha yoshdaman?»</i> Chizma bilan yechamiz.</p>",
 btns:[phaser(P6)],
 after:"<p>Uch qadam: 1) <b>hozirga</b> qaytamiz: 24 − 3 − 3 = 18; 2) akamning <b>ortiqcha</b> 4 yilini olib tashlaymiz: 18 − 4 = 14; 3) ikkita teng bo'lak: 14 : 2 = <b>7</b>.</p>",
 q:{t:"Egizaklar Hasan va Husanning yoshlari yig'indisi 16. Ularning akasi egizaklardan 3 yosh katta. Akasi necha yoshda?",opts:["13","11","19","8"],ok:1,why:"Egizaklar teng: 16 : 2 = 8. Aka 8 + 3 = 11.",hint:"Egizaklarning yoshi bir xil. Har biri necha yoshda?",full:"Egizaklar bir xil yoshda: 16 : 2 = 8. Aka undan 3 yosh katta: 11. «19» — 16 ga 3 ni qo'shish xatosi."},
 tn:"Bu — Singapurning «chizma model» usuli. Bolalar har yosh masalasini tasma bilan chizishga o'rgansin."},
{h:"Bilasizmi? Eng uzoq umr",sum:"Tarixda eng uzoq yashagan odam — fransiyalik Janna Kalman, 122 yil.",a:"m07",
 start:function(){h8Ages([{n:'Siz',a:8,col:C.c},{n:'Bobo',a:70},{n:'Kalman',a:122,col:C.a}],{k:.85});h8Msg('122 yil — tasdiqlangan eng uzoq umr')},fin:function(){h8Ages([{n:'Siz',a:8,col:C.c},{n:'Bobo',a:70},{n:'Kalman',a:122,col:C.a}],{k:.85});h8Msg('122 yil — tasdiqlangan eng uzoq umr')},
 html:"<p>👵 Hujjatlar bilan tasdiqlangan eng uzoq umr ko'rgan odam — fransiyalik <b>Janna Kalman</b>: u <b>122 yil</b> yashagan (1875–1997).</p><p>🐢 Hayvonlardan esa ba'zi toshbaqalar 150 yildan ko'p yashaydi.</p>",
 tn:"Bolalar bobo-buvisidan qaysi yilda tug'ilganini so'rab kelsin va yoshini hisoblasin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h8Ages([{n:'Komil',a:19,col:C.a},{n:'Ukasi',a:13}],{k:4,top:'Farq doim 6'});h8Msg('Farq o‘zgarmaydi')},fin:function(){h8Ages([{n:'Komil',a:19,col:C.a},{n:'Ukasi',a:13}],{k:4,top:'Farq doim 6'});h8Msg('Farq o‘zgarmaydi')},
 html:"<div class='memo'><ul><li>Har yili <b>har kim</b> 1 yoshga katta bo'ladi.</li><li>Ikki kishining <b>farqi o'zgarmaydi</b>.</li><li>Farq — kattasining kichigi tug'ilgandagi yoshi.</li><li>Avval <b>hozirgi</b> yoshni toping, keyin oldin/keyin.</li><li>Yig'indi har yili <b>odamlar soni</b>cha ortadi: 3 kishi, 3 yil → +9.</li><li>Farq va yig'indi: ortiqchani olib tashlang va teng bo'lakka bo'ling.</li></ul></div>",
 tn:"Keyingi darsni «Siz 10 yildan keyin necha yoshda bo'lasiz?» savoli bilan boshlang."}
];
function h8y1(done){var y=Math.max(-5,Math.min(5,S.y));S.y=y;h8Ages([{n:'Komil',a:19+y,col:C.a},{n:'Ukasi',a:13+y}],{k:4,top:(y===0?'Hozir':(y>0?'+'+y+' yil':y+' yil'))+' · farq '+(6)});h8Msg('Komil '+(19+y)+', ukasi '+(13+y)+' — farq: '+(19+y)+' − '+(13+y)+' = <b>6</b>');S.u=S.u||{};S.u[y>0?'p':'m']=1;if(S.u.p&&S.u.m)done()}
function h8y5(){var y=S.y;h8Ages([{n:'Ali',a:9+y,col:C.a},{n:'Singlisi',a:5+y,col:C.c}],{k:5,top:(y?'+'+y+' yil':'Hozir')+' · yig‘indi '+(14+2*y)});h8Msg('Yig‘indi: '+(9+y)+' + '+(5+y)+' = <b>'+(14+2*y)+'</b>'+(14+2*y===20?' ✓ — 3 yildan keyin!':''))}
var PROBS=[
{t:"Komil 19 yoshda, ukasi 6 yosh kichik. 4 yildan keyin ukasi necha yoshda?",o:["17","13","23","9"],k:0,s:"13 + 4 = 17."},
{t:"Bobom 70, otam 40 yoshda. Otam tug'ilganda bobom necha yoshda bo'lgan?",o:["30","40","70","110"],k:0,s:"Farq: 70 − 40 = 30."},
{t:"Lola 2 yil oldin 6 yoshda edi. 3 yildan keyin necha yoshda bo'ladi?",o:["11","9","8","5"],k:0,s:"Hozir 8, keyin 8 + 3 = 11."},
{t:"Men ukamdan 3 yosh kattaman. Ukam 6 yoshda. 4 yildan keyin men necha yoshda bo'laman?",o:["13","10","9","7"],k:0,s:"Men 9, 4 yildan keyin 13."},
{t:"Opam mendan 5 yosh katta. 4 yil oldin opam 9 yoshda edi. Men hozir necha yoshdaman?",o:["8","13","4","18"],k:0,s:"Opa hozir 13, men 13 − 5 = 8."},
{t:"Uchta aka-uka-singilning yoshlari yig'indisi 15. 3 yildan keyin yig'indi?",o:["24","18","21","27"],k:0,s:"3 kishi × 3 = 9. 15 + 9 = 24."},
{t:"Ali ukasidan 2 marta katta. Ukasi 5 yoshda. 3 yildan keyin yig'indi?",o:["21","18","15","24"],k:0,s:"10 + 5 = 15, + 6 = 21."},
{t:"Ali 9, singlisi 5 yoshda. Necha yildan keyin yig'indi 20 bo'ladi?",o:["3","6","5","4"],k:0,s:"(20 − 14) : 2 = 3."},
{t:"Egizaklar yoshlari yig'indisi 16. Akasi egizaklardan 3 yosh katta. Akasi necha yoshda?",o:["11","13","19","8"],k:0,s:"8 + 3 = 11."},
{t:"Akam mendan 4 yosh katta. 3 yildan keyin yig'indimiz 24 bo'ladi. Men hozir necha yoshdaman?",o:["7","8","9","6"],k:0,s:"Hozir 18, 18 − 4 = 14, 14 : 2 = 7."},
{t:"Onam 35, men 9 yoshdaman. Men tug'ilganimda onam necha yoshda edi?",o:["26","44","35","24"],k:0,s:"35 − 9 = 26."},
{t:"Hozir Sardor 8 yoshda. 5 yil oldin u necha yoshda edi?",o:["3","13","5","4"],k:0,s:"8 − 5 = 3."},
{t:"Otam mendan 28 yosh katta. 10 yildan keyin u mendan necha yosh katta bo'ladi?",o:["28","38","18","10"],k:0,s:"Farq o'zgarmaydi: 28."},
{t:"Ota 30, o'g'il 6 yoshda. Necha yildan keyin yig'indi 50 bo'ladi?",o:["7","14","20","10"],k:0,s:"(50 − 36) : 2 = 7."},
{t:"Ikki opa-singilning yoshlari yig'indisi 20, opasi singlisidan 4 yosh katta. Singlisi necha yoshda?",o:["8","12","10","16"],k:0,s:"(20 − 4) : 2 = 8."},
{t:"Bobo nabirasidan 60 yosh katta. Nabira 7 yoshda. Bobo necha yoshda?",o:["67","53","60","70"],k:0,s:"7 + 60 = 67."},
{t:"Oilada 4 kishi, yoshlari yig'indisi 80. 2 yil oldin yig'indi qancha edi?",o:["72","78","76","88"],k:0,s:"4 kishi × 2 yil = 8. 80 − 8 = 72."},
{t:"Hasan 3 yil oldin 5 yoshda edi. Necha yildan keyin u 12 yoshga to'ladi?",o:["4","7","9","3"],k:0,s:"Hozir 8, 12 − 8 = 4."},
{t:"Ona qizidan 25 yosh katta. Qiz tug'ilganda ona necha yoshda edi?",o:["25","0","26","24"],k:0,s:"Farq — tug'ilgandagi yosh: 25."},
{t:"Ukam 4 yoshda, men 10 yoshdaman. Ukam 10 yoshga to'lganda men necha yoshda bo'laman?",o:["16","14","20","10"],k:0,s:"Farq 6: 10 + 6 = 16."}
];
function PRACT_STAGE(){h8Ages([{n:'A',a:10,col:C.a},{n:'B',a:6}],{k:8,top:'Farq doim bir xil'});h8Msg('Avval «hozir»ni toping')}
var PREP_DATA={teach:["Har yili har kim 1 yoshga ulg'ayadi; yosh farqi o'zgarmaydi.","Farq — kattasining kichigi tug'ilgandagi yoshi.","O'tmish ↔ hozir ↔ kelajak: avval hozirgi yoshni topish.","Yig'indi har yili odamlar soncha ortadi; farq va yig'indi bilan masalalar."],
 mist:["Farq vaqt o'tishi bilan o'zgaradi deb o'ylaydi.","Yig'indiga yillar sonini bir marta qo'shadi (15 + 3 = 18).","«Oldin» va «keyin» ni aralashtiradi.","Javob sifatida boshqa odamning yoshini yozadi."],
 need:["Vaqt chizig'i (doskada).","Rangli tasmalar (yosh ustunlari)."],
 board:["<span class='w2'>19 − 13 = 6</span> — farq doim 6.","Vaqt chizig'i: oldin ← hozir → keyin.","<span class='w2'>15 + 3 · 3 = 24</span>.","<span class='w2'>(20 − 14) : 2 = 3</span> yil.","Chizma: men [?], akam [? +4], jami 18."]};
