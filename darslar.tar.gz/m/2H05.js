var CODE='2H05',TITLE='2-sinf olimpiada · Sehrli kvadrat va sonli jumboqlar';
var h5LS=[4,9,2,3,5,7,8,1,6];
function h5msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// 3x3 kvadrat: v — 9 ta qiymat (null = ?), o.hl — belgilangan kataklar, o.rs/o.cs — qator/ustun yig'indilari
function h5sq(v,o){o=o||{};var g=S.g,s=o.s||40,x0=o.x!=null?o.x:180-1.5*s,y0=o.y!=null?o.y:14;
 for(var i=0;i<9;i++){var r=Math.floor(i/3),c=i%3,hl=o.hl&&o.hl.indexOf(i)>=0,nw=o.nw&&o.nw.indexOf(i)>=0;
  E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:nw?'#d9f2df':(hl?'#ffe9b0':'#fff'),stroke:'#7a6a55','stroke-width':1.5},g);
  T(g,x0+c*s+s/2,y0+r*s+s/2+7,v[i]==null?'?':String(v[i]),{'font-size':20,'font-weight':800,fill:v[i]==null?C.bad:(nw?C.ok:'#333')})}
 if(o.rs)for(var a=0;a<3;a++)T(g,x0+3*s+24,y0+a*s+s/2+5,'= '+o.rs[a],{'font-size':14,'font-weight':800,fill:C.ok});
 if(o.cs)for(var b=0;b<3;b++)T(g,x0+b*s+s/2,y0+3*s+16,o.cs[b],{'font-size':14,'font-weight':800,fill:C.ok});
 if(o.d){E('line',{x1:x0,y1:y0,x2:x0+3*s,y2:y0+3*s,stroke:C.ok,'stroke-width':2,'stroke-dasharray':'5 4'},g);E('line',{x1:x0+3*s,y1:y0,x2:x0,y2:y0+3*s,stroke:C.ok,'stroke-width':2,'stroke-dasharray':'5 4'},g)}}
// piramida: rows yuqoridan pastga, null = ?
function h5pyr(rows,o){o=o||{};var g=S.g,w=54,h=32,n=rows.length;
 for(var i=0;i<n;i++)for(var j=0;j<rows[i].length;j++){var x=180-rows[i].length*w/2+j*w,y=14+i*(h+4),v=rows[i][j],hl=o.hl&&o.hl.indexOf(i+','+j)>=0;
  E('rect',{x:x+2,y:y,width:w-4,height:h,rx:5,fill:hl?'#ffe9b0':'#f6e3c8',stroke:'#a5764a','stroke-width':1.5},g);
  T(g,x+w/2,y+h/2+6,v==null?'?':String(v),{'font-size':18,'font-weight':800,fill:v==null?C.bad:'#333'})}}
// shakl tengliklari: qatorlar ro'yxati
function h5eqs(L,hl){clear();for(var i=0;i<L.length;i++)T(S.g,180,34+i*36,L[i],{'font-size':22,'font-weight':800,fill:hl===i?C.ok:'#333'})}
var P1=[function(){clear();h5sq(h5LS);h5msg('Bu kvadratda 1 dan 9 gacha sonlar bor')},
 function(){clear();h5sq(h5LS,{rs:[15,15,15]});h5msg('Qatorlar: 4+9+2, 3+5+7, 8+1+6 — hammasi <b>15</b>')},
 function(){clear();h5sq(h5LS,{rs:[15,15,15],cs:[15,15,15]});h5msg('Ustunlar: 4+3+8, 9+5+1, 2+7+6 — yana <b>15</b>')},
 function(){clear();h5sq(h5LS,{rs:[15,15,15],cs:[15,15,15],d:1,hl:[0,4,8,2,6]});h5msg('Diagonallar: 4+5+6 va 2+5+8 — ham <b>15</b>! Bu — <b>sehrli kvadrat</b>')}];
var P2=[function(){clear();h5sq([4,null,2,3,5,7,8,1,6],{hl:[0,2]});h5msg('Sehrli yig‘indi 15. ? qaysi son?')},
 function(){clear();h5sq([4,null,2,3,5,7,8,1,6],{hl:[0,2]});h5msg('Yuqori qator: 4 + ? + 2 = 15 → 6 + ? = 15')},
 function(){clear();h5sq(h5LS,{nw:[1]});h5msg('? = 15 − 6 = <b>9</b>. Tekshiramiz: 9 + 5 + 1 = 15 ✓')}];
var P4=[function(){clear();h5sq([4,null,2,null,5,null,null,null,null],{hl:[0,2,4]});h5msg('Yig‘indi 15. Faqat 4, 2 va 5 ma‘lum')},
 function(){clear();h5sq([4,null,2,null,5,null,8,null,6],{nw:[6,8]});h5msg('Diagonallar: 4 + 5 + ? → <b>6</b>; 2 + 5 + ? → <b>8</b>')},
 function(){clear();h5sq([4,9,2,null,5,null,8,1,6],{nw:[1,7]});h5msg('Qatorlar: 4 + ? + 2 → <b>9</b>; 8 + ? + 6 → <b>1</b>')},
 function(){clear();h5sq(h5LS,{nw:[3,5]});h5msg('Ustunlar: 4 + ? + 8 → <b>3</b>; 2 + ? + 6 → <b>7</b>. Tayyor!')}];
var P5=[function(){clear();h5pyr([[null],[null,null],[3,5,2]]);h5msg('Har g‘isht — ostidagi ikki g‘isht yig‘indisi')},
 function(){clear();h5pyr([[null],[8,7],[3,5,2]],{hl:['1,0','1,1']});h5msg('3 + 5 = <b>8</b>, 5 + 2 = <b>7</b>')},
 function(){clear();h5pyr([[15],[8,7],[3,5,2]],{hl:['0,0']});h5msg('8 + 7 = <b>15</b> — piramida cho‘qqisi')}];
var P6=[function(){h5eqs(['● + ● = 12','● + ▲ = 10','▲ = ?']);h5msg('Bir xil shakl — bir xil son')},
 function(){h5eqs(['● + ● = 12  →  ● = 6','● + ▲ = 10','▲ = ?'],0);h5msg('Ikki bir xil son 12 → har biri 12 : 2 = <b>6</b>')},
 function(){h5eqs(['● = 6','6 + ▲ = 10','▲ = 4'],2);h5msg('6 + ▲ = 10 → ▲ = <b>4</b>. Tekshiruv: 6 + 4 = 10 ✓')}];
var P7=[function(){h5eqs(['■ + ■ + ■ = 15','■ + ★ = 9','★ + ▲ = 7']);h5msg('Zanjir: qaysi tenglikda faqat bitta shakl?')},
 function(){h5eqs(['■ = 15 : 3 = 5','■ + ★ = 9','★ + ▲ = 7'],0);h5msg('Birinchi qatorda faqat ■: ■ = <b>5</b>')},
 function(){h5eqs(['■ = 5','5 + ★ = 9 → ★ = 4','★ + ▲ = 7'],1);h5msg('★ = 9 − 5 = <b>4</b>')},
 function(){h5eqs(['■ = 5','★ = 4','4 + ▲ = 7 → ▲ = 3'],2);h5msg('▲ = 7 − 4 = <b>3</b>. Zanjir bo‘ylab bitta-bitta topdik')}];
var STEPS=[
{h:"Sehrli kvadrat nima?",sum:"Har qator, ustun va diagonal yig'indisi bir xil bo'lgan kvadrat — sehrli kvadrat.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Mana 1 dan 9 gacha sonlar yozilgan kvadrat. Unda bir sir bor! Tugmani bosib, qatorlar, ustunlar va diagonallarni qo'shib ko'ring.</p>",
 btns:[phaser(P1,'➕ Qo‘shib ko‘rish')],
 after:"<p>3 ta qator, 3 ta ustun va 2 ta diagonal — jami <b>8 ta chiziq</b>, hammasining yig'indisi <b>15</b>. Bunday kvadrat <b>sehrli kvadrat</b> deyiladi, 15 esa — <b>sehrli yig'indi</b>.</p>",
 q:{t:"Sehrli kvadratda (3 × 3) nechta chiziqning yig'indisi teng bo'ladi?",opts:["8","6","3","9"],ok:0,why:"3 qator + 3 ustun + 2 diagonal = 8.",hint:"Diagonallarni unutmang.",full:"Qatorlar 3 ta, ustunlar 3 ta, diagonallar 2 ta: 3 + 3 + 2 = 8. «6» — diagonallar unutilgan."},
 tn:"Kvadratni doskaga chizing, bolalar navbat bilan bitta chiziqni qo'shsin."},
{h:"Bitta bo'sh katak",sum:"Sehrli yig'indidan ma'lum ikki sonni ayiramiz: 15 − 4 − 2 = 9.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Kvadratda bitta son yo'qolgan. Sehrli yig'indi 15 ekanini bilamiz. Yo'qolgan sonni qanday topamiz?</p>",
 btns:[phaser(P2)],
 after:"<p>Bo'sh katak turgan, qolgan 2 soni ma'lum chiziqni tanlaymiz: 4 + ? + 2 = 15. Ma'lumlarini qo'shamiz (6) va 15 dan ayiramiz: <b>9</b>. Boshqa chiziq bilan albatta tekshiramiz.</p>",
 q:{t:"Sehrli yig'indi 15. Qatorda: 8, ?, 6. ? qaysi son?",opts:["1","2","14","7"],ok:0,why:"15 − 8 − 6 = 1.",hint:"8 + 6 = 14. 15 bo'lishi uchun yana qancha kerak?",full:"8 + ? + 6 = 15 → 14 + ? = 15 → ? = 1. «14» — 8 va 6 ning yig'indisi, javob emas."},
 tn:"«Avval ma'lumlarni qo'sh, keyin yig'indidan ayir» qoidasini aytib bering."},
{h:"Sehrli yig'indini topish",sum:"1–9 yig'indisi 45, uch qatorga bo'linadi: 45 : 3 = 15. Markazda — o'rtadagi son 5.",a:"m03",
 start:function(){clear();h5sq(h5LS,{rs:[15,15,15]});h5msg('1 + 2 + … + 9 = ?')},fin:function(){clear();h5sq(h5LS,{rs:[15,15,15],hl:[4]});h5msg('45 : 3 = <b>15</b>, markaz — <b>5</b>')},
 html:"<p>Nega aynan 15? 1 dan 9 gacha barcha sonlar kvadratning 3 ta qatoriga taqsimlangan. Barcha sonlar yig'indisini topsak, uni 3 ga bo'lamiz.</p>",
 btns:[["🧮 Hisoblash",function(c,done){h5msg('1+9, 2+8, 3+7, 4+6 — 4 ta «10» va yana 5: 40 + 5 = <b>45</b>. 45 : 3 = <b>15</b>');done()}]],
 after:"<p>Hammasi: 45. Uch qator teng — 45 : 3 = <b>15</b>. Yana sir: markazda doim <b>o'rtadagi son</b> (5) turadi va qarama-qarshi kataklar juftlari yig'indisi 10 ga teng.</p>",
 q:{t:"2, 3, 4, 5, 6, 7, 8, 9, 10 sonlaridan sehrli kvadrat tuzildi. Sehrli yig'indi nechaga teng?",opts:["18","15","54","16"],ok:0,why:"2 + … + 10 = 54, 54 : 3 = 18.",hint:"Avval hammasini qo'shing, keyin 3 ga bo'ling.",full:"2+10, 3+9, 4+8, 5+7 — to'rtta 12 va 6: 48 + 6 = 54. 54 : 3 = 18. Har son 1 ga oshdi — har qatorda 3 ta son, shuning uchun yig'indi 15 + 3 = 18."},
 tn:"Juftlab qo'shish usulini (1+9, 2+8 …) alohida ko'rsating — bu Gauss usuli."},
{h:"Ko'p bo'sh katak",sum:"Har safar bitta bo'sh katagi qolgan chiziqni to'ldiramiz: diagonallar → qatorlar → ustunlar.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Endi faqat 3 ta son berilgan: 4, 2 va markazda 5. Qolgan 6 ta sonni topamiz — har safar <b>faqat bitta</b> bo'sh katagi qolgan chiziqni tanlaymiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Sir: bitta bo'sh katagi bor chiziqni toping, uni to'ldiring — keyin yangi shunday chiziq paydo bo'ladi. Yana bir qoida: markazdan o'tgan chiziqda qarama-qarshi sonlar yig'indisi <b>10</b> (4–6, 9–1, 3–7, 2–8).</p>",
 q:{t:"Sehrli kvadrat (yig'indi 15), markazda 5. Burchakda 4 turibdi. Qarama-qarshi burchakda qaysi son?",opts:["6","11","4","5"],ok:0,why:"4 + 5 + ? = 15 → ? = 6.",hint:"Diagonal markazdan o'tadi.",full:"Diagonal: 4 + 5 + ? = 15 → 9 + ? = 15 → ? = 6. Juft yig'indisi 4 + 6 = 10 ✓."},
 tn:"Bolalar o'z kvadratini burab yoki ko'zguday aylantirib, yangi sehrli kvadratlar oladi — hammasi 8 xil."},
{h:"Sonli piramida",sum:"Har g'isht — ostidagi ikki g'isht yig'indisi. Pastdan yuqoriga qo'shamiz, yuqoridan pastga ayiramiz.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>G'ishtlardan piramida qurilgan. Qoida: har bir g'ishtdagi son — <b>uning ostidagi ikki g'isht</b> sonlari yig'indisi.</p>",
 btns:[phaser(P5,'⬆ Yuqoriga')],
 after:"<p>Pastdan yuqoriga — <b>qo'shamiz</b>. Agar yuqoridagi son ma'lum bo'lib, pastdagisi yo'q bo'lsa — <b>ayiramiz</b>: masalan, 8 = 3 + ?, demak ? = 5.</p>",
 q:{t:"Piramida: pastda 2, ?, 4; o'rta qatorda 7 va ?. Cho'qqida qaysi son?",opts:["16","13","9","14"],ok:0,why:"? = 7 − 2 = 5; 5 + 4 = 9; 7 + 9 = 16.",hint:"Avval pastdagi ? ni toping: 2 + ? = 7.",full:"2 + ? = 7 → ? = 5. O'rtadagi ikkinchi g'isht: 5 + 4 = 9. Cho'qqi: 7 + 9 = 16. «13» — 2 + 7 + 4, qoida buzilgan."},
 tn:"Piramidani kubiklar yoki yopishqoq qog'ozlar bilan doskada yasang."},
{h:"Shakllar — sonlar o'rnida",sum:"Bir xil shakl — bir xil son. Avval bitta shakl qatnashgan tenglikni yeching.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Jumboqda sonlar shakllar bilan yashiringan. Qoida: <b>bir xil shakl — doim bir xil son</b>.</p>",
 btns:[phaser(P6)],
 after:"<p>Avval faqat bitta shakl qatnashgan tenglikni topamiz: ● + ● = 12 → ● = 6. Keyin uni keyingi tenglikka qo'yamiz: 6 + ▲ = 10 → ▲ = 4.</p>",
 q:{t:"▲ + ▲ = 14, ▲ + ● = 10. ● = ?",opts:["3","7","4","24"],ok:0,why:"▲ = 7, ● = 10 − 7 = 3.",hint:"Avval ▲ ni toping: 14 : 2.",full:"▲ + ▲ = 14 → ▲ = 7. 7 + ● = 10 → ● = 3. «7» — bu ▲, ● emas."},
 tn:"Shakllar o'rniga bolalar ismlarining bosh harflarini ishlatish qiziqarli bo'ladi."},
{h:"Tuzoq: zanjirli jumboq",sum:"Qaysi tenglikda bitta shakl bor — o'shandan boshlab, zanjir bo'ylab boramiz.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Uchta shakl, uchta tenglik. Ko'p bola birinchi qatordan emas, oxirgisidan boshlab, adashib qoladi. Qayerdan boshlash kerak?</p>",
 btns:[phaser(P7)],
 after:"<p>Faqat <b>bitta</b> shakl qatnashgan tenglikdan boshlaymiz (■ + ■ + ■ = 15 → ■ = 5). Keyin <b>topilganini</b> qo'yib, keyingisiga o'tamiz: ★ = 4, ▲ = 3.</p>",
 q:{t:"● + ● + ● = 12, ● + ■ = 10, ■ + ▲ = 8. ▲ = ?",opts:["2","4","6","8"],ok:0,why:"● = 4, ■ = 6, ▲ = 2.",hint:"● = 12 : 3.",full:"● = 12 : 3 = 4. ■ = 10 − 4 = 6. ▲ = 8 − 6 = 2. «4» — bu ●, «6» — bu ■."},
 tn:"Har topilgan shaklni doskada yozib qo'ying — zanjir ko'rinsin."},
{h:"Bilasizmi? Toshbaqa kosasidagi kvadrat",sum:"Lo Shu — eng qadimgi sehrli kvadrat (Xitoy afsonasi). Dyurer 1514-yilda 4 × 4 sehrli kvadratni gravyurasiga chizgan.",a:"m08",
 start:function(){clear();h5sq(h5LS,{hl:[4]});h5msg('Lo Shu kvadrati')},fin:function(){clear();h5sq(h5LS,{hl:[4]});h5msg('Lo Shu kvadrati')},
 html:"<p>🐢 Qadimgi Xitoy afsonasiga ko'ra, daryodan chiqqan toshbaqaning kosasida nuqtalardan iborat naqsh bo'lgan. Bu naqsh — aynan siz ko'rgan 3 × 3 sehrli kvadrat. Uni <b>Lo Shu</b> deb atashadi.</p><p>🎨 Nemis rassomi Albrext Dyurer 1514-yilda «Melanxoliya I» gravyurasiga 4 × 4 sehrli kvadrat chizgan: unda yig'indi <b>34</b>, pastki qatorning o'rtasida esa yil — <b>15 14</b> yashiringan!</p>",
 tn:"Dyurer kvadrati rasmini ko'rsatib, bolalarga bitta qatorini qo'shtiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){clear();h5sq(h5LS,{rs:[15,15,15]});h5msg('Sehrli yig‘indi 15')},fin:function(){clear();h5sq(h5LS,{rs:[15,15,15]});h5msg('Sehrli yig‘indi 15')},
 html:"<div class='memo'><ul><li>Sehrli kvadrat: har qator, ustun va diagonal yig'indisi bir xil.</li><li>1–9 dan: yig'indi <b>15</b> (45 : 3), markazda <b>5</b>.</li><li>Bo'sh katak: yig'indidan ma'lumlarini ayiring.</li><li>Piramida: pastdan — qo'shamiz, yuqoridan — ayiramiz.</li><li>Shakl jumbog'i: bir xil shakl — bir xil son; <b>bitta shakl</b> qatnashgan tenglikdan boshlang.</li><li>Javobni doim tekshiring.</li></ul></div>",
 tn:"Uyga: o'z piramidangizni tuzib, cho'qqisini yashirib, do'stingizga bering."}
];
var PROBS=[
{t:"1 dan 9 gacha sonlardan tuzilgan sehrli kvadratda sehrli yig'indi nechaga teng?",o:["15","45","9","18"],k:0,s:"45 : 3 = 15."},
{t:"1–9 sehrli kvadratining markazida qaysi son turadi?",o:["5","9","1","4"],k:0,s:"Markazda doim o'rtadagi son — 5."},
{t:"Sehrli yig'indi 15. Qator: 4, ?, 2. ? = ?",o:["9","6","8","11"],k:0,s:"15 − 4 − 2 = 9."},
{t:"Sehrli yig'indi 15. Ustun: ?, 5, 7. ? = ?",o:["3","2","12","8"],k:0,s:"15 − 5 − 7 = 3."},
{t:"Sehrli yig'indi 15, markazda 5. Bir burchakda 2. Qarama-qarshi burchakda?",o:["8","7","10","3"],k:0,s:"2 + 5 + 8 = 15."},
{t:"3 × 3 sehrli kvadratda nechta chiziqning yig'indisi teng?",o:["8","6","9","4"],k:0,s:"3 qator + 3 ustun + 2 diagonal."},
{t:"Sonlar 2–10 dan sehrli kvadrat. Sehrli yig'indi?",o:["18","15","54","20"],k:0,s:"54 : 3 = 18."},
{t:"Sehrli yig'indi 18. Qator: 7, ?, 5. ? = ?",o:["6","8","12","4"],k:0,s:"18 − 7 − 5 = 6."},
{t:"Piramida: pastda 4 va 6. Ustidagi g'ishtda qaysi son?",o:["10","2","24","46"],k:0,s:"4 + 6 = 10."},
{t:"Piramida: pastda 1, 3, 5. Cho'qqida qaysi son?",o:["12","9","8","15"],k:0,s:"4 va 8, keyin 4 + 8 = 12."},
{t:"Piramida: yuqorida 9, ostida 5 va ?. ? = ?",o:["4","14","5","3"],k:0,s:"9 − 5 = 4."},
{t:"Piramida: pastda 2, 3, 4, 1. Cho'qqi?",o:["24","10","20","22"],k:0,s:"5, 7, 5 → 12, 12 → 24."},
{t:"● + ● = 18. ● = ?",o:["9","18","8","36"],k:0,s:"18 : 2 = 9."},
{t:"▲ + ▲ + ▲ = 21. ▲ = ?",o:["7","3","18","6"],k:0,s:"21 : 3 = 7."},
{t:"● + ● = 10, ● + ■ = 12. ■ = ?",o:["7","5","2","6"],k:0,s:"● = 5, ■ = 12 − 5 = 7."},
{t:"■ + ■ + ■ = 15, ■ + ★ = 9, ★ + ▲ = 7. ▲ = ?",o:["3","4","5","2"],k:0,s:"■ = 5, ★ = 4, ▲ = 3."},
{t:"● + ▲ = 9, ● − ▲ = 1. ● = ?",o:["5","4","8","10"],k:0,s:"5 + 4 = 9, 5 − 4 = 1 → ● = 5."},
{t:"● · ● = 16, ● + ▲ = 13. ▲ = ?",o:["9","4","12","3"],k:0,s:"● = 4 (4 · 4 = 16), ▲ = 13 − 4 = 9."},
{t:"1▲ + ▲ = 24 (1▲ — ikki xonali son, ▲ — raqam). ▲ = ?",o:["7","4","12","6"],k:0,s:"17 + 7 = 24 → ▲ = 7."},
{t:"Qaysi kvadrat sehrli emas?",o:["1 2 3 / 4 5 6 / 7 8 9","4 9 2 / 3 5 7 / 8 1 6","2 7 6 / 9 5 1 / 4 3 8","8 1 6 / 3 5 7 / 4 9 2"],k:0,s:"1+2+3 = 6, 7+8+9 = 24 — qatorlar teng emas."}
];
function PRACT_STAGE(){clear();h5sq(h5LS,{rs:[15,15,15]});h5msg('Bir xil shakl — bir xil son; yig‘indidan ayiring')}
var PREP_DATA={teach:["Sehrli kvadrat va sehrli yig'indi.","Bo'sh kataklarni ayirish orqali topish; markaz 5 qoidasi.","Sonli piramida: qo'shish va ayirish.","Shakl tengliklarini zanjir bo'ylab yechish."],
 mist:["Diagonallarni tekshirmaydi.","Ma'lum sonlar yig'indisini javob deb yozadi.","Piramidada uchta sonni birdan qo'shadi.","Zanjirli jumboqni noto'g'ri tenglikdan boshlaydi."],
 need:["3 × 3 katakli kartochkalar, 1–9 raqamli kichik kartochkalar (har bolaga)."],
 board:["<span class='w2'>4 9 2 / 3 5 7 / 8 1 6</span> — yig'indi 15.","1 + … + 9 = 45, 45 : 3 = 15.","Piramida: <span class='w2'>3, 5, 2 → 8, 7 → 15</span>.","● + ● = 12 → ● = 6."]};
