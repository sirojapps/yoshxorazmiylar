var CODE='3Y5',TITLE='3-sinf · Eyler–Venn diagrammasi bilan murakkab masalalar';
function y5msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var Y5C={A:[150,72],B:[210,72],C:[180,120]},Y5R=50;
function y5in(x,y,k){var c=Y5C[k];return Math.hypot(x-c[0],y-c[1])<Y5R}
function y5regAt(x,y){var s=(y5in(x,y,'A')?'A':'')+(y5in(x,y,'B')?'B':'')+(y5in(x,y,'C')?'C':'');return s||'N'}
var Y5POS={ABC:[180,92],AB:[180,50],AC:[148,110],BC:[212,110],A:[115,62],B:[245,62],C:[180,150],N:[330,150]};
function y5rings(g,o){o=o||{};var col={A:C.blue,B:C.a2,C:C.ok};['A','B','C'].forEach(function(k){var c=Y5C[k];E('circle',{cx:c[0],cy:c[1],r:Y5R,fill:'rgba(0,0,0,.025)',stroke:col[k],'stroke-width':2.6},g)});
 T(g,62,26,o.a||'A',{'font-size':11,'font-weight':800,fill:C.blue});T(g,298,26,o.b||'B',{'font-size':11,'font-weight':800,fill:C.a2});T(g,62,160,o.c||'C',{'font-size':11,'font-weight':800,fill:C.ok})}
// 1..15: A juft, B 3 ga karrali, C 5 ga karrali
function y5reg(n){var s=(n%2===0?'A':'')+(n%3===0?'B':'')+(n%5===0?'C':'');return s||'N'}
var Y5SP={A:[[112,66],[118,88],[126,40],[140,58]],B:[[248,66],[242,88]],C:[[180,150]],AB:[[180,44],[180,62]],AC:[[150,108]],BC:[[210,108]],ABC:[[180,90]],N:[[24,40],[24,140],[336,40],[336,140]]};
function y5chip(g,x,y,t,col){E('circle',{cx:x,cy:y,r:8.5,fill:'#fff',stroke:col||'#33475b','stroke-width':1.6},g);T(g,x,y+3.5,''+t,{'font-size':10,'font-weight':800,fill:'#33475b'})}
function y5place(list,o){clear();var g=S.g;y5rings(g,o||{a:'A: juft',b:'B: 3 ga karrali',c:'C: 5 ga karrali'});var used={};
 list.forEach(function(n){var r=y5reg(n);used[r]=(used[r]||0);var p=Y5SP[r][used[r]++];y5chip(g,p[0],p[1],n)})}
var Y5G=[[6,12],[10],[15],[2,4,8,14],[3,9],[5],[1,7,11,13]];
function y5upto(k){var a=[];for(var i=0;i<k;i++)a=a.concat(Y5G[i]);return a}
var P1=[function(){y5place([]);y5msg('Uch halqa — 8 ta joy. 1 dan 15 gacha sonlarni joylaymiz')},
 function(){y5place(y5upto(1));y5msg('Juft va 3 ga karrali (lekin 5 ga emas): 6, 12')},
 function(){y5place(y5upto(3));y5msg('A va C: 10; B va C: 15')},
 function(){y5place(y5upto(6));y5msg('Faqat bittasiga: 2, 4, 8, 14 | 3, 9 | 5')},
 function(){y5place(y5upto(7));y5msg('Hech biriga: 1, 7, 11, 13. <b>Markaz bo‘sh!</b>')}];
// 2) hudud bosish
var Y5NM={ABC:'uchalasiga',AB:'faqat A va B ga',AC:'faqat A va C ga',BC:'faqat B va C ga',A:'faqat A ga',B:'faqat B ga',C:'faqat C ga',N:'hech biriga'};
function y5s2(){clear();var g=S.g;y5rings(g,{a:'A: juft',b:'B: 3 ga karrali',c:'C: 5 ga karrali'});(S.p2||[]).forEach(function(p){var q=Y5POS[p[1]];y5chip(g,q[0],q[1],p[0],C.ok)});
 var t=S.q2[0];if(t)T(g,300,90,'Son: '+t[0],{'font-size':16,'font-weight':800,fill:C.bad});
 var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:pointer'},sv);
 r.addEventListener('click',function(ev){if(!S.d2)return;var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var q=pt.matrixTransform(sv.getScreenCTM().inverse());y5t2(y5regAt(q.x,q.y))})}
function y5t2(rg){var t=S.q2[0];if(!t)return;if(rg!==t[1]){y5msg('Bu joy — <b>'+Y5NM[rg]+'</b> tegishli sonlar uchun. '+t[0]+' ni yana tekshiring');return}
 S.p2.push(t);S.q2.shift();y5s2();if(S.q2.length)y5msg('To‘g‘ri! Endi <b>'+S.q2[0][0]+'</b> ni joylang');else{y5msg('Barakalla! 30 — juft ham, 3 ga ham, 5 ga ham bo‘linadi');var d=S.d2;S.d2=null;d()}}
// sonli 3 to'plam diagrammasi
function y5num(v,o){o=o||{};clear();var g=S.g;y5rings(g,{a:o.a||'I — ingliz: 14',b:o.b||'R — rus: 12',c:o.c||'N — nemis: 9'});if(o.top)T(g,300,150,o.top,{'font-size':11,'font-weight':800,fill:'#5a6b7c'});
 Object.keys(v).forEach(function(k){var p=Y5POS[k];var hi=o.hi&&o.hi.indexOf(k)>=0;if(hi)E('circle',{cx:p[0],cy:p[1]-5,r:13,fill:'#ffd24d',stroke:C.bad,'stroke-width':2},g);T(g,p[0],p[1],''+v[k],{'font-size':16,'font-weight':800,fill:hi?C.bad:'#33475b'})})}
var Y5V={ABC:2,AB:3,AC:2,BC:1,A:7,B:6,C:4};
var P3=[function(){y5num({},{top:'Sinfda 28 o‘quvchi'});calc(['I ∩ R = 5, I ∩ N = 4, R ∩ N = 3','Uchala tilni: 2'])},
 function(){y5num({ABC:2},{top:'Sinfda 28 o‘quvchi'});y5msg('1) Avval <b>markaz</b>: uchala til — 2')},
 function(){y5num({ABC:2,AB:3,AC:2,BC:1},{top:'Sinfda 28 o‘quvchi'});calc(['2) Faqat I va R: 5 − 2 = 3; faqat I va N: 4 − 2 = 2','faqat R va N: 3 − 2 = 1'])},
 function(){y5num(Y5V,{top:'Sinfda 28 o‘quvchi'});calc(['3) Faqat I: 14 − 3 − 2 − 2 = 7; faqat R: 12 − 3 − 1 − 2 = 6','faqat N: 9 − 2 − 1 − 2 = 4'])},
 function(){var v=Object.assign({N:3},Y5V);y5num(v,{top:''});calc(['4) Kamida bittasi: 2 + 3 + 2 + 1 + 7 + 6 + 4 = 25','Hech biri: 28 − 25 = <b>3</b>'])}];
// 5) eng kam / eng ko'p kesishma — chiziqli model
function y5bar(st){clear();var g=S.g;var x0=40,k=11;
 E('rect',{x:x0,y:30,width:25*k,height:22,rx:4,fill:'#eef1f4',stroke:'#9aa7b4'},g);T(g,x0+25*k/2,46,'Sinf: 25 o‘quvchi',{'font-size':11,'font-weight':800});
 if(st>=1){E('rect',{x:x0,y:66,width:18*k,height:22,rx:4,fill:'#cfe3f6',stroke:C.blue},g);T(g,x0+9*k,82,'Suzish: 18',{'font-size':11,'font-weight':800,fill:C.blue})}
 if(st===2){E('rect',{x:x0+10*k,y:100,width:15*k,height:22,rx:4,fill:'#ffe2b8',stroke:C.a2},g);T(g,x0+17.5*k,116,'Tennis: 15',{'font-size':11,'font-weight':800,fill:C.a2});
  E('rect',{x:x0+10*k,y:62,width:8*k,height:64,fill:'rgba(30,142,90,.18)',stroke:C.ok,'stroke-width':2,'stroke-dasharray':'4 3'},g);T(g,x0+14*k,145,'ikkalasi: 8',{'font-size':12,'font-weight':800,fill:C.ok})}
 if(st===3){E('rect',{x:x0,y:100,width:15*k,height:22,rx:4,fill:'#ffe2b8',stroke:C.a2},g);T(g,x0+7.5*k,116,'Tennis: 15',{'font-size':11,'font-weight':800,fill:C.a2});
  E('rect',{x:x0,y:62,width:15*k,height:64,fill:'rgba(30,142,90,.18)',stroke:C.ok,'stroke-width':2,'stroke-dasharray':'4 3'},g);T(g,x0+7.5*k,145,'ikkalasi: 15',{'font-size':12,'font-weight':800,fill:C.ok})}}
var P5=[function(){y5bar(0);y5msg('Ikkalasi bilan shug‘ullanadiganlar eng kami va eng ko‘pi nechta?')},
 function(){y5bar(1);y5msg('Suzish — 18 o‘quvchi, chapdan joylaymiz')},
 function(){y5bar(2);calc(['Tennisni iloji boricha <b>o‘ngga</b> suramiz: 25 − 15 = 10 dan boshlanadi','Ustma-ust: 18 + 15 − 25 = <b>8</b> — eng kami'])},
 function(){y5bar(3);calc(['Tennisni butunlay suzish <b>ichiga</b> joylaymiz','Ustma-ust: <b>15</b> — eng ko‘pi (kichik guruhdan oshmaydi)'])}];
// 7) mantiqiy doiralar
function y5logic(st){clear();var g=S.g;
 if(st>=1){E('ellipse',{cx:180,cy:92,rx:170,ry:78,fill:'rgba(30,142,90,.05)',stroke:C.ok,'stroke-width':2.6},g);T(g,180,30,'O‘simliklar',{'font-size':12,'font-weight':800,fill:C.ok})}
 E('ellipse',{cx:180,cy:100,rx:110,ry:54,fill:'rgba(224,122,47,.06)',stroke:C.a2,'stroke-width':2.6},g);T(g,180,60,'Gullar',{'font-size':12,'font-weight':800,fill:C.a2});
 E('ellipse',{cx:160,cy:110,rx:48,ry:26,fill:'rgba(31,111,178,.10)',stroke:C.blue,'stroke-width':2.6},g);T(g,160,114,'Atirgullar',{'font-size':11,'font-weight':800,fill:C.blue});
 if(st>=3){E('circle',{cx:268,cy:108,r:40,fill:'rgba(217,75,75,.08)',stroke:C.bad,'stroke-width':2.4,'stroke-dasharray':'5 3'},g);T(g,282,112,'Qizil',{'font-size':11,'font-weight':800,fill:C.bad})}}
var P7=[function(){y5logic(0);y5msg('«Barcha atirgullar — gul»: atirgullar halqasi gullar <b>ichida</b>')},
 function(){y5logic(1);y5msg('«Barcha gullar — o‘simlik»: gullar o‘simliklar ichida')},
 function(){y5logic(1);y5msg('Xulosa: <b>barcha atirgullar — o‘simlik</b> ✓ (ichki halqa — eng ichida)')},
 function(){y5logic(3);y5msg('«Ba’zi gullar qizil»: qizillar atirgullarga <b>tegmasligi ham</b> mumkin — aniq xulosa yo‘q')}];
var STEPS=[
{h:"Uch halqa — 8 ta joy",sum:"Uch to'plamli diagrammada 8 ta joy bor: markaz, 3 ta juftlik, 3 ta «faqat», tashqari.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=4;P1[4]()},
 html:"<p>A — juft sonlar, B — 3 ga karrali, C — 5 ga karrali sonlar (1 dan 15 gacha). Sonlarni diagrammaga joylaymiz:</p>",
 btns:[phaser(P1)],
 after:"<p>Uch halqa bir-birini kesib, <b>8 ta joy</b> hosil qiladi. Har bir son uchun uchta savol beramiz: «juftmi? 3 ga bo'linadimi? 5 ga bo'linadimi?» Qiziq: <b>markaz bo'sh</b> — 15 gacha uchala shartga mos son yo'q. Bo'sh joy ham diagrammaning bir qismi.</p>",
 q:{t:"1 dan 15 gacha sonlar uchun uchala halqaning umumiy qismida (markazda) nechta son bor?",opts:["0","1","2","3"],ok:0,why:"Juft, 3 ga va 5 ga bo'linadigan eng kichik son — 30.",hint:"15 juftmi?",full:"Markazdagi son 2 ga, 3 ga va 5 ga bo'linishi kerak. 15 toq, 10 esa 3 ga bo'linmaydi, 6 esa 5 ga bo'linmaydi. Eng kichigi 30 — demak, markazda 0 ta son."},
 tn:"Uchta hulahup bilan polda diagramma yasang. 1–15 kartochkalarini bolalar o'zi joylasin, har biri uchun 3 savolni ovoz chiqarib bersin."},
{h:"Sonni to'g'ri joyga qo'ying",sum:"Uchala shartni tekshirib, son uchun 8 joydan bittasini tanlaymiz.",a:"m02",
 start:function(){S.p2=[];S.q2=[[18,'AB'],[30,'ABC'],[20,'AC'],[7,'N']];y5s2();y5msg('<b>18</b> qayerda turadi? Diagrammada o‘sha joyni bosing')},fin:function(){S.p2=[[18,'AB'],[30,'ABC'],[20,'AC'],[7,'N']];S.q2=[];y5s2();y5msg('18 → A va B; 30 → markaz; 20 → A va C; 7 → tashqari')},
 act:function(c,done){S.d2=done},
 html:"<p>Har bir son uchun diagrammadagi joyni bosing: <b>18</b>, <b>30</b>, <b>20</b>, <b>7</b>.</p>",
 after:"<p>18 — juft va 3 ga bo'linadi, 5 ga emas → <b>faqat A va B</b>. 30 — uchalasiga → <b>markaz</b>. 20 — juft va 5 ga, 3 ga emas → <b>faqat A va C</b>. 7 — hech biriga → <b>tashqari</b>. «Faqat A va B» degani — C ga tegishli emas!</p>",
 q:{t:"Juft, 3 ga karrali va 5 ga karrali — uchalasiga tegishli eng kichik natural son?",opts:["30","15","10","60"],ok:0,why:"2 · 3 · 5 = 30.",hint:"Son 2 ga, 3 ga va 5 ga bo'linishi kerak.",full:"Son 2, 3 va 5 ga bo'linishi uchun 2 · 3 · 5 = 30 ga karrali bo'lishi kerak. Eng kichigi — 30. 15 juft emas, 10 esa 3 ga bo'linmaydi. 60 ham mos, lekin eng kichigi emas."},
 tn:"Doskadagi diagrammaga bolalar o'zi son yozib chiqsin; sinf «ha/yo'q» deb tekshirsin."},
{h:"Sonli masala: markazdan boshlang",sum:"Tartib: markaz → «faqat ikkitasi» → «faqat bittasi» → tashqari.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=4;P3[4]()},
 html:"<p>Sinfda 28 o'quvchi. Ingliz tilini 14, rus tilini 12, nemis tilini 9 kishi o'rganadi. I va R ni 5, I va N ni 4, R va N ni 3 kishi o'rganadi, uchala tilni — 2 kishi. Nechta o'quvchi hech qaysi tilni o'rganmaydi?</p>",
 btns:[phaser(P3)],
 after:"<p>Kalit — <b>ichkaridan tashqariga</b> to'ldirish. Markaz (2) har bir juftlik sonining ichida bor, shuning uchun «faqat ikkitasi» = juftlik − markaz. «Faqat bittasi» = halqa soni − ichidagi boshqa uch joy. Oxirida jami 25, hech biri <b>28 − 25 = 3</b>.</p>",
 q:{t:"Diagrammada: uchalasi — 1, faqat A va B — 2, faqat A va C — 3, faqat A — 4. A to'plamda nechta element?",opts:["10","4","7","9"],ok:0,why:"1 + 2 + 3 + 4 = 10.",hint:"A halqasining ichidagi barcha 4 joyni qo'shing.",full:"A halqasi 4 joydan iborat: markaz 1, faqat A va B 2, faqat A va C 3, faqat A 4. Jami 10. 4 — faqat «faqat A», 9 — markazni unutish."},
 tn:"Bolalarga bo'sh diagramma chizilgan varaqlar tarqating; sonlarni qalam bilan markazdan boshlab yozsin."},
{h:"Tuzoq: «ikkalasi» ichida markaz bor",sum:"«I va R ni o'rganadiganlar» — uchala tilni biladiganlarni ham o'z ichiga oladi.",a:"m04",
 start:function(){y5num(Y5V);y5msg('Uchala tugmani bosib, farqini ko‘ring')},fin:function(){y5num(Y5V,{hi:['AB']});y5msg('Faqat I va R: <b>3</b>; I va R (hammasi): 5')},
 html:"<p>Masalada «ingliz va rus tilini 5 kishi» deyilgan, diagrammada esa 3 turibdi. Nega? Uchala tugmani bosing:</p>",
 btns:[["I va R — hammasi",function(c,done){y5num(Y5V,{hi:['AB','ABC']});y5msg('I ∩ R: 3 + 2 = <b>5</b> (markaz ham kiradi)');mvK(done,3)}],["Faqat I va R",function(c,done){y5num(Y5V,{hi:['AB']});y5msg('Faqat I va R, nemischasiz: <b>3</b>');mvK(done,3)}],["Uchalasi",function(c,done){y5num(Y5V,{hi:['ABC']});y5msg('Uchala til: <b>2</b>');mvK(done,3)}]],g3:1,
 after:"<p>«I va R ni o'rganadiganlar» — I va R halqalarining <b>butun</b> umumiy qismi: 3 + 2 = 5. «<b>Faqat</b> I va R» — markazsiz qism: 3. Masaladagi juftlik sonini diagrammaga to'g'ridan-to'g'ri yozish — eng ko'p uchraydigan xato.</p>",
 q:{t:"Ingliz va rus tilini 8 kishi o'rganadi, ulardan 3 tasi nemis tilini ham. Faqat ingliz va rus tilini (nemischasiz) necha kishi o'rganadi?",opts:["5","8","11","3"],ok:0,why:"8 − 3 = 5.",hint:"8 kishining ichida uchala tilni biladiganlar bor.",full:"8 kishi — ingliz va rus tilini o'rganadiganlarning hammasi, shu jumladan nemis tilini ham biladigan 3 kishi. Faqat ingliz va rus: 8 − 3 = 5."},
 tn:"«Faqat» so'zi bor-yo'qligiga qarab, doskada ikki rang bilan bo'yating."},
{h:"Eng kam va eng ko'p kesishma",sum:"Ikkalasi eng kami: A + B − jami (manfiy bo'lsa 0); eng ko'pi: kichik guruh soni.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>25 o'quvchidan 18 tasi suzish, 15 tasi tennis bilan shug'ullanadi. Ikkalasi bilan shug'ullanadiganlar <b>eng kami</b> va <b>eng ko'pi</b> nechta bo'lishi mumkin? Chiziqli model bilan ko'ramiz (Singapur usuli):</p>",
 btns:[phaser(P5)],
 after:"<p><b>Eng kami</b>: guruhlarni iloji boricha ajratamiz — 18 + 15 = 33, sinfda esa 25: kamida 33 − 25 = <b>8</b> kishi ikkalasida. <b>Eng ko'pi</b>: kichik guruh to'liq kattasining ichida — <b>15</b>. Kesishma 8 dan 15 gacha bo'lishi mumkin.</p>",
 q:{t:"30 o'quvchidan 20 tasi kitobni, 17 tasi rasmni yaxshi ko'radi. Ikkalasini yaxshi ko'radiganlar eng kami nechta?",opts:["7","17","3","37"],ok:0,why:"20 + 17 − 30 = 7.",hint:"Ikki guruh sinfga sig'masa, ortiqchasi ustma-ust tushadi.",full:"20 + 17 = 37, sinfda 30 kishi: 37 − 30 = 7 kishi albatta ikkala guruhda. 17 — eng ko'pi, 3 = 20 − 17 noto'g'ri amal, 37 — yig'indi."},
 tn:"Ikki rangli qog'oz lentani bitta uzun lenta ustiga qo'yib suring: ustma-ust qism qanday o'zgaradi?"},
{h:"Diagrammani o'qish",sum:"«Faqat bittasi», «kamida ikkitasi», «hech biri» — har biri diagrammaning boshqa joylari.",a:"m06",
 start:function(){y5num(Object.assign({N:3},Y5V));y5msg('Uchala tugmani bosing')},fin:function(){y5num(Object.assign({N:3},Y5V),{hi:['AB','AC','BC','ABC']});y5msg('Kamida ikkitasi: 3 + 2 + 1 + 2 = <b>8</b>')},
 html:"<p>Tayyor diagramma (28 o'quvchi, tillar). Har bir savol diagrammaning qaysi joylarini qo'shishni bildiradi?</p>",
 btns:[["Faqat bittasi",function(c,done){y5num(Object.assign({N:3},Y5V),{hi:['A','B','C']});y5msg('Faqat bitta til: 7 + 6 + 4 = <b>17</b>');mvK(done,3)}],["Kamida ikkitasi",function(c,done){y5num(Object.assign({N:3},Y5V),{hi:['AB','AC','BC','ABC']});y5msg('Kamida ikkitasi: 3 + 2 + 1 + 2 = <b>8</b>');mvK(done,3)}],["Hech biri",function(c,done){y5num(Object.assign({N:3},Y5V),{hi:['N']});y5msg('Hech biri: <b>3</b>. Tekshiruv: 17 + 8 + 3 = 28 ✓');mvK(done,3)}]],g3:1,
 after:"<p>«Faqat bittasi» — 3 ta tashqi bo'lak (17). «Kamida ikkitasi» — 3 ta juftlik bo'lagi va markaz (8). «Hech biri» — tashqari (3). Uchalasining yig'indisi butun sinfga teng: 17 + 8 + 3 = 28 — bu tekshirish usuli.</p>",
 q:{t:"Shu diagrammada «kamida ikkita tilni» o'rganadiganlar nechta?",opts:["8","6","17","2"],ok:0,why:"3 + 2 + 1 + 2 = 8.",hint:"Markazni ham qo'shishni unutmang.",full:"Kamida ikkita til: faqat ikkitasi (3 + 2 + 1 = 6) va uchalasi (2): jami 8. 6 — markazni unutish, 17 — faqat bittasi, 2 — faqat markaz."},
 tn:"Diagrammani doskaga chizing va har savol uchun mos bo'laklarni bolalar o'zi bo'yasin."},
{h:"Mulohazalar va doiralar",sum:"«Barcha A — B» = A halqasi B ichida. «Ba'zi» — faqat qisman kesishish.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Eyler doiralari mantiqiy xulosa chiqarishda ham yordam beradi. «Barcha» va «ba'zi» so'zlarini chizamiz:</p>",
 btns:[phaser(P7)],
 after:"<p>«<b>Barcha</b> atirgullar — gul» va «barcha gullar — o'simlik» bo'lsa, atirgul halqasi eng ichida — <b>barcha atirgullar o'simlik</b>. «<b>Ba'zi</b> gullar qizil» dan esa atirgullar haqida aniq xulosa chiqmaydi: qizil halqa atirgullarga tegishi ham, tegmasligi ham mumkin.</p>",
 q:{t:"«Barcha kvadratlar — to'rtburchak. Barcha to'rtburchaklar — ko'pburchak.» Qaysi xulosa to'g'ri?",opts:["Barcha kvadratlar — ko'pburchak","Barcha ko'pburchaklar — kvadrat","Ba'zi kvadratlar ko'pburchak emas","Barcha to'rtburchaklar — kvadrat"],ok:0,why:"Kvadratlar halqasi eng ichida.",hint:"Halqalarni ichma-ich chizing.",full:"Kvadratlar ⊂ to'rtburchaklar ⊂ ko'pburchaklar — kvadratlar halqasi eng ichida, demak barcha kvadratlar ko'pburchak. Teskari gaplar noto'g'ri: uchburchak ham ko'pburchak, lekin kvadrat emas."},
 tn:"Ichma-ich halqalar uchun hayotiy misol: «Qorako'l ⊂ Buxoro viloyati ⊂ O'zbekiston»."},
{h:"Teskari masala",sum:"Jami ma'lum bo'lsa, noma'lum bo'lak = jami − ma'lum bo'laklar.",a:"m08",
 start:function(){clear();var g=S.g;E('rect',{x:12,y:24,width:336,height:140,rx:12,fill:'#fff',stroke:'#9aa7b4','stroke-width':2,'stroke-dasharray':'5 4'},g);T(g,180,16,'Sinfda 32 o‘quvchi',{'font-size':12,'font-weight':800});E('circle',{cx:140,cy:96,r:56,fill:'rgba(31,111,178,.06)',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:220,cy:96,r:56,fill:'rgba(224,122,47,.06)',stroke:C.a2,'stroke-width':3},g);T(g,96,40,'Suzish',{'font-size':11,'font-weight':800,fill:C.blue});T(g,268,40,'Futbol',{'font-size':11,'font-weight':800,fill:C.a2});T(g,112,104,'10',{'font-size':22,'font-weight':800,fill:C.blue});T(g,248,104,'12',{'font-size':22,'font-weight':800,fill:C.a2});T(g,320,150,'4',{'font-size':20,'font-weight':800,fill:'#5a6b7c'});S.q8=E('text',{x:180,y:104,'text-anchor':'middle','font-size':22,'font-weight':800,fill:C.ok},g);S.q8.textContent='?';y5msg('Faqat suzish 10, faqat futbol 12, hech biri 4. Ikkalasi?')},
 fin:function(){STEPS[7].start();S.q8.textContent='6';calc(['32 − 10 − 12 − 4 = <b>6</b>','Tekshiruv: 10 + 6 + 12 + 4 = 32 ✓'])},
 html:"<p>Kesishmani topish uchun to'g'ri amallarni tanlang (har ikkalasini bosing):</p>",
 btns:[["Jamidan ma'lumlarni ayirish",function(c,done){S.q8.textContent='6';calc(['32 − 10 − 12 − 4 = <b>6</b>']);mvK(done,2)}],["Tekshirish",function(c,done){S.q8.textContent='6';calc(['10 + 6 + 12 + 4 = 32 ✓','Hamma bo‘laklar yig‘indisi = jami']);mvK(done,2)}]],
 after:"<p>Diagrammadagi <b>barcha bo'laklar yig'indisi = jami</b>. Shuning uchun noma'lum bo'lak: 32 − 10 − 12 − 4 = <b>6</b>. «Hech biri» ni ayirishni unutmang — aks holda 10 chiqib qoladi.</p>",
 q:{t:"Sinfda 30 o'quvchi: faqat suzish — 9, faqat tennis — 11, hech biri — 6. Ikkalasi bilan nechtasi shug'ullanadi?",opts:["4","10","26","14"],ok:0,why:"30 − 9 − 11 − 6 = 4.",hint:"Barcha bo'laklar yig'indisi 30 ga teng.",full:"9 + 11 + 6 = 26, 30 − 26 = 4. 10 — «hech biri» ni unutish (30 − 9 − 11), 26 — ma'lum bo'laklar yig'indisi."},
 tn:"Bolalar o'zlari shunday masala tuzsin va qo'shnisiga yechtirsin."},
{h:"Bilasizmi?",sum:"Uch to'plam — 8 ta joy; to'rt to'plamning barcha holatlarini faqat doiralar bilan chizib bo'lmaydi.",a:"m09",
 start:function(){P1[4]()},fin:function(){P1[4]()},
 html:"<p>🔵 Ikki to'plamli diagrammada 4 ta, uch to'plamlida <b>8</b> ta joy bor — har bir yangi to'plam joylar sonini ikki baravar oshiradi: to'rt to'plamda <b>16</b> ta.</p><p>✏️ To'rt to'plamning barcha 16 holatini faqat <b>doiralar</b> bilan chizib bo'lmaydi — Jon Venn buning uchun ellips kabi cho'zinchoq shakllardan foydalanishni ko'rsatgan.</p><p>🧠 Bunday diagrammalar bugun dasturlash, biologiya (turlarning umumiy belgilari) va ma'lumotlar tahlilida ishlatiladi.</p>",
 tn:"Kuchli o'quvchilarga topshiriq: 4 ta to'plam uchun 16 ta joyni qanday chizish mumkin?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P1[4]()},fin:function(){P1[4]()},
 html:"<div class='memo'><ul><li>Uch to'plam — <b>8</b> ta joy (markaz, 3 juftlik, 3 «faqat», tashqari).</li><li>To'ldirish tartibi: <b>markaz → faqat ikkitasi → faqat bittasi → tashqari</b>.</li><li>«A va B» ichida markaz ham bor; «faqat A va B» — markazsiz.</li><li>Barcha bo'laklar yig'indisi = jami (tekshiruv).</li><li>Ikki guruh kesishmasi: eng kami A + B − jami, eng ko'pi — kichik guruh.</li><li>«Barcha A — B»: A halqasi B ichida; «ba'zi» — qisman kesishish.</li></ul></div>",
 tn:"Bu mavzu 3-sinf yakuniy murakkab mavzusi: olimpiada masalalarida tez-tez uchraydi."}
];
var PROBS=[
{t:"A = { 1, 2, 3, 4, 5, 6 }, B = { 4, 5, 6, 7 }, C = { 5, 6, 8 }. Uchala to'plamning kesishmasi?",o:["{ 5, 6 }","{ 4, 5, 6 }","{ 6 }","{ 1, 2, 3, 4, 5, 6, 7, 8 }"],k:0,s:"5 va 6 uchalasida bor; 4 C da yo'q."},
{t:"A = { 1, 2, 3, 4, 5, 6 }, B = { 4, 5, 6, 7 }, C = { 5, 6, 8 }. A ∪ B ∪ C da nechta element?",o:["8","13","10","2"],k:0,s:"{ 1, 2, 3, 4, 5, 6, 7, 8 } — 8 ta."},
{t:"A = { 1, 2, 3, 4, 5, 6 }, B = { 4, 5, 6, 7 }, C = { 5, 6, 8 }. A va B ga tegishli, lekin C ga tegishli bo'lmagan elementlar?",o:["{ 4 }","{ 4, 5, 6 }","{ 5, 6 }","{ 7 }"],k:0,s:"A ∩ B = { 4, 5, 6 }, ulardan C da yo'qi — 4."},
{t:"1 dan 30 gacha 2 ga ham, 3 ga ham bo'linadigan sonlar nechta?",o:["5","10","15","25"],k:0,s:"6 ga karrali: 6, 12, 18, 24, 30."},
{t:"Diagrammada: uchalasi 2, faqat A va B 3, faqat A va C 1, faqat B va C 4, faqat A 5, faqat B 6, faqat C 7. A da nechta element?",o:["11","5","9","18"],k:0,s:"2 + 3 + 1 + 5 = 11."},
{t:"Diagrammada: uchalasi 2, faqat A va B 3, faqat A va C 1, faqat B va C 4, faqat A 5, faqat B 6, faqat C 7. B va C ga tegishli elementlar nechta?",o:["6","4","2","10"],k:0,s:"Faqat B va C 4 + uchalasi 2 = 6."},
{t:"Diagrammada: uchalasi 2, faqat A va B 3, faqat A va C 1, faqat B va C 4, faqat A 5, faqat B 6, faqat C 7. Kamida bittasiga tegishli elementlar nechta?",o:["28","30","18","26"],k:0,s:"2 + 3 + 1 + 4 + 5 + 6 + 7 = 28."},
{t:"Diagrammada: uchalasi 2, faqat A va B 3, faqat A va C 1, faqat B va C 4, faqat A 5, faqat B 6, faqat C 7. Faqat bitta to'plamga tegishli elementlar nechta?",o:["18","28","8","10"],k:0,s:"5 + 6 + 7 = 18."},
{t:"Ingliz va rus tilini 8 kishi o'rganadi, ulardan 3 tasi nemis tilini ham. Faqat ingliz va rus tilini necha kishi o'rganadi?",o:["5","8","11","3"],k:0,s:"8 − 3 = 5."},
{t:"40 o'quvchining har biri matematika yoki ingliz to'garagiga (kamida bittasiga) qatnashadi. Matematikaga 25, inglizga 22 kishi. Ikkalasiga nechta?",o:["7","3","47","15"],k:0,s:"25 + 22 − 40 = 7."},
{t:"Sinfda 32 o'quvchi: faqat suzish — 10, faqat futbol — 12, hech biri — 4. Ikkalasi bilan nechtasi shug'ullanadi?",o:["6","10","22","28"],k:0,s:"32 − 10 − 12 − 4 = 6."},
{t:"25 o'quvchidan 18 tasi suzish, 15 tasi tennis bilan shug'ullanadi. Ikkalasi bilan shug'ullanadiganlar eng kami nechta?",o:["8","3","15","33"],k:0,s:"18 + 15 − 25 = 8."},
{t:"25 o'quvchidan 18 tasi suzish, 15 tasi tennis bilan shug'ullanadi. Ikkalasi bilan shug'ullanadiganlar eng ko'pi nechta?",o:["15","18","8","25"],k:0,s:"Tennischilar to'liq suzuvchilar ichida bo'lsa — 15."},
{t:"25 o'quvchidan 18 tasi suzish, 15 tasi tennis bilan shug'ullanadi. Hech biri bilan shug'ullanmaydiganlar eng ko'pi nechta?",o:["7","0","10","3"],k:0,s:"Kesishma eng katta (15) bo'lganda kamida bittasi 18 ta: 25 − 18 = 7."},
{t:"«Barcha kvadratlar — to'rtburchak. Barcha to'rtburchaklar — ko'pburchak.» Qaysi xulosa to'g'ri?",o:["Barcha kvadratlar — ko'pburchak","Barcha ko'pburchaklar — kvadrat","Ba'zi kvadratlar ko'pburchak emas","Barcha to'rtburchaklar — kvadrat"],k:0,s:"Kvadratlar ⊂ to'rtburchaklar ⊂ ko'pburchaklar."},
{t:"«Ba'zi o'quvchilar — shaxmatchi. Barcha shaxmatchilar — mantiqchi.» Qaysi xulosa aniq to'g'ri?",o:["Ba'zi o'quvchilar — mantiqchi","Barcha o'quvchilar — mantiqchi","Barcha mantiqchilar — shaxmatchi","Hech bir o'quvchi mantiqchi emas"],k:0,s:"Shaxmatchi o'quvchilar mantiqchi ham — demak, ba'zi o'quvchilar mantiqchi."},
{t:"Har bir bola kamida bitta to'garakka qatnashadi: raqs — 12, qo'shiq — 10, rasm — 8. Har ikki to'garakka (har bir juftlik) 3 tadan bola qatnashadi, shu jumladan uchalasiga 1 bola. Jami nechta bola?",o:["22","30","21","19"],k:0,s:"Faqat juftliklar 2 tadan; faqat raqs 7, faqat qo'shiq 5, faqat rasm 3: 7 + 5 + 3 + 2 + 2 + 2 + 1 = 22."},
{t:"1 dan 30 gacha 2 ga yoki 3 ga (kamida bittasiga) bo'linadigan sonlar nechta?",o:["20","25","15","10"],k:0,s:"2 ga: 15, 3 ga: 10, ikkalasiga: 5; 15 + 10 − 5 = 20."},
{t:"1 dan 30 gacha na 2 ga, na 3 ga bo'linadigan sonlar nechta?",o:["10","5","20","15"],k:0,s:"30 − 20 = 10."},
{t:"1 dan 30 gacha 2 ga ham, 3 ga ham, 5 ga ham bo'linmaydigan sonlar nechta?",o:["8","10","7","3"],k:0,s:"1, 7, 11, 13, 17, 19, 23, 29 — 8 ta."}
];
function PRACT_STAGE(){P1[4]()}
var PREP_DATA={teach:["Uch to'plamli diagramma: 8 ta joy.","To'ldirish tartibi: markazdan tashqariga.","«Va» va «faqat … va …» farqi; diagrammani o'qish.","Kesishmaning eng kam/eng ko'p qiymati (chiziqli model).","Mulohazalar: «barcha», «ba'zi» — Eyler doiralari."],
 mist:["Juftlik sonini (masalan, I ∩ R = 5) markazni ayirmasdan yozadi.","Markazni bir necha marta qo'shadi.","«Hech biri» ni unutadi.","«Ba'zi» dan «barcha» xulosasini chiqaradi."],
 need:["3 ta hulahup yoki ip halqa.","1–30 son kartochkalari.","Bo'sh 3 halqali diagramma varaqlari, rangli qalamlar.","Ikki rangli qog'oz lenta (chiziqli model uchun)."],
 board:["8 ta joy: markaz, AB, AC, BC, A, B, C, tashqari.","Tartib: markaz → juftlik − markaz → halqa − 3 joy → tashqari.","28 o'q.: 2 | 3, 2, 1 | 7, 6, 4 | 3.","Eng kam: 18 + 15 − 25 = 8; eng ko'p: 15.","Atirgul ⊂ gul ⊂ o'simlik."]};
