// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4H4',TITLE='4-sinf · Masshtab va plan';
function h4plan(sc,lab){clear();var g=S.g,s=18;E('rect',{x:40,y:30,width:5*s,height:4*s,fill:'#fff3dc',stroke:C.t1,'stroke-width':2.4},g);E('rect',{x:40+5*s-26,y:30+4*s-2,width:20,height:4,fill:'#fff'},g);
 T(g,40+2.5*s,30+4*s+15,'5 sm',{'font-size':11,'font-weight':800,fill:C.bad});T(g,32,30+2*s+4,'4 sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});T(g,85,22,'Plan',{'font-size':12,'font-weight':800,fill:'#5b6b7b'});
 T(g,85,150,'Masshtab '+sc,{'font-size':13,'font-weight':800,fill:C.a2});E('path',{d:'M150 66 L190 66',stroke:C.ok,'stroke-width':2.4},g);E('path',{d:'M184 60 L192 66 L184 72',fill:'none',stroke:C.ok,'stroke-width':2.4},g);
 if(lab){E('rect',{x:205,y:24,width:130,height:104,fill:'#f6e7cf',stroke:C.t1,'stroke-width':3},g);T(g,270,140,lab[0],{'font-size':12,'font-weight':800,fill:C.bad});T(g,270,80,lab[1],{'font-size':12,'font-weight':800,fill:C.blue});T(g,270,18,'Haqiqatda',{'font-size':12,'font-weight':800,fill:'#5b6b7b'})}}
var P2=[function(){h4plan('1 : 100');calc(['Planda xona 5 sm × 4 sm. Haqiqiy o‘lchamlari?'])},
 function(){h4plan('1 : 100',['5 · 100 = 500 sm = 5 m','eni 4 · 100 = 4 m']);calc(['Har bir o‘lchamni <b>100 ga</b> ko‘paytiramiz','5 sm → 500 sm = <b>5 m</b>, 4 sm → <b>4 m</b>'])},
 function(){h4plan('1 : 100',['5 m','4 m · yuzi 20 m²']);calc(['Xona: 5 m × 4 m','Yuzi: 5 · 4 = <b>20 m²</b>'])}];
function h4bar(k){clear();var g=S.g,x0=40,u=56;E('line',{x1:x0,y1:62,x2:x0+5*u,y2:62,stroke:'#1d2b3a','stroke-width':2},g);
 for(var i=0;i<=5;i++){E('rect',{x:x0+i*u,y:56,width:i<5?u:0,height:12,fill:i%2?'#fff':'#1d2b3a',stroke:'#1d2b3a'},g);T(g,x0+i*u,48,(i*2)+(i===5?' km':''),{'font-size':12,'font-weight':800})}
 T(g,180,20,'Chiziqli masshtab: har bo‘lak (1 sm) — 2 km',{'font-size':11.5,'font-weight':800,fill:C.blue});
 if(k>=1){E('circle',{cx:x0,cy:118,r:6,fill:C.ok},g);E('circle',{cx:x0+3*u,cy:118,r:6,fill:C.bad},g);T(g,x0,140,'Qishloq',{'font-size':11,'font-weight':800,fill:C.ok});T(g,x0+3*u,140,'Shahar',{'font-size':11,'font-weight':800,fill:C.bad});E('line',{x1:x0,y1:118,x2:x0+3*u,y2:118,stroke:C.a2,'stroke-width':2.4,'stroke-dasharray':'6 4'},g)}
 if(k>=2){for(var j=0;j<3;j++)E('path',{d:'M'+(x0+j*u)+' 104 Q'+(x0+j*u+u/2)+' 88 '+(x0+(j+1)*u)+' 104',fill:'none',stroke:C.a2,'stroke-width':2},g);T(g,x0+1.5*u,84,'3 bo‘lak',{'font-size':12,'font-weight':800,fill:C.a2})}
 if(k>=3)T(g,290,122,'= 6 km',{'font-size':18,'font-weight':800,fill:C.a2})}
var P5=[function(){h4bar(0);calc(['Xaritada ko‘pincha bunday «chizg‘ich» chiziladi'])},function(){h4bar(1);calc(['Qishloqdan shahargacha xaritada qancha?'])},function(){h4bar(2);calc(['Masofani chiziqli masshtabga qo‘yamiz: <b>3 bo‘lak</b>'])},function(){h4bar(3);calc(['3 · 2 km = <b>6 km</b>'])}];
var P3=[function(){clear();var g=S.g;E('rect',{x:30,y:40,width:300,height:30,fill:'#d6efc7',stroke:'#3d8b3d','stroke-width':2},g);T(g,180,60,'Hovli bo‘yi: 12 m',{'font-size':13,'font-weight':800,fill:'#1d4d1d'});T(g,180,24,'Haqiqatda',{'font-size':11,'font-weight':700,fill:'#5b6b7b'});calc(['Masshtab 1 : 200. Planda necha sm?'])},
 function(){P3[0]();calc(['12 m = <b>1200 sm</b> (avval santimetrga!)'])},
 function(){P3[0]();var g=S.g;E('rect',{x:150,y:110,width:60,height:16,fill:'#d6efc7',stroke:'#3d8b3d','stroke-width':2},g);T(g,180,146,'Planda: 6 sm',{'font-size':13,'font-weight':800,fill:C.a2});calc(['1200 sm','1200 : 200 = <b>6 sm</b>'])}];
var P7=[function(){clear();var g=S.g;T(g,180,50,'Haqiqatda: 30 m',{'font-size':18,'font-weight':800,fill:'#1d4d1d'});T(g,180,100,'Planda: 6 sm',{'font-size':18,'font-weight':800,fill:C.a2});calc(['Masshtab qanday?'])},
 function(){P7[0]();calc(['Bir xil birlikka: 30 m = <b>3000 sm</b>'])},
 function(){P7[0]();calc(['3000 : 6 = 500 — haqiqiy uzunlik 500 marta katta','Masshtab <b>1 : 500</b>'])}];
function h4ant(k){clear();var g=S.g,s=k?5:1;function ant(x,y,sc){[[0,0,6],[10,0,5],[19,0,7]].forEach(function(b){E('ellipse',{cx:x+b[0]*sc,cy:y,rx:b[2]*sc,ry:b[2]*sc*.75,fill:'#5b3b1c'},g)});for(var i=0;i<3;i++){E('line',{x1:x+(6+i*4)*sc,y1:y,x2:x+(2+i*6)*sc,y2:y+9*sc,stroke:'#5b3b1c','stroke-width':Math.max(1,sc*.8)},g);E('line',{x1:x+(6+i*4)*sc,y1:y,x2:x+(2+i*6)*sc,y2:y-9*sc,stroke:'#5b3b1c','stroke-width':Math.max(1,sc*.8)},g)}}
 ant(60,90,1.2);T(g,70,124,'Haqiqatda',{'font-size':11,'font-weight':800,fill:'#5b6b7b'});T(g,70,140,'8 mm',{'font-size':12,'font-weight':800,fill:C.blue});
 if(k){ant(190,90,4.6);T(g,240,150,'Rasmda (5 : 1): 4 sm',{'font-size':12,'font-weight':800,fill:C.a2})}}
var STEPS=[
{h:"Masshtab nima?",sum:"1 : 100 — planda 1 sm haqiqatda 100 sm = 1 m. Ikkinchi son — necha marta kichraytirilgan.",a:"m01",
 start:function(){h4plan('1 : 100');g4m('Masshtabni tanlang')},fin:function(){h4plan('1 : 100',['5 m','4 m']);g4m('1 : 100 → planda 1 sm = haqiqatda 1 m')},
 html:"<p>Uy, hovli, shahar qog'ozga sig'maydi — ularni <b>kichraytirib</b> chizamiz. Necha marta kichraytirilganini <b>masshtab</b> ko'rsatadi. Bosing:</p>",
 btns:[["1 : 10",function(c,done){h4plan('1 : 10',['50 sm','40 sm']);g4m('Planda 1 sm = haqiqatda <b>10 sm</b> (10 marta kichik)');mvK(done,3)}],["1 : 100",function(c,done){h4plan('1 : 100',['5 m','4 m']);g4m('Planda 1 sm = haqiqatda <b>100 sm = 1 m</b>');mvK(done,3)}],["1 : 1000",function(c,done){h4plan('1 : 1000',['50 m','40 m']);g4m('Planda 1 sm = haqiqatda <b>1000 sm = 10 m</b>');mvK(done,3)}]],g3:1,
 after:"<p><b>1 : n</b> masshtab — chizmadagi har bir uzunlik haqiqiysidan <b>n marta kichik</b>. Planda 1 sm = haqiqatda n sm. Javobni qulay birlikka (m, km) o'tkazamiz.</p>",
 q:{t:"Masshtab 1 : 1000. Planda 1 sm haqiqatda qancha?",opts:["1 m","10 m","100 m","1000 m"],ok:1,why:"1000 sm = 10 m.",hint:"1 sm ni 1000 ga ko'paytiring va metrga o'tkazing.",full:"1 sm · 1000 = 1000 sm = 10 m. «1000 m» — sm ni m ga o'tkazmaslik xatosi, «1 m» — 1 : 100 bilan aralashtirish."},
 tn:"Sinf xonasini 1 : 100 masshtabda katakli daftarga chizdiring (1 katak = 50 sm)."},
{h:"Plandan haqiqiy o'lchamga",sum:"Planda 5 sm × 4 sm, 1 : 100 → 5 m × 4 m, yuzi 20 m².",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Kvartira planida bir xona 5 sm × 4 sm. Masshtab 1 : 100. Xona haqiqatda qanday?</p>",
 btns:[phaser(P2)],
 after:"<p>Plandan haqiqatga: <b>ko'paytiramiz</b> (plandagi uzunlik · n). Yuzni esa <b>haqiqiy o'lchamlardan</b> hisoblaymiz.</p>",
 q:{t:"Planda yo'lak 7 sm. Masshtab 1 : 200. Haqiqatda?",opts:["7 m","1400 m","14 m","35 m"],ok:2,why:"7 · 200 = 1400 sm = 14 m.",hint:"7 ni 200 ga ko'paytiring, keyin metrga o'tkazing.",full:"7 · 200 = 1400 sm = 14 m. «1400 m» — santimetrni metr deb olish, «7 m» — 1 : 100 deb o'qish."},
 tn:"Haqiqiy kvartira planini (e'lon gazetasidan) ko'rsating va xonalarni hisoblang."},
{h:"Haqiqiydan planga",sum:"12 m = 1200 sm; 1 : 200 da 1200 : 200 = 6 sm.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Hovli bo'yi 12 m. Uni 1 : 200 masshtabda chizish kerak. Planda necha sm?</p>",
 btns:[phaser(P3)],
 after:"<p>Haqiqatdan planga: avval <b>santimetrga</b> o'tkazamiz, keyin <b>n ga bo'lamiz</b>.</p>",
 q:{t:"Hovli 30 m. 1 : 500 masshtabdagi planda necha sm?",opts:["60 sm","6 sm","15 sm","150 sm"],ok:1,why:"3000 sm : 500 = 6 sm.",hint:"30 m ni avval sm ga o'tkazing.",full:"30 m = 3000 sm. 3000 : 500 = 6 sm. «60» — 30 m = 30 000 sm deb xato o'tkazish."},
 tn:"Bolalar maktab hovlisini qadamlab o'lchasin va 1 : 500 planini chizsin."},
{h:"Xarita masshtabi",sum:"1 : 100 000 → 1 sm = 1 km; 1 : 1 000 000 → 1 sm = 10 km.",a:"m04",
 start:function(){clear();g4m('Xarita masshtabini tanlang')},fin:function(){clear();T(S.g,180,80,'1 : 1 000 000  →  1 sm = 10 km',{'font-size':17,'font-weight':800,fill:C.blue});g4m('100 000 sm = 1 km')},
 html:"<p>Xaritalarda masshtab juda katta sonli bo'ladi. Eslab qoling: <b>1 km = 100 000 sm</b>. Bosing:</p>",
 btns:[["1 : 100 000",function(c,done){clear();T(S.g,180,60,'1 : 100 000',{'font-size':20,'font-weight':800,fill:C.blue});T(S.g,180,100,'1 sm = 100 000 sm = 1 km',{'font-size':15,'font-weight':800,fill:C.a2});g4m('Tuman xaritasi');mvK(done,3)}],["1 : 1 000 000",function(c,done){clear();T(S.g,180,60,'1 : 1 000 000',{'font-size':20,'font-weight':800,fill:C.blue});T(S.g,180,100,'1 sm = 10 km',{'font-size':15,'font-weight':800,fill:C.a2});g4m('Viloyat xaritasi');mvK(done,3)}],["1 : 5 000 000",function(c,done){clear();T(S.g,180,60,'1 : 5 000 000',{'font-size':20,'font-weight':800,fill:C.blue});T(S.g,180,100,'1 sm = 50 km',{'font-size':15,'font-weight':800,fill:C.a2});g4m('Respublika xaritasi');mvK(done,3)}]],g3:1,
 after:"<p>Qisqa yo'l: masshtabdagi sondan <b>beshta nolni olib tashlasak</b> — 1 sm necha km ekanini olamiz: 1 : 1 000 000 → 10 km.</p>",
 q:{t:"1 : 1 000 000 xaritada ikki shahar orasi 8 sm. Haqiqatda?",opts:["8 km","80 km","800 km","8000 km"],ok:1,why:"1 sm = 10 km; 8 · 10 = 80 km.",hint:"Avval 1 sm necha km ekanini toping.",full:"1 : 1 000 000 da 1 sm = 1 000 000 sm = 10 km. 8 · 10 = 80 km. «8 km» — 1 : 100 000 deb o'qish."},
 tn:"O'zbekiston xaritasida Toshkent–Samarqand masofasini chizg'ich bilan o'lchab, km ga o'tkazing."},
{h:"Chiziqli masshtab",sum:"Har bo'lak 2 km; masofa 3 bo'lak → 6 km.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Ko'pincha xaritaga raqamli emas, <b>chiziqli masshtab</b> chiziladi — kichik «chizg'ich». Undan foydalanamiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Masofani sirkul yoki qog'oz chetiga belgilab, chiziqli masshtabga qo'yamiz va bo'laklarni sanaymiz. Afzalligi: xarita kattalashtirib chop etilsa ham chiziqli masshtab to'g'ri qoladi.</p>",
 q:{t:"Chiziqli masshtabda 1 sm — 5 km. Xaritada masofa 4 sm. Haqiqatda?",opts:["9 km","20 km","45 km","4 km"],ok:1,why:"4 · 5 = 20 km.",hint:"Nechta bo'lak va har biri necha km?",full:"4 ta bo'lak, har biri 5 km: 20 km. «9» — qo'shish xatosi."},
 tn:"Qog'oz tasma chetiga chiziqli masshtab chizib, bolalar xaritada o'lchasin."},
{h:"Tuzoq: yuz masshtabda qanday o'zgaradi?",sum:"1 : 100 da 1 sm → 1 m, lekin 1 sm² → 1 m² = 10 000 sm². Yuz n · n marta katta.",a:"m06",
 start:function(){clear();var g=S.g;E('rect',{x:60,y:60,width:18,height:18,fill:C.hi,stroke:C.t1,'stroke-width':1.5},g);T(g,69,96,'1 sm²',{'font-size':11,'font-weight':800});T(g,69,50,'Planda',{'font-size':11,'font-weight':700,fill:'#5b6b7b'});E('rect',{x:170,y:22,width:120,height:120,fill:'#fff3dc',stroke:C.t1,'stroke-width':2},g);T(g,230,86,'1 m²',{'font-size':16,'font-weight':800,fill:C.a2});T(g,230,160,'Haqiqatda: 100 sm × 100 sm',{'font-size':11,'font-weight':800,fill:C.blue});g4m('Javobni bosing')},fin:function(){STEPS[5].start();g4m('1 sm² (planda) = 1 m² = 10 000 sm² (haqiqatda)')},
 html:"<p>Masshtab 1 : 100. Planda yuzi <b>1 sm²</b> bo'lgan kvadrat haqiqatda qancha?</p>",
 btns:[["100 sm²",function(c,done,b){b.style.background='#fde2e2';g4m('❌ Har tomon 100 marta, demak yuz 100 · 100 marta');setTimeout(function(){b.style.background=''},1600)}],["1 m²",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g4m('To‘g‘ri! 1 m × 1 m = <b>1 m²</b> = 10 000 sm²');done()}],["1 m",function(c,done,b){b.style.background='#fde2e2';g4m('❌ Yuz — kvadrat birlikda (m²), uzunlik emas');setTimeout(function(){b.style.background=''},1600)}]],
 after:"<p>Uzunliklar n marta oshsa, yuz <b>n · n</b> marta oshadi. 1 : 100 planda 12 sm² → haqiqatda 12 m² (12 · 10 000 sm²). Shuning uchun yuzni doim <b>haqiqiy o'lchamlardan</b> hisoblash xavfsiz.</p>",
 q:{t:"1 : 100 planda xona yuzi 12 sm². Haqiqiy yuzi?",opts:["1200 m²","12 m²","120 m²","12 sm²"],ok:1,why:"Planda 1 sm² = haqiqatda 1 m².",hint:"1 : 100 da 1 sm² haqiqatda qancha?",full:"1 : 100 da 1 sm² → 1 m², shuning uchun 12 sm² → 12 m². «1200 m²» — yuzni 100 ga ko'paytirish (uzunlikdagidek)."},
 tn:"Katakli qog'ozda 1 : 2 masshtabli kvadrat chizib, kataklar 4 marta kamayganini ko'rsating."},
{h:"Masshtabni topish",sum:"Haqiqiy 30 m = 3000 sm, planda 6 sm: 3000 : 6 = 500 → 1 : 500.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Haqiqiy uzunlik va plandagi uzunlik ma'lum. Masshtab qanday?</p>",
 btns:[phaser(P7)],
 after:"<p>Masshtab: <b>1 : (haqiqiy uzunlik : plandagi uzunlik)</b> — ikkalasi ham bir xil birlikda (sm)!</p>",
 q:{t:"Haqiqiy masofa 2 km, xaritada 4 sm. Masshtab?",opts:["1 : 500","1 : 50 000","1 : 5000","1 : 200 000"],ok:1,why:"2 km = 200 000 sm; 200 000 : 4 = 50 000.",hint:"2 km ni sm ga o'tkazing.",full:"2 km = 200 000 sm. 200 000 : 4 = 50 000 → 1 : 50 000. «1 : 500» — 2000 m : 4 (birliklarni tenglashtirmaslik)."},
 tn:"Bolalar o'z chizmasining masshtabini o'zi aniqlasin: stol o'lchami va chizmadagi o'lchami."},
{h:"Kattalashtirish masshtabi",sum:"5 : 1 — rasm haqiqiydan 5 marta katta. Rasmda 4 sm → haqiqatda 8 mm.",a:"m08",
 start:function(){h4ant(0);g4m('Chumoli juda kichik — uni kattalashtirib chizamiz')},fin:function(){h4ant(1);g4m('5 : 1 — rasm 5 marta katta')},
 html:"<p>Mayda narsalar (hasharot, soat detali) <b>kattalashtirib</b> chiziladi. Unda masshtab <b>5 : 1</b> kabi yoziladi. Bosing:</p>",
 btns:[["Kattalashtirish 5 : 1",function(c,done,b){b.disabled=true;h4ant(1);g4m('Haqiqatda 8 mm → rasmda 8 · 5 = 40 mm = <b>4 sm</b>');done()}]],
 after:"<p><b>n : 1</b> — rasm n marta <b>katta</b>: haqiqiy = rasmdagi : n. <b>1 : n</b> — rasm n marta <b>kichik</b>: haqiqiy = rasmdagi · n. Birinchi son — rasm, ikkinchisi — haqiqat.</p>",
 q:{t:"Masshtab 5 : 1. Rasmda detal 2 sm. Haqiqatda?",opts:["10 sm","4 mm","2 sm","4 sm"],ok:1,why:"20 mm : 5 = 4 mm.",hint:"Rasm kattalashtirilgan — haqiqiysi kichikroq.",full:"2 sm = 20 mm. Rasm 5 marta katta, demak haqiqatda 20 : 5 = 4 mm. «10 sm» — 1 : 5 deb ko'paytirish xatosi."},
 tn:"Lupa bilan barg yoki tangani ko'rib, kattalashtirilgan rasmini chizdiring."},
{h:"Bilasizmi? Eng qadimgi xaritalar",sum:"Bobil loy xaritasi (miloddan avvalgi ≈ 6-asr). Al-Xorazmiy «Surat al-arz» kitobida minglab joylarning o'rnini yozgan.",a:"m09",
 start:function(){h4bar(3);g4m('Xarita — masshtabli rasm')},fin:function(){h4bar(3);g4m('Xarita — masshtabli rasm')},
 html:"<p>🏺 Ma'lum bo'lgan eng qadimgi «dunyo xaritalari»dan biri — loy taxtachadagi <b>Bobil xaritasi</b> (miloddan avvalgi taxminan 6-asr).</p><p>🌍 Bizning bobokalonimiz <b>Muhammad al-Xorazmiy</b> «Surat al-arz» («Yer surati») kitobida minglab shahar, tog' va daryolarning o'rnini kenglik va uzunlik bilan yozib bergan — undan xarita chizish mumkin bo'lgan.</p>",
 tn:"Mahalliy xaritadan (tuman) maktabgacha bo'lgan masofani o'lchang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h4plan('1 : 100',['5 m','4 m'])},fin:function(){h4plan('1 : 100',['5 m','4 m'])},
 html:"<div class='memo'><ul><li><b>1 : n</b> — chizma n marta kichik: planda 1 sm = haqiqatda n sm.</li><li>Plandan haqiqatga — <b>· n</b>; haqiqatdan planga — avval sm ga, keyin <b>: n</b>.</li><li>1 km = 100 000 sm: 1 : 100 000 → 1 sm = 1 km; 1 : 1 000 000 → 10 km.</li><li>Masshtabni topish: haqiqiy (sm) : plandagi (sm).</li><li><b>n : 1</b> — kattalashtirish: haqiqiy = rasmdagi : n.</li><li>Yuz masshtabda n · n marta o'zgaradi: yuzni haqiqiy o'lchamlardan toping.</li><li>Chiziqli masshtab — bo'laklarni sanab ko'paytiring.</li></ul></div>",
 tn:"Uyga vazifa: o'z xonangiz planini 1 : 50 masshtabda chizish."}
];
var PROBS=[
{t:"Masshtab 1 : 100. Planda 1 sm haqiqatda?",o:["1 m","10 sm","10 m","100 m"],k:0,s:"100 sm = 1 m."},
{t:"Masshtab 1 : 1000. Planda 3 sm haqiqatda?",o:["30 m","3 m","300 m","3000 m"],k:0,s:"3 · 1000 = 3000 sm = 30 m."},
{t:"1 : 100 planda xona 6 sm × 4 sm. Haqiqiy o'lchamlari?",o:["6 m × 4 m","60 m × 40 m","6 dm × 4 dm","600 m × 400 m"],k:0,s:"600 sm × 400 sm = 6 m × 4 m."},
{t:"1 : 100 planda xona 6 sm × 4 sm. Haqiqiy yuzi?",o:["24 m²","24 sm²","2400 m²","20 m²"],k:0,s:"6 m · 4 m = 24 m²."},
{t:"Hovli 12 m. 1 : 200 planda necha sm?",o:["6 sm","24 sm","60 sm","2400 sm"],k:0,s:"1200 sm : 200 = 6 sm."},
{t:"1 : 100 000 xaritada 1 sm haqiqatda?",o:["1 km","100 m","10 km","100 km"],k:0,s:"100 000 sm = 1000 m = 1 km."},
{t:"1 : 1 000 000 xaritada 8 sm haqiqatda?",o:["80 km","8 km","800 km","8000 km"],k:0,s:"1 sm = 10 km; 8 · 10 = 80 km."},
{t:"Chiziqli masshtab: 1 sm — 5 km. Xaritada 4 sm. Haqiqatda?",o:["20 km","9 km","40 km","4 km"],k:0,s:"4 · 5 = 20 km."},
{t:"Haqiqiy uzunlik 30 m, planda 6 sm. Masshtab?",o:["1 : 500","1 : 5","1 : 50","1 : 180"],k:0,s:"3000 sm : 6 = 500."},
{t:"Haqiqiy masofa 2 km, xaritada 4 sm. Masshtab?",o:["1 : 50 000","1 : 500","1 : 5000","1 : 200 000"],k:0,s:"200 000 sm : 4 = 50 000."},
{t:"Masshtab 5 : 1. Rasmda 2 sm. Haqiqatda?",o:["4 mm","10 sm","2 sm","4 sm"],k:0,s:"20 mm : 5 = 4 mm."},
{t:"1 : 100 planda xona yuzi 12 sm². Haqiqiy yuzi?",o:["12 m²","1200 m²","120 m²","12 sm²"],k:0,s:"1 : 100 da 1 sm² = 1 m²."},
{t:"1 : 2 000 000 xaritada shaharlar orasi 3 sm. Avtobus soatiga 60 km yuradi. Necha soatda yetadi?",o:["1 soat","3 soat","6 soat","2 soat"],k:0,s:"1 sm = 20 km; 3 · 20 = 60 km; 60 : 60 = 1 soat."},
{t:"Bog' 40 m × 25 m. 1 : 500 plandagi o'lchamlari?",o:["8 sm × 5 sm","80 sm × 50 sm","4 sm × 2 sm","40 sm × 25 sm"],k:0,s:"4000 : 500 = 8 sm, 2500 : 500 = 5 sm."},
{t:"1 : 200 planda kvadrat xona tomoni 2 sm. Haqiqiy yuzi?",o:["16 m²","4 m²","8 m²","16 sm²"],k:0,s:"Tomon 400 sm = 4 m; 4 · 4 = 16 m²."},
{t:"Qaysi masshtabda chizma eng katta (eng ko'p detal) bo'ladi?",o:["1 : 100","1 : 1000","1 : 10 000","1 : 100 000"],k:0,s:"1 : 100 — eng kam kichraytirilgan."},
{t:"1 : 50 planda stol 3 sm. Haqiqatda?",o:["1 m 50 sm","150 m","15 sm","53 sm"],k:0,s:"3 · 50 = 150 sm = 1 m 50 sm."},
{t:"1 : 500 000 xaritada 25 km masofa necha sm bo'ladi?",o:["5 sm","50 sm","25 sm","2 sm"],k:0,s:"25 km = 2 500 000 sm; 2 500 000 : 500 000 = 5 sm."},
{t:"1 : 100 planda xona 3 sm × 2 sm. Polga 50 sm × 50 sm plitka. Nechta kerak?",o:["24","6","12","600"],k:0,s:"Xona 300 × 200 sm: (300 : 50) · (200 : 50) = 6 · 4 = 24."},
{t:"Model mashina 1 : 43 masshtabda, uzunligi 10 sm. Haqiqiy mashina?",o:["4 m 30 sm","43 sm","4 m 3 sm","53 sm"],k:0,s:"10 · 43 = 430 sm = 4 m 30 sm."}
];
function PRACT_STAGE(){h4plan('1 : 100',['5 m','4 m']);g4m('1 : n → planda 1 sm = haqiqatda n sm')}
var PREP_DATA={teach:["Masshtab tushunchasi: 1 : n.","Plandan haqiqatga (· n) va haqiqatdan planga (: n).","Xarita masshtabi, 1 km = 100 000 sm; chiziqli masshtab.","Masshtabni topish; kattalashtirish n : 1; yuz va masshtab."],
 mist:["Birliklarni tenglashtirmaydi (12 m : 200).","Natijani sm da qoldirib, m deb o'qiydi.","Yuzni ham n marta oshiradi (n · n o'rniga).","5 : 1 va 1 : 5 ni aralashtiradi."],
 need:["Katakli daftar, chizg'ich.","Tuman/viloyat xaritasi.","Sirkul yoki qog'oz tasma."],
 board:["<span class='w2'>1 : 100 → 1 sm = 1 m</span>.","<span class='w2'>5 sm · 100 = 5 m</span>; <span class='w2'>1200 sm : 200 = 6 sm</span>.","<span class='w2'>1 km = 100 000 sm</span>.","<span class='w2'>3000 : 6 = 500 → 1 : 500</span>.","Yuz: 1 sm² → 1 m²."]};
