// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4Y2',TITLE='4-sinf · Murakkab harakat: quvlama, kechikish, daryo oqimi';
function y2meet(st){clear();y4title('180 km. Bir vaqtda bir-biriga qarab: 50 km/soat va 40 km/soat');var X=y4road(110,180,30,330,[0,50,100,140,180]);
 var a=[0,50,100][st],b=[180,140,100][st];y4dot(X(a),96,'A',C.a);y4dot(X(b),72,'B',C.b);
 if(st===0){y4arrow(X(0)+12,X(0)+60,64,'50',C.a2);y4arrow(X(180)-12,X(180)-60,64,'40',C.blue)}
 if(st===1){E('line',{x1:X(50),y1:140,x2:X(140),y2:140,stroke:C.bad,'stroke-width':2},S.g);y4t((X(50)+X(140))/2,156,'qoldi 90 km',{'font-size':11,fill:C.bad})}
 if(st===2)y4t(X(100),148,'uchrashdi! 2 soat',{'font-size':13,'font-weight':800,fill:C.ok});y4t(320,40,st+' soat',{'font-size':13,'font-weight':800,fill:'#33475b','text-anchor':'end'})}
var Y2P1=[function(){y2meet(0);calc(['Har soatda ular orasidagi masofa qanchaga qisqaradi?'])},function(){y2meet(1);calc(['1 soatda: 50 + 40 = <b>90 km</b> ga yaqinlashdi'])},function(){y2meet(2);calc(['Yaqinlashish tezligi = 50 + 40 = 90 km/soat','180 : 90 = <b>2 soat</b>'])}];
function y2chase(st){clear();y4title('Piyoda 12 km oldinda (4 km/soat), velosipedchi 10 km/soat');var X=y4road(116,24,30,330,[0,4,8,12,16,20,24]);
 var p=[12,16,20][st],v=[0,10,20][st];y4dot(X(p),98,'P',C.a);y4dot(X(v),74,'V',C.b);
 if(st<2){E('line',{x1:X(v),y1:146,x2:X(p),y2:146,stroke:C.bad,'stroke-width':2},S.g);y4t((X(v)+X(p))/2,160,'orasi '+(p-v)+' km',{'font-size':11,fill:C.bad})}
 else y4t(X(20),150,'yetib oldi! 2 soat',{'font-size':13,'font-weight':800,fill:C.ok});y4t(330,40,st+' soat',{'font-size':13,'font-weight':800,fill:'#33475b','text-anchor':'end'})}
var Y2P2=[function(){y2chase(0);calc(['Bir yo‘nalishda harakat. Oradagi masofa qanday o‘zgaradi?'])},function(){y2chase(1);calc(['1 soatda: velosiped +10, piyoda +4 → ora <b>6 km</b> ga qisqardi (12 → 6)'])},function(){y2chase(2);calc(['Quvlash tezligi = 10 − 4 = 6 km/soat','12 : 6 = <b>2 soat</b>'])}];
function y2late(sh){clear();y4title('Ota 5 km/soat; o‘g‘li 2 soat kech chiqdi, 15 km/soat');var X=y4road(116,20,30,330,[0,5,10,15,20]);
 if(!sh){y4dot(X(10),98,'O',C.a);y4dot(X(0),74,'B',C.b);Br(X(0),X(10),132,'2 soatda: 10 km',false,C.bad)}
 else{y4dot(X(15),98,'O',C.a);y4dot(X(15),74,'B',C.b);y4t(X(15),150,'15 km da uchrashdi',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y2late2(st){clear();y4title('100 km. A — 40 km/soat; B 1 soat kech, 20 km/soat');var X=y4road(110,100,30,330,[0,40,80,100]);
 var a=[0,40,80][st],b=[100,100,80][st];y4dot(X(a),96,'A',C.a);y4dot(X(b),72,'B',C.b);
 if(st===1){E('line',{x1:X(40),y1:140,x2:X(100),y2:140,stroke:C.bad,'stroke-width':2},S.g);y4t(X(70)-20,156,'qoldi 60 km — endi ikkalasi yuradi',{'font-size':11,fill:C.bad})}
 if(st===2)y4t(180,150,'uchrashdi: 60 : (40 + 20) = 1 soat',{'font-size':12,'font-weight':800,fill:C.ok})}
var Y2P4=[function(){y2late2(0);calc(['Kechikish bor: avval faqat A yuradi'])},function(){y2late2(1);calc(['1 soatda A 40 km yurdi. Qoldi: 100 − 40 = <b>60 km</b>'])},function(){y2late2(2);calc(['Endi yaqinlashish: 40 + 20 = 60 km/soat. 60 : 60 = <b>1 soat</b>','A jami 2 soat yo‘lda: 80 km'])}];
function y2river(st){clear();y4title('Kater: o‘z tezligi 18 km/soat, daryo oqimi 3 km/soat');var g=S.g;E('rect',{x:14,y:46,width:332,height:84,rx:10,fill:'#d6ecfa'},g);
 for(var i=0;i<5;i++)y4arrow(30+i*66,70+i*66,120,'',C.blue);y4t(330,142,'oqim 3 →',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 function boat(x,dir){E('path',{d:dir>0?'M'+(x-26)+' 78 h44 l10 10 h-54 Z':'M'+(x+26)+' 78 h-44 l-10 10 h54 Z',fill:'#f0a040',stroke:'#8a5a24'},g);E('rect',{x:x-8,y:66,width:16,height:12,fill:'#fff',stroke:'#8a5a24'},g)}
 if(st===0){boat(180,1);y4t(180,58,'turg‘un suvda: 18',{'font-size':12,'font-weight':800})}
 if(st===1){boat(140,1);y4arrow(176,236,62,'18 + 3 = 21',C.ok)}
 if(st===2){boat(220,-1);y4arrow(184,124,62,'18 − 3 = 15',C.bad)}
 if(st===3){E('rect',{x:160,y:84,width:40,height:8,fill:'#b08a5a'},g);y4arrow(206,250,74,'sol: 3',C.blue)}}
var Y2P5=[function(){y2river(0);calc(['Ko‘lda (oqimsiz) kater 18 km/soat yuradi'])},function(){y2river(1);calc(['<b>Oqim bo‘yicha</b>: daryo itaradi → 18 + 3 = <b>21</b> km/soat'])},function(){y2river(2);calc(['<b>Oqimga qarshi</b>: daryo to‘sadi → 18 − 3 = <b>15</b> km/soat'])},function(){y2river(3);calc(['Sol (motorsiz) — o‘z tezligi 0: u <b>oqim tezligida</b> suzadi, 3 km/soat'])}];
function y2find(sh){clear();y4title('Oqim bo‘yicha 24 km/soat, oqimga qarshi 16 km/soat');var g=S.g,k=6,x0=40;
 E('rect',{x:x0,y:50,width:24*k*2,height:24,fill:'#cfeccf',stroke:C.ok},g);y4T(g,x0+24*k,67,'oqim bo‘yicha 24',{'font-size':11,'font-weight':800});
 E('rect',{x:x0,y:94,width:16*k*2,height:24,fill:'#ffd9d9',stroke:C.bad},g);y4T(g,x0+16*k,111,'qarshi 16',{'font-size':11,'font-weight':800});
 if(sh){Br(x0+32*k,x0+48*k,90,'2 · oqim = 8',false,C.blue);y4T(g,180,156,'oqim = 8 : 2 = 4; kater = 16 + 4 = 20',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y2avg(sh){clear();y4title('60 km bordi (60 km/soat), qaytdi (30 km/soat)');var X=y4road(80,60,40,320,[0,30,60]);y4arrow(X(0),X(60),60,'borish: 1 soat',C.ok);y4arrow(X(60),X(0),128,'qaytish: 2 soat',C.bad);
 if(sh)y4t(180,160,'120 km : 3 soat = 40 km/soat',{'font-size':14,'font-weight':800,fill:C.blue})}
function y2track(sh){clear();y4title('Stadion 400 m. Bir joydan bir tomonga: 5 m/s va 3 m/s');var g=S.g;E('ellipse',{cx:128,cy:98,rx:104,ry:58,fill:'none',stroke:'#c0587e','stroke-width':12,opacity:.5},g);E('ellipse',{cx:128,cy:98,rx:104,ry:58,fill:'none',stroke:'#fff','stroke-width':1,'stroke-dasharray':'6 6'},g);
 y4dot(128,40,'5',C.a);y4dot(154,42,'3',C.b);if(sh){y4t(298,80,'1 aylana ortda',{'font-size':11,'font-weight':800,fill:C.ok});y4t(298,100,'qolganda',{'font-size':11,'font-weight':800,fill:C.ok});y4t(298,124,'400 : 2 = 200 s',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y2zeno(st){clear();y4title('Axilles va toshbaqa (Zenon, ~2 500 yil oldin)');var X=y4road(110,120,30,330,[0,100,110,120]);
 var a=[0,100,110][st],t=[100,110,111][st];y4dot(X(a),96,'A',C.a);y4dot(X(t),72,'T',C.ok);
 if(st===2)y4t(180,148,'Har safar toshbaqa sal oldinda… Yetib oladimi?',{'font-size':12,'font-weight':800,fill:C.bad})}
var Y2P9=[function(){y2zeno(0);calc(['Axilles 10 m/s, toshbaqa 1 m/s; toshbaqa 100 m oldinda'])},function(){y2zeno(1);calc(['Axilles 100 m ga yetguncha (10 s) toshbaqa yana 10 m yurgan; keyin yana 1 m…'])},function(){y2zeno(2);calc(['Zenon: «hech qachon yetib ololmaydi!» Quvlama: 100 : (10 − 1) ≈ 11 soniyada yetib oladi!'])}];
function PRACT_STAGE(){clear();y4title('Harakat masalasi: avval chizma, keyin formula');var X=y4road(100,10,40,320,[]);y4dot(X(0),82,'A',C.a);y4dot(X(10),82,'B',C.b);y4arrow(X(0)+12,X(0)+60,60,'v₁',C.a2);y4arrow(X(10)-12,X(10)-60,60,'v₂',C.blue);
 calc(['Qarshi: v₁ + v₂; quvlama: v₁ − v₂; oqim: v ± u'])}
var STEPS=[
{h:"Qarama-qarshi harakat (takror)",sum:"Bir-biriga qarab: yaqinlashish tezligi v₁ + v₂. 180 : (50 + 40) = 2 soat.",a:"m01",
 start:function(){startPh(Y2P1)},fin:function(){S.ph=2;Y2P1[2]()},
 html:"<p>Avval asosiy holat: ikki mashina 180 km uzoqlikdan bir-biriga qarab yo'lga chiqdi. Har soatni kuzating:</p>",btns:[phaser(Y2P1)],
 after:"<p>Bir-biriga qarab harakatda oradagi masofa har soatda <b>v₁ + v₂</b> ga qisqaradi. Uchrashish vaqti = masofa : (v₁ + v₂). Qarama-qarshi tomonga (bir-biridan uzoqlashib) ketsa ham, ora shu tezlikda <b>ortadi</b>.</p>",
 q:{t:"Ikki mashina bir joydan qarama-qarshi tomonlarga yo'lga chiqdi: 55 va 65 km/soat. 3 soatdan keyin ular orasidagi masofa?",opts:["360 km","30 km","120 km","195 km"],ok:0,why:"(55 + 65) · 3 = 360.",hint:"Har soatda ular qanchaga uzoqlashadi?",full:"Har soatda ora 55 + 65 = 120 km ga ortadi. 3 soatda: 120 · 3 = 360 km. «30» — tezliklar ayirmasi · 3, «120» — bir soatlik masofa."},
 tn:"Ikki bola sinf ikki chetidan bir-biriga qarab qadam tashlaydi (biri 2, biri 1 kafeldan). Necha qadamda uchrashadi?"},
{h:"Quvlama: bir yo'nalishda",sum:"Oradagi masofa har soatda v₁ − v₂ ga qisqaradi: 12 : (10 − 4) = 2 soat.",a:"m02",
 start:function(){startPh(Y2P2)},fin:function(){S.ph=2;Y2P2[2]()},
 html:"<p>Piyoda 12 km oldinda. Velosipedchi uning orqasidan quvadi. Har soatni kuzating:</p>",btns:[phaser(Y2P2)],
 after:"<p>Bir yo'nalishda quvganda oradagi masofa har soatda <b>tezliklar ayirmasi</b>ga qisqaradi. Vaqt = oradagi masofa : (v₁ − v₂). Ko'p bola bu yerda ham tezliklarni qo'shib xato qiladi.</p>",
 q:{t:"It quyondan 150 m orqada. It 18 m/s, quyon 13 m/s tezlikda yuguradi. It necha soniyada quyonni quvib yetadi?",opts:["30 soniyada","5 soniyada","10 soniyada","8 soniyada"],ok:0,why:"150 : (18 − 13) = 30.",hint:"Har soniyada it quyonga qanchaga yaqinlashadi?",full:"Har soniyada ora 18 − 13 = 5 m ga qisqaradi. 150 : 5 = 30 soniya. «5» — tezliklar ayirmasi, «10» — 150 : 15, «8» — 150 : 18 (quyonni turgan deb olish)."},
 tn:"Doskada ikkita son o'qi chizib, har soat oxiridagi holatni jadvalga yozing: vaqt | velosiped | piyoda | ora."},
{h:"Kechikish bilan quvlama",sum:"Ota 2 soatda 10 km oldinlaydi; o'g'li 10 : (15 − 5) = 1 soatda yetadi.",a:"m03",
 start:function(){y2late(0);calc(['O‘g‘li yo‘lga chiqqanda otasi qayerda? Keyin quvlama'])},fin:function(){y2late(1);y4msg('O‘g‘li <b>1 soatda</b> yetib oladi (15 km da)')},
 html:"<p>Ota 5 km/soat tezlikda yo'lga chiqdi. 2 soatdan keyin o'g'li velosipedda 15 km/soat bilan uning orqasidan chiqdi. O'g'li necha soatda otasiga yetib oladi?</p>",
 btns:y4pick(0,[["1 soatda","Kechikishda ota 5 · 2 = 10 km yurdi. Quvlash: 10 : (15 − 5) = 1 soat."],["2 soatda","2 soat — kechikish vaqti. Avval otaning qancha oldinlaganini toping."],["3 soatda","3 soat — otaning yo'lda bo'lgan jami vaqti, o'g'ilniki emas."],["10 soatda","10 — oradagi masofa (km), vaqt emas."]],function(){y2late(1)}),g2:1,
 after:"<p>Kechikishli masala <b>ikki bosqich</b>: 1) kechikish vaqtida birinchisi qancha oldinlaydi (v · t); 2) keyin oddiy quvlama yoki uchrashish. Javobda kimning vaqti so'ralganiga qarang!</p>",
 q:{t:"Piyoda 4 km/soat bilan yo'lga chiqdi. 3 soatdan keyin orqasidan velosipedchi 10 km/soat bilan chiqdi. Ular boshlang'ich joydan qancha uzoqda uchrashadi?",opts:["20 km","12 km","30 km","8 km"],ok:0,why:"Oldinlik 12 km, 12 : 6 = 2 soat; velosipedchi 10 · 2 = 20 km.",hint:"Avval velosipedchi necha soatda yetishini toping.",full:"Piyoda 3 soatda 12 km yurdi. Quvlash: 12 : (10 − 4) = 2 soat. Velosipedchi 2 soatda 10 · 2 = 20 km yuradi (tekshirish: piyoda 4 · 5 = 20 ✓). «12» — oldinlik, «30» — 10 · 3."},
 tn:"Jadval usuli (Singapur): vaqt | ota | o'g'il. Har soatni to'ldirib, raqamlar teng bo'lgan qatorni toping."},
{h:"Kechikish bilan qarama-qarshi harakat",sum:"A 1 soatda 40 km yuradi, qoladi 60 km; 60 : (40 + 20) = 1 soat.",a:"m04",
 start:function(){startPh(Y2P4)},fin:function(){S.ph=2;Y2P4[2]()},
 html:"<p>Shaharlar orasi 100 km. A 40 km/soat bilan chiqdi, 1 soatdan keyin qarshi tomondan B 20 km/soat bilan chiqdi. Bosing:</p>",btns:[phaser(Y2P4)],
 after:"<p>Yana ikki bosqich: 1) kechikish vaqtida faqat bittasi yuradi — masofa qisqaradi; 2) qolgan masofani <b>v₁ + v₂</b> ga bo'lamiz. Bu vaqt — ikkinchisi chiqqandan keyingi vaqt.</p>",
 q:{t:"Shaharlar orasi 300 km. Avtobus 50 km/soat bilan chiqdi, 1 soatdan keyin qarshi tomondan mashina 75 km/soat bilan chiqdi. Mashina chiqqandan keyin necha soatda uchrashadi?",opts:["2 soatda","3 soatda","5 soatda","4 soatda"],ok:0,why:"300 − 50 = 250; 250 : 125 = 2.",hint:"Mashina chiqqanda ular orasida qancha masofa qolgan?",full:"1 soatda avtobus 50 km yurdi, qoldi 250 km. Yaqinlashish 50 + 75 = 125 km/soat: 250 : 125 = 2 soat. «3» — avtobusning jami vaqti."},
 tn:"Kechikishni rangli bo'r bilan alohida chizing — bolalar ikki bosqichni ko'rib turadi."},
{h:"Daryo oqimi",sum:"Oqim bo'yicha v + u = 21, qarshi v − u = 15. Sol oqim tezligida suzadi.",a:"m05",
 start:function(){startPh(Y2P5)},fin:function(){S.ph=3;Y2P5[3]()},
 html:"<p>Daryoda suv ham harakatlanadi — u katerni yo itaradi, yo to'sadi. Bosing:</p>",btns:[phaser(Y2P5)],
 after:"<p><b>Oqim bo'yicha</b>: v + u. <b>Oqimga qarshi</b>: v − u. <b>Sol, xas, yog'och</b> — motorsiz, ular faqat oqim tezligida suzadi. Ko'lda (turg'un suvda) — faqat o'z tezligi v.</p>",
 q:{t:"Daryo oqimi 2 km/soat. Sol 3 soatda qancha masofa suzadi?",opts:["6 km","0 km","2 km","5 km"],ok:0,why:"Sol oqim tezligida: 2 · 3 = 6.",hint:"Solning o'z motori yo'q. Uni nima harakatlantiradi?",full:"Sol oqim bilan birga suzadi: 2 km/soat. 3 soatda 2 · 3 = 6 km. «0» — solni turgan deb olish, «5» — 2 + 3."},
 tn:"Yo'lakda yurayotgan bola (oqim) ustida o'yinchoq mashina — tekis va teskari harakatni sinfda ko'rsating."},
{h:"Oqim tezligini topish",sum:"Bo'ylab 24, qarshi 16: farq 8 = ikki oqim → oqim 4, kater 20.",a:"m06",
 start:function(){y2find(0);calc(['Daryo oqimining tezligi qancha?'])},fin:function(){y2find(1);y4msg('Oqim <b>4</b> km/soat, kater <b>20</b> km/soat')},
 html:"<p>Kater oqim bo'yicha 24 km/soat, oqimga qarshi 16 km/soat tezlikda suzadi. Daryo oqimining tezligi qancha?</p>",
 btns:y4pick(1,[["8 km/soat","24 − 16 = 8 — bu ikki oqim farqi: bir tomonda +u, boshqasida −u."],["4 km/soat","Farq 8 = 2 ta oqim. Oqim: 8 : 2 = 4."],["20 km/soat","20 — katerning o'z tezligi: (24 + 16) : 2."],["40 km/soat","24 + 16 = 40 — bu ikki tezlik yig'indisi."]],function(){y2find(1)}),g2:1,
 after:"<p>Tasmalarda ko'rinadi: oqim bo'yicha tezlik oqimga qarshidan <b>ikki marta oqim</b>ga katta. Oqim = (bo'ylab − qarshi) : 2. Kater = (bo'ylab + qarshi) : 2.</p>",
 q:{t:"Kater oqim bo'yicha 2 soatda 44 km, oqimga qarshi 3 soatda 54 km suzdi. Oqim tezligi?",opts:["2 km/soat","4 km/soat","10 km/soat","20 km/soat"],ok:0,why:"Bo'ylab 22, qarshi 18; (22 − 18) : 2 = 2.",hint:"Avval ikkala tezlikni toping.",full:"Bo'ylab: 44 : 2 = 22 km/soat; qarshi: 54 : 3 = 18 km/soat. Oqim = (22 − 18) : 2 = 2. «4» — 2 ga bo'lishni unutish, «20» — katerning o'z tezligi."},
 tn:"Chizma: ikki tasma, ustma-ust. Farqni qavs bilan belgilab, «bu ikkita oqim» deb yozing."},
{h:"Tuzoq: o'rtacha tezlik",sum:"Borish 1 soat, qaytish 2 soat: 120 : 3 = 40 km/soat, 45 emas!",a:"m07",
 start:function(){y2avg(0);calc(['Butun yo‘ldagi o‘rtacha tezlik qancha?'])},fin:function(){y2avg(1);y4msg('O‘rtacha tezlik: <b>40</b> km/soat')},
 html:"<p>Mashina 60 km ni 60 km/soat bilan bordi, xuddi shu yo'ldan 30 km/soat bilan qaytdi. Butun yo'ldagi o'rtacha tezlik qancha?</p>",
 btns:y4pick(1,[["45 km/soat","(60 + 30) : 2 — tezliklarni o'rtachalash xato: sekin yurgan vaqt ko'proq."],["40 km/soat","Jami yo'l 120 km, jami vaqt 1 + 2 = 3 soat: 120 : 3 = 40."],["90 km/soat","90 — tezliklar yig'indisi."],["30 km/soat","30 — faqat qaytishdagi tezlik."]],function(){y2avg(1)}),g2:1,
 after:"<p><b>O'rtacha tezlik = jami yo'l : jami vaqt.</b> Tezliklarni qo'shib 2 ga bo'lish faqat ikkalasida bir xil <b>vaqt</b> yurilganda to'g'ri bo'ladi.</p>",
 q:{t:"Mashina 3 soat 60 km/soat bilan yurib shaharga bordi, qaytishda 90 km/soat bilan yurdi. Butun yo'ldagi o'rtacha tezlik?",opts:["72 km/soat","75 km/soat","150 km/soat","80 km/soat"],ok:0,why:"Yo'l 180 km, qaytish 2 soat; 360 : 5 = 72.",hint:"Jami yo'l va jami vaqtni toping.",full:"Borish: 60 · 3 = 180 km. Qaytish: 180 : 90 = 2 soat. Jami: 360 km, 5 soat. 360 : 5 = 72 km/soat. «75» — (60 + 90) : 2."},
 tn:"Bu tuzoqqa kattalar ham tushadi. Bolalar uydagilarga savol bersin va natijani sinfga aytsin."},
{h:"Aylana yo'lda quvlama",sum:"Bir joydan bir tomonga: tezi sekinini 1 aylana ortda qoldirganda yetadi: 400 : (5 − 3) = 200 s.",a:"m08",
 start:function(){y2track(0);calc(['Tezroq bola sekinini birinchi marta qachon quvib yetadi?'])},fin:function(){y2track(1);y4msg('<b>200</b> soniyada')},
 html:"<p>Stadion aylanasi 400 m. Ikki bola bir joydan bir tomonga yugurdi: 5 m/s va 3 m/s. Tezi sekinini necha soniyada birinchi marta quvib yetadi?</p>",
 btns:y4pick(0,[["200 s","Tezi 1 aylana (400 m) ko'p yugurishi kerak: 400 : (5 − 3) = 200."],["50 s","400 : (5 + 3) — bu qarama-qarshi tomonga yugurganda uchrashish."],["80 s","400 : 5 — tezi bir aylanani tugatadi, lekin sekini ham joyida turmaydi."],["133 s","400 : 3 — bu sekinining bir aylanasi."]],function(){y2track(1)}),g2:1,
 after:"<p>Aylanada «oradagi masofa» — <b>butun aylana</b>: tezi sekinini quvib yetishi uchun undan bir aylana ko'p yugurishi kerak. Bir tomonga — ayirma, qarama-qarshi tomonga — yig'indi.</p>",
 q:{t:"Aylana yo'l 600 m. Ikki bola bir joydan QARAMA-QARSHI tomonga yugurdi: 4 m/s va 2 m/s. Necha soniyada uchrashadi?",opts:["100 s","300 s","150 s","600 s"],ok:0,why:"600 : (4 + 2) = 100.",hint:"Qarama-qarshi tomonga — yaqinlashish tezligi qancha?",full:"Ular birga butun aylanani bosib o'tganda uchrashadi: 600 : (4 + 2) = 100 s. «300» — 600 : (4 − 2), bu bir tomonga yugurganda."},
 tn:"Maktab hovlisida aylana chizib, ikki bolani turli tezlikda yurgizing (bittasi 1 qadam, boshqasi 2 qadam)."},
{h:"Bilasizmi? Axilles va toshbaqa",sum:"Zenon (~2 500 yil oldin) «tez yuguruvchi toshbaqaga yetolmaydi» deb bahslashgan. Quvlama formulasi javob beradi.",a:"m09",
 start:function(){startPh(Y2P9)},fin:function(){S.ph=2;Y2P9[2]()},
 html:"<p>Qadimgi yunon faylasufi Zenonning mashhur jumbog'i. Bosing:</p>",btns:[phaser(Y2P9)],
 after:"<p>Zenon har safar masofa qisqarib, lekin «hech qachon tugamaydi» deb o'ylagan. Matematiklar ming yillar o'tib cheksiz kichrayuvchi bo'laklar yig'indisi <b>chekli</b> bo'lishini isbotladi. Biz esa oddiy hisob bilan bilamiz: oradagi masofa : tezliklar ayirmasi — yetib olish vaqti.</p>",
 tn:"Bolalar bilan bahs: Axilles yetib oladimi? Ular o'z dalilini aytsin, keyin quvlama formulasi bilan tekshiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>Bir-biriga qarab yoki qarama-qarshi tomonga: <b>v₁ + v₂</b>.</li><li>Bir yo'nalishda quvlash: <b>v₁ − v₂</b>; vaqt = ora : (v₁ − v₂).</li><li>Kechikish: avval birinchisi qancha oldinlagani (v · t), keyin oddiy masala.</li><li>Daryo: bo'ylab v + u, qarshi v − u; sol — u. Oqim = (bo'ylab − qarshi) : 2.</li><li>O'rtacha tezlik = jami yo'l : jami vaqt (tezliklarni o'rtachalamang!).</li><li>Aylanada bir tomonga: aylana : (v₁ − v₂).</li></ul></div>",
 tn:"Kartochkani daftarga yozdiring; har formulaga bitta chizma qo'shtiring."}
];
var PROBS=[
{t:"Ikki shahar orasi 240 km. Ikki mashina bir vaqtda bir-biriga qarab chiqdi: 70 va 50 km/soat. Necha soatda uchrashadi?",o:["2 soatda","3 soatda","12 soatda","20 soatda"],k:0,s:"240 : 120 = 2."},
{t:"Velosipedchi 15 km/soat. Undan 30 km oldinda piyoda 5 km/soat tezlikda o'sha tomonga ketyapti. Necha soatda quvib yetadi?",o:["3 soatda","2 soatda","6 soatda","1,5 soatda"],k:0,s:"30 : (15 − 5) = 3."},
{t:"Kater tezligi 20 km/soat, daryo oqimi 3 km/soat. Oqim bo'yicha 3 soatda qancha masofa suzadi?",o:["69 km","60 km","51 km","23 km"],k:0,s:"(20 + 3) · 3 = 69."},
{t:"Kater tezligi 15 km/soat, oqim 2 km/soat. Oqimga qarshi 52 km ni necha soatda suzadi?",o:["4 soatda","13 soatda","2 soatda","17 soatda"],k:0,s:"52 : (15 − 2) = 4."},
{t:"Sol daryoda 5 soatda 15 km suzdi. Daryo oqimining tezligi?",o:["3 km/soat","15 km/soat","75 km/soat","20 km/soat"],k:0,s:"15 : 5 = 3."},
{t:"Kater oqim bo'yicha 26 km/soat, oqimga qarshi 18 km/soat tezlikda suzadi. Daryo oqimining tezligi?",o:["4 km/soat","8 km/soat","22 km/soat","44 km/soat"],k:0,s:"(26 − 18) : 2 = 4."},
{t:"Kater oqim bo'yicha 26 km/soat, oqimga qarshi 18 km/soat tezlikda suzadi. Uning turg'un suvdagi tezligi?",o:["22 km/soat","26 km/soat","18 km/soat","8 km/soat"],k:0,s:"(26 + 18) : 2 = 22."},
{t:"Piyoda 4 km/soat bilan chiqdi. 3 soatdan keyin orqasidan velosipedchi 10 km/soat bilan chiqdi. Velosipedchi necha soatda yetib oladi?",o:["2 soatda","3 soatda","5 soatda","1,2 soatda"],k:0,s:"12 : 6 = 2."},
{t:"Piyoda 4 km/soat bilan chiqdi. 3 soatdan keyin orqasidan velosipedchi 10 km/soat bilan chiqdi. Boshlang'ich joydan qancha uzoqda uchrashadi?",o:["20 km","12 km","30 km","8 km"],k:0,s:"10 · 2 = 20."},
{t:"Shaharlar orasi 300 km. Avtobus 50 km/soat bilan chiqdi, 1 soatdan keyin qarshi tomondan mashina 75 km/soat bilan chiqdi. Mashina chiqqandan keyin necha soatda uchrashadi?",o:["2 soatda","3 soatda","2,4 soatda","5 soatda"],k:0,s:"250 : 125 = 2."},
{t:"Mashina 3 soat 60 km/soat bilan yurib shaharga bordi, qaytishda 90 km/soat bilan yurdi. Butun yo'ldagi o'rtacha tezlik?",o:["72 km/soat","75 km/soat","150 km/soat","80 km/soat"],k:0,s:"360 : 5 = 72."},
{t:"Aylana yo'l 600 m. Ikki bola bir joydan qarama-qarshi tomonga yugurdi: 4 m/s va 2 m/s. Necha soniyada uchrashadi?",o:["100 s","300 s","150 s","600 s"],k:0,s:"600 : 6 = 100."},
{t:"Aylana yo'l 600 m. Ikki bola bir joydan bir tomonga yugurdi: 4 m/s va 2 m/s. Tezi sekinini necha soniyada quvib yetadi?",o:["300 s","100 s","150 s","200 s"],k:0,s:"600 : 2 = 300."},
{t:"Ikki mashina bir joydan qarama-qarshi tomonlarga chiqdi: 55 va 65 km/soat. 3 soatdan keyin ular orasidagi masofa?",o:["360 km","30 km","120 km","195 km"],k:0,s:"120 · 3 = 360."},
{t:"Bir joydan bir yo'nalishda ikki mashina chiqdi: 80 va 65 km/soat. Necha soatdan keyin ular orasi 60 km bo'ladi?",o:["4 soatdan","15 soatdan","2 soatdan","6 soatdan"],k:0,s:"60 : 15 = 4."},
{t:"It quyondan 150 m orqada. It 18 m/s, quyon 13 m/s tezlikda yuguradi. It necha soniyada quyonni quvib yetadi?",o:["30 s","10 s","5 s","8 s"],k:0,s:"150 : 5 = 30."},
{t:"Kater oqim bo'yicha 2 soatda 44 km, oqimga qarshi 3 soatda 54 km suzdi. Oqim tezligi?",o:["2 km/soat","4 km/soat","20 km/soat","10 km/soat"],k:0,s:"(22 − 18) : 2 = 2."},
{t:"Uzunligi 100 m bo'lgan poyezd 300 m uzunlikdagi ko'prikdan 20 m/s tezlikda o'tdi. To'liq o'tishiga necha soniya ketdi?",o:["20 s","15 s","5 s","400 s"],k:0,s:"(300 + 100) : 20 = 20."},
{t:"A va B orasi 36 km. Ikki piyoda bir vaqtda bir-biriga qarab chiqdi: 5 va 4 km/soat. 2 soatdan keyin ular orasida qancha masofa qoladi?",o:["18 km","0 km","9 km","54 km"],k:0,s:"36 − 9 · 2 = 18."},
{t:"Toshbaqa 2 m/min, quyon 12 m/min. Quyon toshbaqadan 90 m orqada edi, lekin 10 minut uxladi, keyin yugurdi. Uyg'ongach necha minutda yetib oladi?",o:["11 minutda","9 minutda","10 minutda","21 minutda"],k:0,s:"Ora 90 + 20 = 110; 110 : 10 = 11."}
];
var PREP_DATA={teach:["Qarama-qarshi harakat: v₁ + v₂ (takror).","Quvlama: v₁ − v₂; kechikish bilan quvlama va uchrashish (ikki bosqich).","Daryo: v + u, v − u, sol = u; oqim va o'z tezlikni topish.","O'rtacha tezlik = jami yo'l : jami vaqt.","Aylana yo'lda quvlama va uchrashish."],
 mist:["Quvlamada tezliklarni qo'shadi.","Kechikish vaqtidagi oldinlikni hisobga olmaydi.","Oqim = bo'ylab − qarshi deb oladi (2 ga bo'lmaydi).","O'rtacha tezlikni (v₁ + v₂) : 2 deb hisoblaydi.","Poyezd masalasida poyezd uzunligini unutadi."],
 need:["Uzun qog'oz lenta (son o'qi), ikki o'yinchoq mashina.","Doskada jadval: vaqt | 1-chi | 2-chi | ora."],
 board:["Qarshi: <span class='w2'>t = S : (v₁ + v₂)</span>.","Quvlama: <span class='w2'>t = ora : (v₁ − v₂)</span>.","Daryo: v ± u; <span class='w2'>u = (bo'ylab − qarshi) : 2</span>.","<span class='w2'>v o'rt = jami yo'l : jami vaqt</span>."]};
