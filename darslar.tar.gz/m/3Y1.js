var CODE='3Y1',TITLE="3-sinf · Ko'p xonali sonlar bilan raqamli jumboqlar";
// ustun hisob: rows = [['','★','4','7'],['+','2','★','8'],['','7','3','5']], hl = {r:{c:color}}
function Y1col(rows,o){o=o||{};var g=S.g,w=34,x0=o.x||100,y0=o.y||42;rows.forEach(function(r,ri){r.forEach(function(d,ci){var x=x0+ci*w,y=y0+ri*40;var c=o.hl&&o.hl[ri]&&o.hl[ri][ci];
  if(c)E('rect',{x:x-15,y:y-26,width:30,height:34,rx:6,fill:c},g);T(g,x,y,String(d),{'font-size':24,'font-weight':800,fill:d==='★'?C.bad:'#1d2b3a'})})});
 E('line',{x1:x0-20,y1:y0+(rows.length-2)*40+14,x2:x0+(rows[0].length-1)*w+18,y2:y0+(rows.length-2)*40+14,stroke:C.line,'stroke-width':2.4},g);
 (o.carry||[]).forEach(function(cc){T(g,x0+cc*w,y0-26,'1',{'font-size':13,'font-weight':800,fill:C.blue})});
 if(o.note)(o.note).forEach(function(t,i){T(g,288,y0+i*28-8,t,{'font-size':11,'font-weight':700,fill:o.nc||C.blue})})}
var Y1Y='#fff4d6',Y1G='#d6f1e0';
var P1=[function(){clear();Y1col([['','★','4','7'],['+','2','★','8'],['','7','3','5']]);Y3msg('Yulduzchalar o‘rnida qaysi raqamlar? <b>Birlardan</b> boshlaymiz')},
 function(){clear();Y1col([['','★','4','7'],['+','2','★','8'],['','7','3','5']],{hl:{0:{3:Y1Y},1:{3:Y1Y},2:{3:Y1Y}},carry:[2],note:['7 + 8 = 15','5 yoziladi,','1 o‘tadi']});Y3msg('Birlar: 7 + 8 = 15 → 5, o‘nlarga <b>1</b> o‘tadi')},
 function(){clear();Y1col([['','★','4','7'],['+','2','8','8'],['','7','3','5']],{hl:{0:{2:Y1Y},1:{2:Y1G},2:{2:Y1Y}},carry:[1,2],note:['4 + ★ + 1 = 13','★ = 8','1 o‘tadi']});Y3msg('O‘nlar: 4 + ★ + 1 natijasi 3 bilan tugaydi → 13, ★ = <b>8</b>')},
 function(){clear();Y1col([['','4','4','7'],['+','2','8','8'],['','7','3','5']],{hl:{0:{1:Y1G},1:{1:Y1Y},2:{1:Y1Y}},carry:[1,2],note:['★ + 2 + 1 = 7','★ = 4','447 + 288 = 735 ✓'],nc:C.ok});Y3msg('Yuzlar: ★ + 2 + 1 = 7 → ★ = <b>4</b>. Tekshiruv: 447 + 288 = 735 ✓')}];
var P3=[function(){clear();Y3seq([2,4,6,8,9]);Y3msg('2, 4, 6, 8, 9 raqamlaridan (har biri bir marta) 5 xonali son tuzing')},
 function(){clear();Y3seq([9,8,6,4,2],{hi:{0:'#fde6c8',1:'#fde6c8',2:'#fde6c8',3:'#fde6c8',4:'#fde6c8'},lab:['eng katta','','','','eng kichik']});Y3msg('Eng katta: raqamlar <b>kamayish</b> tartibida — 98 642')},
 function(){clear();Y3seq([2,4,6,8,9],{hi:{0:'#d8efe9',1:'#d8efe9',2:'#d8efe9',3:'#d8efe9',4:'#d8efe9'}});Y3msg('Eng kichik: raqamlar <b>o‘sish</b> tartibida — 24 689')},
 function(){clear();Y3seq([3,0,5,7],{hi:{0:'#fbdada',1:'#fff4d6'},lab:['0 emas!','','','']});Y3msg('Tuzoq: 0, 3, 5, 7 dan eng kichigi 0357 emas (u 4 xonali emas) — <b>3057</b>')}];
var P5=[function(){clear();Y3seq(['?','?','?','?']);Y3msg('Raqamlari har xil eng katta va eng kichik 4 xonali sonlar ayirmasi?')},
 function(){clear();Y3seq([9,8,7,6],{hi:{0:'#fde6c8',1:'#fde6c8',2:'#fde6c8',3:'#fde6c8'}});Y3msg('Eng kattasi: <b>9876</b> (9999 emas — raqamlar har xil bo‘lishi kerak)')},
 function(){clear();Y3seq([1,0,2,3],{hi:{0:'#d8efe9',1:'#d8efe9',2:'#d8efe9',3:'#d8efe9'}});Y3msg('Eng kichigi: <b>1023</b> (boshida 1, keyin 0, 2, 3)')},
 function(){clear();Y1col([['',9,8,7,6],['−',1,0,2,3],['',8,8,5,3]],{x:110});Y3msg('9876 − 1023 = <b>8853</b>')}];
var P6=[function(){clear();Y3seq(['45','…','125']);Y3msg('45 dan 125 gacha sonlarni yozsak, nechta 0 raqami ishlatiladi?')},
 function(){clear();Y3seq(['50','60','70','80','90'],{hi:{0:Y1Y,1:Y1Y,2:Y1Y,3:Y1Y,4:Y1Y}});Y3msg('Ikki xonali: 50, 60, 70, 80, 90 — <b>5</b> ta nol')},
 function(){clear();Y3seq(['100','101','…','109'],{hi:{0:'#fbdada'},lab:['2 ta nol!','','','']});Y3msg('100 da — <b>2</b> ta, 101 … 109 da — <b>9</b> ta')},
 function(){clear();Y3seq(['110','120'],{hi:{0:Y1Y,1:Y1Y}});Y3msg('110, 120 — 2 ta. Jami: 5 + 2 + 9 + 2 = <b>18</b>')}];
function Y1pg(fin){clear();var g=S.g;Y1B2(fin);Y3msg(fin?'39 − 9 = 30 raqam → 30 : 2 = 15 ta ikki xonali bet → 9 + 15 = <b>24</b> bet':'Kitob betlarini raqamlashga <b>39 ta</b> raqam ketdi. Kitobda nechta bet?')}
function Y1B2(fin){var g=S.g;E('rect',{x:20,y:30,width:150,height:56,rx:8,fill:'#fde6c8',stroke:C.line},g);T(g,95,52,'1 … 9 bet',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,95,74,'9 · 1 = 9 raqam',{'font-size':12,fill:'#1d2b3a'});
 E('rect',{x:190,y:30,width:150,height:56,rx:8,fill:'#d8efe9',stroke:C.line},g);T(g,265,52,fin?'10 … 24 bet':'10, 11, … bet',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,265,74,fin?'15 · 2 = 30 raqam':'har biri 2 raqam',{'font-size':12,fill:'#1d2b3a'});
 if(fin)T(g,180,124,'9 + 30 = 39 ✓',{'font-size':16,'font-weight':800,fill:C.ok})}
function Y1sw(n){clear();var g=S.g,a=Math.floor(n/10),b=n%10,r=b*10+a;Y3seq([n,'→',r],{});T(g,180,140,r+' − '+n+' = '+(r-n),{'font-size':16,'font-weight':800,fill:r-n===27?C.ok:C.bad});Y3msg(r-n===27?'<b>47</b>: 4 + 7 = 11, 74 − 47 = 27 ✓':'Raqamlar yig‘indisi 11, lekin farq 27 emas')}
var Y1K=[3524,3087,8352,6174];
function Y1kap(i){clear();var g=S.g,n=Y1K[i];var ds=String(n).padStart(4,'0').split('');var hi=ds.slice().sort().reverse().join(''),lo=ds.slice().sort().join('');
 Y3seq(Y1K.slice(0,i+1),{hi:{[i]:i===3?Y1G:Y1Y},y:24});if(i<3)T(g,180,120,hi+' − '+lo+' = '+Y1K[i+1],{'font-size':15,'font-weight':800,fill:C.blue});else T(g,180,120,'7641 − 1467 = 6174 — to‘xtadi!',{'font-size':15,'font-weight':800,fill:C.ok});
 Y3msg(i<3?'Raqamlardan eng katta va eng kichik son tuzib, ayiring':'<b>6174</b> — Kaprekar soni')}
var STEPS=[
{h:"Yulduzchali qo'shish",sum:"★47 + 2★8 = 735: birlardan boshlab, o'tkazishni hisobga olib: 447 + 288 = 735.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Ba'zi raqamlar yulduzcha bilan yopilgan. Ularni topamiz. Qoida: <b>birlardan</b> boshlang va <b>o'tkazishni</b> unutmang.</p>",btns:[phaser(P1)],
 after:"<p>Har xonada bitta noma'lum — uni o'tkazishni qo'shib topamiz. Oxirida albatta <b>tekshiring</b>: 447 + 288 = 735 ✓.</p>",
 q:{t:"5★3 + ★78 = 921. Yulduzchalar o'rnida qaysi raqamlar? (birinchi qo'shiluvchida, ikkinchisida)",opts:["3 va 4","4 va 3","4 va 4","5 va 3"],ok:1,why:"543 + 378 = 921 ✓.",hint:"Birlar: 3 + 8 = 11 — o'nlarga 1 o'tadi. O'nlar: ★ + 7 + 1 natijasi 2 bilan tugaydi.",full:"Birlar: 3 + 8 = 11 → 1, bir o'tadi. O'nlar: ★ + 7 + 1 = 12 → ★ = 4, bir o'tadi. Yuzlar: 5 + ★ + 1 = 9 → ★ = 3. 543 + 378 = 921 ✓. «3 va 4» — tartib almashgan: 533 + 478 = 1011."},
 tn:"Doskada ustunni katta yozing; har xonani hal qilganda yulduzchani rangli bo'r bilan raqamga almashtiring."},
{h:"Yulduzchali ayirish",sum:"8★2 − ★57 = 465: birlarda qarz olinadi, o'nlarda ham. 822 − 357 = 465.",a:"m02",start:function(){clear();Y1col([['','8','★','2'],['−','★','5','7'],['','4','6','5']]);Y3msg('Ayirishda <b>qarz olish</b>ni kuzating')},
 fin:function(){clear();Y1col([['','8','2','2'],['−','3','5','7'],['','4','6','5']],{note:['12 − 7 = 5','12 − 1 − 5 = 6','8 − 1 − 3 = 4'],nc:C.ok});Y3msg('822 − 357 = 465 ✓')},
 html:"<p>8★2 − ★57 = 465. Yulduzchalar o'rnida qaysi raqamlar? Birlardan boshlab o'ylang va javobni tanlang.</p>",
 btns:Y3ch(["832 − 367","822 − 357","812 − 347","822 − 457"],1,function(){STEPS[1].fin()},'Birlarda 2 − 7 — qarz olish kerak. O‘nlarda ham qarzni unutmang'),g2:1,
 after:"<p>Birlar: 12 − 7 = 5 (o'nlardan qarz). O'nlar: ★ − 1 − 5 = 6 bo'lishi uchun yana qarz kerak: ★ + 10 − 1 − 5 = 6 → ★ = <b>2</b>. Yuzlar: 8 − 1 − ★ = 4 → ★ = <b>3</b>.</p>",
 q:{t:"6★1 − ★47 = 284. Kamayuvchi qaysi?",opts:["641","631","621","731"],ok:1,why:"631 − 347 = 284 ✓.",hint:"Birlar: 11 − 7 = 4 (qarz). O'nlarda ham qarz kerak bo'ladimi?",full:"Birlar: 11 − 7 = 4, o'nlardan qarz. O'nlar: ★ − 1 − 4 = 8 bo'lishi uchun yana qarz: ★ + 10 − 1 − 4 = 8 → ★ = 3. Yuzlar: 6 − 1 − ★ = 2 → ★ = 3. 631 − 347 = 284 ✓. «641» — o'nlardagi qarz unutilgan."},
 tn:"Ayirishni qo'shish bilan tekshirish: 465 + 357 = 822 — bola bu usulni har doim qo'llasin."},
{h:"Raqamlardan son tuzish",sum:"Eng katta — raqamlar kamayish tartibida, eng kichik — o'sish tartibida; 0 boshda turmaydi.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Berilgan raqamlardan eng katta va eng kichik sonni qanday tuzamiz? Bosqichlarni ko'ring.</p>",btns:[phaser(P3)],
 after:"<p>Eng katta xonaga (chapga) — eng katta raqam. Eng kichik son uchun — eng kichik raqam, lekin <b>0 bo'lmagan</b>! 0, 3, 5, 7 → <b>3057</b>.</p>",
 q:{t:"0, 1, 4, 6, 8 raqamlaridan (har biri bir marta) eng kichik besh xonali son qaysi?",opts:["01468","10468","14068","10486"],ok:1,why:"1 boshda, keyin 0 va qolganlari o'sish tartibida: 10468.",hint:"0 birinchi o'rinda tura oladimi?",full:"01468 — aslida 4 xonali son. Birinchi o'ringa noldan keyingi eng kichik raqam — 1, so'ng 0, 4, 6, 8: 10468. «10486» — oxirgi ikki raqam tartibi buzilgan."},
 tn:"Raqam kartochkalarini bolalarga berib, sonni stol ustida tuzdiring."},
{h:"Raqamlar yig'indisi",sum:"Raqamlar yig'indisi 20 bo'lgan eng kichik son: iloji boricha kam xona va oxirida 9 lar → 299.",a:"m04",start:function(){clear();Y3seq(['?','?','?']);Y3msg('Raqamlari yig‘indisi 20 bo‘lgan eng kichik son?')},fin:function(){clear();Y3seq([2,9,9],{hi:{1:Y1G,2:Y1G}});Y3msg('2 + 9 + 9 = 20 → <b>299</b>')},
 html:"<p>Raqamlarining yig'indisi <b>20</b> ga teng bo'lgan eng kichik natural son qaysi?</p>",
 btns:Y3ch(["1199","299","389","992"],1,function(){STEPS[3].fin()},'Xonalar soni kam bo‘lsin, oxirgi raqamlar esa iloji boricha katta (9)'),g2:1,
 after:"<p>Ikki xonali sonda raqamlar yig'indisi ko'pi bilan 9 + 9 = 18 — yetmaydi. Uch xonali: birinchi raqam eng kichik bo'lishi uchun qolganlari 9 bo'lsin: 20 − 18 = 2 → <b>299</b>.</p>",
 q:{t:"Raqamlari yig'indisi 25 bo'lgan eng kichik uch xonali son qaysi?",opts:["997","799","889","898"],ok:1,why:"25 − 9 − 9 = 7 → 799.",hint:"Oxirgi ikki raqamni 9 qiling.",full:"Birinchi raqam iloji boricha kichik bo'lishi uchun qolgan ikkitasi 9: 25 − 18 = 7 → 799. 889, 898, 997 — barchasi 799 dan katta."},
 tn:"«Eng kichik» — chap tomon kichik, o'ng tomon katta; «eng katta» — teskarisi. Bolalar o'zi qoidani aytsin."},
{h:"Raqamlari har xil",sum:"Raqamlari har xil eng katta 4 xonali — 9876, eng kichigi — 1023. Ayirma 8853.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Raqamlari <b>har xil</b> bo'lgan eng katta va eng kichik to'rt xonali sonlarni topib, ayirmasini hisoblaymiz.</p>",btns:[phaser(P5)],
 after:"<p>Tuzoqlar: 9999 va 1000 — raqamlari takrorlangan. 1234 — eng kichik emas, chunki 0 ni ham ishlatsa bo'ladi (ikkinchi o'rinda). Javob: 9876 − 1023 = <b>8853</b>.</p>",
 q:{t:"Raqamlari har xil eng kichik uch xonali juft son qaysi?",opts:["100","102","120","123"],ok:1,why:"1, 0 va eng kichik juft raqam (0 band) — 2: 102.",hint:"Raqamlar takrorlanmasin va son juft bo'lsin.",full:"100 — nollar takrorlangan. 101 — toq. 102 — raqamlari har xil va juft ✓. 120, 123 — kattaroq (123 toq ham)."},
 tn:"Bolalar sonni tuzib, raqamlarini ustidan chizib tekshirsin: takror bormi?"},
{h:"Raqamlarni sanash",sum:"45 dan 125 gacha nollar: 5 + 2 (100) + 9 + 2 = 18. 100 dagi ikki nolni unutmang.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>45 dan 125 gacha barcha sonlarni yozsak, <b>0</b> raqami necha marta yoziladi? Guruhlab sanaymiz.</p>",btns:[phaser(P6)],
 after:"<p>Guruhlar: 50–90 (5 ta), 100 (2 ta!), 101–109 (9 ta), 110 va 120 (2 ta). Jami <b>18</b>. Eng ko'p uchraydigan xato — 100 dagi nollarni bitta deb sanash (17).</p>",
 q:{t:"1 dan 100 gacha sonlarni yozishda 7 raqami necha marta yoziladi?",opts:["10","20","19","11"],ok:1,why:"Birlar xonasida 10 marta, o'nlar xonasida 10 marta: 20.",hint:"Birlar xonasidagi 7 lar va o'nlar xonasidagi 7 larni alohida sanang.",full:"Birlarda: 7, 17, …, 97 — 10 ta. O'nlarda: 70 … 79 — 10 ta. 77 da ikkala xonada 7 bor — ikki raqam, ikki marta sanaladi. Jami 20. «19» — 77 bitta deb olingan."},
 tn:"Yuzlik jadvalda (1–100) rangli qalam bilan 7 larni bo'yash — bola o'z ko'zi bilan ko'radi."},
{h:"Kitob sahifalari",sum:"39 ta raqam: 1–9 betlar 9 raqam, qolgan 30 raqam → 15 ta ikki xonali bet → jami 24 bet.",a:"m07",start:function(){Y1pg(0)},fin:function(){Y1pg(1)},
 html:"<p>Kitob betlarini 1 dan boshlab raqamlashga <b>39 ta</b> raqam ishlatildi. Kitobda nechta bet bor?</p>",
 btns:Y3ch(["39","24","20","30"],1,function(){Y1pg(1)},'Bir xonali va ikki xonali betlarni alohida hisoblang'),g2:1,
 after:"<p>1–9 betlar: 9 raqam. Qolgan 39 − 9 = 30 raqam ikki xonali betlarga: 30 : 2 = 15 bet (10 dan 24 gacha). Jami <b>24</b> bet. Teskari tekshiruv: 9 + 15 · 2 = 39 ✓.</p>",
 q:{t:"1 dan 25 gacha sahifalarni raqamlash uchun nechta raqam kerak?",opts:["25","41","50","40"],ok:1,why:"9 · 1 + 16 · 2 = 41.",hint:"10 dan 25 gacha nechta bet bor?",full:"1–9: 9 raqam. 10–25: 16 bet × 2 = 32 raqam. Jami 41. «40» — 10 dan 25 gacha 15 bet deb sanalgan."},
 tn:"Haqiqiy kitobning birinchi 12 betini ochib, raqamlarni sanatish — masala hayotiy bo'ladi."},
{h:"Olimpiada: raqamlar o'rni",sum:"ab + 27 = ba va a + b = 11: 9·(b − a) = 27 → b − a = 3 → 47.",a:"m08",start:function(){S.d={};clear();Y3seq(['?','?']);Y3msg('Raqamlari yig‘indisi 11. O‘rnini almashtirsak, son 27 ga ortadi')},fin:function(){Y1sw(47)},
 html:"<p>Ikki xonali sonning raqamlari yig'indisi <b>11</b>. Raqamlar o'rnini almashtirsak, son <b>27 ga ortadi</b>. Bu qaysi son? Nomzodlarni sinab ko'ring:</p>",
 btns:[29,38,47,56].map(function(n){return [String(n),function(c,done){Y1sw(n);if(n===47)done()}]}),g2:1,
 after:"<p>Raqamlarni almashtirganda farq doim <b>9 · (raqamlar farqi)</b> bo'ladi: 74 − 47 = 27 = 9 · 3. Demak raqamlar farqi 3, yig'indisi 11 → 4 va 7 → <b>47</b>.</p>",
 q:{t:"Ikki xonali son raqamlari teskari yozilgan sondan 63 ga katta (teskarisi ham ikki xonali). Shunday sonlar nechta?",opts:["1","2","3","7"],ok:1,why:"9 · (a − b) = 63 → a − b = 7: 81 va 92.",hint:"Farq 63 = 9 · ? Raqamlar farqi nechaga teng?",full:"ab − ba = 9 · (a − b) = 63 → a − b = 7. b ≠ 0 (teskarisi ikki xonali): 81 (81 − 18 = 63) va 92 (92 − 29 = 63). 70 ham a − b = 7, lekin 07 ikki xonali emas. Javob: 2 ta."},
 tn:"Bolalar 3–4 ta son uchun ab − ba ni hisoblab, natijalar doim 9 ga bo'linishini o'zlari kashf etsin."},
{h:"Bilasizmi? Kaprekar soni",sum:"Hindistonlik matematik D. R. Kaprekar 6174 sonini topgan: to'rt xonali sondan «katta − kichik» amali 6174 ga olib keladi.",a:"m09",start:function(){S.i=0;Y1kap(0)},fin:function(){Y1kap(3)},
 html:"<p>🔢 Hindistonlik matematik <b>D. R. Kaprekar</b> (1949-yil) ajoyib qonuniyatni topgan. Raqamlari bir xil bo'lmagan istalgan to'rt xonali son oling. Raqamlardan eng katta va eng kichik son tuzib, ayiring. Natija bilan yana shunday qiling… Ko'p o'tmay <b>6174</b> ga kelasiz va u yerda to'xtaysiz!</p>",
 btns:[["▶ Keyingi qadam",function(c,done){if(S.i<3){S.i++;Y1kap(S.i)}if(S.i>=3)done()}]],
 after:"<p>3524 → 3087 → 8352 → 6174. 6174 dan: 7641 − 1467 = 6174 — o'zi qaytadi. Ko'pi bilan 7 qadamda har qanday shunday son 6174 ga yetib keladi.</p>",
 tn:"Har o'quvchi o'z sonini tanlab, Kaprekar zanjirini daftarda hisoblasin — kim kamroq qadamda yetadi?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P1[3]()},fin:function(){P1[3]()},
 html:"<div class='memo'><ul><li>Yulduzchali misollarda <b>birlardan</b> boshlang, o'tkazish va qarzni hisobga oling, oxirida tekshiring.</li><li>Eng katta son — raqamlar kamayish tartibida; eng kichik — o'sish tartibida, lekin <b>0 boshda emas</b>.</li><li>Yig'indi berilgan eng kichik son: xonalar kam, oxirida 9 lar.</li><li>Raqamlarni sanashda guruhlang; 100 da <b>ikkita</b> nol.</li><li>ab va ba ayirmasi = 9 · (raqamlar farqi).</li></ul></div>",
 tn:"Uyga: o'zingiz yulduzchali misol tuzing va javobi yagona ekanini tekshiring."}
];
var PROBS=[
{t:"3★5 + 214 = 579. Yulduzcha o'rnida qaysi raqam?",o:["6","7","5","8"],k:0,s:"O'nlar: ★ + 1 = 7 → 6."},
{t:"Raqamlari har xil eng katta uch xonali son qaysi?",o:["987","999","998","989"],k:0,s:"9, 8, 7 — kamayish tartibida."},
{t:"Raqamlari har xil eng kichik to'rt xonali son qaysi?",o:["1023","1000","1234","1012"],k:0,s:"1, 0, 2, 3."},
{t:"1, 3, 5, 7, 9 raqamlaridan (har biri bir marta) eng katta besh xonali son qaysi?",o:["97531","13579","95731","97513"],k:0,s:"Kamayish tartibida."},
{t:"0, 2, 5, 8 raqamlaridan (har biri bir marta) eng kichik to'rt xonali son qaysi?",o:["2058","2085","2508","2005"],k:0,s:"Boshda 2, keyin 0, 5, 8."},
{t:"100 dan 999 gacha raqamlari bir xil bo'lgan sonlar nechta?",o:["9","10","27","90"],k:0,s:"111, 222, …, 999."},
{t:"Raqamlari yig'indisi 20 bo'lgan eng kichik natural son qaysi?",o:["299","389","992","1199"],k:0,s:"Ikki xonali yetmaydi (≤ 18): 2 + 9 + 9."},
{t:"Raqamlari yig'indisi 25 bo'lgan eng kichik uch xonali son qaysi?",o:["799","997","889","898"],k:0,s:"25 − 18 = 7 → 799."},
{t:"★47 + 2★8 = 735. Birinchi qo'shiluvchi qaysi?",o:["447","457","437","547"],k:0,s:"7+8 = 15; 4+★+1 = 13 → ★ = 8; ★+2+1 = 7 → ★ = 4."},
{t:"8★2 − ★57 = 465. Kamayuvchi qaysi?",o:["822","832","812","922"],k:0,s:"822 − 357 = 465."},
{t:"1 dan 25 gacha sahifalarni raqamlash uchun nechta raqam kerak?",o:["41","25","50","40"],k:0,s:"9 + 16 · 2 = 41."},
{t:"1 dan 100 gacha sonlarni yozishda 7 raqami necha marta yoziladi?",o:["20","19","11","10"],k:0,s:"Birlarda 10, o'nlarda 10."},
{t:"Raqamlari har xil eng katta va eng kichik to'rt xonali sonlar ayirmasi nechaga teng?",o:["8853","8999","8876","8642"],k:0,s:"9876 − 1023 = 8853."},
{t:"Kitob betlarini 1 dan raqamlashga 39 ta raqam ketdi. Kitobda nechta bet?",o:["24","39","20","30"],k:0,s:"9 + 15 · 2 = 39 → 9 + 15 = 24."},
{t:"45 dan 125 gacha sonlarni yozishda 0 raqami necha marta yoziladi?",o:["18","17","9","16"],k:0,s:"5 + 2 + 9 + 2 = 18."},
{t:"Ikki xonali sonning raqamlari yig'indisi 11. Raqamlar o'rni almashtirilsa, son 27 ga ortadi. Bu qaysi son?",o:["47","74","38","56"],k:0,s:"74 − 47 = 27 va 4 + 7 = 11."},
{t:"Ikki xonali son (raqamlari 0 emas) bilan uning raqamlari teskari yozilgan son yig'indisi 121. Shunday sonlarning eng kattasi qaysi?",o:["92","83","74","99"],k:0,s:"11 · (a + b) = 121 → a + b = 11: 92 + 29 = 121."},
{t:"Uch xonali sonning raqamlari ko'paytmasi 24, yig'indisi 9. Shunday sonlarning eng kattasi qaysi?",o:["432","234","423","342"],k:0,s:"Faqat 2, 3, 4 mos keladi; eng kattasi 432."},
{t:"Ikki xonali son raqamlari teskari yozilgan sondan 63 ga katta (teskarisi ham ikki xonali). Shunday sonlar nechta?",o:["2","3","1","7"],k:0,s:"a − b = 7: 81 va 92."},
{t:"3524 sonidan Kaprekar amali (eng katta − eng kichik) bilan necha qadamda 6174 ga kelinadi?",o:["3","4","2","7"],k:0,s:"3087 → 8352 → 6174."}
];
function PRACT_STAGE(){P1[3]()}
var PREP_DATA={teach:["Yulduzchali qo'shish va ayirish (o'tkazish va qarz).","Raqamlardan eng katta/eng kichik son tuzish, 0 ning o'rni.","Raqamlar yig'indisi; raqamlari har xil sonlar.","Raqamlarni sanash, sahifa masalalari.","Raqamlar o'rnini almashtirish: 9 · farq. Kaprekar soni."],
 mist:["O'tkazilgan birlikni unutadi.","0 ni birinchi o'ringa qo'yadi.","100 dagi ikki nolni bitta sanaydi.","Sahifa masalasida hamma betni bir xonali deb hisoblaydi (39 bet)."],
 need:["Raqam kartochkalari 0–9.","Yuzlik jadval.","Kitob (sahifa raqamlari uchun)."],
 board:["<span class='w2'>★47 + 2★8 = 735</span> → 447 + 288.","Eng kichik: <span class='w2'>0,3,5,7 → 3057</span>.","<span class='w2'>9876 − 1023 = 8853</span>.","<span class='w2'>ab − ba = 9 · (a − b)</span>."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
