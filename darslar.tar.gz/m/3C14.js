var CODE='3C14',TITLE='3-sinf · Yig‘indini songa bo‘lish';
function c14Apples(st){clear();var g=S.g;E('rect',{x:10,y:16,width:200,height:66,rx:10,fill:'#fdf0dc',stroke:'#efd9b5'},g);E('rect',{x:220,y:16,width:130,height:66,rx:10,fill:'#e3f5f3',stroke:'#bfe6e1'},g);
 T(g,110,32,'1-savat: 60 ta olma',{'font-size':11,'font-weight':800,fill:C.t1});T(g,285,32,'2-savat: 12 ta',{'font-size':11,'font-weight':800,fill:C.u});
 for(var i=0;i<6;i++){E('rect',{x:22+i*31,y:42,width:26,height:30,rx:5,fill:'#f2b766',stroke:C.t1},g);T(g,35+i*31,62,'10',{'font-size':11,'font-weight':800})}
 for(var j=0;j<12;j++)E('circle',{cx:236+(j%6)*19,cy:50+Math.floor(j/6)*18,r:7,fill:'#e05555',stroke:'#a33'},g);
 for(var k=0;k<6;k++){var x=20+k*56;E('rect',{x:x,y:100,width:50,height:62,rx:8,fill:st?'#e6f6ee':'#fff',stroke:st?C.ok:'#c9d3dd','stroke-width':1.5},g);T(g,x+25,116,(k+1)+'-bola',{'font-size':10,fill:'#5b6b7b'});if(st)T(g,x+25,146,st===1?'12':'10+2',{'font-size':15,'font-weight':800,fill:C.ok})}}
var P3=[function(){w3Expr(['84 : 7 = ?']);w3Msg('84 ni 7 ga bo‘linadigan ikki bo‘lakka ajratamiz')},
 function(){w3Expr(['84 = {70} + {14}','70 : 7 = 10','14 : 7 = 2']);w3Msg('70 va 14 — ikkalasi ham 7 ga bo‘linadi')},
 function(){w3Expr(['84 : 7 = 10 + 2','= {12}']);w3Msg('Tekshiramiz: 12 · 7 = 84 ✓')}];
var P5=[function(){w3Expr(['642 : 3 = ?']);w3Msg('Uch xonali son — xonalar bo‘yicha ajratamiz')},
 function(){w3Expr(['642 = {600} + {42}','600 : 3 = 200','42 : 3 = 14']);w3Msg('40 ni 3 ga bo‘lib bo‘lmaydi — shuning uchun 40 va 2 ni birga olamiz: 42')},
 function(){w3Expr(['642 : 3 = 200 + 14','= {214}']);w3Msg('Tekshiramiz: 214 · 3 = 642 ✓')}];
var P8=[function(){w3Expr(['568 : 4 + 568 : 8']);w3Msg('Bankdan: ikki bo‘lishni alohida bajaramiz')},
 function(){w3Expr(['568 : 4 = 500:4 + 68:4','= 125 + 17 = {142}']);w3Msg('568 = 500 + 68 — 4 ga qulay bo‘laklar')},
 function(){w3Expr(['568 : 8 = 560:8 + 8:8','= 70 + 1 = {71}']);w3Msg('568 = 560 + 8 — 8 ga qulay bo‘laklar')},
 function(){w3Expr(['142 + 71 = {213}']);w3Msg('Javob: <b>213</b>. Har bo‘luvchi uchun o‘ziga qulay bo‘laklar tanlandi!')}];
var STEPS=[
{h:"Ikki savat olmani bo'lishamiz",sum:"(60 + 12) : 6 = 72 : 6 = 12 yoki 60 : 6 + 12 : 6 = 10 + 2 = 12 — natija bir xil.",a:"m01",
 start:function(){S.w14={};c14Apples(0);w3Msg('Olmalarni 6 bolaga teng bo‘ling — ikki xil usulni sinab ko‘ring')},fin:function(){c14Apples(2);w3Msg('Ikkala usulda ham har bolaga 12 tadan')},
 html:"<p>Ikkita savatda olma bor: birida 60 ta, ikkinchisida 12 ta. Ularni 6 bolaga teng bo'lamiz. Ikki xil usulni sinab ko'ring:</p>",
 btns:[["Avval qo'shib, keyin bo'lamiz",function(c,done){S.w14.a=1;c14Apples(1);w3Msg('(60 + 12) : 6 = 72 : 6 = <b>12</b>');if(S.w14.b)done()}],["Har savatni alohida bo'lamiz",function(c,done){S.w14.b=1;c14Apples(2);w3Msg('60 : 6 + 12 : 6 = 10 + 2 = <b>12</b>');if(S.w14.a)done()},'u']],g2:1,
 after:"<p>Natija bir xil — <b>12</b>! Demak yig'indini songa bo'lish uchun har bir qo'shiluvchini alohida bo'lib, natijalarni qo'shish mumkin:</p><div class='life'><div>📐<span><b>(a + b) : c = a : c + b : c</b> (agar a va b ikkalasi ham c ga bo'linsa)</span></div></div>",
 q:{t:"(40 + 16) : 8 ni qulay usulda hisoblang.",opts:["7","5","56","9"],ok:0,why:"40 : 8 + 16 : 8 = 5 + 2 = 7.",hint:"Har qo'shiluvchini alohida 8 ga bo'ling va qo'shing.",full:"40 : 8 = 5, 16 : 8 = 2. Yig'indi: 7. Tekshirish: 56 : 8 = 7 ✓. «5» — faqat birinchi qo'shiluvchi bo'lingan."},
 tn:"Bolalarga 72 ta cho'pni (6 ta o'nlik bog'lami + 12 dona) 6 guruhga bo'ldiring: bog'lamlar alohida, donalar alohida."},
{h:"Qoida: har bir qo'shiluvchini bo'lamiz",sum:"(a + b) : c = a : c + b : c. Ikkala qo'shiluvchini ham bo'lish shart.",a:"m02",
 start:function(){w3Expr(['(48 + 24) : 6']);w3Msg('Qaysi yozuv to‘g‘ri?')},fin:function(){w3Expr(['(48 + 24) : 6','= 48 : 6 + 24 : 6','= 8 + 4 = {12}']);w3Msg('Ikkala qo‘shiluvchi ham bo‘lindi')},
 html:"<p>(48 + 24) : 6 ni qanday yozish to'g'ri? Tugmalarni bosib, natijalarni solishtiring:</p>",
 btns:[["48 : 6 + 24 : 6",function(c,done){w3Expr(['48 : 6 + 24 : 6','= 8 + 4 = {12}','tekshiruv: 72 : 6 = {12} ✓']);w3Msg('To‘g‘ri: ikkala qo‘shiluvchi bo‘lindi');mvK(done,2)}],["48 : 6 + 24",function(c,done){w3Expr(['48 : 6 + 24','= 8 + 24 = [32]','lekin 72 : 6 = 12']);w3Msg('Xato: 24 bo‘linmay qoldi');mvK(done,2)}]],g2:1,
 after:"<p>Eng ko'p xato: faqat <b>birinchi</b> qo'shiluvchini bo'lib, ikkinchisini unutish. Qoida: qavs ichidagi <b>har bir</b> qo'shiluvchi bo'linadi.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["(36 + 9) : 9 = 36 : 9 + 9 : 9","(36 + 9) : 9 = 36 : 9 + 9","(36 + 9) : 9 = 36 + 9 : 9","(36 + 9) : 9 = 36 : 9 · 9"],ok:0,why:"Ikkala qo'shiluvchi 9 ga bo'linadi: 4 + 1 = 5 = 45 : 9.",hint:"Qavs ichidagi ikkala son ham 9 ga bo'linishi kerak.",full:"45 : 9 = 5. Birinchi yozuv: 4 + 1 = 5 ✓. Ikkinchisi: 4 + 9 = 13, uchinchisi: 36 + 1 = 37 — xato."},
 tn:"Ikki ustunli doska: «to'g'ri yozuv» va «xato yozuv». Bolalar misollarni ustunlarga ajratsin."},
{h:"Sonni qulay bo'laklarga ajratamiz",sum:"84 : 7 = (70 + 14) : 7 = 10 + 2 = 12. Bo'laklar bo'luvchiga bo'linadigan qilib tanlanadi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Qoidani teskari ishlatamiz: <b>bitta sonni</b> o'zimiz ikkita qulay bo'lakka ajratamiz. 84 : 7 ni og'zaki hisoblaymiz.</p>",btns:[phaser(P3)],
 after:"<p>Kalit: bo'laklarni shunday tanlaymizki, <b>ikkalasi ham</b> bo'luvchiga bo'linsin. Ko'pincha birinchi bo'lak — bo'luvchining «yaxlit» karralisi (70, 140, 210 …).</p>",
 q:{t:"91 : 7 ni qaysi bo'laklar orqali hisoblash qulay?",opts:["70 + 21","90 + 1","80 + 11","50 + 41"],ok:0,why:"70 : 7 = 10, 21 : 7 = 3 → 13.",hint:"Ikkala bo'lak ham 7 ga bo'linishi kerak.",full:"70 va 21 — ikkalasi 7 ga bo'linadi: 10 + 3 = 13. 90, 80, 50 — 7 ga bo'linmaydi."},
 tn:"Bu — og'zaki hisoblashning asosiy usuli. Har kuni 2–3 daqiqa «qulay bo'lak top» o'yinini o'ynang."},
{h:"Bo'laklarni o'zingiz tanlang",sum:"96 : 4: 80 + 16 qulay (20 + 4 = 24); 90 + 6 — 90 ham, 6 ham 4 ga bo'linmaydi.",a:"m04",
 start:function(){w3Expr(['96 : 4 = ?']);w3Msg('96 ni qanday ajratamiz?')},fin:function(){w3Expr(['96 = {80} + {16}','80 : 4 + 16 : 4 = 20 + 4 = {24}']);w3Msg('96 : 4 = 24')},
 html:"<p>96 : 4. Sonni qaysi bo'laklarga ajratish qulay? Tanlang:</p><div class='digs w3c'></div>",
 act:function(c,done){w3Btns(c,'.w3c',['90 + 6','80 + 16','50 + 46'],function(v,b){if(v==='80 + 16'){b.className='dg wide yes';w3Expr(['96 = {80} + {16}','80 : 4 + 16 : 4 = 20 + 4 = {24}']);w3Msg('Ikkala bo‘lak ham 4 ga bo‘linadi!');done()}else{b.className='dg wide no';setTimeout(function(){b.className='dg wide'},1200);w3Msg(v==='90 + 6'?'90 : 4 — butun chiqmaydi, 6 : 4 ham':'50 ham, 46 ham 4 ga bo‘linmaydi')}})},
 after:"<p>Bir nechta to'g'ri yo'l bo'lishi mumkin: 96 = 40 + 56 ham ishlaydi (10 + 14 = 24). Eng qulayi — bo'luvchining eng katta yaxlit karralisini olish (80).</p>",
 q:{t:"78 : 6 = ?",opts:["13","12","14","18"],ok:0,why:"60 : 6 + 18 : 6 = 10 + 3 = 13.",hint:"78 = 60 + ?",full:"78 = 60 + 18. 60 : 6 = 10, 18 : 6 = 3. Javob: 13. Tekshiruv: 13 · 6 = 78 ✓."},
 tn:"Bolalar o'z ajratish usulini taxtada ko'rsatsin — har xil to'g'ri usullar bo'lishini qadrlang (Yaponiyadagi «neriage» — fikrlarni solishtirish)."},
{h:"Uch xonali sonni bo'lamiz",sum:"642 : 3 = (600 + 42) : 3 = 200 + 14 = 214.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Katta sonlarda ham shu usul: avval yuzliklarni, keyin qolganini bo'lamiz.</p>",btns:[phaser(P5)],
 after:"<p>642 : 3 = <b>214</b>. Agar biror xona (40) bo'luvchiga bo'linmasa, uni keyingi xona bilan birga olamiz (42). Aynan shu fikr <b>burchakli bo'lish</b>ning asosi!</p>",
 q:{t:"856 : 4 = ?",opts:["214","224","204","2014"],ok:0,why:"800 : 4 + 56 : 4 = 200 + 14 = 214.",hint:"856 = 800 + 56. Har birini 4 ga bo'ling.",full:"800 : 4 = 200, 56 : 4 = 14. Javob: 214. «2014» — natijalarni yonma-yon yozib qo'yish xatosi."},
 tn:"Keyingi mavzu (3C15) — burchakli bo'lish — shu misollarni yozma bajaradi. Bog'lanishni ko'rsating."},
{h:"Ayirmani songa bo'lish",sum:"(60 − 12) : 6 = 60 : 6 − 12 : 6 = 10 − 2 = 8.",a:"m06",
 start:function(){w3Expr(['(60 − 12) : 6']);w3Msg('Ayirmaga ham shu qoida ishlaydimi?')},fin:function(){w3Expr(['(60 − 12) : 6','= 60 : 6 − 12 : 6','= 10 − 2 = {8}']);w3Msg('48 : 6 = 8 ✓')},
 html:"<p>Qoida ayirmaga ham ishlaydimi? Ikkala usulda hisoblab ko'ring:</p>",
 btns:[["Avval ayirib, keyin bo'lamiz",function(c,done){w3Expr(['(60 − 12) : 6','= 48 : 6 = {8}']);w3Msg('48 : 6 = 8');mvK(done,2)}],["Har birini bo'lib, ayiramiz",function(c,done){w3Expr(['60 : 6 − 12 : 6','= 10 − 2 = {8}']);w3Msg('10 − 2 = 8 — xuddi shunday!');mvK(done,2)},'u']],g2:1,
 after:"<p>Ha: <b>(a − b) : c = a : c − b : c</b>. Masalan, 196 : 4 = (200 − 4) : 4 = 50 − 1 = 49 — juda tez!</p>",
 q:{t:"198 : 2 ni qulay hisoblang.",opts:["99","100","98","101"],ok:0,why:"(200 − 2) : 2 = 100 − 1 = 99.",hint:"198 = 200 − 2.",full:"198 = 200 − 2. 200 : 2 = 100, 2 : 2 = 1. 100 − 1 = 99."},
 tn:"«Yaxlit sondan ayirish» usuli: 196, 297, 395 kabi sonlarni bo'lishda juda qulay."},
{h:"Tuzoq: bo'luvchi yig'indi bo'lsa",sum:"24 : (4 + 2) = 24 : 6 = 4. Lekin 24 : 4 + 24 : 2 = 6 + 12 = 18 — XATO! Qoida faqat bo'linuvchi yig'indi bo'lganda ishlaydi.",a:"m07",
 start:function(){w3Expr(['24 : (4 + 2) = ?']);w3Msg('Bu yerda qoidani qo‘llasa bo‘ladimi?')},fin:function(){w3Expr(['24 : (4 + 2) = 24 : 6 = {4}','24 : 4 + 24 : 2 = [18] ✗']);w3Msg('Bo‘luvchini bo‘laklarga ajratib BO‘LMAYDI')},
 html:"<p>Endi yig'indi <b>bo'luvchi</b> o'rnida: 24 : (4 + 2). Qoidani shu yerda ham ishlatsa bo'ladimi? Ikkalasini hisoblang:</p>",
 btns:[["To'g'ri tartib: avval qavs",function(c,done){w3Expr(['24 : (4 + 2)','= 24 : 6 = {4}']);w3Msg('To‘g‘ri javob: 4');mvK(done,2)}],["«Qoida» bilan: 24:4 + 24:2",function(c,done){w3Expr(['24 : 4 + 24 : 2','= 6 + 12 = [18]','18 ≠ 4 ✗']);w3Msg('Natija boshqa chiqdi — bu xato yo‘l!');mvK(done,2)},'u']],g2:1,
 after:"<p>Qoida faqat <b>bo'linuvchi</b> yig'indi bo'lganda ishlaydi: (a + b) : c. Agar yig'indi <b>bo'luvchi</b> bo'lsa — c : (a + b) — avval qavsni hisoblaymiz. Mantiq: 24 ta olmani 6 kishiga bo'lsak, har biriga 4 ta; 18 ta tegishi mumkin emas!</p>",
 q:{t:"60 : (10 + 5) = ?",opts:["4","18","9","75"],ok:0,why:"60 : 15 = 4.",hint:"Bo'luvchi qavs ichida — avval qavsni hisoblang.",full:"10 + 5 = 15, 60 : 15 = 4. «18» — xato: 60 : 10 + 60 : 5 = 6 + 12 — bo'luvchini bo'laklash mumkin emas."},
 tn:"Bu xatoni bolalar juda ko'p qiladi. Real misol bilan ko'rsating: 24 ta konfetni 6 bolaga bo'lish."},
{h:"Murakkab misol: har biriga o'z bo'laklari",sum:"568 : 4 + 568 : 8 = 142 + 71 = 213.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>Bankdagi misol: <b>568 : 4 + 568 : 8</b>. Ikki bo'lishning har biri uchun eng qulay bo'laklarni tanlaymiz.</p>",btns:[phaser(P8)],
 after:"<p>Bitta son har xil bo'luvchi uchun <b>har xil</b> ajratiladi: 4 ga — 500 + 68, 8 ga — 560 + 8. Usul moslashuvchan — shunisi bilan kuchli.</p>",
 q:{t:"Hisoblang: 816 : 6 + 359 − 95",opts:["400","390","500","410"],ok:0,why:"816 : 6 = 136; 136 + 359 = 495; 495 − 95 = 400.",hint:"Avval bo'lish: 816 = 600 + 216.",full:"816 : 6 = 600 : 6 + 216 : 6 = 100 + 36 = 136. Keyin 136 + 359 = 495, 495 − 95 = 400."},
 tn:"Bank misollaridan 3–4 tasini tanlab, guruhlarda «kim qulayroq usul topadi» musobaqasini o'tkazing."},
{h:"Bilasizmi? Evklid isbotlagan",sum:"Taqsimot xossasini qadimgi yunon olimi Evklid «Negizlar» kitobida to'rtburchaklar bilan isbotlagan.",a:"m09",
 start:function(){w3Bar([{segs:[{w:60,t:'60',c:'#f2b766'},{w:12,t:'12',c:'#bfe9e3'}],br:'72',lab:''}],{top:60});w3Msg('Bir lenta — ikki bo‘lak: 72 = 60 + 12')},fin:function(){w3Bar([{segs:[{w:60,t:'60',c:'#f2b766'},{w:12,t:'12',c:'#bfe9e3'}],br:'72',lab:''}],{top:60});w3Msg('Bir lenta — ikki bo‘lak: 72 = 60 + 12')},
 html:"<p>📜 Bundan 2300 yil oldin yunon olimi <b>Evklid</b> «Negizlar» kitobining II qismida shu qoidani sonlar bilan emas, <b>to'rtburchaklar</b> bilan isbotlagan: katta to'rtburchakni bo'laklarga kessangiz, yuzlar yig'indisi o'zgarmaydi.</p><p>⭐ Bu qoida — <b>taqsimot xossasi</b> — keyinchalik al-Xorazmiy algebrasida ham asosiy usullardan biri bo'lgan.</p>",
 tn:"Kuchli o'quvchilarga to'rtburchakni ikki bo'lakka bo'lib, (a + b) · c = a · c + b · c ni ko'rsating — bu bo'lish qoidasining «egizagi»."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['(a + b) : c = a : c + b : c']);w3Msg('Har bir qo‘shiluvchini bo‘lamiz')},fin:function(){w3Expr(['(a + b) : c = a : c + b : c']);w3Msg('Har bir qo‘shiluvchini bo‘lamiz')},
 html:"<div class='memo'><ul><li><b>(a + b) : c = a : c + b : c</b> — har bir qo'shiluvchini bo'lib, natijalarni qo'shamiz.</li><li><b>(a − b) : c = a : c − b : c</b>.</li><li>Og'zaki hisoblash: sonni bo'luvchiga bo'linadigan bo'laklarga ajrating: 84 : 7 = 70 : 7 + 14 : 7 = 12.</li><li>Yaxlitdan ayirish: 198 : 2 = 100 − 1 = 99.</li><li>⚠️ Bo'luvchini bo'laklab bo'lmaydi: 24 : (4 + 2) = 4, 18 emas!</li><li>⚠️ Ikkala qo'shiluvchini ham bo'lishni unutmang.</li></ul></div>",
 tn:"Keyingi dars — burchakli bo'lish. Uni «yig'indini bo'lishning yozma ko'rinishi» deb tanishtiring."}
];
var PROBS=[
{t:"(30 + 18) : 6 = ?",o:["8","5","48","11"],k:0,s:"30 : 6 + 18 : 6 = 5 + 3 = 8."},
{t:"(80 + 24) : 8 = ?",o:["13","10","3","104"],k:0,s:"10 + 3 = 13."},
{t:"72 : 4 ni qulay hisoblang.",o:["18","17","16","19"],k:0,s:"(40 + 32) : 4 = 10 + 8 = 18."},
{t:"95 : 5 = ?",o:["19","18","21","17"],k:0,s:"(50 + 45) : 5 = 10 + 9 = 19."},
{t:"Qaysi bo'laklar 87 : 3 uchun qulay?",o:["60 + 27","80 + 7","50 + 37","70 + 17"],k:0,s:"60 va 27 ikkalasi ham 3 ga bo'linadi: 20 + 9 = 29."},
{t:"(63 + 7) : 7 = ?",o:["10","9","63","16"],k:0,s:"63 : 7 + 7 : 7 = 9 + 1 = 10."},
{t:"(56 − 16) : 8 = ?",o:["5","7","2","9"],k:0,s:"56 : 8 − 16 : 8 = 7 − 2 = 5."},
{t:"396 : 4 ni qulay hisoblang.",o:["99","98","101","104"],k:0,s:"(400 − 4) : 4 = 100 − 1 = 99."},
{t:"936 : 3 = ?",o:["312","321","302","3012"],k:0,s:"900 : 3 + 36 : 3 = 300 + 12 = 312."},
{t:"848 : 4 = ?",o:["212","202","221","2012"],k:0,s:"800 : 4 + 48 : 4 = 200 + 12 = 212."},
{t:"Qaysi tenglik NOTO'G'RI?",o:["36 : (3 + 3) = 36 : 3 + 36 : 3","(36 + 3) : 3 = 36 : 3 + 3 : 3","(40 − 8) : 4 = 40 : 4 − 8 : 4","(50 + 25) : 5 = 10 + 5"],k:0,s:"36 : 6 = 6, lekin 12 + 12 = 24 — bo'luvchini bo'laklab bo'lmaydi."},
{t:"48 : (6 + 2) = ?",o:["6","14","8","40"],k:0,s:"48 : 8 = 6."},
{t:"(248 + 136) : 2 = ?",o:["192","316","202","182"],k:0,s:"384 : 2 = 192 yoki 124 + 68 = 192."},
{t:"(936 − 384) : 3 = ?",o:["184","174","194","284"],k:0,s:"552 : 3 = 184 (312 − 128 = 184)."},
{t:"568 : 4 + 568 : 8 = ?",o:["213","284","223","203"],k:0,s:"142 + 71 = 213."},
{t:"846 : 2 − 846 : 3 = ?",o:["141","131","151","282"],k:0,s:"423 − 282 = 141."},
{t:"6 ta bola 54 ta yong'oq va 18 ta olmani teng bo'lishdi. Har biriga nechta meva tegdi?",o:["12","9","3","72"],k:0,s:"54 : 6 + 18 : 6 = 9 + 3 = 12."},
{t:"Sinfga 84 ta qizil va 56 ta ko'k qalam 7 ta guruhga teng bo'lindi. Bir guruhga nechta qalam?",o:["20","12","8","140"],k:0,s:"84 : 7 + 56 : 7 = 12 + 8 = 20."},
{t:"Qaysi sonni 4 ga bo'lganda 125 dan 5 ta ko'p chiqadi?",o:["520","500","505","130"],k:0,s:"125 + 5 = 130, 130 · 4 = 520."},
{t:"(a + 20) : 5 = 9 bo'lsa, a = ?",o:["25","45","5","65"],k:0,s:"a + 20 = 45 → a = 25. Tekshiruv: 45 : 5 = 9."}
];
function PRACT_STAGE(){w3Expr(['(a + b) : c = a : c + b : c']);w3Msg('Qulay bo‘laklarni toping')}
var PREP_DATA={teach:["Yig'indini songa bo'lish qoidasi: (a + b) : c = a : c + b : c.","Sonni qulay bo'laklarga ajratib og'zaki bo'lish (84 : 7, 642 : 3).","Ayirmani songa bo'lish; yaxlitdan ayirish usuli (198 : 2).","Tuzoq: bo'luvchini bo'laklab bo'lmaydi."],
 mist:["Faqat birinchi qo'shiluvchini bo'ladi: (48 + 24) : 6 = 8 + 24.","Bo'luvchini bo'laklaydi: 24 : (4 + 2) = 6 + 12.","Bo'linmaydigan bo'laklar tanlaydi (90 + 6 ni 4 ga).","Natijalarni yonma-yon yozib qo'yadi (200 va 14 → 2014)."],
 need:["Cho'p bog'lamlari yoki o'nlik bloklar.","Ikki xil rangdagi olmalar/kubiklar."],
 board:["<span class='w2'>(60 + 12) : 6 = 60 : 6 + 12 : 6 = 12</span>.","<span class='w2'>84 = 70 + 14</span> → <span class='w2'>10 + 2</span>.","<span class='w2'>642 = 600 + 42</span> → <span class='w2'>214</span>.","<span class='w2'>198 : 2 = 100 − 1</span>.","⚠️ <span class='w2'>24 : (4 + 2) = 4</span>, 18 emas."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
