var CODE='3C10',TITLE='3-sinf · Ko‘paytirish va bo‘lishning qulay og‘zaki usullari';
var P1=[function(){W3area([23],4,{lbl:'23 · 4 = ?'});W3msg('23 ni o‘nlik va birlikka ajratamiz')},
 function(){W3area([20,3],4,{show:1,lbl:'23 = 20 + 3'})},
 function(){W3area([20,3],4,{show:2,lbl:'80 + 12 = 92'});W3msg('23 · 4 = 20 · 4 + 3 · 4 = 80 + 12 = <b>92</b>')}];
var P2=[function(){W3eq(['16 · 4 = ?']);W3msg('4 = 2 · 2. Ikki marta ikkilantiramiz')},
 function(){W3eq(['16 · 2 = [32]']);W3msg('Bir marta ikkilantirdik')},
 function(){W3eq(['16 · 2 = 32','32 · 2 = [64]']);W3msg('Yana bir marta: 16 · 4 = <b>64</b>')}];
var P3=[function(){W3eq(['48 · 5 = ?']);W3msg('5 — bu 10 ning yarmi')},
 function(){W3eq(['48 · 10 = [480]']);W3msg('Avval 10 ga ko‘paytiramiz — oson')},
 function(){W3eq(['48 · 10 = 480','480 : 2 = [240]']);W3msg('Keyin yarmini olamiz: 48 · 5 = <b>240</b>')}];
var P4=[function(){W3eq(['84 : 6 = ?']);W3msg('84 ni 6 ga qulay bo‘linadigan qismlarga ajratamiz')},
 function(){W3eq(['84 = 60 + 24']);W3msg('60 va 24 — ikkalasi ham 6 ga bo‘linadi')},
 function(){W3eq(['84 = 60 + 24','60 : 6 + 24 : 6','= 10 + 4 = [14]']);W3msg('Tekshiruv: 14 · 6 = 84 ✓')}];
var P5=[function(){W3pv([{v:30}],{cols:3});W3msg('30 · 4 = ? &nbsp; 30 = 3 ta o‘nlik')},
 function(){W3pv([{v:30},{v:120,lab:'·4'}],{cols:3});W3msg('3 o‘nlik · 4 = <b>12 o‘nlik</b> = 120')},
 function(){W3eq(['30 · 4 = [120]','240 : 6 = [40]']);W3msg('240 = 24 o‘nlik; 24 o‘nlik : 6 = <b>4 o‘nlik</b> = 40')}];
var P8=[function(){W3eq(['72 : 4 = ?']);W3msg('4 ga bo‘lish = ikki marta 2 ga bo‘lish')},
 function(){W3eq(['72 : 2 = [36]']);W3msg('Yarmi')},
 function(){W3eq(['72 : 2 = 36','36 : 2 = [18]']);W3msg('Yarmining yarmi: 72 : 4 = <b>18</b>')}];
var STEPS=[
{h:"Xona qo'shiluvchilariga ajratish",sum:"23 · 4 = 20 · 4 + 3 · 4 = 80 + 12 = 92.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ikki xonali sonni bir xonaliga og'zaki ko'paytirishning asosiy usuli.</p>",btns:[phaser(P1)],
 after:"<p>Avval <b>o'nliklar</b>, keyin <b>birliklar</b> ko'paytiriladi, natijalar qo'shiladi. Bu — taqsimot xossasi.</p>",
 q:{t:"34 · 3 = ?",opts:["102","912","94","37"],ok:0,why:"90 + 12 = 102.",hint:"30 · 3 va 4 · 3 ni qo'shing.",full:"30 · 3 = 90, 4 · 3 = 12, 90 + 12 = 102. «912» — natijalar qo'shilmay yonma-yon yozilgan, «94» — 30 · 3 + 4."},
 tn:"Bolalar natijani yozishdan oldin ovoz chiqarib aytsin: «o'ttiz uch marta — to'qson, to'rt uch marta — o'n ikki…»."},
{h:"·4 — ikki marta ikkilantirish",sum:"16 · 4 = 16 · 2 · 2 = 32 · 2 = 64.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ikkilantirish — eng oson amal. 4 = 2 · 2 bo'lgani uchun…</p>",btns:[phaser(P2)],
 after:"<p><b>·4 = ·2 ·2</b>, <b>·8 = ·2 ·2 ·2</b>. Masalan 15 · 8: 30, 60, <b>120</b>.</p>",
 q:{t:"25 · 4 = ?",opts:["100","50","90","29"],ok:0,why:"50, keyin 100.",hint:"Ikki marta ikkilantiring.",full:"25 · 2 = 50, 50 · 2 = 100. «50» — faqat bir marta ikkilantirilgan."},
 tn:"«Ikkilantirish zanjiri» o'yini: o'qituvchi son aytadi, bolalar navbat bilan ikkilantiradi."},
{h:"·5 — 10 ning yarmi",sum:"48 · 5 = 48 · 10 : 2 = 480 : 2 = 240.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>5 ga ko'paytirish qiyinmi? Unda 10 ga ko'paytirib, yarmini oling!</p>",btns:[phaser(P3)],
 after:"<p><b>·5 = ·10 :2</b>. Juft son bo'lsa yanada oson: avval yarmi, keyin ·10: 48 : 2 = 24 → 240.</p>",
 q:{t:"64 · 5 = ?",opts:["320","640","3200","69"],ok:0,why:"640 : 2 = 320.",hint:"10 ga ko'paytirib, yarmini oling.",full:"64 · 10 = 640, 640 : 2 = 320. «640» — yarmini olish unutilgan."},
 tn:"Hayotiy misol: 5 so'mlik tangalar — 10 so'mlikning yarmi."},
{h:"Bo'lishni qismlarga ajratish",sum:"84 : 6 = 60 : 6 + 24 : 6 = 10 + 4 = 14.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Bo'linuvchini bo'luvchiga <b>qulay bo'linadigan</b> qismlarga ajratamiz.</p>",btns:[phaser(P4)],
 after:"<p>Ajratishda birinchi qism — bo'luvchining <b>yaxlit karralisi</b> (60, 30, 40…) bo'lsin. 84 = 80 + 4 qilsak, 80 : 6 butun chiqmaydi!</p>",
 q:{t:"91 : 7 = ?",opts:["13","12","17","10"],ok:0,why:"70 : 7 + 21 : 7 = 10 + 3 = 13.",hint:"91 = 70 + 21.",full:"91 = 70 + 21; 70 : 7 = 10, 21 : 7 = 3; jami 13. Tekshiruv: 13 · 7 = 91 ✓."},
 tn:"Bolalar birinchi qismni o'zi tanlasin va nega 80 emas, 60 qulayligini muhokama qiling."},
{h:"Yaxlit sonlar bilan amallar",sum:"30 · 4 = 3 o'nlik · 4 = 12 o'nlik = 120; 240 : 6 = 24 o'nlik : 6 = 40.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Yaxlit o'nliklarni xuddi birliklar kabi ko'paytiramiz va bo'lamiz — faqat «o'nlik» deb aytamiz.</p>",btns:[phaser(P5)],
 after:"<p>30 · 4: <b>3 · 4 = 12</b>, o'nlik bo'lgani uchun — 120. 240 : 6: <b>24 : 6 = 4</b>, o'nlik — 40.</p>",
 q:{t:"70 · 6 = ?",opts:["420","42","4200","76"],ok:0,why:"7 · 6 = 42 o'nlik = 420.",hint:"7 o'nlik · 6 = ? o'nlik.",full:"7 · 6 = 42, o'nlik bo'lgani uchun 420. «42» — 0 unutilgan, «4200» — ortiqcha 0."},
 tn:"O'nlik cho'p bog'lamlari bilan: 3 bog'lam · 4 = 12 bog'lam."},
{h:"Tuzoq: nollar soni",sum:"50 · 8 = 400 (5 · 8 = 40 da o'zining noli bor); 600 : 30 = 20.",a:"m06",start:function(){W3eq(['50 · 8 = ?']);W3msg('Variantni tanlang')},fin:function(){W3eq(['5 · 8 = 40','50 · 8 = [400]'])},
 html:"<p><b>50 · 8</b> nechaga teng?</p>",
 btns:[["400",function(c,done){W3eq(['5 · 8 = 40','50 · 8 = 40 o‘nlik = [400]']);W3msg('To‘g‘ri: 40 ning o‘z noli + 50 dagi nol = ikki 0');done()}],["40",function(){W3eq(['50 · 8 = ?']);W3msg('Yo‘q: 50 dagi nolni unutdingiz','Qayta tanlang')}],["4000",function(){W3eq(['50 · 8 = ?']);W3msg('Yo‘q: 5 · 8 = 40, unga faqat bitta 0 qo‘shiladi','Qayta tanlang')}]],g3:1,
 after:"<p>Ehtiyot bo'ling: 5 · 8 = 40 — natijaning <b>o'zida</b> 0 bor. Shuning uchun 50 · 8 = 400 da ikkita nol. Bo'lishda: 600 : 30 = 60 o'nlik : 3 o'nlik = <b>20</b>.</p>",
 q:{t:"800 : 40 = ?",opts:["20","2","200","40"],ok:0,why:"80 o'nlik : 4 o'nlik = 20.",hint:"Ikkala sondan bittadan 0 olib tashlang: 80 : 4.",full:"800 : 40 = 80 : 4 = 20. «2» — 8 : 4 deb ikkala nol olingan, «200» — 800 : 4."},
 tn:"«Nollarni yopish» usuli: avval nollarni barmoq bilan yopib hisoblang, keyin nollarni sanang."},
{h:"Tuzoq: qulay usulni tanlash",sum:"25 · 16: 25 · 4 · 4 = 100 · 4 = 400 — ko'paytuvchini ajratish.",a:"m07",start:function(){W3eq(['25 · 16 = ?']);W3msg('Qaysi usul eng tez?')},fin:function(){W3eq(['25 · 16 = 25 · 4 · 4','= 100 · 4 = [400]'])},
 html:"<p><b>25 · 16</b> ni og'zaki hisoblang. Usulni tanlang:</p>",
 btns:[["16 = 4 · 4",function(c,done){W3eq(['25 · 16 = 25 · 4 · 4','= 100 · 4 = [400]']);W3msg('Eng tez! 25 · 4 = 100');done()}],["16 = 10 + 6",function(){W3eq(['250 + 150 = 400']);W3msg('To‘g‘ri, lekin 25 · 6 ni hisoblash qo‘shimcha ish','Tezrog‘ini toping')}],["25 = 20 + 5",function(){W3eq(['320 + 80 = 400']);W3msg('To‘g‘ri, lekin uzunroq','Tezrog‘ini toping')}]],g3:1,
 after:"<p>Ko'paytuvchini <b>ko'paytuvchilarga</b> ajratish (16 = 4 · 4) ham qulay usul. Usullar ko'p — eng tezini tanlash o'zi mahorat.</p>",
 q:{t:"5 · 18 = ?",opts:["90","58","80","95"],ok:0,why:"5 · 2 · 9 = 10 · 9 = 90.",hint:"18 = 2 · 9.",full:"5 · 18 = 5 · 2 · 9 = 90. Yoki 180 : 2 = 90. «58» — natija sifatida sonlar yonma-yon yozilgan."},
 tn:"Bitta misolni 3 xil usulda yechtirib, eng qisqasini sinf ovoz bilan tanlasin (Yaponiya «neriage» muhokamasi)."},
{h:":4 — ikki marta yarmi",sum:"72 : 4 = 72 : 2 : 2 = 36 : 2 = 18.",a:"m08",start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>4 ga bo'lishning tez usuli — <b>yarmining yarmi</b>.</p>",btns:[phaser(P8)],
 after:"<p><b>:4 = :2 :2</b>, <b>:8 = :2 :2 :2</b>. Xuddi shunday <b>:5</b> uchun: ·2, keyin :10 → 135 : 5 = 270 : 10 = 27.</p>",
 q:{t:"96 : 8 = ?",opts:["12","24","48","11"],ok:0,why:"48, 24, 12.",hint:"Uch marta yarmini oling.",full:"96 : 2 = 48, 48 : 2 = 24, 24 : 2 = 12. «24» — ikki marta, «48» — bir marta bo'lingan."},
 tn:"Qog'ozni ikki marta buklang — 4 bo'lak; uch marta — 8 bo'lak. Yarmining yarmi ko'rinadi."},
{h:"Bilasizmi? Misr usuli",sum:"Qadimgi Misrda ko'paytirish ikkilantirish orqali bajarilgan (Rind papirusi).",a:"m09",start:function(){W3eq(['[1 → 13]','[2 → 26]','4 → 52','[8 → 104]'],{fs:18});W3msg('13 · 11: 1 + 2 + 8 = 11 → 13 + 26 + 104 = 143')},fin:function(){STEPS[8].start()},
 html:"<p>📜 Taxminan 3600 yil oldin yozilgan Misr <b>Rind papirusida</b> ko'paytirish faqat <b>ikkilantirish va qo'shish</b> bilan bajarilgan. Masalan 13 · 11: 13, 26, 52, 104 ni yozib, 1 + 2 + 8 = 11 bo'ladigan qatorlarni qo'shishgan: 13 + 26 + 104 = 143.</p>",
 tn:"Bolalarga ko'paytirish jadvalisiz 12 · 7 ni Misr usulida yechtiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3area([20,3],4,{show:2,lbl:'23 · 4 = 80 + 12'})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Xonalarga ajratish: 23 · 4 = 80 + 12 = 92.</li><li>·4 = ·2 ·2; ·8 = ·2 ·2 ·2; :4 = :2 :2.</li><li>·5 = ·10 :2 (48 · 5 = 240); :5 = ·2 :10.</li><li>Bo'lish: qulay qismlar — 84 : 6 = 60 : 6 + 24 : 6 = 14.</li><li>Yaxlit sonlar: 30 · 4 = 120, 240 : 6 = 40, 800 : 40 = 20.</li><li>Nolni sanang: 50 · 8 = 400 (5 · 8 = 40 ning o'z noli bor).</li></ul></div>",
 tn:"Har dars boshida 5 daqiqalik og'zaki hisob — usullarni avtomatlashtiradi."}
];
var PROBS=[
{t:"42 · 2 = ?",o:["84","82","44","824"],k:0,s:"80 + 4 = 84."},
{t:"26 · 3 = ?",o:["78","68","618","29"],k:0,s:"60 + 18 = 78."},
{t:"40 · 7 = ?",o:["280","28","2800","47"],k:0,s:"4 · 7 = 28 o'nlik."},
{t:"360 : 9 = ?",o:["40","4","400","36"],k:0,s:"36 o'nlik : 9 = 4 o'nlik."},
{t:"18 · 4 = ?",o:["72","36","62","144"],k:0,s:"36, 72."},
{t:"86 · 5 = ?",o:["430","860","4300","91"],k:0,s:"860 : 2 = 430."},
{t:"78 : 6 = ?",o:["13","12","14","18"],k:0,s:"60 : 6 + 18 : 6 = 13."},
{t:"60 · 5 = ?",o:["300","30","3000","65"],k:0,s:"6 · 5 = 30 o'nlik."},
{t:"900 : 30 = ?",o:["30","3","300","90"],k:0,s:"90 : 3 = 30."},
{t:"84 : 4 = ?",o:["21","42","24","20"],k:0,s:"42, 21."},
{t:"25 · 12 = ?",o:["300","250","275","312"],k:0,s:"25 · 4 · 3 = 300."},
{t:"14 · 5 · 2 = ?",o:["140","70","28","1400"],k:0,s:"14 · 10 = 140."},
{t:"19 · 4 = ?",o:["76","80","79","36"],k:0,s:"80 − 4 = 76."},
{t:"Qaysi ifoda eng katta?",o:["40 · 9","70 · 5","50 · 7","90 · 3"],k:0,s:"360; 350; 350; 270."},
{t:"115 : 5 = ?",o:["23","25","22","32"],k:0,s:"230 : 10 = 23."},
{t:"Bitta kitob 15 ming so'm. 8 ta kitob necha ming so'm?",o:["120","80","115","150"],k:0,s:"15 · 8: 30, 60, 120."},
{t:"Sinfda 96 ta daftar 8 ta partaga teng tarqatildi. Har partaga nechta?",o:["12","11","14","88"],k:0,s:"48, 24, 12."},
{t:"500 · 8 = ?",o:["4000","400","40 000","508"],k:0,s:"5 · 8 = 40 yuzlik = 4000."},
{t:"□ · 5 = 350. □ = ?",o:["70","7","700","35"],k:0,s:"350 · 2 : 10 = 70."},
{t:"(80 : 4) · (24 : 6) = ?",o:["80","24","20","44"],k:0,s:"20 · 4 = 80."}
];
function PRACT_STAGE(){W3area([20,3],4,{show:1,lbl:'Ajrating — keyin hisoblang'})}
var PREP_DATA={teach:["Xona qo'shiluvchilariga ajratib ko'paytirish.","·4, ·8 — ikkilantirish; ·5 — ·10 :2; :4 — yarmining yarmi.","Bo'linuvchini qulay qismlarga ajratish.","Yaxlit sonlar bilan ko'paytirish va bo'lish, nollar soni."],
 mist:["34 · 3 = 912 (qo'shmay yonma-yon yozadi).","50 · 8 = 4000.","800 : 40 = 2.","84 : 6 da 80 + 4 ga ajratadi."],
 need:["O'nlik cho'p bog'lamlari.","Qog'oz varag'i (buklash), og'zaki hisob kartochkalari."],
 board:["<span class='w2'>23 · 4 = 80 + 12 = 92</span>","<span class='w2'>48 · 5 = 480 : 2 = 240</span>","<span class='w2'>84 : 6 = 10 + 4 = 14</span>","<span class='w2'>50 · 8 = 400</span>","<span class='w2'>72 : 4 = 36 : 2 = 18</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
