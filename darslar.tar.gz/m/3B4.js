var CODE='3B4',TITLE='3-sinf · Komponentlar va noma‘lumni topish';
var P1=[function(){bqBar(830,[{v:'560',w:560,lab:'1-qo‘shiluvchi'},{v:'270',w:270,col:C.b,lab:'2-qo‘shiluvchi'}],{title:'560 + 270 = 830'});bqMsg('Ikki qism birgalikda — butun (yig‘indi)')},
 function(){bqBar(830,[{v:'560',w:560,lab:'ma’lum'},{v:'x',w:270,q:1,lab:'noma’lum'}],{title:'560 + x = 830'});bqMsg('Bir qism yashirindi. Uni qanday topamiz?')},
 function(){bqBar(830,[{v:'560',w:560,col:'#e9e2d6',lab:'olib tashlaymiz'},{v:'270',w:270,col:C.ok,lab:'x = 830 − 560'}],{title:'x = 830 − 560 = 270'});bqMsg('Noma’lum qo‘shiluvchi = yig‘indi − ma’lum qo‘shiluvchi')}];
var P2=[function(){bqBar('x',[{v:'375',w:375,col:C.b,lab:'ayriluvchi (ketdi)'},{v:'248',w:248,lab:'ayirma (qoldi)'}],{title:'x − 375 = 248',tq:1});bqMsg('Kamayuvchi — butun. U noma’lum')},
 function(){bqBar('623',[{v:'375',w:375,col:C.b,lab:'ketdi'},{v:'248',w:248,lab:'qoldi'}],{title:'x = 248 + 375 = 623'});bqMsg('Noma’lum kamayuvchi = ayirma + ayriluvchi')}];
var P3=[function(){bqBar('900',[{v:'x',w:410,q:1,lab:'ayriluvchi (ketdi)'},{v:'490',w:490,lab:'ayirma (qoldi)'}],{title:'900 − x = 490'});bqMsg('Butun ma’lum, ketgan qism noma’lum')},
 function(){bqBar('900',[{v:'410',w:410,col:C.ok,lab:'x = 900 − 490'},{v:'490',w:490,lab:'qoldi'}],{title:'x = 900 − 490 = 410'});bqMsg('Noma’lum ayriluvchi = kamayuvchi − ayirma')}];
var P5=[function(){bqScale(['x','150'],['600'],0);bqMsg('x + 150 = 600. Tarozi teng turibdi')},
 function(){bqScale(['x'],['450'],0);bqMsg('Ikkala palladan 150 ni olamiz — tarozi baribir teng: x = 450')}];
var P6=[function(){bqExpr(['(x + 125) − 300 = 480']);bqMsg('Murakkab tenglama: noma’lum qavs ichida')},
 function(){bqExpr(['(x + 125) − 300 = 480','x + 125 = 480 + [300] = 780']);bqMsg('Qavsni «yashirin kamayuvchi» deb qaraymiz: kamayuvchi = ayirma + ayriluvchi')},
 function(){bqExpr(['x + 125 = 780','x = 780 − 125 = [655]']);bqMsg('Endi oddiy tenglama. Tekshiramiz: 655 + 125 = 780, 780 − 300 = 480 ✓')}];
var STEPS=[
{h:"Qo'shish komponentlari",sum:"qo'shiluvchi + qo'shiluvchi = yig'indi. Noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har bir sonning <b>nomi</b> bor. 560 + 270 = 830 da 560 va 270 — <b>qo'shiluvchilar</b>, 830 — <b>yig'indi</b>. Chizma modelida qo'shiluvchilar — qismlar, yig'indi — butun.</p>",btns:[phaser(P1)],
 after:"<p>Qism yashirinsa — butundan ma'lum qismni ayiramiz. <b>x = 830 − 560 = 270</b>.</p>",
 q:{t:"x + 438 = 905. x ni toping.",opts:["467","1343","577","533"],ok:0,why:"x = 905 − 438 = 467.",hint:"Noma'lum — qism. Butundan ma'lum qismni ayiring.",full:"905 — yig'indi (butun), 438 — ma'lum qism. x = 905 − 438 = 467. Tekshiramiz: 467 + 438 = 905 ✓. «1343» — qo'shib yuborilgan."},
 tn:"Bolalar har tenglamaga chizma chizsin: butun — uzun chiziq, qismlar — bo'laklar. Bu Singapur darsliklarining asosiy usuli."},
{h:"Ayirish komponentlari",sum:"kamayuvchi − ayriluvchi = ayirma. Noma'lum kamayuvchi = ayirma + ayriluvchi.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>623 − 375 = 248 da 623 — <b>kamayuvchi</b> (butun), 375 — <b>ayriluvchi</b> (ketgan qism), 248 — <b>ayirma</b> (qolgan qism). Agar butun noma'lum bo'lsa-chi?</p>",btns:[phaser(P2)],
 after:"<p>Kamayuvchi — bu butun. Butun = ikki qism yig'indisi: <b>x = 248 + 375 = 623</b>.</p>",
 q:{t:"x − 286 = 457. x ni toping.",opts:["743","171","733","643"],ok:0,why:"x = 457 + 286 = 743.",hint:"x — butun (kamayuvchi). Qolgan va ketgan qismlarni qo'shing.",full:"Kamayuvchi = ayirma + ayriluvchi = 457 + 286 = 743. Tekshiramiz: 743 − 286 = 457 ✓. «171» — ayirib yuborilgan (eng ko'p xato)."},
 tn:"Eng ko'p xato: «minus bor — demak ayiraman». Chizmada x butun ekanini ko'rgan bola qo'shishni tanlaydi."},
{h:"Noma'lum ayriluvchi",sum:"Noma'lum ayriluvchi = kamayuvchi − ayirma: 900 − x = 490 → x = 410.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>900 − x = 490. Bu safar butun ma'lum, ketgan qism noma'lum.</p>",btns:[phaser(P3)],
 after:"<p>Ketgan qism = butun − qolgan qism: <b>x = 900 − 490 = 410</b>.</p><div class='life'><div>🧩<span><b>Noma'lum qism</b> → butundan ayiramiz</span></div><div>📦<span><b>Noma'lum butun</b> → qismlarni qo'shamiz</span></div></div>",
 q:{t:"700 − x = 265. x ni toping.",opts:["435","965","445","535"],ok:0,why:"x = 700 − 265 = 435.",hint:"700 — butun, 265 — qolgan qism. Ketgan qismni toping.",full:"x — ketgan qism (ayriluvchi). x = 700 − 265 = 435. Tekshiramiz: 700 − 435 = 265 ✓. «965» — qo'shilgan."},
 tn:"Uch qoidani yodlatishdan ko'ra, har safar «x butunmi yoki qismmi?» deb so'rang."},
{h:"Qaysi qoida? O'zingiz tanlang",sum:"Avval x ning o'rnini aniqlaymiz: butunmi yoki qism? Butun — qo'shamiz, qism — ayiramiz.",a:"m04",start:function(){w3b4Sort(null)},fin:function(){w3b4Sort(3)},
 html:"<p>Uchta tenglama berilgan. Har birida x — <b>butunmi</b> yoki <b>qismmi</b>? Tenglamalarni bosing — sahnada chizmasi chiqadi.</p>",
 btns:[["x + 340 = 900",function(c,done){w3b4Sort(0);w3b4M(done)}],["x − 340 = 900",function(c,done){w3b4Sort(1);w3b4M(done)}],["900 − x = 340",function(c,done){w3b4Sort(2);w3b4M(done)}]],
 after:"<p>Uchalasida ham sonlar bir xil (340 va 900), lekin javoblar har xil: <b>560</b>, <b>1240</b>, <b>560</b>. Hal qiluvchi narsa — <b>x ning o'rni</b>.</p>",
 q:{t:"Qaysi tenglamada x qo'shish bilan topiladi?",opts:["x − 509 = 380","x + 380 = 509","509 − x = 380","380 + x = 509"],ok:0,why:"x − 509 = 380 da x — kamayuvchi (butun): x = 380 + 509.",hint:"Qaysi tenglamada x butun (kamayuvchi)?",full:"x − 509 = 380 da x dan 509 ayirilyapti — demak x butun, x = 380 + 509 = 889. Qolgan uchtasida x — qism, ayirish bilan topiladi."},
 tn:"Bolalarga kartochkalar bering: «butun» va «qism». Har tenglamada x ga mos kartochkani qo'ysin."},
{h:"Tarozi usuli",sum:"x + 150 = 600: ikkala palladan 150 ni olsak — x = 450. Tenglik saqlanadi.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Tenglamani <b>tarozi</b> deb tasavvur qiling: ikkala tomon teng. Ikkala palladan bir xil narsa olsak — tarozi teng qoladi.</p>",btns:[phaser(P5,'▶ Palladan olish')],
 after:"<p>Tenglik «tarozi»: chap va o'ng tomonga bir xil amal bajarsak, tenglik buzilmaydi. Bu fikr keyingi sinflarda barcha tenglamalarning asosi bo'ladi.</p>",
 q:{t:"Tarozida: chapda x va 275, o'ngda 1000. x nechaga teng?",opts:["725","1275","735","625"],ok:0,why:"Ikkala tomondan 275 ni olamiz: x = 1000 − 275 = 725.",hint:"Ikkala palladan 275 ni oling.",full:"x + 275 = 1000. Ikkala tomondan 275 ni ayiramiz: x = 1000 − 275 = 725 (9-9-10 usuli: 7, 2, 5)."},
 tn:"Ikki pallali tarozi yoki ilgichdan foydalaning. «Al-jabr» so'zining ma'nosi — «tiklash», ya'ni tenglamaning bir tomonidan ikkinchisiga o'tkazish."},
{h:"Tuzoq: qavsli tenglama",sum:"(x + 125) − 300 = 480: avval qavs = 780, keyin x = 655.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Testlarda shunday tenglamalar keladi: <b>(x + 125) − 300 = 480</b>. Qavsni <b>bitta narsa</b> deb qaraymiz.</p>",btns:[phaser(P6)],
 after:"<p>Usul: avval <b>tashqi</b> amalni «yechamiz» — qavs ichidagi ifoda topiladi. Keyin ichkariga kiramiz. Oxirida albatta tekshiring!</p>",
 q:{t:"(x − 200) + 350 = 900. x ni toping.",opts:["750","550","1450","350"],ok:0,why:"x − 200 = 900 − 350 = 550, x = 550 + 200 = 750.",hint:"Avval (x − 200) ni toping: u qo'shiluvchi.",full:"(x − 200) — noma'lum qo'shiluvchi: 900 − 350 = 550. Endi x − 200 = 550, x — kamayuvchi: 550 + 200 = 750. Tekshiramiz: 750 − 200 = 550, 550 + 350 = 900 ✓. «550» — ikkinchi qadamni unutish."},
 tn:"Qavsni rangli qalam bilan o'rab, «quti» deb nomlang. Avval qutini topamiz, keyin ichini ochamiz."},
{h:"Tuzoq: matndan tenglama",sum:"«Bir son o'ylab, 245 qo'shdim, 900 chiqdi» → x + 245 = 900 → x = 655.",a:"m07",start:function(){bqBar(900,[{v:'x',w:655,q:1,lab:'o‘ylangan son'},{v:'245',w:245,col:C.b,lab:'qo‘shildi'}],{title:'x + 245 = 900'});bqMsg('Matnni chizmaga, chizmani tenglamaga aylantiramiz')},fin:function(){bqBar(900,[{v:'655',w:655,col:C.ok,lab:'o‘ylangan son'},{v:'245',w:245,col:C.b,lab:'qo‘shildi'}],{title:'x = 900 − 245 = 655'});bqMsg('x = 655')},
 html:"<p>Masala: <i>«Ali bir son o'yladi. Unga 245 ni qo'shib, keyin 380 ni ayirdi va 520 hosil bo'ldi. Ali qaysi sonni o'ylagan?»</i></p>",
 btns:[["① Oxiridan: 520 + 380",function(c,done,b){b.disabled=true;bqExpr(['□ − 380 = 520','□ = 520 + 380 = [900]']);bqMsg('380 ni ayirishdan oldin 900 bor edi');S._q7=(S._q7||0)+1;if(S._q7>=2)done()}],["② Keyin: 900 − 245",function(c,done,b){b.disabled=true;bqExpr(['x + 245 = 900','x = 900 − 245 = [655]']);bqMsg('245 qo‘shilishidan oldin 655 bor edi. Ali 655 ni o‘ylagan');S._q7=(S._q7||0)+1;if(S._q7>=2)done()}]],g2:1,
 after:"<p>Oxiridan boshlab, har amalni <b>teskarisiga</b> almashtiramiz: «ayirdi» → qo'shamiz, «qo'shdi» → ayiramiz. Tekshiramiz: 655 + 245 = 900, 900 − 380 = 520 ✓.</p>",
 q:{t:"Bir songa 168 qo'shib, natijadan 400 ayirilsa 375 chiqadi. Son nechaga teng?",opts:["607","943","775","207"],ok:0,why:"375 + 400 = 775, 775 − 168 = 607.",hint:"Oxiridan boshlang: 400 ayirilmasdan oldin nechta edi?",full:"Oxiridan: 375 + 400 = 775. Keyin 775 − 168 = 607. Tekshiramiz: 607 + 168 = 775, 775 − 400 = 375 ✓. «943» — amallar teskari qilinmagan."},
 tn:"«O'ylangan son» o'yinini sinfda o'ynang: bitta bola son o'ylab, amallarni aytadi, sinf topadi."},
{h:"Bilasizmi? «x» harfi qayerdan?",sum:"Noma'lumni x bilan belgilashni Dekart (1637) ommalashtirgan. Tenglamalar ilmi al-Xorazmiyning «al-jabr»idan boshlangan.",a:"m08",start:function(){bqExpr(['x + 560 = 830']);bqMsg('Noma’lum son — x')},fin:function(){bqExpr(['x + 560 = 830']);bqMsg('Noma’lum son — x')},
 html:"<p>⭐ Tenglamalarni yechish qoidalarini IX asrda vatandoshimiz <b>Muhammad al-Xorazmiy</b> «Al-jabr val-muqobala» kitobida yozgan. «Algebra» so'zi shu kitob nomidan olingan.</p><p>✏️ Noma'lumni <b>x</b> harfi bilan belgilashni fransuz olimi <b>Rene Dekart</b> 1637-yilda kitobida ommalashtirgan. Undan oldin olimlar noma'lumni so'z bilan («narsa») yozishgan.</p>",
 btns:[["✏️ So'z bilan yozib ko'rish",function(c,done){bqExpr(['«narsa» va 560 — bu 830','narsa = 830 − 560 = [270]']);bqMsg('Al-Xorazmiy davrida tenglama shunday so‘z bilan yozilgan');done()}]],
 tn:"Bolalar tenglamani «so'z bilan» va «x bilan» yozib solishtirsin — belgilar qanchalik qulayligini ko'radi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqBar(830,[{v:'560',w:560},{v:'x',w:270,q:1}],{title:'560 + x = 830'});bqMsg('x = 830 − 560 = 270')},fin:function(){bqBar(830,[{v:'560',w:560},{v:'x',w:270,q:1}],{title:'560 + x = 830'});bqMsg('x = 830 − 560 = 270')},
 html:"<div class='memo'><ul><li><b>qo'shiluvchi + qo'shiluvchi = yig'indi</b>; <b>kamayuvchi − ayriluvchi = ayirma</b>.</li><li>Avval so'rang: x <b>butunmi</b> yoki <b>qismmi</b>?</li><li>x — qism (qo'shiluvchi yoki ayriluvchi) → <b>butundan ayiramiz</b>.</li><li>x — butun (kamayuvchi) → <b>qismlarni qo'shamiz</b>.</li><li>Qavsli tenglama: avval qavsni «quti» deb toping, keyin ichini.</li><li>Matnli masalada — oxiridan boshlab, amallarni teskarisiga almashtiring.</li><li>Doim <b>tekshiring</b>: topilgan sonni tenglamaga qo'ying.</li></ul></div>",
 tn:"Keyingi darsni «x − 250 = 250 va 250 − x = 250 — farqi nima?» savoli bilan boshlang (500 va 0)."}
];
function w3b4Sort(k){var D=[[[{v:'x',w:560,q:1,lab:'qism'},{v:'340',w:340,col:C.b,lab:'qism'}],'900','x = 900 − 340 = 560'],[[{v:'340',w:340,col:C.b,lab:'ketdi'},{v:'900',w:900,lab:'qoldi'}],'x','x = 900 + 340 = 1240'],[[{v:'x',w:560,q:1,lab:'ketdi'},{v:'340',w:340,lab:'qoldi'}],'900','x = 900 − 340 = 560']];
 if(k==null){bqExpr(['x + 340 = 900','x − 340 = 900','900 − x = 340']);bqMsg('Tenglamani tanlang');return}if(k===3)k=1;var d=D[k];bqBar(d[1],d[0],{title:['x + 340 = 900','x − 340 = 900','900 − x = 340'][k],tq:d[1]==='x'});bqMsg((d[1]==='x'?'x — <b>butun</b> → qo‘shamiz: ':'x — <b>qism</b> → ayiramiz: ')+d[2])}
function w3b4M(done){S._s4=(S._s4||0)+1;if(S._s4>=3)done()}
var PROBS=[
{t:"x + 356 = 802. x ni toping.",o:["446","1158","456","546"],k:0,s:"x = 802 − 356 = 446."},
{t:"x − 278 = 534. x ni toping.",o:["812","256","802","712"],k:0,s:"x = 534 + 278 = 812."},
{t:"1000 − x = 637. x ni toping.",o:["363","1637","373","463"],k:0,s:"x = 1000 − 637 = 363."},
{t:"465 + x = 900. x ni toping.",o:["435","1365","445","535"],k:0,s:"x = 900 − 465 = 435."},
{t:"Qaysi tenglamaning ildizi eng katta?",o:["x − 300 = 500","x + 300 = 500","500 − x = 300","x + 500 = 800"],k:0,s:"800, 200, 200, 300 — eng kattasi 800."},
{t:"Yig'indi 720, bir qo'shiluvchi 385. Ikkinchi qo'shiluvchini toping.",o:["335","1105","345","435"],k:0,s:"720 − 385 = 335."},
{t:"Ayirma 196, ayriluvchi 508. Kamayuvchini toping.",o:["704","312","694","604"],k:0,s:"196 + 508 = 704."},
{t:"Kamayuvchi 650, ayirma 284. Ayriluvchini toping.",o:["366","934","376","466"],k:0,s:"650 − 284 = 366."},
{t:"(x + 120) − 250 = 400. x ni toping.",o:["530","770","280","650"],k:0,s:"x + 120 = 650, x = 530."},
{t:"(x − 150) + 300 = 800. x ni toping.",o:["650","350","500","950"],k:0,s:"x − 150 = 500, x = 650."},
{t:"700 − (x + 200) = 150. x ni toping.",o:["350","550","650","250"],k:0,s:"x + 200 = 700 − 150 = 550, x = 350."},
{t:"Bir songa 236 qo'shilsa 1000 chiqadi. Son nechaga teng?",o:["764","1236","864","774"],k:0,s:"1000 − 236 = 764."},
{t:"O'ylangan sondan 345 ayirib, natijaga 120 qo'shilsa 500 chiqdi. Son nechaga teng?",o:["725","35","965","625"],k:0,s:"500 − 120 = 380, 380 + 345 = 725."},
{t:"Savatda bir necha olma bor edi. 125 tasi olindi, keyin 60 tasi qo'shildi va 410 ta bo'ldi. Boshida nechta edi?",o:["475","345","595","535"],k:0,s:"410 − 60 = 350, 350 + 125 = 475."},
{t:"x + x = 840. x ni toping.",o:["420","840","410","1680"],k:0,s:"Ikki teng qism 840: x = 840 : 2 = 420."},
{t:"x − 250 = 250 bo'lsa, 250 − y = 250 bo'lsa, x + y nechaga teng?",o:["500","250","0","750"],k:0,s:"x = 500, y = 0. x + y = 500."},
{t:"Tarozida: chapda x va 300 g, o'ngda 500 g va 450 g. x nechaga teng?",o:["650 g","1250 g","150 g","750 g"],k:0,s:"x + 300 = 950, x = 650."},
{t:"a + 375 = 600 va b − 375 = 600. b − a nechaga teng?",o:["750","225","975","375"],k:0,s:"a = 225, b = 975. 975 − 225 = 750."},
{t:"Qaysi tenglamada x = 280 emas?",o:["x − 140 = 140 + 140","x + 220 = 500","500 − x = 220","x − 220 = 60"],k:0,s:"x − 140 = 280 → x = 420. Qolganlarida x = 280."},
{t:"Kitobning 386 beti o'qildi, 214 bet qoldi. Agar yana 99 bet o'qilsa, necha bet qoladi?",o:["115","313","485","214"],k:0,s:"Qolgan 214 − 99 = 115."}
];
function PRACT_STAGE(){bqBar(830,[{v:'560',w:560},{v:'x',w:270,q:1}],{title:'Butun va qismlar'});bqMsg('x butunmi yoki qismmi? — avval shuni aniqlang')}
var PREP_DATA={teach:["Qo'shish va ayirish komponentlari: nomlari va o'zaro bog'liqligi.","Noma'lum qo'shiluvchi, kamayuvchi, ayriluvchini chizma model bilan topish.","Tarozi usuli; qavsli tenglamalar.","Matndan tenglama: oxiridan boshlab teskari amallar."],
 mist:["x − 286 = 457 da 457 − 286 qiladi («minus bor — ayiraman»).","Qavsli tenglamada faqat birinchi qadamni bajaradi.","Kamayuvchi va ayriluvchi nomlarini adashtiradi.","Tekshirmaydi."],
 need:["Qog'oz tasmalar (chizma model uchun).","Ikki pallali tarozi yoki uning rasmi."],
 board:["<span class='w2'>qo'shiluvchi + qo'shiluvchi = yig'indi</span>","<span class='w2'>kamayuvchi − ayriluvchi = ayirma</span>","Chizma: <span class='w2'>[ 560 | x ] = 830</span>","x — qism → ayiramiz; x — butun → qo'shamiz.","<span class='w2'>(x + 125) − 300 = 480 → x + 125 = 780 → x = 655</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<n)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=Math.max(W*p/tot,34);E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,p+' · '+b+' = '+(p*b),{'font-size':w<70?10:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
