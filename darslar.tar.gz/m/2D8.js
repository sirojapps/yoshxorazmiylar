var CODE='2D8',TITLE='2-sinf · Rasm va sxema bo‘yicha masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval chizish: rows = [[...],[...]], hl = {r:..,c:..}
function bm8tab(title,rows,hl,colw){clear();var g=S.g,n=rows[0].length,W=340,cw=colw||rows[0].map(function(){return W/n}),rh=Math.min(28,(150-(title?18:0))/rows.length),y0=title?24:10;if(title)T(g,180,16,title,{'font-size':12,'font-weight':800,fill:C.blue});
 rows.forEach(function(r,i){var x=10;r.forEach(function(v,j){var on=hl&&hl.some(function(h){return h[0]===i&&h[1]===j});E('rect',{x:x,y:y0+i*rh,width:cw[j],height:rh,fill:on?C.hi:(i===0?'#e8f1fb':'#fff'),stroke:'#c9d3dd'},g);T(g,x+cw[j]/2,y0+i*rh+rh/2+4,String(v),{'font-size':12,'font-weight':i===0||on?800:600,fill:'#1d2b3a'});x+=cw[j]})})}
// ustunli diagramma: data [[nom,qiymat]], step — shkala qadami
function bm8chart(title,data,max,step,hl,showv){clear();var g=S.g,x0=40,y0=150,H=112,W=300,bw=W/data.length*.55;T(g,180,16,title,{'font-size':12,'font-weight':800,fill:C.blue});
 for(var v=0;v<=max;v+=step){var y=y0-v/max*H;E('line',{x1:x0,y1:y,x2:x0+W,y2:y,stroke:'#e1e7ee'},g);T(g,x0-6,y+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#5b6b7b'})}
 E('line',{x1:x0,y1:y0,x2:x0+W,y2:y0,stroke:'#33475b','stroke-width':1.5},g);E('line',{x1:x0,y1:y0,x2:x0,y2:y0-H-6,stroke:'#33475b','stroke-width':1.5},g);
 S.bars8=[];data.forEach(function(d,i){var x=x0+(i+.5)*W/data.length-bw/2,h=d[1]/max*H,on=hl&&hl.indexOf(i)>=0;var r=E('rect',{x:x,y:y0-h,width:bw,height:h,fill:on?C.hi:[C.b,C.a,BMC.g,C.c][i%4],stroke:C.line,'stroke-width':1.2,style:'cursor:pointer'},g);r._i=i;S.bars8.push(r);T(g,x+bw/2,y0+14,d[0],{'font-size':11,'font-weight':700});if(showv&&showv.indexOf(i)>=0){E('line',{x1:x0,y1:y0-h,x2:x,y2:y0-h,stroke:C.bad,'stroke-dasharray':'4 3'},g);T(g,x+bw/2,y0-h-5,String(d[1]),{'font-size':12,'font-weight':800,fill:C.bad})}})}
// yo'l sxemasi
function bm8road(lab){clear();var g=S.g,P=[[40,120,'Gulzor'],[180,46,'Bog‘ishamol'],[320,120,'Yangiobod']];E('path',{d:'M40 120 L180 46 L320 120',fill:'none',stroke:'#8a7a60','stroke-width':5,'stroke-linecap':'round'},g);
 P.forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:8,fill:C.blue,stroke:'#fff','stroke-width':2},g);T(g,p[0],p[1]+(p[1]>100?26:-14),p[2],{'font-size':12,'font-weight':800})});
 T(g,96,74,'65 km',{'font-size':13,'font-weight':800,fill:C.a2});T(g,264,74,lab||'? km',{'font-size':13,'font-weight':800,fill:lab?C.ok:C.bad});T(g,180,150,'jami yo‘l: 105 km',{'font-size':12,'font-weight':700,fill:'#33475b'})}
var BUS=[['Jo‘nash','8:15','8:35','9:00','9:20']];
var CH=[['2-A',20],['2-B',30],['2-D',20]];
var R8=[function(){bm8road();calc(['Gulzor → Bog‘ishamol: 65 km. Jami yo‘l: 105 km'])},function(){bm8road('? km');calc(['Bog‘ishamol → Yangiobod: 105 − 65 = ?'])},function(){bm8road('40 km');calc(['105 − 65 = <b>40</b> km'])}];
var STEPS=[
bmStep({h:"Jadvaldan ma'lumot olamiz",sum:"Avtobus 8:15, 8:35, 9:00 da. 8:40 da kelgan Ali 9:00 dagi avtobusni 20 daqiqa kutadi.",a:"m01",frames:[{}],
 start:function(){bm8tab('Avtobus jo‘nash vaqtlari',[['1-avtobus','2-avtobus','3-avtobus','4-avtobus'],['8:15','8:35','9:00','9:20']]);calc(['Ali bekatga 8:40 da keldi. Qaysi avtobusga ulguradi?'])},
 fin:function(){bm8tab('Avtobus jo‘nash vaqtlari',[['1-avtobus','2-avtobus','3-avtobus','4-avtobus'],['8:15','8:35','9:00','9:20']],[[1,2]]);calc(['8:35 ketib bo‘lgan, navbatdagisi — <b>9:00</b>','8:40 dan 9:00 gacha — <b>20 daqiqa</b>'])},
 html:"<p>Jadval — ma'lumotlarni tartib bilan saqlaydi. Ali bekatga <b>8:40</b> da keldi. U qaysi avtobusga chiqadi? Jadvaldagi katakni tanlang:</p>",
 btns:bmPick(["8:35","9:00","9:20"],1,null,["8:35 da avtobus ketib bo‘lgan — Ali 8:40 da keldi.","","9:20 dan oldin 9:00 dagi avtobus bor-ku."]),
 after:"<p>8:35 dagi avtobus ketib bo'lgan. Navbatdagisi — <b>9:00</b>. Kutish: 8:40 dan 9:00 gacha <b>20 daqiqa</b>.</p>",
 q:{t:"Ali 8:40 da keldi. U navbatdagi avtobusni necha daqiqa kutadi?",opts:["25","20","5","15"],ok:1,why:"8:40 → 9:00 — 20 daqiqa.",hint:"Navbatdagi avtobus soat nechada? 8:40 dan unga qancha qoladi?",full:"Navbatdagi avtobus — 9:00. 8:40 dan 9:00 gacha: 20 daqiqa. «5» — 8:35 bilan solishtirish xatosi (u ketib bo'lgan)."},
 tn:"Maktab dars jadvali yoki avtobus jadvali bilan ishlang — haqiqiy ma'lumot qiziqroq."}),
bmStep({h:"Diagrammani o'qiymiz",sum:"Ustun balandligini chap shkaladan o'qiymiz: 2-A — 20, 2-B — 30, 2-D — 20 kg.",a:"m02",frames:[{}],
 start:function(){bm8chart('Sinflar yig‘gan qog‘oz (kg)',CH,40,10);calc(['Ustunlarni bosing — qiymati ko‘rinadi']);S.seen8={};S.bars8.forEach(function(r){r.addEventListener('click',function(){S.seen8[r._i]=1;bm8chart('Sinflar yig‘gan qog‘oz (kg)',CH,40,10,null,Object.keys(S.seen8).map(Number));bm8rebind();calc(['Ko‘rildi: '+Object.keys(S.seen8).map(function(i){return CH[i][0]+' — '+CH[i][1]+' kg'}).join(', ')]);if(Object.keys(S.seen8).length===3&&S.d8)S.d8()})})},
 fin:function(){bm8chart('Sinflar yig‘gan qog‘oz (kg)',CH,40,10,null,[0,1,2]);calc(['2-A — 20 kg, 2-B — 30 kg, 2-D — 20 kg'])},
 act:function(c,done){S.d8=function(){S.d8=null;done()};c.querySelector('.hint').textContent='Diagrammadagi 3 ta ustunni bosing.'},
 html:"<p><b>Ustunli diagramma</b> — sonlarni ustunlar bilan ko'rsatadi. Ustunning qiymatini bilish uchun uning uchidan <b>chap shkalaga</b> qarang. Har ustunni bosing:</p>",
 after:"<p>Diagramma bir qarashda kim ko'p, kim kam ekanini ko'rsatadi: 2-B eng ko'p yig'gan. Aniq sonni shkala beradi.</p>",
 q:{t:"2-B sinf yig'gan qog'oz qolgan ikki sinf birgalikda yig'gandan necha kg kam?",opts:["5 kg","10 kg","15 kg","20 kg"],ok:1,why:"20 + 20 = 40, 40 − 30 = 10 kg.",hint:"Avval 2-A va 2-D ni qo'shing.",full:"Qolgan ikki sinf: 20 + 20 = 40 kg. 2-B: 30 kg. Farq: 40 − 30 = 10 kg."},
 tn:"Bolalar sinfdagi bitta savol bo'yicha (sevimli meva) o'zi diagramma chizsin."}),
bmStep({h:"Yo'l sxemasi",sum:"Jami 105 km, Gulzor–Bog'ishamol 65 km → Bog'ishamol–Yangiobod 40 km; farq 25 km.",a:"m03",frames:[{}],
 start:function(){startPh(R8)},fin:function(){S.ph=2;R8[2]()},btns:[phaser(R8)],
 html:"<p>Sxemada uch qishloq va ular orasidagi yo'l. Bir bo'lagi noma'lum. Kuzating.</p>",
 after:"<p>Sxemadagi ma'lumotlar — masala sharti. Ularni <b>chizma</b>ga aylantirsak, masala oddiy bo'lib qoladi.</p>",
 q:{t:"Bog'ishamoldan Yangiobodgacha yo'l Gulzordan Bog'ishamolgacha yo'ldan necha km qisqa?",opts:["40 km","25 km","105 km","15 km"],ok:1,why:"65 − 40 = 25 km.",hint:"Avval noma'lum bo'lakni toping, keyin ikkala bo'lakni solishtiring.",full:"Bog'ishamol–Yangiobod: 105 − 65 = 40 km. Farq: 65 − 40 = 25 km. «40» — bo'lakning o'zi, farq emas."},
 tn:"Qishloq xaritasini chizib, haqiqiy masofalar bilan masala tuzing."}),
bmStep({h:"Rasmdan chizmaga",sum:"80 o'quvchi: rasm 45, musiqa 18, qolgani kulolchilik — 80 − 63 = 17.",a:"m04",
 frames:[{t:'To‘garaklarda 80 o‘quvchi: rasm 45, musiqa 18, qolgani kulolchilik',bars:[{y:66,segs:[{w:45,txt:'45 rasm',c:'a'},{w:18,txt:'18',c:'b'},{w:17,txt:'?',c:'q'}]}],br:[{b:0,lab:'80',up:true}],note:'Rasmdagi ma’lumotni chizmaga ko‘chirdik'},
  {t:'To‘garaklarda 80 o‘quvchi: rasm 45, musiqa 18, qolgani kulolchilik',bars:[{y:66,segs:[{w:45,txt:'45 rasm',c:'a'},{w:18,txt:'18',c:'b'},{w:17,txt:'17',c:'g'}]}],br:[{b:0,lab:'80',up:true}],calc:['1) 45 + 18 = 63','2) 80 − 63 = <b>17</b> o‘quvchi']}],
 html:"<p>Rasm yoki plakatdagi ma'lumotni chizmaga ko'chiramiz. Kuzating.</p>",
 after:"<p>Rasm — ma'lumot manbai, chizma — yechish vositasi. Har doim kerakli sonlarni rasmdan chizmaga ko'chiring.</p>",
 q:{t:"Uch bola jami 120 ochko to'pladi. Sardor 34 ochko, Anvar va Nodir teng to'plashdi. Anvar nechta ochko to'plagan?",opts:["40","43","86","77"],ok:1,why:"120 − 34 = 86, 86 : 2 = 43.",hint:"Avval Anvar va Nodir birgalikda qancha to'plaganini toping.",full:"Anvar + Nodir = 120 − 34 = 86. Ular teng: 86 : 2 = 43. «40» — 120 ni 3 ga bo'lish (Sardorni ham teng deb olish) xatosi."},
 tn:"Bolalarga gazeta yoki jurnaldan oddiy infografika topib kelishni topshiring."}),
bmStep({h:"Narxlar jadvali va o'zgarish",sum:"Ko'ylak 45, kepka 35; har biri 10 ming arzonlashdi: 35 + 25 = 60 ming.",a:"m05",frames:[{}],
 start:function(){bm8tab('Narxlar (ming so‘m)',[['Kiyim','Ko‘ylak','Kepka','Shim'],['Narx','45','35','60']]);calc(['Bugun har bir kiyim 10 ming arzonlashdi'])},
 fin:function(){bm8tab('Narxlar (ming so‘m)',[['Kiyim','Ko‘ylak','Kepka','Shim'],['Narx','45','35','60'],['Bugun','35','25','50']],[[2,1],[2,2]]);calc(['Ko‘ylak 45 − 10 = 35, kepka 35 − 10 = 25','Birgalikda: 35 + 25 = <b>60</b> ming'])},
 btns:[["📉 Arzonlashtirish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 html:"<p>Jadvalda kiyimlar narxi. Bugun <b>har bir</b> kiyim 10 ming so'mga arzonlashdi. Tugmani bosing — yangi qator qo'shiladi.</p>",
 after:"<p>Ikki usul: har birini arzonlashtirib qo'shish (35 + 25 = 60) yoki avval qo'shib, keyin ikki marta 10 ni ayirish (80 − 20 = 60). Xato: 80 − 10 = 70 — chegirma <b>har biriga</b> berilgan!</p>",
 q:{t:"Shim va kepka bugun birgalikda qancha turadi?",opts:["85 ming","75 ming","95 ming","65 ming"],ok:1,why:"50 + 25 = 75 ming.",hint:"Bugungi narxlar qatoriga qarang.",full:"Bugun shim 50, kepka 25: 50 + 25 = 75 ming. «85» — faqat bittasiga chegirma qilish xatosi (60 + 35 − 10)."},
 tn:"Bolalar sinf do'koni uchun o'z narxlar jadvalini tuzsin."}),
bmStep({h:"Tuzoq: shkala qadami",sum:"Shkala 5 dan emas, 10 dan bo'lsa — ustun o'rtasi 25 yoki 35 ni bildiradi.",a:"m06",frames:[{}],
 start:function(){bm8chart('Kitoblar soni',[['Ali',25],['Vali',35],['Sardor',20]],40,10);calc(['Shkala qadami — 10. Alining ustuni chiziqlar orasida!'])},
 fin:function(){bm8chart('Kitoblar soni',[['Ali',25],['Vali',35],['Sardor',20]],40,10,null,[0,1,2]);calc(['Ali — 25 (20 bilan 30 ning o‘rtasi), Vali — 35, Sardor — 20'])},
 html:"<p>Ba'zan ustun shkala chiziqlari <b>orasida</b> tugaydi. Unda uning qiymati — ikki chiziq <b>o'rtasi</b>. Alining ustuni nechani ko'rsatadi?</p>",
 btns:bmPick(["20","25","30"],1,null,["Ustun 20 chizig‘idan yuqoriroq tugagan.","","Ustun 30 chizig‘iga yetmagan."]),
 after:"<p>20 va 30 ning o'rtasi — <b>25</b>. Diagrammani o'qishdan oldin doim shkala <b>qadamini</b> tekshiring: 1 lab, 5 lab yoki 10 labmi?</p>",
 q:{t:"Vali Alidan nechta ko'p kitob o'qigan?",opts:["15","10","5","60"],ok:1,why:"35 − 25 = 10.",hint:"Ikkala ustun qiymatini aniq o'qing (o'rtalarini ham).",full:"Vali 35, Ali 25: 35 − 25 = 10. «15» — Alini 20 deb o'qish xatosi."},
 tn:"Shkalasi har xil (1, 2, 5, 10) diagrammalarni solishtiring."}),
bmStep({h:"Bilasizmi? Diagrammani kim o'ylab topgan?",sum:"Ustunli diagrammani 1786-yilda shotlandiyalik Uilyam Pleyfer ixtiro qilgan.",a:"m07",frames:[{}],
 start:function(){bm8chart('1786 · Uilyam Pleyfer',[['',12],['',28],['',20],['',34]],40,10);calc(['Birinchi ustunli diagramma — savdo ma’lumotlari uchun'])},fin:function(){bm8chart('1786 · Uilyam Pleyfer',[['',12],['',28],['',20],['',34]],40,10);calc(['Birinchi ustunli diagramma — savdo ma’lumotlari uchun'])},
 html:"<p>📊 Ustunli diagrammani <b>1786-yilda</b> shotlandiyalik <b>Uilyam Pleyfer</b> o'ylab topgan. U mamlakatlar o'rtasidagi savdoni ko'rsatish uchun sonlarni ustunlar bilan chizgan.</p><p>Bugun diagrammalar ob-havo, sport, yangiliklar — hamma joyda. Ularni o'qiy olish — muhim hayotiy ko'nikma.</p>",
 tn:"Televizor yoki gazetadagi diagrammalarni sinfda muhokama qiling."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m08",memo:1,frames:[{}],start:function(){bm8chart('Diagramma',CH,40,10,null,[0,1,2]);calc(['Ustun uchidan chap shkalaga qarang'])},fin:function(){bm8chart('Diagramma',CH,40,10,null,[0,1,2]);calc(['Ustun uchidan chap shkalaga qarang'])},
 html:"<div class='memo'><ul><li><b>Jadval</b>: kerakli qator va ustun kesishgan katakni toping.</li><li><b>Diagramma</b>: ustun uchidan chap shkalaga qarang. Avval shkala <b>qadamini</b> tekshiring.</li><li>Ustun chiziqlar orasida bo'lsa — qiymat ikki chiziqning <b>o'rtasi</b>.</li><li><b>Sxema</b> (yo'l, xarita): noma'lum bo'lakni butundan toping.</li><li>Rasmdagi sonlarni <b>chizmaga</b> ko'chirib yeching.</li><li>Chegirma <b>har biriga</b> berilsa — har birini kamaytiring.</li></ul></div>",
 tn:"Keyingi darsni sinf o'quvchilarining tug'ilgan oylari bo'yicha birga diagramma tuzish bilan boshlang."})
];
function bm8rebind(){S.bars8.forEach(function(r){r.addEventListener('click',function(){S.seen8[r._i]=1;bm8chart('Sinflar yig‘gan qog‘oz (kg)',CH,40,10,null,Object.keys(S.seen8).map(Number));bm8rebind();calc(['Ko‘rildi: '+Object.keys(S.seen8).map(function(i){return CH[i][0]+' — '+CH[i][1]+' kg'}).join(', ')]);if(Object.keys(S.seen8).length===3&&S.d8)S.d8()})})}
var PROBS=[
{t:"Avtobuslar 8:15, 8:35, 9:00, 9:20 da jo'naydi. Ali bekatga 8:40 da keldi. U necha daqiqa kutadi?",o:["20","25","5","15"],k:0,s:"Navbatdagi — 9:00. 8:40 → 9:00 — 20 daqiqa."},
{t:"Diagrammada: 2-A 20 kg, 2-B 30 kg, 2-D 20 kg qog'oz. 2-B qolgan ikki sinfdan birgalikda necha kg kam?",o:["10 kg","5 kg","15 kg","20 kg"],k:0,s:"20 + 20 = 40, 40 − 30 = 10."},
{t:"Sxemada: Gulzor–Bog'ishamol 65 km, jami yo'l 105 km. Bog'ishamol–Yangiobod necha km?",o:["40 km","25 km","170 km","65 km"],k:0,s:"105 − 65 = 40 km."},
{t:"To'garaklarda 80 o'quvchi: rasm 45, musiqa 18, qolgani kulolchilik. Kulolchilikda nechta?",o:["17","27","35","63"],k:0,s:"45 + 18 = 63, 80 − 63 = 17."},
{t:"Uch bola jami 120 ochko to'pladi. Sardor 34, Anvar va Nodir teng. Anvar nechta ochko to'plagan?",o:["43","40","77","86"],k:0,s:"120 − 34 = 86, 86 : 2 = 43."},
{t:"Ko'ylak 45 ming, kepka 35 ming. Har biri 10 ming arzonlashdi. Ikkalasi birga qancha?",o:["60 ming","70 ming","80 ming","50 ming"],k:0,s:"35 + 25 = 60 ming."},
{t:"Diagramma shkalasi 10 dan. Alining ustuni 20 va 30 chiziqlarining o'rtasida. Ali nechta kitob o'qigan?",o:["25","20","30","15"],k:0,s:"20 va 30 ning o'rtasi — 25."},
{t:"Jadval: dushanba 12, seshanba 15, chorshanba 9 ta gul sotildi. Uch kunda jami nechta gul sotildi?",o:["36","27","24","35"],k:0,s:"12 + 15 + 9 = 36."},
{t:"Jadval: olma 8 ming, nok 10 ming (1 kg). 2 kg olma va 1 kg nok qancha?",o:["26 ming","18 ming","28 ming","20 ming"],k:0,s:"8 · 2 = 16, 16 + 10 = 26 ming."},
{t:"Piktogrammada ★ = 5 ta kitob. Alining qatorida ★★★★. Ali nechta kitob o'qigan?",o:["20","4","9","25"],k:0,s:"4 · 5 = 20."},
{t:"Piktogrammada ★ = 2 ta olma. Valining qatorida ★★★ va yarim yulduz. Vali nechta olma tergan?",o:["7","6","3","8"],k:0,s:"3 · 2 = 6, yarim yulduz — 1 ta: 7."},
{t:"Termometr ertalab 8°, tushda 17° ko'rsatdi. Harorat necha darajaga ko'tarildi?",o:["9","25","8","11"],k:0,s:"17 − 8 = 9."},
{t:"Dars jadvali: 1-dars 8:00 da boshlanadi, har dars 45 daqiqa, tanaffus 10 daqiqa. 2-dars soat nechada boshlanadi?",o:["8:55","8:45","9:00","8:50"],k:0,s:"8:00 + 45 = 8:45, + 10 = 8:55."},
{t:"Diagrammada: Ali 30, Vali 15, Sardor 25 ochko. Eng ko'p va eng kam to'plaganlar farqi?",o:["15","10","5","45"],k:0,s:"30 − 15 = 15."},
{t:"Sxema: uydan maktabgacha 300 m, maktabdan kutubxonagacha 450 m. Uydan maktab orqali kutubxonagacha?",o:["750 m","150 m","450 m","700 m"],k:0,s:"300 + 450 = 750 m."},
{t:"Jadval: 2-A da 26, 2-B da 24, 2-D da 25 o'quvchi. Qaysi sinfda eng ko'p o'quvchi?",o:["2-A","2-B","2-D","hammasida teng"],k:0,s:"26 eng katta — 2-A."},
{t:"Diagrammada har sinf ustuni: 2-A 18, 2-B 22. Ikki sinf birga nechta daraxt ekkan?",o:["40","4","30","44"],k:0,s:"18 + 22 = 40."},
{t:"Jadvalda jami 50 ta shar: qizil 18, ko'k 14, qolgani yashil. Yashil sharlar nechta?",o:["18","32","14","22"],k:0,s:"18 + 14 = 32, 50 − 32 = 18."},
{t:"Rasmda 4 ta qutida 6 tadan olma. 5 ta olma yeyildi. Nechta olma qoldi?",o:["19","24","15","29"],k:0,s:"6 · 4 = 24, 24 − 5 = 19."},
{t:"Diagramma: dushanba 10, seshanba 20, chorshanba 15 kitob berildi. Seshanba dushanbadan necha marta ko'p?",o:["2 marta","10 marta","3 marta","1 marta"],k:0,s:"20 : 10 = 2 marta."}
];
function PRACT_STAGE(){bm8chart('Diagramma va jadval — ma’lumot manbai',CH,40,10,null,[0,1,2]);calc(['Avval shkalani tekshiring'])}
var PREP_DATA={teach:["Jadvaldan ma'lumot olish (qator va ustun).","Ustunli diagrammani o'qish, shkala qadami.","Yo'l sxemasi, rasm va infografikadan chizmaga o'tish.","Narxlar jadvali va o'zgarish (chegirma)."],
 mist:["Jadvaldan o'tib ketgan vaqtni tanlaydi (8:35).","Shkala qadamini tekshirmaydi, chiziqlar orasidagi qiymatni noto'g'ri o'qiydi.","Chegirmani faqat bitta narsaga qo'llaydi.","Sxemadagi bo'lakni farq bilan aralashtirib yuboradi."],
 need:["Haqiqiy avtobus/dars jadvali, gazetadagi diagramma."],
 board:["Jadval: <span class='w2'>8:15 | 8:35 | 9:00 | 9:20</span>.","Diagramma: shkala 0–40, qadam 10.","Sxema: <span class='w2'>65 + ? = 105</span>.","Chegirma: <span class='w2'>(45 − 10) + (35 − 10) = 60</span>."]};
