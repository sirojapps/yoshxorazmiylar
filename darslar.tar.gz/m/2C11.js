// --- k2c11_ yordamchilari ---
function k2c11_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c11_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c11_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c11_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C11',TITLE='2-sinf · Ko‘paytirish xossalari, nolning xossalari';
function k2c11_boxes(n,per,lbl){clear();var g=S.g,w=Math.min(64,320/Math.max(n,1));var x0=180-w*n/2;
 if(n===0){E('rect',{x:130,y:40,width:100,height:70,rx:10,fill:'none',stroke:'#c9d3dd','stroke-width':2,'stroke-dasharray':'6 4'},g);T(g,180,82,'quti yo‘q',{'font-size':14,fill:'#9aa8b6','font-weight':800})}
 for(var i=0;i<n;i++){var x=x0+i*w;E('rect',{x:x+3,y:40,width:w-6,height:70,rx:8,fill:'#fff7ea',stroke:C.line,'stroke-width':1.5},g);
  for(var j=0;j<per;j++)E('circle',{cx:x+12+(j%3)*((w-24)/2),cy:54+Math.floor(j/3)*14,r:5,fill:C.a,stroke:'rgba(0,0,0,.15)'},g);if(per===0)T(g,x+w/2,80,'bo‘sh',{'font-size':10,fill:'#9aa8b6'})}
 if(lbl)T(g,180,146,lbl,{'font-size':14,'font-weight':800,fill:C.blue})}
var P2=[function(){k2c11_cube(2,3,4,0);k2c11_big('2 · 3 · 4 = ?','Qutida 2 qavat, har qavatda 3 × 4 ta kubik')},
 function(){k2c11_cube(2,3,4,1);k2c11_big('(2 · 3) · 4 = 6 · 4 = <b>24</b>','Avval old tomoni: 2 · 3 = 6 ta ustun, har birida 4 ta')},
 function(){k2c11_cube(2,3,4,2);k2c11_big('2 · (3 · 4) = 2 · 12 = <b>24</b>','Yoki avval qavat: 3 · 4 = 12, ikki qavat')}];
var P5=[function(){k2c11_big('2 · 3 · 4 · 5 · 11 = ?','Ketma-ket ko‘paytirish qiyin. Juftlarni qidiramiz!');clear();k2c11_chips([2,3,4,5,11],[])},
 function(){clear();k2c11_chips([2,3,4,5,11],[[0,3]]);k2c11_big('2 · 5 = <b>10</b>','Juftlab qo‘yamiz — 10 chiqadigan juft')},
 function(){clear();k2c11_chips([2,3,4,5,11],[[0,3],[1,2]]);k2c11_big('10 · 12 · 11','3 · 4 = 12')},
 function(){clear();k2c11_chips([2,3,4,5,11],[[0,3],[1,2]]);k2c11_big('10 · 12 = 120, 120 · 11 = <b>1320</b>')}];
var P6=[function(){k2c11_big('360 : (5 · 6) = ?','Qavs ichida ko‘paytma — bu ikki marta bo‘lish demak')},
 function(){k2c11_big('360 : (5 · 6) = 360 : 30 = <b>12</b>','Usul 1: avval qavs')},
 function(){k2c11_big('360 : 5 : 6 = 72 : 6 = <b>12</b> ✓','Usul 2: avval 5 ga, keyin 6 ga bo‘lamiz — xuddi shu!')},
 function(){k2c11_big('360 : 5 · 6 = 72 · 6 = <b>432</b> ✗','Qavssiz yozsak — boshqa narsa: bo‘lib, keyin KO‘PAYTIRAMIZ')}];
var STEPS=[
{h:"O'rin almashtirish xossasi",sum:"a · b = b · a: 3 · 5 = 5 · 3 = 15. Massivni burab qo'ysak, nuqtalar soni o'zgarmaydi.",a:"m01",
 start:function(){S.rot=0;k2c11_arr(3,5,{lbl:'3 qator × 5 = 15'})},fin:function(){k2c11_arr(5,3,{lbl:'5 qator × 3 = 15'})},
 html:"<p>Massivni buramiz: qatorlar ustunga aylanadi. Nuqtalar soni o'zgaradimi?</p>",
 btns:[["↻ Burab qo'y",function(c,d){S.rot=1-S.rot;if(S.rot)k2c11_arr(5,3,{lbl:'5 qator × 3 = 15'});else k2c11_arr(3,5,{lbl:'3 qator × 5 = 15'});k2c11_big('3 · 5 = 5 · 3 = 15');d()}]],
 after:"<p>Nuqtalar <b>o'sha-o'sha</b> — 15 ta. Ko'paytuvchilarning o'rni almashsa, ko'paytma o'zgarmaydi: <b>a · b = b · a</b>. Qulay: 9 · 2 ni 2 · 9 deb hisoblash osonroq.</p>",
 q:{t:"8 · 7 = 56. 7 · 8 nechaga teng?",opts:["56","15","54","78"],ok:0,why:"O'rin almashtirish xossasi.",hint:"Massivni burasak nima o'zgaradi?",full:"7 · 8 = 8 · 7 = 56. Ko'paytuvchilar o'rni almashsa, ko'paytma o'zgarmaydi."},
 tn:"Bolalar bir varaqqa 3×5 massiv chizib, varaqni burab ko'rsin."},
{h:"Guruhlash xossasi",sum:"(2 · 3) · 4 = 2 · (3 · 4) = 24. Qaysi juftni avval ko'paytirsak ham natija bir xil.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Kubiklardan quti yasaldi: <b>2 qavat</b>, har qavatda <b>3 qator</b>, har qatorda <b>4 ta</b>. Nechta kubik? Ikki xil hisoblaymiz.</p>",btns:[phaser(P2)],
 after:"<p>Uchta sonni ko'paytirganda, <b>qaysi ikkitasini avval</b> ko'paytirsak ham natija bir xil: (2 · 3) · 4 = 2 · (3 · 4). Bu — <b>guruhlash</b> xossasi. U bizga qulay juftni tanlash imkonini beradi.</p>",
 q:{t:"5 · 7 · 2 ni qulay usulda hisoblang.",opts:["70","35","14","72"],ok:0,why:"5 · 2 = 10, 10 · 7 = 70.",hint:"Qaysi ikkitasi birga 10 beradi?",full:"O'rin almashtirib guruhlaymiz: (5 · 2) · 7 = 10 · 7 = 70. «35» — faqat 5 · 7, «14» — 7 · 2."},
 tn:"Kubiklardan quti yasab ko'rsating. Bu xossa yuqori sinfda hajmni topishda ham kerak bo'ladi."},
{h:"1 bilan amallar",sum:"a · 1 = a, a : 1 = a, a : a = 1.",a:"m03",
 start:function(){k2c11_boxes(1,5,'1 quti, 5 tadan: 5 · 1 = 5')},fin:function(){k2c11_boxes(5,1,'5 quti, 1 tadan: 5')},
 html:"<p>1 bilan nima bo'ladi? Tugmalarni bosib ko'ring:</p>",
 btns:[["5 · 1",function(c,d){k2c11_boxes(1,5,'1 marta 5 ta: 5 · 1 = 5');k2c11_big('5 · 1 = <b>5</b> — o‘zi qoladi');mvK(d,3)}],["5 : 1",function(c,d){k2c11_boxes(1,5,'5 tani 1 kishiga: hammasi unga');k2c11_big('5 : 1 = <b>5</b>');mvK(d,3)}],["5 : 5",function(c,d){k2c11_boxes(5,1,'5 tani 5 kishiga: har biriga 1');k2c11_big('5 : 5 = <b>1</b>');mvK(d,3)}]],
 after:"<p><b>1 ga ko'paytirsak yoki 1 ga bo'lsak — son o'zgarmaydi.</b> Sonni o'ziga bo'lsak — <b>1</b> chiqadi (0 dan boshqa son).</p>",
 q:{t:"48 : 48 · 1 nechaga teng?",opts:["48","1","0","96"],ok:1,why:"48 : 48 = 1, 1 · 1 = 1.",hint:"Chapdan o'ngga: avval 48 : 48.",full:"48 : 48 = 1, keyin 1 · 1 = 1. «48» — 48 · 1 deb o'ylangan, lekin avval bo'lish bajariladi."},
 tn:"«1 — o'zgartirmaydigan son» degan iborani doskaga yozing."},
{h:"Nol bilan ko'paytirish va bo'lish",sum:"a · 0 = 0, 0 · a = 0, 0 : a = 0. Nolga bo'lish MUMKIN EMAS.",a:"m04",
 start:function(){k2c11_boxes(0,4,'0 ta quti — 4 tadan: hech narsa')},fin:function(){k2c11_boxes(0,4,'0 · 4 = 0')},
 html:"<p>Nol eng ayyor son. Har bir holatni sinab ko'ring:</p>",
 btns:[["0 · 4",function(c,d){k2c11_boxes(0,4,'0 ta quti, 4 tadan: 0 · 4 = 0');k2c11_big('0 · 4 = <b>0</b>');mvK(d,4)}],["4 · 0",function(c,d){k2c11_boxes(4,0,'4 ta quti, ichi bo‘sh: 4 · 0 = 0');k2c11_big('4 · 0 = <b>0</b>');mvK(d,4)}],["0 : 4",function(c,d){k2c11_boxes(4,0,'0 ta olmani 4 kishiga: hech kimga yo‘q');k2c11_big('0 : 4 = <b>0</b>');mvK(d,4)}],["4 : 0",function(c,d){k2c11_boxes(0,4,'4 ta olmani 0 kishiga bo‘lib bo‘lmaydi!');k2c11_big('4 : 0 — <b style="color:#d94b4b">ma’nosi yo‘q, mumkin emas</b>');mvK(d,4)}]],g2:1,
 after:"<p><b>Nolga ko'paytirsak — 0.</b> <b>Nolni bo'lsak — 0.</b> Lekin <b>nolga bo'lish mumkin emas</b>: 4 ta olmani «hech kimga» bo'lib bo'lmaydi — savolning o'zi ma'nosiz.</p>",
 q:{t:"Qaysi ifodaning qiymati 0 EMAS?",opts:["0 : 9","9 · 0","9 : 9","0 · 0"],ok:2,why:"9 : 9 = 1.",hint:"Sonni o'ziga bo'lsak nima chiqadi?",full:"0 : 9 = 0, 9 · 0 = 0, 0 · 0 = 0. Lekin 9 : 9 = 1 — sonni o'ziga bo'lsak 1 chiqadi."},
 tn:"Nolga bo'lishni «mumkin emas» deb qisqa aytmang — olmalar misolida ma'nosizligini ko'rsating."},
{h:"Tuzoq: qulay juftlarni topamiz",sum:"2 · 3 · 4 · 5 · 11 = (2 · 5)(3 · 4) · 11 = 10 · 12 · 11 = 1320.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Bank savoli: <b>2 · 3 · 4 · 5 · 11</b> ni qulay usulda hisoblang. Ikki xossani birga ishlatamiz: o'rin almashtirish va guruhlash.</p>",btns:[phaser(P5)],
 after:"<p>Usul: avval <b>10 beradigan juftni</b> (2 va 5, 4 va 5 …) qidiring, keyin qolganlarini. Eng oxirida 10 ga ko'paytirish oson.</p>",
 q:{t:"25 · 7 · 4 ni qulay usulda hisoblang.",opts:["700","175","28","625"],ok:0,why:"25 · 4 = 100, 100 · 7 = 700.",hint:"25 ni nechaga ko'paytirsak 100 chiqadi?",full:"25 · 4 = 100 — juda qulay juft. 100 · 7 = 700. «175» — faqat 25 · 7."},
 tn:"«Do'st juftlar»: 2·5=10, 4·5=20, 25·4=100. Kartochka qilib bering."},
{h:"Tuzoq: qavs va bo'lish",sum:"360 : (5 · 6) = 360 : 5 : 6 = 12, lekin 360 : 5 · 6 = 432.",a:"m06",
 start:function(){clear();k2c11_chips2();startPh(P6)},fin:function(){clear();k2c11_chips2();S.ph=3;P6[3]()},
 html:"<p>Bank savoli: «Qaysi ifodaning qiymati <b>360 : (5 · 6)</b> ga teng EMAS?» Kuzating:</p>",btns:[phaser(P6)],
 after:"<p>Songa <b>ko'paytmani</b> bo'lish — ketma-ket <b>ikkala ko'paytuvchiga</b> bo'lish demak: 360 : (5 · 6) = 360 : 5 : 6 = 360 : 6 : 5. Qavssiz «360 : 5 · 6» esa — bo'lib, keyin ko'paytirish, natija boshqa.</p>",
 q:{t:"Qaysi ifodaning qiymati 480 : (2 · 6) ga teng?",opts:["(480 : 6) : 2","480 : 2 · 6","480 : 6 · 2","480 : 2 − 6"],ok:0,why:"Ko'paytmaga bo'lish = ikkala ko'paytuvchiga ketma-ket bo'lish: 480 : 6 : 2 = 40.",hint:"Qavs ichidagi ko'paytmaga bo'lish — har biriga bo'lish demak.",full:"480 : (2 · 6) = 480 : 12 = 40. (480 : 6) : 2 = 80 : 2 = 40 ✓. 480 : 2 · 6 = 1440, 480 : 6 · 2 = 160 — qavssiz ko'paytirib qo'yilgan."},
 tn:"Bu 3-sinf mavzusiga ko'prik. Bolalar ikkala usulda hisoblab, javobni solishtirsin."},
{h:"Bilasizmi? Nolning tarixi",sum:"Nol bilan hisoblash qoidalarini Hindiston olimi Braxmagupta 628-yilda yozgan; al-Xorazmiy ularni dunyoga tanitgan.",a:"m07",
 start:function(){clear();T(S.g,180,110,'0',{'font-size':90,'font-weight':800,fill:C.a2});k2c11_big('«Sifr» — bo\u2018sh')},fin:function(){clear();T(S.g,180,110,'0',{'font-size':90,'font-weight':800,fill:C.a2});k2c11_big('«Sifr» — bo\u2018sh')},
 html:"<p>📜 Uzoq vaqt odamlarda <b>nol</b> degan son bo'lmagan. Hindiston olimi <b>Braxmagupta</b> 628-yilda birinchilardan bo'lib nol bilan hisoblash qoidalarini yozgan: «sonni nolga ko'paytirsak — nol».</p><p>⭐ Hind raqamlari va nolni butun dunyoga tarqatgan kitob — vatandoshimiz <b>al-Xorazmiy</b>ning hisob kitobi. «Sifr» (nol) so'zi arabcha «bo'sh» degani.</p>",
 tn:"Bolalarga «nol — bo'sh joy belgisi va son» degan ikki ma'noni eslating (305 dagi 0)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){k2c11_arr(3,5,{lbl:'3 · 5 = 5 · 3'})},fin:function(){k2c11_arr(3,5,{lbl:'3 · 5 = 5 · 3'})},
 html:"<div class='memo'><ul><li><b>O'rin almashtirish:</b> a · b = b · a.</li><li><b>Guruhlash:</b> (a · b) · c = a · (b · c). Qulay juft: 2·5=10, 4·25=100.</li><li><b>1 bilan:</b> a · 1 = a, a : 1 = a, a : a = 1.</li><li><b>0 bilan:</b> a · 0 = 0, 0 : a = 0. <b>Nolga bo'lish mumkin emas!</b></li><li>Ko'paytmaga bo'lish: 360 : (5 · 6) = 360 : 5 : 6.</li></ul></div>",
 tn:"Keyingi darsda «0 · 1 · 2 · … · 9 nechaga teng?» deb so'rang (0)."}
];
function k2c11_chips(v,pairs){var g=S.g,cols=['#ffd24d','#bfe9e3'];v.forEach(function(n,i){var x=40+i*70,f='#fff';pairs.forEach(function(p,k){if(p.indexOf(i)>=0)f=cols[k]});E('circle',{cx:x,cy:80,r:24,fill:f,stroke:C.line,'stroke-width':2},g);T(g,x,89,String(n),{'font-size':22,'font-weight':800,fill:'#1d2b3a'});if(i<v.length-1)T(g,x+35,88,'·',{'font-size':22,'font-weight':800})})}
function k2c11_chips2(){T(S.g,180,90,'360 : (5 · 6)',{'font-size':32,'font-weight':800,fill:'#1d2b3a'})}
function k2c11_cube(l,r,c,mode){clear();var g=S.g,s=20;
 for(var k=0;k<l;k++){var ox=40+k*160,oy=36;T(g,ox+c*s/2,26,(k+1)+'-qavat',{'font-size':12,'font-weight':800,fill:C.blue});
  for(var i=0;i<r;i++)for(var j=0;j<c;j++){var f=mode===2&&k===0?C.hi:(mode===1?(i%2?'#7fb3e0':C.b):C.b);E('rect',{x:ox+j*s,y:oy+i*s,width:s-2,height:s-2,rx:3,fill:f,stroke:'#2c5d8a','stroke-width':.8},g)}
  if(mode===1)for(var i2=0;i2<r;i2++)T(g,ox+c*s+12,oy+i2*s+14,'4',{'font-size':10,fill:'#5b6b7b'})}
 T(g,180,140,mode===1?'2 · 3 = 6 ta qator, har birida 4 ta':(mode===2?'1 qavatda 3 · 4 = 12 ta, qavat 2 ta':l+' qavat · '+r+' qator · '+c+' ta'),{'font-size':12,'font-weight':800,fill:C.blue})}
var PROBS=[
{t:"9 · 0 nechaga teng?",o:["0","9","1","90"],k:0,s:"Nolga ko'paytirsak — 0."},
{t:"0 : 7 nechaga teng?",o:["0","7","1","bo'lib bo'lmaydi"],k:0,s:"Nolni bo'lsak — 0 (hech kimga hech narsa tegmaydi)."},
{t:"6 : 6 nechaga teng?",o:["1","0","6","36"],k:0,s:"Sonni o'ziga bo'lsak — 1."},
{t:"8 · 1 nechaga teng?",o:["8","1","9","0"],k:0,s:"1 ga ko'paytirsak — son o'zgarmaydi."},
{t:"Qaysi amalni bajarib bo'lmaydi?",o:["5 : 0","0 : 5","5 · 0","0 · 5"],k:0,s:"Nolga bo'lish mumkin emas."},
{t:"5 · 9 · 2 ni qulay usulda hisoblang.",o:["90","45","18","99"],k:0,s:"5 · 2 = 10, 10 · 9 = 90."},
{t:"4 · 8 · 25 ni qulay usulda hisoblang.",o:["800","32","200","100"],k:0,s:"4 · 25 = 100, 100 · 8 = 800."},
{t:"2 · 3 · 4 · 5 · 11 ni qulay usulda hisoblang.",o:["1320","1230","1210","1302"],k:0,s:"(2 · 5) · (3 · 4) · 11 = 10 · 12 · 11 = 1320."},
{t:"Qaysi ifodaning qiymati 360 : (5 · 6) ga teng EMAS?",o:["360 : 5 · 6","360 : 6 : 5","360 : 30","360 : 5 : 6"],k:0,s:"360 : 5 · 6 = 432, qolganlari 12."},
{t:"Qaysi ifodaning qiymati 480 : (2 · 6) ga teng?",o:["(480 : 6) : 2","480 : 2 · 6","480 : 6 · 2","480 : 2 − 6"],k:0,s:"480 : 6 : 2 = 40 = 480 : 12."},
{t:"0 · 1 · 2 · 3 · 4 · 5 · 6 · 7 · 8 · 9 nechaga teng?",o:["0","45","362880","9"],k:0,s:"Ko'paytuvchilar orasida 0 bor — natija 0."},
{t:"□ · 1 = 37 bo'lsa, □ nechaga teng?",o:["37","1","36","38"],k:0,s:"1 ga ko'paytirsak o'zgarmaydi: □ = 37."},
{t:"□ · 9 = 0 bo'lsa, □ nechaga teng?",o:["0","9","1","90"],k:0,s:"Ko'paytma 0 — demak □ = 0."},
{t:"(7 · 4) · 5 ni boshqacha yozing.",o:["7 · (4 · 5)","7 + (4 · 5)","(7 + 4) · 5","7 · 4 + 5"],k:0,s:"Guruhlash xossasi: (7 · 4) · 5 = 7 · (4 · 5) = 140."},
{t:"25 · 3 · 4 nechaga teng?",o:["300","75","100","700"],k:0,s:"25 · 4 = 100, 100 · 3 = 300."},
{t:"54 : 54 + 54 · 0 nechaga teng?",o:["1","0","54","55"],k:0,s:"54 : 54 = 1, 54 · 0 = 0, 1 + 0 = 1."},
{t:"Qutida 3 qavat, har qavatda 2 qator, har qatorda 5 tadan konfet. Nechta konfet?",o:["30","10","15","25"],k:0,s:"3 · (2 · 5) = 3 · 10 = 30."},
{t:"a · 6 = 6 · 8 bo'lsa, a nechaga teng?",o:["8","6","48","14"],k:0,s:"O'rin almashtirish: a · 6 = 8 · 6, a = 8."},
{t:"100 : (2 · 5) nechaga teng?",o:["10","250","50","20"],k:0,s:"100 : 10 = 10. Yoki 100 : 2 : 5 = 50 : 5 = 10."},
{t:"2 · 2 · 2 · 5 · 5 · 5 nechaga teng?",o:["1000","100","30","500"],k:0,s:"(2·5)(2·5)(2·5) = 10 · 10 · 10 = 1000."}
];
function PRACT_STAGE(){k2c11_arr(3,5,{lbl:'a · b = b · a'})}
var PREP_DATA={teach:["O'rin almashtirish va guruhlash xossalari; qulay juftlar.","1 bilan: a · 1 = a, a : 1 = a, a : a = 1.","0 bilan: a · 0 = 0, 0 : a = 0, nolga bo'lish mumkin emas.","Ko'paytmaga bo'lish: 360 : (5 · 6) = 360 : 5 : 6."],
 mist:["a · 0 = a deb o'ylaydi (0 ni «hech narsa qilmaydi» deb).","0 : a va a : 0 ni aralashtiradi.","a : a ni 0 deydi.","Qavssiz 360 : 5 · 6 ni 360 : 30 deb hisoblaydi."],
 need:["Kubiklar (quti yasash uchun).","Qutilar va olma/tugmalar.","«Do'st juftlar» kartochkalari."],
 board:["<span class='w2'>3 · 5 = 5 · 3</span>.","<span class='w2'>(2 · 3) · 4 = 2 · (3 · 4) = 24</span>.","<span class='w2'>a · 1 = a, a : a = 1</span>.","<span class='w2'>a · 0 = 0, 0 : a = 0, a : 0 — yo'q!</span>","<span class='w2'>2·3·4·5·11 = 10·12·11 = 1320</span>."]};
