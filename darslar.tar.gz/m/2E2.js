var CODE='2E2',TITLE='2-sinf · Vaqt: soat va minut';
// ---------- sahna: strelkali soat ----------
var e2T={h:3,m:0};
function e2Clock(h,m,o){o=o||{};clear();var g=S.g,cx=100,cy=87,R=72;e2T.h=h;e2T.m=m;
 E('circle',{cx:cx,cy:cy,r:R+5,fill:'#1f6fb2'},g);E('circle',{cx:cx,cy:cy,r:R,fill:'#fff'},g);
 for(var i=0;i<60;i++){var a=i*6*Math.PI/180,r1=i%5===0?R-9:R-4;E('line',{x1:cx+r1*Math.sin(a),y1:cy-r1*Math.cos(a),x2:cx+(R-1)*Math.sin(a),y2:cy-(R-1)*Math.cos(a),stroke:'#33475b','stroke-width':i%5===0?2:.8},g)}
 for(var n=1;n<=12;n++){var b=n*30*Math.PI/180;T(g,cx+(R-20)*Math.sin(b),cy-(R-20)*Math.cos(b)+5,String(n),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.mins)T(g,cx+(R+13)*Math.sin(b)*0+cx*0+cx+(R-34)*Math.sin(b)-cx,cy-(R-34)*Math.cos(b)+4,String((n*5)%60===0?60:n*5),{'font-size':8,'font-weight':700,fill:C.ok})}
 if(o.arc){var am=m*6*Math.PI/180;E('path',{d:'M'+cx+' '+(cy-R+12)+' A'+(R-12)+' '+(R-12)+' 0 '+(m>30?1:0)+' 1 '+(cx+(R-12)*Math.sin(am))+' '+(cy-(R-12)*Math.cos(am)),fill:'none',stroke:C.ok,'stroke-width':6,opacity:.35},g)}
 var ha=((h%12)+m/60)*30*Math.PI/180,ma=m*6*Math.PI/180;
 E('line',{x1:cx,y1:cy,x2:cx+40*Math.sin(ha),y2:cy-40*Math.cos(ha),stroke:'#1d2b3a','stroke-width':6,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+60*Math.sin(ma),y2:cy-60*Math.cos(ma),stroke:C.bad,'stroke-width':3.5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:5,fill:'#1d2b3a'},g);
 E('rect',{x:210,y:52,width:130,height:52,rx:10,fill:'#1d2b3a'},g);T(g,275,88,pad(h)+':'+pad(m),{'font-size':30,'font-weight':800,fill:'#7CFC9A','font-family':'ui-monospace,Menlo,monospace'});
 T(g,275,124,'qisqa — soat',{'font-size':11,fill:'#1d2b3a','font-weight':700});T(g,275,140,'uzun — minut',{'font-size':11,fill:C.bad,'font-weight':700});
 if(!o.nomsg)e2Msg(e2Say(h,m))}
function e2Say(h,m){var hh=h%12===0?12:h%12;if(m===0)return 'Soat <b>'+hh+'</b> (butun soat)';if(m===30)return '<b>'+hh+' yarim</b> — '+hh+' dan 30 minut o‘tdi';if(m===15)return hh+' dan <b>chorak</b> o‘tdi (15 minut)';if(m===45)return (hh%12+1)+' ga <b>chorak qoldi</b> (15 minut)';if(m>30)return (hh%12+1)+' ga <b>'+(60-m)+' minut qoldi</b>';return hh+' dan <b>'+m+' minut</b> o‘tdi'}
function e2Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// vaqt chizig'i
function e2Line(a,steps,lab){clear();var g=S.g,x0=20,x1=340,t0=a,t1=a+steps.reduce(function(s,x){return s+x},0),k=(x1-x0)/(t1-t0||1);var X=function(t){return x0+(t-t0)*k};
 E('line',{x1:x0,y1:100,x2:x1,y2:100,stroke:'#33475b','stroke-width':2.5},g);var t=t0,f=function(t){return pad(Math.floor(t/60))+':'+pad(t%60)};
 E('circle',{cx:X(t),cy:100,r:6,fill:C.blue},g);T(g,X(t),126,f(t),{'font-size':12,'font-weight':800,fill:C.blue});
 steps.forEach(function(s,i){var a2=t,b2=t+s;E('path',{d:'M'+X(a2)+' 92 Q'+(X(a2)+X(b2))/2+' 50 '+X(b2)+' 92',fill:'none',stroke:[C.a2,C.ok,C.bad][i%3],'stroke-width':2},g);T(g,(X(a2)+X(b2))/2,58,'+'+(s>=60?Math.floor(s/60)+' soat '+(s%60?s%60+' min':''):s+' min'),{'font-size':11,'font-weight':800,fill:[C.a2,C.ok,C.bad][i%3]});t=b2;E('circle',{cx:X(t),cy:100,r:6,fill:i===steps.length-1?C.ok:'#9aa8b6'},g);T(g,X(t),126,f(t),{'font-size':12,'font-weight':800,fill:i===steps.length-1?C.ok:'#5b6b7b'})});
 if(lab)T(g,180,156,lab,{'font-size':12,fill:'#5b6b7b'})}
var P5=[function(){clear();var g=S.g;E('rect',{x:20,y:60,width:200,height:34,rx:4,fill:'#8fc6f0',stroke:'#2b6ca3'},g);T(g,120,82,'1 soat = 60 minut',{'font-size':13,'font-weight':800});e2Msg('1 soat 35 minut — necha minut?')},
 function(){clear();var g=S.g;E('rect',{x:20,y:60,width:200,height:34,rx:4,fill:'#8fc6f0',stroke:'#2b6ca3'},g);T(g,120,82,'60 minut',{'font-size':13,'font-weight':800});E('rect',{x:220,y:60,width:117,height:34,rx:4,fill:'#f6c343',stroke:'#a07a1c'},g);T(g,278,82,'35 minut',{'font-size':13,'font-weight':800});Br(20,337,98,'60 + 35 = 95 minut',false,C.ok);e2Msg('1 soat 35 minut = 60 + 35 = <b>95 minut</b> (135 emas!)')}];
var P6=[function(){e2Line(555,[25],'9:15 da uyg‘ondi');e2Msg('9:15 + 25 minut yuvinish va nonushta')},
 function(){e2Line(555,[25,20],'');e2Msg('9:15 + 25 min = <b>9:40</b>; 9:40 + 20 min = <b>10:00</b>')}];
var STEPS=[
{h:"Soat va uning millari",sum:"Qisqa mil — soatni, uzun mil — minutni ko'rsatadi.",a:"m01",
 start:function(){e2Clock(3,0)},fin:function(){e2Clock(5,0)},
 html:"<p>Soatning ikkita mili bor: <b>qisqa</b> (qora) mil — <b>soat</b>ni, <b>uzun</b> (qizil) mil — <b>minut</b>ni ko'rsatadi. Qisqa milni yurgizib ko'ring:</p>",
 btns:[["+1 soat",function(c,done){e2Clock((e2T.h%12)+1,0);mvK(done,2)}]],
 after:"<p>Uzun mil <b>12</b> da turganda — <b>butun soat</b>: qisqa mil qaysi raqamda bo'lsa, soat shuncha. Elektron soatda esa ikki nuqtadan keyin <b>00</b> yoziladi: 5:00.</p>",
 q:{t:"Soat roppa-rosa 8 bo'lsa, uzun mil qayerda turadi?",opts:["8 da","12 da","6 da","1 da"],ok:1,why:"Butun soatda uzun mil 12 da, qisqa mil 8 da.",hint:"Qaysi mil soatni, qaysi biri minutni ko'rsatadi?",full:"Qisqa mil soatni ko'rsatadi — u 8 da. Uzun mil minutni ko'rsatadi — butun soatda minut 0, ya'ni uzun mil 12 da."},
 tn:"Kartondan millari aylanadigan soat yasating. Har bola o'z soatida siz aytgan vaqtni ko'rsatsin."},
{h:"Minutlarni beshlab sanaymiz",sum:"Uzun mil bir raqamdan keyingisiga o'tsa — 5 minut. 4 da — 20 minut.",a:"m02",
 start:function(){e2Clock(7,0,{mins:1})},fin:function(){e2Clock(7,20,{mins:1,arc:1})},
 html:"<p>Uzun mil bir raqamdan keyingi raqamga o'tishi uchun <b>5 minut</b> kerak. Kichik yashil sonlar — minutlar. Minut milini yurgizing:</p>",
 btns:[["+5 minut",function(c,done){var m=e2T.m+5,h=e2T.h;if(m>=60){m=0;h=h%12+1}e2Clock(h,m,{mins:1,arc:1});mvK(done,4)}]],
 after:"<p>Uzun mil 1 da — 5 minut, 2 da — 10, 3 da — 15, 4 da — <b>20 minut</b>… Raqamni <b>5 ga ko'paytirsak</b> — minut chiqadi. Bir to'liq aylanish — <b>60 minut = 1 soat</b>.</p>",
 q:{t:"Uzun mil 7 raqamida turibdi. Necha minut bo'ldi?",opts:["7 minut","35 minut","70 minut","12 minut"],ok:1,why:"7 · 5 = 35 minut.",hint:"Har bir raqam — 5 minut. 7 ta raqam-chi?",full:"Uzun mil uchun har raqam 5 minut: 5, 10, 15, 20, 25, 30, 35. Demak 35 minut. «7 minut» — raqamni minut deb o'qigan xato."},
 tn:"Bolalar beshlab sanashni (5, 10, 15 … 60) xor bilan aytishi kerak — bu soatni o'qishning kaliti."},
{h:"Yarim, chorak o'tdi, chorak qoldi",sum:"30 minut — yarim, 15 — chorak o'tdi, 45 — keyingi soatga chorak qoldi.",a:"m03",
 start:function(){e2Clock(7,30)},fin:function(){e2Clock(7,45)},
 html:"<p>Kundalik hayotda vaqtni so'z bilan aytamiz: «yetti yarim», «sakkizdan chorak o'tdi». Tugmalarni bosing:</p>",
 btns:[["7:30",function(c,done){e2Clock(7,30);mvK(done,3)}],["7:15",function(c,done){e2Clock(7,15);mvK(done,3)}],["7:45",function(c,done){e2Clock(7,45);mvK(done,3)}]],g3:1,
 after:"<p>Soat 4 ta chorakka bo'linadi: <b>15 minut — chorak</b>, <b>30 minut — yarim</b>. 7:45 da — <b>8 ga chorak qoldi</b>. Diqqat: yarim soatda qisqa mil ikki raqam <b>o'rtasida</b> turadi!</p>",
 q:{t:"«Sakkizdan chorak o'tdi» — soat nechada?",opts:["8:04","8:15","7:45","8:25"],ok:1,why:"Chorak — 15 minut: 8:15.",hint:"Chorak necha minut? Soatning to'rtdan biri.",full:"Soat 60 minut, chorak — uning to'rtdan biri, 15 minut. «Sakkizdan chorak o'tdi» — 8:15. «7:45» — «sakkizga chorak qoldi»."},
 tn:"Doirani to'rt qismga bo'lib bo'yating: chorak — bitta qism, yarim — ikki qism."},
{h:"Tuzoq: «… ga … minut qoldi»",sum:"«3 ga 10 minut qoldi» = 2:50 (3:10 emas).",a:"m04",
 start:function(){e2Clock(2,50)},fin:function(){e2Clock(2,50)},
 html:"<p>«Uchga 10 minut qoldi» — soat nechada? Bolalar ko'pincha 3:10 deyishadi. Tekshiramiz:</p>",
 btns:[["2:50",function(c,done){e2Clock(2,50);mvK(done,2)}],["3:10",function(c,done){e2Clock(3,10);mvK(done,2)}]],g2:1,
 after:"<p>«Uchga 10 minut qoldi» — soat hali <b>3 bo'lmagan</b>, unga 10 minut bor: <b>2:50</b>. 3:10 esa — «uchdan 10 minut o'tdi». Uzun mil chap yarmida (30 dan keyin) bo'lsa — keyingi soatga necha minut qolganini aytamiz.</p>",
 q:{t:"Soat 11:40. Soat 12:00 bo'lishiga necha minut qoldi?",opts:["40 minut","20 minut","60 minut","8 minut"],ok:1,why:"60 − 40 = 20 minut.",hint:"Bir soat — 60 minut. 40 minut o'tgan. Qancha qoldi?",full:"Soat 11:40 — 11 dan 40 minut o'tdi. To'liq soatgacha 60 − 40 = 20 minut qoldi. «8» — mil turgan raqam, minut emas."},
 tn:"Bank: «Rasmdagi soat — 3 ga 10 daqiqa qoldi» kabi savollar ko'p keladi. Bolalar avval «hali 3 bo'ldimi?» deb o'zidan so'rasin."},
{h:"1 soat = 60 minut",sum:"1 soat 35 minut = 60 + 35 = 95 minut; 2 soat = 120 minut.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Soat va minutlarni bitta birlikka — minutga aylantiramiz. Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>1 soat = <b>60 minut</b> (100 emas!). Shuning uchun 1 soat 35 minut = <b>95 minut</b>, 2 soat = <b>120 minut</b>. Uzunlikdagi «1 m = 100 sm» bilan adashtirmang.</p>",
 q:{t:"2 soat necha minut?",opts:["200 minut","120 minut","100 minut","60 minut"],ok:1,why:"60 + 60 = 120.",hint:"1 soat — 60 minut. 2 soat-chi?",full:"1 soat 60 minut, 2 soat — 60 + 60 = 120 minut. «200» — soatni 100 deb o'ylagan xato."},
 tn:"Bolalar vaqtni metr bilan adashtiradi (100). «Soat — 60» ni alohida ta'kidlang."},
{h:"Vaqt o'tishini hisoblash",sum:"9:15 + 25 min = 9:40; + 20 min = 10:00. Minutlar 60 ga yetsa — yangi soat.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Masala: <i>«Ali 9:15 da uyg'ondi. 25 minut yuvinib nonushta qildi, keyin 20 minut yurib parkka bordi. Parkka soat nechada yetdi?»</i> Vaqt chizig'ida ko'ramiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: vaqtni <b>bo'laklab</b> qo'shamiz. 9:40 + 20 min = 9:60 bo'lardi — lekin 60 minut = 1 soat, demak <b>10:00</b>. Minutlar 60 ga yetsa yoki oshsa — soatga 1 qo'shamiz.</p>",
 q:{t:"Kino 15:40 da boshlanib, 1 soat 35 minut davom etdi. Soat nechada tugadi?",opts:["16:15","17:05","17:15","16:75"],ok:2,why:"15:40 + 1 soat = 16:40; + 20 min = 17:00; + 15 min = 17:15.",hint:"Avval 1 soat qo'shing, keyin 35 minutni ikkiga bo'lib qo'shing: 20 va 15.",full:"15:40 + 1 soat = 16:40. 16:40 + 20 minut = 17:00. Yana 15 minut: 17:15. «16:75» — 60 minutni soatga aylantirmagan."},
 tn:"Vaqt chizig'i (lenta) — xalqaro dasturlarda vaqt oralig'ini hisoblashning asosiy vositasi. Doskada chizib, sakrashlar bilan ko'rsating."},
{h:"Kunduzgi va kechki vaqt (24 soat)",sum:"Sutkada 24 soat. 15:00 — kunduzi soat 3, 18:00 — kechki 6.",a:"m07",
 start:function(){e2Clock(15,0)},fin:function(){e2Clock(18,0)},
 html:"<p>Strelkali soat bir sutkada <b>ikki marta</b> aylanadi: kechasi va kunduzi. Elektron soat esa 0 dan 23 gacha sanaydi:</p>",
 btns:[["08:00",function(c,done){e2Clock(8,0);e2Msg('08:00 — <b>ertalab</b> soat 8');mvK(done,3)}],["15:00",function(c,done){e2Clock(15,0);e2Msg('15:00 — <b>kunduzi</b> soat 3 (15 − 12 = 3)');mvK(done,3)}],["21:00",function(c,done){e2Clock(21,0);e2Msg('21:00 — <b>kechqurun</b> soat 9 (21 − 12 = 9)');mvK(done,3)}]],g3:1,
 after:"<p>Sutkada <b>24 soat</b>. Tushdan keyingi vaqtda elektron soat 12 dan katta sonni ko'rsatadi: <b>15:00 − 12 = 3</b> — kunduzi soat 3. Strelkali soatda esa ikkalasi bir xil ko'rinadi.</p>",
 q:{t:"Elektron soat 18:30 ni ko'rsatyapti. Strelkali soatda bu qanday?",opts:["8 yarim","6 yarim","18 yarim","3 yarim"],ok:1,why:"18 − 12 = 6: kechki olti yarim.",hint:"Tushdan keyingi soatdan 12 ni ayiring.",full:"18 − 12 = 6. 18:30 — kechki 6 yarim. Strelkali soatda qisqa mil 6 va 7 orasida, uzun mil 6 da."},
 tn:"Kun tartibi jadvalini tuzing: uyg'onish 07:00, dars 08:30, tushlik 13:00, uxlash 21:00."},
{h:"Bilasizmi? Nega 60 minut?",sum:"60 lik hisobni qadimgi Bobil olimlari ishlatgan, sutkani 24 qismga misrliklar bo'lgan.",a:"m08",
 start:function(){e2Clock(12,0)},fin:function(){e2Clock(12,0)},
 html:"<p>🏺 Nega soatda 100 emas, <b>60 minut</b>? Bundan 4000 yildan ko'proq vaqt oldin Bobil (Mesopotamiya) olimlari <b>60 lab</b> sanashgan: 60 ni 2, 3, 4, 5, 6, 10, 12, 15, 20, 30 ga bo'lish mumkin — juda qulay!</p><p>☀️ Sutkani <b>24 soatga</b> bo'lishni qadimgi misrliklar boshlagan.</p><p>⭐ Vatandoshimiz <b>Mirzo Ulug'bek</b> Samarqanddagi rasadxonasida yilning uzunligini o'sha davr uchun hayratlanarli aniqlikda hisoblagan.</p>",
 tn:"Bolalardan «60 ni nechta teng bo'lakka bo'lish mumkin?» deb so'rang — choraklar, yarimlar shu yerdan kelib chiqadi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){e2Clock(7,45)},fin:function(){e2Clock(7,45)},
 html:"<div class='memo'><ul><li><b>Qisqa</b> mil — soat, <b>uzun</b> mil — minut.</li><li>Uzun mil bir raqamdan keyingisiga — <b>5 minut</b>; raqam · 5 = minut.</li><li><b>1 soat = 60 minut</b>; yarim — 30, chorak — 15 minut.</li><li>«3 ga 10 minut qoldi» = <b>2:50</b>; «3 dan 10 minut o'tdi» = 3:10.</li><li>1 soat 35 minut = <b>95 minut</b>.</li><li>Vaqt qo'shish: bo'laklab; minut 60 ga yetsa — soatga 1 qo'shing.</li><li>Sutkada 24 soat: 15:00 = kunduzi soat 3.</li></ul></div>",
 tn:"Keyingi darsni «Dars 8:30 da boshlanib 45 minut davom etadi. Qachon tugaydi?» savoli bilan boshlang."}
];
var PROBS=[
{t:"Uzun mil 12 da, qisqa mil 4 da. Soat nechada?",o:["4:00","12:04","12:20","4:12"],k:0,s:"Qisqa mil — soat (4), uzun mil 12 da — butun soat: 4:00."},
{t:"Uzun mil 9 raqamida. Necha minut?",o:["45 minut","9 minut","90 minut","30 minut"],k:0,s:"9 · 5 = 45 minut."},
{t:"«To'rt yarim» — soat nechada?",o:["4:30","4:50","3:30","4:15"],k:0,s:"Yarim — 30 minut: 4:30."},
{t:"«Oltiga chorak qoldi» — soat nechada?",o:["5:45","6:15","6:45","5:15"],k:0,s:"6 ga 15 minut qoldi: 5:45."},
{t:"1 soat 15 minut necha minut?",o:["75 minut","115 minut","65 minut","90 minut"],k:0,s:"60 + 15 = 75."},
{t:"1 soat 35 minut necha minut?",o:["95 minut","135 minut","36 minut","85 minut"],k:0,s:"60 + 35 = 95."},
{t:"90 minut necha soat va necha minut?",o:["1 soat 30 minut","9 soat","1 soat 50 minut","90 soat"],k:0,s:"90 = 60 + 30: 1 soat 30 minut."},
{t:"Ali 9:15 da uyg'ondi. 25 minut nonushta qildi, keyin 20 minut yurib parkka bordi. Parkka soat nechada yetdi?",o:["10:00","9:50","9:40","10:10"],k:0,s:"9:15 + 25 = 9:40; + 20 = 10:00."},
{t:"Kino 15:40 da boshlanib 1 soat 35 minut davom etdi. Qachon tugadi?",o:["17:15","17:05","16:15","17:25"],k:0,s:"15:40 + 1 soat = 16:40; + 35 min = 17:15."},
{t:"Aziz 1 soat 45 minut kitob o'qidi, keyin 2 soat 15 minut ishladi. Hammasi necha soat?",o:["4 soat","3 soat","5 soat","6 soat"],k:0,s:"45 + 15 = 60 minut = 1 soat; 1 + 2 + 1 = 4 soat."},
{t:"Soat 11:40. 12:00 ga necha minut qoldi?",o:["20 minut","40 minut","60 minut","8 minut"],k:0,s:"60 − 40 = 20."},
{t:"Dars 8:30 da boshlanib, 45 minut davom etadi. Qachon tugaydi?",o:["9:15","9:00","8:75","9:30"],k:0,s:"8:30 + 30 min = 9:00; + 15 min = 9:15."},
{t:"Elektron soat 20:00 ni ko'rsatyapti. Bu kechki soat nechi?",o:["8","10","2","20"],k:0,s:"20 − 12 = 8."},
{t:"Avtobus har 15 minutda keladi. 8:00 dan keyin uchinchi avtobus soat nechada keladi?",o:["8:45","8:30","8:15","9:00"],k:0,s:"8:15, 8:30, 8:45 — uchinchisi 8:45."},
{t:"Qaysi vaqt oralig'i eng uzun?",o:["75 minut","1 soat 10 minut","65 minut","1 soat"],k:0,s:"1 soat 10 min = 70 min, 1 soat = 60 min. Eng uzuni 75 minut."},
{t:"Ali uydan 7:45 da chiqdi, maktabga 20 minut yuradi. Dars 8:10 da. Darsdan necha minut oldin yetib keladi?",o:["5 minut","10 minut","15 minut","25 minut"],k:0,s:"7:45 + 20 = 8:05. 8:10 gacha 5 minut."},
{t:"Hozir 4:30. 2 soat 45 minutdan keyin soat necha bo'ladi?",o:["7:15","6:75","6:15","7:45"],k:0,s:"4:30 + 2 soat = 6:30; + 30 min = 7:00; + 15 min = 7:15."},
{t:"Bir sutkada necha soat bor?",o:["24","12","60","100"],k:0,s:"Sutka — 24 soat."},
{t:"Yarim soat va chorak soat birgalikda necha minut?",o:["45 minut","30 minut","75 minut","35 minut"],k:0,s:"30 + 15 = 45."},
{t:"Soat 9:50 da tugagan dars 45 minut davom etgan. Dars qachon boshlangan?",o:["9:05","9:15","8:55","9:00"],k:0,s:"9:50 − 45 min: 9:50 − 40 = 9:10, − 5 = 9:05."}
];
function PRACT_STAGE(){e2Clock(7,45)}
var PREP_DATA={teach:["Soat millari: qisqa — soat, uzun — minut; beshlab sanash.","Yarim, chorak o'tdi, chorak qoldi; «… ga … minut qoldi».","1 soat = 60 minut; soat va minutni minutga aylantirish.","Vaqt oralig'ini hisoblash (vaqt chizig'i); 24 soatlik yozuv."],
 mist:["Uzun mil turgan raqamni minut deb o'qiydi (7 → 7 minut).","«3 ga 10 minut qoldi» ni 3:10 deydi.","1 soatni 100 minut deb hisoblaydi (1 soat 35 min = 135).","9:40 + 20 = 9:60 deb yozadi."],
 need:["Kartondan millari aylanadigan soat (har bolaga).","Vaqt chizig'i uchun lenta."],
 board:["Soat siferblati, raqamlar yonida 5, 10, 15 … 60.","<span class='w2'>1 soat = 60 min</span>, yarim = 30, chorak = 15.","<span class='w2'>2:50</span> = «3 ga 10 minut qoldi».","<span class='w2'>1 soat 35 min = 95 min</span>.","Vaqt chizig'i: <span class='w2'>9:15 → 9:40 → 10:00</span>.","<span class='w2'>15:00 = 3</span> (kunduzi)."]};
