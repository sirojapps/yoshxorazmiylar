var CODE='4C5',TITLE='4-sinf · Ikki xonali songa bo‘lish';
var P1=[function(){W3eq(['2 400 : 30 = ?']);W3msg('Avval yaxlit o‘nlikka bo‘lishni eslaymiz')},
 function(){W3eq(['2 40[0] : 3[0]','240 : 3 = [80]']);W3msg('Bittadan nol o‘chiramiz: 240 : 3 = <b>80</b>')},
 function(){W3eq(['1 470 : 21 = ?','21 · 70 = 1 470']);W3msg('Yaxlit bo‘lmagan bo‘luvchi: «21 ni nechaga ko‘paytirsam 1 470 chiqadi?»')},
 function(){W3eq(['21 · 7 = 147','21 · 70 = 1 470','1 470 : 21 = [70]']);W3msg('Bo‘lish — ko‘paytirishning teskarisi. Bo‘linma <b>70</b>')}];
var P3=w4LongPh(1728,24,'1 728 : 24 — birinchi to‘liqsiz bo‘linuvchi 172');
var P4=[function(){W3eq(['297 : 35 = ?']);W3msg('2 975 : 35 — birinchi to‘liqsiz bo‘linuvchi 297. Sinov raqamini topamiz')},
 function(){W3eq(['35 ≈ 40 → 297 : 40 ≈ 7','35 · 7 = 245','297 − 245 = [52] > 35']);W3msg('Qoldiq bo‘luvchidan katta — 7 <b>kichik</b>','40 ga yaxlitlash kam beradi')},
 function(){W3eq(['35 ≈ 30 → 297 : 30 ≈ 9','35 · 9 = [315] > 297']);W3msg('Oshib ketdi — 9 <b>katta</b>','30 ga yaxlitlash ko‘p beradi')},
 function(){W3eq(['35 · 8 = 280','297 − 280 = 17 < 35 ✓']);W3msg('To‘g‘ri raqam o‘rtada — <b>8</b>')}].concat(w4LongPh(2975,35,'Endi burchakda yozamiz: 8 dan boshlaymiz'));
var P6=w4LongPh(38532,52,'38 532 : 52 — besh xonali bo‘linuvchi');
var STEPS=[
{h:"Bog'lanish: yaxlit o'nlikka bo'lish",sum:"2 400 : 30 = 80; 1 470 : 21 = 70, chunki 21 · 70 = 1 470.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Ikki xonali songa bo'lishdan oldin — tanish narsalar.</p>",btns:[phaser(P1)],
 after:"<p>Ikki xonali songa bo'lishning siri: <b>«bo'luvchini nechaga ko'paytirsam, bo'linuvchiga yaqin son chiqadi?»</b> — deb so'rash.</p>",
 q:{t:"3 600 : 40 = ?",opts:["90","9","900","80"],ok:0,why:"360 : 4 = 90.",hint:"Bittadan nol o'chiring.",full:"3 600 : 40 = 360 : 4 = 90. Tekshiruv: 90 · 40 = 3 600. «9» — ikki nol o'chirilgan."},
 tn:"Ko'paytirish jadvalini «bo'luvchi qatori» shaklida yozdiring: 24, 48, 72, 96, 120, … — bo'lishda shu qatordan foydalaniladi."},
{h:"Bo'linma raqamini tanlash",sum:"172 : 24: 24 ≈ 20 → sinov 8; 24 · 8 = 192 > 172 — katta; 7 → 168, qoldiq 4 ✓.",a:"m02",start:function(){W3eq(['172 : 24 = ?','24 · ? ≤ 172']);W3msg('24 ≈ 20: 172 : 20 ≈ 8. Sinab ko‘ring!')},fin:function(){W3eq(['24 · 7 = 168','172 − 168 = 4 < 24 ✓'])},
 html:"<p>Birinchi qadam: <b>172 : 24</b>. Bo'linma raqamini sinab ko'ring:</p>",
 btns:[["8",function(){W3eq(['24 · 8 = [192]','192 > 172']);W3msg('Sig‘maydi — 172 dan oshib ketdi. Kichikroq raqam kerak','Yana sinang')}],["7",function(c,done){W3eq(['24 · 7 = 168','172 − 168 = 4 < 24 ✓']);W3msg('To‘g‘ri! 168 ≤ 172 va qoldiq 4 &lt; 24');done()}],["6",function(){W3eq(['24 · 6 = 144','172 − 144 = [28] > 24']);W3msg('Qoldiq 28 — bo‘luvchidan katta! Yana bitta 24 sig‘adi','Kattaroq raqam kerak')}]],g3:1,
 after:"<p>Ikki tekshiruv: 1) ko'paytma bo'linuvchidan <b>oshmasin</b>; 2) qoldiq bo'luvchidan <b>kichik</b> bo'lsin. Biri buzilsa — raqamni 1 ga tuzatamiz.</p>",
 q:{t:"250 : 34. Bo'linma raqami?",opts:["7","8","6","9"],ok:0,why:"34 · 7 = 238, qoldiq 12.",hint:"34 ≈ 30: 250 : 30 ≈ 8. Tekshiring!",full:"Sinov: 8 → 34 · 8 = 272 > 250 — katta. 7 → 238, qoldiq 12 < 34 ✓. Javob 7. 6 → qoldiq 46 > 34."},
 tn:"«Sinab ko'r, tuzat» — xato emas, usulning bir qismi. Bolalar sinov raqamini kichik doskaga yozib, o'chirib tuzatsin."},
{h:"Burchak usuli: 1 728 : 24",sum:"1 728 : 24 = 72.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=P3.length-1;P3[P3.length-1]()},
 html:"<p>To'liq burchakli bo'lish. Har qadamni bosing.</p>",btns:[phaser(P3)],
 after:"<p>Qadamlar bir xonali songa bo'lishdagidek: <b>bo'l → ko'paytir → ayir → tushir</b>. Farqi faqat «bo'l» qadamida — raqamni <b>sinab</b> topamiz.</p>",
 q:{t:"1 196 : 26 = ?",opts:["46","36","56","406"],ok:0,why:"119 : 26 = 4 (q. 15); 156 : 26 = 6.",hint:"119 : 26 — sinov: 26 ≈ 30, 119 : 30 ≈ 4.",full:"119 : 26 = 4 (26 · 4 = 104, qoldiq 15). 6 ni tushiramiz: 156 : 26 = 6. Javob 46. Tekshiruv: 46 · 26 = 1 196."},
 tn:"Bo'luvchining karralilari ro'yxati (24, 48, 72, …, 216) daftar chetida tursin — sinov tezlashadi."},
{h:"Tuzoq: sinov raqami ikki marta",sum:"2 975 : 35 = 85: 35 ≈ 40 bilan 7 chiqadi, lekin qoldiq 52 > 35 — 8 ga oshiramiz.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=P4.length-1;P4[P4.length-1]()},
 html:"<p>Bo'luvchi 35 — 30 ga ham, 40 ga ham yaqin. Qaysi yaxlitlash yordam beradi? Kuzating.</p>",btns:[phaser(P4)],
 after:"<p>297 : 35 → 35 ni 40 ga yaxlitlasak, sinov <b>7</b> (kam chiqadi, qoldiq 52 > 35), 30 ga yaxlitlasak — <b>9</b> (ko'p: 315 > 297). To'g'risi o'rtada — <b>8</b>. Sinov raqami ±1 tuzatilishi oddiy hol.</p>",
 q:{t:"3 128 : 46 = ?",opts:["68","78","58","608"],ok:0,why:"312 : 46 = 6 (q. 36); 368 : 46 = 8.",hint:"46 ≈ 50: 312 : 50 ≈ 6.",full:"312 : 46: 6 → 276, qoldiq 36 < 46 ✓. 8 ni tushiramiz: 368 : 46 = 8 (46 · 8 = 368). Javob 68."},
 tn:"Bo'luvchi 5 bilan tugasa (35, 45) — ikkala yaxlitlashni sinab ko'rish foydali; bolalar qaysi biri yaqinroq chiqqanini solishtirsin."},
{h:"Bo'linmada nol",sum:"6 324 : 31 = 204: 12 : 31 — sig'maydi, bo'linmaga 0.",a:"m05",start:function(){W3eq(['6 324 : 31 = ?']);W3msg('Uchta javob: 24, 204, 2 004. Qaysi biri?')},fin:function(){w3Long(6324,31,99)},
 html:"<p><b>6 324 : 31</b>. To'g'ri javobni tanlang:</p>",
 btns:[["204",function(c,done){w3Long(6324,31,99);W3msg('63 : 31 = 2 (q. 1); 12 : 31 — sig‘maydi → <b>0</b>; 124 : 31 = 4');done()}],["24",function(){W3eq(['24 · 31 = 744 ≠ 6 324']);W3msg('Tekshiruv: 10 marta kam. Bo‘linmadagi 0 yo‘qolgan','Qayta tanlang')}],["2 004",function(){W3eq(['2 004 · 31 = 62 124']);W3msg('10 marta ko‘p. Birinchi to‘liqsiz bo‘linuvchi — 63 yuz, demak 3 raqam','Qayta tanlang')}]],g3:1,
 after:"<p>Birinchi to'liqsiz bo'linuvchi (63 <b>yuz</b>) bo'linmada <b>3 ta raqam</b> bo'lishini aytadi. 24 — ikki raqam, demak xato.</p>",
 q:{t:"8 568 : 42 = ?",opts:["204","24","2 004","214"],ok:0,why:"85 : 42 = 2 (q. 1); 16 → 0; 168 : 42 = 4.",hint:"16 : 42 — sig'maydi.",full:"85 : 42 = 2 (qoldiq 1). 6 tushdi: 16 : 42 = 0. 8 tushdi: 168 : 42 = 4. Javob 204. Tekshiruv: 204 · 42 = 8 568."},
 tn:"Bo'linmaga nuqtalar bilan joy ajratish usuli (• • •) bu yerda juda foydali."},
{h:"Besh xonali sonni bo'lish",sum:"38 532 : 52 = 741.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=P6.length-1;P6[P6.length-1]()},
 html:"<p>Katta sonlarda ham xuddi shu to'rt qadam.</p>",btns:[phaser(P6)],
 after:"<p>385 : 52 — sinov: 52 ≈ 50, 385 : 50 ≈ 7 → 364, qoldiq 21 ✓. Har qadamda qoldiq bo'luvchidan kichik — demak to'g'ri ketyapmiz.</p>",
 q:{t:"Qaysi javob 27 945 : 45 ga to'g'ri kelishi mumkin?",opts:["621","62","6 210","521"],ok:0,why:"27 000 : 45 = 600 atrofida.",hint:"279 : 45 — bo'linma yuzliklardan boshlanadi.",full:"Birinchi to'liqsiz bo'linuvchi 279 yuz → 3 raqam. 45 · 600 = 27 000, 45 · 621 = 27 945 ✓. 521 · 45 = 23 445 — kam."},
 tn:"Bolalar bu misolni juftlikda, har qadamni navbat bilan bajarib yechsin."},
{h:"Tuzoq: qoldiq bo'luvchidan katta",sum:"453 : 56 da 7 tanlansa qoldiq 61 > 56 chiqadi — raqamni 8 ga oshirish kerak. 4 536 : 56 = 81.",a:"m07",start:function(){W3eq(['453 : 56 → 7','56 · 7 = 392','453 − 392 = [61]']);W3msg('Bola 7 ni tanladi. Qoldiq 61. Nima qilish kerak?')},fin:function(){W3eq(['56 · 8 = 448','453 − 448 = 5 ✓','4 536 : 56 = [81]'])},
 html:"<p>Bola <b>4 536 : 56</b> ni bo'lyapti: birinchi qadamda 7 ni tanlab, qoldiq <b>61</b> chiqdi. Endi nima qiladi?</p>",
 btns:[["Raqamni 1 ga oshiradi",function(c,done){W3eq(['56 · 8 = 448','453 − 448 = 5 ✓','4 536 : 56 = [81]']);W3msg('61 &gt; 56 — yana bitta 56 sig‘adi. 8 ni olamiz, qoldiq 5. 56 : 56 = 1 → <b>81</b>');done()}],["Qoldiq bilan davom etadi",function(){W3eq(['616 : 56 = 11 ?']);W3msg('Bo‘linmaning bitta xonasiga ikki xonali 11 yozib bo‘lmaydi!','Qayta tanlang')}],["Raqamni 1 ga kamaytiradi",function(){W3eq(['56 · 6 = 336','453 − 336 = 117']);W3msg('Qoldiq yanada katta bo‘ldi — 117!','Qayta tanlang')}]],
 after:"<p>Qoida: qoldiq ≥ bo'luvchi bo'lsa — bo'linma raqami <b>kichik</b> tanlangan, 1 ga oshiramiz. Ko'paytma bo'linuvchidan oshsa — raqam <b>katta</b>, 1 ga kamaytiramiz.</p>",
 q:{t:"Bola 2 516 : 37 da birinchi qadamda 251 − 37 · 7 = 251 − 259 deb yozdi. Nima qilishi kerak?",opts:["Raqamni 6 ga kamaytirish","Raqamni 8 ga oshirish","Ayirishni teskari bajarish","Bo'linmaga 0 yozish"],ok:0,why:"259 > 251 — 7 katta.",hint:"Ko'paytma bo'linuvchidan oshib ketdi.",full:"37 · 7 = 259 > 251 — sig'maydi, raqam katta. 6 ni olamiz: 37 · 6 = 222, qoldiq 29 < 37 ✓. Javob: 2 516 : 37 = 68."},
 tn:"«Juda katta — kamaytir, juda kichik (qoldiq katta) — oshir» qoidasini plakat qilib iling."},
{h:"Masala: ikki bosqich",sum:"1 248 : 24 = 52 kitob bir sinfga; 52 : 26 = 2 kitob har o'quvchiga.",a:"m08",start:function(){W3eq(['1 248 ta kitob','24 ta sinf','har sinfda 26 o‘quvchi'],{fs:19});W3msg('Har o‘quvchiga nechtadan kitob?')},fin:function(){W3eq(['1 248 : 24 = 52','52 : 26 = [2]'])},
 html:"<p>Maktab <b>1 248</b> ta kitobni <b>24</b> ta sinfga teng tarqatdi. Har sinfda <b>26</b> tadan o'quvchi. Har o'quvchiga nechtadan kitob tegdi?</p>",
 btns:[["1: bir sinfga",function(c,done,b){b.disabled=true;W3eq(['1 248 : 24 = 52']);W3msg('124 : 24 = 5 (q. 4); 48 : 24 = 2 → <b>52</b> ta kitob')}],["2: bir o‘quvchiga",function(c,done){W3eq(['1 248 : 24 = 52','52 : 26 = [2]']);W3msg('52 : 26 = <b>2</b> ta kitob','Boshqa yo‘l: jami o‘quvchi 24 · 26 = 624; 1 248 : 624 = 2');done()}]],
 after:"<p>Ikkala yo'l ham to'g'ri. Qaysi biri qulayroq — bolalar o'zi tanlasin: biri bo'lishni, biri ko'paytirishni ko'proq talab qiladi.</p>",
 q:{t:"1 152 o'quvchini 32 o'rinli avtobuslarga joylashtirish kerak. Har avtobus kuniga 2 marta qatnaydi. Bir kunda hammasini tashish uchun nechta avtobus kerak?",opts:["18","36","64","16"],ok:0,why:"1 152 : 32 = 36 qatnov; 36 : 2 = 18 avtobus.",hint:"Avval nechta qatnov kerakligini toping.",full:"Jami qatnovlar: 1 152 : 32 = 36. Har avtobus 2 marta qatnaydi: 36 : 2 = 18 avtobus. «36» — qatnovlar soni."},
 tn:"Ikki yo'lni doskada yonma-yon yozing: Yaponiya darslarida bu «Qaysi yo'l chiroyli?» muhokamasi deb ataladi."},
{h:"Bilasizmi? 60 lik vaqt",sum:"Soatning 60 daqiqa, daqiqaning 60 soniya bo'lishi qadimgi Bobilning 60 lik sanoq tizimidan qolgan.",a:"m09",start:function(){W3eq(['86 400 : 60 = 1 440','1 440 : 60 = 24'],{fs:20});W3msg('Bir sutkadagi soniyalarni ikki xonali songa bo‘lamiz')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Qadimgi <b>Bobil</b>da (hozirgi Iroq hududi) sonlar <b>60 lik</b> tizimda yozilgan. Soatda 60 daqiqa, daqiqada 60 soniya bo'lishi — o'sha zamondan qolgan meros.</p><p>⭐ Bir sutkada 86 400 soniya bor: 86 400 : 60 = 1 440 daqiqa, 1 440 : 60 = 24 soat. 60 ning bo'luvchilari ko'p (2, 3, 4, 5, 6, 10, 12, 15, 20, 30) — shuning uchun vaqtni bo'lish qulay.</p>",
 tn:"Bolalarga: «1 soatni teng bo'laklarga necha xil usulda bo'lish mumkin?» — 60 ning bo'luvchilarini topishsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Long(1728,24,99)},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>«Bo'luvchini nechaga ko'paytirsam?» deb so'raymiz: 1 470 : 21 = 70.</li><li>Sinov raqami: bo'luvchini yaxlitlab topamiz (24 ≈ 20).</li><li>Ko'paytma oshib ketsa — raqamni <b>kamaytir</b>; qoldiq ≥ bo'luvchi — <b>oshir</b>.</li><li>Sig'masa — bo'linmaga 0: 6 324 : 31 = 204.</li><li>Birinchi to'liqsiz bo'linuvchi bo'linma raqamlari sonini aytadi.</li><li>Tekshiruv: 72 · 24 = 1 728.</li></ul></div>",
 tn:"Keyingi mavzu: qoldiqli bo'lish va qoldiqni masalada to'g'ri talqin qilish."}
];
var PROBS=[
{t:"4 800 : 60 = ?",o:["80","8","800","48"],k:0,s:"480 : 6."},
{t:"936 : 12 = ?",o:["78","68","88","708"],k:0,s:"93 : 12 = 7 (q. 9); 96 : 12 = 8."},
{t:"1 512 : 21 = ?",o:["72","62","702","82"],k:0,s:"151 : 21 = 7 (q. 4); 42 : 21 = 2."},
{t:"2 701 : 37 = ?",o:["73","63","703","83"],k:0,s:"270 : 37 = 7 (q. 11); 111 : 37 = 3."},
{t:"4 485 : 65 = ?",o:["69","59","79","609"],k:0,s:"448 : 65 = 6 (q. 58); 585 : 65 = 9."},
{t:"7 395 : 85 = ?",o:["87","77","97","807"],k:0,s:"739 : 85 = 8 (q. 59); 595 : 85 = 7."},
{t:"9 324 : 18 = ?",o:["518","58","508","528"],k:0,s:"93 : 18 = 5 (q. 3); 32 : 18 = 1 (q. 14); 144 : 18 = 8."},
{t:"6 528 : 32 = ?",o:["204","24","2 004","214"],k:0,s:"65 : 32 = 2 (q. 1); 12 → 0; 128 : 32 = 4."},
{t:"15 776 : 29 = ?",o:["544","54","5 044","534"],k:0,s:"157 : 29 = 5 (q. 12); 127 : 29 = 4 (q. 11); 116 : 29 = 4."},
{t:"34 020 : 54 = ?",o:["630","63","603","6 300"],k:0,s:"340 : 54 = 6 (q. 16); 162 : 54 = 3; 0 → 0."},
{t:"25 194 : 13 bo'linmasida nechta raqam bor?",o:["4","3","5","2"],k:0,s:"25 : 13 — minglardan; 1 938."},
{t:"Bola 1 653 : 57 da birinchi qadamda 4 ni tanladi: 165 − 228. Bo'linma raqami qanday bo'lishi kerak?",o:["2","3","5","1"],k:0,s:"57 · 2 = 114, qoldiq 51 < 57; 1 653 : 57 = 29."},
{t:"Bola 2 448 : 34 = 702 deb yozdi. To'g'ri javob?",o:["72","702","7 002","62"],k:0,s:"244 : 34 = 7 (q. 6); 68 : 34 = 2. Tekshiruv 72 · 34 = 2 448."},
{t:"□ · 47 = 3 196. □ = ?",o:["68","78","58","608"],k:0,s:"3 196 : 47 = 68."},
{t:"□ : 23 = 156. □ = ?",o:["3 588","3 488","179","3 578"],k:0,s:"156 · 23."},
{t:"Qaysi bo'lishda bo'linma eng katta?",o:["8 064 : 42","7 776 : 48","9 375 : 75","6 552 : 63"],k:0,s:"192; 162; 125; 104."},
{t:"1 sutkada 1 440 daqiqa. Necha sutka 20 160 daqiqaga teng?",o:["14","12","140","24"],k:0,s:"20 160 : 1 440 = 2 016 : 144 = 14."},
{t:"Bog'da 2 925 tup daraxt 45 qatorga teng ekilgan. 13 qator olma, qolgani o'rik. Nechta o'rik daraxti bor?",o:["2 080","845","1 180","2 912"],k:0,s:"2 925 : 45 = 65 tup qatorda; o'rik 45 − 13 = 32 qator; 65 · 32 = 2 080."},
{t:"Velosipedchi 14 kunda 2 870 km yurdi. Har kuni bir xil yurgan bo'lsa, 9 kunda necha km?",o:["1 845 km","205 km","1 435 km","2 055 km"],k:0,s:"2 870 : 14 = 205; 205 · 9."},
{t:"Qaysi ifoda 1 728 : 24 ga teng EMAS?",o:["1 728 : 4 : 8","1 728 : 8 : 3","1 728 : 6 : 4","72"],k:0,s:"1 728 : 4 : 8 = 54 (4 · 8 = 32); qolganlari 72."}
];
function PRACT_STAGE(){w3Long(1728,24,99);W3msg('Sinov raqami → tekshir → tuzat')}
var PREP_DATA={teach:["Yaxlit o'nlikka bo'lish (bog'lanish).","Bo'linma raqamini sinov bilan tanlash.","Burchak usuli: ikki xonali bo'luvchi.","Sinov raqamini tuzatish (oshirish/kamaytirish).","Bo'linmada nol, katta sonlar, masalalar."],
 mist:["Ko'paytma bo'linuvchidan oshsa ham ayirishga urinadi.","Qoldiq bo'luvchidan katta qoladi.","Bo'linmadagi 0 ni yozmaydi: 6 324 : 31 = 24.","Masalada oraliq natijani noto'g'ri talqin qiladi."],
 need:["Bo'luvchining karralilari ro'yxati (daftar chetida).","Kichik doska — sinov raqamlari uchun."],
 board:["<span class='w2'>1 728 : 24 = 72</span>","<span class='w2'>24 ≈ 20 → sinov 8 → 7</span>","<span class='w2'>6 324 : 31 = 204</span>","<span class='w2'>Katta → kamaytir, qoldiq katta → oshir</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
