var CODE='2H15',TITLE='2-sinf · Eng kami nechta? (Dirixle prinsipi)';
// ---------- sahna: xonalar (qutilar) va narsalar ----------
function h15Rooms(n,items,o){o=o||{};clear();var g=S.g,w=Math.min(104,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.rx=[];
 for(var i=0;i<n;i++){var x=x0+i*(w+8);S.rx.push(x);var full=items[i]&&items[i].length>=2&&o.mark;E('rect',{x:x,y:30,width:w,height:110,rx:10,fill:full?'#fde6e6':'#fff7ea',stroke:full?C.bad:'#d9b98a','stroke-width':full?3:1.6},g);
  T(g,x+w/2,22,(o.names?o.names[i]:(i+1)+'-xona'),{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  (items[i]||[]).forEach(function(it,k){var cx=x+18+(k%3)*((w-24)/2.4),cy=58+Math.floor(k/3)*34;T(g,cx,cy+8,it,{'font-size':24})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:110,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}}}
function h15Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// qorong'ida qutidan olish: olinganlar qatori
function h15Draw(taken,note,good){clear();var g=S.g;E('rect',{x:20,y:20,width:120,height:120,rx:12,fill:'#2b2f3a'},g);T(g,80,88,'🌑 qorong‘i',{'font-size':12,fill:'#fff'});T(g,80,108,'quti',{'font-size':11,fill:'#c9d3dd'});
 taken.forEach(function(it,i){var x=168+(i%5)*36,y=50+Math.floor(i/5)*44;E('rect',{x:x-16,y:y-20,width:32,height:34,rx:8,fill:good&&good.indexOf(i)>=0?'#e6f6ee':'#fff',stroke:good&&good.indexOf(i)>=0?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,y+6,it,{'font-size':20})});
 T(g,250,160,note||'',{'font-size':12,'font-weight':800,fill:C.blue})}
var P2=[function(){h15Rooms(3,[[],[],[]],{});h15Msg('3 ta xona, 4 ta mushuk. Mushuklar <b>alohida-alohida</b> yashashga harakat qiladi…')},
 function(){h15Rooms(3,[['🐱'],['🐱'],['🐱']],{});h15Msg('Birinchi 3 ta mushuk — har biri o‘z xonasida. Xonalar tugadi!')},
 function(){h15Rooms(3,[['🐱','🐱'],['🐱'],['🐱']],{mark:1});h15Msg('4-mushuk qayerga borsa ham — u yerda <b>ikkita</b> bo‘ladi')}];
var P3=[function(){h15Draw([],'Qutida 5 qora, 5 oq paypoq');h15Msg('Qorong‘ida olamiz. Kamida nechta olsak, <b>albatta</b> bir xil rangli juft bo‘ladi?')},
 function(){h15Draw(['⚫','⚪'],'eng omadsiz holat');h15Msg('Eng yomon holat: 1-si qora, 2-si oq — hali juft yo‘q')},
 function(){h15Draw(['⚫','⚪','⚫'],'3-si albatta juft beradi',[0,2]);h15Msg('3-paypoq qora bo‘lsa ham, oq bo‘lsa ham — juft tayyor! Javob: <b>3</b>')}];
var P4=[function(){h15Draw([],'3 qizil, 4 ko‘k, 5 yashil');h15Msg('Ikkitasi bir xil rangli bo‘lishi uchun kamida nechta koptok?')},
 function(){h15Draw(['🔴','🔵','🟢'],'har rangdan bittadan');h15Msg('Eng yomon holat: 3 ta rangdan bittadan — hali juft yo‘q')},
 function(){h15Draw(['🔴','🔵','🟢','🔵'],'4-si albatta juft',[1,3]);h15Msg('Ranglar 3 ta — 4-koptok albatta takrorlanadi. Javob: <b>4</b> (rang soni + 1)')}];
var P5=[function(){h15Draw([],'6 olma va 6 nok');h15Msg('Kamida nechta meva olsak, <b>albatta bitta olma</b> bo‘ladi?')},
 function(){h15Draw(['🍐','🍐','🍐','🍐','🍐','🍐'],'eng omadsiz: hammasi nok');h15Msg('Eng yomon holat: avval <b>hamma 6 ta nok</b> chiqib ketadi')},
 function(){h15Draw(['🍐','🍐','🍐','🍐','🍐','🍐','🍎'],'7-si albatta olma',[6]);h15Msg('Nok qolmadi — 7-meva albatta olma. Javob: <b>7</b> (2 emas!)')}];
var STEPS=[
{h:"Mushuklarni joylang",sum:"3 ta xonaga 4 ta mushuk qanday joylansa ham — bir xonada kamida 2 ta bo'ladi.",a:"m01",
 start:function(){S.it=[[],[],[]];S.n=0;h15Rooms(3,S.it,{tap:h15Put});h15Msg('4 ta mushukni xonalarga joylang: xonani bosing (qolgan: 4)')},fin:function(){h15Rooms(3,[['🐱','🐱'],['🐱'],['🐱']],{mark:1});h15Msg('Qaysidir xonada albatta 2 ta mushuk')},
 html:"<p>3 ta xona va 4 ta mushuk bor. Mushuklarni xonalarga joylang — <b>xonani bosing</b>. Iloji boricha har bir mushukni alohida xonaga joylashga harakat qiling!</p>",
 act:function(c,done){S.d1=done;c.querySelector('.hint').textContent='Rasmdagi xonalarni bosing.'},
 after:"<p>Qanchalik harakat qilsangiz ham, qaysidir xonada <b>kamida 2 ta</b> mushuk bo'lib qoldi. Chunki mushuklar (4) xonalardan (3) <b>ko'p</b>!</p>",
 q:{t:"5 ta qushga 4 ta in bor. Qaysidir inda kamida nechta qush borligi aniq?",opts:["1","2","5","4"],ok:1,why:"Qushlar inlardan ko'p — qaysidir inda albatta 2 ta.",hint:"Avval har inga bittadan qush joylang. Beshinchisi qayerga boradi?",full:"4 ta inga bittadan qush — 4 ta qush joylashdi. 5-qush albatta biror inga, u yerda 2 ta bo'ladi. «1» bo'lishi ham mumkin edi, lekin savol «aniq» deyapti."},
 tn:"Sinfda 4 ta bolani 3 ta stulga o'tqazishni so'rang (har stulga bittadan) — ular o'zi tushunadi."},
{h:"Eng yomon holatni o'ylaymiz",sum:"«Albatta» savolida eng omadsiz holatni olamiz: avval hamma xonaga bittadan.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Kalit fikr: «<b>albatta</b>», «<b>aniq</b>» degan savolda biz <b>eng omadsiz holatni</b> o'ylaymiz. Kuzating.</p>",
 btns:[phaser(P2)],
 after:"<p>Eng omadsiz holat — har xonaga bittadan. Xonalar tugagach, keyingi mushuk <b>albatta</b> qaysidir mushukning yoniga tushadi.</p>",
 q:{t:"Sinfda 13 o'quvchi bor. Ulardan kamida nechtasi haftaning bir xil kunida tug'ilgani aniq?",opts:["1","7","2","13"],ok:2,why:"Hafta kunlari 7 ta, o'quvchilar 13 ta — ko'p, demak kamida 2 tasi bir kunda.",hint:"Hafta kunlari — «xonalar». Nechta xona bor? O'quvchilar ko'pmi?",full:"Hafta kunlari 7 ta — 7 ta «xona». Eng yomon holatda 7 o'quvchi turli kunlarda. 8-o'quvchi albatta takrorlaydi. Demak kamida 2 tasi bir kunda tug'ilgan."},
 tn:"«Xonalar» va «quyonlar» — Rossiyada bu prinsipni «quyonlar va qafaslar» deb o'rgatishadi. Doskada ham shunday chizing."},
{h:"Qorong'ida paypoq",sum:"2 rang bo'lsa — 3 ta paypoq olinsa albatta juft bo'ladi (rang soni + 1).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Qutida 5 ta qora va 5 ta oq paypoq. Qorong'i — rangini ko'rmaymiz. Kamida nechta olsak, ular orasida <b>albatta</b> bir xil rangli 2 ta bo'ladi?</p>",
 btns:[phaser(P3,'▶ Paypoq olish')],
 after:"<p>Ranglar — bu «xonalar»: 2 ta. Eng yomon holatda har rangdan bittadan oldik. Keyingisi albatta juft beradi: <b>2 + 1 = 3</b>. Paypoqlar 5 tadan bo'lishi muhim emas!</p>",
 q:{t:"Qutida 5 ta qora va 5 ta oq paypoq. Kamida nechta olinsa, albatta bir xil rangli 2 ta bo'ladi?",opts:["2","6","3","5"],ok:2,why:"2 rang: eng yomoni — qora va oq, 3-si albatta juft.",hint:"Eng omadsiz bo'lsa, birinchi ikkitasi qanday rangda bo'ladi?",full:"1-si qora, 2-si oq bo'lishi mumkin — juft yo'q. 3-si qaysi rangda bo'lsa ham, juftlik hosil bo'ladi. Javob: 3. «6» — 5 + 1, bu boshqa savolga (bitta rangdan albatta) javob."},
 tn:"Ikki xil rangli qalamni sumkaga solib, ko'rmasdan olish o'yinini o'ynang."},
{h:"Ranglar ko'p bo'lsa",sum:"3 rangli koptoklar: 3 tasi har xil bo'lishi mumkin, 4-si albatta takrorlanadi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Qutida 3 ta qizil, 4 ta ko'k, 5 ta yashil koptok. Ko'rmasdan kamida nechta olsak, ikkitasi <b>albatta</b> bir xil rangli bo'ladi?</p>",
 btns:[phaser(P4,'▶ Koptok olish')],
 after:"<p>Qoida: «ikkitasi bir xil bo'lsin» desa — <b>xillar soni + 1</b>. Ranglar 3 ta → 4 ta koptok.</p>",
 q:{t:"Savatda olma, nok, behi va anor bor (har biridan ko'p). Ko'rmasdan kamida nechta meva olinsa, ikkitasi albatta bir xil bo'ladi?",opts:["4","2","5","8"],ok:2,why:"4 xil meva — 4 tasi har xil bo'lishi mumkin, 5-si takrorlanadi.",hint:"Nechta xil meva bor? Eng yomoni — har xildan bittadan.",full:"Xillar 4 ta: olma, nok, behi, anor. Eng yomon holatda 4 tasi har xil. 5-meva albatta takrorlanadi. Javob: 4 + 1 = 5."},
 tn:"Bolalar «xillar soni + 1» qoidasini o'zlari topishsin — avval 2 rang, keyin 3 rang bilan sinab."},
{h:"Tuzoq: «albatta bitta olma»",sum:"6 olma, 6 nok: albatta olma bo'lishi uchun — avval 6 nok chiqib ketishi mumkin → 7 ta.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Endi savol boshqacha: qutida 6 ta olma va 6 ta nok. Kamida nechta olsak, ular orasida <b>albatta bitta olma</b> bo'ladi? Ehtiyot bo'ling!</p>",
 btns:[phaser(P5,'▶ Meva olish')],
 after:"<p>Bu yerda «juft» emas, <b>aniq bir xil</b> narsa so'ralyapti. Eng yomon holat — boshqa hamma narsalar oldin chiqib ketadi: 6 nok + 1 = <b>7</b>.</p>",
 q:{t:"Qutida 4 ta qizil va 9 ta ko'k qalam bor. Kamida nechta olinsa, albatta qizil qalam bo'ladi?",opts:["2","5","10","13"],ok:2,why:"Eng yomoni: avval 9 ta ko'k, 10-si albatta qizil.",hint:"Eng omadsiz holatda qizildan oldin qaysi qalamlar chiqib ketadi? Ular nechta?",full:"Qizil chiqishi uchun eng yomon holatda avval hamma ko'klar chiqadi — 9 ta. 10-qalam albatta qizil. «5» — 4 + 1, bu qizillarni sanab adashish."},
 tn:"Ikki xil savolni yonma-yon yozing: «ikkitasi bir xil» (xillar + 1) va «albatta qizil» (boshqalari + 1). Farqini bolalar ayta olsin."},
{h:"Ko'proq narsa — ko'proq kafolat",sum:"7 ta quti, 15 ta olma: har qutiga 2 tadan = 14, 15-si → kamida bitta qutida 3 ta.",a:"m06",
 start:function(){S.k6=0;h15Rooms(3,[[],[],[]],{});h15Msg('3 ta savat, 7 ta olma. Qaysidir savatda kamida nechta?')},fin:function(){h15Rooms(3,[['🍎','🍎','🍎'],['🍎','🍎'],['🍎','🍎']],{mark:1});h15Msg('Kamida bitta savatda 3 ta olma')},
 html:"<p>3 ta savatga 7 ta olma solindi. Qaysidir savatda <b>kamida nechta</b> olma borligi aniq?</p>",
 btns:[["▶ Teng tarqatamiz",function(c,done,b){S.k6++;var it=[[],[],[]];var n=S.k6===1?6:7;for(var i=0;i<n;i++)it[i%3].push('🍎');h15Rooms(3,it,{mark:S.k6>1});if(S.k6===1)h15Msg('Har savatga 2 tadan — 6 ta olma. Yana 1 ta qoldi…');else{h15Msg('7-olma qaysi savatga tushsa ham — u yerda <b>3 ta</b>');b.disabled=true;done()}}]],
 after:"<p>Iloji boricha teng tarqatsak ham: 7 = 2 + 2 + 2 + <b>1</b>. Ortgan bitta olma qaysidir savatda uchinchi bo'ladi. Javob: <b>3</b>.</p>",
 q:{t:"4 ta qutiga 9 ta kitob terildi. Qaysidir qutida kamida nechta kitob borligi aniq?",opts:["2","3","9","4"],ok:1,why:"Har qutiga 2 tadan — 8 ta, 9-kitob qaysidir qutida 3-chi bo'ladi.",hint:"Avval har qutiga teng (2 tadan) tarqating. Nechta ortib qoladi?",full:"4 quti · 2 = 8 kitob. 9-kitob qaysidir qutiga tushib, u yerda 3 ta bo'ladi. Demak kamida 3 ta aniq."},
 tn:"Bu — prinsipning kengroq ko'rinishi. Faqat kuchli bolalar bilan."},
{h:"Bilasizmi? Dirixle qutilari",sum:"Bu fikrni 1834-yilda nemis matematigi Peter Dirixle «qutilar prinsipi» deb nomlagan.",a:"m07",
 start:function(){h15Rooms(3,[['🐰','🐰'],['🐰'],['🐰']],{mark:1,names:['quti','quti','quti']});h15Msg('Quyonlar va qutilar')},fin:function(){h15Rooms(3,[['🐰','🐰'],['🐰'],['🐰']],{mark:1,names:['quti','quti','quti']});h15Msg('Quyonlar va qutilar')},
 html:"<p>📜 Nemis matematigi <b>Peter Dirixle</b> 1834-yilda bu oddiy fikrga e'tibor qaratgan va uni «<b>qutilar prinsipi</b>» deb atagan. Bugun u Dirixle prinsipi deyiladi.</p><p>💡 Juda oddiy ko'rinadi, lekin olimpiadalarda uning yordamida eng qiyin masalalar yechiladi. Masalan: «Toshkentda kamida ikki kishining sochidagi tolalar soni bir xil» — buni ham shu prinsip isbotlaydi!</p>",
 tn:"Bolalardan o'z misolini o'ylab topishni so'rang: «Sinfimizda kamida ikki kishi bir oyda tug'ilgan — nega?» (o'quvchilar 12 tadan ko'p bo'lsa)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h15Rooms(3,[['🐱','🐱'],['🐱'],['🐱']],{mark:1});h15Msg('4 mushuk, 3 xona')},fin:function(){h15Rooms(3,[['🐱','🐱'],['🐱'],['🐱']],{mark:1});h15Msg('4 mushuk, 3 xona')},
 html:"<div class='memo'><ul><li>Narsalar xonalardan <b>ko'p</b> bo'lsa — qaysidir xonada <b>kamida 2 ta</b>.</li><li>«Albatta», «aniq» desa — <b>eng omadsiz holatni</b> o'ylang.</li><li>«Ikkitasi bir xil bo'lsin» → <b>xillar soni + 1</b> (2 rang → 3 ta, 3 rang → 4 ta).</li><li>«Albatta bitta X bo'lsin» → <b>X dan boshqa hammasi + 1</b> (6 nok → 7 ta).</li><li>Teng tarqatib qoldiqqa qarang: 7 olma, 3 savat → kamida 3 ta.</li></ul></div>",
 tn:"Keyingi darsni «Sinfda 25 o'quvchi. Kamida nechtasi bir oyda tug'ilgan?» (3 ta) savoli bilan boshlang."}
];
function h15Put(i){if(S.n>=4)return;S.it[i].push('🐱');S.n++;var full=S.n===4;h15Rooms(3,S.it,{tap:full?null:h15Put,mark:full});
 if(full){h15Msg('Qaysidir xonada <b>2 ta</b> mushuk bo‘lib qoldi!');if(S.d1){S.d1();S.d1=null}}else h15Msg('Qolgan mushuklar: '+(4-S.n))}
var PROBS=[
{t:"3 ta xonaga 4 ta mushuk joylashdi. Qaysidir xonada kamida nechta mushuk borligi aniq?",o:["2","1","4","3"],k:0,s:"Mushuklar xonalardan ko'p — kamida 2 ta."},
{t:"5 ta qushga 4 ta in bor. Qaysidir inda kamida nechta qush bor?",o:["2","1","5","4"],k:0,s:"4 inga bittadan, 5-qush — ikkinchi."},
{t:"Qutida 5 qora va 5 oq paypoq bor. Qorong'ida kamida nechta olinsa, albatta bir xil rangli 2 ta bo'ladi?",o:["3","2","6","5"],k:0,s:"2 rang + 1 = 3."},
{t:"Qutida 3 qizil, 4 ko'k va 5 yashil koptok. Kamida nechta olinsa, ikkitasi albatta bir xil rangli bo'ladi?",o:["4","3","6","13"],k:0,s:"3 rang + 1 = 4."},
{t:"Qutida 6 olma va 6 nok. Ko'rmasdan kamida nechta meva olinsa, albatta bitta olma bo'ladi?",o:["7","2","6","12"],k:0,s:"Eng yomoni: 6 nok, 7-si olma."},
{t:"Sinfda 13 o'quvchi. Ulardan kamida nechtasi haftaning bir xil kunida tug'ilgani aniq?",o:["2","1","3","7"],k:0,s:"7 kun, 13 o'quvchi — kamida 2 tasi bir kunda."},
{t:"Qutida 4 qizil va 9 ko'k qalam. Kamida nechta olinsa, albatta qizil qalam bo'ladi?",o:["10","5","2","13"],k:0,s:"Avval 9 ko'k chiqishi mumkin, 10-si qizil."},
{t:"3 ta savatga 7 ta olma solindi. Qaysidir savatda kamida nechta olma bor?",o:["3","2","7","4"],k:0,s:"2 + 2 + 2 = 6, ortgan 1 ta — 3-chi."},
{t:"Savatda olma, nok, behi va anor ko'p. Kamida nechta meva olinsa, ikkitasi albatta bir xil bo'ladi?",o:["5","4","2","8"],k:0,s:"4 xil + 1 = 5."},
{t:"Sumkada 2 xil rangli shar bor. Ko'rmasdan kamida nechta olinsa, albatta bir xil rangli 2 ta shar bo'ladi?",o:["3","2","4","1"],k:0,s:"2 rang + 1 = 3."},
{t:"Qutida 5 qizil va 3 sariq gul. Kamida nechta olinsa, albatta sariq gul bo'ladi?",o:["6","4","2","8"],k:0,s:"Eng yomoni: 5 qizil, 6-si sariq."},
{t:"Qutida 5 qizil va 3 sariq gul. Kamida nechta olinsa, albatta qizil gul bo'ladi?",o:["4","6","2","8"],k:0,s:"Eng yomoni: 3 sariq, 4-si qizil."},
{t:"4 ta qutiga 9 ta kitob terildi. Qaysidir qutida kamida nechta kitob bor?",o:["3","2","4","9"],k:0,s:"4 · 2 = 8, 9-kitob — uchinchi."},
{t:"Sinfda 30 o'quvchi. Kamida nechtasi bir oyda tug'ilgani aniq? (yilda 12 oy)",o:["3","2","12","30"],k:0,s:"12 · 2 = 24, qolgan 6 ta — qaysidir oyda 3-chi."},
{t:"Qutida 3 xil rangli qalam, har rangdan 10 tadan. Kamida nechta olinsa, albatta 3 ta bir xil rangli bo'ladi?",o:["7","4","6","10"],k:0,s:"Eng yomoni: har rangdan 2 tadan = 6, 7-si uchinchi bo'ladi."},
{t:"Qutida 2 qizil, 3 ko'k va 4 yashil koptok. Kamida nechta olinsa, albatta yashil koptok bo'ladi?",o:["6","5","2","4"],k:0,s:"Avval 2 + 3 = 5 ta boshqa rang chiqishi mumkin, 6-si yashil."},
{t:"6 ta qafasga 7 ta quyon joylandi. Qaysidir qafasda kamida nechta quyon bor?",o:["2","1","7","6"],k:0,s:"Quyonlar qafaslardan ko'p — kamida 2."},
{t:"Qutida 4 juft qo'lqop (4 ta chap, 4 ta o'ng). Kamida nechta olinsa, albatta bitta juft (chap va o'ng) bo'ladi?",o:["5","2","3","8"],k:0,s:"Eng yomoni: 4 ta chap, 5-si o'ng — juft."},
{t:"Ikkita qutida jami 9 ta yong'oq. Qaysidir qutida kamida nechta yong'oq bor?",o:["5","4","9","2"],k:0,s:"4 + 4 = 8, 9-si qaysidir qutida 5-chi."},
{t:"Qutida 10 ta oq va 10 ta qora tugma. Kamida nechta olinsa, albatta 2 ta oq tugma bo'ladi?",o:["12","3","11","20"],k:0,s:"Eng yomoni: 10 qora va 1 oq, 12-si ikkinchi oq."}
];
function PRACT_STAGE(){h15Rooms(3,[['🐱','🐱'],['🐱'],['🐱']],{mark:1});h15Msg('Eng omadsiz holatni o‘ylang')}
var PREP_DATA={teach:["Dirixle prinsipi: narsalar xonalardan ko'p bo'lsa — qaysidir xonada kamida 2 ta.","«Albatta» savolida eng omadsiz holat.","«Ikkitasi bir xil» → xillar soni + 1; «albatta X» → boshqalari + 1.","Teng tarqatish va qoldiq (7 olma, 3 savat → 3)."],
 mist:["«Albatta bitta olma» savoliga 2 deb javob beradi (omadli holatni oladi).","«Ikkitasi bir xil rangli» savoliga paypoqlar sonini qo'shadi (5 + 1).","Ikki turdagi savolni aralashtiradi.","«Kamida 2 ta» o'rniga eng ko'pini aytadi."],
 need:["Rangli qalamlar va shaffof bo'lmagan sumka.","Stullar (4 bola, 3 stul o'yini)."],
 board:["3 xona, 4 mushuk: <span class='w2'>[🐱🐱][🐱][🐱]</span>.","Paypoq: <span class='w2'>⚫ ⚪ → 3-si juft</span>.","3 rang: <span class='w2'>🔴🔵🟢 → 4-si</span>.","Olma: <span class='w2'>6 nok + 1 = 7</span>.","7 olma, 3 savat: <span class='w2'>2+2+2+1 → 3</span>."]};
