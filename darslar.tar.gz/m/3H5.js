var CODE='3H5',TITLE='3-sinf · Murakkab va katakli shakllar perimetri va yuzi';
// katakli shakl: cells — [[c,r],...], n — nechta bo'yalgan
function h5Cells(cells,n,o){o=o||{};var cs=o.cs||22,x0=o.x||100,y0=o.y||20,g=S.g;g3Paper(cs,x0-cs,y0-cs,o.cols||9,o.rows||7,'#e3ebf4');
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*cs,y:y0+p[1]*cs,width:cs,height:cs,fill:i<n?(o.fill||'#f6c98a'):'#fff',stroke:'#9aa8b6','stroke-width':1},g);if(i<n&&o.num)T(g,x0+p[0]*cs+cs/2,y0+p[1]*cs+cs/2+4,String(i+1),{'font-size':10,'font-weight':800,fill:'#7a4b12'})});return [x0,y0,cs]}
var H5L=[[0,0],[0,1],[0,2],[0,3],[1,3],[2,3],[3,3],[1,2],[2,2],[3,2]];
var P1=[function(){clear('#ffffff');h5Cells(H5L,0,{x:130});g3Msg('Har katak — 1 sm². Shakl yuzi qancha?')},
 function(){clear('#ffffff');h5Cells(H5L,4,{x:130,num:1});g3Msg('Ustun: <b>4</b> katak')},
 function(){clear('#ffffff');h5Cells(H5L,7,{x:130,num:1});g3Msg('Pastki qator: yana <b>3</b> — jami 7')},
 function(){clear('#ffffff');h5Cells(H5L,10,{x:130,num:1});g3Msg('Yana 3: S = <b>10 sm²</b>')}];
var H5X=[[1,0],[0,1],[1,1],[2,1],[1,2]];
function h5Cross(k){clear('#ffffff');var o=h5Cells(H5X,5,{x:140,y:30,cs:30,cols:5,rows:5,fill:'#cfe6f8'}),x0=o[0],y0=o[1],cs=o[2];
 var path=[[1,0],[2,0],[2,1],[3,1],[3,2],[2,2],[2,3],[1,3],[1,2],[0,2],[0,1],[1,1],[1,0]];
 for(var i=0;i<Math.min(k,12);i++){var a=path[i],b=path[i+1];g3Line([x0+a[0]*cs,y0+a[1]*cs],[x0+b[0]*cs,y0+b[1]*cs],{w:5,c:C.bad});g3Dot([x0+b[0]*cs,y0+b[1]*cs],C.bad,3)}
 g3Msg(k===0?'«Xoch»: 5 katak (tomoni 1 sm). Perimetri — chegaradagi katak tomonlari soni':k<12?'Sanadik: <b>'+k+'</b> ta tomon':'P = <b>12 sm</b> (yuzi 5 sm², lekin perimetri 12 sm!)')}
var P2=[function(){h5Cross(0)},function(){h5Cross(3)},function(){h5Cross(6)},function(){h5Cross(9)},function(){h5Cross(12)}];
// L shakl 8×6 (yuqori o'ng burchakdan 3×3 qirqilgan)
function h5L(m){clear('#ffffff');var cs=16,x0=110,y0=30,g=S.g;function p(a,b){return [x0+a*cs,y0+b*cs]}
 g3Paper(cs,x0,y0,8,6,'#eef3f8');
 if(m===2){E('rect',{x:x0+5*cs,y:y0,width:3*cs,height:3*cs,fill:'rgba(231,76,60,.15)',stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'4 3'},g)}
 g3Poly([p(0,0),p(5,0),p(5,3),p(8,3),p(8,6),p(0,6)],{fill:m===1?'none':'rgba(240,160,64,.3)',stroke:C.line});
 if(m===1){E('rect',{x:x0,y:y0,width:5*cs,height:6*cs,fill:'rgba(240,160,64,.35)',stroke:C.t1,'stroke-width':2},g);E('rect',{x:x0+5*cs,y:y0+3*cs,width:3*cs,height:3*cs,fill:'rgba(90,169,230,.35)',stroke:C.blue,'stroke-width':2},g);T(g,x0+2.5*cs,y0+3*cs+4,'5·6=30',{'font-size':11,'font-weight':800});T(g,x0+6.5*cs,y0+4.5*cs+4,'3·3=9',{'font-size':10,'font-weight':800})}
 if(m===2){T(g,x0+6.5*cs,y0+1.5*cs+4,'−9',{'font-size':12,'font-weight':800,fill:C.bad});T(g,x0+3*cs,y0+4*cs,'8·6=48',{'font-size':12,'font-weight':800})}
 T(g,x0+2.5*cs,y0-5,'5',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0+4*cs,y0+6*cs+14,'8',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-6,y0+3*cs+4,'6',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});T(g,x0+8*cs+6,y0+4.5*cs+4,'3',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});
 g3Msg(m===1?'<b>Bo‘lish</b>: 30 + 9 = <b>39</b>':m===2?'<b>Ayirish</b>: 48 − 9 = <b>39</b>':'L shaklning yuzi qancha? (o‘lchamlar sm da)')}
function h5Cut(k){clear('#ffffff');var g=S.g,x=70,y=26,w=200,h=120;
 E('path',{d:'M'+x+' '+y+' h'+(w-80)+' v50 h80 v'+(h-50)+' h'+(-w)+' Z',fill:'rgba(240,160,64,.3)',stroke:C.line,'stroke-width':2.4},g);
 E('rect',{x:x+w-80,y:y,width:80,height:50,fill:k>=1?'rgba(231,76,60,.12)':'#fff',stroke:'#9aa8b6','stroke-width':1.5,'stroke-dasharray':'5 4'},g);
 T(g,x+w/2,y+h+15,'20 sm',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x-6,y+h/2+4,'12 sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});T(g,x+w-40,y-5,'8 sm',{'font-size':11,'font-weight':800,fill:C.bad});T(g,x+w+6,y+28,'5 sm',{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 g3Msg(['20 × 12 to‘rtburchak burchagidan 8 × 5 qirqildi. Qolgan yuz?','Butun: 20 · 12 = <b>240 sm²</b>','Qirqilgan: 8 · 5 = <b>40 sm²</b>','Qoldi: 240 − 40 = <b>200 sm²</b>'][k])}
var P4=[function(){h5Cut(0)},function(){h5Cut(1)},function(){h5Cut(2)},function(){h5Cut(3)}];
function h5Same(m){clear('#ffffff');var g=S.g;
 E('rect',{x:30,y:40,width:120,height:80,fill:'rgba(90,169,230,.25)',stroke:m===2?C.bad:C.blue,'stroke-width':m===2?4:2.2},g);T(g,90,136,'6 × 4',{'font-size':12,'font-weight':800});
 E('path',{d:'M210 40 h80 v20 h40 v60 h-120 Z',fill:'rgba(240,160,64,.3)',stroke:m===2?C.bad:C.line,'stroke-width':m===2?4:2.2},g);E('rect',{x:290,y:40,width:40,height:20,fill:'none',stroke:'#9aa8b6','stroke-dasharray':'4 3'},g);T(g,270,136,'burchagi qirqilgan',{'font-size':12,'font-weight':800});
 if(m===2){g3Line([290,40],[330,40],{w:4,c:C.ok,d:'4 3'});g3Line([330,40],[330,60],{w:4,c:C.ok,d:'4 3'})}
 g3Msg(m===1?'<b>Yuz</b>: 24 → 24 − 2 = <b>22</b> — kamaydi':m===2?'<b>Perimetr</b>: ichki ikki tomon = tashqi ikki tomon → <b>20</b> → <b>20</b> — o‘zgarmadi!':'Burchak qirqilsa, yuz va perimetr nima bo‘ladi? (1 katak = 1 sm)')}
function h5T(k){clear('#ffffff');var g=S.g,cs=12,x0=120,y0=24;function p(a,b){return [x0+a*cs,y0+b*cs]}
 g3Paper(cs,x0,y0,10,9,'#eef3f8');
 E('rect',{x:x0,y:y0,width:10*cs,height:3*cs,fill:k>=1?'rgba(240,160,64,.45)':'rgba(240,160,64,.25)',stroke:C.line,'stroke-width':k>=1?2.5:0},g);E('rect',{x:x0+3*cs,y:y0+3*cs,width:4*cs,height:6*cs,fill:k>=1?'rgba(90,169,230,.45)':'rgba(240,160,64,.25)',stroke:C.line,'stroke-width':k>=1?2.5:0},g);
 g3Poly([p(0,0),p(10,0),p(10,3),p(7,3),p(7,9),p(3,9),p(3,3),p(0,3)],{fill:'none',stroke:k>=3?C.bad:C.line,sw:k>=3?4:2.4});
 T(g,x0+5*cs,y0-5,'10',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-5,y0+1.5*cs+4,'3',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});T(g,x0+5*cs,y0+9*cs+13,'4',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0+7*cs+5,y0+6*cs+4,'6',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});
 if(k>=1){T(g,x0+5*cs,y0+1.5*cs+4,'30',{'font-size':12,'font-weight':800});T(g,x0+5*cs,y0+6*cs+4,'24',{'font-size':12,'font-weight':800})}
 g3Msg(['«T» shakl (sm). Yuzi va perimetri?','Ikki to‘rtburchak: 10 · 3 = 30 va 4 · 6 = 24','S = 30 + 24 = <b>54 sm²</b>','P: gorizontallar 10 + 3 + 3 + 4 = 20, vertikallar 3 + 3 + 6 + 6 = 18 → <b>38 sm</b>'][k])}
var P6=[function(){h5T(0)},function(){h5T(1)},function(){h5T(2)},function(){h5T(3)}];
function h5U(k){clear('#ffffff');var g=S.g,cs=22,x0=114,y0=34;function p(a,b){return [x0+a*cs,y0+b*cs]}
 g3Paper(cs,x0,y0,6,4,'#eef3f8');
 g3Poly([p(0,0),p(2,0),p(2,2),p(4,2),p(4,0),p(6,0),p(6,4),p(0,4)],{fill:'rgba(240,160,64,.3)',stroke:C.line});
 T(g,x0+3*cs,y0+4*cs+15,'6 sm',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-6,y0+2*cs+4,'4 sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 if(k>=1){g3Line(p(0,4),p(6,4),{w:4,c:C.blue});g3Line(p(0,0),p(0,4),{w:4,c:C.blue});g3Line(p(6,0),p(6,4),{w:4,c:C.blue});g3Line(p(0,0),p(2,0),{w:4,c:C.blue});g3Line(p(4,0),p(6,0),{w:4,c:C.blue});g3Line(p(2,2),p(4,2),{w:4,c:C.blue})}
 if(k>=2){g3Line(p(2,0),p(2,2),{w:5,c:C.bad});g3Line(p(4,0),p(4,2),{w:5,c:C.bad});T(g,x0+3*cs,y0+1*cs+4,'+2 +2',{'font-size':12,'font-weight':800,fill:C.bad})}
 g3Msg(['«П» chuqurchali shakl. Perimetri 6 × 4 to‘rtburchaknikidek 20 mi?','Tashqi qism (surish usuli): (6 + 4) · 2 = <b>20</b>','Lekin chuqurchaning <b>ikki devori</b> ortiqcha: 2 + 2 = 4','P = 20 + 4 = <b>24 sm</b>'][k])}
var P7=[function(){h5U(0)},function(){h5U(1)},function(){h5U(2)},function(){h5U(2);g3Msg('P = 20 + 4 = <b>24 sm</b>, yuzi 24 − 4 = 20 sm²')}];
function h5Plan(k){clear('#ffffff');var g=S.g,cs=15,x0=105,y0=22,W=10*cs,H=7*cs;
 E('rect',{x:x0,y:y0,width:6*cs,height:4*cs,fill:'#fbe0b4',stroke:C.line,'stroke-width':2},g);E('rect',{x:x0,y:y0+4*cs,width:6*cs,height:3*cs,fill:k>=1?'#cfe6f8':'#fff',stroke:C.line,'stroke-width':2},g);E('rect',{x:x0+6*cs,y:y0,width:4*cs,height:7*cs,fill:k>=2?'#d4edc9':'#fff',stroke:C.line,'stroke-width':2},g);
 T(g,x0+3*cs,y0+2*cs+4,'A: 6 × 4',{'font-size':11,'font-weight':800});T(g,x0+3*cs,y0+5.5*cs+4,k>=1?'B: 6 × 3':'B',{'font-size':11,'font-weight':800});T(g,x0+8*cs,y0+3.5*cs+4,k>=2?'C: 4 × 7':'C',{'font-size':11,'font-weight':800});
 T(g,x0+W/2,y0-5,'10 m',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-6,y0+H/2+4,'7 m',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 g3Msg(['Uy: 10 m × 7 m. A xona 6 × 4. B va C xonalar yuzi?','B: eni 7 − 4 = <b>3</b>, yuzi 6 · 3 = <b>18 m²</b>','C: bo‘yi 10 − 6 = <b>4</b>, yuzi 4 · 7 = <b>28 m²</b>','Tekshirish: 24 + 18 + 28 = 70 = 10 · 7 ✓'][k])}
var P8=[function(){h5Plan(0)},function(){h5Plan(1)},function(){h5Plan(2)},function(){h5Plan(3)}];
var H5TG=[[[0,0],[4,0],[2,2],'#e0713b',4],[[0,0],[2,2],[0,4],'#1f6fb2',4],[[2,4],[4,4],[4,2],'#2f8f5b',2],[[4,0],[4,2],[3,1],'#d68910',1],[[2,2],[3,3],[1,3],'#8e44ad',1],[[2,2],[3,1],[4,2],[3,3],'#c0392b',2],[[0,4],[1,3],[3,3],[2,4],'#16a085',2]];
function h5Tan(on){clear('#ffffff');var g=S.g,s=32,x0=116,y0=22;H5TG.forEach(function(pc2){var pts=pc2.slice(0,pc2.length-2),cx=0,cy=0;g3Poly(pts.map(function(p){cx+=p[0];cy+=p[1];return [x0+p[0]*s,y0+p[1]*s]}),{fill:pc2[pc2.length-2],stroke:'#fff',sw:2});if(on)T(g,x0+cx/pts.length*s,y0+cy/pts.length*s+4,String(pc2[pc2.length-1]),{'font-size':12,'font-weight':800,fill:'#fff'})});
 g3Msg(on?'4 + 4 + 2 + 1 + 1 + 2 + 2 = <b>16</b> = 4 · 4 ✓':'Tangram: 7 bo‘lakdan kvadrat (4 × 4)')}
var STEPS=[
{h:"Katakli shakl yuzi",sum:"Katakli shakl yuzi — ichidagi kataklar soni (qator-ustun bo'yicha sanash).",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Katakli qog'ozdagi shaklning yuzini topish uchun kataklarni <b>guruhlab</b> sanaymiz:</p>",
 btns:[phaser(P1,'▦ Sanash')],
 after:"<p>Kataklarni birma-bir emas, <b>qator va ustunlar</b> bilan sanang: 4 + 3 + 3 = <b>10 sm²</b>. Yarim kataklar bo'lsa — ikkita yarim = bitta butun.</p>",
 q:{t:"Shakl 3 qatordan iborat: 5, 5 va 2 katak. Yuzi (1 katak = 1 sm²)?",opts:["10 sm²","12 sm²","15 sm²","7 sm²"],ok:1,why:"5 + 5 + 2 = 12.",hint:"Har qatordagi kataklarni qo'shing.",full:"5 + 5 + 2 = 12 sm². «15» — 3 · 5 (oxirgi qator to'liq emas), «10» — oxirgi qator unutilgan."},
 tn:"Bolalarga katakli qog'ozda o'z «harf» shaklini chizdirib, yuzini sanattiring."},
{h:"Katakli shakl perimetri",sum:"Perimetr — chegaradagi katak tomonlari soni. «Xoch» (5 katak): S = 5, P = 12.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=4;P2[4]()},
 html:"<p>Perimetrni topish uchun shakl <b>chegarasi</b> bo'ylab katak tomonlarini sanaymiz (ichki chiziqlar hisob emas):</p>",
 btns:[phaser(P2,'🔴 Sanash')],
 after:"<p>Xoch shaklning yuzi atigi 5 sm², lekin perimetri <b>12 sm</b>. Shakl qancha «tarmoqlangan» bo'lsa, perimetri shuncha katta.</p>",
 q:{t:"4 katak 2 × 2 kvadrat shaklida joylashgan (1 katak = 1 sm). Perimetri?",opts:["16 sm","8 sm","4 sm","12 sm"],ok:1,why:"Tomoni 2 sm kvadrat: 2 · 4 = 8.",hint:"Faqat tashqi chegara tomonlarini sanang.",full:"Chegarada 8 ta katak tomoni: P = 8 sm. «16» — har katakning 4 tomoni sanalgan (ichki tomonlar ham)."},
 tn:"Daftar kataklarida bolalar shakl chegarasini qizil qalam bilan aylantirib, tomonlarni sanasin."},
{h:"Murakkab shakl yuzi: ikki usul",sum:"Bo'laklarga ajratib qo'shish yoki katta to'rtburchakdan ayirish: 30 + 9 = 48 − 9 = 39.",a:"m03",
 start:function(){h5L(0)},fin:function(){h5L(2)},
 html:"<p>L shaklning yuzini ikki xil usulda topamiz. Ikkalasini sinang:</p>",
 btns:[["✂️ Bo'lish",function(c,done){h5L(1);mvK(done,2)}],["➖ Ayirish",function(c,done){h5L(2);mvK(done,2)}]],g2:1,
 after:"<p>Ikkala usul ham <b>39 sm²</b> beradi. 1) Bo'laklarga bo'lib <b>qo'shish</b>. 2) Butun to'rtburchakdan yetishmaganini <b>ayirish</b>. Qulayini tanlang, ikkinchisi bilan tekshiring.</p>",
 q:{t:"6 × 6 kvadratning o'rtasidan 2 × 2 teshik qirqildi. Qolgan yuz?",opts:["36","32","4","40"],ok:1,why:"36 − 4 = 32.",hint:"Butun kvadrat yuzidan teshik yuzini ayiring.",full:"Butun: 36, teshik: 4, qoldi: 32. «40» — qo'shib yuborilgan."},
 tn:"Ikki usulni ikki guruhga bering — natijalar bir xil chiqishini o'zlari ko'rsin."},
{h:"Qirqilgan to'rtburchak",sum:"20 · 12 − 8 · 5 = 240 − 40 = 200 sm².",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Masala: <i>«Bo'yi 20 sm, eni 12 sm to'g'ri to'rtburchakning burchagidan bo'yi 8 sm, eni 5 sm to'g'ri to'rtburchak qirqildi. Qolgan qism yuzi?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Ayirish usuli: 240 − 40 = <b>200 sm²</b>. Xato yo'llar: 240 + 40 = 280 (qo'shish) yoki 20 · 12 − 8 − 5.</p>",
 q:{t:"Tomorqa 12 m × 10 m. Uning 12 m × 6 m qismiga sabzavot, qolganiga gul ekildi. Gul ekilgan yuz?",opts:["72 m²","48 m²","120 m²","28 m²"],ok:1,why:"120 − 72 = 48 yoki 12 · 4 = 48.",hint:"Gul qismining eni qancha?",full:"Gul qismi 12 × (10 − 6) = 12 × 4 = 48 m². Yoki 120 − 72 = 48. «72» — sabzavot qismi."},
 tn:"Qog'oz to'rtburchakdan haqiqatan burchak qirqib, kataklarni sanattiring."},
{h:"Tuzoq: burchak qirqilsa perimetr?",sum:"To'g'ri to'rtburchak burchagidan to'rtburchak qirqilsa: yuz kamayadi, perimetr o'zgarmaydi.",a:"m05",
 start:function(){h5Same(0)},fin:function(){h5Same(2)},
 html:"<p>6 × 4 to'g'ri to'rtburchak burchagidan 2 × 1 qirqildi. Yuz va perimetr qanday o'zgardi?</p>",
 btns:[["Yuz",function(c,done){h5Same(1);mvK(done,2)}],["Perimetr",function(c,done){h5Same(2);mvK(done,2)}]],g2:1,
 after:"<p>Qirqilgan joyda ikki tashqi tomon o'rniga <b>xuddi shunday uzunlikdagi</b> ikki ichki tomon paydo bo'ldi. Shuning uchun <b>perimetr o'zgarmaydi</b> (20), yuz esa <b>kamayadi</b> (22).</p>",
 q:{t:"20 × 12 to'rtburchak burchagidan 8 × 5 qirqildi. Hosil bo'lgan shakl perimetri?",opts:["64 sm","48 sm","54 sm","80 sm"],ok:0,why:"Burchak qirqilganda perimetr o'zgarmaydi: (20 + 12) · 2 = 64.",hint:"Qirqilgan joydagi yangi tomonlar qaysi tomonlarga teng?",full:"Yangi ichki tomonlar (8 va 5) yo'qolgan tashqi bo'laklarga teng. P = (20 + 12) · 2 = 64 sm. «48» — 8 va 5 ayirilgan."},
 tn:"Ip bilan ikkala shaklni aylantirib o'lchang — uzunlik bir xil!"},
{h:"«T» shakli",sum:"T: 10 · 3 + 4 · 6 = 54 sm²; P = 20 + 18 = 38 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>«T» harfi shaklidagi figuraning yuzi va perimetrini topamiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Yuz — bo'laklar yig'indisi: <b>54 sm²</b>. Perimetrda gorizontal va vertikal bo'laklarni alohida qo'shing: 20 + 18 = <b>38 sm</b>. Har bir tomonni bir martadan sanash uchun chizmada belgilab boring.</p>",
 q:{t:"Ikki to'rtburchak 5 × 4 va 3 × 4 balandliklari teng holda yonma-yon qo'yildi. Hosil shakl perimetri?",opts:["36","24","32","18"],ok:1,why:"Yangi shakl 8 × 4: (8 + 4) · 2 = 24.",hint:"Ular birga qanday to'rtburchak hosil qiladi?",full:"8 × 4 to'rtburchak: P = 24. «36» — ikkala perimetr qo'shilgan (18 + 18), ichki tomon ham sanalgan. «32» — bu yuz."},
 tn:"Bolalar T shaklini katakli qog'ozga chizib, chegarani rangli qalam bilan sanasin."},
{h:"Tuzoq: «П» chuqurcha",sum:"Ichkariga kirgan chuqurcha devorlari perimetrga qo'shiladi: 20 + 2 + 2 = 24.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Zinapoyada pog'onalarni «surish» mumkin edi. Ammo shaklda <b>chuqurcha</b> bo'lsa-chi?</p>",
 btns:[phaser(P7)],
 after:"<p>Chuqurchaning ikki yon devori tashqi chegaraga surilmaydi — ular <b>qo'shimcha</b> qo'shiladi: P = 20 + 2 · 2 = <b>24 sm</b>.</p>",
 q:{t:"8 × 5 to'rtburchakning yuqori tomoni o'rtasidan eni 2, chuqurligi 3 bo'lgan chuqurcha qirqildi. Perimetri?",opts:["26","32","30","34"],ok:1,why:"26 + 3 + 3 = 32.",hint:"To'rtburchak perimetri + chuqurchaning ikki devori.",full:"(8 + 5) · 2 = 26, chuqurchaning ikki devori 3 + 3 = 6. P = 32. «26» — devorlar unutilgan."},
 tn:"Doskada chuqurcha devorlarini boshqa rangda ko'rsating — ular «ortiqcha» yo'l."},
{h:"Uy plani",sum:"Uy 10 × 7, A xona 6 × 4 → B: 6 × 3 = 18, C: 4 × 7 = 28.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>Uy plani: barcha xonalar to'g'ri to'rtburchak. Ba'zi o'lchamlar yozilmagan — ularni <b>ayirish</b> bilan topamiz:</p>",
 btns:[phaser(P8)],
 after:"<p>Noma'lum tomon = umumiy tomon − ma'lum bo'lak. B: 7 − 4 = 3, C: 10 − 6 = 4. Xonalar yuzlari yig'indisi uyning yuziga teng: 70 m² ✓</p>",
 q:{t:"Uy 10 m × 7 m, A xona 6 × 4 m. Qolgan xonalarning umumiy yuzi?",opts:["24 m²","46 m²","34 m²","70 m²"],ok:1,why:"70 − 24 = 46.",hint:"Butun uydan A xonani ayiring.",full:"Uy: 10 · 7 = 70 m², A: 24 m², qolgan: 46 m² (18 + 28). «24» — A xonaning o'zi."},
 tn:"Sinf yoki maktab plani chizib, xonalar yuzini hisoblating."},
{h:"Bilasizmi? Tangram",sum:"Tangram — 7 bo'lakli qadimiy Xitoy jumbog'i: undan yig'ilgan har qanday shaklning yuzi bir xil.",a:"m09",
 start:function(){h5Tan(0)},fin:function(){h5Tan(1)},
 html:"<p>🧩 <b>Tangram</b> — qadimiy Xitoy jumbog'i: kvadrat 7 bo'lakka kesilgan. Ulardan mushuk, uy, odam — yuzlab shakl yig'iladi. Bo'laklar yuzini sanang:</p>",
 btns:[["🔢 Yuzlarni ko'rsatish",function(c,done){h5Tan(1);done()}]],
 after:"<p>Bo'laklar yuzlari yig'indisi 16 = kvadrat yuzi. Tangramdan qaysi shakl yig'ilmasin, uning yuzi doim <b>16</b> bo'ladi — chunki o'sha 7 bo'lak ishlatiladi. Perimetrlari esa har xil!</p>",
 tn:"Kartondan tangram qirqib, bolalar shakllar yig'sin va yuz o'zgarmasligini muhokama qiling."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h5L(1)},fin:function(){h5L(1)},
 html:"<div class='memo'><ul><li>Katakli shakl: yuz — kataklar, perimetr — chegaradagi tomonlar.</li><li>Murakkab shakl yuzi: <b>bo'lib qo'shish</b> yoki <b>butundan ayirish</b>.</li><li>Burchak qirqilsa: yuz kamayadi, perimetr <b>o'zgarmaydi</b>.</li><li>Chuqurcha (П): perimetrga ikki devor <b>qo'shiladi</b>.</li><li>Yonma-yon shakllar: ichki tomonlar perimetrga kirmaydi.</li><li>Noma'lum tomon = butun − ma'lum bo'lak.</li></ul></div>",
 tn:"Uyga: o'z xonangiz plani va yuzini chizib keling."}
];
var PROBS=[
{t:"Shakl 3 qatordan iborat: 5, 5 va 2 katak (1 katak = 1 sm²). Yuzi?",o:["12 sm²","10 sm²","15 sm²","7 sm²"],k:0,s:"5 + 5 + 2 = 12."},
{t:"«Xoch» shakli 5 katakdan (tomoni 1 sm). Perimetri?",o:["12 sm","20 sm","16 sm","10 sm"],k:0,s:"Chegarada 12 tomon."},
{t:"4 katak 2 × 2 kvadrat shaklida (1 katak tomoni 1 sm). Perimetri?",o:["8 sm","16 sm","4 sm","12 sm"],k:0,s:"2 · 4 = 8."},
{t:"3 katak bir qatorda (tomoni 1 sm). Perimetri?",o:["8 sm","12 sm","6 sm","10 sm"],k:0,s:"(3 + 1) · 2 = 8."},
{t:"3 katak «L» shaklida (tomoni 1 sm). Perimetri?",o:["8 sm","6 sm","10 sm","12 sm"],k:0,s:"2 × 2 dan burchak qirqilgan: P o'zgarmaydi — 8."},
{t:"20 × 12 sm to'rtburchak burchagidan 8 × 5 sm qirqildi. Qolgan yuz?",o:["200 sm²","240 sm²","280 sm²","64 sm²"],k:0,s:"240 − 40 = 200."},
{t:"20 × 12 sm to'rtburchak burchagidan 8 × 5 sm qirqildi. Hosil shakl perimetri?",o:["64 sm","48 sm","54 sm","80 sm"],k:0,s:"O'zgarmaydi: 64."},
{t:"Tomorqa 12 m × 10 m, 12 m × 6 m qismiga sabzavot. Qolgan qism yuzi?",o:["48 m²","72 m²","120 m²","22 m²"],k:0,s:"12 · 4 = 48."},
{t:"«T» shakl: yuqori qismi 10 × 3, oyog'i 4 × 6 sm. Yuzi?",o:["54 sm²","60 sm²","30 sm²","90 sm²"],k:0,s:"30 + 24 = 54."},
{t:"«T» shakl: yuqori qismi 10 × 3, oyog'i 4 × 6 sm. Perimetri?",o:["38 sm","54 sm","26 sm","46 sm"],k:0,s:"20 + 18 = 38."},
{t:"6 × 6 sm kvadrat o'rtasidan 2 × 2 sm teshik qirqildi. Qolgan yuz?",o:["32 sm²","36 sm²","4 sm²","40 sm²"],k:0,s:"36 − 4 = 32."},
{t:"5 × 4 va 3 × 4 to'rtburchaklar 4 sm li tomonlari bilan yonma-yon qo'yildi. Perimetri?",o:["24 sm","36 sm","32 sm","18 sm"],k:0,s:"8 × 4: 24."},
{t:"Zinapoya: 1, 2, 3 katakli ustunlar yonma-yon (1 katak tomoni 1 sm). Perimetri?",o:["12 sm","6 sm","18 sm","14 sm"],k:0,s:"Surish: (3 + 3) · 2 = 12."},
{t:"6 × 4 to'rtburchak yuqori tomonidan eni 2, chuqurligi 2 chuqurcha qirqildi. Perimetri?",o:["24","20","16","28"],k:0,s:"20 + 2 + 2 = 24."},
{t:"6 × 4 to'rtburchakdan 2 × 2 chuqurcha qirqildi. Yuzi?",o:["20","24","16","22"],k:0,s:"24 − 4 = 20."},
{t:"Uy 10 m × 7 m, bir xona 6 m × 4 m. Qolgan xonalar umumiy yuzi?",o:["46 m²","24 m²","34 m²","70 m²"],k:0,s:"70 − 24 = 46."},
{t:"Tomoni 3 sm bo'lgan 4 ta kvadrat bir qatorda. Perimetri?",o:["30 sm","48 sm","36 sm","24 sm"],k:0,s:"12 × 3: (12 + 3) · 2 = 30."},
{t:"Tomoni 3 sm bo'lgan 4 ta kvadrat 2 × 2 blok qilib qo'yildi. Perimetri?",o:["24 sm","48 sm","36 sm","30 sm"],k:0,s:"6 × 6 kvadrat: 24."},
{t:"Katak tomoni 2 sm. Shakl 7 katakdan iborat. Yuzi?",o:["28 sm²","7 sm²","14 sm²","49 sm²"],k:0,s:"1 katak = 4 sm², 7 · 4 = 28."},
{t:"8 × 6 sm to'rtburchakdan bo'yi bo'ylab 8 × 2 sm polosa qirqib olindi. Qolgan qism perimetri?",o:["24 sm","28 sm","32 sm","16 sm"],k:0,s:"8 × 4: (8 + 4) · 2 = 24."}
];
function PRACT_STAGE(){h5L(1)}
var PREP_DATA={teach:["Katakli shakllar yuzi (sanash) va perimetri (chegara tomonlari).","Murakkab shakl yuzi: bo'lib qo'shish va butundan ayirish.","Burchak qirqilganda perimetr o'zgarmasligi; chuqurchada devorlar qo'shilishi.","Plan masalalari: noma'lum tomonni ayirish bilan topish."],
 mist:["Perimetrda ichki chiziqlarni ham sanaydi.","Qirqilgan shakl perimetrini kamaygan deb o'ylaydi.","Chuqurcha devorlarini unutadi.","Yuz va perimetrni bir son deb adashtiradi.","Noma'lum tomonni topmasdan ko'paytiradi."],
 need:["Katakli qog'oz, rangli qalamlar, qaychi.","Karton tangram, ip."],
 board:["L: <span class='w2'>30 + 9 = 48 − 9 = 39</span>.","Qirqish: S kamayadi, <span class='w2'>P o'zgarmaydi</span>.","П: <span class='w2'>20 + 2 + 2 = 24</span>.","T: 30 + 24 = 54; P = 20 + 18 = 38."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
