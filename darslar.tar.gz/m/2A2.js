var CODE='2A2',TITLE='2-sinf · Sonlarni taqqoslash (>, <, =)';
// ---------- sahna: ikki son yonma-yon, o'rtada belgi ----------
var CMP={};
function two(a,b,opt){opt=opt||{};clear();var g=S.g;
 E('rect',{x:8,y:10,width:150,height:132,rx:12,fill:'#fdf3e3',stroke:'#efd9b5'},g);E('rect',{x:202,y:10,width:150,height:132,rx:12,fill:'#fdf3e3',stroke:'#efd9b5'},g);
 var A=numPic(g,a,14,30,{t:opt.ta,u:opt.ua,h:92}),Bp=numPic(g,b,208,30,{t:opt.tb,u:opt.ub,h:92});
 CMP.A=A;CMP.B=Bp;
 T(g,83,162,opt.la!=null?opt.la:String(a),{'font-size':20,'font-weight':800,fill:'#1d2b3a'});T(g,277,162,opt.lb!=null?opt.lb:String(b),{'font-size':20,'font-weight':800,fill:'#1d2b3a'});
 CMP.sign=E('g',{},g);E('circle',{cx:180,cy:76,r:19,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},CMP.sign);CMP.st=T(CMP.sign,180,85,opt.sign||'?',{'font-size':26,'font-weight':800,fill:opt.sign?C.blue:'#9aa8b6'});
 if(opt.tap){[[8,'L'],[202,'R']].forEach(function(z){var r=E('rect',{x:z[0],y:10,width:150,height:132,rx:12,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){opt.tap(z[1],r)})})}}
function setSign(s,col){CMP.st.textContent=s;CMP.st.setAttribute('fill',col||C.blue)}
function hlRods(p,on){[].forEach.call(p.querySelectorAll('rect'),function(r){r.setAttribute('stroke',on?C.bad:'#d9b98a');r.setAttribute('stroke-width',on?3:1.3)})}
function hlUnits(p,on){[].forEach.call(p.querySelectorAll(':scope > circle'),function(c){c.setAttribute('stroke',on?C.bad:'rgba(0,0,0,.15)');c.setAttribute('stroke-width',on?2.5:1)})}
function pvStrip(a,b,sign,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="font-size:22px;text-align:center">'+a+' <b style="color:#1f6fb2">'+(sign||'?')+'</b> '+b+'</div></div>'}
// son o'qi
function line(from,to,marks){clear();var x0=20,x1=340,y=96,k=(x1-x0)/(to-from);var X=function(v){return x0+(v-from)*k};
 E('line',{x1:x0-6,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);E('path',{d:'M'+(x1+8)+' '+(y-6)+' L'+(x1+16)+' '+y+' L'+(x1+8)+' '+(y+6)+' Z',fill:'#33475b'},S.g);
 for(var v=from;v<=to;v++){var big=v%5===0;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+26,String(v),{'font-size':12,fill:'#5b6b7b'})}
 T(S.g,x1-10,y-28,'katta →',{'font-size':12,fill:C.ok,'font-weight':800});T(S.g,x0+24,y-28,'← kichik',{'font-size':12,fill:C.bad,'font-weight':800});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:8,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},S.g);T(S.g,X(m[0]),y-16,String(m[0]),{'font-size':15,'font-weight':800,fill:m[1]||C.blue})});S.X=X}
// ---------- bosqichlar ----------
var P3=[function(){two(52,48);pvStrip(52,48,null,'48 da 8 ta birlik — ko‘p. Demak 48 katta? Tekshiramiz…')},
 function(){two(52,48);hlRods(CMP.A,1);hlRods(CMP.B,1);pvStrip('<span style="color:#d94b4b">5</span>2','<span style="color:#d94b4b">4</span>8',null,'Avval O‘NLIKLAR: 5 ta va 4 ta tayoqcha')},
 function(){two(52,48,{sign:'>'});hlRods(CMP.A,1);pvStrip(52,48,'>','5 o‘nlik > 4 o‘nlik — birliklarga qaramaymiz ham!')}];
var P4=[function(){two(63,67);pvStrip(63,67,null,'O‘nliklar: 6 va 6 — teng')},
 function(){two(63,67);hlUnits(CMP.A,1);hlUnits(CMP.B,1);pvStrip('6<span style="color:#d94b4b">3</span>','6<span style="color:#d94b4b">7</span>',null,'O‘nliklar teng — endi BIRLIKLAR: 3 va 7')},
 function(){two(63,67,{sign:'<'});hlUnits(CMP.B,1);pvStrip(63,67,'<','3 birlik < 7 birlik, demak 63 < 67')}];
var P8=[function(){two(0,44,{ta:3,ua:15,la:'3 o‘nlik 15 birlik'});pvStrip('3 o‘nlik 15 birlik',44,null,'Birliklar 10 tadan ko‘p — avval tartibga keltiramiz')},
 function(){two(0,44,{ta:4,ua:5,la:'4 o‘nlik 5 birlik'});pvStrip('45',44,null,'15 birlikdan 10 tasi — yangi o‘nlik: 4 o‘nlik 5 birlik = 45')},
 function(){two(0,44,{ta:4,ua:5,la:'45',sign:'>'});pvStrip('3 o‘nlik 15 birlik = 45',44,'>','O‘nliklar teng (4 va 4), birliklar 5 > 4')}];
var STEPS=[
{h:"Qayerda ko'p?",sum:"Ikki to'pni solishtiramiz: o'nlik tayoqchalari ko'p bo'lgan to'p katta.",a:"m01",
 start:function(){var tries=0;two(34,43,{tap:function(z){if(st['a0'])return;if(z==='R'){setSign('<',C.ok);pvStrip(34,43,'<','To‘g‘ri! O‘ngda 4 ta tayoqcha, chapda 3 ta');actDone(0)}else{tries++;pvStrip(34,43,null,'Qayta qarang: tayoqchalarni sanang. Har bir tayoqcha — 10 ta!')}}});pvStrip(34,43,null,'Qaysi tomonda ko‘p? O‘sha tomonni bosing')},
 fin:function(){two(34,43,{sign:'<'});pvStrip(34,43,'<')},
 html:"<p>Tepada ikki to'p: chapda va o'ngda. Har bir <b>tayoqcha</b> — 10 ta (bitta o'nlik), har bir <b>nuqta</b> — 1 ta. Qaysi tomonda ko'p? <b>O'sha tomonni bosing.</b></p>",
 act:function(c){c.querySelector('.hint').textContent='Rasmdagi chap yoki o‘ng to‘pni bosing.'},
 after:"<p>O'ngda 4 ta tayoqcha (40) va 3 ta nuqta — <b>43</b>. Chapda 3 ta tayoqcha (30) va 4 ta nuqta — <b>34</b>. 43 ko'p!</p><p>Raqamlar bir xil (3 va 4), lekin o'nliklar soni hal qiladi.</p>",
 q:{t:"Qaysi son katta: 29 yoki 31?",opts:["29","31","Teng","29, chunki 9 katta"],ok:1,why:"31 da 3 ta o'nlik, 29 da 2 ta.",hint:"Har birida nechta o'nlik (tayoqcha) bor?",full:"29 = 2 ta o'nlik va 9 ta birlik. 31 = 3 ta o'nlik va 1 ta birlik. 3 ta o'nlik ko'p — 31 katta. 9 ta birlik birgalikda ham bitta o'nlikka yetmaydi."},
 tn:"Bolalar avval narsalarni (cho'p bog'lamlari, o'nlik tayoqchalari) solishtirsin, keyin sonlarni. Belgilarni keyingi qadamda kiritamiz."},
{h:"Belgilar: >, < va =",sum:"Belgining o'tkir uchi kichik songa, ochiq tomoni katta songa qaraydi: 34 < 43.",a:"m02",
 start:function(){two(34,43);pvStrip(34,43,null,'Belgini tanlang')},fin:function(){two(34,43,{sign:'<'});pvStrip(34,43,'<')},
 html:"<p>Matematikada taqqoslash uchun 3 ta belgi bor:</p><div class='life'><div><b style='font-size:26px'>&gt;</b><span><b>katta</b>: 43 &gt; 34</span></div><div><b style='font-size:26px'>&lt;</b><span><b>kichik</b>: 34 &lt; 43</span></div><div><b style='font-size:26px'>=</b><span><b>teng</b>: 25 = 25</span></div></div><p>Eslab qolish oson: belgining <b>ochiq tomoni</b> katta songa ochiladi, <b>o'tkir uchi</b> kichik songa tegadi. 34 va 43 orasiga to'g'ri belgini qo'ying:</p>",
 btns:[["<",function(c,done){setSign('<',C.ok);pvStrip(34,43,'<','To‘g‘ri! Uchi 34 ga, ochig‘i 43 ga qaragan');done()}],[">",function(c){setSign('>',C.bad);pvStrip(34,43,'>','Yo‘q: ochiq tomon 34 ga qaragan, lekin 34 kichik-ku')}],["=",function(c){setSign('=',C.bad);pvStrip(34,43,'=','Yo‘q: 34 va 43 teng emas')}]],
 after:"<p>34 &lt; 43 — «o'ttiz to'rt <b>kichik</b> qirq uchdan». Teskari o'qisak: 43 &gt; 34 — «qirq uch <b>katta</b> o'ttiz to'rtdan». Ikkalasi ham bir xil haqiqat!</p>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["57 < 75","57 > 75","57 = 75","75 < 57"],ok:0,why:"57 da 5 ta o'nlik, 75 da 7 ta — 57 kichik, uchi 57 ga qaraydi.",hint:"Avval qaysi son kichik ekanini toping. Belgining uchi o'sha songa qarashi kerak.",full:"57 = 5 o'nlik, 75 = 7 o'nlik. 57 kichik. To'g'ri yozuv: 57 < 75 (uchi 57 ga). «75 < 57» — belgi teskari qo'yilgan."},
 tn:"Ko'p mamlakatlarda «och timsoh katta songa og'iz ochadi» degan o'yin bor. Uni ishlatsangiz ham, oxirida «uchi kichikka» qoidasini albatta ayting — timsoh unutiladi, qoida qoladi."},
{h:"Avval o'nliklar!",sum:"52 va 48: avval o'nliklar — 5 > 4, demak 52 > 48. Birliklarga qaralmaydi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>52 va 48 — qaysi katta? 48 da <b>8</b> bor, 8 esa katta raqam… Shoshilmang! Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p><b>Qoida:</b> avval <b>o'nliklarni</b> solishtiramiz. Qaysi sonda o'nliklar ko'p bo'lsa — o'sha katta. Birliklar qancha bo'lishidan qat'i nazar! Chunki 9 ta birlik ham bitta o'nlikka yetmaydi.</p>",
 q:{t:"Qaysi son katta: 61 yoki 59?",opts:["59","61","Teng","59, chunki 9 katta"],ok:1,why:"6 ta o'nlik > 5 ta o'nlik.",hint:"Faqat o'nliklarga qarang: 6 va 5.",full:"Avval o'nliklar: 61 da 6 ta, 59 da 5 ta. 6 > 5, demak 61 > 59. 59 dagi 9 ta birlik bunga ta'sir qilmaydi."},
 tn:"Eng ko'p uchraydigan xato: bolalar katta raqamni ko'radi (48 dagi 8) va shu sonni katta deydi. Cho'p bog'lamlarida ko'rsatib bering."},
{h:"O'nliklar teng bo'lsa",sum:"63 va 67: o'nliklar teng (6 = 6) → birliklar: 3 < 7, demak 63 < 67.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>63 va 67 da o'nliklar bir xil — 6 tadan. Endi nima qilamiz?</p>",
 btns:[phaser(P4)],
 after:"<p>O'nliklar teng bo'lsa — <b>birliklarni</b> solishtiramiz. 3 &lt; 7, demak <b>63 &lt; 67</b>.</p><p>Hammasi bitta tartib: <b>1) o'nliklar → 2) birliklar</b>.</p>",
 q:{t:"Belgini qo'ying: 85 ... 82",opts:["<",">","="],ok:1,why:"O'nliklar teng, 5 birlik > 2 birlik.",hint:"O'nliklar teng-mi? Unda birliklarga qarang.",full:"85 va 82 da 8 tadan o'nlik — teng. Birliklar: 5 va 2. 5 > 2, demak 85 > 82."},
 tn:"Doskaga ikki ustunli jadval chizing: «o'nliklar | birliklar». Sonlarni ustma-ust yozib, chapdan o'ngga solishtiring."},
{h:"Son o'qida: o'ngdagisi katta",sum:"Son o'qida o'ngga borgan sari sonlar kattalashadi: 47 dan o'ngdagi 52 katta.",a:"m05",
 start:function(){line(40,60,[]);pvStrip(47,52,null,'Sonlarni son o‘qiga qo‘yamiz')},fin:function(){line(40,60,[[47,C.bad],[52,C.ok]]);pvStrip(47,52,'<','52 o‘ngda — katta')},
 html:"<p>Son o'qida sonlar tartib bilan turadi: <b>o'ngga</b> borgan sari kattalashadi. 47 va 52 ni o'qqa qo'ying.</p>",
 btns:[["📍 47",function(c,done,b){b.disabled=true;S.m=S.m||{};S.m[47]=1;line(40,60,Object.keys(S.m).map(function(v){return [+v,+v===47?C.bad:C.ok]}));if(S.m[52]){pvStrip(47,52,'<','52 o‘ngda — demak katta');done()}}],["📍 52",function(c,done,b){b.disabled=true;S.m=S.m||{};S.m[52]=1;line(40,60,Object.keys(S.m).map(function(v){return [+v,+v===47?C.bad:C.ok]}));if(S.m[47]){pvStrip(47,52,'<','52 o‘ngda — demak katta');done()}}]],g2:1,
 after:"<p>52 o'ngda — u katta: <b>47 &lt; 52</b>. Son o'qi ayniqsa «qaysi biri <b>yaqinroq</b>» yoki «<b>orasida</b> nechta» degan savollarda yordam beradi.</p>",
 q:{t:"Son o'qida qaysi son eng o'ngda turadi?",opts:["39","93","63","36"],ok:1,why:"Eng katta son eng o'ngda — 93.",hint:"O'ngdagi son kattami yoki kichik? Eng katta sonni toping.",full:"Son o'qida eng o'ngda eng katta son turadi. 39, 93, 63, 36 dan eng kattasi — 93 (9 ta o'nlik)."},
 tn:"Xalqaro tadqiqotlar son o'qini sonlarni tushunishning eng kuchli vositasi deb biladi. Sinf polida lenta bilan 0–100 o'qini yasab, bolalarni «son bo'lib» turg'izish mumkin."},
{h:"Tuzoq: yashiringan raqam",sum:"6□ < 64: □ o'rniga 0, 1, 2, 3 bo'ladi (4 ta). 64 ning o'zi bo'lmaydi — teng, kichik emas.",a:"m06",
 start:function(){hid(null)},fin:function(){hid(3,true)},
 html:"<p>Testlarda shunday savol keladi: <b>6□ &lt; 64</b>. Kvadrat o'rniga qaysi raqamlarni qo'yish mumkin? Raqamlarni bittalab sinab ko'ring:</p><div class='digs'></div>",
 act:function(c,done){var box=c.querySelector('.digs'),seen={};box.innerHTML='';for(var d=0;d<=9;d++)(function(d){var b=document.createElement('button');b.className='dg';b.textContent=d;b.onclick=function(){hid(d);var ok=d<4;b.className='dg '+(ok?'yes':'no');seen[d]=1;if(Object.keys(seen).length>=5&&!st['a'+cur])done()};box.appendChild(b)})(d)},
 after:"<p>Mos keladi: <b>0, 1, 2, 3</b> — 4 ta raqam. 4 ni qo'ysak, 64 = 64 bo'ladi — bu <b>teng</b>, «kichik» emas! Shuning uchun 4 ham mos kelmaydi.</p><p>Tez usul: o'nliklar teng (6 va 6) — demak birliklar 4 dan <b>kichik</b> bo'lishi kerak: 0, 1, 2, 3.</p>",
 q:{t:"7□ < 75 bo'lishi uchun □ o'rniga qo'yish mumkin bo'lgan eng katta raqam qaysi?",opts:["5","9","4","3"],ok:2,why:"Birlik 5 dan kichik bo'lishi kerak: eng kattasi 4 (74 < 75).",hint:"O'nliklar teng (7 va 7). Unda birlik 5 dan qanday bo'lishi kerak?",full:"O'nliklar teng, demak □ < 5: 0, 1, 2, 3, 4. Eng kattasi — 4: 74 < 75. «5» bo'lmaydi: 75 = 75 — teng."},
 tn:"«Kichik» va «kichik yoki teng» farqini aniq ayting. Bolalar ko'pincha chegaradagi raqamni (4) ham qo'shib yuboradi."},
{h:"Tuzoq: o'nlik va birlik bilan berilsa",sum:"3 o'nlik 15 birlik = 45 > 44. Avval birliklarni tartibga keltiramiz.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>«3 o'nlik 15 birlik» va 44 — qaysi katta? 3 ta o'nlik 4 tadan kam-ku… Lekin shoshilmang!</p>",
 btns:[phaser(P8)],
 after:"<p>15 ta birlikdan 10 tasi — yana bitta o'nlik. Shuning uchun <b>3 o'nlik 15 birlik = 45</b>, va <b>45 &gt; 44</b>.</p><p>Qoida: birliklar 9 tadan ko'p bo'lsa — avval o'nlikka aylantiring, keyin solishtiring.</p>",
 q:{t:"Qaysi taqqoslash to'g'ri?",opts:["2 o'nlik 13 birlik > 34","2 o'nlik 13 birlik < 30","2 o'nlik 13 birlik = 33","2 o'nlik 13 birlik = 213"],ok:2,why:"13 birlik = 1 o'nlik 3 birlik → 3 o'nlik 3 birlik = 33.",hint:"13 ta birlikdan 10 tasini o'nlikka aylantiring. Nechta o'nlik bo'ladi?",full:"2 o'nlik 13 birlik: 13 dan 10 tasi — 1 o'nlik. Jami 3 o'nlik 3 birlik = 33. Demak «= 33» to'g'ri. 33 > 30, 33 < 34."},
 tn:"Bu bank testlarida tez-tez keladi. Bolalar cho'p bilan qilib ko'rsin: 15 ta donadan 10 tasini bog'lasin."},
{h:"Tartib bilan teramiz",sum:"O'sish tartibi — kichikdan kattaga: 29, 35, 53, 92. Har safar qolganlarning eng kichigini olamiz.",a:"m08",
 start:function(){ord([])},fin:function(){ord([29,35,53,92])},
 html:"<p>Sonlarni <b>o'sish tartibida</b> (kichikdan kattaga) teraylik. Pastdagi sonlarni <b>eng kichigidan</b> boshlab bosing:</p><div class='digs ordb'></div>",
 act:function(c,done){var box=c.querySelector('.ordb'),need=[29,35,53,92],got=[];box.innerHTML='';[53,92,29,35].forEach(function(v){var b=document.createElement('button');b.className='dg wide';b.textContent=v;b.onclick=function(){if(b.disabled)return;if(v===need[got.length]){got.push(v);b.disabled=true;b.className='dg wide yes';ord(got);if(got.length===4)done()}else{b.className='dg wide no';setTimeout(function(){b.className='dg wide'},1200);ordMsg('Bu hali eng kichigi emas — qolganlarini solishtiring')}};box.appendChild(b)})},
 after:"<p>Usul: har safar qolgan sonlar ichidan <b>eng kichigini</b> topamiz — avval o'nliklar bo'yicha, o'nliklar teng bo'lsa birliklar bo'yicha. 35 va 53 da raqamlar bir xil, lekin 35 da 3 ta o'nlik — u oldin keladi.</p>",
 q:{t:"Shohjahon 39, 65, 44, 91, 82, 18, 36, 99, 47, 29 sonlarini o'sish tartibida yozdi. 7-o'rinda qaysi son turadi?",opts:["44","65","82","47"],ok:1,why:"18, 29, 36, 39, 44, 47, 65 — 7-o'rinda 65.",hint:"Sonlarni kichikdan kattaga yozib chiqing va 7 tasini sanang.",full:"Tartib: 18, 29, 36, 39, 44, 47, 65, 82, 91, 99. Sanaymiz: 1) 18, 2) 29, 3) 36, 4) 39, 5) 44, 6) 47, 7) 65. Javob: 65."},
 tn:"Bolalar sonlarni kartochkalarga yozib, stol ustida tartiblasin. «Kamayish tartibi» — teskarisi ekanini ham ayting."},
{h:"Bilasizmi? Belgilar tarixi",sum:"«=» belgisini 1557-yilda Robert Rekord, «>» va «<» ni Tomas Xarriot o'ylab topgan.",a:"m09",
 start:function(){hist()},fin:function(){hist()},
 html:"<p>📜 Bundan 470 yil oldin olimlar «teng» so'zini har safar so'z bilan yozishardi. Uelslik matematik <b>Robert Rekord</b> 1557-yilda <b>=</b> belgisini o'ylab topdi: «ikki parallel chiziqdan ko'ra tengroq narsa yo'q» degan.</p><p>📜 <b>&gt;</b> va <b>&lt;</b> belgilarini ingliz olimi <b>Tomas Xarriot</b> kiritgan, ular 1631-yilda kitobida chop etilgan.</p><p>⭐ Undan ancha oldin, IX asrda vatandoshimiz <b>al-Xorazmiy</b> tenglamalarni so'z bilan yozgan — belgilar keyin paydo bo'lgan.</p>",
 tn:"Bolalarga «belgilarni ham kimdir o'ylab topgan» degan fikr juda yoqadi. O'z belgisini o'ylab topishni so'rang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){two(52,48,{sign:'>'});pvStrip(52,48,'>')},fin:function(){two(52,48,{sign:'>'});pvStrip(52,48,'>')},
 html:"<div class='memo'><ul><li><b>&gt;</b> katta, <b>&lt;</b> kichik, <b>=</b> teng. Belgining <b>uchi kichik songa</b> qaraydi.</li><li><b>1) Avval o'nliklar</b>: 52 &gt; 48 (5 &gt; 4), birliklarga qaralmaydi.</li><li><b>2) O'nliklar teng bo'lsa — birliklar</b>: 63 &lt; 67.</li><li>Son o'qida <b>o'ngdagi</b> son katta.</li><li>Ikki xonali son har doim bir xonalidan katta: 10 &gt; 9.</li><li>6□ &lt; 64: □ = 0, 1, 2, 3. <b>4 bo'lmaydi</b> — teng bo'lib qoladi.</li><li>Birliklar 9 dan ko'p bo'lsa, avval o'nlikka aylantiring: 3 o'nlik 15 birlik = 45.</li><li>O'sish tartibi — kichikdan kattaga, kamayish — kattadan kichikka.</li></ul></div>",
 tn:"Keyingi darsni «3□ > □8, ikkala □ da bir xil raqam» savoli bilan boshlang (javob: 2 ta raqam — 1 va 2: 31 > 18, 32 > 28)."}
];
// yashiringan raqam sahnasi
function hid(d,all){clear();var g=S.g;T(g,180,40,'6□ < 64',{'font-size':30,'font-weight':800,fill:'#1d2b3a'});
 if(d!=null&&!all){var ok=d<4;T(g,180,95,'6'+d+(ok?' < ':(d===4?' = ':' > '))+'64',{'font-size':34,'font-weight':800,fill:ok?C.ok:C.bad});T(g,180,135,ok?'✓ to‘g‘ri':(d===4?'✗ teng — «kichik» emas':'✗ katta bo‘lib qoldi'),{'font-size':15,'font-weight':800,fill:ok?C.ok:C.bad})}
 if(all){T(g,180,100,'60, 61, 62, 63  <  64',{'font-size':26,'font-weight':800,fill:C.ok});T(g,180,140,'4 ta raqam: 0, 1, 2, 3',{'font-size':15,'font-weight':800,fill:C.blue})}
 strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">O‘nliklar teng (6 va 6) → birlik 4 dan <b>kichik</b> bo‘lishi kerak</div></div>'}
function ord(got){clear();var g=S.g;T(g,180,30,'O‘sish tartibi: kichikdan kattaga',{'font-size':13,fill:C.blue,'font-weight':800});
 for(var i=0;i<4;i++){var x=40+i*80;E('rect',{x:x-28,y:58,width:56,height:44,rx:10,fill:got[i]?'#e6f6ee':'#fff',stroke:got[i]?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,88,got[i]?String(got[i]):'?',{'font-size':22,'font-weight':800,fill:got[i]?C.ok:'#9aa8b6'});if(i<3)T(g,x+40,88,'<',{'font-size':20,'font-weight':800,fill:'#9aa8b6'})}
 strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">Har safar qolganlarning <b>eng kichigini</b> tanlang</div></div>'}
function ordMsg(m){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center;color:#d94b4b">'+m+'</div></div>'}
function hist(){clear('#f6ead0');var g=S.g;T(g,70,95,'=',{'font-size':70,'font-weight':800,fill:'#6b3d12'});T(g,70,140,'1557 · Rekord',{'font-size':12,fill:'#6b3d12'});T(g,180,95,'>',{'font-size':70,'font-weight':800,fill:'#6b3d12'});T(g,290,95,'<',{'font-size':70,'font-weight':800,fill:'#6b3d12'});T(g,235,140,'1631 · Xarriot',{'font-size':12,fill:'#6b3d12'});
 strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">Belgilar ham kimningdir ixtirosi!</div></div>'}
var PROBS=[
{t:"Qaysi son katta: 38 yoki 83?",o:["83","38","Teng","38, chunki 8 katta"],k:0,s:"83 da 8 ta o'nlik, 38 da 3 ta. 83 katta."},
{t:"Belgini qo'ying: 47 ... 74",o:["<",">","="],k:0,s:"4 o'nlik < 7 o'nlik: 47 < 74."},
{t:"Belgini qo'ying: 56 ... 52",o:[">","<","="],k:0,s:"O'nliklar teng, 6 birlik > 2 birlik: 56 > 52."},
{t:"Qaysi yozuv noto'g'ri?",o:["69 > 71","71 > 69","40 < 44","90 > 89"],k:0,s:"69 da 6 ta o'nlik, 71 da 7 ta: 69 < 71. «69 > 71» noto'g'ri."},
{t:"Qaysi qatorda sonlar o'sish tartibida yozilgan?",o:["29, 35, 53, 92","92, 53, 35, 29","35, 29, 53, 92","29, 53, 35, 92"],k:0,s:"Kichikdan kattaga: 29, 35, 53, 92."},
{t:"7□ < 75 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin?",o:["5","4","6","10"],k:0,s:"O'nliklar teng — birlik 5 dan kichik: 0, 1, 2, 3, 4 — 5 ta."},
{t:"4□ > 46 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin?",o:["3","4","6","2"],k:0,s:"Birlik 6 dan katta: 7, 8, 9 — 3 ta."},
{t:"6□ < 64 bo'lishi uchun □ o'rniga qo'yish mumkin bo'lgan barcha raqamlar yig'indisi?",o:["6","10","4","3"],k:0,s:"Raqamlar: 0, 1, 2, 3. Yig'indisi: 0 + 1 + 2 + 3 = 6."},
{t:"Qaysi taqqoslash to'g'ri?",o:["5 o'nlik 3 birlik > 49","8 o'nlik < 79","6 o'nlik 6 birlik = 60","3 o'nlik 15 birlik < 44"],k:0,s:"5 o'nlik 3 birlik = 53 > 49. Qolganlari: 80 > 79, 66 ≠ 60, 45 > 44."},
{t:"Qaysi taqqoslash noto'g'ri?",o:["8 o'nlik 2 birlik < 80","9 o'nlik > 89","6 o'nlik > 59","3 o'nlik 7 birlik = 37"],k:0,s:"8 o'nlik 2 birlik = 82, 82 > 80. Demak «< 80» noto'g'ri."},
{t:"Bekzodda 18 ta marka bor. Jasurning markalari ko'proq, lekin 30 tadan kam va soni 3 bilan tugaydi. Jasurda nechta marka bor?",o:["23","13","33","43"],k:0,s:"18 dan katta, 30 dan kichik, 3 bilan tugaydi: 23."},
{t:"Ali 47 ni yozdi, Vali uning raqamlari o'rnini almashtirdi. Kimning soni katta va qanchaga?",o:["Valiniki 27 ga","Aliniki 27 ga","Teng","Valiniki 3 ga"],k:0,s:"Vali: 74. 74 > 47, farq 74 − 47 = 27."},
{t:"Eng kichik ikki xonali son va eng katta bir xonali sonni taqqoslang.",o:["10 > 9","10 < 9","10 = 9","9 > 10"],k:0,s:"Eng kichik ikki xonali — 10, eng katta bir xonali — 9. 10 > 9."},
{t:"Qaysi son 50 dan katta, lekin 55 dan kichik?",o:["53","57","50","45"],k:0,s:"50 < 53 < 55. 50 ning o'zi «katta» emas — teng."},
{t:"Kamayish tartibida yozilgan qatorni toping.",o:["81, 64, 46, 18","18, 46, 64, 81","64, 81, 46, 18","81, 46, 64, 18"],k:0,s:"Kattadan kichikka: 81, 64, 46, 18."},
{t:"3□ > □8 tengsizlikda ikkala □ da bir xil raqam (1–9). Nechta raqam to'g'ri keladi?",o:["2","1","3","4"],k:0,s:"Sinaymiz: 1 → 31 > 18 ✓, 2 → 32 > 28 ✓, 3 → 33 > 38 ✗, 4 → 34 > 48 ✗… Faqat 1 va 2 — 2 ta."},
{t:"Son o'qida 48 ga qaysi son yaqinroq: 40 yoki 50?",o:["50","40","Teng","45"],k:0,s:"48 dan 50 gacha 2 qadam, 40 gacha 8 qadam. 50 yaqin."},
{t:"Qaysi sonni □ o'rniga qo'ysak, 39 < □ < 41 to'g'ri bo'ladi?",o:["40","39","41","42"],k:0,s:"39 dan katta va 41 dan kichik — faqat 40."},
{t:"Sonlar: 27, 72, 70, 20. Eng kattasi bilan eng kichigi farqi?",o:["52","45","50","2"],k:0,s:"Eng kattasi 72, eng kichigi 20. 72 − 20 = 52."},
{t:"□5 > 75 bo'lishi uchun □ o'rniga qaysi raqamlar to'g'ri keladi?",o:["8 va 9","7, 8, 9","faqat 9","6 va 7"],k:0,s:"Birliklar teng (5 va 5), o'nliklar 7 dan katta: 8, 9. 75 = 75 — 7 bo'lmaydi."}
];
function PRACT_STAGE(){two(52,48,{sign:'>'});pvStrip(52,48,'>','Avval o‘nliklar, keyin birliklar')}
var PREP_DATA={teach:["Ikki sonni taqqoslash: >, <, = belgilari.","Taqqoslash tartibi: avval o'nliklar, keyin birliklar.","Son o'qida taqqoslash; sonlarni o'sish va kamayish tartibida terish.","Test turlari: yashiringan raqam (6□ < 64), o'nlik-birlik ko'rinishi (3 o'nlik 15 birlik)."],
 mist:["Katta raqamni ko'rib, sonni katta deydi (48 > 52, «chunki 8 katta»).","Belgini teskari qo'yadi (uchini katta songa).","6□ < 64 da 4 ni ham qo'shadi (teng va kichikni farqlamaydi).","«3 o'nlik 15 birlik» ni 315 yoki 35 deb o'qiydi."],
 need:["O'nlik tayoqchalari yoki cho'p bog'lamlari.","Raqam kartochkalari, «>», «<», «=» kartochkalari.","Polda lentadan 0–100 son o'qi (ixtiyoriy)."],
 board:["Ikki ustun: <span class='w2'>o'nliklar | birliklar</span>.","<span class='w2'>34 < 43</span> — uchi kichikka.","<span class='w2'>52 > 48</span> — 5 > 4, birliklarga qaralmaydi.","<span class='w2'>63 < 67</span> — o'nliklar teng, 3 < 7.","Son o'qi: <span class='w2'>47 · · · · 52</span> — o'ngdagisi katta.","<span class='w2'>6□ < 64</span> → 0, 1, 2, 3.","<span class='w2'>3 o'nlik 15 birlik = 45 > 44</span>."]};
