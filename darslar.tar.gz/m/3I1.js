var CODE='3I1',TITLE='3-sinf · Jadval, piktogramma va ustunli diagramma';
function i1msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// d: [[nom, qiymat|[q1,q2], rang]], o: max, step, base, hl, vals, x0,x1
function i1bars(d,o){o=o||{};clear();var g=S.g,base=o.base||0,mx=o.max,st=o.step,x0=o.x0||46,x1=o.x1||346,y0=142,H=118,sc=H/(mx-base),v;
 for(v=base;v<=mx;v+=st){var y=y0-(v-base)*sc;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#e6ebf0'},g);T(g,x0-6,y+4,''+v,{'font-size':10,'text-anchor':'end',fill:'#5a6b7b'})}
 E('line',{x1:x0,y1:y0,x2:x1,y2:y0,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0,y1:y0,x2:x0,y2:y0-H-6,stroke:'#33475b','stroke-width':2},g);
 if(base>0){E('path',{d:'M'+(x0-6)+' '+(y0-6)+' l6 -4 l6 4 l6 -4',fill:'none',stroke:C.bad,'stroke-width':2},g)}
 var n=d.length,w=(x1-x0)/n;d.forEach(function(b,i){var cx=x0+w*(i+.5),vals=Array.isArray(b[1])?b[1]:[b[1]],bw=Math.min(40,w*.55)/vals.length;
  vals.forEach(function(val,k){if(val==null)return;var h=Math.max(0,(val-base)*sc),x=cx-bw*vals.length/2+k*bw;E('rect',{x:x+1,y:y0-h,width:bw-2,height:h,rx:3,fill:(o.cols?o.cols[k]:b[2])||C.blue,opacity:o.hl!=null&&o.hl!==i?.35:1},g);if(o.vals)T(g,x+bw/2,y0-h-4,''+val,{'font-size':11,'font-weight':800})});
  T(g,cx,158,b[0],{'font-size':11,'font-weight':700})});
 if(o.ttl)T(g,(x0+x1)/2,14,o.ttl,{'font-size':11,fill:'#5a6b7b'})}
var I1D=[['Olma',8,'#e0584f'],['Uzum',6,'#8e6bbf'],['Anor',4,'#c0392b'],['Nok',7,'#9bbf3b']];
function i1tab(on){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center"><table style="margin:auto;border-collapse:collapse;font-size:14px">'+'<tr>'+I1D.map(function(b){return '<td style="border:1px solid #cfd8e3;padding:2px 8px;font-weight:700">'+b[0]+'</td>'}).join('')+'</tr><tr>'+I1D.map(function(b,i){return '<td style="border:1px solid #cfd8e3;padding:2px 8px;'+(on&&on.indexOf(i)>=0?'background:#dff3e3':'')+'">'+b[1]+'</td>'}).join('')+'</tr></table></div></div>'}
function i1s1(i,done){S.on1=S.on1||[];if(S.on1.indexOf(i)<0)S.on1.push(i);i1bars(I1D.map(function(b,k){return [b[0],S.on1.indexOf(k)>=0?b[1]:null,b[2]]}),{max:10,step:1,vals:1});i1tab(S.on1);if(S.on1.length===4)done()}
var I1S=[['A',10],['B',14],['C',7],['D',12]];
function i1s2(v,done){i1bars(I1S.map(function(b){return [b[0],b[1],b[0]==='C'?C.a2:C.blue]}),{max:16,step:2,hl:2});if(v===7){i1msg('✓ C = <b>7</b>: ustun 6 va 8 ning o‘rtasida');done()}else i1msg(v===8?'Ustun 8 gacha yetmagan — u 6 va 8 ning <b>o‘rtasida</b>':v===6?'Ustun 6 dan baland — 6 va 8 ning o‘rtasida':'14 — bu B ustuni. C ni qarang')}
// piktogramma
function i1pic(k){clear();var g=S.g;T(g,300,20,'● = 2 bola',{'font-size':12,'font-weight':800,fill:C.blue});
 I1D.forEach(function(b,i){var y=34+i*34;T(g,40,y+5,b[0],{'font-size':12,'font-weight':700});var n=b[1]/2;
  for(var j=0;j<Math.ceil(n);j++){var x=90+j*30;if(n-j>=1)E('circle',{cx:x,cy:y,r:11,fill:b[2]},g);else E('path',{d:'M'+x+' '+(y-11)+' A11 11 0 0 0 '+x+' '+(y+11)+' Z',fill:b[2]},g)}
  if(k>=1&&i===3){E('rect',{x:165,y:y-14,width:30,height:28,rx:6,fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g)}
  if(k>=2)T(g,240,y+5,(n%1?Math.floor(n)+' × 2 + 1':n+' × 2')+' = '+b[1],{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'start'})});
 i1msg(['Piktogramma: rasm bilan ko‘rsatilgan jadval. Kalitga qarang: ● = 2 bola','Yarim rasm (◖) — <b>yarmi</b>: 2 : 2 = 1 bola','Nok: 3 ta butun + yarim → 2 + 2 + 2 + 1 = <b>7</b>'][k])}
var P3=[function(){i1pic(0)},function(){i1pic(1)},function(){i1pic(2)}];
var P5=[function(){i1bars(I1D,{max:10,step:1,vals:1});i1msg('Olma va nok birgalikda uzum va anordan nechta ko‘p?')},
 function(){i1bars(I1D,{max:10,step:1,vals:1,hl:null});calc(['Olma + Nok = 8 + 7 = <b>15</b>'])},
 function(){calc(['Olma + Nok = 8 + 7 = 15','Uzum + Anor = 6 + 4 = <b>10</b>'])},
 function(){calc(['Olma + Nok = 15','Uzum + Anor = 10','15 − 10 = <b>5</b>'])}];
var I1T=[['Futbol',12,'#2f6fb5'],['Rasm',8,'#e08a3c'],['Shaxmat',null,'#5cb85c']];
var P6=[function(){i1bars(I1T,{max:14,step:2,vals:1});i1msg('Uch to‘garakda jami <b>30</b> bola. Shaxmat ustuni chizilmay qolgan')},
 function(){calc(['Futbol + Rasm = 12 + 8 = <b>20</b>'])},
 function(){i1bars([I1T[0],I1T[1],['Shaxmat',10,'#5cb85c']],{max:14,step:2,vals:1});calc(['Futbol + Rasm = 20','Shaxmat = 30 − 20 = <b>10</b>'])}];
var P7=[function(){i1bars([['3-A',60,C.blue],['3-B',70,C.a2]],{max:72,base:56,step:2,x0:60,x1:200});T(S.g,280,60,'B «3 marta',{'font-size':12,'font-weight':800,fill:C.bad});T(S.g,280,76,'ko‘p»',{'font-size':12,'font-weight':800,fill:C.bad});T(S.g,280,92,'ko‘rinadi…',{'font-size':12,'font-weight':800,fill:C.bad});i1msg('3-A — 60 ta, 3-B — 70 ta kitob. Ustunlar juda farq qiladi!')},
 function(){i1bars([['3-A',60,C.blue],['3-B',70,C.a2]],{max:72,base:56,step:2,x0:60,x1:200});E('circle',{cx:54,cy:136,r:14,fill:'none',stroke:C.bad,'stroke-width':3},S.g);i1msg('Lekin o‘q <b>0 dan emas, 56 dan</b> boshlangan (qizil «uzilish» belgisi)!')},
 function(){i1bars([['3-A',60,C.blue],['3-B',70,C.a2]],{max:70,step:10,x0:60,x1:200,vals:1});T(S.g,280,76,'Farq atigi 10',{'font-size':13,'font-weight':800,fill:C.ok});i1msg('O‘q 0 dan: ustunlar deyarli teng. Farq <b>10 ta</b>, «3 marta» emas')}];
function i1leg(){var g=S.g;E('rect',{x:262,y:10,width:10,height:10,fill:C.blue},g);T(g,276,19,'stul',{'font-size':10,'text-anchor':'start'});E('rect',{x:304,y:10,width:10,height:10,fill:C.a2},g);T(g,318,19,'stol',{'font-size':10,'text-anchor':'start'})}
var I1U=[['Anvar',[5,3]],['Dilshod',[4,6]],['Bobur',[7,2]]];
function i1s8(i,done){i1bars(I1U,{max:8,step:1,vals:1,hl:i,cols:[C.blue,C.a2]});var u=I1U[i];i1leg();calc([u[0]+': '+u[1][0]+' stul + '+u[1][1]+' stol = <b>'+(u[1][0]+u[1][1])+'</b>'],'ko‘k — stul, to‘q sariq — stol');mvK(done,3)}
var STEPS=[
{h:"Jadvaldan ustunli diagramma",sum:"Ustunli diagrammada har bir sonni balandligi shu songa teng ustun ko'rsatadi.",a:"m01",
 start:function(){S.on1=[];i1bars(I1D.map(function(b){return [b[0],null]}),{max:10,step:1});i1tab([])},fin:function(){i1bars(I1D,{max:10,step:1,vals:1});i1tab([0,1,2,3])},
 html:"<p>Sinfda «Qaysi mevani yaxshi ko'rasiz?» deb so'radik. Javoblar jadvalda (pastda). Har bir mevani bosib, uning <b>ustunini</b> chizing:</p>",
 btns:[["Olma",function(c,done){i1s1(0,done)}],["Uzum",function(c,done){i1s1(1,done)}],["Anor",function(c,done){i1s1(2,done)}],["Nok",function(c,done){i1s1(3,done)}]],g2:1,
 after:"<p>Jadval va diagramma bir xil ma'lumotni ko'rsatadi. Diagrammada <b>eng baland ustun</b> — eng ko'p (olma), eng past — eng kam (anor) bir qarashda ko'rinadi. Chap tomondagi sonlar — <b>shkala</b>.</p>",
 q:{t:"Nechta bola so'raldi (har biri bitta meva tanlagan)?",opts:["4","25","8","20"],ok:1,why:"8 + 6 + 4 + 7 = 25.",hint:"Hamma ustunlar qiymatlarini nima qilish kerak?",full:"Har bola bitta meva tanlagan, demak hammasini qo'shamiz: 8 + 6 + 4 + 7 = 25. 4 — mevalar soni, 8 — eng ko'p tanlangan meva."},
 tn:"Sinfda qo'l ko'tarish orqali so'rovnoma o'tkazing va doskada katakli ustunlarni birga bo'yang (Singapur CPA: aniq → rasm → belgi)."},
{h:"Shkalani o'qiymiz",sum:"Shkala 2 tadan bo'lsa, ikki chiziq o'rtasidagi ustun toq sonni bildiradi.",a:"m02",
 start:function(){i1bars(I1S.map(function(b){return [b[0],b[1],b[0]==='C'?C.a2:C.blue]}),{max:16,step:2,hl:2});i1msg('C ustuni nechani ko‘rsatadi?')},fin:function(){i1s2(7,function(){})},
 html:"<p>Bu diagrammada shkala <b>2 tadan</b> oshib boradi. To'q sariq <b>C</b> ustuni nechani ko'rsatadi?</p>",
 btns:[["6",function(c,done){i1s2(6,done)}],["8",function(c,done){i1s2(8,done)}],["7",function(c,done){i1s2(7,done)}],["14",function(c,done){i1s2(14,done)}]],g2:1,
 after:"<p>Avval shkala qadamini aniqlaymiz: 0, 2, 4, 6… — <b>2 tadan</b>. C ustuni 6 va 8 chiziqlarining o'rtasida tugaydi, demak <b>7</b>.</p>",
 q:{t:"Shkala 10 tadan (0, 10, 20, 30…). Ustun 20 va 30 ning o'rtasida tugaydi. Qiymati?",opts:["25","20","30","21"],ok:0,why:"20 va 30 ning o'rtasi — 25.",hint:"Shkalaning ikki chizig'i orasida nechta birlik bor?",full:"20 va 30 orasida 10 birlik, uning yarmi 5: 20 + 5 = 25. 21 — shkala qadamini 1 deb o'ylash xatosi."},
 tn:"Bolalar avval doim «shkala qanchadan?» deb so'rasin — bu odat ko'p xatoning oldini oladi."},
{h:"Piktogramma",sum:"Piktogrammada bir rasm bir nechta narsani bildiradi (kalit). Yarim rasm — yarmi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Shu ma'lumotni rasmlar bilan ko'rsatamiz. Diqqat — <b>kalitga</b> qarang!</p>",
 btns:[phaser(P3)],
 after:"<p>Piktogrammada avval <b>kalit</b>ni o'qiymiz: ● = 2 bola. Rasmlar sonini 2 ga ko'paytiramiz. Yarim rasm — 2 ning yarmi, ya'ni 1.</p>",
 q:{t:"Kalit: ★ = 4 bola. Qatorda 3 ta butun ★ va yarim ★ bor. Nechta bola?",opts:["14","4","12","16"],ok:0,why:"3 × 4 = 12, yarim ★ = 2; 12 + 2 = 14.",hint:"Yarim yulduz necha bolani bildiradi?",full:"Butun yulduzlar: 3 × 4 = 12. Yarim yulduz — 4 ning yarmi, 2. Jami 14. 4 — rasmlarni sanash (kalitni unutish), 16 — yarimni butun deb hisoblash."},
 tn:"Bolalar qog'ozdan yasalgan belgilar bilan doskada piktogramma tuzsin; kalitni albatta yozsin."},
{h:"Diagrammadan savollarga javob",sum:"Eng ko'p/kam — ustunlar balandligidan; «nechta ko'p» — ayirish bilan.",a:"m04",
 start:function(){i1bars(I1D,{max:10,step:1,vals:1})},fin:function(){i1bars(I1D,{max:10,step:1,vals:1,hl:0});calc(['Olma − Anor = 8 − 4 = <b>4</b>'])},
 html:"<p>Diagrammadan uch savolga javob toping — tugmalarni bosing:</p>",
 btns:[["Eng ko'p",function(c,done){i1bars(I1D,{max:10,step:1,vals:1,hl:0});i1msg('Eng baland ustun — <b>Olma (8)</b>');mvK(done,3)}],["Eng kam",function(c,done){i1bars(I1D,{max:10,step:1,vals:1,hl:2});i1msg('Eng past ustun — <b>Anor (4)</b>');mvK(done,3)}],["Olma − Anor",function(c,done){i1bars(I1D,{max:10,step:1,vals:1,hl:0});calc(['Olma Anordan 8 − 4 = <b>4</b> ta ko‘p','yoki: 8 : 4 = <b>2 marta</b> ko‘p']);mvK(done,3)}]],g3:1,
 after:"<p>«<b>Nechta ko'p</b>» — ayiramiz: 8 − 4 = 4. «<b>Necha marta ko'p</b>» — bo'lamiz: 8 : 4 = 2. Bu ikki savolni adashtirmang!</p>",
 q:{t:"Uzum 6 ta, Anor 4 ta. Uzum anordan nechta ko'p?",opts:["2","10","1","24"],ok:0,why:"6 − 4 = 2.",hint:"«Nechta ko'p» uchun qaysi amal?",full:"«Nechta ko'p» — ayirish: 6 − 4 = 2. 10 — qo'shib yuborish, 24 — ko'paytirish."},
 tn:"Doskaga ikki savolni yozing: «nechta ko'p?» (−) va «necha marta ko'p?» (:). Har birini diagrammadan topishsin."},
{h:"Ko'p bosqichli savol",sum:"Avval guruhlar yig'indisi, keyin ularning farqi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){i1bars(I1D,{max:10,step:1,vals:1});S.ph=3;P5[3]()},
 html:"<p>Murakkab savol: <b>olma va nok birgalikda</b> uzum va anor birgalikdagidan nechta ko'p?</p>",
 btns:[phaser(P5)],
 after:"<p>Bunday savolni <b>bosqichma-bosqich</b> yechamiz: 1) birinchi guruh: 8 + 7 = 15; 2) ikkinchi guruh: 6 + 4 = 10; 3) farq: 15 − 10 = <b>5</b>.</p>",
 q:{t:"Diagrammada: Palov 50, Manti 40, Sho'rva 20, Lag'mon 30. Palov va manti birgalikda sho'rva va lag'mondan nechta ko'p?",opts:["40","90","50","10"],ok:0,why:"(50 + 40) − (20 + 30) = 90 − 50 = 40.",hint:"Avval har bir juftning yig'indisini toping.",full:"Palov + Manti = 90, Sho'rva + Lag'mon = 50, farq 90 − 50 = 40. 90 va 50 — oraliq natijalar, 10 — faqat palov va mantining farqi."},
 tn:"Bolalar oraliq natijalarni daftarga alohida qatorda yozsin — shunda bosqich tushib qolmaydi."},
{h:"Chizilmay qolgan ustun",sum:"Jami ma'lum bo'lsa, yetishmagan qiymat = jami − ma'lum qiymatlar yig'indisi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Uch to'garakda jami <b>30</b> bola qatnashadi. Shaxmat to'garagining ustuni chizilmay qolgan. Uni tiklaymiz!</p>",
 btns:[phaser(P6)],
 after:"<p>Ma'lum ustunlarni qo'shamiz: 12 + 8 = 20. Jamidan ayiramiz: 30 − 20 = <b>10</b>. Shaxmat ustuni 10 gacha chiziladi.</p>",
 q:{t:"To'rt sinfdan jami 150 o'quvchi. Uch sinfda 40, 30 va 40 o'quvchi. To'rtinchi sinfda nechta?",opts:["40","110","30","50"],ok:0,why:"150 − (40 + 30 + 40) = 150 − 110 = 40.",hint:"Avval ma'lum uch sinfni qo'shing.",full:"40 + 30 + 40 = 110, 150 − 110 = 40. 110 — oraliq natija (ma'lum sinflar yig'indisi), javob emas."},
 tn:"Ustunni katakli daftarda chizdirib, «Diagramma to'liqmi?» deb tekshirtiring."},
{h:"Tuzoq: shkala 0 dan boshlanmasa",sum:"Ustunlarni solishtirishdan oldin o'q qayerdan boshlanganini tekshiring.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ikki sinf yig'gan kitoblar diagrammasi. 3-B ning ustuni 3-A nikidan bir necha marta baland! Rostdanmi?</p>",
 btns:[phaser(P7)],
 after:"<p>O'q <b>0 dan emas</b>, 56 dan boshlansa, kichik farq juda katta ko'rinadi. Har doim <b>sonlarni</b> o'qing: 70 − 60 = 10. Reklamalarda ba'zan shu usul bilan aldashadi.</p>",
 q:{t:"Diagramma o'qi 90 dan boshlangan. Ustunlar 92 va 98 ni ko'rsatadi. Farq qancha?",opts:["6","4 marta","90","190"],ok:0,why:"98 − 92 = 6.",hint:"Ustunlar balandligiga emas, sonlarga qarang.",full:"Farq sonlardan topiladi: 98 − 92 = 6. Ustunlar 2 va 8 birlik balandlikda ko'rinadi (4 marta), lekin bu o'q 90 dan boshlangani uchun."},
 tn:"Gazeta yoki reklamadan shunday diagramma topib, bolalarga «aldovni toping» deb bering."},
{h:"Ikki xil ustunli diagramma",sum:"Bitta nom yonida ikki rangli ustun — ikki xil narsa. Jami uchun ikkalasini qo'shamiz.",a:"m08",
 start:function(){i1bars(I1U,{max:8,step:1,vals:1,cols:[C.blue,C.a2]});i1leg();i1msg('Ko‘k — stul, to‘q sariq — stol')},fin:function(){i1bars(I1U,{max:8,step:1,vals:1,hl:1,cols:[C.blue,C.a2]});calc(['Anvar 8, <b>Dilshod 10</b>, Bobur 9'])},
 html:"<p>Uch usta bir kunda yasagan stul (ko'k) va stollar (to'q sariq). Har bir ustani bosing:</p>",
 btns:[["Anvar",function(c,done){i1s8(0,done)}],["Dilshod",function(c,done){i1s8(1,done)}],["Bobur",function(c,done){i1s8(2,done)}]],g3:1,
 after:"<p>Eng baland <b>bitta</b> ustun Boburda (7 stul), lekin <b>jami</b> eng ko'p mahsulot Dilshodda: 4 + 6 = 10. Savolni diqqat bilan o'qing: «stul» so'raladimi yoki «jami»?</p>",
 q:{t:"Qaysi usta jami eng ko'p mahsulot yasaydi?",opts:["Bobur","Dilshod","Anvar","Uchalasi teng"],ok:1,why:"Anvar 8, Dilshod 10, Bobur 9.",hint:"Har bir ustaning ikki ustunini qo'shing.",full:"Jami: Anvar 5 + 3 = 8, Dilshod 4 + 6 = 10, Bobur 7 + 2 = 9. Bobur faqat stulda birinchi."},
 tn:"Ikki rangli ustunlarni ikki xil rangli kubik minoralar bilan ko'rsating."},
{h:"Bilasizmi? Diagrammalar tarixi",sum:"Ustunli diagrammani 1786-yilda Uilyam Pleyfer ixtiro qilgan; Florens Naytingeyl diagramma bilan hayotlarni saqlagan.",a:"m09",
 start:function(){i1bars(I1D,{max:10,step:1,vals:1})},fin:function(){i1bars(I1D,{max:10,step:1,vals:1})},
 html:"<p>📊 Ustunli diagrammani shotlandiyalik <b>Uilyam Pleyfer</b> 1786-yilda chop etilgan kitobida birinchilardan bo'lib ishlatgan.</p><p>🏥 Hamshira <b>Florens Naytingeyl</b> 1858-yilda askarlarning ko'pi jarohatdan emas, kasalxonadagi iflos sharoitdan vafot etayotganini diagramma bilan ko'rsatgan. Shundan keyin kasalxonalarda tozalikka e'tibor kuchaygan.</p><p>📱 Bugun telefoningizdagi ob-havo, qadam sanagich ilovalari ham diagramma bilan ishlaydi.</p>",
 tn:"Bolalar bir hafta davomida ob-havoni kuzatib, juma kuni diagramma tuzsin (3I3 mavzusiga ko'prik)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){i1bars(I1D,{max:10,step:1,vals:1})},fin:function(){i1bars(I1D,{max:10,step:1,vals:1})},
 html:"<div class='memo'><ul><li><b>Jadval</b> — sonlar, <b>diagramma</b> — ustunlar, <b>piktogramma</b> — rasmlar.</li><li>Avval <b>shkala qadamini</b> va <b>kalitni</b> aniqlang.</li><li>Ikki chiziq o'rtasi — qadamning yarmi qo'shiladi.</li><li>«Nechta ko'p» — ayirish, «necha marta ko'p» — bo'lish.</li><li>Murakkab savol: avval guruh yig'indilari, keyin farq.</li><li>Yetishmagan ustun = jami − ma'lumlar yig'indisi.</li><li>O'q 0 dan boshlanmasa — ustunlar aldaydi, sonlarni o'qing.</li></ul></div>",
 tn:"Keyingi darsni «Diagramma nima deydi?» — 1 daqiqalik og'zaki savol-javob bilan boshlang."}
];
var PROBS=[
{t:"Ustunli diagrammada eng baland ustun nimani bildiradi?",o:["Eng katta qiymatni","Eng kichik qiymatni","Birinchi qiymatni","O'rtacha qiymatni"],k:0,s:"Balandlik qiymatga teng."},
{t:"Shkala 0, 4, 8, 12… Ustun 8 va 12 ning o'rtasida. Qiymati?",o:["10","8","12","9"],k:0,s:"8 va 12 o'rtasi: 8 + 2 = 10."},
{t:"Kalit: ● = 4 kitob. Qatorda 5 ta ●. Nechta kitob?",o:["20","9","5","4"],k:0,s:"5 × 4 = 20."},
{t:"Kalit: ■ = 10 o'quvchi. Qatorda 3 ta butun va yarim ■. Nechta o'quvchi?",o:["35","31","40","3"],k:0,s:"3 × 10 + 5 = 35."},
{t:"Kalit: ♥ = 2 ta. 14 tani ko'rsatish uchun nechta ♥ kerak?",o:["7","14","28","12"],k:0,s:"14 : 2 = 7."},
{t:"Kalit: ★ = 6 ta. 15 tani ko'rsatish uchun qanday chiziladi?",o:["2 ta butun va yarim ★","3 ta ★","15 ta ★","2 ta ★"],k:0,s:"6 + 6 = 12, qoldi 3 = yarim ★."},
{t:"Olma 9, Nok 5. Olma nokdan nechta ko'p?",o:["4","14","45","5"],k:0,s:"9 − 5 = 4."},
{t:"Qizil 12, Ko'k 4. Qizil ko'kdan necha marta ko'p?",o:["3","8","16","48"],k:0,s:"12 : 4 = 3."},
{t:"Diagrammada: A 15, B 25, C 10. Jami?",o:["50","40","25","35"],k:0,s:"15 + 25 + 10 = 50."},
{t:"Oylar bo'yicha kitobxonlar: 30, 45, 38, 25, 40, 36. Nechta oyda 35 dan ko'p?",o:["4","3","2","5"],k:0,s:"45, 38, 40, 36 — 4 ta oy."},
{t:"Baholar: «5» — 8, «4» — 12, «3» — 6, «2» — 2. «4» va «5» olganlar «3» va «2» olganlardan nechta ko'p?",o:["12","20","8","28"],k:0,s:"(8 + 12) − (6 + 2) = 20 − 8 = 12."},
{t:"Palov 60, Manti 50, Sho'rva 30, Lag'mon 40. Palov va sho'rva birgalikda manti va lag'mondan nechta ko'p yoki kam?",o:["Teng","10 ta ko'p","10 ta kam","20 ta ko'p"],k:0,s:"60 + 30 = 90, 50 + 40 = 90 — teng."},
{t:"Jami 100 o'quvchi. Uch to'garakda 35, 25, 20. To'rtinchi to'garakda nechta?",o:["20","80","25","35"],k:0,s:"100 − (35 + 25 + 20) = 20."},
{t:"Bir qovun 5 kg, bir tarvuz 8 kg, bir qovoq 6 kg. 4 ta tarvuz va 2 ta qovoq necha kg?",o:["44","32","46","26"],k:0,s:"4 × 8 + 2 × 6 = 32 + 12 = 44."},
{t:"Nodira har kuni sahifa o'qiydi: Du 20, Se 15, Ch 25, Pa 10, Ju 30. Har kuni jumadagidek o'qisa, 5 kunda hozirgidan nechta ko'p o'qirdi?",o:["50","150","100","30"],k:0,s:"5 × 30 = 150, hozir 100, farq 50."},
{t:"O'q 80 dan boshlangan. Ustunlar 84 va 92 ni ko'rsatadi. Haqiqiy farq?",o:["8","3 marta","12","4"],k:0,s:"92 − 84 = 8; «3 marta» — ustunlar ko'rinishi aldaydi."},
{t:"Ustalar: Anvar 6 stul 4 stol, Dilshod 8 stul 1 stol, Bobur 5 stul 6 stol. Kim jami eng ko'p yasaydi?",o:["Bobur","Dilshod","Anvar","Uchalasi teng"],k:0,s:"Anvar 10, Dilshod 9, Bobur 11."},
{t:"Avtoturargoh: 1-qavat 250, 2-qavat 400, 3-qavat 200 mashina. Eng ko'p va eng kam qavat farqi?",o:["200","150","600","50"],k:0,s:"400 − 200 = 200."},
{t:"Kalit: ● = 2 bola. Olma 4 ●, Uzum 2 va yarim ●. Olmani uzumdan nechta bola ko'p tanlagan?",o:["3","5","2","8"],k:0,s:"Olma 8, uzum 5: 8 − 5 = 3."},
{t:"Jadval: dushanba 12, seshanba 18, chorshanba 15 ta ko'ylak. Har biriga 2 m mato ketdi. Jami necha metr?",o:["90","45","47","30"],k:0,s:"(12 + 18 + 15) × 2 = 45 × 2 = 90."}
];
function PRACT_STAGE(){i1bars(I1D,{max:10,step:1,vals:1})}
var PREP_DATA={teach:["Jadval, piktogramma va ustunli diagramma — bir ma'lumotning uch ko'rinishi.","Shkala va kalitni o'qish, yarim rasm.","Diagramma bo'yicha savollar: eng ko'p/kam, nechta/necha marta ko'p, ko'p bosqichli.","Yetishmagan ustunni tiklash; 0 dan boshlanmagan o'q tuzog'i."],
 mist:["Shkala qadamini 1 deb o'ylaydi.","Piktogrammada kalitni hisobga olmaydi (rasmlarni sanaydi).","«Nechta ko'p» va «necha marta ko'p» ni aralashtiradi.","Ko'p bosqichli savolda oraliq natijani javob deb beradi."],
 need:["Katakli qog'oz, rangli qalam.","Qog'oz belgilar (piktogramma uchun).","Kubiklar (ustunlarni ko'rsatish uchun)."],
 board:["Jadval → <span class='w2'>ustunlar</span>.","Shkala 2 tadan: 6 va 8 o'rtasi — 7.","Kalit ● = 2; yarim ● = 1.","Nechta ko'p: 8 − 4; necha marta: 8 : 4.","(8 + 7) − (6 + 4) = 5.","30 − (12 + 8) = 10.","O'q 56 dan — aldov!"]};
