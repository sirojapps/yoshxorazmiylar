var CODE='3D3',TITLE='3-sinf · Harfli ifodalar';
function d3Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
function d3Tab(rows,hi){clear();var g=S.g,n=rows[0].length,cw=Math.min(62,280/n),x0=180-((n-1)*cw+60)/2;
 rows.forEach(function(r,i){var y=40+i*44;E('rect',{x:x0,y:y-24,width:60,height:38,fill:i?'#e3f5f3':'#fdf0dc',stroke:'#c9d3dd'},g);T(g,x0+30,y,r[0],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  for(var j=1;j<n;j++){var on=hi&&hi.indexOf(j)>=0;E('rect',{x:x0+60+(j-1)*cw,y:y-24,width:cw,height:38,fill:on&&i?'#e6f6ee':'#fff',stroke:'#c9d3dd'},g);T(g,x0+60+(j-1)*cw+cw/2,y,String(r[j]),{'font-size':16,'font-weight':800,fill:on&&i?C.ok:'#1d2b3a'})}})}
function d3Rect(a,b,lab){clear();var g=S.g;E('rect',{x:90,y:28,width:180,height:100,rx:4,fill:'#fdf0dc',stroke:C.t1,'stroke-width':2.5},g);
 T(g,180,22,a,{'font-size':15,'font-weight':800,fill:C.blue});T(g,180,146,a,{'font-size':15,'font-weight':800,fill:C.blue});T(g,58,83,b,{'font-size':15,'font-weight':800,fill:C.u});T(g,302,83,b,{'font-size':15,'font-weight':800,fill:C.u});if(lab)T(g,180,84,lab,{'font-size':16,'font-weight':800,fill:'#1d2b3a'})}
var P2=[function(){w3Expr(['a · b − a : b','a = 240,  b = 3']);w3Msg('Harflar o‘rniga sonlarni qo‘yamiz')},
 function(){w3Expr(['{240} · {3} − {240} : {3}']);w3Msg('Har bir a → 240, har bir b → 3')},
 function(){w3Expr(['[240 · 3] − [240 : 3]','720 − 80']);w3Msg('Amallar tartibi: avval · va :')},
 function(){w3Expr(['720 − 80','= {640}']);w3Msg('Ifodaning qiymati: <b>640</b>')}];
var P4=[function(){d3Rect('a','b');w3Msg('To‘g‘ri to‘rtburchak: bo‘yi a, eni b')},
 function(){d3Rect('a','b','P = a + b + a + b');w3Msg('Perimetr — hamma tomonlar yig‘indisi')},
 function(){d3Rect('a','b','P = (a + b) · 2');w3Msg('Qisqaroq: (a + b) ikki marta')},
 function(){d3Rect('6 sm','4 sm','P = (6 + 4) · 2 = 20');w3Msg('a = 6 sm, b = 4 sm bo‘lsa: <b>P = 20 sm</b>')}];
function d3Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Harf — o'zgaruvchan son",sum:"a + 5 da a istalgan son bo'lishi mumkin: a = 1 → 6, a = 10 → 15, a = 25 → 30.",a:"m01",
 start:function(){S.w1=[];d3Tab([['a','?','?','?'],['a + 5','','','']]);w3Msg('a ga qiymat bering — ifoda qiymatini kuzating')},fin:function(){d3Tab([['a',1,10,25],['a + 5',6,15,30]],[1,2,3]);w3Msg('a o‘zgarsa — ifoda qiymati ham o‘zgaradi')},
 html:"<p>Qutida 5 ta konfet bor, yana <b>a</b> ta solindi. Jami: <b>a + 5</b>. Bu — <b>harfli ifoda</b>: a o'rniga istalgan son qo'yish mumkin. Uchta qiymatni sinab ko'ring:</p>",
 btns:[["a = 1",function(c,done){d3Up(1,c,done)}],["a = 10",function(c,done){d3Up(10,c,done)}],["a = 25",function(c,done){d3Up(25,c,done)}]],g3:1,
 after:"<p>Harf — «son uchun bo'sh joy». Bitta ifoda <b>cheksiz ko'p</b> misolni bir yozuvda ifodalaydi. a ni <b>o'zgaruvchi</b> deyiladi.</p>",
 q:{t:"a + 15 ifodaning a = 25 dagi qiymati?",opts:["40","10","2515","375"],ok:0,why:"25 + 15 = 40.",hint:"a o'rniga 25 ni qo'ying.",full:"25 + 15 = 40. «2515» — sonlarni yonma-yon yozish, «375» — ko'paytirish."},
 tn:"Bo'sh qutichaga raqamli kartochkalarni navbat bilan soling: «a — quti, ichida har xil son bo'lishi mumkin»."},
{h:"Ifoda qiymatini topamiz",sum:"a = 240, b = 3: a · b − a : b = 720 − 80 = 640.",a:"m02",
 start:function(){startPh(P2)},fin:d3Fin(P2),
 html:"<p>Bankdagi misol: <b>a · b − a : b</b>, bunda a = 240, b = 3. Ikki qadam: 1) harflar o'rniga sonlar, 2) amallar tartibi.</p>",btns:[phaser(P2)],
 after:"<p>Qiymat — <b>640</b>. Diqqat: <b>har bir</b> a o'rniga bir xil son qo'yiladi (240 ikki marta). Keyin oddiy amallar tartibi — avval · va :.</p>",
 q:{t:"m : 4 + m, bunda m = 36. Qiymati?",opts:["45","9","10","40"],ok:0,why:"36 : 4 + 36 = 9 + 36 = 45.",hint:"m ikki joyda — ikkalasiga ham 36.",full:"36 : 4 = 9, 9 + 36 = 45. «9» — ikkinchi m unutilgan; «10» — (36 + 4) : 4 kabi noto'g'ri tartib."},
 tn:"Doskada harflarni rangli bo'r bilan yozing; sonni qo'yganda ham shu rangda yozing."},
{h:"Matndan ifoda tuzamiz",sum:"«Nodirada n ta qalam, opasida 5 ta ko'p» → opasida n + 5 ta.",a:"m03",
 start:function(){w3Bar([{lab:'Nodira',segs:[{w:6,t:'n',c:'#cfe6f7'}],tot:8},{lab:'Opasi',segs:[{w:6,t:'n',c:'#cfe6f7'},{w:2,t:'5',c:'#f2b766'}],tot:8}],{top:24,gap:70});w3Msg('Opasida nechta qalam?')},fin:function(){w3Bar([{lab:'Nodira',segs:[{w:6,t:'n',c:'#cfe6f7'}],tot:8},{lab:'Opasi',segs:[{w:6,t:'n',c:'#cfe6f7'},{w:2,t:'5',c:'#f2b766'}],tot:8,br:'n + 5'}],{top:24,gap:70});w3Msg('Opasida: <b>n + 5</b>')},
 html:"<p>«Nodirada <b>n</b> ta qalam bor. Opasida undan <b>5 ta ko'p</b>.» Opasidagi qalamlar soni qaysi ifoda?</p><div class='digs w3c'></div>",
 act:function(c,done){d3Sel(c,'.w3c',['n − 5','n + 5','5 · n'],'n + 5',function(){w3Bar([{lab:'Nodira',segs:[{w:6,t:'n',c:'#cfe6f7'}],tot:8},{lab:'Opasi',segs:[{w:6,t:'n',c:'#cfe6f7'},{w:2,t:'5',c:'#f2b766'}],tot:8,br:'n + 5'}],{top:24,gap:70});w3Msg('«5 ta ko‘p» → <b>n + 5</b>');done()},{'n − 5':'«ko‘p» — demak qo‘shamiz','5 · n':'«5 marta ko‘p» emas, «5 ta ko‘p»'})},
 after:"<div class='life'><div>➕<span>«5 ta ko'p» → n + 5</span></div><div>➖<span>«5 ta kam» → n − 5</span></div><div>✖️<span>«5 marta ko'p» → n · 5</span></div><div>➗<span>«5 marta kam» → n : 5</span></div></div>",
 q:{t:"«y ning 3 baravari» qaysi ifoda?",opts:["3 · y","y + 3","y : 3","y − 3"],ok:0,why:"Baravar — ko'paytirish.",hint:"«3 marta ko'p» bilan bir xil.",full:"3 baravar = 3 marta ko'p → 3 · y. «y + 3» — «3 ta ko'p» bilan adashtirish."},
 tn:"Singapur chizma modeli (lenta) — «ta ko'p» va «marta ko'p» farqini ko'rsatadi."},
{h:"Formula: to'g'ri to'rtburchak perimetri",sum:"P = (a + b) · 2. a = 6 sm, b = 4 sm → P = 20 sm.",a:"m04",
 start:function(){startPh(P4)},fin:d3Fin(P4),
 html:"<p><b>Formula</b> — harfli ifodaning eng foydali turi: bir marta yozib, istalgan to'rtburchak uchun ishlatamiz.</p>",btns:[phaser(P4)],
 after:"<p>Formula <b>P = (a + b) · 2</b> — millionlab to'rtburchak uchun bitta yozuv. Kvadrat uchun: P = a · 4.</p>",
 q:{t:"P = (a + b) · 2, a = 12 sm, b = 8 sm. P = ?",opts:["40 sm","28 sm","20 sm","96 sm"],ok:0,why:"(12 + 8) · 2 = 40.",hint:"Avval qavs.",full:"12 + 8 = 20, 20 · 2 = 40 sm. «28» — 12 + 8 · 2 (qavssiz), «20» — 2 ga ko'paytirish unutilgan, «96» — 12 · 8 (yuza)."},
 tn:"Ip bilan to'rtburchak atrofini o'lchab, formulani tekshiring."},
{h:"Jadvaldan qonuniyat topamiz",sum:"a: 1, 2, 3, 4 → 3, 7, 11, 15. Ifoda: 4 · a − 1.",a:"m05",
 start:function(){d3Tab([['a',1,2,3,4],['?',3,7,11,15]]);w3Msg('Har gal 4 ga oshyapti. Qaysi ifoda?')},fin:function(){d3Tab([['a',1,2,3,4],['4·a−1',3,7,11,15]],[1,2,3,4]);w3Msg('4 · 1 − 1 = 3, 4 · 4 − 1 = 15 ✓')},
 html:"<p>Jadvalda a ning qiymatlari va ifodaning qiymatlari. Qaysi ifoda <b>hamma</b> ustunlarga mos?</p><div class='digs w3c'></div>",
 act:function(c,done){d3Sel(c,'.w3c',['a + 2','4 · a − 1','3 · a'],'4 · a − 1',function(){d3Tab([['a',1,2,3,4],['4·a−1',3,7,11,15]],[1,2,3,4]);w3Msg('Hamma ustun mos: 3, 7, 11, 15 ✓');done()},{'a + 2':'a = 1 da 3 ✓, lekin a = 2 da 4 — 7 emas','3 · a':'a = 1 da 3 ✓, lekin a = 2 da 6 — 7 emas'})},
 after:"<p>Tuzoq: bitta ustunga mos ifoda ko'p! <b>Hamma</b> ustunni tekshirish shart. Qadam 4 ga oshsa — ifodada «4 · a» bor.</p>",
 q:{t:"a = 1 da 3, a = 4 da 15. Qaysi ifoda mos?",opts:["4 · a − 1","a + 11","3 · a + 3","5 · a − 5"],ok:0,why:"4 − 1 = 3, 16 − 1 = 15.",hint:"Har bir ifodaga ikkala qiymatni qo'ying.",full:"4·a − 1: 3 ✓ va 15 ✓. a + 11: 12 ✗. 3·a + 3: 6 ✗. 5·a − 5: 0 ✗."},
 tn:"Kubiklardan «zinapoya» quring: har pog'onada 4 ta ko'p. Bolalar qonuniyatni o'zi aytsin (Gollandiya RME)."},
{h:"Tuzoq: 3a qanday o'qiladi?",sum:"3a = 3 · a. a = 5 bo'lsa, 3a = 15, 35 emas!",a:"m06",
 start:function(){w3Expr(['3a = ?','a = 5']);w3Msg('Harf oldidagi son — ko‘paytuvchi')},fin:function(){w3Expr(['3a = 3 · a','= 3 · 5 = {15}']);w3Msg('Ko‘paytirish belgisi yozilmaydi, lekin bor!')},
 html:"<p>Matematiklar <b>3 · a</b> ni qisqacha <b>3a</b> deb yozadilar. a = 5 bo'lsa, 3a nechaga teng?</p><div class='digs w3c'></div>",
 act:function(c,done){d3Sel(c,'.w3c',['35','15','8'],'15',function(){w3Expr(['3a = 3 · a','= 3 · 5 = {15}']);w3Msg('To‘g‘ri: <b>15</b>');done()},{'35':'3 va 5 ni yonma-yon yozib bo‘lmaydi — 3a bu 3 · a','8':'3a — qo‘shish emas, ko‘paytirish'})},
 after:"<p>Qoida: son va harf orasida (yoki ikki harf orasida) belgi yo'q bo'lsa — bu <b>ko'paytirish</b>: 3a = 3 · a, ab = a · b. Lekin ikki son orasida belgi doim yoziladi: 3 · 5, chunki 35 — boshqa son.</p>",
 q:{t:"a = 6 bo'lsa, 3a + a = ?",opts:["24","42","72","15"],ok:0,why:"3 · 6 + 6 = 18 + 6 = 24.",hint:"3a = 3 · 6.",full:"3a = 18, + 6 = 24. «42» — 36 + 6 (yonma-yon yozish xatosi)."},
 tn:"Bu yozuv keyingi sinflarda juda ko'p ishlatiladi — hoziroq to'g'ri o'qishni o'rgating."},
{h:"Murakkab: qiymatni hisoblamasdan topish",sum:"a + b = 960 bo'lsa, (a + 40) + (b − 40) = 960: biri 40 ga oshdi, ikkinchisi 40 ga kamaydi.",a:"m07",
 start:function(){w3Expr(['a + b = 960','(a + 40) + (b − 40) = ?']);w3Msg('a va b ni bilmaymiz — lekin javobni topa olamiz!')},fin:function(){w3Expr(['(a + 40) + (b − 40)','= a + b + 40 − 40','= a + b = {960}']);w3Msg('+40 va −40 bir-birini yo‘qotadi')},
 html:"<p><b>a + b = 960</b>. a va b alohida noma'lum. <b>(a + 40) + (b − 40)</b> nechaga teng?</p><div class='digs w3c'></div>",
 act:function(c,done){d3Sel(c,'.w3c',['1040','960','880'],'960',function(){w3Expr(['(a + 40) + (b − 40)','= a + b + 40 − 40','= a + b = {960}']);w3Msg('Biri 40 ga oshdi, ikkinchisi 40 ga kamaydi — yig‘indi o‘zgarmadi');done()},{'1040':'b − 40 ni ham hisobga oling','880':'a + 40 ham bor — 40 qaytib qo‘shildi'})},
 after:"<p>Bu — olimpiada usuli: harflar bilan «qismlarni» ko'chirib, qiymatni hisoblamasdan topish. Yana bir misol: a − b = 100 bo'lsa, (a + 7) − (b + 7) = 100 (ikkalasini bir xil oshirsak, ayirma o'zgarmaydi).</p>",
 q:{t:"a · b = 120 bo'lsa, (a · 2) · b = ?",opts:["240","120","122","60"],ok:0,why:"Bitta ko'paytuvchi 2 marta oshsa, ko'paytma ham 2 marta oshadi.",hint:"(a · 2) · b = (a · b) · 2.",full:"(a · 2) · b = a · b · 2 = 120 · 2 = 240. «122» — 2 ni qo'shish xatosi."},
 tn:"Ikki guruh olma bilan ko'rsating: biridan 40 tasini ikkinchisiga o'tkazsak, jami o'zgarmaydi."},
{h:"Hayotiy masala: ifoda tuzib hisoblaymiz",sum:"4 ta daftar a so'mdan va ruchka b so'm: 4 · a + b. a = 250, b = 300 → 1300.",a:"m08",
 start:function(){w3Expr(['4 daftar × a so‘m','1 ruchka: b so‘m']);w3Msg('Jami narx qaysi ifoda?')},fin:function(){w3Expr(['4 · a + b','= 4 · 250 + 300','= 1000 + 300 = {1300}']);w3Msg('Jami: 1300 so‘m')},
 html:"<p>Ali har biri <b>a</b> so'mdan 4 ta daftar va <b>b</b> so'mlik ruchka oldi. Jami narx qaysi ifoda?</p><div class='digs w3c'></div>",
 act:function(c,done){d3Sel(c,'.w3c',['4 · (a + b)','4 · a + b','4 + a + b'],'4 · a + b',function(){w3Expr(['4 · a + b','a = 250, b = 300:','1000 + 300 = {1300}']);w3Msg('Jami: <b>1300 so‘m</b>');done()},{'4 · (a + b)':'Unda ruchka ham 4 ta bo‘lardi!','4 + a + b':'4 — daftarlar soni, narx emas'})},
 after:"<p>Harfli ifoda — <b>tayyor hisob-kitob</b>: narxlar o'zgarsa, faqat yangi sonlarni qo'yamiz. Do'kondagi kassa dasturlari aynan shunday ishlaydi.</p>",
 q:{t:"2 · (x + y), bunda x = 15, y = 25. Qiymati?",opts:["80","55","65","40"],ok:0,why:"2 · 40 = 80.",hint:"Avval qavs: 15 + 25.",full:"15 + 25 = 40, 2 · 40 = 80. «55» — 2 · 15 + 25 (qavsni e'tiborsiz)."},
 tn:"Sinfda «do'kon» o'yini: narx yorliqlari harf bilan, keyin son bilan almashtiriladi."},
{h:"Bilasizmi? Harflarni kim kiritgan?",sum:"Sonlarni harflar bilan belgilashni XVI asrda fransuz matematigi Fransua Viyet tizimli qo'llagan.",a:"m09",
 start:function(){w3Expr(['P = (a + b) · 2','S = a · b']);w3Msg('Formulalar — matematikaning tili')},fin:function(){w3Expr(['P = (a + b) · 2','S = a · b']);w3Msg('Formulalar — matematikaning tili')},
 html:"<p>📜 Uzoq vaqt masalalar faqat <b>so'zlar</b> bilan yozilgan — hatto al-Xorazmiy ham tenglamalarni so'z bilan bayon qilgan.</p><p>⭐ XVI asr oxirida fransuz matematigi <b>Fransua Viyet</b> ham noma'lum, ham ma'lum sonlarni <b>harflar</b> bilan belgilashni tizimli qo'llay boshladi. Shundan keyin formulalar qisqa va hammaga tushunarli bo'ldi.</p>",
 tn:"Bir masalani so'z bilan va formula bilan yozib, uzunligini solishtiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['a + 5,  3a = 3 · a','P = (a + b) · 2']);w3Msg('Harf — son uchun joy')},fin:function(){w3Expr(['a + 5,  3a = 3 · a','P = (a + b) · 2']);w3Msg('Harf — son uchun joy')},
 html:"<div class='memo'><ul><li>Harfli ifoda: harf o'rniga istalgan son qo'yiladi (a + 5).</li><li>Qiymatni topish: 1) har bir harf o'rniga son, 2) amallar tartibi.</li><li>«5 ta ko'p» → + 5; «5 marta ko'p» → · 5.</li><li>3a = 3 · a; ab = a · b.</li><li>Formula: P = (a + b) · 2.</li><li>Qonuniyatni topganda hamma ustunni tekshiring.</li></ul></div>",
 tn:"Keyingi mavzular (tengsizliklar, tarkibli tenglamalar) harfli ifodalarga tayanadi."}
];
function d3Up(v,c,done){if(S.w1.indexOf(v)<0)S.w1.push(v);var vals=[1,10,25],r1=['a'],r2=['a + 5'],hi=[];vals.forEach(function(x,i){var on=S.w1.indexOf(x)>=0;r1.push(on?x:'?');r2.push(on?x+5:'');if(x===v)hi.push(i+1)});d3Tab([r1,r2],hi);w3Msg('a = '+v+' → a + 5 = '+v+' + 5 = <b>'+(v+5)+'</b>');if(S.w1.length>=3)done()}
var PROBS=[
{t:"a + 15 ifodaning a = 25 dagi qiymati?",o:["40","10","2515","375"],k:0,s:"25 + 15 = 40."},
{t:"60 − b, bunda b = 18. Qiymati?",o:["42","78","48","52"],k:0,s:"60 − 18 = 42."},
{t:"7 · c, bunda c = 8. Qiymati?",o:["56","78","15","87"],k:0,s:"7 · 8 = 56."},
{t:"m : 4, bunda m = 36. Qiymati?",o:["9","144","32","40"],k:0,s:"36 : 4 = 9."},
{t:"3a, bunda a = 6. Qiymati?",o:["18","36","9","63"],k:0,s:"3a = 3 · 6 = 18."},
{t:"a · b − a : b, bunda a = 240, b = 3. Qiymati?",o:["640","720","80","800"],k:0,s:"720 − 80 = 640."},
{t:"P = (a + b) · 2, a = 12 sm, b = 8 sm. P = ?",o:["40 sm","28 sm","20 sm","96 sm"],k:0,s:"20 · 2 = 40 sm."},
{t:"«x dan 7 ta kam» qaysi ifoda?",o:["x − 7","7 − x","x + 7","x : 7"],k:0,s:"Kam → ayirish: x − 7."},
{t:"«y ning 3 baravari» qaysi ifoda?",o:["3 · y","y + 3","y : 3","y − 3"],k:0,s:"Baravar → ko'paytirish."},
{t:"a = 1 da 3, a = 4 da 15. Qaysi ifoda mos?",o:["4 · a − 1","a + 11","3 · a + 3","5 · a − 5"],k:0,s:"4 − 1 = 3, 16 − 1 = 15."},
{t:"a + b = 960 bo'lsa, (a + 40) + (b − 40) = ?",o:["960","1040","880","1000"],k:0,s:"+40 va −40 bir-birini yo'qotadi."},
{t:"a − b = 100 bo'lsa, (a + 7) − (b + 7) = ?",o:["100","114","107","86"],k:0,s:"Ikkalasi bir xil oshsa, ayirma o'zgarmaydi."},
{t:"a · b = 120 bo'lsa, (a · 2) · b = ?",o:["240","120","122","60"],k:0,s:"Ko'paytma 2 marta oshadi."},
{t:"Nodirada n ta qalam, opasida 5 ta ko'p. Opasida nechta?",o:["n + 5","n − 5","5 · n","n : 5"],k:0,s:"«ta ko'p» → qo'shish."},
{t:"4 · a + b, bunda a = 250, b = 300. Qiymati?",o:["1300","2200","554","1150"],k:0,s:"1000 + 300 = 1300."},
{t:"Qaysi ifoda har qanday a uchun a + a + a ga teng?",o:["3 · a","a + 3","a · a · a","3 + a + a"],k:0,s:"Uchta bir xil qo'shiluvchi = 3 · a."},
{t:"100 − k · 5, bunda k = 9. Qiymati?",o:["55","455","95","45"],k:0,s:"9 · 5 = 45, 100 − 45 = 55."},
{t:"2 · (x + y), bunda x = 15, y = 25. Qiymati?",o:["80","55","65","40"],k:0,s:"2 · 40 = 80."},
{t:"a : b + c, bunda a = 72, b = 8, c = 1. Qiymati?",o:["10","8","9","73"],k:0,s:"72 : 8 = 9, 9 + 1 = 10."},
{t:"a = b + 5 va b = 7 bo'lsa, a · 2 = ?",o:["24","19","14","17"],k:0,s:"a = 12, 12 · 2 = 24."}
];
function PRACT_STAGE(){w3Expr(['a + 5,  3a = 3 · a','P = (a + b) · 2']);w3Msg('Harf — son uchun joy')}
var PREP_DATA={teach:["Harfli ifoda va o'zgaruvchi tushunchasi.","Harfli ifodaning qiymatini topish (harf o'rniga son + amallar tartibi).","Matndan ifoda tuzish: «ta ko'p/kam», «marta ko'p/kam».","Formula (P = (a + b) · 2); jadvaldan qonuniyat; 3a = 3 · a."],
 mist:["Sonni harf yoniga yozib qo'yadi: a = 5 da 3a = 35.","Ifodadagi ikkinchi harfni unutadi (m : 4 + m).","«ta ko'p» va «marta ko'p» ni adashtiradi.","Qonuniyatni faqat bitta ustun bo'yicha tekshiradi."],
 need:["Bo'sh quticha va raqamli kartochkalar.","Kubiklar (qonuniyat zinapoyasi)."],
 board:["<span class='w2'>a + 5</span>: a = 1 → 6, a = 10 → 15.","<span class='w2'>a · b − a : b = 640</span> (a = 240, b = 3).","<span class='w2'>P = (a + b) · 2</span>.","<span class='w2'>3a = 3 · a</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
