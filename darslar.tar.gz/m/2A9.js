var CODE='2A9',TITLE='2-sinf · Uch xonali sonlarni taqqoslash';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ikki uch xonali son ustma-ust: yuzlik (kvadrat), o'nlik (tayoqcha), birlik (nuqta)
function fl(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.2},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function row(n,y,hl,lab){var g=S.g,h=Math.floor(n/100),t=Math.floor(n/10)%10,u=n%10;
 T(g,34,y+22,String(n),{'font-size':18,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)fl(g,66+i*17,y+6,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+j*6,y:y+4,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:290+(k%5)*12,cy:y+12+Math.floor(k/5)*14,r:4.5,fill:hl==='u'?C.hi:C.u},g)}
function cmp2(a,b,hl,sign){clear();var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,252,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,314,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u});
 row(a,22,hl);row(b,96,hl);E('line',{x1:10,y1:84,x2:350,y2:84,stroke:'#e6d6bd','stroke-width':1},g);
 if(sign){E('circle',{cx:34,cy:84,r:13,fill:'#fff',stroke:C.blue,'stroke-width':2},g);T(g,34,90,sign,{'font-size':18,'font-weight':800,fill:C.blue})}}
function dig(a,b,pos,sign,note){var A=String(a),B=String(b);function f(s){return s.split('').map(function(c,i){return i===pos?'<b style="color:#d94b4b">'+c+'</b>':c}).join('')}
 strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:22px">'+f(A)+' <b style="color:#1f6fb2">'+(sign||'?')+'</b> '+f(B)+'</div></div>'}
var P1=[function(){cmp2(512,498);dig(512,498,-1,null,'498 da 9 va 8 bor — katta raqamlar. Demak 498 katta?')},
 function(){cmp2(512,498,'h');dig(512,498,0,null,'Avval YUZLIKLAR: 5 ta va 4 ta kvadrat')},
 function(){cmp2(512,498,'h','>');dig(512,498,0,'>','5 yuzlik > 4 yuzlik — qolgan xonalarga qaramaymiz!')}];
var P2=[function(){cmp2(478,487,'h');dig(478,487,0,null,'Yuzliklar: 4 va 4 — teng')},
 function(){cmp2(478,487,'t');dig(478,487,1,null,'Endi O‘NLIKLAR: 7 va 8')},
 function(){cmp2(478,487,'t','<');dig(478,487,1,'<','7 o‘nlik < 8 o‘nlik, demak 478 < 487')}];
var P3=[function(){cmp2(653,657,'t');dig(653,657,-1,null,'Yuzliklar teng (6), o‘nliklar teng (5)…')},
 function(){cmp2(653,657,'u','<');dig(653,657,2,'<','…endi BIRLIKLAR: 3 < 7, demak 653 < 657')}];
var P7=[function(){cmp2(0,515);clear();var g=S.g;T(g,180,40,'4 yuzlik 12 o‘nlik  ?  515',{'font-size':18,'font-weight':800,fill:'#1d2b3a'});T(g,180,90,'4 < 5 — demak kichik?',{'font-size':15,fill:C.bad,'font-weight':700});msg('Shoshilmang: o‘nliklar 9 tadan ko‘p!')},
 function(){clear();var g=S.g;T(g,180,40,'4 yuzlik 12 o‘nlik',{'font-size':18,'font-weight':800,fill:'#1d2b3a'});T(g,180,84,'= 400 + 120 = 520',{'font-size':22,'font-weight':800,fill:C.blue});msg('12 o‘nlik = 1 yuzlik 2 o‘nlik → 5 yuzlik 2 o‘nlik = <b>520</b>')},
 function(){cmp2(520,515,'t','>');dig(520,515,1,'>','Yuzliklar teng, o‘nliklar 2 > 1: <b>4 yuzlik 12 o‘nlik > 515</b>')}];
var STEPS=[
{h:"Avval yuzliklar!",sum:"Uch xonali sonlarda avval yuzliklarni solishtiramiz: 512 > 498, chunki 5 > 4.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>512 va 498 — qaysi katta? 498 da 9 va 8 bor, ular katta raqamlar… Shoshilmang, kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Eng «qimmat» xona — <b>yuzliklar</b>. 512 da 5 ta yuzlik, 498 da 4 ta. 498 dagi 9 ta o'nlik va 8 ta birlik birgalikda ham bitta yuzlikka yetmaydi (98 < 100). Demak <b>512 > 498</b>.</p>",
 q:{t:"Qaysi son katta: 389 yoki 401?",opts:["389","401","Teng","389, chunki 9 katta"],ok:1,why:"4 yuzlik > 3 yuzlik.",hint:"Faqat yuzliklarga qarang: 3 va 4.",full:"Yuzliklar: 389 da 3, 401 da 4. 4 > 3, demak 401 > 389. 389 dagi 8 va 9 ahamiyatsiz — ular yuzlikka yetmaydi."},
 tn:"Ikki xonali sonlarni taqqoslash (2A2) bilan bog'lang: qoida o'sha — chapdan, eng katta xonadan boshlanadi."},
{h:"Yuzliklar teng bo'lsa — o'nliklar",sum:"478 va 487: yuzliklar teng (4), o'nliklar 7 < 8, demak 478 < 487.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>478 va 487 — raqamlari bir xil, faqat o'rni boshqa. Qaysi katta?</p>",
 btns:[phaser(P2)],
 after:"<p>Yuzliklar teng bo'lsa, <b>keyingi xonaga</b> — o'nliklarga o'tamiz: 7 < 8, demak <b>478 < 487</b>. Birliklarga qarash shart emas.</p>",
 q:{t:"Belgini qo'ying: 736 … 763",opts:[">","<","="],ok:1,why:"Yuzliklar teng (7), o'nliklar 3 < 6.",hint:"Yuzliklar teng-mi? Unda o'nliklarga qarang.",full:"736 va 763: yuzliklar 7 va 7 — teng. O'nliklar: 3 va 6. 3 < 6, demak 736 < 763."},
 tn:"Sonlarni ustma-ust yozdiring (xona tagiga xona) — qaysi xonada birinchi farq chiqishini bolalar ko'zi bilan ko'radi."},
{h:"Yuzlar va o'nlar teng bo'lsa — birlar",sum:"653 va 657: yuzlar va o'nlar teng, birlar 3 < 7.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>653 va 657 — birinchi ikki raqam bir xil. Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>Qoida — <b>chapdan o'ngga</b>: yuzliklar → o'nliklar → birliklar. <b>Birinchi farq</b> qilgan xona javobni hal qiladi: 3 < 7, demak 653 < 657.</p>",
 q:{t:"Qaysi yozuv noto'g'ri?",opts:["478 < 487","711 > 117","329 < 239","640 > 599"],ok:2,why:"329 da 3 yuzlik, 239 da 2 yuzlik — 329 katta.",hint:"Har bir yozuvda avval yuzliklarni solishtiring.",full:"478 < 487 ✓ (o'nliklar 7 < 8). 711 > 117 ✓ (7 > 1). 640 > 599 ✓ (6 > 5). 329 < 239 ✗: 3 yuzlik > 2 yuzlik, aslida 329 > 239."},
 tn:"Bankdagi kartochkali savol shu turdagi. Bolalar har yozuvni bittalab tekshirsin, birinchi farqni doira ichiga olsin."},
{h:"Xonalar soni har xil bo'lsa",sum:"Uch xonali son har doim ikki xonalidan katta: 100 > 99. Avval xonalar sonini sanang.",a:"m04",
 start:function(){cmp2(100,99);dig(100,99,-1,null,'100 va 99')},fin:function(){cmp2(100,99,null,'>');dig(100,99,-1,'>','100 — uch xonali, 99 — ikki xonali')},
 html:"<p>100 va 99 — qaysi katta? 99 da 9 lar bor… Lekin 99 da <b>yuzlik umuman yo'q</b>! Tugmani bosing.</p>",
 btns:[["🔍 Xonalarni sanash",function(c,done,b){b.disabled=true;cmp2(100,99,'h','>');dig(100,99,0,'>','100 da 1 yuzlik bor, 99 da — 0. Uch xonali son har doim katta!');done()}]],
 after:"<p>Avval <b>xonalar sonini</b> sanang: uch xonali son har doim istalgan ikki xonali sondan katta. Eng kichik uch xonali (100) ham eng katta ikki xonalidan (99) katta.</p>",
 q:{t:"Qaysi son eng katta?",opts:["99","100","98","89"],ok:1,why:"100 — yagona uch xonali son.",hint:"Qaysi son uch xonali?",full:"99, 98, 89 — ikki xonali. 100 — uch xonali, demak eng katta."},
 tn:"Bolalarga bitta jumla bering: «Raqami ko'p son — katta» (faqat butun sonlar uchun!)."},
{h:"Son o'qida: yuzliklar oralig'i",sum:"400 dan 500 gacha son o'qida 478 va 487 — 487 o'ngroqda, katta.",a:"m05",
 start:function(){S.m5={};ax5();msg('Sonlarni o‘qqa qo‘ying')},fin:function(){S.m5={478:1,487:1,450:1};ax5()},
 html:"<p>Son o'qida 400 dan 500 gacha bo'lgan oraliq. Sonlarni joylashtiring va qaysi biri o'ngroqda turishini ko'ring:</p>",
 btns:[["📍 478",function(c,done,b){b.disabled=true;S.m5[478]=1;ax5();if(S.m5[487])done()}],["📍 487",function(c,done,b){b.disabled=true;S.m5[487]=1;ax5();if(S.m5[478])done()}],["📍 450",function(c,done,b){b.disabled=true;S.m5[450]=1;ax5()}]],g3:1,
 after:"<p>478 ham, 487 ham 400 va 500 orasida. 487 <b>o'ngroqda</b> — u katta. 450 — oraliqning qoq o'rtasi: 478 va 487 undan katta.</p>",
 q:{t:"Son o'qida 600 va 700 orasidagi qaysi son 700 ga eng yaqin?",opts:["610","695","650","601"],ok:1,why:"695 dan 700 gacha 5 qadam — eng kam.",hint:"Qaysi son o'nliklari va birliklari bo'yicha 700 ga eng yaqin?",full:"700 gacha: 610 → 90, 695 → 5, 650 → 50, 601 → 99. Eng yaqini — 695."},
 tn:"Polda 400–500 lentasini belgilang, har 10 qadamda belgi. Bolalar kartochkadagi sonni o'z joyiga qo'ysin."},
{h:"Tuzoq: yashiringan raqam",sum:"6□5 > 675 → □ o'rniga 8 yoki 9. 7 bo'lmaydi: 675 = 675.",a:"m06",
 start:function(){hid6(null)},fin:function(){hid6('all')},
 html:"<p><b>6□5 > 675</b> — □ o'rniga qaysi raqamlarni qo'yish mumkin? Raqamlarni bittalab sinab ko'ring:</p><div class='a9d' style='display:flex;flex-wrap:wrap;gap:6px;margin:8px 0'></div>",
 act:function(c,done){var box=c.querySelector('.a9d'),seen={};box.innerHTML='';for(var d=0;d<=9;d++)(function(d){var b=document.createElement('button');b.textContent=d;b.style.cssText='width:40px;height:42px;border:1px solid #dde5ee;border-radius:10px;background:#fff;font-size:18px;font-weight:700';b.onclick=function(){hid6(d);var ok=d>7;b.style.background=ok?'#e6f6ee':'#fdeaea';b.style.color=ok?'#1e8e5a':'#c23b3b';seen[d]=1;if(Object.keys(seen).length>=5&&!st['a'+cur])done()};box.appendChild(b)})(d)},
 after:"<p>Yuzliklar teng (6 va 6), shuning uchun <b>o'nliklar</b> hal qiladi: □ > 7 bo'lishi kerak — <b>8 yoki 9</b>. □ = 7 bo'lsa, 675 = 675 — teng, «katta» emas!</p>",
 q:{t:"3□8 < 348 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin?",opts:["3","4","5","9"],ok:1,why:"□ < 4: 0, 1, 2, 3 — 4 ta. □ = 4 bo'lsa 348 = 348.",hint:"Yuzliklar teng. O'nliklar xonasidagi □ 4 dan qanday bo'lishi kerak?",full:"Yuzliklar 3 va 3 — teng. O'nliklar: □ < 4 bo'lsa, son kichik: 0, 1, 2, 3 — 4 ta. □ = 4 bo'lsa, birliklar ham teng (8 = 8), 348 = 348 — «kichik» emas."},
 tn:"Chegaradagi raqamni (7 yoki 4) albatta alohida tekshirtiring — bu eng ko'p uchraydigan xato."},
{h:"Tuzoq: xona birliklari bilan berilsa",sum:"4 yuzlik 12 o'nlik = 520 > 515. Avval sonni tartibga keltiring.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>«4 yuzlik 12 o'nlik» va 515 — qaysi katta? 4 < 5 — demak kichikmi? Tekshiramiz!</p>",
 btns:[phaser(P7)],
 after:"<p>12 o'nlikdan 10 tasi — yana bitta yuzlik. Shuning uchun 4 yuzlik 12 o'nlik = <b>520</b>, va <b>520 > 515</b>. Avval sonni to'g'ri ko'rinishga keltiring, keyin taqqoslang.</p>",
 q:{t:"Qaysi taqqoslash to'g'ri?",opts:["3 yuzlik 15 o'nlik < 400","3 yuzlik 15 o'nlik = 315","3 yuzlik 15 o'nlik > 400","3 yuzlik 15 o'nlik = 350"],ok:2,why:"300 + 150 = 450 > 400.",hint:"15 o'nlik nechaga teng? 300 ga qo'shing.",full:"15 o'nlik = 150. 300 + 150 = 450. 450 > 400 — to'g'ri. «315» — o'nliklarni noto'g'ri yozish, «350» — 5 o'nlik deb hisoblash xatosi."},
 tn:"Bolalar xonalar bo'yicha qiymatni yozsin (300 + 150), keyin qo'shsin."},
{h:"Tartib bilan teramiz",sum:"O'sish tartibi: 239, 329, 392, 923 — har safar qolganlarning eng kichigi.",a:"m08",
 start:function(){ord8([])},fin:function(){ord8([239,329,392,923])},
 html:"<p>Sonlarni <b>o'sish tartibida</b> teraylik. Eng kichigidan boshlab bosing:</p><div class='a9o' style='display:flex;flex-wrap:wrap;gap:6px;margin:8px 0'></div>",
 act:function(c,done){var box=c.querySelector('.a9o'),need=[239,329,392,923],got=[];box.innerHTML='';[392,923,239,329].forEach(function(v){var b=document.createElement('button');b.textContent=v;b.style.cssText='width:70px;height:42px;border:1px solid #dde5ee;border-radius:10px;background:#fff;font-size:18px;font-weight:700';b.onclick=function(){if(b.disabled)return;if(v===need[got.length]){got.push(v);b.disabled=true;b.style.background='#e6f6ee';b.style.color='#1e8e5a';ord8(got);if(got.length===4)done()}else{b.style.background='#fdeaea';setTimeout(function(){b.style.background='#fff'},1200);msg('Bu hali eng kichigi emas — yuzliklarni solishtiring')}};box.appendChild(b)})},
 after:"<p>Hamma sonda bir xil raqamlar (2, 3, 9), lekin o'rni har xil. Avval yuzliklar bo'yicha: 2.. < 3.. < 9..; 329 va 392 da yuzliklar teng — o'nliklar: 2 < 9.</p>",
 q:{t:"Qaysi qatorda sonlar kamayish tartibida yozilgan?",opts:["805, 850, 508, 580","850, 805, 580, 508","508, 580, 805, 850","850, 580, 805, 508"],ok:1,why:"Kattadan kichikka: 850 > 805 > 580 > 508.",hint:"Kamayish — kattadan kichikka. Eng kattasi qaysi?",full:"Yuzliklar bo'yicha: 8.. katta, 5.. kichik. 850 va 805: o'nliklar 5 > 0. 580 va 508: 8 > 0. Tartib: 850, 805, 580, 508."},
 tn:"Bitta raqamlardan (2, 3, 9) tuzilgan sonlarni tartiblash — o'rin qiymatini tushunishning eng yaxshi sinovi."},
{h:"Bilasizmi?",sum:"Toshkent teleminorasi 375 m, Eyfel minorasi 330 m atrofida: 375 > 330 — yuzliklar teng, o'nliklar 7 > 3.",a:"m09",
 start:function(){tower()},fin:function(){tower()},
 html:"<p>🗼 <b>Toshkent teleminorasi</b> balandligi — <b>375 metr</b>. Parijdagi mashhur <b>Eyfel minorasi</b> (antennasi bilan) — taxminan <b>330 metr</b>. Qaysi biri baland?</p><p>Yuzliklar teng (3 va 3), o'nliklar: 7 > 3. Demak Toshkent teleminorasi Eyfel minorasidan <b>baland</b>!</p>",
 tn:"Bolalarga haqiqiy sonlarni solishtirish yoqadi: sinf o'quvchilarining bo'yi (sm), maktabgacha masofa (m)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){cmp2(512,498,'h','>');dig(512,498,0,'>')},fin:function(){cmp2(512,498,'h','>');dig(512,498,0,'>')},
 html:"<div class='memo'><ul><li>Avval <b>xonalar sonini</b> sanang: uch xonali > ikki xonali (100 > 99).</li><li>Keyin <b>chapdan o'ngga</b>: yuzliklar → o'nliklar → birliklar.</li><li><b>Birinchi farq</b> qilgan xona hal qiladi: 512 > 498 (5 > 4), 478 < 487 (7 < 8).</li><li>Yashiringan raqam: 6□5 > 675 → □ = 8, 9 (7 — teng bo'lib qoladi).</li><li>Xona birliklari bilan berilsa, avval sonni tuzing: 4 yuzlik 12 o'nlik = 520.</li></ul></div>",
 tn:"Keyingi darsni «Raqamlari 1, 5, 8 bo'lgan eng katta va eng kichik uch xonali sonni taqqoslang» savoli bilan boshlang."}
];
function ax5(){clear();var x0=26,x1=334,y=96,X=function(v){return x0+(v-400)*(x1-x0)/100};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=400;v<=500;v+=10){E('line',{x1:X(v),y1:y-(v%50?6:11),x2:X(v),y2:y+(v%50?6:11),stroke:'#33475b','stroke-width':v%50?1.3:2.6},S.g);if(v%50===0)T(S.g,X(v),y+28,String(v),{'font-size':13,'font-weight':800})}
 var ks=Object.keys(S.m5||{}).map(Number);ks.forEach(function(v,i){var col=v===487?C.ok:(v===478?C.blue:C.a);E('circle',{cx:X(v),cy:y,r:7,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,X(v),y-(v===487?34:16),String(v),{'font-size':13,'font-weight':800,fill:col})});
 msg(S.m5[478]&&S.m5[487]?'487 o‘ngroqda: <b>478 < 487</b>':'Sonlarni joylashtiring')}
function hid6(d){clear();var g=S.g;T(g,180,40,'6□5 > 675',{'font-size':28,'font-weight':800,fill:'#1d2b3a'});
 if(d==='all'){T(g,180,100,'685, 695  >  675',{'font-size':24,'font-weight':800,fill:C.ok});T(g,180,138,'□ = 8 yoki 9',{'font-size':16,'font-weight':800,fill:C.blue});msg('Yuzliklar teng → o‘nliklar 7 dan katta bo‘lsin');return}
 if(d==null){msg('Raqamlarni bosib sinab ko‘ring');return}var n=600+d*10+5,ok=n>675;T(g,180,100,n+(ok?' > ':(n===675?' = ':' < '))+'675',{'font-size':30,'font-weight':800,fill:ok?C.ok:C.bad});T(g,180,138,ok?'✓ to‘g‘ri':(n===675?'✗ teng — «katta» emas':'✗ kichik'),{'font-size':15,'font-weight':800,fill:ok?C.ok:C.bad});msg('Yuzliklar teng (6 va 6) → o‘nliklar hal qiladi')}
function ord8(got){clear();var g=S.g;T(g,180,30,'O‘sish tartibi: kichikdan kattaga',{'font-size':13,fill:C.blue,'font-weight':800});for(var i=0;i<4;i++){var x=48+i*88;E('rect',{x:x-34,y:58,width:68,height:44,rx:10,fill:got[i]?'#e6f6ee':'#fff',stroke:got[i]?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,88,got[i]?String(got[i]):'?',{'font-size':21,'font-weight':800,fill:got[i]?C.ok:'#9aa8b6'});if(i<3)T(g,x+44,88,'<',{'font-size':18,'font-weight':800,fill:'#9aa8b6'})}msg('Har safar qolganlarning <b>eng kichigini</b> tanlang')}
function tower(){clear();var g=S.g,base=160;function tw(x,h,lab,col){var hh=h*0.36;E('path',{d:'M'+(x-16)+' '+base+' L'+(x-3)+' '+(base-hh)+' L'+(x+3)+' '+(base-hh)+' L'+(x+16)+' '+base+' Z',fill:col,stroke:'#33475b','stroke-width':1.2},g);T(g,x,base-hh-8,h+' m',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});T(g,x+(x<180?-60:60),base-10,lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b'})}
 tw(120,375,'Toshkent','#bfe0ff');tw(240,330,'Parij','#ffd9b8');E('line',{x1:20,y1:base,x2:340,y2:base,stroke:'#33475b','stroke-width':2},g);msg('375 > 330: yuzliklar teng, o‘nliklar 7 > 3')}
var PROBS=[
{t:"Qaysi son katta: 512 yoki 498?",o:["512","498","Teng","498, chunki 9 katta"],k:0,s:"5 yuzlik > 4 yuzlik."},
{t:"Belgini qo'ying: 478 … 487",o:["<",">","="],k:0,s:"Yuzliklar teng, o'nliklar 7 < 8."},
{t:"Belgini qo'ying: 905 … 899",o:[">","<","="],k:0,s:"9 yuzlik > 8 yuzlik."},
{t:"Kartochkalardan qaysi yozuv noto'g'ri?",o:["329 < 239","478 < 487","711 > 117","640 > 599"],k:0,s:"329 da 3 yuzlik, 239 da 2 — 329 katta."},
{t:"Qaysi son eng kichik?",o:["199","201","210","1000"],k:0,s:"1 yuzlik — eng kam: 199."},
{t:"6□5 > 675 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin?",o:["2","3","1","4"],k:0,s:"□ = 8 yoki 9 (7 — teng)."},
{t:"3□8 < 348 bo'lishi uchun □ o'rniga qo'yish mumkin bo'lgan eng katta raqam?",o:["3","4","8","2"],k:0,s:"□ < 4: eng kattasi 3."},
{t:"Qaysi qatorda sonlar o'sish tartibida yozilgan?",o:["239, 329, 392, 923","923, 392, 329, 239","329, 239, 392, 923","239, 392, 329, 923"],k:0,s:"Kichikdan kattaga: 239, 329, 392, 923."},
{t:"Qaysi taqqoslash to'g'ri?",o:["4 yuzlik 12 o'nlik > 515","4 yuzlik 12 o'nlik < 500","4 yuzlik 12 o'nlik = 412","4 yuzlik 12 o'nlik < 515"],k:0,s:"400 + 120 = 520 > 515."},
{t:"100 va 99 dan qaysi biri katta?",o:["100","99","Teng","99, chunki 9 katta"],k:0,s:"100 — uch xonali."},
{t:"Raqamlari 1, 5, 8 (har biri bir marta) bo'lgan eng katta uch xonali son?",o:["851","815","581","158"],k:0,s:"Kamayish tartibida: 851."},
{t:"Qaysi son 500 dan katta, lekin 510 dan kichik?",o:["505","515","499","510"],k:0,s:"500 < 505 < 510."},
{t:"□ o'rniga qaysi raqamni qo'ysak, 7□3 > 789 bo'ladi?",o:["9","8","7","0"],k:0,s:"Yuzliklar teng, o'nliklar □ > 8 bo'lishi kerak: 9 (793 > 789). 8 bo'lsa 783 < 789."},
{t:"Son o'qida 300 va 400 orasidagi qaysi son 300 ga eng yaqin?",o:["302","350","398","320"],k:0,s:"302 dan 300 gacha 2 qadam."},
{t:"Ali 437 ni, Vali uning raqamlarini teskari tartibda (734) yozdi. Kimniki katta?",o:["Valiniki","Aliniki","Teng","Raqamlar bir xil — teng"],k:0,s:"7 yuzlik > 4 yuzlik."},
{t:"Toshkent teleminorasi 375 m, Eyfel minorasi 330 m. Qaysi biri qanchaga baland?",o:["Toshkentniki 45 m ga","Eyfel 45 m ga","Toshkentniki 55 m ga","Teng"],k:0,s:"375 − 330 = 45."},
{t:"Kamayish tartibida yozilgan qatorni toping.",o:["850, 805, 580, 508","805, 850, 508, 580","508, 580, 805, 850","850, 580, 805, 508"],k:0,s:"850 > 805 > 580 > 508."},
{t:"Qaysi son 645 dan 10 ta katta?",o:["655","646","745","635"],k:0,s:"O'nliklar 1 ga ortadi: 655."},
{t:"□48 > 748 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin?",o:["2","3","7","1"],k:0,s:"□ > 7: 8 yoki 9."},
{t:"Eng katta uch xonali son eng katta ikki xonali sondan qanchaga katta?",o:["900","99","909","990"],k:0,s:"999 − 99 = 900."}
];
function PRACT_STAGE(){cmp2(512,498,'h','>');dig(512,498,0,'>','Chapdan o‘ngga: birinchi farq hal qiladi')}
var PREP_DATA={teach:["Uch xonali sonlarni taqqoslash: avval xonalar soni, keyin chapdan o'ngga (yuzliklar → o'nliklar → birliklar).","Son o'qida 400–500 oralig'i.","Yashiringan raqam bilan tuzoqlar (6□5 > 675).","Xona birliklarida berilgan sonlar; o'sish va kamayish tartibi."],
 mist:["Katta raqamlarni ko'rib kichik sonni katta deydi (498 > 512).","Chegaradagi raqamni (6□5 > 675 da 7) ham qo'shadi.","«4 yuzlik 12 o'nlik» ni 412 deb o'qiydi.","Ikki xonali va uch xonali sonni raqamlar bo'yicha solishtiradi (99 > 100)."],
 need:["Yuzlik, o'nlik, birlik kartochkalari (qog'oz).","Doskada 400–500 son o'qi."],
 board:["Ustma-ust yozish: <span class='w2'>5 1 2 / 4 9 8</span> — birinchi farq.","<span class='w2'>478 < 487</span> (o'nliklar), <span class='w2'>653 < 657</span> (birliklar).","<span class='w2'>100 > 99</span> — xonalar soni.","<span class='w2'>6□5 > 675 → 8, 9</span>.","<span class='w2'>4 yuzlik 12 o'nlik = 520 > 515</span>."]};
