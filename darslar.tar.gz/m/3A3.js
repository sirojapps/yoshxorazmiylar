var CODE='3A3',TITLE='3-sinf · Rim raqamlari';
var RV=[['M',1000],['CM',900],['D',500],['CD',400],['C',100],['XC',90],['L',50],['XL',40],['X',10],['IX',9],['V',5],['IV',4],['I',1]];
function toR(n){var s='';RV.forEach(function(p){while(n>=p[1]){s+=p[0];n-=p[1]}});return s}
function rom(txt,sub,o){o=o||{};clear('#f6ead0');var g=S.g;T(g,180,o.y||78,txt,{'font-size':o.fs||44,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif','letter-spacing':4});if(sub)T(g,180,(o.y||78)+40,sub,{'font-size':16,'font-weight':700,fill:'#1d2b3a'})}
function keys7(){clear('#f6ead0');var g=S.g,L=[['I',1],['V',5],['X',10],['L',50],['C',100],['D',500],['M',1000]];L.forEach(function(p,i){var x=28+i*50;E('rect',{x:x-20,y:44,width:42,height:50,rx:8,fill:'#fff8e8',stroke:'#c9a764'},g);T(g,x+1,78,p[0],{'font-size':26,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'});T(g,x+1,116,String(p[1]),{'font-size':13,'font-weight':700,fill:'#1d2b3a'})});msg('7 ta asosiy belgi')}
var P3=[function(){rom('VI','5 + 1 = 6');msg('Kichik belgi katta belgidan <b>o‘ngda</b> — qo‘shamiz')},function(){rom('IV','5 − 1 = 4');msg('Kichik belgi katta belgidan <b>chapda</b> — ayiramiz')},function(){rom('XIV','10 + (5 − 1) = 14');msg('Murakkabroq: X + IV = 10 + 4 = 14')},function(){rom('XCIX','(100 − 10) + (10 − 1) = 99');msg('99 = XC + IX. «IC» deb yozilmaydi!')}];
var STEPS=[
{h:"Rimliklarning 7 ta belgisi",sum:"I = 1, V = 5, X = 10, L = 50, C = 100, D = 500, M = 1000.",a:"m01",
 start:function(){keys7()},fin:function(){keys7()},
 html:"<p>Qadimgi Rimda sonlar <b>harflar</b> bilan yozilgan. Faqat 7 ta asosiy belgi bor. Belgini tanlang va qiymatini eslab qoling:</p>",
 btns:[["I · V · X",function(c,done){keys7();msg('I = 1, V = 5, X = 10 — barmoqlar: I bitta barmoq, V ochiq kaft, X ikki kaft');mvK(done,2)}],["L · C · D · M",function(c,done){keys7();msg('L = 50, C = 100 (lotincha centum — yuz), D = 500, M = 1000 (mille — ming)');mvK(done,2)},'u']],g2:1,
 after:"<p>Eslab qolish yo'li: <b>C</b> — «centum» (yuz), «sent» so'zidan tanish; <b>M</b> — «mille» (ming). Rimliklarda <b>0 yo'q</b>!</p>",
 q:{t:"L belgisi nechaga teng?",opts:["5","500","50","100"],ok:2,why:"L = 50.",hint:"Yuzning yarmi qaysi belgi?",full:"L = 50 (C = 100 ning yarmi). 5 — V, 500 — D, 100 — C."},
 tn:"Soat siferblati, kitob boblari, asr raqamlari (XXI asr) — rim raqamlari hayotda qayerda uchrashini so'rang."},
{h:"Qo'shish qoidasi: III, VI, XII",sum:"Teng yoki kichik belgi o'ngda turadi — qo'shiladi: VII = 5 + 2, XXIII = 23.",a:"m02",
 start:function(){S.b='';build()},fin:function(){S.b='XXIII';build()},
 html:"<p>Belgilarni qo'shib son quring. <b>23</b> ni yasang (kattasidan boshlang):</p>",
 btns:[["X",function(c,done){add23("X",done)}],["V",function(c,done){add23("V",done)}],["I",function(c,done){add23("I",done)}]],g3:1,
 after:"<p>XXIII = 10 + 10 + 1 + 1 + 1 = 23. Belgilar <b>kattadan kichikka</b> yoziladi. Bitta belgi ketma-ket <b>3 martadan ko'p</b> yozilmaydi: 4 — IIII emas!</p>",
 q:{t:"XXVII qaysi son?",opts:["22","27","32","17"],ok:1,why:"10 + 10 + 5 + 1 + 1 = 27.",hint:"Har bir belgining qiymatini qo'shing.",full:"X + X = 20, V = 5, I + I = 2. Jami 27."},
 tn:"Cho'plar bilan rim raqamlarini yasash — bolalarga yoqadi."},
{h:"Ayirish qoidasi: IV, IX, XL",sum:"Kichik belgi kattasidan chapda — ayriladi: IV = 4, IX = 9, XL = 40, XC = 90.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>4 ni IIII deb yozish noqulay. Rimliklar ayyorlik qilgan: kichik belgini kattasining <b>chap</b> tomoniga qo'yishgan. Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>Ayirish uchun faqat 6 ta juft ishlatiladi: <b>IV</b> (4), <b>IX</b> (9), <b>XL</b> (40), <b>XC</b> (90), <b>CD</b> (400), <b>CM</b> (900). «IC» (99) yoki «VX» (5) deb yozilmaydi.</p>",
 q:{t:"XIX qaysi son?",opts:["21","9","19","11"],ok:2,why:"X + IX = 10 + 9 = 19.",hint:"I qayerda turibdi — X dan oldinmi, keyinmi?",full:"Avval X = 10. Keyin IX — I katta X dan oldin, demak 10 − 1 = 9. Jami 19. «21» — IX ni XI deb o'qish xatosi."},
 tn:"Oynada IV va VI ni ko'rsating: belgilar bir xil, joyi boshqa — qiymati boshqa."},
{h:"Arab sonini rimchaga o'giramiz",sum:"Sonni xonalarga ajratib, har birini yozamiz: 1 994 = M + CM + XC + IV = MCMXCIV.",a:"m04",
 start:function(){S.n=0;conv()},fin:function(){S.n=4;conv()},
 html:"<p>Tartib: sonni <b>xonalarga ajratamiz</b> va har birini alohida rimchaga o'giramiz. 1994 ni o'giramiz:</p>",
 btns:[["▶ Keyingi xona",function(c,done,b){if(S.n<4){S.n++;conv()}if(S.n>=4){b.disabled=true;done()}}]],
 after:"<p>1994 = 1000 + 900 + 90 + 4 = M + CM + XC + IV = <b>MCMXCIV</b>. Har bir xona o'z belgisini oladi — xuddi bizning xonalar kabi.</p>",
 q:{t:"48 rim raqamlarida qanday yoziladi?",opts:["XLVIII","XXXXVIII","IIL","XLIIX"],ok:0,why:"40 = XL, 8 = VIII → XLVIII.",hint:"Avval o'nliklar (40), keyin birliklar (8).",full:"48 = 40 + 8. 40 = XL (50 − 10). 8 = VIII. Natija: XLVIII. «XXXX» — 4 marta takror mumkin emas, «IIL» — bunday juft yo'q."},
 tn:"Bolalar tug'ilgan yilini rim raqamlarida yozsin (masalan 2017 = MMXVII)."},
{h:"Tuzoq: XL yoki LX — qaysi katta?",sum:"Belgilar bir xil bo'lsa ham tartib qiymatni o'zgartiradi: XL = 40, LX = 60.",a:"m05",
 start:function(){rom('XL   ?   LX','',{fs:38});msg('Belgilar bir xil — X va L. Qaysi son katta?')},fin:function(){rom('XL < LX','40 < 60',{fs:38})},
 html:"<p>Ikkala sonda ham bitta X va bitta L bor. Qaysi biri katta? To'g'ri belgini tanlang:</p>",
 btns:w3choose(["XL > LX","XL = LX","XL < LX"],2,function(){rom('XL < LX','40 < 60',{fs:38});msg('XL = 50 − 10 = 40, LX = 50 + 10 = 60')},function(i){msg(i===1?'Belgilar bir xil, lekin joyi boshqa — qiymat ham boshqa!':'Avval har birini arabchaga o‘giring')}),g3:1,
 after:"<p>Rim sonlarini taqqoslash uchun avval ikkalasini <b>arabchaga</b> o'giring. Belgilar soni ham yordam bermaydi: <b>VIII</b> (4 belgi) = 8, <b>X</b> (1 belgi) = 10 — qisqa yozuv katta son bo'lishi mumkin!</p>",
 q:{t:"Qaysi taqqoslash to'g'ri?",opts:["XIX > XXI","VIII > X","XC > LXXX","CD > DC"],ok:2,why:"XC = 90, LXXX = 80 — 90 > 80.",hint:"Har bir sonni arabchaga o'giring.",full:"XIX = 19 < XXI = 21; VIII = 8 < X = 10 (uzun yozuv katta degani emas); XC = 90 > LXXX = 80 ✓; CD = 400 < DC = 600."},
 tn:"Kartochkalarda juftliklar: IV/VI, IX/XI, XL/LX — bolalar arabcha qiymatini yozib taqqoslasin."},
{h:"Tuzoq: rim raqamlarida hisoblash",sum:"XIV + IX: avval arabchaga — 14 + 9 = 23 — keyin qaytadan: XXIII.",a:"m06",
 start:function(){rom('XIV + IX = ?','',{fs:34});msg('Rim raqamlarida to‘g‘ridan-to‘g‘ri hisoblash qiyin…')},fin:function(){rom('XIV + IX = XXIII','14 + 9 = 23',{fs:28})},
 html:"<p>«XIV + IX ni hisoblang va javobni rim raqamlarida yozing». Belgilarni shunchaki yonma-yon qo'yib bo'lmaydi! Usulni tanlang:</p>",
 btns:w3choose(["XIVIX — yonma-yon yozamiz","Arabchaga o'girib, hisoblab, qaytaramiz"],1,function(){rom('XIV + IX = XXIII','14 + 9 = 23 → XXIII',{fs:28});msg('Usul: <b>rimcha → arabcha → hisob → rimcha</b>')},function(){msg('XIVIX — bunday son yo‘q! Belgilar tartibi buziladi')}),
 after:"<p>Rimliklarning o'zlari ham hisobni cho'tda (abakda) qilgan, yozuvda faqat natijani yozishgan. Bizning raqamlarda esa ustun bilan hisoblash juda oson — shuning uchun ular butun dunyoda qabul qilingan.</p>",
 q:{t:"659 va 478 yig'indisini rim raqamlarida yozing.",opts:["MCXXVII","MCXXXVII","MCCXXXVII","MXXXVII"],ok:1,why:"659 + 478 = 1137 = M + C + XXX + VII.",hint:"Avval 659 + 478 ni hisoblang, keyin xonalarga ajrating.",full:"659 + 478 = 1137 = 1000 + 100 + 30 + 7 = M C XXX VII → MCXXXVII. Variantlar faqat bitta belgi bilan farq qiladi — diqqat!"},
 tn:"Bank savollari (141, 2234). Bolalar har doim arabcha hisob qatorini yozsin."},
{h:"Bilasizmi? Rim raqamlari bugun",sum:"Soatlar, asrlar, kitob boblari, Olimpiada o'yinlari raqamlari — rim raqamlarida.",a:"m07",
 start:function(){clock()},fin:function(){clock()},
 html:"<p>🕰 Ko'p eski soatlarda rim raqamlari bor. Qiziq: ba'zi soatlarda 4 <b>IIII</b> deb yozilgan — bu an'ana, qoida emas.</p><p>📖 Asrlar ham rim raqamlarida yoziladi: hozir <b>XXI</b> asr. Al-Xorazmiy <b>IX</b> asrda yashagan.</p><p>❌ Rim raqamlarida <b>nol yo'q</b> va katta sonlarni yozish juda uzun — shuning uchun ular hisob uchun emas, bezak uchun qoldi.</p>",
 tn:"Sinf soatidagi raqamlarni o'qitish."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){keys7()},fin:function(){keys7()},
 html:"<div class='memo'><ul><li>I 1 · V 5 · X 10 · L 50 · C 100 · D 500 · M 1000.</li><li>Kichik belgi <b>o'ngda</b> — qo'shiladi: VI = 6, XII = 12.</li><li>Kichik belgi <b>chapda</b> — ayriladi: IV 4, IX 9, XL 40, XC 90, CD 400, CM 900.</li><li>Bir belgi <b>3 martadan ko'p</b> takrorlanmaydi.</li><li>O'girish: xonalarga ajrating — 1994 = M CM XC IV.</li><li>Hisoblash: rimcha → arabcha → hisob → rimcha.</li></ul></div>",
 tn:"Keyingi dars — sonlar ketma-ketligi."}
];
function add23(ch,done){var T23="XXIII";if(S.b.length>=5)return;if(T23[S.b.length]===ch){S.b+=ch;build(done)}else{build();var r=23-fromR(S.b||'');msg((S.b||'…')+' — hali '+r+' yetmaydi. '+(r>=10?'Avval o‘nliklar: X':'Endi birliklar: I'))}}
function build(done){var v=0;try{v=fromR(S.b)}catch(e){}rom(S.b||'…',S.b?('= '+v):'',{fs:40});msg(S.b?(S.b+' = '+v+(v===23?' ✓ Topdingiz!':'')):'Belgilarni bosing');if(v===23&&S.b==='XXIII'&&done)done()}
function fromR(s){var m={I:1,V:5,X:10,L:50,C:100,D:500,M:1000},t=0;for(var i=0;i<s.length;i++){var a=m[s[i]],b=m[s[i+1]]||0;t+=a<b?-a:a}return t}
function conv(){clear('#f6ead0');var g=S.g,parts=[[1000,'M'],[900,'CM'],[90,'XC'],[4,'IV']];T(g,180,30,'1994 = 1000 + 900 + 90 + 4',{'font-size':16,'font-weight':800,fill:'#1d2b3a'});
 parts.forEach(function(p,i){var x=60+i*80;E('rect',{x:x-34,y:52,width:68,height:44,rx:8,fill:i<S.n?'#fff8e8':'#fff',stroke:i<S.n?'#c9a764':'#ddd'},g);T(g,x,80,i<S.n?p[1]:'?',{'font-size':24,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'});T(g,x,112,String(p[0]),{'font-size':12,fill:'#5b6b7b'})});
 if(S.n>=4)T(g,180,150,'MCMXCIV',{'font-size':28,'font-weight':800,fill:C.ok,'font-family':'Georgia,serif','letter-spacing':3});msg(S.n>=4?'1994 = <b>MCMXCIV</b>':'Har bir xonani alohida o‘giramiz')}
function clock(){clear('#f6ead0');var g=S.g,cx=180,cy=88,r=70;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff8e8',stroke:'#6b3d12','stroke-width':3},g);for(var h=1;h<=12;h++){var a=(h/12)*2*Math.PI-Math.PI/2;T(g,cx+Math.cos(a)*(r-15),cy+Math.sin(a)*(r-15)+4,toR(h),{'font-size':11,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'})}E('line',{x1:cx,y1:cy,x2:cx,y2:cy-40,stroke:'#6b3d12','stroke-width':3},g);E('line',{x1:cx,y1:cy,x2:cx+30,y2:cy+12,stroke:'#6b3d12','stroke-width':4},g);msg('Soat siferblati: I dan XII gacha')}
var PROBS=[
{t:"XVII qaysi son?",o:["17","15","27","12"],k:0,s:"10 + 5 + 2 = 17."},
{t:"IX qaysi son?",o:["9","11","4","19"],k:0,s:"10 − 1 = 9."},
{t:"XL qaysi son?",o:["40","60","50","90"],k:0,s:"50 − 10 = 40."},
{t:"14 rim raqamlarida:",o:["XIV","XIIII","IVX","XVI"],k:0,s:"10 + 4 = X + IV."},
{t:"29 rim raqamlarida:",o:["XXIX","XXVIIII","XIXX","IXXX"],k:0,s:"20 + 9 = XX + IX."},
{t:"90 rim raqamlarida:",o:["XC","LXXXX","CX","LC"],k:0,s:"100 − 10 = XC."},
{t:"XIV + IX ni hisoblang va rim raqamlarida yozing.",o:["XXIII","XXIV","XIX","XXI"],k:0,s:"14 + 9 = 23 = XXIII."},
{t:"659 va 478 yig'indisi rim raqamlarida:",o:["MCXXXVII","MCXXVII","MCCXXXVII","MXXXVII"],k:0,s:"1137 = M C XXX VII."},
{t:"CD qaysi son?",o:["400","600","500","300"],k:0,s:"500 − 100 = 400."},
{t:"Qaysi yozuv noto'g'ri?",o:["IIII = 4","IV = 4","VI = 6","XI = 11"],k:0,s:"Bir belgi 3 martadan ko'p takrorlanmaydi: 4 = IV."},
{t:"MMXXVI qaysi yil?",o:["2026","2016","2024","1026"],k:0,s:"1000 + 1000 + 20 + 5 + 1 = 2026."},
{t:"XXI asr — nechanchi asr?",o:["21","19","11","12"],k:0,s:"10 + 10 + 1 = 21."},
{t:"Al-Xorazmiy IX asrda yashagan. Bu nechanchi asr?",o:["9","11","4","19"],k:0,s:"IX = 9."},
{t:"LXIV − XXIX = ? (javob rimcha)",o:["XXXV","XXXIV","XLV","XXV"],k:0,s:"64 − 29 = 35 = XXXV."},
{t:"Qaysi son eng katta?",o:["XC","LXXX","LIX","XLIX"],k:0,s:"90, 80, 59, 49 — XC eng katta."},
{t:"VI ni 3 ga ko'paytiring va rimcha yozing.",o:["XVIII","XVI","XIIX","XXIII"],k:0,s:"6 · 3 = 18 = XVIII."},
{t:"Cho'plar bilan VII yozilgan. Bitta cho'pni olib tashlab qaysi sonni hosil qilish mumkin?",o:["VI","IX","VIII","X"],k:0,s:"Oxirgi I ni olsak: VI = 6."},
{t:"499 rim raqamlarida:",o:["CDXCIX","ID","CDIC","CCCCXCIX"],k:0,s:"400 + 90 + 9 = CD XC IX."},
{t:"Rim raqamlarida qaysi raqam yo'q?",o:["0 (nol)","1","5","1000"],k:0,s:"Rimliklarda nol belgisi bo'lmagan."},
{t:"MCMXCIV qaysi yil?",o:["1994","1996","2004","1494"],k:0,s:"M (1000) + CM (900) + XC (90) + IV (4) = 1994."}
];
function PRACT_STAGE(){keys7()}
var PREP_DATA={teach:["7 ta rim belgisi va ularning qiymatlari.","Qo'shish va ayirish qoidalari, 6 ta ayirish jufti.","Arab sonini rimchaga xonalab o'girish; rim raqamlarida hisob."],mist:["IV va VI ni chalkashtiradi.","4 ni IIII, 99 ni IC deb yozadi.","XIV + IX ni XIVIX deb yozadi.","Variantlardagi bitta belgi farqini sezmaydi (MCXXVII / MCXXXVII)."],need:["Cho'plar, soat rasmi."],board:["<span class='w2'>I V X L C D M</span> = 1 5 10 50 100 500 1000.","<span class='w2'>VI = 6, IV = 4</span>.","<span class='w2'>IV IX XL XC CD CM</span>.","<span class='w2'>1994 = M CM XC IV</span>.","<span class='w2'>XIV + IX → 14 + 9 = 23 → XXIII</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
