// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4I5',TITLE='4-sinf · Venn diagrammasi';
function i5nums(st){clear();y4title('1 dan 20 gacha sonlar');y4venn2('A: juft sonlar','B: 3 ga bo‘linadi');
 if(st>=1){var g=S.g,put=function(arr,pos,col){arr.forEach(function(v,i){y4T(g,pos[i][0],pos[i][1],String(v),{'font-size':12,'font-weight':800,fill:col})})};
  put([2,4,8,10,14,16,20],[[100,80],[122,80],[100,100],[122,100],[100,120],[122,120],[110,140]],C.a2);
  put([3,9,15],[[252,88],[252,108],[252,128]],C.blue);
  if(st>=2)put([6,12,18],[[180,88],[180,108],[180,128]],C.ok);
  if(st>=3)put([1,5,7,11,13,17,19],[[300,72],[324,72],[300,92],[324,92],[300,112],[324,112],[300,132]],'#7a8794')}}
var I5P1=[function(){i5nums(0);calc(['A doirasi — juft sonlar, B doirasi — 3 ga bo‘linadigan sonlar'])},function(){i5nums(1);calc(['Faqat 2 ga: 2, 4, 8… Faqat 3 ga: 3, 9, 15'])},function(){i5nums(2);calc(['6, 12, 18 — <b>ikkala</b> shartga mos → <b>kesishma</b>ga'])},function(){i5nums(3);calc(['Hech biriga mos kelmaydiganlar — doiralardan <b>tashqarida</b>','7 + 3 + 3 + 7 = 20 ✓'])}];
function i5union(st){clear();y4title('Futbol — 25 bola, shaxmat — 18 bola, ikkalasi — 7 bola');var n={};if(st>=1){n.a=18;n.ab=7}if(st>=2)n.b=11;y4venn2('futbol','shaxmat',n,{ab:st>=1});
 if(st===0){y4T(S.g,180,111,'?',{'font-size':18,'font-weight':800,fill:C.bad})}
 }
var I5P2=[function(){i5union(0);calc(['Nechta bola to‘garakka qatnaydi? 25 + 18 = 43 mi?'])},function(){i5union(1);calc(['Markazdan boshlaymiz: kesishma — 7. Faqat futbol: 25 − 7 = 18'])},function(){i5union(2);calc(['Faqat shaxmat: 18 − 7 = 11'])},function(){i5union(3);calc(['Jami: 18 + 7 + 11 = <b>36</b>. Formula: 25 + 18 − <b>7</b> = 36','7 ta bola ikki marta sanalgan edi — bir marta ayiramiz'])}];
function i5none(sh){clear();y4title('Sinfda 30 bola: futbol 18, shaxmat 14, ikkalasi 7');y4venn2('futbol','shaxmat',{a:11,ab:7,b:7,o:sh?5:'?'},{});}
function i5lang(sh){clear();y4title('30 bola: ingliz 20, rus 15, har biri kamida bittasini o‘rganadi');y4venn2('ingliz','rus',sh?{a:15,ab:5,b:10,o:0}:{ab:'?',o:0},{ab:1});}
function i5three(st){clear();var n={};if(st>=1)n.abc=2;if(st>=2){n.ab=3;n.ac=2;n.bc=1}if(st>=3){n.a=8;n.b=6;n.c=5}y4venn3('A: 15','B: 12','C: 10',n);
 y4t(330,58,'AB = 5',{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'});y4t(330,72,'AC = 4',{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'});y4t(330,86,'BC = 3',{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'});y4t(330,100,'ABC = 2',{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'});
 if(st>=4)y4t(60,160,'jami 27',{'font-size':13,'font-weight':800,fill:C.ok})}
var I5P5=[function(){i5three(0);calc(['Uch to‘garak. Ma‘lumlar o‘ngda. Qayerdan boshlaymiz?'])},function(){i5three(1);calc(['<b>Markaz</b>dan: uchalasi — 2'])},function(){i5three(2);calc(['Juftliklar: faqat AB = 5 − 2 = 3, faqat AC = 4 − 2 = 2, faqat BC = 3 − 2 = 1'])},function(){i5three(3);calc(['Faqat A = 15 − 3 − 2 − 2 = 8; faqat B = 12 − 3 − 1 − 2 = 6; faqat C = 10 − 2 − 1 − 2 = 5'])},function(){i5three(4);calc(['Jami: 8 + 6 + 5 + 3 + 2 + 1 + 2 = <b>27</b>'])}];
function i5minmax(st){clear();y4title('30 bola: 20 tasi olmani, 18 tasi nokni yoqtiradi');var g=S.g,k=10;
 E('rect',{x:30,y:40,width:300,height:20,fill:'#f2f4f7',stroke:'#8a99a8'},g);y4T(g,180,55,'30 bola',{'font-size':11,'font-weight':800,fill:'#3a4a5a'});
 E('rect',{x:30,y:76,width:200,height:20,fill:'#ffe1b0',stroke:C.a},g);y4T(g,130,91,'olma 20',{'font-size':11,'font-weight':800});
 var nx=st>=1?150:30;E('rect',{x:nx,y:104,width:180,height:20,fill:'#cfe6fa',stroke:C.b},g);y4T(g,nx+90,119,'nok 18',{'font-size':11,'font-weight':800});
 if(st>=1){E('rect',{x:150,y:72,width:80,height:56,fill:'none',stroke:C.ok,'stroke-width':2.5,'stroke-dasharray':'5 3'},g);y4T(g,190,146,'kamida 8',{'font-size':13,'font-weight':800,fill:C.ok})}
 else{E('rect',{x:30,y:72,width:180,height:56,fill:'none',stroke:C.blue,'stroke-width':2.5,'stroke-dasharray':'5 3'},g);y4T(g,120,146,'ko‘pi bilan 18',{'font-size':13,'font-weight':800,fill:C.blue})}}
function i5logic(sh){clear();y4title('«Barcha kvadratlar — to‘g‘ri to‘rtburchaklar». Qaysi rasm?');var g=S.g;
 [[60,1],[180,2],[300,3]].forEach(function(p){var x=p[0];E('rect',{x:x-54,y:30,width:108,height:110,rx:6,fill:sh&&p[1]===1?'#e7f6ec':'#fff',stroke:sh&&p[1]===1?C.ok:'#c9d3dd','stroke-width':sh&&p[1]===1?2.5:1},g);y4T(g,x,158,p[1]+'-rasm',{'font-size':12,'font-weight':800})});
 E('circle',{cx:60,cy:85,r:44,fill:'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:60,cy:98,r:22,fill:'rgba(240,160,64,.3)',stroke:C.a,'stroke-width':2},g);y4T(g,60,56,'T',{'font-size':12,'font-weight':800,fill:C.blue});y4T(g,60,103,'K',{'font-size':12,'font-weight':800,fill:C.a2});
 E('circle',{cx:180,cy:85,r:44,fill:'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:180,cy:98,r:22,fill:'rgba(90,169,230,.3)',stroke:C.b,'stroke-width':2},g);y4T(g,180,56,'K',{'font-size':12,'font-weight':800,fill:C.a2});y4T(g,180,103,'T',{'font-size':12,'font-weight':800,fill:C.blue});
 E('circle',{cx:282,cy:85,r:26,fill:'rgba(240,160,64,.25)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:318,cy:85,r:26,fill:'rgba(90,169,230,.25)',stroke:C.b,'stroke-width':2},g);y4T(g,270,90,'K',{'font-size':12,'font-weight':800,fill:C.a2});y4T(g,330,90,'T',{'font-size':12,'font-weight':800,fill:C.blue})}
function i5only(sh){clear();y4title('Faqat futbol — 12, ikkalasi — 5, faqat basketbol — 9');y4venn2('futbol','basketbol',{a:12,ab:5,b:9},sh?{a:1,ab:1}:{});}
function i5venn(st){clear();y4title('Jon Venn va uning diagrammasi');var g=S.g;
 E('circle',{cx:150,cy:84,r:44,fill:'rgba(240,160,64,.25)',stroke:C.a,'stroke-width':2.5},g);E('circle',{cx:210,cy:84,r:44,fill:'rgba(90,169,230,.25)',stroke:C.b,'stroke-width':2.5},g);
 if(st>=1)E('circle',{cx:180,cy:124,r:44,fill:'rgba(30,142,90,.2)',stroke:C.ok,'stroke-width':2.5},g);
 y4T(g,60,60,'1880',{'font-size':18,'font-weight':800,fill:C.a2});if(st>=1)y4T(g,300,150,'Kembrij',{'font-size':12,'font-weight':800,fill:'#3a4a5a'});if(st>=1)y4T(g,300,164,'vitraj oynasi',{'font-size':11,fill:'#3a4a5a'})}
var I5P9=[function(){i5venn(0);calc(['1880-yil: ingliz olimi Jon Venn mantiq masalalari uchun doiralardan foydalandi'])},function(){i5venn(1);calc(['Kembrij universitetidagi Venn kollejida uning sharafiga uch doirali <b>rangli oyna</b> (vitraj) bor'])}];
function PRACT_STAGE(){clear();y4title('Avval markaz, keyin «faqat» qismlar, oxirida tashqari');y4venn2('A','B',{a:'faqat A',ab:'A va B',b:'faqat B'});calc(['A yoki B = A + B − (A va B)'])}
var STEPS=[
{h:"Sonlarni diagrammaga joylash",sum:"1–20: faqat juft — 7 ta, faqat 3 ga bo'linadigan — 3 ta, ikkalasi (6, 12, 18) — 3 ta, hech biri — 7 ta.",a:"m01",
 start:function(){startPh(I5P1)},fin:function(){S.ph=3;I5P1[3]()},
 html:"<p><b>Venn diagrammasi</b>da har bir doira — bitta to'plam (shartga mos narsalar). 1 dan 20 gacha sonlarni ikki shart bo'yicha joylaymiz. Bosing:</p>",btns:[phaser(I5P1)],
 after:"<p>Diagrammaning <b>4 ta qismi</b>: faqat A, faqat B, A va B (<b>kesishma</b>), hech biri (tashqari). Har bir son faqat bitta qismga tushadi. Ikkala shartga mos sonlar — kesishmada.</p>",
 q:{t:"Shu diagrammada 6 ga bo'linadigan sonlar qayerda turadi?",opts:["Kesishmada","Faqat A da","Faqat B da","Tashqarida"],ok:0,why:"6 ga bo'linadigan son ham 2 ga, ham 3 ga bo'linadi.",hint:"6 ga bo'linadigan son 2 ga bo'linadimi? 3 ga-chi?",full:"6, 12, 18 — ham juft, ham 3 ga bo'linadi. Shuning uchun ular ikkala doiraga ham tegishli, ya'ni kesishmada."},
 tn:"Polga ikki hulahop (yoki arqon halqa) qo'ying. Bolalarga son yozilgan kartochka bering — o'zi to'g'ri joyga borib tursin."},
{h:"Birlashmani sanash: ikki marta sanamang!",sum:"25 + 18 − 7 = 36. Kesishma ikki marta sanaladi — bir marta ayiramiz.",a:"m02",
 start:function(){startPh(I5P2)},fin:function(){S.ph=3;I5P2[3]()},
 html:"<p>Futbolga 25 bola, shaxmatga 18 bola qatnaydi, 7 bola ikkalasiga. Jami nechta bola to'garakda? Bosing:</p>",btns:[phaser(I5P2)],
 after:"<p>Doimo <b>markazdan</b> (kesishmadan) boshlang. Formula: <b>A yoki B = A + B − (A va B)</b>. Ayirmasak, kesishmadagi bolalar ikki marta sanalib qoladi.</p>",
 q:{t:"Rasm to'garagida 16, qo'shiq to'garagida 13 bola. 4 bola ikkalasiga qatnaydi. Jami nechta bola?",opts:["25","29","33","21"],ok:0,why:"16 + 13 − 4 = 25.",hint:"Ikkalasiga qatnaydiganlarni necha marta sanadingiz?",full:"16 + 13 = 29 da 4 bola ikki marta sanalgan. 29 − 4 = 25. «29» — kesishmani ayirmaslik, «33» — kesishmani qo'shish, «21» — kesishmani ikki marta ayirish."},
 tn:"Ikki ro'yxat tuzing (futbol, shaxmat) — ikkalasida bor ismlarni doiraga oling. Bolalar takror sanalganini o'zi ko'radi."},
{h:"Hech biriga kirmaganlar",sum:"30 − (11 + 7 + 7) = 5 bola hech qaysi to'garakda emas.",a:"m03",
 start:function(){i5none(0);calc(['Nechta bola hech qaysi to‘garakka qatnamaydi?'])},fin:function(){i5none(1);y4msg('Hech biriga: <b>5</b> bola')},
 html:"<p>Sinfda 30 bola. 18 tasi futbol, 14 tasi shaxmat o'ynaydi, 7 tasi — ikkalasini. Nechta bola hech birini o'ynamaydi?</p>",
 btns:y4pick(1,[["2 ta","18 + 14 = 32 dan 30 ni ayirdingiz. Avval kesishmani hisobga oling: kamida bittasi 18 + 14 − 7 = 25."],["5 ta","Kamida bittasi: 18 + 14 − 7 = 25. Hech biri: 30 − 25 = 5."],["12 ta","30 − 18 = 12 — shaxmatchilarni unutdingiz."],["7 ta","7 — ikkalasini o'ynaydiganlar, hech birini emas."]],function(){i5none(1)}),g2:1,
 after:"<p>Ikki qadam: 1) <b>kamida bittasi</b>ga kirganlar: A + B − (A va B); 2) <b>hech biri</b> = jami − shu son. Tashqi qism ham diagrammaning bir qismi!</p>",
 q:{t:"32 bola: 20 tasi suzish, 15 tasi tennis bilan shug'ullanadi, 6 tasi ikkalasi bilan. Nechta bola hech biri bilan shug'ullanmaydi?",opts:["3","9","29","35"],ok:0,why:"20 + 15 − 6 = 29; 32 − 29 = 3.",hint:"Avval kamida bittasi bilan shug'ullanadiganlarni toping.",full:"Kamida bittasi: 20 + 15 − 6 = 29. Hech biri: 32 − 29 = 3. «29» — bu kamida bittasi bilan shug'ullanadiganlar, «35» — kesishmani ayirmaslik."},
 tn:"Hulahop tashqarisida turgan bolalarni ham sanating — ular ham sinf a'zosi!"},
{h:"Tuzoq: kesishmani topish",sum:"Hamma kamida bitta tilni o'rganadi: 20 + 15 − 30 = 5 bola ikkalasini.",a:"m04",
 start:function(){i5lang(0);calc(['Nechta bola ikkala tilni ham o‘rganadi?'])},fin:function(){i5lang(1);y4msg('Ikkalasi: <b>5</b> bola')},
 html:"<p>30 bola. 20 tasi ingliz tilini, 15 tasi rus tilini o'rganadi. Har bir bola kamida bitta tilni o'rganadi. Nechta bola ikkalasini o'rganadi?</p>",
 btns:y4pick(0,[["5","20 + 15 = 35, lekin bolalar 30 ta. Ortiqcha 5 — ikki marta sanalganlar."],["35","35 — bolalar sonidan ko'p! Kimdir ikki marta sanalgan."],["10","20 − 15 = 5 emas, 10 ham emas: ayirish emas, yig'indini jami bilan taqqoslang."],["15","15 — rus tilini o'rganadiganlarning hammasi."]],function(){i5lang(1)}),g2:1,
 after:"<p>Agar hamma kamida bitta to'plamda bo'lsa: <b>kesishma = A + B − jami</b>. Yig'indi jamidan qanchaga oshsa — shuncha bola ikki marta sanalgan.</p>",
 q:{t:"25 bola: 16 tasi olmani, 14 tasi nokni yoqtiradi. Har bir bola kamida bittasini yoqtiradi. Nechta bola ikkalasini yoqtiradi?",opts:["5","30","2","9"],ok:0,why:"16 + 14 − 25 = 5.",hint:"16 + 14 jamidan qanchaga oshadi?",full:"16 + 14 = 30, bolalar 25 ta: 30 − 25 = 5 bola ikki marta sanalgan, ya'ni ikkalasini yoqtiradi. «2» — 16 − 14, «9» — 25 − 16."},
 tn:"Bolalar ikki guruhga bo'linib tursin; ikkala guruhda ham bo'lgan bolalar o'rtaga o'tadi."},
{h:"Uch to'plam: markazdan tashqariga",sum:"Uchalasi 2 → juftliklar 3, 2, 1 → faqat A 8, faqat B 6, faqat C 5 → jami 27.",a:"m05",
 start:function(){startPh(I5P5)},fin:function(){S.ph=4;I5P5[4]()},
 html:"<p>Uchta to'garak: A — 15, B — 12, C — 10 bola. Ikkitadan: AB — 5, AC — 4, BC — 3. Uchalasiga — 2 bola. Jami nechta bola? Bosing:</p>",btns:[phaser(I5P5)],
 after:"<p>Uch doirada <b>7 ta ichki qism</b> bor. Tartib: 1) markaz; 2) juftliklardan markazni ayiring; 3) har doiradan ichidagi boshqa qismlarni ayiring; 4) hammasini qo'shing. Teskari yo'l bilan boshlasangiz, albatta adashasiz.</p>",
 q:{t:"Shu diagrammada nechta bola faqat BITTA to'garakka qatnaydi?",opts:["19","27","6","37"],ok:0,why:"8 + 6 + 5 = 19.",hint:"«Faqat» qismlarni qo'shing.",full:"Faqat A — 8, faqat B — 6, faqat C — 5: jami 19. «27» — hamma bolalar, «6» — ikki va uchta to'garakdagilar (3 + 2 + 1), «37» — 15 + 12 + 10."},
 tn:"Uchta hulahop bilan o'yin. Har bola o'z qatnaydigan to'garaklariga mos joyga tursin."},
{h:"Kesishma kamida va ko'pi bilan",sum:"30 bola, olma 20, nok 18: ikkalasi kamida 20 + 18 − 30 = 8, ko'pi bilan 18.",a:"m06",
 start:function(){i5minmax(0);calc(['Nok yoqtiradiganlarning hammasi olmani ham yoqtirsa — kesishma 18 (eng ko‘p)'])},fin:function(){i5minmax(1);y4msg('Kamida <b>8</b>, ko‘pi bilan <b>18</b>')},
 html:"<p>30 bola: 20 tasi olmani, 18 tasi nokni yoqtiradi. Ko'pi bilan 18 ta bola ikkalasini yoqtirishi mumkin (sahnada). <b>Kamida</b> nechta bola ikkalasini yoqtiradi?</p>",
 btns:y4pick(1,[["0","Kesishma bo'lmasa, 20 + 18 = 38 bola kerak bo'ladi — sinfda esa 30 ta."],["8","Tasmalarni bir-biridan iloji boricha uzoqlashtiramiz: 20 + 18 − 30 = 8 tasi baribir ustma-ust tushadi."],["18","Bu — eng ko'p bo'lishi mumkin bo'lgan kesishma, eng kam emas."],["2","20 − 18 = 2 — bu ayirma kesishmaga aloqasi yo'q."]],function(){i5minmax(1)}),g2:1,
 after:"<p>Chiziqli model (tasmalar) yordam beradi. <b>Eng ko'p</b> kesishma — kichik to'plam butunlay kattasi ichida (18). <b>Eng kam</b> — tasmalarni ikki chetga surish: A + B − jami (agar musbat bo'lsa).</p>",
 q:{t:"40 bola: 26 tasi suzishni, 22 tasi yugurishni yaxshi ko'radi. Kamida nechta bola ikkalasini yaxshi ko'radi?",opts:["8","22","4","0"],ok:0,why:"26 + 22 − 40 = 8.",hint:"Ikkala son yig'indisi jamidan qanchaga oshadi?",full:"26 + 22 = 48 > 40. Ortiqcha 8 — ular albatta ikki to'plamda. «22» — eng ko'pi, «4» — 26 − 22, «0» — kesishma bo'lmasa 48 bola kerak."},
 tn:"Ikki qog'oz tasmani 30 katakli lentaga qo'yib, surib ko'ring — kesishma qachon eng kichik bo'ladi?"},
{h:"Mulohazalar va doiralar",sum:"«Barcha K — T»: K doirasi T ning ichida (1-rasm).",a:"m07",
 start:function(){i5logic(0);calc(['K — kvadratlar, T — to‘g‘ri to‘rtburchaklar'])},fin:function(){i5logic(1);y4msg('1-rasm: K butunlay T ichida')},
 html:"<p>Venn diagrammasi so'z bilan aytilgan mulohazani ham chizadi. «Barcha kvadratlar — to'g'ri to'rtburchaklar». Qaysi rasm to'g'ri?</p>",
 btns:y4pick(0,[["1-rasm","Har bir kvadrat to'g'ri to'rtburchak — K doirasi T ichida."],["2-rasm","Bu «barcha to'g'ri to'rtburchaklar — kvadrat» degani. Lekin 2×5 to'rtburchak kvadrat emas."],["3-rasm","Bu «hech bir kvadrat to'g'ri to'rtburchak emas» degani — noto'g'ri."]],function(){i5logic(1)}),
 after:"<p>«<b>Barcha</b> A — B» → A doirasi B ichida. «<b>Hech bir</b> A — B emas» → doiralar alohida. «<b>Ba'zi</b> A — B» → doiralar kesishadi. Chizib qarasangiz, qaysi xulosa to'g'ri ekani ko'rinadi.</p>",
 q:{t:"«Barcha kvadratlar — romb. Ba'zi to'rtburchaklar — kvadrat.» Qaysi xulosa albatta to'g'ri?",opts:["Ba'zi to'rtburchaklar — romb","Barcha romblar — kvadrat","Hech bir romb to'rtburchak emas","Barcha to'rtburchaklar — kvadrat"],ok:0,why:"Kvadrat bo'lgan to'rtburchaklar romb ham — demak ba'zi to'rtburchaklar romb.",hint:"Kvadrat doirasini romb doirasi ichiga chizing.",full:"Kvadratlar romb ichida. Ba'zi to'rtburchaklar kvadrat — ular romb ichida ham. Demak, ba'zi to'rtburchaklar — romb. «Barcha romblar — kvadrat» — teskari mulohaza, u noto'g'ri."},
 tn:"Bolalar o'z mulohazasini aytadi («Barcha qushlar uchadi»?) — sinf chizib tekshiradi va qarshi misol izlaydi (pingvin)."},
{h:"«Faqat» va «hammasi» farqi",sum:"Futbol o'ynaydiganlar = faqat futbol + ikkalasi = 12 + 5 = 17.",a:"m08",
 start:function(){i5only(0);calc(['Nechta bola futbol o‘ynaydi?'])},fin:function(){i5only(1);y4msg('Futbol: 12 + 5 = <b>17</b>')},
 html:"<p>Diagrammada «faqat» qismlar yozilgan. Nechta bola <b>futbol</b> o'ynaydi?</p>",
 btns:y4pick(0,[["17","Futbol doirasi ikki qismdan iborat: faqat futbol (12) va ikkalasi (5)."],["12","12 — faqat futbol o'ynaydiganlar. Ikkalasini o'ynaydiganlar ham futbol o'ynaydi!"],["26","26 — hamma bolalar."],["5","5 — ikkalasini o'ynaydiganlar."]],function(){i5only(1)}),g2:1,
 after:"<p>Diagrammadagi son — <b>qism</b>ning soni. To'plam (butun doira) = uning ichidagi barcha qismlar yig'indisi. Savoldagi «faqat» so'ziga e'tibor bering!</p>",
 q:{t:"Faqat ingliz — 14, ikkala til — 6, faqat nemis — 8 bola. Nechta bola nemis tilini o'rganadi?",opts:["14","8","28","20"],ok:0,why:"8 + 6 = 14.",hint:"Nemis doirasida qaysi qismlar bor?",full:"Nemis doirasi: faqat nemis (8) + ikkalasi (6) = 14. «8» — faqat nemis, «20» — ingliz tilini o'rganadiganlar (14 + 6), «28» — hamma."},
 tn:"Savollarni juft qilib bering: «faqat futbol?» va «futbol?» — farqni bolalar o'zi tushuntirsin."},
{h:"Bilasizmi? Jon Venn",sum:"1880-yil — Jon Venn doiralar diagrammasini e'lon qildi; Kembrijda uning sharafiga vitraj oyna bor.",a:"m09",
 start:function(){startPh(I5P9)},fin:function(){S.ph=1;I5P9[1]()},
 html:"<p>Doiralar bilan fikrlash g'oyasining tarixi bor. Bosing:</p>",btns:[phaser(I5P9)],
 after:"<p>🇬🇧 Jon Venn (1834–1923) — ingliz mantiqshunosi. Undan oldin ham doiralardan Leonard Eyler (XVIII asr) foydalangan, shuning uchun ba'zan <b>Eyler–Venn diagrammasi</b> deyiladi. Bugun bu usul matematika, biologiya va dasturlashda ishlatiladi.</p>",
 tn:"Bolalardan o'zlari haqida 2 doirali diagramma chizdiring: «men yoqtiraman» va «do'stim yoqtiradi»."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>Ikki doirada 4 qism: faqat A, faqat B, A va B, hech biri.</li><li><b>Har doim markazdan boshlang.</b></li><li>A yoki B = A + B − (A va B). Hech biri = jami − (A yoki B).</li><li>Hamma kamida bittasida bo'lsa: kesishma = A + B − jami.</li><li>Kesishma: kamida A + B − jami, ko'pi bilan kichik to'plam.</li><li>«Barcha» — ichida, «hech bir» — alohida, «ba'zi» — kesishadi.</li><li>To'plam soni = uning ichidagi barcha qismlar yig'indisi («faqat» bilan adashtirmang).</li></ul></div>",
 tn:"Uyga: oiladagi 5 kishi haqida «choy ichadi / qahva ichadi» diagrammasi."}
];
var PROBS=[
{t:"1 dan 30 gacha sonlar. A — 2 ga bo'linadiganlar, B — 5 ga bo'linadiganlar. Kesishmada nechta son?",o:["3","6","15","2"],k:0,s:"10, 20, 30."},
{t:"1 dan 20 gacha sonlar. A — juft sonlar, B — 4 ga bo'linadigan sonlar. B doirasi qanday joylashadi?",o:["B butunlay A ichida","A butunlay B ichida","Ular kesishmaydi","Qisman kesishadi"],k:0,s:"4 ga bo'linadigan har bir son juft."},
{t:"32 bola: 20 tasi suzish, 15 tasi tennis bilan, 6 tasi ikkalasi bilan shug'ullanadi. Nechta bola hech biri bilan shug'ullanmaydi?",o:["3","9","29","35"],k:0,s:"32 − (20 + 15 − 6) = 3."},
{t:"25 bola: 16 tasi olmani, 14 tasi nokni yoqtiradi, har biri kamida bittasini. Nechta bola ikkalasini yoqtiradi?",o:["5","30","2","9"],k:0,s:"16 + 14 − 25 = 5."},
{t:"Faqat futbol — 12, ikkalasi — 5, faqat shaxmat — 9 bola. Nechta bola futbol o'ynaydi?",o:["17","12","26","21"],k:0,s:"12 + 5."},
{t:"Faqat futbol — 12, ikkalasi — 5, faqat shaxmat — 9 bola (boshqa bola yo'q). Jami nechta bola?",o:["26","31","21","17"],k:0,s:"12 + 5 + 9."},
{t:"40 bola: 25 tasi ingliz, 18 tasi nemis tilini o'rganadi, 10 tasi ikkalasini. Nechta bola faqat BITTA tilni o'rganadi?",o:["23","33","43","13"],k:0,s:"15 + 8 = 23."},
{t:"A = {2, 4, 6, 8, 10}, B = {3, 6, 9, 12}. A va B ning birlashmasida nechta element bor?",o:["8","9","1","7"],k:0,s:"5 + 4 − 1 = 8."},
{t:"A = {2, 4, 6, 8, 10}, B = {3, 6, 9, 12}. A va B ning kesishmasi qaysi?",o:["{6}","{2, 3}","{6, 12}","Bo'sh to'plam"],k:0,s:"Faqat 6 ikkalasida bor."},
{t:"30 bola: 18 tasi olmani, 17 tasi nokni yoqtiradi. Kamida nechta bola ikkalasini yoqtiradi?",o:["5","17","0","35"],k:0,s:"18 + 17 − 30 = 5."},
{t:"30 bola: 18 tasi olmani, 17 tasi nokni yoqtiradi. Ko'pi bilan nechta bola ikkalasini yoqtirishi mumkin?",o:["17","18","5","35"],k:0,s:"Kichik to'plam butunlay kattasi ichida."},
{t:"«Barcha mushuklar — hayvon». Diagrammada «mushuklar» doirasi qanday joylashadi?",o:["«Hayvonlar» doirasi ichida","«Hayvonlar»ni o'z ichiga oladi","Alohida turadi","Qisman kesishadi"],k:0,s:"Har bir mushuk hayvon."},
{t:"Matematika — 14, rasm — 11, musiqa — 9 bola. Mat+rasm — 5, mat+musiqa — 4, rasm+musiqa — 3, uchalasi — 2. Jami nechta bola?",o:["24","34","22","20"],k:0,s:"14 + 11 + 9 − 5 − 4 − 3 + 2 = 24."},
{t:"Matematika — 14, rasm — 11, musiqa — 9 bola. Mat+rasm — 5, mat+musiqa — 4, rasm+musiqa — 3, uchalasi — 2. Nechta bola FAQAT matematikaga qatnaydi?",o:["7","5","9","14"],k:0,s:"Mat+rasm faqat 3, mat+mus faqat 2: 14 − 3 − 2 − 2 = 7."},
{t:"1 dan 30 gacha sonlar. A — 3 ga, B — 5 ga bo'linadiganlar. Nechta son hech qaysi doiraga tushmaydi?",o:["16","14","18","12"],k:0,s:"10 + 6 − 2 = 14; 30 − 14 = 16."},
{t:"Sinfda 28 bola, 15 tasi qiz. Ko'zoynak taqadigan 8 bola bor, ulardan 3 tasi o'g'il. Ko'zoynak taqmaydigan qizlar nechta?",o:["10","7","5","13"],k:0,s:"Ko'zoynakli qizlar 5; 15 − 5 = 10."},
{t:"A to'plamda 12, B da 9 element, birlashmasida 17 element. Kesishmada nechta element?",o:["4","21","3","8"],k:0,s:"12 + 9 − 17 = 4."},
{t:"«Barcha kvadratlar — romb. Ba'zi to'rtburchaklar — kvadrat.» Qaysi xulosa albatta to'g'ri?",o:["Ba'zi to'rtburchaklar — romb","Barcha romblar — kvadrat","Hech bir romb to'rtburchak emas","Barcha to'rtburchaklar — kvadrat"],k:0,s:"Kvadrat to'rtburchaklar romb ham."},
{t:"50 o'quvchi: 30 tasi kitobni, 25 tasi sportni yaxshi ko'radi, 8 tasi hech birini. Nechtasi ikkalasini yaxshi ko'radi?",o:["13","5","8","55"],k:0,s:"Kamida bittasi 42; 30 + 25 − 42 = 13."},
{t:"Uchta to'garakning har birida 10 tadan bola. Har ikki to'garakda 3 tadan umumiy bola bor, 1 bola uchalasiga qatnaydi. Jami nechta bola?",o:["22","21","30","19"],k:0,s:"30 − 9 + 1 = 22."}
];
var PREP_DATA={teach:["Venn diagrammasining qismlari: faqat A, faqat B, kesishma, tashqari.","Birlashma formulasi: A + B − (A va B); hech biri.","Kesishmani topish (hamma kamida bittasida); kesishmaning eng kam va eng ko'p qiymati.","Uch to'plam: markazdan tashqariga.","Mulohazalar (barcha, ba'zi, hech bir) va «faqat» so'zi."],
 mist:["Kesishmadagi elementlarni ikki marta sanaydi.","Tashqi qismni (hech biri) unutadi.","«Faqat A» va «A» ni adashtiradi.","Uch doirada markazni hisobga olmay juftliklarni ayiradi.","«Barcha A — B» ni teskarisi bilan adashtiradi."],
 need:["2–3 ta hulahop yoki arqon halqa.","Son va ism yozilgan kartochkalar."],
 board:["<span class='w2'>A yoki B = A + B − (A va B)</span>.","Hech biri = jami − (A yoki B).","Kesishma ≥ A + B − jami.","Uch doira: <span class='w2'>markaz → juftliklar → «faqat» qismlar</span>."]};
