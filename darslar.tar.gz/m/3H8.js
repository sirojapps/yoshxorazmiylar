var CODE='3H8',TITLE='3-sinf · Parallelepiped va kub: qirralar, yoyilma, hajm';
// ---------- sahna: izometrik quti ----------
function h8msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// a — uzunlik (old), b — eni (chuqurlik), c — balandlik; hl: 'faces'|'edges'|'verts'|'a'|'b'|'c'|'all'
function h8box(a,b,c,o){o=o||{};clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0||(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.hl==='faces'?['#ffd9a8','#ffc477','#ffe7c4']:['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 // orqa (ko'rinmas) qirralar
 [[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++)E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0]+0,y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}
  for(var i2=1;i2<a;i2++)E('line',{x1:x0+i2*s,y1:y0-H,x2:x0+i2*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
 var EA=[[A,B],[D,Cc],[D2,C2],[A2,B2]],EB=[[B,B2],[Cc,C2],[D,D2],[A,A2]],EC=[[A,D],[B,Cc],[B2,C2],[A2,D2]];
 function edges(l,col){l.forEach(function(e,i){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:col,'stroke-width':4,'stroke-linecap':'round',opacity:.9},g)})}
 if(o.hl==='edges'||o.hl==='all'){edges(EA,C.bad);edges(EB,C.blue);edges(EC,C.ok)}
 if(o.hl==='a')edges(EA,C.bad);if(o.hl==='b')edges(EB,C.blue);if(o.hl==='c')edges(EC,C.ok);
 if(o.hl==='verts')[A,B,Cc,D,A2,B2,C2,D2].forEach(function(p,i){E('circle',{cx:p[0],cy:p[1],r:5,fill:C.bad,stroke:'#fff','stroke-width':1.5},g);T(g,p[0]+(i%2?9:-9),p[1]-6,String(i+1),{'font-size':10,'font-weight':800,fill:C.bad})});
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+16,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+14,(B[1]+B2[1])/2+10,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-16,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok})}
 S.dims=[a,b,c]}
// yoyilma: kub (xoch) yoki parallelepiped
function h8net(kind,o){o=o||{};clear();var g=S.g;
 if(kind==='cube'){var s=30,x0=120,y0=22,cells=o.cells||[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]],lab=o.lab||['1','2','3','4','5','6'],cols=o.cols||[];
  cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s-30,y:y0+p[1]*s+20,width:s,height:s,fill:cols[i]||'#fbe0b4',stroke:C.t1,'stroke-width':1.5},g);if(lab[i])T(g,x0+p[0]*s-15,y0+p[1]*s+40,lab[i],{'font-size':13,'font-weight':800,fill:'#5b3b1c'})});return}
 var a=o.a||6,b=o.b||4,c=o.c||3,s=o.s||9,x0=o.x0||40,y0=o.y0||24,cl=['#f6c98a','#bfe3f5','#c9ecd2'];
 // markaz: [b*c][a*c][b*c][a*c] gorizontal; ustida va ostida a*b
 var xs=[x0,x0+b*s,x0+(a+b)*s,x0+(a+2*b)*s],ws=[b,a,b,a];
 for(var i=0;i<4;i++){E('rect',{x:xs[i],y:y0+b*s,width:ws[i]*s,height:c*s,fill:i%2?cl[0]:cl[1],stroke:C.t1,'stroke-width':1.3},g);T(g,xs[i]+ws[i]*s/2,y0+b*s+c*s/2+4,ws[i]+'×'+c,{'font-size':10,'font-weight':800,fill:'#5b3b1c'})}
 [y0,y0+(b+c)*s].forEach(function(y){E('rect',{x:xs[1],y:y,width:a*s,height:b*s,fill:cl[2],stroke:C.t1,'stroke-width':1.3},g);T(g,xs[1]+a*s/2,y+b*s/2+4,a+'×'+b,{'font-size':10,'font-weight':800,fill:'#1d5a2f'})})}
// qatlamlab hajm
function h8layers(a,b,c,k){h8box(a,b,Math.max(k,0.0001),{cubes:true,lab:false,s:20});if(k<=0){clear();T(S.g,180,90,'Bo‘sh quti: '+a+' × '+b+' tub',{'font-size':14,'font-weight':800,fill:C.blue})}}
var P3=[function(){h8box(5,4,3,{hl:'a'});calc(['Uzunlik bo‘yicha qirralar — <b>4 ta</b>, har biri 5 sm: 4 · 5 = 20'])},
 function(){h8box(5,4,3,{hl:'b'});calc(['4 · 5 = 20','Eni bo‘yicha qirralar — <b>4 ta</b>, har biri 4 sm: 4 · 4 = 16'])},
 function(){h8box(5,4,3,{hl:'c'});calc(['4 · 5 = 20, 4 · 4 = 16','Balandlik bo‘yicha — <b>4 ta</b>, 3 sm dan: 4 · 3 = 12'])},
 function(){h8box(5,4,3,{hl:'all'});calc(['20 + 16 + 12 = <b>48 sm</b>','Yoki qisqacha: 4 · (5 + 4 + 3) = 4 · 12 = 48 sm'])}];
var P6=[function(){h8box(6,4,3,{s:16});calc(['Qutini qog‘oz bilan yopishtiramiz. Nechta yoq bor? <b>6 ta</b>'])},
 function(){h8net('box',{a:6,b:4,c:3});calc(['Qutini «ochib» tekislikka yoydik — bu <b>yoyilma</b>','Bir xil rangli yoqlar juft-juft teng'])},
 function(){h8net('box',{a:6,b:4,c:3});calc(['Ost va ust: 2 · (6 · 4) = 48','Old va orqa: 2 · (6 · 3) = 36','Yon tomonlar: 2 · (4 · 3) = 24','Jami: 48 + 36 + 24 = <b>108 sm²</b>'])}];
var P7=[function(){h8layers(4,3,2,0);calc(['Tubi 4 × 3 bo‘lgan qutiga 1 sm³ li kubiklar teramiz'])},
 function(){h8layers(4,3,2,1);calc(['1-qatlam: 4 · 3 = <b>12</b> ta kubik'])},
 function(){h8layers(4,3,2,2);calc(['1-qatlam: 12 ta','2-qatlam: yana 12 ta → 12 · 2 = <b>24 sm³</b>','Hajm = uzunlik · eni · balandlik = 4 · 3 · 2 = 24'])}];
var P8=[function(){h8box(5,4,6,{la:'5 sm',lb:'4 sm',lc:'x = ?',s:14});calc(['Hajm 120 sm³. Uzunlik 5 sm, eni 4 sm. Balandlik x = ?'])},
 function(){h8box(5,4,1,{cubes:true,lab:false,s:18});calc(['1 qatlam: 5 · 4 = <b>20</b> kubik','Nechta qatlam bo‘lsa 120 chiqadi?'])},
 function(){h8box(5,4,6,{cubes:true,s:14});calc(['120 : 20 = <b>6</b> qatlam','x = 6 sm. Tekshiramiz: 5 · 4 · 6 = 120 ✓'])}];
function h8dm(){var d=S.dims;h8msg('Kuboid: uzunlik <b>'+d[0]+' sm</b>, eni <b>'+d[1]+' sm</b>, balandlik <b>'+d[2]+' sm</b>. Yoqlari — <b>to‘g‘ri to‘rtburchak</b>')}
var STEPS=[
{h:"Kubning yoqlari, qirralari va uchlari",sum:"Kubda 6 ta yoq, 12 ta qirra, 8 ta uch. Hamma qirralar teng.",a:"m01",
 start:function(){h8box(3,3,3,{lab:false,s:26});h8msg('Tugmalarni bosib, kubning qismlarini ko‘ring')},fin:function(){h8box(3,3,3,{hl:'edges',lab:false,s:26});h8msg('6 yoq · 12 qirra · 8 uch')},
 html:"<p>Kub — o'yin soqqasi, muz bo'lagi, Rubik kubigi. Uning uch xil qismi bor. Uchala tugmani bosib, har birini sanang:</p>",
 btns:[["🟧 Yoqlar",function(c,done){h8box(3,3,3,{hl:'faces',lab:false,s:26});h8msg('<b>Yoq</b> — tekis kvadrat. Ko‘ringan 3 ta + orqada 3 ta = <b>6 ta</b>');mvK(done,3)}],["📏 Qirralar",function(c,done){h8box(3,3,3,{hl:'edges',lab:false,s:26});h8msg('<b>Qirra</b> — ikki yoq tutashgan chiziq. 4 ta qizil + 4 ta ko‘k + 4 ta yashil = <b>12 ta</b>');mvK(done,3)}],["🔴 Uchlar",function(c,done){h8box(3,3,3,{hl:'verts',lab:false,s:26});h8msg('<b>Uch</b> — qirralar uchrashgan nuqta: tepada 4 ta, pastda 4 ta = <b>8 ta</b>');mvK(done,3)}]],g3:1,
 after:"<p>Kubda: <b>6 ta yoq</b> (hammasi teng kvadrat), <b>12 ta qirra</b> (hammasi teng), <b>8 ta uch</b>. Punktir chiziqlar — orqadagi ko'rinmaydigan qirralar: ularni ham sanashni unutmang!</p>",
 q:{t:"Kubning qirralari soni uchlari sonidan nechta ko'p?",opts:["8","2","4","6"],ok:2,why:"12 − 8 = 4.",hint:"Qirralar nechta, uchlar nechta? Ikkalasini toping.",full:"Kubda 12 ta qirra va 8 ta uch. 12 − 8 = 4. «6» — bu yoqlar soni, «8» — uchlar soni."},
 tn:"Bolalarga gugurt cho'pi va plastilindan kub karkasini yasating: 12 ta cho'p (qirra) va 8 ta plastilin sharcha (uch) kerak bo'ladi."},
{h:"To'g'ri burchakli parallelepiped",sum:"Parallelepiped (kuboid) — 6 ta to'g'ri to'rtburchak yoq; 3 ta o'lcham: uzunlik, eni, balandlik.",a:"m02",
 start:function(){h8box(5,3,2);h8dm()},fin:function(){h8box(5,3,2);h8dm()},
 html:"<p>G'isht, quti, shkaf — bular <b>to'g'ri burchakli parallelepiped</b> (qisqasi <b>kuboid</b>). Uning 3 ta o'lchami bor. Tugmalar bilan o'zgartirib ko'ring:</p>",
 btns:[["+ uzunlik",function(c,done){var d=S.dims;if(d[0]<7)h8box(d[0]+1,d[1],d[2]);h8dm();mvK(done,3)}],["+ eni",function(c,done){var d=S.dims;if(d[1]<5)h8box(d[0],d[1]+1,d[2]);h8dm();mvK(done,3)},'u'],["+ balandlik",function(c,done){var d=S.dims;if(d[2]<5)h8box(d[0],d[1],d[2]+1);h8dm();mvK(done,3)}]],g3:1,
 after:"<p>Kuboidda ham <b>6 ta yoq, 12 ta qirra, 8 ta uch</b> bor — xuddi kubdagidek. Farqi: yoqlari kvadrat emas, <b>to'g'ri to'rtburchak</b>, qarama-qarshi yoqlar esa teng. Uch o'lcham teng bo'lsa — kub hosil bo'ladi.</p>",
 q:{t:"Qaysi gap to'g'ri?",opts:["Kub — bu kuboidning bir turi","Kuboidda 8 ta qirra bor","Kubning yoqlari to'g'ri to'rtburchak emas","Kuboidda 4 ta yoq bor"],ok:0,why:"Uchala o'lchami teng kuboid — kub.",hint:"Kuboidning o'lchamlari teng bo'lsa nima hosil bo'ladi?",full:"Kub — uzunligi, eni va balandligi teng kuboid. Kuboidda 12 ta qirra va 6 ta yoq bor. Kvadrat ham to'g'ri to'rtburchak, shuning uchun 3-gap ham xato."},
 tn:"Sinfga gugurt qutisi, sut qutisi, kitob olib keling. Bolalar har birining uzunligi, eni va balandligini chizg'ich bilan o'lchasin."},
{h:"Barcha qirralar uzunliklari yig'indisi",sum:"Kuboidda har o'lchamdan 4 tadan qirra: 4 · (5 + 4 + 3) = 48 sm.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Usta simdan quti karkasi yasaydi: uzunligi 5 sm, eni 4 sm, balandligi 3 sm. Qancha sim kerak? Qirralarni guruhlab sanaymiz.</p>",
 btns:[phaser(P3)],
 after:"<p>Har bir o'lcham bo'yicha <b>4 tadan</b> qirra bor. Shuning uchun: <b>qirralar yig'indisi = 4 · (uzunlik + eni + balandlik)</b>. Kubda hammasi teng: 12 · qirra.</p>",
 q:{t:"Simdan karkas: uzunligi 6 sm, eni 3 sm, balandligi 2 sm. Necha sm sim kerak?",opts:["11 sm","22 sm","44 sm","36 sm"],ok:2,why:"4 · (6 + 3 + 2) = 4 · 11 = 44 sm.",hint:"Har o'lchamdan nechta qirra bor? 4 tadan.",full:"Uchala o'lchamni qo'shamiz: 6 + 3 + 2 = 11. Har biridan 4 tadan qirra: 4 · 11 = 44 sm. «11» — faqat bittadan olingan, «22» — 2 tadan olingan."},
 tn:"Eng ko'p xato: 5 + 4 + 3 = 12 bilan to'xtab qolish. Karkasni cho'pdan yasab, cho'plarni rang bo'yicha guruhlang."},
{h:"Kub va uning qirralari",sum:"Kubning 12 ta teng qirrasi: yig'indi = 12 · qirra. 60 sm bo'lsa, qirra = 5 sm.",a:"m04",
 start:function(){h8box(4,4,4,{s:22});h8msg('Qirrasi 4 sm bo‘lgan kub')},fin:function(){h8box(5,5,5,{hl:'edges',s:18});h8msg('12 · 5 = 60 sm')},
 html:"<p>Kubning hamma qirralari teng. Qirra uzunligini tanlang va yig'indini ko'ring:</p>",
 btns:[["3 sm",function(c,done){h8box(3,3,3,{hl:'edges',s:26});h8msg('12 · 3 = <b>36 sm</b>');mvK(done,2)}],["4 sm",function(c,done){h8box(4,4,4,{hl:'edges',s:22});h8msg('12 · 4 = <b>48 sm</b>');mvK(done,2)}],["5 sm",function(c,done){h8box(5,5,5,{hl:'edges',s:18});h8msg('12 · 5 = <b>60 sm</b>');mvK(done,2)}]],g3:1,
 after:"<p>Kub uchun: <b>qirralar yig'indisi = 12 · qirra</b>. Teskari ham bo'ladi: yig'indi 60 sm bo'lsa, qirra = 60 : 12 = 5 sm.</p>",
 q:{t:"Kubning barcha qirralari yig'indisi 84 sm. Bitta qirrasi necha sm?",opts:["7 sm","14 sm","21 sm","12 sm"],ok:0,why:"84 : 12 = 7 sm.",hint:"Kubda nechta teng qirra bor?",full:"Kubda 12 ta teng qirra. 84 : 12 = 7 sm. «21» — 84 ni 4 ga bo'lish xatosi (kvadrat perimetri kabi), «14» — 6 ga bo'lish (yoqlar soni)."},
 tn:"Kvadrat perimetri (4 · a) bilan kub qirralari yig'indisini (12 · a) solishtiring — bolalar ko'pincha aralashtirib yuboradi."},
{h:"Kubning yoyilmasi",sum:"Kubni «ochsak» 6 ta kvadrat — yoyilma hosil bo'ladi. Soqqada qarama-qarshi yoqlar yig'indisi 7.",a:"m05",
 start:function(){h8net('cube');h8msg('Kub «ochildi»: 6 ta kvadrat. Qaysilari bir-biriga qarama-qarshi?')},fin:function(){h8net('cube',{lab:['2','3','1','4','6','5'],cols:['#ffd9a8','#bfe3f5','#c9ecd2','#bfe3f5','#c9ecd2','#ffd9a8']});h8msg('Bir xil rang — qarama-qarshi yoqlar')},
 html:"<p>Kubni qaychi bilan kesib, tekislikka yoysak, <b>yoyilma</b> hosil bo'ladi — 6 ta kvadrat. Yig'ganda qaysi yoqlar bir-biriga qarama-qarshi bo'ladi? Tugmani bosing.</p>",
 btns:[["🎲 Soqqa qilib raqamlash",function(c,done,b){b.disabled=true;h8net('cube',{lab:['2','3','1','4','6','5'],cols:['#ffd9a8','#bfe3f5','#c9ecd2','#bfe3f5','#c9ecd2','#ffd9a8']});h8msg('Qarama-qarshi: 1 va 6, 2 va 5, 3 va 4 — har juftda yig‘indi <b>7</b>');done()}]],
 after:"<p>Yoyilmada <b>bitta oraliq</b> bilan turgan kvadratlar yig'ilganda <b>qarama-qarshi</b> bo'ladi (orasida bitta kvadrat). O'yin soqqasida qarama-qarshi yoqlar yig'indisi doim <b>7</b>: 1 + 6, 2 + 5, 3 + 4.</p>",
 q:{t:"Kubning yoyilmasi nechta kvadratdan iborat?",opts:["4","8","12","6"],ok:3,why:"Kubning 6 ta yog'i — 6 ta kvadrat.",hint:"Kubda nechta yoq bor?",full:"Yoyilma — kubning hamma yoqlari tekislikka yoyilgani. Kubda 6 ta yoq, demak 6 ta kvadrat. 12 — qirralar, 8 — uchlar soni."},
 tn:"Qog'ozdan xoch shaklidagi yoyilmani kesib, bolalar o'zi buklasin. Keyin «noto'g'ri» yoyilmani (6 kvadrat qator) berib, nega yig'ilmasligini sinab ko'rsin."},
{h:"Parallelepipedning yoyilmasi va sirti",sum:"Kuboid yoyilmasi — 3 juft teng to'rtburchak. 6×4×3: 2·24 + 2·18 + 2·12 = 108 sm².",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Masala: <i>«O'lchamlari 6 sm, 4 sm va 3 sm bo'lgan qutining hamma yoqlarini qog'oz bilan yopishtirish kerak. Qancha qog'oz kerak?»</i> Qutini yoyib ko'ramiz.</p>",
 btns:[phaser(P6)],
 after:"<p>Kuboid yoyilmasida <b>3 juft</b> teng to'rtburchak bor: ost-ust, old-orqa, ikki yon. Har juftning yuzini topib, 2 ga ko'paytiramiz va qo'shamiz. Bu — qutining <b>sirti</b> (to'liq yuzi).</p>",
 q:{t:"Kubning qirrasi 3 sm. Uning hamma yoqlarini yopishtirish uchun necha sm² qog'oz kerak?",opts:["9 sm²","27 sm²","54 sm²","36 sm²"],ok:2,why:"Bitta yoq 3 · 3 = 9, 6 ta yoq: 9 · 6 = 54 sm².",hint:"Bitta yoqning yuzi qancha? Kubda nechta yoq bor?",full:"Bitta yoq — kvadrat, yuzi 3 · 3 = 9 sm². Kubda 6 ta yoq: 9 · 6 = 54 sm². «27» — bu hajm (3 · 3 · 3), «9» — faqat bitta yoq."},
 tn:"Haqiqiy qutini (choy qutisi) yoyib, har yoqning o'lchamini yozdiring. Bu 4-sinfdagi sirt va hajm farqiga tayyorgarlik."},
{h:"Hajm: kubiklar bilan qatlamlab",sum:"Hajm = uzunlik · eni · balandlik. 4 × 3 × 2: bir qatlam 12, ikki qatlam 24 sm³.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p><b>Hajm</b> — jism qancha joy egallashi. Uni 1 sm³ li kubiklar bilan o'lchaymiz (qirrasi 1 sm bo'lgan kubik). Qutini qatlam-qatlam to'ldiring:</p>",
 btns:[phaser(P7,'▶ Qatlam qo‘yish')],
 after:"<p>Bitta qatlamda: uzunlik · eni = 4 · 3 = 12 kubik. Qatlamlar soni — balandlik: 2. <b>Hajm = 4 · 3 · 2 = 24 sm³</b>. Kub uchun: qirra · qirra · qirra.</p>",
 q:{t:"Qutining uzunligi 5 sm, eni 4 sm, balandligi 3 sm. Uning hajmi qancha?",opts:["12 sm³","48 sm³","60 sm³","20 sm³"],ok:2,why:"5 · 4 · 3 = 60 sm³.",hint:"Avval bitta qatlamdagi kubiklarni toping, keyin qatlamlar soniga ko'paytiring.",full:"Bir qatlam: 5 · 4 = 20 kubik. 3 ta qatlam: 20 · 3 = 60 sm³. «48» — bu qirralar yig'indisi, «12» — o'lchamlar yig'indisi, «20» — bitta qatlam."},
 tn:"Kubiklar (Lego, shakar bo'laklari) bilan qutini to'ldiring. «Hajm — kubiklar soni» degan fikr formula yod olishdan oldin kelishi kerak."},
{h:"Tuzoq: hajmdan o'lchamni topish",sum:"V = 120 sm³, 5 × 4 tub: bir qatlam 20, 120 : 20 = 6 qatlam → balandlik 6 sm.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Teskari masala: <i>«Kuboidning hajmi 120 sm³, uzunligi 5 sm, eni 4 sm. Balandligi qancha?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Usul: avval <b>bitta qatlam</b> (tub)dagi kubiklarni toping: 5 · 4 = 20. Keyin hajmni shunga bo'ling: 120 : 20 = 6. Bu — qatlamlar soni, ya'ni balandlik.</p>",
 q:{t:"Basseyn uzunligi 12 m, eni 5 m, chuqurligi 2 m. Quvurdan har 3 minutda 2 m³ suv tushadi. Bo'sh basseyn qancha vaqtda to'ladi?",opts:["1 soat","2 soat","6 soat","3 soat"],ok:3,why:"Hajm 12 · 5 · 2 = 120 m³; 120 : 2 = 60 marta; 60 · 3 = 180 min = 3 soat.",hint:"Avval basseyn hajmini toping. Keyin 2 m³ dan necha marta tushishi kerak?",full:"Hajm: 12 · 5 · 2 = 120 m³. Har 3 minutda 2 m³: 120 : 2 = 60 marta. Vaqt: 60 · 3 = 180 minut = 3 soat. «1 soat» — 60 ni minut emas, soat deb olgan xato."},
 tn:"Bankdagi qiyin masala (1862). Bolalar uch bosqichni alohida yozsin: hajm → necha marta → vaqt."},
{h:"Bilasizmi? Soqqa va Rubik kubigi",sum:"Soqqada qarama-qarshi yoqlar yig'indisi 7. Rubik kubigi 1974-yilda ixtiro qilingan.",a:"m09",
 start:function(){h8box(3,3,3,{cubes:true,lab:false,s:26});h8msg('3 × 3 × 3 = 27 ta kichik kub')},fin:function(){h8box(3,3,3,{cubes:true,lab:false,s:26});h8msg('3 × 3 × 3 = 27 ta kichik kub')},
 html:"<p>🎲 O'yin soqqasi ming yillardan beri kub shaklida yasaladi, va qarama-qarshi yoqlaridagi nuqtalar yig'indisi doim <b>7</b> bo'ladi.</p><p>🧩 Vengriyalik me'mor <b>Erno Rubik</b> 1974-yilda mashhur kubigini ixtiro qildi. U 3 × 3 × 3 qilib yasalgan: tashqaridan qaraganda <b>27</b> ta kichik kubdan iborat (aslida o'rtadagisi yo'q, uning o'rnida aylanish mexanizmi turadi).</p>",
 tn:"Rubik kubigi bo'lsa, sinfga olib keling: bolalar kichik kubchalarni qatlamlab sanasin (9 + 9 + 9)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h8box(5,4,3,{hl:'all',s:18});h8msg('a = 5, b = 4, c = 3')},fin:function(){h8box(5,4,3,{hl:'all',s:18});h8msg('a = 5, b = 4, c = 3')},
 html:"<div class='memo'><ul><li>Kub va kuboidda: <b>6 yoq, 12 qirra, 8 uch</b>.</li><li>Kubning hamma qirralari teng, yoqlari — teng kvadratlar.</li><li>Kuboidning qarama-qarshi yoqlari teng to'g'ri to'rtburchaklar.</li><li>Qirralar yig'indisi: kuboid — <b>4 · (a + b + c)</b>, kub — <b>12 · a</b>.</li><li>Yoyilma: kub — 6 ta kvadrat; kuboid — 3 juft teng to'rtburchak.</li><li>Sirt: 2 · (a·b + a·c + b·c); kub — 6 · a · a.</li><li>Hajm: <b>V = a · b · c</b>; kub — a · a · a. Birligi: sm³, dm³, m³.</li><li>Hajm va tub ma'lum bo'lsa: balandlik = V : (a · b).</li></ul></div>",
 tn:"Keyingi darsni «Qirrasi 2 sm kubning hajmi va sirti teng bo'lishi mumkinmi?» degan savol bilan boshlang (8 sm³ va 24 sm² — birliklari har xil, solishtirib bo'lmaydi)."}
];
var PROBS=[
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","4"],k:0,s:"Kubda 12 ta qirra: tepada 4, pastda 4, yonda 4."},
{t:"Kuboidning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"Tepada 4 ta, pastda 4 ta — 8 ta uch."},
{t:"Kubning qirralari soni uchlari sonidan nechta ko'p?",o:["4","2","6","8"],k:0,s:"12 − 8 = 4."},
{t:"Kubning qirrasi 6 sm. Barcha qirralari uzunliklari yig'indisi?",o:["72 sm","24 sm","36 sm","216 sm"],k:0,s:"12 · 6 = 72 sm."},
{t:"Kuboid o'lchamlari 5 sm, 4 sm, 3 sm. Barcha qirralari yig'indisi?",o:["48 sm","12 sm","60 sm","36 sm"],k:0,s:"4 · (5 + 4 + 3) = 4 · 12 = 48 sm."},
{t:"Kubning barcha qirralari yig'indisi 96 sm. Qirrasi necha sm?",o:["8 sm","24 sm","16 sm","12 sm"],k:0,s:"96 : 12 = 8 sm."},
{t:"Qirrasi 3 sm bo'lgan kubning hajmi?",o:["27 sm³","9 sm³","36 sm³","54 sm³"],k:0,s:"3 · 3 · 3 = 27 sm³."},
{t:"Kuboid: uzunligi 6 sm, eni 5 sm, balandligi 2 sm. Hajmi?",o:["60 sm³","13 sm³","30 sm³","52 sm³"],k:0,s:"6 · 5 · 2 = 60 sm³."},
{t:"Kuboid hajmi 120 sm³, uzunligi 5 sm, eni 4 sm. Balandligi?",o:["6 sm","30 sm","24 sm","12 sm"],k:0,s:"Bir qatlam 5 · 4 = 20; 120 : 20 = 6 sm."},
{t:"Darvoza 1 sm³ li kubchalardan: ikki ustun 4 tadan va ustida 2 ta. Hajmi?",o:["10 sm³","8 sm³","12 sm³","6 sm³"],k:0,s:"4 + 4 + 2 = 10 ta kubcha — 10 sm³."},
{t:"Qirrasi 2 sm kubning hamma yoqlari yuzi (sirti)?",o:["24 sm²","8 sm²","16 sm²","12 sm²"],k:0,s:"Bitta yoq 2 · 2 = 4, 6 ta yoq: 4 · 6 = 24 sm²."},
{t:"O'lchamlari 6 sm, 4 sm, 3 sm qutining hamma yoqlari yuzi?",o:["108 sm²","72 sm²","54 sm²","52 sm²"],k:0,s:"2·(6·4) + 2·(6·3) + 2·(4·3) = 48 + 36 + 24 = 108 sm²."},
{t:"O'yin soqqasining bir yog'ida 2 ta nuqta. Qarama-qarshi yog'ida nechta?",o:["5","4","6","3"],k:0,s:"Qarama-qarshi yoqlar yig'indisi 7: 7 − 2 = 5."},
{t:"Qirrasi 1 sm kubchalardan qirrasi 3 sm bo'lgan kub yasaldi. Nechta kubcha ishlatildi?",o:["27","9","18","12"],k:0,s:"3 · 3 · 3 = 27 ta."},
{t:"Qirrasi 4 sm kub qirrasi 2 sm kubdan necha marta ko'p hajmga ega?",o:["8 marta","2 marta","4 marta","16 marta"],k:0,s:"64 : 8 = 8 marta (4·4·4 = 64, 2·2·2 = 8)."},
{t:"Basseyn 10 m × 4 m × 2 m. Unga necha m³ suv sig'adi?",o:["80 m³","16 m³","40 m³","28 m³"],k:0,s:"10 · 4 · 2 = 80 m³."},
{t:"Karkas uchun 36 sm sim bor. Undan qanday qirrali kub karkasini yasash mumkin?",o:["3 sm","9 sm","6 sm","4 sm"],k:0,s:"36 : 12 = 3 sm."},
{t:"Kuboid o'lchamlari 4 sm, 3 sm, 2 sm. Undan 1 sm³ li nechta kubcha chiqadi?",o:["24","9","26","12"],k:0,s:"4 · 3 · 2 = 24 ta."},
{t:"Kuboidning tub yuzi 15 sm², balandligi 4 sm. Hajmi?",o:["60 sm³","19 sm³","45 sm³","30 sm³"],k:0,s:"Bir qatlam 15 kubik, 4 qatlam: 15 · 4 = 60 sm³."},
{t:"Qirrasi 3 sm kub qizilga bo'yalib, 1 sm li 27 kubchaga kesildi. Nechta kubchaning hech bir yog'i bo'yalmagan?",o:["1","0","8","6"],k:0,s:"Faqat o'rtadagi bitta kubcha tashqariga chiqmaydi — 1 ta."}
];
function PRACT_STAGE(){h8box(5,4,3,{hl:'all',s:18});h8msg('Kerak bo‘lsa, chizmaga qarang')}
var PREP_DATA={teach:["Kub va kuboidning yoq, qirra, uchlari (6, 12, 8).","Qirralar yig'indisi: 4·(a+b+c) va 12·a.","Kub va kuboid yoyilmasi; sirt (hamma yoqlar yuzi).","Hajm: kubiklar bilan qatlamlab, V = a·b·c; teskari masala."],
 mist:["Orqadagi ko'rinmaydigan qirra va uchlarni sanamaydi (12 o'rniga 9).","Qirralar yig'indisida faqat a + b + c ni oladi.","Hajm va sirtni aralashtiradi (27 sm³ va 54 sm²).","Hajmni o'lchamlar yig'indisi deb hisoblaydi."],
 need:["Gugurt qutisi, choy qutisi, kubiklar (Lego, shakar).","Qog'oz yoyilma andozalari, qaychi, yelim.","Karkas uchun cho'p va plastilin."],
 board:["Kub chizmasi: <span class='w2'>6 yoq, 12 qirra, 8 uch</span>.","<span class='w2'>4 · (5 + 4 + 3) = 48 sm</span>.","Kub: <span class='w2'>12 · a</span>.","Xoch yoyilma, qarama-qarshi yoqlar.","Sirt: <span class='w2'>2·24 + 2·18 + 2·12 = 108 sm²</span>.","Hajm: <span class='w2'>4 · 3 · 2 = 24 sm³</span>.","Teskari: <span class='w2'>120 : (5 · 4) = 6</span>."]};
