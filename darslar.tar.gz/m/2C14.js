// --- k2c14_ yordamchilari ---
function k2c14_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c14_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c14_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c14_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C14',TITLE='2-sinf · Yaxlit sonlarni ko‘paytirish va bo‘lish';
// guruhlar: har guruhda t ta o'nlik tayoqcha
function k2c14_rods(groups,t,o){o=o||{};clear();var g=S.g,gw=Math.min(Math.max(t*14+22,70),340/Math.max(groups,1)),x0=180-gw*groups/2;
 for(var i=0;i<groups;i++){var x=x0+i*gw;E('rect',{x:x+3,y:12,width:gw-6,height:118,rx:10,fill:'#fff7ea',stroke:'#e6d0a8'},g);
  for(var j=0;j<t;j++)rod(g,x+14+j*14,22,96,o.col);if(o.lab)T(g,x+gw/2,145,o.lab(i),{'font-size':11,'font-weight':800,fill:C.blue})}
 if(o.cap)T(g,180,166,o.cap,{'font-size':13,'font-weight':800,fill:C.ok})}
var P1=[function(){k2c14_rods(1,2,{lab:function(){return '20'}});k2c14_big('20 · 3 = ?','20 — bu 2 ta o‘nlik')},
 function(){k2c14_rods(3,2,{lab:function(){return '2 o‘nlik'}});k2c14_big('2 o‘nlik · 3 = <b>6 o‘nlik</b>','Uchta guruh — har birida 2 tadan o‘nlik')},
 function(){k2c14_rods(3,2,{lab:function(){return '20'},cap:'6 o‘nlik = 60'});k2c14_big('20 · 3 = 2 · 3 o‘nlik = <b>60</b>','Qisqasi: 2 · 3 = 6, oxiriga 0')}];
var P3=[function(){k2c14_rods(1,8,{});k2c14_big('80 : 4 = ?','80 — bu 8 ta o‘nlik')},
 function(){k2c14_rods(4,2,{lab:function(){return '2 o‘nlik'}});k2c14_big('8 o‘nlik : 4 = <b>2 o‘nlik</b>','8 ta o‘nlikni 4 guruhga teng bo‘ldik')},
 function(){k2c14_rods(4,2,{lab:function(){return '20'},cap:'80 : 4 = 20'});k2c14_big('80 : 4 = 8 : 4 o‘nlik = <b>20</b>')}];
var P5=[function(){k2c14_rods(1,6,{});k2c14_big('60 : 3 = ?','Ko‘pchilik «2» deydi. Tekshiramiz!')},
 function(){k2c14_rods(3,2,{lab:function(){return '2 o‘nlik = 20'}});k2c14_big('6 o‘nlik : 3 = 2 <b>o‘nlik</b> = <b>20</b>','Har guruhga 2 ta TAYOQCHA — ya’ni 20 ta')},
 function(){k2c14_rods(3,2,{lab:function(){return '20'},cap:'Tekshiruv: 20 · 3 = 60 ✓'});k2c14_big('60 : 3 = <b>20</b>, 2 emas! (2 · 3 = 6, 60 emas)')}];
var P6=[function(){k2c14_rods(1,8,{});k2c14_big('80 : 40 = ?','Endi bo‘luvchi ham yaxlit son')},
 function(){k2c14_rods(2,4,{lab:function(){return '40'}});k2c14_big('80 da nechta 40 bor? → <b>2</b> ta','8 o‘nlik : 4 o‘nlik = 2')},
 function(){k2c14_rods(2,4,{lab:function(){return '40'},cap:'80 : 40 = 2 (20 emas!)'});k2c14_big('80 : 40 = <b>2</b> &nbsp; Tekshiruv: 40 · 2 = 80 ✓')}];
var STEPS=[
{h:"20 · 3: o'nliklarni ko'paytiramiz",sum:"20 · 3 = 2 o'nlik · 3 = 6 o'nlik = 60.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p><b>Yaxlit son</b> — 0 bilan tugaydigan son: 20, 50, 300. 20 · 3 ni hisoblashning sirini o'nlik tayoqchalarda ko'ramiz.</p>",btns:[phaser(P1)],
 after:"<p>20 — bu <b>2 ta o'nlik</b>. 2 o'nlik · 3 = 6 o'nlik = <b>60</b>. Usul: <b>0 siz ko'paytiramiz, keyin 0 ni qaytaramiz</b>: 2 · 3 = 6 → 60.</p>",
 q:{t:"40 · 2 nechaga teng?",opts:["80","8","42","800"],ok:0,why:"4 o'nlik · 2 = 8 o'nlik = 80.",hint:"40 — nechta o'nlik?",full:"40 = 4 o'nlik. 4 · 2 = 8 o'nlik = 80. «8» — 0 qaytarilmagan, «800» — ortiqcha 0."},
 tn:"Bolalar «4 o'nlik · 2» deb gapirib hisoblasin — bu birlik nomini saqlab qolish usuli (Yaponiya darsliklarida «10 ning nechtasi» deyiladi)."},
{h:"Mashq: tez ko'paytiramiz",sum:"30 · 3 = 90, 3 · 30 = 90, 50 · 2 = 100, 200 · 4 = 800.",a:"m02",
 start:function(){k2c14_rods(3,3,{lab:function(){return '30'}});k2c14_big('Misolni tanlang')},fin:function(){k2c14_big('200 · 4 = 2 yuzlik · 4 = <b>800</b>')},
 html:"<p>Misolni tanlang — rasm va javob chiqadi:</p>",
 btns:[["30 · 3",function(c,d){k2c14_rods(3,3,{lab:function(){return '30'}});k2c14_big('3 o‘nlik · 3 = 9 o‘nlik = <b>90</b>');mvK(d,3)}],["3 · 30",function(c,d){k2c14_rods(3,3,{lab:function(){return '30'}});k2c14_big('3 · 30 = 30 · 3 = <b>90</b> (o‘rin almashtirish)');mvK(d,3)}],["50 · 2",function(c,d){k2c14_rods(2,5,{lab:function(){return '50'}});k2c14_big('5 o‘nlik · 2 = 10 o‘nlik = <b>100</b>');mvK(d,3)}],["200 · 4",function(c,d){clear();for(var i=0;i<4;i++){T(S.g,60+i*80,70,'200',{'font-size':22,'font-weight':800,fill:C.t1})}T(S.g,180,130,'2 yuzlik · 4 = 8 yuzlik',{'font-size':14,'font-weight':800,fill:C.ok});k2c14_big('2 yuzlik · 4 = 8 yuzlik = <b>800</b>');mvK(d,3)}]],g2:1,
 after:"<p>50 · 2 = 10 o'nlik = <b>100</b> — e'tibor bering, bu yerda 0 lar ikkita bo'ldi! Chunki 5 · 2 = 10 ning o'zida ham 0 bor. Yuzliklar ham xuddi shunday: 200 · 4 = 2 · 4 yuzlik = 800.</p>",
 q:{t:"60 · 5 nechaga teng?",opts:["300","30","3000","65"],ok:0,why:"6 · 5 = 30 o'nlik = 300.",hint:"Avval 6 · 5 ni toping, keyin 0 ni qaytaring.",full:"6 · 5 = 30, bu 30 ta o'nlik = 300. «30» — 0 qaytarilmagan. Natijada ikkita 0: bittasi 30 dan, bittasi 60 dan."},
 tn:"«50 · 2 = 100» kabi misollar nollar sonini sanashda xatoga olib keladi — alohida to'xtaling."},
{h:"80 : 4: o'nliklarni bo'lamiz",sum:"80 : 4 = 8 o'nlik : 4 = 2 o'nlik = 20.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Endi bo'lish: <b>80 : 4</b>. 80 — bu 8 ta o'nlik. Ularni 4 guruhga teng bo'lamiz.</p>",btns:[phaser(P3)],
 after:"<p>8 o'nlik : 4 = 2 o'nlik = <b>20</b>. Usul: <b>0 siz bo'lamiz, 0 ni qaytaramiz</b>: 8 : 4 = 2 → 20.</p>",
 q:{t:"90 : 3 nechaga teng?",opts:["3","30","300","27"],ok:1,why:"9 o'nlik : 3 = 3 o'nlik = 30.",hint:"90 — nechta o'nlik? Ularni 3 ga bo'ling.",full:"90 = 9 o'nlik. 9 : 3 = 3 o'nlik = 30. «3» — 0 qaytarilmagan."},
 tn:"10 talik bog'lamlarni bolalar teng guruhlarga taqsimlasin."},
{h:"Yuzliklarni bo'lamiz",sum:"600 : 3 = 6 yuzlik : 3 = 2 yuzlik = 200.",a:"m04",
 start:function(){clear();T(S.g,180,90,'600 : 3',{'font-size':32,'font-weight':800});k2c14_big('600 : 3 = ?','600 — 6 ta yuzlik')},fin:function(){clear();for(var i=0;i<3;i++)T(S.g,70+i*110,80,'200',{'font-size':26,'font-weight':800,fill:C.t1});k2c14_big('6 yuzlik : 3 = 2 yuzlik = <b>200</b>')},
 html:"<p>Yuzliklar ham xuddi o'nliklardek bo'linadi. Tugmani bosing:</p>",
 btns:[["▶ 600 ni 3 ga bo'l",function(c,d,b){b.disabled=true;STEPS[3].fin();d()}]],
 after:"<p>6 yuzlik : 3 = 2 yuzlik = <b>200</b>. 800 : 4 = 200, 900 : 3 = 300.</p>",
 q:{t:"800 : 2 nechaga teng?",opts:["400","40","4","4000"],ok:0,why:"8 yuzlik : 2 = 4 yuzlik = 400.",hint:"800 — nechta yuzlik?",full:"800 = 8 yuzlik. 8 : 2 = 4 yuzlik = 400. Nollar soni o'zgarmaydi: 800 da ikkita, 400 da ham ikkita."},
 tn:"Bolalar «nechta yuzlik?» deb so'rab hisoblasin."},
{h:"Tuzoq: 60 : 3 = 2 emas!",sum:"60 : 3 = 20. 2 · 3 = 6, 60 emas — tekshiruv xatoni ko'rsatadi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Ko'p bolalar 60 : 3 = 2 deb yozadi. Nima uchun xato? Kuzating.</p>",btns:[phaser(P5)],
 after:"<p>6 o'nlik : 3 = 2 <b>o'nlik</b>. «O'nlik» so'zini tushirib qoldirsak — xato. Doim <b>tekshiring</b>: 20 · 3 = 60 ✓, 2 · 3 = 6 ✗.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["80 : 2 = 4","80 : 2 = 40","80 : 2 = 400","80 : 2 = 82"],ok:1,why:"8 o'nlik : 2 = 4 o'nlik = 40.",hint:"Tekshiring: javobni 2 ga ko'paytirsangiz 80 chiqadimi?",full:"80 : 2 = 40, chunki 40 · 2 = 80 ✓. 4 · 2 = 8 ✗, 400 · 2 = 800 ✗."},
 tn:"«Birlik nomini ayt» qoidasi: «6 o'nlik bo'lingan 3 — 2 o'nlik»."},
{h:"Tuzoq: 80 : 40",sum:"80 : 40 = 2 (80 da ikkita 40 bor). O'nlikni o'nlikka bo'lsak — oddiy son chiqadi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Endi bo'luvchi ham yaxlit: <b>80 : 40</b>. Bu safar savol: «80 da <b>nechta 40</b> bor?»</p>",btns:[phaser(P6)],
 after:"<p>8 o'nlik : 4 o'nlik = <b>2</b> — natija «o'nlik» emas, shunchaki 2. Chunki «nechta 40 sig'adi?» deb so'rayapmiz. Xato yo'l: 80 : 40 = 20.</p>",
 q:{t:"90 : 30 nechaga teng?",opts:["30","3","300","60"],ok:1,why:"90 da uchta 30 bor.",hint:"30 ni nechaga ko'paytirsak 90 chiqadi?",full:"30 · 3 = 90, demak 90 : 30 = 3. «30» — 90 : 3 bilan aralashtirilgan."},
 tn:"Ikki xil bo'lishni solishtiring: 80 : 4 (teng bo'lish, javob — o'nlik) va 80 : 40 (sig'dirish, javob — son)."},
{h:"Masala: yaxlit sonlar hayotda",sum:"4 ta qutida 20 tadan — 80 ta; 80 tani 40 tadan — 2 ta quti.",a:"m07",
 start:function(){k2c14_rods(4,2,{lab:function(){return '20 ta'}});k2c14_big('4 ta quti, har birida 20 ta qalam')},fin:function(){k2c14_rods(4,2,{lab:function(){return '20 ta'},cap:'20 · 4 = 80 ta'});k2c14_big('20 · 4 = <b>80</b> ta qalam')},
 html:"<p>Do'konga 4 ta quti qalam keldi, har birida 20 tadan. Nechta qalam? Hisoblang:</p>",
 btns:[["▶ Hisobla",function(c,d,b){b.disabled=true;STEPS[6].fin();d()}]],
 after:"<p>20 · 4 = <b>80</b> ta. Agar ularni 40 tadan yangi qutilarga solsak — 80 : 40 = <b>2</b> ta quti. 20 tadan solsak — 80 : 20 = 4 ta quti.</p>",
 q:{t:"Bir sinfda 30 ta o'quvchi. 3 ta sinfga 90 ta kitob keldi va teng bo'lindi. Bir sinfga nechta kitob tegdi?",opts:["30","3","60","270"],ok:0,why:"90 : 3 = 30.",hint:"90 ta kitob 3 sinfga teng bo'lindi.",full:"90 : 3 = 30 ta kitob har sinfga. Ortiqcha ma'lumot: «30 ta o'quvchi» savolga kerak emas."},
 tn:"Masaladagi ortiqcha ma'lumotni topishni o'rgating (2D9 mavzusi bilan bog'liq)."},
{h:"Bilasizmi? Pul — yaxlit sonlar",sum:"Pullarimiz yaxlit sonlar: 1000, 5000, 10 000 so'm. Ular bilan hisob — shu mavzu!",a:"m08",
 start:function(){clear();['1 000','5 000','10 000'].forEach(function(t,i){E('rect',{x:20+i*112,y:50,width:100,height:56,rx:8,fill:['#e6f6ee','#e8f1fb','#fde6c8'][i],stroke:C.line},S.g);T(S.g,70+i*112,84,t,{'font-size':16,'font-weight':800})});k2c14_big('Pullarimiz — yaxlit sonlar')},fin:function(){STEPS[7].start()},
 html:"<p>💵 Bizning pullarimiz ham yaxlit sonlar: 1 000, 5 000, 10 000 so'm. «3 ta 20 ming so'mlik — necha so'm?» — bu 20 · 3 = 60 ming so'm. Do'konda har kuni shu hisobni qilamiz!</p><p>🧮 Qadimda savdogarlar «o'nliklar» va «yuzliklar»ni toshcha va cho'tlarda sanagan — biz bugun sizga ko'rsatgan usul ham o'sha: avval nechta o'nlik, keyin javob.</p>",
 tn:"O'yin pullari bilan «do'kon» o'ynang: narxlar yaxlit sonlar (20, 30, 50)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c14_rods(3,2,{lab:function(){return '20'},cap:'20 · 3 = 60'});k2c14_big('20 · 3 = 60')},fin:function(){k2c14_rods(3,2,{lab:function(){return '20'},cap:'20 · 3 = 60'});k2c14_big('20 · 3 = 60')},
 html:"<div class='memo'><ul><li><b>Yaxlit son</b> — 0 bilan tugaydi: 20, 50, 300.</li><li>Ko'paytirish: 0 siz ko'paytir, 0 ni qaytar: 20 · 3 = (2 · 3) o'nlik = 60.</li><li>Bo'lish: 80 : 4 = (8 : 4) o'nlik = 20.</li><li>Yuzliklar ham shunday: 600 : 3 = 200.</li><li>50 · 2 = 100 — nollar ikkita bo'lishi mumkin!</li><li>80 : 40 = 2 — o'nlikni o'nlikka bo'lsak, oddiy son.</li><li>Doim tekshiring: 20 · 3 = 60 ✓.</li></ul></div>",
 tn:"Keyingi darsni «40 · 5 va 400 : 5» bilan boshlang (200 va 80)."}
];
var PROBS=[
{t:"30 · 2 nechaga teng?",o:["60","6","32","600"],k:0,s:"3 o'nlik · 2 = 6 o'nlik = 60."},
{t:"20 · 4 nechaga teng?",o:["80","8","24","800"],k:0,s:"2 · 4 = 8 o'nlik = 80."},
{t:"60 : 2 nechaga teng?",o:["30","3","300","58"],k:0,s:"6 o'nlik : 2 = 3 o'nlik = 30."},
{t:"80 : 4 nechaga teng?",o:["20","2","200","76"],k:0,s:"8 o'nlik : 4 = 2 o'nlik = 20."},
{t:"50 · 2 nechaga teng?",o:["100","10","1000","52"],k:0,s:"5 · 2 = 10 o'nlik = 100."},
{t:"300 · 3 nechaga teng?",o:["900","90","9000","303"],k:0,s:"3 yuzlik · 3 = 9 yuzlik = 900."},
{t:"800 : 4 nechaga teng?",o:["200","20","2","2000"],k:0,s:"8 yuzlik : 4 = 2 yuzlik = 200."},
{t:"90 : 30 nechaga teng?",o:["3","30","300","60"],k:0,s:"30 · 3 = 90."},
{t:"Qaysi tenglik NOTO'G'RI?",o:["60 : 3 = 2","40 · 2 = 80","90 : 9 = 10","70 · 1 = 70"],k:0,s:"60 : 3 = 20, chunki 2 · 3 = 6."},
{t:"Hisoblang: 200 · 4 − 30 · 20",o:["200","740","400","20"],k:0,s:"800 − 600 = 200."},
{t:"40 · 5 nechaga teng?",o:["200","20","45","2000"],k:0,s:"4 · 5 = 20 o'nlik = 200."},
{t:"Bir qopda 30 kg un. 3 ta qopda necha kg?",o:["90","33","60","900"],k:0,s:"30 · 3 = 90 kg."},
{t:"80 ta daftarni 20 tadan pachkalarga solishdi. Nechta pachka?",o:["4","40","60","100"],k:0,s:"80 : 20 = 4."},
{t:"Hisoblang: 60 · (45 − 38 + 5)",o:["720","120","480","780"],k:0,s:"45 − 38 + 5 = 12, 60 · 12 = 720."},
{t:"400 : □ = 80. □ nechaga teng?",o:["5","50","320","4"],k:0,s:"400 : 80 = 5. Tekshiruv: 80 · 5 = 400."},
{t:"□ · 30 = 210. □ nechaga teng?",o:["7","70","180","240"],k:0,s:"21 o'nlik : 3 o'nlik = 7. Tekshiruv: 7 · 30 = 210."},
{t:"Qaysi ko'paytma eng katta?",o:["70 · 6","60 · 6","80 · 5","90 · 4"],k:0,s:"420, 360, 400, 360 — eng kattasi 70 · 6 = 420."},
{t:"Hisoblang: 524 : 4 + 276 : 4 (qulay usulda)",o:["200","210","190","400"],k:0,s:"(524 + 276) : 4 = 800 : 4 = 200."},
{t:"3 ta kitob 20 ming so'mdan va 2 ta daftar 5 ming so'mdan. Hammasi necha ming so'm?",o:["70","65","60","25"],k:0,s:"20 · 3 = 60, 5 · 2 = 10, 60 + 10 = 70 ming so'm."},
{t:"Hisoblang: (400 : 5 · 7) : 10",o:["56","560","66","5600"],k:0,s:"400 : 5 = 80, 80 · 7 = 560, 560 : 10 = 56."}
];
function PRACT_STAGE(){k2c14_rods(3,2,{lab:function(){return '20'}});k2c14_msg('Nechta o‘nlik? — keyin javob')}
var PREP_DATA={teach:["Yaxlit son — 0 bilan tugaydigan son.","20 · 3 kabi: o'nliklar (yuzliklar) soni bilan ko'paytirish.","80 : 4 kabi: o'nliklarni teng bo'lish; 80 : 40 kabi: sig'dirish.","Tekshirish va hayotiy masalalar (pul, qadoq)."],
 mist:["60 : 3 = 2 (o'nlik nomini tashlab yuboradi).","50 · 2 = 10 yoki 1000 (nollar sonini xato sanaydi).","80 : 40 = 20 (ikki xil bo'lishni aralashtiradi).","Ortiqcha ma'lumotni ham hisobga qo'shadi."],
 need:["10 talik cho'p bog'lamlari.","O'yin pullari (1000, 5000, 10 000)."],
 board:["<span class='w2'>20 · 3 = 2 o'nlik · 3 = 6 o'nlik = 60</span>.","<span class='w2'>80 : 4 = 8 o'nlik : 4 = 20</span>.","<span class='w2'>600 : 3 = 200</span>.","Tuzoq: <span class='w2'>60 : 3 = 20, 2 emas</span>.","<span class='w2'>80 : 40 = 2</span>."]};
