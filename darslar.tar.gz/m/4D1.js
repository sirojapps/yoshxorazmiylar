var CODE='4D1',TITLE='4-sinf · Ko‘p amalli ifodalar, amallar tartibi';
var P2=[function(){w3Expr(['120 + 80 · 5 − 300 : 6']);w3Msg('Avval «kuchli» amallar: ko‘paytirish va bo‘lish')},
 function(){w3Expr(['120 + [80 · 5] − 300 : 6','80 · 5 = {400}']);w3Msg('1-amal: 80 · 5 = 400')},
 function(){w3Expr(['120 + 400 − [300 : 6]','300 : 6 = {50}']);w3Msg('2-amal: 300 : 6 = 50')},
 function(){w3Expr(['[120 + 400] − 50','120 + 400 = {520}']);w3Msg('3-amal: endi chapdan o‘ngga — qo‘shish')},
 function(){w3Expr(['520 − 50 = {470}']);w3Msg('4-amal: 520 − 50 = <b>470</b>')}];
var P3=[function(){w3Expr(['2400 : (40 + 8 · (15 − 10))']);w3Msg('Ichma-ich qavs: eng ichkaridan boshlaymiz')},
 function(){w3Expr(['2400 : (40 + 8 · [(15 − 10)])','15 − 10 = {5}']);w3Msg('1) eng ichki qavs: 15 − 10 = 5')},
 function(){w3Expr(['2400 : (40 + [8 · 5])','8 · 5 = {40}']);w3Msg('2) katta qavs ichida avval ko‘paytirish')},
 function(){w3Expr(['2400 : [(40 + 40)]','40 + 40 = {80}']);w3Msg('3) qavs ichini tugatamiz')},
 function(){w3Expr(['2400 : 80 = {30}']);w3Msg('4) 2400 : 80 = <b>30</b>')}];
var P7=[function(){w3Expr(['3060 : 34 + 205 · 18']);w3Msg('Ikki «kuchli» amal, keyin qo‘shish')},
 function(){w3Expr(['[3060 : 34] + 205 · 18','3060 : 34 = {90}']);w3Msg('34 · 9 = 306, demak 3060 : 34 = 90')},
 function(){w3Expr(['90 + [205 · 18]','205 · 18 = 3600 + 90 = {3690}']);w3Msg('200 · 18 = 3600, 5 · 18 = 90')},
 function(){w3Expr(['90 + 3690 = {3780}']);w3Msg('Javob: <b>3780</b>')}];
var STEPS=[
{h:"Faqat qo'shish va ayirish: chapdan o'ngga",sum:"900 − 300 + 100 = 700: amallar chapdan o'ngga bajariladi, 500 emas.",a:"m01",
 start:function(){w3Expr(['900 − 300 + 100']);w3Msg('Qaysi javob to‘g‘ri?')},fin:function(){w3Expr(['[900 − 300] + 100','600 + 100 = {700}']);w3Msg('Chapdan o‘ngga: avval ayirish, keyin qo‘shish')},
 html:"<p>Ifodada faqat <b>+</b> va <b>−</b> bor. Ikki bola ikki xil javob topdi. Qaysi biri to'g'ri?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['700','500'],'700',function(){w3Expr(['[900 − 300] + 100','600 + 100 = {700}']);w3Msg('To‘g‘ri: chapdan o‘ngga');done()},{'500':'500 — avval 300 + 100 qilingan. Lekin qo‘shish ayirishdan «kuchli» emas! Chapdan o‘ngga hisoblang'})},
 after:"<p>Qoida 1. Qavs yo'q va faqat <b>qo'shish-ayirish</b> (yoki faqat <b>ko'paytirish-bo'lish</b>) bo'lsa — amallar <b>chapdan o'ngga</b>, yozilgan tartibda bajariladi.</p>",
 q:{t:"1000 − 400 + 200 = ?",opts:["800","400","600","1600"],ok:0,why:"600 + 200 = 800.",hint:"Avval 1000 − 400.",full:"Chapdan o'ngga: 1000 − 400 = 600, 600 + 200 = 800. «400» — avval 400 + 200 = 600 qilib, 1000 − 600 deb hisoblash xatosi."},
 tn:"Doskaga strelka bilan «→» yo'nalishini chizing. Bolalar barmog'ini ifoda bo'ylab yurgizib, amal raqamini ustiga yozsin."},
{h:"Ko'paytirish va bo'lish oldin",sum:"120 + 80 · 5 − 300 : 6 = 120 + 400 − 50 = 470.",a:"m02",
 start:w4St(P2),fin:w4Fin(P2),
 html:"<p>Qoida 2. Qavssiz ifodada <b>avval ko'paytirish va bo'lish</b> (chapdan o'ngga), <b>keyin qo'shish va ayirish</b> (chapdan o'ngga). Bosib kuzating:</p>",btns:[phaser(P2)],
 after:"<p>Natija <b>470</b>. Ko'paytirish va bo'lish — «birinchi bosqich» amallari, qo'shish va ayirish — «ikkinchi bosqich» amallari. Amal tartibini avval ifoda ustiga raqam bilan yozib oling: 1, 2, 3, 4.</p>",
 q:{t:"60 + 40 · 3 − 90 : 9 = ?",opts:["170","180","190","300"],ok:0,why:"60 + 120 − 10 = 170.",hint:"Avval 40 · 3 va 90 : 9.",full:"40 · 3 = 120, 90 : 9 = 10. Keyin 60 + 120 = 180, 180 − 10 = 170. «180» — 10 ni ayirish unutilgan; «190» — 10 qo'shib yuborilgan; «300» — avval 60 + 40 qilingan."},
 tn:"Ikki rangli bo'r: ko'paytirish/bo'lish — qizil, qo'shish/ayirish — ko'k. Avval qizillarni bajaring."},
{h:"Tuzoq: bo'lish va ko'paytirish yonma-yon",sum:"48 : 6 · 2 = 8 · 2 = 16. 4 emas: ko'paytirish bo'lishdan «oldin» emas, ular teng huquqli.",a:"m03",
 start:function(){w3Expr(['48 : 6 · 2']);w3Msg('Qaysi javob to‘g‘ri: 16 yoki 4?')},fin:function(){w3Expr(['[48 : 6] · 2','8 · 2 = {16}']);w3Msg('Teng huquqli amallar — chapdan o‘ngga')},
 html:"<p>Ko'pchilik shu yerda adashadi! <b>48 : 6 · 2</b> nechaga teng?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['16','4'],'16',function(){w3Expr(['[48 : 6] · 2','8 · 2 = {16}']);w3Msg('To‘g‘ri! Bo‘lish va ko‘paytirish teng huquqli');done()},{'4':'4 — avval 6 · 2 = 12 qilingan. Ko‘paytirish bo‘lishdan kuchli emas — chapdan o‘ngga!'})},
 after:"<p>Ko'paytirish va bo'lish — <b>bir bosqich</b> amallari, ular orasida «katta-kichik» yo'q. Shuning uchun yozilgan tartibda: 48 : 6 = 8, 8 · 2 = 16. Agar avval 6 · 2 ni bajarmoqchi bo'lsak, qavs kerak: 48 : (6 · 2) = 4.</p>",
 q:{t:"72 : 8 · 3 = ?",opts:["27","3","24","9"],ok:0,why:"9 · 3 = 27.",hint:"Chapdan o'ngga: avval 72 : 8.",full:"72 : 8 = 9, 9 · 3 = 27. «3» — avval 8 · 3 = 24, keyin 72 : 24 = 3 deb hisoblash. Bu 72 : (8 · 3) ifodasining qiymati."},
 tn:"Kalkulyatorda ham tekshiring: oddiy kalkulyator 48 : 6 · 2 ni ketma-ket hisoblaydi va 16 beradi."},
{h:"Ichma-ich qavslar",sum:"2400 : (40 + 8 · (15 − 10)) = 2400 : 80 = 30. Eng ichki qavsdan boshlanadi.",a:"m04",
 start:w4St(P3),fin:w4Fin(P3),
 html:"<p>Qoida 3. Qavs bo'lsa, <b>avval qavs ichi</b> bajariladi. Qavs ichida qavs bo'lsa — <b>eng ichkaridan</b> boshlanadi. Qavs ichida ham 1- va 2-qoida ishlaydi.</p>",btns:[phaser(P3)],
 after:"<p>Natija <b>30</b>. Qavs — «avval meni hisoblang!» degan belgi. Uni matryoshka deb tasavvur qiling: eng kichigi ichkarida.</p>",
 q:{t:"500 − (40 + 6 · (25 − 18)) = ?",opts:["418","178","82","458"],ok:0,why:"25 − 18 = 7, 6 · 7 = 42, 40 + 42 = 82, 500 − 82 = 418.",hint:"Eng ichki qavs: 25 − 18.",full:"7 → 6 · 7 = 42 → 40 + 42 = 82 → 500 − 82 = 418. «458» — 40 ni unutib, faqat 42 ni ayirish; «178» — qavs ichida 40 + 6 = 46 ni avval qo'shish (46 · 7 = 322); «82» — oxirgi ayirish unutilgan."},
 tn:"Qavslarni rangli yoyqavs bilan aylantirib chizing: ichkisi qizil, tashqisi ko'k."},
{h:"Birinchi amalni toping",sum:"560 − 40 · (12 − 5) + 81 : 9: birinchi amal — qavs ichidagi 12 − 5.",a:"m05",
 start:function(){w3Expr(['560 − 40 · (12 − 5) + 81 : 9']);w3Msg('Qaysi amal birinchi bajariladi?')},fin:function(){w3Expr(['560 − 40 · [(12 − 5)] + 81 : 9','560 − [40 · 7] + [81 : 9]','560 − 280 + 9 = {289}']);w3Msg('Tartib: qavs → ·, : → −, +')},
 html:"<p>Birinchi bajariladigan amalni tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['12 − 5','560 − 40','81 : 9','40 · 12'],'12 − 5',function(){w3Expr(['560 − 40 · [(12 − 5)] + 81 : 9','560 − [40 · 7] + [81 : 9]','560 − 280 + 9 = {289}']);w3Msg('To‘g‘ri — qavs birinchi. Javob 289');done()},{'560 − 40':'Ayirish — eng oxirgi bosqich amali','81 : 9':'Bo‘lish qavsdan keyin bajariladi','40 · 12':'40 ni 12 ga emas, butun qavsga ko‘paytiramiz'})},
 after:"<p>To'liq tartib: <b>12 − 5 = 7</b> → <b>40 · 7 = 280</b> → <b>81 : 9 = 9</b> → <b>560 − 280 = 280</b> → <b>280 + 9 = 289</b>. Har bir amal ustiga raqam qo'ying — beshta amal, beshta raqam.</p>",
 q:{t:"81 : 9 + 7 · (20 − 13) ifodada birinchi bajariladigan amal qaysi?",opts:["20 − 13","81 : 9","9 + 7","7 · 20"],ok:0,why:"Qavs ichidagi amal birinchi.",hint:"Qavs bormi?",full:"Qavs bor — demak birinchi 20 − 13 = 7. Keyin 81 : 9 = 9 va 7 · 7 = 49, oxiri 9 + 49 = 58."},
 tn:"Bolalar ifodani daftarga ko'chirib, amallar ustiga 1, 2, 3… raqamlarini yozsin; so'ng juftlikda tekshirishsin."},
{h:"Qavs qo'yib natijani o'zgartiring",sum:"6 + 4 · 5 − 2 = 24, lekin (6 + 4) · 5 − 2 = 48. Qavs natijani tubdan o'zgartiradi.",a:"m06",
 start:function(){w3Expr(['6 + 4 · 5 − 2 = 24']);w3Msg('Qavs qo‘yib, 48 hosil qiling')},fin:function(){w3Expr(['(6 + 4) · 5 − 2','10 · 5 − 2 = {48}']);w3Msg('Qavs natijani o‘zgartirdi: 24 → 48')},
 html:"<p>Qavssiz <b>6 + 4 · 5 − 2 = 24</b>. Qavsni qayerga qo'ysak, natija <b>48</b> bo'ladi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['(6 + 4) · 5 − 2','6 + 4 · (5 − 2)','(6 + 4) · (5 − 2)','6 + (4 · 5 − 2)'],'(6 + 4) · 5 − 2',function(){w3Expr(['(6 + 4) · 5 − 2','10 · 5 − 2 = {48}']);w3Msg('To‘g‘ri!');done()},{'6 + 4 · (5 − 2)':'6 + 4 · 3 = 18','(6 + 4) · (5 − 2)':'10 · 3 = 30','6 + (4 · 5 − 2)':'6 + 18 = 24 — bu qavs hech narsani o‘zgartirmadi'})},
 after:"<p>Bir xil sonlar va amallar — qavsga qarab 18, 24, 30 yoki 48. Qavs ko'paytirish yoki bo'lishdan oldin turgan <b>qo'shish/ayirishni</b> «yuqoriga ko'taradi». Ko'paytirish atrofidagi qavs (4 · 5) esa hech narsani o'zgartirmaydi — u baribir birinchi bajariladi.</p>",
 q:{t:"Qaysi ifodada qavsni olib tashlasa ham qiymat o'zgarmaydi?",opts:["30 − (8 · 3)","(30 − 8) · 3","30 : (5 + 1)","(30 + 6) : 6"],ok:0,why:"8 · 3 baribir birinchi bajariladi.",hint:"Qavs ichida qaysi amal turibdi?",full:"30 − (8 · 3) = 30 − 24 = 6 va 30 − 8 · 3 = 6 — bir xil. Qolganlarida qavs qo'shish yoki ayirishni oldinga chiqaryapti: (30 − 8) · 3 = 66, lekin 30 − 8 · 3 = 6."},
 tn:"«Qavs o'yini»: sonlar kartochkalarini qo'yib, guruhlar kim ko'p turli natija topishini musobaqa qilsin."},
{h:"Ko'p xonali sonlar bilan",sum:"3060 : 34 + 205 · 18 = 90 + 3690 = 3780.",a:"m07",
 start:w4St(P7),fin:w4Fin(P7),
 html:"<p>4-sinfda ifodalar ko'p xonali sonlar bilan keladi. Tartib o'sha-o'sha, faqat har amalni ehtiyotkor hisoblash kerak:</p>",btns:[phaser(P7)],
 after:"<p>Natija <b>3780</b>. Maslahat: katta ifodada oraliq natijalarni alohida qatorga yozing — «zanjir» usuli. Har amal: 1) 3060 : 34 = 90; 2) 205 · 18 = 3690; 3) 90 + 3690 = 3780.</p>",
 q:{t:"7200 : (900 − 300 · 2) = ?",opts:["24","6","12","8"],ok:0,why:"300 · 2 = 600, 900 − 600 = 300, 7200 : 300 = 24.",hint:"Qavs ichida avval ko'paytirish.",full:"Qavs ichi: 300 · 2 = 600, 900 − 600 = 300. 7200 : 300 = 24. «6» — qavs ichini (900 − 300) · 2 = 1200 deb hisoblash: 7200 : 1200 = 6."},
 tn:"Bolalar oraliq natijalarni ifoda ostiga «zinapoya» shaklida yozsin. Kalkulyatorsiz!"},
{h:"Masaladan ifoda tuzish",sum:"3 qutida 24 tadan, 2 qutida 36 tadan olma, 50 tasi sotildi: 3 · 24 + 2 · 36 − 50 = 94.",a:"m08",
 start:function(){w3Bar([{lab:'3 quti',segs:[{w:24,t:'24'},{w:24,t:'24'},{w:24,t:'24'}],tot:144},{lab:'2 quti',segs:[{w:36,t:'36',c:C.a},{w:36,t:'36',c:C.a}],tot:144}]);w3Msg('Jami olmadan 50 tasi sotildi. Qancha qoldi?')},
 fin:function(){w3Expr(['3 · 24 + 2 · 36 − 50','72 + 72 − 50 = {94}']);w3Msg('Bitta ifoda — butun masala')},
 html:"<p>«Omborda 24 tadan olma solingan 3 ta quti va 36 tadan solingan 2 ta quti bor edi. 50 ta olma sotildi. Nechta qoldi?» Qaysi ifoda masalaga mos?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['3 · 24 + 2 · 36 − 50','(3 + 2) · (24 + 36) − 50','3 · 24 + 2 · (36 − 50)','3 + 24 + 2 + 36 − 50'],'3 · 24 + 2 · 36 − 50',function(){w3Expr(['3 · 24 + 2 · 36 − 50','72 + 72 − 50 = {94}']);w3Msg('To‘g‘ri — 94 ta olma qoldi');done()},{'(3 + 2) · (24 + 36) − 50':'Bu har bir qutida 24 + 36 = 60 ta olma bor degani — xato','3 · 24 + 2 · (36 − 50)':'50 ta olma butun ombordan sotilgan, faqat 36 dan emas','3 + 24 + 2 + 36 − 50':'Qutilar soni va olmalar soni qo‘shilib ketdi'})},
 after:"<p>Ifoda tuzish usuli: har bir «bo'lak»ni alohida yozing (3 · 24, 2 · 36), keyin ular bilan nima qilinganini qo'shing (+, − 50). Amallar tartibi tufayli bu yerda qavs kerak emas!</p>",
 q:{t:"Ali 2500 so'mlik 3 ta daftar va 4500 so'mlik kitob olib, 20 000 so'm berdi. Qaytimni qaysi ifoda to'g'ri hisoblaydi?",opts:["20000 − (2500 · 3 + 4500)","20000 − 2500 · 3 + 4500","(20000 − 2500) · 3 − 4500","20000 − 2500 + 4500 · 3"],ok:0,why:"Avval xarid narxi (qavs ichida), keyin pul − narx.",hint:"Xaridning umumiy narxi qavs ichida bo'lishi kerak.",full:"Xarid: 2500 · 3 + 4500 = 12 000. Qaytim: 20 000 − 12 000 = 8000. Qavssiz «20000 − 2500 · 3 + 4500» da kitob narxi pulga qo'shilib ketadi: 17 000 — noto'g'ri."},
 tn:"Singapur chizma modeli: avval masalani lenta bilan chizing, keyin har bo'lakni ifoda bo'lagiga aylantiring."},
{h:"Bilasizmi? Ko'paytirish belgilarining tarixi",sum:"«×» belgisini 1631-yilda ingliz Uilyam Outred, nuqta «·» ni nemis olimi Leybnits ishlatgan.",a:"m09",
 start:function(){w3Expr(['5 × 4  =  5 · 4  =  20']);w3Msg('Ikki xil belgi — bitta ma’no')},fin:function(){w3Expr(['5 × 4  =  5 · 4  =  20']);w3Msg('Ikki xil belgi — bitta ma’no')},
 html:"<p>📜 Ko'paytirish uchun <b>«×»</b> belgisini ingliz matematigi <b>Uilyam Outred</b> 1631-yilda nashr etilgan kitobida ishlatgan.</p><p>⭐ Nemis olimi <b>Gotfrid Leybnits</b> esa «×» ni «x» harfi bilan adashtirmaslik uchun <b>nuqta «·»</b> ni afzal ko'rgan. Shuning uchun maktabda biz ko'pincha «·» yozamiz — ayniqsa harfli ifodalarda.</p>",
 tn:"Bolalardan so'rang: nega algebrada «×» noqulay? (x harfi bilan aralashadi.)"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['1) qavs (ichkaridan)','2) · va : (chapdan o‘ngga)','3) + va − (chapdan o‘ngga)']);w3Msg('Amallar tartibi')},fin:function(){w3Expr(['1) qavs (ichkaridan)','2) · va : (chapdan o‘ngga)','3) + va − (chapdan o‘ngga)']);w3Msg('Amallar tartibi')},
 html:"<div class='memo'><ul><li>Avval qavs ichidagi amallar; ichma-ich qavsda — eng ichkaridan.</li><li>Keyin ko'paytirish va bo'lish — chapdan o'ngga, yozilgan tartibda.</li><li>Oxirida qo'shish va ayirish — chapdan o'ngga.</li><li>48 : 6 · 2 = 16 (4 emas!); 900 − 300 + 100 = 700 (500 emas!).</li><li>Hisoblashdan oldin har amal ustiga tartib raqamini yozing.</li><li>Masaladan ifoda: har bo'lakni alohida yozing, keyin birlashtiring.</li></ul></div>",
 tn:"Kartochkani daftar muqovasiga yopishtirtiring — 4D2 (tenglamalar) da ham kerak bo'ladi."}
];
var PROBS=[
{t:"900 − 300 + 100 = ?",o:["700","500","600","800"],k:0,s:"Chapdan o'ngga: 600 + 100 = 700."},
{t:"48 : 6 · 2 = ?",o:["16","4","12","24"],k:0,s:"48 : 6 = 8, 8 · 2 = 16."},
{t:"120 + 80 · 5 = ?",o:["520","1000","600","420"],k:0,s:"80 · 5 = 400, 120 + 400 = 520."},
{t:"72 : 8 : 3 = ?",o:["3","9","24","27"],k:0,s:"72 : 8 = 9, 9 : 3 = 3."},
{t:"560 − 40 · (12 − 5) = ?",o:["280","3640","520","380"],k:0,s:"12 − 5 = 7, 40 · 7 = 280, 560 − 280 = 280."},
{t:"(450 − 150) : 3 · 2 = ?",o:["200","50","100","600"],k:0,s:"300 : 3 = 100, 100 · 2 = 200."},
{t:"81 : 9 + 7 · (20 − 13) ifodada birinchi bajariladigan amal?",o:["20 − 13","81 : 9","9 + 7","7 · 20"],k:0,s:"Qavs ichidagi amal birinchi."},
{t:"1000 − 25 · 4 · 8 = ?",o:["200","31200","800","300"],k:0,s:"25 · 4 = 100, 100 · 8 = 800, 1000 − 800 = 200."},
{t:"2400 : (40 + 8 · (15 − 10)) = ?",o:["30","10","60","240"],k:0,s:"15 − 10 = 5, 8 · 5 = 40, 40 + 40 = 80, 2400 : 80 = 30."},
{t:"Qavsni qayerga qo'ysak, 6 + 4 · 5 − 2 ning qiymati 48 bo'ladi?",o:["(6 + 4) · 5 − 2","6 + 4 · (5 − 2)","(6 + 4) · (5 − 2)","6 + (4 · 5 − 2)"],k:0,s:"10 · 5 − 2 = 48."},
{t:"3060 : 34 + 205 · 18 = ?",o:["3780","3800","3700","3690"],k:0,s:"90 + 3690 = 3780."},
{t:"500 − 4 · (36 + 14) : 25 = ?",o:["492","992","8","484"],k:0,s:"36 + 14 = 50, 4 · 50 = 200, 200 : 25 = 8, 500 − 8 = 492."},
{t:"25 · 8 − 36 : 4 · 3 + 7 = ?",o:["180","204","166","194"],k:0,s:"200 − 27 + 7 = 180 (36 : 4 · 3 = 9 · 3 = 27)."},
{t:"Omborda 24 tadan olma solingan 3 ta quti va 36 tadan solingan 2 ta quti bor edi. 50 ta olma sotildi. Nechta qoldi?",o:["94","144","194","44"],k:0,s:"3 · 24 + 2 · 36 − 50 = 72 + 72 − 50 = 94."},
{t:"7200 : (900 − 300 · 2) = ?",o:["24","6","12","8"],k:0,s:"900 − 600 = 300, 7200 : 300 = 24."},
{t:"1001 − 1001 : 7 · 7 = ?",o:["0","858","1001","143"],k:0,s:"1001 : 7 = 143, 143 · 7 = 1001, 1001 − 1001 = 0."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["(100 − 20) · 3","100 − 20 · 3","100 : 20 · 3","100 + 20 : 4"],k:0,s:"240; 40; 15; 105."},
{t:"Ali 2500 so'mlik 3 ta daftar va 4500 so'mlik kitob olib, 20 000 so'm berdi. Qancha qaytim oladi?",o:["8000","17 000","12 000","3000"],k:0,s:"20 000 − (2500 · 3 + 4500) = 20 000 − 12 000 = 8000."},
{t:"64 : 8 · 2 − 64 : (8 · 2) = ?",o:["12","0","20","14"],k:0,s:"16 − 4 = 12."},
{t:"(36 + 64) · (125 − 25) : 50 = ?",o:["200","164","10 000","20"],k:0,s:"100 · 100 = 10 000, 10 000 : 50 = 200."}
];
function PRACT_STAGE(){w3Expr(['1) qavs','2) · va :','3) + va −']);w3Msg('Amallar tartibini eslang')}
var PREP_DATA={teach:["Qavssiz ifodalarda amallar tartibi (bir bosqichli va ikki bosqichli).","Qavsli va ichma-ich qavsli ifodalar.","Ko'p xonali sonlar bilan 4–6 amalli ifodalarni hisoblash.","Masala shartiga ko'ra ifoda tuzish va qavs qo'yish."],
 mist:["900 − 300 + 100 ni 500 deb hisoblaydi (qo'shishni oldin bajaradi).","48 : 6 · 2 ni 4 deb hisoblaydi (ko'paytirishni bo'lishdan oldin bajaradi).","Ichma-ich qavsda tashqi qavsdan boshlaydi.","Xarid narxini qavssiz yozadi: 20000 − 2500 · 3 + 4500."],
 need:["Ikki rangli bo'r.","Sonlar va amal belgilari kartochkalari (qavs o'yini uchun)."],
 board:["<span class='w2'>900 − 300 + 100 = 700</span>.","<span class='w2'>48 : 6 · 2 = 16</span>.","<span class='w2'>120 + 80 · 5 − 300 : 6 = 470</span>.","<span class='w2'>2400 : (40 + 8 · (15 − 10)) = 30</span>.","<span class='w2'>(6 + 4) · 5 − 2 = 48</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
