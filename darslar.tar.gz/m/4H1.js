// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4H1',TITLE='4-sinf · Murakkab shakllar perimetri va yuzi';
var H1L=g4rect(0,0,3,4).concat(g4rect(3,2,3,2));
function h1base(cells,o){clear();o=o||{};return g4cells(cells,Object.assign({s:18,x0:o.x0!=null?o.x0:72,y0:o.y0!=null?o.y0:18,cols:12,rows:7},o))}
function h1L(o){var r=h1base(H1L,o),g=S.g,s=r.s,x0=r.x0,y0=r.y0;
 if(!(o&&o.nolab)){T(g,x0+3*s,y0+4*s+15,'6 sm',{'font-size':12,'font-weight':800,fill:C.bad});T(g,x0-20,y0+2*s+4,'4 sm',{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0+1.5*s,y0-5,'3 sm',{'font-size':11,'font-weight':800,fill:C.bad});T(g,x0+6*s+16,y0+3*s+4,'2 sm',{'font-size':11,'font-weight':800,fill:C.blue})}
 T(g,330,150,'1 katak = 1 sm²',{'font-size':10,'font-weight':700,fill:'#7a6a50','text-anchor':'end'});return r}
var P2=[function(){h1L({col:C.t2});calc(['Shaklni ikkita to‘g‘ri to‘rtburchakka bo‘lamiz'])},
 function(){h1L({colf:function(p){return p[0]<3?'#f6c98a':'#bfe3f5'}});calc(['Chap qism: 3 · 4 = <b>12 sm²</b>','O‘ng-past qism: 3 · 2 = <b>6 sm²</b>'])},
 function(){h1L({colf:function(p){return p[0]<3?'#f6c98a':'#bfe3f5'}});calc(['12 + 6 = <b>18 sm²</b>'])}];
var P3=[function(){h1L({col:C.t2});calc(['Endi boshqa usul: shaklni to‘liq to‘rtburchakka «to‘ldiramiz»'])},
 function(){var r=h1L({col:C.t2}),s=r.s;E('rect',{x:r.x0+3*s,y:r.y0,width:3*s,height:2*s,fill:'#fde2e2',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 3'},S.g);calc(['To‘liq to‘rtburchak: 6 · 4 = <b>24 sm²</b>','Yetishmayotgan bo‘lak: 3 · 2 = 6 sm²'])},
 function(){var r=h1L({col:C.t2}),s=r.s;E('rect',{x:r.x0+3*s,y:r.y0,width:3*s,height:2*s,fill:'#fde2e2',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 3'},S.g);calc(['24 − 6 = <b>18 sm²</b> — xuddi birinchi usuldagidek ✓'])}];
var P4=[function(){h1L({col:C.t2,edge:true});calc(['Perimetr — chegara uzunligi. Ikki tomon ko‘rsatilmagan: ?'])},
 function(){var r=h1L({col:C.t2,edge:true}),s=r.s,g=S.g;E('line',{x1:r.x0+3*s,y1:r.y0-3,x2:r.x0+6*s,y2:r.y0-3,stroke:C.ok,'stroke-width':3,'stroke-dasharray':'5 3'},g);E('line',{x1:r.x0+6*s+3,y1:r.y0,x2:r.x0+6*s+3,y2:r.y0+2*s,stroke:C.ok,'stroke-width':3,'stroke-dasharray':'5 3'},g);calc(['«Zinapoya» tomonlarini tashqariga surib qo‘yamiz','Ichki gorizontal (3 sm) + yuqori (3 sm) = 6 sm; vertikallar: 2 + 2 = 4 sm'])},
 function(){h1L({col:C.t2,edge:true});calc(['P = 6 + 4 + 6 + 4 = <b>20 sm</b>','To‘liq 6 × 4 to‘rtburchakniki bilan bir xil!'])}];
function h1cut(kind){var c=g4rect(0,0,4,4),rm=kind===1?'3,0':kind===2?'1,0':'';c=c.filter(function(p){return p[0]+','+p[1]!==rm});var r=h1base(c,{edge:true,col:C.t2,x0:144,y0:30,cols:4,rows:4,s:20});
 if(rm){var q=rm.split(',');E('rect',{x:r.x0+q[0]*r.s,y:r.y0+q[1]*r.s,width:r.s,height:r.s,fill:'none',stroke:C.grey,'stroke-dasharray':'3 3'},S.g)}
 var A=[16,15,15],P=[16,16,18];g4m('Yuz: <b>'+A[kind]+' sm²</b> · Perimetr: <b>'+P[kind]+' sm</b>'+(kind===1?' — o‘zgarmadi!':kind===2?' — oshdi!':''))}
var P6=[function(){clear();var g=S.g;E('rect',{x:110,y:30,width:144,height:96,fill:'#f6c98a',stroke:C.t1,'stroke-width':2},g);T(g,182,144,'6 sm',{'font-size':12,'font-weight':800,fill:C.bad});T(g,96,82,'4 sm',{'font-size':12,'font-weight':800,fill:C.blue});calc(['To‘g‘ri to‘rtburchak: 6 · 4 = <b>24 sm²</b>'])},
 function(){P6[0]();E('line',{x1:110,y1:126,x2:254,y2:30,stroke:C.bad,'stroke-width':2.4},S.g);calc(['Diagonal uni ikkita <b>teng</b> to‘g‘ri burchakli uchburchakka bo‘ladi'])},
 function(){clear();var g=S.g;E('polygon',{points:'110,30 110,126 254,126',fill:'#bfe3f5',stroke:C.blue,'stroke-width':2},g);E('polygon',{points:'110,30 254,30 254,126',fill:'#fff',stroke:C.grey,'stroke-width':1.2,'stroke-dasharray':'4 3'},g);T(g,182,144,'6 sm',{'font-size':12,'font-weight':800,fill:C.bad});T(g,96,82,'4 sm',{'font-size':12,'font-weight':800,fill:C.blue});calc(['Uchburchak yuzi = 24 : 2 = <b>12 sm²</b>','Ya’ni: (6 · 4) : 2'])}];
function h1pool(k){clear();var g=S.g,s=18,x0=90,y0=18;for(var c=0;c<10;c++)for(var r=0;r<7;r++){var inn=c>0&&c<9&&r>0&&r<6;E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:inn?'#9fd3f5':(k?'#b7dd9b':'#f3f3f3'),stroke:'#fff','stroke-width':.8},g)}
 T(g,x0+5*s,y0+3.5*s+4,'Hovuz 8 × 5 m',{'font-size':13,'font-weight':800,fill:'#1d4d6d'});T(g,x0+5*s,y0+7*s+14,'10 m',{'font-size':12,'font-weight':800,fill:C.bad});T(g,x0-6,y0+3.5*s+4,'7 m',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
var P7=[function(){h1pool(0);calc(['Hovuz 8 m × 5 m. Atrofida eni 1 m li yo‘lak. Yo‘lak yuzi?'])},
 function(){h1pool(1);calc(['Tashqi o‘lcham: 8 + 1 + 1 = <b>10 m</b>, 5 + 1 + 1 = <b>7 m</b>','Hammasi: 10 · 7 = 70 m²'])},
 function(){h1pool(1);calc(['70 − 8 · 5 = 70 − 40 = <b>30 m²</b> — yo‘lak','(Diqqat: har tomonga 1 m — jami 2 m qo‘shiladi)'])}];
function h1same(w,h){clear();var r=g4cells(g4rect(0,0,w,h),{s:18,x0:180-w*9,y0:40,cols:w,rows:h,edge:true,col:C.t2});g4m(w+' × '+h+': yuz <b>'+(w*h)+' sm²</b>, perimetr <b>'+(2*(w+h))+' sm</b>')}
var STEPS=[
{h:"Perimetr va yuz — farqi",sum:"Perimetr — chegara uzunligi (sm), yuz — ichidagi kataklar (sm²). L-shakl: P = 20 sm, S = 18 sm².",a:"m01",
 start:function(){h1L({col:C.t2})},fin:function(){h1L({col:C.t2,edge:true})},
 html:"<p>Mana murakkab — <b>L</b> shaklidagi figura. Ikkala tugmani bosing:</p>",
 btns:[["📏 Perimetr",function(c,done){h1L({col:C.t2,edge:true});g4m('Qizil chegara bo‘ylab birlik kesmalarni sanang: <b>20 sm</b>');mvK(done,2)}],["🟧 Yuz",function(c,done){h1L({col:C.t2});g4m('Ichidagi kataklarni sanang: <b>18 sm²</b>');mvK(done,2)}]],g2:1,
 after:"<p><b>Perimetr</b> — shakl atrofidagi chiziq uzunligi (sm, m). <b>Yuz</b> — shakl egallagan joy (sm², m²). Ular har xil kattalik — solishtirib ham, qo'shib ham bo'lmaydi.</p>",
 q:{t:"Bu L-shaklning yuzi qancha?",opts:["20 sm²","18 sm²","24 sm²","16 sm²"],ok:1,why:"Kataklar soni 18.",hint:"Perimetr emas — ichidagi kataklarni sanang.",full:"Shaklda 18 ta katak bor: 18 sm². «20» — bu perimetr (sm), «24» — butun 6 × 4 to'rtburchak."},
 tn:"Bolalar katakli qog'ozda o'z L-shaklini chizib, perimetrni qizil, yuzni sariq bilan belgilasin."},
{h:"1-usul: bo'laklarga ajratish",sum:"L-shakl = 3 × 4 + 3 × 2 = 12 + 6 = 18 sm².",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Murakkab shakl yuzini kataklarsiz qanday topamiz? Uni <b>to'g'ri to'rtburchaklarga bo'lamiz</b>:</p>",
 btns:[phaser(P2)],
 after:"<p>Shaklni oddiy bo'laklarga ajratamiz, har birining yuzini topamiz va <b>qo'shamiz</b>. Bo'lish usuli har xil bo'lishi mumkin — javob bir xil chiqadi.</p>",
 q:{t:"Shaklni boshqacha bo'lsak: yuqori 3 × 2 va pastki 6 × 2. Yuz?",opts:["16 sm²","18 sm²","20 sm²","12 sm²"],ok:1,why:"3 · 2 + 6 · 2 = 6 + 12 = 18 sm².",hint:"Ikkala bo'lakning yuzini qo'shing.",full:"Yuqori bo'lak 3 · 2 = 6, pastki 6 · 2 = 12. Jami 18 sm² — bo'lish usuliga bog'liq emas."},
 tn:"Bolalarni turli bo'lish usullarini topishga undang (gorizontal va vertikal) — Yaponiya darsi uslubi: «Yana qanday?»"},
{h:"2-usul: to'ldirib ayirish",sum:"6 × 4 = 24, kesilgan 3 × 2 = 6: 24 − 6 = 18 sm².",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ba'zan shaklni bo'lishdan ko'ra, uni <b>to'liq to'rtburchakka to'ldirib</b>, ortiqchasini ayirish oson:</p>",
 btns:[phaser(P3)],
 after:"<p><b>Katta to'rtburchak − kesilgan bo'lak</b>. Bu usul ichida «teshik» bo'lgan shakllar (ramka, yo'lak) uchun juda qulay.</p>",
 q:{t:"8 sm × 5 sm to'rtburchakning burchagidan 3 sm × 2 sm bo'lak kesildi. Qolgan yuz?",opts:["40 sm²","6 sm²","34 sm²","46 sm²"],ok:2,why:"8 · 5 − 3 · 2 = 40 − 6 = 34 sm².",hint:"Katta to'rtburchak yuzidan kesilganini ayiring.",full:"40 − 6 = 34 sm². «46» — ayirish o'rniga qo'shish, «40» — kesilgan bo'lakni unutish."},
 tn:"Qog'ozdan to'rtburchak kesib, burchagini qaychi bilan qirqing — bolalar kataklarni sanab tekshirsin."},
{h:"Tuzoq: L-shakl perimetri",sum:"Zinapoya tomonlarini surib qo'ysak, perimetr to'liq to'rtburchakniki: 2 · (6 + 4) = 20 sm.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Perimetr uchun hamma tomonlar kerak, lekin ikkitasi yozilmagan. Yo'qolgan tomonlarni qanday topamiz?</p>",
 btns:[phaser(P4)],
 after:"<p>Hamma burchaklari to'g'ri bo'lgan «zinapoya» shaklida ichkariga botgan tomonlarni tashqariga surish mumkin — <b>perimetr o'zgarmaydi</b>. Shuning uchun P = 2 · (eng katta bo'yi + eng katta balandligi).</p>",
 q:{t:"Zinapoyasimon shakl: eng katta bo'yi 7 sm, eng katta balandligi 5 sm, hamma burchaklari to'g'ri (ichkariga chuqur o'yiq yo'q). Perimetri?",opts:["35 sm","12 sm","24 sm","20 sm"],ok:2,why:"2 · (7 + 5) = 24 sm.",hint:"Zinapoya tomonlarini tashqariga surib ko'ring.",full:"Tomonlarni surib, 7 × 5 to'rtburchak hosil qilamiz: P = 2 · (7 + 5) = 24 sm. «35» — bu yuz (7 · 5) bilan aralashtirish, «12» — faqat 7 + 5."},
 tn:"Ip bilan L-shakl chegarasini o'rab o'lchang, keyin ipni to'rtburchak qilib o'rang — uzunligi bir xil."},
{h:"Tuzoq: kesish perimetrni qanday o'zgartiradi?",sum:"Burchakdan kesilsa — yuz kamayadi, perimetr o'zgarmaydi. Chetidan o'yilsa — perimetr oshadi.",a:"m05",
 start:function(){h1cut(0)},fin:function(){h1cut(2)},
 html:"<p>4 × 4 kvadratdan bitta katakni ikki xil joydan kesib ko'ring:</p>",
 btns:[["Butun kvadrat",function(c,done){h1cut(0);mvK(done,3)}],["Burchakdan kesish",function(c,done){h1cut(1);mvK(done,3)}],["Chetidan o'yish",function(c,done){h1cut(2);mvK(done,3)}]],g3:1,
 after:"<p>Burchakdan kesganda ikki tomon yo'qoladi, lekin ikkita yangi tomon paydo bo'ladi — perimetr <b>o'zgarmaydi</b>. Chetidan o'yganda 1 tomon yo'qolib, <b>3 ta</b> yangi tomon chiqadi — perimetr <b>2 ga oshadi</b>. Yuz esa ikkala holda ham kamayadi!</p>",
 q:{t:"4 × 4 kvadratning ikki tomonining o'rtasidan bittadan katak o'yildi. Perimetr?",opts:["16 sm","20 sm","18 sm","14 sm"],ok:1,why:"Har o'yiq +2: 16 + 2 + 2 = 20 sm.",hint:"Bitta o'yiq perimetrni necha sm oshiradi?",full:"Bitta o'yiq perimetrni 2 ga oshiradi, ikkitasi — 4 ga: 16 + 4 = 20 sm. «14» — kesildi, demak kamaydi deb o'ylash xatosi."},
 tn:"«Yuz kamaysa, perimetr ham kamayadi» degan noto'g'ri fikrni ataylab muhokama qiling."},
{h:"To'g'ri burchakli uchburchak yuzi",sum:"Diagonal to'rtburchakni teng ikkiga bo'ladi: uchburchak yuzi = (6 · 4) : 2 = 12 sm².",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Murakkab shakllarda ko'pincha uchburchak bo'laklar uchraydi. To'g'ri burchakli uchburchakning yuzini topamiz:</p>",
 btns:[phaser(P6)],
 after:"<p>To'g'ri burchakli uchburchak — to'rtburchakning <b>yarmi</b>. Yuzi = (to'g'ri burchak yonidagi ikki tomon ko'paytmasi) : 2.</p>",
 q:{t:"To'g'ri burchak yonidagi tomonlari 8 sm va 5 sm bo'lgan uchburchak yuzi?",opts:["40 sm²","20 sm²","13 sm²","26 sm²"],ok:1,why:"(8 · 5) : 2 = 20 sm².",hint:"Avval to'rtburchak yuzini toping, keyin 2 ga bo'ling.",full:"8 · 5 = 40 — bu butun to'rtburchak. Uchburchak uning yarmi: 20 sm². «40» — 2 ga bo'lishni unutish, «13» — tomonlarni qo'shish."},
 tn:"Qog'oz to'rtburchakni diagonal bo'yicha qirqib, ikki uchburchakni ustma-ust qo'ying."},
{h:"Yo'lak va ramka",sum:"Hovuz 8 × 5, yo'lak 1 m: tashqi 10 × 7 = 70; 70 − 40 = 30 m².",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Hovuz atrofiga yo'lak qurilmoqda. Necha m² plitka kerak?</p>",
 btns:[phaser(P7)],
 after:"<p>Ramka (yo'lak) yuzi = <b>tashqi to'rtburchak − ichki to'rtburchak</b>. Tashqi o'lchamga yo'lak eni <b>ikki marta</b> qo'shiladi (ikki tomondan).</p>",
 q:{t:"Rasm 20 sm × 15 sm. Atrofida eni 2 sm li ramka. Ramka yuzi?",opts:["70 sm²","156 sm²","456 sm²","140 sm²"],ok:1,why:"Tashqi 24 · 19 = 456; 456 − 300 = 156 sm².",hint:"Tashqi o'lchamlar: 20 + 2 + 2 va 15 + 2 + 2.",full:"Tashqi 24 × 19 = 456 sm², rasm 20 × 15 = 300 sm². Ramka 456 − 300 = 156 sm². «140» — 2 · (20 + 15) · 2 (burchaklar hisobga olinmagan), «456» — rasm ayirilmagan."},
 tn:"Haqiqiy rasm ramkasini o'lchab, bolalar ramka yuzini hisoblasin."},
{h:"Yuzi bir xil — perimetri har xil",sum:"12 sm²: 4 × 3 (P = 14), 6 × 2 (P = 16), 12 × 1 (P = 26).",a:"m08",
 start:function(){h1same(4,3)},fin:function(){h1same(12,1)},
 html:"<p>12 ta katakdan har xil to'g'ri to'rtburchak yasang:</p>",
 btns:[["4 × 3",function(c,done){h1same(4,3);mvK(done,3)}],["6 × 2",function(c,done){h1same(6,2);mvK(done,3)}],["12 × 1",function(c,done){h1same(12,1);mvK(done,3)}]],g3:1,
 after:"<p>Yuzi bir xil bo'lsa ham perimetri har xil bo'lishi mumkin! Shakl <b>kvadratga qanchalik yaqin</b> bo'lsa, perimetri shuncha <b>kichik</b>; cho'zilgan sari kattalashadi.</p>",
 q:{t:"Yuzi 16 sm² bo'lgan to'g'ri to'rtburchaklardan qaysi birining perimetri eng kichik?",opts:["4 × 4","2 × 8","1 × 16"],ok:0,why:"4 × 4: P = 16; 2 × 8: 20; 1 × 16: 34.",hint:"Qaysi biri kvadratga eng yaqin?",full:"4 × 4 kvadratning perimetri 16 sm, 2 × 8 — 20 sm, 1 × 16 — 34 sm. Kvadrat eng kichik perimetrga ega."},
 tn:"Bolalarga savol: «Fermer 16 m sim bilan eng katta tovuqxona qurmoqchi — qanday shakl tanlaydi?» (kvadrat 4 × 4)."},
{h:"Bilasizmi? «Geometriya» — yer o'lchash",sum:"Yunoncha «geo» — yer, «metriya» — o'lchash. Misrda Nil toshqinidan keyin yerlar qayta o'lchangan.",a:"m09",
 start:function(){clear();var g=S.g;E('rect',{x:20,y:30,width:320,height:110,fill:'#d6efc7',stroke:'#3d8b3d','stroke-width':2},g);E('path',{d:'M20 80 C100 40 160 130 340 70',fill:'none',stroke:'#5aa9e6','stroke-width':14,opacity:.8},g);[[60,40,90,30],[170,95,120,40],[60,100,80,36]].forEach(function(r){E('rect',{x:r[0],y:r[1],width:r[2],height:r[3],fill:'none',stroke:C.t1,'stroke-width':2,'stroke-dasharray':'5 3'},g)});T(g,180,22,'Nil bo‘yidagi dalalar',{'font-size':12,'font-weight':800,fill:C.blue});g4m('geo — yer, metriya — o‘lchash')},fin:function(){STEPS[8].start()},
 html:"<p>🌾 Qadimgi <b>Misr</b>da Nil daryosi har yili toshib, dalalar chegarasini yuvib ketardi. Har safar yerlarni qayta o'lchash kerak bo'lgan — shu tariqa yuz hisoblash usullari paydo bo'lgan.</p><p>📜 «Geometriya» so'zi yunonchadan: <b>geo</b> — yer, <b>metreo</b> — o'lchayman, ya'ni «yer o'lchash».</p>",
 tn:"Bolalar maktab hovlisidagi biror maydonchani qadamlab o'lchab, taxminiy yuzini topsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h1L({col:C.t2,edge:true})},fin:function(){h1L({col:C.t2,edge:true})},
 html:"<div class='memo'><ul><li><b>Perimetr</b> — chegara uzunligi (sm); <b>yuz</b> — egallagan joy (sm²).</li><li>Murakkab shakl yuzi: <b>bo'laklarga ajratib qo'shish</b> yoki <b>to'ldirib ayirish</b>.</li><li>To'g'ri burchakli «zinapoya» shakl: P = 2 · (eng katta bo'yi + eng katta balandligi).</li><li>Burchakdan kesish perimetrni o'zgartirmaydi; chetidan o'yish uni oshiradi.</li><li>To'g'ri burchakli uchburchak yuzi = (a · b) : 2.</li><li>Ramka yuzi = tashqi − ichki; tashqi o'lchamga eni 2 marta qo'shiladi.</li><li>Yuzi teng shakllarda kvadratning perimetri eng kichik.</li></ul></div>",
 tn:"Uyga vazifa: xonangiz plani (L shakl bo'lsa yaxshi) — yuzini ikki usulda toping."}
];
var PROBS=[
{t:"To'g'ri to'rtburchak 9 sm × 4 sm. Perimetri?",o:["26 sm","36 sm","13 sm","18 sm"],k:0,s:"2 · (9 + 4) = 26 sm."},
{t:"To'g'ri to'rtburchak 9 sm × 4 sm. Yuzi?",o:["36 sm²","26 sm²","13 sm²","72 sm²"],k:0,s:"9 · 4 = 36 sm²."},
{t:"Kvadrat perimetri 28 sm. Yuzi?",o:["49 sm²","28 sm²","196 sm²","14 sm²"],k:0,s:"Tomon 28 : 4 = 7; 7 · 7 = 49 sm²."},
{t:"6 sm × 4 sm to'rtburchak burchagidan 3 sm × 2 sm kesildi. Qolgan yuz?",o:["18 sm²","24 sm²","20 sm²","6 sm²"],k:0,s:"24 − 6 = 18 sm²."},
{t:"6 sm × 4 sm to'rtburchak burchagidan 3 sm × 2 sm kesildi. Perimetri?",o:["20 sm","14 sm","24 sm","18 sm"],k:0,s:"Burchakdan kesilganda perimetr o'zgarmaydi: 2 · (6 + 4) = 20 sm."},
{t:"8 sm × 5 sm to'rtburchak burchagidan 3 sm × 2 sm kesildi. Yuzi?",o:["34 sm²","40 sm²","6 sm²","46 sm²"],k:0,s:"40 − 6 = 34 sm²."},
{t:"Zinapoyasimon shakl (hamma burchaklar to'g'ri): eng katta bo'yi 7 sm, balandligi 5 sm. Perimetri?",o:["24 sm","35 sm","12 sm","20 sm"],k:0,s:"2 · (7 + 5) = 24 sm."},
{t:"4 × 4 kvadratning bir tomonining o'rtasidan 1 × 1 katak o'yildi. Perimetr?",o:["18 sm","16 sm","15 sm","14 sm"],k:0,s:"O'yiq 1 tomonni olib, 3 ta yangi tomon beradi: 16 + 2 = 18 sm."},
{t:"To'g'ri burchak yonidagi tomonlari 8 sm va 5 sm bo'lgan uchburchak yuzi?",o:["20 sm²","40 sm²","13 sm²","26 sm²"],k:0,s:"(8 · 5) : 2 = 20 sm²."},
{t:"Hovuz 8 m × 5 m, atrofida eni 1 m yo'lak. Yo'lak yuzi?",o:["30 m²","26 m²","70 m²","40 m²"],k:0,s:"10 · 7 − 8 · 5 = 70 − 40 = 30 m²."},
{t:"Rasm 20 sm × 15 sm, ramka eni 2 sm. Ramka yuzi?",o:["156 sm²","70 sm²","456 sm²","140 sm²"],k:0,s:"24 · 19 − 20 · 15 = 456 − 300 = 156 sm²."},
{t:"Tomoni 5 sm va 3 sm bo'lgan ikki kvadrat yonma-yon qo'yildi. Shakl yuzi?",o:["34 sm²","64 sm²","16 sm²","26 sm²"],k:0,s:"25 + 9 = 34 sm²."},
{t:"Tomoni 5 sm va 3 sm bo'lgan ikki kvadrat yonma-yon (ostlari bir chiziqda). Shakl perimetri?",o:["26 sm","32 sm","16 sm","34 sm"],k:0,s:"Perimetrlar 20 + 12 = 32, tutashgan 3 sm ikki marta ayiriladi: 32 − 6 = 26 sm."},
{t:"Yuzi 12 sm² bo'lgan to'g'ri to'rtburchak (tomonlari butun sm) perimetri eng ko'pi bilan?",o:["26 sm","14 sm","16 sm","24 sm"],k:0,s:"1 × 12: P = 26 sm (eng cho'zilgani)."},
{t:"To'g'ri to'rtburchak perimetri 30 sm, bo'yi 9 sm. Yuzi?",o:["54 sm²","270 sm²","21 sm²","36 sm²"],k:0,s:"Eni (30 − 18) : 2 = 6 sm; 9 · 6 = 54 sm²."},
{t:"Xona 6 m × 5 m, gilam 4 m × 3 m. Gilamsiz qism yuzi?",o:["18 m²","12 m²","30 m²","42 m²"],k:0,s:"30 − 12 = 18 m²."},
{t:"Kvadrat tomoni 2 marta oshirildi. Perimetri necha marta oshdi?",o:["2 marta","4 marta","8 marta","O'zgarmadi"],k:0,s:"Har tomon 2 marta → perimetr ham 2 marta (yuz esa 4 marta)."},
{t:"Tomoni 4 sm bo'lgan 3 ta kvadrat qatorga qo'yildi. Hosil to'rtburchak perimetri?",o:["32 sm","48 sm","36 sm","24 sm"],k:0,s:"12 × 4 to'rtburchak: 2 · (12 + 4) = 32 sm."},
{t:"To'g'ri to'rtburchak bitta kesik bilan ikki teng kvadratga bo'lindi; har kvadrat perimetri 20 sm. To'rtburchak perimetri?",o:["30 sm","40 sm","20 sm","25 sm"],k:0,s:"Kvadrat tomoni 5 sm; to'rtburchak 10 × 5: P = 30 sm."},
{t:"Yuzi 36 sm² bo'lgan kvadratning perimetri?",o:["24 sm","36 sm","9 sm","18 sm"],k:0,s:"Tomon 6 sm (6 · 6 = 36); P = 4 · 6 = 24 sm."}
];
function PRACT_STAGE(){h1L({col:C.t2,edge:true});g4m('Bo‘laklarga ajrating yoki to‘ldirib ayiring')}
var PREP_DATA={teach:["Perimetr va yuz farqi (birliklari bilan).","Murakkab shakl yuzi: bo'lish va to'ldirish usullari.","L-shakl perimetri; kesish/o'yish perimetrga ta'siri.","To'g'ri burchakli uchburchak yuzi; ramka/yo'lak; yuzi teng — perimetri har xil."],
 mist:["Perimetr va yuzni aralashtiradi (birliklarini ham).","L-shakl perimetrida yozilmagan tomonlarni tashlab ketadi.","«Kesildi — perimetr kamaydi» deb o'ylaydi.","Ramkada eni bir marta qo'shiladi."],
 need:["Katakli qog'oz, rangli qalam.","Qaychi, qog'oz to'rtburchaklar.","Ip (perimetr uchun)."],
 board:["L-shakl: <span class='w2'>3·4 + 3·2 = 18</span> va <span class='w2'>6·4 − 3·2 = 18</span>.","<span class='w2'>P = 2 · (6 + 4) = 20</span>.","Uchburchak: <span class='w2'>(6 · 4) : 2 = 12</span>.","Yo'lak: <span class='w2'>10 · 7 − 8 · 5 = 30</span>.","12 sm²: 3×4 (14), 2×6 (16), 1×12 (26)."]};
