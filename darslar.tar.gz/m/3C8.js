var CODE='3C8',TITLE='3-sinf · Ko‘paytirish va bo‘lish komponentlari, noma’lumni topish';
function c8tri(top,l,r,hl){clear();var g=S.g;E('polygon',{points:'180,12 70,150 290,150',fill:'#f4f8fc',stroke:'#9cc3e8','stroke-width':2},g);
 var P=[[180,58,top,'ko‘paytma'],[112,132,l,'ko‘paytuvchi'],[248,132,r,'ko‘paytuvchi']];
 P.forEach(function(p,i){var on=hl===i;E('circle',{cx:p[0],cy:p[1]-6,r:22,fill:on?'#fdeaea':'#fff',stroke:on?C.bad:C.line,'stroke-width':2},g);T(g,p[0],p[1],String(p[2]),{'font-size':18,'font-weight':800,fill:on?C.bad:'#1d2b3a'});T(g,p[0],p[1]+28,p[3],{'font-size':10,'font-weight':700,fill:'#5b6b7b'})});
 T(g,180,100,'·  :',{'font-size':14,'font-weight':800,fill:C.blue})}
function c8bar(n,each,tot,q){clear();var g=S.g;var t=[];for(var i=0;i<n;i++)t.push(i===0?each:'');W3bars(70,n,t,{fill:function(i){return i===0?'#fde6c8':null}});
 E('path',{d:'M40 60 Q40 50 50 50 L310 50 Q320 50 320 60',fill:'none',stroke:C.blue,'stroke-width':2},g);T(g,180,42,String(tot),{'font-size':15,'font-weight':800,fill:C.blue});
 T(g,180,130,q||'',{'font-size':13,'font-weight':800,fill:'#33475b'})}
var P1=[function(){W3arr(3,4,{lbl:'3 qator, har birida 4 ta'});W3msg('Nechta nuqta bor?')},
 function(){W3arr(3,4,{lbl:'3 · 4 = 12'});W3msg('<b>3</b> va <b>4</b> — <b>ko‘paytuvchilar</b>, <b>12</b> — <b>ko‘paytma</b>')},
 function(){W3arr(3,4,{vline:2,lbl:'12 : 3 = 4'});W3msg('<b>12</b> — <b>bo‘linuvchi</b>, <b>3</b> — <b>bo‘luvchi</b>, <b>4</b> — <b>bo‘linma</b>')}];
var P2=[function(){c8tri(12,3,4);W3msg('Uchburchak-oila: tepada ko‘paytma, pastda ko‘paytuvchilar')},
 function(){c8tri(12,3,4);W3msg('3 · 4 = 12 &nbsp; 4 · 3 = 12')},
 function(){c8tri(12,3,4);W3msg('3 · 4 = 12 &nbsp; 4 · 3 = 12 &nbsp; 12 : 3 = 4 &nbsp; 12 : 4 = 3','Bitta oila — 4 ta tenglik')}];
var P7=[function(){W3eq(['(□ : 4) · 2 = 10'])},
 function(){W3eq(['(□ : 4) · 2 = 10','□ : 4 = 10 : 2 = [5]']);W3msg('Qavsni bitta «quti» deb ko‘ring: quti · 2 = 10, quti = 5')},
 function(){W3eq(['(□ : 4) · 2 = 10','□ : 4 = 5','□ = 5 · 4 = [20]']);W3msg('Tekshiruv: 20 : 4 = 5, 5 · 2 = 10 ✓')}];
function c8pick(eq,sol,ans,msg){return function(c,done){W3eq([eq,sol]);W3msg(msg);done()}}
function c8bad(eq,msg){return function(){W3eq([eq]);W3msg(msg,'Qayta tanlang')}}
var STEPS=[
{h:"Komponentlar nomi",sum:"3 · 4 = 12: ko'paytuvchilar va ko'paytma; 12 : 3 = 4: bo'linuvchi, bo'luvchi, bo'linma.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har bir son amalda o'z «ismi»ga ega. Nuqtalar massivida kuzating.</p>",btns:[phaser(P1)],
 after:"<p><b>ko'paytuvchi · ko'paytuvchi = ko'paytma</b><br><b>bo'linuvchi : bo'luvchi = bo'linma</b></p>",
 q:{t:"45 : 9 = 5. Bo'luvchi qaysi son?",opts:["9","45","5","54"],ok:0,why:"Bo'luvchi — nimaga bo'lyapmiz: 9.",hint:"Bo'linuvchi — bo'linadigan son, bo'luvchi — nimaga bo'linadi.",full:"45 — bo'linuvchi (bo'linadi), 9 — bo'luvchi (bo'ladi), 5 — bo'linma (natija)."},
 tn:"Nomlarni kartochkalarga yozib, doskadagi misol ostiga bolalarning o'zi ilsin."},
{h:"Bir oila — to'rt tenglik",sum:"3, 4, 12 — bir oila: 3·4=12, 4·3=12, 12:3=4, 12:4=3.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ko'paytirish va bo'lish — <b>teskari</b> amallar. Uchta son bitta oila tuzadi.</p>",btns:[phaser(P2)],
 after:"<p>Uchburchakda bitta sonni yopsak, qolgan ikkitasidan topamiz: <b>tepadagi</b> son yopilsa — ko'paytiramiz, <b>pastdagi</b> yopilsa — bo'lamiz.</p>",
 q:{t:"7 · 8 = 56. Qaysi tenglik shu oiladan?",opts:["56 : 8 = 7","56 : 7 = 9","8 : 7 = 56","56 · 7 = 8"],ok:0,why:"56 : 8 = 7 — to'g'ri.",hint:"Ko'paytmani bitta ko'paytuvchiga bo'lsak, ikkinchisi chiqadi.",full:"Oila: 7·8=56, 8·7=56, 56:7=8, 56:8=7. «56 : 7 = 9» — hisob xatosi."},
 tn:"Singapur «fact family» uchburchagi: qog'ozdan uchburchak kesib, burchaklariga son yozing va bittasini barmoq bilan yoping."},
{h:"Noma'lum ko'paytuvchi",sum:"□ · 4 = 28 → □ = 28 : 4 = 7.",a:"m03",start:function(){c8tri(28,'□',4,1);W3msg('□ · 4 = 28. Qanday topamiz?')},fin:function(){c8tri(28,7,4,1);W3msg('□ = 28 : 4 = 7')},
 html:"<p><b>□ · 4 = 28</b>. Qaysi amal bilan topiladi?</p>",
 btns:[["28 : 4",function(c,done){c8tri(28,7,4,1);W3msg('To‘g‘ri! Noma’lum ko‘paytuvchi = ko‘paytma : ma’lum ko‘paytuvchi = <b>7</b>');done()}],["28 · 4",function(){W3msg('Yo‘q: 112 · 4 = 448, 28 emas','Qayta tanlang')}],["28 − 4",function(){W3msg('Yo‘q: bu qo‘shishning teskarisi. 24 · 4 = 96','Qayta tanlang')}]],g3:1,
 after:"<p><b>Noma'lum ko'paytuvchini topish uchun ko'paytmani ma'lum ko'paytuvchiga bo'lamiz.</b> Tekshiruv: 7 · 4 = 28 ✓.</p>",
 q:{t:"9 · □ = 63. □ = ?",opts:["7","54","72","567"],ok:0,why:"63 : 9 = 7.",hint:"Ko'paytmani ma'lum ko'paytuvchiga bo'ling.",full:"□ = 63 : 9 = 7, tekshiruv 9·7=63. «54» — ayirilgan, «567» — ko'paytirilgan."},
 tn:"Har tenglamadan keyin «tekshiruv» qatorini yozish odatini shakllantiring."},
{h:"Noma'lum bo'linuvchi",sum:"□ : 6 = 8 → □ = 8 · 6 = 48.",a:"m04",start:function(){W3eq(['□ : 6 = 8']);W3msg('Bo‘linuvchi noma’lum. Tanlang:')},fin:function(){W3eq(['□ : 6 = 8','□ = 8 · 6 = [48]'])},
 html:"<p><b>□ : 6 = 8</b>. Qaysi son 6 ga bo'linganda 8 chiqadi?</p>",
 btns:[["8 · 6",c8pick('□ : 6 = 8','□ = 8 · 6 = [48]',48,'Bo‘linuvchi = bo‘linma · bo‘luvchi. Tekshiruv: 48 : 6 = 8 ✓')],["8 : 6",c8bad('□ : 6 = 8','8 : 6 butun son chiqmaydi. Bo‘linuvchi bo‘linmadan katta bo‘ladi')],["8 + 6",c8bad('□ : 6 = 8','14 : 6 = 8 emas')]],g3:1,
 after:"<p><b>Noma'lum bo'linuvchi = bo'linma · bo'luvchi.</b> Bo'lish — ko'paytirishning teskarisi: «8 ta oltilik — 48».</p>",
 q:{t:"□ : 7 = 9. □ = ?",opts:["63","2","16","56"],ok:0,why:"9 · 7 = 63.",hint:"Bo'linma bilan bo'luvchini ko'paytiring.",full:"□ = 9 · 7 = 63, tekshiruv 63 : 7 = 9. «2» — 9 dan 7 ayirilgan, «16» — qo'shilgan."},
 tn:"Bar model chizing: 6 ta teng bo'lak, har biri 8 — butun nechaga teng?"},
{h:"Noma'lum bo'luvchi",sum:"56 : □ = 7 → □ = 56 : 7 = 8.",a:"m05",start:function(){W3eq(['56 : □ = 7']);W3msg('Endi bo‘luvchi noma’lum')},fin:function(){W3eq(['56 : □ = 7','□ = 56 : 7 = [8]'])},
 html:"<p><b>56 : □ = 7</b>. Bu yerda ko'paytirish emas!</p>",
 btns:[["56 : 7",c8pick('56 : □ = 7','□ = 56 : 7 = [8]',8,'Bo‘luvchi = bo‘linuvchi : bo‘linma. Tekshiruv: 56 : 8 = 7 ✓')],["56 · 7",c8bad('56 : □ = 7','56 : 392 = 7 bo‘lmaydi. Noma’lum bo‘linuvchi bo‘lsa ko‘paytirardik — bu yerda bo‘luvchi')],["56 − 7",c8bad('56 : □ = 7','56 : 49 = 7 emas')]],g3:1,
 after:"<p><b>Noma'lum bo'luvchi = bo'linuvchi : bo'linma.</b> Diqqat: bo'linuvchi noma'lum bo'lsa — ko'paytiramiz, bo'luvchi noma'lum bo'lsa — <b>bo'lamiz</b>.</p>",
 q:{t:"72 : □ = 8. □ = ?",opts:["9","576","64","80"],ok:0,why:"72 : 8 = 9.",hint:"Bo'linuvchini bo'linmaga bo'ling.",full:"□ = 72 : 8 = 9, tekshiruv 72 : 9 = 8. «576» — eng ko'p uchraydigan xato: bo'linuvchi qoidasini qo'llash."},
 tn:"Ikki qoidani yonma-yon doskaga yozing: □ : 6 = 8 va 48 : □ = 8 — farqini bolalar aytsin."},
{h:"Tuzoq: qaysi qoida?",sum:"□ : 9 = 9 → 81; 81 : □ = 9 → 9; □ · 9 = 81 → 9.",a:"m06",start:function(){W3eq(['A) □ : 9 = 9','B) 81 : □ = 9','C) □ · 9 = 81'],{fs:22})},fin:function(){W3eq(['A) □ = [81]','B) □ = [9]','C) □ = [9]'],{fs:22})},
 html:"<p>Uch tenglama bir-biriga o'xshaydi, lekin javoblari har xil. Har birini yeching:</p>",
 btns:[["A",function(c,done){W3eq(['A) □ : 9 = 9','□ = 9 · 9 = [81]'],{fs:22});W3msg('Bo‘linuvchi noma’lum — ko‘paytiramiz');mvK(done,3)}],["B",function(c,done){W3eq(['B) 81 : □ = 9','□ = 81 : 9 = [9]'],{fs:22});W3msg('Bo‘luvchi noma’lum — bo‘lamiz');mvK(done,3)}],["C",function(c,done){W3eq(['C) □ · 9 = 81','□ = 81 : 9 = [9]'],{fs:22});W3msg('Ko‘paytuvchi noma’lum — bo‘lamiz');mvK(done,3)}]],g3:1,
 after:"<p>Avval <b>□ qaysi komponent</b> ekanini aniqlang, keyin qoidani tanlang. A da «□ : 9 = 9 → 1» deb yozish — eng ko'p xato.</p>",
 q:{t:"□ : 8 = 8. □ = ?",opts:["64","1","0","16"],ok:0,why:"8 · 8 = 64.",hint:"□ — bo'linuvchi.",full:"Bo'linuvchi = bo'linma · bo'luvchi = 8 · 8 = 64. «1» — 8 : 8, bu bo'luvchi qoidasi."},
 tn:"Bolalar har tenglama yoniga □ ning nomini (ko'paytuvchi / bo'linuvchi / bo'luvchi) yozib chiqsin."},
{h:"Murakkab: ifodali tenglama",sum:"□ · 3 = 30 − 6 → □ · 3 = 24 → □ = 8; (□ : 4) · 2 = 10 → □ = 20.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p><b>(□ : 4) · 2 = 10</b>. Qavs ichini bitta «quti» deb qarang va qadamma-qadam yeching.</p>",btns:[phaser(P7)],
 after:"<p>Murakkab tenglamani <b>tashqaridan ichkariga</b> yechamiz. O'ng tomonda ifoda bo'lsa (□ · 3 = 30 − 6), <b>avval uni hisoblaymiz</b>: □ · 3 = 24, □ = 8.</p>",
 q:{t:"□ · 5 = 50 − 15. □ = ?",opts:["7","35","10","3"],ok:0,why:"50 − 15 = 35, 35 : 5 = 7.",hint:"Avval o'ng tomonni hisoblang.",full:"50 − 15 = 35; □ · 5 = 35; □ = 7. «35» — o'ng tomonni hisoblab, bo'lishni unutgan. «10» — 50 : 5, ayirishni tashlab ketgan."},
 tn:"Qavsni qog'oz quti bilan yoping — bola qutining ichida nima borligini topsin, keyin qutini ochsin."},
{h:"Masala: bar model",sum:"5 ta qutida teng miqdorda 40 ta qalam → □ · 5 = 40 → □ = 8.",a:"m08",start:function(){c8bar(5,'?',40,'5 quti — jami 40 ta qalam')},fin:function(){c8bar(5,8,40,'□ · 5 = 40 → □ = 8')},
 html:"<p>5 ta qutiga teng miqdorda jami 40 ta qalam solindi. Bitta qutida nechta?</p>",
 btns:[["Tenglama tuzish",function(c,done){c8bar(5,8,40,'□ · 5 = 40 → □ = 40 : 5 = 8');W3msg('Har bir qutida <b>8</b> ta qalam. Tekshiruv: 8 · 5 = 40 ✓');done()}]],
 after:"<p>Bar modelda butun — <b>ko'paytma</b>, bo'laklar soni va bitta bo'lak — <b>ko'paytuvchilar</b>. Noma'lum bo'lak = butun : bo'laklar soni.</p>",
 q:{t:"Bir nechta qutiga 6 tadan olma solindi, jami 54 ta. Nechta quti?",opts:["9","48","60","324"],ok:0,why:"□ · 6 = 54, □ = 9.",hint:"Qutilar soni · 6 = 54.",full:"□ · 6 = 54 → □ = 54 : 6 = 9 quti. «48» va «60» — ayirish/qo'shish, «324» — ko'paytirish."},
 tn:"Masalani avval chizma bilan, keyin tenglama bilan yozish — Singapur usuli."},
{h:"Bilasizmi? Al-Xorazmiy",sum:"«Algebra» so'zi al-Xorazmiyning «al-jabr» kitobi nomidan kelib chiqqan.",a:"m09",start:function(){W3eq(['al-jabr → algebra','al-Xorazmiy → algoritm'],{fs:20});W3msg('Vatandoshimiz — Muhammad ibn Muso al-Xorazmiy (IX asr)')},fin:function(){STEPS[8].start()},
 html:"<p>📜 IX asrda Bag'dodda ishlagan vatandoshimiz <b>Muhammad ibn Muso al-Xorazmiy</b> noma'lumni topish usullari haqida kitob yozgan. Kitob nomidagi <b>«al-jabr»</b> so'zidan butun fan nomi — <b>algebra</b> kelib chiqdi.</p><p>⭐ Uning ismi esa <b>«algoritm»</b> so'ziga aylangan — kompyuter dasturlari ham shu so'z bilan ataladi!</p>",
 tn:"Bu fakt «Yosh Xorazmiylar» nomi bilan bog'liq — bolalarga g'urur hissini bering."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){c8tri(12,3,4);W3msg('Tepada yopilsa — ko‘paytir, pastda yopilsa — bo‘l')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>ko'paytuvchi · ko'paytuvchi = ko'paytma; bo'linuvchi : bo'luvchi = bo'linma.</li><li>Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi (□ · 4 = 28 → 7).</li><li>Noma'lum bo'linuvchi = bo'linma · bo'luvchi (□ : 6 = 8 → 48).</li><li>Noma'lum bo'luvchi = bo'linuvchi : bo'linma (56 : □ = 7 → 8).</li><li>O'ng tomonda ifoda bo'lsa — avval uni hisoblang.</li><li>Doim tekshiring: topilgan sonni tenglamaga qo'ying.</li></ul></div>",
 tn:"Keyingi mavzu: ko'paytirish xossalari — o'rin almashtirish, guruhlash, taqsimot."}
];
var PROBS=[
{t:"8 · 6 = 48. 48 — bu nima?",o:["ko'paytma","ko'paytuvchi","bo'linma","bo'linuvchi"],k:0,s:"Ko'paytirish natijasi — ko'paytma."},
{t:"36 : 4 = 9. Bo'linuvchi qaysi?",o:["36","4","9","32"],k:0,s:"Bo'linadigan son — 36."},
{t:"□ · 6 = 42. □ = ?",o:["7","36","48","252"],k:0,s:"42 : 6 = 7."},
{t:"□ : 5 = 9. □ = ?",o:["45","4","14","40"],k:0,s:"9 · 5 = 45."},
{t:"48 : □ = 6. □ = ?",o:["8","288","42","54"],k:0,s:"48 : 6 = 8."},
{t:"7 · □ = 0. □ = ?",o:["0","7","1","70"],k:0,s:"Faqat 7 · 0 = 0."},
{t:"6 · 9 = 54 oilasidan qaysi tenglik?",o:["54 : 9 = 6","54 : 6 = 8","9 : 6 = 54","54 · 9 = 6"],k:0,s:"54 : 9 = 6."},
{t:"□ : 9 = 9. □ = ?",o:["81","1","0","18"],k:0,s:"9 · 9 = 81."},
{t:"□ : 1 = 47. □ = ?",o:["47","1","48","46"],k:0,s:"47 · 1 = 47."},
{t:"Bo'linma 8, bo'luvchi 7. Bo'linuvchi = ?",o:["56","1","15","63"],k:0,s:"8 · 7 = 56."},
{t:"Ko'paytma 72, bitta ko'paytuvchi 9. Ikkinchisi = ?",o:["8","63","81","648"],k:0,s:"72 : 9 = 8."},
{t:"□ · 4 = 20 + 8. □ = ?",o:["7","28","5","112"],k:0,s:"20 + 8 = 28, 28 : 4 = 7."},
{t:"□ : 3 = 18 − 10. □ = ?",o:["24","8","2","54"],k:0,s:"18 − 10 = 8, 8 · 3 = 24."},
{t:"63 : □ = 3 · 3. □ = ?",o:["7","9","21","567"],k:0,s:"3 · 3 = 9, 63 : 9 = 7."},
{t:"(□ : 2) · 3 = 12. □ = ?",o:["8","4","2","72"],k:0,s:"□ : 2 = 4, □ = 8."},
{t:"(□ · 3) : 6 = 4. □ = ?",o:["8","24","2","72"],k:0,s:"□ · 3 = 24, □ = 8."},
{t:"Bir nechta qatorga 7 tadan stul qo'yildi, jami 56 ta. Nechta qator?",o:["8","49","63","392"],k:0,s:"□ · 7 = 56, □ = 8."},
{t:"Sonni 6 ga bo'lib, 4 ga ko'paytirsak 24 chiqdi. Son qaysi?",o:["36","6","16","144"],k:0,s:"24 : 4 = 6, 6 · 6 = 36."},
{t:"Qaysi tenglamaning yechimi eng katta?",o:["□ : 4 = 6","□ · 4 = 24","24 : □ = 4","□ · 6 = 24"],k:0,s:"24; 6; 6; 4."},
{t:"Bo'linuvchi bo'luvchidan 4 marta katta, bo'luvchi 9. Bo'linma = ?",o:["4","36","9","13"],k:0,s:"Bo'linuvchi 36, 36 : 9 = 4."}
];
function PRACT_STAGE(){c8tri(12,3,4);W3msg('Qaysi son noma’lum? Shunga qarab qoidani tanlang')}
var PREP_DATA={teach:["Ko'paytirish va bo'lish komponentlari nomlari.","Bir oila — to'rt tenglik (uchburchak).","Noma'lum ko'paytuvchi, bo'linuvchi, bo'luvchini topish.","O'ng tomonda ifodali va qavsli tenglamalar, matnli masala."],
 mist:["56 : □ = 7 → □ = 392 (bo'linuvchi qoidasini qo'llaydi).","□ : 9 = 9 → 1.","□ · 3 = 30 − 6 da ayirishni tashlab ketadi.","Komponent nomlarini adashtiradi (bo'luvchi ↔ bo'linuvchi)."],
 need:["Komponent nomlari yozilgan kartochkalar.","Qog'oz uchburchak (fact family), qog'oz «quti» qavs uchun."],
 board:["<span class='w2'>3 · 4 = 12</span>, <span class='w2'>12 : 3 = 4</span>","<span class='w2'>□ · 4 = 28 → □ = 7</span>","<span class='w2'>□ : 6 = 8 → □ = 48</span>","<span class='w2'>56 : □ = 7 → □ = 8</span>","<span class='w2'>(□ : 4) · 2 = 10 → □ = 20</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
