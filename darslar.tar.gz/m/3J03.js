var CODE='3J03',TITLE='3-sinf · Shakllarni sanash';
var J3L='ABCDE';
function J3pts(){var g=S.g;E('line',{x1:30,y1:120,x2:330,y2:120,stroke:C.line,'stroke-width':2},g);for(var i=0;i<5;i++){E('circle',{cx:50+i*65,cy:120,r:6,fill:C.blue},g);T(g,50+i*65,146,J3L[i],{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}}
function J3arcs(from,upto){var g=S.g,cols=[C.a,C.b,C.c,'#9bd08a'];for(var i=from;i<upto;i++)for(var j=i+1;j<5;j++){var xa=50+i*65,xb=50+j*65,h=12+(j-i)*20;E('path',{d:'M'+xa+' 114 Q'+((xa+xb)/2)+' '+(114-h*1.6)+' '+xb+' 114',fill:'none',stroke:cols[i],'stroke-width':2.4},g)}}
var P1=[function(){clear();J3pts();Y3msg('Chiziqda 5 ta nuqta. Nechta kesma bor? (AB, AC, …)')},
 function(){clear();J3pts();J3arcs(0,1);Y3msg('A dan boshlanadiganlar: AB, AC, AD, AE — <b>4</b> ta')},
 function(){clear();J3pts();J3arcs(0,2);Y3msg('B dan (o‘ngga): BC, BD, BE — <b>3</b> ta (BA allaqachon sanalgan)')},
 function(){clear();J3pts();J3arcs(0,4);Y3msg('C dan: 2 ta, D dan: 1 ta. Jami: 4 + 3 + 2 + 1 = <b>10</b>')}];
// uchburchak va asosdagi nuqtalar
function J3tri(hl){var g=S.g,ax=180,ay=14,xs=[40,96,152,208,264,320],by=140,cols=['#fde6c8','#d8efe9','#e5e0f6','#fbdada','#dcebf8'];
 (hl||[]).forEach(function(p,k){E('path',{d:'M'+ax+' '+ay+' L'+xs[p[0]]+' '+by+' L'+xs[p[1]]+' '+by+' Z',fill:cols[k%5],stroke:'none'},g)});
 xs.forEach(function(x){E('line',{x1:ax,y1:ay,x2:x,y2:by,stroke:C.line,'stroke-width':1.8},g)});E('line',{x1:40,y1:by,x2:320,y2:by,stroke:C.line,'stroke-width':1.8},g);
 xs.forEach(function(x,i){T(g,x,by+16,String(i+1),{'font-size':11,'font-weight':700,fill:'#5b6b7b'})})}
var P2=[function(){clear();J3tri();Y3msg('Uchidan asosga 4 ta kesma o‘tkazilgan. Nechta uchburchak bor?')},
 function(){clear();J3tri([[0,1],[1,2],[2,3],[3,4],[4,5]]);Y3msg('Asosi <b>1 bo‘lakli</b> uchburchaklar: 5 ta')},
 function(){clear();J3tri([[0,2]]);Y3msg('Asosi <b>2 bo‘lakli</b>: 1–3, 2–4, 3–5, 4–6 → 4 ta')},
 function(){clear();J3tri([[0,5]]);Y3msg('3 bo‘lakli 3 ta, 4 bo‘lakli 2 ta, butuni 1 ta. Jami: 5+4+3+2+1 = <b>15</b>')}];
// katak to'r
function J3grid(x,y,r,c,s,hl,col){var g=S.g;for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('rect',{x:x+j*s,y:y+i*s,width:s,height:s,fill:'#fff',stroke:'#9aa9b8','stroke-width':1},g);
 (hl||[]).forEach(function(h){E('rect',{x:x+h[1]*s+1.5,y:y+h[0]*s+1.5,width:h[3]*s-3,height:h[2]*s-3,fill:col||'rgba(245,158,66,.55)',stroke:C.bad,'stroke-width':2},g)})}
function J3sq(k){S.d=S.d||{};S.d[k]=1;clear();var g=S.g;
 if(k===1){J3grid(130,30,3,3,34,[[0,0,1,1],[0,1,1,1],[0,2,1,1],[1,0,1,1],[1,1,1,1],[1,2,1,1],[2,0,1,1],[2,1,1,1],[2,2,1,1]]);Y3msg('1×1 kvadratlar: <b>9</b> ta')}
 if(k===2){[[0,0],[0,1],[1,0],[1,1]].forEach(function(p,i){J3grid(22+i*84,50,3,3,22,[[p[0],p[1],2,2]])});Y3msg('2×2 kvadratlar: <b>4</b> ta (ustma-ust tushadi!)')}
 if(k===3){J3grid(130,30,3,3,34,[[0,0,3,3]]);Y3msg('3×3 — butun shakl: <b>1</b> ta')}
 if(S.d[1]&&S.d[2]&&S.d[3])Y3msg('Jami: 9 + 4 + 1 = <b>14</b> ta kvadrat')}
// 2x3 to'g'ri to'rtburchaklar
function J3rg(vh,hh,r){clear();var g=S.g,x=105,y=30,s=50;J3grid(x,y,2,3,s,r?[r]:null,'rgba(18,163,159,.35)');
 if(vh)for(var j=0;j<4;j++)E('line',{x1:x+j*s,y1:y-8,x2:x+j*s,y2:y+2*s+8,stroke:C.blue,'stroke-width':3},g);
 if(hh)for(var i=0;i<3;i++)E('line',{x1:x-8,y1:y+i*s,x2:x+3*s+8,y2:y+i*s,stroke:C.bad,'stroke-width':3},g)}
var P4=[function(){J3rg(0,0,[0,0,1,2]);Y3msg('2×3 to‘rda nechta to‘g‘ri to‘rtburchak bor? (kvadratlar ham hisob)')},
 function(){J3rg(1,0);Y3msg('Chap va o‘ng tomon — 4 ta ko‘k chiziqdan 2 tasi: 3+2+1 = <b>6</b> usul')},
 function(){J3rg(0,1);Y3msg('Tepa va past tomon — 3 ta qizil chiziqdan 2 tasi: 2+1 = <b>3</b> usul')},
 function(){J3rg(1,1,[0,1,2,2]);Y3msg('Har juftlik bitta to‘rtburchak beradi: 6 · 3 = <b>18</b>')}];
function J3box(diag2,mid){var g=S.g,x=120,y=27,s=120;E('rect',{x:x,y:y,width:s,height:s,fill:'#fff',stroke:C.line,'stroke-width':2.4},g);
 E('line',{x1:x,y1:y+s,x2:x+s,y2:y,stroke:C.line,'stroke-width':2.4},g);
 if(diag2)E('line',{x1:x,y1:y,x2:x+s,y2:y+s,stroke:C.line,'stroke-width':2.4},g);
 if(mid){E('line',{x1:x+s/2,y1:y,x2:x+s/2,y2:y+s,stroke:C.line,'stroke-width':2.4},g);E('line',{x1:x,y1:y+s/2,x2:x+s,y2:y+s/2,stroke:C.line,'stroke-width':2.4},g)}}
function J3poly(pts,col){E('path',{d:'M'+pts.map(function(p){return p[0]+' '+p[1]}).join(' L')+' Z',fill:col,stroke:'none'},S.g)}
function J3d2(){clear();var x=120,y=27,s=120,c=[x+s/2,y+s/2];J3poly([[x,y],[x+s,y],c],'#fde6c8');J3poly([[x,y+s],[x+s,y+s],[x+s,y]],'rgba(31,111,178,.22)');J3box(1);
 T(S.g,300,70,'4 kichik',{'font-size':12,'font-weight':800,fill:C.a});T(S.g,300,92,'+ 4 yarim',{'font-size':12,'font-weight':800,fill:C.blue});T(S.g,300,116,'= 8',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
 Y3msg('4 ta kichik uchburchak + har diagonal 2 tadan katta: 4 + 4 = <b>8</b>')}
function J3md(){clear();var x=120,y=27,s=120,h=s/2;J3poly([[x+h,y+h],[x+s,y+h],[x+s,y]],'#fde6c8');J3poly([[x+h,y+h],[x+h,y],[x+s,y]],'#fde6c8');J3poly([[x,y+s],[x+h,y+s],[x+h,y+h]],'#d8efe9');J3poly([[x,y+s],[x,y+h],[x+h,y+h]],'#d8efe9');J3box(0,1);
 T(S.g,300,80,'4 kichik',{'font-size':12,'font-weight':800,fill:C.a});T(S.g,300,104,'+ 2 katta',{'font-size':12,'font-weight':800,fill:C.blue});T(S.g,300,128,'= 6',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
 Y3msg('Diagonal kesgan 2 katakda 4 ta kichik + diagonal ajratgan 2 ta katta = <b>6</b>')}
// doira va kesimlar
function J3chord(px,py,qx,qy){var cx=180,cy=85,r=70,dx=qx-px,dy=qy-py,fx=px-cx,fy=py-cy,a=dx*dx+dy*dy,b=2*(fx*dx+fy*dy),c=fx*fx+fy*fy-r*r,D=Math.sqrt(b*b-4*a*c),t1=(-b-D)/(2*a),t2=(-b+D)/(2*a);
 E('line',{x1:px+t1*dx,y1:py+t1*dy,x2:px+t2*dx,y2:py+t2*dy,stroke:'#7a4b16','stroke-width':2.6},S.g)}
function J3pizza(kind){S.d=S.d||{};S.d[kind]=1;clear();var g=S.g;E('circle',{cx:180,cy:85,r:70,fill:'#f6d38a',stroke:'#c98b2a','stroke-width':3},g);
 if(kind==='m'){J3chord(180,15,180,155);J3chord(120,50,240,120);J3chord(120,120,240,50);T(g,310,90,'6',{'font-size':26,'font-weight':800,fill:C.blue});Y3msg('Hammasi markazdan o‘tsa: <b>6</b> bo‘lak')}
 else{J3chord(150,100,210,100);J3chord(150,100,190,60);J3chord(210,100,170,60);T(g,310,90,'7',{'font-size':26,'font-weight':800,fill:C.ok});Y3msg('Har kesim qolgan ikkalasini <b>har xil</b> nuqtada kesadi: <b>7</b> bo‘lak — eng ko‘pi')}}
function J3cube(show){clear();var g=S.g,x=130,y=50,s=70,o=30;E('path',{d:'M'+x+' '+y+' l'+s+' 0 l0 '+s+' l-'+s+' 0 Z',fill:'#dcebf8',stroke:C.line,'stroke-width':2},g);
 E('path',{d:'M'+x+' '+y+' l'+o+' -'+o+' l'+s+' 0 l-'+o+' '+o+' Z',fill:'#eef6fd',stroke:C.line,'stroke-width':2},g);E('path',{d:'M'+(x+s)+' '+y+' l'+o+' -'+o+' l0 '+s+' l-'+o+' '+o+' Z',fill:'#c6ddf2',stroke:C.line,'stroke-width':2},g);
 if(show){T(g,300,60,'yoq: 6',{'font-size':13,'font-weight':800,fill:C.blue});T(g,300,84,'uch: 8',{'font-size':13,'font-weight':800,fill:C.a});T(g,300,108,'qirra: 12',{'font-size':13,'font-weight':800,fill:C.bad});T(g,300,140,'6 + 8 − 12 = 2',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}
 Y3msg(show?'Eyler formulasi: <b>yoqlar + uchlar − qirralar = 2</b>':'Kubni sanang: nechta yoq, uch, qirra?')}
var STEPS=[
{h:"Kesmalarni sanash",sum:"5 nuqtali chiziqda kesmalar: 4 + 3 + 2 + 1 = 10. Har nuqtadan faqat o'ngga sanaymiz.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Chiziqda 5 ta nuqta belgilangan. Ular orasida <b>nechta kesma</b> bor? Tartib bilan sanaymiz — hech birini tashlab ketmaslik va ikki marta sanamaslik uchun.</p>",btns:[phaser(P1)],
 after:"<p>Usul: har nuqtadan faqat <b>o'ng tomonga</b> sanang. 4 + 3 + 2 + 1 = <b>10</b>. «AB» va «BA» — bitta kesma, uni ikki marta sanamang.</p>",
 q:{t:"Chiziqda 6 ta nuqta bor. Nechta kesma hosil bo'ladi?",opts:["6","15","5","30"],ok:1,why:"5 + 4 + 3 + 2 + 1 = 15.",hint:"Birinchi nuqtadan nechta kesma chiqadi? Keyingisidan-chi?",full:"1-nuqtadan o'ngga 5 ta, 2-dan 4 ta, … : 5 + 4 + 3 + 2 + 1 = 15. «5» — faqat qo'shni nuqtalar orasidagi kesmalar. «30» — har kesma ikki marta (AB va BA) sanalgan."},
 tn:"Doskada nuqtalarni harf bilan belgilab, kesmalarni ro'yxat qilib yozdiring: AB, AC, … — tizimli sanash odati shakllanadi."},
{h:"Uchburchaklarni sanash",sum:"Uchidan 4 kesma → asosda 6 nuqta → asosdagi kesmalar soni: 5+4+3+2+1 = 15 uchburchak.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Uchburchakning uchidan asosiga 4 ta kesma o'tkazilgan. Rasmda nechta uchburchak bor? Asosining kattaligi bo'yicha guruhlab sanaymiz.</p>",btns:[phaser(P2)],
 after:"<p>Har uchburchak asosdagi <b>bitta kesmaga</b> mos keladi. Asosda 6 nuqta → 5 + 4 + 3 + 2 + 1 = <b>15</b> kesma → 15 uchburchak. Ko'rinmaydigan katta uchburchaklarni unutmang!</p>",
 q:{t:"Uchidan asosga 2 ta kesma o'tkazilgan. Nechta uchburchak bor?",opts:["3","6","4","5"],ok:1,why:"Asosda 4 nuqta: 3 + 2 + 1 = 6.",hint:"Asosda nechta nuqta bor? Ular orasida nechta kesma?",full:"Asosdagi nuqtalar: 2 uchi + 2 ta kesma uchi = 4 nuqta. Kesmalar: 3 + 2 + 1 = 6 → 6 uchburchak. «3» — faqat eng kichiklari sanalgan; «4» — butun uchburchak qo'shilgan, lekin o'rtachalari unutilgan."},
 tn:"Shaklni qog'ozga chizib, har uchburchakni alohida rangli qalam bilan aylantirib chiqish mumkin. Bu masala kesmalar masalasining aynan o'zi ekanini bola o'zi topsin."},
{h:"Kvadratlarni sanash",sum:"3×3 to'rda: 1×1 — 9, 2×2 — 4, 3×3 — 1. Jami 14.",a:"m03",start:function(){S.d={};clear();J3grid(130,30,3,3,34);Y3msg('3×3 to‘rda nechta kvadrat bor? Har o‘lchamni bosing')},fin:function(){S.d={1:1,2:1};J3sq(3)},
 html:"<p>3×3 katakli to'rda nechta <b>kvadrat</b> bor? «9» deb shoshilmang! Uch xil o'lchamdagi kvadratlarni alohida sanang — har tugmani bosing.</p>",
 btns:[["1×1",function(c,done){J3sq(1);if(S.d[1]&&S.d[2]&&S.d[3])done()}],["2×2",function(c,done){J3sq(2);if(S.d[1]&&S.d[2]&&S.d[3])done()}],["3×3",function(c,done){J3sq(3);if(S.d[1]&&S.d[2]&&S.d[3])done()}]],g3:1,
 after:"<p>9 + 4 + 1 = <b>14</b>. Qonuniyat: 1×1 — 3·3, 2×2 — 2·2, 3×3 — 1·1. 4×4 to'rda: 16 + 9 + 4 + 1 = <b>30</b>.</p>",
 q:{t:"2×2 katakli to'rda nechta kvadrat bor?",opts:["4","5","6","8"],ok:1,why:"4 ta kichik + 1 ta katta = 5.",hint:"Katta kvadratni ham sanadingizmi?",full:"1×1 kvadratlar — 4 ta, 2×2 — butun shaklning o'zi, 1 ta. Jami 5. «4» — katta kvadrat unutilgan."},
 tn:"Shaffof plyonkadan yoki qog'ozdan 2×2 «ramka» qirqib, to'r ustida siljitib sanash — bola ustma-ust tushgan kvadratlarni o'z ko'zi bilan ko'radi."},
{h:"To'g'ri to'rtburchaklar",sum:"2×3 to'r: tik chiziqlardan 2 tasini tanlash — 6 usul, yotiq chiziqlardan — 3 usul: 6 · 3 = 18.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>2 qator, 3 ustunli to'rda nechta <b>to'g'ri to'rtburchak</b> bor? Bittalab sanash qiyin — chegara chiziqlarini tanlash bilan sanaymiz.</p>",btns:[phaser(P4)],
 after:"<p>Har to'g'ri to'rtburchakni 2 ta tik va 2 ta yotiq chiziq belgilaydi. Tik juftlar: 6, yotiq juftlar: 3 → <b>6 · 3 = 18</b>. Kvadratlar ham shu 18 ichida.</p>",
 q:{t:"1 qator, 4 katakli tasmada nechta to'g'ri to'rtburchak bor?",opts:["4","10","7","8"],ok:1,why:"5 ta tik chiziqdan 2 tasi: 4 + 3 + 2 + 1 = 10.",hint:"Tasmada nechta tik chiziq bor? Ulardan 2 tasini necha usulda tanlash mumkin?",full:"4 katakli tasmada 5 ta tik chiziq. Ikkitasini tanlash: 4 + 3 + 2 + 1 = 10. «4» — faqat bitta kataklilari sanalgan."},
 tn:"Bu — kesmalar masalasining ikki o'lchamli ko'rinishi. Bolaga oldingi qadamni eslating: «tasma — bu chiziqdagi nuqtalar»."},
{h:"Tuzoq: diagonallar",sum:"Kvadrat va ikki diagonal: 4 ta kichik + 4 ta yarim = 8 uchburchak.",a:"m05",start:function(){clear();J3box(1);Y3msg('Kvadratga ikkala diagonal o‘tkazildi. Nechta uchburchak bor?')},fin:function(){J3d2()},
 html:"<p>Kvadratga ikkala <b>diagonali</b> o'tkazildi. Rasmda jami nechta uchburchak bor? Javobni tanlang.</p>",
 btns:Y3ch(["4","6","8","10"],2,function(){J3d2()},'Katta uchburchaklar ham bor — har diagonal kvadratni 2 ga bo‘ladi'),g2:1,
 after:"<p>Kichik uchburchaklar — 4 ta. Har diagonal kvadratni 2 ta katta uchburchakka bo'ladi: 2 · 2 = 4. Jami <b>8</b>.</p>",
 q:{t:"Kvadratga bitta diagonal o'tkazildi. Nechta uchburchak bor?",opts:["1","2","4","3"],ok:1,why:"Diagonal kvadratni 2 ta uchburchakka bo'ladi.",hint:"Diagonal kvadratni nechta qismga bo'ladi?",full:"Bitta diagonal — 2 ta uchburchak. Kvadratning o'zi uchburchak emas, shuning uchun 3 emas."},
 tn:"Bolalar har topgan uchburchagini uchlari bilan yozsin (masalan, ABO). Yozib sanash — takrorlashdan saqlaydi."},
{h:"Tuzoq: o'rta chiziqlar",sum:"Kvadrat, ikki o'rta chiziq va bitta diagonal: 4 ta kichik + 2 ta katta = 6 uchburchak.",a:"m06",start:function(){clear();J3box(0,1);Y3msg('O‘rta chiziqlar va bitta diagonal. Nechta uchburchak?')},fin:function(){J3md()},
 html:"<p>Kvadrat ikki <b>o'rta chiziq</b> bilan 4 katakka bo'lingan va bitta diagonal o'tkazilgan. Nechta uchburchak bor?</p>",
 btns:Y3ch(["4","5","6","8"],2,function(){J3md()},'Diagonal butun kvadratni ham 2 ga bo‘ladi — katta uchburchaklarni unutmang'),g2:1,
 after:"<p>Diagonal faqat 2 ta katakni kesadi: 4 ta kichik uchburchak. Butun kvadratni esa 2 ta katta uchburchakka bo'ladi. Jami <b>6</b>. O'rta chiziqlar markazda diagonal bilan bitta nuqtada kesishadi — u yerda yangi uchburchak hosil bo'lmaydi.</p>",
 q:{t:"Kvadrat 4 katakka bo'lingan, ikkala diagonal ham o'tkazilgan. Diagonal kesmagan katak bormi?",opts:["Ha, 2 ta","Yo'q, har katak kesilgan","Ha, 1 ta","Ha, 4 ta"],ok:1,why:"1-diagonal 2 ta katakni, 2-diagonal qolgan 2 ta katakni kesadi.",hint:"Har diagonal qaysi kataklardan o'tadi?",full:"Bir diagonal chap-yuqori va o'ng-past kataklardan, ikkinchisi o'ng-yuqori va chap-past kataklardan o'tadi. Demak, har katak kesilgan."},
 tn:"Shaklni katta qilib doskaga chizing; bola uchburchakni topganda bo'r bilan bo'yasin."},
{h:"Pishiriqni kesish",sum:"3 ta to'g'ri kesim: markazdan o'tsa — 6 bo'lak, hammasi har xil nuqtada kesishsa — 7 bo'lak (eng ko'pi).",a:"m07",start:function(){S.d={};clear();E('circle',{cx:180,cy:85,r:70,fill:'#f6d38a',stroke:'#c98b2a','stroke-width':3},S.g);Y3msg('3 ta to‘g‘ri kesim bilan eng ko‘pi nechta bo‘lak?')},fin:function(){J3pizza('x')},
 html:"<p>Dumaloq pishiriqni <b>3 ta to'g'ri kesim</b> bilan kesamiz. Ikki usulni sinab ko'ring: qaysi biri ko'proq bo'lak beradi?</p>",
 btns:[["✳ Markazdan",function(c,done){J3pizza('m');if(S.d.m&&S.d.x)done()}],["△ Har xil joydan",function(c,done){J3pizza('x');if(S.d.m&&S.d.x)done()}]],g2:1,
 after:"<p>Yangi kesim avvalgi kesimlarni qancha ko'p nuqtada kesib o'tsa, shuncha ko'p bo'lak qo'shadi. 1 kesim — 2, 2 ta — 4, 3 ta — <b>7</b>, 4 ta — 11 bo'lak (har safar +2, +3, +4).</p>",
 q:{t:"2 ta to'g'ri kesim bilan eng ko'pi nechta bo'lak olish mumkin?",opts:["3","4","5","6"],ok:1,why:"Ikki kesim pishiriq ichida kesishsa — 4 bo'lak.",hint:"Kesimlar pishiriq ichida kesishsa, nechta bo'lak bo'ladi?",full:"Kesimlar kesishmasa — 3 bo'lak; ichkarida kesishsa — 4. Ikki to'g'ri chiziq faqat bitta nuqtada kesishadi, shuning uchun 4 dan ko'p bo'lmaydi."},
 tn:"Qog'ozdan doira qirqib, chizg'ich bilan chiziq tortdiring. Bolalar 4 kesimda 11 bo'lak olishga urinib ko'rsin."},
{h:"Olimpiada: 4×4 to'r",sum:"4×4 to'rda kvadratlar: 16 + 9 + 4 + 1 = 30.",a:"m08",start:function(){clear();J3grid(112,10,4,4,34);Y3msg('4×4 to‘rda nechta kvadrat bor?')},fin:function(){J3f4()},
 html:"<p>Shaxmat taxtasining bir burchagi — 4×4 katak. Unda jami nechta <b>kvadrat</b> bor?</p>",
 btns:Y3ch(["16","20","25","30"],3,function(){J3f4()},'Har o‘lchamni alohida sanang: 1×1, 2×2, 3×3, 4×4'),g2:1,
 after:"<p>1×1 — 4·4 = 16, 2×2 — 3·3 = 9, 3×3 — 2·2 = 4, 4×4 — 1. Jami <b>30</b>. Butun shaxmat taxtasida (8×8) esa 204 ta kvadrat bor!</p>",
 q:{t:"4×4 to'rda nechta 2×2 kvadrat bor?",opts:["4","9","8","16"],ok:1,why:"2×2 kvadrat har qatorda 3 xil joyda, har ustunda 3 xil: 3 · 3 = 9.",hint:"2×2 ramka gorizontal bo'yicha necha joyga siljiydi?",full:"2×2 ramkani 4 katakli qatorda 3 joyga qo'yish mumkin, ustunda ham 3 joyga: 3 · 3 = 9. «4» — faqat ustma-ust tushmaydiganlari sanalgan."},
 tn:"Shaxmat taxtasi bo'lsa — haqiqiy taxtada 2×2 ramkani siljitib sanang."},
{h:"Bilasizmi? Eyler formulasi",sum:"Kubda yoqlar 6, uchlar 8, qirralar 12: 6 + 8 − 12 = 2. Bu har qanday ko'pyoq uchun to'g'ri (Eyler, XVIII asr).",a:"m09",start:function(){J3cube(0)},fin:function(){J3cube(1)},
 html:"<p>🔷 Shveytsariyalik buyuk matematik <b>Leonard Eyler</b> (XVIII asr) ajoyib qonuniyatni topgan: qavariq ko'pyoqda <b>yoqlar + uchlar − qirralar = 2</b> bo'ladi. Kubda tekshirib ko'ring!</p>",
 btns:[["🔢 Sanash",function(c,done){J3cube(1);done()}]],
 after:"<p>Kub: 6 + 8 − 12 = 2 ✓. Piramida (asosi kvadrat): 5 yoq, 5 uch, 8 qirra → 5 + 5 − 8 = 2 ✓. Shakllarni sanash — chinakam matematikaning boshlanishi!</p>",
 tn:"Kubik, gugurt qutisi yoki piramida modelida bolalar yoqlarni sanab, formulani o'zi tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.d={1:1,2:1};J3sq(3)},fin:function(){S.d={1:1,2:1};J3sq(3)},
 html:"<div class='memo'><ul><li>Shakllarni <b>o'lchami bo'yicha guruhlab</b> sanang: avval eng kichiklari, keyin kattaroqlari.</li><li>Chiziqdagi n ta nuqta: kesmalar = (n−1) + … + 2 + 1.</li><li>Uchidan kesmalar o'tkazilgan uchburchak — asosdagi kesmalar soni bilan bir xil.</li><li>To'rdagi kvadratlar: 3×3 da 9+4+1 = 14, 4×4 da 30.</li><li>To'g'ri to'rtburchaklar: tik juftlar × yotiq juftlar.</li><li>Katta, «ko'rinmaydigan» shakllarni unutmang!</li></ul></div>",
 tn:"Uyga vazifa: daftarga o'z shaklini chizib, undagi uchburchaklar sonini topish va sinfdoshiga berish."}
];
function J3f4(){clear();J3grid(112,10,4,4,34,[[0,0,1,1],[1,1,2,2]]);T(S.g,310,40,'16',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(S.g,310,62,'+ 9',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(S.g,310,84,'+ 4',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(S.g,310,106,'+ 1',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(S.g,310,134,'= 30',{'font-size':15,'font-weight':800,fill:C.ok});Y3msg('16 + 9 + 4 + 1 = <b>30</b> ta kvadrat')}
var PROBS=[
{t:"Chiziqda 4 ta nuqta bor. Nechta kesma hosil bo'ladi?",o:["6","4","3","8"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Kubda nechta qirra bor?",o:["12","8","6","24"],k:0,s:"Tepada 4, pastda 4, yon tomonlarda 4: 12."},
{t:"2×2 katakli to'rda nechta kvadrat bor?",o:["5","4","6","8"],k:0,s:"4 + 1 = 5."},
{t:"1 qator, 3 katakli tasmada nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",o:["6","3","4","5"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Kvadratga ikkala diagonal o'tkazildi. Nechta uchburchak hosil bo'ldi?",o:["8","4","6","10"],k:0,s:"4 kichik + 4 katta = 8."},
{t:"Uchburchak uchidan asosga 2 ta kesma o'tkazildi. Nechta uchburchak bor?",o:["6","3","5","4"],k:0,s:"Asosda 4 nuqta: 3+2+1 = 6."},
{t:"3×3 katakli to'rda nechta 2×2 kvadrat bor?",o:["4","9","1","5"],k:0,s:"2·2 = 4."},
{t:"Chiziqda 6 ta nuqta bor. Nechta kesma hosil bo'ladi?",o:["15","6","12","21"],k:0,s:"5+4+3+2+1 = 15."},
{t:"3×3 katakli to'rda nechta kvadrat bor?",o:["14","9","13","10"],k:0,s:"9 + 4 + 1 = 14."},
{t:"1 qator, 4 katakli tasmada nechta to'g'ri to'rtburchak bor?",o:["10","4","8","7"],k:0,s:"4+3+2+1 = 10."},
{t:"5 kishi bir-biri bilan bir martadan qo'l berib ko'rishdi. Jami nechta qo'l berish bo'ldi?",o:["10","25","20","5"],k:0,s:"4+3+2+1 = 10 (kesmalar masalasining o'zi)."},
{t:"Uchburchak uchidan asosga 3 ta kesma o'tkazildi. Nechta uchburchak bor?",o:["10","4","8","7"],k:0,s:"Asosda 5 nuqta: 4+3+2+1 = 10."},
{t:"Tekislikda 4 ta to'g'ri chiziq eng ko'pi nechta nuqtada kesishadi?",o:["6","4","8","12"],k:0,s:"Har juftlik bitta nuqta: 3+2+1 = 6."},
{t:"Kvadrat ikki o'rta chiziq bilan 4 katakka bo'lingan va bitta diagonal o'tkazilgan. Nechta uchburchak bor?",o:["6","4","5","8"],k:0,s:"4 kichik + 2 katta = 6."},
{t:"2×2 katakli to'rda nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",o:["9","5","4","8"],k:0,s:"Tik juftlar 3 × yotiq juftlar 3 = 9."},
{t:"Uchburchak tomonlarining o'rtalari tutashtirildi (ichida 4 ta kichik uchburchak). Rasmda jami nechta uchburchak?",o:["5","4","6","8"],k:0,s:"4 kichik + 1 katta = 5."},
{t:"Dumaloq pishiriqni 3 ta to'g'ri kesim bilan eng ko'pi nechta bo'lakka bo'lish mumkin?",o:["7","6","8","9"],k:0,s:"2 → 4 → 7: uchinchi kesim 3 ta bo'lak qo'shadi."},
{t:"2 qator, 3 ustunli to'rda nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",o:["18","6","12","17"],k:0,s:"Tik juftlar 6 × yotiq juftlar 3 = 18."},
{t:"4×4 katakli to'rda nechta kvadrat bor?",o:["30","16","25","20"],k:0,s:"16 + 9 + 4 + 1 = 30."},
{t:"Dumaloq pishiriqni 4 ta to'g'ri kesim bilan eng ko'pi nechta bo'lakka bo'lish mumkin?",o:["11","8","10","16"],k:0,s:"2, 4, 7, 11: har safar +2, +3, +4."}
];
function PRACT_STAGE(){S.d={1:1,2:1};J3sq(3)}
var PREP_DATA={teach:["Kesmalarni tizimli sanash: har nuqtadan o'ngga.","Uchburchaklar va kesmalar o'rtasidagi bog'liqlik.","To'rdagi kvadratlar va to'g'ri to'rtburchaklar (chiziq juftlari).","Tuzoqlar: diagonallar, o'rta chiziqlar, pishiriqni kesish.","Eyler formulasi."],
 mist:["Katta («ko'rinmaydigan») shakllarni unutadi.","Bir shaklni ikki marta sanaydi (AB va BA).","3×3 to'rda kvadratlarni 9 deb javob beradi.","Kesimlar markazdan o'tishi shart deb o'ylaydi (6 o'rniga 7)."],
 need:["Katak daftar, rangli qalamlar.","Qog'oz doiralar, chizg'ich.","2×2 qog'oz ramka, kubik yoki quti."],
 board:["<span class='w2'>4 + 3 + 2 + 1 = 10</span> kesma.","3×3: <span class='w2'>9 + 4 + 1 = 14</span>.","2×3: <span class='w2'>6 · 3 = 18</span>.","4×4: <span class='w2'>16+9+4+1 = 30</span>.","Pishiriq: <span class='w2'>2, 4, 7, 11</span>."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
