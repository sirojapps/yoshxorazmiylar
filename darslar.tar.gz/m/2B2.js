var CODE='2B2',TITLE='2-sinf · O‘nlikdan o‘tib qo‘shish';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// o'ntalik ramka (2x5): a ta ko'k, b ta pushti; ortiqchasi yon tomonda
function frame10(a,b,moved){clear();var g=S.g,x0=90,y0=40,c=34;E('rect',{x:x0-4,y:y0-4,width:5*c+8,height:2*c+8,rx:8,fill:'#fff',stroke:C.line,'stroke-width':2},g);
 for(var i=0;i<10;i++){var x=x0+(i%5)*c+c/2,y=y0+Math.floor(i/5)*c+c/2;E('circle',{cx:x,cy:y,r:13,fill:'none',stroke:'#e6d6bd'},g)}
 var inA=a,inB=moved?Math.min(b,10-a):0,out=b-inB;
 for(var j=0;j<inA+inB;j++){var x=x0+(j%5)*c+c/2,y=y0+Math.floor(j/5)*c+c/2;E('circle',{cx:x,cy:y,r:12,fill:j<inA?C.b:C.c,stroke:'#fff','stroke-width':2},g)}
 for(var k=0;k<out;k++)E('circle',{cx:290+(k%2)*26,cy:y0+16+Math.floor(k/2)*28,r:12,fill:C.c,stroke:'#fff','stroke-width':2},g);
 T(g,180,150,moved?a+' + '+b+' = 10 + '+out+' = '+(10+out):a+' + '+b+' = ?',{'font-size':18,'font-weight':800,fill:moved?C.ok:'#1d2b3a'})}
function tu2(t,u,o){o=o||{};clear();var g=S.g;T(g,180,20,o.title||'',{'font-size':16,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<t;i++)rod(g,30+i*15,36,96,o.newT&&i===t-1?C.hi:null);
 for(var k=0;k<u;k++){var hl=o.hiU&&k<10;unit(g,230+(k%5)*22,44+Math.floor(k/5)*24,hl?C.hi:null)}
 if(o.note)T(g,180,160,o.note,{'font-size':13,'font-weight':800,fill:o.nc||C.blue})}
var P1=[function(){frame10(8,5,false);msg('8 + 5. Ramkada 10 ta joy. 8 ta band, 2 ta bo‘sh')},function(){frame10(8,5,true);msg('5 dan 2 tasi ramkani to‘ldirdi — <b>10</b>, yana 3 ta qoldi: 10 + 3 = <b>13</b>')}];
var P2=[function(){tu2(5,13,{title:'38 + 25',note:'o‘nliklar 3 + 2 = 5, birliklar 8 + 5 = 13 — 9 dan ko‘p!',nc:C.bad});msg('Birliklar 13 ta — bitta xonaga sig‘maydi')},
 function(){tu2(5,13,{title:'38 + 25',hiU:1,note:'13 dan 10 tasini bog‘laymiz…'});msg('10 ta birlik → 1 ta o‘nlik')},
 function(){tu2(6,3,{title:'38 + 25 = 63',newT:1,note:'6 o‘nlik 3 birlik = 63',nc:C.ok});msg('Yangi o‘nlik (sariq) qo‘shildi: <b>63</b>')}];
var P3=[function(){jl2([]);msg('38 + 25. 38 ni eng yaqin o‘nlikkacha to‘ldiramiz')},function(){jl2([[38,40,'+2']]);msg('38 + 2 = <b>40</b>. 25 dan 2 ni oldik, 23 qoldi')},function(){jl2([[38,40,'+2'],[40,60,'+20']]);msg('40 + 20 = 60')},function(){jl2([[38,40,'+2'],[40,60,'+20'],[60,63,'+3']]);msg('60 + 3 = <b>63</b>. Ya‘ni 38 + 25 = 38 + 2 + 23 = 63')}];
var P5=[function(){clear();T(S.g,180,50,'29 + 47',{'font-size':28,'font-weight':800});msg('29 — 30 ga juda yaqin')},function(){clear();T(S.g,180,50,'29 + 47',{'font-size':28,'font-weight':800});T(S.g,180,96,'30 + 47 = 77',{'font-size':22,'font-weight':800,fill:C.blue});msg('Avval 30 ni qo‘shamiz (1 ta ortiqcha qo‘shdik)')},function(){clear();T(S.g,180,50,'29 + 47',{'font-size':28,'font-weight':800});T(S.g,180,96,'30 + 47 = 77',{'font-size':22,'font-weight':800,fill:C.blue});T(S.g,180,140,'77 − 1 = 76',{'font-size':22,'font-weight':800,fill:C.ok});msg('Ortiqcha 1 ni qaytarib olamiz: <b>76</b>')}];
var P7=[function(){puz(0);msg('4□ + □8 = 75. Kataklarga qanday raqamlar kerak?')},function(){puz(1);msg('Birliklar: □ + 8 ning oxiri 5. □ + 8 = 15 → □ = <b>7</b> (1 o‘nlik o‘tadi)')},function(){puz(2);msg('O‘nliklar: 4 + □ + 1 = 7 → □ = <b>2</b>. 47 + 28 = 75 ✓. Raqamlar yig‘indisi 7 + 2 = 9')}];
var P8=[function(){b8(0);msg('Ali 38 ta yong‘oq terdi, Vali undan 27 ta ko‘p')},function(){b8(1);msg('Vali: 38 + 27 = <b>65</b> (8 + 7 = 15 — o‘nlikdan o‘tdik)')},function(){b8(2);msg('Vali 9 tasini Aliga berdi: 65 − 9 = <b>56</b>')}];
var STEPS=[
{h:"Birliklar 10 dan oshsa",sum:"8 + 5: ramkani 10 gacha to'ldiramiz (8 + 2), qolgani 3 → 13. «10 ni yasash» usuli.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>O'ntalik ramkada 8 ta ko'k doira bor. Yana 5 ta pushti qo'shamiz. Ramka nechtaga to'ladi, nechtasi ortadi?</p>",
 btns:[phaser(P1,'▶ Ramkaga joylash')],
 after:"<p>8 ga 2 tasi yetmas edi — 5 dan 2 tasini oldik: <b>10</b> bo'ldi. 3 tasi ortdi: 10 + 3 = <b>13</b>. Bu — Yaponiyaning mashhur «<b>10 ni yasash</b>» usuli.</p>",
 q:{t:"7 + 6 ni «10 ni yasash» usulida hisoblang.",opts:["10 + 6 = 16","7 + 3 + 3 = 13","7 + 6 = 12","10 + 7 = 17"],ok:1,why:"7 ga 3 yetmaydi: 7 + 3 = 10, 6 dan 3 qoladi.",hint:"7 ni 10 gacha to'ldirish uchun nechta kerak? 6 dan nechta qoladi?",full:"7 + 3 = 10 (6 ni 3 va 3 ga bo'ldik). 10 + 3 = 13. Demak 7 + 6 = 7 + 3 + 3 = 13."},
 tn:"Yaponiya 1-sinf darsliklarida «10 ni yasash» (juu wo tsukuru) — asosiy mavzu. Tuxum qutisi yoki 2×5 ramka bilan mashq qiling."},
{h:"Tayoqchalar bilan: 38 + 25",sum:"Birliklar 8 + 5 = 13 → 10 tasi yangi o'nlik. 5 + 1 = 6 o'nlik, 3 birlik: 63.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>38 + 25 ni tayoqchalar bilan qo'shamiz. Birliklar bilan nima bo'ladi? Kuzating.</p>",
 btns:[phaser(P2)],
 after:"<p>Birliklar 13 ta bo'ldi — bu 9 dan ko'p, xonaga sig'maydi. 10 tasini bog'lab, <b>yangi o'nlik</b> qildik. O'nliklar 5 + 1 = <b>6</b>, birliklar <b>3</b>: 38 + 25 = <b>63</b>. Bu «o'nlikdan o'tish» deyiladi.</p>",
 q:{t:"47 + 36 = ?",opts:["713","73","83","93"],ok:2,why:"7 + 6 = 13 → 1 o'nlik o'tadi; 4 + 3 + 1 = 8: 83.",hint:"Birliklar 7 + 6 nechta? 10 tasi o'nlikka aylanadi.",full:"Birliklar: 7 + 6 = 13 = 1 o'nlik 3 birlik. O'nliklar: 4 + 3 = 7, yana 1 — 8. Javob: 83. «73» — o'tgan o'nlik unutilgan, «713» — yonma-yon yozilgan."},
 tn:"Bolalar cho'p bilan qilib ko'rsin: 13 ta donadan 10 tasini rezinka bilan bog'lasin."},
{h:"Son o'qida: o'nlikkacha to'ldiramiz",sum:"38 + 25 = 38 + 2 + 23: avval 40 ga (+2), keyin +20, +3 → 63.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Boshqa usul — son o'qida. Avval 38 ni eng yaqin <b>o'nlikkacha</b> to'ldiramiz. Kuzating.</p>",
 btns:[phaser(P3,'▶ Sakrash')],
 after:"<p>Usul: <b>avval yaxlit o'nlikkacha</b> yetamiz (38 → 40, +2), keyin qolganini (23) qo'shamiz. Yaxlit sonlar bilan hisoblash oson! Darslikda bu «yaxlit songacha qo'shish» deyiladi.</p>",
 q:{t:"56 + 27 ni o'nlikkacha to'ldirish usulida hisoblang. Birinchi sakrash qanday?",opts:["+ 7 → 63","+ 4 → 60","+ 20 → 76","+ 6 → 62"],ok:1,why:"56 dan 60 gacha 4. Keyin 27 − 4 = 23: 60 + 23 = 83.",hint:"56 ni eng yaqin o'nlikka (60) yetkazish uchun nechta kerak?",full:"56 + 4 = 60 (27 dan 4 ni oldik, 23 qoldi). 60 + 23 = 83. Birinchi sakrash — + 4."},
 tn:"«Bo'sh son o'qi» (Gollandiya RME) — bolalar sakrashlarni o'zi chizsin. Har xil sakrash yo'llari to'g'ri bo'lishi mumkin."},
{h:"Xonalar bo'yicha: o'nliklar va birliklar",sum:"38 + 25 = (30 + 20) + (8 + 5) = 50 + 13 = 63.",a:"m04",
 start:function(){x4(0)},fin:function(){x4(3)},
 html:"<p>Uchinchi usul — xonalar bo'yicha alohida qo'shib, keyin birlashtiramiz. Bosqichlarni bosing:</p>",
 btns:[["1) o'nliklar",function(c,done){x4(1);mvK(done,3)}],["2) birliklar",function(c,done){x4(2);mvK(done,3)},'u'],["3) birlashtirish",function(c,done){x4(3);mvK(done,3)}]],g3:1,
 after:"<p>(30 + 20) + (8 + 5) = 50 + <b>13</b> = 63. Birliklar yig'indisi 13 bo'lgani uchun oxirida yana <b>10</b> qo'shildi. Qaysi usul sizga qulay — o'shandan foydalaning!</p>",
 q:{t:"66 + 28 = ?",opts:["84","94","814","96"],ok:1,why:"60 + 20 = 80, 6 + 8 = 14, 80 + 14 = 94.",hint:"O'nliklar alohida, birliklar alohida — keyin qo'shing.",full:"(60 + 20) + (6 + 8) = 80 + 14 = 94. «84» — birliklardagi 10 unutilgan."},
 tn:"Bir misolni uch usulda yechish — Yaponiya darslarining odati: bolalar usullarni solishtirib, eng qulayini tanlaydi."},
{h:"Qulay usul: yaxlitlab, keyin tuzatamiz",sum:"29 + 47 = 30 + 47 − 1 = 76. 9 bilan tugagan sonni o'nlikka yaxlitlash qulay.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>29 + 47. 29 — deyarli 30! Oson yo'li bor — kuzating.</p>",
 btns:[phaser(P5)],
 after:"<p>29 ning o'rniga 30 qo'shdik — <b>1 ta ortiqcha</b>. Oxirida uni qaytarib olamiz: 77 − 1 = <b>76</b>. Bu usul 9, 8 bilan tugagan sonlar uchun juda qulay: + 19 = + 20 − 1, + 38 = + 40 − 2.</p>",
 q:{t:"45 + 39 ni qulay usulda hisoblang.",opts:["45 + 40 − 1 = 84","45 + 40 + 1 = 86","45 + 30 = 75","45 + 39 = 74"],ok:0,why:"39 = 40 − 1: 85 − 1 = 84.",hint:"39 ni qaysi yaxlit songa almashtirish qulay? Keyin nima qilish kerak?",full:"39 o'rniga 40 qo'shamiz: 45 + 40 = 85. Bitta ortiqcha qo'shdik — qaytaramiz: 85 − 1 = 84. «+1» — tuzatish teskari qilingan."},
 tn:"Bu — «kompensatsiya» strategiyasi, xalqaro og'zaki hisob dasturlarida (Number Talks) markaziy o'rinda."},
{h:"Tuzoq: raqamli jumboq",sum:"4□ + □8 = 75: birliklar □ + 8 = 15 → 7; o'nliklar 4 + □ + 1 = 7 → 2. 47 + 28 = 75.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Olimpiada savoli: <b>4□ + □8 = 75</b>. Kataklarga yozilgan raqamlar yig'indisi nechaga teng? Birliklardan boshlaymiz.</p>",
 btns:[phaser(P7)],
 after:"<p>Kalit: birliklar yig'indisining oxiri 5 bo'lishi kerak, □ + 8 = 5 bo'lmaydi — demak □ + 8 = <b>15</b>, □ = 7 va <b>1 o'nlik o'tadi</b>. O'nliklarda o'sha 1 ni unutmaslik kerak: 4 + □ + 1 = 7, □ = 2.</p>",
 q:{t:"□6 + 2□ = 73 bo'lsa, kataklardagi raqamlar qaysilar?",opts:["4 va 7","5 va 7","4 va 3","3 va 7"],ok:0,why:"6 + □ = 13 → 7; □ + 2 + 1 = 7 → 4. 46 + 27 = 73.",hint:"Birliklardan boshlang: 6 + □ ning oxiri 3. Bu 13 bo'lishi kerak.",full:"Birliklar: 6 + □ = 13 → □ = 7, 1 o'nlik o'tadi. O'nliklar: □ + 2 + 1 = 7 → □ = 4. Tekshiramiz: 46 + 27 = 73 ✓. «5 va 7» — o'tgan 1 unutilgan."},
 tn:"Raqamli jumboqlar (kriptoarifmetika) o'tish tushunchasini eng chuqur tekshiradi. Bolalar o'zlari ham jumboq tuzsin."},
{h:"Masala: ikki bosqich",sum:"Ali 38, Vali 27 ta ko'p → 65; Vali 9 tasini berdi → 56.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p><i>«Ali 38 ta yong'oq terdi, Vali esa Alidan 27 ta ko'p. Keyin Vali o'z yong'oqlaridan 9 tasini Aliga berdi. Endi Valida nechta?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Avval Valida nechta bo'lganini topamiz: 38 + 27 = <b>65</b> (o'nlikdan o'tish!). Keyin 9 tasini berdi: 65 − 9 = <b>56</b>. Diqqat: savol <b>Vali</b> haqida — Alining yong'oqlari kerak emas.</p>",
 q:{t:"Birinchi son 27, ikkinchi son undan 18 ta ko'p. Ikkala sonning yig'indisi nechaga teng?",opts:["45","62","72","82"],ok:2,why:"Ikkinchi: 27 + 18 = 45. Yig'indi: 27 + 45 = 72.",hint:"Avval ikkinchi sonni toping. Keyin ikkalasini qo'shing.",full:"Ikkinchi son: 27 + 18 = 45. Yig'indi: 27 + 45 = 72. «45» — bu faqat ikkinchi son, savol yig'indini so'rayapti."},
 tn:"«… ta ko'p» masalalarida bolalar ko'pincha birinchi amaldan keyin to'xtaydi. Savolni doim qayta o'qitib, nima so'ralganini tagiga chizdiring."},
{h:"Bilasizmi?",sum:"«10 ni yasash» — Yaponiya va Singapur darsliklarining asosi. Ikki qo'lda 10 ta barmoq bo'lgani uchun 10 eng qulay son.",a:"m08",
 start:function(){hands()},fin:function(){hands()},
 html:"<p>🇯🇵🇸🇬 Yaponiya va Singapur o'quvchilari matematika bo'yicha dunyoda doim eng yaxshilar qatorida. Ularning darsliklarida 1-sinfdanoq «<b>10 ni yasash</b>» o'rgatiladi: 8 + 5 = 8 + 2 + 3.</p><p>🖐🖐 Nega aynan 10? Chunki bizning sanoq tizimimiz o'nlikka asoslangan, ikki qo'lda esa 10 ta barmoq bor. 10 ga yetkazsak — hisoblash juda oson bo'ladi!</p>",
 tn:"«Do'st sonlar» o'yini: biri son aytadi (7), boshqasi uni 10 ga to'ldiradi (3)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.ph=2;P2[2]()},fin:function(){S.ph=2;P2[2]()},
 html:"<div class='memo'><ul><li>Birliklar yig'indisi <b>10 va undan ko'p</b> bo'lsa — o'nlikdan o'tiladi: 10 tasi yangi o'nlik.</li><li><b>10 ni yasash</b>: 8 + 5 = 8 + 2 + 3 = 13.</li><li>Son o'qida: avval yaxlit o'nlikkacha — 38 + 2 = 40, keyin qolgani.</li><li>Xonalar bo'yicha: (30 + 20) + (8 + 5) = 50 + 13 = 63.</li><li>Qulay usul: 29 + 47 = 30 + 47 − <b>1</b>.</li><li>O'tgan o'nlikni <b>unutmang</b>: 47 + 36 = 83 (73 emas!).</li></ul></div>",
 tn:"Keyingi darsni «Qaysi yig'indi 90 dan katta: 38 + 49, 29 + 59, 45 + 44, 47 + 46?» savoli bilan boshlang."}
];
function jl2(jumps){clear();var x0=20,x1=340,y=120,a=35,b=65,k=(x1-x0)/(b-a),X=function(v){return x0+(v-a)*k};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=a;v<=b;v++){E('line',{x1:X(v),y1:y-(v%10?4:9),x2:X(v),y2:y+(v%10?4:9),stroke:'#33475b','stroke-width':v%10?1:2.2},S.g);if(v%10===0||v===38)T(S.g,X(v),y+24,String(v),{'font-size':12,'font-weight':800,fill:v===38?C.blue:'#5b6b7b'})}
 E('circle',{cx:X(38),cy:y,r:6,fill:C.blue},S.g);jumps.forEach(function(j,i){var h=[24,54,30][i];E('path',{d:'M'+X(j[0])+' '+(y-4)+' Q'+(X(j[0])+X(j[1]))/2+' '+(y-4-h)+' '+X(j[1])+' '+(y-4),fill:'none',stroke:[C.ok,C.a,C.c][i],'stroke-width':2.4},S.g);T(S.g,(X(j[0])+X(j[1]))/2,y-10-h,j[2],{'font-size':12,'font-weight':800,fill:[C.ok,'#b0601f','#c0507a'][i]})});
 if(jumps.length){var e=jumps[jumps.length-1][1];E('circle',{cx:X(e),cy:y,r:7,fill:C.ok},S.g);T(S.g,X(e),y+40,String(e),{'font-size':15,'font-weight':800,fill:C.ok})}}
function x4(k){clear();var g=S.g;T(g,180,30,'38 + 25',{'font-size':22,'font-weight':800});if(k>=1)T(g,180,68,'30 + 20 = 50',{'font-size':18,'font-weight':800,fill:C.t1});if(k>=2)T(g,180,100,'8 + 5 = 13',{'font-size':18,'font-weight':800,fill:C.u});if(k>=3)T(g,180,142,'50 + 13 = 63',{'font-size':24,'font-weight':800,fill:C.ok});msg(k>=3?'38 + 25 = <b>63</b>':'Bosqichlarni ketma-ket bosing')}
function puz(k){clear();var g=S.g;function cell(x,y,v,hl){E('rect',{x:x,y:y,width:34,height:40,rx:6,fill:hl?'#e6f6ee':'#fff',stroke:hl?C.ok:'#9aa8b6','stroke-width':2,'stroke-dasharray':v==null?'4 3':''},g);T(g,x+17,y+29,v==null?'':String(v),{'font-size':24,'font-weight':800,fill:hl?C.ok:'#1d2b3a'})}
 cell(150,20,4);cell(186,20,k>=1?7:null,k>=1);T(g,130,98,'+',{'font-size':26,'font-weight':800});cell(150,68,k>=2?2:null,k>=2);cell(186,68,8);E('line',{x1:140,y1:116,x2:224,y2:116,stroke:'#1d2b3a','stroke-width':2.5},g);cell(150,122,7);cell(186,122,5);
 if(k>=1)T(g,262,48,'1 o‘tdi',{'font-size':12,'font-weight':800,fill:C.bad})}
function b8(k){clear();var g=S.g,f=4;E('rect',{x:20,y:40,width:38*f,height:32,fill:C.b,stroke:C.line,'stroke-width':1.5},g);T(g,20+19*f,61,'Ali 38',{'font-size':12,'font-weight':800,fill:'#fff'});
 E('rect',{x:20,y:96,width:38*f,height:32,fill:C.c,stroke:C.line,'stroke-width':1.5},g);E('rect',{x:20+38*f,y:96,width:27*f,height:32,fill:k>=1?C.c:'#fff7ea',stroke:C.line,'stroke-width':1.5,'stroke-dasharray':k>=1?'':'4 3'},g);T(g,20+19*f,117,'38',{'font-size':12,'font-weight':800,fill:'#fff'});T(g,20+38*f+13.5*f,117,'+27',{'font-size':12,'font-weight':800,fill:k>=1?'#fff':'#c0507a'});
 T(g,10,90,'Vali',{'font-size':11,'text-anchor':'start',fill:'#5b6b7b'});if(k>=1)T(g,20+65*f+24,117,'= 65',{'font-size':14,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(k>=2){E('rect',{x:20+56*f,y:96,width:9*f,height:32,fill:'#ddd',stroke:C.bad,'stroke-width':2},g);T(g,20+60.5*f,150,'−9 → 56',{'font-size':13,'font-weight':800,fill:C.bad})}}
function hands(){clear();var g=S.g;T(g,120,100,'🖐',{'font-size':64});T(g,240,100,'🖐',{'font-size':64});T(g,180,150,'5 + 5 = 10',{'font-size':18,'font-weight':800,fill:C.blue});msg('10 — eng qulay son')}
var PROBS=[
{t:"38 + 25 = ?",o:["63","53","513","73"],k:0,s:"8 + 5 = 13 → 1 o'nlik o'tadi; 3 + 2 + 1 = 6: 63."},
{t:"47 + 36 = ?",o:["83","73","713","93"],k:0,s:"7 + 6 = 13; 4 + 3 + 1 = 8: 83."},
{t:"Hisoblang: 28 + 28 + 28",o:["84","56","74","86"],k:0,s:"28 + 28 = 56, 56 + 28 = 84."},
{t:"Qaysi yig'indi 90 dan katta?",o:["47 + 46","38 + 49","29 + 59","45 + 44"],k:0,s:"93, 87, 88, 89."},
{t:"Birinchi son 27, ikkinchisi undan 18 ta ko'p. Ikkala son yig'indisi?",o:["72","62","82","45"],k:0,s:"27 + 45 = 72."},
{t:"Ali 38 ta yong'oq terdi, Vali Alidan 27 ta ko'p. Vali 9 tasini Aliga berdi. Endi Valida nechta?",o:["56","74","65","47"],k:0,s:"38 + 27 = 65, 65 − 9 = 56."},
{t:"Lola 39 ni o'yladi, Malika Lolanikidan 15 ta katta sonni. Ikkala son yig'indisi?",o:["93","83","63","54"],k:0,s:"39 + 54 = 93."},
{t:"Bir sonni o'ziga qo'shsak 46 chiqadi. Shu songa 19 ni qo'shsak, nechchi?",o:["42","65","27","46"],k:0,s:"Son 23 (23 + 23 = 46). 23 + 19 = 42."},
{t:"4□ + □8 = 75. Kataklardagi raqamlar yig'indisi?",o:["9","2","11","7"],k:0,s:"47 + 28 = 75: 7 + 2 = 9."},
{t:"56 + □ yig'indisi 100 dan oshishi uchun □ o'rniga eng kichik ikki xonali son?",o:["45","44","54","40"],k:0,s:"56 + 44 = 100 — oshmaydi; 56 + 45 = 101."},
{t:"Son o'qida 15 dan 48 birlik o'ngga, so'ng 19 birlik chapga yurildi. Qaysi songa kelindi?",o:["44","82","54","34"],k:0,s:"15 + 48 = 63, 63 − 19 = 44."},
{t:"29 + 47 ni qulay usulda hisoblang.",o:["76","77","66","86"],k:0,s:"30 + 47 − 1 = 76."},
{t:"7 + 6 = 7 + 3 + □. □ = ?",o:["3","6","4","10"],k:0,s:"6 = 3 + 3."},
{t:"66 + 28 = ?",o:["94","84","814","96"],k:0,s:"80 + 14 = 94."},
{t:"Qaysi misolda o'nlikdan o'tiladi?",o:["57 + 26","43 + 25","61 + 37","52 + 46"],k:0,s:"7 + 6 = 13 — o'tiladi. Qolganlarida birliklar 10 dan kam."},
{t:"□6 + 2□ = 73. Kataklardagi raqamlar?",o:["4 va 7","5 va 7","4 va 3","3 va 7"],k:0,s:"46 + 27 = 73."},
{t:"Do'konda 48 ta qizil va 35 ta ko'k qalam bor. Jami nechta?",o:["83","73","813","93"],k:0,s:"48 + 35 = 83."},
{t:"Qaysi ikki sonning yig'indisi 100 ga teng?",o:["63 va 37","64 va 46","55 va 55","72 va 38"],k:0,s:"63 + 37 = 100."},
{t:"35 + 35 + 18 = ?",o:["88","78","98","87"],k:0,s:"35 + 35 = 70, 70 + 18 = 88."},
{t:"Bir qutida 27 ta, ikkinchisida birinchisidan 9 ta ko'p konfet. Ikkala qutida jami?",o:["63","36","54","45"],k:0,s:"Ikkinchisi 36. 27 + 36 = 63."}
];
function PRACT_STAGE(){S.ph=1;P1[1]()}
var PREP_DATA={teach:["O'nlikdan o'tib qo'shish: birliklar yig'indisi 10 dan oshsa, 10 tasi yangi o'nlik.","«10 ni yasash» (8 + 5 = 8 + 2 + 3) va son o'qida yaxlit o'nlikkacha to'ldirish.","Xonalar bo'yicha qo'shish; qulay usul (29 + 47 = 30 + 47 − 1).","Raqamli jumboqlar va ikki bosqichli masalalar."],
 mist:["O'tgan o'nlikni unutadi (47 + 36 = 73).","Natijani yonma-yon yozadi (713).","Qulay usulda tuzatishni teskari qiladi (+1 o'rniga −1).","«… ta ko'p» masalasida birinchi amaldan keyin to'xtaydi."],
 need:["2×5 ramkalar (tuxum qutisi), 20 ta qopqoq.","Cho'p bog'lamlari va rezinka.","Doskada bo'sh son o'qi."],
 board:["Ramka: <span class='w2'>8 + 5 = 8 + 2 + 3 = 13</span>.","<span class='w2'>38 + 25</span>: birliklar 13 → 1 o'nlik o'tadi → 63.","Son o'qi: 38 → 40 → 60 → 63.","<span class='w2'>(30 + 20) + (8 + 5) = 63</span>.","<span class='w2'>29 + 47 = 30 + 47 − 1 = 76</span>."]};
