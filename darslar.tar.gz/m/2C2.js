var CODE='2C2',TITLE='2-sinf · Bo‘lish ma’nosi (teng bo‘laklarga ajratish)';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P7=[function(){cDeal(20,1,0,{});cMsg('20 ta olma. 2 tasi chirigan…')},
 function(){cDeal(18,1,0,{});cMsg('20 − 2 = <b>18</b> ta yaxshi olma qoldi')},
 function(){cDeal(18,6,18,{per:3});cMsg('18 ta olmani 3 tadan: 18 : 3 = <b>6</b> ta likopcha')}];
var P8=[function(){cDeal(18,3,18,{who:'bola'});cMsg('18 : 3 = 6 — har bir bolaga 6 tadan')},
 function(){cDeal(6,3,6,{who:'kishi'});cMsg('Bitta bola 6 ta konfetni o‘zi va 2 do‘sti — <b>3 kishi</b>ga bo‘ladi')},
 function(){cDeal(6,3,6,{who:'kishi'});cMsg('6 : 3 = <b>2</b> — har biriga 2 tadan. «2 do‘st» = 3 kishi!')}];
var STEPS=[
{h:"Teng bo'lishamiz",sum:"12 ta konfetni 3 bolaga bittadan navbat bilan tarqatsak — har biriga 4 tadan: 12 : 3 = 4.",a:"m01",
 start:function(){cDeal(12,3,0,{who:'bola'});cMsg('12 ta konfet, 3 ta bola')},fin:function(){cDeal(12,3,12,{who:'bola'});cMsg('Har biriga <b>4</b> tadan: 12 : 3 = 4')},
 html:"<p><b>12 ta konfet</b>ni <b>3 ta bola</b> teng bo'lishmoqchi — hech kim xafa bo'lmasin. Navbat bilan bittadan tarqatamiz. Tugmani bosing.</p>",
 btns:[["🍬 Bittadan tarqatish",function(c,done,b){b.disabled=true;cDealAnim(12,3,{who:'bola'},function(){cMsg('Har biriga <b>4</b> tadan: 12 : 3 = 4');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>Hamma konfet tugadi, har bir bolaga <b>4 tadan</b> tegdi. Bu — <b>bo'lish</b>: 12 ni 3 ta teng bo'lakka ajratdik. Yoziladi: <b>12 : 3 = 4</b>.</p>",
 q:{t:"8 ta olmani 2 bolaga teng bo'lishdi. Har biriga nechta?",opts:["6","4","10","16"],ok:1,why:"8 : 2 = 4.",hint:"Bittadan navbat bilan bersangiz, har biriga nechta yetadi?",full:"Ikki bolaga navbat bilan: 1-ga 1, 2-ga 1, … 8 ta tugaguncha. Har biriga 4 tadan: 8 : 2 = 4. «6» — ayirish (8 − 2), «16» — ko'paytirish."},
 tn:"Haqiqiy narsalar bilan qiling: 3 bola chiqib, 12 ta qalamni navbat bilan oladi. Bo'lish — «adolatli taqsimlash»."},
{h:"Bo'lish belgisi",sum:"12 : 3 = 4 — «o'n ikkini uchga bo'lamiz, to'rt». Natija — bo'linma.",a:"m02",
 start:function(){cDeal(12,3,12,{who:'bola'});cMsg('12 : 3 = 4')},fin:function(){cDeal(12,3,12,{who:'bola'});cMsg('12 : 3 = 4 — «o‘n ikkini uchga bo‘lamiz»')},
 html:"<p>Bo'lish belgisi — <b>ikki nuqta (:)</b>. <b>12 : 3 = 4</b> — «o'n ikkini uchga bo'lamiz, to'rt chiqadi». Natija — <b>bo'linma</b>. Tarqatib ko'ring:</p>",
 btns:[["10 : 2",function(c,done,b){mvK(done,2);cDealAnim(10,2,{who:'bola',fast:1},function(){cMsg('10 : 2 = <b>5</b>')})}],["15 : 3",function(c,done){mvK(done,2);cDealAnim(15,3,{who:'bola',fast:1},function(){cMsg('15 : 3 = <b>5</b>')})}],["16 : 4",function(c,done){mvK(done,2);cDealAnim(16,4,{who:'bola',fast:1},function(){cMsg('16 : 4 = <b>4</b>')})}]],
 after:"<p>Bo'lishda birinchi son — <b>hammasi</b> (nechta narsa), ikkinchisi — <b>nechta teng bo'lakka</b> ajratamiz.</p>",
 q:{t:"«O'n beshni beshga bo'lamiz» qanday yoziladi?",opts:["15 − 5","15 : 5","5 : 15","15 · 5"],ok:1,why:"Birinchi — hammasi (15), keyin «:», keyin nechtaga (5).",hint:"Bo'lish belgisi qaysi? Qaysi son birinchi yoziladi?",full:"Hammasi — 15, u birinchi yoziladi. Keyin bo'lish belgisi «:», keyin 5: 15 : 5 = 3. «5 : 15» — tartib almashgan."},
 tn:"Belgini doskaga katta yozing va o'qishni xor bilan mashq qiling."},
{h:"«…tadan» bo'lish",sum:"12 ta olmani likopchalarga 4 tadan solsak — 3 ta likopcha kerak: 12 : 4 = 3.",a:"m03",
 start:function(){cDeal(12,3,0,{per:4});cMsg('12 ta olma, har likopchaga 4 tadan')},fin:function(){cDeal(12,3,12,{per:4});cMsg('3 ta likopcha to‘ldi: 12 : 4 = 3')},
 html:"<p>Bo'lishning ikkinchi ma'nosi: <b>12 ta olmani 4 tadan</b> likopchalarga solamiz. Nechta likopcha kerak? Tugmani bosing.</p>",
 btns:[["🍎 4 tadan solish",function(c,done,b){b.disabled=true;cDealAnim(12,3,{per:4},function(){cMsg('3 ta likopcha to‘ldi: 12 : 4 = <b>3</b>');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>Bu safar biz bo'laklar <b>sonini</b> topdik: 4 tadan solsak, <b>3 ta</b> likopcha. Ikkala masala ham bitta amal — <b>bo'lish</b>:</p><div class='life'><div>👧👦🧒<span>«3 bolaga teng» → har biriga nechtadan? <b>12 : 3 = 4</b></span></div><div>🍽<span>«4 tadan» → nechta likopcha? <b>12 : 4 = 3</b></span></div></div>",
 q:{t:"35 ta kitob javonlarga 5 tadan qo'yildi. Nechta javon to'ldi?",opts:["30","40","5","7"],ok:3,why:"35 : 5 = 7 ta javon.",hint:"5 tadan necha marta olish mumkin? 5, 10, 15 …",full:"5 tadan sanaymiz: 5, 10, 15, 20, 25, 30, 35 — 7 marta. 35 : 5 = 7 ta javon. «30» — ayirish (35 − 5), «40» — qo'shish."},
 tn:"Ikki ma'noni farqlash (teng taqsimlash va «…tadan» guruhlash) — xalqaro tadqiqotlar tavsiya qiladigan muhim qadam. Ikkalasini ham narsalar bilan qiling."},
{h:"Bo'lish — ayirishning takrori",sum:"12 dan 3 ni necha marta ayirish mumkin? 12 − 3 − 3 − 3 − 3 = 0 → 4 marta: 12 : 3 = 4.",a:"m04",
 start:function(){S.j=0;cLine(15,3,0,{from:12,back:1});cMsg('12 dan boshlab 3 tadan orqaga sakraymiz')},fin:function(){cLine(15,3,4,{from:12,back:1});cMsg('4 ta sakrash — 0 ga yetdik: 12 : 3 = <b>4</b>')},
 html:"<p>Son o'qida 12 dan boshlab <b>3 tadan orqaga</b> sakraymiz. 0 ga yetguncha nechta sakrash bo'ladi?</p>",
 btns:[["◀ −3 sakrash",function(c,done,b){if(S.j>=4)return;S.j++;cLine(15,3,S.j,{from:12,back:1});cMsg(S.j<4?'12 − 3·'+S.j+' = '+(12-3*S.j):'4 ta sakrash — 0 ga yetdik: 12 : 3 = <b>4</b>');if(S.j===4){b.disabled=true;done()}}]],
 after:"<p>Bo'lish — bir xil sonni <b>takror ayirish</b>: 12 dan 3 ni 4 marta ayirsak, 0 qoladi. Ko'paytirish — takror qo'shish, bo'lish — takror ayirish.</p>",
 q:{t:"40 sm lentadan 5 sm lik nechta bo'lak qirqib olish mumkin?",opts:["35","8","200","45"],ok:1,why:"40 : 5 = 8.",hint:"40 dan 5 ni necha marta ayirish mumkin?",full:"40 − 5 − 5 − … 8 marta ayirsak, 0 qoladi. 40 : 5 = 8 bo'lak. «35» — bir marta ayirish, «200» — ko'paytirish."},
 tn:"Son o'qini doskaga chizib, bolalar sakrashni rangli bo'r bilan chizsin."},
{h:"Ko'paytirish bilan tekshiramiz",sum:"12 : 3 = 4, chunki 4 · 3 = 12. Bo'lishni ko'paytirish bilan tekshirish mumkin.",a:"m05",
 start:function(){cPlates(3,4,{lab:1});cMsg('12 : 3 = 4  ←→  4 · 3 = 12')},fin:function(){cPlates(3,4,{lab:1});cMsg('12 : 3 = 4, chunki 4 · 3 = 12')},
 html:"<p>12 ni 3 bolaga bo'lganimizda, 3 ta likopchada 4 tadan bo'ldi. Bu — <b>4 · 3 = 12</b> ning o'zi! Tekshirib ko'ring:</p>",
 btns:[["18 : 3 = ?",function(c,done){cPlates(3,6,{lab:1});cMsg('18 : 3 = <b>6</b>, chunki 6 · 3 = 18');mvK(done,2)}],["20 : 4 = ?",function(c,done){cPlates(4,5,{lab:1});cMsg('20 : 4 = <b>5</b>, chunki 5 · 4 = 20');mvK(done,2)}],["14 : 2 = ?",function(c,done){cPlates(2,7,{lab:1});cMsg('14 : 2 = <b>7</b>, chunki 7 · 2 = 14');mvK(done,2)}]],
 after:"<p>Bo'lish va ko'paytirish — <b>aka-uka</b> amallar. «12 : 3 = ?» desa, o'ylang: «qaysi sonni 3 ga ko'paytirsam, 12 chiqadi?» — 4.</p>",
 q:{t:"Do'konga 80 ta sovun keldi va 4 ta yashikka teng joylandi. Bitta yashikda nechta sovun?",opts:["20","2","40","76"],ok:0,why:"80 : 4 = 20, chunki 20 · 4 = 80.",hint:"Qaysi sonni 4 ga ko'paytirsangiz, 80 chiqadi?",full:"80 : 4 = 20. Tekshiramiz: 20 · 4 = 80 ✓. «76» — ayirish, «40» — 2 ga bo'lish."},
 tn:"Bu aloqa 2C7 mavzusida chuqurlashadi; hozir faqat tekshirish usuli sifatida bering."},
{h:"Tuzoq: avval ortiqchasini olib tashlang",sum:"20 ta olmadan 2 tasi chirigan, qolgani 3 tadan: (20 − 2) : 3 = 6.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Masala: <i>«20 ta olmadan 2 tasi chirigan chiqdi. Qolganlari 3 tadan likopchalarga solindi. Nechta likopcha kerak?»</i> Darhol 20 : 3 qilmang!</p>",
 btns:[phaser(P7)],
 after:"<p>Faqat <b>yaxshi</b> olmalar bo'linadi: 20 − 2 = 18, keyin 18 : 3 = 6. Masalani o'qib, <b>avval nimani</b> qilish kerakligini o'ylang.</p>",
 q:{t:"20 ta stul 4 qatorga teng terildi. Keyin har qatordan 2 tadan stul olib ketildi. Har qatorda nechta stul qoldi?",opts:["18","3","5","2"],ok:1,why:"20 : 4 = 5, 5 − 2 = 3.",hint:"Avval har qatorda nechta bo'lganini toping.",full:"Har qatorda: 20 : 4 = 5 ta. Har qatordan 2 ta olindi: 5 − 2 = 3. «18» — 20 dan 2 ni ayirish, «5» — ikkinchi qadamni unutish."},
 tn:"Ikki amalli masalalarda bolalar sonlarni ko'rib, birinchi uchragan amalni bajaradi. «Avval nima bo'ldi?» savolini doim bering."},
{h:"Tuzoq: «2 do'sti bilan»",sum:"6 ta konfetni o'zi va 2 do'sti — 3 kishiga bo'ladi: 6 : 3 = 2.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Masala: <i>«18 ta konfet 3 ta bolaga teng berildi. Keyin har bir bola o'z konfetlarini 2 ta do'sti bilan teng bo'lishdi (o'ziga ham qoldirdi). Har kimga nechtadan tegdi?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>«2 do'sti bilan, o'ziga ham» — bu <b>3 kishi</b>! Ko'p bolalar 2 ga bo'lib, 3 deb javob beradi. Kim bo'lishayotganini sanab chiqing.</p>",
 q:{t:"Bolalar 4 kishidan guruhlarga bo'linganda 5 ta guruh hosil bo'ldi. Agar ular 2 kishidan juft bo'lishsa, nechta juft bo'ladi?",opts:["5","10","20","8"],ok:1,why:"Bolalar: 4 · 5 = 20. Juftlar: 20 : 2 = 10.",hint:"Avval jami bolalar sonini toping.",full:"Jami bolalar: 4 · 5 = 20. 2 kishidan: 20 : 2 = 10 juft. «20» — bolalar soni, javob emas."},
 tn:"Rol o'yini: bitta bola 6 ta qalamni «o'zi va 2 do'sti» bilan bo'lsin — sinf kim nechta olganini sanasin."},
{h:"Bilasizmi? Bo'lish belgisi",sum:"«:» belgisini Leybnits 1684-yilda ishlatgan; «÷» belgisini shveytsariyalik Iogann Ran 1659-yilda kiritgan.",a:"m08",
 start:function(){clear('#f6ead0');T(S.g,110,100,':',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,250,100,'÷',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,110,140,'Leybnits, 1684',{'font-size':12,fill:'#6b3d12'});T(S.g,250,140,'Ran, 1659',{'font-size':12,fill:'#6b3d12'});cMsg('Bo‘lish belgilari')},fin:function(){STEPS[7].start()},
 html:"<p>📜 <b>«:»</b> belgisini nemis olimi <b>Gotfrid Leybnits</b> 1684-yilda ishlatgan — bizning darsliklarda shu belgi. <b>«÷»</b> belgisini shveytsariyalik <b>Iogann Ran</b> 1659-yilda kitobida kiritgan — kalkulyatorlarda shu belgi bor.</p><p>Ikkala belgi ham bir xil ma'noni bildiradi: <b>teng bo'laklarga ajratish</b>.</p>",
 tn:"Kalkulyatorni ko'rsating: ÷ tugmasi — bizning «:» ning o'zi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){cDeal(12,3,12,{who:'bola'});cMsg('12 : 3 = 4')},fin:function(){STEPS[8].start()},
 html:"<div class='memo'><ul><li><b>Bo'lish</b> — teng bo'laklarga ajratish. Belgi <b>:</b>, natija — <b>bo'linma</b>.</li><li>1-ma'no: <b>teng taqsimlash</b> — 12 ta 3 bolaga: har biriga 12 : 3 = 4.</li><li>2-ma'no: <b>«…tadan»</b> — 12 ta 4 tadan: nechta likopcha? 12 : 4 = 3.</li><li>Bo'lish — takror ayirish: 12 − 3 − 3 − 3 − 3 = 0 → 4 marta.</li><li>Tekshirish: 12 : 3 = 4, chunki <b>4 · 3 = 12</b>.</li><li>Ortiqcha narsani avval olib tashlang: (20 − 2) : 3 = 6.</li><li>«O'zi va 2 do'sti» — <b>3 kishi</b>.</li></ul></div>",
 tn:"Keyingi darsni «14 ta g'ildirak, har velosipedda 2 ta — nechta velosiped?» savoli bilan boshlang."}
];
var PROBS=[
{t:"12 ta qalam 4 ta bolaga teng bo'lindi. Har biriga nechta?",o:["3","8","16","4"],k:0,s:"12 : 4 = 3, chunki 3 · 4 = 12."},
{t:"18 ta gul 2 tadan guldonlarga qo'yildi. Nechta guldon kerak?",o:["9","16","20","36"],k:0,s:"18 : 2 = 9."},
{t:"Munisa har bir kiyimni 2 ta qisqich bilan osadi. 18 ta qisqich bilan nechta kiyimni osadi?",o:["9","10","16","36"],k:0,s:"18 : 2 = 9."},
{t:"35 ta kitob javonlarga 5 tadan qo'yildi. Nechta javon to'ldi?",o:["7","30","40","5"],k:0,s:"35 : 5 = 7."},
{t:"Do'konga 80 ta sovun keldi, 4 ta yashikka teng joylandi. Bitta yashikda nechta?",o:["20","2","40","76"],k:0,s:"80 : 4 = 20."},
{t:"36 piyola choy tarqatildi, har stolda 4 kishi o'tirgan (har kishiga 1 piyola). Nechta stol bor?",o:["9","8","32","36"],k:0,s:"36 : 4 = 9."},
{t:"20 ta olmadan 2 tasi chirigan. Qolganlari 3 tadan likopchalarga solindi. Nechta likopcha kerak?",o:["6","5","7","18"],k:0,s:"20 − 2 = 18, 18 : 3 = 6."},
{t:"24 ta konfet 4 bolaga teng bo'lindi. Keyin har bir bola 2 tasini yedi. Har birida nechta qoldi?",o:["4","6","2","22"],k:0,s:"24 : 4 = 6, 6 − 2 = 4."},
{t:"18 ta olma 3 ta savatga teng solindi. Bitta savatdagi olmalar 2 bolaga teng bo'lindi. Har bir bolaga nechta?",o:["3","9","2","6"],k:0,s:"18 : 3 = 6, 6 : 2 = 3."},
{t:"18 ta konfet 3 bolaga teng berildi. Har bir bola o'z konfetini 2 do'sti bilan teng bo'lishdi (o'ziga ham). Har kimga nechtadan?",o:["2","3","6","4"],k:0,s:"18 : 3 = 6. O'zi va 2 do'st — 3 kishi: 6 : 3 = 2."},
{t:"Bolalar 4 kishidan 5 ta guruhga bo'lindi. 2 kishidan juft bo'lishsa, nechta juft bo'ladi?",o:["10","5","20","8"],k:0,s:"4 · 5 = 20 bola, 20 : 2 = 10."},
{t:"20 ta stul 4 qatorga teng terildi, keyin har qatordan 2 tadan olib ketildi. Har qatorda nechta qoldi?",o:["3","5","18","2"],k:0,s:"20 : 4 = 5, 5 − 2 = 3."},
{t:"40 sm lentadan 5 sm lik nechta bo'lak qirqiladi?",o:["8","35","200","9"],k:0,s:"40 : 5 = 8."},
{t:"«O'n beshni beshga bo'lamiz» qanday yoziladi?",o:["15 : 5","5 : 15","15 − 5","15 · 5"],k:0,s:"Hammasi — 15, birinchi yoziladi: 15 : 5."},
{t:"Qaysi bo'lish to'g'ri?",o:["16 : 2 = 8","16 : 2 = 14","16 : 2 = 32","16 : 2 = 4"],k:0,s:"8 · 2 = 16 — to'g'ri."},
{t:"Velosipedlarning jami 16 ta g'ildiragi bor (har birida 2 ta). Nechta velosiped?",o:["8","14","18","32"],k:0,s:"16 : 2 = 8."},
{t:"30 ta daftar 3 sinfga teng bo'lindi, keyin har sinf o'z daftarini 2 qatorga teng qo'ydi. Har qatorda nechta?",o:["5","10","15","6"],k:0,s:"30 : 3 = 10, 10 : 2 = 5."},
{t:"Onam 15 ta pirojkini o'zi, otam va akam uchun teng bo'ldi. Har biriga nechta tegdi?",o:["5","7","3","15"],k:0,s:"Onam, otam, akam — 3 kishi: 15 : 3 = 5."},
{t:"12 ta tuxumdan 3 tasi singan. Qolganlari 3 tadan idishlarga solindi. Nechta idish kerak?",o:["3","4","9","2"],k:0,s:"12 − 3 = 9, 9 : 3 = 3."},
{t:"Ali 20 ta yong'oqni o'zi va 3 ta do'sti bilan teng bo'lishdi. Alining o'ziga nechta qoldi?",o:["5","6","4","17"],k:0,s:"Ali va 3 do'st — 4 kishi: 20 : 4 = 5."}
];
function PRACT_STAGE(){cDeal(12,3,12,{who:'bola'});cMsg('Hammasi nechta? Nechta bo‘lakka?')}
var PREP_DATA={teach:["Bo'lishning ikki ma'nosi: teng taqsimlash va «…tadan» guruhlash.","Bo'lish belgisi «:», o'qilishi, bo'linma.","Bo'lish — takror ayirish (son o'qida orqaga sakrash).","Ko'paytirish bilan tekshirish; ikki amalli tuzoqlar."],
 mist:["Bo'lish o'rniga ayiradi (8 : 2 → 6).","Sonlar tartibini almashtiradi (5 : 15).","Ortiqchani olib tashlamasdan bo'ladi (20 : 3).","«O'zi va 2 do'sti» ni 2 kishi deb sanaydi."],
 need:["12–20 ta tugma, qalam yoki konfet; 3–4 ta likopcha.","Doskada son o'qi 0–20."],
 board:["<span class='w2'>12 : 3 = 4</span> — 3 bolaga teng.","<span class='w2'>12 : 4 = 3</span> — 4 tadan, nechta likopcha.","<span class='w2'>12 − 3 − 3 − 3 − 3 = 0</span>.","<span class='w2'>12 : 3 = 4 ⇔ 4 · 3 = 12</span>.","<span class='w2'>(20 − 2) : 3 = 6</span>."]};
