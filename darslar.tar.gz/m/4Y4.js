// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4Y4',TITLE='4-sinf · Foiz va o‘nli kasrga oid amaliy masalalar';
function y4pct(k){clear();y4title('100 ta katak — butun');y4grid(30,26,13.5,k);var g=S.g;
 if(k>0){y4T(g,280,58,k+' ta 100 tadan',{'font-size':13,'font-weight':800});y4T(g,280,88,k+'%',{'font-size':22,'font-weight':800,fill:C.a2});y4T(g,280,120,'= '+k+'/100',{'font-size':14,'font-weight':800});if(k===25)y4T(g,280,150,'= 1/4 = 0,25',{'font-size':14,'font-weight':800,fill:C.ok})}}
var Y4P1=[function(){y4pct(0);calc(['Foiz — <b>yuzdan bir</b> qism (lotincha «per centum» — «yuzga»)'])},function(){y4pct(7);calc(['7 katak bo‘yaldi: 7 ta 100 tadan — <b>7%</b>'])},function(){y4pct(25);calc(['25 katak — 25% — butunning <b>to‘rtdan biri</b>','25% = 25/100 = 1/4 = 0,25'])}];
function y4bar(total,parts,lab,hl,cap){var g=S.g,x0=30,w=300;E('rect',{x:x0,y:60,width:w,height:30,fill:'#fff',stroke:C.line,'stroke-width':1.6},g);
 for(var i=0;i<parts;i++){E('rect',{x:x0+i*w/parts,y:60,width:w/parts,height:30,fill:i<hl?C.a:'#fff7ea',stroke:C.line},g);if(lab)y4T(g,x0+(i+.5)*w/parts,80,lab,{'font-size':parts>5?10:12,'font-weight':800,fill:'#1d2b3a'})}
 Br(x0,x0+w,56,total,true);if(cap)y4T(g,180,128,cap,{'font-size':14,'font-weight':800,fill:C.ok})}
function y4of80(sh){clear();y4title('80 ning 25% i');y4bar('80',4,sh?'20':'',sh?1:1,sh?'25% = 1/4 → 80 : 4 = 20':'');if(sh)Br(30,105,94,'25%',false,C.a2)}
function y4tenp(st){clear();y4title('250 ning 30% i — 10% orqali');y4bar('250',10,st>=1?'25':'',st>=2?3:st>=1?1:0,st>=2?'30% = 3 · 25 = 75':st>=1?'10% = 250 : 10 = 25':'')}
var Y4P3=[function(){y4tenp(0);calc(['30% — to‘g‘ridan hisoblash qiyin. Avval 10% ni topamiz'])},function(){y4tenp(1);calc(['10% — o‘ndan bir: 250 : 10 = <b>25</b>'])},function(){y4tenp(2);calc(['30% = 3 ta 10%: 25 · 3 = <b>75</b>','5% = 10% ning yarmi, 1% = 100 ga bo‘lish'])}];
function y4sale(sh){clear();y4title('Narx 40 000 so‘m, chegirma 25%');var g=S.g;E('rect',{x:120,y:34,width:120,height:58,rx:8,fill:'#fff',stroke:'#c0587e','stroke-width':2},g);y4T(g,180,60,'40 000',{'font-size':18,'font-weight':800,fill:sh?'#9aa6b2':'#1d2b3a'});if(sh)E('line',{x1:128,y1:55,x2:232,y2:55,stroke:C.bad,'stroke-width':2.5},g);
 E('circle',{cx:250,cy:34,r:20,fill:C.bad},g);y4T(g,250,39,'−25%',{'font-size':11,'font-weight':800,fill:'#fff'});
 if(sh){y4T(g,180,84,'30 000',{'font-size':16,'font-weight':800,fill:C.ok});y4T(g,180,124,'chegirma: 40 000 : 4 = 10 000',{'font-size':12,'font-weight':700});y4T(g,180,146,'yangi narx: 40 000 − 10 000 = 30 000',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y4back(sh){clear();y4title('Sonning 20% i 12 ga teng. Son nechaga teng?');y4bar(sh?'60':'?',5,sh?'12':'',1,sh?'20% = 1/5 → 12 · 5 = 60':'');if(!sh)y4T(S.g,60,80,'12',{'font-size':12,'font-weight':800})}
function y4updown(st){clear();y4title('Narx 100 000. Avval +10%, keyin −10%');var g=S.g,k=0.0022,x0=30;
 var V=[[100000,'100 000','#cfe6fa'],[110000,'110 000 (+10 000)','#cfeccf'],[99000,'99 000 (−11 000)','#ffd9d9']];
 V.forEach(function(v,i){if(i>st)return;var y=40+i*40;E('rect',{x:x0,y:y,width:v[0]*k,height:26,fill:v[2],stroke:'#8a99a8'},g);y4T(g,x0+v[0]*k+6,y+18,v[1],{'font-size':12,'font-weight':800,'text-anchor':'start'})});
 if(st>=2)E('line',{x1:x0+100000*k,y1:34,x2:x0+100000*k,y2:150,stroke:C.blue,'stroke-dasharray':'4 3','stroke-width':1.5},g)}
var Y4P6=[function(){y4updown(0);calc(['Avval narx 10% ga oshdi, keyin 10% ga tushdi. Joyiga qaytdimi?'])},function(){y4updown(1);calc(['+10%: 100 000 ning 10% i = 10 000 → <b>110 000</b>'])},function(){y4updown(2);calc(['−10%: endi <b>110 000</b> ning 10% i = 11 000 → <b>99 000</b>','Foiz har gal <b>yangi</b> sondan olinadi!'])}];
function y4ribbon(sh){clear();y4title('Uchta lenta, har biri 2,35 m');var g=S.g;for(var i=0;i<3;i++){E('rect',{x:40+i*94,y:56,width:90,height:16,rx:3,fill:['#f08aa8','#5aa9e6','#7cc68f'][i]},g);y4T(g,85+i*94,94,'2,35 m',{'font-size':12,'font-weight':800})}
 if(sh){y4T(g,180,124,'2,35 + 2,35 + 2,35 = 2,35 · 3',{'font-size':12,'font-weight':700});y4T(g,180,148,'235 sm · 3 = 705 sm = 7,05 m',{'font-size':13,'font-weight':800,fill:C.ok})}}
function y4dec(sh){clear();y4title('Qaysi son eng katta?');var g=S.g,x0=30,x1=330,X=function(v){return x0+v*(x1-x0)};E('line',{x1:x0,y1:110,x2:x1,y2:110,stroke:'#33475b','stroke-width':2.5},g);
 [0,0.5,1].forEach(function(v){E('line',{x1:X(v),y1:104,x2:X(v),y2:116,stroke:'#33475b','stroke-width':2},g);y4T(g,X(v),132,v===0.5?'0,5':String(v),{'font-size':11,'font-weight':700})});
 var N=[['0,405',.405],['0,45',.45],['0,05',.05],['0,5',.5]];N.forEach(function(n,i){y4T(g,50+i*86,52,n[0],{'font-size':17,'font-weight':800,fill:sh&&i===3?C.ok:'#1d2b3a'});if(sh){E('circle',{cx:X(n[1]),cy:110,r:5,fill:i===3?C.ok:C.a},g);y4T(g,X(n[1]),[96,86,96,86][i],n[0],{'font-size':10,'font-weight':800,fill:i===3?C.ok:C.a2})}})}
function y4kashi(st){clear();y4title('O‘nli kasrlar tarixi');var g=S.g;E('line',{x1:30,y1:100,x2:330,y2:100,stroke:'#33475b','stroke-width':3},g);
 var Y=[[1427,90,'al-Koshiy','Samarqand'],[1585,260,'Simon Stevin','Niderlandiya']];Y.forEach(function(y,i){if(i>st)return;E('circle',{cx:y[1],cy:100,r:7,fill:C.a},g);y4T(g,y[1],86,String(y[0]),{'font-size':15,'font-weight':800,fill:C.a2});y4T(g,y[1],124,y[2],{'font-size':12,'font-weight':800});y4T(g,y[1],140,y[3],{'font-size':11,fill:'#3a4a5a'})})}
var Y4P9=[function(){y4kashi(0);calc(['1427: Jamshid al-Koshiy Ulug‘bek rasadxonasida ishlagan va «Arifmetika kaliti» kitobida o‘nli kasrlarni bayon qilgan'])},function(){y4kashi(1);calc(['1585: Simon Stevin Yevropada o‘nli kasrlarni keng tarqatdi'])}];
function PRACT_STAGE(){clear();y4title('Foiz → kasr → hisob');var g=S.g;[['50%','1/2'],['25%','1/4'],['20%','1/5'],['10%','1/10'],['1%','1/100']].forEach(function(p,i){y4T(g,40+i*70,70,p[0],{'font-size':15,'font-weight':800,fill:C.a2});y4T(g,40+i*70,110,p[1],{'font-size':15,'font-weight':800})});calc(['Avval: foizni kasrga aylantiring'])}
var STEPS=[
{h:"Foiz nima?",sum:"Foiz — yuzdan bir qism. 25% = 25/100 = 1/4 = 0,25.",a:"m01",
 start:function(){startPh(Y4P1)},fin:function(){S.ph=2;Y4P1[2]()},
 html:"<p>Do'konlarda «−20%», bankda «yiliga 10%» deb yoziladi. Foiz nima? 100 katakli to'rda ko'ramiz. Bosing:</p>",btns:[phaser(Y4P1)],
 after:"<p><b>1% = 1/100</b> — butunning yuzdan biri. Asosiy foizlarni yodda tuting: <b>50% = 1/2</b>, <b>25% = 1/4</b>, <b>20% = 1/5</b>, <b>10% = 1/10</b>, 100% — butunning o'zi.</p>",
 q:{t:"0,2 qanday foiz?",opts:["20%","2%","0,2%","200%"],ok:0,why:"0,2 = 2/10 = 20/100 = 20%.",hint:"0,2 ni yuzdan qismlarda yozing.",full:"0,2 = 2/10 = 20/100, ya'ni 100 katakdan 20 tasi — 20%. «2%» — 0,02 ga to'g'ri keladi."},
 tn:"Katakli daftarda 10×10 kvadrat chizdiring. Bolalar 50%, 25%, 10% ni bo'yaydi."},
{h:"Sonning foizini topish",sum:"25% = 1/4: 80 : 4 = 20.",a:"m02",
 start:function(){y4of80(0);calc(['80 ning 25% i nechaga teng?'])},fin:function(){y4of80(1);y4msg('80 ning 25% i — <b>20</b>')},
 html:"<p>Sinfda 80 ta daftar. Ularning 25% i katakli. Nechta katakli daftar bor?</p>",
 btns:y4pick(0,[["20","25% = 1/4: 80 : 4 = 20."],["25","25 — foiz soni, daftarlar soni emas."],["55","80 − 25 — foizni son kabi ayirish xato."],["3,2","80 : 25 — bo'linuvchi va bo'luvchi aralashgan."]],function(){y4of80(1)}),g2:1,
 after:"<p>Usul: foizni <b>kasrga</b> aylantiring, keyin sonning kasrini toping: 25% → 1/4 → 80 : 4. Umumiy usul: son : 100 · foiz (80 : 100 · 25 = 20).</p>",
 q:{t:"Sinfda 25 bola, ularning 40% i qiz. O'g'illar nechta?",opts:["15","10","21","40"],ok:0,why:"40% → 25 : 100 · 40 = 10 qiz; 25 − 10 = 15.",hint:"Avval qizlarni toping.",full:"Qizlar: 25 : 100 · 40 = 10 (yoki 10% = 2,5; 40% = 10). O'g'illar: 25 − 10 = 15. «10» — qizlar, «21» — 25 − 4."},
 tn:"«Foiz → kasr» kartochkalari: bir tomonda 50%, orqada 1/2."},
{h:"10% orqali istalgan foiz",sum:"10% = son : 10 = 25; 30% = 3 · 25 = 75.",a:"m03",
 start:function(){startPh(Y4P3)},fin:function(){S.ph=2;Y4P3[2]()},
 html:"<p>30%, 15%, 70% kabi foizlar kasrga qulay aylanmaydi. Ammo <b>10%</b> doim oson. Bosing:</p>",btns:[phaser(Y4P3)],
 after:"<p>10% — sonni 10 ga bo'lish. Undan: 20% = 2 · 10%, 5% = 10% : 2, 15% = 10% + 5%. Og'zaki hisobda juda qulay usul.</p>",
 q:{t:"600 ning 15% i nechaga teng?",opts:["90","60","15","40"],ok:0,why:"10% = 60, 5% = 30; 60 + 30 = 90.",hint:"10% va 5% ni toping.",full:"10% = 600 : 10 = 60; 5% = 60 : 2 = 30; 15% = 60 + 30 = 90. «60» — faqat 10%, «40» — 600 : 15."},
 tn:"Bolalar «10% zanjiri» tuzsin: 10% → 20% → 5% → 15%."},
{h:"Chegirma: tuzoqqa tushmang",sum:"40 000 ning 25% i — 10 000 (chegirma). Yangi narx — 30 000.",a:"m04",
 start:function(){y4sale(0);calc(['Chegirmadan keyin necha so‘m to‘laymiz?'])},fin:function(){y4sale(1);y4msg('Yangi narx: <b>30 000</b> so‘m')},
 html:"<p>Ko'ylak narxi 40 000 so'm, chegirma 25%. Endi ko'ylak necha so'm turadi?</p>",
 btns:y4pick(0,[["30 000","Chegirma 40 000 : 4 = 10 000; narx 40 000 − 10 000."],["10 000","Bu — chegirma miqdori (tejalgan pul), yangi narx emas."],["39 975","25 so'mni emas, 25 foizni ayirish kerak."],["50 000","Chegirmada narx tushadi, oshmaydi."]],function(){y4sale(1)}),g2:1,
 after:"<p>Ikki savolni farqlang: «chegirma qancha?» (foiz miqdori) va «yangi narx?» (narx − chegirma). Qisqa yo'l: 25% chegirma → 75% to'lanadi: 40 000 : 4 · 3.</p>",
 q:{t:"Do'kon narxni 20% ga tushirdi, endi mahsulot 24 000 so'm. Avvalgi narx qancha edi?",opts:["30 000 so'm","28 800 so'm","120 000 so'm","19 200 so'm"],ok:0,why:"24 000 — 80%; 10% = 3 000; 100% = 30 000.",hint:"24 000 so'm avvalgi narxning necha foizi?",full:"20% tushsa, 80% qoladi: 24 000 = 80%. 10% = 3 000, 100% = 30 000. «28 800» — 24 000 ga 20% qo'shish (xato: foiz eski narxdan olinadi)."},
 tn:"Do'kon reklamalaridan (gazeta) chegirmali narxlarni hisoblash mashqi."},
{h:"Teskari masala: foizdan songa",sum:"20% = 1/5 → 12. Butun = 12 · 5 = 60.",a:"m05",
 start:function(){y4back(0);calc(['Bir bo‘lak (20%) ma‘lum. Butun-chi?'])},fin:function(){y4back(1);y4msg('Son: <b>60</b>')},
 html:"<p>Sonning 20% i 12 ga teng. Sonning o'zi nechaga teng?</p>",
 btns:y4pick(0,[["60","20% = 1/5, demak butun 5 ta bo'lak: 12 · 5 = 60."],["240","12 · 20 — foizni ko'paytiruvchi qilib olish xato."],["2,4","12 ning 20% i — boshqa savol."],["32","12 + 20 — bunday qo'shib bo'lmaydi."]],function(){y4back(1)}),g2:1,
 after:"<p>Bo'lak ma'lum, butun noma'lum: avval <b>1%</b> yoki <b>10%</b> ni toping, keyin 100% gacha ko'paytiring. 20% = 12 → 10% = 6 → 100% = 60.</p>",
 q:{t:"Maydonning 35% i ekilgan, ekilmagan qismi 13 ga. Butun maydon necha gektar?",opts:["20 ga","48 ga","35 ga","13 ga"],ok:0,why:"Ekilmagan 65% = 13; 5% = 1; 100% = 20.",hint:"Ekilmagan qism necha foiz?",full:"Ekilmagan: 100% − 35% = 65% = 13 ga. 5% = 13 : 13 = 1 ga, 100% = 20 ga. «48» — 35 + 13, «13» — faqat ekilmagan qism."},
 tn:"Chizma (Singapur): tasmani 20 ta 5% lik bo'lakka bo'ling — ma'lum bo'lakni bo'yang."},
{h:"Tuzoq: +10% va −10% joyiga qaytarmaydi",sum:"100 000 → 110 000 → 99 000. Foiz har gal yangi sondan.",a:"m06",
 start:function(){startPh(Y4P6)},fin:function(){S.ph=2;Y4P6[2]()},
 html:"<p>Narx 10% ga oshdi, keyin 10% ga tushdi. Ko'pchilik «joyiga qaytdi» deydi. Tekshiramiz:</p>",btns:[phaser(Y4P6)],
 after:"<p>Ketma-ket foizlar <b>har gal yangi songa</b> qo'llanadi. Shuning uchun +10% −10% ≠ 0. Bank foizlari ham shunday: 2-yili foiz endi kattaroq summadan olinadi.</p>",
 q:{t:"Bankka 200 000 so'm qo'yildi, har yili omonatga 10% qo'shiladi. 2 yildan keyin qancha bo'ladi?",opts:["242 000 so'm","240 000 so'm","220 000 so'm","400 000 so'm"],ok:0,why:"1-yil: 220 000; 2-yil: +22 000 = 242 000.",hint:"2-yili foiz qaysi summadan olinadi?",full:"1-yil: 200 000 + 20 000 = 220 000. 2-yil: 220 000 ning 10% i = 22 000; 220 000 + 22 000 = 242 000. «240 000» — ikkala yil ham 200 000 dan olish."},
 tn:"Bolalarga savol: do'kon «avval +20%, keyin −20%» qilsa, kim yutadi? Hisoblab ko'rsin."},
{h:"O'nli kasrlar bilan amallar",sum:"2,35 · 3 = 7,05 m. Sm ga o'tkazib hisoblash qulay: 235 · 3 = 705 sm.",a:"m07",
 start:function(){y4ribbon(0);calc(['Uchta lenta birga necha metr?'])},fin:function(){y4ribbon(1);y4msg('Jami <b>7,05 m</b>')},
 html:"<p>Har biri 2,35 m dan uchta lenta bor. Jami necha metr?</p>",
 btns:y4pick(1,[["6,15 m","2 · 3 = 6 to'g'ri, lekin 0,35 · 3 = 1,05 (0,15 emas): 35 · 3 = 105 yuzdan bir."],["7,05 m","2,35 · 3: 2 · 3 = 6 va 0,35 · 3 = 1,05; 6 + 1,05 = 7,05."],["7,5 m","1,05 dagi 0 ni tushirib qoldirdingiz: 7,05 ≠ 7,5."],["70,5 m","Vergul joyi xato: 3 ta lenta 70 m bo'lishi mumkin emas."]],function(){y4ribbon(1)}),g2:1,
 after:"<p>Vergulda adashmaslik uchun: kichik birlikka o'ting (m → sm), butun sonlar bilan hisoblang, keyin qaytaring. Natijani chamalab tekshiring: 2,35 ≈ 2,5; 2,5 · 3 ≈ 7,5 — javob shu atrofda.</p>",
 q:{t:"Xona 4,5 m ga 3 m. Polning yuzi qancha?",opts:["13,5 m²","15 m²","7,5 m²","12,5 m²"],ok:0,why:"4,5 · 3 = 13,5.",hint:"Yuz = eni · bo'yi. 4,5 · 3 ni 4 · 3 va 0,5 · 3 ga ajrating.",full:"4 · 3 = 12, 0,5 · 3 = 1,5; 12 + 1,5 = 13,5 m². «7,5» — perimetr yarmi (4,5 + 3), «15» — 5 · 3."},
 tn:"Ruletka bilan sinf xonasini o'lchab, yuzini o'nli kasrlarda hisoblang."},
{h:"Tuzoq: uzun kasr — katta emas",sum:"0,5 > 0,45 > 0,405 > 0,05. Xonama-xona taqqoslang.",a:"m08",
 start:function(){y4dec(0);calc(['Raqami ko‘p son kattami?'])},fin:function(){y4dec(1);y4msg('<b>0,5</b> — eng katta (0,50 > 0,45)')},
 html:"<p>To'rtta o'nli kasr. Qaysi biri eng katta?</p>",
 btns:y4pick(3,[["0,405","Raqami ko'p, lekin o'ndan birlar: 4 < 5. 0,405 < 0,5."],["0,45","0,45 = 0,45; 0,5 = 0,50. 45 yuzdan bir < 50 yuzdan bir."],["0,05","Bu 5 yuzdan bir — juda kichik."],["0,5","0,5 = 0,50 = 0,500 — o'ndan birlar xonasida eng katta raqam 5."]],function(){y4dec(1)}),g2:1,
 after:"<p>O'nli kasrlarni taqqoslashda xonalarni tenglang: 0,5 = 0,500; 0,45 = 0,450; 0,405. Keyin xonama-xona chapdan solishtiring. Son o'qi ham yordam beradi.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["0,7 > 0,69","0,7 < 0,69","0,7 = 0,07","0,07 > 0,7"],ok:0,why:"0,70 > 0,69.",hint:"0,7 ni yuzdan birlarda yozing.",full:"0,7 = 0,70; 70 > 69 yuzdan bir. Shuning uchun 0,7 > 0,69. 0,07 esa 0,7 dan 10 marta kichik."},
 tn:"Pul bilan tushuntiring: 0,5 ming = 500 so'm, 0,45 ming = 450 so'm."},
{h:"Bilasizmi? O'nli kasr va Samarqand",sum:"1427 — al-Koshiy Samarqandda o'nli kasrlarni bayon qildi; 1585 — Stevin Yevropada.",a:"m09",
 start:function(){startPh(Y4P9)},fin:function(){S.ph=1;Y4P9[1]()},
 html:"<p>O'nli kasrlar tarixida yurtimizning o'rni bor. Bosing:</p>",btns:[phaser(Y4P9)],
 after:"<p>🔭 Jamshid al-Koshiy Mirzo Ulug'bek rasadxonasining olimlaridan biri edi. Uning «Miftoh al-hisob» («Arifmetika kaliti») kitobida o'nli kasrlar bilan hisoblash batafsil yozilgan. % belgisi esa italyancha «per cento» (yuzga) so'zlarining qisqartmasidan kelib chiqqan.</p>",
 tn:"Ulug'bek rasadxonasi haqida qisqa suhbat; xaritada Samarqandni ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>1% = 1/100. 50% = 1/2, 25% = 1/4, 20% = 1/5, 10% = 1/10.</li><li>Sonning foizi: son : 100 · foiz (yoki 10% orqali).</li><li>Foizdan son: bo'lak → 10% (yoki 1%) → 100%.</li><li>Chegirma ≠ yangi narx. 25% chegirma → 75% to'lanadi.</li><li>Ketma-ket foizlar har gal yangi sondan olinadi.</li><li>O'nli kasrlarda xonalarni tenglang (0,5 = 0,50) va birlikka o'tib hisoblang.</li></ul></div>",
 tn:"Uyga: oiladagi bitta xaridda chegirmani hisoblab kelish."}
];
var PROBS=[
{t:"80 ning 25% i nechaga teng?",o:["20","25","55","32"],k:0,s:"80 : 4 = 20."},
{t:"300 ning 10% i nechaga teng?",o:["30","3","290","10"],k:0,s:"300 : 10 = 30."},
{t:"50% qaysi kasrga teng?",o:["1/2","1/5","1/50","2"],k:0,s:"50/100 = 1/2."},
{t:"0,25 qaysi kasrga teng?",o:["1/4","1/25","2/5","25"],k:0,s:"25/100 = 1/4."},
{t:"250 ning 30% i nechaga teng?",o:["75","7,5","220","25"],k:0,s:"10% = 25; 3 · 25 = 75."},
{t:"Ko'ylak 40 000 so'm, chegirma 25%. Yangi narx?",o:["30 000 so'm","10 000 so'm","39 975 so'm","50 000 so'm"],k:0,s:"40 000 − 10 000."},
{t:"Sonning 20% i 12 ga teng. Sonning o'zi?",o:["60","240","2,4","32"],k:0,s:"12 · 5 = 60."},
{t:"Narx 100 000 so'm. Avval 10% ga oshdi, keyin 10% ga kamaydi. Oxirgi narx?",o:["99 000 so'm","100 000 so'm","101 000 so'm","90 000 so'm"],k:0,s:"110 000 − 11 000."},
{t:"Sinfda 25 bola, ularning 40% i qiz. O'g'illar nechta?",o:["15","10","21","40"],k:0,s:"Qizlar 10; 25 − 10."},
{t:"3 ta lenta, har biri 2,35 m. Jami necha metr?",o:["7,05 m","6,15 m","7,5 m","70,5 m"],k:0,s:"235 · 3 = 705 sm."},
{t:"Qaysi son eng katta?",o:["0,5","0,45","0,405","0,4999"],k:0,s:"0,5 = 0,5000."},
{t:"Olmaning kilosi 12 000 so'm. 2,5 kg olma necha so'm?",o:["30 000 so'm","24 000 so'm","25 000 so'm","3 000 so'm"],k:0,s:"24 000 + 6 000."},
{t:"Bankka 200 000 so'm qo'yildi, har yili 10% qo'shiladi. 2 yildan keyin qancha bo'ladi?",o:["242 000 so'm","240 000 so'm","220 000 so'm","400 000 so'm"],k:0,s:"220 000 + 22 000."},
{t:"Maydonning 35% i ekilgan, ekilmagan qismi 13 ga. Butun maydon?",o:["20 ga","48 ga","35 ga","13 ga"],k:0,s:"65% = 13; 100% = 20."},
{t:"Mahsulot narxi 50 000 so'mdan 60 000 so'mga oshdi. Necha foizga oshgan?",o:["20%","10%","60%","17%"],k:0,s:"10 000 — 50 000 ning 1/5 qismi."},
{t:"6,4 − 2,75 = ?",o:["3,65","4,35","3,75","4,65"],k:0,s:"6,40 − 2,75."},
{t:"0,7 + 0,35 = ?",o:["1,05","0,42","0,105","1,005"],k:0,s:"0,70 + 0,35."},
{t:"Avtobusda 40 yo'lovchi edi. Bekatda 25% i tushdi, keyin 6 kishi chiqdi. Endi nechta yo'lovchi?",o:["36","24","30","46"],k:0,s:"40 − 10 + 6."},
{t:"Xona 4,5 m ga 3 m. Polning yuzi?",o:["13,5 m²","15 m²","7,5 m²","12,5 m²"],k:0,s:"12 + 1,5."},
{t:"Do'kon narxni 20% ga tushirdi, endi mahsulot 24 000 so'm. Avvalgi narx?",o:["30 000 so'm","28 800 so'm","120 000 so'm","19 200 so'm"],k:0,s:"80% = 24 000 → 100% = 30 000."}
];
var PREP_DATA={teach:["Foiz — yuzdan bir; asosiy foiz–kasr juftliklari.","Sonning foizini topish; 10% orqali hisoblash.","Chegirma va yangi narx; foizdan sonni topish.","Ketma-ket foiz o'zgarishlari, bank foizi.","O'nli kasrlar: ko'paytirish, ayirish, taqqoslash."],
 mist:["Foizni son kabi ayiradi (40 000 − 25).","Chegirma miqdorini yangi narx deb javob beradi.","Teskari masalada foizni ko'paytiradi (12 · 20).","+10% −10% ni joyiga qaytadi deb o'ylaydi.","O'nli kasrda «raqami ko'p — katta» deb o'ylaydi; vergulni noto'g'ri qo'yadi."],
 need:["10×10 katakli varaqlar.","Gazeta reklamalari (chegirmalar), ruletka."],
 board:["<span class='w2'>1% = 1/100</span>; 25% = 1/4; 10% = son : 10.","Chegirma 25% → <span class='w2'>to'lov 75%</span>.","100 000 → 110 000 → <span class='w2'>99 000</span>.","0,5 = 0,50 > 0,45."]};
