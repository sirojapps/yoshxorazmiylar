var CODE='2Y4',TITLE='2-sinf yakuni · Yuz va perimetrga oid murakkab masalalar';
// ---------- katakli sahna ----------
var Y4c=16,Y4x=20,Y4y=14;
function y4rect(x,y,w,h){var a=[];for(var i=0;i<w;i++)for(var j=0;j<h;j++)a.push((x+i)+','+(y+j));return a}
function y4per(cells){var set={},p=0;cells.forEach(function(c){set[c]=1});cells.forEach(function(c){var q=c.split(',').map(Number);[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(d){if(!set[(q[0]+d[0])+','+(q[1]+d[1])])p++})});return p}
function y4draw(cells,o){o=o||{};clear();var g=S.g;for(var i=0;i<20;i++)for(var j=0;j<9;j++)E('rect',{x:Y4x+i*Y4c,y:Y4y+j*Y4c,width:Y4c,height:Y4c,fill:'none',stroke:'#e6edf3'},g);
 var set={};cells.forEach(function(c){set[c]=1});var k=0;
 cells.forEach(function(c){var q=c.split(',').map(Number);k++;E('rect',{x:Y4x+q[0]*Y4c,y:Y4y+q[1]*Y4c,width:Y4c,height:Y4c,fill:o.area?(o.cut&&o.cut.indexOf(c)>=0?'#ffd0d0':'#bfe9e3'):(o.cut&&o.cut.indexOf(c)>=0?'#ffd0d0':'#fff3df'),stroke:'#c9b28d','stroke-width':.8},g);if(o.area&&o.num)T(g,Y4x+q[0]*Y4c+8,Y4y+q[1]*Y4c+12,String(k),{'font-size':8,'font-weight':700,fill:'#0b7774'})});
 cells.forEach(function(c){var q=c.split(',').map(Number),x=Y4x+q[0]*Y4c,y=Y4y+q[1]*Y4c;[[1,0,x+Y4c,y,x+Y4c,y+Y4c],[-1,0,x,y,x,y+Y4c],[0,1,x,y+Y4c,x+Y4c,y+Y4c],[0,-1,x,y,x+Y4c,y]].forEach(function(d){if(!set[(q[0]+d[0])+','+(q[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.per?C.bad:'#8a5a24','stroke-width':o.per?3:2,'stroke-linecap':'round'},g)})});
 if(o.lab)T(g,180,168,o.lab,{'font-size':12,'font-weight':800,fill:C.blue})}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var Y4R1=[[12,1],[6,2],[4,3]],Y4R2=[[5,1],[4,2],[3,3]];
var Y4P4=[function(){var c=y4rect(6,2,5,4);y4draw(c);y4msg('5 × 4 to‘rtburchak: yuz = 20, perimetr = 18')},
 function(){var c=y4rect(6,2,5,4);y4draw(c,{cut:['10,2']});y4msg('Burchakdagi 1 katakni kesib olamiz…')},
 function(){var c=y4rect(6,2,5,4).filter(function(x){return x!=='10,2'});y4draw(c,{per:1});y4msg('Yuz: 20 − 1 = <b>19</b>. Perimetr: <b>'+y4per(c)+'</b> — o‘zgarmadi!')}];
var Y4P5=[function(){var a=y4rect(3,3,3,3),b=y4rect(10,3,3,3);y4draw(a.concat(b),{per:1});y4msg('Ikki kvadrat 3 × 3: har birining perimetri 12, jami 24')},
 function(){var a=y4rect(5,3,3,3),b=y4rect(9,3,3,3);y4draw(a.concat(b));y4msg('Ularni yonma-yon qo‘yamiz…')},
 function(){var c=y4rect(6,3,6,3);y4draw(c,{per:1});y4msg('Yangi shakl 6 × 3: perimetr <b>'+y4per(c)+'</b>, 24 emas! Ichkaridagi 2 ta tomon yo‘qoldi (3 + 3)')}];
var Y4P7=[function(){var c=y4rect(4,1,3,6).concat(y4rect(7,4,5,3));y4draw(c);y4msg('«L» shaklining yuzi qancha? Kataklarni bittalab sanash uzoq…')},
 function(){var a=y4rect(4,1,3,6),b=y4rect(7,4,5,3);y4draw(a.concat(b),{area:1,cut:b});y4msg('Ikki to‘rtburchakka bo‘lamiz: 3 × 6 va 5 × 3')},
 function(){var a=y4rect(4,1,3,6),b=y4rect(7,4,5,3);y4draw(a.concat(b),{area:1,cut:b});y4msg('3 · 6 = 18,  5 · 3 = 15,  jami: 18 + 15 = <b>33</b> katak')}];
var STEPS=[
{h:"Yuz va perimetr — ikki xil narsa",sum:"Perimetr — chegara uzunligi (atrofidan aylanib chiqish), yuz — ichidagi kataklar soni.",a:"m01",
 start:function(){y4draw(y4rect(7,2,4,3));y4msg('Tugmalarni bosing')},fin:function(){y4draw(y4rect(7,2,4,3),{area:1,num:1,per:1});y4msg('Perimetr = 14, yuz = 12')},
 html:"<p>To'g'ri to'rtburchak 4 × 3 katak. Uning <b>perimetri</b> — atrofidagi chiziq uzunligi (chumoli aylanib chiqadi). <b>Yuzi</b> — ichidagi kataklar soni (bo'yoq qancha ketadi). Ikkalasini ko'ring:</p>",
 btns:[["🐜 Perimetr",function(c,done){y4draw(y4rect(7,2,4,3),{per:1});y4msg('Chegara: 4 + 3 + 4 + 3 = <b>14</b> ta katak tomoni');mvK(done,2)}],["🎨 Yuz",function(c,done){y4draw(y4rect(7,2,4,3),{area:1,num:1});y4msg('Ichida: 4 · 3 = <b>12</b> ta katak');mvK(done,2)},'u']],g2:1,
 after:"<p>Perimetr <b>14</b> (uzunlik — sm, m bilan o'lchanadi), yuz <b>12</b> (kataklar — sm², m² bilan). Ular har xil narsa: biri chegarani, biri ichini o'lchaydi.</p>",
 q:{t:"Kvadratning tomoni 5 katak. Uning perimetri va yuzi qancha?",opts:["P = 20, yuz = 25","P = 25, yuz = 20","P = 10, yuz = 25","P = 20, yuz = 20"],ok:0,why:"P = 5 · 4 = 20, yuz = 5 · 5 = 25.",hint:"Perimetr — 4 ta tomon yig'indisi. Yuz — tomon tomonga ko'paytmasi.",full:"Perimetr: 5 + 5 + 5 + 5 = 20. Yuz: 5 qator 5 tadan = 25. «P = 10» — faqat ikki tomon qo'shilgan."},
 tn:"Ip bilan shaklni o'rab perimetrni, kvadratcha kartochkalar bilan yuzni o'lchatib ko'ring — ikkalasining farqi qo'lda seziladi."},
{h:"Yuzi bir xil — perimetri har xil",sum:"12 katak: 12×1 (P=26), 6×2 (P=16), 4×3 (P=14). Kvadratga yaqini — perimetri kichik.",a:"m02",
 start:function(){S.y4i=0;y4one(Y4R1,0)},fin:function(){y4one(Y4R1,2)},
 html:"<p>12 ta katakdan har xil to'g'ri to'rtburchak yasash mumkin. Tugmani bosib, ularning perimetrini solishtiring.</p>",
 btns:[["🔄 Boshqa shakl",function(c,done){S.y4i=(S.y4i+1)%3;y4one(Y4R1,S.y4i);mvK(done,2)}]],
 after:"<p>Yuz uchalasida ham <b>12</b>, perimetr esa 26, 16, 14 — har xil! Shakl qancha <b>cho'zinchoq</b> bo'lsa, perimetri shuncha katta; <b>kvadratga</b> yaqinlashsa — kichik.</p>",
 q:{t:"Yuzi 8 katak bo'lgan qaysi to'g'ri to'rtburchakning perimetri eng kichik?",opts:["4 × 2","8 × 1","Ikkalasi teng","2 × 2"],ok:0,why:"4 × 2: P = 12; 8 × 1: P = 18.",hint:"Ikkalasining perimetrini hisoblang. 2 × 2 ning yuzi necha?",full:"4 × 2: 4 + 2 + 4 + 2 = 12. 8 × 1: 8 + 1 + 8 + 1 = 18. 2 × 2 ning yuzi 4, 8 emas. Javob: 4 × 2."},
 tn:"Bolalar 12 ta kvadratcha kartochkadan barcha to'g'ri to'rtburchaklarni o'zi yasab, perimetrini yozsin."},
{h:"Perimetri bir xil — yuzi har xil",sum:"P = 12: 5×1 (yuz 5), 4×2 (8), 3×3 (9). Kvadratning yuzi eng katta.",a:"m03",
 start:function(){S.y4i=0;y4one(Y4R2,0)},fin:function(){y4one(Y4R2,2)},
 html:"<p>Endi teskarisi: 12 katak uzunlikdagi <b>ip</b> bilan o'ralgan shakllar. Perimetr bir xil — yuz-chi?</p>",
 btns:[["🔄 Boshqa shakl",function(c,done){S.y4i=(S.y4i+1)%3;y4one(Y4R2,S.y4i);mvK(done,2)}]],
 after:"<p>Perimetr uchalasida <b>12</b>, yuz esa 5, 8, 9. Bir xil ip bilan eng katta maydonni <b>kvadrat</b> o'raydi. Shuning uchun dehqonlar bir xil devor bilan kattaroq bog' olish uchun kvadratga yaqin shakl tanlashadi.</p>",
 q:{t:"Perimetri 16 bo'lgan qaysi to'g'ri to'rtburchakning yuzi eng katta?",opts:["4 × 4","7 × 1","6 × 2","5 × 3"],ok:0,why:"4 × 4 = 16 — kvadrat, eng katta.",hint:"Har birining yuzini hisoblang: tomonlarni ko'paytiring.",full:"7 × 1 = 7, 6 × 2 = 12, 5 × 3 = 15, 4 × 4 = 16. Hammasining perimetri 16, eng katta yuz kvadratda."},
 tn:"12 sm ip bilan katakli qog'ozda turli shakllar o'rab, kataklarni sanatib ko'ring."},
{h:"Tuzoq: kesib olsak, perimetr kamayadimi?",sum:"Burchakdan 1 katak kesilsa: yuz 1 ga kamayadi, perimetr o'zgarmaydi.",a:"m04",
 start:function(){startPh(Y4P4)},fin:function(){S.ph=2;Y4P4[2]()},
 html:"<p>5 × 4 to'g'ri to'rtburchakning burchagidan bitta katak kesib olinsa, perimetri qanday o'zgaradi? Ko'pchilik «kamayadi» deydi. Tekshiramiz!</p>",
 btns:[phaser(Y4P4)],
 after:"<p>Kesilgan katakning ikkita tomoni yo'qoldi, lekin uning o'rniga <b>ikkita yangi tomon</b> ochildi. Shuning uchun perimetr o'zgarmadi — 18, yuz esa 19 bo'ldi.</p>",
 q:{t:"Kvadrat 4 × 4 ning bir burchagidan 1 ta katak kesildi. Perimetr qancha bo'ladi?",opts:["16","14","15","12"],ok:0,why:"Burchakdan kesilganda perimetr o'zgarmaydi: 4 · 4 = 16.",hint:"Kesilgan katakning qaysi tomonlari yo'qoldi, qaysilari paydo bo'ldi?",full:"Avval P = 16. Burchak kesilganda 2 tomon ketadi, 2 tomon paydo bo'ladi — P = 16. Yuz esa 16 − 1 = 15."},
 tn:"Qog'oz to'g'ri to'rtburchakning burchagini qaychi bilan kesib, ip bilan perimetrini o'lchang — bolalar hayron qoladi."},
{h:"Tuzoq: yopishtirsak, perimetrlar qo'shiladimi?",sum:"Ikki 3×3 kvadrat yonma-yon: perimetr 24 emas, 18 (ichki 2 tomon yo'qoladi).",a:"m05",
 start:function(){startPh(Y4P5)},fin:function(){S.ph=2;Y4P5[2]()},
 html:"<p>Har birining perimetri 12 bo'lgan ikki kvadratni yonma-yon qo'ysak, yangi shaklning perimetri 12 + 12 = 24 bo'ladimi?</p>",
 btns:[phaser(Y4P5)],
 after:"<p>Yonma-yon qo'yilganda tegib turgan tomonlar <b>ichkariga</b> kirib qoladi va perimetrga kirmaydi. 24 − 3 − 3 = <b>18</b>. Yuz esa qo'shiladi: 9 + 9 = 18.</p>",
 q:{t:"Ikki 2 × 2 kvadrat yonma-yon qo'yildi. Yangi shaklning perimetri?",opts:["12","16","8","10"],ok:0,why:"Shakl 4 × 2: 4 + 2 + 4 + 2 = 12.",hint:"Yangi shakl qanday to'g'ri to'rtburchak bo'ldi?",full:"Har bir kvadrat P = 8, jami 16. Lekin tegib turgan 2 + 2 = 4 ta tomon yo'qoladi: 16 − 4 = 12. Yangi shakl 4 × 2."},
 tn:"Ikki kvadrat kartochkani yonma-yon qo'yib, tashqi chegarani bo'r bilan aylantiring."},
{h:"Perimetrdan tomonni topish",sum:"P = 20, bir tomoni 6: ikki tomon yig'indisi 20 : 2 = 10, ikkinchi tomon 10 − 6 = 4.",a:"m06",
 start:function(){y4side(0)},fin:function(){y4side(2)},
 html:"<p>To'g'ri to'rtburchakning perimetri <b>20</b>, bir tomoni <b>6</b>. Ikkinchi tomonini toping. Bosqichlarni bosing:</p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.y4s=(S.y4s||0)+1;y4side(S.y4s);if(S.y4s>=2){b.disabled=true;done()}}]],
 after:"<p>Perimetr — bu <b>ikkita</b> eni va <b>ikkita</b> bo'yi. Demak bitta eni + bitta bo'yi = 20 : 2 = 10. Ikkinchi tomon: 10 − 6 = <b>4</b>. Tekshiramiz: 6 + 4 + 6 + 4 = 20 ✓</p>",
 q:{t:"Kvadratning perimetri 24 sm. Uning tomoni necha sm?",opts:["6","12","8","4"],ok:0,why:"Kvadratda 4 ta teng tomon: 24 : 4 = 6.",hint:"Kvadratning nechta tomoni bor va ular qanday?",full:"Kvadratning 4 tomoni teng: 24 : 4 = 6 sm. «12» — 2 ga bo'lingan (to'g'ri to'rtburchakdagi kabi), lekin kvadratda 4 ga bo'linadi."},
 tn:"Formulani yodlatmang — «chumoli aylanib chiqadi, nechta tomondan o'tadi?» deb so'rang."},
{h:"Murakkab shakl yuzi",sum:"«L» shakl — ikki to'g'ri to'rtburchak: 3·6 + 5·3 = 18 + 15 = 33.",a:"m07",
 start:function(){startPh(Y4P7)},fin:function(){S.ph=2;Y4P7[2]()},
 html:"<p>Shakl to'g'ri to'rtburchak emas — «L» harfiga o'xshaydi. Kataklarni bittalab sanamasdan yuzini topamiz.</p>",
 btns:[phaser(Y4P7)],
 after:"<p>Murakkab shaklni <b>to'g'ri to'rtburchaklarga bo'lamiz</b>, har birining yuzini topib, qo'shamiz. Boshqa usul ham bor: katta to'g'ri to'rtburchakdan bo'sh joyni ayirish.</p>",
 q:{t:"Shakl 4 × 5 to'g'ri to'rtburchakdan iborat, uning yoniga 2 × 3 to'g'ri to'rtburchak qo'shilgan. Shaklning yuzi?",opts:["26","20","6","14"],ok:0,why:"4 · 5 = 20, 2 · 3 = 6, 20 + 6 = 26.",hint:"Har bir bo'lakning yuzini alohida toping.",full:"Katta bo'lak: 4 · 5 = 20. Kichik bo'lak: 2 · 3 = 6. Jami 26 katak. «14» — tomonlar qo'shilgan (perimetr kabi), bu xato."},
 tn:"Bolalar katakli daftarda murakkab shakl chizib, uni ikki xil usulda bo'lsin — javob bir xil chiqishi kerak."},
{h:"Bilasizmi? «Geometriya» — «yer o'lchash»",sum:"Qadimgi Misrda Nil toshqinidan keyin yerlar qayta o'lchangan; «geometriya» yunoncha «yer o'lchash».",a:"m08",
 start:function(){y4draw(y4rect(3,1,6,4).concat(y4rect(11,3,5,4)),{area:1});y4msg('Misrda yer maydonlari har yili qayta o‘lchangan')},fin:function(){y4draw(y4rect(3,1,6,4).concat(y4rect(11,3,5,4)),{area:1});y4msg('Misrda yer maydonlari har yili qayta o‘lchangan')},
 html:"<p>🏺 Qadimgi Misrda Nil daryosi har yili toshib, dalalar chegarasini yuvib ketardi. Shundan keyin yer o'lchovchilar dalalarni <b>qayta o'lchab</b>, har kimga avvalgi yerini berishgan.</p><p>📜 «Geometriya» so'zi yunoncha <b>«yer o'lchash»</b> degani. Yuz va perimetr — eng qadimgi matematik bilimlardan!</p>",
 tn:"Maktab hovlisi yoki sinf xonasining perimetrini qadam bilan o'lchab ko'ring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){y4draw(y4rect(7,2,4,3),{area:1,per:1});y4msg('P = 14, yuz = 12')},fin:function(){y4draw(y4rect(7,2,4,3),{area:1,per:1});y4msg('P = 14, yuz = 12')},
 html:"<div class='memo'><ul><li><b>Perimetr</b> — chegara uzunligi; <b>yuz</b> — ichidagi kataklar.</li><li>To'g'ri to'rtburchak: P = eni + bo'yi + eni + bo'yi; yuz = eni · bo'yi.</li><li>Yuzi bir xil — perimetri har xil bo'lishi mumkin (12×1 va 4×3).</li><li>Perimetri bir xil — kvadratning yuzi eng katta.</li><li>Burchak kesilsa — perimetr <b>o'zgarmaydi</b>, yuz kamayadi.</li><li>Shakllar yopishtirilsa — tegib turgan tomonlar perimetrga <b>kirmaydi</b>.</li><li>P va bir tomon ma'lum: P : 2 − tomon = ikkinchi tomon.</li><li>Murakkab shakl — to'g'ri to'rtburchaklarga bo'ling.</li></ul></div>",
 tn:"Keyingi darsni «Perimetri 20 bo'lgan qaysi to'g'ri to'rtburchakning yuzi eng katta?» (5 × 5 = 25) savoli bilan boshlang."}
];
function y4one(R,i){var r=R[i],x=Math.floor((20-r[0])/2),y=Math.floor((9-r[1])/2),c=y4rect(x,y,r[0],r[1]);y4draw(c,{area:1,per:1});
 y4msg(R.map(function(q,k){return (k===i?'<b>':'')+q[0]+' × '+q[1]+': yuz '+q[0]*q[1]+', P '+2*(q[0]+q[1])+(k===i?'</b>':'')}).join(' &nbsp;·&nbsp; '))}
function y4side(k){var c=y4rect(7,2,6,4);y4draw(c,{per:1});var g=S.g;T(g,Y4x+10*Y4c,Y4y+2*Y4c-6,'6',{'font-size':14,'font-weight':800,fill:C.blue});T(g,Y4x+13*Y4c+14,Y4y+4*Y4c+4,k>=2?'4':'?',{'font-size':14,'font-weight':800,fill:k>=2?C.ok:C.bad});
 calc(['P = 20, bir tomon 6'].concat(k>=1?['Eni + bo‘yi = 20 : 2 = <b>10</b>']:[]).concat(k>=2?['Ikkinchi tomon: 10 − 6 = <b>4</b>']:[]))}
var PROBS=[
{t:"To'g'ri to'rtburchak 6 × 3. Uning perimetri?",o:["18","9","12","36"],k:0,s:"6 + 3 + 6 + 3 = 18."},
{t:"To'g'ri to'rtburchak 6 × 3. Uning yuzi?",o:["18","9","12","36"],k:0,s:"6 · 3 = 18 katak."},
{t:"Kvadratning tomoni 7 sm. Perimetri?",o:["28","49","14","21"],k:0,s:"7 · 4 = 28 sm."},
{t:"Kvadratning perimetri 32 sm. Tomoni?",o:["8","16","4","28"],k:0,s:"32 : 4 = 8 sm."},
{t:"To'g'ri to'rtburchakning perimetri 18, bir tomoni 5. Ikkinchi tomoni?",o:["4","13","9","8"],k:0,s:"18 : 2 = 9, 9 − 5 = 4."},
{t:"Yuzi 16 bo'lgan qaysi to'g'ri to'rtburchakning perimetri eng kichik?",o:["4 × 4","8 × 2","16 × 1","2 × 8 va 4 × 4 teng"],k:0,s:"4×4: 16, 8×2: 20, 16×1: 34."},
{t:"Perimetri 20 bo'lgan qaysi to'g'ri to'rtburchakning yuzi eng katta?",o:["5 × 5","6 × 4","8 × 2","9 × 1"],k:0,s:"25 > 24 > 16 > 9."},
{t:"5 × 5 kvadratning burchagidan 1 katak kesildi. Perimetr?",o:["20","18","19","16"],k:0,s:"Burchak kesilganda perimetr o'zgarmaydi: 20."},
{t:"5 × 5 kvadratning burchagidan 1 katak kesildi. Yuz?",o:["24","25","20","23"],k:0,s:"25 − 1 = 24."},
{t:"Ikki 4 × 4 kvadrat yonma-yon qo'yildi. Yangi shakl perimetri?",o:["24","32","16","28"],k:0,s:"Shakl 8 × 4: 8 + 4 + 8 + 4 = 24."},
{t:"Uchta 1 × 1 katak bir qatorga qo'yildi. Perimetr?",o:["8","12","6","3"],k:0,s:"Shakl 3 × 1: 3 + 1 + 3 + 1 = 8."},
{t:"Kvadratning yuzi 36 katak. Uning perimetri?",o:["24","36","18","12"],k:0,s:"6 · 6 = 36, tomon 6, P = 24."},
{t:"«L» shakl: 2 × 5 va 3 × 2 to'g'ri to'rtburchaklardan. Yuzi?",o:["16","10","12","14"],k:0,s:"10 + 6 = 16."},
{t:"To'g'ri to'rtburchakning bo'yi 8, eni bo'yidan 3 ta qisqa. Perimetr?",o:["26","13","40","22"],k:0,s:"Eni 5. P = 8 + 5 + 8 + 5 = 26."},
{t:"To'g'ri to'rtburchakning bo'yi 8, eni bo'yidan 3 ta qisqa. Yuz?",o:["40","26","24","13"],k:0,s:"Eni 5, yuz 8 · 5 = 40."},
{t:"Ip uzunligi 16 sm. Undan qaysi kvadratni yasash mumkin?",o:["tomoni 4 sm","tomoni 8 sm","tomoni 16 sm","tomoni 2 sm"],k:0,s:"Kvadrat perimetri 16: tomon 16 : 4 = 4."},
{t:"Yuzi 12 katak bo'lgan necha xil to'g'ri to'rtburchak bor (tomonlari butun katak; 3×4 va 4×3 bitta)?",o:["3","2","4","6"],k:0,s:"1×12, 2×6, 3×4 — 3 xil."},
{t:"Ikki kvadrat: tomonlari 2 va 3. Ularning yuzlari yig'indisi?",o:["13","10","25","5"],k:0,s:"4 + 9 = 13."},
{t:"6 × 4 to'g'ri to'rtburchak 4 × 4 kvadrat va qanday to'g'ri to'rtburchakka bo'lindi?",o:["2 × 4","2 × 2","4 × 6","6 × 2"],k:0,s:"6 − 4 = 2: qolgan bo'lak 2 × 4."},
{t:"Bog' 9 m × 4 m. Uni kvadrat shaklga keltirsak (yuz o'zgarmasin), tomoni necha m?",o:["6","13","5","9"],k:0,s:"Yuz 36, 6 · 6 = 36 — tomon 6 m."}
];
function PRACT_STAGE(){y4draw(y4rect(7,2,4,3),{area:1,per:1});y4msg('P — chegara, yuz — ichi')}
var PREP_DATA={teach:["Perimetr va yuz farqi; katakli qog'ozda hisoblash.","Yuz bir xil — perimetr har xil va aksincha.","Kesish va yopishtirish tuzoqlari.","Perimetrdan tomonni topish; murakkab shakl yuzi."],
 mist:["Yuz va perimetrni aralashtiradi.","Burchak kesilganda perimetr kamayadi deb o'ylaydi.","Yopishtirilgan shakllar perimetrini qo'shib yuboradi.","Kvadrat perimetridan tomonni 2 ga bo'lib topadi."],
 need:["Katakli qog'oz, qaychi, ip.","Kvadratcha kartochkalar (12–16 ta)."],
 board:["4 × 3: <span class='w2'>P = 14, yuz = 12</span>.","12 katak: 12×1, 6×2, 4×3 — P: 26, 16, 14.","P = 12: 5×1, 4×2, 3×3 — yuz: 5, 8, 9.","Burchak kesilsa: P o'zgarmaydi.","Ikki 3×3 → 6×3: P = 18.","<span class='w2'>P = 20, tomon 6 → 20 : 2 − 6 = 4</span>."]};
