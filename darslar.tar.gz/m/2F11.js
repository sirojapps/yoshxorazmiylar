var CODE='2F11',TITLE='2-sinf · Hajmli shakllar va hajm (kubiklar bilan)';
// ---------- izometrik kubiklar ----------
function h11Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function h11Cube(p,ox,oy,a,x,y,z,col,num){var sx=ox+(x-y)*a*0.87,sy=oy+(x+y)*a*0.5-z*a,h=a*0.87,v=a*0.5;col=col||['#f7c27a','#e39a45','#c97f2e'];
 var top='M'+sx+' '+(sy-a)+' l'+h+' '+v+' l'+(-h)+' '+v+' l'+(-h)+' '+(-v)+' Z',left='M'+(sx-h)+' '+(sy-a+v)+' l'+h+' '+v+' v'+a+' l'+(-h)+' '+(-v)+' Z',right='M'+sx+' '+(sy)+' l'+h+' '+(-v)+' v'+a+' l'+(-h)+' '+v+' Z';
 E('path',{d:top,fill:col[0],stroke:'#7a4a14','stroke-width':1},p);E('path',{d:left,fill:col[1],stroke:'#7a4a14','stroke-width':1},p);E('path',{d:right,fill:col[2],stroke:'#7a4a14','stroke-width':1},p);
 if(num!=null)T(p,sx,sy-a+v+4,String(num),{'font-size':10,'font-weight':800,fill:'#5a3005'})}
function h11Stack(list,o){o=o||{};var a=o.a||22,ox=o.ox||180,oy=o.oy||70,g=E('g',{},S.g);
 list.slice().sort(function(p,q){return (p[0]+p[1])-(q[0]+q[1])||p[2]-q[2]}).forEach(function(p,i){h11Cube(g,ox,oy,a,p[0],p[1],p[2],p[3],o.num?list.indexOf(p)+1:null)})}
function h11Box(w,d,h){var l=[];for(var z=0;z<h;z++)for(var y=0;y<d;y++)for(var x=0;x<w;x++)l.push([x,y,z]);return l}
// jismlar
function h11Body(k,x,y,s){var g=S.g;s=s||1;
 if(k==='kub'){h11Cube(g,x,y+14*s,30*s,0,0,0,['#f7c27a','#e39a45','#c97f2e'])}
 if(k==='shar'){E('circle',{cx:x,cy:y,r:30*s,fill:'#7fb3e0',stroke:'#2f6f9f','stroke-width':1.5},g);E('ellipse',{cx:x,cy:y,rx:30*s,ry:9*s,fill:'none',stroke:'#2f6f9f','stroke-dasharray':'3 3'},g);E('circle',{cx:x-10*s,cy:y-10*s,r:7*s,fill:'rgba(255,255,255,.55)'},g)}
 if(k==='silindr'){E('path',{d:'M'+(x-24*s)+' '+(y-26*s)+' v'+52*s+' a'+24*s+' '+8*s+' 0 0 0 '+48*s+' 0 v'+(-52*s),fill:'#9fd9a8',stroke:'#2f7d3f','stroke-width':1.5},g);E('ellipse',{cx:x,cy:y-26*s,rx:24*s,ry:8*s,fill:'#c8ecce',stroke:'#2f7d3f','stroke-width':1.5},g)}
 if(k==='konus'){E('path',{d:'M'+x+' '+(y-34*s)+' L'+(x+26*s)+' '+(y+26*s)+' a'+26*s+' '+8*s+' 0 0 1 '+(-52*s)+' 0 Z',fill:'#f6a6b8',stroke:'#b03a5b','stroke-width':1.5},g)}
 if(k==='piramida'){E('path',{d:'M'+x+' '+(y-34*s)+' L'+(x-30*s)+' '+(y+22*s)+' L'+(x+6*s)+' '+(y+30*s)+' Z',fill:'#f2d36b',stroke:'#8a6d0e','stroke-width':1.5},g);E('path',{d:'M'+x+' '+(y-34*s)+' L'+(x+6*s)+' '+(y+30*s)+' L'+(x+30*s)+' '+(y+18*s)+' Z',fill:'#d9b84a',stroke:'#8a6d0e','stroke-width':1.5},g)}}
var BODY={kub:'Kub: 6 ta tekis yog‘, 12 qirra, 8 uch. Dumalamaydi',shar:'Shar: tekis yog‘i yo‘q, uchi yo‘q. Har tomonga dumalaydi',silindr:'Silindr: 2 ta tekis yuza (doira), bitta egri yuza. Yonboshlab dumalaydi',konus:'Konus: 1 ta tekis yuza (doira), 1 ta uch. Aylanib dumalaydi',piramida:'Piramida (asosi kvadrat): 5 ta yog‘, 5 ta uch. Dumalamaydi'};
function h11Bodies(sel){clear('#fbf7ef');var X={kub:44,shar:112,silindr:180,konus:248,piramida:316};Object.keys(X).forEach(function(k){h11Body(k,X[k],78,sel===k?1.05:.85);T(S.g,X[k],150,k,{'font-size':11,'font-weight':sel===k?800:600,fill:sel===k?C.blue:'#5b6b7b'})});h11Msg(sel?BODY[sel]:'Jismni tanlang')}
function h11Flat(k){clear('#fbf7ef');var g=S.g;
 E('rect',{x:40,y:46,width:60,height:60,fill:'#f7c27a',stroke:'#7a4a14','stroke-width':1.5},g);T(g,70,130,'kvadrat (yassi)',{'font-size':11});
 E('circle',{cx:70,cy:76,r:0},g);
 if(k>=1){h11Cube(g,250,90,40,0,0,0);T(g,250,160,'kub (hajmli)',{'font-size':11,'font-weight':800,fill:C.blue})}
 E('path',{d:'M120 76 L170 76',stroke:'#9aa8b6','stroke-width':2,'marker-end':''},g);T(g,145,68,k>=1?'→':'?',{'font-size':18,'font-weight':800,fill:'#9aa8b6'});
 h11Msg(k?'Kvadrat — qog‘ozdagi <b>yassi</b> shakl. Kub — qo‘lga olsa bo‘ladigan <b>hajmli</b> jism: uning 6 ta yog‘i — kvadratlar':'Kvadratni qog‘ozdan «ko‘tarsak», nima bo‘ladi?')}
function h11Parts(k){clear('#fbf7ef');var g=S.g,ox=180,oy=110,a=70,h=a*.87,v=a*.5,sx=ox,sy=oy;
 var P={C:[ox,oy-30],B:[ox+h,oy-30-v],A:[ox,oy-30-2*v],D:[ox-h,oy-30-v],F:[ox,oy-30+a],G:[ox+h,oy-30-v+a],E:[ox-h,oy-30-v+a]};
 var faces=[['A','B','C','D','#f7c27a'],['D','C','F','E','#e39a45'],['C','B','G','F','#c97f2e']];
 faces.forEach(function(f,i){E('path',{d:'M'+f.slice(0,4).map(function(n){return P[n].join(' ')}).join(' L')+' Z',fill:k==='yoq'&&i===0?C.hi:f[4],stroke:'#7a4a14','stroke-width':1.5},g)});
 var edges=[['A','B'],['B','C'],['C','D'],['D','A'],['D','E'],['C','F'],['B','G'],['E','F'],['F','G']];
 if(k==='qirra')edges.forEach(function(e){E('line',{x1:P[e[0]][0],y1:P[e[0]][1],x2:P[e[1]][0],y2:P[e[1]][1],stroke:C.bad,'stroke-width':4,'stroke-linecap':'round'},g)});
 if(k==='uch')['A','B','C','D','E','F','G'].forEach(function(n){E('circle',{cx:P[n][0],cy:P[n][1],r:6,fill:C.blue,stroke:'#fff','stroke-width':2},g)});
 h11Msg({yoq:'<b>Yog‘</b> — tekis kvadrat yuza. Kubda <b>6 ta</b>: 3 tasi ko‘rinadi, 3 tasi orqada (past, orqa, chap-orqa)',qirra:'<b>Qirra</b> — ikki yog‘ tutashgan chiziq. Kubda <b>12 ta</b>: 9 tasi ko‘rinadi, 3 tasi yashirin',uch:'<b>Uch</b> — qirralar uchrashgan nuqta. Kubda <b>8 ta</b>: 7 tasi ko‘rinadi, 1 tasi orqada yashirin'}[k]||'Tugmalarni bosib, kubning qismlarini ko‘ring')}
var P4=[function(){clear('#fbf7ef');h11Stack(h11Box(3,2,1),{num:1});h11Msg('Pastki qavat: 3 × 2 = <b>6</b> ta kubik')},
 function(){clear('#fbf7ef');h11Stack(h11Box(3,2,2),{oy:86});h11Msg('Yana xuddi shunday qavat: 6 + 6 = <b>12</b> ta')},
 function(){clear('#fbf7ef');h11Stack(h11Box(3,2,3),{oy:100,a:20});h11Msg('3 qavat: 6 · 3 = <b>18</b> ta kubik — bu shaklning <b>hajmi</b>')}];
var P6=[function(){clear('#fbf7ef');h11Stack(h11Box(2,2,2),{a:30,oy:80});h11Msg('2 × 2 × 2 kub. Rasmda nechta kubik ko‘rinyapti? Hammasi nechta?')},
 function(){clear('#fbf7ef');var l=h11Box(2,2,2).map(function(p){var hid=p[0]===0&&p[1]===0&&p[2]===0;return [p[0],p[1],p[2],hid?['#ffd24d','#f0b800','#d9a400']:null]});h11Stack(l,{a:30,oy:80});h11Msg('Ko‘rinadigani — <b>7</b> ta. Lekin bitta kubik orqada, ko‘rinmaydi (sariq)')},
 function(){clear('#fbf7ef');h11Stack(h11Box(2,2,1),{a:30,oy:80,ox:110});h11Stack(h11Box(2,2,1),{a:30,oy:80,ox:250});T(S.g,110,160,'pastki qavat: 4',{'font-size':11,'font-weight':800});T(S.g,250,160,'ustki qavat: 4',{'font-size':11,'font-weight':800});h11Msg('Qavatlab sanaymiz: 4 + 4 = <b>8</b> ta (7 emas!)')}];
var STEPS=[
{h:"Yassi shakl va hajmli jism",sum:"Kvadrat — yassi (qog'ozda), kub — hajmli (qo'lda ushlasa bo'ladi). Kubning yog'lari — kvadratlar.",a:"m01",
 start:function(){h11Flat(0)},fin:function(){h11Flat(1)},
 html:"<p>Shu paytgacha qog'ozdagi <b>yassi</b> shakllarni o'rgandik: kvadrat, doira, uchburchak. Atrofimizdagi narsalar esa <b>hajmli</b>: ularni qo'lga olish, aylantirish mumkin. Tugmani bosing.</p>",
 btns:[["⬆ Kvadratni «ko'tarish»",function(c,done,b){b.disabled=true;h11Flat(1);done()}]],
 after:"<p>Yassi shaklning faqat bo'yi va eni bor. Hajmli jismning yana <b>balandligi</b> ham bor. Kvadrat → <b>kub</b>, doira → <b>shar</b>, uchburchak → <b>piramida</b>.</p>",
 q:{t:"Qaysi biri hajmli jism?",opts:["kvadrat","doira","gugurt qutisi","uchburchak"],ok:2,why:"Gugurt qutisini qo'lga olsa bo'ladi — u hajmli.",hint:"Qaysi birini qog'ozga chizmasdan, qo'lda ushlash mumkin?",full:"Kvadrat, doira, uchburchak — qog'ozdagi yassi shakllar. Gugurt qutisining bo'yi, eni va balandligi bor — u hajmli jism (to'g'ri burchakli parallelepiped)."},
 tn:"Sinfga uydagi narsalarni olib keltiring: quti, koptok, konserva bankasi, muzqaymoq vaflisi. Ularni yassi rasmlar bilan solishtiring."},
{h:"Kubning qismlari",sum:"Kubda 6 ta yog', 12 ta qirra, 8 ta uch bor; rasmda ularning bir qismi ko'rinmaydi.",a:"m02",
 start:function(){h11Parts('')},fin:function(){h11Parts('qirra')},
 html:"<p>Kubni ko'rib chiqaylik. Tugmalarni bosing va har bir qismni sanang:</p>",
 btns:[["▢ yog'lar",function(c,done){h11Parts('yoq');mvK(done,3)}],["╱ qirralar",function(c,done){h11Parts('qirra');mvK(done,3)}],["• uchlar",function(c,done){h11Parts('uch');mvK(done,3)}]],g3:1,
 after:"<p>Kubda: <b>6 ta yog'</b> (hammasi teng kvadratlar), <b>12 ta qirra</b> (hammasi teng), <b>8 ta uch</b>. Rasmda hammasi ko'rinmaydi — orqadagilarini xayolan tasavvur qiling!</p>",
 q:{t:"Kubning nechta qirrasi bor?",opts:["6","8","12","4"],ok:2,why:"Tepada 4, pastda 4, yonda 4 — 12 ta.",hint:"Tepadagi kvadratda nechta qirra? Pastdagida? Ularni tutashtiruvchilar-chi?",full:"Tepa yog'ida 4 qirra, past yog'ida 4 qirra va ularni tutashtiruvchi 4 ta tik qirra: 4 + 4 + 4 = 12. «6» — yog'lar, «8» — uchlar soni."},
 tn:"Plastilin va cho'plardan kub «skeleti»ni yasang: 12 ta cho'p (qirra) va 8 ta plastilin sharcha (uch) kerak bo'ladi."},
{h:"Jismlar oilasi",sum:"Kub, shar, silindr, konus, piramida: kimning yog'i tekis, kim dumalaydi, kimning uchi bor.",a:"m03",
 start:function(){h11Bodies('')},fin:function(){h11Bodies('silindr')},
 html:"<p>Beshta jism bilan tanishing. Har birini bosib, xossalarini o'qing:</p>",
 btns:[["kub",function(c,done){h11Bodies('kub');mvK(done,3)}],["shar",function(c,done){h11Bodies('shar');mvK(done,3)}],["silindr",function(c,done){h11Bodies('silindr');mvK(done,3)}],["konus",function(c,done){h11Bodies('konus');mvK(done,3)}],["piramida",function(c,done){h11Bodies('piramida');mvK(done,3)}]],g3:1,
 after:"<p>Hayotda: koptok — <b>shar</b>, konserva bankasi — <b>silindr</b>, muzqaymoq vaflisi — <b>konus</b>, zar — <b>kub</b>. Egri yuzasi bor jismlar (shar, silindr, konus) dumalaydi, faqat tekis yog'li jismlar (kub, piramida) dumalamaydi.</p>",
 q:{t:"Shar, kub, silindr va konusdan qaysi biri stol ustida dumalay olmaydi?",opts:["shar","silindr","kub","konus"],ok:2,why:"Kubning hamma yog'i tekis — u dumalamaydi.",hint:"Qaysi jismning egri yuzasi yo'q?",full:"Shar, silindr va konusning egri yuzasi bor — ular dumalaydi. Kubning 6 ta yog'i ham tekis kvadrat — u faqat siljiydi, dumalamaydi."},
 tn:"Jismlarni qiya taxta ustiga qo'yib ko'ring: qaysi biri dumalaydi, qaysi biri sirpanadi, qaysi biri joyida qoladi?"},
{h:"Hajm — nechta kubik sig'adi",sum:"Hajm — jism egallagan joy; uni bir xil kubiklar bilan o'lchaymiz. 3 × 2 qavat, 3 qavat — 18 kubik.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Yuzni kvadratchalar bilan o'lchagan edik. <b>Hajmni</b> — bir xil <b>kubiklar</b> bilan o'lchaymiz. Kubiklardan qurilgan qutini qavatma-qavat sanaymiz.</p>",
 btns:[phaser(P4,'▶ Yana bir qavat')],
 after:"<p>Hajm = <b>bitta qavatdagi kubiklar × qavatlar soni</b>. 3 × 2 = 6 kubik bitta qavatda, 3 qavat — 6 · 3 = 18. Kubikni bittalab sanash shart emas!</p>",
 q:{t:"Bitta qavatda 4 ta kubik, jami 5 qavat. Hammasi nechta kubik?",opts:["9","20","16","45"],ok:1,why:"4 · 5 = 20.",hint:"Har qavatda bir xil kubik — qo'shish o'rniga ko'paytiring.",full:"4 + 4 + 4 + 4 + 4 = 4 · 5 = 20 kubik. «9» — 4 + 5 qo'shib yuborish."},
 tn:"Kubiklar (yoki gugurt qutilari) bilan quti quring va bolalar qavatlab sanasin. Darslikdagi «Shakllarning hajmi» (144-dars)."},
{h:"Bir xil hajm, har xil shakl",sum:"4 ta kubik qatorda yoki 2 × 2 kvadratda — shakli boshqa, hajmi bir xil: 4 kubik.",a:"m05",
 start:function(){h11Same(0)},fin:function(){h11Same(2)},
 html:"<p>4 ta kubikdan har xil shakl yasang:</p>",
 btns:[["qator",function(c,done){h11Same(0);mvK(done,2)}],["kvadrat",function(c,done){h11Same(1);mvK(done,2)}],["minora",function(c,done){h11Same(2);mvK(done,2)}]],g3:1,
 after:"<p>Kubiklar soni o'zgarmasa — <b>hajm o'zgarmaydi</b>, shakl qanday bo'lishidan qat'i nazar. Xuddi yuz kabi: kesib qayta yig'sak, yuz saqlanadi.</p>",
 q:{t:"6 ta kubikdan minora yasaldi, keyin uni buzib, 2 qatorli devor qilindi. Devorning hajmi necha kubik?",opts:["3","6","12","2"],ok:1,why:"Kubiklar o'sha 6 ta — hajm 6.",hint:"Kubiklar soni o'zgardimi?",full:"Minorada ham, devorda ham o'sha 6 ta kubik — hajm 6 kubik. Shakl o'zgardi, hajm o'zgarmadi."},
 tn:"Bolalar bir xil sonli kubiklardan kim ko'p har xil shakl yasasa — g'olib. Hammasining hajmi bir xil ekanini ta'kidlang."},
{h:"Tuzoq: yashiringan kubiklar",sum:"2 × 2 × 2 kubda ko'rinadigani 7 ta, lekin jami 8 ta — qavatlab sanang.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Rasmdagi kubiklarni sanashda eng ko'p xato — <b>orqadagi, ko'rinmaydigan</b> kubiklarni unutish. Kuzating.</p>",
 btns:[phaser(P6)],
 after:"<p>Rasmda biz faqat <b>3 tomonni</b> ko'ramiz. Orqadagi va ichkaridagi kubiklar ham bor! Shuning uchun <b>qavatlab</b> sanash ishonchli: har qavatda nechta, nechta qavat.</p>",
 q:{t:"3 × 3 × 3 kub kubiklardan yig'ilgan. Hammasi nechta kubik?",opts:["9","19","27","18"],ok:2,why:"Har qavatda 3 · 3 = 9, 3 qavat: 27.",hint:"Bitta qavatda nechta kubik? Nechta qavat?",full:"Bitta qavat 3 · 3 = 9 kubik, 3 qavat: 9 · 3 = 27. «19» — faqat ko'rinadiganlarini sanash, «9» — faqat bitta qavat."},
 tn:"Kubiklardan 2 × 2 × 2 yasab, bolalarga faqat bir tomondan ko'rsating va «nechta?» deb so'rang, keyin buzib sanang."},
{h:"Bilasizmi? Rubik kubigi",sum:"Rubik kubigi 1974-yilda o'ylab topilgan; u 3 × 3 × 3 = 27 ta kubchaga o'xshaydi.",a:"m07",
 start:function(){h11Rubik()},fin:function(){h11Rubik()},
 html:"<p>🧊 Vengriyalik me'mor <b>Erno Rubik</b> 1974-yilda mashhur kubni o'ylab topdi. Tashqaridan u <b>3 × 3 × 3 = 27</b> ta kubchaga o'xshaydi. Har yog'i 9 ta kvadratdan iborat, 6 ta yog'i 6 xil rangda. Uni aralashtirish usullari shunchalik ko'pki, hamma usulni sinab chiqishga butun umr yetmaydi!</p>",
 tn:"Sinfda Rubik kubigi bo'lsa, uning yog'lari, qirralari va uchlarini sanatib ko'ring."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){clear('#fbf7ef');h11Stack(h11Box(3,2,2),{oy:86});h11Msg('6 · 2 = 12 kubik')},fin:function(){clear('#fbf7ef');h11Stack(h11Box(3,2,2),{oy:86});h11Msg('6 · 2 = 12 kubik')},
 html:"<div class='memo'><ul><li><b>Yassi</b> shakllar (kvadrat, doira) — qog'ozda; <b>hajmli</b> jismlar (kub, shar) — bo'yi, eni, balandligi bor.</li><li>Kub: <b>6 yog'</b>, <b>12 qirra</b>, <b>8 uch</b>.</li><li>Shar, silindr, konus — dumalaydi; kub, piramida — dumalamaydi.</li><li><b>Hajm</b> — nechta bir xil kubik sig'adi.</li><li>Hajm = bitta qavat × qavatlar soni (6 · 3 = 18).</li><li>Shakl o'zgarsa ham kubiklar soni o'sha — hajm o'sha.</li><li>Rasmda yashiringan kubiklarni unutmang: 2 × 2 × 2 = <b>8</b>.</li></ul></div>",
 tn:"3-sinfda hajm birliklari (sm³) o'rganiladi — bu darsdagi «kubik» o'sha sm³ ning o'zi."}
];
function h11Same(k){clear('#fbf7ef');var L=[[[0,0,0],[1,0,0],[2,0,0],[3,0,0]],[[0,0,0],[1,0,0],[0,1,0],[1,1,0]],[[0,0,0],[0,0,1],[0,0,2],[0,0,3]]][k];h11Stack(L,{a:24,oy:k===2?140:80,ox:k===0?150:180});h11Msg(['Qator','Kvadrat','Minora'][k]+': <b>4</b> ta kubik — hajm 4')}
function h11Rubik(){clear('#fbf7ef');var cols=[['#ffffff','#e0475b','#1e8e5a'],['#f2d36b','#e07a2f','#5aa9e6']],l=[];for(var z=0;z<3;z++)for(var y=0;y<3;y++)for(var x=0;x<3;x++){var c=[['#f7f7f7','#d22f3c','#14904a'],['#ffd23f','#ef7d22','#2f7fd1'],['#f7f7f7','#2f7fd1','#d22f3c']][(x+y+z)%3];l.push([x,y,z,c])}
 h11Stack(l,{a:22,oy:96});h11Msg('3 × 3 × 3 = <b>27</b> ta kubchaga o‘xshaydi')}
var PROBS=[
{t:"Kubning nechta yog'i bor?",o:["6","4","8","12"],k:0,s:"Kubda 6 ta kvadrat yog' bor."},
{t:"Kubning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"Tepada 4, pastda 4 — 8 ta uch."},
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","10"],k:0,s:"4 + 4 + 4 = 12."},
{t:"Qaysi jismning birorta ham uchi yo'q?",o:["shar","piramida","kub","konus"],k:0,s:"Sharning uchi ham, tekis yog'i ham yo'q."},
{t:"Silindrning nechta tekis yuzasi bor?",o:["2","0","1","3"],k:0,s:"Tepa va past — 2 ta doira."},
{t:"Konusning nechta uchi bor?",o:["1","0","2","3"],k:0,s:"Konusning bitta uchi bor."},
{t:"Qaysi narsa shar shaklida?",o:["koptok","konserva bankasi","muzqaymoq vaflisi","gugurt qutisi"],k:0,s:"Koptok — shar."},
{t:"Konserva bankasi qaysi jism shaklida?",o:["silindr","konus","shar","kub"],k:0,s:"Ikki tekis doira va egri yuza — silindr."},
{t:"Asosi kvadrat bo'lgan piramidaning nechta yog'i bor?",o:["5","4","6","8"],k:0,s:"1 ta kvadrat asos + 4 ta uchburchak = 5."},
{t:"Kub shaklidagi qutining har bir yog'iga 3 tadan yulduzcha yopishtirildi. Jami nechta yulduzcha?",o:["18","12","24","9"],k:0,s:"6 yog' · 3 = 18."},
{t:"Bitta qavatda 3 × 2 kubik, 2 qavat. Jami nechta kubik?",o:["12","6","10","5"],k:0,s:"6 · 2 = 12."},
{t:"Bitta qavatda 4 × 3 kubik, 3 qavat. Jami nechta kubik?",o:["36","12","21","24"],k:0,s:"12 · 3 = 36."},
{t:"2 × 2 × 2 kub kubiklardan yig'ilgan. Jami nechta kubik?",o:["8","7","4","6"],k:0,s:"4 · 2 = 8 (bittasi orqada yashirin)."},
{t:"3 × 3 × 3 kub kubiklardan yig'ilgan. Jami nechta kubik?",o:["27","9","19","18"],k:0,s:"9 · 3 = 27."},
{t:"10 ta kubikdan minora yasaldi. Undan 3 ta olib, qatorga qo'yildi. Minora va qator birga necha kubik hajmga ega?",o:["10","7","3","13"],k:0,s:"Kubiklar soni o'zgarmadi: 10."},
{t:"Qaysi jism dumalaydi, lekin uning uchi bor?",o:["konus","shar","kub","piramida"],k:0,s:"Konus egri yuzasi bilan dumalaydi va bitta uchi bor."},
{t:"Kubning hamma yog'lari qanday shakl?",o:["kvadrat","uchburchak","doira","to'g'ri to'rtburchak (kvadrat emas)"],k:0,s:"Kubning 6 ta yog'i — teng kvadratlar."},
{t:"Kubdan 2 × 2 × 2 yasash uchun 5 ta kubik bor. Yana nechta kerak?",o:["3","8","2","4"],k:0,s:"Kerak 8 ta, bor 5: 8 − 5 = 3."},
{t:"Quti 3 × 3 × 2 kubik sig'adi. Unga 10 ta kubik solindi. Yana nechta sig'adi?",o:["8","18","10","2"],k:0,s:"Hajm 9 · 2 = 18; 18 − 10 = 8."},
{t:"Kubning 12 ta qirrasidan har biri 3 sm. Barcha qirralar uzunliklari yig'indisi?",o:["36 sm","12 sm","18 sm","24 sm"],k:0,s:"12 · 3 = 36 sm."}
];
function PRACT_STAGE(){clear('#fbf7ef');h11Stack(h11Box(3,2,2),{oy:86});h11Msg('Qavatlab sanang')}
var PREP_DATA={teach:["Yassi shakl va hajmli jism; kvadrat → kub, doira → shar.","Kubning yog'lari (6), qirralari (12), uchlari (8).","Jismlar: kub, shar, silindr, konus, piramida — xossalari, hayotdagi misollar.","Hajm — kubiklar soni; qavatlab sanash; yashiringan kubiklar tuzog'i."],
 mist:["Rasmda ko'rinmaydigan qirra va kubiklarni sanamaydi (kub qirralarini 9 deydi).","Yog', qirra va uchni chalkashtiradi.","2 × 2 × 2 kubni 7 kubik deydi.","Hajmni shakl bilan bog'laydi («minora kattaroq»)."],
 need:["Kubiklar (konstruktor yoki gugurt qutilari).","Koptok, banka, vafli, quti; plastilin va cho'plar."],
 board:["Kvadrat → kub, doira → shar.","Kub: <span class='w2'>6 yog' · 12 qirra · 8 uch</span>.","Dumalaydi: shar, silindr, konus.","Hajm: <span class='w2'>3 × 2 = 6, 6 · 3 = 18</span> kubik.","<span class='w2'>2 × 2 × 2 = 8</span> (7 emas)."]};
