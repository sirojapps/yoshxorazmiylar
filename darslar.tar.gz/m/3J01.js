var CODE='3J01',TITLE='3-sinf · Sonli qonuniyatlar';
var J1a=[function(){clear();Y3seq([3,5,9,15,23,'?']);Y3msg('Qadam bir xil emas… Qanday qonuniyat?')},
 function(){clear();Y3seq([3,5,9,15,23,'?'],{diff:['+2','+4','+6','+8','']});Y3msg('Farqlar: 2, 4, 6, 8 — ular ham qonuniyatli!')},
 function(){clear();Y3seq([3,5,9,15,23,33],{diff:['+2','+4','+6','+8','+10'],hi:{5:'#e6f6ee'}});Y3msg('Keyingi farq — 10: 23 + 10 = <b>33</b>')}];
var J1b=[function(){clear();Y3seq([1,4,16,64,'?',1024]);Y3msg('Qo‘shib bo‘lmaydi: farqlar 3, 12, 48 — tez o‘smoqda')},
 function(){clear();Y3seq([1,4,16,64,'?',1024],{diff:['·4','·4','·4','','']});Y3msg('Har bir son oldingisidan <b>4 marta</b> katta')},
 function(){clear();Y3seq([1,4,16,64,256,1024],{diff:['·4','·4','·4','·4','·4'],hi:{4:'#e6f6ee'}});Y3msg('64 · 4 = <b>256</b>; tekshiramiz: 256 · 4 = 1024 ✓')}];
var J1c=[function(){clear();Y3seq([205,212,219,226,'…','?'],{lab:['1','2','3','4','','10']});Y3msg('10-son qaysi? Bittalab yozish uzoq…')},
 function(){clear();Y3seq([205,212,219,226,'…','?'],{lab:['1','2','3','4','','10'],diff:['+7','+7','+7','','']});Y3msg('1-sondan 10-songacha <b>9 ta qadam</b> (10 emas!)')},
 function(){clear();Y3seq([205,212,219,226,'…',268],{lab:['1','2','3','4','','10'],hi:{5:'#e6f6ee'}});Y3msg('205 + 9 · 7 = 205 + 63 = <b>268</b>')}];
var J1d=[function(){clear();Y3seq([1,7,9,0,1,7,9,0,'…']);Y3msg('1, 7, 9, 0 takrorlanadi. 49-o‘rinda nima?')},
 function(){clear();Y3seq([1,7,9,0,1,7,9,0,'…'],{hi:{0:'#fde6c8',1:'#fde6c8',2:'#fde6c8',3:'#fde6c8',4:'#e1f4f2',5:'#e1f4f2',6:'#e1f4f2',7:'#e1f4f2'}});Y3msg('Har guruhda 4 ta son. 49 : 4 = 12 guruh va <b>1</b> qoldiq')},
 function(){clear();Y3seq([1,7,9,0,'…',1],{lab:['1','2','3','4','','49'],hi:{5:'#e6f6ee'}});Y3msg('12 ta to‘liq guruhdan keyin yangi guruhning <b>1-soni</b>: 1')}];
var J1e=[function(){clear();Y3seq([1,10,2,20,3,30,'?']);Y3msg('Bu qator g‘alati… Balki ikkita qator aralashgandir?')},
 function(){clear();Y3seq([1,10,2,20,3,30,'?'],{hi:{0:'#fde6c8',2:'#fde6c8',4:'#fde6c8',6:'#fde6c8',1:'#e1f4f2',3:'#e1f4f2',5:'#e1f4f2'}});Y3msg('Toq o‘rinlar: 1, 2, 3, … · Juft o‘rinlar: 10, 20, 30, …')},
 function(){clear();Y3seq([1,10,2,20,3,30,4],{hi:{0:'#fde6c8',2:'#fde6c8',4:'#fde6c8',6:'#e6f6ee',1:'#e1f4f2',3:'#e1f4f2',5:'#e1f4f2'}});Y3msg('7-o‘rin — toq o‘rin, demak birinchi qator davomi: <b>4</b>')}];
var J1f=[function(){clear();Y3seq([312,423,534,645,'?']);Y3msg('Raqamlarga qarang: har bir xonada nima o‘zgaryapti?')},
 function(){clear();Y3seq([312,423,534,645,'?'],{diff:['+111','+111','+111','']});Y3msg('Har bir raqam 1 ga ortadi — son esa 111 ga')},
 function(){clear();Y3seq([312,423,534,645,756],{diff:['+111','+111','+111','+111'],hi:{4:'#e6f6ee'}});Y3msg('645 + 111 = <b>756</b>')}];
var STEPS=[
{h:"Farqlar qatori",sum:"Qadam o'zgarsa — farqlarni yozing: 3, 5, 9, 15, 23 → farqlar 2, 4, 6, 8 → keyingi 33.",a:"m01",start:function(){startPh(J1a)},fin:function(){S.ph=2;J1a[2]()},
 html:"<p>3, 5, 9, 15, 23, … Keyingi son qaysi? Qadam bir xil emas. Shunday paytda olimpiadachilar <b>farqlarni</b> yozib chiqadi.</p>",btns:[phaser(J1a)],
 after:"<p>Sonlarning o'zida qonuniyat ko'rinmasa — <b>farqlar qatoriga</b> qarang. Farqlar 2, 4, 6, 8 — bular ham qator. Keyingi farq 10, demak 23 + 10 = <b>33</b>.</p>",
 q:{t:"2, 6, 12, 20, 30, … keyingi son qaysi?",opts:["40","42","36","44"],ok:1,why:"Farqlar 4, 6, 8, 10 → keyingisi 12: 30 + 12 = 42.",hint:"Farqlarni yozing: 6 − 2, 12 − 6, 20 − 12…",full:"Farqlar: 4, 6, 8, 10 — har safar 2 ga ortadi. Keyingi farq 12: 30 + 12 = 42. «40» — farqni 10 deb qoldirgan xato."},
 tn:"Doskada sonlar ostiga farqlarni, ularning ostiga «farqlarning farqi»ni yozdiring — bu usul keyinchalik algebra va fizikada ham kerak bo'ladi."},
{h:"Ko'paytma qadam",sum:"Farqlar tez o'ssa — nisbatni tekshiring: 1, 4, 16, 64 → har safar ·4 → 256.",a:"m02",start:function(){startPh(J1b)},fin:function(){S.ph=2;J1b[2]()},
 html:"<p>1, 4, 16, 64, ?, 1024 — farqlar 3, 12, 48: juda tez o'syapti. Bunday paytda <b>necha marta</b> ortayotganini tekshiramiz.</p>",btns:[phaser(J1b)],
 after:"<p>Farqlar «portlab» o'ssa, qonuniyat ko'pincha <b>ko'paytirish</b>. Tekshiruv: topgan soningizdan keyingisini ham hisoblang — 256 · 4 = 1024 ✓.</p>",
 q:{t:"3, 6, 12, 24, ?, 96 — qaysi son yetishmayapti?",opts:["36","48","30","72"],ok:1,why:"Har safar 2 marta: 24 · 2 = 48, 48 · 2 = 96 ✓.",hint:"6 son 3 dan necha marta katta? 12 son 6 dan-chi?",full:"Har bir son oldingisidan 2 marta katta: 3, 6, 12, 24, 48, 96. «36» — 12 qo'shib qo'yilgan, lekin 36 · 2 = 72, 96 emas."},
 tn:"Bolalar doim «keyingisini tekshirish» odatini o'rgansin: topgan son qatorning davomiga to'g'ri kelishi shart."},
{h:"n-o'rindagi son",sum:"205, 212, 219, … 10-son: 205 + 9 · 7 = 268. Qadamlar soni o'rindan 1 ta kam.",a:"m03",start:function(){startPh(J1c)},fin:function(){S.ph=2;J1c[2]()},
 html:"<p>205, 212, 219, 226, … Shu qatorning <b>10-soni</b> qaysi? Hammasini yozib chiqmasdan topamiz.</p>",btns:[phaser(J1c)],
 after:"<p><b>Qoida:</b> n-son = 1-son + (n − 1) · qadam. 10-songacha 9 ta qadam: 205 + 63 = 268.</p><p>Tuzoq: 205 + 10 · 7 = 275 — bu 11-son!</p>",
 q:{t:"4, 9, 14, 19, … qatorning 20-soni qaysi?",opts:["104","100","99","95"],ok:2,why:"Qadam 5, qadamlar 19 ta: 4 + 19 · 5 = 99.",hint:"1-sondan 20-songacha nechta qadam bor?",full:"Qadam — 5. 20-songacha 19 ta qadam: 4 + 95 = 99. «104» — 20 ta qadam olingan (bu 21-son), «100» — 4 ni unutgan."},
 tn:"Bu «ustunlar xatosi»ning qatordagi ko'rinishi (2A3). Barmoqlarda ko'rsating: 5 ta barmoq — 4 ta oraliq."},
{h:"Davriy takrorlanish",sum:"Takrorlanuvchi guruh uzunligiga bo'lamiz: 49 : 4 = 12 (qoldiq 1) → guruhning 1-soni.",a:"m04",start:function(){startPh(J1d)},fin:function(){S.ph=2;J1d[2]()},
 html:"<p>1, 7, 9, 0, 1, 7, 9, 0, … takrorlanadi. <b>49-o'rinda</b> qaysi raqam? Guruhlab sanaymiz.</p>",btns:[phaser(J1d)],
 after:"<p>Guruh uzunligi 4. O'rinni 4 ga bo'lamiz: <b>qoldiq</b> guruh ichidagi o'rinni beradi. Qoldiq 0 bo'lsa — guruhning <b>oxirgi</b> soni (bu yerda 0).</p>",
 q:{t:"A, B, C, D, E, A, B, C, D, E, … 53-o'rinda qaysi harf?",opts:["B","C","D","E"],ok:1,why:"53 : 5 = 10 (qoldiq 3) → guruhning 3-harfi: C.",hint:"Guruhda nechta harf? 53 ni shunga bo'ling va qoldiqqa qarang.",full:"Guruh — 5 ta harf. 53 = 10 · 5 + 3. 10 ta to'liq guruhdan keyin 3-harf: C. «E» — qoldiq 0 bo'lganda bo'lardi (masalan, 50-o'rin)."},
 tn:"Qoldiqli bo'lish (3C6) bilan bog'lang. Hafta kunlari (7 kunlik davr) yaxshi hayotiy misol."},
{h:"Ikki qator aralashgan",sum:"1, 10, 2, 20, 3, 30, … — toq o'rinlarda bir qator, juft o'rinlarda boshqa qator.",a:"m05",start:function(){startPh(J1e)},fin:function(){S.ph=2;J1e[2]()},
 html:"<p>1, 10, 2, 20, 3, 30, ? — sonlar sakrab turibdi. Balki bu yerda <b>ikkita</b> qator bor?</p>",btns:[phaser(J1e)],
 after:"<p>Qator «sakrasa», toq va juft o'rinlarni <b>alohida</b> ko'ring. Har biri o'z qonuniyatiga ega bo'lishi mumkin.</p>",
 q:{t:"5, 1, 7, 3, 9, 5, ? — keyingi son qaysi?",opts:["7","13","11","10"],ok:2,why:"Toq o'rinlar: 5, 7, 9, 11 (+2). Keyingisi toq o'rin — 11.",hint:"1-, 3-, 5-o'rinlardagi sonlarni alohida yozing.",full:"Toq o'rinlar: 5, 7, 9 → keyingisi 11. Juft o'rinlar: 1, 3, 5 → bular ham +2. 7-o'rin toq o'rin — javob 11. «7» — juft o'rinlar qatori davom ettirilgan."},
 tn:"Sonlarni ikki rangli bo'r bilan yozing — ikkita qator darhol ko'rinadi."},
{h:"Raqamlardagi qonuniyat",sum:"312, 423, 534, 645 — har xona +1, ya'ni son +111 → 756.",a:"m06",start:function(){startPh(J1f)},fin:function(){S.ph=2;J1f[2]()},
 html:"<p>312, 423, 534, 645, … Ba'zan qonuniyat sonning <b>raqamlarida</b> yashiringan bo'ladi.</p>",btns:[phaser(J1f)],
 after:"<p>Har bir xonada raqam 1 ga ortadi: 3→4→5→6→<b>7</b>, 1→2→3→4→<b>5</b>, 2→3→4→5→<b>6</b>. Son 111 ga ortadi: <b>756</b>.</p>",
 q:{t:"135, 246, 357, … keyingi son qaysi?",opts:["468","458","467","478"],ok:0,why:"Har raqam +1: 4, 6, 8 → 468 (son +111).",hint:"Har bir xonadagi raqam qanday o'zgaryapti?",full:"Yuzliklar 1, 2, 3 → 4; o'nliklar 3, 4, 5 → 6; birliklar 5, 6, 7 → 8. Javob 468 = 357 + 111."},
 tn:"Bolalarga raqamlarni ustma-ust yozdiring — har ustunda o'z qonuniyati ko'rinadi."},
{h:"Tuzoq: qonuniyat bir nechta bo'lishi mumkin",sum:"1, 2, 4, … — keyingisi 7 ham (+1,+2,+3), 8 ham (·2) bo'lishi mumkin. Kamida 4–5 ta son kerak.",a:"m07",
 start:function(){S.v1=S.v2=0;clear();Y3seq([1,2,4,'?']);Y3msg('1, 2, 4, … — keyingisi qaysi? Ikkala variantni ko‘ring')},fin:function(){clear();Y3seq([1,2,4,7,11],{y:30,diff:['+1','+2','+3','+4']});Y3seq([1,2,4,8,16],{y:110,diff:['·2','·2','·2','·2'],dc:C.ok});Y3msg('Ikkalasi ham to‘g‘ri! Shuning uchun masalada <b>ko‘proq son</b> beriladi')},
 html:"<p>1, 2, 4, … — keyingi son qaysi? Ikkala qonuniyatni tugmalar bilan ko'ring.</p>",
 btns:[["+1, +2, +3 …",function(c,done){clear();Y3seq([1,2,4,7,11],{diff:['+1','+2','+3','+4']});Y3msg('Farqlar o‘sadi: 1, 2, 4, <b>7</b>, 11');S.v1=1;if(S.v2)done()}],["· 2, · 2 …",function(c,done){clear();Y3seq([1,2,4,8,16],{diff:['·2','·2','·2','·2'],dc:C.ok});Y3msg('Har safar 2 marta: 1, 2, 4, <b>8</b>, 16');S.v2=1;if(S.v1)done()},'u']],g2:1,
 after:"<p>Uchta son bilan qonuniyat <b>yagona emas</b>! Olimpiadada har doim berilgan <b>hamma</b> sonlarni tekshiring: qonuniyat hammasiga to'g'ri kelishi shart.</p>",
 q:{t:"2, 3, 5, 8, 13, ? — keyingi son qaysi?",opts:["18","21","20","26"],ok:1,why:"Har son oldingi ikkitasining yig'indisi: 8 + 13 = 21.",hint:"5 qanday hosil bo'ldi? 2 va 3 dan… 8 chi?",full:"2 + 3 = 5, 3 + 5 = 8, 5 + 8 = 13, 8 + 13 = 21. Farqlar (1, 2, 3, 5) ham shu qator — Fibonachchi qatori. «18» — farqni 5 deb olgan."},
 tn:"Bolalar o'z qonuniyatini o'ylab, bir-biriga topishmoq qilsin. Ataylab 2 xil javobli qator berib, munozara qiling."},
{h:"Kvadrat sonlar",sum:"1, 4, 9, 16, 25 — nuqtalardan kvadrat: n-son = n · n. Farqlari toq sonlar: 3, 5, 7, 9.",a:"m08",
 start:function(){S.k=1;J1sq(1)},fin:function(){J1sq(5)},
 html:"<p>Nuqtalardan kvadrat quramiz. Tugmani bosib, kvadratni kattalashtiring va nuqtalarni sanang.</p>",
 btns:[["➕ Kvadratni kattalashtirish",function(c,done){if(S.k<6){S.k++;J1sq(S.k)}if(S.k>=5)done()}]],
 after:"<p>1, 4, 9, 16, 25, 36 — <b>kvadrat sonlar</b>: n · n. Har safar qo'shilgan nuqtalar «burchak» shaklida: 3, 5, 7, 9 — ketma-ket <b>toq sonlar</b>!</p>",
 q:{t:"1, 4, 9, 16, 25, 36, ? — keyingi son qaysi?",opts:["42","48","49","64"],ok:2,why:"7 · 7 = 49 (farq 13).",hint:"36 = 6 · 6. Keyingisi?",full:"Bu kvadrat sonlar: 1·1, 2·2, … 6·6 = 36. Keyingisi 7 · 7 = 49. Farqlar: 3, 5, 7, 9, 11, 13 — toq sonlar."},
 tn:"Bolalar katak daftarda kvadratlar chizib, har yangi «burchak»ni boshqa rangda bo'yasin."},
{h:"Bilasizmi? Gauss va 5050",sum:"1 + 2 + … + 100 = 5050: juftlab qo'shamiz (1 + 100) · 50.",a:"m09",start:function(){J1g(false)},fin:function(){J1g(true)},
 html:"<p>🎓 Rivoyat qilinishicha, buyuk nemis matematigi <b>Karl Gauss</b> maktabda o'qib yurganida o'qituvchi 1 dan 100 gacha sonlarni qo'shishni buyuradi. Gauss bir necha daqiqada javob beradi. Qanday qilib? Tugmani bosing.</p>",
 btns:[["🔗 Juftlab qo'shish",function(c,done){J1g(true);done()}]],
 after:"<p>1 + 100 = 101, 2 + 99 = 101, … — <b>50 ta juft</b>, har biri 101: 50 · 101 = <b>5050</b>. Qonuniyatni ko'ra bilish — hisoblashdan tezroq!</p>",
 tn:"Sinfda 1 dan 20 gacha yig'indini Gauss usulida topishni so'rang (10 · 21 = 210)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){J1a[2]()},fin:function(){J1a[2]()},
 html:"<div class='memo'><ul><li>Qonuniyat ko'rinmasa — <b>farqlarni</b> yozing; farqlar ham qator bo'lishi mumkin.</li><li>Farqlar juda tez o'ssa — <b>necha marta</b> ortishini tekshiring (·2, ·4).</li><li><b>n-son</b> = 1-son + (n − 1) · qadam.</li><li><b>Davriy</b> qatorda: o'rinni guruh uzunligiga bo'ling, <b>qoldiq</b> — guruhdagi o'rin (qoldiq 0 → oxirgisi).</li><li>Qator sakrasa — <b>toq va juft o'rinlarni</b> alohida ko'ring.</li><li>Qonuniyat <b>raqamlarda</b> ham bo'lishi mumkin (312, 423, 534).</li><li>Topgan qonuniyatni <b>hamma</b> sonlarda tekshiring.</li><li>Kvadrat sonlar: 1, 4, 9, 16, 25 …; Fibonachchi: 1, 1, 2, 3, 5, 8 …</li></ul></div>",
 tn:"Keyingi darsni «1, 3, 6, 10, 15, ? — 21» (uchburchak sonlar) bilan boshlang."}
];
function J1sq(k){clear();var g=S.g,s=Math.min(20,130/k),x0=180-k*s/2,y0=20;for(var r=0;r<k;r++)for(var c=0;c<k;c++){var nw=(r===k-1||c===k-1)&&k>1;E('circle',{cx:x0+c*s+s/2,cy:y0+r*s+s/2,r:s*.32,fill:nw?C.a:C.b},g)}
 T(g,300,90,k+' · '+k,{'font-size':16,'font-weight':800,fill:C.blue});T(g,300,114,'= '+(k*k),{'font-size':20,'font-weight':800,fill:'#1d2b3a'});
 Y3msg(k>1?'Yangi «burchak»: <b>'+(2*k-1)+'</b> ta nuqta · jami <b>'+(k*k)+'</b>':'1 ta nuqta')}
function J1g(on){clear();var g=S.g;if(!on){T(g,180,90,'1 + 2 + 3 + … + 99 + 100 = ?',{'font-size':18,'font-weight':800,fill:'#1d2b3a'});Y3msg('Bittalab qo‘shsak — 99 ta amal…');return}
 var pr=[[1,100],[2,99],[3,98],[50,51]];pr.forEach(function(p,i){var y=30+i*30;T(g,120,y,(i===3?'… ':'')+p[0]+' + '+p[1],{'font-size':16,'font-weight':800,fill:'#1d2b3a'});T(g,230,y,'= 101',{'font-size':16,'font-weight':800,fill:C.ok})});
 T(g,180,160,'50 juft · 101 = 5050',{'font-size':18,'font-weight':800,fill:C.blue});Y3msg('50 · 101 = <b>5050</b>')}
var PROBS=[
{t:"7, 12, 17, 22, … keyingi son qaysi?",o:["27","26","32","29"],k:0,s:"Qadam 5: 22 + 5 = 27."},
{t:"2, 5, 10, 17, 26, … keyingi son qaysi?",o:["37","35","36","39"],k:0,s:"Farqlar 3, 5, 7, 9 → 11: 26 + 11 = 37."},
{t:"1, 3, 9, 27, … keyingi son qaysi?",o:["81","54","36","45"],k:0,s:"Har safar 3 marta: 27 · 3 = 81."},
{t:"205, 212, 219, 226, … 10-son nechaga teng?",o:["268","275","261","233"],k:0,s:"205 + 9 · 7 = 268."},
{t:"1, 7, 9, 0, 1, 7, 9, 0, … 49-o'rinda qaysi raqam?",o:["1","7","9","0"],k:0,s:"49 : 4 = 12 (qoldiq 1) → 1."},
{t:"A, B, B, A, B, B, … dastlabki 30 ta harfdan nechtasi B?",o:["20","15","18","10"],k:0,s:"Guruh ABB — 3 ta harf, 30 : 3 = 10 guruh, har birida 2 ta B: 20."},
{t:"1, 4, 16, 64, ?, 1024 — qaysi son yetishmayapti?",o:["256","128","144","512"],k:0,s:"Har safar ·4: 64 · 4 = 256."},
{t:"312, 423, 534, 645, … keyingi son?",o:["756","746","757","656"],k:0,s:"Har xona +1: 756."},
{t:"1, 10, 2, 20, 3, 30, … 9-o'rindagi son?",o:["5","40","4","50"],k:0,s:"Toq o'rinlar: 1, 2, 3, 4, 5 — 9-o'rin 5-son: 5."},
{t:"1, 1, 2, 3, 5, 8, … 10-son qaysi?",o:["55","34","89","50"],k:0,s:"13, 21, 34, 55 — 10-son 55."},
{t:"1, 3, 6, 10, 15, … keyingi son?",o:["21","20","25","18"],k:0,s:"Farqlar 2, 3, 4, 5 → 6: 15 + 6 = 21."},
{t:"100, 93, 86, 79, … qaysi son bu qatorda bo'lmaydi?",o:["50","65","58","44"],k:0,s:"Qadam −7: 72, 65, 58, 51, 44 … 50 yo'q."},
{t:"4, 9, 14, … qatorning 20-soni?",o:["99","104","100","95"],k:0,s:"4 + 19 · 5 = 99."},
{t:"Qator: 3, 6, 12, 24, … Nechanchi son birinchi marta 200 dan oshadi?",o:["8-son","7-son","9-son","6-son"],k:0,s:"3, 6, 12, 24, 48, 96, 192, 384 — 8-son."},
{t:"2, 3, 5, 8, 12, 17, … keyingi son?",o:["23","22","24","21"],k:0,s:"Farqlar 1, 2, 3, 4, 5 → 6: 17 + 6 = 23."},
{t:"Soat 9:00 da boshlab har 40 minutda qo'ng'iroq chalinadi. 5-qo'ng'iroq soat nechada?",o:["11:40","12:20","11:00","12:00"],k:0,s:"5-qo'ng'iroqqacha 4 ta oraliq: 4 · 40 = 160 minut = 2 soat 40 minut → 11:40."},
{t:"1 + 2 + 3 + … + 20 = ?",o:["210","200","220","190"],k:0,s:"Gauss usuli: 10 juft · 21 = 210."},
{t:"5, 1, 7, 3, 9, 5, … keyingi son?",o:["11","7","13","10"],k:0,s:"Toq o'rinlar 5, 7, 9 → 11."},
{t:"Qatorda har son oldingisining raqamlari yig'indisiga 10 qo'shilganiga teng: 25, 17, 18, 19, ? Keyingi son?",o:["20","11","21","19"],k:0,s:"1 + 9 + 10 = 20."},
{t:"1, 4, 9, 16, 25, … 10-son qaysi?",o:["100","81","90","121"],k:0,s:"10 · 10 = 100."}
];
function PRACT_STAGE(){J1a[2]()}
var PREP_DATA={teach:["Farqlar qatori va «farqlarning farqi».","Ko'paytma qadam (·2, ·3, ·4).","n-o'rindagi son: 1-son + (n − 1) · qadam.","Davriy qatorlar va qoldiq; aralash qatorlar; raqamlardagi qonuniyat.","Qonuniyatning yagona emasligi; kvadrat sonlar, Fibonachchi; Gauss usuli."],
 mist:["n-son uchun n ta qadam oladi (bitta ortiq).","Qoldiq 0 bo'lganda guruhning birinchisini oladi.","Faqat bitta-ikkita songa qarab qonuniyat «topadi», qolganini tekshirmaydi.","Aralash qatorni bitta qator deb o'ylaydi."],
 need:["Ikki rangli bo'r.","Katak daftar (kvadrat sonlar uchun)."],
 board:["<span class='w2'>3, 5, 9, 15, 23</span> ostiga farqlar <span class='w2'>2, 4, 6, 8</span>.","<span class='w2'>1, 4, 16, 64</span> — ·4.","<span class='w2'>n-son = 1-son + (n − 1) · qadam</span>.","<span class='w2'>49 : 4 = 12 (q. 1)</span> → guruhning 1-soni.","Ikki rangda: <span class='w2'>1, 10, 2, 20, 3, 30</span>.","<span class='w2'>1 + … + 100 = 50 · 101</span>."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
