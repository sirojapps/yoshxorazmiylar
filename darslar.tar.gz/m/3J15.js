var CODE='3J15',TITLE='3-sinf · Simmetriya, burish, oynadagi aks';
// --- 1-qadam: katakli simmetriya ---
var J15L=[[1,0],[2,0],[0,1],[1,1],[2,1],[3,1],[1,2],[3,2],[2,3],[3,3],[3,4]],J15={};
function j15Key(c,r){return c+'_'+r}
function j15Grid(){clear();var g=S.g,cell=28,x0=68,y0=16;J15.on=J15.on||{};var tgt={};J15L.forEach(function(p){tgt[j15Key(7-p[0],p[1])]=1});J15.tgt=tgt;
 j2Grid(8,5,cell,x0,y0,function(c,r){var k=j15Key(c,r);if(c<4)return J15L.some(function(p){return p[0]===c&&p[1]===r})?'#4b8fd9':'#fff';if(J15.on[k])return '#5cc98a';if(J15.bad===k)return '#f08a8a';return '#fff'});
 var ov=E('rect',{x:x0+4*cell,y:y0,width:4*cell,height:5*cell,fill:'transparent',style:'cursor:pointer'},g);ov.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var q=pt.matrixTransform(sv.getScreenCTM().inverse()),c=Math.floor((q.x-x0)/cell),r=Math.floor((q.y-y0)/cell);if(c<4||c>7||r<0||r>4)return;var k=j15Key(c,r);
  if(tgt[k]){J15.on[k]=1;J15.bad=null}else{J15.bad=k;setTimeout(function(){if(J15.bad===k){J15.bad=null;j15Grid()}},700)}j15Grid();j15Check(tgt[k]?'':'Bu katak aks emas: o\u2018qdan sanab ko\u2018ring')});
 E('line',{x1:x0+4*cell-0.5,y1:y0-8,x2:x0+4*cell-0.5,y2:y0+5*cell+6,stroke:C.bad,'stroke-width':3,'stroke-dasharray':'6 4'},g);T(g,x0+4*cell,y0+5*cell+16,'simmetriya o‘qi',{'font-size':10,fill:C.bad})}
function j15Check(w){var ok=0;for(var k in J15.on)if(J15.on[k])ok++;
 j2Msg(w?w:'Bo\u2018yalgan: <b>'+ok+'</b> / '+J15L.length+(ok===J15L.length?' ✓ Shakl simmetrik!':''));if(ok===J15L.length&&J15.done){var d=J15.done;J15.done=null;d()}}
// --- shakllar va o'qlar ---
function j15Shape(kind,axes){clear();var g=S.g,cx=180,cy=86,P={kv:'130,36 230,36 230,136 130,136',tt:'110,51 250,51 250,121 110,121',uch:'180,26 249,138 111,138',par:'135,51 255,51 225,121 105,121'};
 if(kind==='doira')E('circle',{cx:cx,cy:cy,r:56,fill:'#e1f4f2',stroke:'#2b8a7e','stroke-width':3},g);else E('polygon',{points:P[kind],fill:'#e1f4f2',stroke:'#2b8a7e','stroke-width':3},g);
 (axes||[]).forEach(function(a){E('line',{x1:a[0],y1:a[1],x2:a[2],y2:a[3],stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'6 4'},g)})}
var P2=[function(){j15Shape('kv',[[180,22,180,150],[116,86,244,86],[122,28,238,144],[238,28,122,144]]);j2Msg('Kvadrat: <b>4</b> ta o‘q — 2 ta o‘rtadan, 2 ta diagonal bo‘yicha')},
 function(){j15Shape('tt',[[180,38,180,134],[96,86,264,86]]);j2Msg('To‘g‘ri to‘rtburchak: faqat <b>2</b> ta. Diagonal bo‘yicha buklasak — burchaklar ustma-ust tushmaydi!')},
 function(){j15Shape('uch',[[180,18,180,146],[264,62,131,118],[96,62,229,118]]);j2Msg('Teng tomonli uchburchak: <b>3</b> ta o‘q — har uchidan qarshi tomon o‘rtasiga')},
 function(){var a=[];for(var i=0;i<8;i++){var t=i*Math.PI/8;a.push([180+66*Math.cos(t),86+66*Math.sin(t),180-66*Math.cos(t),86-66*Math.sin(t)])}j15Shape('doira',a);j2Msg('Doira: markazdan o‘tgan <b>har qanday</b> to‘g‘ri chiziq — o‘q. Cheksiz ko‘p!')}];
// --- soat ---
function j15Clock(cx,cy,r,h,m,mir,lab){var g=S.g,s=mir?-1:1;E('circle',{cx:cx,cy:cy,r:r,fill:mir?'#eef4fb':'#fff',stroke:mir?'#7aa7d6':'#33475b','stroke-width':3,'stroke-dasharray':mir?'5 3':''},g);
 for(var i=0;i<12;i++){var t=i*Math.PI/6,L=i%3===0?9:4;E('line',{x1:cx+(r-2)*Math.sin(t),y1:cy-(r-2)*Math.cos(t),x2:cx+(r-2-L)*Math.sin(t),y2:cy-(r-2-L)*Math.cos(t),stroke:'#33475b','stroke-width':i===0?4:2},g)}
 var ah=s*((h%12)+m/60)*Math.PI/6,am=s*m*Math.PI/30;E('line',{x1:cx,y1:cy,x2:cx+r*0.5*Math.sin(ah),y2:cy-r*0.5*Math.cos(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*0.82*Math.sin(am),y2:cy-r*0.82*Math.cos(am),stroke:C.blue,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);if(lab)T(g,cx,cy+r+16,lab,{'font-size':12,'font-weight':800,fill:mir?'#4a77a8':'#1d2b3a'})}
// --- burish ---
function j15Flag(g,cx,cy,ang,col){var w=E('g',{transform:'rotate('+ang+' '+cx+' '+cy+')'},g);E('line',{x1:cx,y1:cy+34,x2:cx,y2:cy-34,stroke:'#33475b','stroke-width':4,'stroke-linecap':'round'},w);E('polygon',{points:cx+','+(cy-34)+' '+(cx+30)+','+(cy-24)+' '+cx+','+(cy-12),fill:col},w);E('circle',{cx:cx,cy:cy+34,r:5,fill:'#33475b'},w)}
function j15Rot(){clear();var g=S.g;T(g,100,22,'hozir',{'font-size':12,'font-weight':800});T(g,260,22,'kerak',{'font-size':12,'font-weight':800});E('line',{x1:180,y1:14,x2:180,y2:160,stroke:'#e3d6bf','stroke-width':2},g);
 j15Flag(g,100,96,J15.ang,J15.ang%360===270?'#5cc98a':'#f08a8a');j15Flag(g,260,96,270,'#f4b860');j2Msg('Burilish: <b>'+J15.ang+'°</b> soat strelkasi yo‘nalishida')}
function j15Turn(d){return function(c,done){J15.ang=(J15.ang+d+360)%360;J15.cnt=(J15.cnt||0)+1;j15Rot();if(J15.ang===270){j2Msg('✓ Mos keldi! 270° soat bo‘yicha = 90° soatga <b>qarshi</b> ('+J15.cnt+' ta bosish)');done()}}}
// --- buklash ---
function j15Sheet(w,h,holes,fold){clear();var g=S.g,x=180-w/2,y=86-h/2;E('rect',{x:x,y:y,width:w,height:h,fill:'#fff7ea',stroke:'#d9b98a','stroke-width':2},g);
 (fold||[]).forEach(function(f){E('line',{x1:f[0]?x+w/2:x,y1:f[0]?y:y+h/2,x2:f[0]?x+w/2:x+w,y2:f[0]?y+h:y+h/2,stroke:'#b89a6a','stroke-width':1.5,'stroke-dasharray':'4 3'},g)});
 holes.forEach(function(p){E('circle',{cx:x+p[0]*w,cy:y+p[1]*h,r:7,fill:'#33475b'},g)})}
var P5=[function(){j15Sheet(140,140,[]);j2Msg('Kvadrat qog‘oz varag‘i')},
 function(){j15Sheet(70,140,[]);j2Msg('1-buklash: chapdan o‘ngga — yarmi qoldi (2 qavat)')},
 function(){j15Sheet(70,70,[]);j2Msg('2-buklash: pastdan yuqoriga — chorak qoldi (<b>4 qavat</b>)')},
 function(){j15Sheet(70,70,[[0.3,0.3]]);j2Msg('Burchakka yaqin bitta teshik teshamiz — u <b>4 qavatni</b> teshadi')},
 function(){j15Sheet(140,140,[[0.15,0.15],[0.85,0.15],[0.15,0.85],[0.85,0.85]],[[1],[0]]);j2Msg('Ochamiz: <b>4</b> ta teshik — buklash chiziqlariga nisbatan simmetrik joylashgan')}];
// --- 180° burilgan sonlar ---
function j15Num(t,rot,col){clear();var g=S.g;T(g,110,100,t,{'font-size':44,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'});T(g,110,140,'asl',{'font-size':12});T(g,180,96,'→ 180° →',{'font-size':13,fill:C.blue,'font-weight':800});
 var w=E('g',{transform:'rotate(180 250 86)'},g);T(w,250,100,t,{'font-size':44,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'});T(g,250,140,'teskari',{'font-size':12})}
var STEPS=[
{h:"Shaklni simmetrik qiling",sum:"Katakli to'rda shaklni simmetriya o'qiga nisbatan aks ettirish: har katak o'qdan bir xil masofada, qarshi tomonda.",a:"m01",
 start:function(){J15.on={};j15Grid();j2Msg('O‘ng tomonda kataklarni bosib, ko‘k shaklning <b>oynadagi aksini</b> yasang')},
 fin:function(){J15.on={};for(var k in J15.tgt)J15.on[k]=1;j15Grid();j2Msg('✓ Shakl simmetrik!')},
 html:"<p>Simmetriya o'qi — <b>oyna</b>. Har bir ko'k katak o'qdan necha katak uzoqda bo'lsa, uning aksi ham qarshi tomonda <b>xuddi shuncha</b> uzoqda bo'ladi. O'ng tomonda kataklarni bosing:</p>",
 act:function(c,done){c.querySelector('.hint').textContent='O‘qdan sanang: 1-katak, 2-katak…';J15.done=done},
 after:"<p>Aks ettirishda <b>balandlik o'zgarmaydi</b>, faqat chap va o'ng almashadi: o'qqa eng yaqin katak — aksida ham o'qqa eng yaqin.</p>",
 q:{t:"Katak o'qdan chapda 3-katakda turibdi. Uning aksi qayerda bo'ladi?",opts:["o'qdan o'ngda 3-katakda","o'qdan o'ngda 1-katakda","o'qdan chapda 3-katakda","o'qdan o'ngda 6-katakda"],ok:0,why:"Aks o'qdan xuddi shuncha uzoqda, lekin qarshi tomonda.",hint:"Oynaga 3 qadam uzoqda tursangiz, aksingiz oynadan necha qadam narida?",full:"Simmetriyada nuqta va uning aksi o'qdan bir xil masofada, qarshi tomonda. 3-katak → o'ngda 3-katak. «6-katak» — masofa ikki marta qo'shib yuborilgan, «chapda» — joyidan qo'zg'almagan."},
 tn:"Katakli daftarda: bola bir yarmini chizadi, sherigi aksini to'ldiradi. Keyin varaqni o'q bo'yicha buklab, tekshirishadi (yorug'ga tutib)."},
{h:"Nechta simmetriya o'qi?",sum:"Kvadrat — 4, to'g'ri to'rtburchak — 2, teng tomonli uchburchak — 3, doira — cheksiz ko'p.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Shaklni o'q bo'yicha buklasak, ikki yarmi <b>to'liq ustma-ust</b> tushishi kerak. Har shakl uchun o'qlarni ko'ring:</p>",
 btns:[phaser(P2,'▶ Keyingi shakl')],
 after:"<p>Tuzoq: to'g'ri to'rtburchakning <b>diagonali — o'q emas</b>! Qog'ozdan qirqib, diagonal bo'yicha buklab ko'ring — burchaklar chiqib qoladi.</p>",
 q:{t:"Parallelogramm (to'g'ri to'rtburchak emas, romb ham emas) nechta simmetriya o'qiga ega?",opts:["0","2","4","1"],ok:0,why:"Uni qanday buklamang, yarmlari ustma-ust tushmaydi.",hint:"Qiyshiq shaklni o'rtadan buklasangiz, burchaklari ustma-ust tushadimi?",full:"Parallelogrammning simmetriya o'qi yo'q — 0. U faqat markazi atrofida 180° burilganda o'ziga tushadi (bu burish simmetriyasi, o'q emas). «2» — to'g'ri to'rtburchak bilan chalkashtirish."},
 tn:"Qog'ozdan kvadrat, to'g'ri to'rtburchak, uchburchak qirqtiring — bolalar o'zlari buklab, o'qlarni sanasin."},
{h:"Oynadagi soat",sum:"Strelkali soat oynada 2:30 ni ko'rsatsa, haqiqiy vaqt 9:30 (12:00 − 2:30).",a:"m03",
 start:function(){clear();j15Clock(110,80,52,2,30,true,'oynada');j15Clock(260,80,52,0,0,false,'haqiqiy?');j2Msg('Oynada soat <b>2:30</b> ko‘rinyapti. Haqiqiy vaqt qancha?')},
 fin:function(){clear();j15Clock(110,80,52,2,30,true,'oynada 2:30');j15Clock(260,80,52,9,30,false,'haqiqiy 9:30');j2Msg('12:00 − 2:30 = <b>9:30</b>')},
 html:"<p>Oyna soatni <b>chap-o'ngga</b> almashtiradi: 3 → 9, 2 → 10, 12 va 6 joyida qoladi. Haqiqiy vaqtni tanlang:</p>",
 g2:1,btns:j2Pick(["9:30","2:30","3:30","10:30"],0,function(){clear();j15Clock(110,80,52,2,30,true,'oynada 2:30');j15Clock(260,80,52,9,30,false,'haqiqiy 9:30');j2Msg('✓ 12:00 − 2:30 = <b>9:30</b>')},function(i){j2Msg(['','Bu oynadagi vaqt — haqiqiysi emas','Minut strelkasi 6 da — u joyida qoladi, 30 daqiqa to‘g‘ri. Soat strelkasini aks ettiring','Soat strelkasi 2 va 3 orasida → oynada 9 va 10 orasiga o‘tadi; u 10 ga yetmagan'][i])}),
 after:"<p>Qisqa qoida: <b>haqiqiy vaqt = 12:00 − oynadagi vaqt</b> (12 soatlik strelkali soat uchun). 2:30 → 9:30, 4:15 → 7:45. Tekshirish: ikkalasining yig'indisi 12:00.</p>",
 q:{t:"Oynada strelkali soat 4:15 ni ko'rsatyapti. Haqiqiy vaqt qancha?",opts:["7:45","8:15","4:45","8:45"],ok:0,why:"12:00 − 4:15 = 7:45.",hint:"Minut strelkasi 3 da (15 daq) — oynada u qayerga o'tadi?",full:"Minut strelkasi 3 dan 9 ga o'tadi — 45 daqiqa. Soat strelkasi 4 dan biroz o'tgan → oynada 8 ga biroz yetmagan. Demak 7:45. «8:15» — faqat soatni almashtirib, minutni unutish."},
 tn:"Sinfga kichik oyna va karton soat olib keling — bolalar o'zlari aksini ko'rib, qoidani topsin."},
{h:"Burish: 90°, 180°, 270°",sum:"Bayroqchani soat yo'nalishida 270° burish = soatga qarshi 90° burish.",a:"m04",
 start:function(){J15.ang=0;J15.cnt=0;j15Rot()},fin:function(){J15.ang=270;j15Rot()},
 html:"<p>Burish — shakl bir nuqta atrofida aylanadi. To'liq aylanish — 360°, chorak — 90°. Chapdagi bayroqchani o'ngdagiga <b>mos</b> qiling. Imkon qadar kam bosishga harakat qiling!</p>",
 g2:1,btns:[["↺ 90° (soatga qarshi)",j15Turn(-90)],["↻ 90° (soat bo‘yicha)",j15Turn(90)]],
 after:"<p>Soat bo'yicha 3 marta 90° (270°) — soatga qarshi <b>1 marta</b> 90° bilan bir xil. Chunki 270° + 90° = 360° — to'liq aylanish.</p>",
 q:{t:"Minut strelkasi 12 dan boshlab 40 daqiqa yurdi. U necha gradusga burildi?",opts:["240°","40°","200°","120°"],ok:0,why:"1 daqiqa — 6° (360 : 60). 40 · 6 = 240°.",hint:"60 daqiqada strelka 360° aylanadi. 1 daqiqada-chi?",full:"360° : 60 = 6° har daqiqada. 40 · 6° = 240°. «40°» — daqiqani gradus deb olish, «120°» — 20 daqiqa (soatga qarshi qolgan qism)."},
 tn:"Bolalarni turg'izing: «90° o'ngga burilish», «180°», «270° o'ngga» — oxirgisida hamma chapga qaraganini sezadi."},
{h:"Buklab teshamiz",sum:"Qog'oz 2 marta buklanib (4 qavat) bitta teshik → ochilganda 4 ta teshik, simmetrik joylashgan.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=4;P5[4]()},
 html:"<p>Kvadrat qog'ozni ikki marta yarimga buklab, bitta teshik teshamiz. Ochilganda nechta teshik bo'ladi? Avval o'ylang, keyin kuzating.</p>",
 btns:[phaser(P5,'▶ Keyingi')],
 after:"<p>Har buklash qavatlarni <b>2 marta</b> ko'paytiradi: 1 → 2 → 4 → 8. Teshiklar har buklash chizig'iga nisbatan simmetrik — ular aynan buklash chiziqlari bo'yicha aks etadi.</p>",
 q:{t:"Qog'oz 3 marta yarimga buklandi va bitta teshik teshildi. Ochilganda nechta teshik bo'ladi?",opts:["8","6","3","4"],ok:0,why:"1 → 2 → 4 → 8 qavat; har qavatda bitta teshik.",hint:"Har buklashda qavatlar soni qanday o'zgaradi?",full:"Qavatlar: 1 → 2 → 4 → 8. Bitta teshik barcha 8 qavatni teshadi — 8 ta teshik. «6» — 3 · 2 deb qo'shib/ko'paytirish xatosi, «3» — buklashlar soni."},
 tn:"Haqiqiy qog'oz va qalam uchi bilan sinab ko'ring: bolalar oldindan javob yozib qo'ysin, keyin ochib tekshirsin."},
{h:"Oynadagi so'z",sum:"Vertikal oynada so'z harflari tartibi teskari bo'ladi va har harf aks etadi: «AMU» → «UMA».",a:"m06",
 start:function(){clear();var g=S.g;T(g,100,100,'AMU',{'font-size':46,'font-weight':800});E('line',{x1:180,y1:24,x2:180,y2:150,stroke:'#7aa7d6','stroke-width':4},g);T(g,180,166,'oyna',{'font-size':11,fill:'#4a77a8'});j2Msg('Oynada qanday ko‘rinadi?')},
 fin:function(){clear();var g=S.g;T(g,100,100,'AMU',{'font-size':46,'font-weight':800});E('line',{x1:180,y1:24,x2:180,y2:150,stroke:'#7aa7d6','stroke-width':4},g);var w=E('g',{transform:'translate(520 0) scale(-1 1)'},g);T(w,260,100,'AMU',{'font-size':46,'font-weight':800,fill:'#4a77a8'});j2Msg('Oynada: <b>UMA</b>')},
 html:"<p>A, M, U harflari o'zi simmetrik. Lekin oyna <b>tartibni</b> ham almashtiradi! Javobni tanlang:</p>",
 g2:1,btns:j2Pick(["UMA","AMU","MAU","AUM"],0,function(){STEPS[5].fin();j2Msg('✓ Oynada: <b>UMA</b> — chapdagi harf o‘ngga o‘tdi')},function(i){j2Msg(i===1?'Harflar o‘zgarmadi, lekin <b>tartib</b>-chi? Oynaga eng yaqin harf qaysi?':'Oynaga eng yaqin harf — U. Aksda ham u oynaga eng yaqin bo‘ladi')}),
 after:"<p>Oynaga eng yaqin harf aksda ham eng yaqin — shuning uchun so'z teskari o'qiladi. Shu sababli tez yordam mashinasi oldida yozuv <b>teskari</b> yoziladi: haydovchilar uni ko'zguda to'g'ri o'qiydi.</p>",
 q:{t:"Qaysi so'z vertikal oynada o'zgarmay ko'rinadi?",opts:["TOT","OTA","ANOR","KIM"],ok:0,why:"T, O — simmetrik harflar, so'z ikki tomondan bir xil o'qiladi.",hint:"Ikki shart kerak: har harf simmetrik bo'lsin VA so'z teskari o'qilganda ham o'sha so'z bo'lsin.",full:"TOT: harflar simmetrik va teskarisi ham TOT. OTA → ATO (tartib o'zgaradi). ANOR va KIM da N, R, K harflari simmetrik emas."},
 tn:"Bolalar o'z ismini katta harflar bilan yozib, oynaga tutsin. Qaysi harflar «buzilmadi»?"},
{h:"Teskari aylantirilgan son",sum:"180° burishda raqamlar tartibi teskari va 6 ↔ 9 almashadi: 1961 → 1961, 96 → 96, 68 → 89.",a:"m07",
 start:function(){j15Num('68');j2Msg('Kartochkani teskari aylantiramiz: 68 → <b>89</b>! 6 → 9 ga, 8 → 8, tartib almashadi')},
 fin:function(){j15Num('96',0,C.ok);j2Msg('✓ 96 teskari aylantirilganda ham <b>96</b>')},
 html:"<p>Son yozilgan kartochkani <b>180°</b> burasiz (teskari qilasiz). Bunda: 0, 1, 8 — o'zgarmaydi, 6 ↔ 9 almashadi, va raqamlar <b>tartibi teskari</b> bo'ladi. Qaysi son o'zgarmaydi?</p>",
 g2:1,btns:j2Pick(["96","68","99","16"],0,function(){j15Num('96',0,C.ok);j2Msg('✓ 96: 6 → 9, 9 → 6 va tartib teskari → yana <b>96</b>')},function(i){j15Num(['96','68','99','16'][i],0,C.bad);j2Msg(['','68 → 89','99 → 66 — har 9 6 ga aylanadi','16 → 91'][i])}),
 after:"<p>Tuzoq: «99» chiroyli ko'rinadi, lekin 9 teskari 6 bo'ladi — 66. Mashhur misol: <b>1961</b>-yil teskari aylantirilsa ham 1961 — bunday yil keyin faqat 6009-yilda bo'ladi.</p>",
 q:{t:"Qaysi son kartochkada 180° burilganda 8008 bo'ladi?",opts:["8008","8080","0880","8800"],ok:0,why:"8 va 0 o'zgarmaydi, tartib teskari: 8008 → 8008.",hint:"8 va 0 burilganda o'zgarmaydi. Faqat tartib teskari bo'ladi.",full:"8008 ni teskari o'qisak — 8008. 8080 → 0808, 8800 → 0088. Demak faqat 8008."},
 tn:"Kartochkaga 69, 88, 1961 yozib, sinfga teskari ko'rsating. Bolalar o'zi shunday son o'ylab topsin."},
{h:"Bilasizmi? Qor parchasi",sum:"Qor parchalari 6 nurli; 1611-yilda Kepler bu haqda alohida risola yozgan.",a:"m08",
 start:function(){clear();var g=S.g;for(var i=0;i<6;i++){var t=i*Math.PI/3;E('line',{x1:180,y1:86,x2:180+60*Math.cos(t),y2:86+60*Math.sin(t),stroke:'#4b8fd9','stroke-width':5,'stroke-linecap':'round'},g);for(var j=1;j<3;j++){var bx=180+j*20*Math.cos(t),by=86+j*20*Math.sin(t);[1,-1].forEach(function(s){E('line',{x1:bx,y1:by,x2:bx+14*Math.cos(t+s*0.8),y2:by+14*Math.sin(t+s*0.8),stroke:'#4b8fd9','stroke-width':3,'stroke-linecap':'round'},g)})}}},
 fin:function(){STEPS[7].start()},
 html:"<p>❄️ Qor parchalarining deyarli hammasi <b>6 nurli</b> — chunki muz kristallari olti burchakli shaklda o'sadi. 1611-yilda nemis olimi <b>Iogann Kepler</b> «Olti burchakli qor parchasi haqida» degan kichik risola yozib, nega shunday ekanini birinchilardan bo'lib so'ragan. Qor parchasini 60° ga bursak, u o'ziga tushadi.</p>",
 btns:[["Tushundim",function(c,done){j2Msg('❄️ 6 nur → 6 ta simmetriya o‘qi, 60° burishda o‘ziga tushadi');done()}]],
 after:"<p>Tabiatda simmetriya ko'p: kapalak qanotlari (1 o'q), gul barglari, asal mumi kataklari (olti burchak).</p>",
 tn:"Qishda qora mato ustiga tushgan qor parchasini lupada ko'rish — eng yaxshi tajriba."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){j15Shape('kv',[[180,22,180,150],[116,86,244,86],[122,28,238,144],[238,28,122,144]])},fin:function(){j15Shape('kv',[[180,22,180,150],[116,86,244,86],[122,28,238,144],[238,28,122,144]])},
 html:"<div class='memo'><ul><li>Aks — o'qdan <b>bir xil masofada</b>, qarshi tomonda.</li><li>O'qlar: kvadrat 4, to'g'ri to'rtburchak 2, teng tomonli uchburchak 3, doira — cheksiz, parallelogramm 0.</li><li>Oynadagi soat: <b>haqiqiy = 12:00 − ko'ringan</b>.</li><li>Oyna so'zning <b>tartibini</b> ham teskari qiladi.</li><li>Burish: 270° soat bo'yicha = 90° soatga qarshi; minut strelkasi 1 daqiqada 6°.</li><li>n marta buklash → 2 · 2 · … (n marta) qavat.</li><li>180° burishda 6 ↔ 9, tartib teskari.</li></ul></div>",
 tn:"Uyga vazifa: uydan 3 ta simmetrik va 1 ta simmetrik bo'lmagan buyum topib, chizib kelish."}
];
var PROBS=[
{t:"Kvadratning nechta simmetriya o'qi bor?",o:["4","2","1","8"],k:0,s:"2 ta o'rta chiziq va 2 ta diagonal."},
{t:"Kvadrat bo'lmagan to'g'ri to'rtburchakning nechta simmetriya o'qi bor?",o:["2","4","1","0"],k:0,s:"Faqat ikki o'rta chiziq; diagonal — o'q emas."},
{t:"Teng tomonli uchburchakning nechta simmetriya o'qi bor?",o:["3","1","6","0"],k:0,s:"Har uchidan qarshi tomon o'rtasiga — 3 ta."},
{t:"Doiraning nechta simmetriya o'qi bor?",o:["cheksiz ko'p","1","2","4"],k:0,s:"Markazdan o'tgan har bir to'g'ri chiziq — o'q."},
{t:"Qaysi harfning vertikal simmetriya o'qi bor?",o:["A","F","R","N"],k:0,s:"A ni o'rtadan tik buklash mumkin."},
{t:"Qaysi harfning birorta ham simmetriya o'qi yo'q?",o:["F","H","E","O"],k:0,s:"H va O da bir nechta, E da gorizontal o'q bor; F da yo'q."},
{t:"Oynada strelkali soat 3:00 ni ko'rsatyapti. Haqiqiy vaqt qancha?",o:["9:00","3:00","6:00","12:00"],k:0,s:"12:00 − 3:00 = 9:00."},
{t:"Oynada strelkali soat 2:30 ni ko'rsatyapti. Haqiqiy vaqt qancha?",o:["9:30","2:30","10:30","3:30"],k:0,s:"12:00 − 2:30 = 9:30."},
{t:"Oynada strelkali soat 4:15 ni ko'rsatyapti. Haqiqiy vaqt qancha?",o:["7:45","8:15","4:45","8:45"],k:0,s:"12:00 − 4:15 = 7:45."},
{t:"Qog'oz 2 marta yarimga buklanib, bitta teshik teshildi. Ochilganda nechta teshik bo'ladi?",o:["4","2","3","8"],k:0,s:"1 → 2 → 4 qavat."},
{t:"Qog'oz 3 marta yarimga buklanib, bitta teshik teshildi. Ochilganda nechta teshik bo'ladi?",o:["8","6","4","3"],k:0,s:"1 → 2 → 4 → 8 qavat."},
{t:"Yuqoriga qaragan strelka soat yo'nalishida 90° burildi. Endi u qayerga qaraydi?",o:["o'ngga","chapga","pastga","yuqoriga"],k:0,s:"Chorak aylanish soat bo'yicha: yuqori → o'ng."},
{t:"Yuqoriga qaragan strelka soat yo'nalishida 270° burildi. Endi u qayerga qaraydi?",o:["chapga","o'ngga","pastga","yuqoriga"],k:0,s:"270° soat bo'yicha = 90° soatga qarshi → chapga."},
{t:"Minut strelkasi 15 daqiqada necha gradusga buriladi?",o:["90°","15°","45°","180°"],k:0,s:"15 · 6° = 90°."},
{t:"Minut strelkasi 12 dan boshlab 20 daqiqa yurdi. U necha gradusga burildi?",o:["120°","20°","100°","60°"],k:0,s:"20 · 6° = 120°."},
{t:"Qaysi so'z vertikal oynada o'zgarmay ko'rinadi?",o:["TOT","OTA","ANOR","KIM"],k:0,s:"T, O simmetrik va TOT teskarisi ham TOT."},
{t:"Kvadratni markazi atrofida burayapmiz. Necha gradusga burganda u birinchi marta o'z o'rniga tushadi?",o:["90°","180°","360°","45°"],k:0,s:"To'rt bir xil tomon: 360° : 4 = 90°."},
{t:"Teng tomonli uchburchakni markazi atrofida burayapmiz. Necha gradusga burganda u birinchi marta o'z o'rniga tushadi?",o:["120°","90°","60°","180°"],k:0,s:"Uch bir xil tomon: 360° : 3 = 120°."},
{t:"Qaysi son kartochkada 180° burilganda (teskari qilinganda) o'zgarmaydi?",o:["69","66","89","16"],k:0,s:"6 ↔ 9 almashadi va tartib teskari: 69 → 69. 66 → 99, 89 → 68, 16 → 91."},
{t:"1961 soni teskari (180°) aylantirildi. Qaysi son ko'rinadi?",o:["1961","1691","1916","9161"],k:0,s:"Tartib teskari (1691) va 6 ↔ 9: 1961."}
];
function PRACT_STAGE(){j15Shape('uch',[[180,18,180,146],[264,62,131,118],[96,62,229,118]])}
var PREP_DATA={teach:["O'q simmetriya: aks o'qdan bir xil masofada.","Shakllarning simmetriya o'qlari soni.","Oynadagi soat va so'z; tartib teskari bo'lishi.","Burish: 90°, 180°, 270°; minut strelkasi gradusda.","Buklab teshish: qavatlar ikki barobar."],
 mist:["To'g'ri to'rtburchak diagonalini o'q deb hisoblaydi.","Oynada faqat harflarni aks ettirib, tartibni unutadi.","Oynadagi soatda faqat soatni almashtirib, minutni unutadi.","270° ni chapga emas, o'ngga deb o'ylaydi.","Buklashlar sonini teshiklar soni deb oladi."],
 need:["Qog'oz kvadratlar, qaychi, kichik oyna.","Karton soat.","Katakli daftar."],
 board:["<span class='w2'>Aks: o'qdan 3 katak → narida 3 katak</span>.","<span class='w2'>Kvadrat 4 · To'rtburchak 2 · Uchburchak 3 · Doira ∞</span>.","<span class='w2'>Oyna soat: 12:00 − 2:30 = 9:30</span>.","<span class='w2'>270° ↻ = 90° ↺</span>.","<span class='w2'>Buklash: 1 → 2 → 4 → 8</span>.","<span class='w2'>180°: 6 ↔ 9, 1961 → 1961</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
