var CODE='3C5',TITLE='3-sinf · Bir xonali songa bo‘lish';
// ulashish sahnasi: yuqorida "bor" (o'nlik tayoqchalar, birliklar), pastda k ta quti
function c5(t,u,k,per,perU,o){o=o||{};clear();var g=S.g;
 E('rect',{x:8,y:6,width:344,height:58,rx:10,fill:'#fdf3e3',stroke:'#efd9b5'},g);T(g,20,20,'Bor:',{'font-size':11,fill:'#5b6b7b','text-anchor':'start'});
 for(var i=0;i<t;i++)rod(g,60+i*14,12,46);for(var j=0;j<u;j++)unit(g,60+t*14+12+(j%5)*12,18+Math.floor(j/5)*14);
 var bw=(344-(k-1)*6)/k;for(var b=0;b<k;b++){var x=8+b*(bw+6);E('rect',{x:x,y:76,width:bw,height:82,rx:10,fill:'#e8f1fb',stroke:'#9cc3e8'},g);T(g,x+bw/2,90,(b+1)+'-do‘st',{'font-size':10,fill:'#5b6b7b'});
  for(var r=0;r<per;r++)rod(g,x+12+r*12,96,50);for(var q=0;q<perU;q++)unit(g,x+16+per*12+(q%3)*11,104+Math.floor(q/3)*12);
  if(o.lab)T(g,x+bw/2,154,String(per*10+perU),{'font-size':13,'font-weight':800,fill:C.ok})}}
var P1=[function(){c5(8,4,4,0,0);W3msg('84 ta yong‘oq: 8 ta o‘nlik va 4 ta birlik. 4 do‘stga teng bo‘lamiz')},
 function(){c5(0,4,4,2,0);W3msg('Avval o‘nliklar: 8 o‘nlik : 4 = har biriga <b>2 o‘nlik</b>')},
 function(){c5(0,0,4,2,1,{lab:1});W3msg('Keyin birliklar: 4 : 4 = <b>1</b>. Har biriga 2 o‘nlik 1 birlik = <b>21</b>')}];
var P2=[function(){c5(7,2,3,0,0);W3msg('72 : 3. 7 ta o‘nlikni 3 ga bo‘lamiz')},
 function(){c5(1,2,3,2,0);W3msg('Har biriga 2 o‘nlik (6 ta). <b>1 o‘nlik ortdi</b> — u bo‘linmaydi!')},
 function(){c5(0,12,3,2,0);W3msg('Ortgan o‘nlikni <b>10 ta birlikka maydalaymiz</b>: 10 + 2 = 12 birlik')},
 function(){c5(0,0,3,2,4,{lab:1});W3msg('12 : 3 = 4. Har biriga 2 o‘nlik 4 birlik = <b>24</b>')}];
var P5=[function(){W3eq(['369 : 3 = ?']);W3msg('Uch xonali sonni xonalarga ajratamiz')},
 function(){W3eq(['369 : 3 = ?','300 : 3 + 60 : 3 + 9 : 3']);W3msg('Har bir xona 3 ga bo‘linadi')},
 function(){W3eq(['369 : 3 = ?','300 : 3 + 60 : 3 + 9 : 3','[100] + [20] + [3] = 123']);W3msg('Tekshiramiz: 123 · 3 = 369 ✓')}];
var P6=[function(){W3eq(['618 : 3 = ?']);W3msg('6 yuzlik, 1 o‘nlik, 8 birlik')},
 function(){W3eq(['618 : 3 = ?','600 : 3 = [200]']);W3msg('Yuzliklar: 6 : 3 = 2 yuzlik')},
 function(){W3eq(['618 : 3 = ?','600 : 3 = 200','18 : 3 = [6]']);W3msg('1 o‘nlik 3 ga bo‘linmaydi — uni birliklar bilan birga olamiz: 18 : 3 = 6')},
 function(){W3eq(['618 : 3 = ?','200 + 6 = [206]']);W3msg('O‘nliklar xonasida <b>0</b>! Javob 206 (26 emas). Tekshiruv: 206 · 3 = 618 ✓')}];
var P7=[function(){W3eq(['104 : 4 = ?']);W3msg('1 yuzlikni 4 ga bo‘lib bo‘lmaydi…')},
 function(){W3eq(['104 : 4 = ?','104 = 80 + 24']);W3msg('Bo‘linadigan qulay qismlarga ajratamiz: 80 va 24')},
 function(){W3eq(['104 : 4 = ?','80 : 4 + 24 : 4','[20] + [6] = 26']);W3msg('Javob 26 — ikki xonali! Tekshiruv: 26 · 4 = 104 ✓')}];
var STEPS=[
{h:"Teng ulashamiz: avval o'nliklar",sum:"84 : 4 — avval o'nliklar (8 : 4 = 2), keyin birliklar (4 : 4 = 1): 21.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>84 ta yong'oqni 4 do'st teng bo'lishmoqchi. Yong'oqlar o'ntadan qopchada (o'nlik) va donalab (birlik). Tugmani bosib ulashing.</p>",btns:[phaser(P1,'▶ Ulashish')],
 after:"<p>Bo'lishda ham xonalar bo'yicha ishlaymiz: <b>avval katta xona</b> (o'nliklar), keyin kichigi (birliklar). 84 : 4 = <b>21</b>.</p>",
 q:{t:"63 : 3 = ?",opts:["21","20","12","30"],ok:0,why:"6 o'nlik : 3 = 2 o'nlik, 3 birlik : 3 = 1: 21.",hint:"Avval o'nliklarni 3 ga bo'ling, keyin birliklarni.",full:"63 = 6 o'nlik 3 birlik. 6 : 3 = 2 o'nlik, 3 : 3 = 1 birlik. Javob: 21. «12» — raqamlar teskari yozilgan."},
 tn:"Bolalarga o'nlik tayoqchalarni (yoki 10 talik bog'lamlarni) berib, 3–4 kishilik guruhlarda haqiqatan ulashtiring — Yaponiya darsliklarida bo'lish shu tarzda boshlanadi."},
{h:"O'nlik ortib qolsa — maydalaymiz",sum:"72 : 3: 7 o'nlikdan har biriga 2, 1 o'nlik ortdi → 10 birlik + 2 = 12 → 12 : 3 = 4. Javob 24.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>72 ni 3 do'stga bo'lamiz. 7 ta o'nlik 3 ga teng bo'linmaydi! Nima qilamiz? Kuzating.</p>",btns:[phaser(P2,'▶ Ulashish')],
 after:"<p>Ortib qolgan o'nlikni <b>10 ta birlikka maydalaymiz</b> va birliklar bilan qo'shamiz. Bu — keyingi darsdagi burchakli bo'lishning asosi.</p>",
 q:{t:"52 : 4 = ?",opts:["12","13","14","11"],ok:1,why:"5 o'nlik : 4 = 1 o'nlik, 1 o'nlik ortadi → 12 birlik : 4 = 3. Javob 13.",hint:"Ortib qolgan o'nlikni birliklarga qo'shishni unutmang.",full:"5 o'nlikdan har biriga 1, 1 o'nlik ortdi. U 10 birlik + 2 = 12 birlik, 12 : 4 = 3. Javob: 1 o'nlik 3 birlik = 13. Tekshiruv: 13 · 4 = 52 ✓."},
 tn:"«Maydalash» so'zini atay ishlating — bu qarz olib ayirish bilan bir xil g'oya: 1 o'nlik = 10 birlik."},
{h:"Qulay qismlarga ajratish",sum:"96 : 4 = 80 : 4 + 16 : 4 = 20 + 4 = 24. Har bir qism 4 ga bo'linishi kerak.",a:"m03",start:function(){W3eq(['96 : 4 = ?']);W3msg('96 ni qaysi qismlarga ajratsak, ikkalasi ham 4 ga bo‘linadi?')},fin:function(){W3eq(['96 : 4','80 : 4 + 16 : 4','20 + 4 = 24']);W3msg('Javob: 24')},
 html:"<p>Og'zaki hisoblashning eng kuchli usuli: sonni <b>bo'linadigan qismlarga</b> ajratish. 96 : 4 uchun qaysi ajratish qulay? Tanlang:</p>",
 btns:[["90 + 6",function(c){W3eq(['96 : 4','90 : 4 = ?']);W3msg('90 ni 4 ga teng bo‘lib bo‘lmaydi — bu ajratish noqulay','Qayta tanlang')}],["80 + 16",function(c,done){W3eq(['96 : 4','80 : 4 + 16 : 4','[20] + [4] = 24']);W3msg('Zo‘r! 80 ham, 16 ham 4 ga bo‘linadi');done()}],["50 + 46",function(c){W3eq(['96 : 4','50 : 4 = ?']);W3msg('50 ni 4 ga teng bo‘lib bo‘lmaydi','Qayta tanlang')}]],g3:1,
 after:"<p>Qoida: qismlar <b>bo'luvchiga bo'linadigan</b> bo'lsin. Ko'pincha «o'nliklar + qolgani» qulay: 96 = 80 + 16 (8 o'nlik 4 ga bo'linadi).</p>",
 q:{t:"78 : 6 ni qaysi ajratish bilan hisoblash qulay?",opts:["70 + 8","60 + 18","40 + 38","75 + 3"],ok:1,why:"60 : 6 = 10, 18 : 6 = 3 — ikkalasi ham bo'linadi: 13.",hint:"Qaysi variantda ikkala qism ham 6 ga bo'linadi?",full:"60 : 6 = 10 va 18 : 6 = 3, javob 13. 70 va 8 — 6 ga bo'linmaydi, 40 va 38 ham, 75 va 3 ham."},
 tn:"Bu — «taqsimot xossasi» ning bo'lishdagi ko'rinishi. Bolalar bir misolni 2–3 xil ajratib ko'rsin va eng qulayini tanlasin."},
{h:"Tekshirish: ko'paytirib ko'ramiz",sum:"Bo'linma · bo'luvchi = bo'linuvchi. 24 · 4 = 96 ✓.",a:"m04",start:function(){W3eq(['96 : 4 = 24','?']);W3msg('Javobni qanday tekshiramiz?')},fin:function(){W3eq(['96 : 4 = 24','24 · 4 = [96] ✓']);W3msg('To‘g‘ri!')},
 html:"<p>Bo'lishning javobi to'g'rimi? <b>Ko'paytirish bilan</b> tekshiramiz: bo'linma · bo'luvchi = bo'linuvchi.</p>",
 btns:[["✓ Tekshirish",function(c,done){W3eq(['96 : 4 = 24','24 · 4 = [96] ✓']);W3msg('24 · 4 = 96 — bo‘linuvchining o‘zi chiqdi');done()}]],
 after:"<p>Agar ko'paytirganda bo'linuvchi chiqmasa — javob xato. Masalan, 96 : 4 = 23 desak: 23 · 4 = 92 ≠ 96.</p>",
 q:{t:"Ali 85 : 5 = 16 deb yozdi. Tekshiring.",opts:["To'g'ri, chunki 16 · 5 = 85","Xato: 16 · 5 = 80, to'g'ri javob 17","Xato: to'g'ri javob 15","To'g'ri, chunki 85 − 5 = 80"],ok:1,why:"16 · 5 = 80 ≠ 85. 17 · 5 = 85.",hint:"16 ni 5 ga ko'paytirib ko'ring.",full:"16 · 5 = 80, bu 85 emas — javob xato. 85 = 50 + 35: 10 + 7 = 17. Tekshiruv: 17 · 5 = 85 ✓."},
 tn:"Har bo'lishdan keyin og'zaki tekshirishni odat qildiring — bu xatolarni ikki barobar kamaytiradi."},
{h:"Uch xonali sonni bo'lish",sum:"369 : 3 = 300 : 3 + 60 : 3 + 9 : 3 = 100 + 20 + 3 = 123.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Uch xonali son ham xonalar bo'yicha bo'linadi: yuzliklar, o'nliklar, birliklar.</p>",btns:[phaser(P5)],
 after:"<p>Har xona alohida bo'linsa — juda oson: <b>369 : 3 = 123</b>. Qiyini — xona bo'linmay qolganda. Keyingi qadamlarda shu tuzoqlar.</p>",
 q:{t:"484 : 4 = ?",opts:["121","112","211","120"],ok:0,why:"400 : 4 = 100, 80 : 4 = 20, 4 : 4 = 1.",hint:"Har bir xonani alohida 4 ga bo'ling.",full:"484 = 400 + 80 + 4. 100 + 20 + 1 = 121. Tekshiruv: 121 · 4 = 484 ✓."},
 tn:"Xonalar jadvalini doskaga chizib, har xona ostiga bo'linmasini yozdiring."},
{h:"Tuzoq: javob ichida 0",sum:"618 : 3 = 206: o'nliklar xonasida 1 < 3, shuning uchun bo'linmada 0 turadi.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>618 : 3. Ko'pchilik «26» deb yozadi. Nima uchun xato? Kuzating.</p>",btns:[phaser(P6)],
 after:"<p>Bo'linmada har xona uchun raqam bo'lishi kerak. O'nliklar bo'linmasa — o'nliklar o'rniga <b>0</b> yoziladi: 206. Tekshirish xatoni darhol ko'rsatadi: 26 · 3 = 78, 618 emas!</p>",
 q:{t:"824 : 4 = ?",opts:["26","206","216","260"],ok:1,why:"800 : 4 = 200, 24 : 4 = 6: 206.",hint:"Yuzliklarni bo'ling, keyin qolgan 24 ni.",full:"800 : 4 = 200. 2 o'nlik 4 ga bo'linmaydi, 24 birlik : 4 = 6. Javob 206. «26» — 0 tushib qolgan: 26 · 4 = 104."},
 tn:"«Bo'linmada nechta raqam bo'ladi?» savolini har misoldan oldin bering: 618 : 3 da — uch xonali, chunki 6 ≥ 3."},
{h:"Tuzoq: birinchi raqam kichik bo'lsa",sum:"104 : 4 = 26: 1 < 4, shuning uchun birinchi bo'lak 10, javob ikki xonali.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>104 : 4. Birinchi raqam 1 — u 4 ga bo'linmaydi. Javob necha xonali bo'ladi?</p>",btns:[phaser(P7)],
 after:"<p>Birinchi raqam bo'luvchidan kichik bo'lsa, ikkita raqamni birga olamiz (10 o'nlik) — javob <b>bir xona qisqa</b> bo'ladi: 104 : 4 = 26.</p>",
 q:{t:"Qaysi bo'lishning javobi ikki xonali son?",opts:["369 : 3","618 : 3","216 : 4","484 : 4"],ok:2,why:"216 : 4 — 2 < 4, javob 54.",hint:"Qaysi misolda birinchi raqam bo'luvchidan kichik?",full:"216 : 4: 2 yuzlik 4 ga bo'linmaydi, 21 o'nlik olinadi — javob 54 (ikki xonali). Qolganlari: 123, 206, 121 — uch xonali."},
 tn:"Javobning xonalar sonini oldindan aytish — xalqaro tavsiyadagi «natijani chamalash» odati."},
{h:"Masalada bo'lish: chizma",sum:"96 bet 4 kunda teng o'qilsa — 96 : 4 = 24 bet kuniga. Chizmada 4 ta teng bo'lak.",a:"m08",start:function(){clear();W3bars(60,4,['?','?','?','?']);Br(40,320,56,'96 bet',true);W3msg('Kitob 96 bet, 4 kunda teng o‘qildi. Kuniga necha bet?')},fin:function(){clear();W3bars(60,4,[24,24,24,24],{fill:function(){return C.a}});Br(40,320,56,'96 bet',true);W3msg('96 : 4 = <b>24</b> bet kuniga')},
 html:"<p>Masala: <i>«Kitob 96 bet. Bola uni 4 kunda teng o'qidi. Kuniga necha bet o'qigan?»</i> Chizmani to'ldiring.</p>",
 btns:[["✏️ Chizmani to'ldirish",function(c,done){clear();W3bars(60,4,[24,24,24,24],{fill:function(){return C.a}});Br(40,320,56,'96 bet',true);W3msg('96 : 4 = <b>24</b>. Tekshiruv: 24 · 4 = 96 ✓');done()}]],
 after:"<p>«Teng bo'lindi» — chizmada <b>teng bo'laklar</b>. Butun ma'lum, bo'laklar soni ma'lum → bo'lish.</p>",
 q:{t:"84 ta daftar 7 ta sinfga teng tarqatildi. Har sinfga nechta?",opts:["14","12","11","13"],ok:1,why:"84 : 7 = 12 (70 : 7 + 14 : 7 = 10 + 2).",hint:"84 ni 7 ga bo'linadigan qismlarga ajrating: 70 + 14.",full:"84 = 70 + 14. 70 : 7 = 10, 14 : 7 = 2. Javob 12. Tekshiruv: 12 · 7 = 84 ✓."},
 tn:"Singapur chizma modeli: butun — bitta uzun to'rtburchak, teng bo'laklarga bo'linadi. Bolalar avval chizsin, keyin hisoblasin."},
{h:"Bilasizmi? Bo'lish belgisi",sum:"«:» belgisini Leybnits (1684), «÷» ni Iogann Ran (1659) kiritgan.",a:"m09",start:function(){clear('#f6ead0');T(S.g,110,96,':',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,250,100,'÷',{'font-size':80,'font-weight':800,fill:'#6b3d12'});T(S.g,110,150,'Leybnits, 1684',{'font-size':12,fill:'#6b3d12'});T(S.g,250,150,'Ran, 1659',{'font-size':12,fill:'#6b3d12'});W3msg('Ikki xil belgi — bitta amal')},fin:function(){STEPS[8].start()},
 html:"<p>📜 Biz yozadigan <b>:</b> belgisini nemis olimi <b>Gotfrid Leybnits</b> 1684-yilda kiritgan. Ko'p mamlakatlarda <b>÷</b> belgisi ishlatiladi — uni shveytsariyalik <b>Iogann Ran</b> 1659-yilda kitobida qo'llagan. Kalkulyatordagi ÷ tugmasi ham shu!</p><p>⭐ Al-Xorazmiyning hind hisobi haqidagi kitobida bo'lish xonalar bo'yicha, yuqoridan pastga bajarilgan — hozirgi usulimizning bobosi.</p>",
 tn:"Bolalarga kalkulyatorda ÷ tugmasini ko'rsating va «bu ham bizning : belgimiz» deng."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3eq(['96 : 4 = 80 : 4 + 16 : 4','= 20 + 4 = 24','24 · 4 = 96 ✓'])},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Bo'lish <b>katta xonadan</b> boshlanadi: 84 : 4 → 8 o'nlik : 4 = 2, 4 : 4 = 1 → 21.</li><li>Xona ortib qolsa — <b>maydalang</b>: 1 o'nlik = 10 birlik (72 : 3 = 24).</li><li>Qulay ajratish: qismlar bo'luvchiga bo'linsin (96 = 80 + 16).</li><li><b>Tekshiring</b>: bo'linma · bo'luvchi = bo'linuvchi.</li><li>Xona bo'linmasa — bo'linmada <b>0</b>: 618 : 3 = 206.</li><li>Birinchi raqam bo'luvchidan kichik — javob bir xona qisqa: 104 : 4 = 26.</li></ul></div>",
 tn:"Keyingi darsni «Qoldiq qayerdan keladi? 25 : 4 = ?» savoli bilan boshlang."}
];
var PROBS=[
{t:"48 : 4 = ?",o:["12","14","21","11"],k:0,s:"4 o'nlik : 4 = 1, 8 : 4 = 2 → 12."},
{t:"75 : 5 = ?",o:["15","13","17","25"],k:0,s:"75 = 50 + 25: 10 + 5 = 15."},
{t:"92 : 4 = ?",o:["23","22","24","32"],k:0,s:"92 = 80 + 12: 20 + 3 = 23."},
{t:"84 : 6 = ?",o:["14","12","16","13"],k:0,s:"84 = 60 + 24: 10 + 4 = 14."},
{t:"91 : 7 = ?",o:["13","12","11","17"],k:0,s:"91 = 70 + 21: 10 + 3 = 13."},
{t:"639 : 3 = ?",o:["213","231","203","312"],k:0,s:"600 : 3 + 30 : 3 + 9 : 3 = 200 + 10 + 3 = 213."},
{t:"848 : 4 = ?",o:["212","221","202","242"],k:0,s:"200 + 10 + 2 = 212."},
{t:"515 : 5 = ?",o:["103","13","113","130"],k:0,s:"500 : 5 = 100, 15 : 5 = 3 → 103 (o'nliklarda 0)."},
{t:"936 : 3 = ?",o:["312","321","302","213"],k:0,s:"900 : 3 + 30 : 3 + 6 : 3 = 300 + 10 + 2 = 312."},
{t:"128 : 4 = ?",o:["32","23","302","42"],k:0,s:"1 < 4, 12 o'nlik : 4 = 3, 8 : 4 = 2 → 32."},
{t:"Qaysi bo'lishning javobi uch xonali?",o:["642 : 2","156 : 3","245 : 5","168 : 4"],k:0,s:"642 : 2 = 321. Qolganlarida birinchi raqam bo'luvchidan kichik: 52, 49, 42."},
{t:"Vali 96 : 3 = 31 deb yozdi. To'g'ri javob qaysi?",o:["32","31","33","23"],k:0,s:"31 · 3 = 93 ≠ 96. 96 = 90 + 6: 30 + 2 = 32."},
{t:"72 ta olma 6 ta savatga teng solindi. Har savatda nechta?",o:["12","14","11","13"],k:0,s:"72 = 60 + 12: 10 + 2 = 12."},
{t:"Bo'linma 24, bo'luvchi 4. Bo'linuvchini toping.",o:["96","6","28","20"],k:0,s:"Bo'linuvchi = bo'linma · bo'luvchi = 24 · 4 = 96."},
{t:"812 : 4 = ?",o:["203","23","213","230"],k:0,s:"800 : 4 = 200, 12 : 4 = 3 → 203."},
{t:"98 ni 7 ga bo'lish uchun qaysi ajratish qulay?",o:["70 + 28","90 + 8","50 + 48","80 + 18"],k:0,s:"70 : 7 = 10, 28 : 7 = 4 → 14."},
{t:"Qaysi tenglik noto'g'ri?",o:["618 : 3 = 26","306 : 3 = 102","480 : 4 = 120","555 : 5 = 111"],k:0,s:"618 : 3 = 206 (26 · 3 = 78)."},
{t:"Bir pachkada 4 ta pechene. 96 ta pechene nechta pachka bo'ladi?",o:["24","23","26","22"],k:0,s:"96 : 4 = 24."},
{t:"Sonni 3 ga bo'lib, 5 ni qo'shsak 30 chiqdi. Sonni toping.",o:["75","25","105","90"],k:0,s:"Oxiridan: 30 − 5 = 25, 25 · 3 = 75. Tekshiruv: 75 : 3 + 5 = 30."},
{t:"(84 : 4) : 3 = ?",o:["7","21","28","6"],k:0,s:"84 : 4 = 21, 21 : 3 = 7."}
];
function PRACT_STAGE(){W3eq(['96 : 4 = 80 : 4 + 16 : 4','= 24']);W3msg('Avval katta xona, oxirida tekshirish')}
var PREP_DATA={teach:["Ikki va uch xonali sonni bir xonali songa xonalar bo'yicha bo'lish.","Ortgan xonani maydalash (1 o'nlik = 10 birlik).","Qulay qismlarga ajratish; ko'paytirish bilan tekshirish.","Tuzoqlar: bo'linmada 0 (618 : 3 = 206), birinchi raqam kichik (104 : 4 = 26)."],
 mist:["618 : 3 = 26 deb yozadi — 0 ni tushirib qoldiradi.","Ortgan o'nlikni birliklarga qo'shmaydi (72 : 3 = 22).","96 ni noqulay ajratadi (90 + 6).","Javobni tekshirmaydi."],
 need:["O'nlik tayoqchalar yoki 10 talik bog'lamlar.","Doskada xonalar jadvali."],
 board:["<span class='w2'>84 : 4 → 8 o'nlik : 4 = 2, 4 : 4 = 1 → 21</span>","<span class='w2'>72 : 3 → 2 o'nlik, 1 ortdi → 12 : 3 = 4 → 24</span>","<span class='w2'>96 : 4 = 80 : 4 + 16 : 4</span>","<span class='w2'>24 · 4 = 96 ✓</span>","<span class='w2'>618 : 3 = 206</span>","<span class='w2'>104 : 4 = 26</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
