var CODE='3J13',TITLE='3-sinf · Eng kami nechta? (Dirixle prinsipi)';
var D13={};
function d13Draw(taken,cap,good){clear();var g=S.g;E('rect',{x:16,y:24,width:110,height:116,rx:12,fill:'#2b2f3a'},g);T(g,71,80,'🌑',{'font-size':26});T(g,71,108,cap||'qorong‘i quti',{'font-size':10,fill:'#fff'});
 taken.forEach(function(e,i){var x=152+(i%7)*29,y=42+Math.floor(i/7)*36,ok=good&&good.indexOf(i)>=0;E('rect',{x:x-13,y:y-16,width:26,height:30,rx:7,fill:ok?'#e6f6ee':'#fff',stroke:ok?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,y+6,e,{'font-size':17})})}
var P2=[function(){d13Draw([],'2🔴 8🟢 7🟡 9🔵');j2Msg('Qutida 2 qizil, 8 yashil, 7 sariq, 9 ko‘k shar. <b>4 ta bir xil rangli</b> shar albatta bo‘lishi uchun kamida nechta olamiz?')},
 function(){d13Draw(['🔴','🔴','🟢','🟢','🟢','🟡','🟡','🟡','🔵','🔵','🔵']);j2Msg('Eng omadsiz holat: har rangdan <b>3 tadan</b> (qizil esa bor-yo‘g‘i 2 ta) — 2 + 3 + 3 + 3 = <b>11</b>, hali 4 ta bir xil yo‘q')},
 function(){d13Draw(['🔴','🔴','🟢','🟢','🟢','🟡','🟡','🟡','🔵','🔵','🔵','🟢'],'',[2,3,4,11]);j2Msg('12-shar yashil, sariq yoki ko‘k bo‘ladi — 4 ta bir xil tayyor! Javob: <b>12</b>')}];
var P3=[function(){d13Draw([],'4🔴 6🔵 3🟢');j2Msg('4 qizil, 6 ko‘k, 3 yashil. <b>Har xil rangli</b> 2 ta shar albatta bo‘lishi uchun kamida nechta olamiz?')},
 function(){d13Draw(['🔵','🔵','🔵','🔵','🔵','🔵']);j2Msg('Eng omadsiz holat: <b>eng ko‘p</b> rangdagilarning hammasi chiqadi — 6 ta ko‘k')},
 function(){d13Draw(['🔵','🔵','🔵','🔵','🔵','🔵','🔴'],'',[5,6]);j2Msg('7-shar endi ko‘k bo‘la olmaydi — boshqa rang! Javob: 6 + 1 = <b>7</b>')}];
var P4=[function(){d13Draw([],'10🔴 10🔵');j2Msg('10 qizil va 10 ko‘k qalam. <b>Albatta 2 ta qizil</b> bo‘lishi uchun kamida nechta?')},
 function(){d13Draw(['🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵']);j2Msg('Eng omadsiz holat: avval 10 ta ko‘kning <b>hammasi</b> chiqadi')},
 function(){d13Draw(['🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔵','🔴','🔴'],'',[10,11]);j2Msg('Endi faqat qizil qoldi: yana 2 ta. Javob: 10 + 2 = <b>12</b> (3 emas!)')}];
var P5=[function(){j2Boxes([[],[],[],[],[],[]],{names:['yan–fev','mar–apr','may–iyn','iyl–avg','sen–okt','noy–dek']});j2Msg('25 o‘quvchi, 12 oy. Kamida nechtasi bir oyda tug‘ilgani aniq?')},
 function(){j2Lines([['25 = 12 · 2 + 1',C.blue,26],['har oyga 2 tadan — 24 ta',null,16],['ortib qolgan 1 ta → biror oyda 3 ta',C.bad,16]]);j2Msg('Teng tarqatamiz: har oyga 2 tadan = 24. Qolgan 1 kishi qaysi oyga tushsa ham — u yerda <b>3 ta</b>')}];
var P7=[function(){j2Boxes([['1','10'],['2','9'],['3','8'],['4','7'],['5','6']],{names:['11','11','11','11','11']});j2Msg('1 dan 10 gacha sonlarni yig‘indisi 11 bo‘ladigan <b>5 ta juft</b>ga — 5 ta qutiga ajratdik')},
 function(){j2Boxes([['1'],['9'],['3'],['7'],['5']],{names:['11','11','11','11','11']});j2Msg('5 ta sonni har qutidan bittadan tanlasak — hali juft yo‘q')},
 function(){j2Boxes([['1'],['9'],['3','8'],['7'],['5']],{names:['11','11','11','11','11'],hl:[2]});j2Msg('6-son albatta biror qutiga ikkinchi bo‘lib tushadi: 3 + 8 = 11! Javob: <b>6</b> ta son')}];
var STEPS=[
{h:"Kabutarlar va uyalar",sum:"5 kabutar 4 uyaga kirsa, albatta biror uyada kamida 2 ta kabutar bo'ladi.",a:"m01",
 start:function(){D13.k=0;D13.it=[[],[],[],[]];j2Boxes(D13.it,{names:['1-uya','2-uya','3-uya','4-uya'],tap:d13Tap});j2Msg('Kabutarlarni uyalarga joylang: uyalarni bosing. <b>Har uyaga bittadan</b> qo‘yishga harakat qiling!')},
 fin:function(){j2Boxes([['🐦','🐦'],['🐦'],['🐦'],['🐦']],{names:['1-uya','2-uya','3-uya','4-uya'],hl:[0]});j2Msg('5 kabutar, 4 uya → biror uyada albatta <b>2 ta</b>')},
 html:"<p>5 ta kabutar 4 ta uyaga uchib kirdi. Siz ularni joylang — iloji boricha <b>har biri alohida</b> bo'lsin. Uyalarni bosing.</p>",
 act:function(c,done){c.querySelector('.hint').textContent='Uyalarni 5 marta bosing.';D13.done=done},
 after:"<p>Qanday joylasangiz ham, 4 ta uya 4 ta kabutarga yetadi, <b>5-kabutar</b> albatta kimningdir yoniga tushadi. Bu — <b>Dirixle prinsipi</b>: narsa qutidan ko'p bo'lsa, biror qutida kamida 2 ta bo'ladi.</p>",
 q:{t:"13 o'quvchi bor. Qaysi gap ALBATTA to'g'ri?",opts:["Hammasi har xil oyda tug'ilgan","Kamida 2 tasi bir oyda tug'ilgan","Kamida 3 tasi bir oyda tug'ilgan","Kimdir yanvarda tug'ilgan"],ok:1,why:"Oylar 12 ta — 13-o'quvchi albatta kimningdir oyiga tushadi.",hint:"Oylar — «uyalar», o'quvchilar — «kabutarlar». Kabutar uyadan ko'pmi?",full:"12 ta oy — 12 ta uya. 13 o'quvchi — 13 ta kabutar. 13 > 12, demak biror oyda kamida 2 tasi bor. «3 tasi» albatta emas, «yanvar» ham shart emas."},
 tn:"Sinfda bolalarni «uyalar»ga (stullarga) o'tqazib ko'ring: stul bitta kam bo'lsa, kimdir albatta ikki kishi bo'lib qoladi. Prinsipni bolalar o'z tanasida his qilsin."},
{h:"Eng omadsiz holat",sum:"«Albatta» savolida eng omadsiz holatni o'ylaymiz: 2+3+3+3 = 11, keyingisi 12-shar.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>«Kamida nechta olsak, <b>albatta</b>…» degan savollarning kaliti — <b>eng omadsiz holat</b>. Biz go'yo eng yomon omadli odammiz: kerakli narsa iloji boricha kech chiqadi.</p>",
 btns:[phaser(P2)],
 after:"<p>Usul: har rangdan «kerakli sondan bitta kam» olamiz (3 tadan), lekin rang kam bo'lsa — borini (qizil 2 ta). Keyin <b>+1</b>.</p>",
 q:{t:"Qutida 6 qizil, 6 ko'k, 6 yashil shar. Albatta 3 ta bir xil rangli bo'lishi uchun kamida nechta olish kerak?",opts:["3","7","9","6"],ok:1,why:"Har rangdan 2 tadan = 6 ta, 7-shar albatta uchinchi bo'ladi.",hint:"Eng omadsiz holat: har rangdan nechtadan olinsa, hali 3 ta bir xil yo'q?",full:"Har rangdan 2 tadan olinsa — 6 ta, hali 3 ta bir xil yo'q. 7-shar qaysi rang bo'lsa ham, uchinchisi bo'ladi. Javob: 7. «3» — eng omadli holat, savol esa «albatta»."},
 tn:"Bolalar «albatta» va «balki» so'zlarini farqlashi kerak. 3 ta olib omad kulsa — 3 ta bir xil chiqishi MUMKIN, lekin ALBATTA emas."},
{h:"«Har xil rangli» bo'lsin desa",sum:"Har xil rang kerak bo'lsa — eng ko'p rangning hammasi + 1: 6 + 1 = 7.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Endi teskarisi: bir xil emas, <b>har xil</b> rangli 2 ta kerak. Eng omadsiz holat qanday bo'ladi?</p>",
 btns:[phaser(P3)],
 after:"<p>Bu safar eng yomon holat — <b>bir xil</b> rang ketma-ket chiqishi. Eng ko'p rang 6 ta — hammasi chiqib bo'lgach, keyingisi albatta boshqa rang: <b>7</b>.</p>",
 q:{t:"Qutida 8 qizil va 3 ko'k shar. Ikkala rangdan ham bo'lishi uchun kamida nechta olish kerak?",opts:["2","4","9","11"],ok:2,why:"Eng omadsiz: 8 ta qizilning hammasi, keyin 9-si ko'k.",hint:"Eng ko'p rangdagi sharlar hammasi chiqib ketsa-chi?",full:"Eng yomon holat — avval 8 ta qizilning hammasi chiqadi. 9-shar albatta ko'k. Javob: 9. «4» — 3 ko'k + 1 deb, kichik rangni olgan xato."},
 tn:"Ikki turdagi savolni yonma-yon yozing: «bir xil» → har biridan (kerak − 1) + 1; «har xil» → eng ko'p rangning hammasi + 1."},
{h:"Tuzoq: «albatta 2 ta qizil»",sum:"10 qizil, 10 ko'k: albatta 2 qizil uchun — 10 ko'k + 2 = 12 (3 emas).",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«10 ta qizil va 10 ta ko'k qalamdan, ko'rmasdan, kamida nechta olsak, albatta <b>2 ta qizil</b> bo'ladi?» Ko'pchilik «3» deydi. Tekshiramiz!</p>",
 btns:[phaser(P4)],
 after:"<p>«3» — bu «2 ta <b>bir xil</b> rangli» savolining javobi. Bizdan esa aniq <b>qizil</b> so'ralyapti. Eng omadsiz holatda boshqa rangning <b>hammasi</b> oldin chiqadi: 10 + 2 = <b>12</b>.</p>",
 q:{t:"Tortmada 4 juft qora va 4 juft jigarrang paypoq aralash yotibdi. Albatta bir juft QORA paypoq olish uchun kamida nechta paypoq olish kerak?",opts:["3","10","9","16"],ok:1,why:"8 ta jigarrang paypoq + 2 ta qora = 10.",hint:"Qancha jigarrang paypoq bor? Eng yomon holatda ularning hammasi chiqadi.",full:"4 juft jigarrang — 8 ta paypoq. Eng omadsiz holatda hammasi oldin chiqadi, keyin 2 ta qora: 8 + 2 = 10. «3» — rangi farqsiz juft uchun javob."},
 tn:"Savoldagi so'zlarni tagiga chizdiring: «bir xil», «har xil», «qizil». Har biri boshqa javob beradi."},
{h:"Ko'p narsa — ko'p qutiga",sum:"25 o'quvchi, 12 oy: 25 = 12 · 2 + 1 → kamida 3 tasi bir oyda.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Narsalar qutilardan bir necha barobar ko'p bo'lsa-chi? 25 o'quvchi va 12 oy.</p>",
 btns:[phaser(P5)],
 after:"<p>Qoida: narsalarni qutilarga <b>iloji boricha teng</b> taqsimlaymiz. Qoldiq bo'lsa — biror qutida bittaga ko'p bo'ladi. 25 : 12 = 2 (qoldiq 1) → kamida <b>3</b>.</p>",
 q:{t:"Kamida nechta o'quvchi bo'lsa, ularning 4 tasi bir oyda tug'ilgani aniq?",opts:["36","37","48","13"],ok:1,why:"12 · 3 = 36 — har oyda 3 tadan; 37-si albatta to'rtinchi.",hint:"Har oyga 3 tadan tushsa, nechta kishi bo'ladi? Keyin +1.",full:"Har oyda 3 tadan bo'lsa — 12 · 3 = 36 kishi, hali 4 ta yo'q. 37-kishi qaysi oyga tushsa ham, u yerda 4 ta bo'ladi. Javob: 37."},
 tn:"Formula: narsa = quti · k + 1 bo'lsa, biror qutida kamida k + 1 ta. Uni rasm bilan ko'rsatgandan keyin aytish kerak."},
{h:"Qutini o'zingiz yasang",sum:"1–10 dan yig'indisi 11 bo'lgan 5 juft = 5 quti; 6 ta son tanlansa, albatta bir juft to'liq.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Eng qiyin turi: qutilar tayyor berilmaydi, ularni <b>o'zimiz o'ylab topamiz</b>. Masala: 1 dan 10 gacha sonlardan kamida nechtasini tanlasak, ular orasida albatta yig'indisi 11 bo'lgan ikkita son bo'ladi?</p>",
 btns:[phaser(P7)],
 after:"<p>Hiyla — to'g'ri «quti»ni topish: yig'indisi 11 bo'lgan juftlar (1+10, 2+9, …). Ular 5 ta. 5 tadan ko'p son tanlasak — biror juft albatta to'liq bo'ladi.</p>",
 q:{t:"40 o'quvchi 3 ta to'garakka bo'lindi (har biri bitta to'garakda). Eng katta to'garakda kamida nechta o'quvchi bor?",opts:["13","14","15","20"],ok:1,why:"40 = 3 · 13 + 1 → biror to'garakda kamida 14.",hint:"Iloji boricha teng tarqating: har to'garakka 13 tadan — nechta qoladi?",full:"Har to'garakka 13 tadan — 39 kishi. Qolgan 1 kishi biror to'garakka qo'shiladi: 14. Demak eng kattasida kamida 14 ta. «13» — qoldiqni unutgan."},
 tn:"Olimpiadada qutini o'ylab topish — eng qiyin joy. Bolalarga «nimaga bo'lsak qulay?» deb so'rang: oylar, ranglar, juftlar, qoldiqlar."},
{h:"Bilasizmi? Dirixle «yashiklari»",sum:"Nemis matematigi Dirixle 1834-yilda bu fikrni «yashiklar prinsipi» deb yozgan.",a:"m07",
 start:function(){j2Lines([['🗄️  Dirixle prinsipi',C.blue,22],['n + 1 narsa, n ta yashik',null,17],['→ biror yashikda kamida 2 ta',C.ok,17]])},fin:function(){j2Lines([['🗄️  Dirixle prinsipi',C.blue,22],['n + 1 narsa, n ta yashik',null,17],['→ biror yashikda kamida 2 ta',C.ok,17]])},
 html:"<p>📜 Nemis matematigi <b>Peter Gustav Lejen Dirixle</b> 1834-yilda bu fikrni «yashiklar prinsipi» deb ishlatgan. Inglizlar uni «kabutar uyalari prinsipi» deyishadi.</p><p>Bu oddiy fikr yordamida murakkab narsalar isbotlanadi: masalan, katta shaharda sochlari soni bir xil bo'lgan kamida ikki kishi borligini — chunki odamning sochi bir necha yuz mingdan oshmaydi, aholi esa millionlab.</p>",
 btns:[["🗄️ Tushundim",function(c,done){done()}]],
 tn:"Bolalarga o'zlari ham shunday «isbot» topishni taklif qiling: «Bizning maktabda tug'ilgan kuni bir xil ikki o'quvchi bormi?» (o'quvchilar 366 dan ko'p bo'lsa — albatta)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([['n + 1 → kamida 2',C.blue,26]])},fin:function(){j2Lines([['n + 1 → kamida 2',C.blue,26]])},
 html:"<div class='memo'><ul><li><b>Dirixle prinsipi:</b> narsa qutidan ko'p bo'lsa — biror qutida kamida 2 ta.</li><li>«<b>Albatta</b>» savoli → <b>eng omadsiz holatni</b> o'ylang, keyin <b>+1</b>.</li><li>Bir xil rangli k ta: har rangdan (k − 1) ta (rang kam bo'lsa — borini), keyin +1.</li><li>Har xil rangli: eng ko'p rangning <b>hammasi</b> + 1.</li><li>Aniq rang (masalan, 2 qizil): boshqa ranglarning hammasi + 2.</li><li>Ko'p narsa: teng taqsimlang — qoldiq bo'lsa, biror qutida bittaga ko'p (25 = 12 · 2 + 1 → 3).</li><li>Qutilar berilmasa — o'zingiz toping: oylar, ranglar, juftlar.</li></ul></div>",
 tn:"Keyingi darsni «Sinfimizda bir oyda tug'ilgan kamida nechta o'quvchi bor?» savoli bilan boshlang — sinf ro'yxati bilan tekshiring."}
];
function d13Tap(i){if(D13.k>=5)return;D13.it[i].push('🐦');D13.k++;var hl=[];D13.it.forEach(function(b,j){if(b.length>=2)hl.push(j)});j2Boxes(D13.it,{names:['1-uya','2-uya','3-uya','4-uya'],tap:d13Tap,hl:D13.k>=5?hl:[]});
 j2Msg(D13.k<5?'Joylandi: <b>'+D13.k+'</b> ta kabutar':'5 ta kabutar — qizil uyada albatta 2 ta yoki undan ko‘p!');if(D13.k>=5&&D13.done){var d=D13.done;D13.done=null;d()}}
var PROBS=[
{t:"5 mushuk 4 xonaga joylashdi. Qaysi gap ALBATTA to'g'ri?",o:["Biror xonada kamida 2 mushuk bor","Har xonada bittadan mushuk","Biror xonada 5 mushuk","Biror xona bo'sh"],k:0,s:"Xona 4 ta, mushuk 5 ta — biror xonada albatta kamida 2 ta."},
{t:"Qutida 3 xil rangli paypoqlar ko'p. Ko'rmasdan kamida nechta olsak, 2 tasi bir xil rangda bo'ladi?",o:["4","3","2","6"],k:0,s:"Eng omadsiz: har rangdan 1 tadan — 3 ta. 4-si albatta takrorlanadi."},
{t:"Qutida 5 qora va 7 oq shar. Albatta 2 ta oq shar bo'lishi uchun kamida nechta olish kerak?",o:["7","3","2","12"],k:0,s:"Eng omadsiz: 5 qoraning hammasi, keyin 2 oq: 5 + 2 = 7."},
{t:"Sinfda 32 o'quvchi. Kamida nechtasi haftaning bir kunida tug'ilgani aniq?",o:["5","4","6","7"],k:0,s:"32 = 7 · 4 + 4 → biror kunda kamida 5 ta."},
{t:"Qutida 2 qizil, 8 yashil, 7 sariq, 9 ko'k shar. 4 ta bir xil rangli shar albatta bo'lishi uchun kamida nechta olish kerak?",o:["12","11","10","9"],k:0,s:"2 + 3 + 3 + 3 = 11 ta — hali yo'q; 12-si albatta to'rtinchi."},
{t:"4 qizil, 6 ko'k, 3 yashil shar. Har xil rangli 2 ta shar albatta bo'lishi uchun kamida nechta?",o:["7","3","4","11"],k:0,s:"Eng ko'p rang — 6 ko'k, hammasi + 1 = 7."},
{t:"10 qizil va 10 ko'k qalam. Albatta 2 ta qizil qalam bo'lishi uchun kamida nechta?",o:["12","11","3","20"],k:0,s:"10 ko'k + 2 qizil = 12."},
{t:"25 o'quvchidan kamida nechtasi bir oyda tug'ilgani aniq?",o:["3","2","4","12"],k:0,s:"25 = 12 · 2 + 1 → kamida 3."},
{t:"Kamida nechta o'quvchi bo'lsa, ularning 4 tasi bir oyda tug'ilgani aniq?",o:["37","36","48","13"],k:0,s:"12 · 3 + 1 = 37."},
{t:"Xaltada 3 olma, 3 nok, 3 behi. Ko'rmasdan kamida nechta olsak, albatta har turdan bittadan bo'ladi?",o:["7","3","4","9"],k:0,s:"Eng omadsiz: ikki turning hammasi (6 ta), 7-si uchinchi tur."},
{t:"1 dan 10 gacha sonlardan kamida nechtasini tanlasak, albatta yig'indisi 11 bo'lgan ikki son bo'ladi?",o:["6","5","7","10"],k:0,s:"5 ta juft (1+10, 2+9, …) — 5 quti; 6-son juftni to'ldiradi."},
{t:"10 ta qalam 3 xil rangda. Kamida nechta qalam bir xil rangda ekani aniq?",o:["4","3","5","10"],k:0,s:"10 = 3 · 3 + 1 → kamida 4 ta."},
{t:"Qutida 6 qizil, 6 ko'k, 6 yashil shar. Albatta 3 ta bir xil rangli uchun kamida nechta?",o:["7","9","3","6"],k:0,s:"Har rangdan 2 tadan = 6, 7-si albatta uchinchi."},
{t:"Qutida 8 qizil va 3 ko'k shar. Ikkala rangdan ham bo'lishi uchun kamida nechta?",o:["9","4","3","11"],k:0,s:"8 qizilning hammasi + 1 = 9."},
{t:"Tortmada 4 juft qora va 4 juft jigarrang paypoq (alohida). Bir xil rangli juft uchun kamida nechta paypoq?",o:["3","2","9","5"],k:0,s:"Ranglar 2 ta: 2 + 1 = 3."},
{t:"Shu tortmadan albatta bir juft qora paypoq uchun kamida nechta paypoq?",o:["10","3","9","16"],k:0,s:"8 jigarrang + 2 qora = 10."},
{t:"Ali 1 dan 9 gacha raqamlardan 10 ta yozdi. Qaysi gap albatta to'g'ri?",o:["Ikkita bir xil raqam bor","Hammasi har xil","9 raqami bor","Hammasi juft"],k:0,s:"Raqamlar 9 xil, yozilgani 10 ta — takror albatta bor."},
{t:"40 o'quvchi 3 ta to'garakka bo'lindi. Eng katta to'garakda kamida nechta o'quvchi bor?",o:["14","13","15","20"],k:0,s:"40 = 3 · 13 + 1 → kamida 14."},
{t:"Tanga 9 marta tashlandi. Bir tomoni kamida necha marta tushgani aniq?",o:["5","4","9","6"],k:0,s:"Tomonlar 2 ta: 9 = 2 · 4 + 1 → kamida 5."},
{t:"Qutida 7 qizil, 5 ko'k, 2 oq shar. 2 ta bir xil rangli shar albatta bo'lishi uchun kamida nechta?",o:["4","3","8","14"],k:0,s:"Ranglar 3 ta: 3 + 1 = 4."}
];
function PRACT_STAGE(){j2Lines([['n + 1 → kamida 2',C.blue,24],['eng omadsiz holat + 1',null,16]])}
var PREP_DATA={teach:["Dirixle prinsipi: n + 1 narsa, n quti.","«Albatta» savoli: eng omadsiz holat + 1.","Uch tur: bir xil rang, har xil rang, aniq rang.","Ko'p narsa: teng taqsimlash va qoldiq; qutini o'zi topish."],
 mist:["«Albatta» va «mumkin»ni chalkashtiradi (eng omadli holatni oladi).","«2 ta qizil» va «2 ta bir xil» savollarini bir xil yechadi.","Rang kam bo'lganini hisobga olmaydi (2 qizil + 3 + 3 + 3).","Qoldiqni unutadi (40 : 3 → 13)."],
 need:["Rangli qopqoqlar va shaffof bo'lmagan xalta.","Stullar (kabutar-uya o'yini uchun)."],
 board:["<span class='w2'>5 kabutar, 4 uya → kamida 2</span>.","Eng omadsiz: <span class='w2'>2 + 3 + 3 + 3 = 11 → 12</span>.","Har xil: <span class='w2'>6 + 1 = 7</span>.","Aniq rang: <span class='w2'>10 + 2 = 12</span>.","<span class='w2'>25 = 12 · 2 + 1 → 3</span>.","Juftlar: <span class='w2'>(1,10) (2,9) … → 6 ta son</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
