var CODE='4B2',TITLE='4-sinf · Noma’lum komponentni topish';
function a42b(total,parts,title,note){bqBar(total,parts,{title:title,y:66,tq:String(total).indexOf('x')>=0});if(note)bqMsg(note)}
var STEPS=[
{h:"Noma'lum qo'shiluvchi",sum:"x + 2 450 = 7 000 → x = 7 000 − 2 450 = 4 550.",a:"m01",
 start:function(){a42b('7 000',[{v:'x',q:1,w:4550},{v:'2 450',w:2450,col:C.a}],'x + 2 450 = 7 000','Butun — 7 000, bir bo‘lagi — 2 450')},fin:function(){a42b('7 000',[{v:'4 550',w:4550,col:'#bfe6d4'},{v:'2 450',w:2450,col:C.a}],'x = 4 550','Tekshirish: 4 550 + 2 450 = 7 000 ✓')},
 html:"<p>Chizma modelga qarang: butun — 7 000, bitta bo'lagi — 2 450. Noma'lum bo'lak qanday topiladi?</p>",
 btns:a4ch(["7 000 − 2 450","7 000 + 2 450","2 450 − 7 000"],0,function(){a42b('7 000',[{v:'4 550',w:4550,col:'#bfe6d4'},{v:'2 450',w:2450,col:C.a}],'x = 4 550','Bo‘lak = butun − ma‘lum bo‘lak: 7 000 − 2 450 = <b>4 550</b>')},function(i){bqMsg(i===1?'Qo‘shsak — butundan ham katta son chiqadi!':'Kichikdan kattani ayirib bo‘lmaydi')}),
 after:"<p>Qoida: <b>noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi</b>. Chizmada: bo'lak = butun − boshqa bo'lak. Javobni doim <b>qo'yib tekshiring</b>.</p>",
 q:{t:"36 850 + x = 50 000. x = ?",opts:["13 150","86 850","14 150","13 250"],ok:0,why:"50 000 − 36 850 = 13 150.",hint:"Yig'indidan ma'lum qo'shiluvchini ayiring.",full:"x = 50 000 − 36 850 = 13 150. Tekshirish: 36 850 + 13 150 = 50 000 ✓. «86 850» — qo'shib yuborish; «14 150» — nollardan qarzda xato."},
 tn:"Singapur chizma modeli: har tenglama uchun avval chizma, keyin amal."},
{h:"Noma'lum kamayuvchi",sum:"x − 1 875 = 3 125 → x = 3 125 + 1 875 = 5 000.",a:"m02",
 start:function(){a42b('x',[{v:'3 125',w:3125,col:'#bfe6d4',lab:'qoldi'},{v:'1 875',w:1875,col:C.a,lab:'olindi'}],'x − 1 875 = 3 125','Kamayuvchi — butun: undan olindi va qoldi')},fin:function(){a42b('5 000',[{v:'3 125',w:3125,col:'#bfe6d4',lab:'qoldi'},{v:'1 875',w:1875,col:C.a,lab:'olindi'}],'x = 5 000','Tekshirish: 5 000 − 1 875 = 3 125 ✓')},
 html:"<p>Bir sondan 1 875 ayirildi, 3 125 qoldi. Dastlabki son (kamayuvchi) qanday topiladi?</p>",
 btns:a4ch(["3 125 + 1 875","3 125 − 1 875","1 875 − 3 125"],0,function(){a42b('5 000',[{v:'3 125',w:3125,col:'#bfe6d4',lab:'qoldi'},{v:'1 875',w:1875,col:C.a,lab:'olindi'}],'x = 5 000','Butun = qoldi + olindi: <b>5 000</b>')},function(i){bqMsg(i===1?'Kamayuvchi — eng katta son, u ayirmadan katta bo‘lishi kerak!':'Kichikdan kattani ayirib bo‘lmaydi')}),
 after:"<p>Qoida: <b>kamayuvchi = ayirma + ayriluvchi</b>. Mantiq: kamayuvchi — butun; ayriluvchi va ayirma — uning ikki bo'lagi.</p>",
 q:{t:"x − 48 600 = 151 400. x = ?",opts:["200 000","102 800","190 000","200 100"],ok:0,why:"151 400 + 48 600 = 200 000.",hint:"Kamayuvchi = ayirma + ayriluvchi.",full:"151 400 + 48 600 = 200 000. Tekshirish: 200 000 − 48 600 = 151 400 ✓. «102 800» — ayirib yuborish."},
 tn:"Hayotiy: «Hamyondan 1 875 so'm sarfladim, 3 125 qoldi — avval qancha bor edi?»"},
{h:"Tuzoq: noma'lum ayriluvchi",sum:"9 000 − x = 3 760 → x = 9 000 − 3 760 = 5 240 (qo'shilmaydi!).",a:"m03",
 start:function(){a42b('9 000',[{v:'3 760',w:3760,col:'#bfe6d4',lab:'qoldi'},{v:'x',q:1,w:5240,lab:'olindi'}],'9 000 − x = 3 760','9 000 dan nimadir olindi, 3 760 qoldi')},fin:function(){a42b('9 000',[{v:'3 760',w:3760,col:'#bfe6d4',lab:'qoldi'},{v:'5 240',w:5240,col:C.a,lab:'olindi'}],'x = 5 240','Tekshirish: 9 000 − 5 240 = 3 760 ✓')},
 html:"<p>9 000 − x = 3 760. Ko'p bolalar bu yerda xato qiladi. x qanday topiladi?</p>",
 btns:a4ch(["9 000 + 3 760","9 000 − 3 760","3 760 − 9 000"],1,function(){a42b('9 000',[{v:'3 760',w:3760,col:'#bfe6d4',lab:'qoldi'},{v:'5 240',w:5240,col:C.a,lab:'olindi'}],'x = 5 240','Olingan bo‘lak = butun − qolgan: <b>5 240</b>')},function(i){bqMsg(i===0?'12 760 ni 9 000 dan ayirib bo‘lmaydi! Ayriluvchi kamayuvchidan katta bo‘lolmaydi':'Kichikdan kattani ayirib bo‘lmaydi')}),g3:1,
 after:"<p>Qoida: <b>ayriluvchi = kamayuvchi − ayirma</b>. Esda tuting: noma'lum <b>kamayuvchi</b> — qo'shish bilan, noma'lum <b>ayriluvchi</b> — ayirish bilan topiladi. Chizma chizsangiz, adashmaysiz.</p>",
 q:{t:"70 000 − x = 26 485. x = ?",opts:["43 515","96 485","44 515","43 525"],ok:0,why:"70 000 − 26 485 = 43 515.",hint:"Ayriluvchi = kamayuvchi − ayirma.",full:"x = 70 000 − 26 485 = 43 515. Tekshirish: 70 000 − 43 515 = 26 485 ✓. «96 485» — qo'shish xatosi."},
 tn:"Bank 4B2 eng ko'p xato qilinadigan turi. Uchala tur (qo'shiluvchi, kamayuvchi, ayriluvchi) uchun bitta chizma bilan jadval tuzing."},
{h:"Ko'paytuvchi va bo'luvchi",sum:"x · 8 = 5 600 → x = 700; 4 800 : x = 6 → x = 800.",a:"m04",
 start:function(){a42b('5 600',[{v:'x',q:1},{v:'x',q:1},{v:'x',q:1},{v:'x',q:1},{v:'x',q:1},{v:'x',q:1},{v:'x',q:1},{v:'x',q:1}],'x · 8 = 5 600','8 ta teng bo‘lak')},fin:function(){a42b('5 600',[{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'}],'x = 5 600 : 8 = 700')},
 html:"<p>x · 8 = 5 600. Chizmada 8 ta teng bo'lak. Bitta bo'lak qancha?</p>",
 btns:a4ch(["700","44 800","70","5 592"],0,function(){a42b('5 600',[{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'},{v:'700'}],'x = 5 600 : 8 = 700','Noma‘lum ko‘paytuvchi = ko‘paytma : ma‘lum ko‘paytuvchi')},function(i){bqMsg(i===1?'Ko‘paytirib yubordingiz — bo‘lish kerak edi':i===3?'5 600 − 8 — bu ayirish':'8 · 70 = 560, 5 600 emas')}),g2:1,
 after:"<p>Xuddi shu mantiq: <b>ko'paytuvchi = ko'paytma : boshqa ko'paytuvchi</b>; <b>bo'linuvchi = bo'linma · bo'luvchi</b>; <b>bo'luvchi = bo'linuvchi : bo'linma</b>. Masalan 4 800 : x = 6 → x = 4 800 : 6 = 800.</p>",
 q:{t:"x : 9 = 1 250. x = ?",opts:["11 250","139","1 241","10 250"],ok:0,why:"1 250 · 9 = 11 250.",hint:"Bo'linuvchi = bo'linma · bo'luvchi.",full:"x = 1 250 · 9 = 11 250. Tekshirish: 11 250 : 9 = 1 250 ✓. «139» — bo'lib yuborish (1 250 : 9 ham butun chiqmaydi)."},
 tn:"Amallar oilasi uchburchagi: 5 600 tepada, 8 va 700 pastda — 4 ta tenglik."},
{h:"Tarkibli tenglama — qatlamlarni ochamiz",sum:"(x + 350) − 1 200 = 4 800 → x + 350 = 6 000 → x = 5 650.",a:"m05",
 start:function(){bqExpr(['([x + 350]) − 1 200 = 4 800','qavs ichidagi — butun bir «quti»']);bqMsg('Avval qavs ichini bitta noma‘lum deb qaraymiz')},fin:function(){bqExpr(['(x + 350) − 1 200 = 4 800','x + 350 = 4 800 + 1 200 = 6 000','x = 6 000 − 350 = [5 650]']);bqMsg('Tekshirish: (5 650 + 350) − 1 200 = 4 800 ✓')},
 html:"<p>(x + 350) − 1 200 = 4 800. Qavs ichini bitta «quti» deb qarang: <b>quti − 1 200 = 4 800</b>. Quti nimaga teng?</p>",
 btns:a4ch(["6 000","3 600","5 650"],0,function(){bqExpr(['(x + 350) − 1 200 = 4 800','x + 350 = 4 800 + 1 200 = 6 000','x = 6 000 − 350 = [5 650]']);bqMsg('Quti (kamayuvchi) = 4 800 + 1 200 = <b>6 000</b>. Endi x + 350 = 6 000 → x = <b>5 650</b>')},function(i){bqMsg(i===1?'Quti — kamayuvchi, u qo‘shish bilan topiladi':'5 650 — bu x ning o‘zi. Avval qutini toping')}),g3:1,
 after:"<p>Usul — <b>piyozni tashqaridan po'stlash</b>: oxirgi bajarilgan amaldan boshlab teskari amal qilamiz. Har qatlamda «bu yerda noma'lum qaysi komponent?» deb so'raymiz.</p>",
 q:{t:"(x − 2 500) : 4 = 1 500. x = ?",opts:["8 500","3 500","6 500","875"],ok:0,why:"x − 2 500 = 6 000 → x = 8 500.",hint:"Avval qavs ichi = 1 500 · 4.",full:"Qavs (bo'linuvchi) = 1 500 · 4 = 6 000. x − 2 500 = 6 000 → x = 8 500. Tekshirish: (8 500 − 2 500) : 4 = 1 500 ✓."},
 tn:"Matryoshka yoki piyoz rasmi: tashqi qatlamdan ichkariga."},
{h:"Ikki amalli tenglama",sum:"x · 4 + 600 = 5 000 → x · 4 = 4 400 → x = 1 100.",a:"m06",
 start:function(){a42b('5 000',[{v:'x',q:1,w:1100},{v:'x',q:1,w:1100},{v:'x',q:1,w:1100},{v:'x',q:1,w:1100},{v:'600',w:600,col:C.a}],'x · 4 + 600 = 5 000','4 ta x va yana 600')},fin:function(){a42b('5 000',[{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'600',w:600,col:C.a}],'x = 1 100','(5 000 − 600) : 4 = 1 100')},
 html:"<p>x · 4 + 600 = 5 000. Birinchi qadam qaysi?</p>",
 btns:a4ch(["5 000 − 600","5 000 : 4","5 000 + 600"],0,function(){a42b('5 000',[{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'1 100',w:1100},{v:'600',w:600,col:C.a}],'x = 1 100','Avval 600 ni olib tashlaymiz: 4 400; keyin : 4 = <b>1 100</b>')},function(i){bqMsg(i===1?'Hali 600 ham bor — avval uni ajratish kerak (oxirgi amal — qo‘shish)':'600 qo‘shilgan, olib tashlash kerak')}),g3:1,
 after:"<p>Hisoblash tartibida avval ko'paytirish, keyin qo'shish bajarilgan. Yechishda — <b>teskari tartib</b>: avval qo'shishni ochamiz (−600), keyin ko'paytirishni (: 4).</p>",
 q:{t:"12 000 − x · 5 = 2 000. x = ?",opts:["2 000","2 800","10 000","50 000"],ok:0,why:"x · 5 = 10 000 → x = 2 000.",hint:"x · 5 — ayriluvchi.",full:"Ayriluvchi x · 5 = 12 000 − 2 000 = 10 000, demak x = 10 000 : 5 = 2 000. Tekshirish: 12 000 − 10 000 = 2 000 ✓. «2 800» — (12 000 + 2 000) : 5."},
 tn:"Bank 4B2 qiyin turi. Doskada: «oxirgi amal qaysi?» — rangli bo'r bilan belgilash."},
{h:"Masaladan tenglama tuzish",sum:"Son + 1 250, natija · 3 = 9 000 → (x + 1 250) · 3 = 9 000 → x = 1 750.",a:"m07",
 start:function(){bqExpr(['x → [+ 1 250] → [· 3] → 9 000','oxiridan boshlab qaytamiz']);bqMsg('O‘ylangan son ustida 2 ta amal bajarildi')},fin:function(){bqExpr(['9 000 → [: 3] → 3 000 → [− 1 250] → 1 750','(1 750 + 1 250) · 3 = 9 000 ✓']);bqMsg('O‘ylangan son <b>1 750</b>')},
 html:"<p>«Bir son o'yladim, unga 1 250 qo'shdim, natijani 3 ga ko'paytirdim — 9 000 chiqdi». Qaysi son o'ylangan?</p>",
 btns:a4ch(["1 750","25 750","1 750 dan ko'p","4 250"],0,function(){bqExpr(['9 000 → [: 3] → 3 000 → [− 1 250] → 1 750','(1 750 + 1 250) · 3 = 9 000 ✓']);bqMsg('Teskari yo‘l: 9 000 : 3 = 3 000, 3 000 − 1 250 = <b>1 750</b>')},function(i){bqMsg(i===1?'Amallarni teskarisiga aylantiring: · 3 → : 3, + 1 250 → − 1 250':i===3?'Tartib muhim: avval : 3, keyin − 1 250':'Aniq sonni toping')}),g2:1,
 after:"<p>Ikki usul: 1) <b>tenglama</b>: (x + 1 250) · 3 = 9 000; 2) <b>oxiridan</b> teskari amallar bilan qaytish. Ikkalasi bir xil javob beradi — bu tekshirish ham.</p>",
 q:{t:"Son 4 ga ko'paytirilib, natijadan 3 000 ayirildi va 5 000 chiqdi. Son:",opts:["2 000","500","8 000","2 750"],ok:0,why:"5 000 + 3 000 = 8 000; 8 000 : 4 = 2 000.",hint:"Oxiridan: + 3 000, keyin : 4.",full:"x · 4 − 3 000 = 5 000 → x · 4 = 8 000 → x = 2 000. «500» — 2 000 : 4 qilish; «8 000» — bitta qadam qolib ketdi."},
 tn:"«Son o'ylash» o'yini: bolalar bir-biriga topishmoq beradi."},
{h:"Tekshirish — xatoni topish",sum:"Javobni tenglamaga qo'yamiz: tenglik bajarilsa — to'g'ri.",a:"m08",
 start:function(){bqExpr(['15 000 − x = 6 500','Vali: x = 21 500','Sardor: x = 8 500']);bqMsg('Kim haq? Qo‘yib tekshiring')},fin:function(){bqExpr(['15 000 − 8 500 = 6 500 ✓','15 000 − 21 500 — bo‘lmaydi ✗']);bqMsg('Sardor haq: x = <b>8 500</b>')},
 html:"<p>15 000 − x = 6 500 tenglamasini Vali «21 500», Sardor «8 500» deb yechdi. Kim haq?</p>",
 btns:a4ch(["Vali","Sardor","ikkalasi ham"],1,function(){bqExpr(['15 000 − 8 500 = 6 500 ✓','15 000 − 21 500 — bo‘lmaydi ✗']);bqMsg('8 500 ni qo‘ysak — 6 500 chiqadi. Vali qo‘shib yuborgan (ayriluvchi tuzog‘i)')},function(i){bqMsg(i===0?'15 000 dan 21 500 ni ayirib bo‘lmaydi — tekshiring!':'Faqat bitta javob tenglikni to‘g‘ri qiladi')}),g3:1,
 after:"<p>Tenglamaning ildizi — tenglikni <b>to'g'ri</b> qiladigan son. Shuning uchun tekshirish oddiy: javobni x o'rniga qo'yib hisoblang. Bu odat imtihonda ballarni saqlab qoladi.</p>",
 q:{t:"Qaysi son 3 · x − 1 500 = 4 500 tenglamaning ildizi?",opts:["2 000","1 000","6 000","3 000"],ok:0,why:"3 · 2 000 − 1 500 = 4 500.",hint:"Har bir variantni qo'yib ko'ring.",full:"3 · 2 000 = 6 000; 6 000 − 1 500 = 4 500 ✓. 1 000 → 1 500; 3 000 → 7 500; 6 000 → 16 500."},
 tn:"Javoblar varaqasida «tekshirish» ustuni bo'lsin."},
{h:"Bilasizmi?",sum:"Rivoyatga ko'ra Diofant qabr toshidagi topishmoq — tenglama.",a:"m09",
 start:function(){bqExpr(['Diofant topishmog‘i','x = ?']);bqMsg('Qadimgi Yunoniston, III asr')},fin:function(){bqExpr(['Diofant topishmog‘i','x = 84']);bqMsg('Javob: 84 yil')},
 html:"<p>📜 Qadimgi yunon olimi <b>Diofant</b> «arifmetikaning otasi» deb ataladi. Rivoyatga ko'ra, uning qabr toshiga topishmoq yozilgan: hayotining oltidan biri — bolalik, o'n ikkidan biri — yigitlik, yettidan biri o'tib uylangan… Bu aslida tenglama, uning javobi — <b>84 yil</b>.</p><p>🌟 Tenglamalarni tizimli yechish usullarini esa bizning bobokalonimiz <b>al-Xorazmiy</b> «Al-jabr» kitobida bayon qilgan.</p>",
 tn:"Kuchli o'quvchilar uchun: Diofant topishmog'ini to'liq o'qib berish (5-6-sinfda yechiladi)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a42b('7 000',[{v:'4 550',w:4550,col:'#bfe6d4'},{v:'2 450',w:2450,col:C.a}],'x + 2 450 = 7 000')},fin:function(){a42b('7 000',[{v:'4 550',w:4550,col:'#bfe6d4'},{v:'2 450',w:2450,col:C.a}],'x + 2 450 = 7 000')},
 html:"<div class='memo'><ul><li>Qo'shiluvchi = yig'indi − boshqa qo'shiluvchi.</li><li>Kamayuvchi = ayirma + ayriluvchi.</li><li>Ayriluvchi = kamayuvchi − ayirma (qo'shilmaydi!).</li><li>Ko'paytuvchi = ko'paytma : boshqasi; bo'linuvchi = bo'linma · bo'luvchi; bo'luvchi = bo'linuvchi : bo'linma.</li><li>Tarkibli tenglama: oxirgi amaldan boshlab teskari amallar.</li><li>Doim qo'yib tekshiring.</li></ul></div>",
 tn:"Keyingi dars — qulay usulda hisoblash."}
];
var PROBS=[
{t:"x + 2 450 = 7 000. x = ?",o:["4 550","9 450","5 450","4 650"],k:0,s:"7 000 − 2 450."},
{t:"36 850 + x = 50 000. x = ?",o:["13 150","86 850","14 150","13 250"],k:0,s:"50 000 − 36 850."},
{t:"x − 1 875 = 3 125. x = ?",o:["5 000","1 250","4 000","5 100"],k:0,s:"3 125 + 1 875."},
{t:"x − 48 600 = 151 400. x = ?",o:["200 000","102 800","190 000","200 100"],k:0,s:"151 400 + 48 600."},
{t:"9 000 − x = 3 760. x = ?",o:["5 240","12 760","6 240","5 340"],k:0,s:"9 000 − 3 760."},
{t:"70 000 − x = 26 485. x = ?",o:["43 515","96 485","44 515","43 525"],k:0,s:"70 000 − 26 485."},
{t:"x · 8 = 5 600. x = ?",o:["700","44 800","70","5 592"],k:0,s:"5 600 : 8."},
{t:"4 800 : x = 6. x = ?",o:["800","28 800","4 794","80"],k:0,s:"4 800 : 6."},
{t:"x : 9 = 1 250. x = ?",o:["11 250","10 250","1 259","11 350"],k:0,s:"1 250 · 9."},
{t:"(x + 350) − 1 200 = 4 800. x = ?",o:["5 650","6 000","3 250","6 350"],k:0,s:"x + 350 = 6 000."},
{t:"(x − 2 500) : 4 = 1 500. x = ?",o:["8 500","3 500","6 500","875"],k:0,s:"x − 2 500 = 6 000."},
{t:"x · 4 + 600 = 5 000. x = ?",o:["1 100","1 400","4 400","1 250"],k:0,s:"(5 000 − 600) : 4."},
{t:"12 000 − x · 5 = 2 000. x = ?",o:["2 000","2 800","10 000","1 600"],k:0,s:"x · 5 = 10 000."},
{t:"Son + 1 250, natija · 3 = 9 000. Son:",o:["1 750","25 750","4 250","3 000"],k:0,s:"9 000 : 3 − 1 250."},
{t:"Son · 4, natija − 3 000 = 5 000. Son:",o:["2 000","500","8 000","1 250"],k:0,s:"(5 000 + 3 000) : 4."},
{t:"Qaysi son 3 · x − 1 500 = 4 500 ning ildizi?",o:["2 000","1 000","3 000","6 000"],k:0,s:"6 000 − 1 500 = 4 500."},
{t:"Omborda bir necha qop un bor edi. 2 450 qop olib ketildi, 1 300 qop keltirildi, 5 000 qop bo'ldi. Avval nechta qop bo'lgan?",o:["6 150","3 850","8 750","6 250"],k:0,s:"x − 2 450 + 1 300 = 5 000 → x = 6 150."},
{t:"25 000 − (x + 4 000) = 9 000. x = ?",o:["12 000","20 000","16 000","30 000"],k:0,s:"x + 4 000 = 16 000."},
{t:"(x : 3) + 1 200 = 4 000. x = ?",o:["8 400","15 600","2 800","933"],k:0,s:"x : 3 = 2 800 → x = 8 400."},
{t:"Qaysi tenglamaning ildizi eng katta? A) x − 500 = 2 000; B) 5 000 − x = 2 000; C) x · 2 = 4 000",o:["B (x = 3 000)","A (x = 2 500)","C (x = 2 000)","hammasida teng"],k:0,s:"A = 2 500, B = 3 000, C = 2 000."}
];
function PRACT_STAGE(){a42b('9 000',[{v:'3 760',w:3760,col:'#bfe6d4',lab:'qoldi'},{v:'5 240',w:5240,col:C.a,lab:'olindi'}],'9 000 − x = 3 760')}
var PREP_DATA={teach:["Qo'shish/ayirish komponentlari: noma'lum qo'shiluvchi, kamayuvchi, ayriluvchi.","Ko'paytirish/bo'lish komponentlari.","Tarkibli tenglamalar (teskari amallar), masaladan tenglama, tekshirish."],mist:["Noma'lum ayriluvchini qo'shish bilan topadi.","Noma'lum kamayuvchini ayirish bilan topadi.","Tarkibli tenglamada amallarni noto'g'ri tartibda ochadi.","Tekshirmaydi."],need:["Chizma model kartochkalari, amallar uchburchagi."],board:["<span class='w2'>x + 2 450 = 7 000</span> → 4 550.","<span class='w2'>x − 1 875 = 3 125</span> → 5 000.","<span class='w2'>9 000 − x = 3 760</span> → 5 240.","<span class='w2'>(x + 350) − 1 200 = 4 800</span> → 5 650."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
