// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F2',TITLE='4-sinf · Sonning kasri va kasriga ko‘ra son';
// konfetlar: n ta, b guruh, hl — ajratilgan guruhlar soni (yoki massiv)
function f2cand(n,b,hl,title){clear();var g=S.g;f4t(180,18,title||'',12,'#3a4a5a');
 if(!b){for(var i=0;i<n;i++)E('circle',{cx:30+i*(300/(n-1)),cy:80,r:10,fill:['#e05a7a','#f0a040','#5aa9e6','#7bc47f'][i%4],stroke:'#fff','stroke-width':2},g);return}
 var per=n/b,bw=330/b,hs=typeof hl==='number'?hl:0;S.boxes=[];
 for(var j=0;j<b;j++){var x=15+j*bw,on=Array.isArray(hl)?hl.indexOf(j)>=0:j<hs;var r=E('rect',{x:x+3,y:40,width:bw-6,height:86,rx:10,fill:on?'#ffe2b0':'#f7f3ea',stroke:on?C.a2:'#d9cdb6','stroke-width':on?2.5:1.5},g);r._j=j;r._on=on;S.boxes.push(r);
  for(var k=0;k<per;k++){var cols=Math.min(per,2),cx=x+bw/2+((k%cols)-(cols-1)/2)*24,cy=60+Math.floor(k/cols)*24;E('circle',{cx:cx,cy:cy,r:9,fill:['#e05a7a','#f0a040','#5aa9e6','#7bc47f'][k%4],stroke:'#fff','stroke-width':2,'pointer-events':'none'},g)}
  T(g,x+bw/2,146,on?per+' ta':'1/'+b,{'font-size':13,'font-weight':800,fill:on?C.a2:'#8a7a60','pointer-events':'none'})}}
var F2P1=[function(){f2cand(12,0,0,'12 ta konfet. 1/4 qismi nechta?');f4c(['1/4 — butunni <b>4 ta teng</b> bo‘lakka bo‘lib, bittasini olish'])},
 function(){f2cand(12,4,0,'4 ta teng guruhga bo‘lamiz');f4c(['12 : 4 = 3 — har guruhda 3 tadan'])},
 function(){f2cand(12,4,1,'Bitta guruh — 1/4 qismi');f4c(['12 ning 1/4 qismi = 12 : 4 = <b>3</b>'])}];
// tasma model
function f2bar(n,b,a,total,showEach,showA,unknown){clear();var x=30,w=300,y=62,h=40;f4bar(x,y,w,h,b,showA?a:0,C.a,showEach?Array(b).fill(String(n/b)):null);
 f4Br(x,x+w,y-6,unknown?'?':String(n),true,'#33475b');if(showA&&a)f4Br(x,x+w*a/b,y+h+4,showEach?String(n/b*a):'?',false,C.a2)}
var F2P3=[function(){f2bar(20,5,2,20,false,false);f4c(['20 ning 2/5 qismi — tasma chizamiz, uzunligi 20'])},
 function(){f2bar(20,5,2,20,true,false);f4c(['Maxraj 5 — 5 ta teng bo‘lak: 20 : 5 = <b>4</b>'])},
 function(){f2bar(20,5,2,20,true,true);f4c(['Surat 2 — 2 ta bo‘lak: 4 · 2 = <b>8</b>','Qoida: <b>son : maxraj · surat</b>'])}];
// kasriga ko'ra son
function f2inv(b,a,val,st){clear();var x=30,w=300,y=62,h=40,lab=[];for(var i=0;i<b;i++)lab.push(st>=1?(i<a||st>=2?String(val/a):''):(i<a&&a===1?String(val):''));
 f4bar(x,y,w,h,b,a,C.b,lab);f4Br(x,x+w*a/b,y+h+4,String(val),false,C.blue);f4Br(x,x+w,y-6,st>=2?String(val/a*b):'?',true,'#33475b')}
var F2P4=[function(){f2inv(3,1,7,0);f4c(['Sonning 1/3 qismi 7 ga teng. Son nechaga teng?'])},
 function(){f2inv(3,1,7,2);f4c(['3 ta bo‘lakning har biri 7: 7 · 3 = <b>21</b>','Tekshirish: 21 : 3 = 7 ✓'])}];
var F2P5=[function(){f2inv(5,3,12,0);f4c(['Sonning 3/5 qismi 12. 3 ta bo‘lak birga 12'])},
 function(){f2inv(5,3,12,1);f4c(['Bitta bo‘lak (1/5): 12 : 3 = <b>4</b>'])},
 function(){f2inv(5,3,12,2);f4c(['Butun — 5 ta bo‘lak: 4 · 5 = <b>20</b>','Qoida: <b>qism : surat · maxraj</b>'])}];
// qolgan qism
function f2rest(st){clear();var x=30,w=300,y=62,h=40,lab=[];for(var i=0;i<7;i++)lab.push(st>=2?'7':'');
 f4barC(x,y,w,h,[C.grey,C.grey,C.b,C.b,C.b,C.b,C.b],lab);f4t(x+w*1/7,y-10,'o‘qildi 2/7',11,'#5b6b7b');
 f4Br(x+w*2/7,x+w,y+h+4,st>=1?'35 bet = 5/7':'35 bet',false,C.blue);f4Br(x,x+w,y-22,st>=3?'49 bet':'?',true,'#33475b')}
var F2P7=[function(){f2rest(0);f4c(['Kitobning 2/7 qismi o‘qildi, 35 bet qoldi. Kitob necha bet?'])},
 function(){f2rest(1);f4c(['Qolgan qism: 7/7 − 2/7 = <b>5/7</b> → 35 bet shu 5/7 ga to‘g‘ri keladi'])},
 function(){f2rest(2);f4c(['1/7 qism: 35 : 5 = <b>7</b> bet'])},
 function(){f2rest(3);f4c(['Kitob: 7 · 7 = <b>49</b> bet','Xato: 35 : 2 · 7 — 35 ni «o‘qilgan» deb olish'])}];
// soat
function f2clock(k){clear();var g=S.g,cx=110,cy=88,r=66;E('circle',{cx:cx,cy:cy,r:r+5,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(k)f4sec(g,cx,cy,r,-Math.PI/2,-Math.PI/2+2*Math.PI*k/4,'#ffd9a0');
 for(var i=0;i<12;i++){var a=i*Math.PI/6-Math.PI/2;E('line',{x1:cx+r*.86*Math.cos(a),y1:cy+r*.86*Math.sin(a),x2:cx+r*Math.cos(a),y2:cy+r*Math.sin(a),stroke:'#33475b','stroke-width':i%3?1.5:3},g);if(i%3===0)T(g,cx+r*.68*Math.cos(a),cy+r*.68*Math.sin(a)+5,String(i||12),{'font-size':13,'font-weight':800})}
 var a2=-Math.PI/2+2*Math.PI*k/4;E('line',{x1:cx,y1:cy,x2:cx+r*.55*Math.cos(a2),y2:cy+r*.55*Math.sin(a2),stroke:C.bad,'stroke-width':3},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#33475b'},g);
 var L=['0 minut','1/4 soat = 15 minut','1/2 soat = 30 minut','3/4 soat = 45 minut','1 soat = 60 minut'];[1,2,3].forEach(function(j){f4t(270,44+(j-1)*42,L[j],12,j<=k?C.a2:'#b8b0a0')})}
var F2P9=[function(){f2clock(1);f4c(['1 soat = 60 minut. 60 : 4 = 15 → <b>chorak soat = 15 minut</b>'])},function(){f2clock(2);f4c(['60 : 2 = 30 → yarim soat = 30 minut'])},function(){f2clock(3);f4c(['60 : 4 · 3 = 45 → 3/4 soat = 45 minut'])}];
function PRACT_STAGE(){f2bar(20,5,2,20,true,true);f4c(['Sonning kasri: <b>son : maxraj · surat</b>','Kasriga ko‘ra son: <b>qism : surat · maxraj</b>'])}
var STEPS=[
{h:"Sonning 1/4 qismi",sum:"12 ning 1/4 qismi: 12 ni 4 ta teng guruhga bo'lamiz — bitta guruhda 3 ta. 12 : 4 = 3.",a:"m01",
 start:function(){startPh(F2P1)},fin:function(){S.ph=2;F2P1[2]()},
 html:"<p>Onam 12 ta konfetning <b>1/4 qismini</b> ukamga berdi. Ukam nechta konfet oldi? Bosib ko'ring:</p>",btns:[phaser(F2P1)],
 after:"<p>1/4 — butunni <b>4 ta teng</b> bo'lakka bo'lib, bittasini olish. Konfetlarda «butun» — 12 ta, demak 12 ni 4 ga bo'lamiz: <b>12 : 4 = 3</b>.</p><p>Sonning 1/2, 1/3, 1/5 … qismini topish uchun sonni <b>maxrajga bo'lamiz</b>.</p>",
 q:{t:"15 ning 1/5 qismi nechaga teng?",opts:["3","5","10","75"],ok:0,why:"15 : 5 = 3.",hint:"15 ta narsani 5 ta teng guruhga bo'lsangiz, bitta guruhda nechta bo'ladi?",full:"1/5 — 5 ta teng bo'lakdan bittasi: 15 : 5 = 3. «75» — bo'lish o'rniga ko'paytirish (15 · 5), «10» — qolgan qism (15 − 5)."},
 tn:"Sinfda 12 ta tayoqcha yoki qopqoqni 4 bolaga teng ulashtiring. «Har biriga butunning qanday qismi tegdi?» — 1/4. Singapur dasturida avval ulashish, keyin chizma model."},
{h:"Sonning 3/4 qismi",sum:"12 ning 3/4 qismi: bitta guruh 3 ta, uchta guruh 3 · 3 = 9.",a:"m02",
 start:function(){f2cand(12,4,[],'Guruhlarni bosing: kerak 3/4 qismi');f4c(['Kerak: 4 ta guruhdan <b>3 tasi</b>'])},fin:function(){f2cand(12,4,3,'12 ning 3/4 qismi = 9');f4c(['12 : 4 = 3; 3 · 3 = <b>9</b>'])},
 html:"<p>Endi 12 ta konfetning <b>3/4 qismini</b> oling. Rasmda guruhlarni bosing — nechta guruh kerak?</p>",
 act:function(c,done){var h=c.querySelector('.hint'),n=0;h.textContent='Guruhlarni bosing.';S.boxes.forEach(function(r){r.style.cursor='pointer';r.addEventListener('click',function(){if(r._on||n>=3)return;r._on=true;n++;r.setAttribute('fill','#ffe2b0');r.setAttribute('stroke',C.a2);f4c(['Olindi: '+n+' ta guruh = '+(n*3)+' ta konfet']);if(n===3){h.textContent='';f4c(['3 ta guruh: 3 · 3 = <b>9</b> ta konfet','12 ning 3/4 qismi = 12 : 4 · 3 = 9']);done()}})})},
 after:"<p>Maxraj (4) — <b>nechta</b> teng guruhga bo'lamiz: 12 : 4 = 3. Surat (3) — <b>nechta</b> guruhni olamiz: 3 · 3 = 9.</p><p><b>Qoida:</b> sonning kasrini topish uchun sonni <b>maxrajga bo'lib, suratga ko'paytiramiz</b>.</p>",
 q:{t:"20 ning 3/4 qismi nechaga teng?",opts:["5","12","15","60"],ok:2,why:"20 : 4 = 5; 5 · 3 = 15.",hint:"Avval 1/4 qismini toping (20 : 4), keyin nechta shunday bo'lak kerak?",full:"20 : 4 = 5 — bu 1/4 qismi. 3/4 — uchta shunday bo'lak: 5 · 3 = 15. «5» — faqat 1/4 qism, «60» — 20 · 3 (maxrajga bo'lish unutilgan)."},
 tn:"Doskada 12 ta doiracha chizib, 4 ta guruhga o'rab chiqing. «3/4» ni bolalar o'zi bo'yasin. Har safar: «maxraj — nechtaga bo'lamiz, surat — nechtasini olamiz»."},
{h:"Chizma model: 2/5 qism",sum:"20 ning 2/5 qismi: 20 : 5 = 4, 4 · 2 = 8. Qoida: son : maxraj · surat.",a:"m03",
 start:function(){startPh(F2P3)},fin:function(){S.ph=2;F2P3[2]()},
 html:"<p>Narsalar ko'p bo'lsa, ularni chizish qiyin. Singapur o'quvchilari <b>tasma (chizma model)</b> chizishadi. 20 ning 2/5 qismini topamiz:</p>",btns:[phaser(F2P3)],
 after:"<p>Tasma — butun son (20). Maxraj 5 — tasmani 5 ta teng bo'lakka bo'lamiz, har biri 4. Surat 2 — ikkita bo'lak: 8.</p><p>Bitta qoida hamma joyda ishlaydi: <b>son : maxraj · surat</b>.</p>",
 q:{t:"42 ning 2/7 qismi nechaga teng?",opts:["6","12","147","30"],ok:1,why:"42 : 7 = 6; 6 · 2 = 12.",hint:"Tasmani 7 ga bo'ling — bitta bo'lak nechaga teng?",full:"42 : 7 = 6 (bitta bo'lak), 6 · 2 = 12. «6» — faqat 1/7 qism, «30» — qolgan 5/7 qism, «147» — 42 : 2 · 7 (surat bilan maxraj almashtirilgan)."},
 tn:"Chizma model (bar model) — Singapur matematikasining asosiy vositasi. Bolalar har masalada tasma chizib, ma'lumni ustiga, so'ralganni «?» bilan yozsin."},
{h:"Kasriga ko'ra sonni topish",sum:"Sonning 1/3 qismi 7 bo'lsa, butun son 7 · 3 = 21.",a:"m04",
 start:function(){startPh(F2P4)},fin:function(){S.ph=1;F2P4[1]()},
 html:"<p>Endi teskari masala: <b>qism ma'lum, butun — noma'lum</b>. Sonning 1/3 qismi 7 ga teng. Son nechaga teng?</p>",btns:[phaser(F2P4)],
 after:"<p>1/3 — butunni 3 ta teng bo'lakka bo'lganda bitta bo'lak. Bitta bo'lak 7 bo'lsa, uchtasi: <b>7 · 3 = 21</b>. Tekshiring: 21 ning 1/3 qismi — 21 : 3 = 7 ✓.</p>",
 q:{t:"Sonning 1/4 qismi 9 ga teng. Son nechaga teng?",opts:["36","13","5","27"],ok:0,why:"9 · 4 = 36.",hint:"9 — bu 4 ta teng bo'lakdan bittasi. Butunda nechta bo'lak?",full:"Bitta bo'lak 9, butun — 4 ta bo'lak: 9 · 4 = 36. Tekshirish: 36 : 4 = 9 ✓. «27» — 3 ta bo'lak, «13» — 9 + 4, «5» — 9 − 4."},
 tn:"Ikki turdagi masalani doim chizma bilan farqlang: «son : maxraj · surat» (butun ma'lum) va «qism : surat · maxraj» (qism ma'lum). Bolalar ko'pincha qaysi biri ekanini ajratmaydi."},
{h:"Sonning 3/5 qismi 12 bo'lsa",sum:"3/5 qism = 12 → 1/5 qism = 12 : 3 = 4 → son = 4 · 5 = 20.",a:"m05",
 start:function(){startPh(F2P5)},fin:function(){S.ph=2;F2P5[2]()},
 html:"<p>Sonning <b>3/5 qismi 12</b> ga teng. Endi 12 — bitta emas, <b>uchta</b> bo'lak birgalikda. Bosing:</p>",btns:[phaser(F2P5)],
 after:"<p>Avval bitta bo'lakni topamiz: 12 ni <b>suratga</b> (3 ga) bo'lamiz — 4. Keyin butunni: 4 ni <b>maxrajga</b> (5 ga) ko'paytiramiz — 20.</p><p><b>Qoida:</b> kasriga ko'ra sonni topish uchun <b>qismni suratga bo'lib, maxrajga ko'paytiramiz</b>.</p>",
 q:{t:"Sonning 2/3 qismi 14 ga teng. Son nechaga teng?",opts:["28","21","7","42"],ok:1,why:"14 : 2 = 7; 7 · 3 = 21.",hint:"14 — ikkita bo'lak. Bitta bo'lak nechaga teng?",full:"14 : 2 = 7 (bitta bo'lak, 1/3), 7 · 3 = 21. Tekshirish: 21 : 3 · 2 = 14 ✓. «28» — 14 · 2, «42» — 14 · 3 (bo'lish unutilgan), «7» — faqat bitta bo'lak."},
 tn:"Ikki usulni doskada yonma-yon yozing: «20 ning 3/5 qismi = 12» va «3/5 qismi 12 bo'lgan son = 20». Bir xil chizma, faqat «?» joyi boshqa."},
{h:"Qaysi amal? Masalani tanlang",sum:"Butun ma'lum → son : maxraj · surat. Qism ma'lum → qism : surat · maxraj.",a:"m06",
 start:function(){clear();f4t(180,40,'Ali 18 bet o‘qidi — bu kitobning 2/5 qismi.',12);f4t(180,66,'Kitob necha bet?',14,C.blue);f4bar(40,92,280,34,5,2,C.b,['9','9','','','']);f4Br(40,152,130,'18',false,C.blue);f4msg('Qaysi yo‘l to‘g‘ri? Tugmani tanlang')},
 fin:function(){clear();f4t(180,40,'Ali 18 bet o‘qidi — bu kitobning 2/5 qismi.',12);f4bar(40,72,280,34,5,2,C.b,['9','9','9','9','9']);f4Br(40,320,68,'45 bet',true,'#33475b');f4msg('18 : 2 · 5 = <b>45</b> bet')},
 html:"<p>Masalani o'qing: <b>18 bet — bu qism yoki butun?</b> To'g'ri yo'lni tanlang:</p>",
 btns:f4pick(1,[["18 : 5 · 2","Bu «18 ning 2/5 qismi» bo'lardi. Lekin 18 — butun kitob emas, o'qilgan qism!"],["18 : 2 · 5","To'g'ri: 18 — bu 2/5 qism. 18 : 2 = 9 (1/5), 9 · 5 = 45 bet."],["18 · 2 : 5","Bu ham 18 ni butun deb olish — xato."]],function(){clear();f4t(180,40,'Ali 18 bet o‘qidi — bu kitobning 2/5 qismi.',12);f4bar(40,72,280,34,5,2,C.b,['9','9','9','9','9']);f4Br(40,320,68,'45 bet',true,'#33475b')}),
 after:"<p>Avval savol bering: <b>ma'lum son — butunmi yoki qismmi?</b> «Bu kitobning 2/5 qismi» — demak 18 qism, butun noma'lum. Kitob 18 betdan <b>ko'p</b> bo'lishi kerak — javob 45 mantiqan to'g'ri.</p><p>Tekshirish odati: qismni topsangiz — javob sondan <b>kichik</b>; butunni topsangiz — <b>katta</b>.</p>",
 q:{t:"Bog'dagi daraxtlarning 3/8 qismi olma. Olma daraxtlari 30 ta. Bog'da hammasi bo'lib nechta daraxt bor?",opts:["90","80","10","240"],ok:1,why:"30 — 3/8 qism: 30 : 3 = 10, 10 · 8 = 80.",hint:"30 ta — bu hamma daraxtlarmi yoki ularning qismi?",full:"30 ta olma — bu 3/8 qism. 1/8 qism: 30 : 3 = 10. Hammasi: 10 · 8 = 80 ta. «10» — faqat 1/8, «90» — 30 · 3, «240» — 30 · 8."},
 tn:"Bolalarga «kalit so'z»larni izlatmang — ular aldaydi. Har safar chizma chizib, ma'lum son tasmaning qayeriga tushishini so'rang."},
{h:"Tuzoq: qolgan qism",sum:"2/7 o'qildi, 35 bet qoldi → qolgan qism 5/7 = 35 → 1/7 = 7 → kitob 49 bet.",a:"m07",
 start:function(){startPh(F2P7)},fin:function(){S.ph=3;F2P7[3]()},
 html:"<p>Kitobning <b>2/7 qismi</b> o'qildi, <b>35 bet qoldi</b>. Kitob necha bet? Diqqat: 35 — o'qilgan qism emas!</p>",btns:[phaser(F2P7)],
 after:"<p>Asosiy qadam: <b>35 qaysi kasrga to'g'ri keladi?</b> Butun — 7/7. O'qilgan — 2/7. Qolgan — <b>5/7</b>. Demak 35 bet — bu 5/7: bitta bo'lak 35 : 5 = 7, kitob 7 · 7 = 49 bet.</p><p>Eng ko'p xato: 35 ni 2/7 deb olish (35 : 2 · 7). Chizma chizsangiz — xato qilmaysiz.</p>",
 q:{t:"Yo'lning 3/8 qismi o'tildi, yana 25 km qoldi. Yo'l necha km?",opts:["15 km","40 km","200 km","33 km"],ok:1,why:"Qolgan qism 5/8 = 25 km → 1/8 = 5 km → 40 km.",hint:"25 km — bu o'tilgan qismmi yoki qolgan qism? Qolgan qism qaysi kasr?",full:"8/8 − 3/8 = 5/8 — qolgan qism, u 25 km. 1/8 = 25 : 5 = 5 km, butun yo'l 5 · 8 = 40 km. «15 km» — o'tilgan qism, «200 km» — 25 · 8, «33 km» — 25 + 8."},
 tn:"Saralash testlarida eng ko'p uchraydigan tur. Doskada tasmani ikki rangga bo'yang: o'tilgan — kulrang, qolgan — rangli, va son qaysi rangga tegishli ekanini belgilang."},
{h:"Tuzoq: qaysi biri katta?",sum:"20 ning 3/4 qismi = 15, 24 ning 2/3 qismi = 16. Kasr katta bo'lsa ham, natija kichik bo'lishi mumkin.",a:"m08",
 start:function(){clear();f4t(90,30,'20 ning 3/4 qismi',13,C.a2);f4t(270,30,'24 ning 2/3 qismi',13,C.blue);f4bar(20,50,140,34,4,3,C.a);f4bar(200,50,140,34,3,2,C.b);f4t(90,120,'?',20,C.a2);f4t(270,120,'?',20,C.blue);f4msg('3/4 &gt; 2/3. Demak, birinchisi katta?')},
 fin:function(){clear();f4t(90,30,'20 ning 3/4 qismi',13,C.a2);f4t(270,30,'24 ning 2/3 qismi',13,C.blue);f4bar(20,50,140,34,4,3,C.a,['5','5','5','5']);f4bar(200,50,140,34,3,2,C.b,['8','8','8']);f4t(90,124,'15',22,C.a2);f4t(180,124,'<',22,'#33475b');f4t(270,124,'16',22,C.blue);f4msg('15 &lt; 16 — ikkinchisi katta!')},
 html:"<p>Qaysi biri katta: <b>20 ning 3/4 qismi</b> yoki <b>24 ning 2/3 qismi</b>? Avval o'ylang, keyin tanlang:</p>",
 btns:f4pick(1,[["20 ning 3/4 qismi","Shoshildingiz: 3/4 katta kasr, lekin butunlar har xil! Hisoblab ko'ring: 20 : 4 · 3 = ?"],["24 ning 2/3 qismi","To'g'ri! 20 : 4 · 3 = 15, 24 : 3 · 2 = 16. 16 &gt; 15."],["Teng","Hisoblang: 20 : 4 · 3 va 24 : 3 · 2 — teng chiqmaydi."]],function(){STEPS[cur].fin()}),
 after:"<p>Kasrlarni solishtirish yetmaydi — <b>butunlar har xil</b> bo'lsa, natijani hisoblash kerak. 3/4 &gt; 2/3, lekin 20 ning 3/4 qismi (15) &lt; 24 ning 2/3 qismi (16).</p>",
 q:{t:"Qaysi biri katta: 35 ning 3/5 qismi yoki 24 ning 5/6 qismi?",opts:["35 ning 3/5 qismi","24 ning 5/6 qismi","Teng","24 ning 5/6 qismi, chunki 5/6 katta"],ok:0,why:"35 : 5 · 3 = 21, 24 : 6 · 5 = 20.",hint:"Ikkalasini ham hisoblang: son : maxraj · surat.",full:"35 : 5 · 3 = 21; 24 : 6 · 5 = 20. 21 &gt; 20 — birinchisi katta. 5/6 katta kasr bo'lsa ham, 24 kichik son — natija kichik chiqdi."},
 tn:"Bolalar «katta kasr — katta natija» deb o'ylaydi. Har bir taqqoslashni hisob bilan isbotlatib, daftarga yozdiring."},
{h:"Bilasizmi? Chorak soat",sum:"1 soat = 60 minut. 1/4 soat = 15 minut, 1/2 soat = 30, 3/4 soat = 45. «Chorak» — forscha «chahor» (to'rt) so'zidan.",a:"m09",
 start:function(){startPh(F2P9)},fin:function(){S.ph=2;F2P9[2]()},
 html:"<p>⏰ Biz har kuni kasr ishlatamiz: «chorak soat», «yarim soat». Soatda ko'ring:</p>",btns:[phaser(F2P9,'⏰ Keyingisi')],
 after:"<p><b>«Chorak»</b> so'zi forscha <b>«chahor»</b> — «to'rt» so'zidan kelgan: chorak — to'rtdan bir. Soat 60 minut bo'lgani uchun 1/4 soat = 60 : 4 = 15 minut, 3/4 soat = 45 minut.</p><p>Soatni 60 ga bo'lishni qadimgi <b>Bobil</b> olimlari o'ylab topgan: ular 60 lik sanoq tizimidan foydalanishgan. 60 ni 2, 3, 4, 5, 6, 10, 12 ga qoldiqsiz bo'lish mumkin — kasrlar bilan hisoblash juda qulay.</p>",
 q:{t:"3/4 soat necha minut?",opts:["34 minut","45 minut","15 minut","75 minut"],ok:1,why:"60 : 4 · 3 = 45.",hint:"1 soat = 60 minut. Uning 1/4 qismi nechaga teng?",full:"60 : 4 = 15 minut (chorak), 15 · 3 = 45 minut. «15» — faqat 1/4, «34» — 3 va 4 ni yonma-yon yozish, «75» — 60 + 15."},
 tn:"Kartondan soat yasatib, 1/4, 1/2, 3/4, 1/3, 1/6 soatni bo'yatib, minutini yozdiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>Sonning kasri</b> (butun ma'lum): <b>son : maxraj · surat</b>. 20 ning 2/5 qismi = 20 : 5 · 2 = 8.</li><li><b>Kasriga ko'ra son</b> (qism ma'lum): <b>qism : surat · maxraj</b>. 3/5 qismi 12 bo'lsa, son = 12 : 3 · 5 = 20.</li><li>Avval so'rang: ma'lum son — <b>butunmi yoki qismmi?</b> Chizma chizing.</li><li>«2/7 o'qildi, 35 qoldi» — 35 bu <b>5/7</b>!</li><li>Tekshirish: qism doim butundan kichik.</li><li>Butunlar har xil bo'lsa — kasrni emas, natijani solishtiring.</li><li>1/4 soat = 15 minut, 1/2 soat = 30, 3/4 soat = 45.</li></ul></div>",
 tn:"Keyingi darsni og'zaki savol bilan boshlang: «36 ning 3/4 qismi? 3/4 qismi 36 bo'lgan son?»."}
];
var PROBS=[
{t:"24 ning 1/6 qismi nechaga teng?",o:["4","6","18","144"],k:0,s:"24 : 6 = 4."},
{t:"40 ning 3/8 qismi nechaga teng?",o:["15","5","25","120"],k:0,s:"40 : 8 = 5; 5 · 3 = 15."},
{t:"1/5 qismi 9 ga teng bo'lgan sonni toping.",o:["45","14","4","54"],k:0,s:"9 · 5 = 45."},
{t:"2/3 qismi 18 ga teng bo'lgan sonni toping.",o:["27","12","36","9"],k:0,s:"18 : 2 = 9; 9 · 3 = 27."},
{t:"56 ning 5/7 qismi nechaga teng?",o:["40","8","16","35"],k:0,s:"56 : 7 = 8; 8 · 5 = 40."},
{t:"Sinfda 32 o'quvchi bor, ularning 3/8 qismi qizlar. Sinfda nechta o'g'il bola bor?",o:["20","12","8","24"],k:0,s:"Qizlar: 32 : 8 · 3 = 12. O'g'il bolalar: 32 − 12 = 20."},
{t:"1 metrning 3/4 qismi necha santimetr?",o:["75 sm","25 sm","30 sm","34 sm"],k:0,s:"1 m = 100 sm; 100 : 4 · 3 = 75."},
{t:"1 soatning 3/5 qismi necha minut?",o:["36 minut","12 minut","35 minut","24 minut"],k:0,s:"60 : 5 = 12; 12 · 3 = 36."},
{t:"Kitobning 2/9 qismi 16 bet. Kitob necha bet?",o:["72","18","32","64"],k:0,s:"16 : 2 = 8 (1/9); 8 · 9 = 72."},
{t:"Ip 48 m. Uning 5/12 qismi kesib olindi. Necha metr qoldi?",o:["28 m","20 m","4 m","43 m"],k:0,s:"Kesildi: 48 : 12 · 5 = 20. Qoldi: 48 − 20 = 28 m."},
{t:"Fermer dalasining 3/10 qismiga bug'doy ekdi — bu 15 ga. Butun dala necha gektar?",o:["50 ga","45 ga","5 ga","150 ga"],k:0,s:"15 : 3 = 5 (1/10); 5 · 10 = 50 ga."},
{t:"Qaysi biri katta: 60 ning 2/5 qismi yoki 36 ning 3/4 qismi?",o:["36 ning 3/4 qismi","60 ning 2/5 qismi","Teng","60 ning 2/5 qismi, chunki 60 katta"],k:0,s:"60 : 5 · 2 = 24; 36 : 4 · 3 = 27. 27 > 24."},
{t:"Alida 36 000 so'm bor edi. Pulining 1/3 qismiga kitob, qolgan pulining 1/2 qismiga o'yinchoq oldi. Unda qancha pul qoldi?",o:["12 000 so'm","6 000 so'm","18 000 so'm","24 000 so'm"],k:0,s:"Kitob: 12 000, qoldi 24 000. O'yinchoq: 24 000 ning yarmi — 12 000. Qoldi 12 000."},
{t:"Bola kitobning 1-kuni 2/9 qismini, 2-kuni 4/9 qismini o'qidi. Yana 18 bet qoldi. Kitob necha bet?",o:["54","27","81","162"],k:0,s:"O'qildi 6/9, qoldi 3/9 = 18 → 1/9 = 6 → 54 bet."},
{t:"Sonning 3/4 qismi 30 dan 6 ta kam. Shu sonni toping.",o:["32","40","18","24"],k:0,s:"3/4 qism = 30 − 6 = 24; 24 : 3 · 4 = 32."},
{t:"Bir son 40 ning 3/8 qismiga teng. Shu sonning 2/5 qismini toping.",o:["6","16","10","24"],k:0,s:"40 : 8 · 3 = 15; 15 : 5 · 2 = 6."},
{t:"Sinfdagi qizlar 15 ta — bu sinfning 5/9 qismi. Sinfda nechta o'g'il bola bor?",o:["12","27","9","6"],k:0,s:"1/9 = 15 : 5 = 3; sinf 27; o'g'il bolalar 27 − 15 = 12."},
{t:"Savatdagi olmalarning 2/5 qismi qizil, qolgan 18 tasi yashil. Savatda hammasi nechta olma?",o:["30","45","12","90"],k:0,s:"Yashillar — 3/5 = 18 → 1/5 = 6 → 30 ta."},
{t:"1 kg ning 3/8 qismi necha gramm?",o:["375 g","125 g","38 g","300 g"],k:0,s:"1 000 : 8 = 125; 125 · 3 = 375 g."},
{t:"Hovuzning 4/7 qismi suv bilan to'ldi. Yana 120 litr quyilsa, hovuz to'ladi. Hovuzga necha litr suv sig'adi?",o:["280 l","210 l","160 l","840 l"],k:0,s:"Bo'sh qism 3/7 = 120 → 1/7 = 40 → 280 l."}
];
var PREP_DATA={teach:["Sonning kasrini topish: son : maxraj · surat (konfet guruhlari → chizma model).","Kasriga ko'ra sonni topish: qism : surat · maxraj.","Masala turini ajratish: ma'lum son butunmi yoki qism?","Qolgan qism bo'yicha butunni topish (2/7 o'qildi — 35 qoldi).","Natijalarni solishtirish; soat va o'lchov birliklarida kasr."],
 mist:["Ikki tur masalani almashtiradi: qismni butun deb oladi.","Surat bilan maxrajni almashtiradi: 42 : 2 · 7.","Bo'lishni unutadi: 20 · 3 = 60.","«Qoldi» degan sonni o'qilgan qism deb oladi.","Kattaroq kasr — doim kattaroq natija deb o'ylaydi."],
 need:["Qopqoqlar yoki tayoqchalar (12–20 ta).","Rangli qog'oz tasmalar, karton soat."],
 board:["<span class='w2'>12 ning 3/4 qismi = 12 : 4 · 3 = 9</span>.","Chizma: 20 → 5 bo'lak → 4 · 2 = 8.","<span class='w2'>3/5 qismi 12 → 12 : 3 · 5 = 20</span>.","2/7 o'qildi, 35 qoldi: <span class='w2'>5/7 = 35 → 49</span>.","1/4 soat = 15 min, 3/4 soat = 45 min."]};
