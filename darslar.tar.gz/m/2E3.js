var CODE='2E3',TITLE='2-sinf · Kalendar: kun, hafta, oy, yil';
var E3D=['dushanba','seshanba','chorshanba','payshanba','juma','shanba','yakshanba'];
var E3M=['yanvar','fevral','mart','aprel','may','iyun','iyul','avgust','sentabr','oktabr','noyabr','dekabr'],E3N=[31,28,31,30,31,30,31,31,30,31,30,31];
function e3Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// hafta doirasi
function e3Week(cur,hl,arcs){clear();var g=S.g,cx=180,cy=86,R=64;
 for(var i=0;i<7;i++){var a=(i/7)*2*Math.PI-Math.PI/2,x=cx+R*Math.cos(a),y=cy+R*Math.sin(a),on=i===cur,h=hl&&hl.indexOf(i)>=0;
  E('circle',{cx:x,cy:y,r:20,fill:on?C.blue:(h?'#ffd9b8':'#fff'),stroke:'#c9d3dd','stroke-width':1.5},g);T(g,x,y+4,E3D[i].slice(0,3)+'.',{'font-size':10,'font-weight':800,fill:on?'#fff':'#1d2b3a'})}
 T(g,cx,cy-4,'hafta',{'font-size':12,'font-weight':800,fill:C.blue});T(g,cx,cy+12,'7 kun',{'font-size':11,fill:'#5b6b7b'})}
// musht usuli
function e3Fist(upto){clear();var g=S.g,x0=40,dx=40;
 var pts=[];for(var i=0;i<7;i++){var kn=i%2===0;pts.push([x0+i*dx,kn?60:84])}
 E('path',{d:'M'+(x0-14)+' 60 '+pts.map(function(p){return 'L'+p[0]+' '+p[1]}).join(' ')+' L'+(x0+6*dx+14)+' 60 L'+(x0+6*dx+20)+' 140 L'+(x0-20)+' 140 Z',fill:'#f5d2b0',stroke:'#b07a4f','stroke-width':2},g);
 var seq=[0,1,2,3,4,5,6,0,1,2,3,4];
 for(var m=0;m<12&&m<upto;m++){var p=pts[seq[m]],kn=seq[m]%2===0,yy=kn?(m<7?40:24):(m<7?104:120);T(g,p[0],yy,E3M[m].slice(0,3)+' '+E3N[m],{'font-size':10,'font-weight':800,fill:kn?C.ok:C.bad})}
 T(g,180,160,'Do‘nglik — 31 kun, chuqurcha — 30 (fevral — 28 yoki 29)',{'font-size':10,fill:'#5b6b7b'})}
// oy kalendari (28-dekabr — 8-yanvar)
function e3Span(on){clear();var g=S.g;var days=[];for(var d=28;d<=31;d++)days.push(['dek',d]);for(var d2=1;d2<=8;d2++)days.push(['yan',d2]);
 days.forEach(function(x,i){var c=i%6,r=Math.floor(i/6),X=30+c*52,Y=24+r*62;E('rect',{x:X,y:Y,width:46,height:50,rx:6,fill:on?'#e6f6ee':'#fff',stroke:on?C.ok:'#c9d3dd','stroke-width':1.5},g);T(g,X+23,Y+16,x[0],{'font-size':10,fill:'#5b6b7b'});T(g,X+23,Y+38,String(x[1]),{'font-size':18,'font-weight':800,fill:'#1d2b3a'});if(on)T(g,X+40,Y+12,String(i+1),{'font-size':8,'font-weight':800,fill:C.ok})})}
var P2=[function(){e3Week(1);e3Msg('Bugun <b>seshanba</b>. 10 kundan keyin qaysi kun?')},
 function(){e3Week(1,[1]);e3Msg('7 kundan keyin yana <b>seshanba</b> bo‘ladi — hafta aylanib keldi. 10 = 7 + 3')},
 function(){e3Week(4,[1]);e3Msg('Seshanbadan yana 3 kun: chorshanba, payshanba, <b>juma</b>')}];
var P6=[function(){e3Span(false);e3Msg('Ta‘til 28-dekabrdan 8-yanvargacha (ikkala kun ham kiradi)')},
 function(){e3Span(true);e3Msg('Dekabrda: 28, 29, 30, 31 — <b>4 kun</b>; yanvarda: 1 … 8 — <b>8 kun</b>. Jami <b>12 kun</b>')}];
var STEPS=[
{h:"Hafta kunlari",sum:"Haftada 7 kun: dushanba … yakshanba, keyin yana dushanba.",a:"m01",
 start:function(){S.e3c=0;e3Week(0);e3Msg('Bugun <b>dushanba</b>')},fin:function(){e3Week(6);e3Msg('Yakshanbadan keyin yana <b>dushanba</b>')},
 html:"<p>Haftada <b>7 kun</b> bor va ular aylana bo'yicha takrorlanadi. «Ertaga» tugmasini bosib, haftani aylanib chiqing:</p>",
 btns:[["Ertaga →",function(c,done){S.e3c=(S.e3c+1)%7;e3Week(S.e3c);e3Msg('Bugun <b>'+E3D[S.e3c]+'</b>');mvK(done,7)}]],
 after:"<p>Hafta kunlari tartibi: dushanba, seshanba, chorshanba, payshanba, juma, shanba, yakshanba. Yakshanbadan keyin hafta <b>qaytadan</b> boshlanadi.</p>",
 q:{t:"Bugun payshanba. Ertaga qaysi kun?",opts:["chorshanba","juma","shanba","seshanba"],ok:1,why:"Payshanbadan keyin juma.",hint:"Doirada payshanbadan keyingi kunni toping.",full:"Tartib: … chorshanba, payshanba, juma … Payshanbadan keyin — juma. Chorshanba — kecha."},
 tn:"Hafta kunlarini 7 ta kartochkaga yozib, doira qilib terib qo'ying — bolalar «aylanish» g'oyasini ko'rsin."},
{h:"N kundan keyin qaysi kun?",sum:"Har 7 kunda hafta kuni takrorlanadi. 10 kun = 7 + 3 → seshanbadan 3 kun keyin — juma.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>«Bugun seshanba. 10 kundan keyin haftaning qaysi kuni bo'ladi?» — 10 kunni birma-bir sanash shart emas. Kuzating:</p>",
 btns:[phaser(P2)],
 after:"<p>Usul: kunlar sonidan <b>7 larni olib tashlaymiz</b> (har 7 kunda o'sha kun qaytadi), qolganini sanaymiz. 10 = 7 + 3 → 3 kun keyin. 15 = 7 + 7 + 1 → 1 kun keyin.</p>",
 q:{t:"Bugun dushanba. 9 kundan keyin qaysi kun?",opts:["seshanba","chorshanba","payshanba","dushanba"],ok:1,why:"9 = 7 + 2: dushanbadan 2 kun keyin — chorshanba.",hint:"9 dan 7 ni olib tashlang. Qancha qoldi?",full:"7 kundan keyin yana dushanba. Qolgan 2 kun: seshanba, chorshanba. Javob: chorshanba."},
 tn:"Bank: «Ali dushanba kasal bo'lib, 9 kundan keyin qaytdi» — shu usul bilan yechiladi."},
{h:"N kun oldin qaysi kun edi?",sum:"Orqaga sanaymiz: chorshanbadan 3 kun oldin — yakshanba.",a:"m03",
 start:function(){S.e3b=2;S.e3k=0;e3Week(2);e3Msg('Bugun <b>chorshanba</b>. 3 kun oldin qaysi kun edi?')},fin:function(){e3Week(6,[2]);e3Msg('Chorshanbadan 3 kun oldin — <b>yakshanba</b>')},
 html:"<p>Endi teskarisi: <b>orqaga</b> sanaymiz. «Kecha» tugmasini 3 marta bosing:</p>",
 btns:[["← Kecha",function(c,done,b){S.e3b=(S.e3b+6)%7;e3Week(S.e3b,[2]);S.e3k=(S.e3k||0)+1;e3Msg(S.e3k+' kun oldin: <b>'+E3D[S.e3b]+'</b>');if(S.e3k>=3){b.disabled=true;done()}}]],
 after:"<p>Chorshanba → seshanba → dushanba → <b>yakshanba</b>. Haftaning boshi dushanba bo'lsa ham, orqaga sanaganda yakshanbaga — oldingi haftaga o'tamiz.</p>",
 q:{t:"Bugun seshanba. 4 kun oldin qaysi kun edi?",opts:["shanba","juma","yakshanba","dushanba"],ok:1,why:"dushanba, yakshanba, shanba, juma — 4 kun oldin juma.",hint:"Seshanbadan orqaga 4 qadam yuring.",full:"1 kun oldin — dushanba, 2 — yakshanba, 3 — shanba, 4 — juma."},
 tn:"«Kecha», «o'tgan kuni», «bir hafta oldin» so'zlarini kalendarda ko'rsatib mashq qiling."},
{h:"Oylar va kunlar soni: musht usuli",sum:"Do'nglikka tushgan oy — 31 kun, chuqurchaga tushgani — 30 kun; fevral — 28 (yoki 29).",a:"m04",
 start:function(){S.e3m=0;e3Fist(0);e3Msg('Yilda 12 oy. Qaysi oyda necha kun?')},fin:function(){e3Fist(12);e3Msg('Musht usuli: do‘nglik — 31, chuqurcha — 30')},
 html:"<p>Oylarda kunlar soni har xil. Uni eslab qolishning dunyoga mashhur usuli — <b>musht</b>. Oylarni birma-bir qo'ying: do'nglik (suyak) — 31 kun, chuqurcha — 30 kun.</p>",
 btns:[["+ keyingi oy",function(c,done,b){S.e3m++;e3Fist(S.e3m);var m=S.e3m-1;e3Msg('<b>'+E3M[m]+'</b> — '+E3N[m]+' kun'+(m===1?' (kabisa yilda 29)':''));if(S.e3m>=12){b.disabled=true;done()}}]],
 after:"<p>31 kunli oylar: yanvar, mart, may, iyul, avgust, oktabr, dekabr. 30 kunli: aprel, iyun, sentabr, noyabr. <b>Fevral</b> — 28 kun, har 4 yilda (kabisa yili) — 29 kun. Iyul va avgust — ketma-ket ikki «31»!</p>",
 q:{t:"Iyun oyida necha kun bor?",opts:["31","30","28","29"],ok:1,why:"Iyun chuqurchaga tushadi — 30 kun.",hint:"Musht usulida iyun qayerga tushdi?",full:"Yanvar (do'nglik), fevral, mart, aprel, may, iyun — iyun chuqurchaga tushadi: 30 kun."},
 tn:"Musht usuli ko'p mamlakatlarda o'rgatiladi. Har bola o'z mushtida ko'rsatib chiqsin."},
{h:"Hafta va kunlarni almashtirish",sum:"1 hafta = 7 kun. 2 hafta 3 kun = 14 + 3 = 17 kun.",a:"m05",
 start:function(){e3Bars(0)},fin:function(){e3Bars(2)},
 html:"<p>«Alining tug'ilgan kuniga 2 hafta va 3 kun qoldi. Bu necha kun?» Bloklar bilan ko'ramiz:</p>",
 btns:[["+ 1 hafta",function(c,done){S.e3w=Math.min(2,(S.e3w||0)+1);e3Bars(S.e3w);mvK(done,2)}]],
 after:"<p>Har bir hafta — <b>7 kun</b>. 2 hafta = 14 kun, yana 3 kun — <b>17 kun</b>. Teskari: 20 kun = 2 hafta 6 kun (14 + 6).</p>",
 q:{t:"Ali lagerda 3 hafta, Lola 20 kun dam oldi. Kim necha kun ko'p dam oldi?",opts:["Lola 17 kun","Ali 1 kun","Teng","Lola 1 kun"],ok:1,why:"3 hafta = 21 kun, 21 − 20 = 1.",hint:"3 haftani kunlarga aylantiring.",full:"3 hafta = 7 + 7 + 7 = 21 kun. Ali 21, Lola 20 — Ali 1 kun ko'p. «Lola 17» — haftani 1 kun deb o'ylagan xato."},
 tn:"Kalendar varag'ida haftalar qator bo'lib turadi — bir qator = 7 kun ekanini ko'rsating."},
{h:"Tuzoq: «dan … gacha» kunlar",sum:"28-dekabrdan 8-yanvargacha (ikkalasi kiradi): dekabrda 4 kun + yanvarda 8 kun = 12 kun.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Masala: <i>«Qishki ta'til 28-dekabrdan 8-yanvargacha davom etdi (ikkala kun ham kiradi). Ta'til necha kun?»</i> Kuzating:</p>",
 btns:[phaser(P6)],
 after:"<p>Oy almashganda ikkiga bo'lib sanaymiz: dekabrda 28, 29, 30, 31 — <b>4 kun</b> (dekabr 31 kunli!), yanvarda 1 dan 8 gacha — <b>8 kun</b>. Jami <b>12 kun</b>. «8 − 28» deb ayirib bo'lmaydi!</p>",
 q:{t:"Bugun 25-may. Ta'til 1-iyundan boshlanadi. Necha kun qoldi? (May — 31 kun)",opts:["6","7","5","8"],ok:1,why:"26, 27, 28, 29, 30, 31-may va 1-iyun — 7 kun.",hint:"Ertadan boshlab 1-iyungacha har kunni sanang.",full:"Maydan qolgan kunlar: 26, 27, 28, 29, 30, 31 — 6 kun. Yana 1-iyun ta'til boshlanadigan kun, unga yetish uchun 7-kun. Bank javobi: 7."},
 tn:"Bu — 2A3 dagi «ustunlar xatosi»ning kalendar ko'rinishi. Bolalar kalendarda barmoq bilan sanab ko'rsin."},
{h:"Yil, fasl va oylar tartibi",sum:"Yilda 12 oy, 4 fasl, 365 kun (kabisa yilda 366).",a:"m07",
 start:function(){e3Year(-1)},fin:function(){e3Year(3)},
 html:"<p>Yil <b>12 oy</b>dan va <b>4 fasl</b>dan iborat. Fasllarni bosib ko'ring:</p>",
 btns:[["❄️ Qish",function(c,done){e3Year(0);mvK(done,4)}],["🌸 Bahor",function(c,done){e3Year(1);mvK(done,4)}],["☀️ Yoz",function(c,done){e3Year(2);mvK(done,4)}],["🍂 Kuz",function(c,done){e3Year(3);mvK(done,4)}]],g2:1,
 after:"<p>Har faslda <b>3 oy</b>: 4 · 3 = 12. Yilda <b>365 kun</b>, kabisa yilida <b>366</b> (fevral 29 kun). Yilning uchinchi oyi — mart, oltinchi oyi — iyun.</p>",
 q:{t:"Yilning uchinchi oyidan keyin keladigan oy qaysi?",opts:["mart","may","aprel","fevral"],ok:2,why:"3-oy — mart, keyingisi — aprel.",hint:"Avval uchinchi oyni toping: yanvar, fevral, …",full:"1 — yanvar, 2 — fevral, 3 — mart. Martdan keyin — aprel. «Mart» — uchinchi oyning o'zi."},
 tn:"Bolalar o'z tug'ilgan oyini va faslini aytsin, sinf bo'yicha piktogramma tuzing (2G2 bilan bog'lanadi)."},
{h:"Bilasizmi? Hafta va yil tarixi",sum:"Hafta 7 kunligi Bobildan kelgan. Ulug'bek yil uzunligini juda aniq hisoblagan.",a:"m08",
 start:function(){e3Week(0)},fin:function(){e3Week(0)},
 html:"<p>🏺 Haftaning 7 kunligini qadimgi <b>Bobil</b> olimlari boshlagan deyiladi: ular osmonda ko'zga ko'rinadigan 7 ta yoritqichni (Quyosh, Oy va 5 ta sayyora) kuzatishgan.</p><p>📅 Har 4 yilda fevralga bir kun qo'shiladi, chunki Yer Quyosh atrofini 365 kun va qariyb <b>6 soat</b>da aylanadi. 4 marta 6 soat — bir kun!</p><p>⭐ <b>Mirzo Ulug'bek</b> XV asrda Samarqand rasadxonasida yil uzunligini o'sha davr uchun juda aniq hisoblagan.</p>",
 tn:"«Kabisa yil» ni 6 soatlik «qoldiq»lar yig'ilib bir kun bo'lishi orqali tushuntiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){e3Fist(12)},fin:function(){e3Fist(12)},
 html:"<div class='memo'><ul><li>Haftada <b>7 kun</b>; har 7 kunda hafta kuni takrorlanadi.</li><li>«10 kundan keyin»: 10 = 7 + 3 → 3 kun keyingi kun.</li><li>Yilda <b>12 oy</b>, 4 fasl, <b>365 kun</b> (kabisa — 366).</li><li>Musht usuli: do'nglik — <b>31</b>, chuqurcha — <b>30</b>, fevral — <b>28/29</b>.</li><li>1 hafta = 7 kun: 2 hafta 3 kun = 17 kun.</li><li>Oy almashganda kunlarni ikki qismga bo'lib sanang: 28-dekabr – 8-yanvar = 4 + 8 = 12 kun.</li></ul></div>",
 tn:"Keyingi darsni «Bugun juma. 20 kundan keyin qaysi kun?» (20 = 14 + 6 → payshanba) savoli bilan boshlang."}
];
function e3Bars(w){clear();var g=S.g;S.e3w=w;for(var i=0;i<w;i++)for(var d=0;d<7;d++)E('rect',{x:20+d*22,y:30+i*36,width:20,height:28,rx:3,fill:'#8fc6f0',stroke:'#2b6ca3'},g);
 for(var i2=0;i2<w;i2++)T(g,190,50+i2*36,'1 hafta = 7 kun',{'font-size':11,'font-weight':800,'text-anchor':'start',fill:'#2b6ca3'});
 if(w>=2){for(var k=0;k<3;k++)E('rect',{x:20+k*22,y:30+2*36,width:20,height:28,rx:3,fill:'#f6c343',stroke:'#a07a1c'},g);T(g,100,122,'+ 3 kun',{'font-size':11,'font-weight':800,'text-anchor':'start',fill:'#a07a1c'})}
 e3Msg(w>=2?'7 + 7 + 3 = <b>17 kun</b>':w+' hafta = '+(w*7)+' kun')}
function e3Year(f){clear();var g=S.g,cols=['#bfe3ff','#c9f2c1','#ffe08a','#ffc89a'],names=['Qish','Bahor','Yoz','Kuz'],ms=[[11,0,1],[2,3,4],[5,6,7],[8,9,10]];
 for(var i=0;i<4;i++){var x=14+i*86;E('rect',{x:x,y:20,width:80,height:130,rx:10,fill:cols[i],stroke:f===i?C.blue:'#c9d3dd','stroke-width':f===i?3:1},g);T(g,x+40,40,names[i],{'font-size':13,'font-weight':800});ms[i].forEach(function(m,j){T(g,x+40,70+j*26,E3M[m],{'font-size':11,'font-weight':f===i?800:500})})}
 e3Msg(f<0?'Faslni bosing':names[f]+': '+ms[f].map(function(m){return E3M[m]}).join(', '))}
var PROBS=[
{t:"Haftada necha kun bor?",o:["7","5","10","30"],k:0,s:"Hafta — 7 kun."},
{t:"Bugun shanba. Ertaga qaysi kun?",o:["yakshanba","juma","dushanba","payshanba"],k:0,s:"Shanbadan keyin yakshanba."},
{t:"Bugun seshanba. 10 kundan keyin qaysi kun?",o:["juma","payshanba","shanba","chorshanba"],k:0,s:"10 = 7 + 3: seshanbadan 3 kun keyin — juma."},
{t:"Bugun chorshanba. 3 kun oldin qaysi kun edi?",o:["yakshanba","juma","dushanba","shanba"],k:0,s:"seshanba, dushanba, yakshanba."},
{t:"Ali dushanba kasal bo'lib, 9 kundan keyin maktabga qaytdi. U qaysi kuni qaytdi?",o:["chorshanba","seshanba","dushanba","payshanba"],k:0,s:"9 = 7 + 2: dushanbadan 2 kun keyin — chorshanba."},
{t:"Iyun oyida necha kun bor?",o:["30","31","28","29"],k:0,s:"Iyun — 30 kun."},
{t:"Qaysi oyda 31 kun bor?",o:["avgust","aprel","iyun","noyabr"],k:0,s:"Avgust — 31 kun, qolganlari 30."},
{t:"Yilda nechta oy bor?",o:["12","10","4","7"],k:0,s:"Yil — 12 oy."},
{t:"Tug'ilgan kunga 2 hafta 3 kun qoldi. Bu necha kun?",o:["17","23","5","10"],k:0,s:"14 + 3 = 17."},
{t:"Ali 3 hafta, Lola 20 kun dam oldi. Kim necha kun ko'p dam oldi?",o:["Ali, 1 kun","Lola, 1 kun","Lola, 17 kun","Teng"],k:0,s:"3 hafta = 21 kun, 21 − 20 = 1."},
{t:"Yilning uchinchi oyidan keyingi oy qaysi?",o:["aprel","mart","may","fevral"],k:0,s:"3-oy mart, keyingisi aprel."},
{t:"Bugun 25-may. Ta'til 1-iyundan boshlanadi (may — 31 kun). Necha kun qoldi?",o:["7","6","5","8"],k:0,s:"26–31-may (6 kun) va 1-iyun: 7."},
{t:"Ta'til 28-dekabrdan 8-yanvargacha (ikkalasi ham kiradi). Ta'til necha kun?",o:["12","11","10","20"],k:0,s:"Dekabrda 4 kun, yanvarda 8 kun: 12."},
{t:"Bugun juma. 20 kundan keyin qaysi kun?",o:["payshanba","juma","seshanba","shanba"],k:0,s:"20 = 14 + 6: jumadan 6 kun keyin — payshanba."},
{t:"Qishki oylar qaysilar?",o:["dekabr, yanvar, fevral","yanvar, fevral, mart","noyabr, dekabr, yanvar","dekabr, yanvar, mart"],k:0,s:"Qish: dekabr, yanvar, fevral."},
{t:"Kabisa yilida fevralda necha kun bor?",o:["29","28","30","31"],k:0,s:"Kabisa yilida fevral 29 kun."},
{t:"28 kun necha hafta?",o:["4","3","7","5"],k:0,s:"28 = 7 + 7 + 7 + 7: 4 hafta."},
{t:"Oyning 3-sanasi seshanba. Shu oyning 17-sanasi qaysi kun?",o:["seshanba","chorshanba","dushanba","juma"],k:0,s:"17 − 3 = 14 = 2 hafta: yana seshanba."},
{t:"Bugun yakshanba. 5 kundan keyin qaysi kun?",o:["juma","shanba","payshanba","dushanba"],k:0,s:"dushanba (1), seshanba, chorshanba, payshanba, juma (5)."},
{t:"Yozgi uch oyda jami necha kun bor?",o:["92","90","91","93"],k:0,s:"Iyun 30 + iyul 31 + avgust 31 = 92."}
];
function PRACT_STAGE(){e3Fist(12)}
var PREP_DATA={teach:["Hafta kunlari tartibi va aylanish (7 kunda takrorlanadi).","N kundan keyin / oldin qaysi kun (7 larni olib tashlash).","Oylar va kunlar soni (musht usuli), fasllar, yil va kabisa yili.","Hafta ↔ kun almashtirish; oy almashganda kunlarni sanash."],
 mist:["10 kundan keyinni birma-bir sanab adashadi.","Orqaga sanaganda dushanbadan yakshanbaga o'ta olmaydi.","Barcha oylarni 30 kun deb hisoblaydi.","28-dekabr – 8-yanvarni 8 − 28 yoki 11 deb hisoblaydi."],
 need:["Devoriy kalendar.","7 ta hafta kuni kartochkasi."],
 board:["Doira: <span class='w2'>du → se → chor → pay → ju → sha → yak → du</span>.","<span class='w2'>10 = 7 + 3</span> → 3 kun keyin.","Musht: do'nglik 31, chuqurcha 30, fevral 28/29.","<span class='w2'>2 hafta 3 kun = 17 kun</span>.","<span class='w2'>28.12 – 8.01 = 4 + 8 = 12 kun</span>."]};
