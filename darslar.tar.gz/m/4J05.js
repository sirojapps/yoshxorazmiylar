var CODE='4J05',TITLE="4-sinf · Sehrli kvadrat va raqamli jumboqlar";
function s5Sq(rows,o){o=o||{};var col={},fill={};rows.forEach(function(r,i){r.forEach(function(v,j){if(v==='?'){col[i+','+j]=C.bad;fill[i+','+j]='#ffe9e9'}if(o.hl&&o.hl[i+','+j])fill[i+','+j]='#ffe9a8'})});j3Tab(rows,{cw:o.cw||46,ch:o.ch||40,fs:o.fs||19,col:col,fill:fill,y0:o.y0});if(o.t)T(S.g,o.tx||300,o.ty||90,o.t,{'font-size':14,'font-weight':800,fill:o.tc||'#1d2b3a'})}
function s5Pyr(rows){clear();var w=46,h=30,n=rows.length;rows.forEach(function(r,i){var y=20+i*(h+4),x0=180-r.length*w/2;r.forEach(function(v,j){var q=v==='?';E('rect',{x:x0+j*w,y:y,width:w-2,height:h,rx:5,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.4},S.g);T(S.g,x0+j*w+w/2-1,y+21,String(v),{'font-size':16,'font-weight':800,fill:q?C.bad:'#1d2b3a'})})})}
var STEPS=[
J4({h:"Sehrli kvadratning markazi",sum:"2 dan 10 gacha sonlar yig'indisi 54. 3 qator → har qator 18. Markazdagi son = 18 : 3 = 6.",a:"m01",
 s:function(){s5Sq([[5,10,3],[4,'?',8],[9,2,7]],{t:'2 … 10'})},m:"Har qator, ustun va diagonal yig‘indisi bir xil",
 f:function(){s5Sq([[5,10,3],[4,6,8],[9,2,7]],{t:'= 18',tc:C.ok,hl:{'1,1':1}})},fm:"2+3+…+10 = 54, 54 : 3 = 18, markaz 18 : 3 = 6",
 html:"<p>Bu sehrli kvadratga 2 dan 10 gacha sonlar yozilgan: har qator, har ustun va ikkala diagonal yig'indisi bir xil. Markazdagi son qaysi?</p>",
 ch:["6","5","9","18"],ok:0,bad:["","5 — 1 dan 9 gacha bo‘lgan kvadratning markazi. Bu yerda sonlar 2 dan boshlanadi","Qatorni tekshiring: 4 + 9 + 8 = 21 — sehrli yig‘indidan ortiq","18 — bu sehrli yig‘indi, markazdagi son emas"],
 after:"<p>Hamma sonlar yig'indisi 2 + 3 + … + 10 = 54. Uchta qator teng → har biri 54 : 3 = <b>18</b>. 3×3 sehrli kvadratda markaz doim sehrli yig'indining uchdan biri: 18 : 3 = 6. Tekshiring: 4 + 6 + 8 = 18 ✓, 5 + 6 + 7 = 18 ✓.</p>",
 q:{t:"1 dan 9 gacha sonlar yozilgan sehrli kvadratda har qatordagi yig'indi nechchi?",opts:["15","45","9","12"],ok:0,why:"1 + … + 9 = 45, 45 : 3 = 15.",hint:"Hamma sonlarni qo'shib, qatorlar soniga bo'ling.",full:"45 : 3 = 15. «45» — butun kvadrat yig'indisi, bitta qator emas."},
 tn:"Ikki usulni ko'rsating: umumiy yig'indini bo'lish va markazdan o'tuvchi 4 ta chiziqni qo'shish (4 · 18 = 54 + 3 · markaz)."}),
J4({h:"Bo'sh kataklarni to'ldirish",sum:"Sehrli yig'indi ma'lum bo'lsa, ikkita son ma'lum bo'lgan qatordan uchinchisi topiladi: 18 − 5 − 3 = 10.",a:"m02",
 s:function(){s5Sq([[5,'?',3],['',6,''],[9,'',7]],{t:'yig‘indi 18'})},m:"Qaysi qatorda faqat bitta katak bo‘sh?",
 f:function(){s5Sq([[5,10,3],[4,6,8],[9,2,7]],{t:'yig‘indi 18',hl:{'0,1':1}})},fm:"18 − 5 − 3 = 10; keyin 18 − 5 − 9 = 4 va hokazo",
 html:"<p>Sehrli yig'indi 18. Yuqori o'rtadagi <b>?</b> katakka qaysi son yoziladi?</p>",
 ch:["10","8","4","2"],ok:0,bad:["","8 bo‘lsa yuqori qator 5 + 8 + 3 = 16","4 — chap o‘rta katak bo‘ladi (ustun: 5 + ? + 9)","2 — pastki o‘rta katak (ustun: 10 + 6 + ?)"],
 after:"<p>Yuqori qatorda ikki son bor: 18 − 5 − 3 = <b>10</b>. Keyin har safar faqat bitta katagi bo'sh qolgan qatorni yoki ustunni topamiz: chap ustun 18 − 5 − 9 = 4, o'rta qator 18 − 4 − 6 = 8, o'rta ustun 18 − 10 − 6 = 2.</p>",
 q:{t:"Shu kvadratdagi chap o'rta katakka qaysi son yoziladi?",opts:["4","3","8","2"],ok:0,why:"Chap ustun: 18 − 5 − 9 = 4.",hint:"Chap ustunda qaysi sonlar bor?",full:"Chap ustunda 5 va 9: 18 − 14 = 4. «8» — o'ng o'rta katak."},
 tn:"Bolalar har topilgan katakdan keyin «qaysi chiziq bo'yicha topdim?» deb aytsin."}),
J4({h:"4×4 sehrli kvadrat",sum:"1 dan 16 gacha sonlar yig'indisi 136. 4 ta qator → har birida 136 : 4 = 34.",a:"m03",
 s:function(){s5Sq([[16,3,2,13],[5,10,11,8],[9,6,7,12],[4,15,14,1]],{cw:40,ch:34,fs:16})},m:"Bu Dyurer kvadrati — har qatorni qo‘shib ko‘ring",
 f:function(){s5Sq([[16,3,2,13],[5,10,11,8],[9,6,7,12],[4,15,14,1]],{cw:40,ch:34,fs:16,hl:{'3,1':1,'3,2':1}})},fm:"1 + 2 + … + 16 = 136, 136 : 4 = 34",
 html:"<p>4×4 kvadratga 1 dan 16 gacha sonlar yozilgan va u ham sehrli. Hech qaysi qatorni qo'shmasdan, sehrli yig'indini toping.</p>",
 ch:["34","40","136","32"],ok:0,bad:["","Yig‘indini qayta hisoblang: (1 + 16) · 16 : 2","136 — barcha sonlar yig‘indisi, bitta qator emas",""],
 after:"<p>1 + 2 + … + 16 = (1 + 16) · 16 : 2 = 136. Qatorlar 4 ta: 136 : 4 = <b>34</b>. Tekshiring: 16 + 3 + 2 + 13 = 34 ✓. Pastki qatorning o'rtasida 15 va 14 — shu kvadrat chizilgan yil: 1514!</p>",
 q:{t:"Shu 4×4 sehrli kvadratda ikkala diagonaldagi sonlar birgalikda nechchi?",opts:["68","34","136","64"],ok:0,why:"Har diagonal 34, ular umumiy katakka ega emas: 68.",hint:"Bitta diagonal yig'indisi nechchi?",full:"Har diagonal 34. 4×4 da diagonallar kesishmaydi: 34 + 34 = 68. «34» — faqat bittasi."},
 tn:"Dyurer kvadratida 4 ta burchak (16 + 13 + 4 + 1) va markaziy 4 katak (10 + 11 + 6 + 7) ham 34 — bolalar yana 34 li to'rtliklarni izlasin."}),
J4({h:"Bir xil raqamlar jumbog'i",sum:"□□ + □ = 72: ikki xonali □□ = 11 · □. 11 · □ + □ = 12 · □ = 72 → □ = 6.",a:"m04",
 s:['□□ + □ = 72','(□ — bir xil raqam)'],so:{fs:22,lh:44},m:"□□ — bu 11 ta □ ga teng (masalan, 33 = 11 · 3)",
 f:['66 + 6 = 72 ✓','12 · □ = 72 → □ = [6]'],fso:{fs:20,lh:44},fm:"Ikki xonali bir xil raqamli son = 11 · raqam",
 html:"<p>Har bir □ o'rnida bir xil raqam turibdi: □□ + □ = 72. Qaysi raqam?</p>",
 ch:["6","7","8","9"],ok:0,bad:["","77 + 7 = 84","88 + 8 = 96","99 + 9 = 108"],
 after:"<p>Sinab ko'rish mumkin, lekin chiroyli yo'l bor: 66 = 6 · 11, ya'ni □□ = 11 · □. Unda 11 · □ + □ = 12 · □ = 72 → □ = 6. Uch xonali □□□ = 111 · □.</p>",
 q:{t:"△△△ : △ = ? (△ — nol bo'lmagan bir xil raqam)",opts:["111","101","110","3"],ok:0,why:"△△△ = 111 · △, uni △ ga bo'lsak 111.",hint:"777 : 7 ni hisoblang.",full:"777 : 7 = 111, 444 : 4 = 111 — har doim 111. «3» — raqamlar sonini sanash xatosi."},
 tn:"Bolalar «11 · □» qoidasini 2–3 misolda tekshirsin: 44 = 11 · 4, 99 = 11 · 9."}),
J4({h:"Tuzoq: nechta yechim?",sum:"AB + BA = 121 → 11 · (A + B) = 121 → A + B = 11. Mos juftlar: 29, 38, 47, 56, 65, 74, 83, 92 — 8 ta.",a:"m05",
 s:['AB + BA = 121','Nechta AB son mos keladi?'],so:{fs:20,lh:44},m:"AB = 10 · A + B, BA = 10 · B + A",
 f:['A + B = 11','29, 38, 47, 56,','65, 74, 83, 92 → [8 ta]'],fso:{fs:18,lh:36},fm:"Javob bitta emas — sakkizta!",
 html:"<p>AB va BA — ikki xonali sonlar (A va B — raqamlar, nol emas). AB + BA = 121. Bunday AB sonlar <b>nechta</b>?</p>",
 ch:["8","9","4","7"],ok:0,bad:["","A + B = 11. A = 1 bo‘lsa B = 10 — raqam emas","56 va 65 alohida sonlar — ikkalasini ham sanang","Juftlarni qayta yozing: A 2 dan 9 gacha"],
 after:"<p>AB + BA = 10A + B + 10B + A = 11 · (A + B) = 121 → A + B = 11. A 2 dan 9 gacha bo'lishi mumkin (A = 1 da B = 10 — raqam emas): <b>8 ta</b> son. Jumboqda yechim bitta deb o'ylash — tuzoq!</p>",
 q:{t:"AB + BA = 66 (A va B — har xil, noldan farqli raqamlar). Nechta AB son mos keladi?",opts:["4","5","6","3"],ok:0,why:"A + B = 6, har xil: 15, 24, 42, 51.",hint:"A + B nechchi bo'lishi kerak? A = B bo'lishi mumkin emas.",full:"11 · (A + B) = 66 → A + B = 6. Juftlar: 1+5, 2+4, 4+2, 5+1 (3+3 — bir xil, mumkin emas). 4 ta."},
 tn:"Kuchli o'quvchilarga: AB − BA = 9 · (A − B) ekanini isbotlatish."}),
J4({h:"Ko'paytirish jumbog'i",sum:"1★ · ★ = 96. Oxirgi raqam: ★ · ★ oxiri 6 → ★ = 4 yoki 6. 14 · 4 = 56, 16 · 6 = 96 ✓.",a:"m06",
 s:['1★ · ★ = 96'],so:{fs:24},m:"Oxirgi raqamdan boshlang: ★ · ★ ning oxiri 6",
 f:['★ · ★ → oxiri 6: ★ = 4 yoki 6','14 · 4 = 56 — kichik','16 · 6 = [96] ✓'],fso:{fs:17,lh:36},fm:"Oxirgi raqam nomzodlarni kamaytiradi, keyin tekshiramiz",
 html:"<p>★ — bir xil raqam: 1★ · ★ = 96. Qaysi raqam?</p>",
 ch:["6","8","4","9"],ok:0,bad:["","18 · 8 = 144","14 · 4 = 56 — oxiri 6, lekin son kichik","19 · 9 = 171"],
 after:"<p>Usul: <b>oxirgi raqam</b> bo'yicha nomzodlarni tanlaymiz. ★ · ★ 6 bilan tugashi kerak: 4 · 4 = 16, 6 · 6 = 36. Ikkalasini tekshiramiz: faqat 16 · 6 = 96 to'g'ri.</p>",
 q:{t:"★★ · ★ = 176 (★ — bir xil raqam). ★ = ?",opts:["4","6","8","2"],ok:0,why:"44 · 4 = 176.",hint:"★ · ★ ning oxirgi raqami 6 bo'lishi kerak.",full:"Nomzodlar 4 va 6: 44 · 4 = 176 ✓, 66 · 6 = 396 ✗."},
 tn:"Ko'paytirish jadvalida kvadratlarning oxirgi raqamlarini yozdiring: 1, 4, 9, 6, 5, 6, 9, 4, 1."}),
J4info({h:"Bilasizmi? Dyurerning sehrli kvadrati",a:"m07",s:function(){s5Sq([[16,3,2,13],[5,10,11,8],[9,6,7,12],[4,15,14,1]],{cw:40,ch:34,fs:16,hl:{'3,1':1,'3,2':1}})},m:"Pastki qator o‘rtasida: 15 14 → 1514-yil",
 html:"<p>🎨 Nemis rassomi <b>Albrext Dyurer</b> 1514-yilda «Melanxoliya I» gravyurasini yaratgan. Unda devorda 4×4 sehrli kvadrat tasvirlangan — pastki qatorning o'rtasidagi 15 va 14 sonlari asar yaratilgan yilni bildiradi. Undan ancha oldin xitoyliklar 3×3 sehrli kvadratni (Lo Shu) bilgan.</p>",
 tn:"Dyurer kvadratini nusxalab, bolalar 34 beradigan to'rtliklarni rang bilan belgilasin."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){s5Sq([[5,10,3],[4,6,8],[9,2,7]])},m:"Avval umumiy yig‘indini toping",
 html:"<div class='memo'><ul><li>Sehrli yig'indi = hamma sonlar yig'indisi : qatorlar soni.</li><li>3×3 da markaz = sehrli yig'indi : 3.</li><li>Faqat bitta bo'sh katakli qator yoki ustundan boshlang.</li><li>□□ = 11 · □, □□□ = 111 · □.</li><li>AB + BA = 11 · (A + B).</li><li>Ko'paytirishda oxirgi raqamdan boshlang.</li><li>Yechim bir nechta bo'lishi mumkin — hammasini toping!</li></ul></div>",
 tn:"Uyga: 3 dan 11 gacha sonlar bilan sehrli kvadrat tuzib kelish (yig'indi 21, markaz 7)."})
];
var PROBS=[
{t:"1 dan 9 gacha sonlar yozilgan 3×3 sehrli kvadratning markazida qaysi son turadi?",o:["5","9","1","15"],k:0,s:"Sehrli yig'indi 15, markaz 15 : 3 = 5."},
{t:"3 dan 11 gacha sonlar bilan 3×3 sehrli kvadrat tuzildi. Sehrli yig'indi nechchi?",o:["21","63","7","18"],k:0,s:"3 + … + 11 = 63, 63 : 3 = 21."},
{t:"3×3 sehrli kvadratda har qator yig'indisi 30. Markazda qaysi son?",o:["10","15","30","5"],k:0,s:"Markaz = 30 : 3 = 10."},
{t:"1 dan 9 gacha sonlar bilan tuzilgan 3×3 sehrli kvadratning burchaklarida qanday sonlar turadi?",o:["faqat juft sonlar","faqat toq sonlar","1 va 9","5 dan katta sonlar"],k:0,s:"Masalan: 2 7 6 / 9 5 1 / 4 3 8 — burchaklarda 2, 6, 4, 8."},
{t:"1 dan 16 gacha sonlar bilan 4×4 sehrli kvadrat tuzildi. Har qator yig'indisi?",o:["34","36","136","17"],k:0,s:"136 : 4 = 34."},
{t:"□□ + □□ = 88 (□ — bir xil raqam). □ = ?",o:["4","8","2","44"],k:0,s:"22 · □ = 88 → □ = 4: 44 + 44."},
{t:"□□□ − □□ = 400 (□ — bir xil raqam). □ = ?",o:["4","2","8","5"],k:0,s:"111 · □ − 11 · □ = 100 · □ = 400 → 4: 444 − 44."},
{t:"AB + BA = 99 (A, B — noldan farqli raqamlar). Nechta AB son mos keladi?",o:["8","9","10","4"],k:0,s:"A + B = 9: 18, 27, 36, 45, 54, 63, 72, 81."},
{t:"AB − BA = 27 (A, B — noldan farqli raqamlar). Nechta AB son mos keladi?",o:["6","7","3","9"],k:0,s:"9 · (A − B) = 27 → A − B = 3: 41, 52, 63, 74, 85, 96."},
{t:"1★ · ★ = 96 (★ — bir xil raqam). ★ = ?",o:["6","8","4","9"],k:0,s:"16 · 6 = 96."},
{t:"★★ · ★ = 176 (★ — bir xil raqam). ★ = ?",o:["4","6","8","2"],k:0,s:"44 · 4 = 176."},
{t:"Uchburchakning 3 ta uchiga va 3 ta tomoni o'rtasiga 1 dan 6 gacha sonlar yozildi. Har tomondagi 3 ta son yig'indisi 9. Uchlardagi sonlar yig'indisi?",o:["6","9","12","3"],k:0,s:"3 · 9 = 27 = 21 + uchlar (ular ikki marta sanaladi) → 6."},
{t:"Xuddi shu uchburchakda har tomon yig'indisi 12. Uchlarda qaysi sonlar turadi?",o:["4, 5, 6","1, 2, 3","2, 4, 6","1, 5, 6"],k:0,s:"3 · 12 − 21 = 15 = 4 + 5 + 6."},
{t:"4★ + ★7 = 80 (★ — bir xil raqam). ★ = ?",o:["3","4","2","7"],k:0,s:"43 + 37 = 80."},
{t:"★★ + ★★ + ★★ = 132 (★ — bir xil raqam). ★ = ?",o:["4","6","2","3"],k:0,s:"33 · ★ = 132 → 4."},
{t:"Sonli piramida: pastki qatorda 3, 5, 2; har katak — ostidagi ikki katak yig'indisi. Tepada qaysi son?",o:["15","10","20","12"],k:0,s:"8 va 7, tepada 15."},
{t:"Sonli piramida: pastki qatorda 1, 2, 3, 4. Tepada qaysi son?",o:["20","10","24","16"],k:0,s:"3, 5, 7 → 8, 12 → 20."},
{t:"Sonli piramida: pastki qatorda □, 3, 5; tepada 20. □ = ?",o:["9","12","4","6"],k:0,s:"O'rta qator: □ + 3 va 8; tepada □ + 11 = 20 → □ = 9."},
{t:"3×3 sehrli kvadratda har qator yig'indisi 15. Kvadratdagi barcha sonlar yig'indisi?",o:["45","15","30","135"],k:0,s:"3 qator · 15 = 45."},
{t:"2 dan 18 gacha juft sonlar (2, 4, …, 18) bilan 3×3 sehrli kvadrat tuzildi. Sehrli yig'indi?",o:["30","90","10","27"],k:0,s:"Yig'indi 90, 90 : 3 = 30."}
];
function PRACT_STAGE(){s5Pyr([[20],[8,12],[3,5,7],[1,2,3,4]])}
var PREP_DATA={teach:["Sehrli yig'indi va 3×3 markazi.","Bo'sh kataklarni bitta noma'lumli chiziqdan to'ldirish.","□□ = 11 · □ va AB + BA = 11 · (A + B).","Oxirgi raqam bo'yicha nomzodlarni tanlash.","Bir nechta yechim bo'lishi."],
 mist:["Sehrli yig'indi o'rniga umumiy yig'indini oladi.","Bitta yechim topib, to'xtaydi.","Sinab ko'rishni tartibsiz qiladi."],
 need:["1–16 raqamli kartochkalar.","3×3 va 4×4 bo'sh kvadratli varaqlar."],
 board:["sehrli yig'indi = jami : 3","3×3 markaz = yig'indi : 3","□□ = 11 · □","AB + BA = 11 · (A + B)"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
