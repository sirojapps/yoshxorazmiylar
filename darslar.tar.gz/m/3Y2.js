var CODE='3Y2',TITLE="3-sinf · Burchakli bo'lish va qoldiqqa oid murakkab masalalar";
function Y2dots(n,k,grp){clear();var g=S.g,cols=[C.a,C.b,C.c,'#9bd08a','#e59ac0'];for(var i=0;i<n;i++){var gi=Math.floor(i/k),full=grp&&gi<Math.floor(n/k);var x=grp?20+gi*62+(i%k)*11:30+(i%12)*26,y=grp?70:50+Math.floor(i/12)*30;
  E('circle',{cx:x+5,cy:y,r:grp?5:9,fill:grp?(full?cols[gi%5]:'#c9d3dd'):C.b,stroke:C.line,'stroke-width':.8},g)}
 if(grp){for(var j=0;j<Math.floor(n/k);j++)E('rect',{x:14+j*62,y:58,width:k*11+2,height:24,rx:6,fill:'none',stroke:'#7a8a9a','stroke-dasharray':'3 2'},g);T(g,180,120,n+' : '+k+' = '+Math.floor(n/k)+' (qoldiq '+(n%k)+')',{'font-size':16,'font-weight':800,fill:C.blue})}}
var P1=[function(){Y2dots(23,5,0);Y3msg('23 ta konfetni 5 tadan qilib qutichalarga solamiz')},
 function(){Y2dots(23,5,1);Y3msg('4 ta to‘la quticha, <b>3 ta</b> konfet ortib qoldi — bu <b>qoldiq</b>')},
 function(){Y2dots(23,5,1);T(S.g,180,150,'23 = 5 · 4 + 3,   3 < 5',{'font-size':14,'font-weight':800,fill:C.ok});Y3msg('Qoldiq har doim <b>bo‘luvchidan kichik</b>: aks holda yana bitta quticha to‘lardi')}];
// burchakli bo'lish chizmasi
function Y2div(num,d,q,rows,o){clear();var g=S.g,cw=19,x0=o&&o.x||40,y0=30;String(num).split('').forEach(function(c,i){T(g,x0+i*cw,y0,c,{'font-size':19,'font-weight':800,fill:'#1d2b3a'})});
 var xl=x0+String(num).length*cw-4;E('line',{x1:xl,y1:y0-20,x2:xl,y2:y0+38,stroke:C.line,'stroke-width':2},g);E('line',{x1:xl,y1:y0+8,x2:xl+70,y2:y0+8,stroke:C.line,'stroke-width':2},g);
 T(g,xl+10,y0,String(d),{'font-size':19,'font-weight':800,fill:'#1d2b3a','text-anchor':'start'});if(q)T(g,xl+10,y0+30,String(q),{'font-size':19,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 rows.forEach(function(r){var s=String(r[1]),y=r[2],col=r[4]||'#1d2b3a';s.split('').forEach(function(c,i){T(g,x0+(r[0]+i)*cw,y,c,{'font-size':17,'font-weight':800,fill:col})});
  if(r[3]==='-'){T(g,x0+(r[0]-1)*cw+4,y-12,'−',{'font-size':15,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+r[0]*cw-9,y1:y+6,x2:x0+(r[0]+s.length)*cw-9,y2:y+6,stroke:C.line,'stroke-width':1.6},g)}});
 (o&&o.note||[]).forEach(function(t,i){T(g,292,40+i*26,t,{'font-size':12,'font-weight':700,fill:C.blue})})}
var P5=[function(){Y2div(2416,8,'',[]);Y3msg('2416 : 8 — burchak usulida bo‘lamiz')},
 function(){Y2div(2416,8,'3',[[0,24,58,'-'],[1,0,84,'',C.bad]],{note:['24 : 8 = 3','24 − 24 = 0']});Y3msg('Birinchi to‘liqsiz bo‘linuvchi — <b>24</b> (2 < 8). 24 : 8 = 3')},
 function(){Y2div(2416,8,'30',[[0,24,58,'-'],[2,1,84,'',C.bad]],{note:['1 ni tushiramiz','1 < 8 → bo‘linmaga 0!']});Y3msg('1 ni tushiramiz: 1 < 8 — bo‘linmaga <b>0</b> yoziladi. Buni unutmang!')},
 function(){Y2div(2416,8,'302',[[0,24,58,'-'],[2,16,84,'-'],[2,16,110],[3,0,136,'',C.ok]],{note:['16 : 8 = 2','302 · 8 = 2416 ✓']});Y3msg('6 ni tushiramiz: 16 : 8 = 2. Javob: <b>302</b> (32 emas!)')}];
var P6=[function(){Y2div(864,24,'',[]);Y3msg('864 : 24 — ikki xonali songa bo‘lish')},
 function(){Y2div(864,24,'3',[[0,72,58,'-'],[0,14,84,'',C.bad]],{note:['86 : 24 ≈ ?','chamalash: 80 : 20 = 4','24 · 4 = 96 > 86 ✗','24 · 3 = 72 ✓']});Y3msg('86 : 24 ni <b>chamalaymiz</b>: 4 ko‘p chiqdi, demak 3. 86 − 72 = 14')},
 function(){Y2div(864,24,'36',[[0,72,58,'-'],[0,144,84,'-'],[0,144,110],[2,0,136,'',C.ok]],{note:['144 : 24 = 6','24 · 6 = 144','36 · 24 = 864 ✓']});Y3msg('4 ni tushiramiz: 144 : 24 = 6. Javob: <b>36</b>')}];
var Y2DAYS=['Dushanba','Seshanba','Chorshanba','Payshanba','Juma','Shanba','Yakshanba'];
function Y2week(k){clear();var g=S.g;for(var i=0;i<7;i++){var hl=(k===2&&i===2)||(k===0&&i===0);E('rect',{x:8+i*50,y:40,width:46,height:46,rx:8,fill:hl?(k?Y2G:'#fde6c8'):'#fff',stroke:'#c9d3dd','stroke-width':1.6},g);T(g,31+i*50,68,Y2DAYS[i].slice(0,3),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
 if(k>=1)T(g,180,118,'100 = 14 · 7 + 2',{'font-size':17,'font-weight':800,fill:C.blue});if(k===2)T(g,180,148,'14 to‘liq hafta + 2 kun → Chorshanba',{'font-size':13,'font-weight':800,fill:C.ok})}
var Y2G='#d6f1e0';
var P4=[function(){Y2week(0);Y3msg('Bugun <b>dushanba</b>. 100 kundan keyin qaysi kun bo‘ladi?')},
 function(){Y2week(1);Y3msg('Har 7 kunda hafta kuni takrorlanadi: 100 ni 7 ga bo‘lamiz')},
 function(){Y2week(2);Y3msg('14 haftadan keyin yana dushanba, +2 kun → <b>chorshanba</b>')}];
function Y2ser(k){clear();var g=S.g,a=[7,11,15,19,23,27],b=[8,13,18,23,28];Y3seq(a.slice(0,k>=1?6:0).length?a:[],{y:22,hi:k>=3?{4:Y2G}:{}});T(g,30,16,'4k+3:',{'font-size':10,fill:'#5b6b7b','text-anchor':'start'});
 if(k>=2){Y3seq(b,{y:96,hi:k>=3?{3:Y2G}:{}});T(g,30,90,'5k+3:',{'font-size':10,fill:'#5b6b7b','text-anchor':'start'})}}
var P8=[function(){clear();Y3msg('4 ga ham, 5 ga ham bo‘lganda qoldiq 3. Eng kichik shunday son (3 dan katta)?')},
 function(){Y2ser(1);Y3msg('4 ga bo‘lganda qoldiq 3: 7, 11, 15, 19, 23, …')},
 function(){Y2ser(2);Y3msg('5 ga bo‘lganda qoldiq 3: 8, 13, 18, 23, …')},
 function(){Y2ser(3);Y3msg('Umumiy: <b>23</b>. Yoki: 23 − 3 = 20 — 4 ga ham, 5 ga ham bo‘linadi')}];
function Y2clock(h,add){clear();var g=S.g,cx=110,cy=87,r=64;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.line,'stroke-width':3},g);for(var i=1;i<=12;i++){var a=i*Math.PI/6;T(g,cx+Math.sin(a)*(r-14),cy-Math.cos(a)*(r-14)+5,String(i),{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}
 var t=add?((h+add-1)%12)+1:h,an=t*Math.PI/6;E('line',{x1:cx,y1:cy,x2:cx+Math.sin(an)*38,y2:cy-Math.cos(an)*38,stroke:add?C.ok:C.bad,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:5,fill:'#1d2b3a'},g);
 T(g,270,70,add?h+' + '+add+' = '+t:'Soat '+h,{'font-size':20,'font-weight':800,fill:add?C.ok:'#1d2b3a'});if(add)T(g,270,100,'(14 − 12 = 2)',{'font-size':13,fill:'#5b6b7b'})}
var STEPS=[
{h:"Qoldiq nima?",sum:"23 : 5 = 4 (qoldiq 3): 23 = 5 · 4 + 3. Qoldiq har doim bo'luvchidan kichik.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har doim ham teng bo'lib bo'lmaydi — ba'zan <b>qoldiq</b> chiqadi. Konfetlarni guruhlaymiz.</p>",btns:[phaser(P1)],
 after:"<p><b>Bo'linuvchi = bo'luvchi · bo'linma + qoldiq</b>: 23 = 5 · 4 + 3. Qoldiq bo'luvchidan kichik (3 < 5). 5 ga bo'lganda qoldiq faqat 0, 1, 2, 3, 4 bo'lishi mumkin.</p>",
 q:{t:"Sonni 8 ga bo'lganda qoldiq eng ko'pi bilan nechaga teng bo'lishi mumkin?",opts:["8","7","9","4"],ok:1,why:"Qoldiq bo'luvchidan kichik: 0 … 7.",hint:"Qoldiq 8 bo'lsa, yana bitta guruh tuzish mumkin bo'lardimi?",full:"Qoldiq 8 bo'lsa, yana bir guruh to'lardi. Demak eng katta qoldiq 7. «4» — bo'luvchining yarmi, qoidaga aloqasi yo'q."},
 tn:"Cho'plar yoki tugmachalar bilan: bola 23 tasini 5 tadan qilib guruhlasin va ortganini o'zi aytsin (Singapur CPA: narsa → rasm → yozuv)."},
{h:"Bo'linuvchini topish",sum:"? : 7 = 23 (qoldiq 6) → 7 · 23 + 6 = 167.",a:"m02",start:function(){clear();Y3seq(['?',':','7','=','23','q. 6']);Y3msg('Bo‘linuvchini toping')},fin:function(){clear();Y3seq(['167',':','7','=','23','q. 6'],{hi:{0:Y2G}});Y3msg('7 · 23 + 6 = 161 + 6 = <b>167</b>')},
 html:"<p>Bir sonni 7 ga bo'lganda bo'linma 23, qoldiq 6 chiqdi. Bu qaysi son? Formula: bo'linuvchi = bo'luvchi · bo'linma + qoldiq.</p>",
 btns:Y3ch(["161","167","166","173"],1,function(){STEPS[1].fin()},'7 · 23 ni hisoblang va qoldiqni qo‘shing'),g2:1,
 after:"<p>7 · 23 = 161, 161 + 6 = <b>167</b>. Tekshiruv: 167 : 7 = 23 (qoldiq 6) ✓. «161» — qoldiq qo'shilmagan.</p>",
 q:{t:"Bo'linma 15, qoldiq 7. Bo'linuvchi eng kamida nechaga teng bo'lishi mumkin?",opts:["112","127","105","135"],ok:1,why:"Qoldiq 7 bo'lsa, bo'luvchi kamida 8: 8 · 15 + 7 = 127.",hint:"Qoldiq 7 bo'lishi uchun bo'luvchi kamida nechaga teng bo'lishi kerak?",full:"Qoldiq bo'luvchidan kichik: bo'luvchi ≥ 8. Eng kichigi 8 da: 8 · 15 + 7 = 127. «112» — bo'luvchi 7 deb olingan (7 · 15 + 7), lekin unda qoldiq 7 bo'la olmaydi."},
 tn:"Formulani uchburchak shaklida doskaga yozing: bo'linuvchi tepada, bo'luvchi · bo'linma + qoldiq pastda."},
{h:"Qoldiq bilan nima qilamiz?",sum:"Avtobusda 12 o'rin, 50 kishi: 50 : 12 = 4 (qoldiq 2) → 5 ta avtobus kerak. Guldastalar: 68 : 6 = 11 (qoldiq 2) → 11 ta.",a:"m03",start:function(){clear();Y2bus(0);Y3msg('50 kishi, har avtobusda 12 o‘rin. Nechta avtobus kerak?')},fin:function(){Y2bus(1)},
 html:"<p>Ekskursiyaga <b>50 kishi</b> boradi. Har avtobusda <b>12 o'rin</b>. Hamma ketishi uchun nechta avtobus kerak?</p>",
 btns:Y3ch(["4","4 (qoldiq 2)","5","6"],2,function(){Y2bus(1)},'Ortib qolgan 2 kishi qayerda ketadi?'),g2:1,
 after:"<p>50 : 12 = 4 (qoldiq 2). Qolgan 2 kishiga ham joy kerak → <b>5</b> ta avtobus. Lekin «68 gul bilan 6 tadan guldasta» masalasida 68 : 6 = 11 (qoldiq 2) — 2 ta gul ortadi, to'liq guldasta <b>11</b> ta. Savolni diqqat bilan o'qing!</p>",
 q:{t:"Sinfda 29 o'quvchi. Har partaga 2 kishi o'tiradi. Hamma o'tirishi uchun nechta parta kerak?",opts:["14","15","14 (qoldiq 1)","16"],ok:1,why:"29 : 2 = 14 (qoldiq 1): ortgan 1 o'quvchiga ham parta kerak — 15.",hint:"Ortib qolgan o'quvchi qayerga o'tiradi?",full:"29 : 2 = 14 (qoldiq 1). 14 partaga 28 kishi o'tiradi, 1 kishi qoladi — unga ham parta kerak: 15. «14 (qoldiq 1)» — hisob to'g'ri, lekin savolga javob emas."},
 tn:"Ikki ustun: «Yuqoriga yaxlitlaymiz» (avtobus, parta, quti) va «Qoldiqni tashlaymiz» (to'liq guldasta, to'liq quti). Bolalar misol qo'shsin."},
{h:"Hafta kunlari va qoldiq",sum:"Bugun dushanba. 100 = 14 · 7 + 2 → 100 kundan keyin chorshanba.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Bugun dushanba. <b>100 kundan keyin</b> haftaning qaysi kuni bo'ladi? 100 kunni sanab chiqmasdan topamiz.</p>",btns:[phaser(P4)],
 after:"<p>Hafta kunlari har 7 kunda takrorlanadi — faqat <b>qoldiq</b> muhim. 100 : 7 = 14 (qoldiq 2): dushanbadan 2 kun keyin — <b>chorshanba</b>.</p>",
 q:{t:"Bugun juma. 50 kundan keyin qaysi kun bo'ladi?",opts:["Juma","Shanba","Yakshanba","Payshanba"],ok:1,why:"50 = 7 · 7 + 1 → jumadan 1 kun keyin: shanba.",hint:"50 ni 7 ga bo'ling, qoldiqqa qarang.",full:"50 : 7 = 7 (qoldiq 1). 7 haftadan keyin yana juma, +1 kun → shanba. «Juma» — qoldiq hisobga olinmagan."},
 tn:"Devor kalendarida tekshirib ko'ring: bolalar 14 kunni sanab, 2 haftadan keyin kun takrorlanishini ko'rsin."},
{h:"Bo'linmada nol",sum:"2416 : 8 = 302: tushirilgan raqam bo'luvchidan kichik bo'lsa, bo'linmaga 0 yoziladi.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Burchak usulida bo'lishning eng ko'p uchraydigan tuzog'i — bo'linmadagi <b>nol</b>. 2416 : 8 ni bosqichma-bosqich bajaring.</p>",btns:[phaser(P5)],
 after:"<p>Har tushirilgan raqam uchun bo'linmaga bitta raqam yoziladi. 1 < 8 bo'lgani uchun <b>0</b> yozdik. Tekshiruv: avval bo'linmada nechta raqam bo'lishini aniqlang: 24|1|6 → 3 xonali → 302.</p>",
 q:{t:"4536 : 9 = ?",opts:["54","504","540","514"],ok:1,why:"45 : 9 = 5, 3 < 9 → 0, 36 : 9 = 4: 504.",hint:"3 ni tushirganda 9 ga bo'lish mumkinmi?",full:"45 : 9 = 5, qoldiq 0. 3 ni tushiramiz: 3 < 9 → bo'linmaga 0. 36 : 9 = 4. Javob: 504. «54» — nol unutilgan: 54 · 9 = 486 ≠ 4536."},
 tn:"Bo'lishdan oldin bo'linmadagi raqamlar sonini nuqtalar bilan belgilang: «· · ·» — bola nolni tashlab ketmaydi."},
{h:"Ikki xonali songa bo'lish",sum:"864 : 24 = 36: bo'linma raqamini chamalash bilan topamiz (80 : 20 ≈ 4 → ko'p → 3).",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Ikki xonali songa bo'lishda bo'linma raqamini <b>chamalash</b> kerak. 864 : 24 ni bajaring.</p>",btns:[phaser(P6)],
 after:"<p>Chamalash: 24 ni 20 ga, 86 ni 80 ga yaxlitlab 80 : 20 = 4. Tekshiramiz: 24 · 4 = 96 > 86 — ko'p, demak <b>3</b>. Qoldiq 14 < 24 ✓. So'ng 144 : 24 = 6. Javob: <b>36</b>.</p>",
 q:{t:"7248 : 24 = ?",opts:["32","302","312","3020"],ok:1,why:"72 : 24 = 3, 4 < 24 → 0, 48 : 24 = 2: 302.",hint:"72 : 24 dan keyin 4 ni tushiring — 24 ga bo'linadimi?",full:"72 : 24 = 3. 4 ni tushiramiz: 4 < 24 → 0. 48 : 24 = 2. Javob 302. Tekshiruv: 302 · 24 = 7248 ✓. «32» — nol unutilgan."},
 tn:"Bo'luvchining karralilarini chetga yozib qo'ying: 24, 48, 72, 96, 120, 144 — chamalash osonlashadi."},
{h:"Tuzoq: qoldiq bo'yicha izlash",sum:"11 ga bo'lganda qoldiq 9: …, 119, 130, … — 120 dan 126 gacha bunday son yo'q.",a:"m07",start:function(){clear();Y3seq([120,121,122,123,124,125,126]);Y3msg('Qaysi biri 11 ga bo‘linganda 9 qoldiq beradi?')},fin:function(){clear();Y3seq([119,'…',126,'…',130],{hi:{0:Y2G,4:Y2G}});Y3msg('11 · 10 + 9 = 119, 11 · 11 + 9 = 130 — oraliqda <b>hech biri</b> yo‘q')},
 html:"<p>120, 121, …, 126 sonlaridan qaysi biri 11 ga bo'linganda <b>9</b> qoldiq beradi?</p>",
 btns:Y3ch(["120","124","126","Hech biri"],3,function(){STEPS[6].fin()},'Qoldiq 9 bo‘ladigan sonlar: 11 · k + 9. Ularni yozib ko‘ring'),g2:1,
 after:"<p>11 ga bo'lganda 9 qoldiq beradigan sonlar: 9, 20, 31, …, 108, <b>119</b>, <b>130</b>, … 119 dan keyingisi 130 — oraliqqa tushmaydi. Ba'zan to'g'ri javob — «<b>bunday son yo'q</b>».</p>",
 q:{t:"1 dan 100 gacha sonlardan nechtasi 7 ga bo'linganda 3 qoldiq beradi?",opts:["13","14","15","7"],ok:1,why:"3, 10, 17, …, 94: (94 − 3) : 7 + 1 = 14.",hint:"Birinchisi 3, keyin har safar +7. Oxirgisi qaysi?",full:"Sonlar: 3, 10, 17, …, 94 (94 = 7 · 13 + 3). Ular 7 · 0 + 3 dan 7 · 13 + 3 gacha — 14 ta. «13» — 3 sonining o'zi (7 · 0 + 3) unutilgan."},
 tn:"Sonlar o'qida 11 qadamli «sakrash» chizing va qoldiq 9 nuqtalarini belgilang."},
{h:"Olimpiada: ikki shart",sum:"4 ga ham, 5 ga ham bo'lganda qoldiq 3: n − 3 son 20 ga bo'linadi → 23.",a:"m08",start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>Son 4 ga bo'linganda ham, 5 ga bo'linganda ham <b>3</b> qoldiq beradi. 3 dan katta eng kichik shunday son qaysi?</p>",btns:[phaser(P8)],
 after:"<p>Ikki ro'yxatni yozib, umumiy sonni topdik: <b>23</b>. Qisqa yo'l: son − 3 ham 4 ga, ham 5 ga bo'linadi → 20 ga bo'linadi: 20 + 3 = 23. Keyingilari: 43, 63, …</p>",
 q:{t:"Son 3 ga ham, 4 ga ham bo'linganda qoldiq 1 beradi. 1 dan katta eng kichik shunday son qaysi?",opts:["7","13","12","25"],ok:1,why:"n − 1 son 12 ga bo'linadi: 12 + 1 = 13.",hint:"n − 1 son qaysi sonlarga bo'linadi?",full:"n − 1 ham 3 ga, ham 4 ga bo'linadi → 12 ga bo'linadi. Eng kichigi: 12 + 1 = 13. Tekshiruv: 13 = 3 · 4 + 1 = 4 · 3 + 1 ✓. «7» — 7 : 3 qoldiq 1, lekin 7 : 4 qoldiq 3."},
 tn:"Ikki ustunda ro'yxatlarni doskaga yozdiring — umumiy sonni bolalar o'zi topsin."},
{h:"Bilasizmi? Soat arifmetikasi",sum:"Gauss 1801-yilda qoldiqlar arifmetikasini kitobda bayon qilgan. Soat — shunday arifmetika: 9 + 5 = 2.",a:"m09",start:function(){Y2clock(9,0);Y3msg('Soat 9. 5 soatdan keyin soat necha bo‘ladi?')},fin:function(){Y2clock(9,5);Y3msg('Soatda <b>12 ga bo‘lgandagi qoldiq</b> muhim')},
 html:"<p>🕘 Nemis matematigi <b>Karl Fridrix Gauss</b> 1801-yilda chop etilgan kitobida qoldiqlar bilan hisoblashni — «modul bo'yicha arifmetika»ni bayon qilgan. Uni har kuni ishlatamiz: soatga qarang!</p>",
 btns:[["➕ 5 soat",function(c,done){Y2clock(9,5);Y3msg('9 + 5 = 14, lekin soatda <b>2</b>: 14 : 12 qoldiq 2');done()}]],
 after:"<p>Soat 9 + 5 soat = 14 → soat yuzida <b>2</b>. Hafta kunlari — 7 bo'yicha, soat — 12 bo'yicha arifmetika. Bugun u kompyuter va bank kartalarida ham qo'llanadi.</p>",
 tn:"Karton soat bilan: «Soat 10, 7 soatdan keyin?» — bolalar qoldiq bilan hisoblab, keyin strelkani burab tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P5[3]()},fin:function(){P5[3]()},
 html:"<div class='memo'><ul><li><b>Bo'linuvchi = bo'luvchi · bo'linma + qoldiq</b>, qoldiq &lt; bo'luvchi.</li><li>Savolni o'qing: hammaga joy kerakmi (yuqoriga) yoki faqat to'liq guruhlarmi (qoldiqni tashlash)?</li><li>Hafta, soat — qoldiq bo'yicha takrorlanadi.</li><li>Burchakli bo'lishda tushirilgan raqam bo'luvchidan kichik bo'lsa — bo'linmaga <b>0</b>.</li><li>Ikki xonali bo'luvchida — chamalang va ko'paytirib tekshiring.</li><li>Ikki shartli qoldiq: n − qoldiq ikkala songa bo'linadi.</li></ul></div>",
 tn:"Oxirida har o'quvchi bitta bo'lish misolini ko'paytirish bilan tekshirib, sherigiga ko'rsatsin."}
];
function Y2bus(fin){clear();var g=S.g;for(var b=0;b<5;b++){var x=8+b*70,on=b<4||fin;E('rect',{x:x,y:40,width:62,height:38,rx:8,fill:on?(b<4?'#8fb7dc':'#f6c98a'):'#eef2f6',stroke:C.line,'stroke-width':1.4,'stroke-dasharray':on?'':'4 3'},g);E('circle',{cx:x+14,cy:82,r:6,fill:'#333'},g);E('circle',{cx:x+48,cy:82,r:6,fill:'#333'},g);
  T(g,x+31,64,b<4?'12':(fin?'2':'?'),{'font-size':15,'font-weight':800,fill:'#1d2b3a'})}
 T(g,180,124,'50 = 12 · 4 + 2',{'font-size':16,'font-weight':800,fill:C.blue});if(fin){T(g,180,152,'2 kishi uchun ham avtobus → 5 ta',{'font-size':13,'font-weight':800,fill:C.ok});Y3msg('Javob: <b>5</b> ta avtobus')}}
var PROBS=[
{t:"23 : 5 = ?",o:["4 (qoldiq 3)","3 (qoldiq 8)","4 (qoldiq 2)","5 (qoldiq 3)"],k:0,s:"5 · 4 = 20, 23 − 20 = 3."},
{t:"Sonni 7 ga bo'lganda qoldiq eng ko'pi bilan nechaga teng bo'ladi?",o:["6","7","5","3"],k:0,s:"Qoldiq bo'luvchidan kichik."},
{t:"68 ta guldan 6 tadan guldasta tuziladi. Nechta to'liq guldasta chiqadi?",o:["11","12","10","13"],k:0,s:"68 : 6 = 11 (qoldiq 2)."},
{t:"50 kishi ekskursiyaga boradi, har avtobusda 12 o'rin. Nechta avtobus kerak?",o:["5","4","6","3"],k:0,s:"50 : 12 = 4 (qoldiq 2) → 5."},
{t:"Bir sonni 7 ga bo'lganda bo'linma 23, qoldiq 6 chiqdi. Bu qaysi son?",o:["167","161","166","173"],k:0,s:"7 · 23 + 6 = 167."},
{t:"1000 ni 7 ga bo'lganda qoldiq nechaga teng?",o:["6","4","1","3"],k:0,s:"7 · 142 = 994, 1000 − 994 = 6."},
{t:"Bugun dushanba. 100 kundan keyin qaysi kun bo'ladi?",o:["Chorshanba","Seshanba","Payshanba","Dushanba"],k:0,s:"100 = 14 · 7 + 2."},
{t:"2416 : 8 = ?",o:["302","32","320","312"],k:0,s:"24 : 8 = 3, 1 < 8 → 0, 16 : 8 = 2."},
{t:"1500 : 25 = ?",o:["60","6","600","50"],k:0,s:"25 · 60 = 1500."},
{t:"864 : 24 = ?",o:["36","34","38","46"],k:0,s:"86 : 24 = 3 (qoldiq 14), 144 : 24 = 6."},
{t:"4536 : 9 = ?",o:["504","54","540","514"],k:0,s:"45 : 9 = 5, 3 < 9 → 0, 36 : 9 = 4."},
{t:"7248 : 24 = ?",o:["302","32","312","3020"],k:0,s:"72 : 24 = 3, 4 < 24 → 0, 48 : 24 = 2."},
{t:"9 ga bo'lganda qoldiq 5 beradigan eng kichik uch xonali son qaysi?",o:["104","105","100","113"],k:0,s:"9 · 11 + 5 = 104 (9 · 10 + 5 = 95 — ikki xonali)."},
{t:"4 ga ham, 5 ga ham bo'lganda qoldiq 3 beradigan, 3 dan katta eng kichik son qaysi?",o:["23","43","13","8"],k:0,s:"23 − 3 = 20 ikkalasiga bo'linadi."},
{t:"Bo'linma 15, qoldiq 7. Bo'linuvchi eng kamida nechaga teng?",o:["127","112","105","135"],k:0,s:"Bo'luvchi ≥ 8: 8 · 15 + 7 = 127."},
{t:"Sonni 6 ga bo'lganda bo'linma 12, qoldiq esa bo'linmadan 7 ta kam. Bu qaysi son?",o:["77","72","79","65"],k:0,s:"Qoldiq 5: 6 · 12 + 5 = 77."},
{t:"Sonni 9 ga bo'lganda bo'linma ham, qoldiq ham 7 chiqdi. Bu qaysi son?",o:["70","63","77","56"],k:0,s:"9 · 7 + 7 = 70."},
{t:"Son 7 ga bo'linganda qoldiq 4 beradi. Shu sonni 2 ga ko'paytirib, 7 ga bo'lsak, qoldiq nechaga teng?",o:["1","8","4","2"],k:0,s:"Qoldiqlar ham ikkilanadi: 2 · 4 = 8, 8 : 7 qoldiq 1."},
{t:"Soat hozir 9:00. 50 soatdan keyin soat necha bo'ladi?",o:["11:00","9:50","23:00","10:00"],k:0,s:"50 = 2 · 24 + 2 → 9 + 2 = 11."},
{t:"1 dan 100 gacha sonlardan nechtasi 7 ga bo'linganda 3 qoldiq beradi?",o:["14","13","15","7"],k:0,s:"3, 10, …, 94 — 14 ta."}
];
function PRACT_STAGE(){P5[3]()}
var PREP_DATA={teach:["Qoldiqli bo'lish ma'nosi, qoldiq < bo'luvchi.","Bo'linuvchini topish formulasi.","Qoldiqni talqin qilish: yuqoriga yaxlitlash yoki tashlash.","Hafta va soat — qoldiq bo'yicha takrorlanish.","Burchakli bo'lish: bo'linmadagi nol, ikki xonali bo'luvchi va chamalash.","Ikki shartli qoldiq masalalari."],
 mist:["Bo'linmadagi 0 ni tushirib qoldiradi (302 → 32).","Qoldiq bo'luvchidan katta bo'lib qoladi.","Avtobus masalasida qoldiqni tashlab yuboradi (4).","Bo'linuvchini topishda qoldiqni qo'shmaydi (161).","Chamalashda raqam ortiq chiqadi va tekshirmaydi."],
 need:["Cho'plar yoki tugmachalar.","Karton soat, devor kalendari.","Karralilar jadvali (24, 48, 72 …)."],
 board:["<span class='w2'>23 = 5 · 4 + 3</span>, 3 &lt; 5.","<span class='w2'>2416 : 8 = 302</span> (0!).","<span class='w2'>864 : 24 = 36</span>.","<span class='w2'>100 = 14 · 7 + 2</span> → chorshanba."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
