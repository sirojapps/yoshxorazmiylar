var CODE='2E1',TITLE='2-sinf · Uzunlik: mm, sm, dm, m';
// ---------- sahna: chizg'ich ----------
var e1S={x0:20,k:16}; // 1 sm = 16 px (0..20 sm)
function e1Ruler(from,to,obj,o){o=o||{};clear();var g=S.g,x0=e1S.x0,k=e1S.k,y=110;
 E('rect',{x:x0-8,y:y,width:20*k+16,height:44,rx:4,fill:'#fff3c4',stroke:'#c9a764','stroke-width':1.5},g);
 for(var v=0;v<=20;v++){E('line',{x1:x0+v*k,y1:y,x2:x0+v*k,y2:y+14,stroke:'#5b4a1c','stroke-width':1.4},g);T(g,x0+v*k,y+28,String(v),{'font-size':9,fill:'#5b4a1c'});
  if(v<20&&o.mm)for(var m=1;m<10;m++)E('line',{x1:x0+v*k+m*k/10,y1:y,x2:x0+v*k+m*k/10,y2:y+(m===5?10:6),stroke:'#5b4a1c','stroke-width':.5},g)}
 T(g,x0+20*k-4,y+40,'sm',{'font-size':9,fill:'#5b4a1c'});
 if(obj!=null){var a=x0+from*k,b=x0+to*k;E('rect',{x:a,y:y-54,width:b-a-12,height:16,rx:3,fill:o.col||'#f6c343',stroke:'#a07a1c'},g);E('path',{d:'M'+(b-12)+' '+(y-54)+' L'+b+' '+(y-46)+' L'+(b-12)+' '+(y-38)+' Z',fill:'#e8b48a',stroke:'#a07a1c'},g);E('rect',{x:a-6,y:y-54,width:8,height:16,rx:2,fill:'#e87a8a'},g);
  E('line',{x1:a,y1:y-36,x2:a,y2:y+2,stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'3 2'},g);E('line',{x1:b,y1:y-36,x2:b,y2:y+2,stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'3 2'},g)}
 return g}
function e1Hops(from,to,col){var g=S.g,k=e1S.k,x0=e1S.x0;for(var v=from;v<to;v++){E('path',{d:'M'+(x0+v*k)+' 104 Q'+(x0+v*k+k/2)+' 86 '+(x0+(v+1)*k)+' 104',fill:'none',stroke:col||C.blue,'stroke-width':1.4},g);T(g,x0+v*k+k/2,86,String(v-from+1),{'font-size':8,'font-weight':800,fill:col||C.blue})}}
function e1Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// lenta (sm bo'laklari)
function e1Tape(n,lab){clear();var g=S.g,x0=20,w=32;for(var i=0;i<n;i++)E('rect',{x:x0+(i%10)*w,y:40+Math.floor(i/10)*40,width:w-2,height:26,rx:3,fill:i<10?'#8fc6f0':'#f6c343',stroke:'#2b6ca3'},g);
 if(n>=10){Br(x0,x0+10*w-2,74,'10 sm = 1 dm',false,C.ok)}T(g,180,22,lab||(n+' sm'),{'font-size':14,'font-weight':800,fill:C.blue})}
var P2=[function(){e1Ruler(0,9,true);e1Msg('Qalamning bir uchi <b>0</b> da. Ikkinchi uchi qayerda?')},
 function(){e1Ruler(0,9,true);e1Hops(0,9);e1Msg('Har bir oraliq — <b>1 santimetr</b> (1 sm). Sanaymiz: 1, 2, … 9')},
 function(){e1Ruler(0,9,true);e1Hops(0,9,C.ok);e1Msg('Qalam uzunligi — <b>9 sm</b>')}];
var P3=[function(){e1Ruler(3,11,true,{col:'#9ed99a'});e1Msg('Bu qalam <b>0</b> dan emas, <b>3</b> dan boshlanadi. Uzunligi 11 sm mi?')},
 function(){e1Ruler(3,11,true,{col:'#9ed99a'});e1Hops(3,11,C.ok);e1Msg('Oraliqlarni sanaymiz: <b>8 ta</b>. Yoki: 11 − 3 = <b>8 sm</b>')}];
var P4=[function(){e1Ruler(0,0,null);e1Msg('1 sm ichida yana mayda chiziqlar bor — ularni kattalashtiramiz')},
 function(){clear();var g=S.g,x0=30,k=30;E('rect',{x:x0-6,y:60,width:10*k+12,height:50,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);for(var m=0;m<=10;m++){E('line',{x1:x0+m*k,y1:60,x2:x0+m*k,y2:60+(m%5===0?24:14),stroke:'#5b4a1c','stroke-width':m%10===0?2:1},g);T(g,x0+m*k,100,String(m),{'font-size':11,fill:'#5b4a1c'})}T(g,180,40,'1 sm = 10 mm',{'font-size':18,'font-weight':800,fill:C.blue});T(g,180,140,'mm — millimetr: chumolining bo‘yi taxminan 2–5 mm',{'font-size':11,fill:'#5b6b7b'});e1Msg('1 santimetr — <b>10 ta millimetr</b>')}];
var P6=[function(){e1Tape(10,'10 sm');e1Msg('10 ta santimetr — 1 detsimetr (1 dm)')},
 function(){clear();var g=S.g;for(var i=0;i<10;i++){E('rect',{x:20+i*32,y:60,width:30,height:30,rx:3,fill:i%2?'#8fc6f0':'#f6c343',stroke:'#2b6ca3'},g);T(g,35+i*32,80,'1 dm',{'font-size':9,'font-weight':800})}Br(20,338,96,'10 dm = 1 m = 100 sm',false,C.ok);T(g,180,40,'1 metr',{'font-size':16,'font-weight':800,fill:C.blue});e1Msg('10 ta detsimetr — <b>1 metr</b>. 1 m = 10 dm = <b>100 sm</b>')},
 function(){clear();var g=S.g;E('rect',{x:20,y:50,width:280,height:30,rx:4,fill:'#8fc6f0',stroke:'#2b6ca3'},g);T(g,160,70,'Ali: 1 m 20 sm = 120 sm',{'font-size':12,'font-weight':800});E('rect',{x:20,y:100,width:229,height:30,rx:4,fill:'#f6c343',stroke:'#a07a1c'},g);T(g,135,120,'Vali: 98 sm',{'font-size':12,'font-weight':800});E('rect',{x:249,y:100,width:51,height:30,rx:4,fill:'none',stroke:C.bad,'stroke-dasharray':'4 3','stroke-width':2},g);T(g,275,145,'22 sm',{'font-size':12,'font-weight':800,fill:C.bad});e1Msg('Ali 120 sm, Vali 98 sm. Farq: 120 − 98 = <b>22 sm</b>')}];
var P7=[function(){e1Lenta(100,[]);e1Msg('Lenta <b>1 m</b> = 100 sm. Avval 35 sm, keyin 28 sm qirqildi')},
 function(){e1Lenta(100,[35]);e1Msg('100 − 35 = <b>65 sm</b> qoldi')},
 function(){e1Lenta(100,[35,28]);e1Msg('65 − 28 = <b>37 sm</b> qoldi. Diqqat: 1 − 35 deb bo‘lmaydi — avval metrni santimetrga aylantiring!')}];
function e1Lenta(tot,cuts){clear();var g=S.g,x0=20,W=320,used=0;cuts.forEach(function(c,i){E('rect',{x:x0+used*W/tot,y:60,width:c*W/tot,height:30,fill:'#e9e2d6',stroke:'#8a5a24','stroke-dasharray':'4 3'},g);T(g,x0+(used+c/2)*W/tot,80,c+' sm',{'font-size':11,'font-weight':800,fill:'#8a5a24'});used+=c});
 E('rect',{x:x0+used*W/tot,y:60,width:(tot-used)*W/tot,height:30,fill:'#f08aa8',stroke:'#b03060'},g);T(g,x0+(used+(tot-used)/2)*W/tot,80,(tot-used)+' sm',{'font-size':13,'font-weight':800,fill:'#fff'});Br(x0,x0+W,56,'1 m = 100 sm',true)}
var E1OBJ=[['📏 Daftar varag‘ining qalinligi','mm'],['✏️ Qalamning uzunligi','sm'],['🚪 Eshikning balandligi','m'],['📘 Kitobning eni','sm'],['🏫 Sinf xonasining uzunligi','m'],['🐜 Chumolining bo‘yi','mm']];
var STEPS=[
{h:"Qarich bilan o'lchasak…",sum:"Har kimning qarichi har xil — shuning uchun hamma bir xil o'lchov birligi bilan o'lchaydi.",a:"m01",
 start:function(){e1Hands(null)},fin:function(){e1Hands(2)},
 html:"<p>Qadimda uzunlikni <b>qarich</b> bilan o'lchashgan. Stolni ota va bola o'lchadi. Tugmalarni bosib ko'ring:</p>",
 btns:[["✋ Otaning qarichi",function(c,done){e1Hands(1);S.e1a=1;if(S.e1b)done()}],["🤚 Bolaning qarichi",function(c,done){e1Hands(2);S.e1b=1;if(S.e1a)done()},'u']],g2:1,
 after:"<p>Ota — <b>5 qarich</b>, bola — <b>8 qarich</b>. Stol bitta-ku! Qarichlar har xil bo'lgani uchun javob har xil chiqdi. Shuning uchun odamlar <b>hamma uchun bir xil</b> o'lchov birliklarini kelishib olishgan: millimetr, santimetr, detsimetr, metr.</p>",
 q:{t:"Nega ota va bola stolni o'lchaganda har xil javob chiqdi?",opts:["Stol o'zgarib qoldi","Qarichlari har xil uzunlikda","Bola xato sanadi","Ota xato sanadi"],ok:1,why:"O'lchov birligi (qarich) har xil — javob ham har xil.",hint:"Stol bir xil edi. Unda nima har xil edi?",full:"Ikkalasi to'g'ri sanagan. Lekin otaning qarichi katta, bolaniki kichik. Katta birlik kam marta, kichik birlik ko'p marta sig'adi. Shuning uchun hamma bir xil birlikdan foydalanadi."},
 tn:"Bolalar partani o'z qarichi, qalami bilan o'lchab, natijalarni doskaga yozsin — har xil chiqishini o'zlari ko'rsin. Bu standart birlik kerakligini tushuntirishning eng kuchli yo'li."},
{h:"Santimetr va chizg'ich",sum:"Chizg'ichda har bir oraliq — 1 sm. O'lchash 0 dan boshlanadi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Chizg'ichdagi har bir katta oraliq — <b>1 santimetr</b> (1 sm). Qalamni o'lchaymiz. Kuzating:</p>",
 btns:[phaser(P2)],
 after:"<p>Qalamning bir uchini <b>0</b> ga qo'ydik, ikkinchi uchi <b>9</b> da — qalam <b>9 sm</b>. Chizg'ichdagi raqam — 0 dan qancha santimetr ekanini ko'rsatadi.</p>",
 q:{t:"Lentaning bir uchi chizg'ichda 0 da, ikkinchi uchi 14 da. Lenta uzunligi qancha?",opts:["14 sm","15 sm","13 sm","140 sm"],ok:0,why:"0 dan 14 gacha — 14 ta santimetr.",hint:"Boshi 0 da bo'lsa, oxiridagi raqam nimani ko'rsatadi?",full:"0 dan boshlangani uchun oxiridagi raqam — uzunlikning o'zi: 14 sm. «15» — chiziqlarni (0 ni ham) sanagan xato."},
 tn:"Bolalar chiziqlarni emas, oraliqlarni sanashi kerak. 0 dan 3 gacha chiziqlar 4 ta, oraliqlar 3 ta — buni alohida ko'rsating."},
{h:"Tuzoq: 0 dan boshlanmasa",sum:"Narsa 3 dan 11 gacha bo'lsa: uzunlik 11 − 3 = 8 sm (11 emas).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Chizg'ichning boshi singan bo'lsa yoki narsa 0 ga qo'yilmasa-chi? Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>Narsa <b>3</b> dan <b>11</b> gacha: uzunlik — <b>11 − 3 = 8 sm</b>. Oxirgi raqamni o'qib «11 sm» deyish — eng ko'p uchraydigan xato.</p>",
 q:{t:"Tayoq chizg'ichda 4 dan 13 gacha joylashgan. Uzunligi qancha?",opts:["13 sm","17 sm","9 sm","10 sm"],ok:2,why:"13 − 4 = 9 sm.",hint:"Boshi 0 da emas. Oxiridan boshini ayiring.",full:"Boshi 4 da, oxiri 13 da. Uzunlik — oraliqlar soni: 13 − 4 = 9 sm. «13» — boshini hisobga olmagan, «10» — chiziqlarni sanagan."},
 tn:"Bankdagi «Xonqizi tayoqning boshidan 17 sm yurdi…» kabi masalalar shu ko'nikmaga tayanadi."},
{h:"Millimetr",sum:"1 sm = 10 mm. 3 sm 4 mm = 34 mm.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Juda kichik narsalar uchun santimetr katta. 1 sm ni kattalashtirib ko'raylik:</p>",
 btns:[phaser(P4,'🔍 Kattalashtirish')],
 after:"<p>1 sm ichida <b>10 ta millimetr</b> (mm) bor. Chizg'ichdagi mayda chiziqlar — millimetrlar. <b>3 sm 4 mm = 30 mm + 4 mm = 34 mm</b>.</p>",
 q:{t:"5 sm 2 mm necha millimetr?",opts:["7 mm","52 mm","502 mm","25 mm"],ok:1,why:"5 sm = 50 mm, yana 2 mm: 52 mm.",hint:"1 sm da 10 mm. 5 sm da nechta?",full:"5 sm = 50 mm. 50 + 2 = 52 mm. «7» — sonlarni shunchaki qo'shgan, «502» — yonma-yon yozgan."},
 tn:"Daftar katagi — taxminan 5 mm, bu mm ni his qilishga yordam beradi."},
{h:"Detsimetr: 10 ta santimetr",sum:"10 sm = 1 dm. 4 dm = 40 sm.",a:"m05",
 start:function(){S.e1n=0;e1Tape(0,'0 sm');e1Msg('Santimetrlarni qo‘shing')},fin:function(){e1Tape(10,'10 sm = 1 dm')},
 html:"<p>Santimetr bo'laklarini birma-bir qo'shing. 10 taga yetganda nima bo'ladi?</p>",
 btns:[["+ 1 sm",function(c,done,b){if(S.e1n<10){S.e1n++;e1Tape(S.e1n,S.e1n+' sm'+(S.e1n===10?' = 1 dm':''));e1Msg(S.e1n<10?S.e1n+' sm':'10 sm = <b>1 detsimetr</b> (1 dm)');if(S.e1n===10){b.disabled=true;done()}}}]],
 after:"<p><b>10 sm = 1 dm</b> (detsimetr). 2A1 dagi qoida yana ishladi: 10 ta kichik birlik — 1 ta katta birlik. 4 dm = 40 sm, 1 dm 6 sm = 16 sm.</p>",
 q:{t:"Simning uzunligi 9 dm edi. Undan 4 dm 5 sm qirqildi. Necha santimetr qoldi?",opts:["5 sm","55 sm","45 sm","50 sm"],ok:2,why:"90 sm − 45 sm = 45 sm.",hint:"Avval hammasini santimetrga aylantiring: 9 dm = ? sm.",full:"9 dm = 90 sm. 4 dm 5 sm = 45 sm. 90 − 45 = 45 sm. «5» — faqat detsimetrlarni ayirgan, santimetrni unutgan."},
 tn:"Darslikda dm, sm, mm bir darsda keladi. Qog'oz tasmadan 1 dm lik o'lchagich yasatib, 10 qismga bo'ldiring."},
{h:"Metr",sum:"1 m = 10 dm = 100 sm. 1 m 20 sm = 120 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Katta uzunliklar — xona, eshik, bo'y — metr bilan o'lchanadi. Kuzating:</p>",
 btns:[phaser(P6)],
 after:"<p><b>1 m = 10 dm = 100 sm</b>. Bo'ylarni solishtirish uchun ikkalasini <b>bir xil birlikka</b> (santimetrga) keltiramiz: 1 m 20 sm = 120 sm, 120 − 98 = 22 sm.</p>",
 q:{t:"Arqon 60 dm. Undan 2 m kesib olindi. Necha metr arqon qoldi?",opts:["58 m","40 m","4 m","8 m"],ok:2,why:"60 dm = 6 m, 6 − 2 = 4 m.",hint:"60 dm necha metr? 10 dm = 1 m.",full:"60 dm = 6 m. 6 m − 2 m = 4 m. «58» — dm dan m ni to'g'ridan-to'g'ri ayirgan, «40» — javobni detsimetrda yozgan."},
 tn:"Sinfda 1 m lik ip bilan bolalar bo'yini o'lchang: «1 m va yana necha santimetr?»"},
{h:"Tuzoq: har xil birliklar bilan amal",sum:"1 m − 35 sm − 28 sm: avval 100 sm ga aylantiramiz → 65 → 37 sm.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Masala: <i>«Lenta 1 m edi. Avval 35 sm, keyin 28 sm qirqib olindi. Necha santimetr qoldi?»</i></p>",
 btns:[phaser(P7,'✂️ Qirqish')],
 after:"<p>Qoida: <b>har xil birliklar bilan amal bajarishdan oldin ularni bir xil birlikka keltiring</b>. 1 m = 100 sm, keyin 100 − 35 − 28 = 37 sm.</p>",
 q:{t:"Ip 1 m. Undan har biri 25 sm dan 3 ta bo'lak qirqildi. Necha santimetr qoldi?",opts:["75 sm","97 sm","25 sm","50 sm"],ok:2,why:"3 · 25 = 75 sm qirqildi, 100 − 75 = 25 sm.",hint:"Avval qirqilgan bo'laklar jami nechta santimetr?",full:"3 ta bo'lak: 25 + 25 + 25 = 75 sm. 1 m = 100 sm. 100 − 75 = 25 sm. «75» — qirqilganini javob deb yozgan, «97» — 1 m ni 100 sm ga aylantirmagan."},
 tn:"Bolalar har masalada avval «hammasini santimetrga» degan qadamni yozsin."},
{h:"Qaysi birlik mos keladi?",sum:"Mayda narsa — mm, qo'lda ushlanadigan — sm, xona va bino — m.",a:"m08",
 start:function(){S.e1i=0;e1Obj(null)},fin:function(){e1Obj(2)},
 html:"<p>Har bir narsani qaysi birlikda o'lchash qulay? Tugmani bosib, narsalarni ko'ring:</p>",
 btns:[["🔄 Keyingi narsa",function(c,done){e1Obj(S.e1i%E1OBJ.length);S.e1i++;mvK(done,4)}]],
 after:"<p>Mayda narsalar (qalinlik, chumoli) — <b>mm</b>; qo'lda ushlanadigan narsalar — <b>sm</b>; xona, eshik, daraxt — <b>m</b>. Katta masofalar (shaharlar orasi) uchun esa <b>km</b> bor — uni «Ming va kilometr» mavzusida o'rganasiz.</p>",
 q:{t:"Sinf xonasining uzunligini qaysi birlikda o'lchash qulay?",opts:["mm","sm","m","dm"],ok:2,why:"Xona katta — metr qulay.",hint:"Xona qalamdan ancha katta. Katta narsalar uchun qaysi birlik?",full:"Xona uzunligi bir necha metr. Santimetrda yozsak, son juda katta chiqadi (masalan 800 sm), millimetrda esa yanada katta. Shuning uchun metr qulay."},
 tn:"«Taxmin qil — o'lcha» o'yini: bola avval taxmin aytadi, keyin o'lchaydi. Taxmin qilish ko'nikmasi xalqaro dasturlarda alohida o'rgatiladi."},
{h:"Bilasizmi? Metr qayerdan kelgan",sum:"Metr 1790-yillarda Fransiyada Yer o'lchami asosida kiritilgan.",a:"m09",
 start:function(){e1Earth()},fin:function(){e1Earth()},
 html:"<p>🌍 Qadimda har yurtda o'z o'lchovi bo'lgan: qarich, quloch, gaz, qadam. Savdogarlar doim tortishgan! 1790-yillarda Fransiya olimlari hamma uchun bir xil birlik — <b>metr</b>ni taklif qilishdi.</p><p>📏 Metr Yer o'lchamidan olingan: shimoliy qutbdan ekvatorgacha bo'lgan masofaning o'n milliondan bir qismi. Bugun metrdan deyarli butun dunyo foydalanadi.</p><p>🧵 Bizda ham qadimda mato <b>gaz</b> bilan, uzunlik <b>qarich</b> va <b>quloch</b> bilan o'lchangan.</p>",
 tn:"Bolalardan uydagi kattalardan qadimgi o'lchovlar (qarich, quloch, gaz) haqida so'rab kelishni topshiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e1Ruler(0,9,true);e1Msg('<b>1 m = 10 dm = 100 sm</b>, 1 dm = 10 sm, 1 sm = 10 mm')},fin:function(){e1Ruler(0,9,true);e1Msg('<b>1 m = 10 dm = 100 sm</b>, 1 dm = 10 sm, 1 sm = 10 mm')},
 html:"<div class='memo'><ul><li><b>1 sm = 10 mm</b>, <b>1 dm = 10 sm</b>, <b>1 m = 10 dm = 100 sm</b>.</li><li>O'lchash: narsaning boshini chizg'ichning <b>0</b> iga qo'ying, oraliqlarni sanang.</li><li>Boshi 0 da bo'lmasa: <b>oxiri − boshi</b> (3 dan 11 gacha = 8 sm).</li><li>Aylantirish: 3 sm 4 mm = 34 mm; 1 m 20 sm = 120 sm; 60 dm = 6 m.</li><li>Amaldan oldin <b>bir xil birlikka</b> keltiring: 1 m − 35 sm = 100 − 35 = 65 sm.</li><li>Mayda — mm, o'rta — sm, katta — m.</li></ul></div>",
 tn:"Keyingi darsni «2 dm 5 sm va 30 sm — qaysi biri uzun?» savoli bilan boshlang."}
];
function e1Hands(w){clear();var g=S.g;E('rect',{x:20,y:60,width:320,height:20,rx:4,fill:'#c98b45',stroke:'#8a5a24'},g);E('rect',{x:30,y:80,width:10,height:60,fill:'#a0703c'},g);E('rect',{x:320,y:80,width:10,height:60,fill:'#a0703c'},g);T(g,180,52,'stol',{'font-size':12,fill:'#8a5a24'});
 if(w){var n=w===1?5:8,ww=320/n;for(var i=0;i<n;i++){E('path',{d:'M'+(20+i*ww+3)+' 96 Q'+(20+i*ww+ww/2)+' '+(w===1?70:80)+' '+(20+(i+1)*ww-3)+' 96',fill:'none',stroke:w===1?C.blue:C.a2,'stroke-width':2.5},g);T(g,20+i*ww+ww/2,114,String(i+1),{'font-size':12,'font-weight':800,fill:w===1?C.blue:C.a2})}
  e1Msg(w===1?'Ota: <b>5 qarich</b>':'Bola: <b>8 qarich</b>')}else e1Msg('Stol uzunligini qarich bilan o‘lchaymiz')}
function e1Obj(i){clear();var g=S.g;if(i==null){T(g,180,90,'?',{'font-size':40,'font-weight':800,fill:'#9aa8b6'});e1Msg('Tugmani bosing');return}var o=E1OBJ[i];T(g,180,70,o[0],{'font-size':16,'font-weight':800,fill:'#1d2b3a'});T(g,180,120,o[1],{'font-size':40,'font-weight':800,fill:C.ok});e1Msg(o[0]+' — <b>'+o[1]+'</b>')}
function e1Earth(){clear('#eef6ff');var g=S.g;E('circle',{cx:120,cy:90,r:62,fill:'#8fc6f0',stroke:'#2b6ca3','stroke-width':2},g);E('path',{d:'M120 28 A62 62 0 0 1 182 90',fill:'none',stroke:C.bad,'stroke-width':4},g);T(g,120,22,'qutb',{'font-size':10,fill:'#1d2b3a'});T(g,200,94,'ekvator',{'font-size':10,'text-anchor':'start',fill:'#1d2b3a'});E('line',{x1:58,y1:90,x2:182,y2:90,stroke:'#2b6ca3','stroke-dasharray':'4 3'},g);T(g,280,80,'1 m =',{'font-size':16,'font-weight':800,fill:C.blue});T(g,280,104,'qizil yoyning',{'font-size':11});T(g,280,120,'10 000 000 dan biri',{'font-size':11});e1Msg('Metr — Yer o‘lchamidan olingan birlik')}
var PROBS=[
{t:"1 dm necha santimetr?",o:["10 sm","100 sm","1 sm","20 sm"],k:0,s:"1 dm = 10 sm."},
{t:"1 m necha santimetr?",o:["100 sm","10 sm","1000 sm","60 sm"],k:0,s:"1 m = 10 dm = 100 sm."},
{t:"4 sm necha millimetr?",o:["40 mm","4 mm","400 mm","14 mm"],k:0,s:"1 sm = 10 mm, 4 sm = 40 mm."},
{t:"3 dm 7 sm necha santimetr?",o:["37 sm","10 sm","307 sm","370 sm"],k:0,s:"3 dm = 30 sm, 30 + 7 = 37 sm."},
{t:"Qalam chizg'ichda 2 dan 9 gacha joylashgan. Uning uzunligi?",o:["7 sm","9 sm","11 sm","8 sm"],k:0,s:"9 − 2 = 7 sm."},
{t:"Qaysi uzunlik eng katta?",o:["1 m","95 sm","9 dm","90 mm"],k:0,s:"1 m = 100 sm; 95 sm; 9 dm = 90 sm; 90 mm = 9 sm. Eng kattasi 1 m."},
{t:"Alining bo'yi 1 m 20 sm, Valiniki 98 sm. Kim baland va qanchaga?",o:["Ali, 22 sm","Vali, 22 sm","Ali, 78 sm","Teng"],k:0,s:"120 − 98 = 22 sm, Ali baland."},
{t:"Lenta 1 m edi. Avval 35 sm, keyin 28 sm qirqildi. Necha santimetr qoldi?",o:["37 sm","63 sm","47 sm","43 sm"],k:0,s:"100 − 35 − 28 = 37 sm."},
{t:"Sim 9 dm edi. Undan 4 dm 5 sm qirqildi. Necha santimetr qoldi?",o:["45 sm","55 sm","5 sm","50 sm"],k:0,s:"90 − 45 = 45 sm."},
{t:"Arqon 60 dm. Undan 2 m kesildi. Necha metr qoldi?",o:["4 m","58 m","40 m","8 m"],k:0,s:"60 dm = 6 m, 6 − 2 = 4 m."},
{t:"Ip 1 m. Undan 25 sm dan 3 ta bo'lak qirqildi. Necha santimetr qoldi?",o:["25 sm","75 sm","97 sm","50 sm"],k:0,s:"100 − 75 = 25 sm."},
{t:"Kesma 58 sm. Uning bir bo'lagi 34 sm. Ikkinchi bo'lagining yarmi necha santimetr?",o:["12 sm","24 sm","17 sm","46 sm"],k:0,s:"58 − 34 = 24 sm, yarmi 12 sm."},
{t:"Zinaning har pog'onasi 20 sm. 10 ta pog'ona necha metr?",o:["2 m","1 m","20 m","30 sm"],k:0,s:"10 · 20 = 200 sm = 2 m."},
{t:"Birinchi kesma 1 dm 4 sm, ikkinchisi undan 3 sm uzun. Ikkinchi kesma necha santimetr?",o:["17 sm","11 sm","43 sm","7 sm"],k:0,s:"1 dm 4 sm = 14 sm, 14 + 3 = 17 sm."},
{t:"Daftarning qalinligini qaysi birlikda o'lchash qulay?",o:["mm","m","dm","km"],k:0,s:"Daftar yupqa — millimetr qulay."},
{t:"Qaysi yozuv to'g'ri?",o:["2 dm = 20 sm","2 dm = 2 sm","2 dm = 200 sm","2 dm = 12 sm"],k:0,s:"1 dm = 10 sm, 2 dm = 20 sm."},
{t:"Qaysi qatorda uzunliklar o'sish tartibida?",o:["9 sm, 1 dm 2 sm, 15 sm","1 dm 2 sm, 9 sm, 15 sm","9 sm, 15 sm, 1 dm 2 sm","15 sm, 9 sm, 1 dm 2 sm"],k:0,s:"1 dm 2 sm = 12 sm: 9 < 12 < 15."},
{t:"Bir qadam 50 sm. 6 qadam necha metr?",o:["3 m","6 m","300 m","30 m"],k:0,s:"6 · 50 = 300 sm = 3 m."},
{t:"Tasma 8 dm. Uni 4 ta teng bo'lakka qirqishdi. Har bo'lak necha santimetr?",o:["20 sm","2 sm","32 sm","4 sm"],k:0,s:"8 dm = 80 sm, 80 : 4 = 20 sm."},
{t:"Yo'lakning uzunligi 7 m. Bola 3 m 40 sm yurdi. Yana necha santimetr yurishi kerak?",o:["360 sm","460 sm","4 m","340 sm"],k:0,s:"7 m = 700 sm, 3 m 40 sm = 340 sm, 700 − 340 = 360 sm."}
];
function PRACT_STAGE(){e1Ruler(0,9,true);e1Msg('<b>1 m = 10 dm = 100 sm</b>, 1 dm = 10 sm, 1 sm = 10 mm')}
var PREP_DATA={teach:["Standart o'lchov birligi nega kerak (qarich tajribasi).","Chizg'ich bilan o'lchash; 0 dan boshlanmaganda oxiri − boshi.","mm, sm, dm, m va ular orasidagi bog'lanish; aylantirish.","Har xil birliklar bilan amal: avval bir xil birlikka keltirish."],
 mist:["Chiziqlarni sanaydi, oraliqlarni emas (natija 1 ta ko'p).","Narsa 0 da bo'lmasa, oxirgi raqamni uzunlik deb o'qiydi.","1 m − 35 sm ni «1 − 35» deb hisoblashga urinadi.","3 dm 7 sm ni 307 deb yozadi."],
 need:["Chizg'ich, 1 m lik ip yoki lenta, qog'oz tasma (1 dm)."],
 board:["<span class='w2'>1 sm = 10 mm</span>, <span class='w2'>1 dm = 10 sm</span>, <span class='w2'>1 m = 10 dm = 100 sm</span>.","O'lchash: <span class='w2'>0 → 9</span> = 9 sm; <span class='w2'>3 → 11</span> = 8 sm.","<span class='w2'>1 m 20 sm = 120 sm</span>.","<span class='w2'>1 m − 35 sm − 28 sm = 100 − 35 − 28 = 37 sm</span>.","mm — mayda, sm — o'rta, m — katta."]};
