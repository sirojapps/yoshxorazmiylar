var CODE='3G8',TITLE='3-sinf · Hajm birliklari va ular orasidagi bog‘lanish';
// kubiklardan quti: a×b asos, h qavat; layers — nechta qavat qo'yilgan
function g8Stack(a,b,h,layers,s,ox,oy){clear('#ffffff');s=s||22;ox=ox||100;oy=oy||150;var d=s*0.45,dy=s*0.3;
 // bo'sh quti chizig'i
 var W=a*s,D=b,H=h*s;E('path',{d:'M'+ox+' '+oy+' h'+W+' l'+(b*d)+' '+(-b*dy)+' v'+(-H)+' M'+ox+' '+oy+' v'+(-H)+' l'+(b*d)+' '+(-b*dy)+' h'+W+' M'+(ox+W)+' '+oy+' v'+(-H)+' l'+(b*d)+' '+(-b*dy),fill:'none',stroke:'#9aa8b6','stroke-width':1.2,'stroke-dasharray':'4 3'},S.g);
 for(var z=0;z<layers;z++)for(var y=b-1;y>=0;y--)for(var x=0;x<a;x++){g3Cube(ox+x*s+y*d,oy-z*s-y*dy,s,z%2?{front:'#f6c98a',top:'#fbe0b4',side:'#e0a35f'}:{})}}
var P2=[function(){g8Stack(4,3,3,0);g3Msg('Quti: bo‘yi 4 sm, eni 3 sm, balandligi 3 sm. Ichiga nechta 1 sm³ kubik sig‘adi?')},
 function(){g8Stack(4,3,3,1);g3Msg('1-qavat: 4 · 3 = <b>12</b> kubik')},
 function(){g8Stack(4,3,3,2);g3Msg('2 qavat: 12 · 2 = <b>24</b>')},
 function(){g8Stack(4,3,3,3);g3Msg('3 qavat: 12 · 3 = <b>36 sm³</b>. Hajm = bo‘yi · eni · balandligi')}];
function g8Big(stage){clear('#ffffff');var g=S.g;
 if(stage===0){g3Cube(150,120,26);T(g,163,150,'1 sm³',{'font-size':12,'font-weight':800,fill:C.t1});g3Msg('Bitta kubik — 1 sm³')}
 if(stage===1){for(var i=0;i<10;i++)g3Cube(40+i*12,120,12);T(g,100,146,'1 qator: 10 sm³',{'font-size':12,'font-weight':800,fill:C.t1});g3Msg('Bir qatorda <b>10</b> ta')}
 if(stage===2){for(var y=9;y>=0;y--)for(var x=0;x<10;x++)g3Cube(40+x*12+y*5.4,130-y*3.6,12);T(g,110,160,'1 qavat: 10 · 10 = 100 sm³',{'font-size':12,'font-weight':800,fill:C.t1});g3Msg('Bir qavatda <b>100</b> ta')}
 if(stage===3){g3Box(110,150,110,110,110,{front:'#f2b766',top:'#f6c98a',side:'#d9954a'});for(var k=1;k<10;k++){g3Line([110,150-k*11],[220,150-k*11],{w:.6,c:C.line});g3Line([110+k*11,150],[110+k*11,40],{w:.6,c:C.line})}T(g,322,90,'10 qavat',{'font-size':12,'font-weight':800,fill:C.t1});T(g,322,108,'= 1 000 sm³',{'font-size':13,'font-weight':800,fill:C.bad});g3Msg('<b>1 dm³ = 1 000 sm³</b> (10 · 10 · 10)')}}
var P3=[function(){g8Big(0)},function(){g8Big(1)},function(){g8Big(2)},function(){g8Big(3)}];
function g8Jar(ml,stone){clear('#ffffff');var g=S.g,x=140,y=20,w=80,h=140,lvl=h*(ml/1000);
 E('rect',{x:x,y:y+h-lvl,width:w,height:lvl,fill:'rgba(90,169,230,.45)'},g);E('path',{d:'M'+x+' '+y+' v'+h+' h'+w+' v'+(-h),fill:'none',stroke:'#33475b','stroke-width':2.5},g);
 for(var k=1;k<10;k++){g3Line([x+w,y+h-k*h/10],[x+w+8,y+h-k*h/10],{w:1.2});if(k%2===0)T(g,x+w+12,y+h-k*h/10+4,k*100+' ml',{'font-size':9,fill:'#5b6b7b','text-anchor':'start'})}
 if(stone)E('ellipse',{cx:x+w/2,cy:y+h-12,rx:18,ry:11,fill:'#8a8f98',stroke:'#4b5059','stroke-width':1.5},g);
 T(g,x-10,y+h-lvl+4,ml+' ml',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
var P7=[function(){clear('#ffffff');g3Box(90,140,160,70,60,{la:'bo‘yi 16 dm',lc:'10 dm',lb:'eni ?'});g3Msg('Idishga roppa-rosa <b>1 920 litr</b> suv sig‘adi. Eni qancha?')},
 function(){clear('#ffffff');g3Box(90,140,160,70,60,{la:'bo‘yi 16 dm',lc:'10 dm',lb:'eni ?'});g3Msg('1 l = 1 dm³, demak hajm <b>1 920 dm³</b>')},
 function(){clear('#ffffff');g3Box(90,140,160,70,60,{la:'bo‘yi 16 dm',lc:'10 dm',lb:'eni ?'});g3Msg('Bir qavat (balandlik 1 dm): 1 920 : 10 = <b>192 dm³</b>')},
 function(){clear('#ffffff');g3Box(90,140,160,70,60,{la:'bo‘yi 16 dm',lc:'10 dm',lb:'eni 12 dm'});g3Msg('Eni: 192 : 16 = <b>12 dm</b>. Tekshiramiz: 16 · 12 · 10 = 1 920 ✓')}];
var STEPS=[
{h:"Hajm — ichiga qancha sig'adi",sum:"Hajm — jism egallagan joy: nechta birlik kubik sig'ishi.",a:"m01",
 start:function(){S.lay=0;g8Stack(3,2,3,0);g3Msg('Qutiga kubiklarni qavatlab joylang')},fin:function(){g8Stack(3,2,3,3);g3Msg('3 · 2 · 3 = <b>18</b> kubik')},
 html:"<p>Yuz — tekis shaklning o'lchovi, <b>hajm</b> esa jismning: uning ichiga nechta <b>birlik kubik</b> sig'adi. Qutiga kubiklarni qavatlab joylang.</p>",
 btns:[["＋ Qavat qo'yish",function(c,done,b){if(S.lay<3){S.lay++;g8Stack(3,2,3,S.lay);g3Msg('Qavatlar: <b>'+S.lay+'</b> · kubiklar: <b>'+(6*S.lay)+'</b>');if(S.lay===3){b.disabled=true;done()}}}]],
 after:"<p>Bir qavatda 3 · 2 = <b>6</b> kubik, 3 qavatda 6 · 3 = <b>18</b>. Bittalab sanash shart emas: <b>asos yuzi × balandlik</b>.</p>",
 q:{t:"Bir qavatda 8 ta kubik, 5 qavat. Hammasi nechta kubik?",opts:["13","40","35","85"],ok:1,why:"8 · 5 = 40.",hint:"Har qavatda bir xil sondagi kubik. Qavatlar sonini ko'paytiring.",full:"Har qavatda 8 ta, 5 qavat: 8 · 5 = 40. «13» — qo'shib yuborilgan (8 + 5)."},
 tn:"Bolalarga gugurt qutisi va kichik kubiklar (yoki shakar bo'laklari) berib, qutini to'ldirtiring."},
{h:"Kub santimetr va formula",sum:"1 sm³ — qirrasi 1 sm bo'lgan kub. Hajm = bo'yi · eni · balandligi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Qirrasi <b>1 sm</b> bo'lgan kubikning hajmi — <b>1 kub santimetr</b> (1 sm³). Qutini qavatlab to'ldirib, formula chiqaramiz.</p>",
 btns:[phaser(P2,'▶ Qavat')],
 after:"<p><b>Hajm = bo'yi · eni · balandligi</b>: 4 · 3 · 3 = 36 sm³. Birligi — <b>kub</b> birlik (sm³), kvadrat emas!</p>",
 q:{t:"Bo'yi 5 sm, eni 2 sm, balandligi 3 sm bo'lgan qutining hajmi?",opts:["10 sm³","30 sm³","30 sm²","15 sm³"],ok:1,why:"5 · 2 · 3 = 30 sm³.",hint:"Uchala o'lchamni ko'paytiring.",full:"Hajm = 5 · 2 · 3 = 30 sm³. «10» — faqat asos yuzi, «30 sm²» — birligi noto'g'ri, hajm kub birlikda."},
 tn:"Formula bilan birga «qavatlar» tasavvurini saqlang: asos yuzi — bir qavatdagi kubiklar soni."},
{h:"1 dm³ = 1 000 sm³",sum:"Qirrasi 1 dm kubga 10 · 10 · 10 = 1 000 ta sm³ sig'adi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Qirrasi <b>1 dm = 10 sm</b> bo'lgan kub ichiga nechta 1 sm³ sig'adi? Qator → qavat → kub.</p>",
 btns:[phaser(P3,'▶ Yig‘ish')],
 after:"<p>Qatorda 10, qavatda 100, 10 qavatda <b>1 000</b>. Demak <b>1 dm³ = 1 000 sm³</b>. Hajm birliklari <b>1 000 barobardan</b> o'zgaradi!</p>",
 q:{t:"3 dm³ necha sm³?",opts:["30 sm³","300 sm³","3 000 sm³","1 003 sm³"],ok:2,why:"3 · 1 000 = 3 000.",hint:"1 dm³ da nechta sm³ bor — 10, 100 yoki 1 000?",full:"1 dm³ = 1 000 sm³. 3 dm³ = 3 000 sm³. «30» — uzunlik qoidasi, «300» — yuz qoidasi qo'llangan."},
 tn:"1 dm³ li karton kub yasang (tomoni 10 sm) — u 1 litrli suv idishiga teng ekanini keyingi qadamda ko'rsatasiz."},
{h:"Tuzoq: ×10, ×100, ×1 000",sum:"Uzunlik ×10, yuz ×100, hajm ×1 000: 1 dm = 10 sm, 1 dm² = 100 sm², 1 dm³ = 1 000 sm³.",a:"m04",
 start:function(){clear('#ffffff');g3Msg('Uchala o‘lchovni solishtiring')},fin:function(){g4Tri(3)},
 html:"<p>Bitta «1 dm» uch xil narsani o'lchashi mumkin. Tugmalarni bosing:</p>",
 btns:[["📏 Uzunlik",function(c,done){g4Tri(1);mvK(done,3)}],["▦ Yuz",function(c,done){g4Tri(2);mvK(done,3)}],["🧊 Hajm",function(c,done){g4Tri(3);mvK(done,3)}]],g3:1,
 after:"<div class='life'><div>📏<span>uzunlik: 1 dm = <b>10</b> sm</span></div><div>▦<span>yuz: 1 dm² = <b>100</b> sm²</span></div><div>🧊<span>hajm: 1 dm³ = <b>1 000</b> sm³</span></div></div>",
 q:{t:"Qaysi yozuv noto'g'ri?",opts:["1 dm³ = 1 000 sm³","1 dm² = 100 sm²","1 dm³ = 100 sm³","1 dm = 10 sm"],ok:2,why:"Hajmda ×1 000: 1 dm³ = 1 000 sm³.",hint:"Hajm birliklari nechtadan o'zgaradi?",full:"1 dm³ = 1 000 sm³ — to'g'ri, 1 dm³ = 100 sm³ — noto'g'ri (bu yuz qoidasi). Qolganlari to'g'ri."},
 tn:"Doskada uch ustun: «×10 | ×100 | ×1 000». Bolalar misollarni ustunlarga ajratsin."},
{h:"Litr va millilitr",sum:"1 l = 1 dm³, 1 ml = 1 sm³, 1 l = 1 000 ml.",a:"m05",
 start:function(){g8Jar(0);g3Msg('Idishga suv quying')},fin:function(){g8Jar(1000);g3Msg('1 000 ml = 1 l = 1 dm³')},
 html:"<p>Suyuqliklar <b>litr</b> (l) va <b>millilitr</b> (ml) da o'lchanadi. 1 dm³ li kubga roppa-rosa <b>1 litr</b> suv sig'adi. Idishni to'ldiring:</p>",
 btns:[["💧 +250 ml",function(c,done,b){S.ml=(S.ml||0)+250;if(S.ml>1000)S.ml=250;g8Jar(S.ml);g3Msg(S.ml+' ml'+(S.ml===1000?' = <b>1 litr</b> = 1 dm³':''));if(S.ml===1000)done()}]],
 after:"<p><b>1 l = 1 dm³ = 1 000 ml</b>, <b>1 ml = 1 sm³</b>. Choy qoshig'i — taxminan 5 ml, stakan — 250 ml, chelak — 10 l.</p>",
 q:{t:"Akvariumning bo'yi 50 sm, eni 30 sm, balandligi 40 sm. Unga necha litr suv sig'adi?",opts:["6 l","60 l","600 l","120 l"],ok:1,why:"50 · 30 · 40 = 60 000 sm³ = 60 l.",hint:"Hajmni sm³ da toping, keyin 1 l = 1 000 sm³ ekanini eslang.",full:"Hajm: 50 · 30 · 40 = 60 000 sm³. 1 l = 1 000 sm³, 60 000 : 1 000 = 60 l. Yoki dm da: 5 · 3 · 4 = 60 dm³ = 60 l."},
 tn:"Sinfga 1 litrli shisha va 250 ml li stakan olib keling — bolalar 4 stakan suv quyib, shishani to'ldirsin."},
{h:"Kub metr",sum:"1 m³ = 1 000 dm³ = 1 000 litr. Xona havosi, tuproq, beton — m³ da.",a:"m06",
 start:function(){clear('#ffffff');g3Box(100,150,120,120,120,{front:'#e3f0fb',la:'1 m',lc:'1 m',lb:'1 m'});g3Msg('Qirrasi 1 m bo‘lgan kub')},fin:function(){clear('#ffffff');g3Box(100,150,120,120,120,{front:'#e3f0fb',la:'1 m',lc:'1 m',lb:'1 m'});T(S.g,300,70,'1 000 l',{'font-size':18,'font-weight':800,fill:C.blue});g3Msg('<b>1 m³ = 1 000 dm³ = 1 000 l</b>')},
 html:"<p>Katta hajmlar uchun — <b>kub metr</b> (m³): qirrasi 1 m bo'lgan kub. Unga necha litr suv sig'adi?</p>",
 btns:[["🧮 Hisoblash",function(c,done){clear('#ffffff');g3Box(100,150,120,120,120,{front:'#e3f0fb',la:'10 dm',lc:'10 dm',lb:'10 dm'});T(S.g,300,70,'10·10·10',{'font-size':14,'font-weight':800,fill:C.blue});T(S.g,300,92,'= 1 000 dm³',{'font-size':14,'font-weight':800,fill:C.bad});g3Msg('1 m = 10 dm → 10 · 10 · 10 = <b>1 000 dm³ = 1 000 l</b>');done()}]],
 after:"<p>Bitta kub metrga <b>1 000 litr</b> suv sig'adi — bu 100 ta chelak! Uy suv hisoblagichi m³ ni ko'rsatadi.</p>",
 q:{t:"2 m³ necha litr?",opts:["20 l","200 l","2 000 l","2 l"],ok:2,why:"1 m³ = 1 000 l, 2 · 1 000 = 2 000.",hint:"1 m³ da necha litr?",full:"1 m³ = 1 000 dm³ = 1 000 l. 2 m³ = 2 000 l."},
 tn:"Sinf xonasining hajmini (bo'yi · eni · balandligi) bolalar bilan hisoblang — taxminan 150–200 m³ chiqadi."},
{h:"Teskari masala",sum:"1 920 l = 1 920 dm³; 1 920 : 10 = 192 (bir qavat), 192 : 16 = 12 dm — eni.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Masala: <i>«Suv idishi to'g'ri burchakli parallelepiped. Bo'yi 16 dm, balandligi 10 dm. Unga roppa-rosa 1 920 litr suv sig'adi. Idishning eni necha dm?»</i></p>",
 btns:[phaser(P7)],
 after:"<p>Usul: litrni dm³ ga o'tkazamiz, so'ng hajmni ma'lum o'lchamlarga <b>bo'lamiz</b>: 1 920 : 10 : 16 = <b>12 dm</b>. Tekshirish: 16 · 12 · 10 = 1 920 ✓</p>",
 q:{t:"Qutining hajmi 120 sm³, bo'yi 6 sm, eni 5 sm. Balandligi qancha?",opts:["4 sm","20 sm","24 sm","109 sm"],ok:0,why:"Asos yuzi 6 · 5 = 30, 120 : 30 = 4 sm.",hint:"Avval bir qavatdagi kubiklar sonini (asos yuzini) toping.",full:"Asos yuzi 6 · 5 = 30 sm². Hajm 120 sm³, demak qavatlar soni 120 : 30 = 4 — balandlik 4 sm. «20» — faqat 6 ga bo'lingan, «24» — faqat 5 ga."},
 tn:"Teskari masalada «hajm = asos yuzi × balandlik» ni bolalar bilan ikki tomonga o'qing."},
{h:"Tuzoq: aralash birliklar",sum:"2 l 300 ml = 2 300 ml (23 ham, 2 003 ham emas).",a:"m08",
 start:function(){clear('#ffffff');T(S.g,180,70,'2 l 300 ml = ? ml',{'font-size':24,'font-weight':800});g3Msg('Javobni tanlang')},fin:function(){clear('#ffffff');T(S.g,180,70,'2 l 300 ml = 2 300 ml',{'font-size':24,'font-weight':800,fill:C.ok});T(S.g,180,112,'2 000 + 300',{'font-size':18,'font-weight':800,fill:C.blue});g3Msg('1 l = 1 000 ml')},
 html:"<p><b>2 l 300 ml</b> necha millilitr? Javoblarni sinab ko'ring:</p>",
 btns:[["230",function(){clear('#ffffff');T(S.g,180,70,'2 l 300 ml ≠ 230 ml',{'font-size':22,'font-weight':800,fill:C.bad});T(S.g,180,112,'2 l = 200 ml emas!',{'font-size':15,'font-weight':800,fill:C.bad});g3Msg('Litrda 1 000 ml')}],["2 300",function(c,done){clear('#ffffff');T(S.g,180,70,'2 l 300 ml = 2 300 ml',{'font-size':24,'font-weight':800,fill:C.ok});T(S.g,180,112,'2 · 1 000 + 300',{'font-size':18,'font-weight':800,fill:C.blue});g3Msg('To‘g‘ri!');done()},'u'],["2 003",function(){clear('#ffffff');T(S.g,180,70,'2 l 300 ml ≠ 2 003 ml',{'font-size':22,'font-weight':800,fill:C.bad});T(S.g,180,112,'300 ml 3 bo‘lib qolmaydi',{'font-size':15,'font-weight':800,fill:C.bad});g3Msg('300 ligicha qoladi')}]],g3:1,
 after:"<p>2 l = 2 000 ml, unga 300 ml qo'shamiz: <b>2 300 ml</b>. Xuddi shunday: 3 m³ 50 dm³ = 3 000 + 50 = 3 050 dm³.</p>",
 q:{t:"4 l 50 ml necha ml?",opts:["450 ml","4 050 ml","4 500 ml","4 005 ml"],ok:1,why:"4 000 + 50 = 4 050.",hint:"1 l = 1 000 ml. 4 l = ?",full:"4 l = 4 000 ml, + 50 ml = 4 050 ml. «4 500» — 50 ni 500 deb o'qigan, «450» — ×100 qo'llagan."},
 tn:"Bolalar idishlardagi yorliqni o'qisin: «1,5 l = 1 l 500 ml = 1 500 ml»."},
{h:"Bilasizmi? Toshning hajmi",sum:"Noto'g'ri shakldagi jism hajmini suvga botirib o'lchash mumkin: suv qancha ko'tarilsa, shuncha.",a:"m09",
 start:function(){g8Jar(500,false);g3Msg('Idishda 500 ml suv bor. Toshni tashlang')},fin:function(){g8Jar(580,true);g3Msg('Suv 80 ml ko‘tarildi → tosh hajmi <b>80 sm³</b>')},
 html:"<p>🪨 Toshning hajmini qanday o'lchaymiz? U kub ham, quti ham emas! Toshni suvli idishga tashlang:</p>",
 btns:[["🪨 Toshni tashlash",function(c,done){var tok=S.tok;var v=500;(function st2(){v+=10;g8Jar(v,true);if(v<580)setTimeout(st2,60);else{g3Msg('Suv 500 dan 580 ml ga ko‘tarildi → tosh hajmi <b>80 sm³</b>');done()}})()}]],
 after:"<p>Tosh suvni <b>siqib chiqardi</b>: suv 80 ml ko'tarildi, demak tosh hajmi <b>80 ml = 80 sm³</b>.</p><p>📜 Rivoyat qilinishicha, qadimgi yunon olimi <b>Arximed</b> bu usulni hammomda vannaga tushganda suv ko'tarilganini ko'rib o'ylab topgan va «Evrika!» («Topdim!») deb qichqirgan.</p>",
 tn:"Menzurka yoki o'lchov idishida tajribani sinfda qiling — bolalar o'z toshining hajmini o'lchasin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g8Stack(4,3,3,3);g3Msg('Hajm = bo‘yi · eni · balandligi')},fin:function(){g8Stack(4,3,3,3);g3Msg('Hajm = bo‘yi · eni · balandligi')},
 html:"<div class='memo'><ul><li>Hajm — nechta <b>birlik kub</b> sig'ishi. Hajm = <b>bo'yi · eni · balandligi</b>.</li><li><b>1 dm³ = 1 000 sm³</b>, <b>1 m³ = 1 000 dm³</b>.</li><li><b>1 l = 1 dm³ = 1 000 ml</b>, <b>1 ml = 1 sm³</b>, <b>1 m³ = 1 000 l</b>.</li><li>Uzunlik ×10, yuz ×100, hajm <b>×1 000</b>.</li><li>Aralash: 2 l 300 ml = <b>2 300 ml</b>.</li><li>Teskari: balandlik = hajm : (bo'yi · eni).</li><li>Notekis jism hajmi — suvga botirib.</li></ul></div>",
 tn:"Keyingi darsni «Kubning qirrasi 2 sm bo'lsa, hajmi qancha? (8 sm³, 6 emas!)» savoli bilan boshlang."}
];
function g4Tri(k){clear('#ffffff');var g=S.g;
 if(k>=1){g3Line([30,150],[130,150],{w:4,c:C.bad});for(var i=0;i<=10;i++)g3Line([30+i*10,146],[30+i*10,154],{w:1.3,c:C.bad});T(g,80,168,'1 dm = 10 sm',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(k>=2){var x0=150,y0=50;for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*10,y:y0+r*10,width:9,height:9,fill:'#f6c98a'},g);T(g,200,168,'1 dm² = 100 sm²',{'font-size':11,'font-weight':800,fill:C.t1})}
 if(k>=3){g3Box(270,150,60,60,60,{front:'#f2b766',top:'#f6c98a',side:'#d9954a'});T(g,300,168,'1 dm³ = 1 000 sm³',{'font-size':11,'font-weight':800,fill:C.blue})}
 g3Msg(['','<b>×10</b> — uzunlik','<b>×100</b> — yuz','<b>×1 000</b> — hajm'][k])}
var PROBS=[
{t:"Bo'yi 6 sm, eni 4 sm, balandligi 2 sm bo'lgan qutining hajmi?",o:["48 sm³","24 sm³","12 sm³","48 sm²"],k:0,s:"6 · 4 · 2 = 48 sm³."},
{t:"Qirrasi 3 sm bo'lgan kubning hajmi?",o:["27 sm³","9 sm³","12 sm³","18 sm³"],k:0,s:"3 · 3 · 3 = 27 sm³."},
{t:"5 dm³ necha sm³?",o:["5 000 sm³","500 sm³","50 sm³","5 sm³"],k:0,s:"1 dm³ = 1 000 sm³."},
{t:"3 l necha ml?",o:["3 000 ml","300 ml","30 ml","3 ml"],k:0,s:"1 l = 1 000 ml."},
{t:"7 000 sm³ necha litr?",o:["7 l","70 l","700 l","7 000 l"],k:0,s:"1 000 sm³ = 1 l."},
{t:"2 l 300 ml necha ml?",o:["2 300 ml","230 ml","2 003 ml","23 ml"],k:0,s:"2 000 + 300 = 2 300."},
{t:"Akvarium: bo'yi 50 sm, eni 30 sm, balandligi 40 sm. Necha litr suv sig'adi?",o:["60 l","6 l","600 l","120 l"],k:0,s:"50 · 30 · 40 = 60 000 sm³ = 60 l."},
{t:"Idish: bo'yi 16 dm, balandligi 10 dm, unga 1 920 l suv sig'adi. Eni necha dm?",o:["12 dm","6 dm","24 dm","120 dm"],k:0,s:"1 920 : 10 : 16 = 12 dm."},
{t:"Qutining hajmi 120 sm³, bo'yi 6 sm, eni 5 sm. Balandligi?",o:["4 sm","20 sm","24 sm","5 sm"],k:0,s:"120 : (6 · 5) = 4."},
{t:"Qirrasi 2 sm bo'lgan kubdan nechta 1 sm³ li kubik yasash mumkin?",o:["8","6","4","12"],k:0,s:"2 · 2 · 2 = 8."},
{t:"1 m³ necha litr?",o:["1 000 l","100 l","10 l","10 000 l"],k:0,s:"1 m³ = 1 000 dm³ = 1 000 l."},
{t:"Qaysi taqqoslash to'g'ri?",o:["2 l > 1 900 ml","2 l < 1 900 ml","2 l = 200 ml","1 dm³ < 500 sm³"],k:0,s:"2 l = 2 000 ml > 1 900 ml."},
{t:"Chelakka 10 l suv sig'adi. 1 m³ li bakni to'ldirish uchun necha chelak kerak?",o:["100","10","1 000","50"],k:0,s:"1 000 l : 10 l = 100."},
{t:"Suvli idishga tosh tashlandi: suv 600 ml dan 750 ml ga ko'tarildi. Tosh hajmi?",o:["150 sm³","750 sm³","600 sm³","1 350 sm³"],k:0,s:"750 − 600 = 150 ml = 150 sm³."},
{t:"Bir qavatda 4 · 5 kubik, 3 qavat. Hammasi nechta?",o:["60","12","23","20"],k:0,s:"20 · 3 = 60."},
{t:"4 l 50 ml necha ml?",o:["4 050 ml","450 ml","4 500 ml","4 005 ml"],k:0,s:"4 000 + 50 = 4 050."},
{t:"Qirrasi 1 dm bo'lgan kubga necha ml suv sig'adi?",o:["1 000 ml","100 ml","10 ml","10 000 ml"],k:0,s:"1 dm³ = 1 l = 1 000 ml."},
{t:"Shisha 1 l 500 ml. Stakan 250 ml. Shishadan nechta stakan to'ladi?",o:["6","4","5","3"],k:0,s:"1 500 : 250 = 6."},
{t:"Xona: bo'yi 5 m, eni 4 m, balandligi 3 m. Havo hajmi?",o:["60 m³","12 m³","20 m³","60 m²"],k:0,s:"5 · 4 · 3 = 60 m³."},
{t:"Qaysi birlik eng kichik?",o:["1 ml","1 l","1 dm³","1 m³"],k:0,s:"1 ml = 1 sm³ — eng kichigi."}
];
function PRACT_STAGE(){g8Stack(4,3,3,3);g3Msg('Hajm = bo‘yi · eni · balandligi')}
var PREP_DATA={teach:["Hajm tushunchasi: nechta birlik kub sig'adi; V = bo'yi · eni · balandligi.","Hajm birliklari: sm³, dm³, m³; litr va millilitr; ular orasidagi bog'lanish (×1 000).","Teskari masala: hajm va ikki o'lcham bo'yicha uchinchisini topish.","Notekis jism hajmini suvga botirib o'lchash."],
 mist:["1 dm³ = 100 sm³ yoki 10 sm³ deb yozadi.","Hajm javobiga sm² yozadi.","2 l 300 ml ni 230 yoki 2 003 deb yozadi.","Qirrasi 2 sm kubning hajmini 6 yoki 4 deydi."],
 need:["Kichik kubiklar yoki shakar bo'laklari, gugurt qutisi.","Tomoni 10 sm li karton kub (1 dm³) va 1 litrli shisha.","Menzurka yoki o'lchov idishi, kichik tosh."],
 board:["<span class='w2'>V = a · b · c</span>; 4 · 3 · 3 = 36 sm³.","<span class='w2'>1 dm³ = 1 000 sm³</span>, <span class='w2'>1 m³ = 1 000 dm³</span>.","<span class='w2'>1 l = 1 dm³ = 1 000 ml</span>, <span class='w2'>1 ml = 1 sm³</span>.","Uch ustun: ×10 | ×100 | ×1 000.","Teskari: <span class='w2'>1 920 : 10 : 16 = 12</span>."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
