var CODE='3B2',TITLE='3-sinf · Yozma (ustun) qo‘shish';
var B2N=['birliklar','o‘nliklar','yuzliklar','minglar'];
function b2info(nums,k){var c=0,r='';for(var i=0;i<=k;i++){var ds=nums.map(function(v){return +(String(v)[String(v).length-1-i]||0)}),s=ds.reduce(function(a,b){return a+b},0)+c;if(i===k)r='<b>'+B2N[k]+'</b>: '+ds.join(' + ')+(c?' + 1':'')+' = '+s+(s>=10?' → '+(s%10)+' yozamiz, <b>'+Math.floor(s/10)+'</b> eslab qolamiz':' — yozamiz');c=Math.floor(s/10)}return r}
function b2len(nums){return String(nums.reduce(function(a,b){return a+b},0)).length}
function b2btn(nums,fmsg){return [["Keyingi xona ▶",function(c,done,b){var n=b2len(nums);if(S.cs<n){S.cs++;w3col(nums,S.cs,{hl:S.cs-1});var k=S.cs-1,ds=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0);msg(k<Math.max.apply(null,nums.map(function(v){return String(v).length}))?b2info(nums,k):'Eslab qolingan <b>1</b> — yangi xona: <b>minglar</b>')}if(S.cs>=n){b.disabled=true;w3col(nums,n);if(fmsg)msg(fmsg);done()}}]]}
function b2st(nums,txt){S.cs=0;w3col(nums,0);msg(txt||'Birliklardan boshlaymiz →')}
function b2fin(nums,t){w3col(nums,b2len(nums));msg(t)}
var A1=[246,53],A2=[324,152],A3=[247,136],A4=[458,367],A5=[487,356,157];
function b2align(m){clear();var g=S.g,mono={'font-size':24,'font-weight':800,'font-family':'ui-monospace,Menlo,monospace'};
 function row(x,y,ds,start,col){ds.split('').forEach(function(d,i){T(g,x+(start+i-1)*24,y,d,Object.assign({fill:col||'#1d2b3a'},mono))})}
 function blk(x,b0,ok,lab){T(g,x,24,lab,{'font-size':12,'font-weight':800,fill:ok===true?C.ok:(ok===false?C.bad:'#5b6b7b')});for(var c=0;c<3;c++)E('rect',{x:x+(c-1)*24-11,y:40,width:22,height:62,rx:4,fill:['#ede7fb','#fdf0e1','#e1f4f2'][c]},g);row(x,64,'246',0);row(x,96,'53',b0);E('line',{x1:x-44,y1:106,x2:x+44,y2:106,stroke:'#33475b','stroke-width':2},g);T(g,x-56,82,'+',{'font-size':22,'font-weight':800,fill:C.blue})}
 blk(100,0,m==='A'?false:null,'A usul');blk(260,1,m==='B'?true:null,'B usul');if(m==='B')row(260,138,'299',0,C.ok);if(m==='A')row(100,138,'776',0,C.bad)}
var P6=[function(){b2miss(0);msg('3□7 + 24□ = 625. Birliklardan boshlaymiz')},function(){b2miss(1);msg('Birliklar: 7 + □ oxiri 5 bo‘lishi kerak → 7 + <b>8</b> = 15, 1 eslab qolamiz')},function(){b2miss(2);msg('O‘nliklar: □ + 4 + 1 oxiri 2 → □ + 5 = 12 → □ = <b>7</b>, yana 1 eslab qolamiz')},function(){b2miss(3);msg('Yuzliklar: 3 + 2 + 1 = 6 ✓. O‘chgan raqamlar: 7 va 8, yig‘indisi <b>15</b>')}];
function b2miss(p){clear();var g=S.g,mono={'font-size':26,'font-weight':800,'font-family':'ui-monospace,Menlo,monospace'},x1=230,cw=36;
 var r1=['3',p>=2?'7':'□','7'],r2=['2','4',p>=1?'8':'□'],r3=['6','2','5'];
 [r1,r2,r3].forEach(function(r,ri){r.forEach(function(d,i){T(g,x1-(2-i)*cw,(ri===2?140:44+ri*36),d,Object.assign({fill:d==='□'?C.bad:((ri===0&&i===1&&p>=2)||(ri===1&&i===2&&p>=1)?C.ok:'#1d2b3a')},mono))})});
 T(g,x1-3*cw-6,80,'+',{'font-size':24,'font-weight':800,fill:C.blue});E('line',{x1:x1-3*cw-14,y1:96,x2:x1+cw/2,y2:96,stroke:'#33475b','stroke-width':2.4},g);
 if(p>=1)T(g,x1-cw,16,'1',{'font-size':13,'font-weight':800,fill:C.bad});if(p>=2)T(g,x1-2*cw,16,'1',{'font-size':13,'font-weight':800,fill:C.bad});
 if(p>=3)T(g,320,80,'7 + 8 = 15',{'font-size':14,'font-weight':800,fill:C.ok})}
var STEPS=[
{h:"Ustunga to'g'ri yozish",sum:"Xona ostida xona: birliklar birliklar ostida — o'ngdan tekislaymiz.",a:"m01",
 start:function(){b2align('');msg('Qaysi yozuv to‘g‘ri?')},fin:function(){b2align('B');msg('Birliklar ostida birliklar')},
 html:"<p>Ustun usulida eng muhimi — <b>xonalarni tagma-tag</b> yozish. 246 + 53 ni qaysi usulda yozish to'g'ri?</p>",
 btns:w3choose(["A usul","B usul"],1,function(){b2align('B');msg('3 — birlik, 6 ostida; 5 — o‘nlik, 4 ostida. 246 + 53 = <b>299</b>')},function(){b2align('A');msg('Chapdan tekislandi: 53 ning 5 i yuzliklar ostiga tushib qoldi → 776 — xato!')}),g2:1,
 after:"<p>Sonlarni <b>o'ng chetidan</b> tekislaymiz — xuddi xonalar jadvalidagi kabi. Chapdan tekislash — eng ko'p uchraydigan xato: 246 + 53 «776» bo'lib qoladi.</p>",
 q:{t:"518 + 7 ni ustunga yozganda 7 qayerga yoziladi?",opts:["8 ning ostiga","5 ning ostiga","1 ning ostiga","Chetga, alohida"],ok:0,why:"7 — birlik, 518 ning birliklari — 8.",hint:"7 qaysi xona raqami?",full:"7 — bir xonali son, u birliklar xonasida. 518 da birliklar — 8. Shuning uchun 7 — 8 ning ostiga. 5 ning ostiga yozsak, 7 yuzlik bo'lib qoladi."},
 tn:"Katakli daftarda: har bir raqam — bitta katakda. Xonalarni rangli ustun bilan ajratish."},
{h:"O'tishsiz qo'shish",sum:"324 + 152: birliklar, o'nliklar, yuzliklar — 476.",a:"m02",
 start:function(){b2st(A2)},fin:function(){b2fin(A2,'324 + 152 = <b>476</b>')},
 html:"<p>Ustun usulida qo'shishni <b>birliklardan</b> (o'ngdan) boshlaymiz. Har bir xonani qo'shing:</p>",
 btns:b2btn(A2,'324 + 152 = <b>476</b>'),
 after:"<p>Tartib: birliklar → o'nliklar → yuzliklar. Hozircha o'ngdan boshlash shart emasdek tuyuladi — lekin keyingi qadamda nega shartligini ko'rasiz.</p>",
 q:{t:"513 + 264 = ?",opts:["777","787","677","7 717"],ok:0,why:"3 + 4 = 7, 1 + 6 = 7, 5 + 2 = 7.",hint:"Har bir xonani alohida qo'shing.",full:"Birliklar 3 + 4 = 7, o'nliklar 1 + 6 = 7, yuzliklar 5 + 2 = 7: 777."},
 tn:"Doskada har bir xonani boshqa rangli bo'rda yozish."},
{h:"O'tish bilan: «1 ni eslab qolamiz»",sum:"247 + 136: 7 + 6 = 13 — 3 ni yozamiz, 1 ni o'nliklarga o'tkazamiz: 383.",a:"m03",
 start:function(){b2st(A3)},fin:function(){b2fin(A3,'247 + 136 = <b>383</b>')},
 html:"<p>Agar xonada yig'indi <b>10 yoki undan ko'p</b> bo'lsa, faqat birini yozamiz, o'nni keyingi xonaga «o'tkazamiz». Qo'shing:</p>",
 btns:b2btn(A3,'247 + 136 = <b>383</b>'),
 after:"<p>7 + 6 = 13 = 1 o'nlik va 3 birlik. 3 yoziladi, 1 o'nlik — o'nliklar ustiga kichik «1». O'nliklar: 4 + 3 + <b>1</b> = 8. Mana nega o'ngdan boshlaymiz — o'tgan 1 chapdagi xonaga qo'shiladi.</p>",
 q:{t:"358 + 127 = ?",opts:["485","475","4 715","385"],ok:0,why:"8 + 7 = 15 → 5, 1 o'tadi; 5 + 2 + 1 = 8; 3 + 1 = 4.",hint:"Birliklar yig'indisi 10 dan katta — nima qilamiz?",full:"Birliklar: 8 + 7 = 15 → 5 yozamiz, 1 eslab qolamiz. O'nliklar: 5 + 2 + 1 = 8. Yuzliklar: 3 + 1 = 4. Javob 485. «475» — o'tgan 1 ni unutish; «4 715» — 15 ni butunligicha yozish."},
 tn:"Bloklar bilan: 13 ta birlikdan 10 tasini bitta tayoqchaga almashtirib, o'nliklar ustuniga o'tkazing (Yapon usuli)."},
{h:"Ikki marta o'tish",sum:"458 + 367: birliklardan 1, o'nliklardan 1 o'tadi — 825.",a:"m04",
 start:function(){b2st(A4)},fin:function(){b2fin(A4,'458 + 367 = <b>825</b>')},
 html:"<p>Endi ikki xonada o'tish bor. Har bir xonada eslab qolingan 1 ni qo'shishni unutmang:</p>",
 btns:b2btn(A4,'458 + 367 = <b>825</b>'),
 after:"<p>8 + 7 = 15 → 5, 1 o'tadi. 5 + 6 + 1 = 12 → 2, 1 o'tadi. 4 + 3 + 1 = 8. Javob: <b>825</b>. Eng ko'p xato — ikkinchi o'tishni unutish (725).</p>",
 q:{t:"569 + 286 = ?",opts:["855","755","845","8 515"],ok:0,why:"9 + 6 = 15, 6 + 8 + 1 = 15, 5 + 2 + 1 = 8.",hint:"Ikki marta o'tish bor.",full:"Birliklar: 9 + 6 = 15 → 5 (1). O'nliklar: 6 + 8 + 1 = 15 → 5 (1). Yuzliklar: 5 + 2 + 1 = 8. Javob 855. «755» — yuzlikka o'tishni unutish; «845» — o'nliklarga o'tgan 1 ni unutish."},
 tn:"Bank (408) turi. Eslab qolingan raqamni har doim xona ustiga kichik qilib yozdiring."},
{h:"Uchta qo'shiluvchi va 1 000",sum:"487 + 356 + 157 = 1 000: har xonada o'tish, natija to'rt xonali.",a:"m05",
 start:function(){b2st(A5)},fin:function(){b2fin(A5,'487 + 356 + 157 = <b>1 000</b>')},
 html:"<p>Uchta sonni ham bir ustunda qo'shamiz. Yig'indi to'rt xonali bo'lib qolishi mumkin — kuzating:</p>",
 btns:b2btn(A5,'487 + 356 + 157 = <b>1 000</b>'),
 after:"<p>7 + 6 + 7 = 20 → 0, <b>2</b> o'tadi (uchta son qo'shilganda 2 ham o'tishi mumkin!). 8 + 5 + 5 + 2 = 20 → 0, 2 o'tadi. 4 + 3 + 1 + 2 = 10 → 0, 1 — yangi xona. Javob: <b>1 000</b>.</p>",
 q:{t:"276 + 394 + 128 = ?",opts:["798","698","788","898"],ok:0,why:"6 + 4 + 8 = 18 → 8 (1); 7 + 9 + 2 + 1 = 19 → 9 (1); 2 + 3 + 1 + 1 = 7.",hint:"Birliklar: 6 + 4 + 8 = ?",full:"Birliklar 18 → 8, 1 o'tadi. O'nliklar 7 + 9 + 2 + 1 = 19 → 9, 1 o'tadi. Yuzliklar 2 + 3 + 1 + 1 = 7. Javob 798. «698» — oxirgi o'tishni unutish; «788» — o'nliklarda o'tishni unutish."},
 tn:"Bank (409, 410, 427). Qulay guruhlash bilan ham tekshiring: 487 + 356 + 157 = 487 + (356 + 157)."},
{h:"Tuzoq: o'chgan raqamlar",sum:"3□7 + 24□ = 625: birliklardan boshlab topamiz — 8 va 7, yig'indisi 15.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>«Ustun shaklida qo'shishda ba'zi raqamlar o'chib ketgan: <b>3□7 + 24□ = 625</b>. O'chgan raqamlar yig'indisini toping.» Xuddi qo'shgandek, birliklardan boshlaymiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Tuzoq — o'tishlarni hisobga olmaslik. Masalan, o'nliklarda «□ + 4 = 2» ni ko'rib dovdirash: aslida □ + 4 + <b>1</b> = <b>12</b>. Tekshiruv: 377 + 248 = 625 ✓.</p>",
 q:{t:"4□6 + 2□9 = 705. O'chgan raqamlar yig'indisi?",opts:["9","8","10","19"],ok:0,why:"6 + 9 = 15 (1 o'tadi); □ + □ + 1 = 10 → □ + □ = 9; 4 + 2 + 1 = 7 ✓.",hint:"Birliklar: 6 + 9 = 15 — nechta o'tadi?",full:"Birliklar: 6 + 9 = 15 → 5 ✓, 1 o'tadi. O'nliklar: □ + □ + 1 oxiri 0 → □ + □ + 1 = 10 → □ + □ = 9 (1 o'tadi). Yuzliklar: 4 + 2 + 1 = 7 ✓. Yig'indi 9. «10» — o'tgan 1 ni ham qo'shish; «8» — noto'g'ri ayirish."},
 tn:"Bank (2236). Bolalar o'zlari shunday «yashirin misol» tuzib, sherigiga bersin."},
{h:"Chamalab tekshirish",sum:"458 + 367 ≈ 460 + 370 = 830: 725 deb chiqsa — xato bor.",a:"m07",
 start:function(){w3col(A4,null);msg('Bola javobi: 725. To‘g‘rimi?')},fin:function(){w3col(A4,null);msg('≈ 460 + 370 = 830. 825 — to‘g‘ri, 725 — xato')},
 html:"<p>Ali 458 + 367 ni hisoblab <b>725</b> oldi. Chamalab tekshiring: 458 ≈ 460, 367 ≈ 370. Ali to'g'ri hisoblaganmi?</p>",
 btns:w3choose(["Ha, to'g'ri","Yo'q, javob 800 dan katta bo'lishi kerak"],1,function(){msg('460 + 370 = 830 — javob 830 atrofida. 725 juda kichik: yuzlikka o‘tish unutilgan')},function(){msg('Chamalang: 460 + 370 = ? Bu 725 ga yaqinmi?')}),
 after:"<p>Chamalash xatoning <b>katta</b> ekanini darhol ko'rsatadi. Aniq tekshiruv — ayirish bilan: 825 − 367 = 458 ✓. Yoki qo'shiluvchilar o'rnini almashtirib: 367 + 458 = 825.</p>",
 q:{t:"Qaysi javob chamalashning o'zidayoq xato ekani ko'rinadi?",opts:["612 + 289 = 801","312 + 489 = 801","405 + 396 = 801","599 + 202 = 801"],ok:0,why:"612 + 289 ≈ 600 + 300 = 900, 801 emas.",hint:"Har birini yuzliklargacha yaxlitlab qo'shing.",full:"612 + 289 ≈ 900 (aniq: 901) — 801 xato. 312 + 489 ≈ 800 (801 ✓), 405 + 396 ≈ 800 (801 ✓), 599 + 202 ≈ 800 (801 ✓)."},
 tn:"Har bir yozma misoldan oldin «taxminan qancha chiqadi?» deb so'rash odat bo'lsin."},
{h:"Bilasizmi? Nega faqat «1» o'tadi?",sum:"Ikki son qo'shilganda bir xonada eng ko'pi 9 + 9 + 1 = 19 — shuning uchun faqat 1 o'tadi.",a:"m08",
 start:function(){w3col([999,999],null);msg('999 + 999 = 1 998')},fin:function(){w3col([999,999],null);msg('999 + 999 = 1 998')},
 html:"<p>🔢 Ikkita son qo'shilganda bitta xonada eng katta yig'indi: 9 + 9 + 1 (o'tgan) = <b>19</b>. Demak keyingi xonaga hech qachon 2 o'tmaydi — faqat 0 yoki <b>1</b>.</p><p>➕ Uchta son qo'shilganda esa 9 + 9 + 9 + 2 = 29 — <b>2</b> o'tishi mumkin (1 000 ni hosil qilgan misoldagi kabi).</p><p>Eng katta uch xonali ikki sonning yig'indisi: 999 + 999 = <b>1 998</b>.</p>",
 tn:"Bolalar o'zlari tekshirsin: ikki xonali ikki sonning yig'indisi 200 dan oshishi mumkinmi? (99 + 99 = 198)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w3col(A4,null)},fin:function(){w3col(A4,null)},
 html:"<div class='memo'><ul><li>Xona ostida xona — <b>o'ngdan</b> tekislang.</li><li>Birliklardan boshlang (o'ngdan chapga).</li><li>Yig'indi 10 va ko'p bo'lsa: birini yozing, o'nni keyingi xonaga o'tkazing (kichik «1» ustiga).</li><li>Uchta son qo'shilsa — 2 ham o'tishi mumkin.</li><li>O'chgan raqam: birliklardan, o'tishlarni hisobga olib.</li><li>Tekshiring: chamalab va ayirish bilan.</li></ul></div>",
 tn:"Keyingi dars — yozma ayirish."}
];
var PROBS=[
{t:"324 + 152 = ?",o:["476","466","486","376"],k:0,s:"O'tishsiz."},
{t:"513 + 264 = ?",o:["777","787","677","767"],k:0,s:"Har xona 7."},
{t:"246 + 53 = ?",o:["299","776","289","309"],k:0,s:"O'ngdan tekislab."},
{t:"247 + 136 = ?",o:["383","373","3 713","393"],k:0,s:"7 + 6 = 13, 1 o'tadi."},
{t:"358 + 127 = ?",o:["485","475","4 715","495"],k:0,s:"8 + 7 = 15."},
{t:"458 + 367 = ?",o:["825","725","815","835"],k:0,s:"Ikki o'tish."},
{t:"569 + 286 = ?",o:["855","755","845","865"],k:0,s:"15, 15, 8."},
{t:"487 + 356 + 157 = ?",o:["1 000","990","900","1 100"],k:0,s:"Har xonada o'tish."},
{t:"276 + 394 + 128 = ?",o:["798","698","788","898"],k:0,s:"18, 19, 7."},
{t:"204 + 163 + 397 = ?",o:["764","664","754","774"],k:0,s:"14, 16, 7."},
{t:"458 + 367 − 189 = ?",o:["636","626","646","736"],k:0,s:"825 − 189 = 636."},
{t:"586 ga 463 va 78 ning ayirmasini qo'shing.",o:["971","961","981","1 127"],k:0,s:"463 − 78 = 385; 586 + 385 = 971."},
{t:"3□7 + 24□ = 625. O'chgan raqamlar yig'indisi:",o:["15","13","11","16"],k:0,s:"377 + 248: 7 va 8."},
{t:"4□6 + 2□9 = 705. O'chgan raqamlar yig'indisi:",o:["9","8","10","19"],k:0,s:"6 + 9 = 15; □ + □ + 1 = 10."},
{t:"Qaysi yig'indi chamalashdayoq xato?",o:["612 + 289 = 801","312 + 489 = 801","405 + 396 = 801","599 + 202 = 801"],k:0,s:"612 + 289 ≈ 900."},
{t:"Ikki uch xonali sonning yig'indisi eng ko'pi bilan qancha bo'ladi?",o:["1 998","1 000","999","2 000"],k:0,s:"999 + 999."},
{t:"Birinchi minora 268 m, ikkinchisi undan 77 m baland, uchinchisi ikkinchisidan 129 m past. Uchinchisi necha metr?",o:["216","206","345","474"],k:0,s:"268 + 77 = 345; 345 − 129 = 216."},
{t:"Yig'indi: 199 + 299 + 399 = ?",o:["897","900","887","997"],k:0,s:"200 + 300 + 400 − 3 = 897."},
{t:"Ustunda 518 + 7 yozilganda 7 qaysi raqam ostiga yoziladi?",o:["8","1","5","Hech biri"],k:0,s:"Birliklar ostiga."},
{t:"□□□ + □□□ = 1 998. Qo'shiluvchilardagi barcha raqamlar yig'indisi:",o:["54","27","18","45"],k:0,s:"Faqat 999 + 999 = 1 998: oltita 9 — 54."}
];
function PRACT_STAGE(){w3col(A4,null)}
var PREP_DATA={teach:["Ustunga to'g'ri yozish (o'ngdan tekislash).","Yozma qo'shish: o'tishsiz, bir va ikki o'tish bilan, uchta qo'shiluvchi.","O'chgan raqamlarni tiklash; chamalab tekshirish."],mist:["Sonlarni chapdan tekislaydi.","Eslab qolingan 1 ni qo'shishni unutadi.","Xonadagi 15 ni butunligicha yozadi.","Uchta son qo'shganda faqat 1 o'tkazadi (2 o'rniga)."],need:["Katakli daftar, o'nlik bloklar, rangli bo'r."],board:["<span class='w2'>247 + 136 = 383</span> (7 + 6 = 13).","<span class='w2'>458 + 367 = 825</span>.","<span class='w2'>487 + 356 + 157 = 1 000</span>.","<span class='w2'>377 + 248 = 625</span>.","<span class='w2'>chamalash: 460 + 370 = 830</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
