// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4G4',TITLE='4-sinf · Ismli sonlar ustida amallar';
function g44col(rows,res,note,carry){clear();var g=S.g;if(carry)T(g,250,22,carry,{'font-size':12,'font-weight':800,fill:C.bad,'text-anchor':'end'});rows.forEach(function(r,i){T(g,250,46+i*30,r,{'font-size':19,'font-weight':800,fill:'#1d2b3a','text-anchor':'end'})});
 E('line',{x1:100,y1:46+rows.length*30-20,x2:256,y2:46+rows.length*30-20,stroke:'#1d2b3a','stroke-width':2},g);
 if(res)T(g,250,46+rows.length*30+8,res,{'font-size':19,'font-weight':800,fill:C.ok,'text-anchor':'end'});
 if(note)T(g,180,164,note,{'font-size':11,'font-weight':700,fill:C.a2})}
function g44conv(big,small,res,fx){clear();var g=S.g;T(g,180,50,big,{'font-size':24,'font-weight':800,fill:'#1d2b3a'});E('path',{d:'M180 64 L180 92',stroke:C.ok,'stroke-width':2.4},g);E('path',{d:'M173 86 L180 94 L187 86',fill:'none',stroke:C.ok,'stroke-width':2.4},g);T(g,232,82,fx,{'font-size':12,'font-weight':800,fill:C.ok});T(g,180,124,res,{'font-size':24,'font-weight':800,fill:C.a2});T(g,180,152,small,{'font-size':12,'font-weight':700,fill:'#5b6b7b'})}
var P2=[function(){g44col(['4 m 75 sm','+ 2 m 48 sm'],'','Avval santimetrlar');calc(['4 m 75 sm + 2 m 48 sm = ?'])},
 function(){g44col(['4 m 75 sm','+ 2 m 48 sm'],'… m 23 sm','75 + 48 = 123 sm = 1 m 23 sm','+1 m');calc(['75 + 48 = 123 sm = <b>1 m 23 sm</b>','23 sm ni yozamiz, 1 m ni «yodda saqlaymiz»'])},
 function(){g44col(['4 m 75 sm','+ 2 m 48 sm'],'7 m 23 sm','','+1 m');calc(['4 + 2 + 1 = 7 m','Javob: <b>7 m 23 sm</b>'])}];
var P3=[function(){g44col(['8 kg 200 g','− 3 kg 650 g'],'','200 g dan 650 g ni ayirib bo‘lmaydi');calc(['8 kg 200 g − 3 kg 650 g = ?'])},
 function(){g44col(['7 kg 1200 g','− 3 kg 650 g'],'','1 kg ni maydaladik: 8 kg 200 g = 7 kg 1200 g');calc(['1 kg = 1000 g → 200 + 1000 = <b>1200 g</b>'])},
 function(){g44col(['7 kg 1200 g','− 3 kg 650 g'],'4 kg 550 g','');calc(['1200 − 650 = 550 g,  7 − 3 = 4 kg','Javob: <b>4 kg 550 g</b>'])}];
var P5=[function(){g44col(['3 kg 250 g','·         4'],'','Har qismni alohida ko‘paytiramiz');calc(['3 kg 250 g · 4 = ?'])},
 function(){g44col(['3 kg 250 g','·         4'],'12 kg 1000 g','1000 g — bu 1 kg!');calc(['3 kg · 4 = 12 kg','250 g · 4 = 1000 g'])},
 function(){g44col(['3 kg 250 g','·         4'],'13 kg','');calc(['1000 g = 1 kg → 12 kg + 1 kg = <b>13 kg</b>','Tekshiruv: 3250 g · 4 = 13 000 g = 13 kg ✓'])}];
var P6=[function(){g44conv('7 m 20 sm : 6','','?','');calc(['7 m ni 6 ga teng bo‘lib bo‘lmaydi — nima qilamiz?'])},
 function(){g44conv('7 m 20 sm','Bitta birlikka o‘tkazdik','720 sm','× 100 + 20');calc(['7 m 20 sm = <b>720 sm</b>'])},
 function(){g44conv('720 sm : 6','120 sm = 1 m 20 sm','120 sm','');calc(['720 : 6 = 120 sm','120 sm = <b>1 m 20 sm</b>'])}];
function g44tape(k){clear();var g=S.g,x0=30,w=300,n=15;E('rect',{x:x0,y:60,width:w,height:30,fill:'#fff',stroke:C.t1,'stroke-width':2},g);
 for(var i=0;i<Math.min(k,n);i++)E('rect',{x:x0+i*w/n,y:60,width:w/n,height:30,fill:i%2?C.t2:'#f8d29a',stroke:C.t1,'stroke-width':1},g);
 T(g,180,46,'6 m = 600 sm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,x0+10,112,'40 sm',{'font-size':11,'font-weight':800,fill:C.a2});if(k>=n)T(g,180,140,'15 bo‘lak',{'font-size':15,'font-weight':800,fill:C.ok})}
var P7=[function(){g44tape(0);calc(['6 m lentadan 40 sm li bo‘laklar. Nechta chiqadi?'])},
 function(){g44tape(5);calc(['Bitta birlikka: 6 m = <b>600 sm</b>','Necha marta 40 sm sig‘adi?'])},
 function(){g44tape(15);calc(['600 sm : 40 sm = <b>15</b>','Javob — oddiy son: 15 ta bo‘lak (birliksiz!)'])}];
function g44tl(k){clear();var g=S.g,x0=30,x1=330,h0=13.5,h1=17.5;function X(h){return x0+(h-h0)/(h1-h0)*(x1-x0)}
 E('line',{x1:x0,y1:100,x2:x1,y2:100,stroke:'#3a4a5a','stroke-width':2},g);[14,15,16,17].forEach(function(h){E('line',{x1:X(h),y1:94,x2:X(h),y2:106,stroke:'#3a4a5a','stroke-width':2},g);T(g,X(h),122,h+':00',{'font-size':11,'font-weight':700})});
 var a=13+50/60;E('circle',{cx:X(a),cy:100,r:5,fill:C.ok},g);T(g,X(a),140,'13:50',{'font-size':13,'font-weight':800,fill:C.ok});
 if(k>=1){E('path',{d:'M'+X(a)+' 96 Q'+((X(a)+X(16+50/60))/2)+' 30 '+X(16+50/60)+' 96',fill:'none',stroke:C.blue,'stroke-width':2.4},g);T(g,(X(a)+X(16+50/60))/2,50,'+3 soat → 16:50',{'font-size':12,'font-weight':800,fill:C.blue})}
 if(k>=2){var e=17.25;E('path',{d:'M'+X(16+50/60)+' 96 Q'+((X(16+50/60)+X(e))/2)+' 62 '+X(e)+' 96',fill:'none',stroke:C.a2,'stroke-width':2.4},g);T(g,X(e)+4,70,'+25 min',{'font-size':12,'font-weight':800,fill:C.a2});E('circle',{cx:X(e),cy:100,r:5,fill:C.bad},g);T(g,X(e),156,'17:15',{'font-size':13,'font-weight':800,fill:C.bad})}}
var P8=[function(){g44tl(0);calc(['Poyezd 13:50 da jo‘nab, 3 soat 25 min yo‘l yurdi. Qachon yetib keldi?'])},
 function(){g44tl(1);calc(['Avval butun soatlar: 13:50 + 3 soat = <b>16:50</b>'])},
 function(){g44tl(2);calc(['16:50 + 10 min = 17:00, yana 15 min → <b>17:15</b>','(«16:75» deb yozib bo‘lmaydi: soatda 60 minut)'])}];
var STEPS=[
{h:"Ismli son — bitta birlikka",sum:"5 m 30 sm = 530 sm, 2 soat 15 min = 135 min, 3 kg 40 g = 3040 g.",a:"m01",
 start:function(){g44conv('5 m 30 sm','','?','');g4m('Tugmalarni bosib, bitta birlikka o‘tkazing')},fin:function(){g44conv('2 soat 15 min','60 · 2 + 15','135 min','× 60 + 15');g4m('Vaqtda ko‘paytuvchi 60!')},
 html:"<p><b>Ismli son</b> — o'lchov birligi bilan yozilgan son: 5 m 30 sm, 2 soat 15 min, 3 kg 40 g. Amallardan oldin ko'pincha uni <b>bitta birlikka</b> o'tkazamiz:</p>",
 btns:[["5 m 30 sm",function(c,done){g44conv('5 m 30 sm','5 · 100 + 30','530 sm','× 100 + 30');g4m('1 m = 100 sm');mvK(done,3)}],["2 soat 15 min",function(c,done){g44conv('2 soat 15 min','2 · 60 + 15','135 min','× 60 + 15');g4m('1 soat = <b>60</b> min (100 emas!)');mvK(done,3)}],["3 kg 40 g",function(c,done){g44conv('3 kg 40 g','3 · 1000 + 40','3040 g','× 1000 + 40');g4m('1 kg = 1000 g — bo‘sh xonaga 0');mvK(done,3)}]],g3:1,
 after:"<p>Har bir birlik juftining <b>o'z ko'paytuvchisi</b> bor: m–sm — 100, kg–g — 1000, soat–min — <b>60</b>. Vaqtda eng ko'p xato qilinadi!</p>",
 q:{t:"1 soat 50 min necha minut?",opts:["150 min","110 min","105 min","60 min"],ok:1,why:"60 + 50 = 110 min.",hint:"1 soat necha minut?",full:"1 soat = 60 min, 60 + 50 = 110 min. «150» — 1 soatni 100 min deb olish xatosi."},
 tn:"Doskaga uch juft yozing: 100 (m–sm), 1000 (kg–g), 60 (soat–min). Bolalar har misolda avval «qaysi ko'paytuvchi?» deb so'rasin."},
{h:"Qo'shish: kichik birlikdan o'tkazish",sum:"4 m 75 sm + 2 m 48 sm: 75 + 48 = 123 sm = 1 m 23 sm → 7 m 23 sm.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ustunda qo'shamiz — xuddi o'nliklardagidek, faqat «o'tish» 100 sm da:</p>",
 btns:[phaser(P2)],
 after:"<p>Kichik birliklar yig'indisi <b>katta birlikdan oshsa</b> — bittasini katta birlikka o'tkazamiz. Javobda «6 m 123 sm» qoldirmang.</p>",
 q:{t:"2 t 4 s + 3 t 8 s = ?",opts:["5 t 12 s","6 t 2 s","5 t 2 s","6 t 12 s"],ok:1,why:"4 + 8 = 12 s = 1 t 2 s; 2 + 3 + 1 = 6 t.",hint:"1 tonna necha sentner?",full:"Sentnerlar: 4 + 8 = 12 s = 1 t 2 s (1 t = 10 s). Tonnalar: 2 + 3 + 1 = 6. Javob 6 t 2 s. «5 t 12 s» — o'tkazilmagan."},
 tn:"«O'tkazilgan» birlikni ustunda kichik qilib yozish odatini shakllantiring."},
{h:"Ayirish: katta birlikni maydalash",sum:"8 kg 200 g − 3 kg 650 g: 8 kg 200 g = 7 kg 1200 g → 4 kg 550 g.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Kichik birlik yetmasa, katta birlikdan bittasini «maydalaymiz»:</p>",
 btns:[phaser(P3)],
 after:"<p>1 kg = 1000 g ni grammlarga qo'shdik: 200 + 1000 = 1200 g. Endi oddiy ayirish. Kilogrammlar bittaga kamayganini unutmang!</p>",
 q:{t:"10 km − 4 km 350 m = ?",opts:["6 km 650 m","5 km 650 m","6 km 350 m","5 km 350 m"],ok:1,why:"10 km = 9 km 1000 m; 1000 − 350 = 650 m; 9 − 4 = 5 km.",hint:"10 km dan 1 km ni metrga maydalang.",full:"10 km = 9 km 1000 m. Metrlar: 1000 − 350 = 650. Kilometrlar: 9 − 4 = 5. Javob 5 km 650 m. «6 km 650 m» — maydalangan 1 km ni ayirishni unutish."},
 tn:"Pul bilan o'xshatish: 10 ming so'mni 9 ming + 1000 so'm maydaga almashtirish."},
{h:"Tuzoq: vaqtda 60 orqali o'tish",sum:"2 soat 40 min + 1 soat 35 min = 3 soat 75 min = 4 soat 15 min.",a:"m04",
 start:function(){g44col(['2 soat 40 min','+ 1 soat 35 min'],'','40 + 35 = 75 min');g4m('Qaysi javob to‘g‘ri? Bosing')},fin:function(){g44col(['2 soat 40 min','+ 1 soat 35 min'],'4 soat 15 min','75 min = 1 soat 15 min','+1 soat');g4m('75 min = 60 + 15 = 1 soat 15 min')},
 html:"<p>Ali 2 soat 40 min o'qidi, keyin yana 1 soat 35 min. Jami qancha?</p>",
 btns:[["3 soat 75 min",function(c,done,b){b.style.background='#fde2e2';g4m('❌ Soatda 75 minut bo‘lmaydi! 60 min = 1 soat');setTimeout(function(){b.style.background=''},1600)}],["4 soat 15 min",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g44col(['2 soat 40 min','+ 1 soat 35 min'],'4 soat 15 min','75 min = 1 soat 15 min','+1 soat');g4m('To‘g‘ri! 75 min = 1 soat 15 min');done()}],["3 soat 15 min",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 60 min ni soatga o‘tkazdingiz, lekin soatlarga qo‘shmadingiz');setTimeout(function(){b.style.background=''},1600)}],["4 soat 75 min",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 1 soat qo‘shildi, lekin minutlar kamaymadi');setTimeout(function(){b.style.background=''},1600)}]],g2:1,
 after:"<p>Vaqtda o'tish <b>60 da</b>, 100 da emas: 75 min = 60 min + 15 min = 1 soat 15 min. Ayirishda esa 1 soatni <b>60 minut</b>ga maydalaymiz.</p>",
 q:{t:"5 soat − 2 soat 25 min = ?",opts:["3 soat 25 min","2 soat 75 min","2 soat 35 min","3 soat 35 min"],ok:2,why:"5 soat = 4 soat 60 min; 60 − 25 = 35 min; 4 − 2 = 2 soat.",hint:"1 soatni 60 minutga maydalang.",full:"5 soat = 4 soat 60 min. 60 − 25 = 35 min, 4 − 2 = 2 soat. Javob 2 soat 35 min. «2 soat 75 min» — 1 soatni 100 min deb maydalash xatosi."},
 tn:"Eng ko'p xato shu yerda. Karton soat bilan amalda ko'rsating: 2:40 dan 75 minut oldinga."},
{h:"Ismli sonni songa ko'paytirish",sum:"3 kg 250 g · 4 = 12 kg 1000 g = 13 kg.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bitta qadoq shakar 3 kg 250 g. 4 ta qadoq necha kilogramm?</p>",
 btns:[phaser(P5)],
 after:"<p>Ikki usul: 1) har bir qismni ko'paytirib, keyin o'tkazish; 2) avval bitta birlikka (3250 g), keyin ko'paytirish. Ikkalasi ham bir xil javob beradi — biri bilan ikkinchisini tekshiring.</p>",
 q:{t:"1 soat 20 min · 3 = ?",opts:["3 soat 20 min","4 soat","3 soat 60 min","4 soat 20 min"],ok:1,why:"20 · 3 = 60 min = 1 soat; 1 · 3 + 1 = 4 soat.",hint:"Minutlarni ham 3 ga ko'paytiring.",full:"1 soat · 3 = 3 soat, 20 min · 3 = 60 min = 1 soat. Jami 4 soat. «3 soat 20 min» — minutlarni ko'paytirmagan; «3 soat 60 min» — o'tkazmagan (60 min = 1 soat)."},
 tn:"Bolalar ikkala usulni ikki ustunda yozsin va natijani solishtirsin."},
{h:"Ismli sonni songa bo'lish",sum:"7 m 20 sm : 6 = 720 sm : 6 = 120 sm = 1 m 20 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>7 m 20 sm lentani 6 ta teng bo'lakka bo'ldik. Har bo'lak qancha?</p>",
 btns:[phaser(P6)],
 after:"<p>Bo'lishda eng qulayi — avval <b>kichik birlikka</b> o'tish, bo'lish, so'ng javobni yana ikki nomli qilib yozish.</p>",
 q:{t:"9 kg 600 g : 8 = ?",opts:["1 kg 20 g","1 kg 200 g","1 kg 75 g","12 kg"],ok:1,why:"9600 g : 8 = 1200 g = 1 kg 200 g.",hint:"Avval grammga o'tkazing.",full:"9 kg 600 g = 9600 g. 9600 : 8 = 1200 g = 1 kg 200 g. «1 kg 20 g» — 1200 g ni yozishda nolni tushirish, «1 kg 75 g» — 600 : 8 ni alohida bo'lish."},
 tn:"Lenta yoki ipni haqiqatan 6 ga bo'lib ko'rsating, chizg'ich bilan o'lchab tekshiring."},
{h:"Ismli sonni ismli songa bo'lish",sum:"6 m : 40 sm = 600 sm : 40 sm = 15. Javob — birliksiz son (necha marta).",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>6 m lentadan 40 sm li bo'laklar kesildi. Nechta bo'lak chiqdi?</p>",
 btns:[phaser(P7,'▶ Kesish')],
 after:"<p>Ismli sonni <b>xuddi shunday birlikdagi</b> ismli songa bo'lsak, «necha marta sig'adi?» degan savolga javob olamiz — natija <b>oddiy son</b>. Lekin birliklar albatta bir xil bo'lishi kerak: 6 m : 40 sm ≠ 6 : 40.</p>",
 q:{t:"3 kg 600 g unni 400 g dan paketlarga solindi. Nechta paket?",opts:["9","90","8","1 kg 200 g"],ok:0,why:"3600 g : 400 g = 9.",hint:"Ikkalasini ham grammga o'tkazing.",full:"3 kg 600 g = 3600 g. 3600 : 400 = 9 paket. «90» — 3600 ni 40 ga bo'lish xatosi, «1 kg 200 g» — bu 3 ga bo'lish natijasi."},
 tn:"Bolalarga savol: «Javobda nega birlik yo'q?» Ular o'zi tushuntirsin (paketlar soni)."},
{h:"Masala: poyezd jadvali",sum:"13:50 + 3 soat 25 min = 16:50 + 25 min = 17:15.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Vaqt chizig'ida «sakrab» hisoblaymiz:</p>",
 btns:[phaser(P8,'▶ Sakrash')],
 after:"<p>Soat ko'rsatkichiga vaqt qo'shishda: avval <b>butun soatlarni</b>, keyin minutlarni qo'shamiz; minutlar 60 dan oshsa — keyingi soatga o'tamiz.</p>",
 q:{t:"Kino 18:40 da boshlanib, 1 soat 55 min davom etadi. Qachon tugaydi?",opts:["19:95","20:35","19:35","20:45"],ok:1,why:"18:40 + 1 soat = 19:40; + 20 min = 20:00; + 35 min = 20:35.",hint:"Avval 1 soat qo'shing, keyin 20:00 gacha to'ldiring.",full:"18:40 + 1 soat = 19:40. Yana 55 min: 19:40 → 20:00 (20 min), qolgan 35 min → 20:35. «19:95» — 60 orqali o'tmaslik xatosi."},
 tn:"Haqiqiy avtobus/poyezd jadvalidan foydalaning — bolalar uchun hayotiy."},
{h:"Bilasizmi? Nega soatda 60 minut",sum:"Soat va minutdagi 60 — qadimgi Bobilning 60 lik sanoq tizimidan qolgan.",a:"m09",
 start:function(){clear();g4clock(2,40,180,86,64,'');g4m('Bir soat — 60 minut, bir minut — 60 sekund')},fin:function(){clear();g4clock(2,40,180,86,64,'');g4m('Bir soat — 60 minut, bir minut — 60 sekund')},
 html:"<p>🏺 Qadimgi <b>Bobil</b> olimlari 10 lik emas, <b>60 lik</b> sanoqdan foydalanishgan. 60 ning bo'luvchilari ko'p: 2, 3, 4, 5, 6, 10, 12, 15, 20, 30 — bo'lish juda qulay. Shuning uchun bugun ham soatda 60 minut, minutda 60 sekund.</p><p>☀️ Qadimgi <b>Misr</b>da kun va tun 12 tadan qismga bo'lingan — bizning 24 soatli sutkamiz shundan.</p>",
 tn:"Savol: «60 ni nechta teng bo'lakka bo'lish mumkin?» — bolalar bo'luvchilarni topsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g44col(['2 soat 40 min','+ 1 soat 35 min'],'4 soat 15 min','','+1 soat');g4m('Vaqtda o‘tish — 60 da')},fin:function(){g44col(['2 soat 40 min','+ 1 soat 35 min'],'4 soat 15 min','','+1 soat');g4m('Vaqtda o‘tish — 60 da')},
 html:"<div class='memo'><ul><li>Ko'paytuvchilar: m–sm <b>100</b>, km–m va kg–g <b>1000</b>, t–s <b>10</b>, soat–min va min–s <b>60</b>.</li><li>Qo'shish: kichik birlik oshib ketsa — katta birlikka o'tkazing (75 min = 1 soat 15 min).</li><li>Ayirish: yetmasa — bitta katta birlikni maydalang (5 soat = 4 soat 60 min).</li><li>Ko'paytirish/bo'lish: avval bitta birlikka o'tish qulay; javobni yana ikki nomli yozing.</li><li>Ismli son : ismli son (bir xil birlikda) = <b>oddiy son</b> (necha marta).</li><li>Soatga vaqt qo'shish: butun soatlar, keyin minutlar; 60 dan oshsa — keyingi soat.</li></ul></div>",
 tn:"Uyga vazifa: kun tartibidan 3 ta ish davomiyligini hisoblash (masalan, maktabda o'tkazgan vaqt)."}
];
var PROBS=[
{t:"4 m 75 sm + 2 m 48 sm = ?",o:["7 m 23 sm","6 m 123 sm","6 m 23 sm","7 m 13 sm"],k:0,s:"75 + 48 = 123 sm = 1 m 23 sm; 4 + 2 + 1 = 7 m."},
{t:"8 kg 200 g − 3 kg 650 g = ?",o:["4 kg 550 g","5 kg 450 g","5 kg 550 g","4 kg 450 g"],k:0,s:"8200 − 3650 = 4550 g = 4 kg 550 g."},
{t:"2 soat 40 min + 1 soat 35 min = ?",o:["4 soat 15 min","3 soat 75 min","3 soat 15 min","4 soat 5 min"],k:0,s:"40 + 35 = 75 min = 1 soat 15 min; 2 + 1 + 1 = 4 soat."},
{t:"5 soat − 2 soat 25 min = ?",o:["2 soat 35 min","3 soat 25 min","2 soat 75 min","3 soat 35 min"],k:0,s:"5 soat = 4 soat 60 min; 60 − 25 = 35; 4 − 2 = 2."},
{t:"3 kg 250 g · 4 = ?",o:["13 kg","12 kg 250 g","12 kg 100 g","13 kg 250 g"],k:0,s:"3250 · 4 = 13 000 g = 13 kg."},
{t:"7 m 20 sm : 6 = ?",o:["1 m 20 sm","1 m 2 sm","12 sm","1 m 30 sm"],k:0,s:"720 sm : 6 = 120 sm = 1 m 20 sm."},
{t:"6 m lentadan 40 sm li nechta bo'lak chiqadi?",o:["15","24","150","1 m 50 sm"],k:0,s:"600 sm : 40 sm = 15."},
{t:"1 soat 20 min · 3 = ?",o:["4 soat","3 soat 20 min","3 soat 6 min","4 soat 20 min"],k:0,s:"80 min · 3 = 240 min = 4 soat."},
{t:"2 t 4 s + 3 t 8 s = ?",o:["6 t 2 s","5 t 12 s","5 t 2 s","6 t 12 s"],k:0,s:"4 + 8 = 12 s = 1 t 2 s; 2 + 3 + 1 = 6 t."},
{t:"10 km − 4 km 350 m = ?",o:["5 km 650 m","6 km 650 m","6 km 350 m","5 km 350 m"],k:0,s:"10 000 − 4350 = 5650 m = 5 km 650 m."},
{t:"Poyezd 13:50 da jo'nab, 3 soat 25 min yurdi. Qachon yetib keldi?",o:["17:15","16:75","16:15","17:25"],k:0,s:"13:50 + 3 soat = 16:50; + 25 min = 17:15."},
{t:"9 kg 600 g : 8 = ?",o:["1 kg 200 g","1 kg 20 g","1 kg 75 g","12 kg"],k:0,s:"9600 : 8 = 1200 g = 1 kg 200 g."},
{t:"Har biri 1 kg 250 g bo'lgan 5 ta qadoq jami qancha?",o:["6 kg 250 g","5 kg 250 g","6 kg 25 g","5 kg 1250 g"],k:0,s:"1250 · 5 = 6250 g = 6 kg 250 g."},
{t:"1 sutka − 7 soat 45 min = ?",o:["16 soat 15 min","17 soat 15 min","17 soat 55 min","16 soat 25 min"],k:0,s:"24 soat = 23 soat 60 min; 60 − 45 = 15; 23 − 7 = 16."},
{t:"15 m 30 sm arqon 6 ta teng bo'lakka bo'lindi. Har bo'lak?",o:["2 m 55 sm","2 m 5 sm","2 m 50 sm","3 m 5 sm"],k:0,s:"1530 : 6 = 255 sm = 2 m 55 sm."},
{t:"Sumka 3 kg 400 g. Unga 350 g dan 4 ta kitob solindi. Endi sumka qancha?",o:["4 kg 800 g","3 kg 750 g","7 kg 400 g","4 kg 400 g"],k:0,s:"350 · 4 = 1400 g; 3400 + 1400 = 4800 g = 4 kg 800 g."},
{t:"1 m lentadan 3 dm 5 sm qirqildi. Qancha qoldi?",o:["6 dm 5 sm","7 dm 5 sm","2 dm 5 sm","65 dm"],k:0,s:"100 − 35 = 65 sm = 6 dm 5 sm."},
{t:"Usta kuniga 7 soat 30 min ishlaydi. 6 kunda necha soat?",o:["45 soat","42 soat 30 min","43 soat","44 soat 30 min"],k:0,s:"7 · 6 = 42 soat, 30 · 6 = 180 min = 3 soat; 42 + 3 = 45 soat."},
{t:"4 kg 500 g olma 300 g dan paketlarga solindi. Nechta paket?",o:["15","150","13","5"],k:0,s:"4500 : 300 = 15."},
{t:"Shaharlar orasi 245 km. Avtobus soatiga 60 km tezlikda 3 soat 30 min yurdi. Qancha qoldi?",o:["35 km","65 km","185 km","45 km"],k:0,s:"3 soatda 180 km, 30 minutda 30 km: 210 km; 245 − 210 = 35 km."}
];
function PRACT_STAGE(){g44col(['4 m 75 sm','+ 2 m 48 sm'],'7 m 23 sm','','+1 m');g4m('100 · 1000 · 10 · 60 — har juftning o‘z ko‘paytuvchisi')}
var PREP_DATA={teach:["Ismli sonni bitta birlikka o'tkazish (100, 1000, 10, 60).","Qo'shish (o'tkazish) va ayirish (maydalash) ustunda.","Ismli sonni songa ko'paytirish va bo'lish.","Ismli sonni ismli songa bo'lish (necha marta); soatga vaqt qo'shish."],
 mist:["Vaqtda 100 lik o'tish: 3 soat 75 min, 2 soat 75 min.","Ko'paytirishda kichik birlikni ko'paytirishni unutadi.","Bo'lishda birliklarni bir xil qilmaydi (6 m : 40 sm = 6 : 40).","Javobni «12 kg 1000 g» ko'rinishida qoldiradi."],
 need:["Karton soat.","Lenta, ip, metrli tasma.","Tarozi va qadoqlangan mahsulotlar."],
 board:["<span class='w2'>4 m 75 sm + 2 m 48 sm = 7 m 23 sm</span>.","<span class='w2'>8 kg 200 g = 7 kg 1200 g</span>.","<span class='w2'>2 soat 40 min + 1 soat 35 min = 4 soat 15 min</span>.","<span class='w2'>6 m : 40 sm = 600 : 40 = 15</span>."]};
