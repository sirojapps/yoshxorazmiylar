var CODE='3B7',TITLE='3-sinf · Ko‘p xonali sonlarni qo‘shish va ayirish';
var W3B7L=['birliklar','o‘nliklar','yuzliklar','minglar','o‘n minglar','yuz minglar'];
function w3b7P(a,b,op,last){var r=op==='+'?a+b:a-b,n=String(Math.max(a,b,r)).length,P=[],sa=String(a),sb=String(b),c=0,msgs=[];
 for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0),m;
  if(op==='+'){var s=da+db+c;m=W3B7L[k]+': '+da+' + '+db+(c?' + 1':'')+' = '+s+(s>9?' → '+(s%10)+' yozamiz, 1 o‘tadi':'');c=s>9?1:0}
  else{var x=da-c;if(x<db){m=W3B7L[k]+': '+x+' dan '+db+' ayrilmaydi → qarz: '+(x+10)+' − '+db+' = '+(x+10-db);c=1}else{m=W3B7L[k]+': '+x+' − '+db+' = '+(x-db);c=0}}
  msgs.push(m)}
 P.push(function(){bqCol(a,b,op,0);bqMsg('Xonalarni ustma-ust yozdik. O‘ngdan — birliklardan boshlaymiz')});
 msgs.forEach(function(m,k){P.push(function(){bqCol(a,b,op,k+1,{hl:k});bqMsg(k===n-1?m+'<br><b>Javob: '+r.toLocaleString('ru').replace(/,/g,' ')+'</b>'+(last?' — '+last:''):m)})});return P}
function w3b7c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
var P2=w3b7P(3758,2465,'+'),P3=w3b7P(47856,28579,'+'),P4=w3b7P(8352,3768,'-'),P5=w3b7P(40005,12368,'-'),P6=w3b7P(52304,7896,'+','ko‘p o‘tkazish zanjiri');
function w3b7F(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w3b7S(P){return function(){startPh(P)}}
var STEPS=[
{h:"Xonama-xona yozish",sum:"Ko'p xonali sonlarni ustunda yozishda birlik — birlik ostiga, o'nlik — o'nlik ostiga. O'ng chetdan tekislaymiz.",a:"m01",start:function(){bqExpr(['  4523','+ 368 ?']);bqMsg('368 ni qanday yozish kerak?')},fin:function(){bqCol(4523,368,'+',null);bqMsg('O‘ng chet bo‘yicha tekislandi: 4891')},
 html:"<p>4523 + 368 ni ustunda yozamiz. Qaysi yozuv to'g'ri?</p>",g2:1,
 btns:[["368 — o'ng chetga (birlik ostida birlik)",function(c,d,b){bqCol(4523,368,'+',null);w3b7c(b,d,1,'To‘g‘ri: 8 — 3 ostida, 6 — 2 ostida, 3 — 5 ostida. Javob 4891','')}],["368 — chap chetga (4 ostida 3)",function(c,d,b){bqExpr(['  4523','+ 368_','= 8203 ?']);w3b7c(b,d,0,'','Unda 3 yuzlik minglar ostiga tushadi — 368 ni 3680 qilib qo‘shgan bo‘lasiz!')}]],
 after:"<p>Asosiy qoida: <b>bir xil xonalar ustma-ust</b>. Sonlar o'ng chetdan tekislanadi, chunki o'ng chetda doim birliklar turadi. Chap chetdan tekislash — eng ko'p uchraydigan xato.</p>",
 q:{t:"6 207 + 85 ni noto'g'ri (chap chetdan) yozgan bola qanday javob oladi?",opts:["14 707","6 292","6 1287","7 057"],ok:0,why:"85 ni 8500 deb qo'shgan: 6207 + 8500 = 14 707.",hint:"Chap chetdan yozilsa, 85 qaysi son bo'lib qoladi?",full:"Chap chetdan yozilsa, 8 minglar ostiga, 5 yuzliklar ostiga tushadi — bu 8500. 6207 + 8500 = 14 707. To'g'ri javob esa 6207 + 85 = 6292."},
 tn:"Katakli daftar: har raqam alohida katakka. Xona nomlarini (b, o', y, m, o'm) ustunlar tepasiga yozdiring."},
{h:"To'rt xonali sonlarni qo'shish",sum:"3758 + 2465 = 6223: har xonada 10 dan oshsa — 1 keyingi xonaga o'tadi.",a:"m02",start:w3b7S(P2),fin:w3b7F(P2),
 html:"<p>Uch xonali sonlar kabi — faqat xonalar ko'proq. Bosqichma-bosqich kuzating:</p>",btns:[phaser(P2)],
 after:"<p>Qoida o'zgarmaydi: <b>o'ngdan chapga</b>, har xonada qo'shamiz, 10 va undan ortiq bo'lsa — birlikni yozib, <b>1 ni keyingi xonaga</b> o'tkazamiz. Kichik «1» ni ustunning tepasiga yozib qo'ying.</p>",
 q:{t:"4687 + 3546 = ?",opts:["8233","7123","8133","7233"],ok:0,why:"7 + 6 = 13, 8 + 4 + 1 = 13, 6 + 5 + 1 = 12, 4 + 3 + 1 = 8: 8233.",hint:"Har xonada o'tgan 1 ni unutmang.",full:"Birliklar 13 → 3 (1 o'tadi); o'nliklar 8 + 4 + 1 = 13 → 3; yuzliklar 6 + 5 + 1 = 12 → 2; minglar 4 + 3 + 1 = 8. Javob 8233. «7123» — o'tkazilgan birliklar qo'shilmagan."},
 tn:"Yaponiya usuli: bola har xonani ovoz chiqarib aytsin — «birliklar: 8 va 5 — 13, 3 yozaman, 1 eslab qolaman»."},
{h:"Besh xonali sonlar",sum:"47 856 + 28 579 = 76 435. Besh xonali sonlarni o'qishda uch raqamli guruhlar orasiga bo'sh joy qo'yamiz.",a:"m03",start:w3b7S(P3),fin:w3b7F(P3),
 html:"<p>47 856 (qirq yetti ming sakkiz yuz ellik olti) + 28 579. Ketma-ket o'tkazishlarni kuzating:</p>",btns:[phaser(P3)],
 after:"<p>Besh xonali sonlarda ham xuddi shunday. Javobni o'qing: <b>76 435</b> — yetmish olti ming to'rt yuz o'ttiz besh. Katta sonlarni o'ngdan 3 raqamdan guruhlab yozish o'qishni osonlashtiradi.</p>",
 q:{t:"35 678 + 46 945 = ?",opts:["82 623","81 623","82 523","71 513"],ok:0,why:"8+5=13, 7+4+1=12, 6+9+1=16, 5+6+1=12, 3+4+1=8: 82 623.",hint:"Bu misolda har bir xonada o'tkazish bor!",full:"13 → 3, 12 → 2, 16 → 6, 12 → 2, 3 + 4 + 1 = 8. Javob 82 623. «71 513» — birorta ham o'tkazish qo'shilmagan."},
 tn:"Chamani ham so'rang: 48 000 + 29 000 ≈ 77 000. Javob 76 435 — mos."},
{h:"Ko'p xonali sonlarni ayirish",sum:"8352 − 3768 = 4584: ayrilmasa — keyingi xonadan 1 qarz olamiz.",a:"m04",start:w3b7S(P4),fin:w3b7F(P4),
 html:"<p>Ayirishda ham o'ngdan boshlaymiz. Qarz olishlarni kuzating:</p>",btns:[phaser(P4)],
 after:"<p>Qarz olsak, chapdagi raqam <b>1 ga kamayadi</b> (ustiga nuqta qo'ying), bu xonadagi raqam esa <b>10 ga ko'payadi</b>. Bu misolda uch marta ketma-ket qarz olindi.</p>",
 q:{t:"7214 − 2856 = ?",opts:["4358","5642","4458","5368"],ok:0,why:"14 − 6 = 8, 10 − 5 = 5, 11 − 8 = 3, 6 − 2 = 4: 4358.",hint:"Har xonada qarz kerakmi — tekshiring. Qarz bergan raqam 1 ga kamayadi.",full:"14 − 6 = 8; o'nliklar (1 − 1 = 0) dan 5 ayrilmaydi: 10 − 5 = 5; yuzliklar (2 − 1 = 1) dan 8 ayrilmaydi: 11 − 8 = 3; minglar 7 − 1 − 2 = 4. Javob 4358. «5642» — har xonada kattadan kichik ayirilgan («teskari ayirish»)."},
 tn:"Pul bilan: 1000 so'mlik qog'ozni 100 so'mliklarga «maydalash» — qarz olishning hayotiy ma'nosi."},
{h:"Tuzoq: nollardan qarz olish",sum:"40 005 − 12 368 = 27 637: nollar zanjiri 9 ga aylanadi.",a:"m05",start:w3b7S(P5),fin:w3b7F(P5),
 html:"<p>Eng qiyin holat: qarz so'raladigan xonalarda <b>nol</b>. Qarz uzoqdan — o'n minglardan keladi:</p>",btns:[phaser(P5)],
 after:"<p>4 o'n minglikdan 1 tasini maydalaymiz: <b>40 005 = 39 99(15)</b> — ya'ni 3 o'n ming, 9 ming, 9 yuz, 9 o'n va 15 birlik. Shunda har xonadan bemalol ayirish mumkin. Nollar <b>9</b> ga, oxirgisi esa <b>10 ga ortadi</b>.</p>",
 q:{t:"60 003 − 24 586 = ?",opts:["35 417","36 417","35 517","44 583"],ok:0,why:"59 99(13) − 24 586: 13 − 6 = 7, 9 − 8 = 1, 9 − 5 = 4, 9 − 4 = 5, 5 − 2 = 3: 35 417.",hint:"60 003 ni 5 o'n ming, 9 ming, 9 yuz, 9 o'n va 13 birlik deb tasavvur qiling.",full:"13 − 6 = 7, 9 − 8 = 1, 9 − 5 = 4, 9 − 4 = 5, 5 − 2 = 3. Javob 35 417. «36 417» — o'n minglardan olingan qarz unutilgan. «44 583» — nollar ustida teskari ayirilgan."},
 tn:"Yana bir yo'l (3B5 dan): ikkalasidan 4 ni ayiring — 59 999 − 24 582 = 35 417, qarz umuman kerak emas."},
{h:"Xonalari turlicha sonlar",sum:"52 304 + 7 896 = 60 200: qisqa sonni o'ng chetga yozamiz, o'tkazishlar zanjiri.",a:"m06",start:w3b7S(P6),fin:w3b7F(P6),
 html:"<p>Besh xonali va to'rt xonali son. O'tkazishlar ketma-ket «yuguradi»:</p>",btns:[phaser(P6)],
 after:"<p>To'rt xonali son o'n minglar xonasiga yetmaydi — u yerda «bo'sh» (0 deb hisoblang). Ketma-ket o'tkazishlarda javobda <b>nollar</b> paydo bo'lishi mumkin: 60 200. Bu xato emas!</p>",
 q:{t:"89 765 + 10 235 = ?",opts:["100 000","99 990","90 000","99 000"],ok:0,why:"5+5=10, 6+3+1=10, 7+2+1=10, 9+0+1=10, 8+1+1=10 → 100 000.",hint:"Har xonada 10 chiqadi — o'tkazish oxirgi xonadan ham chiqib ketadi.",full:"Har xonada yig'indi 10: 0 yozib, 1 o'tkazamiz. Oxirgi 1 yangi xona — yuz minglarni ochadi: 100 000 (yuz ming). «99 990» — o'tkazishlar unutilgan."},
 tn:"«Do'st sonlar» ko'p xonali: 89 765 va 10 235. Bolalar o'zi 100 000 ga to'ldiruvchi juftlar tuzsin."},
{h:"Ayirishni qo'shish bilan tekshirish",sum:"Ayirma + ayriluvchi = kamayuvchi. 8352 − 3768 = 4584, tekshiruv: 4584 + 3768 = 8352.",a:"m07",start:function(){bqExpr(['73 402 − 28 756 = 45 646 ?']);bqMsg('Javobni qo‘shish bilan tekshiring')},fin:function(){bqCol(44646,28756,'+',null);bqMsg('44 646 + 28 756 = 73 402 ✓')},
 html:"<p>Zafar 73 402 − 28 756 = <b>45 646</b> deb yozdi. Tekshirish uchun nima qilasiz?</p>",g2:1,
 btns:[["45 646 + 28 756 ni hisoblayman",function(c,d,b){bqCol(45646,28756,'+',null);w3b7c(b,d,1,'45 646 + 28 756 = 74 402 ≠ 73 402. Xato! To‘g‘ri javob 44 646','')}],["45 646 − 28 756 ni hisoblayman",function(c,d,b){w3b7c(b,d,0,'','Tekshiruvda teskari amal kerak: ayirma + ayriluvchi = kamayuvchi')}],["73 402 + 28 756 ni hisoblayman",function(c,d,b){w3b7c(b,d,0,'','Bu bilan hech narsa tekshirilmaydi — javob (45 646) ishtirok etmayapti')}],["45 646 + 73 402 ni hisoblayman",function(c,d,b){w3b7c(b,d,0,'','Kamayuvchiga qo‘shish kerak emas — ayirma + ayriluvchi = kamayuvchi')}]],
 after:"<p>Tekshiruv 74 402 berdi — 1000 ga ko'p. Demak minglar xonasida qarz unutilgan. To'g'ri javob <b>44 646</b>: 44 646 + 28 756 = 73 402 ✓. Ko'p xonali misollarda tekshiruv — majburiy odat.</p>",
 q:{t:"Qaysi javob to'g'ri: 50 000 − 1 = ?",opts:["49 999","40 999","49 990","4 999"],ok:0,why:"49 999 + 1 = 50 000 ✓.",hint:"Tekshiring: javob + 1 = 50 000 bo'lishi kerak.",full:"50 000 dan 1 kam — 49 999. «40 999» — faqat bitta xona qarz bergan deb o'ylangan; «4 999» — xona yo'qolgan."},
 tn:"Har ayirish misolidan keyin tekshiruvni qisqa, «o'ng tomonda» yozish odat bo'lsin."},
{h:"Bilasizmi? Al-Xorazmiy va o'nli sanoq",sum:"Muhammad al-Xorazmiyning hind raqamlari haqidagi kitobi Yevropaga o'nli pozitsion sanoq va ustunda hisoblashni tanitgan.",a:"m08",start:function(){bqExpr(['MMCDLVI + MCCCXLV = ?']);bqMsg('Rim raqamlarida ustunda qo‘shib bo‘ladimi?')},fin:function(){bqExpr(['2456 + 1345 = [3801]']);bqMsg('O‘nli sanoq bilan — oson!')},
 html:"<p>🎓 Vatandoshimiz <b>Muhammad ibn Muso al-Xorazmiy</b> (IX asr) hind raqamlari bilan hisoblash haqida kitob yozgan. Uning lotincha tarjimasi Yevropada o'nli sanoq va ustunda hisoblashning tarqalishiga sabab bo'ldi. «Algoritm» so'zi ham uning nomidan — <b>Algoritmi</b> — kelib chiqqan.</p>",
 btns:[["💡 Rim raqamlarini bizning raqamlarga o'giring",function(c,done){bqExpr(['MMCDLVI = 2456','MCCCXLV = 1345','2456 + 1345 = [3801]']);bqMsg('Pozitsion sanoqda xonalar ustma-ust keladi');done()}]],
 after:"<p>Rim raqamlarida xonalar yo'q — shuning uchun ustunda qo'shib bo'lmaydi. Al-Xorazmiy tanitgan tizimda esa raqamning <b>o'rni</b> uning qiymatini bildiradi — bugungi darsdagi barcha usullar shunga asoslangan.</p>",
 tn:"Xiva va Xorazm haqida qisqa suhbat; Toshkent va Xivadagi al-Xorazmiy haykallari rasmini ko'rsatish mumkin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqCol(40005,12368,'-',null);bqMsg('O‘ngdan chapga, xonama-xona')},fin:function(){bqCol(40005,12368,'-',null);bqMsg('O‘ngdan chapga, xonama-xona')},
 html:"<div class='memo'><ul><li>Sonlarni <b>o'ng chetdan</b> tekislang: birlik ostida birlik.</li><li><b>O'ngdan chapga</b> hisoblang.</li><li>Qo'shishda 10 dan oshsa — 1 keyingi xonaga o'tadi.</li><li>Ayirishda ayrilmasa — chapdan 1 qarz (u xona 1 ga kamayadi).</li><li>Nollardan qarz: 40 005 → 3 | 9 | 9 | 9 | 15.</li><li>Chamalang va <b>tekshiring</b>: ayirma + ayriluvchi = kamayuvchi.</li></ul></div>",
 tn:"Keyingi darsda 2 daqiqalik «xatoni top» mashqi: ko'p xonali misollar, har birida bitta tipik xato."}
];
var PROBS=[
{t:"2345 + 4132 = ?",o:["6477","6467","6377","5477"],k:0,s:"Xonama-xona, o'tkazishsiz: 6477."},
{t:"5687 + 2456 = ?",o:["8143","7033","8043","8133"],k:0,s:"13 → 3, 8 + 5 + 1 = 14 → 4, 6 + 4 + 1 = 11 → 1, 5 + 2 + 1 = 8: 8143."},
{t:"9473 − 5231 = ?",o:["4242","4342","4232","3242"],k:0,s:"Qarzsiz: 4242."},
{t:"6204 − 3857 = ?",o:["2347","3653","2447","3457"],k:0,s:"14 − 7 = 7, 9 − 5 = 4, 11 − 8 = 3, 5 − 3 = 2: 2347."},
{t:"34 567 + 23 486 = ?",o:["58 053","57 053","58 043","57 943"],k:0,s:"13, 15, 10, 8, 5 (o'tkazishlar bilan): 58 053."},
{t:"70 000 − 34 528 = ?",o:["35 472","45 472","36 472","35 482"],k:0,s:"69 999 − 34 527 = 35 472."},
{t:"4 263 + 85 ni noto'g'ri, chap chetdan yozgan bola qanday javob oladi?",o:["12 763","4 348","4 1113","5 113"],k:0,s:"85 → 8500: 4263 + 8500 = 12 763. To'g'risi 4348."},
{t:"Qaysi misolda qarz olish kerak emas?",o:["8765 − 4321","8765 − 4329","8705 − 4321","8065 − 4321"],k:0,s:"8765 − 4321: har xonada yuqori raqam katta yoki teng."},
{t:"48 312 − 19 785 = ?",o:["28 527","29 527","28 537","31 473"],k:0,s:"12 − 5 = 7, 10 − 8 = 2, 12 − 7 = 5, 7 − 9 → 17 − 9 = 8, 3 − 1 = 2: 28 527."},
{t:"Tekshiruv: 52 614 − 27 839 = 24 775. Qanday tekshirasiz va javob to'g'rimi?",o:["24 775 + 27 839 = 52 614 — to'g'ri","24 775 + 27 839 = 52 614 — xato","52 614 + 27 839 — xato","24 775 − 27 839 — to'g'ri"],k:0,s:"24 775 + 27 839 = 52 614 ✓."},
{t:"99 999 + 1 = ?",o:["100 000","99 990","1 000 000","10 000"],k:0,s:"Har xonada 10 → 0 va 1 o'tadi: 100 000."},
{t:"100 000 − 1 = ?",o:["99 999","9 999","90 999","99 990"],k:0,s:"99 999 + 1 = 100 000 ✓."},
{t:"Do'konda bir kunda 12 485 so'mlik, ertasiga 9 768 so'mlik non sotildi. Ikki kunda jami?",o:["22 253 so'm","21 253 so'm","22 153 so'm","2 717 so'm"],k:0,s:"12 485 + 9 768 = 22 253."},
{t:"Shaharda 45 300 kishi yashaydi, ulardan 18 754 tasi bolalar. Kattalar nechta?",o:["26 546","27 546","26 646","33 454"],k:0,s:"45 300 − 18 754 = 26 546."},
{t:"Qaysi son 38 476 dan 9 999 ta ko'p?",o:["48 475","48 476","47 475","48 465"],k:0,s:"38 476 + 10 000 − 1 = 48 475."},
{t:"□ − 27 368 = 15 789. □ = ?",o:["43 157","11 579","42 157","43 057"],k:0,s:"Kamayuvchi = 15 789 + 27 368 = 43 157."},
{t:"62 □05 − 3□ 478 = 2□ 627 — bu yerda □ lar turli raqamlar bo'lishi mumkin. Javob 28 627 bo'lsa, kamayuvchi nechaga teng?",o:["62 105","62 205","62 005","61 105"],k:0,s:"Ayriluvchi = kamayuvchi − ayirma. 28 627 + 33 478 = 62 105 (yuzliklar 1)."},
{t:"Eng katta besh xonali son va eng kichik besh xonali son ayirmasi?",o:["89 999","90 000","9 999","89 000"],k:0,s:"99 999 − 10 000 = 89 999."},
{t:"Ali 60 004 − 25 637 = 44 467 deb yozdi. Qaysi xatoni qildi?",o:["O'n minglardan olingan qarzni unutdi","Birliklarda teskari ayirdi","Sonlarni chap chetdan yozdi","Xato yo'q"],k:0,s:"To'g'ri javob 34 367. 44 467 — o'n minglarda 6 − 2 = 4 deb olingan (qarz unutilgan), qolgan xonalarda ham 1 ortiqcha: aslida 59 99(14) − 25 637."},
{t:"a + 8 765 = 20 000. a = ?",o:["11 235","12 235","11 245","28 765"],k:0,s:"20 000 − 8 765 = 19 999 − 8 764 = 11 235."}
];
PROBS[16]={t:"Kamayuvchi 6□ 105, ayriluvchi 33 478, ayirma 28 627. □ o'rnida qaysi raqam?",o:["2","1","3","0"],k:0,s:"28 627 + 33 478 = 62 105 — □ = 2."};
PROBS[18]={t:"Ali 60 004 − 25 637 ni hisoblab 45 633 javob oldi. Qaysi xatoni qildi?",o:["Har xonada kattadan kichikni ayirdi (teskari ayirish)","O'n minglardan olingan qarzni unutdi","Sonlarni chap chetdan yozdi","Xato yo'q"],k:0,s:"To'g'ri javob 34 367. Ali 7 − 4 = 3, 3 − 0 = 3, 6 − 0 = 6, 5 − 0 = 5, 6 − 2 = 4 deb hisoblagan — har xonada teskari."};
function PRACT_STAGE(){bqCol(47856,28579,'+',null);bqMsg('O‘ngdan chapga, xonama-xona')}
var PREP_DATA={teach:["Ko'p xonali sonlarni o'ng chetdan tekislab yozish.","To'rt va besh xonali sonlarni o'tkazish bilan qo'shish.","Qarz bilan ayirish, nollardan qarz olish.","Xonalari turlicha sonlar; javobni qo'shish bilan tekshirish."],
 mist:["Qisqa sonni chap chetdan yozadi.","O'tkazilgan 1 ni unutadi.","Teskari ayiradi (kattadan kichikni).","Nollardan qarzda: faqat bitta xonani o'zgartiradi."],
 need:["Katakli daftar, xona nomlari yozilgan jadval.","Pul kartochkalari: 10 000, 1000, 100, 10, 1."],
 board:["<span class='w2'>3758 + 2465 = 6223</span>","<span class='w2'>47 856 + 28 579 = 76 435</span>","<span class='w2'>40 005 − 12 368 = 27 637</span>","<span class='w2'>Tekshiruv: 27 637 + 12 368 = 40 005</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<n)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=Math.max(W*p/tot,34);E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,p+' · '+b+' = '+(p*b),{'font-size':w<70?10:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
