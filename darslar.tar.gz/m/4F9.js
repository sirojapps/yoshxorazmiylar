// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F9',TITLE='4-sinf · O‘nli kasr: o‘ndan, yuzdan, mingdan birlar';
// 10x10 to'r: nCells ta katak (ustunma-ustun) bo'yalgan
function f9grid(x,y,s,n,col){var g=E('g',{},S.g);for(var c=0;c<10;c++)for(var r=0;r<10;r++){var k=c*10+r;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:k<n?(col||C.b):'#fff',stroke:'#c9d6e2','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:'#33475b','stroke-width':1.6},g);return g}
var F9P2=[function(){clear();f9grid(30,14,14.5,0);f4t(260,40,'1 butun',14);f4t(260,64,'= 100 ta katak',13,'#33475b');f4c(['Kvadrat — 1 butun, 100 ta teng katak'])},
 function(){clear();f9grid(30,14,14.5,1,C.a);f4t(260,40,'1 katak',14,C.a2);f4t(260,70,'1/100 = 0,01',16,C.a2);f4t(260,96,'«nol butun yuzdan bir»',11,'#33475b');f4c(['Bitta katak — <b>yuzdan bir</b>: 1/100 = <b>0,01</b>'])},
 function(){clear();f9grid(30,14,14.5,20);f4t(260,40,'2 ustun',14,C.blue);f4t(260,70,'20/100 = 0,2',16,C.blue);f4t(260,96,'(2 ta o‘ndan bir)',11,'#33475b');f4c(['Bitta ustun — 10 katak = 1/10 = 0,1. Ikki ustun — 0,2'])},
 function(){clear();f9grid(30,14,14.5,23);f4t(260,40,'2 ustun + 3 katak',13,C.blue);f4t(260,72,'23/100 = 0,23',17,C.ok);f4t(260,98,'«nol butun yuzdan',11,'#33475b');f4t(260,114,'yigirma uch»',11,'#33475b');f4c(['0,23: 2 ta o‘ndan bir va 3 ta yuzdan bir = <b>23/100</b>'])}];
// xonalar jadvali
var F9H=['butun','o‘ndan','yuzdan','mingdan'];
function f9table(digs,show){clear();var x0=40,w=70,y=40;F9H.forEach(function(h,i){E('rect',{x:x0+i*w,y:y,width:w,height:28,fill:i?'#e8f2fb':'#fff2dc',stroke:'#9bb3c9'},S.g);f4t(x0+i*w+w/2,y+19,h,12,'#33475b');E('rect',{x:x0+i*w,y:y+28,width:w,height:48,fill:'#fff',stroke:'#9bb3c9'},S.g);if(i<show)f4t(x0+i*w+w/2,y+62,digs[i],26,i?C.blue:C.a2)});
 E('circle',{cx:x0+w,cy:y+68,r:4,fill:C.bad},S.g);f4t(x0+w,y+104,'vergul',10,C.bad)}
var F9P3=[function(){f9table(['3','5','0','7'],0);f4c(['3,507 sonini jadvalga yozamiz'])},function(){f9table(['3','5','0','7'],1);f4c(['Verguldan chapda — <b>butun qism</b>: 3'])},function(){f9table(['3','5','0','7'],2);f4c(['Verguldan keyingi 1-raqam — <b>o‘ndan birlar</b>: 5 ta 1/10'])},function(){f9table(['3','5','0','7'],3);f4c(['2-raqam — <b>yuzdan birlar</b>: 0 ta'])},function(){f9table(['3','5','0','7'],4);f4c(['3-raqam — <b>mingdan birlar</b>: 7 ta 1/1000','3,507 = 3 507/1000 — «uch butun mingdan besh yuz yetti»'])}];
var F9P7=[function(){clear();f4t(180,36,'3/10 = 0,3',18,C.blue);f4c(['Maxraj 10 — verguldan keyin 1 ta raqam'])},
 function(){clear();f4t(180,36,'3/10 = 0,3',18,C.blue);f4t(180,70,'7/100 = 0,07',18,C.blue);f4c(['Maxraj 100 — verguldan keyin 2 ta raqam: 0,<b>07</b> (0 ni unutmang!)'])},
 function(){clear();f4t(180,36,'3/10 = 0,3',16,C.blue);f4t(180,66,'7/100 = 0,07',16,C.blue);f4t(180,100,'1/2 = 5/10 = 0,5',16,C.a2);f4c(['1/2 ni maxraji 10 bo‘lgan kasrga keltiramiz: 1/2 = 5/10'])},
 function(){clear();f4t(180,30,'3/10 = 0,3',15,C.blue);f4t(180,58,'7/100 = 0,07',15,C.blue);f4t(180,88,'1/2 = 5/10 = 0,5',15,C.a2);f4t(180,120,'1/4 = 25/100 = 0,25',15,C.a2);f4t(180,152,'3/4 = 75/100 = 0,75',15,C.a2);f4c(['1/4 = 25/100 = <b>0,25</b>; 3/4 = <b>0,75</b> — pul kabi: 25 tiyin chorak so‘m'])}];
function f9nl(st){clear();var X=f4line(100,0,2,10,24,312,function(q,big){return big?String(q/10):''});var pts=[[.4,'0,4',C.blue],[1.3,'1,3',C.a2],[.85,'0,85',C.ok]];
 pts.forEach(function(p,i){if(i>=st)return;E('circle',{cx:X(p[0]),cy:100,r:6,fill:p[2],stroke:'#fff','stroke-width':2},S.g);f4t(X(p[0]),78-(i===2?18:0),p[1],13,p[2])});if(st>=3){f4arc(X(.8),X(.9),100,14,'',C.ok);f4t(180,150,'0,85 — 0,8 va 0,9 ning qoq o‘rtasida',12,C.ok)}}
var F9P8=[function(){f9nl(0);f4c(['0 dan 2 gacha, har butun 10 ga bo‘lingan: qadam 0,1'])},function(){f9nl(1);f4c(['0,4 — 0 dan 4 qadam'])},function(){f9nl(2);f4c(['1,3 — 1 dan keyin yana 3 qadam'])},function(){f9nl(3);f4c(['0,85 — 0,8 va 0,9 orasida: <b>0,80 &lt; 0,85 &lt; 0,90</b>','Har qanday ikki o‘nli kasr orasida yana son bor!'])}];
function PRACT_STAGE(){f9table(['3','5','0','7'],4);f4c(['1/10 = 0,1 · 1/100 = 0,01 · 1/1000 = 0,001'])}
var STEPS=[
{h:"O'ndan bir: 0,1",sum:"Butunni 10 ta teng bo'lakka bo'lsak, bitta bo'lak 1/10 = 0,1. 3 ta bo'lak — 3/10 = 0,3.",a:"m01",
 start:function(){clear();f4t(180,26,'Tasma — 1 butun, 10 ta teng bo‘lak',13);f4tapBar(20,44,320,44,10,function(k){f4c(['Bo‘yaldi: '+k+' ta → '+k+'/10 = <b>0,'+k+'</b>']);if(k===3&&S.cb3)S.cb3()},C.b);f4c(['Bo‘laklarni bosing: 3 ta kerak'])},
 fin:function(){clear();f4t(180,26,'3/10 = 0,3',16,C.ok);f4bar(20,44,320,44,10,3,C.b,['0,1','0,1','0,1']);f4Br(20,20+96,92,'0,3',false,C.ok);f4c(['3/10 = <b>0,3</b> — «nol butun o‘ndan uch»'])},
 html:"<p>Maxraji 10, 100, 1000 bo'lgan kasrlarni <b>vergul</b> bilan qisqa yozish mumkin. Tasmaning 3/10 qismini bo'yang — bo'laklarni bosing:</p>",
 act:function(c,done){S.cb3=function(){S.cb3=null;f4c(['3/10 = <b>0,3</b> — «nol butun o‘ndan uch»']);done()}},
 after:"<p>1/10 = <b>0,1</b> («nol butun o'ndan bir»). Verguldan chapda — <b>butun qism</b> (bu yerda 0), verguldan keyingi birinchi raqam — <b>o'ndan birlar</b> soni. Bunday kasrlar <b>o'nli kasr</b> deyiladi.</p>",
 q:{t:"7/10 o'nli kasr ko'rinishida qanday yoziladi?",opts:["0,7","7,10","0,07","7,0"],ok:0,why:"7 ta o'ndan bir — 0,7.",hint:"Maxraj 10 — verguldan keyin nechta raqam bo'ladi?",full:"7/10 = 0,7: butun qism 0, o'ndan birlar 7. «0,07» — bu 7/100, «7,10» — surat va maxrajni vergul bilan yozish (xato)."},
 tn:"O'nli kasrni pul orqali kiritish qulay: 1 so'm = 100 tiyin. Lekin avval tasma va 10×10 kvadrat bilan — bu IES tavsiyasidagi «bir nechta ko'rinish» tamoyili."},
{h:"Yuzdan bir: 0,01",sum:"100 katakli kvadratda 1 katak = 1/100 = 0,01. 2 ustun va 3 katak = 23/100 = 0,23.",a:"m02",
 start:function(){startPh(F9P2)},fin:function(){S.ph=3;F9P2[3]()},
 html:"<p>Endi butun — <b>100 ta katakli</b> kvadrat. Bitta katak qanday yoziladi? Bosing:</p>",btns:[phaser(F9P2)],
 after:"<p>1/100 = <b>0,01</b> — verguldan keyin <b>ikki</b> raqam. Bitta ustun (10 katak) — 1/10 = 0,1 = 0,10. Demak 0,23 = 2 ta o'ndan bir + 3 ta yuzdan bir = <b>23/100</b>.</p>",
 q:{t:"45/100 o'nli kasr ko'rinishida qanday yoziladi?",opts:["4,5","0,45","0,045","45,100"],ok:1,why:"Maxraj 100 — 2 ta raqam: 0,45.",hint:"Maxraj 100 — verguldan keyin nechta raqam?",full:"45/100 = 0,45 («nol butun yuzdan qirq besh»). «4,5» = 45/10, «0,045» = 45/1000."},
 tn:"10×10 kvadratni har bir bolaga tarqating. 0,23 ni bo'yatganda «2 ustun va 3 katak» deb aytsin — bu o'nli kasrni xona birliklari bilan bog'laydi."},
{h:"Xonalar jadvali",sum:"3,507: 3 — butun, 5 — o'ndan birlar, 0 — yuzdan birlar, 7 — mingdan birlar.",a:"m03",
 start:function(){startPh(F9P3)},fin:function(){S.ph=4;F9P3[4]()},
 html:"<p>Butun sonlarda xonalar bor edi: birlar, o'nlar, yuzlar. O'nli kasrda vergul o'ngida ham xonalar bor! 3,507 ni joylaymiz:</p>",btns:[phaser(F9P3)],
 after:"<p>Verguldan keyingi xonalar: <b>o'ndan birlar</b> (1/10), <b>yuzdan birlar</b> (1/100), <b>mingdan birlar</b> (1/1000). Har xona chapdagisidan <b>10 marta kichik</b> — butun sonlardagidek!</p><p>O'qilishi: oxirgi raqam qaysi xonada bo'lsa, shunday aytiladi: 3,507 — «uch butun <b>mingdan</b> besh yuz yetti».</p>",
 q:{t:"6,382 sonida 8 raqami qaysi xonada turibdi?",opts:["o'ndan birlar","yuzdan birlar","mingdan birlar","birlar"],ok:1,why:"Verguldan keyin 2-o'rinda.",hint:"Verguldan keyin sanang: 1-o'rin, 2-o'rin…",full:"6,382: 3 — o'ndan birlar, 8 — yuzdan birlar, 2 — mingdan birlar. 8 ning qiymati 8/100 = 0,08."},
 tn:"Doskadagi xonalar jadvalini butun sonlar jadvalining davomi qilib chizing: … yuzlar | o'nlar | birlar , o'ndan | yuzdan | mingdan. Simmetriya birlar atrofida."},
{h:"O'qish va yozish",sum:"2,05 — «ikki butun yuzdan besh»: 5 yuzdan birlar xonasida, o'ndan birlar xonasida 0.",a:"m04",
 start:function(){clear();f4t(180,70,'2,05',40,C.blue);f4msg('Bu son qanday o‘qiladi?')},
 fin:function(){f9table(['2','0','5',''],3);f4msg('2,05 — «ikki butun <b>yuzdan</b> besh»')},
 html:"<p>2,05 sonini qanday o'qiysiz? Tanlang:</p>",
 btns:f4pick(1,[["ikki butun o'ndan besh","Unda 2,5 yozilardi. 2,05 da 5 — ikkinchi o'rinda."],["ikki butun yuzdan besh","To'g'ri! Oxirgi raqam (5) yuzdan birlar xonasida."],["ikki butun besh","Kasr qismi qanday birliklarda ekanini aytish shart."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>O'ndan birlar xonasidagi <b>0</b> — muhim: u «o'ndan birlar yo'q» deydi va 5 ni yuzdan birlar xonasiga suradi. 2,5 va 2,05 — boshqa-boshqa sonlar.</p>",
 q:{t:"Qaysi yozuv «nol butun mingdan o'n yetti»?",opts:["0,17","0,017","0,0017","17,1000"],ok:1,why:"Mingdan — 3 ta raqam: 0,017.",hint:"Mingdan birlar — verguldan keyin nechta raqam bo'lishi kerak?",full:"Mingdan birlar — verguldan keyin 3 ta raqam: 17 ni 3 xonaga joylash uchun oldiga 0 qo'shamiz: 0,017. «0,17» — yuzdan o'n yetti."},
 tn:"Diktant: o'qituvchi aytadi — bolalar yozadi (0,4; 0,04; 0,004; 4,04). Eng ko'p xato — nollarni tushirib qoldirish."},
{h:"Tuzoq: nollar",sum:"0,5 = 0,50 (oxiridagi nol qiymatni o'zgartirmaydi), lekin 0,05 — boshqa son (10 marta kichik).",a:"m05",
 start:function(){clear();f4t(70,40,'0,5',22);f4t(180,40,'0,05',22);f4t(290,40,'0,50',22);f4msg('Qaysi ikkitasi teng?')},
 fin:function(){clear();f9grid(16,40,10,50);f9grid(128,40,10,5,C.bad);f9grid(240,40,10,50);f4t(66,28,'0,5',14,C.blue);f4t(178,28,'0,05',14,C.bad);f4t(290,28,'0,50',14,C.blue);f4t(180,160,'0,5 = 0,50  ≠  0,05',14,C.ok);f4msg('0,5 = 50/100 = 0,50. 0,05 = 5/100 — 10 marta kichik')},
 html:"<p>Uchta son: <b>0,5</b>, <b>0,05</b>, <b>0,50</b>. Qaysi ikkitasi teng?</p>",
 btns:f4pick(1,[["0,5 va 0,05","0,05 da 5 yuzdan birlar xonasida — 0,5 dan 10 marta kichik."],["0,5 va 0,50","To'g'ri! 5 ta o'ndan bir = 50 ta yuzdan bir. Oxiridagi 0 qiymatni o'zgartirmaydi."],["0,05 va 0,50","Kvadratda bo'yab ko'ring: 5 katak va 50 katak."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p><b>O'nli kasrning oxiriga</b> nol yozilsa yoki o'chirilsa — qiymat o'zgarmaydi: 0,5 = 0,50 = 0,500. Lekin <b>vergul bilan raqam orasiga</b> nol qo'yilsa — son 10 marta kichrayadi: 0,05.</p>",
 q:{t:"Qaysi son 0,3 ga teng?",opts:["0,03","0,30","3,0","0,003"],ok:1,why:"Oxiriga 0 qo'shildi — qiymat o'zgarmadi.",hint:"Qaysi variantda 3 hali ham o'ndan birlar xonasida?",full:"0,30 = 30/100 = 3/10 = 0,3. «0,03» — 3/100, «0,003» — 3/1000, «3,0» — 3 butun."},
 tn:"Butun sonlarda teskari: 5 va 50 har xil, 05 va 5 bir xil. O'nli kasrda nolning joyi qoidasi butun sonlarga «teskari» ekanini ta'kidlang."},
{h:"Tuzoq: uzun son — katta sonmi?",sum:"0,7 &gt; 0,65: 0,7 = 0,70 va 70 &gt; 65. Raqamlar soniga emas, xonalarga qarang.",a:"m06",
 start:function(){clear();f4t(110,60,'0,7',30);f4t(180,62,'?',24);f4t(250,60,'0,65',30);f4msg('Qaysi biri katta?')},
 fin:function(){clear();f9grid(40,30,11,70);f9grid(210,30,11,65,C.a);f4t(95,22,'0,7 = 0,70',13,C.blue);f4t(265,22,'0,65',13,C.a2);f4t(180,162,'70 katak &gt; 65 katak → 0,7 &gt; 0,65',13,C.ok);f4msg('<b>0,7 &gt; 0,65</b>')},
 html:"<p>Qaysi biri katta: <b>0,7</b> yoki <b>0,65</b>? Ko'p bolalar adashadi — siz-chi?</p>",
 btns:f4pick(1,[["0,65, chunki 65 &gt; 7","Tuzoq! 0,7 — 7 ta o'ndan bir = 70 ta yuzdan bir. 70 &gt; 65."],["0,7","To'g'ri! 0,7 = 0,70 va 70 yuzdan bir &gt; 65 yuzdan bir."],["Teng","Kvadratda bo'yang: 70 katak va 65 katak."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p><b>Taqqoslash qoidasi:</b> raqamlar sonini tenglang (oxiriga nol qo'shing): 0,70 va 0,65. Keyin xonama-xona chapdan solishtiring: o'ndan birlar 7 &gt; 6 — demak 0,7 katta.</p><p>«Uzun son — katta son» faqat butun sonlarda ishlaydi!</p>",
 q:{t:"Eng katta son qaysi?",opts:["0,79","0,8","0,089","0,709"],ok:1,why:"0,800 &gt; 0,790 &gt; 0,709 &gt; 0,089.",hint:"Hammasini 3 ta raqamli qiling: 0,790; 0,800; …",full:"0,790; 0,800; 0,089; 0,709. Eng katta — 0,800 = 0,8. «0,79» — eng ko'p raqamli bo'lgani uchun tanlanadi, lekin bu xato mantiq."},
 tn:"Bu — o'nli kasrlardagi eng mashhur xato («longer is larger»). Xalqaro tadqiqotlarda 4–6-sinf o'quvchilarining katta qismi shu xatoni qiladi. 10×10 kvadrat bilan isbotlang."},
{h:"Oddiy kasrdan o'nli kasrga",sum:"3/10 = 0,3; 7/100 = 0,07; 1/2 = 5/10 = 0,5; 1/4 = 25/100 = 0,25; 3/4 = 0,75.",a:"m07",
 start:function(){startPh(F9P7)},fin:function(){S.ph=3;F9P7[3]()},
 html:"<p>Maxraji 10 yoki 100 bo'lsa — darhol yozamiz. Boshqa maxrajli kasrlarni avval 10 yoki 100 ga keltiramiz. Bosing:</p>",btns:[phaser(F9P7)],
 after:"<p>Eng ko'p ishlatiladigan juftliklarni yodlab oling:</p><p><b>1/2 = 0,5 · 1/4 = 0,25 · 3/4 = 0,75 · 1/5 = 0,2 · 1/10 = 0,1</b>.</p><p>Pul misoli: chorak so'm — 25 tiyin (0,25 so'm), yarim so'm — 50 tiyin.</p>",
 q:{t:"3/4 o'nli kasr ko'rinishida qanday yoziladi?",opts:["0,34","0,75","0,43","3,4"],ok:1,why:"3/4 = 75/100 = 0,75.",hint:"1/4 = 25/100. 3/4 — uchta shunday.",full:"1/4 = 25/100, 3/4 = 75/100 = 0,75. «0,34» va «3,4» — surat va maxrajni vergul bilan yonma-yon yozish (eng ko'p xato)."},
 tn:"1/2, 1/4, 3/4, 1/5 ning o'nli ko'rinishini kartochkalar bilan juftlash o'yini (memory) o'ynating."},
{h:"O'nli kasrlar son o'qida",sum:"0,4 — 0 dan 4 qadam (qadam 0,1). 1,3 — 1 dan 3 qadam. 0,85 — 0,8 va 0,9 orasida.",a:"m08",
 start:function(){startPh(F9P8)},fin:function(){S.ph=3;F9P8[3]()},
 html:"<p>Son o'qida har butun 10 ta teng qadamga bo'lingan. O'nli kasrlarni joylaymiz:</p>",btns:[phaser(F9P8,'📍 Joylash')],
 after:"<p>0,85 qayerda? 0,8 va 0,9 orasini yana 10 ga bo'lsak — har qadam 0,01. 0,85 — aynan o'rtada. Demak <b>istalgan ikki o'nli kasr orasida yana o'nli kasr bor</b> — butun sonlarda bunday emas edi (3 va 4 orasida butun son yo'q).</p>",
 q:{t:"0,6 va 0,7 orasida qaysi son bor?",opts:["0,65","0,06","0,75","6,5"],ok:0,why:"0,60 &lt; 0,65 &lt; 0,70.",hint:"0,6 = 0,60, 0,7 = 0,70. Ular orasidagi yuzdan birlarni toping.",full:"0,6 = 0,60 va 0,7 = 0,70. Orasida: 0,61; 0,62; … 0,65 … 0,69. «0,06» — 0,6 dan 10 marta kichik, «0,75» — 0,7 dan katta."},
 tn:"Lupa usuli: son o'qining bir qismini «kattalashtirib» (0,8 dan 0,9 gacha) qayta 10 ga bo'lib chizing."},
{h:"Bilasizmi? Samarqandlik olim",sum:"Ulug'bek rasadxonasida ishlagan G'iyosiddin Jamshid al-Koshiy 1427-yilda «Miftoh al-hisob» kitobida o'nli kasrlarni batafsil bayon etgan.",a:"m09",
 start:function(){clear('#f6ead0');f4t(180,44,'Samarqand, XV asr',16,'#7a4a12');f4t(180,70,'Ulug‘bek rasadxonasi',13,'#7a4a12');f4msg('O‘nli kasrlarni kim batafsil tushuntirgan?')},
 fin:function(){clear('#f6ead0');f4t(180,30,'Jamshid al-Koshiy',16,'#7a4a12');f4t(180,56,'«Miftoh al-hisob» («Hisob kaliti»), 1427',12,'#7a4a12');f4t(180,104,'Yevropada: Simon Stevin, 1585-yil',13,'#5b6b7b');f4t(180,134,'— 150 yildan ko‘proq keyin!',12,'#5b6b7b');f4msg('O‘nli kasrlar bilan hisoblash usuli Samarqandda yozilgan')},
 html:"<p>🔭 XV asrda Samarqandda Mirzo Ulug'bek rasadxonasida buyuk olimlar ishlagan. Ulardan biri o'nli kasrlar haqida ajoyib kitob yozgan. Bosing:</p>",
 btns:[["🔭 Kim ekan?",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p><b>G'iyosiddin Jamshid al-Koshiy</b> 1427-yilda yozgan <b>«Miftoh al-hisob»</b> («Hisob kaliti») kitobida o'nli kasrlar bilan hisoblashni batafsil tushuntirgan. U π sonini ham verguldan keyin 16 ta raqamgacha to'g'ri hisoblagan. Yevropada o'nli kasrlarni golland olimi <b>Simon Stevin</b> 1585-yilda keng targ'ib qilgan.</p>",
 tn:"Ulug'bek rasadxonasi haqida qisqa suhbat: Samarqand — jahon fani markazlaridan biri bo'lgan. Bolalar faxrlanishi uchun aniq faktlarni ayting."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>1/10 = 0,1 · 1/100 = 0,01 · 1/1000 = 0,001.</li><li>Verguldan keyin: o'ndan, yuzdan, mingdan birlar. Har xona 10 marta kichik.</li><li>Maxraj 100 — 2 ta raqam: 7/100 = 0,07 (nolni unutmang).</li><li>Oxiridagi nol qiymatni o'zgartirmaydi: 0,5 = 0,50.</li><li>Taqqoslash: raqamlar sonini tenglang: 0,7 = 0,70 &gt; 0,65.</li><li>1/2 = 0,5 · 1/4 = 0,25 · 3/4 = 0,75 · 1/5 = 0,2.</li><li>Ikki o'nli kasr orasida yana son bor: 0,8 &lt; 0,85 &lt; 0,9.</li></ul></div>",
 tn:"Keyingi dars — uzunlik va massa birliklarida o'nli kasr: «1 sm metrning qanday qismi?»"}
];
var PROBS=[
{t:"9/10 o'nli kasr ko'rinishida qanday yoziladi?",o:["0,9","9,10","0,09","9,0"],k:0,s:"Maxraj 10 — bitta raqam: 0,9."},
{t:"31/100 o'nli kasr ko'rinishida qanday yoziladi?",o:["0,31","3,1","0,031","31,100"],k:0,s:"Maxraj 100 — ikkita raqam: 0,31."},
{t:"0,07 qaysi oddiy kasrga teng?",o:["7/100","7/10","7/1000","70/100"],k:0,s:"7 yuzdan birlar xonasida: 7/100."},
{t:"5,284 sonida 4 raqami qaysi xonada turibdi?",o:["mingdan birlar","yuzdan birlar","o'ndan birlar","birlar"],k:0,s:"Verguldan keyin 3-o'rin — mingdan birlar."},
{t:"Qaysi son 0,6 ga teng?",o:["0,60","0,06","6,0","0,006"],k:0,s:"Oxiridagi nol qiymatni o'zgartirmaydi."},
{t:"Eng kichik son qaysi?",o:["0,099","0,1","0,11","0,9"],k:0,s:"0,099 < 0,100 < 0,110 < 0,900."},
{t:"1/2 o'nli kasr ko'rinishida qanday yoziladi?",o:["0,5","0,2","1,2","0,12"],k:0,s:"1/2 = 5/10 = 0,5."},
{t:"1/4 o'nli kasr ko'rinishida qanday yoziladi?",o:["0,25","0,4","1,4","0,14"],k:0,s:"1/4 = 25/100 = 0,25."},
{t:"Qaysi tengsizlik to'g'ri?",o:["0,4 > 0,38","0,4 < 0,38","0,09 > 0,1","0,5 < 0,49"],k:0,s:"0,40 > 0,38."},
{t:"«Ikki butun yuzdan uch» qanday yoziladi?",o:["2,03","2,3","2,003","23,100"],k:0,s:"Yuzdan — 2 ta raqam: 2,03."},
{t:"0,3 + 0,08 = ?",o:["0,38","0,11","0,83","3,08"],k:0,s:"3 ta o'ndan bir va 8 ta yuzdan bir: 0,38."},
{t:"3 ta o'ndan bir va 5 ta mingdan birdan iborat son qaysi?",o:["0,305","0,35","0,3005","3,05"],k:0,s:"Yuzdan birlar xonasida 0: 0,305."},
{t:"3/5 o'nli kasr ko'rinishida qanday yoziladi?",o:["0,6","0,35","3,5","0,53"],k:0,s:"3/5 = 6/10 = 0,6."},
{t:"0,7 va 0,8 orasida yuzdan birlarda yozilgan nechta son bor (0,71; 0,72; …)?",o:["9","10","1","0"],k:0,s:"0,71 … 0,79 — 9 ta."},
{t:"Qaysi son 2,5 ga teng emas?",o:["2,05","2,50","2 1/2","25/10"],k:0,s:"2,05 = 2 5/100 — boshqa son."},
{t:"3 va 7 raqamlaridan foydalanib 0,□□ ko'rinishidagi eng katta sonni tuzing (raqamlar takrorlanmaydi).",o:["0,73","0,37","0,7","7,3"],k:0,s:"O'ndan birlar xonasiga kattasi: 0,73."},
{t:"1 metrning 0,01 qismi necha santimetr?",o:["1 sm","10 sm","0,1 sm","100 sm"],k:0,s:"1 m = 100 sm; 100 ning 1/100 qismi — 1 sm."},
{t:"Sonlarni o'sish tartibida joylang: 0,5; 0,45; 0,054.",o:["0,054; 0,45; 0,5","0,5; 0,45; 0,054","0,45; 0,5; 0,054","0,054; 0,5; 0,45"],k:0,s:"0,054 < 0,450 < 0,500."},
{t:"Son o'qida 0 dan 1,3 gacha 0,1 qadam bilan necha qadam bor?",o:["13","3","130","1,3"],k:0,s:"1,3 = 13 ta o'ndan bir."},
{t:"3/4 va 0,8 ni taqqoslang.",o:["3/4 < 0,8","3/4 > 0,8","3/4 = 0,8","3/4 > 0,8, chunki 4 > 0,8"],k:0,s:"3/4 = 0,75 < 0,80."}
];
var PREP_DATA={teach:["O'ndan bir, yuzdan bir, mingdan bir: 0,1; 0,01; 0,001.","Xonalar jadvali: verguldan keyingi xonalar.","O'qish va yozish; nollarning roli.","Taqqoslash: raqamlar sonini tenglash.","Oddiy kasrdan o'nli kasrga (1/2, 1/4, 3/4, 1/5); son o'qi."],
 mist:["«Uzun son — katta son»: 0,65 > 0,7 deb o'ylaydi.","Nolni tushirib qoldiradi: 7/100 = 0,7.","Surat va maxrajni vergul bilan yozadi: 3/4 = 0,34.","0,5 va 0,05 ni teng deb biladi.","O'qishda xona nomini noto'g'ri aytadi."],
 need:["10×10 katakli kvadratlar (har bolaga).","Qog'oz tasma, son o'qi, tangalar (tiyin/so'm)."],
 board:["<span class='w2'>1/10 = 0,1 · 1/100 = 0,01 · 1/1000 = 0,001</span>.","Jadval: butun | o'ndan | yuzdan | mingdan — <span class='w2'>3,507</span>.","<span class='w2'>0,5 = 0,50 ≠ 0,05</span>.","<span class='w2'>0,7 = 0,70 &gt; 0,65</span>.","<span class='w2'>1/4 = 0,25 · 3/4 = 0,75</span>."]};
f4fix();
