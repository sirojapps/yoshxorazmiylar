var CODE='2E7',TITLE='2-sinf · Ming va kilometr';
function e7Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function e7f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzliklar (kvadratlar) -> ming (kub)
function e7Flats(n,o){o=o||{};clear();var g=S.g;for(var i=0;i<n;i++){var x=20+(i%5)*44,y=22+Math.floor(i/5)*62;E('rect',{x:x,y:y,width:38,height:38,rx:3,fill:o.hl?C.hi:'#f2b766',stroke:'#a8601f','stroke-width':1.4},g);for(var k=1;k<10;k++){E('line',{x1:x+k*3.8,y1:y,x2:x+k*3.8,y2:y+38,stroke:'#c98b45','stroke-width':.4},g);E('line',{x1:x,y1:y+k*3.8,x2:x+38,y2:y+k*3.8,stroke:'#c98b45','stroke-width':.4},g)}T(g,x+19,y+50,String((i+1)*100),{'font-size':10,'font-weight':800,fill:'#a8601f'})}
 T(g,300,80,e7f(n*100),{'font-size':28,'font-weight':800,fill:C.blue});T(g,300,104,n===10?'= 1 ming':(n+' yuzlik'),{'font-size':12,'font-weight':700,fill:'#5b6b7b'})}
// yo'l: metrlar va km
function e7Road(segs,o){o=o||{};clear();var g=S.g,x0=20,x1=340,tot=o.tot||segs.reduce(function(a,b){return a+b[0]},0),k=(x1-x0)/tot,x=x0;
 E('rect',{x:x0,y:80,width:x1-x0,height:16,rx:8,fill:'#cfd6de'},g);
 segs.forEach(function(s,i){var w=s[0]*k;E('rect',{x:x,y:80,width:w,height:16,rx:8,fill:s[1]||[C.b,C.a,C.ok][i%3]},g);T(g,x+w/2,70,s[2]||(e7f(s[0])+' m'),{'font-size':11,'font-weight':800,fill:'#1d2b3a'});E('line',{x1:x,y1:76,x2:x,y2:100,stroke:'#33475b','stroke-width':2},g);x+=w});
 E('line',{x1:x,y1:76,x2:x,y2:100,stroke:'#33475b','stroke-width':2},g);(o.pins||[]).forEach(function(p){T(g,x0+p[0]*k,156,p[1],{'font-size':18})});if(o.br)Br(x0,x1,104,o.br,false,C.ok)}
var P3=[function(){e7Road([[100,'#8fc6f0','100 m']],{tot:1000,br:''});e7Msg('100 metr — futbol maydonining uzunligiga yaqin')},
 function(){var s=[];for(var i=0;i<10;i++)s.push([100,i%2?'#8fc6f0':'#f6c343','100']);e7Road(s,{br:'10 · 100 m = 1 000 m = 1 km'});e7Msg('10 ta 100 metr — <b>1 000 metr</b> = <b>1 kilometr</b> (1 km)')}];
var P5=[function(){e7Road([[600,C.b,'uy → maktab 600 m']],{tot:1000,pins:[[0,'🏠'],[600,'🏫']]});e7Msg('Uydan maktabgacha 600 m')},
 function(){e7Road([[600,C.b,'600 m'],[400,C.a,'400 m']],{pins:[[0,'🏠'],[600,'🏫'],[1000,'🛒']],br:'600 + 400 = 1 000 m = 1 km'});e7Msg('Maktabdan bozorgacha yana 400 m. Jami: <b>1 000 m = 1 km</b>')}];
var P6=[function(){e7Road([[1000,'#cfd6de','1 km']],{});e7Msg('Yo‘l 1 km. 300 m yurildi. Qancha qoldi?')},
 function(){e7Road([[300,C.bad,'300 m'],[700,C.ok,'700 m']],{br:'1 km = 1 000 m'});e7Msg('1 km = <b>1 000 m</b>. 1 000 − 300 = <b>700 m</b> qoldi')}];
var STEPS=[
{h:"Ming: o'nta yuzlik",sum:"10 yuzlik = 1 ming = 1 000. 100, 200, … 1 000.",a:"m01",
 start:function(){S.e7n=0;e7Flats(0);e7Msg('Yuzliklarni qo‘shing')},fin:function(){e7Flats(10,{hl:1})},
 html:"<p>2A8 da 999 + 1 = 1 000 ekanini ko'rdik. Endi mingni <b>yuzliklardan</b> yig'amiz. Yuzlik qo'shing va yuzlab sanang:</p>",
 btns:[["+ 1 yuzlik",function(c,done,b){if(S.e7n<10){S.e7n++;e7Flats(S.e7n,{hl:S.e7n===10});e7Msg(S.e7n<10?e7f(S.e7n*100):'10 yuzlik = <b>1 ming</b> = 1 000!');if(S.e7n===10){b.disabled=true;done()}}}]],
 after:"<p>Yuzlab sanadik: 100, 200, 300, … 900, <b>1 000</b>. O'nta yuzlik — <b>bir ming</b>. 1 000 — birinchi <b>to'rt xonali</b> son: 1 ta ming, 0 yuzlik, 0 o'nlik, 0 birlik.</p>",
 q:{t:"Ming nechta yuzlikdan iborat?",opts:["100","10","1 000","9"],ok:1,why:"10 · 100 = 1 000.",hint:"Nechta yuzlik qo'shganda 1 000 bo'ldi?",full:"Yuzlab sanasak: 100 (1), 200 (2), … 1 000 (10). Demak 1 ming = 10 yuzlik = 100 o'nlik = 1 000 birlik."},
 tn:"Darslik 132-dars «Ming». 10 ta yuzlik kvadratni ustma-ust qo'yib «ming kubi» qilishni ko'rsating."},
{h:"Mingni bo'laklarga ajratamiz",sum:"1 000 = 500 + 500 = 900 + 100 = 250 + 250 + 250 + 250.",a:"m02",
 start:function(){S.e7k=0;e7Split(0)},fin:function(){e7Split(3)},
 html:"<p>Mingni turli yo'llar bilan to'ldirish mumkin. Juftliklarni ko'ring:</p>",
 btns:[["🔄 Keyingisi",function(c,done){S.e7k=(S.e7k+1)%4;e7Split(S.e7k);mvK(done,3)}]],
 after:"<p>Mingga to'ldirishning kaliti — yuzliklar: 700 + <b>300</b>, 650 + <b>350</b>. Birliklarni ham, o'nliklarni ham hisobga oling: 650 + 350 = 1 000, chunki 50 + 50 = 100 va 600 + 300 + 100 = 1 000.</p>",
 q:{t:"640 ga qancha qo'shsak 1 000 bo'ladi?",opts:["460","360","340","400"],ok:1,why:"640 + 360 = 1 000.",hint:"Avval 700 gacha, keyin 1 000 gacha to'ldiring.",full:"640 + 60 = 700, 700 + 300 = 1 000. Jami 60 + 300 = 360. «460» — o'nliklarni 10 ga emas, 10 dan ortiq to'ldirgan."},
 tn:"«Mingga do'st sonlar» o'yini: biri son aytadi, ikkinchisi mingga to'ldiruvchisini."},
{h:"Kilometr — 1 000 metr",sum:"1 km = 1 000 m. Katta masofalar km da o'lchanadi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Shaharlar, qishloqlar orasidagi masofa metrda juda katta son bo'ladi. Shuning uchun yangi birlik bor. Kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p><b>1 kilometr (km) = 1 000 metr</b>. Kilo — «ming» degani: kilogramm ham 1 000 gramm! Piyoda 1 km ni taxminan 12–15 minutda yurasiz.</p>",
 q:{t:"1 km necha metr?",opts:["100 m","1 000 m","10 m","10 000 m"],ok:1,why:"Kilo — ming: 1 km = 1 000 m.",hint:"«Kilo» so'zi qaysi sonni bildiradi?",full:"1 km = 1 000 m. «100 m» — metr va santimetr bog'lanishi bilan adashtirgan (1 m = 100 sm)."},
 tn:"Maktabdan yaqin joygacha (do'kon, masjid, bozor) masofani bolalar bilan birga taxmin qiling, keyin xaritada tekshiring."},
{h:"km va m ni almashtirish",sum:"3 km = 3 000 m; 2 km 500 m = 2 500 m; 4 000 m = 4 km.",a:"m04",
 start:function(){S.e7c=0;e7Conv(0)},fin:function(){e7Conv(3)},
 html:"<p>Kilometrni metrga aylantirish uchun <b>har km o'rniga 1 000 m</b> qo'yamiz. Misollarni ko'ring:</p>",
 btns:[["🔄 Keyingisi",function(c,done){S.e7c=(S.e7c+1)%4;e7Conv(S.e7c);mvK(done,3)}]],
 after:"<p>3 km = 3 000 m, 2 km 500 m = 2 000 + 500 = <b>2 500 m</b>, 1 km 50 m = <b>1 050 m</b> (1 500 emas!). Teskari: 4 000 m = 4 km.</p>",
 q:{t:"1 km 50 m necha metr?",opts:["150 m","1 500 m","1 050 m","1 005 m"],ok:2,why:"1 000 + 50 = 1 050.",hint:"1 km = 1 000 m. Unga 50 ni qo'shing.",full:"1 km = 1 000 m, yana 50 m: 1 050 m. «1 500» — 50 ni yuzliklar xonasiga yozib qo'ygan, «150» — km ni 100 deb olgan."},
 tn:"Xonalar jadvali (ming | yuz | o'n | bir) da 1 050 ni yozdiring — o'nliklar xonasidagi 5 ko'rinadi."},
{h:"Masofalarni qo'shamiz",sum:"Uydan maktabgacha 600 m + maktabdan bozorgacha 400 m = 1 000 m = 1 km.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Masala: <i>«Uydan maktabgacha 600 m, maktabdan bozorgacha 400 m. Uydan bozorgacha maktab orqali necha km?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>600 + 400 = 1 000 m — bu <b>1 km</b>. Javobni qulay birlikda yozish ham muhim: «1 000 m» ham to'g'ri, lekin savol «necha km» deb so'ragan.</p>",
 q:{t:"Ali 500 m yugurdi, keyin 700 m yurdi. Jami necha metr?",opts:["1 200 m","1 km","200 m","12 000 m"],ok:0,why:"500 + 700 = 1 200 m (1 km 200 m).",hint:"Ikkalasini qo'shing.",full:"500 + 700 = 1 200 m = 1 km 200 m. «1 km» — 200 m ni tashlab yuborgan."},
 tn:"Bolalar o'z uyidan maktabgacha yo'lini chizib, taxminiy masofani yozsin."},
{h:"Tuzoq: 1 km dan ayirish",sum:"1 km − 300 m = 1 000 − 300 = 700 m.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Masala: <i>«Yo'l 1 km. Sayyohlar 300 m yurdi. Necha metr qoldi?»</i> «1 − 300» deb bo'lmaydi-ku…</p>",
 btns:[phaser(P6)],
 after:"<p>Yana o'sha qoida: <b>bir xil birlikka</b> keltiramiz. 1 km = 1 000 m, 1 000 − 300 = <b>700 m</b>. Mingdan ayirish: 1 000 − 300 = 700 (10 yuzlikdan 3 yuzlik — 7 yuzlik).</p>",
 q:{t:"Yo'l 2 km. 800 m yurildi. Necha metr qoldi?",opts:["1 200 m","1 800 m","2 800 m","200 m"],ok:0,why:"2 000 − 800 = 1 200 m.",hint:"2 km necha metr?",full:"2 km = 2 000 m. 2 000 − 800 = 1 200 m. «200» — 1 000 deb hisoblagan, «2 800» — qo'shib yuborgan."},
 tn:"Mingdan ayirishni yuzliklar bilan ko'rsating: 10 yuzlikdan 3 tasini olib tashlang."},
{h:"Qaysi birlik qulay?",sum:"Qalam — sm, xona — m, shaharlar orasi — km.",a:"m07",
 start:function(){S.e7o=-1;e7Obj()},fin:function(){S.e7o=3;e7Obj()},
 html:"<p>Har bir masofaga mos birlikni ko'ring:</p>",
 btns:[["🔄 Keyingisi",function(c,done){S.e7o=(S.e7o+1)%5;e7Obj();mvK(done,4)}]],
 after:"<p>Mayda narsalar — mm, sm; xona, daraxt, stadion — m; shaharlar, qishloqlar orasidagi yo'l — <b>km</b>. Toshkentdan Samarqandgacha — taxminan <b>300 km</b>.</p>",
 q:{t:"Qishloqdan tuman markazigacha bo'lgan masofani qaysi birlikda o'lchash qulay?",opts:["sm","m","km","mm"],ok:2,why:"Katta masofa — km.",hint:"Bu masofa juda katta — piyoda bir necha soat.",full:"Qishloqlar orasidagi masofa minglab metr — uni km bilan yozish qulay (masalan, 12 km)."},
 tn:"Xaritada masshtab chizig'ini ko'rsating: «1 sm — 1 km»."},
{h:"Bilasizmi? Marafon",sum:"Marafon yugurishi — 42 km 195 m.",a:"m08",
 start:function(){e7Road([[42,C.ok,'42 km 195 m']],{tot:42,pins:[[0,'🏃'],[42,'🏁']]});e7Msg('Marafon — 42 km 195 m')},fin:function(){e7Road([[42,C.ok,'42 km 195 m']],{tot:42,pins:[[0,'🏃'],[42,'🏁']]});e7Msg('Marafon — 42 km 195 m')},
 html:"<p>🏃 Eng uzun yugurish musobaqasi — <b>marafon</b>: <b>42 km 195 m</b>. Rivoyatga ko'ra, qadimgi yunon chopari Marafon shahridan Afinagacha yugurib, g'alaba xabarini yetkazgan.</p><p>🛣 Bir kunda mashina bir necha yuz kilometr yo'l bosadi. Yer aylanasi esa taxminan <b>40 000 km</b>!</p>",
 tn:"Bolalarga «sinfdan maktab darvozasigacha necha metr?» deb taxmin qildirib, qadam bilan o'lchating."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){e7Flats(10,{hl:1})},fin:function(){e7Flats(10,{hl:1})},
 html:"<div class='memo'><ul><li><b>1 000</b> (ming) = 10 yuzlik = 100 o'nlik.</li><li>Mingga to'ldirish: 640 + 360 = 1 000.</li><li><b>1 km = 1 000 m</b> («kilo» — ming).</li><li>2 km 500 m = 2 500 m; 1 km 50 m = <b>1 050 m</b>.</li><li>Amaldan oldin bir xil birlik: 1 km − 300 m = 700 m.</li><li>Katta masofa — km, o'rta — m, kichik — sm, mm.</li></ul></div>",
 tn:"Keyingi darsni «3 km 200 m va 3 020 m — qaysi biri uzun?» (3 200 > 3 020) savoli bilan boshlang."}
];
var E7S=[['500 + 500'],['900 + 100'],['700 + 300'],['250 + 250 + 250 + 250']];
function e7Split(k){clear();var g=S.g,p=E7S[k][0].split(' + ').map(Number),x=20,W=320;p.forEach(function(v,i){var w=v/1000*W;E('rect',{x:x,y:60,width:w,height:40,fill:[C.b,C.a,C.ok,C.c][i%4],stroke:'#fff','stroke-width':2},g);T(g,x+w/2,85,String(v),{'font-size':13,'font-weight':800});x+=w});Br(20,340,104,'1 000',false,C.ok);e7Msg('1 000 = <b>'+E7S[k][0]+'</b>')}
var E7C=[['3 km','3 000 m'],['2 km 500 m','2 500 m'],['1 km 50 m','1 050 m'],['4 000 m','4 km']];
function e7Conv(k){clear();var g=S.g,p=E7C[k];T(g,95,90,p[0],{'font-size':20,'font-weight':800});T(g,180,90,'=',{'font-size':24,'font-weight':800,fill:C.ok});T(g,270,90,p[1],{'font-size':20,'font-weight':800,fill:C.blue});e7Msg(p[0]+' = <b>'+p[1]+'</b>')}
var E7O=[['✏️ Qalam','sm'],['🏠 Xona','m'],['🏟 Stadion','m'],['🏙 Toshkent — Samarqand','km'],['🐜 Chumoli','mm']];
function e7Obj(){clear();var g=S.g;if(S.e7o<0){T(g,180,90,'?',{'font-size':40,'font-weight':800,fill:'#9aa8b6'});e7Msg('Tugmani bosing');return}var o=E7O[S.e7o];T(g,180,70,o[0],{'font-size':16,'font-weight':800});T(g,180,124,o[1],{'font-size':40,'font-weight':800,fill:C.ok});e7Msg(o[0]+' — <b>'+o[1]+'</b>')}
var PROBS=[
{t:"Ming nechta yuzlikdan iborat?",o:["10","100","1 000","9"],k:0,s:"1 000 = 10 · 100."},
{t:"999 dan keyingi son qaysi?",o:["1 000","9 910","990","10 000"],k:0,s:"999 + 1 = 1 000."},
{t:"700 ga qancha qo'shsak 1 000 bo'ladi?",o:["300","400","200","1 300"],k:0,s:"700 + 300 = 1 000."},
{t:"640 ga qancha qo'shsak 1 000 bo'ladi?",o:["360","460","340","400"],k:0,s:"640 + 60 = 700, + 300 = 1 000: 360."},
{t:"1 km necha metr?",o:["1 000 m","100 m","10 m","10 000 m"],k:0,s:"1 km = 1 000 m."},
{t:"3 km necha metr?",o:["3 000 m","300 m","30 m","3 100 m"],k:0,s:"3 · 1 000 = 3 000."},
{t:"2 km 500 m necha metr?",o:["2 500 m","2 050 m","2 005 m","25 000 m"],k:0,s:"2 000 + 500."},
{t:"1 km 50 m necha metr?",o:["1 050 m","1 500 m","150 m","1 005 m"],k:0,s:"1 000 + 50."},
{t:"4 000 m necha kilometr?",o:["4 km","40 km","400 km","4 000 km"],k:0,s:"4 000 : 1 000 = 4."},
{t:"Uydan maktabgacha 600 m, maktabdan bozorgacha 400 m. Uydan bozorgacha (maktab orqali)?",o:["1 km","10 km","200 m","1 100 m"],k:0,s:"600 + 400 = 1 000 m = 1 km."},
{t:"Yo'l 1 km. 300 m yurildi. Qancha qoldi?",o:["700 m","1 300 m","299 m","200 m"],k:0,s:"1 000 − 300 = 700."},
{t:"Yo'l 2 km. 800 m yurildi. Qancha qoldi?",o:["1 200 m","200 m","1 800 m","2 800 m"],k:0,s:"2 000 − 800 = 1 200."},
{t:"Ali 500 m yugurdi, keyin 700 m yurdi. Jami?",o:["1 km 200 m","1 km","200 m","12 km"],k:0,s:"1 200 m = 1 km 200 m."},
{t:"Qaysi masofa eng uzun?",o:["3 km 200 m","3 020 m","3 km","2 900 m"],k:0,s:"3 200 > 3 020 > 3 000 > 2 900."},
{t:"Stadion aylanasi 400 m. 5 aylana necha metr?",o:["2 000 m","200 m","405 m","20 000 m"],k:0,s:"400 · 5 = 2 000 m = 2 km."},
{t:"Qishloqdan shahargacha masofani qaysi birlikda o'lchash qulay?",o:["km","sm","mm","dm"],k:0,s:"Katta masofa — km."},
{t:"1 000 − 250 = ?",o:["750","850","650","1 250"],k:0,s:"1 000 − 250 = 750."},
{t:"Qaysi yozuv to'g'ri?",o:["1 km = 1 000 m","1 km = 100 m","1 m = 1 000 sm","1 km = 10 m"],k:0,s:"Kilo — ming."},
{t:"Velosipedchi 1 km yo'lning 450 m ini bosdi. Yana necha metr qoldi?",o:["550 m","650 m","450 m","1 450 m"],k:0,s:"1 000 − 450 = 550."},
{t:"Mashina 1-soatda 60 km, 2-soatda 50 km yurdi. Jami necha km?",o:["110 km","10 km","1 100 km","100 km"],k:0,s:"60 + 50 = 110."}
];
function PRACT_STAGE(){e7Road([[600,C.b,'600 m'],[400,C.a,'400 m']],{pins:[[0,'🏠'],[600,'🏫'],[1000,'🛒']],br:'1 km = 1 000 m'});e7Msg('1 km = 1 000 m')}
var PREP_DATA={teach:["Ming: 10 yuzlik; yuzlab sanash 1 000 gacha.","Mingni bo'laklash va mingga to'ldirish.","Kilometr: 1 km = 1 000 m; km ↔ m almashtirish.","Masofalarni qo'shish va ayirish; mos birlikni tanlash."],
 mist:["1 km ni 100 m deb hisoblaydi.","1 km 50 m ni 1 500 m yoki 150 m deb yozadi.","1 km − 300 m ni bajara olmaydi.","640 + 460 = 1 000 deb o'nliklarni noto'g'ri to'ldiradi."],
 need:["10 ta yuzlik kvadrat (qog'oz).","Hudud xaritasi."],
 board:["<span class='w2'>100, 200, … 1 000</span> — 10 yuzlik.","<span class='w2'>640 + 360 = 1 000</span>.","<span class='w2'>1 km = 1 000 m</span>.","<span class='w2'>2 km 500 m = 2 500 m</span>, <span class='w2'>1 km 50 m = 1 050 m</span>.","<span class='w2'>1 000 − 300 = 700 m</span>."]};
