var CODE='4J10',TITLE="4-sinf · Fazoviy tasavvur: kub, yoyilma, ko'rinishlar";
function f10Stack(map,s,x0,y0,col){var R=map.length,d=s*.5,e=s*.3;for(var r=0;r<R;r++){var dx=(R-1-r)*d,dy=-(R-1-r)*e;for(var c=0;c<map[r].length;c++)for(var z=0;z<map[r][c];z++)j4Cube(x0+c*s+dx,y0+dy-z*s,s,col)}}
function f10Map(map,x0,y0,s,lab){var g=S.g;map.forEach(function(row,r){row.forEach(function(v,c){E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:'#fff',stroke:'#2a4a6a','stroke-width':1.3},g);T(g,x0+c*s+s/2,y0+r*s+s/2+6,String(v),{'font-size':16,'font-weight':800,fill:C.blue})})});if(lab)T(g,x0+map[0].length*s/2,y0+map.length*s+16,lab,{'font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function f10S1(){clear();f10Stack([[3,1],[2,1]],30,50,150);f10Map([[3,1],[2,1]],250,40,34,'ustidan (orqa / old)');}
function f10Front(){clear();var g=S.g;[[3,0],[1,1]].forEach(function(p){});var s=26,x0=60,y0=146;[3,1].forEach(function(h,c){for(var z=0;z<h;z++)E('rect',{x:x0+c*s,y:y0-(z+1)*s,width:s,height:s,fill:'#cfe5f7',stroke:'#2a4a6a','stroke-width':1.3},g)});T(g,x0+s,y0+16,'old',{'font-size':11,'font-weight':700,fill:'#3a4a5a'});
 var x1=200;[3,2].forEach(function(h,c){for(var z=0;z<h;z++)E('rect',{x:x1+c*s,y:y0-(z+1)*s,width:s,height:s,fill:'#fde2c8',stroke:'#8a5a24','stroke-width':1.3},g)});T(g,x1+s,y0+16,'o‘ng yon',{'font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function f10Dice(){clear();var g=S.g;for(var i=0;i<3;i++)j4Cube(150,150-i*44,44,['#fff','#eef1f5','#f8f9fb']);
 [[172,24]].forEach(function(p){});var pts=[[160,18],[180,24],[200,30],[170,12],[190,18]];T(g,192,20,'5',{'font-size':14,'font-weight':800,fill:C.bad});T(g,280,40,'ustki yoq: 5',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,280,70,'ko‘rinmaydigan:',{'font-size':12,'font-weight':700,fill:'#3a4a5a'});T(g,280,88,'5 ta yoq',{'font-size':12,'font-weight':700,fill:'#3a4a5a'})}
function f10Big(n){clear();var s=Math.min(26,100/n);var x0=140-n*s/2,y0=152;for(var r=0;r<n;r++){var dx=(n-1-r)*s*.5,dy=-(n-1-r)*s*.3;for(var c=0;c<n;c++)for(var z=0;z<n;z++){var edges=(r===0||r===n-1?1:0)+(c===0||c===n-1?1:0)+(z===0||z===n-1?1:0);var col=edges===2?['#f2a65a','#d98b3e','#f7c089']:['#9cc9ef','#6fa8dc','#cfe5f7'];j4Cube(x0+c*s+dx,y0+dy-z*s,s,col)}}T(S.g,300,70,n+'×'+n+'×'+n,{'font-size':15,'font-weight':800,fill:'#1d2b3a'});T(S.g,300,94,'sariq — 2 yog‘i',{'font-size':11,'font-weight':700,fill:'#d98b3e'})}
function f10Row(n){clear();for(var c=0;c<n;c++)j4Cube(90+c*50,130,50);T(S.g,180,160,n+' ta kubik qatorda',{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
function f10Ant(){clear();var g=S.g,s=90,x=120,y=140,d=s*.5,e=s*.3;var P={A:[x,y],B:[x+s,y],C:[x+s,y-s],D:[x,y-s],E:[x+d,y-e],F:[x+s+d,y-e],G:[x+s+d,y-s-e],H:[x+d,y-s-e]};
 [['A','B'],['B','C'],['C','D'],['D','A'],['E','F'],['F','G'],['G','H'],['H','E'],['A','E'],['B','F'],['C','G'],['D','H']].forEach(function(l){var a=P[l[0]],b=P[l[1]],hid=(l[0]==='E'||l[1]==='E');E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#2a4a6a','stroke-width':2,'stroke-dasharray':hid?'5 4':''},g)});
 E('circle',{cx:P.A[0],cy:P.A[1],r:6,fill:C.bad},g);E('circle',{cx:P.G[0],cy:P.G[1],r:6,fill:C.ok},g);T(g,P.A[0]-12,P.A[1]+6,'A',{'font-size':14,'font-weight':800,fill:C.bad});T(g,P.G[0]+12,P.G[1]+2,'G',{'font-size':14,'font-weight':800,fill:C.ok})}
function f10Plato(){clear();var g=S.g;var names=['tetraedr 4','kub 6','oktaedr 8','dodekaedr 12','ikosaedr 20'];names.forEach(function(n,i){T(g,180,28+i*28,n,{'font-size':15,'font-weight':800,fill:'#1d2b3a'})})}
var STEPS=[
J4({h:"Ustidan ko'rinish xaritasi",sum:"Ustidan ko'rinishdagi har katakdagi son — shu ustundagi kubiklar soni. 3 + 1 + 2 + 1 = 7.",a:"m01",
 s:f10S1,m:"Har katakdagi son — o‘sha joyda nechta kubik ustma-ust turibdi",f:function(){f10S1();j3Msg('3 + 1 + 2 + 1 = <b>7</b> kubik')},
 html:"<p>Kubiklardan qurilma yasalgan. O'ngda — uni ustidan ko'rinishi: har katakda shu joydagi kubiklar soni. Qurilmada <b>nechta kubik</b> bor?</p>",
 ch:["7","4","6","9"],ok:0,bad:["","4 — faqat ustidan ko‘rinadigan kataklar","Bitta ustunni unutdingiz: 3 + 1 + 2 + 1","Orqadagi ustun 3 ta, 4 ta emas"],
 after:"<p>Ustidan ko'rinish — bu xarita: katakdagi son o'sha joydagi ustun balandligi. Barcha sonlarni qo'shamiz: 3 + 1 + 2 + 1 = <b>7</b>. Rasmda orqadagi kubiklar yashiringan bo'lishi mumkin — xarita esa hech narsani yashirmaydi.</p>",
 q:{t:"Ustidan ko'rinish xaritasi: yuqori qatorda 2 va 2, pastki qatorda 1 va 3. Nechta kubik?",opts:["8","4","6","9"],ok:0,why:"2 + 2 + 1 + 3 = 8.",hint:"Barcha sonlarni qo'shing.",full:"Xaritadagi sonlar yig'indisi = kubiklar soni: 8. «4» — kataklar soni."},
 tn:"Haqiqiy kubiklar bilan: bolalar xarita bo'yicha qurilma yasasin, so'ng aksincha — qurilmadan xarita chizsin."}),
J4({h:"Old va yon ko'rinish",sum:"Old tomondan har ustunda eng balandi ko'rinadi: 3 va 1 → 4 ta kvadrat. Yondan: har qatorda eng balandi: 3 va 2 → 5 ta.",a:"m02",
 s:f10S1,m:"Oldindan qaraganda orqadagi baland ustun oldingisini «yopadi»",f:function(){f10Front();j3Msg('Old: max(3, 2) + max(1, 1) = 3 + 1 = <b>4</b>')},
 html:"<p>Xuddi shu qurilmaga <b>old tomondan</b> qaraymiz. Nechta kvadrat ko'rinadi? (Orqadagi kubiklar oldingilari ortida bo'lsa, faqat balandroq qismi ko'rinadi.)</p>",
 ch:["4","7","5","3"],ok:0,bad:["","7 — hamma kubiklar, lekin ba’zilari bir-birini yopadi","5 — bu o‘ng yondan ko‘rinish","Chap ustunda eng balandi 3 ta kvadrat ko‘rinadi"],
 after:"<p>Oldindan har bir ustunda faqat <b>eng balandi</b> ko'rinadi: chap ustunda max(3, 2) = 3, o'ngda max(1, 1) = 1 → 4 ta kvadrat. O'ng yondan esa har qatorning eng balandi: orqa qator 3, old qator 2 → 5 ta.</p>",
 q:{t:"Xuddi shu qurilmaga o'ng tomondan qaralsa, nechta kvadrat ko'rinadi?",opts:["5","4","7","3"],ok:0,why:"Orqa qator max = 3, old qator max = 2: 5.",hint:"Yon tomondan har qatordagi eng baland ustun ko'rinadi.",full:"Orqa qator (3 va 1) → 3, old qator (2 va 1) → 2. Jami 5."},
 tn:"Qurilmani stolga qo'yib, bolalar har tomondan qarab chizsin: old, yon, ust — muhandislar chizmasi shunday."}),
J4({h:"Zarlar minorasi",sum:"Zarda qarama-qarshi yoqlar yig'indisi 7. Ustki 5 → uning ostida 2. O'rta va pastki zarning ustki + pastki yoqlari 7 + 7. Jami 16.",a:"m03",
 s:f10Dice,m:"Har zarda qarama-qarshi yoqlar: 1–6, 2–5, 3–4",f:function(){f10Dice();j3Msg('2 + 7 + 7 = <b>16</b>')},
 html:"<p>Uchta oddiy zar ustma-ust qo'yilgan. Eng ustki yoqda 5 ko'z. Ko'rinmaydigan yoqlar: zarlar bir-biriga tegib turgan 4 ta yoq va eng pastki yoq. Ularda jami nechta ko'z bor?</p>",
 ch:["16","21","14","18"],ok:0,bad:["","21 — bitta zarning barcha yoqlari","Ustki zarning pastki yog‘i: 7 − 5 = 2","Qayta qo‘shing: 2 + 7 + 7"],
 after:"<p>Ustki zarning pastki yog'i: 7 − 5 = 2. O'rta zarning ustki va pastki yoqlari — qarama-qarshi: 7. Pastki zarniki ham 7. Jami 2 + 7 + 7 = <b>16</b>. Hech qaysi yoqning sonini bilmasak ham, «qarama-qarshi = 7» qoidasi javob beradi!</p>",
 q:{t:"Zar stolda turibdi, ustki yog'ida 4 ko'z. Pastki yog'ida nechta?",opts:["3","4","6","2"],ok:0,why:"Qarama-qarshi yoqlar yig'indisi 7.",hint:"Zarning qarama-qarshi yoqlari yig'indisi nechchi?",full:"7 − 4 = 3."},
 tn:"Haqiqiy zar bilan tekshiring: 1–6, 2–5, 3–4 juftlarini bolalar o'zi topsin."}),
J4({h:"Bo'yalgan 4×4×4 kub",sum:"Katta kub sirti bo'yalib, 64 kubikka bo'lindi. 2 yog'i bo'yalgan — qirralarning o'rtasidagilar: 12 qirra · 2 = 24.",a:"m04",
 s:function(){f10Big(4)},m:"Qirradagi kubiklar (burchaklardan tashqari) 2 yog‘i bilan bo‘yalgan",f:function(){f10Big(4);j3Msg('12 qirra · 2 = <b>24</b>')},
 html:"<p>4×4×4 kubning hamma sirti bo'yaldi, keyin u 64 ta kubikka bo'lindi. Nechta kubikning aynan <b>2 ta</b> yog'i bo'yalgan?</p>",
 ch:["24","12","8","36"],ok:0,bad:["","12 — qirralar soni. Har qirrada nechta?","8 — burchaklar, ularda 3 yoq bo‘yalgan","36 — bu 5×5×5 kubda bo‘ladi"],
 after:"<p>3 yog'i bo'yalgan — burchaklar: 8 ta. 2 yog'i — qirralar ichi: har qirrada 4 − 2 = 2 ta, 12 qirra → <b>24</b>. 1 yog'i — yoqlar o'rtasi: 6 · 2 · 2 = 24. Bo'yalmagan — ichki 2×2×2 = 8. Tekshirish: 8 + 24 + 24 + 8 = 64 ✓.</p>",
 q:{t:"Shu 4×4×4 kubda bitta ham yog'i bo'yalmagan kubiklar nechta?",opts:["8","4","16","27"],ok:0,why:"Ichki kub 2×2×2 = 8.",hint:"Sirtdagi qatlamni olib tashlasak, qanday kub qoladi?",full:"Har tomondan bittadan qatlam olinsa, 2×2×2 kub qoladi: 8. «27» — 3×3×3 deb olish."},
 tn:"Formulalar: n×n×n kub uchun 8; 12 · (n − 2); 6 · (n − 2)²; (n − 2)³. 3×3×3 bilan solishtiring."}),
J4({h:"Sirtdagi kvadratlar",sum:"3 kubikda 18 ta yoq. Ikki tegish joyi — har birida 2 yoq yashirinadi: 18 − 4 = 14.",a:"m05",
 s:function(){f10Row(3)},m:"Har tegish joyi 2 ta yoqni yashiradi",f:function(){f10Row(3);j3Msg('3 · 6 − 2 · 2 = <b>14</b>')},
 html:"<p>3 ta kubik qatorasiga yopishtirildi. Hosil bo'lgan jismning sirtida nechta kvadrat (kubik yoqi) bor?</p>",
 ch:["14","18","12","16"],ok:0,bad:["","18 — hamma yoqlar, lekin yopishgan joylar ko‘rinmaydi","Har tegishda 2 ta yoq yashirinadi, 3 ta emas","16 — faqat bitta tegish hisobga olindi"],
 after:"<p>3 kubik — 18 yoq. Kubiklar 2 joyda tegadi, har joyda 2 ta yoq (bittasi bu kubikda, bittasi u kubikda) yashirinadi: 18 − 4 = <b>14</b>. Tekshirish: uzun tomonlarda 3 · 4 = 12, uchlarida 2 → 14 ✓.</p>",
 q:{t:"4 ta kubikdan L shakl: 3 tasi qatorasiga, to'rtinchisi chetdagisining ustida. Sirtda nechta kvadrat?",opts:["18","16","24","20"],ok:0,why:"24 − 3 · 2 = 18.",hint:"Nechta tegish joyi bor?",full:"4 kubik — 24 yoq. Tegishlar 3 ta, har biri 2 yoqni yashiradi: 24 − 6 = 18."},
 tn:"Kubiklarni yopishtirib, rangli stikerlarni sirtdagi kvadratlarga yopishtirish — bolalar sanab tekshirsin."}),
J4({h:"Tuzoq: chumolining yo'llari",sum:"A dan G ga qirralar bo'ylab eng qisqa yo'l — 3 qirra (o'ngga, orqaga, yuqoriga bir martadan). Tartiblar 3 · 2 · 1 = 6.",a:"m06",
 s:f10Ant,m:"Har eng qisqa yo‘lda uch yo‘nalishning har biri bir marta",f:function(){f10Ant();j3Msg('Birinchi qadam — 3 tanlov, ikkinchisi — 2, uchinchisi — 1: <b>6</b>')},
 html:"<p>Chumoli kubning A uchidan qarama-qarshi G uchiga faqat qirralar bo'ylab borishi kerak. <b>Eng qisqa</b> yo'llar nechta?</p>",
 ch:["6","3","8","12"],ok:0,bad:["","3 — birinchi qadam uchun tanlovlar soni. Keyingisi-chi?","8 — kubning uchlari soni","12 — qirralar soni"],
 after:"<p>Eng qisqa yo'l 3 qirradan iborat: o'ngga (O), orqaga (R) va yuqoriga (Y) — har biri bir martadan, tartibi istalgancha. Birinchi qadamga 3 tanlov, ikkinchisiga 2, uchinchisiga 1: 3 · 2 · 1 = <b>6</b> (ORY, OYR, ROY, RYO, YOR, YRO).</p>",
 q:{t:"Kubning bir uchidan qarama-qarshi uchiga qirralar bo'ylab eng qisqa yo'l nechta qirradan iborat?",opts:["3","2","4","6"],ok:0,why:"Uch yo'nalishning har birida bir qirra.",hint:"Qarama-qarshi uch — uchala yo'nalishda ham boshqa tomonda.",full:"Uchala yo'nalishda (eni, bo'yi, balandligi) bir qirradan o'tish shart: 3."},
 tn:"Karton kubga ip bilan yo'llarni yopishtiring; 4J11 dagi «tartiblar soni» bilan bog'lang."}),
J4info({h:"Bilasizmi? Faqat 5 ta muntazam ko'pyoq",a:"m07",s:f10Plato,m:"Yoqlari soni: 4, 6, 8, 12, 20",
 html:"<p>🔷 Barcha yoqlari bir xil muntazam ko'pburchak va har uchida bir xil sondagi yoq uchrashadigan jismlar — <b>muntazam ko'pyoqlar</b>. Ular atigi 5 ta: tetraedr (4 yoq), kub (6), oktaedr (8), dodekaedr (12), ikosaedr (20). Ularni qadimgi yunon faylasufi Platon tasvirlagani uchun «Platon jismlari» deyiladi. Stol o'yinlaridagi zarlar ko'pincha shu shakllarda yasaladi.</p>",
 tn:"Qog'oz yoyilmalardan tetraedr va oktaedr yasating — yoqlar, uchlar, qirralarni sanang."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){f10Big(3)},m:"Qirra, uch, yoq — har birini alohida sanang",
 html:"<div class='memo'><ul><li>Kub: 6 yoq, 8 uch, 12 qirra.</li><li>Ustidan xarita: sonlar yig'indisi = kubiklar soni.</li><li>Oldindan/yondan: har ustun yoki qatorning <b>eng balandi</b>.</li><li>Zar: qarama-qarshi yoqlar yig'indisi 7.</li><li>n×n×n bo'yalgan kub: 8 | 12 · (n − 2) | 6 · (n − 2)² | (n − 2)³.</li><li>Sirt: yoqlar soni − 2 · tegishlar soni.</li></ul></div>",
 tn:"Uyga: 4 ta kubikdan iloji boricha ko'p xil shakl yasab, har birining sirtini sanash."})
];
var PROBS=[
{t:"Kubning nechta yog'i bor?",o:["6","8","12","4"],k:0,s:"6 ta yoq."},
{t:"Kubning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"8 ta uch."},
{t:"2×2×2 kub nechta kichik kubikdan iborat?",o:["8","6","4","12"],k:0,s:"2 · 2 · 2 = 8."},
{t:"3×3×3 kubdan bitta burchakdagi kubik olib tashlandi. Nechta kubik qoldi?",o:["26","24","27","18"],k:0,s:"27 − 1 = 26."},
{t:"Oddiy zarda qarama-qarshi yoqlardagi ko'zlar yig'indisi nechchi?",o:["7","6","12","21"],k:0,s:"1 + 6 = 2 + 5 = 3 + 4 = 7."},
{t:"Oddiy zarning barcha yoqlaridagi ko'zlar yig'indisi?",o:["21","36","7","42"],k:0,s:"1 + 2 + … + 6 = 21."},
{t:"Ikki zar ustma-ust turibdi, eng ustki yoqda 6 ko'z. Zarlar orasidagi ikki yoq va eng pastki yoqdagi ko'zlar yig'indisi?",o:["8","7","13","14"],k:0,s:"Ustki zar pastida 1, pastki zarning ustki + pastki = 7: 8."},
{t:"3×3×3 kub sirti bo'yalib, kubiklarga bo'lindi. Nechtasining 3 ta yog'i bo'yalgan?",o:["8","12","6","1"],k:0,s:"Burchaklar: 8."},
{t:"4×4×4 kub sirti bo'yalib, kubiklarga bo'lindi. Nechtasining aynan 1 ta yog'i bo'yalgan?",o:["24","36","16","12"],k:0,s:"Har yoq o'rtasida 2 · 2 = 4: 6 · 4 = 24."},
{t:"4×4×4 kub sirti bo'yalib, kubiklarga bo'lindi. Nechtasi umuman bo'yalmagan?",o:["8","4","16","27"],k:0,s:"Ichki 2×2×2 = 8."},
{t:"5×5×5 kub sirti bo'yalib, kubiklarga bo'lindi. Nechtasining aynan 2 ta yog'i bo'yalgan?",o:["36","24","48","12"],k:0,s:"Har qirrada 5 − 2 = 3: 12 · 3 = 36."},
{t:"Ustidan ko'rinish xaritasi: yuqori qatorda 2 va 1, pastki qatorda 1 va 3. Nechta kubik?",o:["7","4","6","8"],k:0,s:"2 + 1 + 1 + 3 = 7."},
{t:"Bitta qatordagi uchta ustun: 1, 3 va 2 kubikli. Old tomondan nechta kvadrat ko'rinadi?",o:["6","3","9","4"],k:0,s:"Har ustun to'liq ko'rinadi: 1 + 3 + 2 = 6."},
{t:"Ikki kubik yopishtirildi. Sirtida nechta kvadrat yoq bor?",o:["10","12","8","11"],k:0,s:"12 − 2 = 10."},
{t:"8 ta kubikdan 2×2×2 kub yasaldi. Uning sirtida nechta kichik kvadrat bor?",o:["24","8","48","12"],k:0,s:"6 yoq · 4 = 24."},
{t:"Kubning bir uchidan qarama-qarshi uchiga qirralar bo'ylab nechta eng qisqa yo'l bor?",o:["6","3","8","4"],k:0,s:"3 · 2 · 1 = 6."},
{t:"Kubning yoyilmasi nechta kvadratdan iborat?",o:["6","8","4","5"],k:0,s:"Har yoq — bitta kvadrat: 6."},
{t:"To'g'ri burchakli parallelepiped 2×3×4 kubiklardan yasalgan. Nechta kubik?",o:["24","9","26","20"],k:0,s:"2 · 3 · 4 = 24."},
{t:"2×3×4 parallelepiped sirti bo'yalib, kubiklarga bo'lindi. Nechtasi umuman bo'yalmagan?",o:["0","2","4","6"],k:0,s:"Ichki qism (2 − 2)×(3 − 2)×(4 − 2) = 0×1×2 = 0."},
{t:"3×3×3 kubning faqat ustki va pastki yog'i bo'yaldi. Nechta kubik umuman bo'yalmagan?",o:["9","1","18","7"],k:0,s:"O'rta qatlam to'liq bo'yalmagan: 3 · 3 = 9."}
];
function PRACT_STAGE(){f10Big(3)}
var PREP_DATA={teach:["Ustidan ko'rinish xaritasi va kubiklar soni.","Old va yon ko'rinish: eng baland ustun.","Zar: qarama-qarshi yoqlar.","Bo'yalgan n×n×n kub.","Sirt va eng qisqa yo'llar."],
 mist:["Yashirin (orqadagi) kubiklarni sanamaydi.","Oldindan ko'rinishda hamma kubiklarni qo'shadi.","Bo'yalgan kubda qirralar va burchaklarni aralashtiradi."],
 need:["Kubiklar (lego yoki yog'och).","Oddiy zarlar.","Karton kub va ip."],
 board:["xarita: yig'indi = kubiklar","old: har ustunning maksimumi","zar: qarama-qarshi = 7","n³ kub: 8 | 12(n−2) | 6(n−2)² | (n−2)³"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
