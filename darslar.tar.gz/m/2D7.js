var CODE='2D7',TITLE='2-sinf · Teskari masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// o'zgarishlar zanjiri: qutilar va strelkalar
function bm7chain(vals,ops,back,hl){clear();var g=S.g,n=vals.length,w=64,gap=(340-n*w)/(n-1),y=70;
 for(var i=0;i<n;i++){var x=10+i*(w+gap),v=vals[i],q=v==='?';E('rect',{x:x,y:y,width:w,height:38,rx:8,fill:q?'#fff':(hl===i?'#e6f6ee':'#fff7ea'),stroke:q?C.bad:(hl===i?C.ok:C.line),'stroke-width':2,'stroke-dasharray':q?'5 4':''},g);T(g,x+w/2,y+25,String(v),{'font-size':16,'font-weight':800,fill:q?C.bad:'#1d2b3a'});
  if(i<n-1){var x1=x+w+3,x2=x+w+gap-3,o=ops[i];E('path',{d:'M'+x1+' '+(y+10)+' Q'+(x1+x2)/2+' '+(y-22)+' '+x2+' '+(y+10),fill:'none',stroke:C.blue,'stroke-width':2},g);E('path',{d:'M'+(x2-6)+' '+(y+2)+' L'+x2+' '+(y+10)+' L'+(x2-9)+' '+(y+9),fill:'none',stroke:C.blue,'stroke-width':2},g);T(g,(x1+x2)/2,y-14,o,{'font-size':13,'font-weight':800,fill:C.blue});
   if(back&&back[i]){E('path',{d:'M'+x2+' '+(y+30)+' Q'+(x1+x2)/2+' '+(y+62)+' '+x1+' '+(y+30),fill:'none',stroke:C.a2,'stroke-width':2},g);E('path',{d:'M'+(x1+6)+' '+(y+38)+' L'+x1+' '+(y+30)+' L'+(x1+9)+' '+(y+31),fill:'none',stroke:C.a2,'stroke-width':2},g);T(g,(x1+x2)/2,y+66,back[i],{'font-size':13,'font-weight':800,fill:C.a2})}}}
 T(g,180,166,back?'pastdagi strelkalar — orqaga (teskari amal)':'yuqoridagi strelkalar — voqea tartibi',{'font-size':10,fill:'#5b6b7b'})}
var CH1=[function(){bm7chain(['?','?','20'],['−9','+5']);calc(['Voqea: pul bor edi → 9 ming sarfladi → 5 ming oldi → 20 ming bo‘ldi'],'Boshlang‘ich son noma’lum, OXIRGISI ma’lum')},
 function(){bm7chain(['?','15','20'],['−9','+5'],[null,'−5']);calc(['Oxiridan: «+5» ning teskarisi «−5»: 20 − 5 = <b>15</b>'])},
 function(){bm7chain(['24','15','20'],['−9','+5'],['+9','−5'],0);calc(['20 − 5 = 15','«−9» ning teskarisi «+9»: 15 + 9 = <b>24</b> ming']);}];
var CH3=[function(){bm7chain(['?','?','30'],['−8','+12']);calc(['Savatdan 8 ta yeyildi, 12 ta solindi, 30 ta bo‘ldi'])},
 function(){bm7chain(['?','18','30'],['−8','+12'],[null,'−12']);calc(['30 − 12 = <b>18</b>'])},
 function(){bm7chain(['26','18','30'],['−8','+12'],['+8','−12'],0);calc(['30 − 12 = 18','18 + 8 = <b>26</b> ta olma'])}];
var CH4=[function(){bm7chain(['?','?','40'],['−15','+8']);calc(['15 ta sovg‘a qildi, 8 ta sotib oldi, 40 ta bo‘ldi'])},
 function(){bm7chain(['?','32','40'],['−15','+8'],[null,'−8']);calc(['40 − 8 = 32'])},
 function(){bm7chain(['47','32','40'],['−15','+8'],['+15','−8'],0);calc(['40 − 8 = 32','32 + 15 = <b>47</b> ta marka'])}];
var STEPS=[
bmStep({h:"Oxiri ma'lum — boshini topamiz",sum:"20 ← (+5) ← (−9): 20 − 5 = 15, 15 + 9 = 24.",a:"m01",frames:[{}],
 start:function(){startPh(CH1)},fin:function(){S.ph=2;CH1[2]()},btns:[phaser(CH1,'▶ Orqaga qadam')],
 html:"<p>Masala: <i>«Valida bir oz pul bor edi. U 9 minglik kitob oldi, keyin onasi 5 ming berdi va unda 20 ming bo'ldi. Dastlab Valida qancha pul bo'lgan?»</i> Bu yerda <b>boshi</b> noma'lum, <b>oxiri</b> ma'lum. Oxiridan orqaga yuramiz.</p>",
 after:"<p>Orqaga yurganda har amal <b>teskarisiga</b> aylanadi: «+5» → «−5», «−9» → «+9». Javob: <b>24</b> ming. Tekshirish: 24 − 9 + 5 = 20 ✓</p>",
 q:{t:"Ali o'ylagan sonidan 6 ni ayirdi va 14 chiqdi. Ali qaysi sonni o'ylagan?",opts:["8","20","14","6"],ok:1,why:"«−6» ning teskarisi «+6»: 14 + 6 = 20.",hint:"Oxiridan orqaga yuring: ayirishning teskarisi nima?",full:"Ali: ? − 6 = 14. Orqaga: 14 + 6 = 20. Tekshiramiz: 20 − 6 = 14 ✓. «8» — teskari emas, xuddi shu amalni qilish xatosi."},
 tn:"Bolalarga «vaqt mashinasi» o'yinini taklif qiling: voqeani oxiridan boshiga qarab o'ynab chiqish."}),
bmStep({h:"Teskari amallar",sum:"+ ↔ −, · ↔ :. Orqaga yurganda amal teskarisiga aylanadi.",a:"m02",
 frames:[{t:'Teskari amallar jufti',bars:[{lab:'qo‘shish',y:40,segs:[{w:5,txt:'+ 5',c:'g'}]},{lab:'ayirish',y:96,segs:[{w:5,txt:'− 5',c:'c'}]}],note:'«+5» ning teskarisi qaysi?'}],
 html:"<p>Har bir amalning <b>teskari</b> jufti bor — u bajarilgan ishni bekor qiladi. «Berdi» ning teskarisi — «oldi». «+5» ning teskarisi qaysi?</p>",
 btns:bmPick(["+ 5","− 5","· 5"],1,{t:'Teskari amallar jufti',bars:[{lab:'qo‘shish',y:40,segs:[{w:5,txt:'+ 5',c:'g'}]},{lab:'ayirish',y:96,segs:[{w:5,txt:'− 5',c:'c'}]}],calc:['<b>+</b> ↔ <b>−</b> · <b>·</b> ↔ <b>:</b>','12 + 5 = 17 → 17 − 5 = 12 (qaytib keldik)']},["Bu xuddi o‘zi — teskarisi emas.","","Ko‘paytirishning teskarisi — bo‘lish."]),
 after:"<p><b>Qo'shish ↔ ayirish</b>, <b>ko'paytirish ↔ bo'lish</b>. Teskari amal bilan qaytsak, avvalgi songa qaytamiz: 12 + 5 − 5 = 12.</p>",
 q:{t:"Son 3 ga ko'paytirilgan va 18 chiqqan. Sonni topish uchun nima qilamiz?",opts:["18 · 3","18 : 3","18 − 3","18 + 3"],ok:1,why:"Ko'paytirishning teskarisi — bo'lish: 18 : 3 = 6.",hint:"Ko'paytirishni qaysi amal bekor qiladi?",full:"? · 3 = 18. Teskari: 18 : 3 = 6. Tekshiramiz: 6 · 3 = 18 ✓."},
 tn:"Kartochkalar: bir tomonida amal (+7), orqasida teskarisi (−7). Bolalar juftlarni topsin."}),
bmStep({h:"Savatdagi olmalar",sum:"30 ← (+12) ← (−8): 30 − 12 = 18, 18 + 8 = 26.",a:"m03",frames:[{}],
 start:function(){startPh(CH3)},fin:function(){S.ph=2;CH3[2]()},btns:[phaser(CH3,'▶ Orqaga qadam')],
 html:"<p>Masala: <i>«Savatdagi olmalardan 8 tasi yeyildi, keyin yana 12 ta solindi va 30 ta bo'ldi. Dastlab nechta olma bo'lgan?»</i> Orqaga yuramiz.</p>",
 after:"<p>Xato yo'l: 30 + 12 − 8 = 34 — amallarni teskarisiga aylantirmaslik. Har doim: <b>oxiridan</b> va <b>teskari</b> amal bilan.</p>",
 q:{t:"Avtobusdan 7 kishi tushdi, 4 kishi chiqdi, 20 kishi bo'ldi. Boshida nechta kishi bor edi?",opts:["31","23","17","9"],ok:1,why:"20 − 4 = 16, 16 + 7 = 23.",hint:"Oxiridan: «chiqdi» (+4) ning teskarisi, keyin «tushdi» (−7) ning teskarisi.",full:"Orqaga: 20 − 4 = 16 (chiqqanlar ketadi), 16 + 7 = 23 (tushganlar qaytadi). Tekshiramiz: 23 − 7 + 4 = 20 ✓."},
 tn:"Bolalar strelkalarni o'zi chizsin: yuqorida voqea, pastda teskari yo'l."}),
bmStep({h:"Markalar — o'zingiz yeching",sum:"40 ← (+8) ← (−15): 40 − 8 = 32, 32 + 15 = 47.",a:"m04",frames:[{}],
 start:function(){startPh(CH4)},fin:function(){S.ph=2;CH4[2]()},btns:[phaser(CH4,'▶ Orqaga qadam')],
 html:"<p>Masala: <i>«Vali markalaridan 15 tasini do'stiga sovg'a qildi, keyin 8 ta marka sotib oldi va unda 40 ta bo'ldi. Dastlab nechta marka bo'lgan?»</i></p>",
 after:"<p>Javob: <b>47</b>. Tekshirish: 47 − 15 = 32, 32 + 8 = 40 ✓. Har teskari masalani shunday tekshiring — boshidan oldinga yurib.</p>",
 q:{t:"Lola kitobning har kuni 10 sahifasini o'qidi. 4 kun o'qigach, unga 15 sahifa qoldi. Kitob necha sahifa?",opts:["40","55","25","65"],ok:1,why:"4 kunda 40 sahifa + qolgan 15 = 55.",hint:"4 kunda nechta sahifa o'qildi? Qolgani bilan birga — butun kitob.",full:"O'qilgani: 10 · 4 = 40. Butun kitob: 40 + 15 = 55 sahifa. «40» — qolganini unutish."},
 tn:"Har teskari masaladan keyin «oldinga» tekshirishni majburiy qiling."}),
bmStep({h:"Tuzoq: «bu … dan uzun» — teskari ifoda",sum:"Bog'gacha 37 km — bu ko'lgacha yo'ldan 9 km uzun → ko'lgacha 37 − 9 = 28.",a:"m05",
 frames:[{t:'Bog‘gacha 37 km. BU ko‘lgacha bo‘lgan yo‘ldan 9 km UZUN.',bars:[{lab:'bog‘gacha',y:46,segs:[{w:37,txt:'37',c:'a'}]},{lab:'ko‘lgacha',y:106,segs:[{w:28,txt:'?',c:'q'}]}],note:'Qaysi yo‘l uzun? Amalni tanlang'}],
 html:"<p>«Teskari ifoda» — so'z «uzun» deydi, lekin topilayotgan yo'l <b>qisqa</b>. Amalni tanlang:</p>",
 btns:bmPick(["37 + 9","37 − 9"],1,{t:'Bog‘gacha 37 km. BU ko‘lgacha bo‘lgan yo‘ldan 9 km UZUN.',bars:[{lab:'bog‘gacha',y:46,segs:[{w:28,txt:'28',c:'a'},{w:9,txt:'9',c:'c'}]},{lab:'ko‘lgacha',y:106,segs:[{w:28,txt:'28',c:'b'}]}],calc:['Bog‘gacha uzun → ko‘lgacha qisqa','37 − 9 = <b>28</b> km']},["Unda ko‘lgacha 46 km — bog‘gachadan uzun bo‘lib qoladi. Lekin bog‘gacha uzun deyilgan!"]),
 after:"<p>Bunday masalalar ham «teskari» deyiladi: so'z bir narsani, amal teskarisini talab qiladi. Chizma hech qachon aldamaydi.</p>",
 q:{t:"Usta 146 ta ko'k detal ishlatdi. Bu yashil detallardan 58 ta ko'p. Nechta yashil detal ishlatgan?",opts:["204","88","58","98"],ok:1,why:"Ko'k ko'p → yashil kam: 146 − 58 = 88.",hint:"Qaysi rang ko'p ishlatilgan? Kam bo'lganini topish uchun nima qilamiz?",full:"«Bu (146 ko'k) yashildan 58 ta ko'p» — yashil kam: 146 − 58 = 88. «204» — «ko'p» so'zini ko'rib qo'shish xatosi."},
 tn:"Bolalar har gapni o'z so'zi bilan qayta aytsin: «Demak yashil 58 ta kam»."}),
bmStep({h:"Tuzoq: ko'paytirish bilan teskari",sum:"Son 2 ga ko'paytirilib, 6 qo'shilsa 20: (20 − 6) : 2 = 7.",a:"m06",frames:[{}],
 start:function(){S.ph=0;bm7chain(['?','?','20'],['· 2','+ 6']);calc(['Men son o‘yladim, 2 ga ko‘paytirdim, 6 qo‘shdim — 20 chiqdi'])},
 fin:function(){bm7chain(['7','14','20'],['· 2','+ 6'],[': 2','− 6'],0);calc(['20 − 6 = 14','14 : 2 = <b>7</b>'])},
 btns:[phaser([function(){bm7chain(['?','?','20'],['· 2','+ 6']);calc(['Men son o‘yladim, 2 ga ko‘paytirdim, 6 qo‘shdim — 20 chiqdi'])},function(){bm7chain(['?','14','20'],['· 2','+ 6'],[null,'− 6']);calc(['20 − 6 = 14'])},function(){bm7chain(['7','14','20'],['· 2','+ 6'],[': 2','− 6'],0);calc(['20 − 6 = 14','14 : 2 = <b>7</b>'])}],'▶ Orqaga qadam')],
 html:"<p>«O'ylangan son» topishmog'i: <i>«Men son o'yladim, uni 2 ga ko'paytirdim, keyin 6 qo'shdim va 20 chiqdi. Qaysi sonni o'yladim?»</i></p>",
 after:"<p>Tartib muhim: oxirgi amal (+6) birinchi bo'lib bekor qilinadi. Xato yo'l: 20 : 2 = 10, 10 − 6 = 4 — tartibni buzish. Tekshirish: 7 · 2 + 6 = 20 ✓</p>",
 q:{t:"Son o'ylandi, unga 4 qo'shildi, natija 3 ga ko'paytirildi va 27 chiqdi. Qaysi son o'ylangan?",opts:["5","9","13","23"],ok:0,why:"27 : 3 = 9, 9 − 4 = 5.",hint:"Oxirgi amal — ko'paytirish. Avval uni bekor qiling.",full:"Orqaga: 27 : 3 = 9 (ko'paytirish bekor), 9 − 4 = 5 (qo'shish bekor). Tekshiramiz: (5 + 4) · 3 = 27 ✓."},
 tn:"Bolalar juft bo'lib bir-biriga «o'ylangan son» topishmog'ini bersin."}),
bmStep({h:"Bilasizmi? «Oxiridan yechish» usuli",sum:"Matematik Dyord Polya (1945) «oxiridan boshlash»ni asosiy usullardan biri deb yozgan.",a:"m07",frames:[{}],
 start:function(){bm7chain(['boshi','…','oxiri'],['→','→'],['←','←']);calc(['Maqsaddan boshlab, orqaga yurish'])},fin:function(){bm7chain(['boshi','…','oxiri'],['→','→'],['←','←']);calc(['Maqsaddan boshlab, orqaga yurish'])},
 html:"<p>📘 Venger matematigi <b>Dyord Polya</b> 1945-yilda «Masalani qanday yechish kerak» degan mashhur kitob yozgan. U yerda «<b>oxiridan boshlab, orqaga yurish</b>» — eng kuchli usullardan biri sifatida tushuntirilgan.</p><p>Bu usulni labirintda ham qo'llash mumkin: chiqishdan kirishga qarab yo'l topish ko'pincha osonroq!</p>",
 tn:"Qog'ozga oddiy labirint chizib, bolalarga chiqishdan boshlab yo'l topishni sinab ko'rishni taklif qiling."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m08",memo:1,frames:[{}],start:function(){bm7chain(['24','15','20'],['−9','+5'],['+9','−5'],0);calc(['Oxiridan, teskari amal bilan'])},fin:function(){bm7chain(['24','15','20'],['−9','+5'],['+9','−5'],0);calc(['Oxiridan, teskari amal bilan'])},
 html:"<div class='memo'><ul><li><b>Oxiri ma'lum, boshi noma'lum</b> → oxiridan orqaga yuramiz.</li><li>Har amal <b>teskarisiga</b> aylanadi: + ↔ −, · ↔ :.</li><li>Oxirgi amal <b>birinchi</b> bekor qilinadi.</li><li>«Bu … dan 9 km uzun» — topilayotgan narsa <b>qisqa</b> bo'lishi mumkin, chizmaga qarang.</li><li>Javobni <b>oldinga</b> yurib tekshiring: 24 − 9 + 5 = 20 ✓.</li></ul></div>",
 tn:"Keyingi darsni «Men son o'yladim, 5 ni ayirdim, 2 ga ko'paytirdim — 16 chiqdi» (13) topishmog'i bilan boshlang."})
];
var PROBS=[
{t:"Vali 9 minglik kitob oldi, keyin onasi 5 ming berdi va 20 ming bo'ldi. Dastlab qancha pul bo'lgan?",o:["24 ming","16 ming","34 ming","6 ming"],k:0,s:"20 − 5 = 15, 15 + 9 = 24."},
{t:"Savatdan 8 ta olma yeyildi, keyin 12 ta solindi va 30 ta bo'ldi. Dastlab nechta bo'lgan?",o:["26","34","50","10"],k:0,s:"30 − 12 = 18, 18 + 8 = 26."},
{t:"Vali 15 ta marka sovg'a qildi, 8 ta sotib oldi, 40 ta bo'ldi. Dastlab nechta marka bo'lgan?",o:["47","63","17","33"],k:0,s:"40 − 8 = 32, 32 + 15 = 47."},
{t:"Ali kitobning har kuni 10 sahifasini o'qidi. 4 kun o'qigach, 15 sahifa qoldi. Kitob necha sahifa?",o:["55","40","25","65"],k:0,s:"10 · 4 = 40, 40 + 15 = 55."},
{t:"Bekatdan bog'gacha 37 km. Bu ko'lgacha bo'lgan yo'ldan 9 km uzun. Ko'lgacha necha km?",o:["28 km","46 km","27 km","38 km"],k:0,s:"37 − 9 = 28."},
{t:"Ali o'ylagan sonidan 6 ni ayirdi va 14 chiqdi. Qaysi son o'ylangan?",o:["20","8","14","6"],k:0,s:"14 + 6 = 20."},
{t:"Son 2 ga ko'paytirilib, 6 qo'shilsa 20 chiqadi. Son qaysi?",o:["7","4","13","10"],k:0,s:"20 − 6 = 14, 14 : 2 = 7."},
{t:"Son o'ylandi, 4 qo'shildi, 3 ga ko'paytirildi — 27 chiqdi. Qaysi son?",o:["5","9","13","23"],k:0,s:"27 : 3 = 9, 9 − 4 = 5."},
{t:"Avtobusdan 7 kishi tushdi, 4 kishi chiqdi, 20 kishi bo'ldi. Boshida nechta kishi edi?",o:["23","31","17","9"],k:0,s:"20 − 4 = 16, 16 + 7 = 23."},
{t:"Usta 146 ta ko'k detal ishlatdi. Bu yashil detallardan 58 ta ko'p. Nechta yashil?",o:["88","204","58","98"],k:0,s:"146 − 58 = 88."},
{t:"Usta 146 ta ko'k detal ishlatdi. Bu yashildan 58 ta ko'p, oqdan esa 27 ta kam. Jami nechta detal?",o:["407","397","417","469"],k:0,s:"Yashil 88, oq 173, jami 146 + 88 + 173 = 407."},
{t:"Bir sonni 5 ga bo'lib, 3 ni qo'shishdi — 7 chiqdi. Son qaysi?",o:["20","50","10","35"],k:0,s:"7 − 3 = 4, 4 · 5 = 20."},
{t:"Lola sharlarining yarmini singlisiga berdi, o'zida 9 ta qoldi. Boshida nechta shar bor edi?",o:["18","9","4","27"],k:0,s:"Yarmi 9 → hammasi 9 + 9 = 18."},
{t:"Hovuzdan 12 bola chiqdi, 5 bola tushdi va 30 bola bo'ldi. Boshida nechta bola edi?",o:["37","47","23","13"],k:0,s:"30 − 5 = 25, 25 + 12 = 37."},
{t:"Men son o'yladim, 5 ni ayirdim, natijani 2 ga ko'paytirdim — 16 chiqdi. Qaysi son?",o:["13","3","11","27"],k:0,s:"16 : 2 = 8, 8 + 5 = 13."},
{t:"Bolada bir nechta yong'oq bor edi. U 10 tasini yedi va qolganini 3 do'stiga 4 tadan berdi. Boshida nechta yong'oq bor edi?",o:["22","12","17","34"],k:0,s:"Berilgani 4 · 3 = 12, boshida 12 + 10 = 22."},
{t:"Mashinaga 20 litr benzin quyildi, keyin 15 litr sarflandi va 25 litr qoldi. Boshida necha litr bor edi?",o:["20","60","10","30"],k:0,s:"25 + 15 = 40, 40 − 20 = 20."},
{t:"Dilshod olmalarining yarmini sotdi, keyin yana 4 ta sotdi va 6 ta qoldi. Boshida nechta olma bor edi?",o:["20","10","16","14"],k:0,s:"6 + 4 = 10 — bu yarmi. Hammasi 10 + 10 = 20."},
{t:"Ota yoshidan 25 ni ayirsak, o'g'lining yoshi 9 chiqadi. Ota necha yoshda?",o:["34","16","25","43"],k:0,s:"9 + 25 = 34."},
{t:"Sonni 3 ga ko'paytirib, 10 ni ayirishdi — 14 chiqdi. Son qaysi?",o:["8","12","4","6"],k:0,s:"14 + 10 = 24, 24 : 3 = 8."}
];
function PRACT_STAGE(){bm7chain(['?','…','oxiri'],['amal','amal'],['teskari','teskari']);calc(['Oxiridan boshlang, teskari amal bilan yuring'])}
var PREP_DATA={teach:["Oxiri ma'lum masalalar — orqaga yurish.","Teskari amallar: + ↔ −, · ↔ :.","«O'ylangan son» topishmoqlari, tartib muhimligi.","Teskari ifodali masalalar («bu … dan uzun»)."],
 mist:["Orqaga yurganda amalni teskarisiga aylantirmaydi.","Amallarni noto'g'ri tartibda bekor qiladi (avval :2, keyin −6).","«Uzun» so'zini ko'rib qo'shib yuboradi.","Javobni oldinga tekshirmaydi."],
 need:["Strelkali kartochkalar (amal / teskari amal)."],
 board:["<span class='w2'>? →(−9)→ ? →(+5)→ 20</span>.","Orqaga: <span class='w2'>20 −5 → 15 +9 → 24</span>.","Juftlar: <span class='w2'>+ ↔ −</span>, <span class='w2'>· ↔ :</span>.","Topishmoq: <span class='w2'>(20 − 6) : 2 = 7</span>."]};
