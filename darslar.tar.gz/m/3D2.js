var CODE='3D2',TITLE='3-sinf · Tenglamalar';
function d2Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
var P1=[function(){w3Bal(['x','7'],['15']);w3Msg('Tarozi muvozanatda: x + 7 = 15')},
 function(){w3Bal(['x',{t:'7',c:'#f6c9c9'}],['8',{t:'7',c:'#f6c9c9'}]);w3Msg('15 ni 8 + 7 deb yozamiz — ikkala pallada ham 7 bor')},
 function(){w3Bal(['x'],['8']);w3Msg('Ikkala palladan 7 ni olamiz — muvozanat saqlanadi: <b>x = 8</b>')},
 function(){w3Bal(['8','7'],['15']);w3Msg('Tekshiruv: 8 + 7 = 15 ✓')}];
var P5=[function(){w3Expr(['(x + 370) : 3 = 300']);w3Msg('Oxirgi amal — bo‘lish. Qavs ichini «bitta son» deb qaraymiz')},
 function(){w3Expr(['[(x + 370)] : 3 = 300','bo‘linuvchi = 300 · 3','x + 370 = {900}']);w3Msg('Noma’lum bo‘linuvchi = bo‘linma · bo‘luvchi')},
 function(){w3Expr(['x + 370 = 900','x = 900 − 370','x = {530}']);w3Msg('Noma’lum qo‘shiluvchi = yig‘indi − ma’lum qo‘shiluvchi')},
 function(){w3Expr(['(530 + 370) : 3','= 900 : 3 = {300} ✓']);w3Msg('Tekshiruv — <b>x = 530</b>')}];
var P6=[function(){w3Expr(['(x · 4 − 12) : 6 = 14']);w3Msg('Piyozni qavatma-qavat archiymiz: tashqi amaldan ichkariga')},
 function(){w3Expr(['[(x · 4 − 12)] : 6 = 14','x · 4 − 12 = 14 · 6 = {84}']);w3Msg('1-qavat: bo‘linuvchi = 14 · 6')},
 function(){w3Expr(['[x · 4] − 12 = 84','x · 4 = 84 + 12 = {96}']);w3Msg('2-qavat: kamayuvchi = ayirma + ayriluvchi')},
 function(){w3Expr(['x · 4 = 96','x = 96 : 4 = {24}']);w3Msg('3-qavat: ko‘paytuvchi = ko‘paytma : ma’lum ko‘paytuvchi')},
 function(){w3Expr(['(24 · 4 − 12) : 6','= (96 − 12) : 6 = 84 : 6 = {14} ✓']);w3Msg('Tekshiruv — <b>x = 24</b>')}];
function d2Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Tenglama — muvozanatdagi tarozi",sum:"x + 7 = 15. Ikkala palladan 7 ni olsak, x = 8. Tenglamani yechish — x ni topish.",a:"m01",
 start:function(){startPh(P1)},fin:d2Fin(P1),
 html:"<p><b>Tenglama</b> — noma'lum son (x) qatnashgan tenglik. Uni muvozanatdagi tarozi deb tasavvur qiling. Bosib kuzating:</p>",btns:[phaser(P1)],
 after:"<p>x = 8 — tenglamaning <b>ildizi</b> (yechimi). Uni topish uchun tenglikni buzmasdan x ni yolg'iz qoldiramiz. Har doim tekshiramiz: x o'rniga topilgan sonni qo'yamiz.</p>",
 q:{t:"x + 25 = 60. x = ?",opts:["35","85","25","45"],ok:0,why:"60 − 25 = 35.",hint:"Ikkala tomondan 25 ni oling.",full:"x = 60 − 25 = 35. Tekshiruv: 35 + 25 = 60 ✓. «85» — qo'shib yuborish xatosi."},
 tn:"Haqiqiy tarozi yoki ilgichli kiyim ilgich + qog'oz qopchalar bilan ko'rsating (Singapur CPA: aniq → rasm → belgi)."},
{h:"Noma'lum ayriluvchi",sum:"450 − x = 280 → x = 450 − 280 = 170. Ayriluvchi = kamayuvchi − ayirma.",a:"m02",
 start:function(){w3Expr(['450 − x = 280']);w3Msg('x — ayriluvchi. Qanday topamiz?')},fin:function(){w3Expr(['450 − x = 280','x = 450 − 280','x = {170}']);w3Msg('Tekshiruv: 450 − 170 = 280 ✓')},
 html:"<p>Bu yerda x — <b>ayriluvchi</b>. 450 dan nechani ayirsak, 280 qoladi? Qaysi amal bilan topamiz?</p><div class='digs w3c'></div>",
 act:function(c,done){d2Sel(c,'.w3c',['450 + 280','450 − 280','280 − 450'],'450 − 280',function(){w3Expr(['450 − x = 280','x = 450 − 280','x = {170}']);w3Msg('Tekshiruv: 450 − 170 = 280 ✓');done()},{'450 + 280':'730 bo‘lsa: 450 − 730 — 450 dan katta sonni ayirib bo‘lmaydi!','280 − 450':'280 dan 450 ni ayirib bo‘lmaydi'})},
 after:"<p>Komponentlar qoidalari:</p><div class='life'><div>➕<span>qo'shiluvchi = yig'indi − boshqa qo'shiluvchi</span></div><div>➖<span>kamayuvchi = ayirma + ayriluvchi; <b>ayriluvchi = kamayuvchi − ayirma</b></span></div></div>",
 q:{t:"90 − x = 35. x = ?",opts:["55","125","65","45"],ok:0,why:"x = 90 − 35 = 55.",hint:"x — ayriluvchi.",full:"Ayriluvchi = kamayuvchi − ayirma = 90 − 35 = 55. Tekshiruv: 90 − 55 = 35 ✓. «125» — ayriluvchini kamayuvchi kabi qo'shib topish."},
 tn:"«Butun va bo'lak» chizma modeli: butun lenta 450, bo'laklar 280 va x. Bola butun − bo'lak = bo'lak ekanini ko'rsin."},
{h:"Noma'lum bo'linuvchi va bo'luvchi",sum:"x : 6 = 48 → x = 48 · 6 = 288. 84 : x = 7 → x = 84 : 7 = 12.",a:"m03",
 start:function(){S.w3={};w3Expr(['x : 6 = 48','84 : x = 7']);w3Msg('Ikkala tenglamani yeching')},fin:function(){w3Expr(['x : 6 = 48 → x = {288}','84 : x = 7 → x = {12}']);w3Msg('Bo‘linuvchi va bo‘luvchi — har xil qoida')},
 html:"<p>Bo'lishda ikki xil holat bor. Har birini yeching:</p>",
 btns:[["x : 6 = 48",function(c,done){S.w3.a=1;w3Expr(['x : 6 = 48','x = 48 · 6 = {288}','tekshiruv: 288 : 6 = 48 ✓']);w3Msg('Bo‘linuvchi = bo‘linma · bo‘luvchi');if(S.w3.b)done()}],["84 : x = 7",function(c,done){S.w3.b=1;w3Expr(['84 : x = 7','x = 84 : 7 = {12}','tekshiruv: 84 : 12 = 7 ✓']);w3Msg('Bo‘luvchi = bo‘linuvchi : bo‘linma');if(S.w3.a)done()},'u']],g2:1,
 after:"<div class='life'><div>✖️<span>ko'paytuvchi = ko'paytma : boshqa ko'paytuvchi</span></div><div>➗<span><b>bo'linuvchi = bo'linma · bo'luvchi</b>; <b>bo'luvchi = bo'linuvchi : bo'linma</b></span></div></div><p>Tekshirish sababi: x : 6 = 48 da «48 : 6 = 8» deb yozib qo'yish — eng ko'p xato.</p>",
 q:{t:"x : 8 = 12. x = ?",opts:["96","4","20","86"],ok:0,why:"x = 12 · 8 = 96.",hint:"x — bo'linuvchi.",full:"Bo'linuvchi = bo'linma · bo'luvchi = 12 · 8 = 96. Tekshiruv: 96 : 8 = 12 ✓. «4» — 12 : 8 ni hisoblash urinishi (noto'g'ri amal)."},
 tn:"Uchburchak-kartochka: tepada ko'paytma (bo'linuvchi), pastda ikki ko'paytuvchi. Bittasini yopsangiz, qolganlari orqali topiladi."},
{h:"Qaysi qoida? Tezkor tanlov",sum:"72 : x = 9 → x = 72 : 9 = 8. x · 7 = 63 → x = 9.",a:"m04",
 start:function(){w3Expr(['72 : x = 9']);w3Msg('x — qaysi komponent?')},fin:function(){w3Expr(['72 : x = 9','x — bo‘luvchi','x = 72 : 9 = {8}']);w3Msg('Tekshiruv: 72 : 8 = 9 ✓')},
 html:"<p><b>72 : x = 9</b>. Avval x qaysi komponent ekanini aniqlang:</p><div class='digs w3c'></div>",
 act:function(c,done){d2Sel(c,'.w3c',['bo‘linuvchi','bo‘luvchi','bo‘linma'],'bo‘luvchi',function(){w3Expr(['72 : x = 9','x — bo‘luvchi','x = 72 : 9 = {8}']);w3Msg('Bo‘luvchi = bo‘linuvchi : bo‘linma. Tekshiruv: 72 : 8 = 9 ✓');done()},{'bo‘linuvchi':'Bo‘linuvchi — «:» belgisidan oldingi son (72)','bo‘linma':'Bo‘linma — natija (9)'})},
 after:"<p>Algoritm: 1) x qaysi komponent? 2) shu komponent qoidasini qo'llang. 3) tekshiring. Agar 72 · 9 = 648 desak, tekshiruv 72 : 648 — mumkin emasligini darhol ko'rsatadi.</p>",
 q:{t:"840 : x = 12. x = ?",opts:["70","7","700","10080"],ok:0,why:"x = 840 : 12 = 70.",hint:"x — bo'luvchi: bo'linuvchini bo'linmaga bo'ling.",full:"840 : 12 = 70 (84 : 12 = 7, oxirida 0). Tekshiruv: 840 : 70 = 12 ✓. «10080» — ko'paytirish (bo'linuvchi qoidasi), «7» — nolni yo'qotish."},
 tn:"Komponent nomlari kartochkasini (bo'linuvchi, bo'luvchi, bo'linma) ifoda tagiga qo'ydiring."},
{h:"Tarkibli tenglama: qavsli",sum:"(x + 370) : 3 = 300 → x + 370 = 900 → x = 530.",a:"m05",
 start:function(){startPh(P5)},fin:d2Fin(P5),
 html:"<p>Endi x qavs ichida. Usul: <b>oxirgi bajariladigan amal</b>dan boshlaymiz va qavsni «bitta son» deb qaraymiz.</p>",btns:[phaser(P5)],
 after:"<p>x = <b>530</b>. Kalit savol: «Bu ifodani hisoblaganda <b>eng oxirida</b> qaysi amal bajariladi?» — o'sha amaldan yechishni boshlaymiz.</p>",
 q:{t:"(x − 45) · 3 = 120. x = ?",opts:["85","40","405","165"],ok:0,why:"x − 45 = 40, x = 85.",hint:"Oxirgi amal — ko'paytirish: x − 45 = 120 : 3.",full:"x − 45 = 120 : 3 = 40. x = 40 + 45 = 85. Tekshiruv: (85 − 45) · 3 = 120 ✓. «40» — faqat birinchi qadamda to'xtab qolish."},
 tn:"Ifoda ustida amallar tartibini raqamlang (1 — qavs, 2 — bo'lish) va yechishni teskari tartibda boshlang."},
{h:"Uch qavatli tenglama",sum:"(x · 4 − 12) : 6 = 14 → x · 4 − 12 = 84 → x · 4 = 96 → x = 24.",a:"m06",
 start:function(){startPh(P6)},fin:d2Fin(P6),
 html:"<p>Qiyin daraja: x uch qavat amal ichida. Har qadamda <b>bitta</b> qavatni olib tashlaymiz.</p>",btns:[phaser(P6)],
 after:"<p>x = <b>24</b>. Yechish — ifodani hisoblashning <b>teskarisi</b>: hisoblashda x · 4 → − 12 → : 6. Yechishda: · 6 → + 12 → : 4.</p>",
 q:{t:"5 · x + 15 = 65. x = ?",opts:["10","16","13","50"],ok:0,why:"5 · x = 50, x = 10.",hint:"Oxirgi amal — qo'shish: 5 · x = 65 − 15.",full:"5 · x = 50 → x = 10. Tekshiruv: 50 + 15 = 65 ✓. «16» — avval 65 : 5 = 13, keyin 13 + 3 — tartib xato; «50» — oxirgi qadam unutilgan."},
 tn:"Piyoz yoki matryoshka metaforasi: tashqi qavatdan ichkariga. Bola har qavatni ovoz chiqarib aytsin."},
{h:"Tekshirish: kim to'g'ri yechdi?",sum:"x − 125 = 375: Ali 250 deydi (250 − 125 = 125 ✗), Vali 500 (500 − 125 = 375 ✓).",a:"m07",
 start:function(){w3Expr(['x − 125 = 375','Ali: x = 250   Vali: x = 500']);w3Msg('Ikkala javobni tenglamaga qo‘yib tekshiring')},fin:function(){w3Expr(['250 − 125 = [125] ✗','500 − 125 = {375} ✓']);w3Msg('Vali to‘g‘ri yechdi')},
 html:"<p><b>x − 125 = 375</b>. Ali x = 250, Vali x = 500 deb topdi. Har birini tekshiring:</p>",
 btns:[["Ali: 250",function(c,done){w3Expr(['250 − 125 = [125]','125 ≠ 375 ✗']);w3Msg('Ali kamayuvchini ayirish bilan topgan — xato');mvK(done,2)}],["Vali: 500",function(c,done){w3Expr(['500 − 125 = {375}','375 = 375 ✓']);w3Msg('Vali: kamayuvchi = ayirma + ayriluvchi ✓');mvK(done,2)},'u']],g2:1,
 after:"<p>Tekshiruv — x o'rniga sonni <b>asl tenglamaga</b> qo'yish. Bu sizning «sug'urtangiz»: xatoni darhol ushlaydi. Olimpiadada javob variantlarini ham shunday tez tekshirish mumkin!</p>",
 q:{t:"x · 6 − 4 = 32 tenglamaning ildizi qaysi?",opts:["6","5","7","36"],ok:0,why:"6 · 6 − 4 = 32 ✓.",hint:"Har bir sonni x o'rniga qo'yib ko'ring.",full:"5: 30 − 4 = 26; 6: 36 − 4 = 32 ✓; 7: 42 − 4 = 38. Javob 6. «36» — x · 6 qiymati, x emas."},
 tn:"Juftlikda: biri yechadi, ikkinchisi faqat tekshiradi. Keyin almashinadi."},
{h:"Masalani tenglama bilan yechish",sum:"«Songa 45 qo'shib, 3 ga bo'lsak 25 chiqadi»: (x + 45) : 3 = 25 → x + 45 = 75 → x = 30.",a:"m08",
 start:function(){w3Expr(['Son + 45, keyin : 3 → 25']);w3Msg('Qaysi tenglama masalaga mos?')},fin:function(){w3Expr(['(x + 45) : 3 = 25','x + 45 = 75','x = {30}']);w3Msg('Tekshiruv: (30 + 45) : 3 = 25 ✓')},
 html:"<p>«Bir son o'ylandi. Unga 45 qo'shib, natija 3 ga bo'linsa, 25 chiqadi.» Qaysi tenglama to'g'ri?</p><div class='digs w3c'></div>",
 act:function(c,done){d2Sel(c,'.w3c',['x + 45 : 3 = 25','(x + 45) : 3 = 25','(x + 3) : 45 = 25'],'(x + 45) : 3 = 25',function(){w3Expr(['(x + 45) : 3 = 25','x + 45 = 25 · 3 = 75','x = 75 − 45 = {30}']);w3Msg('Tekshiruv: 75 : 3 = 25 ✓');done()},{'x + 45 : 3 = 25':'Qavssiz faqat 45 bo‘linadi — masalada esa butun yig‘indi bo‘linadi','(x + 3) : 45 = 25':'Sonlar o‘rni almashgan'})},
 after:"<p>Masaladan tenglama: «avval … keyin …» — avvalgi amal qavsga olinadi. Bir xil masalani «teskaridan» ham yechish mumkin: 25 · 3 = 75, 75 − 45 = 30 — bu ham tenglamaning qadamlari!</p>",
 q:{t:"Ota 3 ta bir xil kitob va 200 so'mlik ruchka oldi, jami 1100 so'm to'ladi. Bitta kitob necha so'm?",opts:["300","900","400","1300"],ok:0,why:"x · 3 + 200 = 1100 → x · 3 = 900 → x = 300.",hint:"Tenglama: x · 3 + 200 = 1100.",full:"x · 3 = 1100 − 200 = 900, x = 900 : 3 = 300. «900» — 3 ta kitob narxi, bittasi emas."},
 tn:"Chizma model: lenta 1100 = [x][x][x][200]. Bolalar avval chizsin, keyin tenglama yozsin."},
{h:"Bilasizmi? Al-Xorazmiy va «al-jabr»",sum:"«Algebra» so'zi al-Xorazmiyning «Al-jabr val-muqobala» kitobi nomidan kelib chiqqan.",a:"m09",
 start:function(){w3Bal(['x','7'],['15']);w3Msg('«al-jabr» — to‘ldirish, «al-muqobala» — qarama-qarshi qo‘yish')},fin:function(){w3Bal(['x','7'],['15']);w3Msg('«al-jabr» — to‘ldirish, «al-muqobala» — qarama-qarshi qo‘yish')},
 html:"<p>📜 Vatandoshimiz <b>Muhammad ibn Muso al-Xorazmiy</b> IX asrda Bag'doddagi «Bayt ul-Hikma»da tenglamalar yechish haqida kitob yozgan: <b>«Al-kitob al-muxtasar fi hisob al-jabr val-muqobala»</b>.</p><p>⭐ Kitob nomidagi <b>«al-jabr»</b> so'zidan butun dunyo bugun ishlatadigan <b>«algebra»</b> so'zi, Xorazmiy ismidan esa <b>«algoritm»</b> so'zi kelib chiqqan. Siz — «Yosh Xorazmiylar»!</p>",
 tn:"Bu fakt o'quvchilar faxrini oshiradi. Al-Xorazmiy haykali Xiva shahrida joylashganini eslatib o'ting."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['1) x qaysi komponent?','2) qoidani qo‘llang','3) tekshiring']);w3Msg('Tarkibli: oxirgi amaldan boshlang')},fin:function(){w3Expr(['1) x qaysi komponent?','2) qoidani qo‘llang','3) tekshiring']);w3Msg('Tarkibli: oxirgi amaldan boshlang')},
 html:"<div class='memo'><ul><li>Qo'shiluvchi = yig'indi − qo'shiluvchi.</li><li>Kamayuvchi = ayirma + ayriluvchi; ayriluvchi = kamayuvchi − ayirma.</li><li>Ko'paytuvchi = ko'paytma : ko'paytuvchi.</li><li>Bo'linuvchi = bo'linma · bo'luvchi; bo'luvchi = bo'linuvchi : bo'linma.</li><li>Tarkibli tenglama: oxirgi bajariladigan amaldan boshlab, qavatma-qavat.</li><li>Doim tekshiring: topilgan sonni asl tenglamaga qo'ying.</li></ul></div>",
 tn:"Kartochka 3D6 (tarkibli tenglamalar) va 4-sinf mavzulari uchun asos bo'ladi."}
];
var PROBS=[
{t:"x + 25 = 60. x = ?",o:["35","85","25","45"],k:0,s:"60 − 25 = 35."},
{t:"x − 18 = 42. x = ?",o:["60","24","42","50"],k:0,s:"Kamayuvchi = 42 + 18 = 60."},
{t:"90 − x = 35. x = ?",o:["55","125","65","45"],k:0,s:"Ayriluvchi = 90 − 35 = 55."},
{t:"x · 7 = 63. x = ?",o:["9","441","56","70"],k:0,s:"63 : 7 = 9."},
{t:"x : 8 = 12. x = ?",o:["96","4","20","86"],k:0,s:"12 · 8 = 96."},
{t:"72 : x = 9. x = ?",o:["8","648","63","81"],k:0,s:"72 : 9 = 8."},
{t:"450 − x = 280. x = ?",o:["170","730","270","180"],k:0,s:"450 − 280 = 170."},
{t:"x + 370 = 900. x = ?",o:["530","1270","630","570"],k:0,s:"900 − 370 = 530."},
{t:"(x + 370) : 3 = 300. x = ?",o:["530","1270","630","230"],k:0,s:"x + 370 = 900 → x = 530."},
{t:"(x · 4 − 12) : 6 = 14. x = ?",o:["24","18","96","26"],k:0,s:"x · 4 − 12 = 84 → x · 4 = 96 → x = 24."},
{t:"5 · x + 15 = 65. x = ?",o:["10","16","13","50"],k:0,s:"5 · x = 50 → x = 10."},
{t:"200 − x : 4 = 150. x = ?",o:["200","50","12","1400"],k:0,s:"x : 4 = 50 → x = 200. Tekshiruv: 200 − 50 = 150."},
{t:"x · 6 − 4 = 32 tenglamaning ildizi qaysi?",o:["6","5","7","36"],k:0,s:"36 − 4 = 32."},
{t:"x − 125 = 375. x = ?",o:["500","250","350","400"],k:0,s:"375 + 125 = 500."},
{t:"840 : x = 12. x = ?",o:["70","7","700","10080"],k:0,s:"840 : 12 = 70."},
{t:"«Sonni 5 ga ko'paytirib, 8 qo'shsak 43 chiqadi.» Qaysi tenglama?",o:["x · 5 + 8 = 43","x · (5 + 8) = 43","x + 5 · 8 = 43","(x + 8) · 5 = 43"],k:0,s:"Avval ko'paytirish, keyin qo'shish: x · 5 + 8 = 43 (x = 7)."},
{t:"Son o'ylandi: unga 45 qo'shib, 3 ga bo'lindi — 25 chiqdi. O'ylangan son?",o:["30","120","70","10"],k:0,s:"(x + 45) : 3 = 25 → x + 45 = 75 → x = 30."},
{t:"3 ta bir xil kitob va 200 so'mlik ruchka uchun 1100 so'm to'landi. Bitta kitob necha so'm?",o:["300","900","400","1300"],k:0,s:"x · 3 + 200 = 1100 → x · 3 = 900 → x = 300."},
{t:"(96 − x) : 4 = 18. x = ?",o:["24","168","78","22"],k:0,s:"96 − x = 72 → x = 24."},
{t:"246 : (7 · (x + 1) − 15) = 6. x = ?",o:["7","8","6","41"],k:0,s:"7 · (x + 1) − 15 = 41 → 7 · (x + 1) = 56 → x + 1 = 8 → x = 7."}
];
function PRACT_STAGE(){w3Bal(['x','7'],['15']);w3Msg('Tarozi muvozanatda')}
var PREP_DATA={teach:["Tenglama va uning ildizi; tarozi modeli.","Komponentlar orasidagi bog'lanish orqali oddiy tenglamalarni yechish.","Tarkibli tenglamalar: oxirgi amaldan boshlab yechish.","Tekshirish va masalalarni tenglama yordamida yechish."],
 mist:["Ayriluvchini qo'shib topadi: 450 − x = 280 → 730.","Bo'linuvchini bo'lish bilan topadi: x : 6 = 48 → 8.","Tarkibli tenglamada ichki amaldan boshlaydi.","Tekshirishni o'tkazib yuboradi; birinchi qadamda to'xtab qoladi."],
 need:["Pallali tarozi yoki kiyim ilgichi + qopchalar.","Komponent nomlari kartochkalari."],
 board:["<span class='w2'>x + 7 = 15 → x = 8</span>.","<span class='w2'>450 − x = 280 → x = 170</span>.","<span class='w2'>x : 6 = 48 → x = 288</span>.","<span class='w2'>(x + 370) : 3 = 300 → x = 530</span>.","<span class='w2'>(x · 4 − 12) : 6 = 14 → x = 24</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
