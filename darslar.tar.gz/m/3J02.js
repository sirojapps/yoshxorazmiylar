var CODE='3J02',TITLE='3-sinf · Shaklli qonuniyatlar';
// shakl chizish: t = 'o' doira, 't' uchburchak, 's' kvadrat, 'r' romb
function J2shape(x,y,t,col,s){s=s||12;var g=S.g;col=col||C.b;
 if(t==='o')E('circle',{cx:x,cy:y,r:s,fill:col,stroke:C.line,'stroke-width':1.2},g);
 else if(t==='t')E('path',{d:'M'+x+' '+(y-s)+' L'+(x+s)+' '+(y+s*.8)+' L'+(x-s)+' '+(y+s*.8)+' Z',fill:col,stroke:C.line,'stroke-width':1.2},g);
 else if(t==='s')E('rect',{x:x-s*.85,y:y-s*.85,width:s*1.7,height:s*1.7,fill:col,stroke:C.line,'stroke-width':1.2},g);
 else E('path',{d:'M'+x+' '+(y-s)+' L'+(x+s)+' '+y+' L'+x+' '+(y+s)+' L'+(x-s)+' '+y+' Z',fill:col,stroke:C.line,'stroke-width':1.2},g)}
var J2COL={o:C.a,t:C.b,s:C.c,r:'#9bd08a'};
function J2row(seq,o){o=o||{};var n=seq.length,w=Math.min(30,340/n),x0=180-n*w/2+w/2,y=o.y||80;
 seq.forEach(function(t,i){if(o.box&&i%o.box===0)E('rect',{x:x0+i*w-w/2+1,y:y-20,width:w*Math.min(o.box,n-i)-2,height:40,rx:6,fill:i/o.box%2?'#eef6fd':'#fdf3e3',stroke:'#dde5ee'},S.g)});
 seq.forEach(function(t,i){if(t==='?'){T(S.g,x0+i*w,y+6,'?',{'font-size':18,'font-weight':800,fill:C.bad})}else J2shape(x0+i*w,y,t,(o.hi&&o.hi[i])||J2COL[t],w*.38);if(o.num)T(S.g,x0+i*w,y+34,String(i+1),{'font-size':9,fill:'#5b6b7b'})})}
var P1=[function(){clear();J2row('otss'.repeat(3).split('').concat(['?']),{num:1});Y3msg('Shakllar takrorlanadi. 25 ta shakl ichida nechta kvadrat bor?')},
 function(){clear();J2row('otss'.repeat(3).split(''),{num:1,box:4});Y3msg('Takrorlanuvchi <b>blok</b>: ○ △ □ □ — 4 ta shakl, ichida 2 ta kvadrat')},
 function(){clear();J2row('otss'.repeat(3).split('').concat(['o']),{num:1,box:4});Y3msg('25 = 6 · 4 + 1: 6 ta blok (12 kvadrat) va yana 1 ta shakl — doira. Jami <b>12</b> kvadrat')}];
function J2stairs(n){clear();var g=S.g,s=13,x0=14;for(var k=1;k<=n;k++){
  for(var r=0;r<k+1;r++)E('rect',{x:x0,y:125-(r+1)*s,width:s-1,height:s-1,fill:C.b,stroke:C.line,'stroke-width':.8},g);
  for(var c=1;c<=k;c++)E('rect',{x:x0+c*s,y:125-s,width:s-1,height:s-1,fill:C.a,stroke:C.line,'stroke-width':.8},g);
  T(g,x0+(k+1)*s/2,140,k+'-shakl',{'font-size':10,fill:'#5b6b7b'});T(g,x0+(k+1)*s/2,156,String(2*k+1),{'font-size':11,'font-weight':800,fill:'#1d2b3a'});x0+=(k+1)*s+30}
 Y3msg(n+'-shakl: '+(2*n+1)+' ta katak. Har safar <b>+2</b> ta qo\u2018shiladi')}
function J2rb(n,show){clear();var g=S.g,s=16;var x0=50;Y3msg('ko\u2018k — '+n+', qizil — '+(2*n)+(show?', jami — <b>'+(3*n)+'</b>':''));T(g,180,22,n+'-shakl',{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++)E('rect',{x:x0+i*(s+2),y:60,width:s,height:s,fill:C.b,stroke:C.line,'stroke-width':.8},g);
 for(var j=0;j<2*n;j++)E('rect',{x:x0+(j%n)*(s+2),y:82+Math.floor(j/n)*(s+2),width:s,height:s,fill:C.bad,stroke:C.line,'stroke-width':.8},g);
 T(g,300,72,'ko‘k: '+n,{'font-size':12,'font-weight':800,fill:C.blue});T(g,300,98,'qizil: '+(2*n),{'font-size':12,'font-weight':800,fill:C.bad});if(show)T(g,300,124,'jami: '+(3*n),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
function J2arrow(k){clear();var g=S.g,dirs=[0,90,180,270];for(var i=0;i<8;i++){var x=30+i*42,a=dirs[i%4];var gg=E('g',{transform:'translate('+x+',80) rotate('+a+')'},g);E('path',{d:'M-12 0 L8 0 M2 -7 L10 0 L2 7',fill:'none',stroke:i<k?C.blue:'#c9d3dd','stroke-width':3,'stroke-linecap':'round'},gg);T(g,x,112,String(i+1),{'font-size':10,fill:'#5b6b7b'})}
 Y3msg('Strelka har safar <b>soat yo‘nalishida 90°</b> buriladi: → ↓ ← ↑ → …')}
var STEPS=[
{h:"Takrorlanuvchi blok",sum:"○△□□ bloki 4 ta: 25 = 6·4 + 1 → 6 blokda 12 ta □, ortgan 1 ta — ○. Jami 12.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Shakllar takrorlanmoqda. Dastlabki <b>25 ta</b> shakl ichida nechta kvadrat bor? Hammasini chizmasdan topamiz.</p>",btns:[phaser(P1)],
 after:"<p>Usul: 1) takrorlanuvchi <b>blokni</b> toping; 2) nechta to'liq blok borligini bo'lish bilan toping; 3) <b>ortgan</b> shakllarni alohida qarang.</p>",
 q:{t:"△ ○ ○ △ ○ ○ … takrorlanadi. Dastlabki 20 ta shakldan nechtasi doira?",opts:["10","13","14","12"],ok:1,why:"Blok △○○ (3 ta). 20 = 6·3 + 2: 6 blokda 12 doira, ortgan 2 ta: △○ — yana 1 doira. Jami 13.",hint:"Blokda nechta shakl va nechta doira? Ortgan shakllar qanday?",full:"Blok — △ ○ ○, 3 ta shakl, 2 ta doira. 20 : 3 = 6 (qoldiq 2). 6 blok → 12 doira. Ortgan 2 ta shakl: △, ○ → yana 1 doira. Jami 13. «12» — ortgan qism unutilgan."},
 tn:"Bolalar blokni qavs bilan ajratsin. Qoldiq qismni alohida rangda belgilash xatoni kamaytiradi."},
{h:"O'sib boruvchi shakllar",sum:"Har safar +2 katak: 3, 5, 7, … → n-shakl: 2n + 1. 10-shakl: 21.",a:"m02",start:function(){S.n=1;J2stairs(1)},fin:function(){J2stairs(4)},
 html:"<p>Kataklardan «burchak» shakllar quriladi. Tugmani bosib keyingi shaklni quring va kataklarni sanang.</p>",
 btns:[["➕ Keyingi shakl",function(c,done){if(S.n<4){S.n++;J2stairs(S.n)}if(S.n>=3)done()}]],
 after:"<p>3, 5, 7, 9 … — har safar <b>2 ta</b> qo'shiladi (bittasi tepaga, bittasi yonga). n-shaklda 2 · n + 1 ta katak: 10-shaklda <b>21</b>.</p>",
 q:{t:"Gugurt cho'plaridan yonma-yon uchburchaklar terilmoqda: 1 ta — 3 cho'p, 2 ta — 5, 3 ta — 7. 10 ta uchburchak uchun nechta cho'p kerak?",opts:["30","21","23","20"],ok:1,why:"Har yangi uchburchak +2 cho'p: 3 + 9·2 = 21.",hint:"Har yangi uchburchak uchun nechta cho'p qo'shiladi? Birinchisi nechta?",full:"1-uchburchak — 3 cho'p, keyingi har biri +2 (bitta tomon umumiy). 10 ta uchun: 3 + 9 · 2 = 21. «30» — umumiy tomonlar hisobga olinmagan (10 · 3)."},
 tn:"Shu masalani gugurt cho'plari bilan qildiring: bola «nega 3 emas, 2 qo'shiladi»ni o'zi ko'rsin."},
{h:"Ikki rangli shakllar",sum:"n-shaklda ko'k n, qizil 2n. «Qizil ko'kdan 7 ta ko'p» → n = 7 → jami 21.",a:"m03",start:function(){S.n=1;J2rb(1)},fin:function(){J2rb(7,true)},
 html:"<p>Har shaklda ko'k va qizil kataklar bor. Shakllarni almashtirib, qonuniyatni toping.</p>",
 btns:[["◀",function(c,done){if(S.n>1){S.n--;J2rb(S.n)}mvK(done,3)}],["▶",function(c,done){if(S.n<7){S.n++;J2rb(S.n)}mvK(done,3)},'u']],g2:1,
 after:"<p>n-shaklda: ko'k — <b>n</b>, qizil — <b>2n</b>. Qizil ko'kdan <b>n</b> ta ko'p. Agar «qizil ko'kdan 7 ta ko'p» desa — bu <b>7-shakl</b>: 7 ko'k + 14 qizil = <b>21</b> katak.</p>",
 q:{t:"Shu qonuniyatda qaysi shaklda jami 30 ta katak bo'ladi?",opts:["15-shakl","10-shakl","30-shakl","20-shakl"],ok:1,why:"Jami 3n = 30 → n = 10.",hint:"n-shaklda jami nechta katak: n + 2n = ?",full:"n-shaklda n ko'k + 2n qizil = 3n katak. 3n = 30 → n = 10: 10-shakl. Tekshiramiz: 10 + 20 = 30 ✓."},
 tn:"Jadval tuzdiring: shakl raqami | ko'k | qizil | jami. Jadvaldan qoida o'zi chiqadi."},
{h:"Aylanuvchi strelka",sum:"Strelka 4 xil holatda takrorlanadi: 10-holat = 10 : 4 qoldiq 2 → 2-holat (↓).",a:"m04",start:function(){S.n=1;J2arrow(1)},fin:function(){J2arrow(8)},
 html:"<p>Strelka har qadamda buriladi. Bosib qadamlarni ko'ring.</p>",
 btns:[["↻ Keyingi qadam",function(c,done){if(S.n<8){S.n++;J2arrow(S.n)}if(S.n>=5)done()}]],
 after:"<p>4 ta burilishdan keyin strelka joyiga qaytadi — davr <b>4</b>. 10-holat: 10 : 4 = 2 (qoldiq 2) → 2-holat, ya'ni <b>pastga</b> (↓).</p>",
 q:{t:"Shu qonuniyatda 23-holatda strelka qaysi tomonga qaraydi?",opts:["→ o'ngga","↓ pastga","← chapga","↑ tepaga"],ok:2,why:"23 : 4 = 5 (qoldiq 3) → 3-holat: chapga.",hint:"Davr 4. 23 ni 4 ga bo'lib, qoldiqqa qarang.",full:"Holatlar: 1 → o'ngga, 2 → pastga, 3 → chapga, 4 → tepaga. 23 = 5 · 4 + 3 → 3-holat: chapga."},
 tn:"Bolalar soat strelkasi bilan bog'lasin: 4 ta chorak burilish = to'liq aylanish."},
{h:"Harflar va belgilar qonuniyati",sum:"A, B, B, A, B, B, … — blok ABB: 30 ta ichida 10 blok, B — 20 ta.",a:"m05",
 start:function(){clear();Y3seq('ABBABBABB'.split('').concat(['…']),{});Y3msg('Dastlabki 30 ta harfdan nechtasi B?')},fin:function(){clear();Y3seq('ABBABBABB'.split('').concat(['…']),{hi:{0:'#fde6c8',1:'#fde6c8',2:'#fde6c8',3:'#e1f4f2',4:'#e1f4f2',5:'#e1f4f2'}});Y3msg('Blok ABB: 30 : 3 = 10 blok × 2 B = <b>20</b>')},
 html:"<p>A, B, B, A, B, B, … Dastlabki <b>30 ta</b> harfdan nechtasi B? Javobni tanlang.</p>",
 btns:Y3ch(["10","15","20","18"],2,function(){STEPS[4].fin()},'Blokni toping: nechta harf, ichida nechta B?'),
 after:"<p>Blok «A B B» — 3 ta harf, 2 ta B. 30 : 3 = 10 blok, qoldiq 0 — demak 10 · 2 = <b>20</b> ta B.</p>",
 q:{t:"Shu qatorda 31-harf qaysi va qayerda turadi?",opts:["A — 11-blokning 1-harfi","B — 10-blokning oxirgi harfi","B — 11-blokning 2-harfi","A — 10-blokning 1-harfi"],ok:0,why:"31 : 3 = 10 (qoldiq 1): 10 ta blok to'liq tugadi, 31-harf — 11-blokning 1-harfi: A.",hint:"31 ni 3 ga bo'ling. Qoldiq blokning qaysi harfini ko'rsatadi?",full:"30 ta harf — 10 ta to'liq blok. 31-harf — yangi blokning 1-harfi: A."},
 tn:"Yoz-qish, hafta kunlari, ko'cha chiroqlari — bolalar hayotdan davriy misollar topsin."},
{h:"Tuzoq: o'rin va soni",sum:"«n-o'rinda nima?» — qoldiq bo'yicha; «n tadan nechtasi?» — bloklar soni × + ortgan qism.",a:"m06",
 start:function(){clear();J2row('ottsso'.split('').concat('ottsso'.split('')),{num:1,box:6});Y3msg('Blok: ○ △ △ □ □ ○ — 6 ta shakl')},fin:function(){clear();J2row('ottsso'.split('').concat('ottsso'.split('')),{num:1,box:6});Y3msg('40 = 6·6 + 4: 40-shakl — blokning 4-shakli: □. Uchburchaklar: 6·2 + 2 = <b>14</b>')},
 html:"<p>Bir xil qatorda ikki xil savol: <b>«40-o'rinda qaysi shakl?»</b> va <b>«40 tadan nechtasi uchburchak?»</b>. Ikkalasini aralashtirib yubormang. Avval 40-o'rindagi shaklni tanlang:</p>",
 btns:Y3ch(["○","△","□"],2,function(){STEPS[5].fin()},'40 : 6 = ? va qoldiq? Blokning qaysi o‘rni?'),
 after:"<p>40 = 6 · 6 + 4. 40-o'rin — blokning <b>4-shakli: □</b>. Uchburchaklar soni: har blokda 2 ta → 6 · 2 = 12, ortgan 4 ta shaklda (○ △ △ □) yana 2 ta → <b>14</b>.</p>",
 q:{t:"Shu qatorda dastlabki 40 ta shakldan nechtasi doira?",opts:["12","13","14","7"],ok:1,why:"Har blokda 2 doira: 6·2 = 12; ortgan ○△△□ da yana 1 ta: 13.",hint:"Blokda nechta doira? Ortgan 4 ta shakl qaysilar?",full:"Blok ○△△□□○ da 2 ta doira. 6 blok → 12. Ortgan 4 ta: ○ △ △ □ → 1 doira. Jami 13. «12» — ortgan qism unutilgan."},
 tn:"Ikki savol turini doskada ikki ustunga yozing: «QAYSI?» — qoldiq, «NECHTA?» — bloklar + ortgan qism."},
{h:"Bilasizmi? O'zbek naqshlari",sum:"Samarqand va Buxoro koshinlaridagi girih naqshlari — takrorlanuvchi blokdan qurilgan qonuniyat.",a:"m07",start:function(){J2girih()},fin:function(){J2girih()},
 html:"<p>🕌 Samarqanddagi Registon, Buxorodagi madrasalar devorlaridagi koshin naqshlarni eslang. Ustalar ularni <b>bitta kichik blokni</b> qayta-qayta takrorlab va burib yaratgan. Bu — shaklli qonuniyatning eng go'zal ko'rinishi!</p><p>Bunday naqshlar <b>girih</b> deyiladi. Olimlar ulardagi geometriyani bugun ham o'rganishadi.</p>",
 btns:[["🔁 Blokni takrorlash",function(c,done){J2girih(true);done()}]],
 after:"<p>Bitta blok — butun devor! Shunday qilib, qonuniyatni topgan odam butun naqshni oldindan aytib bera oladi.</p>",
 tn:"Bolalar katak daftarda o'z naqsh blokini chizib, uni 4 marta takrorlasin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){P1[2]()},fin:function(){P1[2]()},
 html:"<div class='memo'><ul><li>Takrorlanuvchi qatorda avval <b>blokni</b> toping va uzunligini sanang.</li><li><b>«n-o'rinda qaysi?»</b> — n ni blok uzunligiga bo'ling, <b>qoldiq</b> — blokdagi o'rin (0 → oxirgisi).</li><li><b>«n tadan nechtasi?»</b> — to'liq bloklar soni × blokdagi son + <b>ortgan qism</b>.</li><li>O'sib boruvchi shakllarda: har safar qancha qo'shilishini toping (3, 5, 7 → +2).</li><li>Jadval tuzing: raqami | soni — qoida o'zi ko'rinadi.</li><li>Aylanish: 4 ta chorak burilishdan keyin qaytadi.</li></ul></div>",
 tn:"Keyingi darsda bolalar o'zi qonuniyatli qator tuzib, sinfdoshiga topishmoq bersin."}
];
function J2girih(rep){clear();var g=S.g,n=rep?4:1;for(var a=0;a<n;a++)for(var b=0;b<(rep?2:1);b++){var x=(rep?40:150)+a*72,y=(rep?20:40)+b*72;E('rect',{x:x,y:y,width:64,height:64,fill:'#1f6fb2',stroke:'#fff'},g);E('path',{d:'M'+(x+32)+' '+(y+4)+' L'+(x+60)+' '+(y+32)+' L'+(x+32)+' '+(y+60)+' L'+(x+4)+' '+(y+32)+' Z',fill:'#f6c98a',stroke:'#fff','stroke-width':2},g);E('circle',{cx:x+32,cy:y+32,r:10,fill:'#12a39f',stroke:'#fff','stroke-width':2},g)}
 Y3msg(rep?'Bitta blok 8 marta takrorlandi — naqsh tayyor':'Bitta blok')}
var PROBS=[
{t:"○ △ □ □ takrorlanadi. Dastlabki 25 ta shakldan nechtasi kvadrat?",o:["12","13","14","10"],k:0,s:"Blok 4 ta: 25 = 6·4 + 1 → 6·2 = 12, ortgan 1 ta — ○."},
{t:"○ △ □ □ takrorlanadi. 25-shakl blokning nechanchi o'rnida va qaysi shakl?",o:["1-o'rin, ○","2-o'rin, △","3-o'rin, □","4-o'rin, □"],k:0,s:"25 : 4 = 6 (qoldiq 1) → 6 blok tugadi, 25-shakl — blokning 1-o'rni: ○."},
{t:"Kataklar: 1-shakl 3 ta, 2-shakl 5 ta, 3-shakl 7 ta. 10-shakl nechta katak?",o:["21","20","23","30"],k:0,s:"3 + 9 · 2 = 21."},
{t:"Nuqtalardan kvadratlar: 1, 4, 9, … 6-shaklda nechta nuqta?",o:["36","25","30","49"],k:0,s:"6 · 6 = 36."},
{t:"Gugurtdan yonma-yon kvadratlar: 1 ta — 4 cho'p, 2 ta — 7, 3 ta — 10. 8 ta kvadrat uchun nechta cho'p?",o:["25","32","24","28"],k:0,s:"4 + 7 · 3 = 25."},
{t:"A, B, B, A, B, B, … dastlabki 30 ta harfdan nechtasi B?",o:["20","15","18","10"],k:0,s:"10 blok × 2 = 20."},
{t:"Strelka har qadamda soat yo'nalishida 90° buriladi, 1-holatda o'ngga qaraydi. 10-holatda qayoqqa qaraydi?",o:["pastga","o'ngga","chapga","tepaga"],k:0,s:"10 : 4 qoldiq 2 → 2-holat: pastga."},
{t:"△ ○ ○ takrorlanadi. Dastlabki 20 ta shakldan nechtasi doira?",o:["13","12","14","10"],k:0,s:"6 blok → 12, ortgan △○ → +1: 13."},
{t:"Qatorda har shakl oldingisidan 3 ta katak ko'p: 2, 5, 8, … Nechanchi shaklda 32 ta katak bor?",o:["11-shakl","10-shakl","12-shakl","30-shakl"],k:0,s:"2 + (n−1)·3 = 32 → n − 1 = 10 → n = 11."},
{t:"n-shaklda ko'k n ta, qizil 2n ta katak. Qizil ko'kdan 7 ta ko'p bo'lgan shaklda jami nechta katak?",o:["21","14","7","24"],k:0,s:"n = 7: 7 + 14 = 21."},
{t:"Qizil, sariq, yashil, ko'k, qizil, sariq, yashil, ko'k … munchoqlar. 50-munchoq qaysi rangda?",o:["sariq","qizil","yashil","ko'k"],k:0,s:"Blokda 4 ta rang. 50 : 4 = 12 (qoldiq 2) → blokning 2-rangi: sariq."},
{t:"1-qavat 1 ta kub, 2-qavatli minorada 1 + 2 = 3 ta, 3-qavatlida 1 + 2 + 3 = 6 ta. 6-qavatli minorada nechta kub?",o:["21","18","15","36"],k:0,s:"1 + 2 + 3 + 4 + 5 + 6 = 21."},
{t:"○ □ □ △ △ △ takrorlanadi. Dastlabki 40 ta shakldan nechtasi uchburchak?",o:["19","20","18","21"],k:0,s:"Blok 6 ta, 3 ta △: 40 = 6·6 + 4 → 18, ortgan ○□□△ → +1: 19."},
{t:"Bayroqchalar: 2 ta qizil, 1 ta ko'k, 2 ta qizil, 1 ta ko'k … 30 ta bayroqchadan nechtasi qizil?",o:["20","15","10","24"],k:0,s:"Blok 3 ta, 2 qizil: 10 blok × 2 = 20."},
{t:"Soat 1:00 dan boshlab strelka har soatda 30° buriladi. Necha soatdan keyin birinchi marta joyiga qaytadi?",o:["12","4","6","10"],k:0,s:"To'liq aylanish 360°: 360 : 30 = 12."},
{t:"Shakllar: 1-shakl 1 ta katak, 2-shakl 5 ta (plyus belgisi), 3-shakl 9 ta. 5-shakl nechta katak?",o:["17","13","25","21"],k:0,s:"Har safar +4: 1, 5, 9, 13, 17."},
{t:"A B C D C B A B C D C B … takrorlanadi. 100-harf qaysi?",o:["D","C","B","A"],k:0,s:"Blok ABCDCB — 6 ta. 100 : 6 = 16 (qoldiq 4) → D."},
{t:"Zinapoya kataklardan: 1-pog'ona 1 ta, 2 pog'onali 3 ta, 3 pog'onali 6 ta. Necha pog'onali zinapoyada 15 ta katak?",o:["5","6","4","15"],k:0,s:"1 + 2 + 3 + 4 + 5 = 15."},
{t:"Qatorda doira va kvadratlar: ○ □ ○ □ □ ○ □ □ □ ○ … (kvadratlar soni har safar 1 ga ortadi). 4-doiradan keyin nechta kvadrat keladi?",o:["4","3","5","10"],k:0,s:"1-doiradan keyin 1, 2-dan keyin 2, 3-dan keyin 3, 4-dan keyin 4 ta."},
{t:"Har kuni gul 2 sm o'sadi. Dushanba kuni bo'yi 10 sm edi. Keyingi dushanba bo'yi necha sm bo'ladi?",o:["24","22","20","26"],k:0,s:"7 kun · 2 = 14: 10 + 14 = 24."}
];
function PRACT_STAGE(){P1[2]()}
var PREP_DATA={teach:["Takrorlanuvchi blok, «qaysi?» va «nechta?» savollari.","O'sib boruvchi shakllar: har safar qo'shiladigan miqdor, n-shakl formulasi.","Ikki rangli shakllar jadvali; aylanish davri.","Girih naqshlari — hayotdagi qonuniyat."],
 mist:["Ortgan qismni unutadi (12 o'rniga 13).","Qoldiq 0 bo'lganda blokning birinchisini oladi.","Gugurt masalasida umumiy tomonlarni ikki marta sanaydi (10·3 = 30).","«Qaysi?» va «nechta?» savollarini aralashtiradi."],
 need:["Gugurt cho'plari yoki tayoqchalar.","Rangli kubiklar yoki munchoqlar.","Katak daftar."],
 board:["Blok qavsda: <span class='w2'>(○△□□)(○△□□)…</span>.","<span class='w2'>25 = 6·4 + 1</span>.","Jadval: <span class='w2'>shakl | katak: 1→3, 2→5, 3→7</span>.","<span class='w2'>n-shakl: 2n + 1</span>.","Strelka: <span class='w2'>→ ↓ ← ↑</span>, davr 4."]};

// ---------- 3Y/3J/3M umumiy yordamchilari (w_3y) ----------
function Y3msg(h,col){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(col?';color:'+col:'')+'">'+h+'</div></div>'}
function Y3B(x,y,w,h,n,fills,txt,o){o=o||{};var g=S.g;for(var i=0;i<n;i++){E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:(fills&&fills[i])||C.off,stroke:C.line,'stroke-width':1.3},g);if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,String(txt[i]),{'font-size':o.fs||12,'font-weight':800,fill:'#2b2b2b'})}E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2,rx:2},g)}
// sonlar qatori: arr (son yoki '?'), o.hi = {i:rang}, o.diff = ['+2',...] (orasidagi yoylar), o.y
function Y3seq(arr,o){o=o||{};var g=S.g,n=arr.length,w=Math.min(52,330/n),x0=180-n*w/2,y=o.y||70;
 arr.forEach(function(v,i){var x=x0+i*w,c=(o.hi&&o.hi[i])||null;E('rect',{x:x+3,y:y,width:w-6,height:38,rx:8,fill:c||(v==='?'?'#fff4d6':'#fff'),stroke:c?C.line:'#c9d3dd','stroke-width':1.6},g);T(g,x+w/2,y+25,String(v),{'font-size':String(v).length>4?12:(w<44?14:17),'font-weight':800,fill:v==='?'?C.bad:'#1d2b3a'});
  if(o.lab)T(g,x+w/2,y+54,o.lab[i]||'',{'font-size':10,fill:'#5b6b7b'})});
 (o.diff||[]).forEach(function(d,i){if(!d)return;var xa=x0+i*w+w/2,xb=xa+w;E('path',{d:'M'+(xa+4)+' '+(y-2)+' Q'+((xa+xb)/2)+' '+(y-26)+' '+(xb-4)+' '+(y-2),fill:'none',stroke:o.dc||C.blue,'stroke-width':1.6},g);T(g,(xa+xb)/2,y-22,d,{'font-size':11,'font-weight':800,fill:o.dc||C.blue})});
 if(o.d2)(o.d2).forEach(function(d,i){if(!d)return;var xm=x0+i*w+w;T(g,xm,y-44,d,{'font-size':11,'font-weight':800,fill:C.ok})})}
// tanlov tugmalari: to'g'ri tanlanganda done; xatoda xabar
function Y3ch(list,ok,onOk,badMsg){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(onOk)onOk();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);Y3msg(badMsg||'Yo‘q, yana o‘ylab ko‘ring',C.bad)}}]})}
function Y3T(x,y,t,o){return T(S.g,x,y,t,o)}
