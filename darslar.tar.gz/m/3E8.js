var CODE='3E8',TITLE='3-sinf · Ortiqcha yoki yetishmaydigan ma’lumotli masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w8u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Nima yetishmaydi?",sum:"«Olma 24 ta, jami nechta?» — nok soni berilmagan; masalani yechib bo'lmaydi. Nok 18 ta bo'lsa: 24 + 18 = 42.",a:"m01",
 frames:[{t:'Masalani o‘qing',lines:['Bog‘da olma va nok daraxtlari bor.','Olma daraxtlari — 24 ta.','Savol: bog‘da jami nechta daraxt bor?'],hl:{2:'q'},note:'Yechish uchun nima yetishmaydi?'}],
 html:"<p>Har qanday masalani yechishdan oldin o'zingizdan so'rang: <b>savolga javob berish uchun hamma narsa bormi?</b></p>",
 btns:bmPick(["daraxtlar yoshi","nok soni","bog‘ yuzi"],1,{t:'Yetishmagan ma’lumotni qo‘shdik',lines:['Bog‘da olma va nok daraxtlari bor.','Olma daraxtlari — 24 ta.','Nok daraxtlari — 18 ta.','Savol: jami nechta? 24 + 18 = 42'],hl:{2:'ok',3:'q'}},["Yosh — jami sonni topishga yordam bermaydi.","","Bog‘ yuzi bilan daraxt sonini topib bo‘lmaydi."]),
 after:"<p>Jami = olma + nok. Nok soni bo'lmasa — masala <b>yechilmaydi</b>. «24» deb javob berish — eng ko'p uchraydigan xato.</p>",
 q:{t:"«Do'kon dushanba 125 ta non sotdi, seshanba undan ko'p. Ikki kunda nechta?» Nima yetishmaydi?",opts:["nonning narxi","seshanba qanchaga ko'p sotgani","dushanba sotilgan non soni","do'kon nomi"],ok:1,why:"«Ko'p» — lekin qanchaga?",hint:"Seshanba nechta sotilgan — bilamizmi?",full:"Seshanba soni noma'lum: «undan ko'p» deyilgan, lekin qanchaga — yo'q. Dushanba soni berilgan, narx va nom esa kerak emas."},
 tn:"Bank misollari (2255, 3115-id). Bolalarga «yarim masala» bering — ular yetishmagan qismni o'zi qo'shsin. Bu AQSh va Singapur darsliklarida keng qo'llaniladi."}),
bmStep({h:"Nima ortiqcha?",sum:"«4 sigirdan 60 l sut, sigirlar 5 yoshda. 1 sigir necha litr?» — yosh ortiqcha; 60 : 4 = 15 l.",a:"m02",
 frames:[{t:'Masalani o‘qing',lines:['Ferma 4 ta sigirdan kuniga 60 l sut sog‘adi.','Sigirlar 5 yoshda.','Savol: bitta sigir kuniga necha litr sut beradi?'],hl:{2:'q'},note:'Qaysi ma’lumot ortiqcha?'}],
 html:"<p>Ba'zan masalada <b>keraksiz</b> son bo'ladi. U chalg'itadi. Qaysi biri?</p>",
 btns:bmPick(["sigirlar soni","sut miqdori","sigirlar yoshi"],2,{t:'Ortiqchasini o‘chirdik',lines:['Ferma 4 ta sigirdan kuniga 60 l sut sog‘adi.','Sigirlar 5 yoshda.','Javob: 60 : 4 = 15 l'],hl:{1:'bad',2:'ok'}},["Sigirlar soni kerak: 60 l ni 4 ga bo‘lamiz.","Sut miqdorisiz hisoblab bo‘lmaydi.",""]),
 after:"<p>Ortiqcha sonni <b>chizib tashlang</b> — keyin masala oson bo'ladi. 60 : 5 = 12 (yoshga bo'lish) — chalg'ituvchi son tuzog'i.</p>",
 q:{t:"«Bog'bon 5 qatorga 8 tadan daraxt ekdi, har daraxt 3 m baland. Nechta daraxt ekdi?»",opts:["40","15","24","120"],ok:0,why:"8 · 5 = 40; balandlik ortiqcha.",hint:"Daraxtlar soni uchun qaysi sonlar kerak?",full:"5 qator · 8 ta = 40 daraxt. Balandlik (3 m) ortiqcha. «24» = 8 · 3, «15» = 5 · 3, «120» = 5 · 8 · 3 — ortiqcha son ishlatilgan."},
 tn:"Bank misoli (3118-id). Masala matnini qog'ozga chiqarib bering, bolalar ortiqcha sonni rangli qalam bilan chizib tashlasin."}),
bmStep({h:"Ikki ortiqcha son",sum:"Soat 8:00 va 45 yo'lovchi ortiqcha: masofa = 70 · 3 = 210 km.",a:"m03",
 frames:[{t:'Masalani o‘qing',lines:['Avtobus soat 8:00 da jo‘nadi.','Unda 45 yo‘lovchi bor edi.','Soatiga 70 km tezlikda 3 soat yurdi.','Savol: necha km yo‘l bosdi?'],hl:{3:'q'}},
  {t:'Ortiqcha ma’lumotni chizamiz',lines:['Avtobus soat 8:00 da jo‘nadi.','Unda 45 yo‘lovchi bor edi.','Soatiga 70 km tezlikda 3 soat yurdi.','Savol: necha km yo‘l bosdi?'],hl:{0:'bad',1:'bad',2:'ok',3:'q'},note:'Faqat 3-qator kerak'},
  {t:'Masofa = tezlik · vaqt',bars:[{lab:'3 soat',y:76,segs:w8u(3,'70','g',1)}],br:[{b:0,lab:'210 km',up:true,col:C.ok}],calc:['70 · 3 = <b>210</b> km']}],
 html:"<p>Bu masalada to'rtta son bor: 8, 45, 70, 3. Qaysilari kerak? Kuzating.</p>",
 after:"<p>Usul: 1) savolni o'qing; 2) savol uchun qaysi <b>formula</b> kerak (S = v · t); 3) faqat shu kattaliklarni oling.</p>",
 q:{t:"«Lola 9 yoshda, 3-qavatda yashaydi, har kuni 2 soat kitob o'qiydi. Bir haftada necha soat o'qiydi?»",opts:["14","27","63","18"],ok:0,why:"2 · 7 = 14.",hint:"Haftada necha kun?",full:"Haftada 7 kun: 2 · 7 = 14 soat. 9 yosh va 3-qavat — ortiqcha. «27» = 9 · 3, «63» = 9 · 7, «18» = 9 · 2 — ortiqcha sonlar ishlatilgan."},
 tn:"Bank misoli (3114, 3117-id). Diqqat: 3117 da «7 kun» masalada yozilmagan, bola «hafta = 7 kun» ni o'zi bilishi kerak."}),
bmStep({h:"Qaysi masalani yechib bo‘lmaydi?",sum:"«28 o'quvchi, ba'zilari to'garakka qatnaydi. Nechtasi qatnamaydi?» — «ba'zilari» son emas, yechib bo'lmaydi.",a:"m04",
 frames:[{t:'Uchta masala',lines:['A) 28 o‘quvchi, 12 tasi to‘garakda. Nechtasi qatnamaydi?','B) 28 o‘quvchi, ba’zilari to‘garakda. Nechtasi qatnamaydi?','C) Lola 30 bet o‘qidi, Malika 2 marta ko‘p. Malika-chi?'],note:'Qaysi birini yechib bo‘lmaydi?'}],
 html:"<p>Uchta masaladan bittasini yechib bo'lmaydi. Qaysi biri?</p>",
 btns:bmPick(["A","B","C"],1,{t:'«ba’zilari» — son emas',lines:['A) 28 − 12 = 16 ✓','B) «ba’zilari» — nechta? Yechib bo‘lmaydi','C) 30 · 2 = 60 ✓'],hl:{0:'ok',1:'bad',2:'ok'}},["A ni yechsa bo‘ladi: 28 − 12 = 16.","","C ni yechsa bo‘ladi: 30 · 2 = 60."]),
 after:"<p>«Ba'zilari», «bir nechta», «ko'p» — bular <b>son emas</b>. Ular bilan aniq hisoblab bo'lmaydi.</p>",
 q:{t:"Qaysi masalani yechish mumkin?",opts:["Qutida bir nechta qalam bor, 5 tasi olindi. Nechta qoldi?","Ali 3 ta olma yedi, Vali undan ko'p yedi. Vali nechta yedi?","Sinfda 25 o'quvchi, 4 tasi kasal. Nechtasi darsda?","Ona bozordan meva oldi. Qancha to'ladi?"],ok:2,why:"25 − 4 = 21.",hint:"Qaysi masalada hamma son aniq?",full:"Faqat 3-masalada ikkala son aniq: 25 − 4 = 21. Qolganlarida «bir nechta», «ko'p», narx va miqdor — noma'lum."},
 tn:"Bank misoli (3116-id). Bolalar juftlikda «yechib bo'lmaydigan» masala tuzib, bir-biriga bersin."}),
bmStep({h:"Ma’lumotni o‘zingiz qo‘shing",sum:"«Ali 15 ming so'm bilan daftar oldi. Qancha qoldi?» — daftar narxi va soni kerak. 3 ta 2500 dan: 15 000 − 7500 = 7500.",a:"m05",
 frames:[{t:'Masalani o‘qing',lines:['Alida 15 000 so‘m bor edi.','U do‘kondan daftar oldi.','Savol: qancha puli qoldi?'],hl:{2:'q'},note:'Qaysi ma’lumotlar kerak?'}],
 html:"<p>Masalani to'ldirish uchun nima qo'shish kerak?</p>",
 btns:bmPick(["daftar narxi","daftar narxi va soni","do‘kon nomi"],1,{t:'To‘ldirilgan masala',lines:['Alida 15 000 so‘m bor edi.','U 2500 so‘mdan 3 ta daftar oldi.','2500 · 3 = 7500;  15 000 − 7500 = 7500'],hl:{1:'ok',2:'q'}},["Faqat narx yetarli emas — nechta oldi?","","Do‘kon nomi hisobga ta’sir qilmaydi."]),
 after:"<p>Qiymat = narx · miqdor — <b>ikkala</b> son ham kerak. Masala tuzuvchi sifatida o'ylash — eng yaxshi mashq.</p>",
 q:{t:"«Velosipedchi shahardan qishloqqa bordi. Necha soat yurdi?» Yechish uchun qaysi juftlik kerak?",opts:["masofa va tezlik","faqat tezlik","velosiped rangi va masofa","jo'nash vaqti"],ok:0,why:"t = S : v.",hint:"Vaqt formulasi qaysi?",full:"Vaqt = masofa : tezlik — ikkala son kerak. Faqat tezlik yetarli emas, rang esa ortiqcha."},
 tn:"«Masala do'koni» o'yini: o'qituvchi savol aytadi, bolalar kerakli ma'lumotni «sotib oladi»."}),
bmStep({h:"Tuzoq: javob shartning ichida",sum:"«Avtobusga 12 kishi chiqdi, 3 kishi tushdi, 15 kishi bo'ldi. Nechta kishi chiqdi?» — javob 12, hisob shart emas.",a:"m06",
 frames:[{t:'Masalani o‘qing',lines:['Bekatda avtobusga 12 kishi chiqdi.','3 kishi tushdi.','Avtobusda 15 kishi bo‘ldi.','Savol: bekatda nechta kishi chiqdi?'],hl:{3:'q'},note:'Javobni tanlang:'}],
 html:"<p>Savolni <b>diqqat bilan</b> o'qing. Hisoblash kerakmi?</p>",
 btns:bmPick(["15","9","12"],2,{t:'Javob shartda yozilgan',lines:['Bekatda avtobusga 12 kishi chiqdi.','3 kishi tushdi.','Avtobusda 15 kishi bo‘ldi.','Javob: 12 kishi'],hl:{0:'ok',1:'bad',2:'bad',3:'ok'}},["15 — avtobusdagi jami, savol esa chiqqanlar haqida.","9 = 12 − 3 — savol tushganlar haqida emas.",""]),
 after:"<p>Hisoblashdan oldin <b>savolni qayta o'qing</b>. Ba'zan javob allaqachon berilgan, boshqa sonlar esa — chalg'ituvchi.</p>",
 q:{t:"«Bog'da 18 ta olma va 7 ta nok daraxti bor. Har olmadan 20 kg hosil olindi. Bog'da nechta nok daraxti bor?»",opts:["7","25","360","11"],ok:0,why:"Shartda: 7 ta nok.",hint:"Savol nima haqida?",full:"Savol — nok daraxtlari soni, u shartda berilgan: 7. «25» — jami daraxtlar, «360» = 18 · 20 — olma hosili."},
 tn:"Bu tur xalqaro testlarda (TIMSS) «diqqat bilan o'qish»ni tekshiradi."}),
bmStep({h:"Tuzoq: keraksiz son ko‘paytirishga undaydi",sum:"«3 qutida 24 tadan qalam, har quti 500 g. Jami nechta qalam?» — og'irlik ortiqcha: 24 · 3 = 72.",a:"m07",
 frames:[{t:'Masalani o‘qing',lines:['Do‘konga 3 ta quti qalam keldi.','Har qutida 24 ta qalam.','Har bir quti 500 g keladi.','Savol: jami nechta qalam keldi?'],hl:{3:'q'},note:'Javobni tanlang:'}],
 html:"<p>Masalada uchta son. Hammasini ishlatish shart emas!</p>",
 btns:bmPick(["1500","72","36 000"],1,{t:'Og‘irlik — ortiqcha',lines:['Do‘konga 3 ta quti qalam keldi.','Har qutida 24 ta qalam.','Har bir quti 500 g keladi.','24 · 3 = 72 ta qalam'],hl:{0:'ok',1:'ok',2:'bad',3:'q'}},["1500 = 500 · 3 — bu qutilar og‘irligi (g), qalam soni emas.","","36 000 = 24 · 3 · 500 — hamma son ko‘paytirildi, ma’nosiz."]),
 after:"<p>Javob birligini tekshiring: savol «nechta qalam» — javob <b>dona</b>da bo'lishi kerak, grammda emas.</p>",
 q:{t:"«Mashina 2 soatda 160 km yurdi, benzin 16 l sarfladi. Mashina tezligi?»",opts:["80 km/soat","10 km/l","8 km/soat","320 km/soat"],ok:0,why:"160 : 2 = 80; benzin ortiqcha.",hint:"Tezlik = masofa : vaqt.",full:"v = 160 : 2 = 80 km/soat. Benzin bu savol uchun ortiqcha. «10» = 160 : 16 (bu 1 l ga yo'l, tezlik emas), «8» = 16 : 2."},
 tn:"Javob birligini doim so'rang: «Bu javob nimani bildiradi — dona, gramm, so'm?»"}),
bmStep({h:"Bilasizmi? «Kapitan necha yoshda?»",sum:"1980-yilda Fransiyada o'quvchilarga «kemada 26 qo'y va 10 echki bor, kapitan necha yoshda?» deb so'ralgan; ko'pchilik sonlarni qo'shib javob bergan.",a:"m08",
 frames:[{t:'Kemada 26 ta qo‘y va 10 ta echki bor. Kapitan necha yoshda?',lines:['Kemada 26 ta qo‘y bor.','Kemada 10 ta echki bor.','Savol: kapitan necha yoshda?'],hl:{2:'q'},note:'Sizning javobingiz?'}],
 html:"<p>🚢 1980-yilda Fransiyaning Grenobl shahridagi tadqiqotchilar boshlang'ich sinf o'quvchilariga shunday savol berishgan. Siz nima deysiz?</p>",
 btns:bmPick(["36 yosh","16 yosh","Bilib bo‘lmaydi"],2,{t:'Qo‘y va echkilar kapitan yoshi haqida hech narsa demaydi',lines:['Kemada 26 ta qo‘y bor.','Kemada 10 ta echki bor.','Kapitan yoshi — berilmagan!'],hl:{0:'bad',1:'bad',2:'ok'}},["36 = 26 + 10 — lekin qo‘ylar soni kapitan yoshi emas!","16 = 26 − 10 — sonlar kapitanga aloqasiz.",""]),
 after:"<p>O'shanda ko'pchilik o'quvchilar sonlarni qo'shib yoki ayirib «javob» bergan! Siz esa endi bilasiz: avval <b>o'ylash</b>, keyin hisoblash. Haqiqiy matematik ma'nosiz masalani taniydi.</p>",
 tn:"Shu savolni sinfga hech qanday izohsiz bering va natijani muhokama qiling — bu tajriba ko'p mamlakatlarda takrorlangan."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Masala bilan ishlash',lines:['1. Savolni o‘qing va tagiga chizing.','2. Kerakli formulani tanlang.','3. Ortiqcha sonni chizib tashlang.','4. Yetishmasa — ayting yoki qo‘shing.'],hl:{0:'q'}})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Avval <b>savolni</b> o'qing: nima so'ralyapti?</li><li>Savol uchun qaysi <b>formula</b> kerak (narx, harakat, ish)?</li><li><b>Ortiqcha</b> sonni chizib tashlang.</li><li><b>Yetishmasa</b> — «yechib bo'lmaydi» deng yoki ma'lumot qo'shing.</li><li>«Ba'zilari», «ko'p», «bir nechta» — <b>son emas</b>.</li><li>Javob shartda bo'lishi mumkin — savolni qayta o'qing.</li><li>Javob birligini tekshiring (dona, gramm, so'm).</li></ul></div>",
 tn:"Bu tartibni doskaning burchagiga doimiy yozib qo'ying — barcha matnli masalalar uchun."}
];
var PROBS=[
{t:"«Bog'da olma va nok bor. Olma 24 ta. Jami nechta daraxt?» Nima yetishmaydi?",o:["nok daraxtlari soni","daraxtlar yoshi","olma soni","bog' yuzi"],k:0,s:"Jami = olma + nok."},
{t:"«Do'kon dushanba 125 ta non, seshanba undan ko'p sotdi. Ikki kunda nechta?» Nima yetishmaydi?",o:["seshanba qanchaga ko'p sotgani","dushanba soni","non narxi","do'kon nomi"],k:0,s:"«Ko'p» — qanchaga?"},
{t:"«4 sigirdan kuniga 60 l sut, sigirlar 5 yoshda. 1 sigir necha litr?» Ortiqcha ma'lumot?",o:["sigirlar yoshi","sigirlar soni","sut miqdori","hech biri"],k:0,s:"60 : 4 = 15; yosh kerak emas."},
{t:"Avtobus 8:00 da 45 yo'lovchi bilan jo'nadi, soatiga 70 km, 3 soat yurdi. Necha km yurdi?",o:["210","73","135","315"],k:0,s:"70 · 3 = 210."},
{t:"Lola 9 yoshda, 3-qavatda yashaydi, kuniga 2 soat kitob o'qiydi. Haftada necha soat o'qiydi?",o:["14","27","63","18"],k:0,s:"2 · 7 = 14."},
{t:"Qaysi masalani yechib bo'lmaydi?",o:["28 o'quvchi, ba'zilari to'garakda. Nechtasi qatnamaydi?","28 o'quvchi, 12 tasi to'garakda. Nechtasi qatnamaydi?","Lola 30 bet, Malika 2 marta ko'p. Malika-chi?","5 daftar 2 mingdan. Qancha to'landi?"],k:0,s:"«Ba'zilari» — son emas."},
{t:"Qaysi masalani yechish mumkin?",o:["25 o'quvchi, 4 tasi kasal. Nechtasi darsda?","Qutida bir nechta qalam, 5 tasi olindi. Nechta qoldi?","Ali 3 olma yedi, Vali ko'proq. Vali nechta?","Ona meva oldi. Qancha to'ladi?"],k:0,s:"25 − 4 = 21."},
{t:"«Ali 15 000 so'm bilan daftar oldi. Qancha qoldi?» Nima kerak?",o:["daftar narxi va soni","faqat daftar narxi","do'kon nomi","faqat daftar soni"],k:0,s:"Qiymat = narx · miqdor."},
{t:"«Velosipedchi qishloqqa bordi. Necha soat yurdi?» Nima kerak?",o:["masofa va tezlik","faqat tezlik","faqat masofa","jo'nash vaqti"],k:0,s:"t = S : v."},
{t:"Avtobusga 12 kishi chiqdi, 3 kishi tushdi, 15 kishi bo'ldi. Bekatda nechta kishi chiqdi?",o:["12","15","9","3"],k:0,s:"Shartda yozilgan."},
{t:"Bog'da 18 olma va 7 nok daraxti, har olmadan 20 kg hosil. Nechta nok daraxti bor?",o:["7","25","360","11"],k:0,s:"Shartda: 7."},
{t:"3 qutida 24 tadan qalam, har quti 500 g. Jami nechta qalam?",o:["72","1500","36 000","27"],k:0,s:"24 · 3 = 72."},
{t:"Mashina 2 soatda 160 km yurdi, 16 l benzin sarfladi. Tezligi necha km/soat?",o:["80","10","8","320"],k:0,s:"160 : 2 = 80."},
{t:"Sinfda 14 qiz va 12 o'g'il, o'qituvchi 35 yoshda. O'quvchilar nechta?",o:["26","61","49","47"],k:0,s:"14 + 12 = 26."},
{t:"Usta 8 soat ishlab, soatiga 6 ta detal yasaydi, ustaxona 3-qavatda. Kunlik ish?",o:["48","24","18","14"],k:0,s:"6 · 8 = 48."},
{t:"«Kitob 12 000 so'm, ruchka arzonroq. Ikkalasi necha so'm?» Nima yetishmaydi?",o:["ruchka qanchaga arzonligi","kitob narxi","kitob betlari soni","do'kon manzili"],k:0,s:"Ruchka narxi noma'lum."},
{t:"Poyezd 4 soatda 320 km yurdi, unda 12 vagon bor. 1 soatda necha km yurdi?",o:["80","26","48","40"],k:0,s:"320 : 4 = 80; vagonlar ortiqcha."},
{t:"Ona 5 kg olma 8000 dan va 2 kg nok oldi. Olmaga necha so'm to'ladi?",o:["40 000","56 000","16 000","10 000"],k:0,s:"8000 · 5 = 40 000; nok ortiqcha."},
{t:"Ali 10 yoshda, ukasi undan 4 yosh kichik, otasi 38 yoshda. Ukasi necha yoshda?",o:["6","14","34","28"],k:0,s:"10 − 4 = 6; otasi yoshi ortiqcha."},
{t:"Hovuzga 3 nasos soatiga 200 l dan suv quyadi, hovuz 2 m chuqur. 4 soatda necha litr quyiladi?",o:["2400","800","1600","600"],k:0,s:"200 · 3 · 4 = 2400; chuqurlik ortiqcha."}
];
function PRACT_STAGE(){bmDraw({t:'Kerakli va ortiqcha ma’lumot',lines:['Savol nimani so‘rayapti?','Qaysi sonlar kerak?','Qaysi son ortiqcha?'],hl:{0:'q'}})}
var PREP_DATA={teach:["Yetishmaydigan ma'lumotni topish va qo'shish.","Ortiqcha ma'lumotni chizib tashlash.","Yechib bo'lmaydigan masalani tanish («ba'zilari», «ko'p»).","Javob shartda bo'lishi; javob birligini tekshirish."],
 mist:["Masaladagi hamma sonni ishlatishga harakat qiladi.","Yetishmasa ham «javob» o'ylab topadi.","«Ko'p» so'zini son deb hisoblaydi.","Savolni o'qimasdan hisoblaydi."],
 need:["Qog'ozga chiqarilgan masala matnlari, rangli qalamlar.","«Masala do'koni» kartochkalari (ma'lumot bo'laklari)."],
 board:["1) Savol → 2) Formula → 3) Ortiqchasini chizish → 4) Yetishmasa — ayting.","<span class='w2'>60 : 4 = 15</span> (yosh ortiqcha).","<span class='w2'>70 · 3 = 210</span> (8:00 va 45 ortiqcha).","«ba'zilari» — son emas."]};
