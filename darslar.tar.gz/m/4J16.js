var CODE='4J16',TITLE="4-sinf · Eng katta / eng kichik qiymat";
// to'g'ri to'rtburchaklar (katakda): list [[a,b]], hl — ajratilgan indeks
function q16Rects(list,hl,lab){clear();var g=S.g,u=11,x=12;list.forEach(function(r,i){var on=hl===i,w=r[0]*u,h=r[1]*u;E('rect',{x:x,y:150-h,width:w,height:h,fill:on?'#d9f2e5':'#eaf3fb',stroke:on?C.ok:'#5aa9e6','stroke-width':on?3:1.5},g);
  for(var k=1;k<r[0];k++)E('line',{x1:x+k*u,y1:150-h,x2:x+k*u,y2:150,stroke:'#cfe0ee'},g);for(var k=1;k<r[1];k++)E('line',{x1:x,y1:150-h+k*u,x2:x+w,y2:150-h+k*u,stroke:'#cfe0ee'},g);
  T(g,x+w/2,150-h-6,r[0]+'×'+r[1],{'font-size':11,'font-weight':800,fill:on?C.ok:'#1f5f9e'});if(lab)T(g,x+w/2,166,lab(r),{'font-size':10,'font-weight':800,fill:on?C.ok:'#5a6a7a'});x+=w+14});}
var P2=[function(){q16Rects([[24,1],[2,12]],null,function(r){return 'P='+2*(r[0]+r[1])});j2Msg("Yuzi 24 katak. To'g'ri to'rtburchaklar har xil: 1×24, 2×12, …")},
 function(){q16Rects([[2,12],[3,8],[4,6]],2,function(r){return 'P='+2*(r[0]+r[1])});j2Msg("Perimetrlar: 1×24 → 50, 2×12 → 28, 3×8 → 22, 4×6 → <b>20</b>. Kvadratga yaqin — perimetr eng kichik.")}];
var P3=[function(){j2Lines([["1  2  3  4",C.blue,26],["□□ · □□ = eng katta?",null,18]]);j2Msg("1, 2, 3, 4 kartochkalaridan ikkita ikki xonali son tuzib ko'paytiramiz. Eng katta ko'paytma?")},
 function(){j2Lines([["o'nliklarga — eng kattalar: 4 va 3",null,16],["4□ · 3□",C.blue,24]]);j2Msg("O'nliklar ko'paytmaga eng ko'p ta'sir qiladi → 4 va 3 o'nliklarga.")},
 function(){j2Lines([["42 · 31 = 1 302",null,18],["41 · 32 = 1 312 ✓",C.ok,22]]);j2Msg("Endi 1 va 2 ni qayerga? Kichik o'nlikka kattaroq birlik: <b>41 · 32 = 1 312</b>. Sonlar bir-biriga yaqin bo'lsa ko'paytma katta.")}];
var P4=[function(){j2Lines([["1 2 3 4 5 6",C.blue,24],["□□□ − □□□ = eng kichik?",null,17]]);j2Msg("1–6 raqamlaridan ikkita uch xonali son. Ayirma eng kichik bo'lsin (musbat).")},
 function(){j2Lines([["yuzliklar 1 ga farq qilsin: 4 va 3",null,16],["4□□ − 3□□",C.blue,24]]);j2Msg("Yuzliklar qo'shni raqamlar bo'lsin.")},
 function(){j2Lines([["kattasi — eng kichik qoldiq: 412",null,15],["kichigi — eng katta qoldiq: 365",null,15],["412 − 365 = 47",C.ok,24]]);j2Msg("Kattasini iloji boricha kichik (412), kichigini iloji boricha katta (365) qilamiz: <b>47</b>.")}];
var P5=[function(){j2Lines([["30 o'quvchi",C.blue,22],["⚽ 20 ta   ♟️ 15 ta",null,20]]);j2Msg("30 o'quvchidan 20 tasi futbolni, 15 tasi shaxmatni yaxshi ko'radi. Ikkalasini ham yaxshi ko'radiganlar kamida nechta? Ko'pi bilan-chi?")},
 function(){j2Lines([["kamida: 20 + 15 − 30 = 5",C.ok,20],["(35 ta «yoqtirish» 30 kishiga)",null,14]]);j2Msg("Eng kam umumiy: hamma kamida bitta narsani yoqtirsa, 20 + 15 = 35 — 30 dan 5 ta ortiq → kamida <b>5</b>.")},
 function(){j2Lines([["ko'pi bilan: 15",C.blue,22],["(shaxmatchilarning hammasi futbolchi)",null,14]]);j2Msg("Eng ko'p umumiy: shaxmatni yoqtirgan 15 kishining hammasi futbolni ham yoqtirsa — <b>15</b>.")}];
var STEPS=[
{h:"Perimetr bir xil — yuz eng katta",sum:"Perimetri 20 bo'lgan to'g'ri to'rtburchaklardan eng katta yuz — kvadrat 5×5 = 25.",a:"m01",
 start:function(){q16Rects([[1,9],[3,7],[4,6],[5,5]],null,function(r){return 'S='+r[0]*r[1]});j2Msg("Hammasining perimetri 20 sm. Qaysi birining yuzi eng katta? Tanlang.")},
 fin:function(){q16Rects([[1,9],[3,7],[4,6],[5,5]],3,function(r){return 'S='+r[0]*r[1]});j2Msg("5 × 5 = <b>25</b> — kvadrat. Tomonlar qancha yaqin bo'lsa, yuz shuncha katta.")},
 html:"<p>20 sm uzunlikdagi ip bilan to'g'ri to'rtburchak yasaymiz (tomonlari butun sm). Qaysi biri eng ko'p joyni o'raydi?</p>",
 btns:j2Pick(["1 × 9","3 × 7","4 × 6","5 × 5"],3,function(){q16Rects([[1,9],[3,7],[4,6],[5,5]],3,function(r){return 'S='+r[0]*r[1]});j2Msg("To'g'ri! 9, 21, 24, <b>25</b>.")},function(i){j2Msg("Yuzini hisoblang: "+["1 · 9 = 9","3 · 7 = 21","4 · 6 = 24"][i]+". Kattarog'i bor.")}),g2:1,
 after:"<p>Perimetr bir xil bo'lsa, <b>kvadratga eng yaqin</b> shakl eng katta yuzga ega. Yarim perimetrni teng ikkiga bo'lamiz: 10 = 5 + 5.</p>",
 q:{t:"Perimetri 18 sm, tomonlari butun sm. Eng katta yuz?",opts:["81 sm²","20 sm²","21 sm²","18 sm²"],ok:1,why:"9 = 4 + 5 → 4 × 5 = 20 (kvadrat 4,5 × 4,5 bo'lmaydi).",hint:"Yarim perimetr 9. Uni ikki butun songa iloji boricha teng bo'ling.",full:"Yarim perimetr 9: 1+8 → 8, 2+7 → 14, 3+6 → 18, 4+5 → 20. Butun tomonli kvadrat bo'lmaydi (4,5). Eng kattasi 20 sm². 81 — 9 · 9, perimetrni tomon deb olgan xato."},
 tn:"Ip (yoki 20 ta gugurt cho'pi) bilan to'g'ri to'rtburchaklar yasab, kataklarini sanatib ko'ring."},
{h:"Yuz bir xil — perimetr eng kichik",sum:"Yuzi 24: 1×24 (P=50) … 4×6 (P=20) — kvadratga yaqini eng qisqa.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>Teskari masala: 24 ta katakli maydonni eng qisqa to'siq bilan o'rash kerak.</p>",
 btns:[phaser(P2)],
 after:"<p>Yana kvadratga yaqin shakl yutadi. Cho'zinchoq shakl — to'siqqa ko'p sarf. Eng katta perimetr esa eng cho'zinchog'ida: 1 × 24 → 50.</p>",
 q:{t:"Yuzi 36 sm² (tomonlari butun). Eng kichik perimetr?",opts:["26 sm","24 sm","30 sm","74 sm"],ok:1,why:"6 × 6 → 24 sm.",hint:"Ko'paytmasi 36 bo'lgan, bir-biriga eng yaqin ikki son?",full:"36 = 6 · 6 → perimetr 4 · 6 = 24. 4 × 9 → 26, 3 × 12 → 30, 1 × 36 → 74."},
 tn:"Bolalar 24 ta kvadrat kartochkadan har xil to'g'ri to'rtburchaklar yig'ib, perimetrini sanasin."},
{h:"Kartochkalardan eng katta ko'paytma",sum:"1,2,3,4: o'nliklarga 4 va 3; sonlar yaqin bo'lsin: 41 · 32 = 1 312.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ikki qadamli fikr: avval qaysi raqam qayerga muhimroq, keyin sonlarni bir-biriga yaqinlashtirish.</p>",
 btns:[phaser(P3)],
 after:"<p>Xuddi perimetrdagi kabi: yig'indi bir xil bo'lsa, ko'paytma sonlar <b>yaqin</b> bo'lganda katta (41 + 32 = 42 + 31 = 73, lekin 41 · 32 katta).</p>",
 q:{t:"2, 3, 5, 7 kartochkalaridan ikki xonali × ikki xonali. Eng katta ko'paytma qaysi?",opts:["73 · 52","72 · 53","75 · 32","57 · 32"],ok:1,why:"72 · 53 = 3 816 > 73 · 52 = 3 796.",hint:"O'nliklarga 7 va 5. Kichik o'nlikka (5) kattaroq birlik (3) bering.",full:"O'nliklarga 7 va 5. Birliklar 3 va 2: 72 · 53 = 3 816, 73 · 52 = 3 796. Sonlar yaqinroq (72 va 53) — ko'paytma katta. Javob: 72 · 53."},
 tn:"Juftlikda kartochkalar bilan o'ynating: kim katta ko'paytma tuzsa, yutadi. Keyin qoidani birga chiqaring."},
{h:"Eng kichik ayirma",sum:"1–6 dan uch xonali sonlar: 412 − 365 = 47.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Olimpiada masalasi: 1, 2, 3, 4, 5, 6 raqamlarining har biri bir marta ishlatilib, ikkita uch xonali son tuzildi. Ayirma eng kami bilan nechaga teng?</p>",
 btns:[phaser(P4)],
 after:"<p>Tekshiring: 3□□/2□□ → 314 − 265 = 49, 5□□/4□□ → 512 − 463 = 49, 2/1 → 234 − 165 = 69. Eng kami 47. Ko'p holatni tekshirish — bu ham usul!</p>",
 q:{t:"0, 1, 2, 3 raqamlaridan (har biri bir marta) ikkita ikki xonali son. Eng kichik ayirma?",opts:["9","7","10","3"],ok:1,why:"20 − 13 = 7.",hint:"O'nliklar qo'shni bo'lsin; kattasi eng kichik birlik bilan, kichigi eng katta birlik bilan.",full:"O'nliklar 2 va 1: kattasi 20 (0 eng kichik), kichigi 13 (3 eng katta) → 7. O'nliklar 3 va 2: 30 − 21 = 9. O'nliklar 3 va 1 farqi katta. Javob: 7."},
 tn:"Kartochkalarni sinfga tarqating — kim kichikroq ayirma topadi."},
{h:"Kamida va ko'pi bilan nechta?",sum:"30 o'quvchi, 20 futbol, 15 shaxmat: ikkalasi kamida 5, ko'pi bilan 15.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Ikki guruh bir-birini qoplaydi. Umumiy qism qancha bo'lishi mumkin?</p>",
 btns:[phaser(P5)],
 after:"<p>Kamida: <b>yig'indi − hammasi</b> (manfiy chiqsa — 0). Ko'pi bilan: <b>kichik guruh</b> to'liq.</p>",
 q:{t:"25 o'quvchidan 18 tasi suzishni, 14 tasi rasm chizishni yaxshi ko'radi. Ikkalasini ham yaxshi ko'radiganlar kamida nechta?",opts:["14","7","32","4"],ok:1,why:"18 + 14 − 25 = 7.",hint:"18 + 14 qancha? 25 dan nechtaga ortiq?",full:"18 + 14 = 32 ta «yoqtirish», o'quvchilar 25. 32 − 25 = 7 kishi ikki marta sanalgan → kamida 7. 14 — bu ko'pi bilan."},
 tn:"Ikki halqali (Venn) diagramma chizib, halqalarni siljitib ko'rsating: eng kam va eng ko'p kesishuv."},
{h:"Tuzoq: eng kattasi ko'pi bilan nechta?",sum:"5 ta har xil natural son, yig'indisi 25: qolgan to'rttasi eng kichik (1+2+3+4 = 10) → eng kattasi 15.",a:"m06",
 start:function(){j2Lines([["□ + □ + □ + □ + □ = 25",C.blue,20],["hammasi har xil",null,16]]);j2Msg("5 ta har xil natural son yig'indisi 25. Eng kattasi <b>ko'pi bilan</b> nechta?")},
 fin:function(){j2Lines([["1 + 2 + 3 + 4 + 15 = 25",C.ok,20],["eng kattasi ko'pi bilan 15",null,16]]);j2Msg("Bittasi katta bo'lishi uchun qolganlar <b>eng kichik</b> bo'lsin: 1, 2, 3, 4.")},
 html:"<p>5 ta <b>har xil</b> natural sonning yig'indisi 25. Eng kattasi ko'pi bilan nechaga teng bo'lishi mumkin?</p>",
 btns:j2Pick(["21","15","5"],1,function(){j2Lines([["1 + 2 + 3 + 4 + 15 = 25",C.ok,20],["eng kattasi ko'pi bilan 15",null,16]]);j2Msg("To'g'ri! 1 + 2 + 3 + 4 = 10, 25 − 10 = 15.")},function(i){j2Msg(i===0?"21 = 25 − 4 — lekin qolgan to'rtta son har xil bo'lishi kerak (1+1+1+1 bo'lmaydi).":"5 — o'rtacha qiymat, eng katta emas.")}),
 after:"<p>Bitta son <b>eng katta</b> bo'lishi uchun qolganlar <b>eng kichik</b> bo'lishi kerak — va aksincha. «Har xil» sharti bu yerda asosiy tuzoq.</p>",
 q:{t:"4 ta har xil natural son yig'indisi 20. Eng kattasi ko'pi bilan nechta?",opts:["17","14","5","11"],ok:1,why:"1 + 2 + 3 = 6, 20 − 6 = 14.",hint:"Qolgan uchtasi eng kichik har xil sonlar bo'lsin.",full:"Qolgan uchtasi: 1, 2, 3 → 6. 20 − 6 = 14. «17» — 1 + 1 + 1 deb olingan, lekin sonlar har xil bo'lishi kerak."},
 tn:"Bolalarga 25 ta cho'p berib, 5 ta har xil uyumga bo'lishni ayting — eng katta uyum qancha bo'la oladi?"},
{h:"Bilasizmi? Didona masalasi",sum:"Afsona: Didona ho'kiz terisidan kesilgan tasma bilan eng katta yerni yarim doira shaklida o'ragan.",a:"m07",
 start:function(){j2Lines([["⭕ bir xil uzunlik → eng katta yuz",C.blue,17],["doira!",C.ok,26]]);j2Msg("Didona afsonasi")},fin:function(){j2Lines([["⭕ bir xil uzunlik → eng katta yuz",C.blue,17],["doira!",C.ok,26]]);j2Msg("Didona afsonasi")},
 html:"<p>📜 Qadimiy afsonaga ko'ra, malika <b>Didona</b>ga «bitta ho'kiz terisi qoplaydigan yer» berilgan. U terini ingichka tasmaga kesib, dengiz bo'yida <b>yarim doira</b> shaklida eng katta yerni o'ragan — Karfagen shahri shunday paydo bo'lgan emish.</p><p>Matematiklar isbotlagan: uzunligi bir xil chegara bilan eng katta maydonni <b>doira</b> o'raydi. To'rtburchaklar orasida esa — kvadrat.</p>",
 btns:[["⭕ Qiziq!",function(c,done){done()}]],
 tn:"Bir xil ip bilan doira, kvadrat va uchburchak yasab, katakli qog'ozda yuzlarini taqqoslang."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["yaqin sonlar → katta ko'paytma",C.blue,18]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["yaqin sonlar → katta ko'paytma",C.blue,18]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Perimetr bir xil → <b>kvadratga yaqin</b> shakl eng katta yuz.</li><li>Yuz bir xil → kvadratga yaqin eng kichik perimetr, cho'zinchoq — eng katta.</li><li>Yig'indi bir xil → sonlar <b>yaqin</b> bo'lsa ko'paytma katta.</li><li>Raqamlardan son: avval katta xonalar, keyin «yaqinlashtirish».</li><li>Umumiy qism: kamida yig'indi − hammasi, ko'pi bilan kichik guruh.</li><li>Biri eng katta → qolganlari eng kichik (har xil shartini unutmang!).</li></ul></div>",
 tn:"Uyga: «Perimetri 30 sm bo'lgan qaysi to'g'ri to'rtburchakning yuzi eng katta?»"}
];
var PROBS=[
{t:"Perimetri 20 sm (tomonlar butun). Eng katta yuz?",o:["25 sm²","24 sm²","21 sm²","20 sm²"],k:0,s:"5 × 5 = 25."},
{t:"Perimetri 24 sm (tomonlar butun). Eng katta yuz?",o:["36 sm²","35 sm²","32 sm²","24 sm²"],k:0,s:"6 × 6 = 36."},
{t:"Perimetri 18 sm (tomonlar butun). Eng katta yuz?",o:["20 sm²","18 sm²","14 sm²","21 sm²"],k:0,s:"4 × 5 = 20."},
{t:"Yuzi 36 sm² (tomonlar butun). Eng kichik perimetr?",o:["24 sm","26 sm","30 sm","74 sm"],k:0,s:"6 × 6 → 24."},
{t:"Yuzi 24 sm² (tomonlar butun). Eng kichik perimetr?",o:["20 sm","22 sm","28 sm","50 sm"],k:0,s:"4 × 6 → 20."},
{t:"Yuzi 24 sm² (tomonlar butun). Eng katta perimetr?",o:["50 sm","28 sm","20 sm","48 sm"],k:0,s:"1 × 24 → 50."},
{t:"1, 2, 3, 4 kartochkalaridan ikki xonali × ikki xonali. Eng katta ko'paytma?",o:["41 · 32","42 · 31","43 · 21","34 · 21"],k:0,s:"41 · 32 = 1 312 > 42 · 31 = 1 302."},
{t:"2, 3, 5, 7 kartochkalaridan ikki xonali × ikki xonali. Eng katta ko'paytma?",o:["72 · 53","73 · 52","75 · 32","57 · 32"],k:0,s:"72 · 53 = 3 816."},
{t:"1, 2, 3, 4 kartochkalaridan ikki xonali + ikki xonali. Eng katta yig'indi?",o:["73","74","77","64"],k:0,s:"42 + 31 = 73."},
{t:"0, 1, 2, 3 raqamlaridan ikkita ikki xonali son. Eng kichik ayirma?",o:["7","9","10","3"],k:0,s:"20 − 13 = 7."},
{t:"1–6 raqamlaridan ikkita uch xonali son. Eng kichik ayirma?",o:["47","49","69","1"],k:0,s:"412 − 365 = 47."},
{t:"25 o'quvchidan 18 tasi suzishni, 14 tasi rasmni yaxshi ko'radi. Ikkalasini kamida nechtasi?",o:["7","14","32","4"],k:0,s:"18 + 14 − 25 = 7."},
{t:"Shu masalada ikkalasini ko'pi bilan nechtasi yaxshi ko'radi?",o:["14","18","7","25"],k:0,s:"Kichik guruh — 14."},
{t:"4 ta har xil natural son yig'indisi 20. Eng kattasi ko'pi bilan?",o:["14","17","5","11"],k:0,s:"20 − (1 + 2 + 3) = 14."},
{t:"5 ta har xil natural son yig'indisi 25. Eng kichigi ko'pi bilan nechta?",o:["3","5","1","4"],k:0,s:"3 + 4 + 5 + 6 + 7 = 25; 4 dan boshlasak 4+5+6+7+8 = 30."},
{t:"Uchta ketma-ket natural son yig'indisi 48. Eng kattasi?",o:["17","16","18","15"],k:0,s:"15 + 16 + 17 = 48."},
{t:"2 kg, 3 kg, 5 kg li qoplar ko'p. 20 kg ni eng kam qop bilan qanday olamiz?",o:["4 qop","5 qop","3 qop","7 qop"],k:0,s:"5 · 4 = 20; 3 qop ko'pi bilan 15 kg."},
{t:"37 m sim 5 m va 3 m bo'laklarga qoldiqsiz kesildi. 5 m li bo'laklar ko'pi bilan nechta?",o:["5","7","6","4"],k:0,s:"5 · 5 + 3 · 4 = 37; 6 · 5 = 30, 7 qoladi — 3 ga bo'linmaydi."},
{t:"7 ming va 4 ming so'mlik daftarlarga 50 ming so'm qaytimsiz sarflandi. 7 minglik ko'pi bilan nechta?",o:["6","2","7","4"],k:0,s:"7 · 6 + 4 · 2 = 50; 7 · 7 = 49, 1 qoladi."},
{t:"Perimetri 30 sm (tomonlar butun). Eng katta yuz?",o:["56 sm²","54 sm²","50 sm²","225 sm²"],k:0,s:"Yarim perimetr 15 = 7 + 8 → 56."}
];
function PRACT_STAGE(){q16Rects([[3,7],[4,6],[5,5]],2,function(r){return 'S='+r[0]*r[1]})}
var PREP_DATA={teach:["Perimetr va yuz: kvadratga yaqin shakl.","Raqam kartochkalaridan eng katta ko'paytma, eng kichik ayirma.","Umumiy qism: kamida va ko'pi bilan.","«Biri eng katta — qolganlari eng kichik»."],
 mist:["Perimetr bir xil bo'lsa yuz ham bir xil deb o'ylaydi.","Ko'paytmada kattani kattaga beradi (42 · 31).","«Har xil» shartini unutadi.","Kamida va ko'pi bilan javoblarni almashtiradi."],
 need:["Ip yoki 20 ta cho'p, katakli qog'oz.","0–9 raqam kartochkalari."],
 board:["<span class='w2'>P = 20: 5 × 5 = 25</span>.","<span class='w2'>S = 24: 4 × 6 → P = 20</span>.","<span class='w2'>41 · 32 = 1 312</span>.","<span class='w2'>412 − 365 = 47</span>.","<span class='w2'>20 + 15 − 30 = 5</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
