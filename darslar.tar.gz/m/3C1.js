var CODE='3C1',TITLE='3-sinf · Ko‘paytirish jadvali';
function w3c1c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
var P1=[function(){w3Arr(4,6,{lab:'4 qator, har birida 6 ta'});bqMsg('Nechta nuqta bor? Birma-bir sanash shart emas')},function(){w3Arr(4,6,{lab:'6 + 6 + 6 + 6 = 24'});bqMsg('Qatorlarni qo‘shamiz: 4 marta 6')},function(){w3Arr(4,6,{lab:'4 · 6 = 24'});bqMsg('Teng qo‘shiluvchilar yig‘indisi — <b>ko‘paytirish</b>')}];
var P2=[function(){w3Arr(3,7,{lab:'3 · 7 = 21'});bqMsg('3 qator, har birida 7 ta')},function(){w3Arr(7,3,{lab:'7 · 3 = 21'});bqMsg('Massivni burdik: 7 qator, har birida 3 ta — o‘sha 21 ta nuqta')},function(){w3Tab([[3,7],[7,3]],null,{diag:1});bqMsg('Jadvalda 21 ikki joyda turadi. Diagonalga nisbatan simmetrik!')}];
var P3=[function(){w3Arr(7,8,{lab:'7 · 8 = ?'});bqMsg('7 · 8 ni unutdingizmi? Bo‘laklarga ajratamiz')},function(){w3Arr(7,8,{split:5,lab:'7 · 5 = 35   va   7 · 3 = 21'});bqMsg('8 = 5 + 3: chap qism 7 · 5, o‘ng qism 7 · 3')},function(){w3Arr(7,8,{split:5,lab:'35 + 21 = 56'});bqMsg('7 · 8 = 7 · 5 + 7 · 3 = <b>56</b>')}];
var STEPS=[
{h:"Ko'paytirish nima?",sum:"4 · 6 = 6 + 6 + 6 + 6 = 24: teng qo'shiluvchilar yig'indisi. 4 — nechta guruh, 6 — har guruhda nechta.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Nuqtalar qatorlarga tizilgan. Ularni tez sanash usulini kuzating:</p>",btns:[phaser(P1)],
 after:"<p><b>4 · 6</b> — «4 marta 6». Birinchi son — nechta guruh, ikkinchisi — har guruhda nechta. Natija — <b>ko'paytma</b>, sonlar esa <b>ko'paytuvchilar</b>.</p>",
 q:{t:"7 + 7 + 7 + 7 + 7 ni ko'paytma ko'rinishida yozing.",opts:["5 · 7 = 35","7 · 7 = 49","7 + 5 = 12","5 · 5 = 25"],ok:0,why:"7 besh marta qo'shilgan: 5 · 7 = 35.",hint:"Qaysi son qo'shilmoqda va necha marta?",full:"7 soni 5 marta takrorlangan: 5 · 7 = 35. «7 · 7» — qo'shiluvchilar soni noto'g'ri sanalgan; «7 + 5» — ko'paytirish o'rniga qo'shish."},
 tn:"CPA (Singapur): avval tugmachalar/cho'plarni qatorlarga tizish, keyin rasm, keyin yozuv."},
{h:"O'rin almashtirish — jadvalning yarmi",sum:"3 · 7 = 7 · 3. Shuning uchun jadvaldagi 81 ta ko'paytmaning deyarli yarmini yodlash kifoya.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>3 · 7 va 7 · 3 — bir xilmi? Massivni burib ko'ring:</p>",btns:[phaser(P2)],
 after:"<p><b>a · b = b · a</b>. Jadval qizil diagonalga nisbatan simmetrik: diagonal ustidagi va ostidagi sonlar bir xil. Demak, 7 · 3 ni bilsangiz, 3 · 7 ni ham bilasiz — <b>yodlash yarmiga qisqaradi</b>.</p>",
 q:{t:"8 · 6 = 48 ekanini bilasiz. Qaysi ko'paytma ham 48?",opts:["6 · 8","8 · 8","6 · 6","4 · 8"],ok:0,why:"O'rin almashtirish: 6 · 8 = 8 · 6 = 48.",hint:"Ko'paytuvchilar o'rnini almashtiring.",full:"6 · 8 = 48. 8 · 8 = 64, 6 · 6 = 36, 4 · 8 = 32."},
 tn:"Doskadagi bo'sh jadvalni sinf birga to'ldirsin: har bola bitta katakni to'ldirsa, uning «juftini» boshqasi topsin."},
{h:"Unutganni tiklash: bo'lib ko'paytirish",sum:"7 · 8 = 7 · 5 + 7 · 3 = 35 + 21 = 56. Kattaroq ko'paytuvchini qulay bo'laklarga ajratamiz.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Eng qiyin ko'paytmalar — 6, 7, 8 bilan. Ularni bilgan ko'paytmalardan tiklash mumkin:</p>",btns:[phaser(P3)],
 after:"<p><b>7 · 8 = 7 · 5 + 7 · 3</b>. 5 ga ko'paytirish oson, qolganini qo'shamiz. Bu — <b>taqsimot xossasi</b>, keyingi darslarda ikki xonali sonlarni ko'paytirishning kaliti bo'ladi.</p>",
 q:{t:"6 · 9 ni qaysi yo'l bilan to'g'ri tiklash mumkin?",opts:["6 · 5 + 6 · 4 = 30 + 24","6 · 5 + 6 · 4 = 30 + 20","6 · 5 + 9 = 39","6 + 5 · 4 = 26"],ok:0,why:"9 = 5 + 4: 30 + 24 = 54.",hint:"9 ni 5 va 4 ga ajrating. Har bo'lakni 6 ga ko'paytiring.",full:"6 · 9 = 6 · 5 + 6 · 4 = 30 + 24 = 54. «30 + 20» — 6 · 4 ni 20 deb olingan; «30 + 9» — ikkinchi bo'lak 6 ga ko'paytirilmagan."},
 tn:"Katakli qog'ozda to'rtburchak chizib, uni qaychi bilan ikki bo'lakka kesish — taqsimot xossasini qo'l bilan his qilish."},
{h:"Ikkilantirish zanjiri",sum:"·2 → ·4 → ·8: har safar ikki baravar. 7 · 8 = 7 · 2 · 2 · 2 = 14 → 28 → 56.",a:"m04",start:function(){bqExpr(['7 · 2 = 14','7 · 4 = ?','7 · 8 = ?']);bqMsg('7 · 4 ni toping: 7 · 2 ni ikkilantiring')},fin:function(){bqExpr(['7 · 2 = 14','7 · 4 = 28','7 · 8 = [56]']);bqMsg('14 → 28 → 56: har gal ikki baravar')},
 html:"<p>7 · 2 = 14. Ikkilantirib <b>7 · 4</b> ni toping:</p>",g3:1,
 btns:[["16",function(c,d,b){w3c1c(b,d,0,'','14 + 2 emas — 14 ni ikki baravar oshiring: 14 + 14')}],["28",function(c,d,b){bqExpr(['7 · 2 = 14','7 · 4 = 28','7 · 8 = [56]']);w3c1c(b,d,1,'14 + 14 = 28. Yana ikkilantirsak: 7 · 8 = 56','')}],["21",function(c,d,b){w3c1c(b,d,0,'','21 — bu 7 · 3. Bizga 7 · 4 kerak')}]],
 after:"<p>4 = 2 · 2, 8 = 2 · 2 · 2. Shuning uchun <b>4 ga ko'paytirish — ikki marta ikkilantirish</b>, 8 ga — uch marta. Xuddi shunday: 6 · 8 = 3 · 8 ni ikkilantirish = 24 + 24 = 48.</p>",
 q:{t:"8 · 6 = 48. Unda 8 · 12 = ?",opts:["96","56","60","88"],ok:0,why:"12 = 6 · 2: 48 ni ikkilantiramiz — 96.",hint:"12 — 6 ning ikki baravari.",full:"8 · 12 = 8 · 6 · 2 = 48 · 2 = 96. «56» — 48 ga 8 qo'shilgan; «60» — 48 ga 12 qo'shilgan."},
 tn:"«Ikkilantirish zinapoyasi»: 3, 6, 12, 24, 48 — bolalar zanjirni og'zaki davom ettirsin."},
{h:"9 ga ko'paytirish sirlari",sum:"9 · 7 = 10 · 7 − 7 = 63. 9 ga karrali sonlarda raqamlar yig'indisi 9: 6 + 3 = 9.",a:"m05",start:function(){bqExpr(['9 · 1 = 9','9 · 2 = 18','9 · 3 = 27','9 · 4 = 36 …']);bqMsg('Naqshni ko‘ryapsizmi?')},fin:function(){bqExpr(['9 · 7 = 10 · 7 − 7','= 70 − 7 = [63]','6 + 3 = 9 ✓']);bqMsg('O‘nliklar 1 tadan ortadi, birliklar 1 tadan kamayadi')},
 html:"<p>9 ga karrali sonlarda o'nliklar 1 ga ortib, birliklar 1 ga kamayadi. Raqamlar yig'indisi doim 9. <b>9 · 7</b> = ?</p>",g3:1,
 btns:[["63",function(c,d,b){bqExpr(['9 · 7 = 10 · 7 − 7','= 70 − 7 = [63]','6 + 3 = 9 ✓']);w3c1c(b,d,1,'70 − 7 = 63, tekshiruv: 6 + 3 = 9','')}],["67",function(c,d,b){w3c1c(b,d,0,'','6 + 7 = 13 — 9 emas. 70 dan 7 ni ayiring')}],["56",function(c,d,b){w3c1c(b,d,0,'','56 — bu 7 · 8. 9 · 7 ga raqamlar yig‘indisi 9 bo‘lishi kerak')}]],
 after:"<p>Ikki usul: <b>9 · n = 10 · n − n</b> (9 · 7 = 70 − 7) va <b>raqamlar yig'indisi tekshiruvi</b>. Barmoq usuli ham bor: 10 ta barmoqdan 7-sini bukasiz — chapda 6, o'ngda 3 barmoq: 63.</p>",
 q:{t:"Qaysi son 9 ga karrali EMAS (raqamlar yig'indisiga qarang)?",opts:["74","72","45","27"],ok:0,why:"7 + 4 = 11 ≠ 9. 72 = 9 · 8, 45 = 9 · 5, 27 = 9 · 3.",hint:"9 ga karrali sonda raqamlar yig'indisi 9.",full:"72: 7 + 2 = 9 ✓; 45: 4 + 5 = 9 ✓; 27: 2 + 7 = 9 ✓; 74: 7 + 4 = 11 — 9 ga karrali emas."},
 tn:"Barmoq usulini sinfda birga bajaring — bolalar juda yaxshi eslab qoladi."},
{h:"Kvadratlar va qo'shnilar",sum:"Diagonalda: 1, 4, 9, 16, 25, 36, 49, 64, 81. Qo'shnisini topish: 7 · 8 = 7 · 7 + 7 = 56.",a:"m06",start:function(){w3Tab([[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7],[8,8],[9,9]],null);bqMsg('Diagonaldagi sonlar — o‘ziga o‘zini ko‘paytirish')},fin:function(){w3Tab([[7,7],[7,8]],null);bqMsg('7 · 8 = 49 + 7 = 56')},
 html:"<p>Diagonaldagi sonlar — <b>kvadratlar</b>: 7 · 7 = 49. 49 dan foydalanib <b>7 · 8</b> ni toping:</p>",g3:1,
 btns:[["49 + 7 = 56",function(c,d,b){w3Tab([[7,7],[7,8]],null);w3c1c(b,d,1,'7 · 8 — bu 7 · 7 va yana bitta 7','')}],["49 + 8 = 57",function(c,d,b){w3c1c(b,d,0,'','7 · 8 = 8 marta 7. 7 · 7 dan keyin yana bitta 7 qo‘shiladi, 8 emas')}],["49 + 1 = 50",function(c,d,b){w3c1c(b,d,0,'','Ko‘paytuvchi 1 ga oshdi, lekin ko‘paytma 1 ga emas, 7 ga oshadi')}]],
 after:"<p>Ko'paytuvchi 1 ga oshsa, ko'paytma <b>ikkinchi ko'paytuvchi qadar</b> oshadi: 7 · 8 = 7 · 7 + 7. Kvadratlarni yaxshi bilish — qo'shni ko'paytmalarni topish yo'li.</p>",
 q:{t:"6 · 6 = 36. Unda 6 · 7 = ?",opts:["42","37","43","48"],ok:0,why:"36 + 6 = 42.",hint:"Yana bitta 6 qo'shiladi.",full:"6 · 7 = 6 · 6 + 6 = 42. «37» — 1 qo'shilgan; «48» — bu 6 · 8."},
 tn:"Diagonalni rangli qalam bilan bo'yash, kvadratlarni kvadrat shaklda nuqtalar bilan chizish."},
{h:"Tuzoq: bitta ko'paytma — bir nechta yo'l",sum:"36 = 4 · 9 = 9 · 4 = 6 · 6: jadvalda 3 marta. 0 · 7 = 0, 1 · 7 = 7.",a:"m07",start:function(){w3Tab([],null);bqMsg('36 soni jadvalda necha marta uchraydi?')},fin:function(){w3Tab([[4,9],[9,4],[6,6]],null);bqMsg('4 · 9, 9 · 4, 6 · 6 — uch marta')},
 html:"<p>Jadvalga qarab sanang: <b>36</b> soni necha marta uchraydi?</p>",g3:1,
 btns:[["2 marta",function(c,d,b){w3c1c(b,d,0,'','4 · 9 va 9 · 4 — to‘g‘ri. Diagonalni ham tekshiring!')}],["3 marta",function(c,d,b){w3Tab([[4,9],[9,4],[6,6]],null);w3c1c(b,d,1,'4 · 9, 9 · 4 va 6 · 6','')}],["1 marta",function(c,d,b){w3c1c(b,d,0,'','6 · 6 = 36 — bu bittasi. 4 · 9 = ?')}]],
 after:"<p>Bir son turli ko'paytmalar bo'lishi mumkin: 36 = 4 · 9 = 6 · 6; 24 = 3 · 8 = 4 · 6. Bu bo'lishda juda kerak bo'ladi. Unutmang: <b>a · 0 = 0</b> (hech narsaning 7 marta takrori — hech narsa) va <b>a · 1 = a</b>.</p>",
 q:{t:"Qaysi ko'paytma boshqalaridan farq qiladi?",opts:["5 · 5","3 · 8","4 · 6","2 · 12"],ok:0,why:"5 · 5 = 25, qolganlari 24.",hint:"Har birini hisoblang.",full:"3 · 8 = 24, 4 · 6 = 24, 2 · 12 = 24, 5 · 5 = 25."},
 tn:"«Ko'paytma oilalari» o'yini: 12, 18, 24, 36 — har biri uchun barcha juftlarni topish."},
{h:"Bilasizmi? Eng qadimgi jadval",sum:"Ma'lum eng qadimgi o'nli ko'paytirish jadvali — Xitoyda topilgan bambuk yozuvlar (taxminan 2300 yil oldin).",a:"m08",start:function(){w3Tab([],null);bqMsg('Bu jadvalning yoshi qancha?')},fin:function(){w3Tab([],null,{diag:1});bqMsg('2300 yildan ortiq tarix')},
 html:"<p>🎓 Xitoyda topilgan, taxminan <b>miloddan avvalgi 305-yil</b>ga oid bambuk tayoqchalarda o'nli ko'paytirish jadvali yozilgan. Olimlar uni bugungacha ma'lum bo'lgan <b>eng qadimgi o'nli ko'paytirish jadvali</b> deb hisoblaydi. Bizda bu jadval ko'pincha <b>Pifagor jadvali</b> deb ham ataladi.</p>",
 btns:[["💡 Jadvalda nechta katak?",function(c,done){w3Tab([],null,{diag:1});bqMsg('9 · 9 = 81 ta katak, lekin diagonal va uning bir tomoni — 45 ta yetarli!');done()}]],
 after:"<p>81 ta katakdan o'rin almashtirish tufayli faqat <b>45 tasi</b> turli: diagonaldagi 9 ta va uning bir tomonidagi 36 ta. ·1 va ·10 ni hisobga olmasak, haqiqatan yodlash kerak bo'lganlari yanada kam.</p>",
 tn:"Bolalar o'z jadvalini yasasin: faqat diagonal va bir tomonni to'ldirib, «yarim jadval»ni devorga ilish."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w3Tab([],null,{diag:1});bqMsg('Ko‘paytirish jadvali')},fin:function(){w3Tab([],null,{diag:1});bqMsg('Ko‘paytirish jadvali')},
 html:"<div class='memo'><ul><li><b>a · b</b> — a marta b (teng qo'shiluvchilar).</li><li><b>a · b = b · a</b> — jadvalning yarmini bilish yetarli.</li><li>Unutsangiz: <b>7 · 8 = 7 · 5 + 7 · 3</b>.</li><li>·4 — ikki marta ikkilantirish, ·8 — uch marta.</li><li><b>9 · n = 10 · n − n</b>; raqamlar yig'indisi 9.</li><li>7 · 8 = 7 · 7 + 7. a · 0 = 0, a · 1 = a.</li></ul></div>",
 tn:"Har dars boshida 2 daqiqa «jadval chaqmog'i» — 10 ta tez savol."}
];
var PROBS=[
{t:"6 · 7 = ?",o:["42","48","36","49"],k:0,s:"6 · 7 = 42."},
{t:"8 · 7 = ?",o:["56","54","64","49"],k:0,s:"8 · 7 = 56."},
{t:"9 · 6 = ?",o:["54","56","63","45"],k:0,s:"60 − 6 = 54."},
{t:"8 · 8 = ?",o:["64","56","72","48"],k:0,s:"8 · 8 = 64."},
{t:"7 · 9 = ?",o:["63","56","72","67"],k:0,s:"70 − 7 = 63."},
{t:"6 + 6 + 6 + 6 + 6 + 6 + 6 + 6 = ?",o:["48","42","54","14"],k:0,s:"8 · 6 = 48."},
{t:"□ · 7 = 49. □ = ?",o:["7","6","8","42"],k:0,s:"7 · 7 = 49."},
{t:"8 · □ = 72. □ = ?",o:["9","8","7","64"],k:0,s:"8 · 9 = 72."},
{t:"Qaysi ko'paytma 7 · 6 ga teng EMAS?",o:["7 · 5 + 6","6 · 7","7 · 5 + 7","7 · 3 · 2"],k:0,s:"7 · 5 + 6 = 41 — noto'g'ri; 7 · 5 + 7 = 42 ✓."},
{t:"Qaysi son 9 ga karrali?",o:["81","82","79","91"],k:0,s:"8 + 1 = 9; 81 = 9 · 9."},
{t:"24 soni ko'paytirish jadvalida (1–9) necha marta uchraydi?",o:["4","2","3","6"],k:0,s:"3 · 8, 8 · 3, 4 · 6, 6 · 4 — 4 marta."},
{t:"Qaysi ko'paytma eng katta?",o:["7 · 9","8 · 8","6 · 9","9 · 6"],k:0,s:"63? 8 · 8 = 64! Tekshiring."},
{t:"7 · 8 − 7 · 7 = ?",o:["7","1","8","56"],k:0,s:"7 · (8 − 7) = 7."},
{t:"6 · 8 = 48. 12 · 8 = ?",o:["96","56","60","54"],k:0,s:"12 = 6 · 2: 48 · 2 = 96."},
{t:"0 · 9 + 1 · 9 = ?",o:["9","0","18","10"],k:0,s:"0 + 9 = 9."},
{t:"Qutida 6 qator, har qatorda 8 tadan shokolad. 9 tasi yeyildi. Nechta qoldi?",o:["39","48","40","57"],k:0,s:"6 · 8 = 48, 48 − 9 = 39."},
{t:"Ikki son ko'paytmasi 42, yig'indisi 13. Bu qaysi sonlar?",o:["6 va 7","2 va 21","3 va 14","5 va 8"],k:0,s:"6 · 7 = 42, 6 + 7 = 13."},
{t:"Qaysi tenglik to'g'ri?",o:["4 · 9 = 6 · 6","3 · 8 = 5 · 5","7 · 7 = 6 · 8","2 · 9 = 4 · 4"],k:0,s:"36 = 36. Qolganlari: 24 ≠ 25, 49 ≠ 48, 18 ≠ 16."},
{t:"9 · 9 = 81. 9 · 8 + 9 = ?",o:["81","72","80","90"],k:0,s:"9 · 8 + 9 = 9 · 9 = 81."},
{t:"Sardor har kuni 7 ta so'z yodladi. 8 kunda nechta, 9 kunda nechta?",o:["56 va 63","56 va 64","54 va 63","48 va 56"],k:0,s:"7 · 8 = 56, 7 · 9 = 63."}
];
PROBS[11]={t:"Qaysi ko'paytma eng katta?",o:["8 · 8","7 · 9","6 · 9","9 · 6"],k:0,s:"8 · 8 = 64 > 7 · 9 = 63 > 6 · 9 = 54."};
function PRACT_STAGE(){w3Tab([],null,{diag:1});bqMsg('Unutganingizni bilganingizdan tiklang')}
var PREP_DATA={teach:["Ko'paytirish — teng qo'shiluvchilar; massiv modeli.","O'rin almashtirish: jadval simmetriyasi.","Taqsimot xossasi va ikkilantirish orqali tiklash.","9 ga ko'paytirish naqshi; kvadratlar va qo'shni ko'paytmalar; 0 va 1."],
 mist:["6 · 7, 7 · 8, 6 · 8 ni adashtiradi.","7 · 8 = 7 · 7 + 8 deb oladi.","Ko'paytirish o'rniga qo'shadi (7 + 5).","a · 0 = a deb o'ylaydi."],
 need:["Katakli qog'oz, qaychi.","Tugmachalar/cho'plar massiv uchun.","Bo'sh 9×9 jadval varag'i."],
 board:["<span class='w2'>4 · 6 = 6 + 6 + 6 + 6</span>","<span class='w2'>7 · 8 = 7 · 5 + 7 · 3 = 56</span>","<span class='w2'>9 · 7 = 70 − 7 = 63</span>","<span class='w2'>7 · 8 = 7 · 7 + 7</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<n)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=Math.max(W*p/tot,34);E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,p+' · '+b+' = '+(p*b),{'font-size':w<70?10:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
