var CODE='4H8',TITLE='4-sinf · Sonli nur: shkala, masofa, nuqtaning harakati';
function q8msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// o: n (bo'linmalar), st (bo'linma qiymati), labs [indekslar] yoki 'all', pts [[qiymat,lab,col,up]], arcs [[a,b,lab,col]], tap, y
function q8nur(o){clear();var g=S.g,n=o.n||10,st=o.st||1,y=o.y||110,x0=26,w=300/n,i;S.q8=o;
 E('line',{x1:x0,y1:y,x2:x0+300+22,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x0+322)+' '+y+' l-9 -5 v10 z',fill:'#33475b'},g);
 for(i=0;i<=n;i++){var lab=o.labs==='all'||(o.labs||[0]).indexOf(i)>=0;E('line',{x1:x0+w*i,y1:y-(lab?8:6),x2:x0+w*i,y2:y+(lab?8:6),stroke:'#33475b','stroke-width':lab?2.2:1.4},g);if(lab)T(g,x0+w*i,y+24,''+(i*st),{'font-size':11,'font-weight':700,fill:'#33475b'})}
 (o.arcs||[]).forEach(function(a){var xa=x0+w*a[0]/st,xb=x0+w*a[1]/st,h=Math.min(46,Math.abs(xb-xa)/2+8);E('path',{d:'M'+xa+' '+(y-4)+' Q'+((xa+xb)/2)+' '+(y-4-h*1.6)+' '+xb+' '+(y-4),fill:'none',stroke:a[3]||C.a2,'stroke-width':2.2,'stroke-dasharray':a[4]?'4 3':'none'},g);if(a[2])T(g,(xa+xb)/2,y-6-h*0.8-4,a[2],{'font-size':12,'font-weight':800,fill:a[3]||C.a2})});
 (o.pts||[]).forEach(function(p){var x=x0+w*p[0]/st;E('circle',{cx:x,cy:y,r:6,fill:p[2]||C.bad,stroke:'#fff','stroke-width':1.5},g);if(p[1])T(g,x,p[3]?y-14:y+40,p[1],{'font-size':12,'font-weight':800,fill:p[2]||C.bad})});
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:pointer'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var k=Math.max(0,Math.min(n,Math.round((p.x-x0)/w)));o.tap(k*st)})}}
var Q8P1=[function(){q8nur({n:10,st:1,labs:[0]});q8msg('Nur 0 dan boshlanib, o‘ngga cheksiz davom etadi')},
 function(){q8nur({n:10,st:1,labs:[0,1],arcs:[[0,1,'birlik kesma',C.ok]]});q8msg('0 dan 1 gacha — <b>birlik kesma</b>. Hammasi shu o‘lcham bilan')},
 function(){q8nur({n:10,st:1,labs:'all'});q8msg('Sonlar o‘ngga qarab <b>ortib</b> boradi. O‘ngdagi son — kattaroq')}];
function q8mv(t){var a=4*t,b=30-2*t;q8nur({n:15,st:2,labs:'all',pts:a<b?[[a,'A',C.blue,1],[b,'B',C.bad,1]]:[[a,'A = B',C.ok,1]],arcs:a<b?[[a,b,(b-a)+'',C.grey,1]]:[]})}
function q8ch(t){var a=6*t,b=12+2*t;q8nur({n:15,st:2,labs:'all',pts:a<b?[[a,'Ali',C.blue,1],[b,'Vali',C.bad,1]]:[[a,'Ali = Vali',C.ok,1]],arcs:a<b?[[a,b,(b-a)+'',C.grey,1]]:[]})}
var Q8P5=[function(){q8nur({n:10,st:20,labs:'all',pts:[[40,'A',C.blue,1],[160,'B',C.bad,1]]});q8msg('A(40) va B(160). Ular orasidagi masofa?')},
 function(){q8nur({n:10,st:20,labs:'all',pts:[[40,'A',C.blue,1],[160,'B',C.bad,1]],arcs:[[40,160,'?',C.a2]]});q8msg('Masofa — kattadan kichikni ayiramiz')},
 function(){q8nur({n:10,st:20,labs:'all',pts:[[40,'A',C.blue,1],[160,'B',C.bad,1]],arcs:[[40,160,'120',C.ok]]});q8msg('AB = 160 − 40 = <b>120</b> birlik (6 bo‘linma · 20)')}];
var STEPS=[
{h:"Sonli nur",sum:"Sonli nur 0 dan boshlanadi, birlik kesma tanlanadi, sonlar o'ngga qarab ortadi.",a:"m01",
 start:function(){startPh(Q8P1)},fin:function(){S.ph=2;Q8P1[2]()},
 html:"<p>O'lchagich, termometr, soat ham bir xil g'oyaga asoslangan — <b>sonli nur</b>. Uning qanday tuzilishini ko'ring.</p>",
 btns:[phaser(Q8P1)],
 after:"<p>Sonli nurning <b>boshi</b> — 0. Birinchi bo'lak — <b>birlik kesma</b>, keyingi bo'laklar unga teng. Sonlar o'ngga qarab ortadi: nurda <b>o'ngroqdagi son kattaroq</b>.</p>",
 q:{t:"Sonli nurda 47 va 74 dan qaysi biri o'ngroqda turadi?",opts:["47","74","Bir joyda","Birlik kesmaga bog'liq"],ok:1,why:"74 > 47, katta son o'ngroqda.",hint:"Nurda sonlar qaysi tomonga ortadi?",full:"Sonli nurda sonlar o'ngga qarab ortadi, 74 > 47, demak 74 o'ngroqda. Birlik kesma o'zgarsa ham tartib o'zgarmaydi."},
 tn:"Doska tagiga uzun nur chizing va bolalarni «tirik sonlar» qilib saflang: har biri o'z sonining joyiga tursin."},
{h:"Bo'linma qiymati",sum:"Bo'linma qiymati = (ikki yozilgan son ayirmasi) : (ular orasidagi bo'linmalar soni).",a:"m02",
 start:function(){q8nur({n:10,st:10,labs:[0,4]});q8msg('Bitta bo‘linma qancha? Tugmani tanlang')},fin:function(){q8nur({n:10,st:10,labs:'all'});q8msg('✓ 40 : 4 = <b>10</b>. Har bir bo‘linma — 10 birlik')},
 btns:[["1",function(c,done){q8msg('1 bo‘lsa, 4-chiziqda 4 turardi, 40 emas')}],["4",function(c,done){q8msg('4 — bu bo‘linmalar <b>soni</b>, qiymati emas')}],["10",function(c,done){STEPS[1].fin();done()}],["40",function(c,done){q8msg('40 — 4 ta bo‘linma birga. Bittasi-chi?')}]],g2:1,
 html:"<p>Shkalada faqat 0 va 40 yozilgan. Ular orasida <b>4</b> ta bo'linma. Bitta bo'linma qancha birlikni bildiradi?</p>",
 after:"<p>0 dan 40 gacha 4 ta bo'linma: <b>40 : 4 = 10</b>. Bu — <b>bo'linma qiymati</b>. Termometr, tarozi, spidometrda doim avval shuni aniqlang!</p>",
 q:{t:"Shkalada 200 va 300 yozilgan, ular orasida 5 ta bo'linma. Bo'linma qiymati?",opts:["20","100","5","50"],ok:0,why:"(300 − 200) : 5 = 20.",hint:"Avval ikki son ayirmasini toping.",full:"Ayirma 300 − 200 = 100, uni bo'linmalar soniga bo'lamiz: 100 : 5 = 20. 100 — bo'lishni unutish, 5 — bo'linmalar soni."},
 tn:"Haqiqiy termometr yoki oshxona tarozisini ko'rsating: «Bitta chiziqcha necha gradus (gramm)?» Bu hayotiy ko'nikma."},
{h:"Tuzoq: nuqtani o'qish",sum:"Nuqtaning qiymati = bo'linmalar soni · bo'linma qiymati. Bo'linmalar sonini javob deb yozmang!",a:"m03",
 start:function(){q8nur({n:10,st:5,labs:[0,2],pts:[[35,'A',C.bad,1]]});q8msg('A nuqta qaysi sonni bildiradi?')},fin:function(){q8nur({n:10,st:5,labs:[0,2,7],pts:[[35,'A = 35',C.ok,1]]});q8msg('✓ Bo‘linma = 10 : 2 = 5. A = 7 · 5 = <b>35</b>')},
 btns:[["7",function(c,done){q8msg('7 — bu bo‘linmalar <b>soni</b>. Har biri qancha?')}],["35",function(c,done){STEPS[2].fin();done()}],["14",function(c,done){q8msg('14 = 7 · 2 — bo‘linma qiymati 2 emas: 10 : 2 = ?')}],["70",function(c,done){q8msg('70 = 7 · 10 — 10 ikki bo‘linmaga to‘g‘ri keladi')}]],g2:1,
 html:"<p>Shkalada faqat 0 va 10 yozilgan. A nuqta qaysi sonni bildiradi?</p>",
 after:"<p>0 dan 10 gacha <b>2</b> ta bo'linma, demak bo'linma qiymati <b>10 : 2 = 5</b>. A nuqta 0 dan <b>7</b> bo'linma o'ngda: 7 · 5 = <b>35</b>. Eng ko'p xato — 7 deb yozish.</p>",
 q:{t:"Bo'linma qiymati 25. Nuqta 0 dan 6 bo'linma o'ngda. U qaysi son?",opts:["150","31","6","125"],ok:0,why:"6 · 25 = 150.",hint:"Har bir bo'linma 25 bo'lsa, 6 tasi qancha?",full:"6 · 25 = 150. 31 — qo'shib yuborish (6 + 25), 125 — 5 bo'linma deb sanash xatosi."},
 tn:"Bolalardan har doim ikki savolni so'rang: «Nechta bo'linma?» va «Bittasi necha?»"},
{h:"Nuqtani o'zingiz qo'ying",sum:"Sonni nurga qo'yish: son : bo'linma qiymati = nechta bo'linma.",a:"m04",
 start:function(){q8nur({n:10,st:20,labs:[0,1],tap:q8t4});q8msg('Shkalada 0 va 20. <b>140</b> ni bosing')},fin:function(){q8nur({n:10,st:20,labs:[0,1,7],pts:[[140,'140',C.ok,1]]});q8msg('✓ 140 : 20 = <b>7</b> bo‘linma')},
 act:function(c,done){S.d4=done},
 html:"<p>Bo'linma qiymati <b>20</b>. <b>140</b> sonini nurda toping va bosing.</p>",
 after:"<p>140 sonida nechta 20 bor? <b>140 : 20 = 7</b>. Demak 0 dan <b>7</b> bo'linma o'ngga sanaymiz. Tekshirish: 7 · 20 = 140.</p>",
 q:{t:"Bo'linma qiymati 50. 450 soni 0 dan nechta bo'linma o'ngda?",opts:["9","45","400","8"],ok:0,why:"450 : 50 = 9.",hint:"450 da nechta 50 bor?",full:"450 : 50 = 9 bo'linma. 45 — 10 ga bo'lish, 8 — bitta kam sanash."},
 tn:"Bolalar daftarda bo'linma qiymati turlicha (2, 5, 25) bo'lgan uchta nur chizib, bir xil sonni (50) belgilasin — joyi har xil chiqadi."},
{h:"Ikki nuqta orasidagi masofa",sum:"Sonli nurdagi ikki nuqta orasidagi masofa — katta sondan kichik sonni ayirish.",a:"m05",
 start:function(){startPh(Q8P5)},fin:function(){S.ph=2;Q8P5[2]()},
 html:"<p>A va B nuqtalar orasida qancha birlik bor?</p>",
 btns:[phaser(Q8P5)],
 after:"<p>Masofa = <b>katta son − kichik son</b>: 160 − 40 = 120. Bo'linmalar orqali tekshirish: 6 bo'linma · 20 = 120. Masofa hech qachon manfiy bo'lmaydi — kattadan kichikni ayiramiz.</p>",
 q:{t:"Sonli nurda C(85) va D(230). CD masofa?",opts:["145","315","155","135"],ok:0,why:"230 − 85 = 145.",hint:"Kattadan kichikni ayiring.",full:"230 − 85 = 145. 315 — qo'shib yuborish, 155 va 135 — ayirishda o'nlik xatosi."},
 tn:"Hayotiy misol: «Avtobus 40-km da, do'kon 160-km da. Qancha yo'l qoldi?» Yo'l belgisidagi kilometrlar ham sonli nur."},
{h:"Kesmaning o'rtasi",sum:"O'rta nuqta = (a + b) : 2 yoki a + (b − a) : 2.",a:"m06",
 start:function(){q8nur({n:10,st:10,labs:'all',pts:[[20,'M',C.blue,1],[80,'N',C.bad,1]],tap:q8t6});q8msg('MN ning o‘rtasini bosing')},fin:function(){q8nur({n:10,st:10,labs:'all',pts:[[20,'M',C.blue,1],[80,'N',C.bad,1],[50,'K',C.ok,1]],arcs:[[20,50,'30',C.a2],[50,80,'30',C.a2]]});q8msg('✓ K = (20 + 80) : 2 = <b>50</b>. MK = KN = 30')},
 act:function(c,done){S.d6=done},
 html:"<p>M(20) va N(80). Kesmaning <b>o'rtasi</b> K ni nurda bosing.</p>",
 after:"<p>MN = 80 − 20 = 60, yarmi <b>30</b>. M dan 30 o'ngga: 20 + 30 = <b>50</b>. Qisqa yo'l: (20 + 80) : 2 = 50. Xato: masofaning yarmini (30) javob deb yozish.</p>",
 q:{t:"P(140) va Q(260) ning o'rtasi?",opts:["200","60","120","400"],ok:0,why:"(140 + 260) : 2 = 200.",hint:"Ikki sonni qo'shib, ikkiga bo'ling.",full:"(140 + 260) : 2 = 400 : 2 = 200. 60 — masofaning yarmi, 120 — masofa, 400 — yig'indi."},
 tn:"Ikki bola nurning ikki nuqtasida tursin va bir xil qadam bilan bir-biriga yursin — uchrashgan joy o'rta nuqta."},
{h:"Qarama-qarshi harakat",sum:"Bir-biriga qarab harakatda masofa har soatda tezliklar yig'indisicha kamayadi.",a:"m07",
 start:function(){S.t7=0;q8mv(0);q8msg('A soatiga 4, B soatiga 2 birlik yuradi')},fin:function(){S.t7=5;q8mv(5);q8msg('✓ 5 soatda 20 da uchrashdi: 30 : (4 + 2) = <b>5</b>')},
 btns:[["+1 soat",function(c,done){if(S.t7>=5)return;S.t7++;q8mv(S.t7);if(S.t7<5)q8msg(S.t7+' soat: A = '+(4*S.t7)+', B = '+(30-2*S.t7)+'. Orasi '+(30-6*S.t7));else{STEPS[6].fin();done()}}]],
 html:"<p>A 0 dan o'ngga soatiga <b>4</b> birlik, B 30 dan chapga soatiga <b>2</b> birlik yuradi. Ular qachon va qayerda uchrashadi? «+1 soat» ni bosing.</p>",
 after:"<p>Har soatda oraliq <b>4 + 2 = 6</b> birlikka qisqaradi (yaqinlashish tezligi). 30 : 6 = <b>5 soat</b>. Uchrashuv joyi: A 5 · 4 = 20, B 30 − 5 · 2 = 20 — <b>20</b>.</p>",
 q:{t:"Ikki shahar orasi 180 km. Ikki mashina bir-biriga qarab chiqdi: 50 km/soat va 40 km/soat. Necha soatda uchrashadi?",opts:["2 soat","18 soat","4 soat","9 soat"],ok:0,why:"180 : (50 + 40) = 2.",hint:"Har soatda oraliq qanchaga qisqaradi?",full:"Yaqinlashish tezligi 50 + 40 = 90 km/soat, 180 : 90 = 2 soat. 18 soat — tezliklar ayirmasiga (10) bo'lish, 4 soat — faqat 50 ga bo'lish."},
 tn:"Ikki bola sinfning ikki chetidan bir-biriga qarab yursin: biri 2 qadam, biri 1 qadamdan. Uchrashgan joy tezroq yurganga uzoqroq ekanini ko'rsating."},
{h:"Quvlash (qiyin)",sum:"Bir tomonga harakatda tez yurgan sekinini oraliq : (tezliklar ayirmasi) vaqtda quvib yetadi.",a:"m08",
 start:function(){S.t8=0;q8ch(0);q8msg('Ali 0 da (6 birlik/soat), Vali 12 da (2 birlik/soat). Ikkalasi o‘ngga')},fin:function(){S.t8=3;q8ch(3);q8msg('✓ 3 soatda 18 da yetdi: 12 : (6 − 2) = <b>3</b>')},
 btns:[["+1 soat",function(c,done){if(S.t8>=3)return;S.t8++;q8ch(S.t8);if(S.t8<3)q8msg(S.t8+' soat: Ali = '+(6*S.t8)+', Vali = '+(12+2*S.t8)+'. Orasi '+(12-4*S.t8));else{STEPS[7].fin();done()}}]],
 html:"<p>Endi ikkalasi bir tomonga — o'ngga yuradi. Ali 0 dan soatiga <b>6</b>, Vali 12 dan soatiga <b>2</b> birlik. Ali Valini qachon quvib yetadi?</p>",
 after:"<p>Har soatda oraliq <b>6 − 2 = 4</b> birlikka qisqaradi (tezliklar <b>ayirmasi</b>!). 12 : 4 = <b>3 soat</b>. Joyi: Ali 3 · 6 = 18, Vali 12 + 3 · 2 = 18. Qarama-qarshi harakatda tezliklar qo'shiladi, quvlashda ayiriladi.</p>",
 q:{t:"Mushuk sichqondan 20 m orqada. Mushuk 7 m/s, sichqon 3 m/s tezlikda bir tomonga yugurdi. Necha soniyada quvib yetadi?",opts:["5 s","2 s","10 s","4 s"],ok:0,why:"20 : (7 − 3) = 5.",hint:"Har soniyada oraliq qanchaga qisqaradi?",full:"Bir tomonga harakatda tezliklar ayiriladi: 7 − 3 = 4 m/s. 20 : 4 = 5 s. 2 s — tezliklarni qo'shish (20 : 10), 10 s — faqat sichqon tezligini (20 : 2) ishlatish."},
 tn:"Qarama-qarshi va quvlash masalalarini doskada yonma-yon yozing: «+» va «−» farqini bolalar o'zlari tushuntirsin."},
{h:"Bilasizmi? Shkalalar hayotda",sum:"Termometr, chizg'ich, spidometr — hammasi sonli nurga asoslangan shkala.",a:"m09",
 start:function(){q8nur({n:10,st:10,labs:'all',pts:[[36,'36',C.bad,1]]});q8msg('Termometr shkalasi ham sonli nur')},fin:function(){q8nur({n:10,st:10,labs:'all',pts:[[36,'36',C.bad,1]]});q8msg('Termometr shkalasi ham sonli nur')},
 html:"<p>🌡 Tibbiy termometrda bitta bo'linma odatda <b>0,1 gradus</b>. Shuning uchun 36,6 kabi aniq o'lchash mumkin.</p><p>📏 Uzunlik o'lchovi <b>metr</b> 1790-yillarda Fransiyada kiritilgan; dastlab u Yer meridiani choragining o'n milliondan biri qilib belgilangan.</p><p>🚗 Mashina spidometrida ham shkala bor: strelka joyiga qarab tezlikni o'qiymiz.</p>",
 tn:"Bolalarga 3 xil shkala rasmini (termometr, tarozi, spidometr) ko'rsatib, har birida bo'linma qiymatini topdiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){q8nur({n:10,st:10,labs:'all',pts:[[20,'M',C.blue,1],[80,'N',C.bad,1]],arcs:[[20,80,'60',C.a2]]});q8msg('MN = 80 − 20 = 60, o‘rtasi 50')},fin:function(){q8nur({n:10,st:10,labs:'all',pts:[[20,'M',C.blue,1],[80,'N',C.bad,1]],arcs:[[20,80,'60',C.a2]]});q8msg('MN = 80 − 20 = 60, o‘rtasi 50')},
 html:"<div class='memo'><ul><li>Sonli nur 0 dan boshlanadi; o'ngdagi son katta.</li><li><b>Bo'linma qiymati</b> = sonlar ayirmasi : bo'linmalar soni.</li><li>Nuqta = bo'linmalar soni · bo'linma qiymati (sonni emas, qiymatni yozing!).</li><li>Masofa = katta − kichik.</li><li>O'rtasi = (a + b) : 2.</li><li>Qarama-qarshi harakat: vaqt = masofa : (v₁ + v₂).</li><li>Quvlash: vaqt = oraliq : (v₁ − v₂).</li></ul></div>",
 tn:"Uyga: uydagi biror shkalaning (tarozi, termometr) rasmini chizib, bo'linma qiymatini yozish."}
];
function q8t4(v){if(v===140){STEPS[3].fin();if(S.d4){var d=S.d4;S.d4=null;d()}}else if(S.d4){q8nur({n:10,st:20,labs:[0,1],tap:q8t4,pts:[[v,''+v,C.grey,1]]});q8msg('Bu — <b>'+v+'</b> ('+(v/20)+' bo‘linma · 20). Kerak: 140')}}
function q8t6(v){if(v===50){STEPS[5].fin();if(S.d6){var d=S.d6;S.d6=null;d()}}else if(S.d6){q8nur({n:10,st:10,labs:'all',tap:q8t6,pts:[[20,'M',C.blue,1],[80,'N',C.bad,1],[v,''+v,C.grey,0]]});q8msg(v===30?'30 — masofaning yarmi. M dan 30 yuring: 20 + 30 = ?':v+' dan M gacha '+Math.abs(v-20)+', N gacha '+Math.abs(80-v)+' — teng emas')}}
var PROBS=[
{t:"Shkalada 0 va 60 yozilgan, orasida 6 bo'linma. Bo'linma qiymati?",o:["10","6","60","5"],k:0,s:"60 : 6 = 10."},
{t:"Shkalada 100 va 200, orasida 4 bo'linma. Bo'linma qiymati?",o:["25","50","100","4"],k:0,s:"(200 − 100) : 4 = 25."},
{t:"Bo'linma qiymati 5. Nuqta 0 dan 9 bo'linma o'ngda. U qaysi son?",o:["45","9","14","40"],k:0,s:"9 · 5 = 45."},
{t:"Bo'linma qiymati 30. 240 soni 0 dan nechta bo'linma o'ngda?",o:["8","24","7","80"],k:0,s:"240 : 30 = 8."},
{t:"Sonli nurda A(37) va B(91). AB masofa?",o:["54","128","64","44"],k:0,s:"91 − 37 = 54."},
{t:"Sonli nurda C(250) va D(70). CD masofa?",o:["180","320","220","170"],k:0,s:"250 − 70 = 180."},
{t:"M(30) va N(90) ning o'rtasi?",o:["60","30","120","45"],k:0,s:"(30 + 90) : 2 = 60."},
{t:"K(15) — AB kesmaning o'rtasi, A(5). B qayerda?",o:["25","20","10","30"],k:0,s:"A dan K gacha 10, K dan B gacha ham 10: 15 + 10 = 25."},
{t:"Nurda 0 dan 4 ta bo'linma 100 ga teng. 7 ta bo'linma qancha?",o:["175","700","140","125"],k:0,s:"Bo'linma 100 : 4 = 25, 7 · 25 = 175."},
{t:"Shkalada 40 va 60 orasida 4 bo'linma. 40 dan 3 bo'linma o'ngdagi son?",o:["55","43","45","70"],k:0,s:"Bo'linma (60 − 40) : 4 = 5, 40 + 15 = 55."},
{t:"Chumoli 0 dan har daqiqada 6 birlik o'ngga yuradi. 7 daqiqadan keyin qayerda?",o:["42","13","48","36"],k:0,s:"7 · 6 = 42."},
{t:"Nuqta 80 dan har soniyada 5 birlik chapga yuradi. Necha soniyada 0 ga yetadi?",o:["16","75","85","15"],k:0,s:"80 : 5 = 16."},
{t:"A 0 da, B 60 da. Ular bir-biriga qarab: A soniyada 7, B soniyada 3 birlik. Necha soniyada uchrashadi?",o:["6","15","10","20"],k:0,s:"60 : (7 + 3) = 6."},
{t:"Shu masalada A va B qaysi nuqtada uchrashadi?",o:["42","18","30","36"],k:0,s:"A: 6 · 7 = 42 (B: 60 − 18 = 42)."},
{t:"A 0 da (soniyada 8), B 30 da (soniyada 5). Ikkalasi o'ngga. A B ni necha soniyada quvib yetadi?",o:["10","3","6","2"],k:0,s:"30 : (8 − 5) = 10."},
{t:"Ikki poyezd bir stansiyadan bir vaqtda qarama-qarshi tomonga chiqdi: 60 va 80 km/soat. 3 soatdan keyin orasi?",o:["420 km","60 km","140 km","240 km"],k:0,s:"Uzoqlashish tezligi 140, 3 · 140 = 420 km."},
{t:"Velosipedchi piyodadan 1 soat keyin chiqdi. Piyoda 5 km/soat, velosipedchi 15 km/soat. Velosipedchi chiqqanidan necha soatda yetadi?",o:["0,5 soat — 30 daqiqa","1 soat","2 soat","3 soat"],k:0,s:"Oraliq 5 km, 5 : (15 − 5) = 0,5 soat = 30 daqiqa."},
{t:"Shkalada 0 va 100 orasida 20 bo'linma. 7 bo'linma qaysi sonni bildiradi?",o:["35","7","70","27"],k:0,s:"Bo'linma 100 : 20 = 5, 7 · 5 = 35."},
{t:"A(16) va B(64) kesmani 3 ta teng bo'lakka bo'luvchi nuqtalar?",o:["32 va 48","24 va 48","32 va 40","20 va 40"],k:0,s:"Uzunlik 48, bo'lak 16: 16 + 16 = 32, 32 + 16 = 48."},
{t:"Nuqta 10 da edi. U o'ngga 25, keyin chapga 18, keyin o'ngga 7 yurdi. Endi qayerda?",o:["24","60","10","38"],k:0,s:"10 + 25 − 18 + 7 = 24."}
];
function PRACT_STAGE(){q8nur({n:10,st:10,labs:'all',pts:[[20,'A',C.blue,1],[70,'B',C.bad,1]]})}
var PREP_DATA={teach:["Sonli nur: boshi, birlik kesma, sonlar tartibi.","Bo'linma qiymati; nuqtani o'qish va qo'yish.","Masofa va kesma o'rtasi.","Nuqtalarning harakati: bir tomonga, qarama-qarshi, quvlash."],
 mist:["Bo'linmalar sonini nuqtaning qiymati deb yozadi.","Bo'linma qiymatini topishda bo'lishni unutadi.","O'rta nuqta o'rniga masofaning yarmini yozadi.","Quvlashda tezliklarni qo'shadi.","Qarama-qarshi harakatda faqat bitta tezlikni oladi."],
 need:["Doskada uzun sonli nur (rangli bo'r).","Termometr, tarozi yoki ularning rasmi.","Chizg'ich, katakli daftar."],
 board:["Bo'linma = (40 − 0) : 4 = 10.","A = 7 · 5 = 35 (7 emas!).","AB = 160 − 40 = 120.","O'rtasi: (20 + 80) : 2 = 50.","Qarshi: 30 : (4 + 2) = 5.","Quvlash: 12 : (6 − 2) = 3."]};
