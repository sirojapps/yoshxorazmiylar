var CODE='2H19',TITLE='2-sinf · Navbat va o‘rin masalalari';
// ---------- sahna: qatorda turgan bolalar ----------
// n — jami, me — belgilangan (1 dan), o: {lab:{i:'matn'}, col:{i:rang}, front:'oldi' yo'nalishi, nums:'L'|'R'|null}
function h19Row(n,o){o=o||{};clear();var g=S.g,w=Math.min(26,320/n),x0=180-n*w/2;S.px=function(i){return x0+(i-0.5)*w};
 T(g,16,160,'oldi ←',{'font-size':10,fill:C.blue,'text-anchor':'start','font-weight':800});T(g,344,160,'→ orqa',{'font-size':10,fill:C.blue,'text-anchor':'end','font-weight':800});
 for(var i=1;i<=n;i++){var x=S.px(i),c=(o.col&&o.col[i])||'#9aa8b6',r=Math.min(9,w/2.6);E('circle',{cx:x,cy:56,r:r*0.8,fill:c},g);E('rect',{x:x-r,y:56+r*0.9,width:r*2,height:r*2.4,rx:r*0.8,fill:c},g);
  if(o.nums==='L'||o.nums==='B')T(g,x,104,String(i),{'font-size':w<20?8:10,'font-weight':700,fill:'#5b6b7b'});
  if(o.nums==='R'||o.nums==='B')T(g,x,o.nums==='B'?118:104,String(n-i+1),{'font-size':w<20?8:10,'font-weight':700,fill:C.a2});
  if(o.lab&&o.lab[i])T(g,x,34,o.lab[i],{'font-size':10,'font-weight':800,fill:c})}
 if(o.br)o.br.forEach(function(b){Br(S.px(b[0])-w/2+2,S.px(b[1])+w/2-2,o.nums==='B'?126:112,b[2],false,b[3])})}
function h19Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function cols(a,b,c){var o={};for(var i=a;i<=b;i++)o[i]=c;return o}
// ---------- bosqichlar ----------
var P2=[function(){var c=cols(1,6,C.b);c[7]=C.bad;Object.assign(c,cols(8,11,C.a));h19Row(11,{col:c,lab:{7:'Lola'}});h19Msg('Lolaning <b>oldida 6</b> kishi, <b>orqasida 4</b> kishi. Jami nechta?')},
 function(){var c=cols(1,6,C.b);c[7]=C.bad;Object.assign(c,cols(8,11,C.a));h19Row(11,{col:c,lab:{7:'Lola'},br:[[1,6,'6',C.blue],[8,11,'4',C.a2]]});h19Msg('6 + 4 = 10 — lekin bu Lolaning <b>o‘zini</b> hisobga olmadi!')},
 function(){var c=cols(1,6,C.b);c[7]=C.bad;Object.assign(c,cols(8,11,C.a));h19Row(11,{col:c,lab:{7:'Lola'},nums:'L'});h19Msg('6 + 4 + <b>1</b> (Lola) = <b>11</b> kishi')}];
var P3=[function(){var c={};c[4]=C.bad;h19Row(9,{col:c,lab:{4:'Ali'},nums:'L'});h19Msg('9 ta vagon. Oldidan sanaganda Ali — <b>4-chi</b>. Orqadan nechanchi?')},
 function(){var c=cols(5,9,C.a);c[4]=C.bad;h19Row(9,{col:c,lab:{4:'Ali'},nums:'B',br:[[5,9,'orqasida 5 ta',C.a2]]});h19Msg('Alining orqasida 9 − 4 = <b>5</b> ta vagon')},
 function(){var c=cols(5,9,C.a);c[4]=C.bad;h19Row(9,{col:c,lab:{4:'Ali'},nums:'B'});h19Msg('Orqadan: 5 + 1 = <b>6-chi</b>. Qoida: 9 − 4 + 1 = 6')}];
var P4=[function(){var c={};c[5]=C.bad;h19Row(12,{col:c,lab:{5:'Ali'}});h19Msg('Ali oldidan <b>5-o‘rinda</b>, orqadan <b>8-o‘rinda</b>. Navbatda nechta kishi?')},
 function(){var c=cols(1,5,C.b);c[5]=C.bad;h19Row(12,{col:c,lab:{5:'Ali'},nums:'L',br:[[1,5,'oldidan 5',C.blue]]});h19Msg('Oldidan sanaganda: 5 kishi (Ali bilan)')},
 function(){var c=cols(1,4,C.b);c[5]=C.bad;Object.assign(c,cols(6,12,C.a));h19Row(12,{col:c,lab:{5:'Ali'},nums:'B',br:[[5,12,'orqadan 8',C.a2]]});h19Msg('Orqadan: 8 kishi (Ali bilan). 5 + 8 = 13 — Ali <b>ikki marta</b> sanaldi!')},
 function(){var c=cols(1,4,C.b);c[5]=C.bad;Object.assign(c,cols(6,12,C.a));h19Row(12,{col:c,lab:{5:'Ali'},nums:'L'});h19Msg('5 + 8 − <b>1</b> = <b>12</b> kishi')}];
var P5=[function(){var c={};c[6]=C.b;c[10]=C.a;h19Row(15,{col:c,lab:{6:'Ali',10:'Vali'},nums:'L'});h19Msg('15 bola. Ali chapdan 6-o‘rinda, Vali o‘ngdan 6-o‘rinda. Orasida nechta?')},
 function(){var c={};c[6]=C.b;c[10]=C.a;h19Row(15,{col:c,lab:{6:'Ali',10:'Vali'},nums:'B'});h19Msg('Valini chapdan sanaymiz: 15 − 6 + 1 = <b>10-o‘rin</b>')},
 function(){var c=cols(7,9,C.ok);c[6]=C.b;c[10]=C.a;h19Row(15,{col:c,lab:{6:'Ali',10:'Vali'},nums:'L',br:[[7,9,'3 ta',C.ok]]});h19Msg('6 va 10 orasida: 7, 8, 9 — <b>3 ta</b> bola (10 − 6 − 1)')}];
var STEPS=[
{h:"Oldida va orqasida",sum:"Navbatdagilar = oldidagilar + orqasidagilar + 1 (o'zi).",a:"m01",
 start:function(){S.t1=0;var c={};c[4]=C.bad;h19Row(8,{col:c,lab:{4:'Siz'}});h19Msg('Navbatda nechta kishi? Har birini bosib sanang')},fin:function(){var c={};c[4]=C.bad;h19Row(8,{col:c,lab:{4:'Siz'},nums:'L'});h19Msg('Oldingizda 3, orqangizda 4 — jami 3 + 4 + 1 = 8')},
 html:"<p>Siz navbatda turibsiz (qizil). Navbatda jami nechta kishi bor? Har bir kishini <b>bosib</b> sanang — o'zingizni ham!</p>",
 act:function(c,done){S.d1=done;S.tp={};h19Tap();c.querySelector('.hint').textContent='Rasmdagi odamlarni bosing.'},
 after:"<p>Oldingizda <b>3</b>, orqangizda <b>4</b> kishi. 3 + 4 = 7, lekin siz ham navbatdasiz: <b>3 + 4 + 1 = 8</b>. Eng ko'p xato — o'zini unutish!</p>",
 q:{t:"Navbatda Lolaning oldida 6 kishi, orqasida 4 kishi. Navbatda jami nechta kishi?",opts:["10","11","9","12"],ok:1,why:"6 + 4 + 1 (Lola) = 11.",hint:"Lolaning o'zini hisobga oldingizmi?",full:"Oldida 6, orqasida 4, o'rtada Lolaning o'zi: 6 + 4 + 1 = 11. «10» — Lola sanalmagan."},
 tn:"Sinfda 5–6 bolani qatorga turg'izing. «Senning oldingda nechta, orqangda nechta?» deb so'rang."},
{h:"Rasm bilan tekshiramiz",sum:"6 + 4 + 1 = 11: o'zini qo'shishni unutmaymiz.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Masalani rasm bilan yechamiz: Lolaning oldida 6, orqasida 4 kishi.</p>",
 btns:[phaser(P2)],
 after:"<p>Har doim <b>chizib</b> ko'ring — shunda o'zini unutmaysiz. Kinoteatrda ham shunday: «Chap tomonida 13, o'ng tomonida 8 bola» → 13 + 8 + 1 = 22.</p>",
 q:{t:"Kamola kinoteatrda o'tiribdi. Chap tomonida 13 ta, o'ng tomonida 8 ta bola. Qatorda jami nechta bola?",opts:["21","22","20","23"],ok:1,why:"13 + 8 + 1 (Kamola) = 22.",hint:"Kamolaning o'zi ham qatorda o'tiribdimi?",full:"13 + 8 = 21 — Kamolasiz. U ham qatorda: 21 + 1 = 22."},
 tn:"Bankda 1197, 2122, 2595-masalalar shu turda."},
{h:"Oldidan va orqadan sanash",sum:"9 ta vagonda oldidan 4-chi → orqadan 9 − 4 + 1 = 6-chi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Poyezdda <b>9 ta</b> vagon. Oldidan sanaganda Alining vagoni <b>4-chi</b>. Orqadan sanaganda nechanchi?</p>",
 btns:[phaser(P3)],
 after:"<p>Ikki qator raqamni ko'ring: kulrang — oldidan, to'q sariq — orqadan. Qoida: <b>orqadan o'rin = jami − oldidan o'rin + 1</b>.</p>",
 q:{t:"Qatorda 10 ta bola. Ali chapdan 3-o'rinda. U o'ngdan nechanchi o'rinda?",opts:["7-o'rinda","8-o'rinda","3-o'rinda","9-o'rinda"],ok:1,why:"10 − 3 + 1 = 8.",hint:"Alining o'ng tomonida nechta bola bor? Keyin Alini qo'shing.",full:"Alining o'ng tomonida 10 − 3 = 7 bola. U o'zi — 8-chi: 7 + 1 = 8. «7» — o'zini qo'shmaslik xatosi."},
 tn:"Bolalar qatorda turib, chapdan va o'ngdan raqam aytib chiqsin — ikkala raqam yig'indisi doim jami + 1 bo'ladi."},
{h:"Tuzoq: ikki marta sanaldi",sum:"Oldidan 5-chi, orqadan 8-chi → 5 + 8 − 1 = 12 kishi (o'zi ikki marta sanalgan).",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Ali navbatda <b>oldidan 5-o'rinda</b>, <b>orqadan 8-o'rinda</b>. Navbatda nechta kishi? 13 deb shoshilmang!</p>",
 btns:[phaser(P4)],
 after:"<p>«Oldidan 5-chi» — Ali bilan 5 kishi, «orqadan 8-chi» — Ali bilan 8 kishi. Ali <b>ikki marta</b> sanaldi, shuning uchun 1 ni ayiramiz: <b>5 + 8 − 1 = 12</b>.</p><div class='life'><div>➕<span>«oldida» va «orqasida» → <b>+ 1</b> (o'zini qo'shamiz)</span></div><div>➖<span>«oldidan …-chi» va «orqadan …-chi» → <b>− 1</b> (o'zi ikki marta)</span></div></div>",
 q:{t:"Lola navbatda oldidan 4-chi, orqadan 7-chi. Navbatda nechta kishi?",opts:["11","10","12","9"],ok:1,why:"4 + 7 − 1 = 10.",hint:"Lola ikkala sanoqda ham bormi?",full:"Oldidan 4 (Lola bilan), orqadan 7 (Lola bilan). Lola ikki marta: 4 + 7 − 1 = 10. «11» — Lola ikki marta sanalgan."},
 tn:"Ikki turdagi masalani doskada yonma-yon yozing: «oldida 6, orqasida 4» (+1) va «oldidan 5-chi, orqadan 8-chi» (−1)."},
{h:"Orasida nechta?",sum:"15 bola: Ali chapdan 6-chi, Vali o'ngdan 6-chi (chapdan 10-chi) → orasida 3 ta.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Qatorda <b>15 bola</b>. Ali <b>chapdan</b> 6-o'rinda, Vali <b>o'ngdan</b> 6-o'rinda. Ular orasida nechta bola bor?</p>",
 btns:[phaser(P5)],
 after:"<p>Avval ikkalasini <b>bir tomondan</b> sanaymiz: Vali chapdan 10-chi. Keyin orasidagilar: 10 − 6 − 1 = <b>3</b> (2A3 dagi «orasida» qoidasi).</p>",
 q:{t:"Qatorda 12 bola. Anvar chapdan 3-chi, Bobur o'ngdan 3-chi. Ular orasida nechta bola?",opts:["6","5","7","4"],ok:0,why:"Bobur chapdan 12 − 3 + 1 = 10-chi; orasida 10 − 3 − 1 = 6.",hint:"Boburni chapdan sanang. Keyin 3 va 10 orasidagilarni toping.",full:"Bobur chapdan: 12 − 3 + 1 = 10-o'rin. Orasida: 4, 5, 6, 7, 8, 9 — 6 ta bola."},
 tn:"Rasm chizmasdan yechish qiyin — bolalarni har doim chizishga undang."},
{h:"O'rtada va navbatdan chiqish",sum:"9 kishining o'rtasi — 5-o'rin (oldida 4). 7-chidan oldin 3 kishi chiqsa — 4-chi bo'ladi.",a:"m06",
 start:function(){S.k6=0;var c={};c[5]=C.bad;h19Row(9,{col:c,lab:{5:'Lola'},nums:'B'});h19Msg('9 kishi, Lola roppa-rosa o‘rtada. Oldida nechta?')},fin:function(){var c={};c[4]=C.bad;h19Row(6,{col:c,lab:{4:'Vali'},nums:'L'});h19Msg('Vali endi 4-o‘rinda')},
 html:"<p>Ikki masala: 1) 9 kishilik qatorda Lola <b>roppa-rosa o'rtada</b>. Uning oldida nechta? 2) Vali navbatda <b>7-o'rinda</b>. Undan oldin turgan <b>3 kishi</b> chiqib ketdi. Endi u nechanchi?</p>",
 btns:[["▶ Keyingi harakat",function(c,done,b){S.k6++;if(S.k6===1){var c1=cols(1,4,C.b);c1[5]=C.bad;Object.assign(c1,cols(6,9,C.a));h19Row(9,{col:c1,lab:{5:'Lola'},nums:'L',br:[[1,4,'4 ta',C.blue],[6,9,'4 ta',C.a2]]});h19Msg('O‘rtada — ikki tomonida teng: (9 − 1) : 2 = <b>4</b>. Lola 5-o‘rinda')}
  else if(S.k6===2){var c2=cols(1,3,'#e0e0e0');c2[7]=C.bad;h19Row(9,{col:c2,lab:{7:'Vali',1:'chiqdi',2:'chiqdi',3:'chiqdi'},nums:'L'});h19Msg('Vali 7-chi. Oldidagi 3 kishi chiqib ketadi…')}
  else{var c3={};c3[4]=C.bad;h19Row(6,{col:c3,lab:{4:'Vali'},nums:'L'});h19Msg('7 − 3 = <b>4-o‘rin</b>');b.disabled=true;b.textContent='✓ Tayyor';done()}}]],
 after:"<p><b>O'rtadagi</b>: ikki tomonida teng — (jami − 1) : 2. <b>Oldidan chiqsa</b> — o'rin kamayadi (7 − 3 = 4), <b>orqadan chiqsa</b> — o'zgarmaydi!</p>",
 q:{t:"Navbatda Ali 8-o'rinda. Uning orqasidagi 2 kishi chiqib ketdi. Ali endi nechanchi o'rinda?",opts:["6-o'rinda","8-o'rinda","10-o'rinda","7-o'rinda"],ok:1,why:"Orqadagilar chiqsa, Alining oldi o'zgarmaydi — 8-o'rin.",hint:"Chiqib ketganlar Alining oldidami yoki orqasidami?",full:"Ali o'rni oldidagilar soniga bog'liq. Orqadagilar chiqsa, oldida baribir 7 kishi — Ali 8-o'rinda qoladi. «6» — oldidan chiqqan deb hisoblash xatosi."},
 tn:"Tuzoq savol: «orqadan chiqsa» — o'rin o'zgarmaydi. Bolalar buni amalda ko'rsin."},
{h:"Bilasizmi? Kompyuterdagi navbat",sum:"Dasturlashda «navbat» (queue) — kim birinchi kelsa, birinchi xizmat oladi.",a:"m07",
 start:function(){h19Row(5,{nums:'L'});h19Msg('Birinchi kelgan — birinchi chiqadi')},fin:function(){h19Row(5,{nums:'L'});h19Msg('Birinchi kelgan — birinchi chiqadi')},
 html:"<p>🖨 Printerga bir nechta hujjat yuborsangiz, u ularni <b>navbat bilan</b> chop etadi: qaysi biri birinchi kelsa — birinchi chiqadi. Dasturchilar buni «<b>navbat</b>» (inglizcha <i>queue</i>) deb ataydi.</p><p>📞 Call-markazga qo'ng'iroq qilganda ham, bankda chipta olganda ham — xuddi shu tartib. Siz o'rgangan «oldida», «orqasida» masalalari — aslida kompyuter fanining boshlanishi!</p>",
 tn:"Bolalarga «navbatni adolatli qilish uchun nima kerak?» deb savol bering — munozara yaxshi chiqadi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){var c={};c[4]=C.bad;h19Row(8,{col:c,lab:{4:'Siz'},nums:'B'});h19Msg('Ikki qator raqam')},fin:function(){var c={};c[4]=C.bad;h19Row(8,{col:c,lab:{4:'Siz'},nums:'B'});h19Msg('Ikki qator raqam')},
 html:"<div class='memo'><ul><li>«Oldida A, orqasida B» → jami = <b>A + B + 1</b>.</li><li>«Oldidan A-chi, orqadan B-chi» → jami = <b>A + B − 1</b>.</li><li>Orqadan o'rin = <b>jami − oldidan o'rin + 1</b>.</li><li>Orasida: avval <b>bir tomondan</b> sanang, keyin katta − kichik − 1.</li><li>O'rtada: ikki tomonida (jami − 1) : 2 kishi.</li><li>Oldidan chiqsa — o'rin kamayadi; orqadan chiqsa — o'zgarmaydi.</li><li>Har doim <b>chizing</b>!</li></ul></div>",
 tn:"Keyingi darsni «Zinapoyada Lola pastdan 5-, tepadan 9-pog'onada. Zinapoyada nechta pog'ona?» (13) savoli bilan boshlang."}
];
function h19Tap(){var c={};c[4]=C.bad;for(var i=1;i<=8;i++)if(S.tp&&S.tp[i])c[i]=i===4?C.bad:C.ok;h19Row(8,{col:c,lab:{4:'Siz'}});
 S.tp=S.tp||{};var hit=E('g',{},S.g);for(var j=1;j<=8;j++)(function(j){var r=E('rect',{x:S.px(j)-13,y:40,width:26,height:56,fill:'transparent',style:'cursor:pointer'},hit);r.addEventListener('click',function(){if(S.tp[j])return;S.tp[j]=1;var n=Object.keys(S.tp).length;h19Tap();T(S.g,S.px(j),112,String(n),{'font-size':12,'font-weight':800,fill:C.ok});h19Msg('Sanadingiz: <b>'+n+'</b>'+(n===8?' — hammasi ✓':''));if(n===8&&S.d1){S.d1();S.d1=null}})})(j)}
function h19Reset(){S.tp={}}
var PROBS=[
{t:"Navbatda Lolaning oldida 6, orqasida 4 kishi. Navbatda jami nechta kishi?",o:["11","10","9","12"],k:0,s:"6 + 4 + 1 = 11."},
{t:"Kamola kinoteatrda. Chap tomonida 13, o'ng tomonida 8 bola. Qatorda jami nechta bola?",o:["22","21","20","23"],k:0,s:"13 + 8 + 1 = 22."},
{t:"Poyezdda 9 vagon. Oldidan Alining vagoni 4-chi. Orqadan nechanchi?",o:["6-chi","5-chi","4-chi","7-chi"],k:0,s:"9 − 4 + 1 = 6."},
{t:"Ali navbatda oldidan 5-o'rinda, orqadan 8-o'rinda. Navbatda nechta kishi?",o:["12","13","11","14"],k:0,s:"5 + 8 − 1 = 12."},
{t:"Qatorda 15 bola. Ali chapdan 6-o'rinda, Vali o'ngdan 6-o'rinda. Ular orasida nechta bola?",o:["3","4","2","5"],k:0,s:"Vali chapdan 10-chi; 10 − 6 − 1 = 3."},
{t:"Bekatda 9 kishi qatorga turdi. Lola roppa-rosa o'rtada. Uning oldida nechta kishi?",o:["4","5","3","9"],k:0,s:"(9 − 1) : 2 = 4."},
{t:"Qatorda 10 bola. Ali chapdan 3-o'rinda. U o'ngdan nechanchi?",o:["8-o'rinda","7-o'rinda","9-o'rinda","3-o'rinda"],k:0,s:"10 − 3 + 1 = 8."},
{t:"Kinoteatrda Lola o'tirgan qatorning oldida 4 qator, orqasida 6 qator. Zalda jami nechta qator?",o:["11","10","9","15"],k:0,s:"4 + 6 + 1 = 11."},
{t:"Vali navbatda 7-o'rinda. Undan oldin turgan 3 kishi chiqib ketdi. Endi u nechanchi o'rinda?",o:["4-o'rinda","3-o'rinda","5-o'rinda","10-o'rinda"],k:0,s:"7 − 3 = 4."},
{t:"Ali navbatda 8-o'rinda. Uning orqasidagi 2 kishi chiqib ketdi. Ali endi nechanchi?",o:["8-o'rinda","6-o'rinda","10-o'rinda","7-o'rinda"],k:0,s:"Orqadagilar chiqsa, o'rin o'zgarmaydi."},
{t:"Lola navbatda oldidan 4-chi, orqadan 7-chi. Navbatda nechta kishi?",o:["10","11","12","9"],k:0,s:"4 + 7 − 1 = 10."},
{t:"Qatorda 12 bola. Anvar chapdan 3-chi, Bobur o'ngdan 3-chi. Orasida nechta bola?",o:["6","5","7","4"],k:0,s:"Bobur chapdan 10-chi; 10 − 3 − 1 = 6."},
{t:"Zinapoyada Lola pastdan 5-, tepadan 9-pog'onada. Zinapoyada nechta pog'ona?",o:["13","14","12","4"],k:0,s:"5 + 9 − 1 = 13."},
{t:"Navbatda 7 kishi bor edi. Ali oxiriga kelib turdi. U nechanchi o'rinda?",o:["8-o'rinda","7-o'rinda","1-o'rinda","9-o'rinda"],k:0,s:"7 kishidan keyin — 8-chi."},
{t:"Qatorda 11 bola turibdi. O'rtadagi bola chapdan nechanchi?",o:["6-chi","5-chi","7-chi","11-chi"],k:0,s:"Ikki tomonida 5 tadan: 5 + 1 = 6."},
{t:"Avtobusda Lola oldidan 3-qatorda, orqadan 6-qatorda o'tiribdi. Avtobusda nechta qator?",o:["8","9","10","7"],k:0,s:"3 + 6 − 1 = 8."},
{t:"Navbatda 10 kishi. Ali oldidan 4-chi. Uning orqasida nechta kishi?",o:["6","7","5","4"],k:0,s:"10 − 4 = 6."},
{t:"Qatorda Anvarning chap tomonida 5, o'ng tomonida 3 bola. Bobur Anvardan o'ngda 2-chi. Bobur o'ngdan nechanchi?",o:["2-chi","3-chi","1-chi","4-chi"],k:0,s:"Anvarning o'ngida 3 bola; Bobur ulardan 2-chi, uning o'ngida 1 bola qoladi — o'ngdan 2-chi."},
{t:"Navbatda Ali 6-o'rinda. Uning oldiga 2 kishi kirib oldi. Ali endi nechanchi?",o:["8-o'rinda","4-o'rinda","6-o'rinda","7-o'rinda"],k:0,s:"Oldiga qo'shilsa, o'rin ortadi: 6 + 2 = 8."},
{t:"Sinfda o'quvchilar bo'yiga qarab turdi. Zarina eng balanddan 4-chi, eng pastdan 9-chi. Sinfda nechta o'quvchi?",o:["12","13","11","14"],k:0,s:"4 + 9 − 1 = 12."}
];
function PRACT_STAGE(){var c={};c[4]=C.bad;h19Row(8,{col:c,lab:{4:'Siz'},nums:'B'});h19Msg('Chizib yeching')}
var PREP_DATA={teach:["Oldida/orqasida — jami = A + B + 1.","Oldidan/orqadan o'rin: jami − o'rin + 1.","Ikki tomondan o'rin → A + B − 1 (ikki marta sanaladi).","Orasida, o'rtada, navbatdan chiqish."],
 mist:["O'zini qo'shmaydi (6 + 4 = 10).","Ikki marta sanalganini ayirmaydi (5 + 8 = 13).","Orasidagilarni sanashda ikki tomondan sanalgan o'rinlarni aralashtiradi.","Orqadan chiqqanda ham o'rinni kamaytiradi."],
 need:["5–10 bola bilan jonli navbat.","Raqam kartochkalari (oldidan va orqadan)."],
 board:["<span class='w2'>[6] Lola [4] → 6 + 4 + 1 = 11</span>.","<span class='w2'>9 − 4 + 1 = 6</span>.","<span class='w2'>5 + 8 − 1 = 12</span>.","Orasida: <span class='w2'>10 − 6 − 1 = 3</span>.","O'rtada: <span class='w2'>(9 − 1) : 2 = 4</span>."]};
