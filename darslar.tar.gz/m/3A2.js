var CODE='3A2',TITLE='3-sinf · Sonlarni taqqoslash va yaxlitlash';
function c2(a,b,hl,sign){clear();w3heads();w3blocks(a,24,hl);w3blocks(b,98,hl);var g=S.g;E('line',{x1:10,y1:88,x2:350,y2:88,stroke:'#e6d6bd'},g);if(sign){E('circle',{cx:34,cy:88,r:13,fill:'#fff',stroke:C.blue,'stroke-width':2},g);T(g,34,94,sign,{'font-size':18,'font-weight':800,fill:C.blue})}}
var P1=[function(){c2(478,487);msg('478 va 487 — qaysi katta?')},function(){c2(478,487,'h');msg('1) Yuzliklar: 4 va 4 — teng')},function(){c2(478,487,'t');msg('2) O‘nliklar: 7 va 8 — 8 katta')},function(){c2(478,487,'t','<');msg('<b>478 < 487</b> — birliklarga qaramaymiz ham')}];
var P3=[function(){w3line(600,700,10,[[652,C.blue]],{big:50,fs:10});msg('652 ni yuzlikkacha yaxlitlaymiz: 600 ga yaqinmi yoki 700 ga?')},
 function(){w3line(600,700,10,[[652,C.blue],[650,C.a,'o‘rta: 650']],{big:50,fs:10});msg('O‘rtasi — 650. 652 o‘rtadan o‘ngda')},
 function(){w3line(600,700,10,[[652,C.blue],[700,C.ok]],{big:50,fs:10});arc3(652,700);msg('652 ≈ <b>700</b>. Qoida: o‘nliklar raqami 5 yoki undan katta — yuqoriga')}];
var P4=[function(){w3line(600,800,10,[[650,C.a],[749,C.a]],{big:50,fs:10});msg('Yuzlikkacha yaxlitlanganda 700 bo‘ladigan sonlar qayerda?')},
 function(){w3line(600,800,10,[[650,C.ok,'650'],[749,C.ok,'749']],{big:50,fs:10});Br(S.X(650),S.X(749),70,'',true,C.ok);msg('650 dan 749 gacha — hammasi ≈ 700')},
 function(){w3line(600,800,10,[[650,C.ok,'650'],[749,C.ok,'749'],[750,C.bad,'']],{big:50,fs:10});T(S.g,S.X(750)+18,62,'750 → 800',{'font-size':12,'font-weight':800,fill:C.bad});msg('749 − 650 + 1 = <b>100</b> ta son. 750 esa 800 ga yaxlitlanadi!')}];
function hid2(d){clear();var g=S.g,ok=d==='8'||d==='9',bad=d==='7';T(g,180,60,'5'+d+'4  >  583',{'font-size':40,'font-weight':800,fill:bad?C.bad:(ok?C.ok:'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'});
 [['5','5','teng'],[d,'8',d==='□'?'?':(d==='7'?'7 < 8':(d==='8'?'teng':'9 > 8'))],['4','3',d==='8'?'4 > 3 ✓':'']].forEach(function(r,i){var x=110+i*70;E('rect',{x:x-28,y:88,width:56,height:62,rx:8,fill:['#e1f4f2','#fdf0e1','#ede7fb'][i],stroke:'#c9d3dd'},g);T(g,x,110,r[0]+' | '+r[1],{'font-size':16,'font-weight':800,fill:'#1d2b3a'});T(g,x,136,r[2],{'font-size':11,'font-weight':700,fill:'#5b6b7b'})});
 if(d==='□')msg('Xonama-xona solishtiramiz: yuzliklar → o‘nliklar → birliklar')}
function arc3(a,b){var X=S.X;E('path',{d:'M'+X(a)+' 90 Q'+(X(a)+X(b))/2+' 54 '+X(b)+' 90',fill:'none',stroke:C.ok,'stroke-width':2},S.g)}
var STEPS=[
{h:"Taqqoslash: yuqori xonadan boshlaymiz",sum:"478 va 487: yuzliklar teng → o'nliklar 7 < 8 → 478 < 487.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Uch xonali sonlarni taqqoslash tartibi: <b>yuzliklar → o'nliklar → birliklar</b>. Birinchi farq qilgan xona javobni hal qiladi. Kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Yuzliklar teng bo'lsa — o'nliklarga o'tamiz; o'nliklar ham teng bo'lsa — birliklarga. Farq topilgan joyda to'xtaymiz.</p>",
 q:{t:"Qaysi yozuv noto'g'ri?",opts:["711 > 117","640 > 599","329 < 239","478 < 487"],ok:2,why:"329 da 3 yuzlik, 239 da 2 yuzlik — 329 katta.",hint:"Har bir juftda avval yuzliklarni solishtiring.",full:"329 va 239: yuzliklar 3 > 2, demak 329 > 239. «329 < 239» noto'g'ri. Qolganlari to'g'ri."},
 tn:"Bank savoli (3207) shu turdagi kartochkalar bilan. Ikki sonni ustma-ust yozdirib, xonalarni chiziq bilan ajrating."},
{h:"Tuzoq: yashiringan raqam",sum:"5□4 > 583: □ = 8 ham to'g'ri (584 > 583), demak eng kichik raqam — 8.",a:"m02",
 start:function(){hid2('□')},fin:function(){hid2('8')},
 html:"<p>«<b>5□4 &gt; 583</b>. □ o'rniga qo'yish mumkin bo'lgan <b>eng kichik</b> raqam qaysi?» Ko'pchilik shoshib 9 deydi. Tanlang:</p>",
 btns:w3choose(["7","8","9"],1,function(){hid2('8');msg('584 > 583 ✓ — o‘nliklar teng bo‘lsa ham birliklar 4 > 3')},function(i){if(i===0){hid2('7');msg('574 < 583 — o‘nliklar 7 < 8. Kattaroq kerak')}else{hid2('9');msg('594 > 583 to‘g‘ri, lekin bu eng kichigi emas! Kichikrog‘ini sinang')}}),g3:1,
 after:"<p>Yuzliklar teng (5 = 5). O'nliklar: □ va 8. Agar □ = 8 bo'lsa — o'nliklar ham teng, birliklarga o'tamiz: <b>4 &gt; 3</b> ✓. Demak 8 ham mos keladi. Javob: <b>8</b> (mos raqamlar: 8 va 9).</p>",
 q:{t:"7□5 < 738. □ o'rniga nechta raqam qo'yish mumkin?",opts:["3 ta (0, 1, 2)","4 ta (0, 1, 2, 3)","2 ta (1, 2)","6 ta (4, 5, … 9)"],ok:1,why:"705, 715, 725, 735 — hammasi 738 dan kichik: 4 ta.",hint:"□ = 3 ni alohida tekshiring: 735 va 738.",full:"Yuzliklar teng. □ = 0, 1, 2 — o'nliklar 3 dan kichik ✓. □ = 3 — o'nliklar teng, birliklar 5 < 8 ✓. □ = 4 — 745 > 738 ✗. Demak 0, 1, 2, 3 — 4 ta. «3 ta» — chegaradagi 3 ni unutish, «2 ta» — 0 ni unutish."},
 tn:"Tuzoq: bola eng katta xonani teng ko'rib, darrov «kattaroq raqam kerak» deydi. Chegaraviy raqamni (8) albatta tekshirtiring."},
{h:"Ifodalarni taqqoslash",sum:"458 + 376 = 834, 297 + 539 = 836 → 834 < 836, farq 2.",a:"m03",
 start:function(){S.e1=0;S.e2=0;exp2(0)},fin:function(){S.e1=1;S.e2=1;exp2(2)},
 html:"<p>«458 + 376 ○ 297 + 539». Avval ikkala ifodani hisoblang, keyin solishtiring:</p>",
 btns:[["Chapni hisoblash",function(c,done){S.e1=1;exp2(S.e2?2:1);if(S.e2)done()}],["O'ngni hisoblash",function(c,done){S.e2=1;exp2(S.e1?2:3);if(S.e1)done()},'u']],g2:1,
 after:"<p>834 &lt; 836. Bank testlarida yana «qanchaga farq qiladi?» deb so'raladi: 836 − 834 = <b>2</b>. Ehtiyot bo'ling: farqni noto'g'ri ishora bilan tanlamang.</p>",
 q:{t:"742 − 368 ○ 615 − 247. Qaysi javob to'g'ri?",opts:["< (chap 6 ta kichik)","> (chap 6 ta katta)","= (teng)","> (chap 16 ta katta)"],ok:1,why:"742 − 368 = 374, 615 − 247 = 368. 374 > 368, farq 6.",hint:"Ikkala ayirmani alohida hisoblang.",full:"Chap: 742 − 368 = 374. O'ng: 615 − 247 = 368. 374 − 368 = 6. Demak chap 6 ta katta: «>»."},
 tn:"Kuchli o'quvchilarga hisoblamasdan taqqoslashni ko'rsating: 458 + 376 va 297 + 539 da 458 dan 297 ga — 161 kamaydi, 376 dan 539 ga — 163 oshdi."},
{h:"Yuzlikkacha yaxlitlash",sum:"652 ≈ 700: o'nliklar raqami 5 yoki katta bo'lsa — yuqoriga, kichik bo'lsa — pastga.",a:"m04",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Yaxlitlash — sonni unga eng <b>yaqin</b> «yumaloq» son bilan almashtirish. Son o'qida ko'raylik:</p>",
 btns:[phaser(P3)],
 after:"<p>Yuzlikkacha yaxlitlashda faqat <b>o'nliklar raqamiga</b> qaraymiz: 0–4 → pastga, 5–9 → yuqoriga. 652 (o'nlik 5) → 700; 648 (o'nlik 4) → 600.</p>",
 q:{t:"Qaysi son yuzlikkacha yaxlitlanganda 700 bo'lmaydi?",opts:["749","652","698","750"],ok:3,why:"750 ning o'nliklari 5 — yuqoriga: 800.",hint:"Har birining o'nliklar raqamiga qarang: 5 va undan katta bo'lsa — yuqoriga.",full:"749 → 700 (o'nlik 4, 749 da yuzlik 7). 652 → 700. 698 → 700. 750 → 800. Javob: 750."},
 tn:"O'nlikkacha yaxlitlash 2-sinfda o'tilgan — qoidasi bir xil, faqat qaraladigan xona o'zgaradi."},
{h:"Tuzoq: nechta son yaxlitlanadi?",sum:"700 ga yaxlitlanadigan uch xonali sonlar: 650 dan 749 gacha — 100 ta.",a:"m05",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«Yuzlikkacha yaxlitlanganda <b>700</b> bo'ladigan nechta uch xonali son bor?» Chegaralarni topamiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Eng kichigi — <b>650</b> (yuqoriga), eng kattasi — <b>749</b> (pastga). «Dan … gacha»: 749 − 650 + 1 = <b>100</b>. 99 yoki 101 deganlar chegarani noto'g'ri sanagan.</p>",
 q:{t:"O'nlikkacha yaxlitlanganda 80 bo'ladigan sonlar nechta?",opts:["9","11","10","5"],ok:2,why:"75, 76, … 84 — 10 ta.",hint:"Eng kichigi va eng kattasi qaysi? 75 yuqoriga, 84 pastga.",full:"75 dan 84 gacha: 84 − 75 + 1 = 10 ta. 85 — 90 ga ketadi, 74 — 70 ga."},
 tn:"Bank (2233) savoli. Son o'qida chegaralarni rangli belgilang."},
{h:"Yaxlitlab chamalash",sum:"Yaxlitlab tez chamalaymiz: 398 + 205 ≈ 400 + 200 = 600.",a:"m06",
 start:function(){est(0)},fin:function(){est(2)},
 html:"<p>Hayotda aniq hisobdan oldin <b>chamalash</b> kerak: «pulim yetadimi?». 398 + 205 ni chamalang:</p>",
 btns:[["Yaxlitlash",function(c,done){est(1);mvK(done,2)}],["Aniq hisob",function(c,done){est(2);mvK(done,2)},'u']],g2:1,
 after:"<p>Chamalash: 400 + 200 = 600. Aniq: 603. Javob 600 ga yaqin — demak hisobda katta xato yo'q. Chamalash xatoni tutib olish uchun eng yaxshi usul!</p>",
 q:{t:"Dilshodda 900 so'm bor. 486 so'mlik va 395 so'mlik narsa olsa, puli yetadimi?",opts:["Yetmaydi","Yetadi, 19 so'm qoladi","Yetadi, 119 so'm qoladi","Aynan 900 so'm"],ok:1,why:"486 + 395 = 881 ≤ 900, qoladi 19.",hint:"Avval chamalang: 500 + 400. Keyin aniq hisoblang.",full:"Chamalash: ≈ 900. Aniq: 486 + 395 = 881. 900 − 881 = 19 so'm qoladi."},
 tn:"Do'kon o'yini: narxlarni yaxlitlab tez chamalash va keyin aniq hisoblash."},
{h:"Bilasizmi? Yaxlitlash hayotda",sum:"Aholi soni, masofa, narx — ko'pincha yaxlitlangan holda aytiladi.",a:"m07",
 start:function(){msgL()},fin:function(){msgL()},
 html:"<p>📰 Gazetalarda «stadionga <b>40 mingga yaqin</b> muxlis keldi» deb yoziladi — bu yaxlitlangan son. Aniq son 39 847 bo'lishi mumkin.</p><p>🗺 Toshkentdan Samarqandgacha «taxminan 300 km» deyiladi.</p><p>⭐ Yaxlitlash qoidasi (5 dan boshlab yuqoriga) butun dunyoda bir xil.</p>",
 tn:"Bolalar gazeta yoki yangiliklardan yaxlitlangan sonlar topib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){c2(478,487,'t','<')},fin:function(){c2(478,487,'t','<')},
 html:"<div class='memo'><ul><li>Taqqoslash: <b>yuzliklar → o'nliklar → birliklar</b>, birinchi farq hal qiladi.</li><li>Ifodalarni taqqoslash: avval hisoblang, «qanchaga» so'ralsa — ayirmani toping.</li><li>Yuzlikkacha yaxlitlash: o'nliklar raqami 0–4 → pastga, 5–9 → yuqoriga. 652 ≈ 700.</li><li>700 ga yaxlitlanadiganlar: 650…749 — <b>100</b> ta.</li><li>Chamalash: yaxlitlab tez hisoblab, natijani tekshiring.</li></ul></div>",
 tn:"Keyingi dars — Rim raqamlari."}
];
function exp2(k){clear();var g=S.g;T(g,90,60,'458 + 376',{'font-size':22,'font-weight':800});T(g,270,60,'297 + 539',{'font-size':22,'font-weight':800});T(g,180,60,'○',{'font-size':26,fill:C.blue});
 if(S.e1)T(g,90,100,'= 834',{'font-size':22,'font-weight':800,fill:C.ok});if(S.e2)T(g,270,100,'= 836',{'font-size':22,'font-weight':800,fill:C.ok});
 if(S.e1&&S.e2){T(g,180,104,'<',{'font-size':30,'font-weight':800,fill:C.blue});T(g,180,145,'farq: 836 − 834 = 2',{'font-size':14,'font-weight':800,fill:C.blue})}msg(S.e1&&S.e2?'834 < 836':'Ikkala ifodani hisoblang')}
function est(k){clear();var g=S.g;T(g,180,50,'398 + 205',{'font-size':26,'font-weight':800});if(k>=1)T(g,180,92,'≈ 400 + 200 = 600',{'font-size':20,'font-weight':800,fill:C.a2});if(k>=2)T(g,180,132,'aniq: 603',{'font-size':20,'font-weight':800,fill:C.ok});msg(k===0?'Avval chamalang':(k===1?'Chamalash: 600 atrofida':'Aniq javob 603 — chamaga yaqin ✓'))}
function msgL(){clear('#f6ead0');T(S.g,180,70,'39 847 ≈ 40 000',{'font-size':28,'font-weight':800,fill:'#6b3d12'});T(S.g,180,110,'«40 mingga yaqin»',{'font-size':16,fill:'#6b3d12'});msg('Yaxlitlangan son — tez tushuniladi')}
var PROBS=[
{t:"Qaysi son eng katta?",o:["805","580","850","508"],k:0,s:"Yuzliklar: 8, 5, 8, 5. 805 va 850 — o'nliklar 0 va 5… 850 katta! "},
{t:"Belgini qo'ying: 609 ... 690",o:["<",">","="],k:0,s:"Yuzliklar teng, o'nliklar 0 < 9: 609 < 690."},
{t:"Qaysi yozuv noto'g'ri?",o:["329 < 239","711 > 117","640 > 599","478 < 487"],k:0,s:"329 > 239, chunki 3 yuzlik > 2 yuzlik."},
{t:"458 + 376 ○ 297 + 539: qaysi to'g'ri?",o:["< (chap 2 ta kichik)","= (teng)","> (chap 2 ta katta)","< (chap 12 ta kichik)"],k:0,s:"834 va 836: chap 2 ta kichik."},
{t:"742 − 368 ○ 615 − 247: qaysi to'g'ri?",o:["> (chap 6 ta katta)","< (chap 6 ta kichik)","= (teng)","> (chap 16 ta katta)"],k:0,s:"374 va 368: chap 6 ta katta."},
{t:"467 ni yuzlikkacha yaxlitlang.",o:["500","400","470","460"],k:0,s:"O'nliklar 6 — yuqoriga: 500."},
{t:"832 ni yuzlikkacha yaxlitlang.",o:["800","900","830","840"],k:0,s:"O'nliklar 3 — pastga: 800."},
{t:"Qaysi son yuzlikkacha yaxlitlanganda 700 bo'lmaydi?",o:["750","749","652","698"],k:0,s:"750 → 800."},
{t:"Yuzlikkacha yaxlitlanganda 700 bo'ladigan uch xonali sonlar nechta?",o:["100","99","101","50"],k:0,s:"650…749: 100 ta."},
{t:"O'nlikkacha yaxlitlanganda 340 bo'ladigan eng kichik son?",o:["335","330","336","344"],k:0,s:"335 → 340 (birlik 5 — yuqoriga)."},
{t:"O'nlikkacha yaxlitlanganda 340 bo'ladigan eng katta son?",o:["344","345","349","340"],k:0,s:"344 → 340; 345 → 350."},
{t:"Sonlarni o'sish tartibida joylang: 506, 560, 605, 650.",o:["506, 560, 605, 650","650, 605, 560, 506","560, 506, 650, 605","506, 605, 560, 650"],k:0,s:"Yuzliklar, keyin o'nliklar bo'yicha."},
{t:"4□7 > 468 bo'lishi uchun □ o'rniga qaysi raqamlar to'g'ri keladi?",o:["7, 8, 9","6, 7, 8, 9","8, 9","faqat 9"],k:0,s:"□ = 6: 467 < 468 ✗; 7, 8, 9 ✓."},
{t:"□35 < 435 bo'lishi uchun □ o'rniga nechta raqam qo'yish mumkin (uch xonali son)?",o:["3","4","5","2"],k:0,s:"1, 2, 3 — 3 ta (0 bo'lmaydi, 4 — teng)."},
{t:"398 + 205 ni chamalang.",o:["≈ 600","≈ 500","≈ 700","≈ 400"],k:0,s:"400 + 200 = 600."},
{t:"Dilshodda 900 so'm. 486 va 395 so'mlik narsa olsa, qancha qoladi?",o:["19 so'm","119 so'm","Yetmaydi","9 so'm"],k:0,s:"486 + 395 = 881, 900 − 881 = 19."},
{t:"Qaysi son 600 ga eng yaqin?",o:["598","610","589","615"],k:0,s:"598 — 2 qadam, 610 — 10, 589 — 11, 615 — 15."},
{t:"Eng katta uch xonali son va eng kichik uch xonali son farqi?",o:["899","900","999","889"],k:0,s:"999 − 100 = 899."},
{t:"Raqamlari 3, 7, 1 bo'lgan eng katta son eng kichigidan qancha katta?",o:["594","604","584","694"],k:0,s:"731 − 137 = 594."},
{t:"Qaysi juftlikda ikkala son yuzlikkacha yaxlitlanganda bir xil bo'ladi?",o:["551 va 649","549 va 551","449 va 551","650 va 749… emas: 650 va 751"],k:0,s:"551 → 600, 649 → 600 ✓. 549 → 500, 551 → 600."}
];
PROBS[0]={t:"Qaysi son eng katta?",o:["850","805","580","508"],k:0,s:"Yuzliklar 8 bo'lganlar: 850 va 805; o'nliklar 5 > 0 — 850."};
PROBS[19]={t:"Qaysi juftlikda ikkala son yuzlikkacha yaxlitlanganda bir xil bo'ladi?",o:["551 va 649","549 va 551","449 va 551","650 va 751"],k:0,s:"551 → 600, 649 → 600 ✓. Boshqalarda farq qiladi."};
function PRACT_STAGE(){c2(478,487,'t','<')}
var PREP_DATA={teach:["Uch xonali sonlarni xonama-xona taqqoslash.","Ifodalarni taqqoslash va farqini topish.","Yuzlikkacha (va o'nlikkacha) yaxlitlash, chegaradagi sonlar soni.","Yaxlitlab chamalash."],mist:["Birinchi farq qilgan xona o'rniga oxirgi raqamga qaraydi.","750 ni 700 ga yaxlitlaydi.","700 ga yaxlitlanadiganlarni 99 yoki 101 deb sanaydi.","Ifodani hisoblamay, birinchi sonlarga qarab taqqoslaydi."],need:["Son o'qi (600–800), raqam kartochkalari."],board:["<span class='w2'>478 < 487</span>: yuzlik =, o'nlik 7 < 8.","<span class='w2'>834 < 836</span>, farq 2.","<span class='w2'>652 ≈ 700</span>, <span class='w2'>648 ≈ 600</span>.","<span class='w2'>650 … 749</span> — 100 ta.","<span class='w2'>398 + 205 ≈ 600</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
