var CODE='2H07',TITLE="2-sinf · Taqqoslash va tartiblash (kim baland, kim kichik)";
function h7Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ustunlar: [{n:'Ali',h:3,col}] — h: 1..6 nisbiy balandlik
function h7Bars(list,o){o=o||{};clear();var g=S.g,n=list.length,w=Math.min(52,300/n-10),gap=(330-n*w)/(n+1),base=146;
 E('line',{x1:14,y1:base,x2:346,y2:base,stroke:'#33475b','stroke-width':2},g);
 list.forEach(function(p,i){var x=15+gap+i*(w+gap),h=p.h*20;E('rect',{x:x,y:base-h,width:w,height:h,rx:6,fill:p.col||C.b,stroke:C.line,'stroke-width':1.4},g);T(g,x+w/2,base+16,p.n,{'font-size':11,'font-weight':800,fill:'#1d2b3a'});if(p.lab)T(g,x+w/2,base-h-6,p.lab,{'font-size':11,'font-weight':800,fill:C.blue})});
 if(o.arrow)T(g,180,16,o.arrow,{'font-size':12,'font-weight':800,fill:C.blue})}
var P1=[function(){h7Bars([{n:'Vali',h:3}]);h7Msg('Boshlaymiz: Vali')},
 function(){h7Bars([{n:'Vali',h:3},{n:'Ali',h:4.5,col:C.a}]);h7Msg('«Ali Validan baland» → Ali Validan yuqorida')},
 function(){h7Bars([{n:'Sardor',h:1.8,col:C.c},{n:'Vali',h:3},{n:'Ali',h:4.5,col:C.a}]);h7Msg('«Vali Sardordan baland» → Sardor Validan past. Eng baland — <b>Ali</b>, eng past — <b>Sardor</b>')}];
var P3=[function(){h7Bars([{n:'Bobur',h:3}]);h7Msg('1) Anvar Boburdan past')},
 function(){h7Bars([{n:'Anvar',h:2},{n:'Bobur',h:3}]);h7Msg('2) Bobur Davrondan past')},
 function(){h7Bars([{n:'Anvar',h:2},{n:'Bobur',h:3},{n:'Davron',h:4}]);h7Msg('3) Eldor Anvardan past')},
 function(){h7Bars([{n:'Eldor',h:1,col:C.c},{n:'Anvar',h:2},{n:'Bobur',h:3},{n:'Davron',h:4}]);h7Msg('4) Farrux Davrondan baland')},
 function(){h7Bars([{n:'Eldor',h:1,col:C.c},{n:'Anvar',h:2},{n:'Bobur',h:3,col:C.ok,lab:'3-o‘rin'},{n:'Davron',h:4},{n:'Farrux',h:5,col:C.a}]);h7Msg('Tartib: Eldor, Anvar, <b>Bobur</b>, Davron, Farrux. O‘rtada — Bobur')}];
var P5=[function(){h7Bars([{n:'Madina',h:3}]);h7Msg('Yoshlari har xil. «Nodira Madinadan katta EMAS»')},
 function(){h7Bars([{n:'Nodira',h:2},{n:'Madina',h:3}]);h7Msg('Yoshlar har xil, «katta emas» → demak Nodira Madinadan <b>kichik</b>')},
 function(){h7Bars([{n:'Sevara',h:1,col:C.c},{n:'Nodira',h:2},{n:'Madina',h:3,col:C.a}]);h7Msg('«Sevara Nodiradan katta emas» → Sevara eng kichik. Kattadan: Madina, Nodira, Sevara')}];
var P6=[function(){h7Line({Vali:0});h7Msg('Vali — 0 nuqtada deylik (santimetrlar o‘qi)')},
 function(){h7Line({Vali:0,Ali:2});h7Msg('«Ali Validan 2 sm baland» → Ali +2')},
 function(){h7Line({Vali:0,Ali:2,Sardor:3});h7Msg('«Vali Sardordan 3 sm past» → Sardor +3. Sardor Alidan <b>3 − 2 = 1 sm</b> baland')}];
function h7Line(m){clear();var g=S.g,x0=40,k=50,y=110;E('line',{x1:20,y1:y,x2:340,y2:y,stroke:'#33475b','stroke-width':2},g);for(var v=-0;v<=5;v++){E('line',{x1:x0+v*k,y1:y-6,x2:x0+v*k,y2:y+6,stroke:'#33475b'},g);T(g,x0+v*k,y+22,v+' sm',{'font-size':10,fill:'#5b6b7b'})}
 var cols={Vali:C.b,Ali:C.a,Sardor:C.c};Object.keys(m).forEach(function(n,i){var x=x0+m[n]*k;E('circle',{cx:x,cy:y,r:8,fill:cols[n],stroke:'#fff','stroke-width':2},g);T(g,x,y-16-(i%2)*14,n,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});T(g,320,y-40,'baland →',{'font-size':11,'font-weight':800,fill:C.ok})}
var P7=[function(){h7Houses([]);h7Msg('5 ta uy. Shartlarni bittalab qo‘yamiz')},
 function(){h7Houses([[4,'oq']]);h7Msg('1) Oq uy eng o‘ngda')},
 function(){h7Houses([[4,'oq'],[0,'sariq'],[1,'ko‘k']]);h7Msg('2) Sariq — ko‘kdan chapda, ko‘k — qizildan chapda, qizil — yashildan chapda: tartib sariq, ko‘k, qizil, yashil')},
 function(){h7Houses([[4,'oq'],[0,'sariq'],[1,'ko‘k'],[2,'qizil'],[3,'yashil']],2);h7Msg('O‘rtadagi (3-) uy — <b>qizil</b>')}];
var HC={'oq':'#ffffff','sariq':'#ffd54d','ko‘k':'#5aa9e6','qizil':'#e85a5a','yashil':'#4caf72'};
function h7Houses(list,hl){clear();var g=S.g;for(var i=0;i<5;i++){var x=22+i*66,c=null,nm='?';list.forEach(function(p){if(p[0]===i){c=HC[p[1]];nm=p[1]}});
  E('path',{d:'M'+x+' 80 L'+(x+26)+' 52 L'+(x+52)+' 80 Z',fill:'#b46a3c',stroke:C.line},g);E('rect',{x:x+4,y:80,width:44,height:46,fill:c||'#eef2f6',stroke:hl===i?C.bad:C.line,'stroke-width':hl===i?3:1.4},g);T(g,x+26,148,nm,{'font-size':11,'font-weight':800,fill:'#1d2b3a'});T(g,x+26,164,(i+1)+'-',{'font-size':9,fill:'#9aa8b6'})}
 T(g,30,30,'← chap',{'font-size':11,fill:C.blue,'font-weight':800});T(g,330,30,'o‘ng →',{'font-size':11,fill:C.blue,'font-weight':800})}
var STEPS=[
{h:"Zanjir: ikki taqqoslashdan bitta tartib",sum:"Ali > Vali, Vali > Sardor → Ali > Vali > Sardor. Eng baland — Ali.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p><i>«Ali Validan baland. Vali Sardordan baland. Eng baland kim? Eng past kim?»</i> Har bir gapni rasmga aylantiramiz.</p>",
 btns:[phaser(P1,'▶ Keyingi gap')],
 after:"<p>Agar Ali Validan, Vali esa Sardordan baland bo'lsa, Ali Sardordan ham <b>albatta</b> baland. Bu — <b>zanjir</b>: Ali &gt; Vali &gt; Sardor.</p>",
 q:{t:"Ali Validan og'ir. Sardor Alidan og'ir. Vali G'anidan og'ir. Eng yengil kim?",opts:["Vali","G'ani","Ali","Sardor"],ok:1,why:"Sardor > Ali > Vali > G'ani — eng yengil G'ani.",hint:"Hammasini bitta zanjirga tering: kim kimdan og'ir?",full:"Sardor > Ali (2-gap), Ali > Vali (1-gap), Vali > G'ani (3-gap). Zanjir: Sardor > Ali > Vali > G'ani. Eng yengil — G'ani."},
 tn:"Bolalarni bo'y bo'yicha qatorga turg'izib, «kim kimdan baland?» gaplarini o'zlari tuzsin."},
{h:"Bir gap — ikki xil aytish",sum:"«Anvar Boburdan past» = «Bobur Anvardan baland». Gapni bir xil yo'nalishga aylantiring.",a:"m02",
 start:function(){h7Bars([{n:'Anvar',h:2},{n:'Bobur',h:3.5}]);h7Msg('«Anvar Boburdan <b>past</b>»')},fin:function(){h7Bars([{n:'Anvar',h:2},{n:'Bobur',h:3.5,col:C.a}]);h7Msg('= «Bobur Anvardan <b>baland</b>»')},
 html:"<p>Masalada «baland» ham, «past» ham aralash keladi. Ularni bir xil so'zga aylantirsak, oson bo'ladi. Tugmani bosing:</p>",
 btns:[["⇄ Teskari aytish",function(c,done){h7Bars([{n:'Anvar',h:2},{n:'Bobur',h:3.5,col:C.a}]);h7Msg('«Anvar Boburdan past» = «Bobur Anvardan <b>baland</b>» — rasm o‘zgarmadi!');done()}]],
 after:"<p>Rasm bir xil qoldi — faqat aytish usuli o'zgardi. «Past» ↔ «baland», «yengil» ↔ «og'ir», «kichik» ↔ «katta», «oldin» ↔ «keyin».</p>",
 q:{t:"«Qovun tarvuzdan yengil» gapi qaysi gap bilan bir xil?",opts:["Tarvuz qovundan yengil","Tarvuz qovundan og'ir","Qovun tarvuzdan og'ir","Ular teng"],ok:1,why:"Qovun yengil bo'lsa, tarvuz og'ir.",hint:"Ikkala nomni almashtiring va «yengil» ni teskarisiga aylantiring.",full:"«Qovun tarvuzdan yengil» — demak tarvuz og'irroq: «Tarvuz qovundan og'ir». Nomlar ham, so'z ham almashadi."},
 tn:"Doskaga juftlarni yozing: past–baland, yengil–og'ir, kichik–katta, oldin–keyin, chap–o'ng."},
{h:"Ko'p kishi: tartib chizig'i",sum:"Har gapni chiziqqa qo'yamiz: Eldor, Anvar, Bobur, Davron, Farrux — o'rtada Bobur.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=4;P3[4]()},
 html:"<p><i>«Anvar Boburdan past. Bobur Davrondan past. Eldor Anvardan past. Farrux Davrondan baland. Bo'y bo'yicha tizilganda o'rtada kim turadi?»</i></p>",
 btns:[phaser(P3,'▶ Keyingi gap')],
 after:"<p>Usul: birinchi kishini o'rtaga qo'yamiz, har bir gapda yangi kishini to'g'ri tomonga qo'shamiz. Oxirida 5 kishining o'rtasi — 3-o'rin: <b>Bobur</b>.</p>",
 q:{t:"To'rtta qalam: qizil ko'kdan uzun, yashil qizildan uzun, sariq yashildan uzun. Eng qisqa qalam qaysi?",opts:["qizil","yashil","ko'k","sariq"],ok:2,why:"Sariq > yashil > qizil > ko'k.",hint:"Ko'k qalamdan uzunroq qalam bormi? Ko'kdan qisqasi-chi?",full:"Ko'k < qizil < yashil < sariq. Eng qisqa — ko'k."},
 tn:"Bolalarni 5 tasini tashqariga chiqarib, gaplar bo'yicha joylashtiring — sinf «yechimni» tirik ko'radi."},
{h:"O'zingiz tering",sum:"Og'irdan yengilga: Sardor, Ali, Vali, G'ani.",a:"m04",
 start:function(){h7Ord([])},fin:function(){h7Ord(['Sardor','Ali','Vali','G‘ani'])},
 html:"<p>Ali Validan og'ir. Sardor Alidan og'ir. Vali G'anidan og'ir. Ismlarni <b>eng og'iridan</b> boshlab bosing:</p><div class='h7b' style='display:flex;flex-wrap:wrap;gap:6px;margin:8px 0'></div>",
 act:function(c,done){var box=c.querySelector('.h7b'),need=['Sardor','Ali','Vali','G‘ani'],got=[];box.innerHTML='';['Vali','G‘ani','Sardor','Ali'].forEach(function(v){var b=document.createElement('button');b.textContent=v;b.style.cssText='padding:9px 14px;border-radius:10px;border:1px solid #dde5ee;background:#fff;font-size:16px;font-weight:700';b.onclick=function(){if(b.disabled)return;if(v===need[got.length]){got.push(v);b.disabled=true;b.style.background='#e6f6ee';h7Ord(got);if(got.length===4)done()}else{b.style.background='#fdeaea';setTimeout(function(){b.style.background='#fff'},1200);h7Msg('Bu hali eng og‘iri emas. Kimdan og‘irroq odam bor?')}};box.appendChild(b)})},
 after:"<p>Har safar <b>qolganlarning eng og'irini</b> topamiz: undan og'ir hech kim yo'q bo'lgan odam. Sardordan og'ir odam aytilmagan — u birinchi.</p>",
 q:{t:"Tarvuz qovundan og'ir, qovun ananasdan og'ir, ananas olmadan og'ir. Og'irligi bo'yicha 2-o'rinda qaysi?",opts:["tarvuz","qovun","ananas","olma"],ok:1,why:"Tarvuz > qovun > ananas > olma — 2-o'rinda qovun.",hint:"Avval eng og'irini toping, keyin uning ortidan kelganini.",full:"Tartib: tarvuz, qovun, ananas, olma. 2-o'rinda — qovun."},
 tn:"Tarozi bilan haqiqiy mevalarni solishtirish — eng yaxshi kirish."},
{h:"Tuzoq: «katta emas»",sum:"Yoshlar har xil bo'lsa, «katta emas» = «kichik». Madina > Nodira > Sevara.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p><i>«Nodira, Sevara va Madinaning yoshlari har xil. Nodira Madinadan katta emas, Sevara Nodiradan katta emas. Ularni kattasidan boshlab tering.»</i></p>",
 btns:[phaser(P5)],
 after:"<p>«Katta emas» — bu «kichik yoki teng». Yoshlar <b>har xil</b> deyilgani uchun «teng» bo'lmaydi — demak <b>kichik</b>. Tartib: Madina, Nodira, Sevara.</p>",
 q:{t:"Uchta qutining og'irligi har xil. A quti B dan yengil emas. C quti A dan og'ir emas. Eng og'iri qaysi?",opts:["B","C","A","Hammasi teng"],ok:2,why:"A > B va A > C — eng og'iri A.",hint:"«Yengil emas» — demak og'ir (og'irliklar har xil). «Og'ir emas» — demak yengil.",full:"A B dan yengil emas → A > B. C A dan og'ir emas → C < A. Demak eng og'iri — A. «Hammasi teng» — shartga zid: og'irliklar har xil."},
 tn:"«Emas» so'zi bor gaplarni avval oddiy gapga aylantirib, keyin chizing."},
{h:"Farqlar bilan: necha sm baland?",sum:"Ali Validan 2 sm baland, Sardor Validan 3 sm baland → Sardor Alidan 1 sm baland.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p><i>«Ali Validan 2 sm baland. Vali Sardordan 3 sm past. Ali va Sardordan qaysi biri baland va qanchaga?»</i> Hammasini bitta o'lchov chizig'iga qo'yamiz.</p>",
 btns:[phaser(P6)],
 after:"<p>Validan hisoblaymiz: Ali +2, Sardor +3. Demak Sardor Alidan <b>1 sm</b> baland. «5 sm» deganlar ikkala sonni qo'shib yuborgan.</p>",
 q:{t:"Lola Malikadan 4 yosh katta, Malika Nodiradan 1 yosh katta. Lola Nodiradan necha yosh katta?",opts:["3","5","4","1"],ok:1,why:"Nodira 0 deylik: Malika +1, Lola +1 + 4 = +5.",hint:"Nodirani chiziqning boshiga qo'ying. Malika qayerda? Lola-chi?",full:"Nodira — 0. Malika undan 1 yosh katta — 1. Lola Malikadan 4 yosh katta — 5. Lola Nodiradan 5 yosh katta. Bu yerda ikkalasi bir tomonga — qo'shiladi."},
 tn:"Farqlar bir tomonga bo'lsa qo'shiladi, qarama-qarshi bo'lsa ayiriladi. Buni son o'qida ko'rsatish shart."},
{h:"Joylashuv: chap va o'ng",sum:"Sariq, ko'k, qizil, yashil, oq — o'rtadagi uy qizil.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p><i>«Qatorda 5 ta uy. Qizil uy ko'k uydan o'ngda, yashil uy qizildan o'ngda, sariq uy ko'kdan chapda, oq uy eng o'ngda. O'rtadagi uy qanday rangda?»</i></p>",
 btns:[phaser(P7,'▶ Keyingi shart')],
 after:"<p>Eng aniq shartdan boshladik: «oq — eng o'ngda». Qolgan to'rttasi zanjir: sariq — ko'k — qizil — yashil. O'rtadagi 3-uy — <b>qizil</b>.</p>",
 q:{t:"Javonda 4 ta kitob: ertak, she'r, qomus, lug'at. Ertak eng chapda, lug'at eng o'ngda. Qomus she'rdan chapda. Chapdan 2-kitob qaysi?",opts:["qomus","she'r","lug'at","ertak"],ok:0,why:"Ertak, qomus, she'r, lug'at.",hint:"Avval eng aniq ikki shartni qo'ying: chetdagilar. O'rtada kimlar qoladi?",full:"Ertak — 1-joy, lug'at — 4-joy. O'rtada qomus va she'r: qomus she'rdan chapda, demak qomus — 2, she'r — 3."},
 tn:"Doskaga 5 ta katak chizib, rangli bo'r bilan to'ldiring. Shartlarni raqamlab, bittalab qo'llang."},
{h:"Bilasizmi? Dunyodagi eng baland odam",sum:"Robert Uodlou — 2 m 72 sm, tarixdagi eng baland odam.",a:"m08",
 start:function(){h7Bars([{n:'Siz',h:1.3,col:C.c},{n:'Ota',h:1.8},{n:'Uodlou',h:2.72,col:C.a,lab:'2 m 72 sm'}]);h7Msg('Bo‘ylarni taqqoslang')},fin:function(){h7Bars([{n:'Siz',h:1.3,col:C.c},{n:'Ota',h:1.8},{n:'Uodlou',h:2.72,col:C.a,lab:'2 m 72 sm'}]);h7Msg('Bo‘ylarni taqqoslang')},
 html:"<p>📏 Tarixdagi eng baland odam — amerikalik <b>Robert Uodlou</b>: uning bo'yi <b>2 metr 72 santimetr</b> bo'lgan. U oddiy eshikdan egilib kirgan!</p><p>🦒 Hayvonlar ichida eng balandi — jirafa: 5 metrdan ham baland bo'ladi.</p>",
 tn:"Sinfdagi bolalarning bo'yini o'lchab, devorga chizma qiling — tartiblash masalalari uchun tayyor material."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){P1[2]()},fin:function(){P1[2]()},
 html:"<div class='memo'><ul><li>Har gapni <b>rasm</b> qiling: ustunlar yoki chiziq.</li><li>Zanjir: A &gt; B va B &gt; C bo'lsa, A &gt; C.</li><li>Gapni bir xil so'zga aylantiring: «A B dan past» = «B A dan baland».</li><li>Eng aniq shartdan boshlang («eng o'ngda», «eng katta»).</li><li>«Katta emas» (hammasi har xil bo'lsa) = kichik.</li><li>Farqlar bilan: bitta odamni 0 deb oling va qolganlarini o'qqa qo'ying.</li><li>O'rtadagi: 5 tadan — 3-o'rin.</li></ul></div>",
 tn:"Keyingi darsni «Kim qaysi o'rinda?» o'yini bilan boshlang."}
];
function h7Ord(got){var names=['1','2','3','4'];var list=got.map(function(n,i){return {n:n,h:5-i,col:C.ok}});while(list.length<4)list.push({n:'?',h:.6,col:'#eef2f6'});h7Bars(list,{arrow:'og‘irdan → yengilga'});h7Msg(got.length?got.join(' > '):'Eng og‘irini tanlang')}
var PROBS=[
{t:"Ali Validan baland, Vali Sardordan baland. Eng past kim?",o:["Sardor","Ali","Vali","Ali va Sardor"],k:0,s:"Ali > Vali > Sardor."},
{t:"Ali Validan og'ir, Sardor Alidan og'ir, Vali G'anidan og'ir. Eng yengil kim?",o:["G'ani","Vali","Ali","Sardor"],k:0,s:"Sardor > Ali > Vali > G'ani."},
{t:"Ali Validan katta, lekin Sardordan kichik. G'ani Sardordan katta. Eng kichigi kim?",o:["Vali","Ali","Sardor","G'ani"],k:0,s:"G'ani > Sardor > Ali > Vali."},
{t:"Malika Nodiradan tez, Oysha Malikadan tez, Nodira Parizoddan tez. Kim 2-bo'lib keldi?",o:["Malika","Oysha","Nodira","Parizod"],k:0,s:"Oysha, Malika, Nodira, Parizod."},
{t:"Anvarda Bobirdan ko'p olma bor. Jahongirda Bobirdan ko'p, lekin Anvardan kam. Kimda eng ko'p?",o:["Anvar","Jahongir","Bobir","teng"],k:0,s:"Anvar > Jahongir > Bobir."},
{t:"Anvar Boburdan past, Bobur Davrondan past, Eldor Anvardan past, Farrux Davrondan baland. O'rtada kim?",o:["Bobur","Anvar","Davron","Eldor"],k:0,s:"Eldor, Anvar, Bobur, Davron, Farrux."},
{t:"Ali Validan 2 sm baland, Vali Sardordan 3 sm past. Ali va Sardordan qaysi biri baland va qanchaga?",o:["Sardor 1 sm","Ali 1 sm","Ali 5 sm","teng"],k:0,s:"Vali 0: Ali +2, Sardor +3. Sardor 1 sm baland."},
{t:"Nodira, Sevara, Madinaning yoshlari har xil. Nodira Madinadan katta emas, Sevara Nodiradan katta emas. Kattasidan tartib?",o:["Madina, Nodira, Sevara","Sevara, Nodira, Madina","Nodira, Madina, Sevara","Madina, Sevara, Nodira"],k:0,s:"Madina > Nodira > Sevara."},
{t:"Qizil uy ko'kdan o'ngda, yashil qizildan o'ngda, sariq ko'kdan chapda, oq eng o'ngda. O'rtadagi uy?",o:["qizil","ko'k","yashil","sariq"],k:0,s:"Sariq, ko'k, qizil, yashil, oq."},
{t:"Ota uyga onadan keyin keladi. Qiz onadan oldin keladi. O'g'il singlisidan oldin keladi. Birinchi kim keladi?",o:["o'g'il","qiz","ona","ota"],k:0,s:"O'g'il, qiz, ona, ota."},
{t:"Besh bola yugurdi. G'ani birinchi. Ali Validan oldin, lekin Sardordan keyin. Lola oxirgi emas. Kim oxirgi?",o:["Vali","Lola","Ali","Sardor"],k:0,s:"G'ani, Sardor, Ali; Vali Alidan keyin; Lola oxirgi emas → Vali oxirgi."},
{t:"Lola Malikadan 4 yosh katta, Malika Nodiradan 1 yosh katta. Lola Nodiradan necha yosh katta?",o:["5","3","4","1"],k:0,s:"Bir tomonga: 4 + 1 = 5."},
{t:"Arqon A dan 3 m uzun, B dan 2 m qisqa. B A dan necha metr uzun?",o:["5","1","3","2"],k:0,s:"A = 0, arqon = 3, B = 5. B A dan 5 m uzun."},
{t:"«Mushuk itdan yengil» qaysi gap bilan bir xil?",o:["It mushukdan og'ir","It mushukdan yengil","Mushuk itdan og'ir","Ular teng"],k:0,s:"Nomlar va so'z almashadi: it og'ir."},
{t:"Sharbat eng chapda. Suv sutning o'ngida yonma-yon. Kompot eng o'ngda. 4 ko'za: sharbat, suv, sut, kompot. Chapdan 2-ko'za?",o:["sut","suv","kompot","sharbat"],k:0,s:"Sharbat, sut, suv, kompot."},
{t:"Uchta qutining og'irligi har xil. A B dan yengil emas. C A dan og'ir emas. Eng og'iri?",o:["A","B","C","teng"],k:0,s:"A > B, A > C."},
{t:"Dilnoza Zarinadan baland, Zarina Kamoladan baland, Kamola Lobardan baland. Ikkinchi eng past kim?",o:["Kamola","Zarina","Lobar","Dilnoza"],k:0,s:"Lobar < Kamola < Zarina < Dilnoza."},
{t:"Ali Validan 3 sm past, Vali Sardordan 1 sm baland. Ali va Sardordan qaysi biri baland va qanchaga?",o:["Sardor 2 sm","Ali 2 sm","Sardor 4 sm","Ali 4 sm"],k:0,s:"Vali 0: Ali −3, Sardor −1. Sardor 2 sm baland."},
{t:"Navbatda Bobur Alidan oldin, Ali Validan oldin, Vali Sardordan oldin. Navbatning oxirida kim?",o:["Sardor","Vali","Ali","Bobur"],k:0,s:"Bobur, Ali, Vali, Sardor."},
{t:"Gulzorda lola, chinnigul, atirgul — jami 7 ta. Har turdan kamida bitta, sonlari har xil. Lola eng kam, atirgul eng ko'p. Atirgul nechta?",o:["4","3","2","5"],k:0,s:"Har xil sonlar: 1 + 2 + 4 = 7. Atirgul 4."}
];
function PRACT_STAGE(){h7Bars([{n:'A',h:2},{n:'B',h:3},{n:'C',h:4}]);h7Msg('Har gapni rasmga aylantiring')}
var PREP_DATA={teach:["Ikki taqqoslashdan zanjir tuzish (A > B > C).","Gapni teskari aytish: past ↔ baland, yengil ↔ og'ir.","Ko'p kishini tartib chizig'ida joylash; o'rtadagini topish.","«Katta emas», farqlar bilan (sm, yosh), chap–o'ng joylashuvi."],
 mist:["Gaplarni chizmasdan, boshda saqlab adashadi.","«Past» va «baland» aralash kelsa, chalkashadi.","«Katta emas» ni «katta» deb o'qiydi.","Farqlarni doim qo'shadi (2 + 3 = 5) — yo'nalishga qaramaydi."],
 need:["Bolalarning o'zi (qatorga turish).","Rangli kartochkalar, tarozi."],
 board:["Ustunli rasm: <span class='w2'>Ali > Vali > Sardor</span>.","Juftlar: past–baland, yengil–og'ir, oldin–keyin.","Tartib chizig'i: har gapda yangi ism.","Farqlar: bitta odam = 0, qolganlari o'qda.","5 ta katak — chap/o'ng masalalari."]};
