var CODE='2Y2',TITLE='2-sinf yakuni · Ko‘paytirish jadvali bo‘yicha mantiqiy masalalar';
// ---------- sahna: 9×9 ko'paytirish jadvali ----------
function y2Grid(o){o=o||{};clear();var g=S.g,x0=34,y0=22,cw=35,ch=16;
 for(var i=1;i<=9;i++){T(g,x0+(i-.5)*cw,y0-6,String(i),{'font-size':10,'font-weight':800,fill:C.blue});T(g,x0-10,y0+(i-.5)*ch+4,String(i),{'font-size':10,'font-weight':800,fill:C.blue})}
 S.y2c={};for(var r=1;r<=9;r++)for(var c=1;c<=9;c++){var v=r*c,f='#fff';if(o.mark&&o.mark(r,c,v))f=o.col||C.hi;
  var e=E('rect',{x:x0+(c-1)*cw,y:y0+(r-1)*ch,width:cw-1,height:ch-1,rx:2,fill:f,stroke:'#dde5ee',style:'cursor:pointer'},g);e._r=r;e._c=c;S.y2c[r+'_'+c]=e;
  T(g,x0+(c-.5)*cw,y0+(r-.5)*ch+4,String(v),{'font-size':9,'font-weight':o.mark&&o.mark(r,c,v)?800:500,fill:'#33475b','pointer-events':'none'})}
 [].forEach.call(g.querySelectorAll('rect'),function(e){if(e._r)e.addEventListener('click',function(){if(S.y2tap)S.y2tap(e._r,e._c)})})}
function y2msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// nuqtalar massivi
function y2dots(r,c,extra,lab){clear();var g=S.g,s=14,x0=180-(c*s)/2,y0=20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s+7,cy:y0+i*s+7,r:5,fill:C.b},g);
 if(extra)for(var k=0;k<extra;k++)E('circle',{cx:x0+c*s+7+4,cy:y0+k*s+7,r:5,fill:C.a},g);
 if(lab)T(g,180,166,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
var Y2P3=[function(){y2dots(6,6,0,'6 · 6 = 36');y2msg('6 · 6 = 36 ni bilamiz. 6 · 7 ni topaylik')},
 function(){y2dots(7,6,0,'');var g=S.g;for(var j=0;j<6;j++)E('circle',{cx:180-42+j*14+7,cy:20+6*14+7,r:5,fill:C.a},g);T(g,180,166,'yana bitta qator: + 6',{'font-size':13,'font-weight':800,fill:C.a2});y2msg('6 · 7 — bu 6 · 6 dan bitta qator (6 ta) ko‘p')},
 function(){y2dots(7,6,0,'6 · 7 = 36 + 6 = 42');y2msg('<b>6 · 7 = 36 + 6 = 42</b>. Unutilgan ko‘paytmani qo‘shnisidan topish mumkin!')}];
var STEPS=[
{h:"Jadvalda yashirin qonuniyatlar",sum:"Jadvalda bir son bir necha marta uchraydi: 24 = 3·8 = 4·6 = 6·4 = 8·3 (4 marta).",a:"m01",
 start:function(){S.y2n=0;y2Grid();y2msg('Jadvaldagi istalgan katakni bosing');S.y2tap=function(r,c){S.y2n++;var v=r*c;y2Grid({mark:function(a,b,x){return x===v}});y2msg('<b>'+r+' · '+c+' = '+v+'</b>. Jadvalda '+v+' yana qayerda bor? — sariq kataklar');if(S.y2n>=2&&S.y2d)S.y2d()}},
 fin:function(){y2Grid({mark:function(a,b,v){return v===24}});y2msg('24 = 3 · 8 = 4 · 6 = 6 · 4 = 8 · 3')},
 html:"<p>Bu — 9 gacha <b>ko'paytirish jadvali</b>. Qatordagi son ustundagi songa ko'paytirilgan. Istalgan katakni bosing: o'sha son jadvalda yana qayerlarda borligini ko'rasiz (kamida 2 ta katak).</p>",
 act:function(c,done){S.y2d=function(){S.y2d=null;done()};c.querySelector('.hint').textContent='Jadvaldagi kataklarni bosing.'},
 after:"<p>Ba'zi sonlar jadvalda ko'p marta uchraydi. Masalan, <b>24</b>: 3·8, 4·6, 6·4, 8·3 — 4 marta. Sababi: 24 ni turli usulda teng guruhlarga bo'lish mumkin.</p>",
 q:{t:"Ko'paytirish jadvalida (9 gacha) 12 soni necha marta uchraydi?",opts:["4","2","3","6"],ok:0,why:"12 = 2·6 = 3·4 = 4·3 = 6·2 — 4 marta.",hint:"12 ni qanday ikki son ko'paytmasi qilib yozsa bo'ladi? 1·12 jadvalda yo'q (12 > 9).",full:"12 = 2·6, 3·4, 4·3, 6·2 — 4 ta katak. 1·12 va 12·1 jadvalga kirmaydi, chunki jadval 9 gacha."},
 tn:"Bolalar jadvalni bo'yab, bir xil sonlarni bir xil rangga bo'yasin — jadval simmetrik naqshga aylanadi."},
{h:"O'rin almashtirish — jadval ikki barobar qisqaradi",sum:"a · b = b · a: diagonal bo'yicha jadval ko'zgudek. 8·7 = 7·8 = 56.",a:"m02",
 start:function(){y2Grid();y2msg('Tugmani bosing')},fin:function(){y2Grid({mark:function(r,c){return r===c},col:'#bfe9e3'});y2msg('Diagonal — ko‘zgu: uning ikki tomonidagi sonlar bir xil')},
 html:"<p>Jadvaldagi ko'k diagonalni ko'ring: u jadvalni <b>ikki teng yarmiga</b> bo'ladi. Tugmani bosing.</p>",
 btns:[["🪞 Diagonalni ko'rsatish",function(c,done){y2Grid({mark:function(r,c2){return r===c2},col:'#bfe9e3'});y2msg('Diagonal (1, 4, 9, 16 … 81) — ko‘zgu chizig‘i');done()}]],
 after:"<p>Diagonalning ikki tomoni bir xil: <b>3 · 8 = 8 · 3</b>. Demak, jadvalning faqat yarmini yodlash yetarli — qolgani o'rin almashtirish bilan chiqadi. Diagonaldagi sonlar (1, 4, 9, 16, 25, 36, 49, 64, 81) — sonning o'ziga ko'paytmasi.</p>",
 q:{t:"Bir xil ikki sonning ko'paytmasi 64. Bu qaysi son?",opts:["8","32","16","6"],ok:0,why:"8 · 8 = 64.",hint:"Diagonaldagi sonlarni eslang: qaysi son o'ziga ko'paytirilganda 64?",full:"Bir xil sonlar ko'paytmasi diagonalda: 8 · 8 = 64. «32» — 64 ni 2 ga bo'lish (32 + 32 = 64), bu ko'paytma emas."},
 tn:"Doskada jadvalni chizib, diagonal bo'yicha buklang — kataklar ustma-ust tushadi."},
{h:"Unutganni qo'shnisidan topish",sum:"6 · 7 = 6 · 6 + 6 = 42. Bitta qator qo'shilsa — ko'paytma bitta songa ortadi.",a:"m03",
 start:function(){startPh(Y2P3)},fin:function(){S.ph=2;Y2P3[2]()},
 html:"<p>6 · 7 esdan chiqdi? Qo'rqmang — uni tanish qo'shnisidan topamiz. Kuzating.</p>",
 btns:[phaser(Y2P3)],
 after:"<p>6 · 7 — bu 6 ta qator 7 tadan… yoki 6 · 6 ga yana <b>bitta 6</b> qo'shilgani. Shunday qilib unutilgan ko'paytmani bilganidan topish mumkin: 9 · 8 = 9 · 9 − 9 = 72.</p>",
 q:{t:"8 · 6 = 48 ekanini bilamiz. 8 · 7 nechaga teng?",opts:["56","49","54","48"],ok:0,why:"8 · 7 = 8 · 6 + 8 = 48 + 8 = 56.",hint:"8 · 7 da 8 · 6 dan nechta ortiq?",full:"7 ta sakkizlik — bu 6 ta sakkizlik va yana bitta sakkizlik: 48 + 8 = 56. «49» — 48 ga 1 qo'shilgan, xato."},
 tn:"Bu — Yaponiya darsliklaridagi asosiy usul: jadvalni yod olishdan oldin uning tuzilishini tushuntirish."},
{h:"Juft yoki toq ko'paytma?",sum:"Ko'paytuvchilardan biri juft bo'lsa — ko'paytma juft. Ikkalasi toq bo'lsa — toq.",a:"m04",
 start:function(){y2Grid();y2msg('Tugmani bosing')},fin:function(){y2Grid({mark:function(r,c,v){return v%2===1},col:'#ffd0d0'});y2msg('Qizil — toq ko‘paytmalar: faqat toq × toq')},
 html:"<p>Jadvaldagi <b>toq</b> sonlarni bo'yab ko'ramiz. Qanday naqsh chiqar ekan?</p>",
 btns:[["🎨 Toq sonlarni bo'yash",function(c,done){y2Grid({mark:function(r,c2,v){return v%2===1},col:'#ffd0d0'});y2msg('Toq sonlar faqat toq qator va toq ustun kesishgan joyda');done()}]],
 after:"<p>Toq ko'paytma faqat <b>toq × toq</b> bo'lganda chiqadi (3 · 5 = 15). Agar ko'paytuvchilardan <b>biri juft</b> bo'lsa — ko'paytma albatta juft (2 · 7 = 14).</p>",
 q:{t:"Qaysi ko'paytma toq?",opts:["3 · 5","2 · 7","4 · 9","6 · 3"],ok:0,why:"3 va 5 — ikkalasi toq, 15 ham toq.",hint:"Qaysi variantda ikkala son ham toq?",full:"2 · 7, 4 · 9, 6 · 3 da bittadan juft son bor — ko'paytma juft. Faqat 3 · 5 = 15 toq."},
 tn:"Bu qonuniyatni bolalar o'zi kashf qilsin: jadvalni bo'yatib, «nimani ko'ryapsiz?» deb so'rang."},
{h:"Tuzoq: yashiringan son",sum:"□ · 6 = 42 → □ = 42 : 6 = 7. Noma'lum ko'paytuvchi — bo'lish bilan.",a:"m05",
 start:function(){y2hid(null)},fin:function(){y2hid(7)},
 html:"<p><b>□ · 6 = 42</b>. Kvadrat o'rnida qaysi son? Sonlarni sinab ko'ring:</p><div class='digs y2d'></div>",
 act:function(c,done){var b=c.querySelector('.y2d');b.innerHTML='';for(var d=1;d<=9;d++)(function(d){var e=document.createElement('button');e.className='dg';e.textContent=d;e.onclick=function(){y2hid(d);e.className='dg '+(d===7?'yes':'no');if(d===7)done()};b.appendChild(e)})(d)},
 after:"<p>Sinab topdik: <b>7</b>. Tezroq yo'l — bo'lish: 42 : 6 = 7. Noma'lum ko'paytuvchini topish uchun ko'paytmani ma'lum ko'paytuvchiga bo'lamiz.</p>",
 q:{t:"□ · □ = 49 (ikkala kvadratda bir xil son). □ = ?",opts:["7","24","9","6"],ok:0,why:"7 · 7 = 49.",hint:"Diagonaldagi sonlarni eslang.",full:"Bir xil sonlar ko'paytmasi 49 — bu 7 · 7. «24» — 49 ni ikkiga bo'lishga urinish, lekin bu ko'paytma, yig'indi emas."},
 tn:"Bolalarga «men o'ylagan sonni 6 ga ko'paytirdim, 42 chiqdi» kabi o'yin o'ynang."},
{h:"Ikki shartli masala",sum:"Ko'paytmasi 24, yig'indisi 10: juftlarni sinaymiz — 4 va 6.",a:"m06",
 start:function(){y2pairs(null)},fin:function(){y2pairs(3)},
 html:"<p>«Ikki sonning <b>ko'paytmasi 24</b>, <b>yig'indisi 10</b>. Bu qaysi sonlar?» Ko'paytmasi 24 bo'lgan juftlarni sinab ko'ring:</p><div class='digs y2p'></div>",
 act:function(c,done){var b=c.querySelector('.y2p');b.innerHTML='';[[1,24],[2,12],[3,8],[4,6]].forEach(function(p,i){var e=document.createElement('button');e.className='dg wide';e.style.width='76px';e.textContent=p[0]+' va '+p[1];e.onclick=function(){y2pairs(i);e.className='dg wide '+(i===3?'yes':'no');if(i===3)done()};b.appendChild(e)})},
 after:"<p>Ko'paytmasi 24 bo'lgan juftlar: 1 va 24, 2 va 12, 3 va 8, 4 va 6. Faqat <b>4 + 6 = 10</b>. Usul: avval bitta shartga mos hammasini yozamiz, keyin ikkinchi shart bilan tekshiramiz.</p>",
 q:{t:"Ikki sonning ko'paytmasi 18, yig'indisi 9. Bu qaysi sonlar?",opts:["3 va 6","2 va 9","1 va 18","4 va 5"],ok:0,why:"3 · 6 = 18, 3 + 6 = 9.",hint:"Ko'paytmasi 18 bo'lgan juftlarni yozing va yig'indisini tekshiring.",full:"Ko'paytmasi 18: 1·18, 2·9, 3·6. Yig'indilar: 19, 11, 9. Faqat 3 va 6. «4 va 5» — yig'indisi 9, lekin ko'paytmasi 20."},
 tn:"Ro'yxat tuzish (barcha variantlarni yozib chiqish) — olimpiada masalalarining asosiy strategiyasi."},
{h:"Oxirgi raqam sirlari",sum:"5 ga ko'paytmalar 0 yoki 5 bilan tugaydi; 10 ga — 0 bilan; 2 ga — juft raqam bilan.",a:"m07",
 start:function(){y2Grid();y2msg('Tugmani bosing')},fin:function(){y2Grid({mark:function(r,c){return r===5||c===5}});y2msg('5 qatori va ustuni: 5, 10, 15 … 45 — hammasi 0 yoki 5 bilan tugaydi')},
 html:"<p>5 ga ko'paytmalarni bo'yab, ularning <b>oxirgi raqamiga</b> qarang.</p>",
 btns:[["🔍 5 ga ko'paytmalar",function(c,done){y2Grid({mark:function(r,c2){return r===5||c2===5}});y2msg('5, 10, 15, 20, 25, 30, 35, 40, 45 — oxiri <b>0 yoki 5</b>');done()}]],
 after:"<p>5 ga ko'paytmalar har doim <b>0 yoki 5</b> bilan tugaydi. Shuning uchun 32 yoki 47 5 ga ko'paytirish jadvalida bo'lishi mumkin emas — hisoblamasdan ham bilamiz!</p>",
 q:{t:"Qaysi son 5 ga ko'paytirish jadvalida yo'q?",opts:["32","35","40","45"],ok:0,why:"32 oxiri 2 — 0 yoki 5 emas.",hint:"Oxirgi raqamlarga qarang.",full:"5 ga ko'paytmalar 0 yoki 5 bilan tugaydi: 35, 40, 45 bor. 32 esa 2 bilan tugaydi — yo'q."},
 tn:"Bo'linish alomatlariga (4-sinf) birinchi qadam. «Qaysi biri 5 ga bo'linadi?» o'yinini o'ynang."},
{h:"Bilasizmi? Pifagor jadvali",sum:"Ko'paytirish jadvalini ko'p mamlakatlarda «Pifagor jadvali» deyishadi.",a:"m08",
 start:function(){y2Grid({mark:function(r,c){return r===1||c===1},col:'#e8f1fb'});y2msg('Pifagor jadvali')},fin:function(){y2Grid({mark:function(r,c){return r===1||c===1},col:'#e8f1fb'});y2msg('Pifagor jadvali')},
 html:"<p>📜 Ko'paytirish jadvalini ko'p mamlakatlarda <b>«Pifagor jadvali»</b> deb atashadi — qadimgi yunon olimi Pifagor nomi bilan. Lekin ko'paytirish jadvallari undan ham ancha oldin, <b>Bobilda</b> (4000 yil oldin) loy taxtachalarga yozilgan.</p><p>⭐ Jadvalda 81 ta katak bor, lekin o'rin almashtirish tufayli turli ko'paytmalar atigi <b>45</b> ta — yarmini bilsangiz, hammasini bilasiz!</p>",
 tn:"Bolalarga 9 ga ko'paytirishning «barmoq usuli»ni ko'rsating: 9 · 3 — uchinchi barmoqni bukamiz, chapda 2, o'ngda 7 — 27."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){y2Grid();y2msg('Ko‘paytirish jadvali')},fin:function(){y2Grid();y2msg('Ko‘paytirish jadvali')},
 html:"<div class='memo'><ul><li>Bir son jadvalda bir necha marta uchraydi: 24 = 3·8 = 4·6.</li><li><b>a · b = b · a</b> — jadvalning yarmini bilish yetarli.</li><li>Unutilganni qo'shnidan: 6 · 7 = 6 · 6 + 6 = 42.</li><li>Biri juft → ko'paytma juft; ikkalasi toq → toq.</li><li>□ · 6 = 42 → □ = 42 : 6 = 7.</li><li>Ikki shartli masala: avval bitta shartga mos hammasini yozing, keyin tekshiring.</li><li>5 ga ko'paytmalar 0 yoki 5 bilan tugaydi.</li></ul></div>",
 tn:"Keyingi darsni «Ko'paytmasi 36, yig'indisi 12 bo'lgan sonlar?» (6 va 6) savoli bilan boshlang."}
];
function y2hid(d){clear();var g=S.g;T(g,180,50,'□ · 6 = 42',{'font-size':32,'font-weight':800,fill:'#1d2b3a'});
 if(d!=null){var ok=d*6===42;T(g,180,105,d+' · 6 = '+d*6,{'font-size':30,'font-weight':800,fill:ok?C.ok:C.bad});T(g,180,145,ok?'✓ to‘g‘ri':(d*6<42?'✗ kam — kattaroq son kerak':'✗ ko‘p — kichikroq son kerak'),{'font-size':14,'font-weight':800,fill:ok?C.ok:C.bad})}
 y2msg('Noma‘lum ko‘paytuvchi = ko‘paytma : ma‘lum ko‘paytuvchi')}
function y2pairs(i){clear();var g=S.g,P=[[1,24],[2,12],[3,8],[4,6]];T(g,180,24,'ko‘paytma = 24,  yig‘indi = ?',{'font-size':14,'font-weight':800,fill:C.blue});
 P.forEach(function(p,k){var y=50+k*28,on=i===k,ok=p[0]+p[1]===10;E('rect',{x:60,y:y-16,width:240,height:24,rx:6,fill:on?(ok?'#e6f6ee':'#fdeaea'):'#fff',stroke:'#c9d3dd'},g);var fc=on?(ok?C.ok:C.bad):'#33475b';T(g,120,y+1,p[0]+' · '+p[1]+' = 24',{'font-size':13,'font-weight':700,fill:fc});T(g,235,y+1,p[0]+' + '+p[1]+' = '+(p[0]+p[1])+(on?(ok?' ✓':' ✗'):''),{'font-size':13,'font-weight':700,fill:fc})});
 y2msg('Yig‘indisi 10 bo‘lgan juftni toping')}
var PROBS=[
{t:"Ko'paytirish jadvalida (9 gacha) 18 soni necha marta uchraydi?",o:["4","2","3","6"],k:0,s:"18 = 2·9 = 3·6 = 6·3 = 9·2 — 4 marta."},
{t:"Agar 7 · 8 = 56 bo'lsa, 8 · 7 = ?",o:["56","54","15","63"],k:0,s:"O'rin almashtirish: 8 · 7 = 7 · 8 = 56."},
{t:"9 · 9 = 81 ni bilamiz. 9 · 8 = ?",o:["72","80","73","63"],k:0,s:"9 · 8 = 9 · 9 − 9 = 81 − 9 = 72."},
{t:"Qaysi ko'paytma juft?",o:["5 · 8","3 · 7","5 · 9","7 · 7"],k:0,s:"5 · 8 da 8 juft — ko'paytma juft: 40."},
{t:"□ · 7 = 63. □ = ?",o:["9","8","56","7"],k:0,s:"63 : 7 = 9."},
{t:"Ikki sonning ko'paytmasi 36, yig'indisi 12. Bu qaysi sonlar?",o:["6 va 6","4 va 9","3 va 12","2 va 18"],k:0,s:"6 · 6 = 36, 6 + 6 = 12."},
{t:"Ikki sonning ko'paytmasi 20, yig'indisi 9. Kattasi qaysi?",o:["5","4","10","20"],k:0,s:"4 · 5 = 20, 4 + 5 = 9. Kattasi 5."},
{t:"Qaysi son ko'paytirish jadvalida (9 gacha) umuman yo'q?",o:["13","12","14","15"],k:0,s:"13 ni 9 gacha bo'lgan ikki son ko'paytmasi qilib bo'lmaydi (faqat 1 · 13)."},
{t:"Qaysi son 5 ga ko'paytirish jadvalida yo'q?",o:["28","25","30","20"],k:0,s:"28 oxiri 8 — 0 yoki 5 emas."},
{t:"Bir xil ikki sonning ko'paytmasi 36. Ularning yig'indisi?",o:["12","18","6","9"],k:0,s:"6 · 6 = 36, 6 + 6 = 12."},
{t:"6 ta qutida 7 tadan, 3 ta qutida 7 tadan qalam bor. Hammasi nechta qalam?",o:["63","42","21","56"],k:0,s:"6 + 3 = 9 quti, 9 · 7 = 63."},
{t:"Qaysi tenglik noto'g'ri?",o:["7 · 8 = 54","6 · 9 = 54","8 · 8 = 64","9 · 4 = 36"],k:0,s:"7 · 8 = 56, 54 emas."},
{t:"□ · □ = 81. □ + □ = ?",o:["18","9","81","27"],k:0,s:"9 · 9 = 81, 9 + 9 = 18."},
{t:"Ko'paytmasi 12 bo'lgan ikki xil bir xonali sonlar juftlari nechta? (2·6 va 6·2 bitta juft)",o:["2","3","4","1"],k:0,s:"2 va 6, 3 va 4 — 2 ta (1 va 12 da 12 bir xonali emas)."},
{t:"Ali bir sonni 4 ga ko'paytirdi va 32 oldi. Shu sonni 5 ga ko'paytirsa nima chiqadi?",o:["40","36","28","45"],k:0,s:"Son 32 : 4 = 8. 8 · 5 = 40."},
{t:"Qaysi ko'paytmalar teng?",o:["3 · 8 va 4 · 6","3 · 6 va 2 · 8","4 · 5 va 2 · 9","6 · 6 va 4 · 8"],k:0,s:"3 · 8 = 24, 4 · 6 = 24."},
{t:"9 ga ko'paytmalarning raqamlari yig'indisi (9·1 dan 9·9 gacha) doim nechaga teng?",o:["9","10","18","1"],k:0,s:"18 → 1+8 = 9, 27 → 9, 36 → 9 … har doim 9."},
{t:"Toq son toq songa ko'paytirildi. Natija qanday?",o:["toq","juft","har doim 0","10 dan katta"],k:0,s:"Toq × toq = toq (3 · 5 = 15, 7 · 1 = 7)."},
{t:"8 · 5 + 8 · 4 qiymati qaysi ko'paytmaga teng?",o:["8 · 9","8 · 20","16 · 9","8 · 1"],k:0,s:"5 ta sakkizlik va 4 ta sakkizlik — 9 ta sakkizlik: 8 · 9 = 72."},
{t:"Ikki sonning ko'paytmasi 0. Ular haqida nima deyish mumkin?",o:["kamida bittasi 0","ikkalasi 1","ikkalasi teng","ikkalasi juft"],k:0,s:"Ko'paytma 0 bo'lishi uchun kamida bitta ko'paytuvchi 0 bo'lishi kerak."}
];
function PRACT_STAGE(){y2Grid();S.y2tap=function(r,c){y2Grid({mark:function(a,b){return a===r&&b===c}});y2msg(r+' · '+c+' = <b>'+r*c+'</b>')};y2msg('Kerak bo‘lsa, jadvaldan foydalaning')}
var PREP_DATA={teach:["Jadvaldagi qonuniyatlar: bir son bir necha marta, diagonal simmetriya.","Unutilgan ko'paytmani qo'shnidan topish.","Juft/toq ko'paytma; oxirgi raqam qonuniyatlari.","Noma'lum ko'paytuvchi; ikki shartli masalalarda ro'yxat usuli."],
 mist:["Ko'paytma va yig'indini aralashtiradi (8 · 8 = 16).","Ikki shartli masalada faqat bitta shartni tekshiradi.","Jadvalni mexanik yodlaydi, qo'shni bilan bog'lamaydi.","Toq × juft ni toq deb o'ylaydi."],
 need:["Har bolaga chop etilgan 9×9 jadval va rangli qalamlar.","Nuqtali kartochkalar (massivlar)."],
 board:["9×9 jadval, diagonal chiziq.","<span class='w2'>24 = 3·8 = 4·6</span>.","<span class='w2'>6 · 7 = 6 · 6 + 6</span>.","Juft × istalgan = juft; toq × toq = toq.","<span class='w2'>□ · 6 = 42 → 42 : 6</span>.","Ro'yxat: <span class='w2'>1·24, 2·12, 3·8, 4·6</span>."]};
