var CODE='4E6',TITLE='4-sinf · O‘rta arifmetik';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
// minoralar: f.v — qiymatlar, f.lab — nomlar, f.line — o'rtacha chizig'i
function e6tw(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,n=f.v.length,u=f.u||10,bw=Math.min(50,240/n),gap=(272-n*bw)/(n+1),base=150,mx=f.mx||Math.max.apply(null,f.v),k=(f.t?96:112)/mx;
 f.v.forEach(function(v,i){var x=20+gap+i*(bw+gap),h=v*k,col=(f.c&&f.c[i])||'#5aa9e6';
  for(var j=0;j<v;j+=u){var hh=Math.min(u,v-j)*k;E('rect',{x:x,y:base-j*k-hh,width:bw,height:hh,fill:col,stroke:'#fff','stroke-width':1},g)}
  T(g,x+bw/2,base-h-5,String(v),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});if(f.lab)T(g,x+bw/2,base+14,f.lab[i],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 E('line',{x1:20,y1:base,x2:340,y2:base,stroke:'#556','stroke-width':1.5},g);
 if(f.line!=null){var y=base-f.line*k;E('line',{x1:20,y1:y,x2:340,y2:y,stroke:C.ok,'stroke-width':2.5,'stroke-dasharray':'7 5'},g);T(g,318,y-6,'o‘rtacha',{'font-size':10,'font-weight':800,fill:C.ok});T(g,318,y+15,String(f.line),{'font-size':13,'font-weight':800,fill:C.ok})}}
function e6st(o){var P=o.frames.map(function(f){return function(){f.v?e6tw(f):e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e6pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)(okF.v?e6tw:e4fr)(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
var STEPS=[
e6st({h:"Tenglashtirish — o‘rtachaning ma’nosi",sum:"3, 7, 5 kubikli minoralar: ortiqchasini kamiga o‘tkazsak, hammasi 5 tadan. O‘rtacha 5.",a:"m01",
 frames:[{v:[3,7,5],u:1,lab:['Ali','Vali','Soli'],mx:7,note:'Minoralar har xil balandlikda'},
  {v:[4,6,5],u:1,lab:['Ali','Vali','Soli'],mx:7,c:['#7cc98f','#f0a040','#5aa9e6'],note:'Vali bitta kubikni Aliga berdi'},
  {v:[5,5,5],u:1,lab:['Ali','Vali','Soli'],mx:7,line:5,c:['#7cc98f','#7cc98f','#7cc98f'],calc:['Hammasi teng: 5 tadan','(3 + 7 + 5) : 3 = 15 : 3 = <b>5</b>']}],
 html:"<p>Uch bolaning kubiklari har xil. Agar ular kubiklarni <b>adolatli</b> bo'lishsa, har kimda nechta bo'ladi? Tugmani bosing.</p>",
 after:"<p>Tenglashgan son — <b>o'rta arifmetik</b> (o'rtacha). Hisoblash: hammasini <b>qo'shib</b>, nechta son bo'lsa shunga <b>bo'lamiz</b>: 15 : 3 = 5.</p>",
 q:{t:"To'rt bolada 6, 2, 9 va 3 ta olma bor. Teng bo'lishsa, har biriga nechtadan tegadi?",opts:["5","20","4","6"],ok:0,why:"(6 + 2 + 9 + 3) : 4 = 20 : 4 = 5.",hint:"Avval jami nechta?",full:"Jami: 6 + 2 + 9 + 3 = 20. 4 bolaga: 20 : 4 = 5. «20» — bo'lish unutilgan, «4» — 20 : 5 (son 4 ta, 5 ta emas)."},
 tn:"Yaponiya va Singapur darsliklarida o'rtacha avval «tenglashtirish» orqali kiritiladi. Partada kubik yoki tayoqchalardan minoralar quring; bolalar o'zi tenglashtirsin."}),
e6st({h:"Formula: yig‘indi : soni",sum:"18, 27, 24, 31 km: (18 + 27 + 24 + 31) : 4 = 100 : 4 = 25 km.",a:"m02",
 frames:[{v:[18,27,24,31],lab:['1-kun','2-kun','3-kun','4-kun'],mx:31,u:100,t:'Velosipedchi 4 kunda yurgan yo‘li (km)',note:'Bir kunda o‘rtacha necha km?'},
  {v:[18,27,24,31],lab:['1-kun','2-kun','3-kun','4-kun'],mx:31,u:100,line:25,t:'Velosipedchi 4 kunda yurgan yo‘li (km)',calc:['18 + 27 + 24 + 31 = 100 km','100 : 4 = <b>25</b> km kuniga']}],
 html:"<p>Kubiklarni ko'chirib o'tirmaymiz — hisoblaymiz. Tugmani bosing.</p>",
 after:"<p><b>O'rta arifmetik = sonlar yig'indisi : sonlar soni.</b> O'rtacha chiziq ustidagi «ortiqcha» ostidagi «kamchilik»ni aniq to'ldiradi.</p>",
 q:{t:"Sinfda 5 kun davomida 28, 30, 25, 29 va 33 o'quvchi keldi. Kuniga o'rtacha nechta?",opts:["29","145","30","27"],ok:0,why:"145 : 5 = 29.",hint:"Yig'indini 5 ga bo'ling.",full:"28 + 30 + 25 + 29 + 33 = 145; 145 : 5 = 29. «145» — bo'lish unutilgan."},
 tn:"Bank: 1788-id. Doskada ustunli diagramma chizib, o'rtacha chiziqni rangli bo'r bilan torting."}),
e6st({h:"Tuzoq: qaysi songa bo‘lamiz?",sum:"6 kun 75 kg, 4 kun 85 kg: (450 + 340) : 10 = 79 kg (80 emas!).",a:"m03",
 frames:[{t:'Fermer 6 kun davomida har kuni 75 kg, keyingi 4 kun har kuni 85 kg pomidor terdi. Kuniga o‘rtacha necha kg?',bars:[{lab:'6 kun',y:62,segs:[{w:75,txt:'75',c:'a'},{w:75,txt:'75',c:'a'},{w:75,txt:'75',c:'a'},{w:75,txt:'75',c:'a'},{w:75,txt:'75',c:'a'},{w:75,txt:'75',c:'a'}]},{lab:'4 kun',y:106,segs:[{w:85,txt:'85',c:'b'},{w:85,txt:'85',c:'b'},{w:85,txt:'85',c:'b'},{w:85,txt:'85',c:'b'}]}],max:450,note:'Tanlang:'}],
 html:"<p>Ehtiyot bo'ling: kunlar soni har xil! Qaysi javob to'g'ri?</p>",
 btns:e6pk(["80 kg","79 kg","790 kg"],1,{t:'Fermer 6 kun 75 kg dan, 4 kun 85 kg dan terdi.',bars:[{lab:'6 kun',y:62,segs:[{w:450,txt:'450',c:'a'}]},{lab:'4 kun',y:106,segs:[{w:340,txt:'340',c:'b'}]}],max:450,calc:['6 · 75 = 450,  4 · 85 = 340','(450 + 340) : 10 = 790 : 10 = <b>79</b> kg']},["80 = (75 + 85) : 2 — lekin 75 kg li kunlar ko‘proq (6 ta), ular o‘rtachani pastga tortadi.","","790 kg — bu jami hosil. Uni kunlar soniga (10) bo‘lish kerak."]),
 after:"<p>O'rtacha — <b>barcha kunlar</b> bo'yicha: jami hosil : jami kun. 75 kunlari ko'p bo'lgani uchun o'rtacha 80 dan <b>pastroq</b>.</p>",
 q:{t:"Do'kon 3 kun 40 tadan, 2 kun 50 tadan non sotdi. Kuniga o'rtacha nechta?",opts:["44","45","220","90"],ok:0,why:"(120 + 100) : 5 = 44.",hint:"Jami nonni jami kunlar soniga bo'ling.",full:"3 · 40 = 120, 2 · 50 = 100; jami 220; 220 : 5 = 44. «45» — (40 + 50) : 2, kunlar soni hisobga olinmagan."},
 tn:"Bank: 1790-id. Bu — eng ko'p uchraydigan xato. Bolalarga «har bir kunni alohida yozib chiqing» deb ko'rsating: 75, 75, 75, 75, 75, 75, 85, 85, 85, 85."}),
e6st({h:"Yo‘qolgan sonni topish",sum:"Ikki sonning o‘rtachasi 64, biri 87: yig‘indi 64 · 2 = 128, ikkinchisi 128 − 87 = 41.",a:"m04",
 frames:[{v:[87,0],lab:['1-son','2-son'],mx:87,u:200,line:64,t:'Ikki sonning o‘rtachasi 64. Biri 87. Ikkinchisi?',note:'O‘rtachadan yig‘indini tiklaymiz'},
  {v:[87,41],lab:['1-son','2-son'],mx:87,u:200,line:64,t:'Ikki sonning o‘rtachasi 64. Biri 87. Ikkinchisi?',c:['#5aa9e6','#7cc98f'],calc:['Yig‘indi: 64 · 2 = 128','128 − 87 = <b>41</b>']}],
 html:"<p>Teskari masala: o'rtacha ma'lum, bitta son noma'lum. Kalit — <b>yig'indi = o'rtacha · soni</b>.</p>",
 after:"<p>Tekshiruv: (87 + 41) : 2 = 64 ✓. Ko'rinib turibdiki, 87 o'rtachadan 23 ga ko'p, 41 esa 23 ga kam — ular bir-birini to'ldiradi.</p>",
 q:{t:"Uch sonning o'rta arifmetigi 30. Ikkitasi 25 va 38. Uchinchisi?",opts:["27","90","33","63"],ok:0,why:"30 · 3 = 90; 90 − 25 − 38 = 27.",hint:"Avval uchala son yig'indisini toping.",full:"Yig'indi: 30 · 3 = 90. Uchinchi son: 90 − 25 − 38 = 27. «33» — 30 · 2 − 25 − ... xato; «63» — faqat 25 + 38."},
 tn:"Bank: 1789-id. Formulani teskari yozing: YIG'INDI = O'RTACHA · SONI."}),
e6st({h:"Yangi a’zo qo‘shildi",sum:"24, 20, 28 + yangi ishchi, o‘rtacha 25: 25 · 4 = 100, 100 − 72 = 28.",a:"m05",
 frames:[{v:[24,20,28,0],lab:['1','2','3','yangi'],mx:30,u:100,line:25,t:'3 ishchi soatiga 24, 20, 28 ta detal. 4-si qo‘shilgach o‘rtacha 25 bo‘ldi.',note:'Yangi ishchi soatiga nechta yasaydi?'}],
 html:"<p>Tanlang:</p>",
 btns:e6pk(["25 ta","28 ta","24 ta"],1,{v:[24,20,28,28],lab:['1','2','3','yangi'],mx:30,u:100,line:25,c:['#5aa9e6','#5aa9e6','#5aa9e6','#7cc98f'],t:'3 ishchi soatiga 24, 20, 28 ta detal. 4-si qo‘shilgach o‘rtacha 25 bo‘ldi.',calc:['4 kishining yig‘indisi: 25 · 4 = 100','100 − (24 + 20 + 28) = 100 − 72 = <b>28</b>']},["Agar yangi ishchi 25 ta yasasa, o‘rtacha 25 dan kam chiqardi: (72 + 25) : 4 ≈ 24.","","24 — eski uch kishining o‘rtachasi."]),
 after:"<p>Eski o'rtacha 24 edi. Yangi ishchi o'rtachani 25 ga ko'tardi — demak u ko'proq yasaydi: o'rtachadan 3 ga ko'p, chunki u qolgan 3 kishining har biriga 1 tadan «ulashdi».</p>",
 q:{t:"4 bolaning o'rtacha bo'yi 130 sm. 5-bola qo'shilgach o'rtacha 132 sm bo'ldi. 5-bolaning bo'yi?",opts:["140 sm","132 sm","134 sm","142 sm"],ok:0,why:"132 · 5 − 130 · 4 = 660 − 520 = 140.",hint:"Yangi yig'indi − eski yig'indi.",full:"Eski yig'indi: 130 · 4 = 520. Yangi: 132 · 5 = 660. Farq: 140 sm. «132» — o'rtachaning o'zi, «134» — 132 + 2 (faqat bitta bolaga qo'shilgan)."},
 tn:"Bank: 233-id. Minoralarda ko'rsating: yangi minora har bir eski minoraga bittadan kubik berib, o'zi ham 25 da qoladi."}),
e6st({h:"Tuzoq: ikkitasi teng",sum:"O‘rtacha 22, Hakim 26, Tohir va Kamol teng: 66 − 26 = 40, 40 : 2 = 20.",a:"m06",
 frames:[{t:'Tohir, Kamol va Hakimning o‘rtacha ochkosi 22. Tohir va Kamol teng, Hakim 26.',bars:[{lab:'jami',y:70,segs:[{w:20,txt:'Tohir',c:'b'},{w:20,txt:'Kamol',c:'b'},{w:26,txt:'26',c:'a'}]}],br:[{b:0,lab:'22 · 3 = ?',col:C.blue}],note:'Ochkolar yig‘indisidan boshlaymiz'},
  {t:'Tohir, Kamol va Hakimning o‘rtacha ochkosi 22. Tohir va Kamol teng, Hakim 26.',bars:[{lab:'jami',y:70,segs:[{w:20,txt:'20',c:'g'},{w:20,txt:'20',c:'g'},{w:26,txt:'26',c:'a'}]}],br:[{b:0,lab:'66',col:C.blue},{b:0,from:0,to:1,lab:'40',up:true,col:C.ok}],calc:['1) 22 · 3 = 66','2) 66 − 26 = 40','3) 40 : 2 = <b>20</b> ochkodan']}],
 html:"<p>O'rtacha va chizma model birga ishlaydi. Tugmani bosing.</p>",
 after:"<p>Tekshiruv: (20 + 20 + 26) : 3 = 66 : 3 = 22 ✓.</p>",
 q:{t:"To'rt sonning o'rtachasi 15. Uchtasi teng, to'rtinchisi 24. Teng sonlar nechadan?",opts:["12","15","20","9"],ok:0,why:"15 · 4 = 60; 60 − 24 = 36; 36 : 3 = 12.",hint:"Yig'indi = 15 · 4.",full:"60 − 24 = 36; 36 : 3 = 12. Tekshiruv: (12 · 3 + 24) : 4 = 15 ✓. «20» — (60 − 24) : ... noto'g'ri bo'linish; «9» — 24 − 15."},
 tn:"Bank: 272-id."}),
e6st({h:"Muvozanat sirlari",sum:"12, 15, 18, 19: o‘rtacha 16. Farqlar −4, −1, +2, +3 — yig‘indisi 0.",a:"m07",
 frames:[{v:[12,15,18,19],lab:['A','B','C','D'],mx:20,u:100,line:16,t:'Ballar: 12, 15, 18, 19. O‘rtacha 16.',note:'O‘rtachadan qanchaga farq qiladi?'},
  {v:[12,15,18,19],lab:['A','B','C','D'],mx:20,u:100,line:16,t:'Farqlar: −4, −1, +2, +3',c:['#f08aa8','#f08aa8','#7cc98f','#7cc98f'],calc:['Kamchilik: 4 + 1 = 5','Ortiqcha: 2 + 3 = 5 — <b>teng!</b>']},
  {v:[12,15,18,19],lab:['A','B','C','D'],mx:20,u:100,line:16,t:'O‘rtacha har doim eng kichik va eng katta orasida',c:['#f08aa8','#f08aa8','#7cc98f','#7cc98f'],calc:['12 ≤ 16 ≤ 19','Tez hisob: 16 deb taxmin → farqlar 0 → to‘g‘ri!']}],
 html:"<p>O'rtacha — tarozining <b>tayanch nuqtasi</b>. Tugmani bosib, sirini oching.</p>",
 after:"<p>Bu sirdan <b>tez hisob</b> chiqadi: 47, 52, 49, 56 ning o'rtachasini topish uchun 50 deb oling: farqlar −3, +2, −1, +6 = +4; 4 : 4 = 1 → o'rtacha 51.</p>",
 q:{t:"Hisoblamasdan o'ylang: 8, 11, 14, 19 ning o'rtachasi quyidagilardan qaysi biri bo'lishi MUMKIN?",opts:["13","7","20","52"],ok:0,why:"O'rtacha 8 va 19 orasida bo'lishi kerak — faqat 13 mos. Tekshiruv: 52 : 4 = 13.",hint:"O'rtacha eng kichik va eng katta son orasida yotadi.",full:"7 &lt; 8 va 20 &gt; 19 — chegaradan tashqarida, bo'lishi mumkin emas. 52 — bu yig'indi, bo'linmagan. Faqat 13 qoladi: (8 + 11 + 14 + 19) : 4 = 52 : 4 = 13."},
 tn:"Gollandiya RME uslubi: o'rtachani «adolatli ulush» va «muvozanat» sifatida tushuntirish. Chizg'ich va tangalar bilan tarozi yasab ko'rsating."}),
e6st({h:"Tuzoq: o‘rtacha tezlik",sum:"2 soat 60 km/soat, 1 soat 90 km/soat: (120 + 90) : 3 = 70 km/soat (75 emas!).",a:"m08",
 frames:[{t:'Avtobus 2 soat 60 km/soat, keyin 1 soat 90 km/soat tezlikda yurdi. O‘rtacha tezligi?',bars:[{lab:'yo‘l',y:76,segs:[{w:60,txt:'60',c:'a'},{w:60,txt:'60',c:'a'},{w:90,txt:'90',c:'b'}]}],max:210,note:'Tanlang:'}],
 html:"<p>O'rtacha tezlik ham o'rta arifmetik — lekin <b>nimaning</b>? Tanlang:</p>",
 btns:e6pk(["75 km/soat","70 km/soat","150 km/soat"],1,{t:'O‘rtacha tezlik = jami yo‘l : jami vaqt',bars:[{lab:'yo‘l',y:76,segs:[{w:70,txt:'70',c:'g'},{w:70,txt:'70',c:'g'},{w:70,txt:'70',c:'g'}]}],max:210,br:[{b:0,lab:'210 km, 3 soat',col:C.ok}],calc:['2 · 60 + 90 = 210 km,  2 + 1 = 3 soat','210 : 3 = <b>70</b> km/soat']},["75 = (60 + 90) : 2 — lekin 60 km/soat tezlikda ko‘proq vaqt (2 soat) yurilgan.","","150 — tezliklar qo‘shilgan, bo‘linmagan."]),
 after:"<p>O'rtacha tezlik = <b>jami yo'l : jami vaqt</b>. Bu har bir soatning tezligini o'rtachalash bilan bir xil: (60 + 60 + 90) : 3 = 70.</p>",
 q:{t:"Piyoda 3 soat 4 km/soat, 1 soat 8 km/soat tezlikda yurdi. O'rtacha tezligi?",opts:["5 km/soat","6 km/soat","12 km/soat","20 km/soat"],ok:0,why:"(12 + 8) : 4 = 5.",hint:"Jami yo'l va jami vaqt.",full:"Yo'l: 3 · 4 + 8 = 20 km. Vaqt: 4 soat. 20 : 4 = 5 km/soat. «6» — (4 + 8) : 2."},
 tn:"Bu tur 5–6-sinf olimpiadalarida ham uchraydi; 4-sinfda «har bir soatni alohida yozish» usuli bilan tushuntiring."}),
e6st({h:"Bilasizmi? Ob-havo «normasi»",sum:"Meteorologlar iqlim normasini 30 yillik o‘rtacha qiymat sifatida hisoblaydi.",a:"m09",
 frames:[{v:[2,4,1,5,3],u:100,mx:6,lab:['1','2','3','4','5'],line:3,t:'Kunlik harorat (°C) va o‘rtacha',note:'«Normadan 5 daraja yuqori» — o‘rtachadan yuqori degani'}],
 html:"<p>🌡️ Ob-havo xabarida «harorat <b>normadan</b> yuqori» deyishadi. Norma — o'rtacha qiymat. Jahon meteorologiya tashkiloti iqlim normasini <b>30 yillik</b> kuzatuvlarning o'rta arifmetigi sifatida hisoblashni tavsiya qiladi.</p>",
 after:"<p>Shifokorlar, sportchilar, fermerlar — hamma o'rtacha bilan ishlaydi: o'rtacha bo'y, o'rtacha natija, o'rtacha hosil.</p>",
 tn:"Bir hafta davomida sinf derazasidagi termometrdan haroratni yozib, juma kuni o'rtachasini hisoblang."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e6tw({v:[3,7,5],u:1,mx:7,lab:['a','b','c'],line:5,t:'O‘rtacha = yig‘indi : soni'})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>O'rtacha = yig'indi : sonlar soni.</b></li><li>Ma'nosi: hammasini <b>tenglashtirsak</b>, har biri shuncha bo'ladi.</li><li>Teskari: <b>yig'indi = o'rtacha · soni</b> — yo'qolgan sonni topish.</li><li>Takrorlanuvchi qiymatlarni hamma sanog'i bilan oling (6 kun · 75).</li><li>O'rtacha eng kichik va eng katta orasida bo'ladi.</li><li>Farqlar: ortiqcha = kamchilik.</li><li>O'rtacha tezlik = jami yo'l : jami vaqt.</li></ul></div>",
 tn:"Kirish testida bolalarning o'rtacha bahosini birga hisoblang — mavzu hayotiy bo'lib qoladi."}
];
var PROBS=[
{t:"6, 2, 9, 3 sonlarining o'rta arifmetigi?",o:["5","20","4","6"],k:0,s:"20 : 4 = 5."},
{t:"Velosipedchi 18, 27, 24, 31 km yurdi. Kuniga o'rtacha necha km?",o:["25","100","24","26"],k:0,s:"100 : 4 = 25."},
{t:"28, 30, 25, 29, 33 sonlarining o'rtachasi?",o:["29","145","30","28"],k:0,s:"145 : 5 = 29."},
{t:"Fermer 6 kun 75 kg dan, 4 kun 85 kg dan pomidor terdi. Kuniga o'rtacha?",o:["79 kg","80 kg","790 kg","78 kg"],k:0,s:"790 : 10 = 79."},
{t:"Do'kon 3 kun 40 tadan, 2 kun 50 tadan non sotdi. O'rtacha kuniga?",o:["44","45","220","46"],k:0,s:"220 : 5 = 44."},
{t:"Ikki sonning o'rtachasi 64, biri 87. Ikkinchisi?",o:["41","23","128","151"],k:0,s:"128 − 87 = 41."},
{t:"Uch sonning o'rtachasi 30; ikkitasi 25 va 38. Uchinchisi?",o:["27","33","90","63"],k:0,s:"90 − 63 = 27."},
{t:"3 ishchi soatiga 24, 20, 28 ta detal yasaydi. 4-si qo'shilgach o'rtacha 25 bo'ldi. 4-si nechta yasaydi?",o:["28","25","24","26"],k:0,s:"100 − 72 = 28."},
{t:"4 bolaning o'rtacha bo'yi 130 sm. 5-si qo'shilgach o'rtacha 132 sm. 5-bolaning bo'yi?",o:["140 sm","132 sm","134 sm","142 sm"],k:0,s:"660 − 520 = 140."},
{t:"Tohir, Kamol, Hakimning o'rtacha ochkosi 22. Tohir va Kamol teng, Hakim 26. Tohir nechta oldi?",o:["20","18","22","21"],k:0,s:"(66 − 26) : 2 = 20."},
{t:"To'rt sonning o'rtachasi 15. Uchtasi teng, to'rtinchisi 24. Teng sonlar?",o:["12","15","20","9"],k:0,s:"(60 − 24) : 3 = 12."},
{t:"Hayot 1-kuni 36 ta, 2-kuni 18 ta ko'p, 3-kuni 2-kunidan 27 ta kam masala yechdi. Kuniga o'rtacha?",o:["39","42","117","38"],k:0,s:"36 + 54 + 27 = 117; 117 : 3 = 39."},
{t:"Avtobus 2 soat 60 km/soat, 1 soat 90 km/soat yurdi. O'rtacha tezlik?",o:["70 km/soat","75 km/soat","150 km/soat","65 km/soat"],k:0,s:"210 : 3 = 70."},
{t:"Piyoda 3 soat 4 km/soat, 1 soat 8 km/soat yurdi. O'rtacha tezlik?",o:["5 km/soat","6 km/soat","12 km/soat","4 km/soat"],k:0,s:"20 : 4 = 5."},
{t:"8, 11, 14, 19 sonlarining o'rta arifmetigi?",o:["13","52","12","14"],k:0,s:"52 : 4 = 13."},
{t:"5 ta sonning o'rtachasi 40. Bitta son 60 ga almashtirildi va o'rtacha 44 bo'ldi. Almashtirilgan son nechchi edi?",o:["40","20","56","16"],k:0,s:"Yig'indi 200 dan 220 ga oshdi (+20); 60 − 20 = 40."},
{t:"Sinfdagi 10 o'g'il bolaning o'rtacha vazni 32 kg, 15 qiz bolaniki 27 kg. Butun sinfning o'rtacha vazni?",o:["29 kg","29 kg 500 g","725 kg","31 kg"],k:0,s:"(320 + 405) : 25 = 725 : 25 = 29."},
{t:"Uch kunda o'rtacha 50 ta konfet sotildi. 4-kuni 70 ta sotildi. Endi o'rtacha?",o:["55","60","70","52"],k:0,s:"(150 + 70) : 4 = 55."},
{t:"Ketma-ket 5 ta sonning o'rtachasi 34. Eng kattasi?",o:["36","34","38","170"],k:0,s:"32, 33, 34, 35, 36."},
{t:"Ali 4 ta testdan o'rtacha 18 ball oldi. O'rtacha 20 bo'lishi uchun 5-testdan necha ball olishi kerak?",o:["28","20","22","2"],k:0,s:"20 · 5 − 18 · 4 = 100 − 72 = 28."}
];
function PRACT_STAGE(){e6tw({v:[3,7,5],u:1,mx:7,lab:['a','b','c'],line:5,t:'O‘rtacha = yig‘indi : soni'})}
var PREP_DATA={teach:["O'rta arifmetikning ma'nosi: tenglashtirish (adolatli ulush).","Hisoblash: yig'indi : soni; teskari: yig'indi = o'rtacha · soni.","Takrorlanuvchi qiymatlar, yangi a'zo qo'shilishi, yo'qolgan sonni topish.","O'rtachaning xossalari: farqlar muvozanati, chegaralar; o'rtacha tezlik."],
 mist:["Yig'indini bo'lishni unutadi.","Takrorlanuvchi qiymatlarda (6 kun 75, 4 kun 85) faqat ikkita sonni o'rtachalaydi.","Teskari masalada o'rtachani yig'indi deb oladi.","O'rtacha tezlikni tezliklarning o'rtachasi deb hisoblaydi."],
 need:["Kubiklar yoki tayoqchalar (minoralar uchun).","Doskada ustunli diagramma.","Chizg'ich va tangalar (muvozanat tarozisi)."],
 board:["<span class='w2'>(3 + 7 + 5) : 3 = 5</span>.","<span class='w2'>(6 · 75 + 4 · 85) : 10 = 79</span>.","<span class='w2'>64 · 2 − 87 = 41</span>.","<span class='w2'>25 · 4 − 72 = 28</span>.","<span class='w2'>(2 · 60 + 90) : 3 = 70</span>."]};
