var CODE='3B3',TITLE='3-sinf · Yozma (ustun) ayirish';
function w3b3Ph(a,b,msgs){var P=[],n=String(a).length;for(var i=0;i<=n;i++)(function(k){P.push(function(){bqCol(a,b,'−',k,{hl:k<n?k:null});bqMsg(msgs[k]||'')})})(i);return P}
var P1=w3b3Ph(685,243,['Xona ostida xona: birlik ostida birlik, o‘nlik ostida o‘nlik','Birliklar: 5 − 3 = 2','O‘nliklar: 8 − 4 = 4','Yuzliklar: 6 − 2 = 4. Javob: <b>442</b>']);
var P2=w3b3Ph(572,138,['Birliklardan boshlaymiz','2 dan 8 ayirib bo‘lmaydi → 1 o‘nlik olamiz: 12 − 8 = 4','O‘nliklar: 7 edi, 1 berdi → 6. 6 − 3 = 3','Yuzliklar: 5 − 1 = 4. Javob: <b>434</b>']);
var P3=w3b3Ph(821,476,['Ikki marta qarz olish kerak bo‘ladi','11 − 6 = 5 (o‘nlikdan oldik, 2 → 1 qoldi)','1 dan 7 olmaydi → yuzlikdan olamiz: 11 − 7 = 4','Yuzliklar: 8 − 1 = 7, 7 − 4 = 3. Javob: <b>345</b>']);
var P4=w3b3Ph(600,257,['Tuzoq: o‘nlik ham, birlik ham 0!','O‘nlik 0 — yuzlikdan olamiz: 6 yuz → 5 yuz + 9 o‘nlik + 10 birlik. 10 − 7 = 3','O‘nliklar: 9 − 5 = 4','Yuzliklar: 5 − 2 = 3. Javob: <b>343</b>']);
var P5=w3b3Ph(1000,376,['1000 − 376: uchta nol ketma-ket!','Mingdan olamiz: 1000 = 9 yuz + 9 o‘nlik + 10 birlik. 10 − 6 = 4','9 − 7 = 2','9 − 3 = 6','Ming ustuni bo‘shadi. Javob: <b>624</b>']);
var P6=[function(){bqCol(1000,376,'−',null);bqMsg('1000 − 376 = 624. To‘g‘rimi? Tekshiramiz')},function(){bqCol(624,376,'+',null);bqMsg('Ayirmaga ayriluvchini qo‘shamiz: 624 + 376 = <b>1000</b> ✓ — kamayuvchi chiqdi')}];
var P7=[function(){bqExpr(['8□2 − 36□ = 457']);bqMsg('Ikki raqam yashiringan. Ayirishni qo‘shish bilan almashtiramiz')},
 function(){bqExpr(['457 + 36□ = 8□2']);bqMsg('Kamayuvchi = ayirma + ayriluvchi')},
 function(){bqExpr(['7 + □ = …2  →  □ = [5]']);bqMsg('Birliklar: 7 + 5 = 12 → 2 yoziladi, 1 eslab qolinadi')},
 function(){bqExpr(['5 + 6 + 1 = 1[2]  →  □ = [2]']);bqMsg('O‘nliklar: 12 → 2 yoziladi. Yuzliklar: 4 + 3 + 1 = 8 ✓')},
 function(){bqCol(822,365,'−',null);bqMsg('Javob: <b>822 − 365 = 457</b>')}];
var STEPS=[
{h:"Ustunda yozish qoidasi",sum:"Xona ostida xona. Ayirish birliklardan boshlanadi: 685 − 243 = 442.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Katta sonlarni og'zaki ayirish qiyin. Shuning uchun ularni <b>ustun</b> qilib yozamiz: birlik ostida birlik, o'nlik ostida o'nlik, yuzlik ostida yuzlik. Har bosishda bitta xona hisoblanadi.</p>",
 btns:[phaser(P1)],after:"<p>Ayirish har doim <b>birliklardan</b> (o'ngdan) boshlanadi. Xonalarni aralashtirib yozsak, 6 yuzlikdan 3 birlikni ayirib qo'yamiz — bu xato.</p>",
 q:{t:"Ustunda 947 − 325 ni hisoblang.",opts:["622","672","1272","612"],ok:0,why:"7 − 5 = 2, 4 − 2 = 2, 9 − 3 = 6.",hint:"Birliklardan boshlang: 7 − 5 = ?",full:"Birliklar: 7 − 5 = 2. O'nliklar: 4 − 2 = 2. Yuzliklar: 9 − 3 = 6. Javob: 622. «1272» — ayirish o'rniga qo'shilgan."},
 tn:"Daftarda katakchalarga yozdiring: har raqam — o'z katagida. Xonalar ustunlarini rangli qalam bilan ajratib qo'yish yordam beradi."},
{h:"Qarz olish (o'nlikdan)",sum:"572 − 138: 2 dan 8 olmaydi → o'nlikdan 1 olamiz: 12 − 8 = 4. Javob 434.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>572 − 138. Birliklarda 2 dan 8 ni ayirib bo'lmaydi. Nima qilamiz? Kuzating.</p>",btns:[phaser(P2)],
 after:"<p>Qo'shni o'nlikdan <b>bitta o'nlik</b> «qarz olamiz»: 2 birlik 12 ga aylanadi, o'nliklar esa 1 taga kamayadi. Shuning uchun ustiga kichik qilib yangi raqam yoziladi va eski raqam chiziladi.</p>",
 q:{t:"572 − 138 ni bir o'quvchi 446 deb topdi. U qayerda xato qildi?",opts:["8 − 2 = 6 deb, kichikdan kattani teskari ayirgan","Yuzliklarni qo'shib yuborgan","Hech qayerda — 446 to'g'ri","O'nliklarni ayirmagan"],ok:0,why:"2 − 8 o'rniga 8 − 2 qilingan — qarz olinmagan.",hint:"Birliklar ustunida 2 − 8 qanday hisoblangan?",full:"Bu eng ko'p uchraydigan xato: «kattadan kichikni ayiraman» deb 8 − 2 = 6 yozish. To'g'risi: o'nlikdan qarz olib, 12 − 8 = 4. O'nliklar 6 bo'ladi: 6 − 3 = 3. Javob 434."},
 tn:"«Kichikdan kattani teskari ayirish» xatosi xalqaro tadqiqotlarda eng ko'p qayd etilgan. Bolalar o'nlik tayoqchalari bilan qarz olishni qo'li bilan bajarib ko'rsin."},
{h:"Ikki marta qarz olish",sum:"821 − 476: ikki marta qarz → 345.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>821 − 476. Bu yerda birliklarda ham, o'nliklarda ham qarz kerak bo'ladi.</p>",btns:[phaser(P3)],
 after:"<p>Har bir ustunda alohida savol: «ustdagi son pastdagidan kichikmi?» Kichik bo'lsa — chapdagi qo'shnidan qarz olamiz. Qarz bergan xona 1 taga kamayadi.</p>",
 q:{t:"Ustunda 734 − 258 ni hisoblang.",opts:["476","524","486","576"],ok:0,why:"14 − 8 = 6, 12 − 5 = 7, 6 − 2 = 4.",hint:"Birliklarda 4 − 8 — qarz kerak. O'nliklarda ham tekshiring.",full:"Birliklar: 14 − 8 = 6 (o'nliklar 3 → 2). O'nliklar: 2 − 5 olmaydi → 12 − 5 = 7 (yuzliklar 7 → 6). Yuzliklar: 6 − 2 = 4. Javob 476. «524» — teskari ayirish xatosi."},
 tn:"Har bir ustunda bola ovoz chiqarib aytsin: «4 dan 8 olmaydi, o'nlikdan olaman…»."},
{h:"Tuzoq: nollar bor kamayuvchi",sum:"600 − 257: o'nlik 0 — yuzlikdan olamiz: 5 yuz + 9 o'nlik + 10 birlik. Javob 343.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>600 − 257. Birlikda 0, o'nlikda ham 0. Qayerdan qarz olamiz?</p>",btns:[phaser(P4)],
 after:"<p>O'nlik bo'sh bo'lsa, qarz <b>yuzlikdan</b> olinadi va u yo'lda maydalanadi: 1 yuzlik = 9 o'nlik + 10 birlik. Shuning uchun nol ustiga <b>9</b> yoziladi.</p>",
 q:{t:"Ustunda 500 − 163 ni hisoblang.",opts:["337","447","463","347"],ok:0,why:"500 = 4 yuz + 9 o'nlik + 10 birlik: 10 − 3 = 7, 9 − 6 = 3, 4 − 1 = 3.",hint:"Yuzlikdan qarz olganda o'nliklar ustiga nima yoziladi?",full:"500 → 4 yuz, 9 o'nlik, 10 birlik. 10 − 3 = 7, 9 − 6 = 3, 4 − 1 = 3. Javob 337. «447» — yuzlikni kamaytirishni unutgan; «463» — teskari ayirgan."},
 tn:"Pul bilan ko'rsating: 500 so'mlik qog'ozni maydalaymiz — 4 ta yuzlik, 9 ta o'nlik va 10 ta birlik."},
{h:"1000 dan ayirish",sum:"1000 − 376 = 624: mingdan qarz → 9 yuz, 9 o'nlik, 10 birlik.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=4;P5[4]()},
 html:"<p>1000 − 376 — uchta nol ketma-ket. Bunday misollar testda ko'p keladi.</p>",btns:[phaser(P5)],
 after:"<p>1000 = <b>9 yuz + 9 o'nlik + 10 birlik</b>. Tez usul: oxirgi raqamni 10 dan, qolganlarini 9 dan ayiring: 1000 − 376 → (9 − 3)(9 − 7)(10 − 6) = <b>624</b>.</p>",
 q:{t:"1000 − 458 = ?",opts:["542","652","552","642"],ok:0,why:"9 − 4 = 5, 9 − 5 = 4, 10 − 8 = 2.",hint:"Yuzlik va o'nlik raqamlarini 9 dan, birlikni 10 dan ayiring.",full:"9 − 4 = 5, 9 − 5 = 4, 10 − 8 = 2: 542. Tekshiramiz: 542 + 458 = 1000 ✓. «652» — hammasi 10 dan ayirilgan."},
 tn:"«9-9-10 usuli» do'konda qaytim hisoblashda juda qulay: 1000 so'mdan 376 so'm."},
{h:"Tekshirish: qo'shish bilan",sum:"Ayirma + ayriluvchi = kamayuvchi: 624 + 376 = 1000 ✓.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Javob to'g'ri ekanini qanday bilamiz? Ayirishni qo'shish bilan tekshiramiz.</p>",btns:[phaser(P6,'▶ Tekshirish')],
 after:"<p>Qoida: <b>ayirma + ayriluvchi = kamayuvchi</b>. Agar natija kamayuvchiga teng chiqmasa — qayerdadir xato bor. Testda vaqtingiz bo'lsa, doim tekshiring.</p>",
 q:{t:"Ali 803 − 246 = 567 deb yozdi. Tekshiruv nima ko'rsatadi?",opts:["567 + 246 = 813 — xato, javob 557","567 + 246 = 803 — to'g'ri","803 + 246 = 1049 — to'g'ri","567 − 246 = 321 — to'g'ri"],ok:0,why:"Yig'indi 803 chiqishi kerak edi, 813 chiqdi — xato. To'g'risi 557.",hint:"Ayirmaga ayriluvchini qo'shing va kamayuvchi bilan solishtiring.",full:"567 + 246 = 813 ≠ 803 — demak xato. To'g'ri hisob: 803 − 246 = 557 (557 + 246 = 803 ✓). Ali o'nliklarda qarzni unutgan."},
 tn:"Bolalar juft-juft ishlasin: biri ayiradi, ikkinchisi qo'shish bilan tekshiradi."},
{h:"Tuzoq: yashiringan raqamlar",sum:"8□2 − 36□ = 457 → qo'shish bilan: 457 + 365 = 822. Raqamlar 2 va 5.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=4;P7[4]()},
 html:"<p>Olimpiada savoli: <b>8□2 − 36□ = 457</b>. Kvadratlar o'rnida qaysi raqamlar? Ayirishni qo'shishga aylantirib yechamiz.</p>",btns:[phaser(P7)],
 after:"<p>Yashiringan raqamli ayirishni <b>qo'shish</b> qilib yechish oson: kamayuvchi = ayirma + ayriluvchi. Keyin birliklardan boshlab har xonani tiklaymiz.</p>",
 q:{t:"7□3 − 25□ = 487. Ikki kvadrat o'rnidagi raqamlar yig'indisi nechaga teng?",opts:["10","9","12","8"],ok:0,why:"487 + 256 = 743: raqamlar 4 va 6, yig'indisi 10.",hint:"487 + 25□ = 7□3 ni birliklardan boshlab tiklang: 7 + □ = …3.",full:"Birliklar: 7 + □ = 13 → □ = 6, 1 eslab qolinadi. O'nliklar: 8 + 5 + 1 = 14 → kamayuvchining o'nligi 4, 1 eslab qolinadi. Yuzliklar: 4 + 2 + 1 = 7 ✓. Demak 743 − 256 = 487, raqamlar 4 va 6, yig'indisi 10."},
 tn:"Bunday jumboqlarni bolalar o'zi tuzib, bir-biriga bersin."},
{h:"Bilasizmi? Ayirishning boshqa usuli",sum:"Ba'zi mamlakatlarda «teng qo'shish» usuli bilan ayiriladi — natija bir xil.",a:"m08",start:function(){bqExpr(['52 − 18','= (52 + 10) − (18 + 10)','= 62 − 28 = 34']);bqMsg('Ikkala songa bir xil son qo‘shsak, ayirma o‘zgarmaydi')},fin:function(){bqExpr(['52 − 18','= (52 + 10) − (18 + 10)','= 62 − 28 = 34']);bqMsg('Ikkala songa bir xil son qo‘shsak, ayirma o‘zgarmaydi')},
 html:"<p>📜 Biz qarz olib ayiramiz. Lekin XX asrning boshlarida ko'p mamlakatlarda <b>«teng qo'shish»</b> usuli o'rgatilgan: kamayuvchiga ham, ayriluvchiga ham bir xil son qo'shiladi — ayirma o'zgarmaydi.</p><p>🧠 Bu xossa og'zaki hisobda juda qulay: 1000 − 376 = 999 − 375 = <b>624</b> — umuman qarz kerak emas!</p>",
 btns:[["💡 999 usulini ko'rish",function(c,done){bqExpr(['1000 − 376','= 999 − 375','= [624]']);bqMsg('Ikkalasidan 1 ni ayirdik — ayirma o‘zgarmadi, qarz esa kerak bo‘lmadi');done()}]],
 tn:"Kuchli o'quvchilarga «1000 − 376 = 999 − 375» usulini ko'rsating — ular uni yaxshi ko'radi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqCol(600,257,'−',null);bqMsg('600 − 257 = 343')},fin:function(){bqCol(600,257,'−',null);bqMsg('600 − 257 = 343')},
 html:"<div class='memo'><ul><li>Xona ostida xona; ayirish <b>birliklardan</b> boshlanadi.</li><li>Ustdagi raqam kichik bo'lsa — chapdagi qo'shnidan <b>1 ni qarz</b> olamiz (o'ngdagi +10, chapdagi −1).</li><li>Qo'shni xona 0 bo'lsa — qarz uzoqroqdan keladi, nollar <b>9</b> ga aylanadi: 600 = 5 yuz + 9 o'nlik + 10.</li><li>1000 dan ayirish: raqamlarni 9, 9, 10 dan ayiring: 1000 − 376 = 624.</li><li>Tekshirish: <b>ayirma + ayriluvchi = kamayuvchi</b>.</li><li>Xato: «kattadan kichikni teskari ayirish» (2 − 8 o'rniga 8 − 2).</li></ul></div>",
 tn:"Keyingi darsni «1000 − 1 = ?» va «700 − 1 = ?» og'zaki savollari bilan boshlang."}
];
var PROBS=[
{t:"Ustunda hisoblang: 869 − 437",o:["432","422","1306","442"],k:0,s:"9 − 7 = 2, 6 − 3 = 3, 8 − 4 = 4: 432."},
{t:"Ustunda hisoblang: 742 − 315",o:["427","437","433","527"],k:0,s:"12 − 5 = 7, 3 − 1 = 2, 7 − 3 = 4: 427."},
{t:"Ustunda hisoblang: 653 − 278",o:["375","425","385","475"],k:0,s:"13 − 8 = 5; 4 − 7 → 14 − 7 = 7; 5 − 2 = 3: 375."},
{t:"Ustunda hisoblang: 900 − 384",o:["516","626","524","616"],k:0,s:"900 = 8 yuz + 9 o'nlik + 10: 10 − 4 = 6, 9 − 8 = 1, 8 − 3 = 5: 516."},
{t:"1000 − 627 = ?",o:["373","483","383","473"],k:0,s:"9 − 6 = 3, 9 − 2 = 7, 10 − 7 = 3: 373."},
{t:"Ustunda hisoblang: 805 − 469",o:["336","446","344","436"],k:0,s:"15 − 9 = 6; 0 − 6 → yuzlikdan: 9 − 6 = 3; 7 − 4 = 3: 336."},
{t:"Kamayuvchi 720, ayriluvchi 385. Ayirma nechaga teng?",o:["335","445","345","1105"],k:0,s:"720 − 385 = 335. Tekshirish: 335 + 385 = 720."},
{t:"Ayirma 248, ayriluvchi 365. Kamayuvchini toping.",o:["613","117","603","513"],k:0,s:"Kamayuvchi = ayirma + ayriluvchi = 248 + 365 = 613."},
{t:"Qaysi misolda qarz olish kerak emas?",o:["786 − 352","731 − 258","604 − 127","810 − 345"],k:0,s:"786 − 352: 6 ≥ 2, 8 ≥ 5, 7 ≥ 3 — qarz yo'q."},
{t:"Kutubxonada 1000 ta kitob bor edi, 236 tasi berildi. Nechtasi qoldi?",o:["764","874","774","864"],k:0,s:"1000 − 236: 9 − 2 = 7, 9 − 3 = 6, 10 − 6 = 4: 764."},
{t:"Ali 634 − 287 = 453 deb yozdi. To'g'ri javob qaysi?",o:["347","453","357","447"],k:0,s:"14 − 7 = 7; 2 − 8 → 12 − 8 = 4; 5 − 2 = 3: 347. Ali teskari ayirgan."},
{t:"8□2 − 36□ = 457. Kvadratlar o'rnidagi raqamlar qaysi?",o:["2 va 5","5 va 2","1 va 5","2 va 6"],k:0,s:"457 + 365 = 822: kamayuvchida 2, ayriluvchida 5."},
{t:"□□□ − 199 = 600. Kamayuvchini toping.",o:["799","401","789","800"],k:0,s:"600 + 199 = 799."},
{t:"Eng katta uch xonali sondan eng kichik uch xonali sonni ayiring.",o:["899","900","889","999"],k:0,s:"999 − 100 = 899."},
{t:"Raqamlari har xil eng katta uch xonali sondan raqamlari har xil eng kichik uch xonali sonni ayiring.",o:["885","887","899","875"],k:0,s:"987 − 102 = 885."},
{t:"500 − 1 − 1 − 1 = ?",o:["497","499","470","400"],k:0,s:"500 − 3 = 497."},
{t:"Do'konga 640 kg un keltirildi. 1-kuni 275 kg, 2-kuni 198 kg sotildi. Necha kg qoldi?",o:["167","365","267","177"],k:0,s:"640 − 275 = 365, 365 − 198 = 167."},
{t:"Qaysi ayirmaning qiymati eng katta?",o:["900 − 456","800 − 367","700 − 299","1000 − 589"],k:0,s:"444, 433, 401, 411 — eng kattasi 900 − 456 = 444."},
{t:"Ikki sonning ayirmasi 375. Kamayuvchini 100 ga orttirsak, ayirma qanday bo'ladi?",o:["475","275","375","385"],k:0,s:"Kamayuvchi 100 ga ortsa, ayirma ham 100 ga ortadi: 475."},
{t:"Ikki sonning ayirmasi 375. Ayriluvchini 100 ga orttirsak, ayirma qanday bo'ladi?",o:["275","475","375","365"],k:0,s:"Ayriluvchi ortsa, ayirma kamayadi: 375 − 100 = 275."}
];
function PRACT_STAGE(){bqCol(742,315,'−',null);bqMsg('Har misolni ustunda yozib, birliklardan boshlang')}
var PREP_DATA={teach:["Ustunda yozish: xona ostida xona, birliklardan boshlash.","Bir va ikki marta qarz olish; nollar bor kamayuvchi (600, 805, 1000).","Ayirishni qo'shish bilan tekshirish.","Yashiringan raqamli ayirish jumboqlari."],
 mist:["Kichikdan kattani teskari ayiradi (2 − 8 o'rniga 8 − 2).","Qarz bergan xonani kamaytirishni unutadi.","Nol ustidan qarz olganda 9 o'rniga 10 yozadi.","Xonalarni ustunda noto'g'ri tekislaydi."],
 need:["O'nlik bloklar yoki pul (yuzlik, o'nlik, birlik).","Katakli daftar."],
 board:["<span class='w2'>685 − 243 = 442</span> — qarzsiz.","<span class='w2'>572 − 138 = 434</span> — bir marta qarz.","<span class='w2'>821 − 476 = 345</span> — ikki marta.","<span class='w2'>600 − 257 = 343</span> — nollar.","<span class='w2'>1000 − 376 = 624</span> (9-9-10).","Tekshirish: <span class='w2'>624 + 376 = 1000</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<n)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=Math.max(W*p/tot,34);E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,p+' · '+b+' = '+(p*b),{'font-size':w<70?10:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
