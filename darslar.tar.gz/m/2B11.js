var CODE='2B11',TITLE='2-sinf · Qo‘shishning xossalari';
function b11Dots(a,b,swap){clear();var g=S.g,A=swap?b:a,B=swap?a:b;var cols=[swap?C.b:C.a,swap?C.a:C.b];
 for(var i=0;i<A+B;i++){var x=40+i*28,ca=i<A;E('circle',{cx:x,cy:70,r:11,fill:ca?cols[0]:cols[1],stroke:'rgba(0,0,0,.15)'},g)}
 T(g,40+(A-1)*14,104,String(A),{'font-size':16,'font-weight':800,fill:cols[0]});T(g,40+A*28+(B-1)*14,104,String(B),{'font-size':16,'font-weight':800,fill:cols[1]});
 T(g,180,146,A+' + '+B+' = '+(A+B),{'font-size':22,'font-weight':800,fill:'#1d2b3a'})}
var P2=[function(){bqBar(67,[{v:'17',w:17},{v:'26',w:26,col:C.b},{v:'24',w:24,col:C.c}],{title:'17 + 26 + 24'});bqMsg('Uchta qo‘shiluvchi. Qaysi ikkitasini avval qo‘shamiz?')},
 function(){bqExpr(['(17 + 26) + 24','43 + 24 = [67]']);bqMsg('Birinchi yo‘l: avval 17 + 26 = 43, keyin 43 + 24 = 67')},
 function(){bqExpr(['17 + (26 + 24)','17 + 50 = [67]']);bqMsg('Ikkinchi yo‘l: avval 26 + 24 = 50 (yaxlit!), keyin 17 + 50 = 67. Natija bir xil, lekin osonroq')}];
var P5=[function(){bqExpr(['9 − 4 = 5','4 − 9 = ?']);bqMsg('Ayirishda ham o‘rin almashtirsa bo‘ladimi?')},
 function(){bqBar(9,[{v:'4',w:4,col:'#e9e2d6'},{v:'5',w:5,col:C.ok}],{title:'9 − 4 = 5'});bqMsg('9 tadan 4 tasini olsak — 5 qoladi')},
 function(){bqExpr(['9 − 4 ≠ 4 − 9','4 tadan 9 tani olib bo‘lmaydi']);bqMsg('Ayirishda o‘rin almashtirish <b>mumkin emas</b> — bu xossa faqat qo‘shish uchun!')}];
var STEPS=[
{h:"O'rin almashtirish xossasi",sum:"3 + 5 = 5 + 3: qo'shiluvchilar o'rni almashsa, yig'indi o'zgarmaydi.",a:"m01",
 start:function(){b11Dots(3,5,false);bqMsg('3 ta sariq va 5 ta ko‘k. Tugmani bosib, o‘rinlarini almashtiring')},fin:function(){b11Dots(3,5,true)},
 html:"<p>3 ta sariq va 5 ta ko'k doira. Ularning o'rnini almashtirsak, hammasi nechta bo'ladi?</p>",
 btns:[["⇄ O'rnini almashtir",function(c,done){S.sw=!S.sw;b11Dots(3,5,S.sw);bqMsg(S.sw?'5 + 3 = 8 — xuddi 3 + 5 kabi!':'3 + 5 = 8');mvK(done,2)}]],
 after:"<p>Doiralar soni o'zgarmadi — faqat joyi almashdi. <b>Qo'shiluvchilarning o'rnini almashtirish bilan yig'indi o'zgarmaydi</b>: a + b = b + a.</p>",
 q:{t:"45 + 28 = 28 + □. Kvadrat o'rniga qaysi son?",opts:["73","45","28","17"],ok:1,why:"O'rin almashtirish: 45 + 28 = 28 + 45.",hint:"Hisoblash shart emas. Qo'shiluvchilar qanday o'zgardi?",full:"Chap tomonda 45 va 28, o'ng tomonda 28 va □. O'rin almashgan — □ = 45. Hisoblasak ham: 73 − 28 = 45."},
 tn:"Bu xossa ko'paytirish jadvalini ikki barobar qisqartiradi (2C6). Hozirdan «kattasidan boshlab sanash» usulini o'rgating: 3 + 8 = 8 + 3."},
{h:"Guruhlash xossasi",sum:"(17 + 26) + 24 = 17 + (26 + 24): qaysi ikkitasini avval qo'shsak ham yig'indi bir xil.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Uchta sonni qo'shishda <b>qaysi ikkitasini birinchi</b> qo'shishni o'zimiz tanlashimiz mumkin. Kuzating:</p>",
 btns:[phaser(P2)],
 after:"<p><b>Guruhlash xossasi:</b> (a + b) + c = a + (b + c). Bu xossa tufayli qulay juftni — yaxlit son beradiganini — birinchi qo'shamiz.</p>",
 q:{t:"Qaysi guruhlash eng qulay: 38 + 45 + 2?",opts:["(38 + 45) + 2","38 + (45 + 2)","(38 + 2) + 45","hammasi bir xil qiyin"],ok:2,why:"38 + 2 = 40 — yaxlit son.",hint:"Qaysi ikkitasi qo'shilib yaxlit son beradi?",full:"38 + 2 = 40, keyin 40 + 45 = 85. Natija har qanday guruhlashda 85, lekin bu yo'l eng oson."},
 tn:"Guruhlashni rangli qavslar bilan ko'rsating — bir xil ifodaning uch xil guruhlanishi."},
{h:"Ikkala xossa birga",sum:"17 + 26 + 33 + 24 = (17 + 33) + (26 + 24) = 50 + 50 = 100.",a:"m03",
 start:function(){bqPairs([17,26,33,24],function(a,b){return (a+b)%10===0},function(){bqMsg('(17 + 33) + (26 + 24) = 50 + 50 = <b>100</b>');if(S.d3)S.d3()},{title:'17 + 26 + 33 + 24 — yaxlit beradigan juftlarni toping'});bqMsg('Yig‘indisi 0 bilan tugaydigan juftlarni bosing')},
 fin:function(){bqExpr(['17 + 26 + 33 + 24','(17 + 33) + (26 + 24)','50 + 50 = 100'])},
 html:"<p>O'rin almashtirish va guruhlash xossalari birga ishlatilsa, hisob juda osonlashadi. Juftlarni toping:</p>",
 act:function(c,done){S.d3=function(){S.d3=null;done()}},
 after:"<p>Biz 33 ni 26 dan oldinga ko'chirdik (o'rin almashtirish) va juftlarni qavsga oldik (guruhlash). Natija o'zgarmadi, hisob esa og'zaki bo'ldi.</p>",
 q:{t:"24 + 38 + 16 + 22 = ?",opts:["90","110","100","96"],ok:2,why:"(24 + 16) + (38 + 22) = 40 + 60 = 100.",hint:"Birliklari 4 + 6 va 8 + 2 bo'lgan juftlarni toping.",full:"24 + 16 = 40, 38 + 22 = 60, 40 + 60 = 100."},
 tn:"Bu — 2B6 dagi «juftlab qo'shish»ning nazariy asosi."},
{h:"Nol bilan qo'shish",sum:"a + 0 = a: songa nolni qo'shsak, son o'zgarmaydi.",a:"m04",
 start:function(){b11Zero(false)},fin:function(){b11Zero(true)},
 html:"<p>Savatda 7 ta olma bor. Unga <b>hech narsa</b> qo'shmasak, nechta bo'ladi?</p>",
 btns:[["➕ 0 ta qo'shish",function(c,done){b11Zero(true);done()}]],
 after:"<p><b>a + 0 = a</b> va <b>0 + a = a</b>. Nol — qo'shishda «hech narsa» degani. Xuddi shunday: <b>a − 0 = a</b>, <b>a − a = 0</b>.</p>",
 q:{t:"58 + 0 − 58 = ?",opts:["58","0","116","1"],ok:1,why:"58 + 0 = 58, 58 − 58 = 0.",hint:"Songa 0 qo'shsak nima bo'ladi? Keyin o'zidan o'zini ayiring.",full:"58 + 0 = 58 (nol qo'shildi — o'zgarmadi), 58 − 58 = 0 (o'zidan o'zi ayirildi). Javob 0."},
 tn:"Nolning xossalari 4-qismda (119-dars) ko'paytirish bilan ham o'tiladi: a · 0 = 0. Hozircha faqat qo'shish-ayirish."},
{h:"Tuzoq: ayirishda bu xossa yo'q!",sum:"9 − 4 ≠ 4 − 9. O'rin almashtirish faqat qo'shishda ishlaydi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Qo'shishda o'rin almashtirsa bo'ladi. Ayirishda-chi? Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>Ayirishda kamayuvchi va ayriluvchi o'rnini almashtirib <b>bo'lmaydi</b>. Lekin ifodada son o'z belgisi bilan ko'chishi mumkin: 50 − 8 + 8 = 50 + 8 − 8.</p>",
 q:{t:"Qaysi tenglik NOTO'G'RI?",opts:["25 + 13 = 13 + 25","40 − 15 = 15 − 40","30 + 0 = 30","(5 + 7) + 3 = 5 + (7 + 3)"],ok:1,why:"Ayirishda o'rin almashtirish mumkin emas.",hint:"Qaysi tenglikda ayirishda o'rin almashtirilgan?",full:"25 + 13 = 13 + 25 ✓ (o'rin almashtirish). 40 − 15 = 25, 15 − 40 — bunday ayirib bo'lmaydi ✗. 30 + 0 = 30 ✓. Guruhlash ✓."},
 tn:"Bolalar «hamma amalda o'rin almashadi» deb umumlashtirib yuboradi — ayirishda albatta qarshi misol ko'rsating."},
{h:"Tuzoq: xossani tanib oling",sum:"38 + 57 = 57 + 38 — o'rin almashtirish; (12 + 8) + 9 = 12 + (8 + 9) — guruhlash.",a:"m06",
 start:function(){bqExpr(['(12 + 8) + 9 = 12 + (8 + 9)']);bqMsg('Bu qaysi xossa?')},fin:function(){bqExpr(['(12 + 8) + 9 = 12 + (8 + 9)','guruhlash xossasi'])},
 html:"<p>Tenglik qaysi xossaga misol? Tanlang:</p>",
 btns:[["O'rin almashtirish",function(c,done,b){flashBad(b);bqMsg('Sonlar tartibi o‘zgarmadi: 12, 8, 9 — faqat qavs ko‘chdi')}],["Guruhlash",function(c,done,b){bqExpr(['(12 + 8) + 9 = 12 + (8 + 9)','guruhlash xossasi']);bqMsg('To‘g‘ri: sonlar joyida, qavslar (guruhlar) o‘zgardi');c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});done()},'u']],g2:1,
 after:"<p>Farqi: <b>o'rin almashtirishda</b> sonlarning tartibi o'zgaradi; <b>guruhlashda</b> tartib o'sha, faqat qaysi ikkitasi birinchi qo'shilishi o'zgaradi.</p>",
 q:{t:"Qaysi tenglik o'rin almashtirish xossasiga misol?",opts:["38 + 57 = 57 + 38","(4 + 6) + 5 = 4 + (6 + 5)","17 + 0 = 17","20 − 5 = 15"],ok:0,why:"Qo'shiluvchilar o'rni almashgan.",hint:"Qaysi tenglikda sonlar joyini almashtirgan?",full:"38 + 57 = 57 + 38 — o'rin almashtirish. Ikkinchisi — guruhlash, uchinchisi — nol bilan qo'shish."},
 tn:"Xossa nomlarini kartochkaga yozib, tengliklarga mos qo'yish o'yinini o'ynating."},
{h:"Tuzoq: ko'p qo'shiluvchi",sum:"8 + 27 + 2 + 13 = (8 + 2) + (27 + 13) = 10 + 40 = 50.",a:"m07",
 start:function(){bqPairs([8,27,2,13],function(a,b){return (a+b)%10===0},function(){bqMsg('(8 + 2) + (27 + 13) = 10 + 40 = <b>50</b>');if(S.d7)S.d7()},{title:'8 + 27 + 2 + 13'});bqMsg('Yaxlit son beradigan juftlarni bosing')},
 fin:function(){bqExpr(['8 + 27 + 2 + 13','(8 + 2) + (27 + 13)','10 + 40 = 50'])},
 html:"<p>To'rtta qo'shiluvchi. Xossalardan foydalanib, og'zaki hisoblang:</p>",
 act:function(c,done){S.d7=function(){S.d7=null;done()}},
 after:"<p>Qo'shiluvchilar ko'p bo'lsa ham, xossalar tufayli ularni istalgan tartibda va istalgan guruhlarda qo'shish mumkin.</p>",
 q:{t:"6 + 35 + 4 + 15 = ?",opts:["50","60","70","56"],ok:1,why:"(6 + 4) + (35 + 15) = 10 + 50 = 60.",hint:"6 bilan qaysi son yaxlit beradi? 35 bilan-chi?",full:"6 + 4 = 10, 35 + 15 = 50, jami 60."},
 tn:"Musobaqa: kim tezroq og'zaki hisoblaydi — juftlab yoki tartib bilan."},
{h:"Bilasizmi? Xossalarning nomlari",sum:"O'rin almashtirish — «kommutativ» (lotincha commutare — almashtirmoq), guruhlash — «assotsiativ» (associare — birlashtirmoq).",a:"m08",
 start:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)']);bqMsg('Xossalar harflar bilan')},fin:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)'])},
 html:"<p>📜 Matematiklar xossalarni <b>harflar</b> bilan yozadi — chunki ular istalgan son uchun to'g'ri. Xalqaro nomlari lotin tilidan olingan: <b>kommutativ</b> (commutare — «almashtirmoq») va <b>assotsiativ</b> (associare — «birlashtirmoq»).</p>",
 btns:[["📜 Ko'rdim",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Siz katta sinflarda bu nomlarni yana uchratasiz. Harflar bilan yozish — algebraning boshlanishi, uni esa al-Xorazmiy tizimga solgan.</p>",
 tn:"Harfli yozuvni bolalarga «istalgan son qo'yish mumkin bo'lgan quti» deb tushuntiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)','a + 0 = a'])},fin:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)','a + 0 = a'])},
 html:"<div class='memo'><ul><li><b>O'rin almashtirish</b>: a + b = b + a (45 + 28 = 28 + 45).</li><li><b>Guruhlash</b>: (a + b) + c = a + (b + c).</li><li>Ikkalasi birga: qulay juftlarni birinchi qo'shing — 17 + 26 + 33 + 24 = 100.</li><li><b>Nol</b>: a + 0 = a, a − 0 = a, a − a = 0.</li><li><b>Ayirishda o'rin almashtirib bo'lmaydi!</b> 9 − 4 ≠ 4 − 9.</li></ul></div>",
 tn:"Keyingi darsda (2B12) bu xossalar ayirishga qanday qo'llanishini ko'rasiz."}
];
function b11Zero(on){clear();var g=S.g;E('path',{d:'M110 70 L250 70 L235 140 L125 140 Z',fill:'#e9c48a',stroke:C.line,'stroke-width':2},g);for(var i=0;i<7;i++)E('circle',{cx:135+(i%4)*30,cy:i<4?100:78,r:12,fill:'#e05555',stroke:'#a33'},g);
 T(g,180,40,on?'7 + 0 = 7':'7 + ? ',{'font-size':22,'font-weight':800,fill:on?C.ok:'#1d2b3a'});bqMsg(on?'Hech narsa qo‘shmadik — 7 ta qoldi':'Savatda 7 ta olma')}
var PROBS=[
{t:"45 + 28 = 28 + □. □ = ?",o:["45","28","73","17"],k:0,s:"O'rin almashtirish."},
{t:"Qaysi guruhlash eng qulay: 38 + 45 + 2?",o:["(38 + 2) + 45","(38 + 45) + 2","38 + (45 + 2)","hammasi bir xil"],k:0,s:"38 + 2 = 40."},
{t:"17 + 26 + 33 + 24 = ?",o:["100","90","110","99"],k:0,s:"(17 + 33) + (26 + 24)."},
{t:"24 + 38 + 16 + 22 = ?",o:["100","90","110","96"],k:0,s:"40 + 60."},
{t:"58 + 0 − 58 = ?",o:["0","58","116","1"],k:0,s:"58 − 58 = 0."},
{t:"Qaysi tenglik NOTO'G'RI?",o:["40 − 15 = 15 − 40","25 + 13 = 13 + 25","30 + 0 = 30","(5 + 7) + 3 = 5 + (7 + 3)"],k:0,s:"Ayirishda o'rin almashtirib bo'lmaydi."},
{t:"Qaysi tenglik o'rin almashtirish xossasiga misol?",o:["38 + 57 = 57 + 38","(4 + 6) + 5 = 4 + (6 + 5)","17 + 0 = 17","20 − 5 = 15"],k:0,s:"Sonlar o'rni almashgan."},
{t:"Qaysi tenglik guruhlash xossasiga misol?",o:["(9 + 1) + 6 = 9 + (1 + 6)","9 + 6 = 6 + 9","9 + 0 = 9","9 − 9 = 0"],k:0,s:"Qavslar ko'chgan."},
{t:"6 + 35 + 4 + 15 = ?",o:["60","50","70","56"],k:0,s:"(6 + 4) + (35 + 15)."},
{t:"8 + 27 + 2 + 13 = ?",o:["50","40","60","48"],k:0,s:"(8 + 2) + (27 + 13)."},
{t:"a + 19 = 19 + 36. a = ?",o:["36","19","55","17"],k:0,s:"O'rin almashtirish."},
{t:"(25 + □) + 8 = 25 + (12 + 8). □ = ?",o:["12","8","25","20"],k:0,s:"Guruhlash: □ = 12."},
{t:"47 + 0 = ?",o:["47","0","470","48"],k:0,s:"a + 0 = a."},
{t:"36 − 36 + 15 = ?",o:["15","36","87","0"],k:0,s:"36 − 36 = 0, 0 + 15 = 15."},
{t:"1 + 9 + 2 + 8 + 3 + 7 = ?",o:["30","27","20","33"],k:0,s:"Uchta o'nlik juft: 30."},
{t:"13 + 28 + 7 + 2 = ?",o:["50","40","48","60"],k:0,s:"(13 + 7) + (28 + 2) = 20 + 30."},
{t:"Qaysi ifodaning qiymati 52 + 39 ga teng?",o:["39 + 52","52 − 39","39 − 52","52 + 93"],k:0,s:"O'rin almashtirish."},
{t:"Ali: «9 − 4 = 4 − 9». U haqmi?",o:["Yo'q, ayirishda o'rin almashtirib bo'lmaydi","Ha, bu o'rin almashtirish","Ha, ikkalasi 5","Yo'q, ikkalasi 13"],k:0,s:"Xossa faqat qo'shishda."},
{t:"19 + 45 + 1 + 35 = ?",o:["100","90","110","95"],k:0,s:"(19 + 1) + (45 + 35) = 20 + 80."},
{t:"(37 + 28) + 2 ni qulay hisoblash uchun qanday guruhlash kerak?",o:["37 + (28 + 2)","(37 + 2) + 28","(37 + 28) + 2","37 − (28 + 2)"],k:0,s:"28 + 2 = 30, 37 + 30 = 67."}
];
function PRACT_STAGE(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)']);bqMsg('Qulay juftni toping')}
var PREP_DATA={teach:["O'rin almashtirish xossasi: a + b = b + a.","Guruhlash xossasi va ikkalasini birga ishlatish.","Nol bilan qo'shish va ayirish.","Ayirishda o'rin almashtirib bo'lmasligi; xossani tanish."],
 mist:["Ayirishda ham o'rin almashtiradi (40 − 15 = 15 − 40).","O'rin almashtirish va guruhlashni adashtiradi.","Xossani bilsa ham, hisobda ishlatmaydi.","a + 0 ni 0 deb yozadi."],
 need:["Ikki rangli fishkalar.","Xossa nomli kartochkalar."],
 board:["<span class='w2'>3 + 5 = 5 + 3</span>.","<span class='w2'>(17 + 26) + 24 = 17 + (26 + 24)</span>.","<span class='w2'>(17 + 33) + (26 + 24) = 100</span>.","<span class='w2'>7 + 0 = 7</span>.","<span class='w2'>9 − 4 ≠ 4 − 9</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
