var CODE='2H14',TITLE='2-sinf · Tarozi va muvozanat masalalari';
// ---------- sahna: pallali tarozi ----------
// L, R: [{l:'yozuv', c:'rang', w:og'irlik yoki null}], tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir (null bo'lsa — hisoblanadi)
function h14Sum(a){var s=0;for(var i=0;i<a.length;i++){if(a[i].w==null)return null;s+=a[i].w}return s}
function h14Scale(L,R,tilt,o){o=o||{};clear();var g=S.g;
 if(tilt==null){var a=h14Sum(L),b=h14Sum(R);tilt=(a==null||b==null)?0:(a>b?-1:(a<b?1:0))}
 var ang=tilt*9,cx=180,cy=50,half=120,rad=ang*Math.PI/180;
 E('path',{d:'M150 168 L210 168 L188 150 L172 150 Z',fill:'#8a6a4a'},g);E('rect',{x:176,y:52,width:8,height:100,fill:'#a07d55'},g);
 var lx=cx-half*Math.cos(rad),ly=cy-half*Math.sin(rad),rx=cx+half*Math.cos(rad),ry=cy+half*Math.sin(rad);
 E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#6b4a2a','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:7,fill:'#6b4a2a'},g);
 // ko'rsatkich
 E('line',{x1:cx,y1:cy,x2:cx-Math.sin(rad)*-22,y2:cy-22,stroke:tilt===0?C.ok:C.bad,'stroke-width':3},g);
 [[lx,ly,L],[rx,ry,R]].forEach(function(z){var px=z[0],py=z[1]+40;E('line',{x1:z[0],y1:z[1],x2:px-38,y2:py,stroke:'#999','stroke-width':1.5},g);E('line',{x1:z[0],y1:z[1],x2:px+38,y2:py,stroke:'#999','stroke-width':1.5},g);
  E('path',{d:'M'+(px-46)+' '+py+' Q'+px+' '+(py+16)+' '+(px+46)+' '+py+' Z',fill:'#c9b28d',stroke:'#8a6a4a','stroke-width':1.5},g);
  var items=z[2],n=items.length,per=Math.min(3,n),bw=26,bh=22;
  items.forEach(function(it,i){var row=Math.floor(i/3),col=i%3,cnt=Math.min(3,n-row*3),bx=px-cnt*bw/2-2+col*(bw+2),by=py-bh-row*(bh+2)-1;
   E('rect',{x:bx,y:by,width:bw,height:bh,rx:it.round?11:4,fill:it.c||C.a,stroke:'rgba(0,0,0,.25)','stroke-width':1},g);T(g,bx+bw/2,by+15,it.l,{'font-size':it.l.length>3?9:11,'font-weight':800,fill:'#1d2b3a'})})});
 S.L=L;S.R=R}
function h14Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function kg(n,c){return {l:n+'kg',w:n,c:c||'#c9d3dd'}}
// ---------- bosqichlar ----------
var P2=[function(){h14Scale([{l:'?',c:C.b,w:null},kg(2)],[kg(9)],0);h14Msg('Chapda: quti va 2 kg. O‘ngda: 9 kg. Tarozi teng. Quti necha kg?')},
 function(){h14Scale([{l:'?',c:C.b,w:null},{l:'2kg',w:2,c:'#ffd0d0'}],[{l:'2kg',w:2,c:'#ffd0d0'},kg(7)],0);h14Msg('9 kg ni <b>2 kg + 7 kg</b> deb almashtiramiz — tarozi baribir teng')},
 function(){h14Scale([{l:'?',c:C.b,w:null}],[kg(7)],0);h14Msg('Ikkala palladan <b>bir xil</b> 2 kg ni olamiz — muvozanat buzilmaydi')},
 function(){h14Scale([{l:'7kg',c:C.b,w:7}],[kg(7)],0);h14Msg('Quti = <b>7 kg</b>. Tekshiramiz: 7 + 2 = 9 ✓')}];
var P3=[function(){h14Scale([kg(46)],[{l:'?',c:C.a,w:null},{l:'?',c:C.a,w:null}],0);h14Msg('46 kg = 2 ta bir xil quti. 3 ta quti necha kg?')},
 function(){h14Scale([kg(23),kg(23)],[{l:'?',c:C.a,w:null},{l:'?',c:C.a,w:null}],0);h14Msg('46 ni ikkita teng bo‘lakka bo‘lamiz: 46 : 2 = <b>23</b>')},
 function(){h14Scale([kg(23)],[{l:'23',c:C.a,w:23}],0);h14Msg('Bitta quti = 23 kg')},
 function(){h14Scale([{l:'23',c:C.a,w:23},{l:'23',c:C.a,w:23},{l:'23',c:C.a,w:23}],[kg(69)],0);h14Msg('3 ta quti: 23 + 23 + 23 = <b>69 kg</b>')}];
var P4=[function(){h14Scale([{l:'nok',c:'#cde89a',w:null},{l:'nok',c:'#cde89a',w:null},{l:'nok',c:'#cde89a',w:null},{l:'nok',c:'#cde89a',w:null}],[{l:'qovun',c:'#f6e08a',w:null,round:1}],0);h14Msg('1-tarozi: <b>4 nok = 1 qovun</b>. 2-ma’lumot: <b>2 qulupnay = 1 nok</b>')},
 function(){var L=[];for(var i=0;i<8;i++)L.push({l:'qlp',c:'#f6a5b5',w:null,round:1});h14Scale(L,[{l:'qovun',c:'#f6e08a',w:null,round:1}],0);h14Msg('Har bir nok o‘rniga 2 ta qulupnay: 4 · 2 = <b>8 qulupnay = 1 qovun</b>')},
 function(){h14Scale([{l:'qovun',c:'#f6e08a',w:null,round:1},{l:'qovun',c:'#f6e08a',w:null,round:1}],[{l:'16 qlp',c:'#f6a5b5',w:null}],0);h14Msg('2 ta qovun = 8 + 8 = <b>16 qulupnay</b>')}];
var P5=[function(){h14Scale([{l:'olma',c:'#f08a8a',w:null,round:1},{l:'olma',c:'#f08a8a',w:null,round:1},{l:'nok',c:'#cde89a',w:null}],[kg(10)],0);h14Msg('2 olma + 1 nok = 10 kg. Bitta olma — 3 kg. Nok necha kg?')},
 function(){h14Scale([{l:'3kg',c:'#f08a8a',w:3,round:1},{l:'3kg',c:'#f08a8a',w:3,round:1},{l:'nok',c:'#cde89a',w:null}],[kg(10)],0);h14Msg('Ma’lumini o‘rniga qo‘yamiz: olma o‘rniga 3 kg')},
 function(){h14Scale([{l:'nok',c:'#cde89a',w:null}],[kg(4)],0);h14Msg('Ikkala palladan 6 kg olamiz: 10 − 6 = <b>4 kg</b> — nok')}];
var STEPS=[
{h:"Tarozini tenglang",sum:"Tarozi teng (muvozanatda) bo'lsa — ikkala palladagi og'irlik bir xil.",a:"m01",
 start:function(){S.r=[];h14Scale([kg(7)],[],null);h14Msg('Chapda 7 kg. O‘ng pallaga toshlar qo‘yib, tarozini tenglang')},fin:function(){h14Scale([kg(7)],[kg(5),kg(2)],null);h14Msg('7 = 5 + 2 — tarozi teng ✓')},
 html:"<p>Chap pallada <b>7 kg</b> tosh bor. O'ng pallaga toshlar qo'ying va tarozini <b>teng</b> qiling (ko'rsatkich yashil bo'lsin). Oshib ketsa — «Tozalash».</p>",
 btns:[["+1 kg",function(c,done){h14Add(1,done)}],["+2 kg",function(c,done){h14Add(2,done)}],["+5 kg",function(c,done){h14Add(5,done)}],["Tozalash",function(c,done){S.r=[];h14Scale([kg(7)],[],null);h14Msg('O‘ng palla bo‘sh')}]],g2:1,
 after:"<p>Tarozi teng bo'ldi — demak ikkala palla <b>bir xil og'ir</b>. Masalalarda «tarozi muvozanatda» degani — «chapdagi og'irlik = o'ngdagi og'irlik».</p>",
 q:{t:"Chapda 12 kg, o'ngda 5 kg va 4 kg. Tarozi teng bo'lishi uchun o'ngga yana nechta kg qo'yish kerak?",opts:["12 kg","9 kg","3 kg","7 kg"],ok:2,why:"5 + 4 = 9, 12 − 9 = 3 kg yetmaydi.",hint:"Avval o'ngdagi toshlarni qo'shing. 12 gacha qancha yetmaydi?",full:"O'ngda 5 + 4 = 9 kg. Chap 12 kg. Farq 12 − 9 = 3 kg — shuni qo'yamiz. «9 kg» — o'ngdagi og'irlik, savol esa yetishmaydiganini so'rayapti."},
 tn:"Sinfda chizg'ich va ikki stakan bilan oddiy tarozi yasash mumkin. Bolalar tangalar qo'yib tenglasin."},
{h:"Ikkala palladan bir xilini olib tashlaymiz",sum:"Quti + 2 kg = 9 kg → ikkala palladan 2 kg olamiz → quti = 7 kg.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Chapda noma'lum quti va 2 kg, o'ngda 9 kg — tarozi teng. Qutini qanday topamiz? Kuzating.</p>",
 btns:[phaser(P2)],
 after:"<p>Asosiy qoida: <b>ikkala palladan bir xil narsani olsak yoki qo'shsak — tarozi teng qoladi</b>. Shunda noma'lum yolg'iz qoladi.</p>",
 q:{t:"Chapda quti va 15 kg, o'ngda 23 kg. Tarozi teng. Quti necha kg?",opts:["38 kg","8 kg","15 kg","23 kg"],ok:1,why:"Ikkala palladan 15 kg olsak: quti = 23 − 15 = 8 kg.",hint:"Ikkala palladan 15 kg ni olib tashlang. O'ngda nima qoladi?",full:"Quti + 15 = 23. Ikkala tomondan 15 olamiz: quti = 23 − 15 = 8 kg. «38» — qo'shib yuborilgan, bu xato."},
 tn:"Bu qadam — tenglamaning ilk ko'rinishi (x + 2 = 9). Doskada tarozi chizib, ikkala pallasidan bir xil narsani o'chirib ko'rsating."},
{h:"Bir xil qutilar",sum:"46 kg = 2 ta bir xil quti → bitta quti 23 kg → 3 ta quti 69 kg.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Chapda 46 kg, o'ngda 2 ta <b>bir xil</b> quti. Shunday 3 ta quti necha kg keladi?</p>",
 btns:[phaser(P3)],
 after:"<p>Avval <b>bitta</b> qutining og'irligini topamiz (46 : 2 = 23), keyin kerakli sonini: 23 · 3 = 69. «Avval bittasi» — bunday masalalarning kaliti.</p>",
 q:{t:"Chapda 30 kg, o'ngda 3 ta bir xil quti. Shunday 2 ta quti necha kg?",opts:["15 kg","20 kg","10 kg","60 kg"],ok:1,why:"Bitta quti 30 : 3 = 10 kg, 2 ta — 20 kg.",hint:"Avval bitta qutini toping: 30 ni nechaga bo'lamiz?",full:"3 quti = 30 kg → 1 quti = 10 kg → 2 quti = 20 kg. «10» — bitta quti, savol esa ikkitasini so'rayapti."},
 tn:"«Avval bittasini top» qoidasi keyinchalik «birga keltirish» masalalarining asosi bo'ladi."},
{h:"Almashtirish zanjiri",sum:"4 nok = 1 qovun, 2 qulupnay = 1 nok → 1 qovun = 8 qulupnay → 2 qovun = 16 qulupnay.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«4 ta nok — 1 ta qovun bilan teng. 2 ta qulupnay — 1 ta nok bilan teng. 2 ta qovun nechta qulupnay bilan teng?» Bir narsani boshqasiga almashtirib boramiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Usul: tarozidagi narsalarni <b>ma'lum narsaga almashtiramiz</b>: har nok o'rniga 2 ta qulupnay. Shunda qovunni qulupnayda o'lchay olamiz.</p>",
 q:{t:"3 ta olma = 1 ta tarvuz, 2 ta gilos = 1 ta olma. 1 ta tarvuz nechta gilos bilan teng?",opts:["5","6","3","9"],ok:1,why:"Har olma — 2 gilos: 3 · 2 = 6.",hint:"Har bir olmani 2 ta gilosga almashtiring.",full:"Tarvuz = 3 olma, olma = 2 gilos. Tarvuz = 2 + 2 + 2 = 6 gilos. «5» — 3 + 2 qo'shilgan, lekin almashtirishda ko'paytiramiz."},
 tn:"Kartochkalar bilan o'ynang: «1 nok kartochkasini 2 ta qulupnay kartochkasiga almashtirish mumkin»."},
{h:"Ma'lumini o'rniga qo'yamiz",sum:"2 olma + nok = 10 kg, olma = 3 kg → 6 + nok = 10 → nok = 4 kg.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Tarozida turli narsalar bo'lsa: avval og'irligi <b>ma'lum</b> narsani son bilan almashtiramiz, keyin qolganini topamiz.</p>",
 btns:[phaser(P5)],
 after:"<p>Olma o'rniga 3 kg qo'ydik — endi tarozida bitta noma'lum qoldi: 6 + nok = 10, nok = 4 kg.</p>",
 q:{t:"Chapda kuchukcha va 2 kg, o'ngda 9 kg. Shunday 2 ta kuchukcha necha kg?",opts:["7 kg","11 kg","14 kg","18 kg"],ok:2,why:"Kuchukcha 9 − 2 = 7 kg, ikkitasi 14 kg.",hint:"Avval bitta kuchukchani toping (ikkala palladan 2 kg oling).",full:"Kuchukcha + 2 = 9 → kuchukcha = 7 kg. 2 ta kuchukcha: 7 + 7 = 14 kg. «18» — 9 ni ikkiga ko'paytirib, 2 kg ni unutish xatosi."},
 tn:"Bankdagi rasmli tarozi masalalari aynan shu ikki qadamdan iborat: almashtir → olib tashla."},
{h:"Tuzoq: ikki tarozi birga",sum:"1-tarozi: mushuk + it = 15; 2-tarozi: it = mushuk + 3 → 2 ta mushuk + 3 = 15 → mushuk = 6 kg.",a:"m06",
 start:function(){S.k6=0;h6(0)},fin:function(){h6(2)},
 html:"<p>Ikkala tarozi ham teng. <b>1-tarozi:</b> mushuk + it = 15 kg. <b>2-tarozi:</b> it = mushuk + 3 kg. Mushuk necha kg?</p>",
 btns:[["▶ Keyingi harakat",function(c,done,b){S.k6=(S.k6||0)+1;h6(S.k6);if(S.k6>=2){b.disabled=true;b.textContent='✓ Tayyor';done()}}]],
 after:"<p>2-tarozidan bilamiz: it = mushuk + 3. Shuni 1-taroziga qo'ydik: mushuk + mushuk + 3 = 15. Ikkala palladan 3 ni olsak: 2 ta mushuk = 12, mushuk = <b>6 kg</b>, it = 9 kg.</p>",
 q:{t:"Ikki tarozi teng: tarvuz + qovun = 20 kg; tarvuz = qovun + 4 kg. Qovun necha kg?",opts:["10 kg","8 kg","12 kg","16 kg"],ok:1,why:"Qovun + 4 + qovun = 20 → 2 qovun = 16 → qovun 8 kg.",hint:"Tarvuz o'rniga «qovun + 4» ni qo'ying.",full:"Tarvuz = qovun + 4. Unda: qovun + 4 + qovun = 20. 4 ni olib tashlasak, 2 ta qovun = 16, qovun = 8 kg, tarvuz = 12 kg. Tekshiramiz: 8 + 12 = 20 ✓."},
 tn:"Bu — kuchli bolalar uchun. Avval 2-tarozini tushuntiring, keyin uni 1-taroziga «ko'chiring»."},
{h:"Bilasizmi? «Al-jabr» va «al-muqobala»",sum:"Al-Xorazmiy kitobi: «al-jabr» — to'ldirish, «al-muqobala» — ikki tomondan bir xilini olib tashlash (tenglash).",a:"m07",
 start:function(){h14Scale([{l:'x',c:C.b,w:null},kg(2)],[kg(9)],0);h14Msg('x + 2 = 9')},fin:function(){h14Scale([{l:'x',c:C.b,w:null},kg(2)],[kg(9)],0);h14Msg('x + 2 = 9 → x = 7')},
 html:"<p>⭐ Vatandoshimiz <b>Muhammad al-Xorazmiy</b> IX asrda «<b>Al-jabr val-muqobala</b>» kitobini yozgan. «Al-muqobala» — aynan biz bugun qilgan ish: ikkala tomondan <b>bir xil</b> narsani olib tashlab, tenglikni soddalashtirish. Bu kitob nomidan <b>«algebra»</b> so'zi kelib chiqqan.</p><p>Tarozi — tenglamaning eng chiroyli rasmi: <b>x + 2 = 9</b>.</p>",
 tn:"Bolalarga «siz bugun haqiqiy algebra bilan shug'ullandingiz» deb ayting — ular juda faxrlanadi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h14Scale([kg(7)],[kg(5),kg(2)],null);h14Msg('7 = 5 + 2')},fin:function(){h14Scale([kg(7)],[kg(5),kg(2)],null);h14Msg('7 = 5 + 2')},
 html:"<div class='memo'><ul><li>Tarozi teng → ikkala palla <b>bir xil og'ir</b>.</li><li>Ikkala palladan <b>bir xil</b> narsani olsak yoki qo'shsak — tarozi teng qoladi.</li><li>Bir xil narsalar bo'lsa — <b>avval bittasini</b> toping (46 : 2 = 23).</li><li>Ma'lum narsani son bilan <b>almashtiring</b> (olma = 3 kg).</li><li>Almashtirish zanjiri: nok = 2 qulupnay → qovun = 4 nok = 8 qulupnay.</li><li>Ikki tarozi bo'lsa — birinchisidan bilganini ikkinchisiga qo'ying.</li><li>Oxirida <b>tekshiring</b>: topgan sonni taroziga qo'yib ko'ring.</li></ul></div>",
 tn:"Keyingi darsni «Chapda 3 ta bir xil quti va 4 kg, o'ngda 19 kg. Quti necha kg?» (5 kg) savoli bilan boshlang."}
];
function h14Add(n,done){S.r=S.r||[];var s=S.r.reduce(function(a,b){return a+b},0);if(s+n>12||S.r.length>=6){h14Msg('Pallada joy yetmaydi — «Tozalash»ni bosing');return}S.r.push(n);s+=n;h14Scale([kg(7)],S.r.map(function(v){return kg(v)}),null);
 if(s===7){h14Msg('7 = '+S.r.join(' + ')+' — tarozi <b>teng</b> ✓');done()}else h14Msg('O‘ngda '+s+' kg — '+(s<7?'yengil, yana qo‘ying':'og‘ir! «Tozalash» va qaytadan'))}
function h6(k){clear();var g=S.g;function mini(x,L,R,lab){E('line',{x1:x-56,y1:60,x2:x+56,y2:60,stroke:'#6b4a2a','stroke-width':5,'stroke-linecap':'round'},g);E('rect',{x:x-3,y:60,width:6,height:70,fill:'#a07d55'},g);E('rect',{x:x-24,y:128,width:48,height:8,rx:3,fill:'#8a6a4a'},g);
  [[x-56,L],[x+56,R]].forEach(function(z){E('path',{d:'M'+(z[0]-30)+' 92 Q'+z[0]+' 104 '+(z[0]+30)+' 92 Z',fill:'#c9b28d',stroke:'#8a6a4a'},g);E('line',{x1:z[0],y1:60,x2:z[0]-26,y2:92,stroke:'#999'},g);E('line',{x1:z[0],y1:60,x2:z[0]+26,y2:92,stroke:'#999'},g);
   z[1].forEach(function(it,i){var n=z[1].length,bw=n>2?20:26,bx=z[0]-n*(bw+1)/2+i*(bw+1);E('rect',{x:bx,y:70,width:bw,height:20,rx:4,fill:it[1],stroke:'rgba(0,0,0,.25)'},g);T(g,bx+bw/2,85,it[0],{'font-size':it[0].length<3?13:8,'font-weight':800,fill:'#1d2b3a'})})});T(g,x,154,lab,{'font-size':11,'font-weight':800,fill:C.blue})}
 var M=['🐱','#f6d9a8'],I=['🐶','#b7d7f2'],K15=['15kg','#c9d3dd'],K3=['3kg','#c9d3dd'];
 if(k===0){mini(90,[M,I],[K15],'1-tarozi');mini(270,[I],[M,K3],'2-tarozi');h14Msg('Ikkala tarozi teng. Mushuk necha kg?')}
 else if(k===1){mini(90,[M,M,K3],[K15],'1-tarozi: it o‘rniga');mini(270,[I],[M,K3],'2-tarozi');h14Msg('2-tarozidan: it = mushuk + 3. Uni 1-taroziga qo‘yamiz')}
 else{mini(90,[M,M],[['12kg','#c9d3dd']],'3 kg ni olib tashladik');mini(270,[['🐱','#f6d9a8']],[['6kg','#c9d3dd']],'javob');h14Msg('2 mushuk = 12 kg → mushuk = <b>6 kg</b>, it = 9 kg')}}
var PROBS=[
{t:"Chapda 8 kg, o'ngda 5 kg va quti. Tarozi teng. Quti necha kg?",o:["3 kg","13 kg","5 kg","8 kg"],k:0,s:"Quti = 8 − 5 = 3 kg."},
{t:"Chapda quti va 6 kg, o'ngda 20 kg. Tarozi teng. Quti necha kg?",o:["14 kg","26 kg","6 kg","20 kg"],k:0,s:"Ikkala palladan 6 kg olamiz: 20 − 6 = 14 kg."},
{t:"Chapda 46 kg, o'ngda 2 ta bir xil quti. Shunday 3 ta quti necha kg?",o:["69 kg","63 kg","23 kg","92 kg"],k:0,s:"Bitta quti 46 : 2 = 23 kg, 3 tasi 69 kg."},
{t:"Chapda 23 kg, o'ngda 15 kg va quti. Shunday 3 ta quti necha kg?",o:["24 kg","8 kg","38 kg","45 kg"],k:0,s:"Quti = 23 − 15 = 8 kg, 3 tasi 24 kg."},
{t:"4 ta nok = 1 ta qovun, 2 ta qulupnay = 1 ta nok. 2 ta qovun nechta qulupnay bilan teng?",o:["16","8","12","32"],k:0,s:"1 qovun = 4 nok = 8 qulupnay, 2 qovun = 16."},
{t:"Chapda 3 ta bir xil quti va 4 kg, o'ngda 19 kg. Bitta quti necha kg?",o:["5 kg","15 kg","7 kg","6 kg"],k:0,s:"Ikkala palladan 4 kg: 3 quti = 15 kg, 1 quti = 5 kg."},
{t:"2 ta olma va 1 ta nok — 10 kg. Bitta olma 3 kg. Nok necha kg?",o:["4 kg","7 kg","6 kg","1 kg"],k:0,s:"2 olma = 6 kg, nok = 10 − 6 = 4 kg."},
{t:"Har bir yashil shar 2 kg. Chapda 3 ta yashil shar, o'ngda 1 ta uchburchak. Tarozi teng. Uchburchak necha kg?",o:["6 kg","5 kg","3 kg","2 kg"],k:0,s:"3 · 2 = 6 kg."},
{t:"Tarvuz + 4 kg = 13 kg. Tarvuz necha kg?",o:["9 kg","17 kg","13 kg","8 kg"],k:0,s:"13 − 4 = 9 kg."},
{t:"Ikki tarozi teng: mushuk + it = 15 kg, it = mushuk + 3 kg. Mushuk necha kg?",o:["6 kg","9 kg","12 kg","3 kg"],k:0,s:"2 mushuk + 3 = 15 → 2 mushuk = 12 → mushuk 6 kg."},
{t:"1 ta ananas = 2 ta banan, 1 ta banan = 3 ta olcha. 2 ta ananas nechta olcha bilan teng?",o:["12","6","8","5"],k:0,s:"1 ananas = 6 olcha, 2 ananas = 12."},
{t:"Chapda 5 ta bir xil kubik, o'ngda 2 ta shunday kubik va 9 kg. Bitta kubik necha kg?",o:["3 kg","9 kg","2 kg","5 kg"],k:0,s:"Ikkala palladan 2 kubikni olsak: 3 kubik = 9 kg, 1 kubik = 3 kg."},
{t:"Chapda 30 kg, o'ngda 3 ta bir xil quti. Shunday 2 ta quti necha kg?",o:["20 kg","10 kg","15 kg","60 kg"],k:0,s:"Bitta quti 10 kg, 2 tasi 20 kg."},
{t:"Tarozi teng: chapda 2 ta qovun, o'ngda 1 ta tarvuz va 2 kg. Tarvuz 10 kg. Bitta qovun necha kg?",o:["6 kg","12 kg","5 kg","4 kg"],k:0,s:"O'ngda 10 + 2 = 12 kg, 2 qovun = 12 → qovun 6 kg."},
{t:"3 ta tovuq = 1 ta qo'y, 2 ta qo'y = 1 ta sigir. Sigir nechta tovuq bilan teng?",o:["6","5","3","9"],k:0,s:"Sigir = 2 qo'y = 2 · 3 = 6 tovuq."},
{t:"Ikki tarozi teng: tarvuz + qovun = 20 kg, tarvuz = qovun + 4 kg. Qovun necha kg?",o:["8 kg","10 kg","12 kg","16 kg"],k:0,s:"2 qovun + 4 = 20 → qovun 8 kg."},
{t:"Chapda 12 kg, o'ngda 5 kg va 4 kg. Tarozi teng bo'lishi uchun o'ngga yana nechta kg qo'yish kerak?",o:["3 kg","9 kg","12 kg","7 kg"],k:0,s:"12 − (5 + 4) = 3 kg."},
{t:"Chapda 4 ta bir xil shar, o'ngda 2 ta shunday shar va 10 kg. 3 ta shar necha kg?",o:["15 kg","10 kg","5 kg","30 kg"],k:0,s:"2 shar = 10 kg, 1 shar = 5 kg, 3 shar = 15 kg."},
{t:"Quti + quti + 7 kg = 25 kg. Bitta quti necha kg?",o:["9 kg","18 kg","16 kg","8 kg"],k:0,s:"2 quti = 25 − 7 = 18, 1 quti = 9 kg."},
{t:"1 ta qovun = 3 ta nok, 1 ta nok = 2 ta olma. 1 ta qovun va 1 ta nok birgalikda nechta olma bilan teng?",o:["8","6","5","9"],k:0,s:"Qovun = 6 olma, nok = 2 olma, jami 8."}
];
function PRACT_STAGE(){h14Scale([{l:'?',c:C.b,w:null},kg(2)],[kg(9)],0);h14Msg('Ikkala palladan bir xilini oling')}
var PREP_DATA={teach:["Tarozi muvozanati — ikkala palla og'irligi teng.","Ikkala palladan bir xil narsani olib tashlash (x + 2 = 9).","Bir xil qutilar: avval bittasini topish.","Almashtirish zanjiri; ma'lumini o'rniga qo'yish; ikki tarozi."],
 mist:["Tarozidagi sonlarni shunchaki qo'shib yuboradi (quti + 15 = 23 → 38).","Bir xil qutilardan bittasini topib, savolga emas, shu songa javob beradi.","Almashtirishda qo'shadi (3 olma = 6 gilos o'rniga 5).","Tekshirmaydi."],
 need:["Chizg'ich va ikki stakandan oddiy tarozi, tangalar.","Meva kartochkalari (nok, qovun, qulupnay)."],
 board:["Tarozi rasmi: <span class='w2'>[? 2kg] = [9kg]</span>.","Ikkala palladan 2 kg: <span class='w2'>? = 7</span>.","<span class='w2'>46 = 2 quti → 1 quti 23 → 3 quti 69</span>.","<span class='w2'>4 nok = 1 qovun, 2 qulupnay = 1 nok → 1 qovun = 8 qulupnay</span>.","Ikki tarozi: <span class='w2'>mushuk + mushuk + 3 = 15</span>."]};
