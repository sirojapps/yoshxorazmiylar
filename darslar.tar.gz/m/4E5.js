var CODE='4E5',TITLE='4-sinf · Ish unumi masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
function e5bars(n,v,c){var s=[];for(var i=0;i<n;i++)s.push({w:v,txt:v,c:c||'a'});return s}
var STEPS=[
e4st({h:"Uch kattalik: unum, vaqt, ish",sum:"Usta soatiga 12 ta detal yasaydi, 5 soat ishladi: 12 · 5 = 60 ta. Ish = unum · vaqt.",a:"m01",
 frames:[{t:'Usta soatiga 12 ta detal yasaydi. 5 soatda nechta yasaydi?',bars:[{lab:'1 soat',y:60,segs:[{w:12,txt:'12',c:'a'}]}],max:60,note:'1 soatdagi ish — unum'},
  {t:'Usta soatiga 12 ta detal yasaydi. 5 soatda nechta yasaydi?',bars:[{lab:'5 soat',y:60,segs:e5bars(3,12)}],max:60,note:'Har soat — yana 12 ta'},
  {t:'Usta soatiga 12 ta detal yasaydi. 5 soatda nechta yasaydi?',bars:[{lab:'5 soat',y:60,segs:e5bars(5,12)}],max:60,br:[{b:0,lab:'60 ta',col:C.ok}],calc:['Ish = unum · vaqt','12 · 5 = <b>60</b> ta detal']}],
 html:"<p>Har bir ishchi, mashina yoki nasosning <b>unumi</b> bor — u <b>1 soatda</b> (1 kunda, 1 daqiqada) qancha ish qilishi. Tugmani bosib, soatlarni qo'shib boring.</p>",
 after:"<p>Uch kattalik bir oila: <b>ish = unum · vaqt</b>. Bittasi noma'lum bo'lsa, qolgan ikkitasidan topiladi. Bu xuddi harakatdagi <b>masofa = tezlik · vaqt</b> kabi.</p>",
 q:{t:"Nasos 1 daqiqada 15 litr suv chiqaradi. 8 daqiqada-chi?",opts:["120 litr","23 litr","105 litr","7 litr"],ok:0,why:"15 · 8 = 120.",hint:"Ish = unum · vaqt.",full:"Unum 15 l/daq, vaqt 8 daq: 15 · 8 = 120 litr. «23» — qo'shib yuborilgan (15 + 8), «7» — ayirilgan."},
 tn:"Singapur usuli: chizma model — har soat bitta bo'lak. Doskada «ISH = UNUM · VAQT» uchburchagini chizing (tepada ISH, pastda UNUM va VAQT) — bitta qopqoqni yopsangiz, qolgani formula."}),
e4st({h:"Unumni topish",sum:"72 ta detal 6 soatda: unum = 72 : 6 = 12 ta soatiga.",a:"m02",
 frames:[{t:'Usta 6 soatda 72 ta detal yasadi. Soatiga nechta yasagan?',bars:[{lab:'6 soat',y:60,segs:[{w:72,txt:'72 ta',c:'g'}]}],note:'Butun ishni 6 ta teng bo‘lakka bo‘lamiz'},
  {t:'Usta 6 soatda 72 ta detal yasadi. Soatiga nechta yasagan?',bars:[{lab:'6 soat',y:60,segs:e5bars(6,12,'g')}],br:[{b:0,from:0,to:0,lab:'1 soat',up:false,col:C.ok}],calc:['Unum = ish : vaqt','72 : 6 = <b>12</b> ta soatiga']}],
 html:"<p>Endi <b>ish</b> va <b>vaqt</b> ma'lum. Unum — bir soatga to'g'ri keladigan ulush.</p>",
 after:"<p><b>Unum = ish : vaqt.</b> Tekshiruv: 12 · 6 = 72 ✓.</p>",
 q:{t:"Traktor 4 kunda 96 gektar yer haydadi. Kuniga necha gektar haydagan?",opts:["24 ga","384 ga","92 ga","100 ga"],ok:0,why:"96 : 4 = 24.",hint:"Unum = ish : vaqt.",full:"96 : 4 = 24 ga kuniga. Tekshiruv: 24 · 4 = 96 ✓. «384» — ko'paytirilgan (96 · 4)."},
 tn:"Bank misollari: 1072, 1073. Bolalardan «unum» so'zini o'z hayotidan misol bilan aytishni so'rang: «men 10 daqiqada 2 bet o'qiyman»."}),
e4st({h:"Vaqtni topish",sum:"96 ta detal, soatiga 8 ta: vaqt = 96 : 8 = 12 soat.",a:"m03",
 frames:[{t:'Robot soatiga 8 ta detal yig‘adi. 96 ta detalni necha soatda yig‘adi?',bars:[{lab:'ish',y:70,segs:[{w:96,txt:'96 ta',c:'g'}]}],note:'Qaysi amal? Tanlang:'}],
 html:"<p>Ish va unum ma'lum, vaqt noma'lum. Qaysi hisob to'g'ri?</p>",
 btns:e4pk(["96 : 8","96 · 8","96 − 8"],0,{t:'Robot soatiga 8 ta detal yig‘adi. 96 ta detalni necha soatda yig‘adi?',bars:[{lab:'ish',y:70,segs:e5bars(12,8,'g')}],br:[{b:0,lab:'12 ta soat',col:C.ok}],calc:['Vaqt = ish : unum','96 : 8 = <b>12</b> soat']},["","Ko‘paytirsak 768 chiqadi — bu 96 soatdagi ish bo‘lardi.","Ayirish bu yerda ma’nosiz: detaldan detal ayirib vaqt chiqmaydi."]),
 after:"<p><b>Vaqt = ish : unum.</b> Ya'ni 96 ning ichida nechta «8» bor — shuncha soat.</p>",
 q:{t:"Printer daqiqasiga 30 bet chop etadi. 450 betni necha daqiqada chop etadi?",opts:["15 daqiqa","13 500 daqiqa","420 daqiqa","25 daqiqa"],ok:0,why:"450 : 30 = 15.",hint:"Vaqt = ish : unum.",full:"450 : 30 = 15 daqiqa. Tekshiruv: 30 · 15 = 450 ✓."},
 tn:"Uchburchak qoidasini takrorlang: ISH ni yopsangiz — UNUM · VAQT; VAQT ni yopsangiz — ISH : UNUM."}),
e4st({h:"Birgalikda ishlash: unumlar qo‘shiladi",sum:"Usta soatiga 15, shogird 10 ta: birga 25 ta soatiga; 150 ta → 150 : 25 = 6 soat.",a:"m04",
 frames:[{t:'Usta soatiga 15 ta, shogird 10 ta g‘isht teradi. 150 ta g‘ishtni birga necha soatda terishadi?',head:['','unum','vaqt','ish'],rows:[['usta','15','?','?'],['shogird','10','?','?'],['birga','?','?','150']],note:'Avval birgalikdagi unumni toping'},
  {t:'Usta soatiga 15 ta, shogird 10 ta g‘isht teradi. 150 ta g‘ishtni birga necha soatda terishadi?',head:['','unum','vaqt','ish'],rows:[['usta','15','?','?'],['shogird','10','?','?'],['birga','25','?','150']],hl:{2:1},calc:['Birgalikdagi unum: 15 + 10 = 25 ta soatiga']},
  {t:'Usta soatiga 15 ta, shogird 10 ta g‘isht teradi. 150 ta g‘ishtni birga necha soatda terishadi?',head:['','unum','vaqt','ish'],rows:[['usta','15','6','90'],['shogird','10','6','60'],['birga','25','6','150']],hl:{2:2},calc:['150 : 25 = <b>6</b> soat','Tekshiruv: 90 + 60 = 150 ✓']}],
 html:"<p>Ikki kishi <b>bir vaqtda</b> ishlasa, har soatda ularning ishi <b>qo'shiladi</b>. Jadvalni to'ldirib boring.</p>",
 after:"<p>Jadval — bunday masalalarning eng yaxshi do'sti: har qatorda <b>unum · vaqt = ish</b>. Vaqt ikkalasida bir xil (6 soat), ishlari esa har xil (90 va 60).</p>",
 q:{t:"Bir nasos soatiga 40 l, ikkinchisi 20 l suv chiqaradi. Birga 360 l ni necha soatda chiqaradi?",opts:["6 soat","9 soat","18 soat","3 soat"],ok:0,why:"40 + 20 = 60; 360 : 60 = 6.",hint:"Avval birgalikdagi unum.",full:"Birga: 40 + 20 = 60 l soatiga. 360 : 60 = 6 soat. «9» — faqat birinchi nasos (360 : 40), «18» — faqat ikkinchisi."},
 tn:"Jadvalni doskada katta chizing; bolalar navbat bilan kataklarni to'ldirsin. Bank: 1780 (ikki usta, bir xil kun)."}),
e4st({h:"Tuzoq: vaqtlar qo‘shilmaydi!",sum:"Akmal devorni 6 soatda, Botir 3 soatda bo‘yaydi. Birga — 2 soat (9 soat emas!).",a:"m05",
 frames:[{t:'Devorda 60 ta taxta bor. Akmal hammasini 6 soatda, Botir 3 soatda bo‘yaydi. Birga necha soatda bo‘yashadi?',head:['','unum','vaqt','ish'],rows:[['Akmal','?','6','60'],['Botir','?','3','60'],['birga','?','?','60']],note:'Javobni tanlang:'}],
 html:"<p>Ko'p bolalar bu yerda adashadi. O'ylab tanlang:</p>",
 btns:e4pk(["9 soat","2 soat","3 soat"],1,{t:'Devorda 60 ta taxta bor. Akmal hammasini 6 soatda, Botir 3 soatda bo‘yaydi. Birga necha soatda bo‘yashadi?',head:['','unum','vaqt','ish'],rows:[['Akmal','10','6','60'],['Botir','20','3','60'],['birga','30','2','60']],hl:{2:2},calc:['Unumlar: 60 : 6 = 10,  60 : 3 = 20','Birga: 10 + 20 = 30 ta soatiga → 60 : 30 = <b>2</b> soat']},["Birga ishlasa tezroq bo‘ladi-ku! 9 soat — yolg‘iz Akmaldan ham sekin.","","3 soat — Botir yolg‘iz shuncha vaqt sarflaydi. Akmal yordam bersa, tezroq bo‘lishi kerak."]),
 after:"<p>Qoida: <b>vaqtlarni emas, unumlarni qo'shamiz.</b> Birga ishlash har doim eng tez ishchidan ham <b>tezroq</b>: 2 soat &lt; 3 soat.</p>",
 q:{t:"Bir quvur hovuzni 12 soatda, ikkinchisi 6 soatda to'ldiradi. Hovuz 72 chelak. Ikkalasi birga necha soatda to'ldiradi?",opts:["4 soat","18 soat","9 soat","6 soat"],ok:0,why:"72 : 12 = 6, 72 : 6 = 12; 6 + 12 = 18 chelak soatiga; 72 : 18 = 4.",hint:"Avval har birining soatlik unumi.",full:"Unumlar: 72 : 12 = 6 va 72 : 6 = 12 chelak soatiga. Birga 18. 72 : 18 = 4 soat. «18 soat» — vaqtlar qo'shilgan, «9» — o'rtachasi olingan; ikkalasi ham noto'g'ri, chunki birga tezroq bo'ladi."},
 tn:"Bu — klassik «hovuz» masalasi; xalqaro olimpiadalarda ko'p uchraydi. Bolalarga «aql bilan tekshirish»ni o'rgating: javob eng tez ishchinikidan kichik bo'lishi shart."}),
e4st({h:"Ko‘proq ishchi — kamroq vaqt",sum:"4 ishchi 12 kunda: ish 48 «ishchi-kun». 6 ishchi: 48 : 6 = 8 kun.",a:"m06",
 frames:[{t:'4 ishchi ariqni 12 kunda qazidi. 6 ishchi necha kunda qaziydi?',bars:[{lab:'4 ishchi',y:44,segs:e5bars(4,12,'b')},{lab:'6 ishchi',y:96,segs:[{w:48,txt:'?',c:'q'}]}],max:48,note:'Ish bir xil — bitta ariq'},
  {t:'4 ishchi ariqni 12 kunda qazidi. 6 ishchi necha kunda qaziydi?',bars:[{lab:'4 ishchi',y:44,segs:e5bars(4,12,'b')},{lab:'1 ishchi',y:96,segs:[{w:48,txt:'48 kun',c:'a'}]}],max:48,calc:['Bitta ishchi: 12 · 4 = 48 kun']},
  {t:'4 ishchi ariqni 12 kunda qazidi. 6 ishchi necha kunda qaziydi?',bars:[{lab:'4 ishchi',y:44,segs:e5bars(4,12,'b')},{lab:'6 ishchi',y:96,segs:e5bars(6,8,'g')}],max:48,br:[{b:1,from:0,to:0,lab:'8 kun',col:C.ok}],calc:['1) 12 · 4 = 48 (bitta ishchi necha kunda)','2) 48 : 6 = <b>8</b> kun']}],
 html:"<p>Ishchilar ko'paysa, vaqt <b>kamayadi</b>. Lekin qanchaga? «Birga keltirish» usuli: avval <b>bitta</b> ishchi uchun hisoblaymiz.</p>",
 after:"<p>Ishchilar <b>1,5 marta</b> ko'paydi (4 → 6), vaqt <b>1,5 marta</b> kamaydi (12 → 8). Bu <b>teskari proporsionallik</b>. Xato: «12 + 2 = 14» yoki «12 · 6 : 4 = 18» — ishchilar ko'paysa vaqt oshmaydi!</p>",
 q:{t:"5 ta kombayn dalani 6 kunda o'radi. 3 ta kombayn necha kunda o'radi?",opts:["10 kun","4 kun","18 kun","8 kun"],ok:0,why:"6 · 5 = 30 (bitta kombayn); 30 : 3 = 10.",hint:"Avval bitta kombayn necha kunda o'radi?",full:"Bitta kombayn: 6 · 5 = 30 kun. 3 tasi: 30 : 3 = 10 kun. Kombayn kamaydi — vaqt ko'paydi. «4» — to'g'ri proporsiya deb o'ylangan (6 · 3 : 5 ≈ 4)."},
 tn:"Bank: 208-id (50 ishchi 8 soat → 30 ishchi). «Ishchi-kun» tushunchasini kartochkalar bilan ko'rsating: 4 qator × 12 katak = 48 katak; 6 qatorga taqsimlansa — 8 tadan."}),
e4st({h:"Tuzoq: biri kechroq qo‘shildi",sum:"Usta 2 soat yolg‘iz (9 · 2 = 18), keyin shogird bilan birga (9 + 6 = 15). 78 ta: (78 − 18) : 15 = 4 soat birga.",a:"m07",
 frames:[{t:'Usta soatiga 9 ta, shogird 6 ta. Usta 2 soat yolg‘iz ishladi, so‘ng shogird qo‘shildi. Jami 78 ta bo‘ldi. Birga necha soat ishlashdi?',bars:[{lab:'ish',y:84,segs:[{w:18,txt:'18',c:'b'},{w:60,txt:'?',c:'q'}]}],max:78,br:[{b:0,from:0,to:0,lab:'yolg‘iz',up:true},{b:0,from:1,to:1,lab:'birga',up:true}],note:'Javobni tanlang:'}],
 html:"<p>Ikki bosqich: avval <b>yolg'iz</b>, keyin <b>birga</b>. Chizmaga qarab tanlang:</p>",
 btns:e4pk(["4 soat","6 soat","5 soat"],0,{t:'Usta soatiga 9 ta, shogird 6 ta. Usta 2 soat yolg‘iz ishladi, so‘ng shogird qo‘shildi. Jami 78 ta bo‘ldi.',bars:[{lab:'ish',y:84,segs:[{w:18,txt:'18',c:'b'},{w:15,txt:'15',c:'g'},{w:15,txt:'15',c:'g'},{w:15,txt:'15',c:'g'},{w:15,txt:'15',c:'g'}]}],max:78,br:[{b:0,from:1,to:4,lab:'4 soat birga',up:true,col:C.ok}],calc:['1) 9 · 2 = 18 (yolg‘iz)','2) 78 − 18 = 60;  9 + 6 = 15','3) 60 : 15 = <b>4</b> soat']},["","6 soat — usta jami ishlagan vaqt (2 + 4), savol esa «birga»ni so‘rayapti.","78 : 15 ≈ 5 — yolg‘iz ishlangan 18 tani ayirmay hisoblangan."]),
 after:"<p>Tekshiruv: usta 6 soat · 9 = 54, shogird 4 soat · 6 = 24; 54 + 24 = 78 ✓. Har bosqichni <b>alohida</b> hisoblang.</p>",
 q:{t:"Bir quvur 3 soat yolg'iz ishlab, soatiga 20 l quydi. Keyin ikkinchi quvur (soatiga 30 l) qo'shildi. Jami 260 l bo'lishi uchun birga necha soat ishlashi kerak?",opts:["4 soat","5 soat","7 soat","8 soat"],ok:0,why:"20 · 3 = 60; 260 − 60 = 200; 200 : 50 = 4.",hint:"Avval yolg'iz quyilganini ayiring.",full:"Yolg'iz: 20 · 3 = 60 l. Qolgan: 260 − 60 = 200 l. Birga: 20 + 30 = 50 l soatiga. 200 : 50 = 4 soat. «5» — 260 : 50 (yolg'iz qismi ayirilmagan), «7» — jami vaqt."},
 tn:"Bu tur 4-sinf olimpiada va saralash testlarida ko'p. Bolalar har doim chizmada ikki bo'lakni ajratsin."}),
e4st({h:"Tuzoq: qaysi biri tezroq?",sum:"Gilam: 1-chi 12 m² ni 84 kunda (7 kun/m²), 2-chi 30 m² ni 240 kunda (8 kun/m²) — birinchisi tezroq.",a:"m08",
 frames:[{t:'1-gilamdo‘z 4 × 3 m gilamni 84 kunda, 2-si 6 × 5 m gilamni 240 kunda to‘qidi. Kim tezroq?',head:['','yuz (m²)','kun','1 m² ga'],rows:[['1-si','12','84','?'],['2-si','30','240','?']],note:'Kim tezroq? Tanlang:'}],
 html:"<p>Ikki usta har xil ish qildi. Tezlikni solishtirish uchun ishni <b>bir xil o'lchov</b>ga keltiramiz — 1 m².</p>",
 btns:e4pk(["2-si — kam kun ketgan","1-si — 1 m² ga kam kun","Teng"],1,{t:'1-gilamdo‘z 4 × 3 m gilamni 84 kunda, 2-si 6 × 5 m gilamni 240 kunda to‘qidi.',head:['','yuz (m²)','kun','1 m² ga'],rows:[['1-si','12','84','7'],['2-si','30','240','8']],hl:{0:3},calc:['84 : 12 = 7 kun,  240 : 30 = 8 kun','1-gilamdo‘z 1 m² ga <b>1 kun kam</b> sarflagan']},["2-si ko‘proq kun ishlagan (240 > 84), lekin gilami ham katta. Solishtirish uchun 1 m² ga keltiring.","","7 va 8 teng emas."]),
 after:"<p>Kim ko'p yoki kam vaqt ishlaganiga qarab emas, <b>bir birlik ishga</b> qancha vaqt ketganiga qarab solishtiramiz.</p>",
 q:{t:"A zavod 5 kunda 600 ta, B zavod 8 kunda 880 ta velosiped chiqardi. Qaysi zavodning kunlik unumi katta va qanchaga?",opts:["A, 10 taga","B, 280 taga","B, 10 taga","Teng"],ok:0,why:"600 : 5 = 120, 880 : 8 = 110; 120 − 110 = 10.",hint:"Har birining kunlik unumini toping.",full:"A: 600 : 5 = 120 ta kuniga. B: 880 : 8 = 110 ta. A ning unumi 10 taga katta. «B, 280» — jami ishlar solishtirilgan, vaqt hisobga olinmagan."},
 tn:"Bank: 1074-id. Bu — «birlikka keltirish» g'oyasi; 5-sinfda «tezlik», «narx» bilan umumlashadi."}),
e4st({h:"Bilasizmi? Konveyer mo‘jizasi",sum:"1913-yilda Genri Ford konveyer joriy qildi: bitta avtomobil yig‘ish taxminan 12 soatdan 1,5 soatga qisqardi.",a:"m09",
 frames:[{t:'Bitta avtomobil yig‘ish vaqti',bars:[{lab:'1913 gacha',y:56,segs:[{w:12,txt:'≈ 12 soat',c:'x'}]},{lab:'konveyer',y:104,segs:[{w:1.5,txt:'',c:'g'}]}],max:12,txt:[[112,138,'≈ 1,5 soat',{fill:C.ok,'text-anchor':'start'}]],note:'Ishni bo‘laklarga bo‘lish unumni oshiradi'}],
 html:"<p>🚗 1913-yilda amerikalik sanoatchi <b>Genri Ford</b> zavodida harakatlanuvchi <b>konveyer</b> joriy qildi. Har bir ishchi faqat bitta ishni bajarardi. Natijada bitta «Model T» avtomobilini yig'ish vaqti <b>taxminan 12 soatdan 1,5 soatga</b> qisqardi.</p>",
 after:"<p>Unumni oshirishning ikki yo'li bor: ko'proq ishchi yoki ishni <b>aqlli tashkil qilish</b>. Ford ikkinchisini tanladi.</p>",
 tn:"Sinfda kichik «konveyer» o'yini: 10 ta qog'oz qayiqchani bitta bola yasaydi, keyin 4 bola har biri bitta buklashni bajaradi — vaqtni solishtiring."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e4tab({t:'Ish = unum · vaqt',head:['','unum','vaqt','ish'],rows:[['1-si','a','t','a · t'],['2-si','b','t','b · t'],['birga','a + b','t','(a + b) · t']]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Ish = unum · vaqt</b>; unum = ish : vaqt; vaqt = ish : unum.</li><li>Birga ishlaganda <b>unumlar qo'shiladi</b>, vaqtlar emas!</li><li>Birga ishlash — eng tez ishchidan ham <b>tezroq</b>.</li><li>Ishchi ko'paysa — vaqt kamayadi: avval <b>bitta</b> ishchiga keltiring.</li><li>Bosqichli ish: yolg'iz qismi alohida, birga qismi alohida.</li><li>Solishtirish — <b>1 birlik ishga</b> keltirib.</li><li>Jadval chizing: har qatorda unum · vaqt = ish.</li></ul></div>",
 tn:"Uyga: oiladagi biror ish (idish yuvish, kartoshka archish)ning «unumi»ni o'lchab kelish."}
];
var PROBS=[
{t:"Usta soatiga 14 ta detal yasaydi. 7 soatda nechta yasaydi?",o:["98","21","84","2"],k:0,s:"14 · 7 = 98."},
{t:"Traktor 5 kunda 120 ga yer haydadi. Kuniga necha gektar?",o:["24","600","115","25"],k:0,s:"120 : 5 = 24."},
{t:"Printer daqiqasiga 25 bet chop etadi. 400 betni necha daqiqada chop etadi?",o:["16","10 000","375","14"],k:0,s:"400 : 25 = 16."},
{t:"Bir zavod kuniga 1536 ta, ikkinchisi 1278 ta detal chiqaradi. 7 kunda ikkalasi jami nechta?",o:["19 698","19 688","19 598","2 814"],k:0,s:"(1536 + 1278) · 7 = 2814 · 7 = 19 698."},
{t:"Zavod 3 kunda 1350 ta kosa va 2850 ta piyola chiqardi. Shu unum bilan 9 kunda jami nechta?",o:["12 600","8 400","4 200","37 800"],k:0,s:"(1350 + 2850) : 3 · 9 = 1400 · 9 = 12 600."},
{t:"Usta soatiga 15 ta, shogird 10 ta g'isht teradi. Birga 200 ta g'ishtni necha soatda terishadi?",o:["8","20","13","5"],k:0,s:"200 : (15 + 10) = 8."},
{t:"Bir nasos soatiga 45 l, ikkinchisi 35 l suv chiqaradi. Birga 5 soatda necha litr?",o:["400","80","225","175"],k:0,s:"(45 + 35) · 5 = 400."},
{t:"1-dastgoh soatiga 1745 ta, 2-si 2100 ta detal yasaydi. 4 soatda 2-si nechta ko'p yasaydi?",o:["1420","355","1410","15 380"],k:0,s:"(2100 − 1745) · 4 = 355 · 4 = 1420."},
{t:"Ikki usta birga 1200 ta g'isht terdi: 1-si kuniga 45 ta, 2-si 35 ta, bir xil kun ishlashgan. 1-si nechta terdi?",o:["675","600","525","700"],k:0,s:"1200 : 80 = 15 kun; 45 · 15 = 675."},
{t:"Akmal devorni 6 soatda, Botir 3 soatda bo'yaydi (60 ta taxta). Birga necha soatda?",o:["2","9","3","4"],k:0,s:"60 : 6 = 10, 60 : 3 = 20; 60 : 30 = 2."},
{t:"Bir quvur hovuzni 12 soatda, ikkinchisi 6 soatda to'ldiradi (72 chelak). Birga necha soatda?",o:["4","18","9","6"],k:0,s:"72 : (6 + 12) = 4."},
{t:"Ota bog'ni 4 soatda, o'g'li 12 soatda chopadi (bog'da 48 tup). Birga necha soatda chopishadi?",o:["3","16","8","6"],k:0,s:"48 : 4 = 12, 48 : 12 = 4; 48 : 16 = 3."},
{t:"4 ishchi ariqni 12 kunda qazidi. 6 ishchi necha kunda qaziydi?",o:["8","18","10","14"],k:0,s:"12 · 4 = 48; 48 : 6 = 8."},
{t:"5 ta kombayn dalani 6 kunda o'radi. 3 ta kombayn necha kunda o'radi?",o:["10","4","18","8"],k:0,s:"6 · 5 = 30; 30 : 3 = 10."},
{t:"50 ishchi uyni 6 kunda quradi. 30 ishchi necha kunda quradi?",o:["10","4","8","26"],k:0,s:"50 · 6 = 300; 300 : 30 = 10."},
{t:"Usta soatiga 9 ta, shogird 6 ta detal yasaydi. Usta 2 soat yolg'iz ishladi, keyin birga ishlashdi, jami 78 ta. Birga necha soat?",o:["4","6","5","3"],k:0,s:"(78 − 18) : 15 = 4."},
{t:"Quvur 3 soat yolg'iz soatiga 20 l quydi, keyin 2-quvur (30 l) qo'shildi. Jami 260 l uchun birga necha soat kerak?",o:["4","5","7","8"],k:0,s:"(260 − 60) : 50 = 4."},
{t:"A zavod 5 kunda 600 ta, B 8 kunda 880 ta velosiped chiqardi. Kunlik unumlar farqi?",o:["10","280","110","120"],k:0,s:"120 − 110 = 10."},
{t:"Ikki ishchi birga soatiga 24 ta detal yasaydi. Biri ikkinchisidan soatiga 4 ta ko'p yasaydi. Tezrog'i soatiga nechta?",o:["14","10","20","12"],k:0,s:"(24 + 4) : 2 = 14."},
{t:"Usta bir ishni 10 kunda bajaradi. U 4 kun ishladi, qolganini shogird 12 kunda tugatdi. Shogird yolg'iz butun ishni necha kunda bajarardi?",o:["20","12","16","8"],k:0,s:"Ishni 10 bo'lak desak: usta 4 bo'lak qildi, 6 bo'lak qoldi; shogird 12 kunda 6 bo'lak, ya'ni 2 kunda 1 bo'lak; 10 bo'lak — 20 kun."}
];
function PRACT_STAGE(){e4tab({t:'Ish = unum · vaqt',head:['','unum','vaqt','ish'],rows:[['1-si','?','?','?'],['2-si','?','?','?'],['birga','?','?','?']]})}
var PREP_DATA={teach:["Ish, unum, vaqt — uch kattalik va ular orasidagi bog'lanish (ish = unum · vaqt).","Birgalikda ishlash: unumlar qo'shiladi.","Teskari proporsionallik: ishchi ko'paysa, vaqt kamayadi (bitta ishchiga keltirish).","Bosqichli ish va unumlarni solishtirish (1 birlikka keltirish)."],
 mist:["Birga ishlaganda vaqtlarni qo'shadi (6 + 3 = 9 soat).","Ishchi ko'payganda vaqtni ham ko'paytiradi.","Bosqichli masalada yolg'iz bajarilgan qismni ayirmaydi.","Kim ko'p ishlaganiga qarab tezlikni baholaydi."],
 need:["Doskada «ISH / UNUM · VAQT» uchburchagi.","Jadval shabloni (unum | vaqt | ish).","Qog'oz kartochkalar («ishchi-kun» kataklari)."],
 board:["<span class='w2'>12 · 5 = 60</span>;  <span class='w2'>72 : 6 = 12</span>;  <span class='w2'>96 : 8 = 12</span>.","<span class='w2'>150 : (15 + 10) = 6</span>.","<span class='w2'>60 : (10 + 20) = 2</span> soat (9 emas!).","<span class='w2'>12 · 4 : 6 = 8</span> kun.","<span class='w2'>(78 − 9 · 2) : (9 + 6) = 4</span>."]};
