var CODE='4I1',TITLE='4-sinf · Jadval va diagrammalar';
function qcmsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ustunli diagramma: o {v:[...], l:[...], max, st, hi:[indekslar], col, y0 (o'q boshlanishi), tap, unit}
function qcbars(o){clear();var g=S.g,n=o.v.length,x0=46,W=300,y0=150,H=126,mn=o.y0||0,mx=o.max,st=o.st,i;S.qc=o;
 var Y=function(v){return y0-(v-mn)/(mx-mn)*H};
 for(var v=mn;v<=mx;v+=st){E('line',{x1:x0,y1:Y(v),x2:x0+W,y2:Y(v),stroke:'#e6ebf0','stroke-width':1},g);T(g,x0-8,Y(v)+4,''+v,{'font-size':10,'font-weight':700,fill:'#5a6b7d','text-anchor':'end'})}
 E('line',{x1:x0,y1:y0,x2:x0+W,y2:y0,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0,y1:y0,x2:x0,y2:y0-H-6,stroke:'#33475b','stroke-width':2},g);
 if(mn>0){E('path',{d:'M'+(x0-5)+' '+(y0-4)+' l10 -4 M'+(x0-5)+' '+(y0+2)+' l10 -4',stroke:C.bad,'stroke-width':2},g)}
 var bw=W/n;for(i=0;i<n;i++){var val=o.v[i],hi=(o.hi||[]).indexOf(i)>=0,cx=x0+bw*i+bw/2;
  if(val!=null&&val>mn)E('rect',{x:cx-bw*0.3,y:Y(val),width:bw*0.6,height:y0-Y(val),rx:3,fill:hi?C.a2:(o.col||C.b),stroke:hi?C.line:'none'},g);
  if(val==null)E('rect',{x:cx-bw*0.3,y:y0-H,width:bw*0.6,height:H,rx:3,fill:'none',stroke:C.grey,'stroke-dasharray':'4 4'},g);
  T(g,cx,y0+15,o.l[i],{'font-size':11,'font-weight':700,fill:'#33475b'});if(o.show&&val!=null)T(g,cx,Y(val)-5,''+val,{'font-size':11,'font-weight':800,fill:hi?C.a2:C.blue})}
 if(o.unit)T(g,x0+4,16,o.unit,{'font-size':10,'font-weight':700,fill:'#5a6b7d','text-anchor':'start'});
 if(o.tap){var r=E('rect',{x:x0,y:y0-H-6,width:W,height:H+6,fill:'transparent',style:'cursor:pointer'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var k=Math.floor((p.x-x0)/bw),v=Math.round((mn+(y0-p.y)/H*(mx-mn))/st)*st;o.tap(Math.max(0,Math.min(n-1,k)),Math.max(mn,Math.min(mx,v)))})}}
function qctab(rows,hi){clear();var g=S.g,nr=rows.length,nc=rows[0].length,cw=Math.min(84,340/nc),rh=Math.min(30,160/nr),x0=180-cw*nc/2,y0=10;
 rows.forEach(function(r,i){r.forEach(function(c,j){var h=hi&&hi[0]===i&&hi[1]===j;E('rect',{x:x0+j*cw,y:y0+i*rh,width:cw,height:rh,fill:h?'rgba(240,160,64,.45)':(i===0||j===0?'#eef3f8':'#fff'),stroke:'#cfd8e2'},g);T(g,x0+j*cw+cw/2,y0+i*rh+rh/2+4,''+c,{'font-size':12,'font-weight':i===0||j===0?800:700,fill:c==='?'?C.bad:'#33475b'})})})}
var QCT=[['','Olma','Nok','Uzum'],['4-A',12,7,9],['4-B',8,11,6],['4-D',10,5,13]];
function qcpic(k){clear();var g=S.g,rows=[['Ali',3],['Vali',5],['Soli',3.5]],x0=70;
 rows.forEach(function(r,i){var y=34+i*40;T(g,30,y+5,r[0],{'font-size':13,'font-weight':800,fill:'#33475b'});for(var j=0;j<Math.ceil(r[1]);j++){var half=r[1]-j<1;var bx=x0+j*36;E('rect',{x:bx,y:y-14,width:half?13:26,height:26,rx:3,fill:k===i?C.a2:C.b,stroke:'#fff'},g);if(!half)E('line',{x1:bx+13,y1:y-14,x2:bx+13,y2:y+12,stroke:'#fff','stroke-width':1.5},g)}});
 E('rect',{x:226,y:140,width:26,height:22,rx:3,fill:C.b},g);T(g,300,156,'= 4 ta kitob',{'font-size':12,'font-weight':800,fill:C.bad})}
var QCP6=[function(){qcbars({v:[52,56],l:['A do‘kon','B do‘kon'],max:57,st:1,y0:51,unit:'savdo'});qcmsg('Qarang: B ustuni A dan 5 marta baland ko‘rinadi!')},
 function(){qcbars({v:[52,56],l:['A do‘kon','B do‘kon'],max:57,st:1,y0:51,show:1,unit:'savdo'});qcmsg('Lekin sonlar: 52 va 56. O‘q <b>51 dan</b> boshlangan (qizil «uzilish» belgisi)')},
 function(){qcbars({v:[52,56],l:['A do‘kon','B do‘kon'],max:60,st:10,show:1,unit:'savdo'});qcmsg('0 dan boshlasak — ustunlar deyarli teng. Farq faqat <b>4</b>')}];
var QCP7=[function(){qcbars({v:[6,9,3,6],l:['Du','Se','Chor','Pay'],max:10,st:2,show:1,unit:'soat'});qcmsg('4 kunda kitob o‘qish (soat). O‘rtacha necha soat?')},
 function(){qcbars({v:[6,9,3,6],l:['Du','Se','Chor','Pay'],max:10,st:2,show:1,unit:'soat',hi:[1,2]});qcmsg('Seshanbadan 3 ni olib, chorshanbaga beramiz: 9 → 6, 3 → 6')},
 function(){qcbars({v:[6,6,6,6],l:['Du','Se','Chor','Pay'],max:10,st:2,show:1,unit:'soat',hi:[0,1,2,3]});qcmsg('Hammasi teng — 6. Hisob: (6 + 9 + 3 + 6) : 4 = 24 : 4 = <b>6</b>')}];
var STEPS=[
{h:"Jadvalni o'qiymiz",sum:"Ikki kirishli jadvalda son qator va ustun kesishgan katakda turadi.",a:"m01",
 start:function(){qctab(QCT);qcmsg('4-B sinf o‘quvchilari nechta <b>nok</b> terdi?')},fin:function(){qctab(QCT,[2,2]);qcmsg('✓ 4-B qatori va Nok ustuni kesishmasi: <b>11</b>')},
 btns:[["8",function(c,done){qctab(QCT,[2,1]);qcmsg('8 — 4-B ning <b>olma</b>si. Nok ustuniga qarang')}],["11",function(c,done){STEPS[0].fin();done()}],["7",function(c,done){qctab(QCT,[1,2]);qcmsg('7 — 4-A ning noki. 4-B qatoriga qarang')}]],g3:1,
 html:"<p>Maktab bog'ida uch sinf meva terdi. Jadvalni o'qing: <b>4-B</b> sinf nechta <b>nok</b> terdi?</p>",
 after:"<p>Kerakli son — <b>qator</b> (4-B) va <b>ustun</b> (Nok) kesishgan katakda: <b>11</b>. Barmoq bilan avval qatorni, keyin ustunni topib, ular uchrashgan joyni o'qing.</p>",
 q:{t:"Jadvalga ko'ra uzumni eng ko'p qaysi sinf terdi?",opts:["4-D (13)","4-A (9)","4-B (6)","Hammasi teng"],ok:0,why:"Uzum ustuni: 9, 6, 13 — eng kattasi 13.",hint:"Faqat Uzum ustunidagi sonlarni solishtiring.",full:"Uzum ustuni: 4-A — 9, 4-B — 6, 4-D — 13. Eng katta — 13, ya'ni 4-D."},
 tn:"Doskaga sinfning tug'ilgan oylari bo'yicha jadval chizing — bolalar o'z ma'lumotlarini o'qiganda qiziqroq bo'ladi."},
{h:"Piktogramma: bitta belgi — bir nechta narsa",sum:"Piktogrammada bitta belgi bir necha narsani bildiradi; yarim belgi — yarmini.",a:"m02",
 start:function(){qcpic(-1);qcmsg('Soli nechta kitob o‘qigan?')},fin:function(){qcpic(2);qcmsg('✓ 3 ta butun = 12, yarimta = 2. Jami <b>14</b>')},
 btns:[["3,5",function(c,done){qcpic(2);qcmsg('3,5 — belgilar soni. Har bir belgi 4 ta kitob')}],["14",function(c,done){STEPS[1].fin();done()}],["12",function(c,done){qcpic(2);qcmsg('12 — faqat butun belgilar. Yarim belgi-chi?')}],["16",function(c,done){qcpic(2);qcmsg('16 — yarim belgini butun deb sanadingiz')}]],g2:1,
 html:"<p>Piktogrammada <b>bitta kitob belgisi = 4 ta kitob</b>. Soli nechta kitob o'qigan?</p>",
 after:"<p>Solida 3 ta butun belgi: 3 · 4 = 12, va <b>yarim</b> belgi: 4 : 2 = 2. Jami <b>14</b>. Piktogrammada avval kalitni («bitta belgi = ?») o'qing!</p>",
 q:{t:"Vali 5 ta belgi, Ali 3 ta belgi. Vali Alidan nechta ko'p kitob o'qigan?",opts:["8","2","20","12"],ok:0,why:"Farq 2 belgi · 4 = 8.",hint:"Belgilar farqini kitobga aylantiring.",full:"Vali 5 · 4 = 20, Ali 3 · 4 = 12, farq 8. Yoki: 2 belgi · 4 = 8. 2 — belgilar farqi, kitob emas."},
 tn:"Bolalar o'zlari piktogramma tuzsin: «1 ta yulduz = 2 ta besh baho». Kalitni tanlash ham muhim qaror."},
{h:"Ustunli diagrammani o'qish",sum:"Ustun balandligini o'q shkalasi bo'yicha o'qiymiz; avval bo'linma qiymatini aniqlang.",a:"m03",
 start:function(){qcbars({v:[25,40,35,15],l:['Du','Se','Chor','Pay'],max:50,st:10,unit:'o‘quvchi',hi:[2]});qcmsg('Chorshanba kuni kutubxonaga nechta o‘quvchi keldi?')},fin:function(){qcbars({v:[25,40,35,15],l:['Du','Se','Chor','Pay'],max:50,st:10,unit:'o‘quvchi',hi:[2],show:1});qcmsg('✓ 30 va 40 ning o‘rtasi: <b>35</b>')},
 btns:[["30",function(c,done){qcmsg('Ustun 30 dan baland — o‘rtagacha yetgan')}],["35",function(c,done){STEPS[2].fin();done()}],["40",function(c,done){qcmsg('40 — seshanba. Chorshanba undan pastroq')}],["3,5",function(c,done){qcmsg('Chiziqlar 10 dan: 3,5 chiziq = 35 o‘quvchi')}]],g2:1,
 html:"<p>Diagrammada kutubxonaga kelgan o'quvchilar soni. <b>Chorshanba</b> (to'q sariq ustun) kuni nechta o'quvchi kelgan?</p>",
 after:"<p>O'qda chiziqlar <b>10</b> dan. Ustun 30 va 40 orasining <b>o'rtasi</b>gacha yetgan: <b>35</b>. Ustun chiziq ustida bo'lmasa — eng yaqin ikki chiziq orasida qayerdaligini chamalang.</p>",
 q:{t:"Diagrammaga ko'ra 4 kunda jami nechta o'quvchi kelgan?",opts:["115","100","125","105"],ok:0,why:"25 + 40 + 35 + 15 = 115.",hint:"Har bir ustunni o'qib, qo'shing.",full:"Du 25, Se 40, Chor 35, Pay 15: 25 + 40 + 35 + 15 = 115. 100 yoki 125 — bitta ustunni xato o'qish."},
 tn:"Diagrammani chizg'ich bilan o'qish odatini bering: chizg'ichni ustun uchidan o'qqa yotqizing."},
{h:"Diagramma tuzing",sum:"Jadvaldagi sonlar bo'yicha har bir ustun balandligini shkalada belgilaymiz.",a:"m04",
 start:function(){S.v4=[20,35,null,15];q4draw();qcmsg('Jadval: Dushanba 20, Seshanba 35, Chorshanba <b>30</b>, Payshanba 15. Chorshanba ustunini quring')},fin:function(){qcbars({v:[20,35,30,15],l:['Du','Se','Chor','Pay'],max:40,st:5,unit:'kg',hi:[2],show:1});qcmsg('✓ Chorshanba — 30 kg')},
 act:function(c,done){S.d4=done},
 html:"<p>Oshxonaga keltirilgan kartoshka (kg): Du — 20, Se — 35, <b>Chor — 30</b>, Pay — 15. Chorshanba ustunini qurish uchun diagrammada uning joyida <b>30</b> balandlikni bosing.</p>",
 after:"<p>Shkalada chiziqlar <b>5</b> dan. 30 — 6-chiziq. Ustun aniq shu chiziqqacha. Diagramma tuzishda: 1) o'q va shkalani tanlash (eng katta son sig'sin); 2) har bir ustunni songa mos balandlikda chizish; 3) nom va birlik yozish.</p>",
 q:{t:"Sonlar: 120, 340, 280, 90. Diagramma shkalasini qaysi qadam bilan tanlash qulay?",opts:["50 dan, 0 dan 350 gacha","1 dan, 0 dan 340 gacha","100 dan, 0 dan 200 gacha","5 dan, 0 dan 50 gacha"],ok:0,why:"Eng katta son 340 sig'ishi kerak, chiziqlar ko'p bo'lmasin.",hint:"Eng katta son sig'adimi? Chiziqlar soni qulaymi?",full:"0–350, qadam 50: 340 sig'adi, chiziqlar 7 ta — qulay. Qadam 1 — 340 ta chiziq, juda ko'p. 0–200 va 0–50 da 340 sig'maydi."},
 tn:"Bolalar katakli daftarda sinf ma'lumotlari (masalan, sevimli fasl) bo'yicha diagramma chizsin; shkalani o'zlari tanlasin."},
{h:"Necha ga va necha marta?",sum:"«Necha ga ko'p» — ayirish, «necha marta ko'p» — bo'lish.",a:"m05",
 start:function(){qcbars({v:[40,10],l:['Futbol','Shaxmat'],max:50,st:10,show:1,unit:'o‘quvchi'});qcmsg('Ikkala tugmani bosing')},fin:function(){qcbars({v:[40,10],l:['Futbol','Shaxmat'],max:50,st:10,show:1,unit:'o‘quvchi',hi:[0]});qcmsg('40 − 10 = <b>30 ga</b> ko‘p; 40 : 10 = <b>4 marta</b> ko‘p')},
 btns:[["Necha ga?",function(c,done){qcbars({v:[40,10],l:['Futbol','Shaxmat'],max:50,st:10,show:1,unit:'o‘quvchi',hi:[0]});qcmsg('Necha <b>ga</b> ko‘p — ayiramiz: 40 − 10 = <b>30</b>');mvK(done,2)}],["Necha marta?",function(c,done){qcbars({v:[40,10],l:['Futbol','Shaxmat'],max:50,st:10,show:1,unit:'o‘quvchi',hi:[1]});qcmsg('Necha <b>marta</b> ko‘p — bo‘lamiz: 40 : 10 = <b>4</b>. Shaxmatdagi 4 ta ustun futbolga teng');mvK(done,2)}]],g2:1,
 html:"<p>To'garaklardagi o'quvchilar. Futbolchilar shaxmatchilardan qancha ko'p? Ikki savol — ikki xil javob.</p>",
 after:"<p><b>Necha ga</b> ko'p (farq) — <b>ayirish</b>: 40 − 10 = 30. <b>Necha marta</b> ko'p (nisbat) — <b>bo'lish</b>: 40 : 10 = 4. Bu ikki savolni aralashtirish — eng ko'p uchraydigan xato.</p>",
 q:{t:"Rasm to'garagida 36, musiqada 9 o'quvchi. Rasmda musiqadan necha marta ko'p?",opts:["4 marta","27 marta","45 marta","3 marta"],ok:0,why:"36 : 9 = 4.",hint:"«Necha marta» — qaysi amal?",full:"«Necha marta» — bo'lish: 36 : 9 = 4. 27 — bu «necha ga» (ayirish), 45 — qo'shish."},
 tn:"Doskaga ikki savolni yonma-yon yozing va ostiga amal belgisini bolalar o'zi qo'ysin: «ga» → −, «marta» → :."},
{h:"Tuzoq: aldovchi diagramma",sum:"Diagramma o'qi 0 dan boshlanmasa, kichik farq juda katta bo'lib ko'rinadi. Har doim sonlarni o'qing!",a:"m06",
 start:function(){startPh(QCP6)},fin:function(){S.ph=2;QCP6[2]()},
 html:"<p>Reklamada shunday diagramma bor: «B do'kon savdosi juda ko'p!» Rostmi?</p>",
 btns:[phaser(QCP6)],
 after:"<p>Birinchi diagrammada o'q <b>51</b> dan boshlangan — shuning uchun B ustuni 5 marta baland ko'rinadi. Aslida 56 va 52, farq atigi <b>4</b>. Diagrammani o'qishda: 1) o'q 0 dan boshlanganmi? 2) shkala qadami qanday? 3) sonlar o'zi qancha?</p>",
 q:{t:"Diagrammada o'q 90 dan boshlanadi. Ustunlar: 95 va 100. Ikkinchisi birinchisidan necha marta katta ko'rinadi va aslida-chi?",opts:["2 marta ko'rinadi, aslida deyarli teng","Aslida ham 2 marta","5 marta ko'rinadi va aslida ham","Teng ko'rinadi"],ok:0,why:"90 dan: 5 va 10 birlik balandlik — 2 marta; aslida 95 va 100.",hint:"Ustunlar 90 dan qancha baland chiziladi?",full:"90 dan boshlansa, ustunlar 5 va 10 birlik — 2 marta farq ko'rinadi. Aslida 100 : 95 ≈ 1,05, ya'ni deyarli teng."},
 tn:"Gazetadan yoki reklamadan aldovchi grafik misolini topib, sinfda «tergov» o'tkazing. Bu tanqidiy fikrlash ko'nikmasi."},
{h:"O'rtacha qiymat",sum:"O'rta arifmetik = sonlar yig'indisi : sonlar soni. Diagrammada ustunlarni «tekislash» bilan ko'rinadi.",a:"m07",
 start:function(){startPh(QCP7)},fin:function(){S.ph=2;QCP7[2]()},
 html:"<p>Sardor 4 kunda kitob o'qidi. Kuniga <b>o'rtacha</b> necha soat o'qigan?</p>",
 btns:[phaser(QCP7)],
 after:"<p>Baland ustundan pastiga «quyib» tekislasak, hamma ustun <b>6</b> bo'ladi. Hisob bilan: yig'indi 6 + 9 + 3 + 6 = 24, kunlar soni 4: <b>24 : 4 = 6</b>. Bu — <b>o'rta arifmetik</b>. U eng katta va eng kichik son orasida bo'ladi.</p>",
 q:{t:"5 kunda harorat: 12°, 15°, 10°, 13°, 15°. O'rtacha harorat?",opts:["13°","65°","15°","12°"],ok:0,why:"(12 + 15 + 10 + 13 + 15) : 5 = 65 : 5 = 13.",hint:"Yig'indini kunlar soniga bo'ling.",full:"Yig'indi 65, kunlar 5: 65 : 5 = 13°. 65 — bo'lishni unutish, 15 — eng ko'p uchragan son, 12 — birinchi kun."},
 tn:"Kubiklar bilan qiling: 4 ta minorani (6, 9, 3, 6) teng qilib qayta taxlang — har birida 6 ta qoladi."},
{h:"Jadvaldagi yetishmayotgan son",sum:"«Jami» ustuni yoki qatoridan yetishmayotgan sonni ayirish bilan topamiz.",a:"m08",
 start:function(){qctab([['','I chorak','II chorak','Jami'],['Ali',14,'?',31],['Vali',12,18,30]],[1,2]);qcmsg('Ali II chorakda nechta «5» olgan?')},fin:function(){qctab([['','I chorak','II chorak','Jami'],['Ali',14,17,31],['Vali',12,18,30]],[1,2]);qcmsg('✓ 31 − 14 = <b>17</b>')},
 btns:[["45",function(c,done){qcmsg('45 = 31 + 14 — qo‘shib yubordingiz. Jamidan bilganimizni ayiramiz')}],["17",function(c,done){STEPS[7].fin();done()}],["18",function(c,done){qcmsg('18 — Valining II choragi. Alining qatoriga qarang')}],["13",function(c,done){qcmsg('Tekshiring: 14 + 13 = 27, 31 emas')}]],g2:1,
 html:"<p>Jadvalda bitta son o'chib ketgan. <b>Jami</b> ustunidan foydalanib, uni toping.</p>",
 after:"<p>Ali: 14 + ? = 31, demak ? = <b>31 − 14 = 17</b>. Tekshirish: 14 + 17 = 31 ✓. Jadvallarda «Jami» qatori yoki ustuni xatoni topish va yetishmagan sonni tiklash uchun juda foydali.</p>",
 q:{t:"Jadvalda: 3 sinfda jami 87 o'quvchi. 4-A da 29, 4-B da 30. 4-D da nechta?",opts:["28","59","116","29"],ok:0,why:"87 − 29 − 30 = 28.",hint:"Jamidan ma'lum sonlarni ayiring.",full:"87 − 29 − 30 = 28. 59 — ikki sinf yig'indisi, 116 — 87 + 29 qo'shish xatosi."},
 tn:"Sinf jurnalidagi haqiqiy son bilan mashq qiling: «Bugun sinfda 27 kishi, 3 kishi kasal — jami nechta?»"},
{h:"Bilasizmi? Diagrammani kim o'ylab topgan?",sum:"Ustunli diagrammani 1786-yilda shotlandiyalik Uilyam Pleyfer birinchi bo'lib kitobda e'lon qilgan.",a:"m09",
 start:function(){qcbars({v:[25,40,35,15],l:['Du','Se','Chor','Pay'],max:50,st:10,show:1});qcmsg('Ustunli diagramma — 1786-yildan beri')},fin:function(){qcbars({v:[25,40,35,15],l:['Du','Se','Chor','Pay'],max:50,st:10,show:1});qcmsg('Ustunli diagramma — 1786-yildan beri')},
 html:"<p>📊 Ustunli va chiziqli diagrammalarni shotlandiyalik <b>Uilyam Pleyfer</b> 1786-yilda chop etgan kitobida birinchi bo'lib keng qo'llagan. Doiraviy diagramma ham uning ixtirosi (1801).</p><p>🏥 Ingliz hamshirasi <b>Florens Naytingeyl</b> 1850-yillarda harbiy kasalxonalardagi o'limlar sababini diagrammalar bilan ko'rsatib, hukumatni gigiena qoidalarini o'zgartirishga ko'ndirgan. Diagramma minglab odamning hayotini saqlab qolgan!</p>",
 tn:"Bolalarga savol: «Nega so'z bilan emas, rasm bilan ko'rsatish yaxshiroq?» — ko'z farqni bir zumda ko'radi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){qcbars({v:[6,9,3,6],l:['Du','Se','Chor','Pay'],max:10,st:2,show:1});qcmsg('O‘rtacha: 24 : 4 = 6')},fin:function(){qcbars({v:[6,9,3,6],l:['Du','Se','Chor','Pay'],max:10,st:2,show:1});qcmsg('O‘rtacha: 24 : 4 = 6')},
 html:"<div class='memo'><ul><li>Jadval: son <b>qator</b> va <b>ustun</b> kesishgan katakda.</li><li>Piktogramma: avval kalitni o'qing (1 belgi = ?); yarim belgi — yarmi.</li><li>Ustunli diagramma: shkala qadamini aniqlang, ustun uchini o'qqa «yotqizing».</li><li>Necha <b>ga</b> — ayirish; necha <b>marta</b> — bo'lish.</li><li>O'q 0 dan boshlanmasa — farq aldab katta ko'rinadi!</li><li>O'rtacha = yig'indi : soni.</li><li>Jamidan ma'lumni ayirib, yetishmaganini topamiz.</li></ul></div>",
 tn:"Uyga: bir hafta davomida uyda nechta non yeyilganini jadvalga yozib, ustunli diagramma chizish."}
];
function q4draw(){qcbars({v:S.v4,l:['Du','Se','Chor','Pay'],max:40,st:5,unit:'kg',tap:qct4,hi:[2]})}
function qct4(k,v){if(k!==2){qcmsg('Bu — '+['Dushanba','Seshanba','Chorshanba','Payshanba'][k]+' ustuni. Chorshanba — uchinchi');return}if(v===30){S.v4=[20,35,30,15];STEPS[3].fin();if(S.d4){var d=S.d4;S.d4=null;d()}}else if(S.d4){S.v4=[20,35,v,15];q4draw();qcmsg('Ustun '+v+' bo‘ldi. Kerak: <b>30</b> (chiziqlar 5 dan)')}}
var PROBS=[
{t:"Jadvalda 4-A: olma 12, nok 7, uzum 9. 4-A jami nechta meva tergan?",o:["28","19","21","27"],k:0,s:"12 + 7 + 9 = 28."},
{t:"Piktogrammada 1 belgi = 5 ta daraxt. 6 ta belgi nechta daraxt?",o:["30","6","11","25"],k:0,s:"6 · 5 = 30."},
{t:"1 belgi = 10 ta qush. 4 ta butun va yarim belgi nechta qush?",o:["45","4,5","40","50"],k:0,s:"4 · 10 + 5 = 45."},
{t:"1 belgi = 8 ta mashina. 32 ta mashina nechta belgi bilan ko'rsatiladi?",o:["4","32","8","24"],k:0,s:"32 : 8 = 4."},
{t:"Diagrammada chiziqlar 20 dan. Ustun 3-chiziq bilan 4-chiziq o'rtasida. Qiymati?",o:["70","3,5","60","80"],k:0,s:"60 va 80 o'rtasi — 70."},
{t:"Ustunlar: 45 va 15. Birinchisi ikkinchisidan necha marta ko'p?",o:["3 marta","30 marta","60 marta","2 marta"],k:0,s:"45 : 15 = 3."},
{t:"Ustunlar: 45 va 15. Birinchisi ikkinchisidan necha ga ko'p?",o:["30 ga","3 ga","60 ga","15 ga"],k:0,s:"45 − 15 = 30."},
{t:"Sonlar: 7, 11, 6, 8. O'rtachasi?",o:["8","32","7","11"],k:0,s:"32 : 4 = 8."},
{t:"Uch kunlik o'rtacha 20 km. Jami necha km yurilgan?",o:["60 km","20 km","23 km","40 km"],k:0,s:"O'rtacha · kunlar = 20 · 3 = 60."},
{t:"Ikki kunda o'rtacha 15 ta, birinchi kunda 11 ta. Ikkinchi kunda nechta?",o:["19","15","4","26"],k:0,s:"Jami 30, 30 − 11 = 19."},
{t:"Jadvalda jami 100. Ma'lum qismlar: 23, 31, 18. Yetishmagan qism?",o:["28","72","32","38"],k:0,s:"100 − 23 − 31 − 18 = 28."},
{t:"Diagramma o'qi 200 dan boshlanadi. Ustunlar 210 va 230. Ikkinchisi necha marta baland ko'rinadi?",o:["3 marta","Deyarli teng","20 marta","2 marta"],k:0,s:"200 dan: 10 va 30 balandlik — 3 marta ko'rinadi, aslida farq kichik."},
{t:"Sonlar: 150, 400, 250, 300. Diagramma uchun qaysi shkala qulay?",o:["0 dan 400 gacha, qadam 50","0 dan 100 gacha, qadam 10","0 dan 400 gacha, qadam 1","150 dan 400 gacha, qadam 100"],k:0,s:"Eng kattasi sig'sin va 0 dan boshlansin, qadam qulay — 50."},
{t:"Ali 4 ta testda: 8, 6, 10, ?. O'rtachasi 8. To'rtinchi test bali?",o:["8","6","32","24"],k:0,s:"Jami 8 · 4 = 32; 32 − 24 = 8."},
{t:"Piktogramma: 1 belgi = 6 ta. Ali 3 ta belgi, Vali 4,5 ta belgi. Ikkalasi jami?",o:["45","7,5","42","48"],k:0,s:"(3 + 4,5) · 6 = 7,5 · 6 = 45 (18 + 27)."},
{t:"Jadval: 4-A 28 o'quvchi, 4-B 4-A dan 3 ta kam, 4-D 4-B dan 5 ta ko'p. 4-D da nechta?",o:["30","25","36","33"],k:0,s:"4-B 25, 4-D 30."},
{t:"Ustunlar: Du 12, Se 18, Chor 24, Pay 30. Har kuni qanchaga ortgan?",o:["6 ga","12 ga","2 marta","18 ga"],k:0,s:"18 − 12 = 6, 24 − 18 = 6, 30 − 24 = 6."},
{t:"Shu qonuniyat bilan juma kuni qancha bo'ladi?",o:["36","30","42","60"],k:0,s:"30 + 6 = 36."},
{t:"5 o'quvchining bo'yi o'rtacha 130 sm. Yangi o'quvchi (142 sm) qo'shilsa, o'rtacha?",o:["132 sm","136 sm","130 sm","142 sm"],k:0,s:"Jami 650 + 142 = 792, 792 : 6 = 132."},
{t:"Jadvalda 3 kunlik savdo: 45, 60, ?. Jami 150. Uchinchi kun birinchisidan necha ga ko'p?",o:["0 ga — teng","15 ga","45 ga","5 ga"],k:0,s:"? = 150 − 105 = 45. 45 − 45 = 0."}
];
function PRACT_STAGE(){qcbars({v:[25,40,35,15],l:['Du','Se','Chor','Pay'],max:50,st:10})}
var PREP_DATA={teach:["Ikki kirishli jadvalni o'qish; «Jami» bilan yetishmagan sonni topish.","Piktogramma: kalit, yarim belgi.","Ustunli diagramma: o'qish, shkala tanlash, tuzish.","«Necha ga» va «necha marta» savollari; o'rtacha qiymat; aldovchi diagramma."],
 mist:["Qator va ustunni adashtiradi.","Piktogrammada belgilar sonini javob deb yozadi.","Shkala qadamini e'tiborsiz qoldiradi.","«Necha marta» savoliga ayirish bilan javob beradi.","O'q 0 dan boshlanmaganini sezmaydi.","O'rtachada bo'lishni unutadi."],
 need:["Katakli daftar, rangli qalam.","Doskada jadval va diagramma shabloni.","Kubiklar (o'rtachani tekislash uchun).","Gazeta/reklamadagi diagramma namunalari."],
 board:["Qator × ustun → katak.","1 belgi = 4 → 3,5 belgi = 14.","Shkala: 10 dan → ustun 35.","Ga: 40 − 10 = 30. Marta: 40 : 10 = 4.","O'q 0 dan boshlanganmi?","O'rtacha: 24 : 4 = 6."]};
