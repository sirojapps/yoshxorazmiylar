var CODE='4A2',TITLE='4-sinf · Taqqoslash va yaxlitlash';
function a42L(a,b,step,big,v,res,o){w3line(a,b,step,v!=null?[[v,C.bad]].concat(res!=null?[[res,C.ok,fmt(res)+' ✓']]:[]):[],{big:big,y:96,fs:11});if(o)T(S.g,180,26,o,{'font-size':13,'font-weight':800,fill:C.blue})}
var STEPS=[
{h:"Avval — xonalar soni",sum:"Ko'proq xonali son katta: 999 999 < 1 000 000.",a:"m01",
 start:function(){a4cards(['999 999','1 000 000'],{title:'Qaysi son katta? Bosing',cw:150,onTap:function(i,r){a4mark(r,i===1);if(i===1){msg('Yetti xonali son har qanday olti xonali sondan katta');S.a42d&&S.a42d()}else msg('Raqamlari katta (9), lekin xonalari kam: 6 ta < 7 ta')}});msg('Raqamlarga emas — xonalar soniga qarang')},
 fin:function(){a4cards(['999 999','1 000 000'],{title:'999 999 < 1 000 000',cw:150});a4mark(S.cardEls[1],true);msg('6 xona < 7 xona')},
 act:function(c,done){S.a42d=done},
 html:"<p>Qaysi son katta? Sahnadagi kartochkani bosing.</p>",
 after:"<p>1-qadam har doim: <b>xonalar sonini</b> sanash. Bunda sinflar bo'yicha yozilgan bo'sh joylar yordam beradi: 999 999 — ikki sinf, 1 000 000 — uch sinf.</p>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["99 999 < 100 000","99 999 > 100 000","9 999 > 10 000","999 > 1 000"],ok:0,why:"Besh xonali son olti xonalidan kichik.",hint:"Har bir sonda nechta raqam bor?",full:"99 999 — 5 xona, 100 000 — 6 xona, demak 99 999 < 100 000. Qolgan yozuvlarda belgi teskari: kam xonali son katta deb olingan."},
 tn:"Bola sonni o'qishdan oldin barmoq bilan xonalarni sanasin."},
{h:"Xonalar teng — chapdan solishtiramiz",sum:"4 582 309 < 4 587 039: birinchi farq minglar xonasida (2 < 7).",a:"m02",
 start:function(){a4table(4582309,{top:'4 582 309  ?  4 587 039',tfs:13});msg('Xonalar soni teng (7). Chapdan birinchi farqni qidiramiz')},fin:function(){a4table(4587039,{hl:[3],top:'4 582 309 < 4 587 039',tfs:13});msg('Minglar: <b>2 < 7</b>')},
 html:"<p>4 582 309 va 4 587 039 ni taqqoslang. Belgini tanlang:</p>",
 btns:a4ch(["4 582 309 > 4 587 039","4 582 309 < 4 587 039","teng"],1,function(){a4table(4587039,{hl:[3],top:'4 582 309 < 4 587 039',tfs:13});msg('4, 5, 8 bir xil — keyin minglar: <b>2 < 7</b>. Qolgan raqamlar endi muhim emas')},function(i){msg(i===0?'Oxiri 309 > 039 — lekin farq oldinroq, minglar xonasida!':'Raqamlar o‘xshash, lekin xonalarda farq bor')}),g3:1,
 after:"<p>Birinchi farq qilgan xona hamma narsani hal qiladi. Undan o'ngdagi raqamlar qanchalik katta bo'lmasin, natijani o'zgartirmaydi.</p>",
 q:{t:"Eng kichik sonni toping:",opts:["5 099 999","5 100 000","5 909 000","5 190 000"],ok:0,why:"Yuz minglar: 0 < 1 < 9.",hint:"Millionlar teng (5). Keyingi xonaga qarang.",full:"Hammasida 5 million. Yuz minglar: 0, 1, 9, 1. Eng kichigi — 0: 5 099 999. Oxiridagi to'qqizlar uni katta qilmaydi."},
 tn:"Ikki sonni jadvalda ustma-ust yozib, farq qilgan xonani doiraga olish."},
{h:"Tuzoq: yashirin raqam",sum:"63 □41 > 63 741 bo'lishi uchun □ eng kamida 8.",a:"m03",
 start:function(){a4table(0,{str:'63?41',top:'63 ?41  >  63 741'});msg('□ o‘rniga qaysi raqamlar mos keladi?')},fin:function(){a4table(63841,{hl:[2],top:'63 841 > 63 741'});msg('□ = 8 yoki 9; eng kichigi <b>8</b>')},
 html:"<p>63 □41 &gt; 63 741. □ o'rniga qo'yish mumkin bo'lgan <b>eng kichik</b> raqam qaysi?</p>",
 btns:a4ch(["7","8","9","0"],1,function(){a4table(63841,{hl:[2],top:'63 841 > 63 741'});msg('7 bo‘lsa — <b>teng</b> bo‘ladi, katta emas. Demak 8 (yoki 9)')},function(i){msg(i===0?'63 741 = 63 741 — teng, «>» emas!':i===2?'9 ham mos, lekin eng kichigi emas':'63 041 < 63 741')}),g2:1,
 after:"<p>Tuzoq — «teng» holatini unutish. Doim tekshiring: chegaradagi raqam qo'yilsa, sonlar <b>teng</b> bo'lib qolmaydimi?</p>",
 q:{t:"7 □05 < 7 405. □ o'rniga nechta raqam qo'yish mumkin?",opts:["4 ta","5 ta","3 ta","10 ta"],ok:0,why:"0, 1, 2, 3 — to'rtta.",hint:"□ = 4 bo'lsa nima bo'ladi?",full:"□ < 4 bo'lishi kerak: 0, 1, 2, 3 — 4 ta. □ = 4 da sonlar teng bo'ladi, shuning uchun «5 ta» — xato."},
 tn:"Bank 4A2-turi. Bolalar har bir raqamni qo'yib tekshirsin (sanab chiqish)."},
{h:"Yaxlitlash nima?",sum:"4 372 ni yuzliklargacha yaxlitlash: 4 300 va 4 400 orasida, 4 400 ga yaqin.",a:"m04",
 start:function(){a42L(4300,4400,10,50,4372,null,'4 372 qaysi yuzlikka yaqin?');msg('4 372 — 4 300 va 4 400 orasida')},fin:function(){a42L(4300,4400,10,50,4372,4400,'4 372 ≈ 4 400');msg('72 > 50 → yuqoriga: <b>4 400</b>')},
 html:"<p>Yaxlitlash — sonni eng yaqin «yumaloq» songa almashtirish. 4 372 ni <b>yuzliklargacha</b> yaxlitlang: qaysi yuzlikka yaqinroq?</p>",
 btns:a4ch(["4 300","4 400"],1,function(){a42L(4300,4400,10,50,4372,4400,'4 372 ≈ 4 400');msg('4 400 gacha 28 qadam, 4 300 gacha 72. Yaqini — <b>4 400</b>')},function(){msg('4 300 dan 72 uzoqda, 4 400 dan 28. Qaysi yaqin?')}),g2:1,
 after:"<p>Qoida: yaxlitlanayotgan xonadan <b>o'ngdagi birinchi raqamga</b> qaraymiz. 0–4 bo'lsa — pastga (xona o'zgarmaydi), <b>5–9</b> bo'lsa — yuqoriga (xona 1 ga oshadi). O'ngdagi hamma raqamlar nolga aylanadi. Belgi: <b>≈</b> («taxminan teng»).</p>",
 q:{t:"6 249 ni yuzliklargacha yaxlitlang:",opts:["6 200","6 300","6 250","6 000"],ok:0,why:"O'ngdagi raqam 4 < 5 → pastga.",hint:"Yuzliklar xonasidan keyingi raqam qaysi?",full:"6 2|49: yuzliklar — 2, keyingi raqam 4 → pastga: 6 200. «6 300» — 49 ni 50 deb yaxlitlab, keyin yana yaxlitlash (ikki marta yaxlitlash — xato!)."},
 tn:"Son o'qi chizib, yuzliklarni «uylar» deb ataymiz: son qaysi uyga yaqinroq bo'lsa, o'sha uyga boradi (Gollandiya RME)."},
{h:"Aynan o'rtada — 5",sum:"38 500 ni minglargacha: o'ngdagi raqam 5 → yuqoriga: 39 000.",a:"m05",
 start:function(){a42L(38000,39000,100,500,38500,null,'38 500 — aynan o‘rtada');msg('Ikkala mingdan bir xil uzoqlikda')},fin:function(){a42L(38000,39000,100,500,38500,39000,'38 500 ≈ 39 000');msg('5 bo‘lsa — <b>yuqoriga</b>')},
 html:"<p>38 500 ni <b>minglargacha</b> yaxlitlang. U 38 000 va 39 000 ning aynan o'rtasida. Qaysi biri?</p>",
 btns:a4ch(["38 000","39 000"],1,function(){a42L(38000,39000,100,500,38500,39000,'38 500 ≈ 39 000');msg('Kelishuv bo‘yicha 5 bo‘lsa yuqoriga: <b>39 000</b>')},function(){msg('O‘rtadagi son uchun kelishuv: 5 — yuqoriga yaxlitlanadi')}),g2:1,
 after:"<p>Matematiklar kelishgan: 5 bo'lsa — <b>yuqoriga</b>. Shuning uchun 38 500 ≈ 39 000, lekin 38 499 ≈ 38 000.</p>",
 q:{t:"72 509 ni minglargacha yaxlitlang:",opts:["73 000","72 000","72 500","70 000"],ok:0,why:"Minglardan keyingi raqam 5 → yuqoriga.",hint:"72 | 509 — chiziqdan keyingi birinchi raqam?",full:"72|509: keyingi raqam 5 → 73 000. «72 500» — yuzliklargacha yaxlitlash; «70 000» — o'n minglargacha."},
 tn:"«38 500 qaysi uyga boradi?» — munozara, keyin kelishuvni tushuntiring."},
{h:"Tuzoq: zanjirli o'tish",sum:"4 962 ni yuzliklargacha: 9 + 1 = 10 → 5 000.",a:"m06",
 start:function(){a4table(4962,{hl:[2],top:'4 962 ≈ ? (yuzliklargacha)'});msg('Yuzliklar — 9, keyingi raqam 6')},fin:function(){a4table(5000,{hl:[3,2],top:'4 962 ≈ 5 000'});msg('9 + 1 = 10 → minglar ham 1 ga oshadi')},
 html:"<p>4 962 ni yuzliklargacha yaxlitlang. Yuzliklarda 9 turibdi — ehtiyot bo'ling!</p>",
 btns:a4ch(["4 900","5 000","4 1000","4 960"],1,function(){a4table(5000,{hl:[3,2],top:'4 962 ≈ 5 000'});msg('9 yuzlik + 1 = 10 yuzlik = 1 ming → <b>5 000</b>')},function(i){msg(i===0?'6 ≥ 5 — yuqoriga yaxlitlash kerak!':i===2?'Bunday son yo‘q: 10 yuzlik = 1 ming':'Bu o‘nliklargacha yaxlitlash')}),g2:1,
 after:"<p>Yuqoriga yaxlitlaganda 9 → 10 bo'lsa, xuddi qo'shishdagidek <b>keyingi xonaga o'tadi</b>: 39 970 ≈ 40 000 (o'nliklargacha ham!). Javobni son o'qida tekshiring: 4 962 haqiqatan 5 000 ga yaqin.</p>",
 q:{t:"39 970 ni yuzliklargacha yaxlitlang:",opts:["40 000","39 900","39 000","40 970"],ok:0,why:"39 9|70: 7 ≥ 5 → 9 + 1 = 10 yuzlik → 40 000.",hint:"Yuzliklar xonasida 9 turibdi.",full:"39 9|70: keyingi raqam 7 → yuzliklar 9 + 1 = 10 → 1 ming o'tadi: 39 + 1 = 40 ming → 40 000. «39 900» — pastga yaxlitlash (7 ≥ 5 bo'lsa ham); «40 970» — o'ngdagi raqamlarni nolga aylantirmaslik."},
 tn:"Bank 4A2-turi: 9 dan keyingi zanjirli o'tish — eng ko'p xato qilinadigan joy."},
{h:"Qaysi sonlar 7 000 ga yaxlitlanadi?",sum:"Minglargacha 7 000 bo'ladigan sonlar: 6 500 dan 7 499 gacha.",a:"m07",
 start:function(){a42L(6000,8000,100,500,null,null,'≈ 7 000 bo‘ladigan sonlar qayerda?');var g=S.g,X=S.X;E('rect',{x:X(6500),y:84,width:X(7500)-X(6500),height:24,rx:4,fill:'rgba(18,163,159,.18)'},g);msg('Yashil oraliq — 7 000 ning «hududi»')},
 fin:function(){a42L(6000,8000,100,500,null,null,'6 500 … 7 499 ≈ 7 000');var g=S.g,X=S.X;E('rect',{x:X(6500),y:84,width:X(7500)-X(6500),height:24,rx:4,fill:'rgba(18,163,159,.18)'},g);msg('Eng kichigi <b>6 500</b>, eng kattasi <b>7 499</b>')},
 html:"<p>Minglargacha yaxlitlanganda <b>7 000</b> bo'ladigan <b>eng katta</b> butun son qaysi?</p>",
 btns:a4ch(["7 500","7 499","7 999","7 000"],1,function(){msg('7 500 ≈ 8 000 (5 — yuqoriga). Shuning uchun eng kattasi <b>7 499</b>')},function(i){msg(i===0?'7 500 da keyingi raqam 5 → 8 000 ga yaxlitlanadi!':i===2?'7 999 ≈ 8 000':'7 000 dan katta sonlar ham bor')}),g2:1,
 after:"<p>Teskari savol: «yaxlitlanganda X bo'ldi, asl son qanday bo'lishi mumkin?» — javob <b>oraliq</b>. 7 000 uchun: 6 500 ≤ son ≤ 7 499.</p>",
 q:{t:"Yuzliklargacha yaxlitlanganda 3 800 bo'ladigan eng kichik butun son:",opts:["3 750","3 700","3 751","3 749"],ok:0,why:"3 750 ≈ 3 800 (5 — yuqoriga), 3 749 ≈ 3 700.",hint:"3 700 va 3 800 ning o'rtasi qaysi son?",full:"3 750 — o'rtasi, kelishuvga ko'ra yuqoriga: 3 800. 3 749 ≈ 3 700. Demak eng kichigi 3 750."},
 tn:"Bank 4A2 qiyin turi. Son o'qida oraliqni rangli qalam bilan bo'yatish."},
{h:"Hayotda: katta sonlarni yaxlitlash",sum:"37 543 210 ≈ 38 000 000 (millionlargacha).",a:"m08",
 start:function(){a4table(37543210,{top:'37 543 210 kishi'});msg('Millionlargacha yaxlitlang')},fin:function(){a4table(38000000,{hl:[6],top:'≈ 38 000 000'});msg('37 | 5… → 5 ≥ 5 → <b>38 million</b>')},
 html:"<p>Yangiliklarda «mamlakatda <b>38 million</b> kishi yashaydi» deyiladi — bu yaxlitlangan son. 37 543 210 ni millionlargacha yaxlitlang:</p>",
 btns:a4ch(["37 000 000","38 000 000","37 500 000"],1,function(){a4table(38000000,{hl:[6],top:'≈ 38 000 000'});msg('Millionlardan keyingi raqam 5 → <b>38 000 000</b>')},function(i){msg(i===0?'Keyingi raqam 5 — yuqoriga!':'Bu yuz minglargacha yaxlitlash')}),g3:1,
 after:"<p>Katta sonlarni yaxlitlab aytish qulay: eslab qolish va solishtirish oson. Lekin hisob-kitobda (pul, narx) aniq son kerak.</p>",
 q:{t:"Stadionda 48 712 tomoshabin bor. O'n minglargacha yaxlitlang:",opts:["50 000","40 000","49 000","48 700"],ok:0,why:"O'n minglardan keyingi raqam 8 → yuqoriga.",hint:"4|8 712 — 4 dan keyingi raqam?",full:"4|8 712: 8 ≥ 5 → 50 000. «49 000» — minglargacha; «48 700» — yuzliklargacha."},
 tn:"Gazetadan son topib yaxlitlash — uyga vazifa."},
{h:"Bilasizmi?",sum:"Do'konlardagi 9 990 so'mlik narx — «chap raqam» hiylasi.",a:"m09",
 start:function(){a4cards(['9 990','10 000'],{title:'Qaysi biri ancha arzon tuyuladi?',cw:150});msg('Farqi atigi 10 so‘m')},fin:function(){a4cards(['9 990','10 000'],{title:'Farqi — 10 so‘m',cw:150});msg('Farqi atigi 10 so‘m')},
 html:"<p>🏷 Narxlar ko'pincha <b>9 990</b> yoki <b>49 900</b> deb yoziladi. Odamlar sonni chapdan o'qiydi va birinchi raqamga ko'proq e'tibor beradi: «9 ming» — «10 ming»dan ancha arzon tuyuladi. Aslida farq atigi 10 so'm!</p><p>✅ Siz endi yaxlitlashni bilasiz: 9 990 ≈ <b>10 000</b>.</p>",
 tn:"Bolalar do'kon cheklaridan narxlarni olib kelib, yaxlitlab yig'indini chamalasin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a42L(4300,4400,10,50,4372,4400,'4 372 ≈ 4 400')},fin:function(){a42L(4300,4400,10,50,4372,4400,'4 372 ≈ 4 400')},
 html:"<div class='memo'><ul><li>Taqqoslash: 1) xonalar soni; 2) chapdan birinchi farq.</li><li>Yashirin raqam: «teng» holatini tekshiring.</li><li>Yaxlitlash: kerakli xonadan keyingi raqam 0–4 → pastga, 5–9 → yuqoriga; o'ngi — nollar.</li><li>9 + 1 = 10 → keyingi xonaga o'tadi: 4 962 ≈ 5 000.</li><li>Ikki marta yaxlitlamang: 6 249 ≈ 6 200 (6 300 emas).</li><li>≈ 7 000 (minglargacha) → 6 500 … 7 499.</li></ul></div>",
 tn:"Keyingi dars — sonlar ketma-ketligi."}
];
var PROBS=[
{t:"Qaysi yozuv to'g'ri?",o:["99 999 < 100 000","99 999 > 100 000","9 999 > 10 000","999 999 > 1 000 000"],k:0,s:"Kam xonali son kichik."},
{t:"Eng kichik sonni toping:",o:["5 099 999","5 100 000","5 190 000","5 909 000"],k:0,s:"Yuz minglar: 0 eng kichik."},
{t:"Eng katta sonni toping:",o:["3 080 000","3 008 000","3 000 800","3 000 080"],k:0,s:"Yuz minglar teng (0), o'n minglar: 8."},
{t:"Qaysi yozuv to'g'ri?",o:["4 582 309 < 4 587 039","4 582 309 > 4 587 039","4 582 309 = 4 587 039","4 587 039 < 4 582 309"],k:0,s:"Minglar: 2 < 7."},
{t:"63 □41 > 63 741. □ ning eng kichik qiymati:",o:["8","7","9","0"],k:0,s:"7 da teng bo'ladi."},
{t:"7 □05 < 7 405. □ o'rniga nechta raqam qo'yish mumkin?",o:["4 ta","5 ta","3 ta","6 ta"],k:0,s:"0, 1, 2, 3."},
{t:"6 249 ni yuzliklargacha yaxlitlang:",o:["6 200","6 300","6 250","6 000"],k:0,s:"Keyingi raqam 4."},
{t:"72 509 ni minglargacha yaxlitlang:",o:["73 000","72 000","72 500","70 000"],k:0,s:"Keyingi raqam 5."},
{t:"4 962 ni yuzliklargacha yaxlitlang:",o:["5 000","4 900","4 960","4 000"],k:0,s:"9 + 1 = 10."},
{t:"39 970 ni o'nliklargacha yaxlitlang:",o:["39 970","40 000","39 900","39 980"],k:0,s:"Birliklar 0 — son o'zgarmaydi."},
{t:"39 975 ni o'nliklargacha yaxlitlang:",o:["39 980","39 970","40 000","39 900"],k:0,s:"Birliklar 5 → o'nliklar 7 + 1 = 8."},
{t:"39 996 ni o'nliklargacha yaxlitlang:",o:["40 000","39 990","39 900","40 990"],k:0,s:"9 + 1 = 10 → zanjir: 40 000."},
{t:"Minglargacha yaxlitlanganda 7 000 bo'ladigan eng katta butun son:",o:["7 499","7 500","7 999","7 000"],k:0,s:"7 500 ≈ 8 000."},
{t:"Yuzliklargacha yaxlitlanganda 3 800 bo'ladigan eng kichik butun son:",o:["3 750","3 700","3 749","3 751"],k:0,s:"3 750 — o'rtasi, yuqoriga."},
{t:"37 543 210 ni millionlargacha yaxlitlang:",o:["38 000 000","37 000 000","37 500 000","40 000 000"],k:0,s:"Keyingi raqam 5."},
{t:"48 712 ni o'n minglargacha yaxlitlang:",o:["50 000","40 000","49 000","48 700"],k:0,s:"Keyingi raqam 8."},
{t:"Qaysi son yuzliklargacha yaxlitlanganda 5 000 bo'lmaydi?",o:["5 050","4 950","4 999","5 049"],k:0,s:"5 050 ≈ 5 100 (5 — yuqoriga)."},
{t:"Son minglargacha yaxlitlanganda 12 000 bo'ldi. Asl son quyidagilardan qaysi biri bo'lishi mumkin emas?",o:["12 500","11 500","12 499","11 999"],k:0,s:"12 500 ≈ 13 000."},
{t:"2 □87 ni yuzliklargacha yaxlitlaganda 2 500 chiqdi. □ = ?",o:["4","5","3","6"],k:0,s:"2 487 ≈ 2 500; 2 587 ≈ 2 600."},
{t:"Ali 3 856 ni avval o'nliklargacha (3 860), keyin yuzliklargacha (3 900) yaxlitladi. To'g'ridan-to'g'ri yuzliklargacha yaxlitlansa nima chiqadi?",o:["3 900","3 800","3 860","4 000"],k:0,s:"3 8|56: 5 → 3 900 (bu safar natija bir xil)."}
];
function PRACT_STAGE(){a42L(4300,4400,10,50,4372,4400,'4 372 ≈ 4 400')}
var PREP_DATA={teach:["Ko'p xonali sonlarni taqqoslash (xonalar soni, chapdan birinchi farq).","Yashirin raqamli taqqoslash.","Yaxlitlash qoidasi, 5 holati, zanjirli o'tish, teskari savol (oraliq)."],mist:["Oxirgi raqamlarga qarab taqqoslaydi.","63 □41 > 63 741 da 7 ni ham qo'shadi.","4 962 ni 4 900 yoki «4 1000» deb yaxlitlaydi.","Ikki marta yaxlitlaydi: 6 249 → 6 250 → 6 300."],need:["Son o'qi (doskada), xonalar jadvali."],board:["<span class='w2'>4 582 309 < 4 587 039</span>.","<span class='w2'>4 372 ≈ 4 400</span>, <span class='w2'>6 249 ≈ 6 200</span>.","<span class='w2'>4 962 ≈ 5 000</span>.","<span class='w2'>6 500 … 7 499 ≈ 7 000</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
