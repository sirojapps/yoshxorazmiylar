var CODE='3E6',TITLE='3-sinf · Sodda harakat masalalari: tezlik, vaqt, masofa';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w6u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Tezlik — 1 soatdagi yo‘l",sum:"3 soatda 54 km → 1 soatda 54 : 3 = 18 km (tezlik 18 km/soat) → 5 soatda 18 · 5 = 90 km.",a:"m01",
 frames:[{t:'Velosipedchi 3 soatda 54 km yo‘l bosdi. Shu tezlik bilan 5 soatda-chi?',bars:[{lab:'3 soat',y:68,segs:w6u(3,'?','a',1)},{lab:'5 soat',y:112,segs:w6u(5,'?','q',1)}],br:[{b:0,lab:'54 km',up:true}],note:'Har bir bo‘lak — 1 soatda bosilgan yo‘l'},
  {t:'Velosipedchi 3 soatda 54 km yo‘l bosdi. Shu tezlik bilan 5 soatda-chi?',bars:[{lab:'3 soat',y:68,segs:w6u(3,'18','a',1)},{lab:'5 soat',y:112,segs:w6u(5,'?','q',1)}],br:[{b:0,lab:'54 km',up:true}],calc:['Tezlik: 54 : 3 = 18 km/soat']},
  {t:'Velosipedchi 3 soatda 54 km yo‘l bosdi. Shu tezlik bilan 5 soatda-chi?',bars:[{lab:'3 soat',y:68,segs:w6u(3,'18','a',1)},{lab:'5 soat',y:112,segs:w6u(5,'18','g',1)}],br:[{b:0,lab:'54 km',up:true},{b:1,lab:'90 km',up:false,col:C.ok}],calc:['1) 54 : 3 = 18 km/soat','2) 18 · 5 = <b>90</b> km']}],
 html:"<p><b>Tezlik</b> — 1 soatda (yoki 1 sekundda) bosilgan yo'l. Chizmada — bitta bo'lak. Kuzating.</p>",
 after:"<p>Tezlik birligi — <b>km/soat</b> («soatiga kilometr») yoki <b>m/s</b>. «Shu tezlik bilan» — bo'laklar bir xil. Bu «birga keltirish»ning o'zi!</p>",
 q:{t:"Piyoda 2 soatda 10 km yurdi. Shu tezlikda 3 soatda necha km yuradi?",opts:["15","30","5","13"],ok:0,why:"10 : 2 = 5 km/soat; 5 · 3 = 15.",hint:"Avval 1 soatda necha km?",full:"Tezlik 10 : 2 = 5 km/soat. 3 soatda 5 · 3 = 15 km. «30» — 10 · 3, «13» — 10 + 3."},
 tn:"Bank misoli (1353-id). Sinf polida 1 m qadamlar bilan yurib, «tezlik»ni his qildiring."}),
bmStep({h:"Uch formula — bitta chizma",sum:"Masofa = tezlik · vaqt; tezlik = masofa : vaqt; vaqt = masofa : tezlik.",a:"m02",
 frames:[{t:'Mashina 60 km/soat tezlikda 4 soat yurdi. Masofani qanday topamiz?',bars:[{lab:'4 soat',y:76,segs:w6u(4,'60','a',1)}],br:[{b:0,lab:'masofa = ?',up:true}],note:'To‘g‘ri hisobni tanlang:'}],
 html:"<p>Narx · miqdor = qiymat ni eslang. Harakatda ham xuddi shunday uchlik bor. Qaysi hisob to'g'ri?</p>",
 btns:bmPick(["60 + 4","60 · 4","60 : 4"],1,{t:'Masofa = tezlik · vaqt',bars:[{lab:'4 soat',y:76,segs:w6u(4,'60','g',1)}],br:[{b:0,lab:'240 km',up:true,col:C.ok},{b:0,lab:'tezlik 60 km/soat × 4 soat',up:false}],calc:['60 · 4 = <b>240</b> km']},["Soat va km ni qo‘shib bo‘lmaydi — har soatda 60 km qo‘shiladi: 4 marta.","","Bo‘lish — vaqt yoki tezlikni topishda kerak."]),
 after:"<p><b>S = v · t</b> (masofa = tezlik · vaqt). Undan: <b>v = S : t</b>, <b>t = S : v</b>. Uchburchak: tepada S, pastda v va t — yopilgan harf amalni ko'rsatadi.</p>",
 q:{t:"Poyezd 360 km ni 90 km/soat tezlikda yurdi. Necha soat yurdi?",opts:["4","270","450","32 400"],ok:0,why:"360 : 90 = 4.",hint:"Vaqt = masofa : tezlik.",full:"t = S : v = 360 : 90 = 4 soat. «270» — ayirish, «32 400» — ko'paytirish xatosi."},
 tn:"Doskaga S–v–t uchburchagini chizing. Uch formulani yodlatmang — uchburchakdan «o'qishni» o'rgating."}),
bmStep({h:"Necha marta uzun — necha marta ko‘p vaqt",sum:"Bo'ri 120 m ni 8 s da; 360 m = 3 marta uzun → 8 · 3 = 24 s.",a:"m03",
 frames:[{t:'Bo‘ri 120 m ni 8 sekundda bosib o‘tdi. 360 m ni necha sekundda bosadi?',bars:[{lab:'120 m',y:68,segs:[{w:120,txt:'8 s',c:'a'}]},{lab:'360 m',y:112,segs:[{w:360,txt:'?',c:'q'}]}],note:'360 m — necha marta 120 m?'},
  {t:'Bo‘ri 120 m ni 8 sekundda bosib o‘tdi. 360 m ni necha sekundda bosadi?',bars:[{lab:'120 m',y:68,segs:[{w:120,txt:'8 s',c:'a'}]},{lab:'360 m',y:112,segs:w6u(3,'8 s','g',120)}],br:[{b:1,lab:'24 s',up:false,col:C.ok}],calc:['360 : 120 = 3 marta','8 · 3 = <b>24</b> s']}],
 html:"<p>Tezlikni hisoblamasdan ham bo'ladi — «necha marta?» usuli. Kuzating.</p>",
 after:"<p>Tezlik bir xil bo'lsa: yo'l 3 marta uzun → vaqt ham 3 marta ko'p. Tekshiruv: tezlik 120 : 8 = 15 m/s, 360 : 15 = 24 s ✓.</p>",
 q:{t:"Toshbaqa 4 m ni 2 daqiqada o'tadi. 20 m ni necha daqiqada o'tadi?",opts:["10","40","5","22"],ok:0,why:"20 : 4 = 5 marta; 2 · 5 = 10.",hint:"20 m — necha marta 4 m?",full:"20 : 4 = 5 marta uzun, vaqt ham 5 marta: 2 · 5 = 10 daqiqa. «40» — 20 · 2, «5» — faqat «marta» soni."},
 tn:"Bank misoli (21-id)."}),
bmStep({h:"Kim tezroq? Birliklarni tenglang",sum:"Akmal 140 m/70 s = 2 m/s; Sardor 360 m/2 min = 360/120 = 3 m/s; Jasur 200/40 = 5 m/s — Jasur.",a:"m04",
 frames:[{t:'Akmal 140 m ni 70 s da, Sardor 360 m ni 2 minutda, Jasur 200 m ni 40 s da yugurdi.',bars:[{lab:'Akmal',y:44,segs:[{w:5,txt:'140 m / 70 s',c:'q'}]},{lab:'Sardor',y:88,segs:[{w:5,txt:'360 m / 2 min',c:'q'}]},{lab:'Jasur',y:132,segs:[{w:5,txt:'200 m / 40 s',c:'q'}]}],note:'Kimning tezligi eng katta?',max:5}],
 html:"<p>Kim eng tez yugurdi? Har birining 1 sekunddagi yo'lini toping. Diqqat: vaqt birligi har xil!</p>",
 btns:bmPick(["Sardor","Jasur","Akmal"],1,{t:'1 sekundda bosilgan yo‘l (m/s)',bars:[{lab:'Akmal',y:44,segs:[{w:2,txt:'2',c:'a'}]},{lab:'Sardor',y:88,segs:[{w:3,txt:'3',c:'b'}]},{lab:'Jasur',y:132,segs:[{w:5,txt:'5',c:'g'}]}],calc:['140 : 70 = 2;  2 min = 120 s, 360 : 120 = 3','200 : 40 = <b>5</b> m/s — Jasur eng tez']},["Sardor ko‘p yo‘l yugurdi, lekin 2 min = 120 s: 360 : 120 = 3 m/s.","","Akmal: 140 : 70 = 2 m/s — eng sekini."]),
 after:"<p>Tezliklarni solishtirish uchun: 1) vaqtni <b>bir xil birlikka</b> o'tkazing (1 min = 60 s); 2) har birining <b>tezligini</b> toping. Eng uzun yo'l — eng tez degani emas!</p>",
 q:{t:"Ot 3 minutda 1800 m, mashina 1 minutda 1200 m yurdi. Kim tezroq va 1 minutda necha m farq?",opts:["Mashina, 600 m","Ot, 600 m","Mashina, 1200 m","Teng"],ok:0,why:"Ot 600 m/min, mashina 1200 m/min.",hint:"Otning 1 minutdagi yo'li?",full:"Ot: 1800 : 3 = 600 m/min. Mashina 1200 m/min. Mashina 600 m ga tez. «Ot» — umumiy yo'l bo'yicha solishtirish xatosi."},
 tn:"Bank misoli (34-id), 3-daraja. Jismoniy tarbiya darsida 30 m yugurish natijalarini solishtirish."}),
bmStep({h:"Qarama-qarshi yo‘nalishda",sum:"62 va 115 km/soat, qarama-qarshi: har soatda 177 km uzoqlashadi; 4 soatda 177 · 4 = 708 km.",a:"m05",
 frames:[{t:'Ikki mashina bir joydan qarama-qarshi tomonga 62 va 115 km/soat tezlikda yo‘lga chiqdi.',bars:[{lab:'1 soat',y:72,segs:[{w:62,txt:'62',c:'a'},{w:115,txt:'115',c:'b'}]}],br:[{b:0,lab:'177 km',up:false}],note:'1 soatda: 62 + 115 = 177 km uzoqlashadi',max:708},
  {t:'Ikki mashina bir joydan qarama-qarshi tomonga 62 va 115 km/soat tezlikda yo‘lga chiqdi.',bars:[{lab:'4 soat',y:72,segs:w6u(4,'62','a',62).concat(w6u(4,'115','b',115))}],br:[{b:0,from:0,to:3,lab:'248',up:true},{b:0,from:4,to:7,lab:'460',up:true},{b:0,lab:'708 km',up:false,col:C.ok}],calc:['1-usul: (62 + 115) · 4 = 177 · 4 = <b>708</b> km','2-usul: 62 · 4 + 115 · 4 = 248 + 460 = 708 km']}],
 html:"<p>Mashinalar bir nuqtadan <b>teskari</b> tomonlarga ketyapti. Ular orasidagi masofa har soatda qanchaga oshadi? Kuzating.</p>",
 after:"<p>Qarama-qarshi harakatda tezliklar <b>qo'shiladi</b>: «uzoqlashish tezligi» = 62 + 115 = 177 km/soat. Ikki usul — bitta javob.</p>",
 q:{t:"Ikki qush bir daraxtdan qarama-qarshi tomonga 12 va 18 m/s tezlikda uchdi. 5 sekunddan keyin ular orasidagi masofa?",opts:["150 m","30 m","30 m/s","60 m"],ok:0,why:"(12 + 18) · 5 = 150.",hint:"1 sekundda ular orasi qanchaga oshadi?",full:"1 sekundda 12 + 18 = 30 m uzoqlashadi, 5 sekundda 30 · 5 = 150 m. «30» — faqat 1 sekund, «60» — 18 − 12 = 6 farqni ishlatish xatosi."},
 tn:"Bank misoli (146-id). Ikki o'quvchini sinf o'rtasidan teskari tomonga qadam tashlatib ko'rsating."}),
bmStep({h:"Bir-biriga qarab",sum:"300 km, 60 va 40 km/soat qarama-qarshi tomondan: har soatda 100 km yaqinlashadi → 300 : 100 = 3 soat.",a:"m06",
 frames:[{t:'Ikki shahar orasi 300 km. Ikki mashina bir vaqtda bir-biriga qarab 60 va 40 km/soat tezlikda chiqdi.',bars:[{lab:'yo‘l',y:72,segs:[{w:300,txt:'',c:'x'}]}],br:[{b:0,lab:'300 km',up:true}],note:'Necha soatda uchrashadi?'},
  {t:'Ikki shahar orasi 300 km. Ikki mashina bir vaqtda bir-biriga qarab 60 va 40 km/soat tezlikda chiqdi.',bars:[{lab:'yo‘l',y:72,segs:[{w:60,txt:'60',c:'a'},{w:200,txt:'1 soatdan keyin',c:'x'},{w:40,txt:'40',c:'b'}]}],br:[{b:0,lab:'300 km',up:true}],calc:['1 soatda yaqinlashish: 60 + 40 = 100 km']},
  {t:'Ikki shahar orasi 300 km. Ikki mashina bir vaqtda bir-biriga qarab 60 va 40 km/soat tezlikda chiqdi.',bars:[{lab:'yo‘l',y:72,segs:w6u(3,'60','a',60).concat(w6u(3,'40','b',40))}],br:[{b:0,lab:'300 km',up:true},{b:0,from:0,to:2,lab:'3 soat',up:false,col:C.ok},{b:0,from:3,to:5,lab:'3 soat',up:false,col:C.ok}],calc:['300 : 100 = <b>3</b> soatda uchrashadi','Tekshiruv: 60 · 3 + 40 · 3 = 180 + 120 = 300 ✓']}],
 html:"<p>Endi mashinalar bir-biriga <b>qarab</b> kelyapti. Har soatda oradagi masofa qanchaga qisqaradi? Kuzating.</p>",
 after:"<p>Bir-biriga qarab harakatda ham tezliklar qo'shiladi: «yaqinlashish tezligi» = 100 km/soat. Uchrashish vaqti = masofa : yaqinlashish tezligi.</p>",
 q:{t:"Ikki qishloq orasi 24 km. Ikki piyoda bir-biriga qarab 5 va 3 km/soat tezlikda chiqdi. Necha soatda uchrashadi?",opts:["3","12","8","192"],ok:0,why:"24 : (5 + 3) = 3.",hint:"1 soatda ular qanchaga yaqinlashadi?",full:"1 soatda 5 + 3 = 8 km yaqinlashadi. 24 : 8 = 3 soat. «12» — 24 : (5 − 3), «8» — yaqinlashish tezligi."},
 tn:"Ikki o'quvchini sinfning ikki chetidan bir-biriga qarab yurgizing: har qadamdan keyin oradagi masofani o'lchang."}),
bmStep({h:"Tuzoq: poyezd va tunnel",sum:"Poyezd 800 m, tunnel 1200 m; to'liq o'tishi uchun 1200 + 800 = 2000 m yuradi → 2000 : 40 = 50 m/s.",a:"m07",
 frames:[{t:'800 m li poyezd 1200 m li tunneldan 40 s da to‘liq o‘tib ketdi. Tezligi necha m/s?',bars:[{lab:'yo‘l',y:72,segs:[{w:1200,txt:'tunnel 1200',c:'x'},{w:800,txt:'poyezd 800',c:'b'}]}],note:'Tezlikni tanlang:'}],
 html:"<p>«To'liq o'tib ketdi» — poyezdning <b>boshi</b> tunnelga kirgandan <b>oxirgi vagoni</b> chiqquncha. Qancha yo'l bosdi?</p>",
 btns:bmPick(["30 m/s","20 m/s","50 m/s"],2,{t:'Poyezd boshi bosgan yo‘l = tunnel + poyezd uzunligi',bars:[{lab:'yo‘l',y:72,segs:[{w:1200,txt:'1200',c:'a'},{w:800,txt:'800',c:'b'}]}],br:[{b:0,lab:'2000 m',up:true,col:C.ok}],calc:['1) 1200 + 800 = 2000 m','2) 2000 : 40 = <b>50</b> m/s']},["30 = 1200 : 40 — poyezd boshi tunneldan chiqqanda dumi hali ichkarida!","20 = 800 : 40 — faqat poyezd uzunligi olingan.",""]),
 after:"<p>Kalit: poyezdning <b>boshini</b> kuzating. U tunnelga kirgandan oxirgi vagon chiqquncha — tunnel uzunligi + poyezd uzunligini bosadi.</p>",
 q:{t:"150 m li poyezd 10 m/s tezlikda 250 m li ko'prikdan to'liq o'tdi. Necha sekund ketdi?",opts:["40","25","15","10"],ok:0,why:"(250 + 150) : 10 = 40.",hint:"Poyezd boshi qancha yo'l bosadi?",full:"Poyezd boshi 250 + 150 = 400 m yuradi; 400 : 10 = 40 s. «25» — faqat ko'prik, «15» — faqat poyezd uzunligi."},
 tn:"Bank misoli (137-id), 3-daraja. Qalam (poyezd) va daftar (tunnel) bilan stolda ko'rsating: qalamning uchini kuzating."}),
bmStep({h:"Bilasizmi? Quyosh nuri bizga qancha yo‘l yuradi?",sum:"Quyoshgacha taxminan 150 000 000 km, yorug'lik tezligi taxminan 300 000 km/s: 500 s ≈ 8 min 20 s.",a:"m08",
 frames:[{t:'Quyoshgacha ≈ 150 000 000 km. Yorug‘lik tezligi ≈ 300 000 km/s.',bars:[{lab:'masofa',y:76,segs:[{w:1,txt:'?',c:'q'}]}],br:[{b:0,lab:'150 000 000 km',up:true}],note:'Quyosh nuri Yerga necha sekundda yetib keladi?'}],
 html:"<p>☀️ Yorug'lik — olamdagi eng tez narsa: 1 sekundda taxminan <b>300 000 km</b> yo'l bosadi (Yer atrofini 7 martadan ko'p aylanadi!). Quyoshdan Yergacha nur necha sekundda keladi? <i>t = S : v</i></p>",
 btns:bmPick(["50 s","500 s","5000 s"],1,{t:'t = S : v',bars:[{lab:'masofa',y:76,segs:[{w:1,txt:'500 s',c:'g'}]}],br:[{b:0,lab:'150 000 000 km',up:true}],calc:['150 000 000 : 300 000 = <b>500</b> s','500 s = 8 min 20 s']},["Nollarni sanang: 1 500 : 3 = 500.","","Nollarni sanang: 150 000 000 : 300 000 = 1500 : 3."]),
 after:"<p>Demak, biz Quyoshni <b>8 minut 20 sekund oldingi</b> holatida ko'ramiz! Tezlik, vaqt, masofa — butun koinotda bir xil formula.</p>",
 tn:"Nollarni «qisqartirish»ni ko'rsating: 150 000 000 : 300 000 = 1500 : 3."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'S = v · t',bars:[{lab:'t = 4',y:76,segs:w6u(4,'v','a',1)}],br:[{b:0,lab:'S (masofa)',up:true}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Tezlik</b> — 1 birlik vaqtdagi yo'l (km/soat, m/s).</li><li><b>S = v · t</b>, <b>v = S : t</b>, <b>t = S : v</b>.</li><li>Tezliklarni solishtirishdan oldin <b>birliklarni tenglang</b> (1 min = 60 s).</li><li>Qarama-qarshi tomonga yoki bir-biriga qarab — <b>tezliklar qo'shiladi</b>.</li><li>Uchrashish vaqti = masofa : (v₁ + v₂).</li><li>Poyezd ko'prik/tunneldan o'tsa: yo'l = <b>ko'prik + poyezd</b> uzunligi.</li></ul></div>",
 tn:"Keyingi darsni S–v–t uchburchagida bitta harfni yopish o'yini bilan boshlang."}
];
var PROBS=[
{t:"Velosipedchi 3 soatda 54 km yurdi. Shu tezlikda 5 soatda necha km yuradi?",o:["90","270","72","108"],k:0,s:"18 · 5 = 90."},
{t:"Piyoda 2 soatda 10 km yurdi. 3 soatda necha km yuradi?",o:["15","30","13","5"],k:0,s:"5 · 3 = 15."},
{t:"Mashina 60 km/soat tezlikda 4 soat yurdi. Necha km yurdi?",o:["240","64","15","56"],k:0,s:"60 · 4 = 240."},
{t:"Poyezd 360 km ni 90 km/soat tezlikda yurdi. Necha soat yurdi?",o:["4","270","450","5"],k:0,s:"360 : 90 = 4."},
{t:"Bo'ri 120 m ni 8 sekundda bosdi. 360 m ni necha sekundda bosadi?",o:["24","32","20","30"],k:0,s:"3 marta: 8 · 3 = 24."},
{t:"Toshbaqa 4 m ni 2 daqiqada o'tadi. 20 m ni necha daqiqada o'tadi?",o:["10","40","5","22"],k:0,s:"5 marta: 2 · 5 = 10."},
{t:"Akmal 140 m ni 70 s da, Sardor 360 m ni 2 min da, Jasur 200 m ni 40 s da yugurdi. Kim eng tez?",o:["Jasur","Sardor","Akmal","Sardor va Jasur teng"],k:0,s:"2, 3, 5 m/s."},
{t:"Ot 3 minutda 1800 m, mashina 1 minutda 1200 m yurdi. 1 minutda mashina otdan necha m ko'p yuradi?",o:["600","1200","0","3000"],k:0,s:"1200 − 600 = 600."},
{t:"Ikki mashina bir joydan qarama-qarshi tomonga 62 va 115 km/soat tezlikda chiqdi. 4 soatdan keyin orasi?",o:["708","212","177","718"],k:0,s:"177 · 4 = 708."},
{t:"Ikki qush qarama-qarshi tomonga 12 va 18 m/s tezlikda uchdi. 5 s dan keyin orasi?",o:["150 m","30 m","60 m","90 m"],k:0,s:"30 · 5 = 150."},
{t:"Shaharlar orasi 300 km. Ikki mashina bir-biriga qarab 60 va 40 km/soat tezlikda chiqdi. Necha soatda uchrashadi?",o:["3","15","5","2"],k:0,s:"300 : 100 = 3."},
{t:"Qishloqlar orasi 24 km. Ikki piyoda bir-biriga qarab 5 va 3 km/soat tezlikda chiqdi. Necha soatda uchrashadi?",o:["3","12","8","6"],k:0,s:"24 : 8 = 3."},
{t:"800 m li poyezd 1200 m li tunneldan 40 s da to'liq o'tdi. Tezligi necha m/s?",o:["50","30","20","10"],k:0,s:"2000 : 40 = 50."},
{t:"150 m li poyezd 10 m/s tezlikda 250 m li ko'prikdan to'liq o'tdi. Necha sekund ketdi?",o:["40","25","15","10"],k:0,s:"400 : 10 = 40."},
{t:"Umar tepalikka 2 km/soat tezlikda chiqib, 4 km/soat tezlikda tushdi. Hammasi 9 soat. Yo'l necha km?",o:["12","18","6","3"],k:0,s:"Chiqish 2 marta sekin → 6 soat chiqdi, 3 soat tushdi: 2 · 6 = 12."},
{t:"Ikki shahar orasi 420 km. Mashina 70 km/soat tezlikda yurib, 2 soat dam oldi. Butun yo'lga necha soat ketdi?",o:["8","6","7","10"],k:0,s:"420 : 70 = 6; 6 + 2 = 8."},
{t:"Mashina 80 km/soat tezlikda 3 soat, keyin 60 km/soat tezlikda 2 soat yurdi. Jami necha km?",o:["360","280","700","140"],k:0,s:"240 + 120 = 360."},
{t:"Ikki piyoda bir joydan bir tomonga 6 va 4 km/soat tezlikda chiqdi. 3 soatdan keyin orasi necha km?",o:["6","30","2","18"],k:0,s:"Har soatda 2 km; 2 · 3 = 6."},
{t:"Ikki mashina bir-biriga qarab chiqdi: 50 va 70 km/soat. 2 soatdan keyin ular orasi 60 km qoldi. Dastlab orasi necha km edi?",o:["300","240","180","360"],k:0,s:"120 · 2 = 240; 240 + 60 = 300."},
{t:"Quyoshgacha ≈ 150 000 000 km, yorug'lik ≈ 300 000 km/s. Quyosh nuri Yerga necha sekundda keladi?",o:["500","50","5000","5"],k:0,s:"150 000 000 : 300 000 = 500."}
];
function PRACT_STAGE(){bmDraw({t:'S = v · t',bars:[{lab:'vaqt',y:76,segs:w6u(4,'v','a',1)}],br:[{b:0,lab:'masofa',up:true}]})}
var PREP_DATA={teach:["Tezlik — 1 birlik vaqtdagi yo'l; S = v · t va undan v, t.","«Necha marta» usuli (tezlik bir xil bo'lganda).","Tezliklarni solishtirish (birliklarni tenglab).","Qarama-qarshi va bir-biriga qarab harakat; poyezd va tunnel."],
 mist:["Tezlik va vaqtni qo'shadi.","Minut va sekundni tenglamasdan solishtiradi.","Qarama-qarshi harakatda tezliklarni ayiradi.","Poyezd uzunligini hisobga olmaydi."],
 need:["S–v–t uchburchagi chizilgan plakat.","O'lchov lentasi, sekundomer (sinfda yurish tajribasi uchun)."],
 board:["<span class='w2'>54 : 3 = 18 km/soat; 18 · 5 = 90 km</span>.","<span class='w2'>S = v · t,  v = S : t,  t = S : v</span>.","<span class='w2'>(62 + 115) · 4 = 708</span>.","<span class='w2'>300 : (60 + 40) = 3</span>.","<span class='w2'>(1200 + 800) : 40 = 50 m/s</span>."]};
