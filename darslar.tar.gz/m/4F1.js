var CODE='4F1',TITLE='4-sinf · Kasr: tushuncha va taqqoslash';

function pad(n){return n<10?'0'+n:''+n}
// ===================== SAHNA (kasrlar) =====================
var NS='http://www.w3.org/2000/svg',sv=document.getElementById('sv'),strip=document.getElementById('strip');
function E(t,a,p){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
function T(p,x,y,txt,a){a=a||{};var m_=/^(\d{1,3})\/(\d{1,3})$/.exec(String(txt));if(m_&&!a.nofr){var fs=+(a['font-size']||12)*.8,g_=E('g',{},p),aa=Object.assign({},a,{'font-size':fs});delete aa.nofr;var n_=E('text',Object.assign({x:x,y:y-fs*.45,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);n_.textContent=m_[1];var d_=E('text',Object.assign({x:x,y:y+fs*.75,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);d_.textContent=m_[2];var w_=Math.max(m_[1].length,m_[2].length)*fs*.62+4,ax=(a['text-anchor']==='start')?x+w_/2-2:((a['text-anchor']==='end')?x-w_/2+2:x);n_.setAttribute('x',ax);d_.setAttribute('x',ax);E('line',{x1:ax-w_/2,y1:y-fs*.18,x2:ax+w_/2,y2:y-fs*.18,stroke:aa.fill||'#3a4a5a','stroke-width':Math.max(1.2,fs/9)},g_);g_.textContent;return g_}var e=E('text',Object.assign({x:x,y:y,'text-anchor':'middle','font-size':12,fill:'#3a4a5a'},a),p);e.textContent=txt;return e}
function tween(ms,f){return new Promise(function(res){var t0=performance.now();function s(n){var t=Math.min(1,(n-t0)/ms);f(t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2);if(t<1)requestAnimationFrame(s);else res()}requestAnimationFrame(s)})}
function wait(ms){return new Promise(function(r){setTimeout(r,ms)})}
function rnd(s){return function(){s=(s*16807)%2147483647;return (s-1)/2147483646}}
var C={on:'#f0a040',on2:'#e07a2f',off:'#fff7ea',line:'#a86a2a',bad:'#e05555',ok:'#1e8e5a',blue:'#1f6fb2'};
var S={tok:0,n:8,k:0,shaded:[]};
var DAN=['','birdan','ikkidan','uchdan','to‘rtdan','beshdan','oltidan','yettidan','sakkizdan','to‘qqizdan','o‘ndan','o‘n birdan','o‘n ikkidan'];
var SON=['nol','bir','ikki','uch','to‘rt','besh','olti','yetti','sakkiz','to‘qqiz','o‘n','o‘n bir','o‘n ikki'];
function read(k,n){if(n===2&&k===1)return 'ikkidan bir (yarim)';if(n===4&&k===1)return 'to‘rtdan bir (chorak)';return DAN[n]+' '+SON[k]}
function clear(bgc){S.tok++;sv.innerHTML='';E('rect',{x:2,y:2,width:356,height:170,rx:14,fill:bgc||'#fffaf2',stroke:'#f0e4cc'},sv);S.g=E('g',{},sv);S.fx=E('g',{},sv)}
function frac(k,n,col){return '<span class="fr" style="color:'+(col||'inherit')+'"><b>'+k+'</b><i></i><b>'+n+'</b></span>'}
function stripFrac(k,n,extra){strip.innerHTML=frac(k,n)+'<div class="lab"><div><b class="sc">'+k+'</b> — surat: nechta bo‘lak olindi</div><div><b class="mc">'+n+'</b> — maxraj: butun nechta <u>teng</u> bo‘lakka bo‘lindi</div><div class="rd">«'+read(k,n)+'»'+(extra||'')+'</div></div>'}
function stripText(h){strip.innerHTML='<div class="lab" style="text-align:center;width:100%">'+h+'</div>'}
// --- Shokolad (to'rtburchak) ---
function bar(p,x,y,w,h,n,k,opt){opt=opt||{};var g=E('g',{},p),cells=[];for(var i=0;i<n;i++){var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:i<k?(opt.col||C.on):C.off,stroke:C.line,'stroke-width':1.5},g);c._i=i;cells.push(c)}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.5,rx:3},g);g.cells=cells;return g}
function setBar(n,k,tap){clear();S.n=n;S.k=k;var B=bar(S.g,20,44,320,70,n,k);S.cells=B.cells;
 T(S.g,180,30,'1 butun shokolad',{'font-size':13,'font-weight':700,fill:C.line});
 if(tap){B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){var on=c.getAttribute('fill')!==C.off;c.setAttribute('fill',on?C.off:C.on);S.k+=on?-1:1;stripFrac(S.k,S.n);if(S.onTap)S.onTap()})})}
 stripFrac(k,n)}
// --- Non (doira) ---
function sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1);var L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#8a5a24','stroke-width':2},p)}
function non(p,cx,cy,r,cuts,shade){var g=E('g',{},p);E('circle',{cx:cx,cy:cy,r:r+4,fill:'#c98b45'},g);
 var a=-Math.PI/2;for(var i=0;i<cuts.length;i++){var b=a+cuts[i]*2*Math.PI;sector(g,cx,cy,r,a,b,shade&&shade.indexOf(i)>=0?C.on:'#f3d29b');a=b}
 for(var j=0;j<6;j++){var an=j*1.05+.4;E('circle',{cx:cx+r*.45*Math.cos(an),cy:cy+r*.45*Math.sin(an),r:1.6,fill:'#8a5a24',opacity:.5},g)}return g}
function setNon(state){clear();
 if(state==='whole'){non(S.g,180,90,64,[1],[]);T(S.g,180,170,'1 ta non — 4 do‘st',{'font-size':12});stripText('Nonni 4 do‘stga <b>teng</b> bo‘lish kerak');return}
 non(S.g,95,88,60,[.4,.25,.2,.15],[3]);T(S.g,95,166,'A: bo‘laklar har xil',{'font-size':12,fill:C.bad,'font-weight':700});
 non(S.g,265,88,60,[.25,.25,.25,.25],[0]);T(S.g,265,166,'B: 4 ta teng bo‘lak',{'font-size':12,fill:C.ok,'font-weight':700});
 stripFrac(1,4,' — B dagi bitta bo‘lak')}
// --- Kasrlar devori ---
var WALL=[1,2,3,4,6,8];
function setWall(rows,hl){clear();var x=58,w=290,h=21;rows=rows==null?WALL.length:rows;
 for(var r=0;r<rows;r++){var n=WALL[r],y=10+r*26;T(S.g,30,y+15,n===1?'1':'1/'+n,{'font-size':13,'font-weight':700,fill:C.line});
  for(var i=0;i<n;i++){var on=hl&&hl.indexOf(n)>=0&&i===0;E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?C.on:(n===1?'#ffe2b8':'#fff3df'),stroke:C.line,'stroke-width':1.3,rx:2},S.g)}}
 if(hl&&hl.length)stripText('Bitta bo‘lakni solishtiring: '+hl.map(function(n){return frac(1,n)}).join(' &nbsp;va&nbsp; ')+'<br><small>Maxraj qancha katta bo‘lsa, bo‘lak shuncha kichik</small>');else stripText('Har bir qator — bitta butun shokolad, har xil bo‘lingan')}
// --- Son o'qi ---
function setLine(pos,maxU){clear();maxU=maxU||2;var x0=30,u=150,y=110;S.lx=function(v){return x0+v*u};
 E('line',{x1:x0-8,y1:y,x2:x0+maxU*u+10,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var q=0;q<=maxU*4;q++){var X=x0+q*u/4,big=q%4===0;E('line',{x1:X,y1:y-(big?12:8),x2:X,y2:y+(big?12:8),stroke:'#33475b','stroke-width':big?2.5:1.5},S.g);
  T(S.g,X,y+(big?30:26),big?String(q/4):(q+'/4'),{'font-size':big?15:11,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 E('rect',{x:x0,y:y-4,width:u,height:8,fill:'#f0a040',opacity:.25},S.g);T(S.g,x0+u/2,y+52,'1 butun = 4 ta teng bo‘lak',{'font-size':11,fill:C.line});
 S.ball=E('circle',{cx:S.lx(pos/4),cy:y-16,r:9,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.pos=pos;lineStrip()}
function lineStrip(){var p=S.pos;stripFrac(p,4,p===4?' = 1 butun':(p>4?' — 1 dan katta':''))}
async function jump(){var tok=S.tok,a=S.pos,b=a+1,y=94;if(b>8)return;await tween(450,function(t){S.ball.setAttribute('cx',S.lx((a+t)/4));S.ball.setAttribute('cy',y-30*Math.sin(Math.PI*t))});if(tok!==S.tok)return;S.pos=b;
 var X=S.lx(b/4);E('path',{d:'M'+S.lx(a/4)+' 96 Q'+(S.lx(a/4)+X)/2+' 66 '+X+' 96',fill:'none',stroke:C.blue,'stroke-width':1.5,'stroke-dasharray':'3 3'},S.g);lineStrip()}
// --- Yarim bilan solishtirish ---
function setHalf(k,n){clear();var B=bar(S.g,20,50,320,60,n,k);E('line',{x1:180,y1:36,x2:180,y2:124,stroke:C.blue,'stroke-width':3,'stroke-dasharray':'6 4'},S.g);T(S.g,180,30,'yarim (1/2)',{'font-size':13,'font-weight':700,fill:C.blue});
 var cmp=k*2>n?'yarimdan <b>katta</b>':(k*2===n?'aynan <b>yarim</b>':'yarimdan <b>kichik</b>');T(S.g,180,150,k*2>n?'chiziqdan o‘tdi':(k*2===n?'chiziqqa teng':'chiziqqa yetmadi'),{'font-size':13,'font-weight':700,fill:k*2>n?C.ok:(k*2===n?C.blue:C.bad)});
 strip.innerHTML=frac(k,n)+'<div class="lab"><div>'+n+' ning yarmi — <b>'+(n/2)+'</b>. Surat '+k+' — '+cmp+'.</div><div class="rd">Qoida: surat maxrajning yarmidan ko‘p bo‘lsa, kasr 1/2 dan katta.</div></div>'}
// --- Yetishmagan bo'lak ---
function setGap(show,list){clear();list=list||[[5,7],[6,8],[7,9]];var x=60,w=230,h=30;
 list.forEach(function(f,r){var y=18+r*50;T(S.g,32,y+20,f[0]+'/'+f[1],{'font-size':14,'font-weight':800,fill:C.line});var B=bar(S.g,x,y,w,h,f[1],f[0]);
  if(show){for(var i=f[0];i<f[1];i++)B.cells[i].setAttribute('fill','#ffd0d0');T(S.g,x+w+34,y+20,(f[1]-f[0])+'/'+f[1],{'font-size':13,'font-weight':800,fill:C.bad})}});
 if(show){T(S.g,x+w+34,12,'yetishmaydi',{'font-size':10,fill:C.bad});stripText('Har biriga <b>2 ta bo‘lak</b> yetishmaydi. Lekin 1/9 bo‘lak eng kichik!<br>Demak, <b>7/9</b> butunga eng yaqin — eng katta: <b>7/9 > 6/8 > 5/7</b>')}
 else stripText('Qaysi biri eng katta? Maxrajlar ham, suratlar ham har xil…')}
// --- Misr ---
function setEgypt(split){clear('#f6ead0');bar(S.g,20,30,320,50,4,3);T(S.g,180,22,'3/4',{'font-size':14,'font-weight':800,fill:C.line});
 if(split){var g=S.g;E('rect',{x:20,y:100,width:160,height:50,fill:C.on,stroke:C.line,'stroke-width':2},g);E('rect',{x:180,y:100,width:80,height:50,fill:C.on2,stroke:C.line,'stroke-width':2},g);E('rect',{x:20,y:100,width:320,height:50,fill:'none',stroke:C.line,'stroke-width':2.5},g);
  T(g,100,131,'1/2',{'font-size':16,'font-weight':800,fill:'#fff'});T(g,220,131,'1/4',{'font-size':16,'font-weight':800,fill:'#fff'});
  stripText('Misrliklar <b>3/4</b> ni shunday yozgan: <b>1/2 + 1/4</b><br><small>Ular faqat surati 1 bo‘lgan kasrlardan foydalangan (2/3 dan tashqari)</small>')}
 else stripText('4000 yil oldin Misrda 3/4 qanday yozilgan?')}

// ===================== QADAMLAR =====================
var PRAISE=[["ok1","Barakalla!"],["ok2","Ha, aynan shunday!"],["ok3","Zo'r, topdingiz!"],["ok4","Juda yaxshi!"]];
var STEPS=[
{h:"Nonni teng bo'lamiz",sum:"Kasr — butunning TENG bo'laklari. Teng bo'lmasa, kasr bo'lmaydi.",a:"m01",
 start:function(){setNon('whole')},fin:function(){setNon('two')},
 html:"<p>Dasturxonda <b>1 ta non</b> bor. Uni 4 do'st bo'lishmoqchi. Har biriga <b>baravar</b> tegishi kerak — hech kim xafa bo'lmasin. Tugmani bosing.</p>",
 btns:[["🔪 4 ga bo'lish",function(c,done,b){b.disabled=true;setNon('two');done()}]],
 after:"<p>A nonda ham 4 bo'lak, B nonda ham 4 bo'lak. Lekin A da bo'laklar <b>har xil</b> — kimgadir katta, kimgadir kichik tegadi. B da hammasi <b>teng</b>.</p><p>B dagi bitta bo'lak — butunning <b>to'rtdan biri</b>, yoziladi: <b>1/4</b>. Butun <b>teng</b> bo'laklarga bo'linganda hosil bo'lgan qism <b>kasr</b> deyiladi.</p>",
 q:{t:"Non 3 bo'lakka bo'lindi, lekin bo'laklar har xil. Har bir bo'lak 1/3 bo'ladimi?",opts:["Ha, 3 ta bo'lak bor","Yo'q, bo'laklar teng emas","Faqat eng kattasi","Faqat eng kichigi"],ok:1,why:"Kasr uchun bo'laklar teng bo'lishi shart.",hint:"A nonni eslang: 4 ta bo'lak bor edi, lekin ular 1/4 bo'ldimi?",full:"1/3 — bu butun 3 ta TENG bo'lakka bo'lingandagi bitta bo'lak. Bo'laklar har xil bo'lsa, ularning birortasi ham 1/3 emas."},
 tn:"Dunyo tadqiqotlari (AQSh Ta'lim instituti tavsiyasi) kasrni «teng bo'lishish»dan boshlashni maslahat beradi: non, olma, shokolad. Bolalarga qog'oz doira bering — teng va teng emas bo'lib ko'rsin."},
{h:"Kasr qanday yoziladi",sum:"3/8: maxraj 8 — nechta teng bo'lak, surat 3 — nechtasi olindi. «Sakkizdan uch».",a:"m02",
 start:function(){setBar(8,0,true)},fin:function(){setBar(8,3)},
 html:"<p>Shokolad <b>8 ta teng</b> bo'lakka bo'lingan. Uning <b>3/8</b> qismini bo'yang — bo'laklarni bosing. Pastdagi kasr siz bosgan sari o'zgaradi.</p>",
 act:function(c,done){var h=c.querySelector('.hint');h.textContent='Rasmdagi bo‘laklarni bosing. Kerak: 3 ta.';S.onTap=function(){if(S.k===3){S.onTap=null;h.textContent='';done()}else h.textContent='Bo‘yaldi: '+S.k+' ta. Kerak: 3 ta.'}},
 after:"<p>Chiziq <b>ostidagi</b> son — <b>maxraj</b>: butun nechta teng bo'lakka bo'lingan (8). Chiziq <b>ustidagi</b> son — <b>surat</b>: nechta bo'lak olingan (3). O'qilishi: <b>«sakkizdan uch»</b> — avval maxraj, keyin surat.</p>",
 q:{t:"Shokolad 6 ta teng bo'lakka bo'lingan, 5 tasi yeyildi. Yeyilgan qism qaysi kasr?",opts:["6/5","5/6","1/6","5/11"],ok:1,why:"Maxraj — 6 (nechta bo'lak), surat — 5 (nechtasi yeyildi).",hint:"Pastda nima turadi — hamma bo'laklar sonimi yoki olinganlarmi?",full:"Butun 6 ta teng bo'lakka bo'lingan — maxraj 6, pastga yoziladi. 5 tasi yeyildi — surat 5, tepaga. Javob: 5/6, «oltidan besh»."},
 tn:"Doskada: shokolad chizing, ostiga «maxraj — hammasi», ustiga «surat — olingani» deb yozing. Bolalar 2–3 ta kasrni o'zi bo'yab, o'qib bersin."},
{h:"Bo'lak ko'p — bo'lak kichik",sum:"Maxraj qancha katta bo'lsa, bitta bo'lak shuncha kichik: 1/3 > 1/5.",a:"m03",
 start:function(){setBar(3,1)},fin:function(){setBar(6,1)},
 html:"<p>Shokolad bitta, faqat uni har xil bo'lamiz. Maxrajni o'zgartiring va <b>bitta bo'lakning</b> kattaligini kuzating.</p>",
 btns:[["− bo'lak",function(c,done){if(S.n>2){setBar(S.n-1,1);mvK(done)}}],["+ bo'lak",function(c,done){if(S.n<12){setBar(S.n+1,1);mvK(done)}}]],g2:1,
 after:"<p>Ko'rdingizmi: shokolad <b>ko'p</b> bo'lakka bo'linsa, har bir bo'lak <b>kichrayadi</b>. Shuning uchun <b>1/5</b> bo'lak <b>1/3</b> bo'lakdan kichik — garchi 5 soni 3 dan katta bo'lsa ham!</p><p>Bu eng ko'p uchraydigan xato: «5 katta, demak 1/5 katta». Yo'q — 5 kishiga bo'linsa, har biriga kamroq tegadi.</p>",
 q:{t:"Qaysi bo'lak katta: 1/3 yoki 1/5?",opts:["1/5","1/3","Ikkalasi teng","1/5, chunki 5 katta"],ok:1,why:"3 ga bo'linganda bo'laklar kattaroq bo'ladi.",hint:"Bitta tortni 3 kishi bo'lishsa ko'p tegadimi, yoki 5 kishi bo'lishsa?",full:"1/3 — tort 3 kishiga bo'lingan, 1/5 — 5 kishiga. Kishi ko'p bo'lsa, har biriga kam tegadi. Demak, 1/3 > 1/5."},
 tn:"Butun sonlardagi «katta son — katta» odati kasrda xato beradi (olimlar buni «butun son tuzog'i» deydi). Bitta qog'oz tasmani 2, 4, 8 ga buklatib, bo'laklarni solishtiring."},
{h:"Kasrlar devori",sum:"Devorda ko'rinadi: 1/2 > 1/3 > 1/4 > 1/6 > 1/8. Suratlar teng bo'lsa — maxraji kichigi katta.",a:"m04",
 start:function(){setWall(0)},fin:function(){setWall(null,[3,8])},
 html:"<p>Har bir qator — bir xil shokolad, faqat har xil bo'lingan. Devorni quring va bo'laklarni solishtiring.</p>",
 btns:[["🧱 Devorni qurish",function(c,done,b){b.disabled=true;var r=0;(function nx(){r++;setWall(r);if(r<WALL.length)setTimeout(nx,420);else{setTimeout(function(){setWall(null,[3,8]);done()},500)}})()}]],
 after:"<p>1/3 bo'lak 1/8 bo'lakdan qariyb uch barobar katta. Endi <b>3/4</b> va <b>3/8</b> ni solishtiraylik: ikkalasida 3 tadan bo'lak, lekin to'rtdan bir bo'lak katta. Demak, <b>3/4 > 3/8</b>.</p><p><b>Qoida:</b> suratlar teng bo'lsa — maxraji <b>kichik</b> kasr katta.</p>",
 q:{t:"Qaysi kasr eng kichik?",opts:["1/2","1/4","1/8","1/6"],ok:2,why:"8 ta bo'lakka bo'lingani eng mayda.",hint:"Devorga qarang: qaysi qatordagi bo'lak eng kalta?",full:"Devorda pastki qator — 8 ga bo'lingan, bo'laklari eng kichik. Suratlar teng (hammasi 1), maxraji eng katta — 1/8 eng kichik."},
 tn:"Bolalar qog'ozdan o'z «kasr devori»ni yasab, daftarga yopishtirsin — butun yil davomida tayanch bo'ladi."},
{h:"Maxrajlar teng bo'lsa",sum:"Bo'laklar bir xil kattalikda — qaysi birida ko'p bo'lak bo'lsa, o'sha katta: 5/8 > 3/8.",a:"m05",
 start:function(){setBar(8,3)},fin:function(){setBar(8,5)},
 html:"<p>Shokolad 8 ga bo'lingan. Avval 3/8 ni, keyin 5/8 ni ko'ring.</p>",
 btns:[["3/8",function(c,done){setBar(8,3);mvK(done,2)}],["5/8",function(c,done){setBar(8,5);mvK(done,2)}]],g2:1,
 after:"<p>Bo'laklar <b>bir xil</b> kattalikda (hammasi sakkizdan bir). Demak, qaysi kasrda bo'lak <b>ko'p</b> bo'lsa — o'sha katta: <b>5/8 > 3/8</b>.</p><p><b>Qoida:</b> maxrajlar teng bo'lsa — surati <b>katta</b> kasr katta.</p>",
 q:{t:"Qaysi kasr katta: 4/9 yoki 7/9?",opts:["4/9","7/9","Teng","11/9"],ok:1,why:"Bo'laklar bir xil, 7 ta bo'lak 4 tadan ko'p.",hint:"Ikkalasida ham to'qqizdan bir bo'laklar. Qayerda ko'proq bo'lak bor?",full:"Maxraj ikkalasida 9 — bo'laklar bir xil. 7/9 da 7 ta, 4/9 da 4 ta bo'lak. 7/9 katta."},
 tn:"Ikki qoidani yonma-yon yozdiring: «maxraj teng → surat katta — katta», «surat teng → maxraj kichik — katta». Bolalar ko'pincha ikkinchisini teskari qiladi."},
{h:"Kasr — bu son, uning ham joyi bor",sum:"Son o'qida 0 bilan 1 orasi 4 ta teng bo'lak: 1/4, 2/4, 3/4, 4/4 = 1. Kasr 1 dan katta ham bo'ladi: 5/4.",a:"m06",
 start:function(){setLine(0)},fin:function(){setLine(5)},
 html:"<p>Kasr — bu ham <b>son</b>. Son o'qida 0 bilan 1 orasini <b>4 ta teng</b> bo'lakka bo'ldik. Sakrang: har sakrash — <b>1/4</b>.</p>",
 btns:[["🦘 Sakra (+1/4)",function(c,done){jump().then(function(){if(S.pos>=5)done()})}]],
 act:function(c){c.querySelector('.hint').textContent='1 dan o‘tguncha sakrang.'},
 after:"<p>To'rtta sakrashda <b>4/4</b> ga keldik — bu aynan <b>1 butun</b>! Yana sakrasak — <b>5/4</b>, u 1 dan katta. Surati maxrajidan katta kasr <b>1 dan katta</b> bo'ladi.</p>",
 q:{t:"7/4 son o'qida qayerda?",opts:["0 dan oldin","1 dan oldin","Aynan 1 da","1 dan keyin"],ok:3,why:"4/4 = 1, 7/4 undan 3 sakrash keyin.",hint:"4/4 qayerda edi? 7/4 unga nisbatan oldindami yoki keyin?",full:"4/4 = 1. 7/4 — bu 4/4 dan yana 3 ta chorak keyin: 1 dan keyin, 2 ga yaqin. Surat (7) maxrajdan (4) katta — kasr 1 dan katta."},
 tn:"Kasrni faqat «pirog bo'lagi» deb o'rgatish yetarli emas — xalqaro tavsiyalar son o'qini erta kiritishni maslahat beradi. Doskada 0–2 o'qini choraklarga bo'ling, bolalar sakrab ko'rsatsin."},
{h:"Yarim bilan solishtirish",sum:"Surat maxrajning yarmidan ko'p bo'lsa — kasr 1/2 dan katta: 5/8 > 1/2 > 3/8.",a:"m07",
 start:function(){setHalf(3,8)},fin:function(){setHalf(5,8)},
 html:"<p>Ko'k chiziq — shokoladning <b>yarmi</b>. Kasrlarni bosib, qaysi biri chiziqdan o'tishini ko'ring.</p>",
 btns:[["3/8",function(c,done){setHalf(3,8);mvK(done,3)}],["4/8",function(c,done){setHalf(4,8);mvK(done,3)}],["5/8",function(c,done){setHalf(5,8);mvK(done,3)}],["4/7",function(c,done){setHalf(4,7);mvK(done,3)}]],g2:1,
 after:"<p>Tez usul: <b>maxrajning yarmini</b> toping va suratni unga solishtiring. 8 ning yarmi 4: surat 5 — ko'p, demak <b>5/8 > 1/2</b>. 7 ning yarmi 3,5: surat 4 — ko'p, demak <b>4/7 > 1/2</b>.</p>",
 q:{t:"Qaysi kasr 1/2 dan katta?",opts:["3/7","4/9","2/5","5/8"],ok:3,why:"8 ning yarmi 4, surat 5 — ko'p.",hint:"Har birida maxrajning yarmini toping. Qaysi surat yarmidan oshadi?",full:"3/7: yarmi 3,5, surat 3 — kam. 4/9: yarmi 4,5, surat 4 — kam. 2/5: yarmi 2,5 — kam. 5/8: yarmi 4, surat 5 — ko'p. Javob: 5/8."},
 tn:"«Tayanch kasr» usuli (1/2 va 1 bilan solishtirish) — Illustrative Mathematics va boshqa xalqaro dasturlarda asosiy usul. Testlarda vaqtni ancha tejaydi."},
{h:"Tuzoq: hammasi har xil bo'lsa",sum:"5/7, 6/8, 7/9 — har biriga 2 bo'lak yetishmaydi; eng kichik yetishmovchilik 2/9 → 7/9 eng katta.",a:"m08",
 start:function(){setGap(false)},fin:function(){setGap(true)},
 html:"<p>5/7, 6/8 va 7/9 — suratlar ham, maxrajlar ham har xil. Qoidalarning hech biri to'g'ri kelmaydi! Lekin bir ayyorlik bor: <b>butun bo'lishiga qancha yetishmaydi?</b> Tugmani bosing.</p>",
 btns:[["🔍 Yetishmaganini ko'rsat",function(c,done,b){b.disabled=true;setGap(true);done()}]],
 after:"<p>Uchalasiga ham <b>2 ta bo'lak</b> yetishmaydi. Lekin bo'laklar har xil: 1/9 eng kichik, 1/7 eng katta. Kimga <b>eng kam</b> yetishmasa, o'sha butunga eng yaqin — <b>eng katta</b>: <b>7/9 > 6/8 > 5/7</b>.</p>",
 q:{t:"Qaysi biri katta: 3/4 yoki 4/5?",opts:["3/4","4/5","Teng","3/4, chunki 4 kichik"],ok:1,why:"3/4 ga 1/4 yetishmaydi, 4/5 ga esa 1/5 — kamroq.",hint:"Har biriga butun bo'lishi uchun qancha yetishmaydi? Qaysi yetishmovchilik kichik?",full:"3/4 ga 1/4 yetishmaydi, 4/5 ga 1/5 yetishmaydi. 1/5 < 1/4 — demak 4/5 butunga yaqinroq, u katta."},
 tn:"Bu usul darslikda yo'q, lekin olimpiada va saralash testlarida tez-tez keladi. Bolalar «yetishmagan bo'lak» rasmini chizib ko'rsin."},
{h:"Bilasizmi? Kasrlar tarixi",sum:"Misrliklar 3/4 ni 1/2 + 1/4 deb yozgan. «Kasr» arabcha «sindirish». Kasr chizig'ini arab olimlari kiritgan.",a:"m09",
 start:function(){setEgypt(false)},fin:function(){setEgypt(true)},
 html:"<p>🏺 Qadimgi Misrda, <b>4000 yil oldin</b>, kasrlarni faqat surati 1 bo'lganlar orqali yozishgan. 3/4 ni qanday yozishgan ekan? Tugmani bosing.</p>",
 btns:[["🏺 Misrcha",function(c,done){setEgypt(true);done()}]],
 after:"<p><b>3/4 = 1/2 + 1/4</b> — ikkalasining surati 1!</p><p>📜 «Kasr» so'zi arabcha <b>«sindirish»</b> degani — butunni sindirib, bo'lakka ajratamiz. Bugungi kasr chizig'ini (surat — tepada, maxraj — pastda) <b>arab olimlari</b> kiritgan. Vatandoshimiz <b>al-Xorazmiy</b> ham o'z arifmetika kitobida kasrlar bilan hisoblashni tushuntirgan.</p>",
 tn:"Bolalar misrcha yozishni sinab ko'rsin: 3/4 = 1/2 + 1/4, 5/6 = 1/2 + 1/3. Bu ham kasrlarni tushunishni mustahkamlaydi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){setBar(8,3)},fin:function(){setBar(8,3)},
 html:"<div class='memo'><ul><li><b>Kasr</b> — butunning <b>teng</b> bo'laklaridan bir nechtasi.</li><li><b>3/8</b>: maxraj 8 — butun nechta teng bo'lakka bo'lingan, surat 3 — nechtasi olingan. «Sakkizdan uch».</li><li>Maxraj katta → bo'lak kichik: <b>1/3 > 1/5</b>.</li><li>Maxrajlar teng → surati katta kasr katta: <b>5/8 > 3/8</b>.</li><li>Suratlar teng → maxraji kichik kasr katta: <b>3/4 > 3/8</b>.</li><li>Yarim bilan: surat maxrajning yarmidan ko'p bo'lsa → <b>> 1/2</b>.</li><li>Hammasi har xil → yetishmagan bo'lakni solishtiring: <b>7/9 > 6/8 > 5/7</b>.</li><li>4/4 = 1. Surat maxrajdan katta bo'lsa → kasr <b>1 dan katta</b>.</li></ul></div>",
 tn:"Keyingi darsni «Qaysi biri katta: 2/3 yoki 3/4?» savoli bilan boshlang (yetishmagan bo'lak usuli)."}
];
function mvK(done,need){var c=STEPS[cur];c._m=(c._m||0)+1;if(c._m>=(need||3))done()}
var PROBS=[
{t:"Butun 9 ta teng bo'lakka bo'lingan, 4 tasi bo'yalgan. Bo'yalgan qism qaysi kasr?",o:["4/9","9/4","5/9","4/13"],k:0,s:"Maxraj — 9 (hammasi), surat — 4 (bo'yalgani): 4/9."},
{t:"Kasrning maxraji 12, surati maxrajidan 5 ta kichik. Bu qaysi kasr?",o:["7/12","12/7","5/12","12/17"],k:0,s:"Surat: 12 − 5 = 7. Kasr: 7/12."},
{t:"Qaysi kasr eng katta?",o:["1/3","1/4","1/7","1/9"],k:0,s:"Suratlar teng — maxraji eng kichik kasr eng katta: 1/3."},
{t:"Qaysi kasr eng kichik?",o:["2/11","5/11","8/11","10/11"],k:0,s:"Maxrajlar teng — surati eng kichik kasr eng kichik: 2/11."},
{t:"Qaysi kasr 1/2 dan katta?",o:["5/9","4/9","3/8","2/6"],k:0,s:"9 ning yarmi 4,5. Surat 5 — ko'p. 5/9 > 1/2."},
{t:"Qaysi kasr 1 ga teng?",o:["6/6","1/6","6/1","0/6"],k:0,s:"Surat maxrajga teng — butun olingan: 6/6 = 1."},
{t:"Qaysi biri katta: 5/6 yoki 6/7?",o:["6/7","5/6","Teng","5/6, chunki 6 kichik"],k:0,s:"5/6 ga 1/6 yetishmaydi, 6/7 ga 1/7 — kamroq. 6/7 katta."},
{t:"Pitsa 8 ta teng bo'lakka bo'lindi. Ali 3 ta, Vali 2 ta bo'lak yedi. Pitsaning qancha qismi yeyildi?",o:["5/8","3/8","5/16","2/8"],k:0,s:"Hammasi 3 + 2 = 5 bo'lak, sakkizdan: 5/8."},
{t:"Pitsa 8 ta teng bo'lakka bo'lindi, 3 tasi yeyildi. Qancha qismi qoldi?",o:["5/8","3/8","8/5","1/8"],k:0,s:"8 − 3 = 5 bo'lak qoldi: 5/8."},
{t:"Qaysi yozuv to'g'ri?",o:["3/7 < 3/5","3/7 > 3/5","3/7 = 3/5","3/5 < 1/5"],k:0,s:"Suratlar teng — maxraji kichik katta: 3/5 > 3/7."},
{t:"Son o'qida 0 bilan 1 orasi 5 ta teng bo'lakka bo'lingan. 3-belgida qaysi kasr turadi?",o:["3/5","5/3","1/3","3/10"],k:0,s:"Har bo'lak — 1/5. Uchta bo'lak: 3/5."},
{t:"Qaysi kasr 1 dan katta?",o:["9/7","7/9","7/7","1/9"],k:0,s:"Surat (9) maxrajdan (7) katta — kasr 1 dan katta."},
{t:"Kasrlarni kamayish tartibida joylang: 2/9, 7/9, 4/9.",o:["7/9, 4/9, 2/9","2/9, 4/9, 7/9","4/9, 7/9, 2/9","7/9, 2/9, 4/9"],k:0,s:"Maxrajlar teng — suratlar bo'yicha: 7 > 4 > 2."},
{t:"Sinfda 10 o'quvchi bor, ulardan 3 tasi qizlar. Qizlar sinfning qanday qismi?",o:["3/10","7/10","3/7","10/3"],k:0,s:"Hammasi 10 — maxraj, qizlar 3 — surat: 3/10."},
{t:"Qaysi kasrning maxraji eng katta?",o:["1/12","5/9","7/8","11/11"],k:0,s:"Maxrajlar: 12, 9, 8, 11. Eng kattasi — 12."},
{t:"Qaysi biri katta: 2/3 yoki 3/4?",o:["3/4","2/3","Teng","2/3, chunki 3 kichik"],k:0,s:"2/3 ga 1/3 yetishmaydi, 3/4 ga 1/4 — kamroq. 3/4 katta."},
{t:"Arqon 6 ta teng bo'lakka kesildi. 1 bo'lak arqonning qanday qismi?",o:["1/6","6/1","1/5","6/6"],k:0,s:"6 ta teng bo'lakdan bittasi: 1/6."},
{t:"Qaysi kasrlar teng?",o:["2/4 va 1/2","2/4 va 1/4","1/3 va 1/2","3/6 va 1/3"],k:0,s:"2/4 — to'rtdan ikki bo'lak, bu yarmi: 2/4 = 1/2."},
{t:"7/8 va 7/10 dan qaysi biri katta?",o:["7/8","7/10","Teng","7/10, chunki 10 katta"],k:0,s:"Suratlar teng — maxraji kichik katta: 7/8."},
{t:"Qaysi kasr 1/2 ga teng?",o:["5/10","5/9","4/10","6/10"],k:0,s:"10 ning yarmi 5: 5/10 = 1/2."}
];
(function(){var R=rnd(13);PROBS.forEach(function(p,i){p.a='p'+pad(i+1);var idx=[0,1,2,3];for(var j=3;j>0;j--){var r=Math.floor(R()*(j+1));var t=idx[j];idx[j]=idx[r];idx[r]=t}var o=idx.map(function(x){return p.o[x]});p.k=idx.indexOf(p.k);p.o=o;p._sh=1})})();
var LOCK_SEC=20;
function PRACT_STAGE(){setBar(8,3)}
var PREP='<div class="st prep"><div class="bd" style="padding-top:12px"><h3 style="margin-top:0">Darsga tayyorlanish</h3><ul><li>Kasr — butunning <b>teng</b> bo\'laklari; surat va maxraj.</li><li>Kasrlarni taqqoslash: maxrajlar teng, suratlar teng, 1/2 bilan, yetishmagan bo\'lak.</li><li>Kasr son o\'qida; 4/4 = 1; 1 dan katta kasrlar.</li></ul><h3>Bolalar odatda qayerda adashadi</h3><ul><li>Bo\'laklar teng bo\'lmasa ham kasr deb hisoblaydi.</li><li>«1/5 katta, chunki 5 katta» — butun son odati.</li><li>Surat va maxrajni almashtirib yozadi (5/6 o\'rniga 6/5).</li><li>Kasrni son deb emas, faqat «bo\'lak» deb biladi — son o\'qida joylay olmaydi.</li></ul><h3>Kerakli narsalar</h3><ul><li>Qog\'oz doiralar va tasmalar (buklab bo\'lish uchun).</li><li>Doskada 0–2 son o\'qi.</li></ul><h3>Doskaga nima yoziladi</h3><ol><li>Teng va teng emas bo\'lingan non — «qaysi biri 1/4?»</li><li><span class="w2">3/8</span>: surat — olingan, maxraj — hammasi. «Sakkizdan uch».</li><li>Kasrlar devori: <span class="w2">1/2 > 1/3 > 1/4 > 1/6 > 1/8</span>.</li><li>Ikki qoida: <span class="w2">5/8 > 3/8</span>, <span class="w2">3/4 > 3/8</span>.</li><li>Son o\'qi: <span class="w2">1/4, 2/4, 3/4, 4/4 = 1, 5/4</span>.</li><li>Yarim bilan: <span class="w2">5/8 > 1/2</span>.</li><li>Yetishmagan bo\'lak: <span class="w2">7/9 > 6/8 > 5/7</span>.</li></ol><button class="printbtn" onclick="window.print()">🖨 Chop etish</button><h3>Mashq varaqasi (javoblari bilan)</h3><ol class="plist">'+PROBS.map(function(p){return '<li>'+p.t+'<br><span class="pnum">'+p.o.map(function(o,j){return String.fromCharCode(65+j)+') '+o}).join(' &nbsp; ')+' — <b>'+String.fromCharCode(65+p.k)+'</b></span></li>'}).join('')+'</ol></div></div>';

