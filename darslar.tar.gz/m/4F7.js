// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F7',TITLE='4-sinf · Aralash kasrlarni qo‘shish va ayirish';
// aralash son tasmalari: wh butun, n/d qism; har tasma bw kenglikda
function f7m(x,y,wh,n,d,col,bw,h,col2){bw=bw||52;h=h||26;for(var j=0;j<wh;j++)f4bar(x+j*(bw+5),y,bw,h,d,d,col||C.b);if(n)f4bar(x+wh*(bw+5),y,bw,h,d,n,col2||col||C.b);return x+(wh+(n?1:0))*(bw+5)}
function f7lab(x,y,s,col){f4t(x,y,s,14,col||'#1d2b3a','start')}
var F7P1=[function(){clear();f7lab(12,30,'2 1/5',C.blue);f7m(70,16,2,1,5,C.b);f7lab(12,76,'1 3/5',C.a2);f7m(70,62,1,3,5,C.a);f4c(['Ikki aralash sonni qo‘shamiz'])},
 function(){clear();f7lab(12,30,'butunlar:',C.ok);f7m(110,16,3,0,5,C.ok);f4t(300,32,'2 + 1 = 3',14,C.ok);f7lab(12,80,'kasrlar:',C.a2);f4bar(110,66,52,26,5,[0],C.b);f4bar(110,66,52,26,5,[1,2,3],C.a);f4t(270,82,'1/5 + 3/5 = 4/5',14,C.a2);f4c(['Butunlarni alohida, kasrlarni alohida qo‘shamiz'])},
 function(){clear();f7m(70,40,3,4,5,C.ok,52,30,C.a);f4t(180,120,'2 1/5 + 1 3/5 = 3 4/5',18,C.ok);f4c(['3 + 4/5 = <b>3 4/5</b>'])}];
var F7P2=[function(){clear();f7lab(12,30,'1 3/4',C.blue);f7m(70,16,1,3,4,C.b);f7lab(12,76,'2 2/4',C.a2);f7m(70,62,2,2,4,C.a);f4c(['1 3/4 + 2 2/4 = ?'])},
 function(){clear();f4t(180,30,'butunlar: 1 + 2 = 3',14,C.ok);f4t(180,58,'kasrlar: 3/4 + 2/4 = 5/4',14,C.a2);f4t(180,100,'3 5/4 ?',20,C.bad);f4t(180,136,'5/4 — noto‘g‘ri kasr! Javob shunday qolmaydi',12,C.bad);f4c(['Kasrlar yig‘indisi 5/4 — u 1 dan katta'])},
 function(){clear();f4t(180,30,'5/4 = 1 1/4',16,C.a2);f4t(180,70,'3 + 1 1/4 = 4 1/4',20,C.ok);f7m(60,96,4,1,4,C.ok,46,28,C.a);f4c(['5/4 dan bitta butun ajratamiz: 3 5/4 = <b>4 1/4</b>'])}];
var F7P3=[function(){clear();f7lab(12,40,'5 4/7',C.blue);f7m(70,26,5,4,7,C.b,40,28);f4c(['5 4/7 − 2 1/7 = ?'])},
 function(){clear();f7m(70,26,5,4,7,C.b,40,28);for(var j=0;j<2;j++){var x=70+j*45;E('line',{x1:x+2,y1:30,x2:x+38,y2:50,stroke:C.bad,'stroke-width':3},S.g)}var bx=70+5*45;E('rect',{x:bx,y:26,width:40/7,height:28,fill:'#ffd0d0',stroke:C.bad},S.g);f4t(180,90,'butunlar: 5 − 2 = 3; kasrlar: 4/7 − 1/7 = 3/7',12,'#33475b');f4c(['Butundan butunni, kasrdan kasrni ayiramiz'])},
 function(){clear();f7m(70,26,3,3,7,C.ok,40,28,C.a);f4t(180,100,'5 4/7 − 2 1/7 = 3 3/7',18,C.ok);f4c(['= <b>3 3/7</b>'])}];
var F7P4=[function(){clear();f7lab(12,40,'4',C.blue);f7m(50,26,4,0,8,C.b,64,28);f4t(180,100,'4 − 1 3/8 = ?',18);f4c(['4 da kasr qismi yo‘q. 3/8 ni qayerdan ayiramiz?'])},
 function(){clear();f7m(50,26,3,0,8,C.b,64,28);f4bar(50+3*69,26,64,28,8,8,C.a);f4t(180,90,'4 = 3 8/8',18,C.a2);f4t(180,124,'bitta butunni 8 ta sakkizdan birga maydalaymiz',11,'#33475b');f4c(['4 = 3 + 8/8 = <b>3 8/8</b>'])},
 function(){clear();f7m(50,26,2,5,8,C.ok,64,28,C.a);f4t(180,90,'3 8/8 − 1 3/8 = 2 5/8',18,C.ok);f4c(['3 − 1 = 2; 8/8 − 3/8 = 5/8 → <b>2 5/8</b>'])}];
var F7P5=[function(){clear();f4t(180,30,'5 1/6 − 2 5/6 = ?',18);f7m(40,52,5,1,6,C.b,44,26);f4t(180,120,'1/6 dan 5/6 ni ayirib bo‘lmaydi!',13,C.bad);f4c(['Kasr qismi kichik — nima qilamiz?'])},
 function(){clear();f4t(180,30,'Bitta butunni «qarz» olamiz',14,C.a2);f7m(40,52,4,0,6,C.b,44,26);f4bar(40+4*49,52,44,26,6,6,C.a);f4bar(40+5*49,52,44,26,6,1,C.b);f4t(180,120,'5 1/6 = 4 + 6/6 + 1/6 = 4 7/6',16,C.a2);f4c(['5 1/6 = <b>4 7/6</b> (qiymati o‘zgarmadi!)'])},
 function(){clear();f4t(180,40,'4 7/6 − 2 5/6',18);f4t(180,80,'4 − 2 = 2;   7/6 − 5/6 = 2/6',14,'#33475b');f4t(180,124,'= 2 2/6',22,C.ok);f4c(['Javob: <b>2 2/6</b>','Xato: 3 4/6 — kasrlarni teskari ayirish (5/6 − 1/6)'])}];
var F7P7=[function(){clear();f4t(180,40,'5 1/6 − 2 5/6',18);f4t(180,80,'Ikkinchi usul: noto‘g‘ri kasrga aylantiramiz',12,'#33475b');f4c(['Qarz olmasdan ham yechish mumkin'])},
 function(){clear();f4t(180,40,'5 1/6 = 31/6;   2 5/6 = 17/6',16,C.blue);f4t(180,80,'5 · 6 + 1 = 31;   2 · 6 + 5 = 17',12,'#33475b');f4c(['Ikkalasini noto‘g‘ri kasr qilamiz'])},
 function(){clear();f4t(180,40,'31/6 − 17/6 = 14/6',18,C.blue);f4t(180,90,'14 : 6 = 2, qoldiq 2',13,'#33475b');f4t(180,130,'14/6 = 2 2/6',22,C.ok);f4c(['Javob o‘sha: <b>2 2/6</b>. Ikkala usul ham to‘g‘ri'])}];
function f7rope(st){clear();var x=20,w=320,u=w/6,y=62;f4t(14,20,'Ip — 6 m',13,'#33475b','start');var g=S.g;
 E('rect',{x:x,y:y,width:w,height:18,rx:9,fill:st>=1?'#cfe3f5':'#e8d7b5',stroke:'#8a5a24','stroke-width':1.5},g);for(var i=1;i<6;i++)E('line',{x1:x+i*u,y1:y,x2:x+i*u,y2:y+18,stroke:'#8a5a24','stroke-width':1},g);
 if(st>=1){E('rect',{x:x,y:y,width:u*2.3,height:18,rx:9,fill:'#ffd0d0',stroke:C.bad},g);f4Br(x,x+u*2.3,y+22,'2 3/10 m kesildi',false,C.bad)}
 if(st>=2){f4Br(x+u*2.3,x+w,y-4,'qoldi: 3 7/10 m',true,C.ok);f4t(180,152,'6 − 2 3/10 = 5 10/10 − 2 3/10 = 3 7/10',13,C.ok)}}
var F7P8=[function(){f7rope(0);f4c(['6 m ipdan 2 3/10 m kesib olindi. Qancha qoldi?'])},function(){f7rope(1);f4c(['6 ni 5 10/10 deb yozamiz (bitta butun = 10/10)'])},function(){f7rope(2);f4c(['5 10/10 − 2 3/10 = <b>3 7/10</b> m'])}];
function PRACT_STAGE(){clear();f4t(180,40,'2 1/5 + 1 3/5 = 3 4/5',16,C.ok);f4t(180,80,'1 3/4 + 2 2/4 = 3 5/4 = 4 1/4',16,C.blue);f4t(180,120,'5 1/6 − 2 5/6 = 4 7/6 − 2 5/6 = 2 2/6',14,C.a2);f4c(['Butunlar — butunlar bilan, kasrlar — kasrlar bilan'])}
var STEPS=[
{h:"Butunlar alohida, kasrlar alohida",sum:"2 1/5 + 1 3/5: butunlar 2 + 1 = 3, kasrlar 1/5 + 3/5 = 4/5 → 3 4/5.",a:"m01",
 start:function(){startPh(F7P1)},fin:function(){S.ph=2;F7P1[2]()},
 html:"<p>Aralash son — butun va kasrdan iborat. Ularni qo'shganda <b>butunni butun bilan</b>, <b>kasrni kasr bilan</b> qo'shamiz. Bosing:</p>",btns:[phaser(F7P1)],
 after:"<p>Xuddi pulni sanagandek: so'mlarni so'mlar bilan, tiyinlarni tiyinlar bilan. <b>2 1/5 + 1 3/5 = (2 + 1) + (1/5 + 3/5) = 3 4/5</b>.</p>",
 q:{t:"3 2/9 + 4 5/9 = ?",opts:["7 7/18","7 7/9","7 3/9","12 2/9"],ok:1,why:"3 + 4 = 7; 2/9 + 5/9 = 7/9.",hint:"Butunlarni qo'shing, keyin kasrlarni — maxraj o'zgarmaydi.",full:"Butunlar: 3 + 4 = 7. Kasrlar: 2/9 + 5/9 = 7/9. Javob: 7 7/9. «7 7/18» — maxrajlarni qo'shish xatosi, «7 3/9» — kasrlarni ayirish."},
 tn:"Singapur usuli: ikki aralash sonni tasmalarda chizib, butun tasmalarni bir guruhga, bo'laklarni boshqa guruhga ko'chiring."},
{h:"Kasrlar yig'indisi butundan oshsa",sum:"1 3/4 + 2 2/4 = 3 5/4 = 4 1/4: 5/4 dan bitta butun ajratamiz.",a:"m02",
 start:function(){startPh(F7P2)},fin:function(){S.ph=2;F7P2[2]()},
 html:"<p>1 3/4 + 2 2/4 ni qo'shamiz. Kasrlarni qo'shganda nima bo'larkin?</p>",btns:[phaser(F7P2)],
 after:"<p>3/4 + 2/4 = 5/4 — bu noto'g'ri kasr. Javobni aralash son ko'rinishida yozish uchun <b>5/4 dan butun ajratamiz</b>: 5/4 = 1 1/4. Shunda 3 + 1 1/4 = <b>4 1/4</b>.</p><p>Esda tuting: javobda kasr qismi doim <b>to'g'ri kasr</b> bo'lishi kerak.</p>",
 q:{t:"2 4/5 + 1 3/5 = ?",opts:["4 2/5","3 2/5","4 7/10","3 1/5"],ok:0,why:"3 7/5 = 4 2/5.",hint:"Kasrlar yig'indisi 7/5 — undan butun ajrating.",full:"Butunlar: 2 + 1 = 3. Kasrlar: 4/5 + 3/5 = 7/5 = 1 2/5. Jami: 3 + 1 2/5 = 4 2/5. «3 2/5» — ajratilgan butunni qo'shishni unutish."},
 tn:"Bu — o'nlikdan o'tib qo'shishning kasrdagi o'xshashi. «10 birlik = 1 o'nlik» kabi «4 chorak = 1 butun»."},
{h:"Aralash sonlarni ayirish",sum:"5 4/7 − 2 1/7: 5 − 2 = 3, 4/7 − 1/7 = 3/7 → 3 3/7.",a:"m03",
 start:function(){startPh(F7P3)},fin:function(){S.ph=2;F7P3[2]()},
 html:"<p>Ayirish ham shunday: butundan butunni, kasrdan kasrni ayiramiz. Bosing:</p>",btns:[phaser(F7P3)],
 after:"<p>Kamayuvchining kasr qismi (4/7) ayriluvchinikidan (1/7) <b>katta</b> bo'lsa — hammasi oddiy: <b>5 4/7 − 2 1/7 = 3 3/7</b>.</p>",
 q:{t:"6 5/8 − 4 2/8 = ?",opts:["2 7/8","10 7/8","2 3/8","3 3/8"],ok:2,why:"6 − 4 = 2; 5/8 − 2/8 = 3/8.",hint:"Butunlarni ayiring, kasrlarni ayiring.",full:"6 − 4 = 2, 5/8 − 2/8 = 3/8: javob 2 3/8. «2 7/8» — kasrlarni qo'shish, «10 7/8» — hammasini qo'shish."},
 tn:"Avval kasr qismlarni solishtirtiring: «kamayuvchining kasri kattami?» — bu keyingi «qarz» qadamiga tayyorlaydi."},
{h:"Butun sondan aralash sonni ayirish",sum:"4 − 1 3/8: 4 = 3 8/8, keyin 3 8/8 − 1 3/8 = 2 5/8.",a:"m04",
 start:function(){startPh(F7P4)},fin:function(){S.ph=2;F7P4[2]()},
 html:"<p>4 − 1 3/8. 4 da kasr qismi yo'q — 3/8 ni nimadan ayiramiz? Bosing:</p>",btns:[phaser(F7P4)],
 after:"<p>Bitta butunni <b>maydalaymiz</b>: 1 = 8/8. Shunda 4 = 3 8/8. Endi: 3 − 1 = 2, 8/8 − 3/8 = 5/8 → <b>2 5/8</b>.</p><p>Xuddi 1 dan ayirish kabi (1 − 3/8 = 5/8), faqat butunlar ko'proq.</p>",
 q:{t:"3 − 1 2/5 = ?",opts:["2 2/5","1 3/5","2 3/5","1 2/5"],ok:1,why:"3 = 2 5/5; 2 5/5 − 1 2/5 = 1 3/5.",hint:"3 ni «2 butun va 5/5» deb yozing.",full:"3 = 2 5/5. Butunlar: 2 − 1 = 1, kasrlar: 5/5 − 2/5 = 3/5. Javob: 1 3/5. «2 2/5» — butunni ayirib, kasrni shunday ko'chirish."},
 tn:"«Maydalash» (o'nlikni birlikka) — ayirishdagi qarz olishning o'zi. Bolalarga tanga misolini bering: 1 so'm = 100 tiyin."},
{h:"Tuzoq: kasr qismi kichik — qarz olamiz",sum:"5 1/6 − 2 5/6: 1/6 &lt; 5/6, shuning uchun 5 1/6 = 4 7/6; 4 7/6 − 2 5/6 = 2 2/6.",a:"m05",
 start:function(){startPh(F7P5)},fin:function(){S.ph=2;F7P5[2]()},
 html:"<p>5 1/6 − 2 5/6. Kasrlar: 1/6 − 5/6 — kichikdan katta ayrilmaydi! Bosing:</p>",btns:[phaser(F7P5)],
 after:"<p>Butun qismdan <b>bitta butun qarz</b> olamiz va uni kasrga qo'shamiz: 5 1/6 = 4 + 6/6 + 1/6 = <b>4 7/6</b>. Endi 7/6 − 5/6 = 2/6, 4 − 2 = 2 → <b>2 2/6</b>.</p><p>Eng ko'p xato: kasrlarni teskari ayirish (5/6 − 1/6) va «3 4/6» deb yozish.</p>",
 q:{t:"4 1/7 − 1 3/7 = ?",opts:["3 2/7","2 5/7","3 4/7","2 4/7"],ok:1,why:"4 1/7 = 3 8/7; 3 8/7 − 1 3/7 = 2 5/7.",hint:"1/7 dan 3/7 ni ayirib bo'ladimi? Bitta butunni qarz oling.",full:"4 1/7 = 3 8/7. Butunlar: 3 − 1 = 2; kasrlar: 8/7 − 3/7 = 5/7. Javob: 2 5/7. «3 2/7» — kasrlarni teskari ayirish (3/7 − 1/7) xatosi."},
 tn:"Qarz olib ayirish — testlarda eng ko'p xato qilinadigan joy. Ustunda ayirishdagi «qarz» bilan to'g'ridan-to'g'ri bog'lang."},
{h:"Tuzoq: 3 − 1/4",sum:"3 − 1/4 = 2 3/4 (3 1/4 ham, 2 1/4 ham emas).",a:"m06",
 start:function(){clear();f4t(180,60,'3 − 1/4 = ?',28);f4msg('To‘g‘ri javobni tanlang')},
 fin:function(){clear();f7m(40,30,2,3,4,C.ok,80,32,C.a);E('rect',{x:40+2*85+60,y:30,width:20,height:32,fill:'#ffd0d0',stroke:C.bad},S.g);f4t(180,110,'3 − 1/4 = 2 4/4 − 1/4 = 2 3/4',16,C.ok);f4msg('3 = 2 4/4 → <b>2 3/4</b>')},
 html:"<p>3 dan 1/4 ni ayiring. Uchta javobdan to'g'risini tanlang:</p>",
 btns:f4pick(1,[["3 1/4","Bu qo'shish: 3 + 1/4. Biz esa ayirdik — natija 3 dan kichik bo'lishi kerak."],["2 3/4","To'g'ri! 3 = 2 4/4, 2 4/4 − 1/4 = 2 3/4."],["2 1/4","Butundan 1 ni olib, kasrni ham olib tashladingiz. 1 butun = 4/4, undan 1/4 ketdi — 3/4 qoladi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Mantiqiy tekshiruv: 3 dan ozgina (chorak) olsak, natija 3 ga <b>yaqin, lekin kichik</b> bo'ladi: 2 3/4 ✓.</p>",
 q:{t:"5 − 3/8 = ?",opts:["5 3/8","4 5/8","4 3/8","2/8"],ok:1,why:"5 = 4 8/8; 4 8/8 − 3/8 = 4 5/8.",hint:"Bitta butunni sakkizdan birlarga maydalang.",full:"5 = 4 8/8. 8/8 − 3/8 = 5/8. Javob: 4 5/8. «4 3/8» — kasr qismni ko'chirib qo'yish, «5 3/8» — qo'shish."},
 tn:"Javobni taxminlash odati: «3 dan ozgina kam» → 2 dan 3 gacha. Bu tekshiruv xatoni darhol ushlaydi."},
{h:"Ikkinchi usul: noto'g'ri kasrga aylantirish",sum:"5 1/6 − 2 5/6 = 31/6 − 17/6 = 14/6 = 2 2/6.",a:"m07",
 start:function(){startPh(F7P7)},fin:function(){S.ph=2;F7P7[2]()},
 html:"<p>Qarz olishni yoqtirmasangiz — boshqa yo'l bor: ikkala sonni <b>noto'g'ri kasrga</b> aylantiramiz.</p>",btns:[phaser(F7P7)],
 after:"<p>Noto'g'ri kasrlarda maxraj bir xil — suratlarni ayiramiz: 31 − 17 = 14, ya'ni 14/6. Keyin butun qismni ajratamiz: <b>2 2/6</b>.</p><p>Ikkala usul ham bir xil javob beradi. Sonlar kichik bo'lsa — ikkinchi usul qulay, katta bo'lsa — birinchisi.</p>",
 q:{t:"3 2/5 − 1 4/5 ni noto'g'ri kasrlar orqali hisoblang.",opts:["1 3/5","2 2/5","2 3/5","1 2/5"],ok:0,why:"17/5 − 9/5 = 8/5 = 1 3/5.",hint:"3 2/5 = ?/5, 1 4/5 = ?/5.",full:"3 2/5 = 17/5, 1 4/5 = 9/5. 17/5 − 9/5 = 8/5 = 1 3/5. «2 2/5» — kasrlarni teskari ayirish xatosi."},
 tn:"Kuchli o'quvchilardan ikkala usulni ham so'rang — natija bir xil chiqqani usullarni ishonchli qiladi."},
{h:"Matnli masala: ip",sum:"6 m ipdan 2 3/10 m kesildi: 6 − 2 3/10 = 5 10/10 − 2 3/10 = 3 7/10 m qoldi.",a:"m08",
 start:function(){startPh(F7P8)},fin:function(){S.ph=2;F7P8[2]()},
 html:"<p>Onam 6 m ipdan sumkaga 2 3/10 m kesib oldi. Necha metr ip qoldi?</p>",btns:[phaser(F7P8)],
 after:"<p>«Qoldi» — ayirish. 6 butunda kasr yo'q, shuning uchun 6 = 5 10/10. Javob: <b>3 7/10 m</b>. Tekshirish: 3 7/10 + 2 3/10 = 5 10/10 = 6 ✓.</p>",
 q:{t:"Bidonda 10 l sut bor edi. Avval 3 1/4 l, keyin 2 3/4 l sut sotildi. Bidonda qancha sut qoldi?",opts:["4 l","5 l","4 2/4 l","3 l"],ok:0,why:"3 1/4 + 2 3/4 = 6; 10 − 6 = 4.",hint:"Avval jami qancha sotilganini toping.",full:"Sotildi: 3 1/4 + 2 3/4 = 5 4/4 = 6 l. Qoldi: 10 − 6 = 4 l. «5 l» — 4/4 = 1 ni butunga qo'shishni unutish."},
 tn:"Masalada ikki usulni solishtiring: ketma-ket ayirish va avval sotilganini qo'shish. Ikkinchisi oson ekanini bolalar o'zi ko'rsin."},
{h:"Bilasizmi? Futbol uchrashuvi",sum:"Futbol o'yini 2 ta 45 minutlik bo'limdan iborat: 1 1/2 soat = 90 minut.",a:"m09",
 start:function(){clear('#e8f5e9');f4t(180,50,'⚽ Futbol o‘yini qancha davom etadi?',14,'#1e5e2a');f4msg('Kasrlar sportda ham bor')},
 fin:function(){clear('#e8f5e9');f4bar(30,40,140,34,4,3,'#7bc47f');f4bar(190,40,140,34,4,3,'#5aa9e6');f4t(100,96,'1-bo‘lim: 3/4 soat',12,'#1e5e2a');f4t(260,96,'2-bo‘lim: 3/4 soat',12,'#1f6fb2');f4t(180,140,'3/4 + 3/4 = 6/4 = 1 2/4 = 1 1/2 soat',15,'#1d2b3a');f4msg('45 + 45 = 90 minut = <b>1 1/2</b> soat')},
 html:"<p>⚽ Futbol o'yini ikki bo'limdan iborat, har biri <b>45 minut</b>. Bu soatning qanday qismi? Tugmani bosing:</p>",
 btns:[["⚽ Hisoblash",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>45 minut = <b>3/4 soat</b> (60 : 4 · 3). Ikki bo'lim: 3/4 + 3/4 = 6/4 = <b>1 1/2 soat</b> = 90 minut. Bo'limlar orasidagi tanaffus esa 15 minut — 1/4 soat.</p>",
 tn:"Bolalardan sevimli sport yoki multfilm davomiyligini aralash son bilan yozishni so'rang (masalan, 1 1/4 soat)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>Butunlar — butunlar bilan, kasrlar — kasrlar bilan: 2 1/5 + 1 3/5 = 3 4/5.</li><li>Kasrlar yig'indisi ≥ 1 bo'lsa — butun ajrating: 3 5/4 = 4 1/4.</li><li>Butundan ayirish: 4 = 3 8/8, 3 8/8 − 1 3/8 = 2 5/8.</li><li>1 − 2/9 = 9/9 − 2/9 = 7/9.</li><li>Kasr qismi kichik bo'lsa — <b>qarz</b>: 5 1/6 = 4 7/6.</li><li>Ikkinchi usul: noto'g'ri kasrga aylantirish.</li><li>Tekshirish: ayirma + ayriluvchi = kamayuvchi.</li></ul></div>",
 tn:"Keyingi dars — kasrni songa ko'paytirish: «2/7 + 2/7 + 2/7 ni qisqaroq yozsa bo'ladimi?»"}
];
var PROBS=[
{t:"2 3/7 + 1 2/7 = ?",o:["3 5/7","3 5/14","3 1/7","1 1/7"],k:0,s:"2 + 1 = 3; 3/7 + 2/7 = 5/7."},
{t:"5 7/9 − 3 2/9 = ?",o:["2 5/9","2 9/9","8 5/9","3 5/9"],k:0,s:"5 − 3 = 2; 7/9 − 2/9 = 5/9."},
{t:"1 − 5/11 = ?",o:["6/11","4/11","5/11","1 5/11"],k:0,s:"11/11 − 5/11 = 6/11."},
{t:"4 − 2/3 = ?",o:["3 1/3","4 2/3","2 2/3","3 2/3"],k:0,s:"4 = 3 3/3; 3 3/3 − 2/3 = 3 1/3."},
{t:"3 3/4 + 2 3/4 = ?",o:["6 2/4","5 6/8","5 2/4","6 6/4"],k:0,s:"5 6/4 = 6 2/4."},
{t:"6 − 2 5/8 = ?",o:["3 3/8","4 3/8","4 5/8","3 5/8"],k:0,s:"6 = 5 8/8; 5 8/8 − 2 5/8 = 3 3/8."},
{t:"7 2/9 − 3 5/9 = ?",o:["3 6/9","4 3/9","4 6/9","3 3/9"],k:0,s:"7 2/9 = 6 11/9; 6 11/9 − 3 5/9 = 3 6/9."},
{t:"1 4/5 + 3/5 = ?",o:["2 2/5","1 2/5","2 7/10","2 1/5"],k:0,s:"4/5 + 3/5 = 7/5 = 1 2/5; 1 + 1 2/5 = 2 2/5."},
{t:"Ikki sonning yig'indisi 5. Ulardan biri 2 3/8. Ikkinchi sonni toping.",o:["2 5/8","3 5/8","2 3/8","7 3/8"],k:0,s:"5 − 2 3/8 = 4 8/8 − 2 3/8 = 2 5/8."},
{t:"8 sm kesmadan 2 3/10 sm va 3 9/10 sm kesib olindi. Necha santimetr qoldi?",o:["1 8/10 sm","2 8/10 sm","1 2/10 sm","2 2/10 sm"],k:0,s:"Kesildi: 5 12/10 = 6 2/10. 8 − 6 2/10 = 1 8/10."},
{t:"□ − 1 5/6 = 2 3/6. Kvadrat o'rnida qaysi son?",o:["4 2/6","1 2/6","3 2/6","4 8/6"],k:0,s:"2 3/6 + 1 5/6 = 3 8/6 = 4 2/6."},
{t:"3 1/4 + 1 2/4 − 2 3/4 = ?",o:["2","2 2/4","3","1 3/4"],k:0,s:"4 3/4 − 2 3/4 = 2."},
{t:"Qaysi ifodaning qiymati 1 ga teng?",o:["2 3/7 − 1 3/7","1 3/7 + 3/7","2 − 1 1/7","3/7 + 3/7"],k:0,s:"2 3/7 − 1 3/7 = 1."},
{t:"Ali 1 3/4 soat kitob o'qidi, Vali esa Alidan 3/4 soat ko'p o'qidi. Ikkalasi birgalikda necha soat o'qidi?",o:["4 1/4 soat","2 2/4 soat","3 2/4 soat","4 3/4 soat"],k:0,s:"Vali: 2 2/4. Birga: 1 3/4 + 2 2/4 = 3 5/4 = 4 1/4."},
{t:"4 − 1 2/5 va 1 4/5 + 4/5 ni taqqoslang.",o:["Teng","Birinchisi katta","Ikkinchisi katta","Birinchisi 1/5 ga katta"],k:0,s:"Ikkalasi ham 2 3/5."},
{t:"5 2/6 − 5 = ?",o:["2/6","5 2/6","10 2/6","3/6"],k:0,s:"Butunlar: 5 − 5 = 0, kasr qoladi: 2/6."},
{t:"Tarvuz 4 1/5 kg, qovun undan 1 3/5 kg yengil. Ikkalasi birgalikda necha kilogramm?",o:["6 4/5 kg","2 3/5 kg","5 4/5 kg","7 4/5 kg"],k:0,s:"Qovun: 2 3/5. Birga: 4 1/5 + 2 3/5 = 6 4/5."},
{t:"1 − 1/9 − 1/9 = ?",o:["7/9","8/9","6/9","1 2/9"],k:0,s:"9/9 − 1/9 − 1/9 = 7/9."},
{t:"10 m ipdan har biri 2 1/4 m bo'lgan 3 ta bo'lak kesib olindi. Necha metr ip qoldi?",o:["3 1/4 m","7 3/4 m","3 3/4 m","4 1/4 m"],k:0,s:"Kesildi: 6 3/4. 10 − 6 3/4 = 3 1/4."},
{t:"a 3/8 + 2 5/8 = 6 bo'lsa, a nechaga teng?",o:["3","4","2","1"],k:0,s:"3/8 + 5/8 = 1; a + 2 + 1 = 6, a = 3."}
];
var PREP_DATA={teach:["Aralash sonlarni qo'shish: butunlar va kasrlar alohida.","Kasrlar yig'indisi ≥ 1 — butun ajratish.","Ayirish; butun sondan ayirish (maydalash: 4 = 3 8/8).","Qarz olib ayirish: 5 1/6 = 4 7/6.","Ikkinchi usul — noto'g'ri kasrga aylantirish; matnli masalalar."],
 mist:["Javobda noto'g'ri kasrni qoldiradi: 3 5/4.","Kasrlarni teskari ayiradi: 5 1/6 − 2 5/6 = 3 4/6.","3 − 1/4 = 3 1/4 yoki 2 1/4 deb yozadi.","Maydalashda butunni kamaytirishni unutadi.","Maxrajlarni ham qo'shadi."],
 need:["Qog'oz tasmalar (butun va bo'laklar), qaychi.","Ip yoki lenta, chizg'ich."],
 board:["<span class='w2'>2 1/5 + 1 3/5 = 3 4/5</span>.","<span class='w2'>1 3/4 + 2 2/4 = 3 5/4 = 4 1/4</span>.","<span class='w2'>4 − 1 3/8 = 3 8/8 − 1 3/8 = 2 5/8</span>.","<span class='w2'>5 1/6 − 2 5/6 = 4 7/6 − 2 5/6 = 2 2/6</span>.","<span class='w2'>31/6 − 17/6 = 14/6 = 2 2/6</span>."]};
