var CODE='3C16',TITLE='3-sinf · Ikki va uch xonali songa burchakli bo‘lish';
function c16Try(k){var L=['187 : 24 = ?  (24 ≈ 20)'];if(k<=9)L.push('9 · 24 = [216] > 187');if(k<=8)L.push('8 · 24 = [192] > 187');if(k<=7)L.push('7 · 24 = {168} ≤ 187 ✓');w3Expr(L,{top:30,gap:38})}
var P3=w3LongPh(1872,24,'1872 : 24. Birinchi to‘liqsiz bo‘linuvchi — 187');
var P4=w3LongPh(714,42,'714 : 42. Bo‘luvchini yaxlitlaymiz: 42 ≈ 40, ya’ni «4 o‘nlik»');
var P5=w3LongPh(4284,42,'4284 : 42. O‘rtada nol chiqishini kuzating!');
var P6=w3LongPh(2484,207,'2484 : 207. Uch xonali bo‘luvchi: 207 ≈ 200');
var P7=w3LongPh(1000,16,'1000 : 16. Birinchi to‘liqsiz bo‘linuvchi — 100');
function c16Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Bo'linmada nechta raqam bo'ladi?",sum:"1872 : 24 — birinchi to'liqsiz bo'linuvchi 187 (18 < 24). Undan keyin yana 1 raqam qoladi → bo'linma 2 xonali.",a:"m01",
 start:function(){w3Long(1872,24,0);w3Msg('Avval bo‘linma necha xonali bo‘lishini aniqlaymiz')},fin:function(){w3Long(1872,24,1);w3Msg('187 → bo‘linmada 2 ta raqam: ** ')},
 html:"<p>1872 : 24. Chapdan raqamlarni olamiz: 1 < 24, 18 < 24, <b>187</b> ≥ 24. Bu — birinchi to'liqsiz bo'linuvchi. Undan keyin yana bitta raqam (2) qoldi. Bo'linma necha xonali?</p><div class='digs w3c'></div>",
 act:function(c,done){w3Btns(c,'.w3c',['1','2','3','4'],function(v,b){if(v==='2'){b.className='dg yes';w3Long(1872,24,1);w3Msg('To‘g‘ri: 187 dan 1 ta raqam + qolgan 1 ta raqam = <b>2 xonali</b>');done()}else{b.className='dg no';setTimeout(function(){b.className='dg'},1200);w3Msg(v==='4'?'1872 ning hamma raqami emas — avval 187 ni olamiz':'187 — bitta raqam beradi, keyin 2 ni tushiramiz')}})},
 after:"<p>Qoida: <b>birinchi to'liqsiz bo'linuvchi</b> bo'linmaning 1 ta raqamini beradi, keyin tushiriladigan <b>har bir</b> raqam yana 1 ta raqam beradi. Shunday qilib javob qanday bo'lishini oldindan bilamiz va nolni tushirib qoldirmaymiz.</p>",
 q:{t:"7740 : 36 — bo'linma necha xonali?",opts:["3 xonali","2 xonali","4 xonali","1 xonali"],ok:0,why:"77 ≥ 36 → 1 raqam, keyin 4 va 0 → yana 2 raqam. Jami 3.",hint:"Birinchi to'liqsiz bo'linuvchini toping: 7 < 36, 77 ≥ 36.",full:"77 — birinchi to'liqsiz bo'linuvchi. Qolgan raqamlar: 4, 0 → 2 ta. 1 + 2 = 3 xonali (7740 : 36 = 215). 4 xonali — bo'linuvchining hamma raqamini sanash xatosi."},
 tn:"Doskada to'liqsiz bo'linuvchini yoy bilan belgilang va bo'linma o'rniga oldindan nuqtalar qo'ying: «• •». Bu nolni yo'qotishning oldini oladi."},
{h:"Bo'linma raqamini sinab tanlaymiz",sum:"187 : 24. 24 ≈ 20, 18 : 2 ≈ 9 — sinaymiz: 9·24 = 216 katta, 8·24 = 192 katta, 7·24 = 168 ✓.",a:"m02",
 start:function(){w3Expr(['187 : 24 = ?','24 ≈ 20 → 18 : 2 ≈ 9']);w3Msg('Taxmin 9. Ko‘paytirib tekshiramiz')},fin:function(){c16Try(7);w3Msg('Raqam: <b>7</b>; 187 − 168 = 19 < 24 ✓')},
 html:"<p>187 da 24 necha marta bor? Yaxlitlab taxmin qilamiz: 24 ≈ 20, 18 : 2 = 9. Lekin taxmin katta chiqishi mumkin! Raqamlarni navbat bilan sinab ko'ring:</p><div class='digs w3c'></div>",
 act:function(c,done){var tried={};w3Btns(c,'.w3c',['9','8','7','6'],function(v,b){if(v==='7'){b.className='dg yes';c16Try(7);w3Msg('7 · 24 = 168 ≤ 187, qoldiq 19 < 24 ✓ — <b>7</b> to‘g‘ri');done()}else if(v==='6'){b.className='dg no';setTimeout(function(){b.className='dg'},1200);w3Expr(['6 · 24 = 144','187 − 144 = [43] > 24']);w3Msg('Qoldiq 43 ≥ 24 — yana bir 24 sig‘adi, raqam kichik!')}else{b.className='dg no';setTimeout(function(){b.className='dg'},1200);c16Try(+v);w3Msg(v+' · 24 = '+(v*24)+' > 187 — katta, kichikroq sinang')}})},
 after:"<p>Ikki xil tekshiruv:</p><div class='life'><div>⬆️<span>Ko'paytma bo'linuvchidan <b>katta</b> → raqam katta, 1 ga kamaytiring.</span></div><div>⬇️<span>Qoldiq bo'luvchidan <b>katta yoki teng</b> → raqam kichik, 1 ga oshiring.</span></div></div>",
 q:{t:"296 : 37 — bo'linma raqami qaysi?",opts:["8","7","9","6"],ok:0,why:"37 · 8 = 296 ✓.",hint:"37 ≈ 40, 29 : 4 ≈ 7. 7 · 37 ni tekshiring — qoldiq qancha?",full:"7 · 37 = 259, qoldiq 37 — bu bo'luvchiga teng, demak raqam kichik. 8 · 37 = 296, qoldiq 0 ✓. 9 · 37 = 333 > 296."},
 tn:"Bolalar daftar chetida «sinov ustuni» yozsin: 24, 48, 72, 96, 120, 144, 168, 192, 216 — Singapurda bu «karralilar jadvali» deyiladi."},
{h:"To'liq bo'lish: 1872 : 24",sum:"1872 : 24 = 78. Bo'l — ko'paytir — ayir — tushir — yana bo'l.",a:"m03",
 start:function(){startPh(P3)},fin:c16Fin(P3),
 html:"<p>Endi to'liq bajaramiz. Har bosishda bitta harakat: <b>bo'l → ko'paytir → ayir → tushir</b>.</p>",btns:[phaser(P3)],
 after:"<p>1872 : 24 = <b>78</b>. Tekshiruv: 78 · 24 = 1872 ✓. Bir xonali songa bo'lishdagi to'rt harakat o'zgarmadi — faqat har bir raqamni sinab tanlaymiz.</p>",
 q:{t:"1344 : 42 = ?",opts:["32","302","31","33"],ok:0,why:"134 : 42 → 3 (126), qoldiq 8; 84 : 42 = 2. Javob 32.",hint:"Birinchi to'liqsiz bo'linuvchi — 134.",full:"134 − 3·42 = 134 − 126 = 8. 4 ni tushiramiz: 84 : 42 = 2. Javob 32 (32 · 42 = 1344 ✓). «302» — ortiqcha nol qo'yish xatosi."},
 tn:"Har harakatni rangli bo'r bilan: bo'l — yashil, ko'paytir — qizil, ayir — qora, tushir — ko'k (sahnadagidek)."},
{h:"Yaxlitlab taxmin qilish",sum:"714 : 42 = 17. 42 ≈ 40: 71 : 40 → 1; 294 : 40 ≈ 7 → 7·42 = 294 ✓.",a:"m04",
 start:function(){startPh(P4)},fin:c16Fin(P4),
 html:"<p>Bo'luvchini o'nlikkacha yaxlitlaymiz va «bir xonali» bo'lish kabi taxmin qilamiz: 42 ≈ 40, ya'ni 294 : 40 ≈ 29 : 4 ≈ 7.</p>",btns:[phaser(P4)],
 after:"<p>714 : 42 = <b>17</b>. Bo'luvchi pastga yaxlitlansa (42 → 40), taxmin ba'zan <b>katta</b> chiqadi; yuqoriga yaxlitlansa (48 → 50), ba'zan <b>kichik</b>. Shuning uchun har doim ko'paytirib tekshiring.</p>",
 q:{t:"Tanya 2944 : 46 da birinchi raqamni topish uchun 46 ni nechaga yaxlitlashi qulay?",opts:["50","40","100","46 ni yaxlitlamaydi"],ok:0,why:"46 o'nlikkacha yaxlitlansa — 50 (6 ≥ 5).",hint:"Birlar xonasi 6 — yuqoriga yaxlitlanadi.",full:"46 ≈ 50. 294 : 50 ≈ 5 → tekshiramiz: 6 · 46 = 276 ≤ 294, qoldiq 18 ✓ — demak 6. Yuqoriga yaxlitlaganda taxmin kichik chiqishi mumkin, 1 ga oshiramiz. Javob: 2944 : 46 = 64."},
 tn:"«Yashirin barmoq» usuli: bo'luvchining birlar raqamini barmoq bilan yoping (42 → 4_) va bo'linuvchidan ham bitta raqam yoping."},
{h:"O'rtada nol: 4284 : 42",sum:"4284 : 42 = 102. 8 : 42 — sig'maydi → bo'linmaga 0 yozamiz.",a:"m05",
 start:function(){startPh(P5)},fin:c16Fin(P5),
 html:"<p>Eng ko'p xato qilinadigan joy: tushirilgan son bo'luvchidan <b>kichik</b> bo'lsa. Kuzating:</p>",btns:[phaser(P5)],
 after:"<p>4284 : 42 = <b>102</b>, 12 emas! Har bir tushirilgan raqam bo'linmaga <b>bitta raqam</b> beradi — sig'masa ham, 0 bo'lib. Tekshiruv: 102 · 42 = 4284 ✓.</p>",
 q:{t:"3672 : 36 = ?",opts:["102","12","120","1002"],ok:0,why:"36 : 36 = 1; 7 : 36 → 0; 72 : 36 = 2. Javob 102.",hint:"Bo'linma necha xonali? 36 — birinchi to'liqsiz bo'linuvchi, keyin 2 ta raqam.",full:"3 xonali bo'linma: 1, 0, 2 → 102. «12» — nolni tushirib qoldirish. Tekshiruv: 12 · 36 = 432 — hatto yaqin ham emas."},
 tn:"Tekshiruvni «baholash» bilan: 4284 : 42 ≈ 4200 : 42 = 100 — demak javob 12 bo'lishi mumkin emas."},
{h:"Uch xonali bo'luvchi: 2484 : 207",sum:"2484 : 207 = 12. 207 ≈ 200: 248 : 200 → 1; 414 : 200 ≈ 2.",a:"m06",
 start:function(){startPh(P6)},fin:c16Fin(P6),
 html:"<p>Bo'luvchi uch xonali bo'lsa ham usul o'sha. Faqat to'liqsiz bo'linuvchi kamida 3 xonali bo'ladi: 2 < 207, 24 < 207, <b>248</b> ≥ 207.</p>",btns:[phaser(P6)],
 after:"<p>2484 : 207 = <b>12</b>. Yuzlikkacha yaxlitlash: 207 ≈ 200 → 414 : 200 ≈ 4 : 2 = 2. Tekshiruv: 12 · 207 = 2484 ✓.</p>",
 q:{t:"5535 : 123 = ?",opts:["45","44","405","46"],ok:0,why:"553 : 123 → 4 (492), qoldiq 61; 615 : 123 = 5.",hint:"123 ≈ 100. Birinchi to'liqsiz bo'linuvchi — 553.",full:"4 · 123 = 492, 553 − 492 = 61. 5 ni tushiramiz: 615. 5 · 123 = 615 ✓. Javob 45 (45 · 123 = 5535)."},
 tn:"Uch xonali bo'luvchida taxmin uchun faqat yuzlar raqamiga qarang: 207 → «2 yuz»."},
{h:"Qoldiqli bo'lish va masala",sum:"1000 : 16 = 62 (qoldiq 8). Tekshiruv: 62 · 16 + 8 = 1000.",a:"m07",
 start:function(){startPh(P7)},fin:c16Fin(P7),
 html:"<p>Bo'linuvchi bo'linmasa — qoldiq qoladi. Qoldiq har doim bo'luvchidan <b>kichik</b> bo'lishi shart.</p>",btns:[phaser(P7)],
 after:"<p>1000 : 16 = <b>62</b> (qoldiq <b>8</b>). Tekshiruv: 62 · 16 = 992, 992 + 8 = 1000 ✓. Masalalarda qoldiq ma'nosini o'ylang: 1000 ta tuxum 16 talik qutiga — 62 ta to'la quti, 8 ta tuxum ortadi.</p>",
 q:{t:"Kutubxonaga 112 ta kitob keltirildi. 16 tadan va 14 tadan bog'lansa, bog'lamlar soni qanchaga farq qiladi?",opts:["1","2","8","7"],ok:0,why:"112 : 14 = 8, 112 : 16 = 7. 8 − 7 = 1.",hint:"Ikkala bo'lishni alohida bajaring.",full:"112 : 16 = 7 bog'lam, 112 : 14 = 8 bog'lam. Farq: 8 − 7 = 1. «2» — 16 − 14 ni hisoblash (kitoblar farqi), «8» va «7» — faqat bitta bo'lish."},
 tn:"Qoldiqli masalalarni hayotiy qiling: avtobusga sig'magan yo'lovchi uchun yana bitta avtobus kerak (javob yuqoriga yaxlitlanadi)."},
{h:"Tuzoq: oxirida nol",sum:"840 : 12 = 70, 7 emas! 84 : 12 = 7, keyin 0 ni tushiramiz: 0 : 12 = 0.",a:"m08",
 start:function(){w3Long(840,12,0);w3Msg('840 : 12 = ? Javobni tanlang')},fin:function(){w3Long(840,12,99);w3Msg('840 : 12 = <b>70</b>')},
 html:"<p>840 : 12. Birinchi to'liqsiz bo'linuvchi 84, 84 : 12 = 7. Javob qaysi?</p><div class='digs w3c'></div>",
 act:function(c,done){w3Btns(c,'.w3c',['7','70','700','17'],function(v,b){if(v==='70'){b.className='dg yes';w3Long(840,12,99);w3Msg('84 dan 1 raqam + tushirilgan 0 dan 1 raqam → <b>70</b>');done()}else{b.className='dg no';setTimeout(function(){b.className='dg'},1200);w3Msg(v==='7'?'Oxirgi 0 ni ham tushirish kerak: 0 : 12 = 0 → yana bir raqam!':v==='700'?'Bo‘linma 2 xonali: 84 → 1 raqam, 0 → 1 raqam':'7 · 12 = 84, 17 emas')}})},
 after:"<p>Tekshiruv baholash bilan: 7 · 12 = 84 — 840 dan 10 marta kichik. Demak javob <b>70</b>. Qoida: bo'linuvchining <b>barcha</b> raqamlari tushirilmaguncha bo'lish tugamaydi.</p>",
 q:{t:"9600 : 32 = ?",opts:["300","30","3","3000"],ok:0,why:"96 : 32 = 3, keyin 0 va 0 ni tushiramiz → 300.",hint:"Bo'linma necha xonali? 96 dan keyin yana 2 ta raqam bor.",full:"96 — birinchi to'liqsiz bo'linuvchi (1 raqam), keyin 0, 0 → yana 2 raqam. Jami 3 xonali: 300. Tekshiruv: 300 · 32 = 9600 ✓."},
 tn:"Bu tuzoq olimpiada testlarida tez-tez uchraydi. Har doim «bo'linma necha xonali?» savolidan boshlang."},
{h:"Bilasizmi? Burchakli bo'lish tarixi",sum:"Hozirgi ko'rinishdagi uzun bo'lish 1491-yilda italyan Filippo Kalandri kitobida bosilgan. Ungacha «galera» usuli keng tarqalgan edi.",a:"m09",
 start:function(){w3Long(2484,207,99);w3Msg('Bugungi yozuv — 500 yildan ortiq tarixga ega')},fin:function(){w3Long(2484,207,99);w3Msg('Bugungi yozuv — 500 yildan ortiq tarixga ega')},
 html:"<p>📜 Hozirgi ko'rinishdagi uzun bo'lish birinchi marta <b>1491-yilda</b> italyan matematigi <b>Filippo Kalandri</b>ning arifmetika kitobida bosilgan.</p><p>⛵ Undan oldin Yevropada <b>«galera» usuli</b> keng tarqalgan edi: raqamlar o'chirilib, ustma-ust yozilar va tayyor yozuv yelkanli kemaga o'xshab ketardi.</p><p>🌍 Bugun ham har xil mamlakatlarda bo'lish har xil yoziladi: bizda va Rossiyada «burchak», AQShda bo'linuvchi «uycha» ichida, Germaniyada bir qatorda yoziladi — lekin harakatlar bir xil!</p>",
 tn:"Kuchli o'quvchilarga bitta misolni ikki xil yozuvda (burchak va AQSh usuli) ko'rsating — harakatlar bir xilligini o'zlari topsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Long(1872,24,99);w3Msg('Bo‘l → ko‘paytir → ayir → tushir')},fin:function(){w3Long(1872,24,99);w3Msg('Bo‘l → ko‘paytir → ayir → tushir')},
 html:"<div class='memo'><ul><li>Birinchi to'liqsiz bo'linuvchini toping va bo'linma necha xonali bo'lishini aniqlang.</li><li>Raqamni taxmin qiling: bo'luvchini yaxlitlang (42 ≈ 40, 207 ≈ 200).</li><li>Ko'paytma katta → raqamni kamaytiring; qoldiq ≥ bo'luvchi → oshiring.</li><li>Tushirilgan son bo'luvchidan kichik bo'lsa — bo'linmaga <b>0</b> yozing.</li><li>Barcha raqamlar tushirilmaguncha to'xtamang (840 : 12 = 70).</li><li>Tekshiruv: bo'linma · bo'luvchi + qoldiq = bo'linuvchi.</li></ul></div>",
 tn:"Kartochkani daftarga yopishtirib, har bo'lishdan oldin 1-qatorni ovoz chiqarib aytish odatini shakllantiring."}
];
var PROBS=[
{t:"96 : 24 = ?",o:["4","3","5","6"],k:0,s:"4 · 24 = 96."},
{t:"156 : 12 = ?",o:["13","12","14","103"],k:0,s:"15 : 12 = 1 (3), 36 : 12 = 3 → 13."},
{t:"375 : 25 = ?",o:["15","14","16","105"],k:0,s:"37 : 25 = 1 (12), 125 : 25 = 5 → 15."},
{t:"672 : 32 = ?",o:["21","22","201","12"],k:0,s:"67 : 32 = 2 (3), 32 : 32 = 1 → 21."},
{t:"1344 : 42 = ?",o:["32","302","31","23"],k:0,s:"134 : 42 = 3 (8), 84 : 42 = 2 → 32."},
{t:"2944 : 46 = ?",o:["64","63","65","604"],k:0,s:"294 : 46 = 6 (18), 184 : 46 = 4 → 64."},
{t:"4508 : 49 = ?",o:["92","902","93","82"],k:0,s:"450 : 49 = 9 (9), 98 : 49 = 2 → 92."},
{t:"6120 : 36 = ?",o:["170","17","107","1700"],k:0,s:"61 : 36 = 1 (25), 252 : 36 = 7 (0), 0 → 0. Javob 170."},
{t:"3672 : 36 = ?",o:["102","12","120","1002"],k:0,s:"36 : 36 = 1, 7 : 36 → 0, 72 : 36 = 2 → 102."},
{t:"1872 : 24 = ?",o:["78","77","79","708"],k:0,s:"187 : 24 = 7 (19), 192 : 24 = 8 → 78."},
{t:"5535 : 123 = ?",o:["45","44","405","46"],k:0,s:"553 : 123 = 4 (61), 615 : 123 = 5 → 45."},
{t:"8424 : 312 = ?",o:["27","26","28","207"],k:0,s:"842 : 312 = 2 (218), 2184 : 312 = 7 → 27."},
{t:"1000 : 16 = ?",o:["62 (qoldiq 8)","62 (qoldiq 4)","61 (qoldiq 24)","602 (qoldiq 8)"],k:0,s:"62 · 16 = 992, 1000 − 992 = 8."},
{t:"500 : 23 = ?",o:["21 (qoldiq 17)","21 (qoldiq 7)","20 (qoldiq 40)","22 (qoldiq 6)"],k:0,s:"21 · 23 = 483, 500 − 483 = 17 < 23."},
{t:"7740 : 36 — bo'linma necha xonali?",o:["3 xonali","2 xonali","4 xonali","1 xonali"],k:0,s:"77 → 1 raqam, keyin 4 va 0 → yana 2. 7740 : 36 = 215."},
{t:"9600 : 32 = ?",o:["300","30","3","3000"],k:0,s:"96 : 32 = 3, keyin ikki nol → 300."},
{t:"112 ta kitob 16 tadan va 14 tadan bog'lansa, bog'lamlar soni qanchaga farq qiladi?",o:["1","2","8","7"],k:0,s:"112 : 14 = 8, 112 : 16 = 7, farq 1."},
{t:"864 nafar o'quvchini sayohatga olib borish uchun 48 o'rinli avtobuslardan nechta kerak?",o:["18","17","19","16"],k:0,s:"864 : 48 = 18 (qoldiqsiz)."},
{t:"x · 34 = 2380 bo'lsa, x = ?",o:["70","7","700","80"],k:0,s:"x = 2380 : 34 = 70 (34 · 70 = 2380)."},
{t:"Bo'luvchi 27, bo'linma 35, qoldiq 13. Bo'linuvchi nechaga teng?",o:["958","945","932","975"],k:0,s:"27 · 35 + 13 = 945 + 13 = 958."}
];
function PRACT_STAGE(){w3Long(1872,24,99);w3Msg('Bo‘l → ko‘paytir → ayir → tushir')}
var PREP_DATA={teach:["Birinchi to'liqsiz bo'linuvchi va bo'linma xonalari sonini aniqlash.","Bo'luvchini yaxlitlab bo'linma raqamini taxmin qilish va sinash.","Ikki va uch xonali songa burchakli bo'lish algoritmi.","Bo'linmada o'rtadagi va oxiridagi nollar; qoldiqli bo'lish."],
 mist:["Taxmin raqamini tekshirmaydi (9 · 24 = 216 > 187 bo'lsa ham yozadi).","Qoldiq bo'luvchidan katta qoladi — raqam kichik tanlangan.","O'rtadagi nolni tushirib qoldiradi: 4284 : 42 = 12.","Oxirgi nolni tushirmaydi: 840 : 12 = 7."],
 need:["Sinov ustuni uchun daftar cheti (bo'luvchining karralilari).","Rangli bo'r (bo'l/ko'paytir/ayir/tushir)."],
 board:["<span class='w2'>1872 : 24</span>: 187 → • • (2 xonali).","<span class='w2'>24 ≈ 20</span>: 9? 8? 7 ✓.","<span class='w2'>4284 : 42 = 102</span>.","<span class='w2'>840 : 12 = 70</span>.","Tekshiruv: <span class='w2'>78 · 24 = 1872</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
