var CODE='2F8',TITLE='2-sinf · Shakllarni bo‘laklarga ajratish va yig‘ish';
// ---------- sahna vositalari ----------
function f8Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f8Poly(pts,fill,dx,dy,lab){var d=pts.map(function(p,i){return (i?'L':'M')+(p[0]+(dx||0))+' '+(p[1]+(dy||0))}).join('')+'Z';E('path',{d:d,fill:fill||C.a,stroke:C.line,'stroke-width':2,'stroke-linejoin':'round'},S.g);
 if(lab){var cx=0,cy=0;pts.forEach(function(p){cx+=p[0];cy+=p[1]});T(S.g,cx/pts.length+(dx||0),cy/pts.length+(dy||0)+5,lab,{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}}
function f8Cut(x1,y1,x2,y2,col){E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:col||C.bad,'stroke-width':3,'stroke-dasharray':'7 4','stroke-linecap':'round'},S.g)}
// kvadrat: x 120..240, y 26..146
var SQ=[[120,26],[240,26],[240,146],[120,146]];
function f8Square(kind){clear();if(!kind){f8Poly(SQ,C.a);f8Msg('Kvadratni bitta to‘g‘ri kesish bilan qanday bo‘laklarga ajratish mumkin?');return}
 if(kind==='v'){f8Poly([[120,26],[176,26],[176,146],[120,146]],C.a,-8,0,'1');f8Poly([[184,26],[240,26],[240,146],[184,146]],'#f6c98a',8,0,'2');f8Msg('O‘rtadan tik kesdik: <b>ikkita to‘g‘ri to‘rtburchak</b>')}
 if(kind==='d'){f8Poly([[120,26],[240,26],[120,146]],C.a,-8,-6,'1');f8Poly([[240,26],[240,146],[120,146]],'#f6c98a',8,6,'2');f8Msg('Burchakdan burchakka (diagonal) kesdik: <b>ikkita uchburchak</b>')}
 if(kind==='c'){f8Poly([[120,26],[200,26],[120,106]],C.a,-8,-6,'1');f8Poly([[200,26],[240,26],[240,146],[120,146],[120,106]],'#f6c98a',8,6,'2');f8Msg('Burchakni kesib oldik: <b>uchburchak va beshburchak</b>')}}
// ikkita uchburchakdan kvadrat
var P2=[function(){clear();f8Poly([[40,40],[120,40],[40,120]],C.a,0,0,'1');f8Poly([[320,60],[320,140],[240,140]],'#f6c98a',0,0,'2');f8Msg('Ikkita bir xil uchburchak: to‘g‘ri burchakli, ikki tomoni teng')},
 function(){clear();f8Poly([[130,40],[210,40],[130,120]],C.a,0,0,'1');f8Poly([[320,60],[320,140],[240,140]],'#f6c98a',-90,-20,'2');f8Msg('Ikkinchisini birinchisiga olib kelamiz…')},
 function(){clear();f8Poly([[130,40],[210,40],[130,120]],C.a,0,0,'1');f8Poly([[210,40],[210,120],[130,120]],'#f6c98a',0,0,'2');f8Msg('Uzun tomonlari bilan qo‘shildi — <b>kvadrat</b> hosil bo‘ldi!')}];
// teng kvadratlarga bo'lish
function f8Grid(n){clear();var x0=110,y0=16,s=140;E('rect',{x:x0,y:y0,width:s,height:s,fill:C.a,stroke:C.line,'stroke-width':2.5},S.g);
 for(var k=1;k<n;k++){f8Cut(x0+k*s/n,y0-6,x0+k*s/n,y0+s+6);f8Cut(x0-6,y0+k*s/n,x0+s+6,y0+k*s/n)}
 f8Msg(n===1?'Bitta kvadrat':'Tik '+(n-1)+' ta + yotiq '+(n-1)+' ta = <b>'+(2*(n-1))+' ta</b> kesik → <b>'+(n*n)+' ta</b> teng kvadratcha ('+n+' × '+n+')')}
var P3=[function(){f8Grid(1)},function(){f8Grid(2)},function(){f8Grid(3)}];
// to'rtburchak -> ikki kvadrat
function f8Rect(w){clear();var h=60,x0=180-w*30,y0=40;E('rect',{x:x0,y:y0,width:w*60,height:h,fill:C.a,stroke:C.line,'stroke-width':2.5},S.g);
 f8Cut(180,y0-8,180,y0+h+8);
 var ok=w===2;T(S.g,180,y0+h+48,ok?'✓ ikkita bir xil kvadrat':'✗ bo‘laklar kvadrat emas',{'font-size':14,'font-weight':800,fill:ok?C.ok:C.bad});
 f8Msg('Bo‘yi '+(w===1?'eniga teng':String(w).replace('.',',')+' marta uzun')+' to‘rtburchakni o‘rtasidan kesdik')}
// pirog kesish: chiziqlar soni -> eng ko'p bo'lak
function f8Pie(n){clear();E('circle',{cx:180,cy:86,r:70,fill:'#f2c27b',stroke:C.line,'stroke-width':2.5},S.g);
 var L={1:[[110,86,250,86]],2:[[110,86,250,86],[180,16,180,156]],3:[[110,66,250,66],[120,36,222,148],[240,36,138,148]]}[n]||[];
 L.forEach(function(l){f8Cut(l[0],l[1],l[2],l[3])});var mx={1:2,2:4,3:7}[n];T(S.g,320,90,mx+' bo‘lak',{'font-size':16,'font-weight':800,fill:C.blue});
 f8Msg(n===3?'3 ta kesik: har yangi kesik oldingilarning <b>hammasini</b> kesib o‘tsa — <b>7</b> bo‘lak (6 emas!)':(n===2?'2 ta kesik kesishsa — <b>4</b> bo‘lak':'1 ta kesik — 2 bo‘lak'))}
var P5=[function(){f8Pie(1)},function(){f8Pie(2)},function(){f8Pie(3)}];
// katta kvadratdan kichiklar
function f8Cutout(k){clear();var x0=110,y0=14,s=144;E('rect',{x:x0,y:y0,width:s,height:s,fill:'#fff3df',stroke:C.line,'stroke-width':2.5},S.g);T(S.g,x0+s/2,y0+s+14,'8 sm',{'font-size':11,fill:'#5b6b7b'});
 var n=4,c=s/n,cnt=0;for(var r=0;r<n;r++)for(var q=0;q<n;q++){if(k===1&&r>0)continue;cnt++;E('rect',{x:x0+q*c+2,y:y0+r*c+2,width:c-4,height:c-4,rx:3,fill:C.a,stroke:C.line},S.g);if(k===2)T(S.g,x0+q*c+c/2,y0+r*c+c/2+5,String(cnt),{'font-size':12,'font-weight':800,fill:'#fff'})}
 if(k===0)f8Msg('Tomoni 8 sm kvadratdan tomoni 2 sm kvadratlar qirqamiz. Nechta chiqadi?');if(k===1)f8Msg('Bitta qatorga: 8 : 2 = <b>4</b> ta');if(k===2)f8Msg('Qatorlar ham 4 ta: 4 × 4 = <b>16</b> ta (4 emas, 32 emas!)')}
var P6=[function(){f8Cutout(0)},function(){f8Cutout(1)},function(){f8Cutout(2)}];
// tangram
function f8Tan(){clear('#fbf7ef');var x0=110,y0=14,s=144,h=s/2,q=s/4,c=['#e0475b','#f0a040','#5aa9e6','#1e8e5a','#a46be0','#f08aa8','#12a39f'];
 var P=[[[0,0],[s,0],[h,h]],[[0,0],[h,h],[0,s]],[[s,0],[s,h],[3*q,q]],[[3*q,q],[s,h],[3*q,3*q],[h,h]],[[h,h],[3*q,3*q],[q,3*q]],[[0,s],[q,3*q],[3*q,3*q],[h,s]],[[s,h],[s,s],[h,s]]];
 P.forEach(function(p,i){f8Poly(p.map(function(v){return [v[0]+x0,v[1]+y0]}),c[i])});f8Msg('Tangram: kvadrat 7 ta bo‘lakka bo‘lingan — ulardan yuzlab shakl yig‘iladi')}
var STEPS=[
{h:"Kvadratni kesamiz",sum:"Bitta to'g'ri kesish kvadratni ikkita to'rtburchak, ikkita uchburchak yoki uchburchak va beshburchakka ajratadi.",a:"m01",
 start:function(){f8Square()},fin:function(){f8Square('d')},
 html:"<p>Qog'oz kvadratni qaychi bilan <b>bitta to'g'ri</b> kesishda qanday bo'laklar chiqadi? Har xil kesib ko'ring:</p>",
 btns:[["│ tik",function(c,done){f8Square('v');mvK(done,2)}],["╱ diagonal",function(c,done){f8Square('d');mvK(done,2)}],["◸ burchak",function(c,done){f8Square('c');mvK(done,2)}]],g3:1,
 after:"<p>Bitta to'g'ri kesish har doim <b>2 ta bo'lak</b> beradi. Bo'laklarning shakli esa qayerdan kesganimizga bog'liq. To'g'ri kesish bilan hech qachon <b>doira</b> chiqmaydi — doiraning chegarasi egri!</p>",
 q:{t:"Kvadrat qog'ozni bitta to'g'ri kesish bilan qaysi shakllarga ajratib bo'lmaydi?",opts:["ikkita uchburchak","ikkita to'g'ri to'rtburchak","uchburchak va beshburchak","ikkita doira"],ok:3,why:"To'g'ri kesish to'g'ri chiziq beradi, doira esa egri chiziq bilan chegaralangan.",hint:"Qaysi shaklning chegarasi egri chiziq?",full:"Tik kesish — ikki to'rtburchak, diagonal — ikki uchburchak, burchakni kesish — uchburchak va beshburchak. Doira chiqishi uchun egri kesish kerak, to'g'ri kesish bilan bo'lmaydi."},
 tn:"Har bolaga qog'oz kvadrat va qaychi bering — «2 ta uchburchak», «2 ta to'rtburchak» qilib kesishsin."},
{h:"Bo'laklardan yig'amiz",sum:"Ikkita bir xil to'g'ri burchakli (ikki tomoni teng) uchburchakdan kvadrat yig'iladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Endi teskarisi: bo'laklardan butun shakl yig'amiz. Ikkita uchburchakni kuzating.</p>",
 btns:[phaser(P2,'▶ Siljitish')],
 after:"<p>Bu uchburchaklar maxsus: ularning bitta burchagi <b>to'g'ri</b> va ikki tomoni <b>teng</b>. Shuning uchun ular uzun tomonlari bilan qo'shilganda kvadrat bo'ladi. Istalgan ikki uchburchakdan kvadrat chiqavermaydi!</p>",
 q:{t:"Ikkita bir xil uchburchakdan kvadrat yig'ish mumkinmi?",opts:["Ha, istalgan uchburchaklardan","Yo'q, hech qachon","Ha, agar ular to'g'ri burchakli va ikki tomoni teng bo'lsa","Faqat 3 ta uchburchakdan"],ok:2,why:"Faqat to'g'ri burchakli, ikki tomoni teng uchburchaklar kvadratga yig'iladi.",hint:"Kvadratni diagonal bo'yicha kesganda qanday uchburchaklar chiqdi?",full:"Kvadratni diagonal bo'ylab kessak, to'g'ri burchakli va ikki tomoni teng ikkita uchburchak chiqadi. Demak, aynan shunday uchburchaklardan kvadrat qayta yig'iladi. Boshqa uchburchaklardan kvadrat chiqmaydi."},
 tn:"Bolalar kesib olgan uchburchaklarini almashtirib, qayta kvadrat yig'ishsin — bo'laklar «yo'qolmaydi», faqat joyi o'zgaradi."},
{h:"Teng kvadratchalarga bo'lamiz",sum:"4 ta teng kvadratcha — 2 kesik (2 × 2), 9 ta — 4 kesik (3 × 3), 16 ta — 6 kesik (4 × 4).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Kvadratni <b>teng</b> kvadratchalarga bo'lish uchun nechta kesik kerak? Kuzating.</p>",
 btns:[phaser(P3,'▶ Ko‘proq bo‘lamiz')],
 after:"<p>Har tomonni <b>n</b> bo'lakka bo'lsak, tik va yotiq kesiklar <b>(n − 1)</b> tadan bo'ladi: 2 × 2 uchun 1 + 1 = 2 kesik, 3 × 3 uchun 2 + 2 = 4 kesik. Kesiklar soni kvadratchalar sonidan ancha kam!</p>",
 q:{t:"Kvadratni 16 ta teng kvadratchaga bo'lish uchun nechta to'g'ri kesik kerak (har kesik butun kvadrat bo'ylab)?",opts:["16","8","6","4"],ok:2,why:"16 = 4 × 4: tik 3 ta va yotiq 3 ta — 6 kesik.",hint:"16 ta kvadratcha — necha qator, necha ustun? Qatorlar orasida nechta chiziq bor?",full:"16 = 4 × 4. 4 ta ustun orasida 3 ta tik chiziq, 4 ta qator orasida 3 ta yotiq chiziq: 3 + 3 = 6 kesik. «8» — har tomonni 4 deb qo'shish, «16» — kvadratchalar soni."},
 tn:"Bu — «ustunlar xatosi»ning bir ko'rinishi: 4 ta bo'lak orasida 3 ta chegara bo'ladi."},
{h:"To'rtburchakdan ikki kvadrat",sum:"Bitta kesishda ikkita bir xil kvadrat chiqishi uchun to'rtburchakning bo'yi enidan 2 marta uzun bo'lishi kerak.",a:"m04",
 start:function(){f8Rect(1.5)},fin:function(){f8Rect(2)},
 html:"<p>To'g'ri to'rtburchakni o'rtasidan bitta kesish bilan <b>ikkita bir xil kvadrat</b> qilmoqchimiz. Qanday to'rtburchak kerak? Sinab ko'ring:</p>",
 btns:[["bo'yi 1,5 marta",function(c,done){f8Rect(1.5);mvK(done,2)}],["bo'yi 2 marta",function(c,done){f8Rect(2);mvK(done,2)}],["bo'yi 3 marta",function(c,done){f8Rect(3);mvK(done,2)}]],g3:1,
 after:"<p>Har bir bo'lak kvadrat bo'lishi uchun uning bo'yi ham, eni ham to'rtburchakning eniga teng bo'lishi kerak. Ikkita shunday bo'lak yonma-yon — demak to'rtburchakning bo'yi <b>enidan 2 marta uzun</b>.</p>",
 q:{t:"Eni 3 sm bo'lgan to'g'ri to'rtburchakni o'rtasidan kesib, ikkita bir xil kvadrat oldik. To'rtburchakning bo'yi necha sm?",opts:["3 sm","6 sm","9 sm","5 sm"],ok:1,why:"Har kvadrat tomoni 3 sm, ikkitasi yonma-yon — 6 sm.",hint:"Har bir kvadratning tomoni nechaga teng? Ikkita kvadrat yonma-yon tursa-chi?",full:"Kvadratlar tomoni to'rtburchakning eniga teng — 3 sm. Ikki kvadrat yonma-yon: 3 + 3 = 6 sm. Bo'yi enidan 2 marta uzun."},
 tn:"Qog'oz tasmalardan har xil to'rtburchaklar kesib, bolalar o'zi sinab ko'rsin."},
{h:"Tuzoq: pirogni kesish",sum:"1 kesik — 2 bo'lak, 2 kesik — 4, 3 kesik — 7 bo'lak (har yangi kesik oldingilarni kesib o'tsa).",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Dumaloq pirogni to'g'ri kesiklar bilan kesamiz (bo'laklar teng bo'lishi shart emas). <b>Eng ko'pi bilan</b> nechta bo'lak chiqadi?</p>",
 btns:[phaser(P5,'▶ Yana bitta kesik')],
 after:"<p>Ko'pchilik «3 kesik — 6 bo'lak» deydi. Lekin kesiklar bitta nuqtada emas, <b>har xil joyda kesishsa</b>, o'rtada yana bitta kichik bo'lak paydo bo'ladi: <b>7</b> ta. Har yangi kesik oldingi kesiklarning hammasini kesib o'tishi kerak.</p>",
 q:{t:"Kvadrat shaklidagi pirogni 2 ta to'g'ri kesish bilan eng ko'pi bilan nechta bo'lakka bo'lish mumkin?",opts:["3","4","5","6"],ok:1,why:"Ikki kesik kesishsa — 4 bo'lak.",hint:"Kesiklar parallel bo'lsa necha bo'lak? Kesishsa-chi?",full:"Ikki kesik parallel bo'lsa — 3 bo'lak, kesishsa — 4 bo'lak. Eng ko'pi — 4. «5» va «6» ikki kesik bilan bo'lmaydi."},
 tn:"Doskada doira chizib, bolalar o'zi 3 ta chiziq bilan 7 bo'lak chiqarishga urinsin — bu mashhur olimpiada masalasi."},
{h:"Tuzoq: kattadan kichiklarni qirqamiz",sum:"8 sm kvadratdan 2 sm kvadratlar: bir qatorga 4 ta, 4 qator — 4 × 4 = 16 ta.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Tomoni 8 sm bo'lgan kvadrat qog'ozdan tomoni 2 sm bo'lgan kvadratlar qirqib olamiz. Nechta chiqadi?</p>",
 btns:[phaser(P6)],
 after:"<p>Tez javob «8 : 2 = 4» — xato, bu faqat <b>bitta qator</b>. Qatorlar ham 4 ta, shuning uchun <b>4 × 4 = 16</b> ta. Kvadrat ikki tomonga ham bo'linadi!</p>",
 q:{t:"Tomoni 6 sm bo'lgan kvadratdan tomoni 2 sm bo'lgan nechta kvadrat qirqib olish mumkin?",opts:["3","9","12","18"],ok:1,why:"Bir qatorda 6 : 2 = 3 ta, 3 qator: 3 × 3 = 9.",hint:"Bitta qatorga nechta sig'adi? Qatorlar nechta?",full:"6 : 2 = 3 — bir qatorda 3 ta. Qatorlar ham 3 ta. 3 × 3 = 9. «3» — faqat bitta qator."},
 tn:"Katakli qog'ozda 8 × 8 kvadrat chizib, uni 2 × 2 bo'laklarga ajratdiring va sanatib ko'ring."},
{h:"Bilasizmi? Tangram",sum:"Tangram — kvadratdan kesilgan 7 bo'lakli qadimiy Xitoy jumbog'i.",a:"m07",
 start:function(){f8Tan()},fin:function(){f8Tan()},
 html:"<p>🧩 <b>Tangram</b> — Xitoyda o'ylab topilgan jumboq. Bitta kvadrat <b>7 ta bo'lakka</b> bo'linadi: 5 ta uchburchak, 1 ta kvadrat va 1 ta parallelogramm. Shu 7 bo'lakdan odam, mushuk, uy, kema kabi <b>minglab</b> shakl yig'ish mumkin — lekin har safar hamma 7 bo'lak ishlatiladi!</p>",
 tn:"Kartondan tangram kesib, bolalarga «mushuk» yoki «uy» yig'ish topshirig'ini bering. Bu fazoviy tasavvurni juda yaxshi rivojlantiradi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){f8Square('d')},fin:function(){f8Square('d')},
 html:"<div class='memo'><ul><li>Bitta to'g'ri kesish — har doim <b>2 bo'lak</b>; to'g'ri kesish bilan doira chiqmaydi.</li><li>Kvadratning diagonali — ikkita bir xil uchburchak; ular qaytib kvadrat bo'ladi.</li><li>n × n teng kvadratcha uchun: (n − 1) tik + (n − 1) yotiq kesik. 3 × 3 → 4 kesik.</li><li>Bitta kesishda ikki kvadrat: bo'yi enidan <b>2 marta</b> uzun.</li><li>Pirog: 1 kesik — 2, 2 kesik — 4, 3 kesik — <b>7</b> bo'lak.</li><li>8 sm kvadratdan 2 sm kvadratlar: 4 × 4 = <b>16</b> (ikki tomonga bo'linadi).</li></ul></div>",
 tn:"Keyingi darsda bo'laklardan yuz (kataklar soni) qanday saqlanishini ko'ramiz: kesib yig'ganda yuz o'zgarmaydi."}
];
var PROBS=[
{t:"Kvadratni bitta to'g'ri kesish bilan nechta bo'lakka ajratish mumkin?",o:["2","1","3","4"],k:0,s:"Bitta to'g'ri kesish — har doim 2 bo'lak."},
{t:"Kvadratni burchakdan qarama-qarshi burchakka kessak, qanday bo'laklar chiqadi?",o:["ikkita uchburchak","ikkita kvadrat","ikkita to'rtburchak","uchburchak va to'rtburchak"],k:0,s:"Diagonal bo'yicha kesish — ikkita bir xil uchburchak."},
{t:"Kvadratni 4 ta teng kvadratchaga bo'lish uchun nechta to'g'ri kesik kerak?",o:["2","4","3","1"],k:0,s:"1 ta tik + 1 ta yotiq = 2 kesik."},
{t:"Kvadratni 9 ta teng kvadratchaga bo'lish uchun nechta to'g'ri kesik kerak?",o:["4","6","8","3"],k:0,s:"2 ta tik + 2 ta yotiq = 4."},
{t:"Pirogni 3 ta to'g'ri kesik bilan eng ko'pi bilan nechta bo'lakka bo'lish mumkin?",o:["7","6","8","9"],k:0,s:"Har yangi kesik oldingilarni kesib o'tsa: 2, 4, 7."},
{t:"Pirogni 2 ta parallel kesik bilan kessak, nechta bo'lak chiqadi?",o:["3","4","2","5"],k:0,s:"Parallel kesiklar kesishmaydi: 3 ta bo'lak."},
{t:"Tomoni 8 sm bo'lgan kvadratdan tomoni 2 sm bo'lgan nechta kvadrat qirqib olish mumkin?",o:["16","4","32","8"],k:0,s:"Bir qatorga 4 ta, 4 qator: 16."},
{t:"Tomoni 9 sm bo'lgan kvadratdan tomoni 3 sm bo'lgan nechta kvadrat qirqib olish mumkin?",o:["9","3","27","6"],k:0,s:"Bir qatorga 3 ta, 3 qator: 9."},
{t:"Eni 4 sm bo'lgan to'g'ri to'rtburchak o'rtasidan kesilib, ikkita bir xil kvadrat chiqdi. Uning bo'yi necha sm?",o:["8 sm","4 sm","16 sm","6 sm"],k:0,s:"Ikkita 4 sm li kvadrat yonma-yon: 8 sm."},
{t:"To'g'ri to'rtburchakni bitta kesishda ikkita bir xil kvadratga ajratish uchun uning bo'yi eniga nisbatan qanday bo'lishi kerak?",o:["2 marta uzun","eniga teng","3 marta uzun","2 sm uzun"],k:0,s:"Ikki kvadrat yonma-yon — bo'yi enidan 2 marta uzun."},
{t:"Tort 8 ta teng bo'lakka kesildi. Ali 2 ta, Lola 3 ta bo'lak yedi. Nechta bo'lak qoldi?",o:["3","5","6","8"],k:0,s:"8 − 2 − 3 = 3."},
{t:"Kvadrat ikkala diagonali bo'yicha kesildi. Nechta uchburchak chiqdi?",o:["4","2","3","8"],k:0,s:"Birinchi diagonal — 2 uchburchak, ikkinchisi ularning har birini yana ikkiga bo'ladi: 4."},
{t:"Ikkita bir xil kvadratni yonma-yon qo'yib qanday shakl hosil qilish mumkin?",o:["to'g'ri to'rtburchak","uchburchak","doira","beshburchak"],k:0,s:"Ikki kvadrat yonma-yon — bo'yi enidan 2 marta uzun to'g'ri to'rtburchak."},
{t:"Lenta 4 joyidan kesildi. Nechta bo'lak chiqdi?",o:["5","4","3","8"],k:0,s:"Kesiklar bo'laklardan bitta kam: 4 kesik — 5 bo'lak."},
{t:"Lentani 6 ta bo'lakka bo'lish uchun uni necha joyidan kesish kerak?",o:["5","6","7","3"],k:0,s:"Bo'laklar 6 — kesiklar bitta kam: 5."},
{t:"To'g'ri to'rtburchakni bitta to'g'ri kesish bilan qaysi shakllarga ajratib bo'lmaydi?",o:["ikkita doira","ikkita uchburchak","ikkita to'rtburchak","uchburchak va beshburchak"],k:0,s:"To'g'ri kesish bilan egri chegarali doira chiqmaydi."},
{t:"Kvadratdan tomoni teng 4 ta kvadratcha kesib olindi va ulardan bitta katta to'g'ri to'rtburchak (bir qatorda) yig'ildi. Bo'yi enidan necha marta uzun?",o:["4","2","1","8"],k:0,s:"4 ta kvadratcha bir qatorda: bo'yi 4 kvadratcha, eni 1 — 4 marta."},
{t:"Tangram nechta bo'lakdan iborat?",o:["7","5","9","4"],k:0,s:"Tangram — 7 bo'lak: 5 uchburchak, 1 kvadrat, 1 parallelogramm."},
{t:"Kvadrat 2 ta kesik bilan 4 ta teng kvadratchaga bo'lindi. Har bir kvadratchani yana xuddi shunday 4 ga bo'lsak, jami nechta kvadratcha bo'ladi?",o:["16","8","12","20"],k:0,s:"4 ta kvadratchaning har biri 4 ga: 4 · 4 = 16."},
{t:"Tomoni 4 sm bo'lgan kvadratdan eni 1 sm, bo'yi 4 sm bo'lgan nechta tasma qirqib olish mumkin?",o:["4","16","8","1"],k:0,s:"Kvadrat eni 4 sm, har tasma 1 sm: 4 ta tasma."}
];
function PRACT_STAGE(){f8Grid(3)}
var PREP_DATA={teach:["Shaklni bitta to'g'ri kesish bilan bo'laklarga ajratish.","Bo'laklardan shakl yig'ish (uchburchaklardan kvadrat).","Kvadratni teng kvadratchalarga bo'lish; kesiklar sonini topish.","Murakkab qism: pirogni kesish (2, 4, 7), kattadan kichiklarni qirqish (4 × 4 = 16)."],
 mist:["To'g'ri kesish bilan doira chiqadi deb o'ylaydi.","8 sm kvadratdan 2 sm kvadratlar sonini 4 deydi (faqat bir qator).","3 kesikdan 6 bo'lak deydi (kesishish nuqtalarini hisobga olmaydi).","Kesiklar sonini bo'laklar soniga teng deb hisoblaydi."],
 need:["Qog'oz kvadratlar, qaychi.","Kartondan tangram to'plami."],
 board:["Kvadrat: tik kesish → 2 to'rtburchak; diagonal → 2 uchburchak.","2 × 2 → 2 kesik; 3 × 3 → 4 kesik.","Pirog: 1 → 2, 2 → 4, 3 → 7 bo'lak.","8 sm : 2 sm = 4, <span class='w2'>4 × 4 = 16</span>.","Bo'yi enidan 2 marta uzun to'rtburchak → 2 ta kvadrat."]};
