var CODE='2F2',TITLE='2-sinf · Siniq chiziq va uning uzunligi';
function f2_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f2_grid(){var g=S.g;for(var x=20;x<=340;x+=20)E('line',{x1:x,y1:10,x2:x,y2:166,stroke:'#eef2f6'},g);for(var y=10;y<=166;y+=20)E('line',{x1:20,y1:y,x2:340,y2:y,stroke:'#eef2f6'},g)}
function f2_pt(x,y,lab,col){E('circle',{cx:x,cy:y,r:5,fill:col||C.blue,stroke:'#fff','stroke-width':1.5},S.g);if(lab)T(S.g,x,y-10,lab,{'font-size':13,'font-weight':800,fill:col||C.blue})}
// asosiy siniq chiziq ABCDE: bo'g'inlar 3, 5, 2, 4 sm (1 sm = 20 px)
var F2_PTS=[[40,130],[100,130],[100,30],[140,30],[220,30]];
function f2_line(pts,labs,lens,hi,col){var g=S.g;for(var i=0;i<pts.length-1;i++){var a=pts[i],b=pts[i+1];E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:hi!=null&&i<=hi?(col||C.a2):'#1d2b3a','stroke-width':hi===i?6:3.5,'stroke-linecap':'round'},g);
 if(lens)T(g,(a[0]+b[0])/2+(a[0]===b[0]?16:0),(a[1]+b[1])/2+(a[1]===b[1]?(a[1]<70?18:-8):4),lens[i]+' sm',{'font-size':12,'font-weight':800,fill:C.ok})}
 pts.forEach(function(p,i){f2_pt(p[0],p[1],labs?labs[i]:null)})}
var F2_LEN=[3,5,2,4];
function f2_main(hi){clear();f2_grid();var pts=[[40,140],[100,140],[100,40],[140,40],[220,40]];f2_line(pts,['A','B','C','D','E'],F2_LEN,hi);var s=0,parts=[];for(var i=0;i<=(hi==null?-1:hi);i++){s+=F2_LEN[i];parts.push(F2_LEN[i])}
 f2_msg(hi==null?'ABCDE siniq chiziq: <b>4 ta bo‘g‘in</b>, <b>5 ta uch</b>':(parts.join(' + ')+' = <b>'+s+' sm</b>'+(hi===3?' — siniq chiziqning uzunligi':'')))}
var F2_P2=[function(){f2_main(null)},function(){f2_main(0)},function(){f2_main(1)},function(){f2_main(2)},function(){f2_main(3)}];
function f2_cmp(k){clear();f2_grid();var A=[40,140],B=[300,140];
 var br=[[40,140],[100,60],[180,120],[240,40],[300,140]];
 if(k>=0){var g=S.g;for(var i=0;i<br.length-1;i++)E('line',{x1:br[i][0],y1:br[i][1],x2:br[i+1][0],y2:br[i+1][1],stroke:C.a2,'stroke-width':3.5,'stroke-linecap':'round'},g)}
 if(k>=1)E('line',{x1:A[0],y1:A[1],x2:B[0],y2:B[1],stroke:C.ok,'stroke-width':4,'stroke-linecap':'round'},S.g);
 f2_pt(A[0],A[1],'A');f2_pt(B[0],B[1],'B');
 if(k===2){clear();var g=S.g;T(g,24,58,'kesma',{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});E('line',{x1:24,y1:70,x2:24+260*0.75,y2:70,stroke:C.ok,'stroke-width':6,'stroke-linecap':'round'},g);T(g,24+260*0.75+8,74,'260',{'font-size':11,fill:C.ok,'text-anchor':'start'});
  T(g,24,108,'siniq chiziq (to\u2018g\u2018rilangan)',{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'start'});E('line',{x1:24,y1:120,x2:24+417*0.75,y2:120,stroke:C.a2,'stroke-width':6,'stroke-linecap':'round'},g);T(g,24+417*0.75-10,140,'417',{'font-size':11,fill:C.a2});f2_msg('Siniq chiziqni to\u2018g\u2018rilab qo\u2018ysak — u kesmadan <b>uzun</b> chiqadi');return}
 f2_pt(A[0],A[1],'A');f2_pt(B[0],B[1],'B');
 if(k===2){var y=160,x=40,lens=[89,100,100,108];E('line',{x1:40,y1:y,x2:300,y2:y,stroke:C.ok,'stroke-width':4},S.g);var tot=0;lens.forEach(function(l){tot+=l});T(S.g,180,y-6,'',{});
  E('line',{x1:40,y1:y+8,x2:40+tot*0.75,y2:y+8,stroke:C.a2,'stroke-width':4},S.g)}
 f2_msg(k===0?'A dan B ga <b>siniq chiziq</b> bo‘ylab yo‘l':(k===1?'Endi to‘g‘ridan-to‘g‘ri — <b>kesma</b> AB':'Siniq chiziqni to‘g‘rilab qo‘ysak — u kesmadan <b>uzun</b> chiqadi'))}
var F2_P5=[function(){f2_cmp(0)},function(){f2_cmp(1)},function(){f2_cmp(2)}];
var F2_P6=[function(){clear();f2_units(0)},function(){clear();f2_units(1)},function(){clear();f2_units(2)}];
function f2_units(k){var g=S.g;var lab=k===0?['40 sm','3 dm','2 dm','50 sm']:['40 sm','30 sm','20 sm','50 sm'];var pts=[[30,130],[110,130],[150,70],[220,70],[320,130]];
 for(var i=0;i<4;i++){var a=pts[i],b=pts[i+1];E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:k===1&&(i===1||i===2)?C.bad:'#1d2b3a','stroke-width':3.5},g);T(g,(a[0]+b[0])/2+(a[1]===b[1]?0:(a[1]>b[1]?-18:18)),(a[1]+b[1])/2-8,lab[i],{'font-size':12,'font-weight':800,fill:k===1&&(i===1||i===2)?C.bad:C.ok})}
 pts.forEach(function(p){f2_pt(p[0],p[1])});
 f2_msg(k===0?'Bo‘g‘inlar: 40 sm, 3 dm, 2 dm, 50 sm — birliklar <b>har xil</b>!':(k===1?'Avval bir xil birlikka: 3 dm = 30 sm, 2 dm = 20 sm':'40 + 30 + 20 + 50 = <b>140 sm = 14 dm</b>'))}
var F2_P7=[function(){f2_miss(0)},function(){f2_miss(1)},function(){f2_miss(2)}];
function f2_miss(k){clear();var g=S.g,x0=30,u=15;var L=[5,7,4,4];var cols=[C.b,C.b,C.b,k>=2?C.ok:'#fff'];var x=x0;
 E('rect',{x:x0,y:70,width:20*u,height:34,fill:'none',stroke:C.line,'stroke-width':2},g);
 L.forEach(function(l,i){E('rect',{x:x,y:70,width:l*u,height:34,fill:cols[i],stroke:C.line,'stroke-width':1.5},g);T(g,x+l*u/2,92,i<3?l+' sm':(k>=2?'4 sm':'?'),{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=l*u});
 Br(x0,x0+20*u,64,'butun siniq chiziq: 20 sm',true);if(k>=1)Br(x0,x0+16*u,110,'5 + 7 + 4 = 16 sm',false,C.a2);
 f2_msg(k===0?'4 bo‘g‘inli siniq chiziq 20 sm. Uchtasi: 5, 7, 4 sm. To‘rtinchisi?':(k===1?'Ma’lum uchtasi birga: 5 + 7 + 4 = <b>16 sm</b>':'To‘rtinchisi: 20 − 16 = <b>4 sm</b>'))}
var STEPS=[
{h:"Siniq chiziqni o'zingiz chizing",sum:"Siniq chiziq — kesmalar ketma-ket ulanib hosil bo'ladi. Kesmalar — bo'g'inlar, ular tutashgan nuqtalar — uchlar.",a:"m01",
 start:function(){clear();f2_grid();S.bp=[];f2_msg('Katakli qog‘ozdagi nuqtalarni ketma-ket bosing (kamida 4 ta)');var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},S.g);r.addEventListener('click',function(ev){var b=sv.getBoundingClientRect(),x=Math.round(((ev.clientX-b.left)*360/b.width)/20)*20,y=Math.round(((ev.clientY-b.top)*174/b.height-10)/20)*20+10;if(S.bp.length>=6)return;S.bp.push([x,y]);var n=S.bp.length;if(n>1){var a=S.bp[n-2];E('line',{x1:a[0],y1:a[1],x2:x,y2:y,stroke:'#1d2b3a','stroke-width':3.5,'stroke-linecap':'round'},S.g)}f2_pt(x,y,'ABCDEF'[n-1]);f2_msg('Uchlar: <b>'+n+'</b> ta, bo‘g‘inlar: <b>'+Math.max(0,n-1)+'</b> ta');if(n===4&&S.d1)S.d1()})},
 fin:function(){f2_main(null)},
 html:"<p>Bir nechta kesmani <b>ketma-ket</b> ulasak — <b>siniq chiziq</b> hosil bo'ladi. Katakli qog'ozdagi nuqtalarni ketma-ket bosib, o'zingiz siniq chiziq chizing.</p>",
 act:function(c,done){S.d1=function(){S.d1=null;done()};c.querySelector('.hint').textContent='Sahnada 4 ta nuqtani ketma-ket bosing.'},
 after:"<p>Har bir kesma — <b>bo'g'in</b>. Bo'g'inlar tutashgan nuqtalar — <b>uchlar</b>. Siniq chiziq nomi uchlari bo'yicha o'qiladi: <b>ABCD</b>.</p><p>Qarang: uchlar doim bo'g'inlardan <b>bitta ko'p</b>.</p>",
 q:{t:"Siniq chiziqning 3 ta bo'g'ini bor. Uning nechta uchi bor?",opts:["3","4","6","2"],ok:1,why:"Uchlar bo'g'inlardan bitta ko'p: 3 + 1 = 4.",hint:"O'zingiz chizgan siniq chiziqda uchlar va bo'g'inlarni solishtiring.",full:"Har bo'g'inning boshi va oxiri bor, lekin qo'shni bo'g'inlar bitta uchni bo'lishadi. Shuning uchun uchlar bo'g'inlardan 1 ta ko'p: 3 bo'g'in — 4 uch."},
 tn:"Daftarda katakli qog'ozda bolalar 3, 4, 5 bo'g'inli siniq chiziq chizib, uchlarini sanasin. «Uchlar = bo'g'inlar + 1» ni o'zlari topsin."},
{h:"Siniq chiziqning uzunligi",sum:"Siniq chiziqning uzunligi — barcha bo'g'inlar uzunliklarining yig'indisi: 3 + 5 + 2 + 4 = 14 sm.",a:"m02",
 start:function(){startPh(F2_P2)},fin:function(){S.ph=4;F2_P2[4]()},
 html:"<p>ABCDE siniq chiziq bo'ylab chumoli yuradi. U jami qancha yo'l yuradi? Har bo'g'inni bittalab qo'shib boramiz.</p>",
 btns:[phaser(F2_P2,'▶ Keyingi bo‘g‘in')],
 after:"<p>Siniq chiziqning uzunligi = <b>barcha bo'g'inlar yig'indisi</b>: 3 + 5 + 2 + 4 = <b>14 sm</b>. Hech bir bo'g'inni tashlab ketmaslik uchun ularni tartib bilan, boshidan oxirigacha qo'shing.</p>",
 q:{t:"Siniq chiziq 4 ta bo'g'indan iborat, har bir bo'g'in 6 sm. Siniq chiziqning uzunligi qancha?",opts:["10 sm","18 sm","24 sm","30 sm"],ok:2,why:"6 + 6 + 6 + 6 = 24 sm.",hint:"4 ta bo'g'inning hammasini qo'shing.",full:"Har bo'g'in 6 sm, ular 4 ta: 6 + 6 + 6 + 6 = 24 sm. «10» — 6 + 4 qo'shilgan, «18» — bitta bo'g'in tushib qolgan."},
 tn:"Chizg'ich bilan har bo'g'inni o'lchatib, ustiga yozdiring, keyin qo'shdiring. Ip bilan ham tekshirish mumkin: ipni siniq chiziq bo'ylab qo'yib, to'g'rilab o'lchang."},
{h:"Ochiq va yopiq siniq chiziq",sum:"Oxirgi uchi birinchisiga tutashsa — yopiq siniq chiziq (ko'pburchak). Aks holda — ochiq.",a:"m03",
 start:function(){f2_open(false)},fin:function(){f2_open(true)},
 html:"<p>Siniq chiziqning oxirgi uchini birinchi uchiga ulasak nima bo'ladi? Tugmalarni bosing.</p>",
 btns:[["Ochiq",function(c,done){f2_open(false);mvK(done,2)}],["Yopiq",function(c,done){f2_open(true);mvK(done,2)}]],g2:1,
 after:"<p><b>Yopiq</b> siniq chiziq — bu <b>ko'pburchak</b>: 3 bo'g'inli — uchburchak, 4 bo'g'inli — to'rtburchak. Yopiq siniq chiziqda uchlar soni bo'g'inlar soniga <b>teng</b>.</p>",
 q:{t:"4 bo'g'inli yopiq siniq chiziq qanday shakl hosil qiladi?",opts:["Uchburchak","To'rtburchak","Beshburchak","Kesma"],ok:1,why:"4 ta bo'g'in yopilsa — 4 ta tomonli shakl, to'rtburchak.",hint:"Yopiq siniq chiziqning har bo'g'ini shaklning tomoni bo'ladi. Nechta tomon?",full:"Yopiq siniq chiziqning bo'g'inlari — shaklning tomonlari. 4 ta tomon — to'rtburchak. Uchlari ham 4 ta."},
 tn:"Bolalarga ip bering: ochiq siniq chiziq yasab, keyin uchlarini ulab yopiq qilsin."},
{h:"Eng qisqa yo'l — kesma",sum:"Ikki nuqta orasidagi eng qisqa yo'l — kesma. Siniq chiziq doim kesmadan uzun.",a:"m04",
 start:function(){startPh(F2_P5)},fin:function(){S.ph=2;F2_P5[2]()},
 html:"<p>A dan B ga ikki yo'l bor: zigzag (siniq chiziq) va to'g'ri (kesma). Qaysi biri qisqa? Kuzating.</p>",
 btns:[phaser(F2_P5)],
 after:"<p>Siniq chiziqni to'g'rilab qo'ysak, u kesmadan <b>uzun</b> chiqadi. <b>Ikki nuqta orasidagi eng qisqa yo'l — kesma</b>. Shuning uchun odamlar maydonni kesib o'tadi — burchakdan aylanib o'tgandan ko'ra yaqin.</p>",
 q:{t:"A va B nuqtalar kesma bilan ham, siniq chiziq bilan ham tutashtirilgan. Qaysi biri qisqaroq?",opts:["Siniq chiziq","Kesma","Ikkalasi teng","Bo'g'ini ko'p bo'lsa siniq chiziq"],ok:1,why:"Kesma — eng qisqa yo'l.",hint:"Zigzag yo'lni to'g'rilab qo'ysak, u kesmadan uzunmi yoki qisqami?",full:"Ikki nuqta orasidagi eng qisqa yo'l — kesma. Siniq chiziq har doim uzunroq, bo'g'inlari qancha ko'p bo'lsa ham."},
 tn:"Sinf ichida ikki bola orasiga ip tortib, keyin ipni egri qilib o'lchang — farqni ko'rsating."},
{h:"Tuzoq: birliklar har xil",sum:"40 sm, 3 dm, 2 dm, 50 sm: avval bir xil birlikka (sm) o'tamiz: 40 + 30 + 20 + 50 = 140 sm = 14 dm.",a:"m05",
 start:function(){startPh(F2_P6)},fin:function(){S.ph=2;F2_P6[2]()},
 html:"<p>Bo'g'inlar: <b>40 sm, 3 dm, 2 dm, 50 sm</b>. Shunchaki 40 + 3 + 2 + 50 = 95 deb qo'shsak — xato! Kuzating.</p>",
 btns:[phaser(F2_P6)],
 after:"<p>Qoida: qo'shishdan oldin hamma uzunliklarni <b>bir xil birlikka</b> keltiring. 1 dm = 10 sm, shuning uchun 3 dm = 30 sm, 2 dm = 20 sm. Javob: <b>140 sm = 14 dm</b>.</p>",
 q:{t:"Siniq chiziq bo'g'inlari: 1 dm, 15 sm, 2 dm. Uning uzunligi qancha?",opts:["18 sm","45 sm","4 dm","35 sm"],ok:1,why:"10 + 15 + 20 = 45 sm.",hint:"dm larni sm ga aylantiring: 1 dm = 10 sm.",full:"1 dm = 10 sm, 2 dm = 20 sm. 10 + 15 + 20 = 45 sm. «18» — birliklarga qaramay qo'shilgan (1 + 15 + 2)."},
 tn:"Bu — testlarda eng ko'p uchraydigan tuzoq. Bolalar har bir uzunlik ostiga «sm» deb yozsin, keyin qo'shsin."},
{h:"Tuzoq: noma'lum bo'g'in",sum:"Butun uzunlikdan ma'lum bo'g'inlar yig'indisini ayiramiz: 20 − (5 + 7 + 4) = 4 sm.",a:"m06",
 start:function(){startPh(F2_P7)},fin:function(){S.ph=2;F2_P7[2]()},
 html:"<p>To'rt bo'g'inli siniq chiziqning uzunligi <b>20 sm</b>. Uchta bo'g'ini 5 sm, 7 sm va 4 sm. To'rtinchi bo'g'in qancha? Chizma bilan yechamiz.</p>",
 btns:[phaser(F2_P7)],
 after:"<p>Usul: avval <b>ma'lum bo'g'inlarni</b> qo'shamiz (16 sm), keyin <b>butun uzunlikdan</b> ayiramiz: 20 − 16 = <b>4 sm</b>. Tekshirish: 5 + 7 + 4 + 4 = 20 ✓</p>",
 q:{t:"Siniq chiziq 15 sm. Uning bo'g'inlari: 4 sm, 6 sm va yana bitta. Uchinchi bo'g'in qancha?",opts:["10 sm","25 sm","5 sm","11 sm"],ok:2,why:"4 + 6 = 10, 15 − 10 = 5 sm.",hint:"Ma'lum ikkita bo'g'inni qo'shing, keyin butun uzunlikdan ayiring.",full:"Ma'lum bo'g'inlar: 4 + 6 = 10 sm. Butun — 15 sm. Uchinchisi: 15 − 10 = 5 sm. «10» — faqat ma'lumlar yig'indisi, «25» — hammasini qo'shib yuborilgan."},
 tn:"Chizma model (Singapur usuli): butun uzunlikni bitta chiziq qilib, bo'laklarga bo'ling — bolalar nima ayirilishini ko'radi."},
{h:"Bilasizmi? Tog' yo'llari nega zigzag?",sum:"Tog' yo'llari siniq chiziq shaklida (serpantin): yo'l uzunroq, lekin qiyalik kamayadi.",a:"m07",
 start:function(){f2_mount(false)},fin:function(){f2_mount(true)},
 html:"<p>⛰ Tog'ga chiqadigan yo'llar to'g'ri emas, <b>zigzag</b> bo'ladi. Nega? Kesma eng qisqa yo'l-ku! Tugmani bosing.</p>",
 btns:[["⛰ Yo'lni ko'rsatish",function(c,done){f2_mount(true);done()}]],
 after:"<p>To'g'ri yo'l juda <b>tik</b> bo'lardi — mashina chiqa olmaydi. Siniq chiziq shaklidagi yo'l (<b>serpantin</b>) uzunroq, lekin har bo'g'ini yotiqroq — chiqish oson. Masalan, Toshkentdan Farg'onaga o'tadigan Qamchiq dovonida ham shunday burilishlar bor.</p>",
 tn:"Bolalar daftarda «tog'» chizib, unga to'g'ri va zigzag yo'l chizsin — qaysi biri uzunligini chizg'ich bilan tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){f2_main(3)},fin:function(){f2_main(3)},
 html:"<div class='memo'><ul><li><b>Siniq chiziq</b> — kesmalar ketma-ket ulangan. Kesmalar — <b>bo'g'inlar</b>, tutashgan nuqtalar — <b>uchlar</b>.</li><li>Ochiq siniq chiziqda: <b>uchlar = bo'g'inlar + 1</b>.</li><li><b>Uzunligi</b> = barcha bo'g'inlar yig'indisi: 3 + 5 + 2 + 4 = 14 sm.</li><li>Birliklar har xil bo'lsa — avval bir xil birlikka: 3 dm = 30 sm.</li><li>Noma'lum bo'g'in = butun uzunlik − ma'lum bo'g'inlar.</li><li><b>Yopiq</b> siniq chiziq — ko'pburchak.</li><li>Eng qisqa yo'l — <b>kesma</b>.</li></ul></div>",
 tn:"Keyingi darsni «Uchburchak — bu qanday siniq chiziq?» savoli bilan boshlang (3 bo'g'inli yopiq)."}
];
function f2_open(cl){clear();f2_grid();var pts=[[60,140],[60,40],[200,40],[300,140]];var g=S.g;for(var i=0;i<3;i++)E('line',{x1:pts[i][0],y1:pts[i][1],x2:pts[i+1][0],y2:pts[i+1][1],stroke:'#1d2b3a','stroke-width':3.5,'stroke-linecap':'round'},g);
 if(cl){E('line',{x1:300,y1:140,x2:60,y2:140,stroke:C.ok,'stroke-width':4,'stroke-linecap':'round'},g);E('polygon',{points:pts.map(function(p){return p.join(',')}).join(' '),fill:'rgba(30,142,90,.10)'},g)}
 ['A','B','C','D'].forEach(function(l,i){f2_pt(pts[i][0],pts[i][1],l)});f2_msg(cl?'<b>Yopiq</b>: 4 bo‘g‘in, 4 uch — to‘rtburchak':'<b>Ochiq</b>: 3 bo‘g‘in, 4 uch')}
function f2_mount(on){clear('#eef6ff');var g=S.g;E('polygon',{points:'40,165 180,20 320,165',fill:'#c9b28d',stroke:'#8a6a3a','stroke-width':2},g);E('polygon',{points:'150,52 180,20 210,52 195,48 180,56 165,48',fill:'#fff'},g);
 E('line',{x1:180,y1:24,x2:180,y2:165,stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'5 4'},g);T(g,60,40,'to\u2018g\u2018ri yo\u2018l — juda tik!',{'font-size':11,fill:C.bad,'font-weight':800,'text-anchor':'start'});
 if(on){var p=[[110,165],[230,140],[130,112],[220,86],[150,62],[190,40]];for(var i=0;i<p.length-1;i++)E('line',{x1:p[i][0],y1:p[i][1],x2:p[i+1][0],y2:p[i+1][1],stroke:'#333','stroke-width':4,'stroke-linecap':'round'},g);T(g,262,132,'serpantin',{'font-size':12,'font-weight':800,fill:C.ok})}
 f2_msg(on?'Zigzag yo‘l uzun, lekin <b>yotiq</b> — chiqish oson':'To‘g‘ri yo‘l eng qisqa, lekin juda tik')}
var PROBS=[
{t:"Siniq chiziq bo'g'inlari 3 sm, 5 sm, 2 sm va 4 sm. Uning uzunligi qancha?",o:["14 sm","12 sm","10 sm","16 sm"],k:0,s:"3 + 5 + 2 + 4 = 14 sm."},
{t:"Siniq chiziqning 3 ta bo'g'ini bor. Uning nechta uchi bor?",o:["4","3","6","2"],k:0,s:"Uchlar bo'g'inlardan bitta ko'p: 4."},
{t:"Siniq chiziqning 6 ta uchi bor. U nechta bo'g'indan iborat?",o:["5","6","7","12"],k:0,s:"Bo'g'inlar uchlardan bitta kam: 6 − 1 = 5."},
{t:"Siniq chiziq 4 ta bo'g'indan iborat, har bir bo'g'in 6 sm. Uzunligi qancha?",o:["24 sm","10 sm","18 sm","30 sm"],k:0,s:"6 + 6 + 6 + 6 = 24 sm."},
{t:"To'rt bo'g'inli siniq chiziq 20 sm. Uchta bo'g'ini 5 sm, 7 sm va 4 sm. To'rtinchi bo'g'in qancha?",o:["4 sm","6 sm","16 sm","36 sm"],k:0,s:"5 + 7 + 4 = 16, 20 − 16 = 4 sm."},
{t:"Siniq chiziq bo'g'inlari: 40 sm, 3 dm, 2 dm, 50 sm. Uning uzunligi qancha?",o:["14 dm","95 sm","14 sm","14 m"],k:0,s:"40 + 30 + 20 + 50 = 140 sm = 14 dm."},
{t:"A va B nuqtalar kesma bilan ham, siniq chiziq bilan ham tutashtirilgan. Qaysi biri qisqaroq?",o:["kesma","siniq chiziq","ikkalasi teng","bo'g'ini ko'p bo'lsa siniq chiziq"],k:0,s:"Ikki nuqta orasidagi eng qisqa yo'l — kesma."},
{t:"3 bo'g'inli yopiq siniq chiziq qanday shakl?",o:["uchburchak","to'rtburchak","kvadrat","kesma"],k:0,s:"3 ta tomonli yopiq shakl — uchburchak."},
{t:"Siniq chiziqning bo'g'inlari 1 dm, 15 sm va 2 dm. Uzunligi qancha?",o:["45 sm","18 sm","35 sm","4 dm"],k:0,s:"10 + 15 + 20 = 45 sm."},
{t:"Siniq chiziq 15 sm. Bo'g'inlari 4 sm, 6 sm va yana bitta. Uchinchisi qancha?",o:["5 sm","10 sm","25 sm","11 sm"],k:0,s:"4 + 6 = 10, 15 − 10 = 5 sm."},
{t:"Chumoli 3 bo'g'inli siniq chiziq bo'ylab yurdi: 8 sm, 6 sm, 9 sm. U jami qancha yo'l yurdi?",o:["23 sm","17 sm","14 sm","32 sm"],k:0,s:"8 + 6 + 9 = 23 sm."},
{t:"Siniq chiziqning ikki bo'g'ini 12 sm va 9 sm, uchinchisi ikkinchisidan 3 sm qisqa. Siniq chiziq uzunligi?",o:["27 sm","24 sm","21 sm","33 sm"],k:0,s:"Uchinchisi: 9 − 3 = 6. 12 + 9 + 6 = 27 sm."},
{t:"Ochiq siniq chiziqda 5 ta bo'g'in bor. Uchlari nechta?",o:["6","5","4","10"],k:0,s:"5 + 1 = 6 ta uch."},
{t:"Yopiq siniq chiziqda 5 ta bo'g'in bor. Uchlari nechta?",o:["5","6","4","10"],k:0,s:"Yopiq siniq chiziqda uchlar bo'g'inlarga teng: 5."},
{t:"Siniq chiziq bo'g'inlari: 2 dm, 2 dm, 2 dm. Uzunligi necha santimetr?",o:["60 sm","6 sm","20 sm","600 sm"],k:0,s:"2 + 2 + 2 = 6 dm = 60 sm."},
{t:"Ikki xil siniq chiziq: birinchisi 7 sm, 8 sm; ikkinchisi 5 sm, 5 sm, 4 sm. Qaysi biri uzun va qanchaga?",o:["birinchisi, 1 sm ga","ikkinchisi, 1 sm ga","teng","birinchisi, 2 sm ga"],k:0,s:"Birinchisi 15 sm, ikkinchisi 14 sm. Birinchisi 1 sm uzun."},
{t:"Siniq chiziq 30 sm. Uning 3 ta bo'g'ini bir xil. Bitta bo'g'inni topish uchun qaysi tenglik to'g'ri?",o:["10 + 10 + 10 = 30","15 + 15 = 30","20 + 10 = 30","30 + 3 = 33"],k:0,s:"3 ta teng bo'g'in: 10 + 10 + 10 = 30. Har biri 10 sm."},
{t:"Siniq chiziqdan bitta 5 sm li bo'g'in olib tashlandi, endi u 17 sm. Avval qancha edi?",o:["22 sm","12 sm","17 sm","5 sm"],k:0,s:"17 + 5 = 22 sm."},
{t:"ABCD siniq chiziqda AB = 4 sm, BC = 3 sm, CD esa AB va BC birga olinganidan 2 sm qisqa. Siniq chiziq uzunligi?",o:["12 sm","9 sm","14 sm","5 sm"],k:0,s:"AB + BC = 7, CD = 7 − 2 = 5. 4 + 3 + 5 = 12 sm."},
{t:"Siniq chiziqni to'g'rilab, kesma bilan solishtirdik. Siniq chiziq qanday chiqadi?",o:["uzunroq","qisqaroq","teng","ba'zan qisqaroq"],k:0,s:"Siniq chiziq har doim o'sha uchlarni tutashtiruvchi kesmadan uzun."}
];
function PRACT_STAGE(){f2_main(3)}
var PREP_DATA={teach:["Siniq chiziq, bo'g'in, uch; nomlanishi (ABCD).","Uzunligi — bo'g'inlar yig'indisi.","Ochiq va yopiq siniq chiziq; yopiq — ko'pburchak.","Eng qisqa yo'l — kesma.","Tuzoqlar: har xil birliklar, noma'lum bo'g'in."],
 mist:["Uchlar va bo'g'inlarni aralashtiradi.","Birliklarni (dm, sm) birxillashtirmasdan qo'shadi.","Bitta bo'g'inni tashlab ketadi.","Noma'lum bo'g'inda hamma sonlarni qo'shib yuboradi."],
 need:["Katakli qog'oz, chizg'ich.","Ip (siniq chiziq uzunligini to'g'rilab o'lchash uchun)."],
 board:["Siniq chiziq ABCDE: 4 bo'g'in, 5 uch.","<span class='w2'>3 + 5 + 2 + 4 = 14 sm</span>.","<span class='w2'>3 dm = 30 sm</span>: <span class='w2'>40 + 30 + 20 + 50 = 140 sm</span>.","Noma'lum: <span class='w2'>20 − 16 = 4 sm</span>.","Yopiq siniq chiziq = ko'pburchak."]};
