// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4Y6',TITLE='4-sinf · Ma‘lumotlar tahlili va diagrammalar bo‘yicha murakkab masalalar';
var Y6V=[3,7,5,9];
function y6level(st){clear();y4title('4 qutidagi koptoklar: 3, 7, 5, 9');var vals=st>=2?[6,6,6,6]:Y6V,cols=[C.b,C.b,C.b,C.b];var A=y4bars({x0:44,x1:340,yb:146,yt:34,min:0,max:10,step:2,n:4,labels:['1','2','3','4']},vals,cols,true);
 if(st===1){var g=S.g;E('line',{x1:44,y1:A.Y(6),x2:340,y2:A.Y(6),stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 3'},g);y4T(g,334,A.Y(6)-6,'6',{'font-size':12,'font-weight':800,fill:C.bad,'text-anchor':'end'});
  y4arrow(A.X(1)+14,A.X(0)+14,A.Y(6.5),'',C.a2);y4arrow(A.X(3)-14,A.X(2)+14,A.Y(7.5),'',C.a2)}
 if(st>=2)y4T(S.g,330,40,'24 : 4 = 6',{'font-size':13,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
var Y6P1=[function(){y6level(0);calc(['Hammasini teng qilib qayta taqsimlasak, har qutida nechta bo‘ladi?'])},function(){y6level(1);calc(['Ortiqchasini kamiga beramiz: 7 → 3 ga 3 ta, 9 → 5 ga 1 ta… yo‘q, 9 dan 3 ta, 7 dan 1 ta'])},function(){y6level(2);calc(['Hammasi <b>6</b> tadan — bu <b>o‘rta arifmetik</b>','Hisob: yig‘indi : soni = 24 : 4 = 6'])}];
function y6new(sh){clear();y4title('4 bola o‘rtacha 30 kg. 5-bola qo‘shilgach, o‘rtacha 32 kg');var g=S.g;
 for(var i=0;i<5;i++){var x=40+i*62;E('rect',{x:x,y:50,width:46,height:56,rx:6,fill:i<4?'#cfe6fa':'#ffe1b0',stroke:'#8a99a8'},g);y4T(g,x+23,84,i<4?'30':(sh?'40':'?'),{'font-size':14,'font-weight':800,fill:i<4?'#1d2b3a':C.bad})}
 if(sh){y4T(g,180,130,'avval jami: 4 · 30 = 120; keyin jami: 5 · 32 = 160',{'font-size':11,'font-weight':800});y4T(g,180,152,'5-bola: 160 − 120 = 40 kg',{'font-size':13,'font-weight':800,fill:C.ok})}}
function y6miss(sh){clear();y4title('5 sonning o‘rtachasi 7: 4, 9, 6, 10 va ?');var g=S.g;[4,9,6,10,sh?6:'?'].forEach(function(v,i){var x=50+i*62;E('rect',{x:x-22,y:46,width:44,height:40,rx:6,fill:i===4?'#fff3c4':'#fff',stroke:'#8a99a8'},g);y4T(g,x,73,String(v),{'font-size':15,'font-weight':800,fill:i===4?C.bad:'#1d2b3a'})});
 if(sh){y4T(g,180,118,'kerakli jami: 5 · 7 = 35; borlari: 4 + 9 + 6 + 10 = 29',{'font-size':11,'font-weight':800});y4T(g,180,142,'? = 35 − 29 = 6',{'font-size':14,'font-weight':800,fill:C.ok})}}
function y6trick(sh){clear();y4title('Ikki do‘kon savdosi (o‘q 50 dan boshlangan!)');var A=y4bars({x0:60,x1:300,yb:146,yt:36,min:50,max:57,step:1,n:2,labels:['A do‘kon','B do‘kon']},[52,56],[C.b,C.a],true);
 if(sh){y4T(S.g,330,70,'farq:',{'font-size':11,'font-weight':800,'text-anchor':'end'});y4T(S.g,330,88,'4 ta',{'font-size':14,'font-weight':800,fill:C.ok,'text-anchor':'end'})}}
var Y6M=[12,18,15,24,21];
function y6month(sh){clear();y4title('Har oyda kitob o‘qigan bolalar');var A=y4bars({x0:44,x1:340,yb:146,yt:34,min:0,max:30,step:5,n:5,labels:['Yan','Fev','Mar','Apr','May']},Y6M,null,true);
 if(sh){E('line',{x1:44,y1:A.Y(18),x2:340,y2:A.Y(18),stroke:C.ok,'stroke-width':2,'stroke-dasharray':'5 3'},S.g);y4T(S.g,46,A.Y(18)-5,'o‘rtacha 18',{'font-size':10,'font-weight':800,fill:C.ok,'text-anchor':'start'})}}
function y6dist(st){clear();y4title('Velosipedchi: masofa (km) va vaqt (soat)');var A=y4axes({x0:44,x1:330,yb:146,yt:30,min:0,max:60,step:10,n:5,labels:['0','1','2','3','4']});
 var P=[[0,0],[1,20],[2,20],[3,50],[4,60]],d='';P.forEach(function(p,i){d+=(i?' L':'M')+A.X(p[0])+' '+A.Y(p[1])});E('path',{d:d,fill:'none',stroke:C.a2,'stroke-width':3},S.g);P.forEach(function(p){E('circle',{cx:A.X(p[0]),cy:A.Y(p[1]),r:4,fill:C.a2},S.g)});
 if(st===1){E('line',{x1:A.X(1),y1:A.Y(20),x2:A.X(2),y2:A.Y(20),stroke:C.bad,'stroke-width':6,opacity:.5},S.g);y4T(S.g,(A.X(1)+A.X(2))/2,A.Y(20)+18,'to‘xtagan',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(st===2){E('line',{x1:A.X(2),y1:A.Y(20),x2:A.X(3),y2:A.Y(50),stroke:C.ok,'stroke-width':6,opacity:.5},S.g);y4T(S.g,A.X(2)+6,A.Y(42),'+30 km — eng tik',{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'end'})}}
var Y6P6=[function(){y6dist(0);calc(['Chiziq yuqoriga — yurayapti; gorizontal — joyida turibdi'])},function(){y6dist(1);calc(['1 dan 2 soatgacha masofa o‘zgarmagan (20 km) — <b>to‘xtagan</b>'])},function(){y6dist(2);calc(['Eng tik bo‘lak: 2 → 3 soat, 30 km — eng katta tezlik <b>30 km/soat</b>','O‘rtacha tezlik: 60 km : 4 soat = 15 km/soat'])}];
function y6share(sh){clear();y4title('A sinf: 20 bola, 5 a‘lochi. B sinf: 25 bola, 5 a‘lochi');var g=S.g;
 function row(y,n,k,lab){for(var i=0;i<n;i++)E('circle',{cx:30+i*12,cy:y,r:5,fill:i<k?C.a:'#e3e8ee'},g);y4T(g,30+n*12+8,y+4,lab,{'font-size':11,'font-weight':800,'text-anchor':'start'})}
 row(60,20,5,'A');row(100,25,5,'B');if(sh){y4T(g,110,140,'A: 5/20 = 1/4',{'font-size':13,'font-weight':800,fill:C.ok});y4T(g,250,140,'B: 5/25 = 1/5',{'font-size':13,'font-weight':800,fill:C.blue})}}
function y6concl(){clear();y4title('Sinfdagi 30 boladan 18 tasi ertalab nonushta qiladi');y4pie(90,100,56,[[216,C.a,'18'],[144,'#e3e8ee','12']],14);var g=S.g;y4T(g,240,80,'18 > 15 (yarmi)',{'font-size':13,'font-weight':800,fill:C.ok});y4T(g,240,110,'faqat SHU sinf haqida',{'font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y6snow(st){clear();y4title('London, 1854: Jon Snou xaritasi');var g=S.g;for(var i=0;i<6;i++){E('line',{x1:20,y1:36+i*24,x2:340,y2:36+i*24,stroke:'#e3e8ee','stroke-width':6},g);E('line',{x1:30+i*60,y1:30,x2:30+i*60,y2:166,stroke:'#e3e8ee','stroke-width':6},g)}
 var D=[[150,90],[160,96],[142,104],[170,84],[156,112],[134,92],[176,104],[148,78],[164,120],[128,108],[182,94],[140,118],[172,116],[158,72],[120,96],[190,110],[230,140],[60,50],[280,60]];
 D.forEach(function(d){E('rect',{x:d[0]-3,y:d[1]-3,width:6,height:6,fill:'#1d2b3a'},g)});
 if(st>=1){E('circle',{cx:155,cy:98,r:9,fill:C.blue,stroke:'#fff','stroke-width':2},g);E('circle',{cx:155,cy:98,r:44,fill:'none',stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'5 3'},g);y4T(g,250,98,'suv nasosi',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'start'})}}
var Y6P9=[function(){y6snow(0);calc(['Har qora nuqta — vabodan kasal bo‘lgan uy'])},function(){y6snow(1);calc(['Nuqtalar bitta <b>suv nasosi</b> atrofida to‘plangan! Nasos yopildi — kasallik kamaydi'])}];
function PRACT_STAGE(){clear();y4title('Tahlil: o‘q, shkala, jami, o‘rtacha');y4bars({x0:44,x1:340,yb:146,yt:34,min:0,max:10,step:2,n:4,labels:['A','B','C','D']},[4,8,6,6],null,true);calc(['O‘rtacha = yig‘indi : soni. Jami = o‘rtacha · soni'])}
var STEPS=[
{h:"O'rta arifmetik: tenglashtirish",sum:"3, 7, 5, 9 ni tenglashtirsak — 6 tadan. (3 + 7 + 5 + 9) : 4 = 6.",a:"m01",
 start:function(){startPh(Y6P1)},fin:function(){S.ph=2;Y6P1[2]()},
 html:"<p><b>O'rta arifmetik</b> nima? Tasavvur qiling: qutilardagi koptoklarni hamma qutida bir xil bo'lguncha qayta taqsimlaymiz. Bosing:</p>",btns:[phaser(Y6P1)],
 after:"<p>O'rta arifmetik = <b>yig'indi : sonlar soni</b>. U «hammaga teng bo'lib berilsa, har biriga qancha tegadi» degani. Teskari: <b>jami = o'rtacha · soni</b> — murakkab masalalarning kaliti shu.</p>",
 q:{t:"5 bolaning bo'yi: 130, 128, 135, 132, 125 sm. O'rtacha bo'y?",opts:["130 sm","128 sm","135 sm","650 sm"],ok:0,why:"Yig'indi 650; 650 : 5 = 130.",hint:"Avval hammasini qo'shing.",full:"130 + 128 + 135 + 132 + 125 = 650; 650 : 5 = 130 sm. «650» — 5 ga bo'lishni unutish, «135» — eng kattasi."},
 tn:"Bolalar qo'lidagi qalamlarni (har xil soni) stolga qo'yib, teng taqsimlash orqali o'rtachani topsin."},
{h:"Yangi qiymat qo'shilganda",sum:"Avval 4 · 30 = 120, keyin 5 · 32 = 160. Yangi bola: 160 − 120 = 40 kg.",a:"m02",
 start:function(){y6new(0);calc(['5-bolaning vazni qancha?'])},fin:function(){y6new(1);y4msg('5-bola: <b>40</b> kg')},
 html:"<p>4 bolaning o'rtacha vazni 30 kg. 5-bola qo'shilgach, o'rtacha 32 kg bo'ldi. 5-bola necha kg?</p>",
 btns:y4pick(0,[["40 kg","Jami: avval 120, keyin 160. Farq 40 — yangi bola."],["32 kg","32 — yangi o'rtacha, bola vazni emas. U o'rtachani ko'targan, demak og'irroq."],["34 kg","30 + 32 … qo'shib bo'lib bo'lmaydi; jamilar orqali hisoblang."],["2 kg","32 − 30 — o'rtacha qanchaga oshgani."]],function(){y6new(1)}),g2:1,
 after:"<p>O'rtacha bilan to'g'ridan ishlab bo'lmaydi — avval <b>jamilarga</b> o'ting: jami = o'rtacha · soni. Keyin jamilar farqi — yangi (yoki olib tashlangan) qiymat.</p>",
 q:{t:"6 ta sonning o'rtachasi 10. Bittasi o'chirilgach, qolgan 5 tasining o'rtachasi 9. O'chirilgan son?",opts:["15","1","10","19"],ok:0,why:"60 − 45 = 15.",hint:"Avvalgi va keyingi jamilarni toping.",full:"Avval jami: 6 · 10 = 60. Keyin: 5 · 9 = 45. O'chirilgan: 60 − 45 = 15. «1» — o'rtachalar farqi."},
 tn:"Doskada ikki ustun: «soni | o'rtacha | jami». Bolalar har gal jamini to'ldirsin."},
{h:"Yetishmagan qiymat",sum:"Kerakli jami 5 · 7 = 35; borlari 29; yetishmagan 6.",a:"m03",
 start:function(){y6miss(0);calc(['Beshinchi son nechaga teng?'])},fin:function(){y6miss(1);y4msg('? = <b>6</b>')},
 html:"<p>5 ta sonning o'rtachasi 7. To'rttasi ma'lum: 4, 9, 6, 10. Beshinchisi nechaga teng?</p>",
 btns:y4pick(0,[["6","Jami 5 · 7 = 35, borlari 29: 35 − 29 = 6."],["7","Hamma son o'rtachaga teng bo'lishi shart emas."],["29","29 — ma'lum sonlar yig'indisi."],["8","Hisobni tekshiring: 4 + 9 + 6 + 10 = 29."]],function(){y6miss(1)}),g2:1,
 after:"<p>Usul o'sha: <b>kerakli jami</b> (o'rtacha · soni) − <b>bor jami</b> = yetishmagan qiymat. Tekshiring: (4 + 9 + 6 + 10 + 6) : 5 = 7 ✓.</p>",
 q:{t:"Bir haftada (7 kun) o'rtacha harorat 20°. Birinchi 6 kunning o'rtachasi 19°. 7-kun harorati?",opts:["26°","20°","21°","1°"],ok:0,why:"7 · 20 − 6 · 19 = 140 − 114 = 26.",hint:"Hafta jami va 6 kun jamini toping.",full:"Hafta: 7 · 20 = 140. 6 kun: 6 · 19 = 114. 7-kun: 140 − 114 = 26°. «21°» — 20 + 1, «1°» — o'rtachalar farqi."},
 tn:"Haqiqiy ma'lumot: sinfning bir haftalik davomati. Bir kun noma'lum — bolalar o'rtachadan topsin."},
{h:"Tuzoq: aldovchi diagramma",sum:"O'q 50 dan boshlangan: ustun 3 marta baland ko'rinadi, aslida farq atigi 4 (52 va 56).",a:"m04",
 start:function(){y6trick(0);calc(['B do‘kon A dan ancha ko‘p sotganmi?'])},fin:function(){y6trick(1);y4msg('Farq atigi <b>4 ta</b> (52 va 56)')},
 html:"<p>Reklamada ikki do'kon savdosi ko'rsatilgan. B ning ustuni A nikidan 3 baravar baland. To'g'ri xulosa qaysi?</p>",
 btns:y4pick(1,[["B 3 marta ko'p sotgan","Ustun balandligi aldaydi: o'q 0 dan emas, 50 dan boshlangan."],["B biroz ko'p: 4 taga","A — 52, B — 56. Farq 4, ya'ni deyarli teng."],["A ko'p sotgan","A ning ustuni past — A kam sotgan."],["Teng sotgan","52 va 56 teng emas."]],function(){y6trick(1)}),g2:1,
 after:"<p>Diagrammaga ishonishdan oldin <b>o'qning boshlanishini</b> tekshiring. O'q 0 dan boshlanmasa, kichik farq juda katta ko'rinadi. Reklama va yangiliklarda bu usul ko'p ishlatiladi.</p>",
 q:{t:"Diagrammada o'q 100 dan boshlanadi. A — 104, B — 108. Haqiqatda B A dan necha taga ko'p?",opts:["4 taga","2 marta","8 taga","104 taga"],ok:0,why:"108 − 104 = 4.",hint:"Ustunlarga emas, sonlarga qarang.",full:"Haqiqiy sonlar: 104 va 108. Farq 4. «2 marta» — ustun balandligiga (4 va 8) qarab aldanish."},
 tn:"Bolalar ikki xil diagramma chizsin: biri 0 dan, biri 50 dan. Qaysi biri halol? Muhokama."},
{h:"Diagrammadan o'rtacha va o'sish",sum:"(12 + 18 + 15 + 24 + 21) : 5 = 18. Eng katta o'sish: mart → aprel (+9).",a:"m05",
 start:function(){y6month(0);calc(['Oyiga o‘rtacha nechta bola kitob o‘qigan?'])},fin:function(){y6month(1);y4msg('O‘rtacha <b>18</b> bola')},
 html:"<p>Ustunli diagramma: besh oy davomida kitob o'qigan bolalar soni. Oyiga o'rtacha nechta bola?</p>",
 btns:y4pick(0,[["18","12 + 18 + 15 + 24 + 21 = 90; 90 : 5 = 18."],["15","15 — mart oyi. O'rtachani hisoblash kerak."],["24","24 — eng ko'p oy (aprel)."],["90","90 — jami. Uni oylar soniga bo'ling."]],function(){y6month(1)}),g2:1,
 after:"<p>O'rtacha chizig'i ustunlarni «tenglashtiradi»: undan yuqoridagi ortiqchalar pastdagi kamlarni to'ldiradi (6 + 3 = 6 + 3). O'sishni topish uchun <b>ketma-ket</b> ustunlar farqiga qarang.</p>",
 q:{t:"Shu diagrammada qaysi ikki ketma-ket oy orasida o'sish eng katta?",opts:["Mart – Aprel","Yanvar – Fevral","Aprel – May","Fevral – Mart"],ok:0,why:"15 → 24: +9.",hint:"Ketma-ket ustunlar farqini hisoblang.",full:"Yan→Fev +6, Fev→Mar −3, Mar→Apr +9, Apr→May −3. Eng katta o'sish — Mart–Aprel."},
 tn:"Sinf o'zi 5 kunlik kuzatuv o'tkazsin (masalan, maktabga piyoda kelganlar) va diagramma chizsin."},
{h:"Masofa–vaqt grafigi",sum:"Gorizontal bo'lak — to'xtash. Eng tik bo'lak — eng katta tezlik (2 → 3 soat, 30 km/soat).",a:"m06",
 start:function(){startPh(Y6P6)},fin:function(){S.ph=2;Y6P6[2]()},
 html:"<p>Grafikda velosipedchining yo'li ko'rsatilgan. Uning harakatini o'qiymiz. Bosing:</p>",btns:[phaser(Y6P6)],
 after:"<p>Masofa–vaqt grafigida: chiziq <b>tik</b> — tez; <b>yotiq</b> (gorizontal) — to'xtagan; har bo'lakdagi tezlik = masofa o'zgarishi : vaqt.</p>",
 q:{t:"Grafik bo'yicha butun yo'ldagi o'rtacha tezlik?",opts:["15 km/soat","30 km/soat","20 km/soat","60 km/soat"],ok:0,why:"60 km : 4 soat = 15.",hint:"Jami yo'l : jami vaqt.",full:"Jami 60 km, jami 4 soat (to'xtash ham kiradi): 60 : 4 = 15 km/soat. «30» — eng tez bo'lak, «20» — 1-soatdagi tezlik."},
 tn:"Bolalar o'z kunining «masofa–vaqt» grafigini chizsin: uydan maktabga, tanaffus, qaytish."},
{h:"Son emas — ulush",sum:"A: 5/20 = 1/4, B: 5/25 = 1/5. Soni teng, ulushi A da katta.",a:"m07",
 start:function(){y6share(0);calc(['Qaysi sinfda a‘lochilar ulushi katta?'])},fin:function(){y6share(1);y4msg('<b>A sinfda</b>: 1/4 > 1/5')},
 html:"<p>Ikki sinfda 5 tadan a'lochi bor. Qaysi sinfda a'lochilar <b>ulushi</b> katta?</p>",
 btns:y4pick(0,[["A sinfda","5/20 = 1/4, 5/25 = 1/5. Chorak beshdan birdan katta."],["B sinfda","B da bolalar ko'p, demak 5 ta a'lochi — kichikroq qism."],["Teng","Soni teng, lekin sinflar har xil: ulush har xil."],["B da 5 taga ko'p","A'lochilar soni bir xil — 5 tadan."]],function(){y6share(1)}),g2:1,
 after:"<p>Har xil kattalikdagi guruhlarni taqqoslashda <b>ulush</b> (yoki foiz) ishlatiladi: qism / butun. A: 25%, B: 20%.</p>",
 q:{t:"A maktabda 400 o'quvchidan 100 tasi, B maktabda 300 o'quvchidan 90 tasi olimpiadada qatnashdi. Qayerda qatnashganlar ulushi katta?",opts:["B da (30% > 25%)","A da (100 > 90)","Teng","A da (400 > 300)"],ok:0,why:"100/400 = 25%, 90/300 = 30%.",hint:"Har maktab uchun qatnashganlarning foizini toping.",full:"A: 100 : 400 = 1/4 = 25%. B: 90 : 300 = 3/10 = 30%. B da ulush katta, garchi soni kam bo'lsa ham."},
 tn:"Bolalar «kim ko'p» va «kimning ulushi katta» savollarini farqlashni misollarda mashq qilsin."},
{h:"To'g'ri xulosa chiqarish",sum:"Ma'lumot faqat shu sinf haqida: «yarmidan ko'pi nonushta qiladi» — to'g'ri; «maktabda hamma» — noto'g'ri.",a:"m08",
 start:function(){y6concl();calc(['Qaysi xulosa ma‘lumotdan kelib chiqadi?'])},fin:function(){y6concl();y4msg('To‘g‘ri: <b>sinfning yarmidan ko‘pi</b> nonushta qiladi')},
 html:"<p>So'rov: sinfdagi 30 boladan 18 tasi ertalab nonushta qiladi. Qaysi xulosa to'g'ri?</p>",
 btns:y4pick(0,[["Sinfning yarmidan ko'pi nonushta qiladi","18 > 15 — bu ma'lumotdan bevosita chiqadi."],["Maktabdagi hamma nonushta qiladi","Faqat bitta sinf so'ralgan — butun maktab haqida bilmaymiz."],["Nonushta qilganlar a'lo o'qiydi","Baholar haqida ma'lumot yo'q."],["12 bola hech qachon nonushta qilmaydi","Ular «ertalab nonushta qilmaydi» deyishgan, «hech qachon» — ortiqcha xulosa."]]),
 after:"<p>Xulosa faqat <b>so'ralgan guruh</b> va <b>so'ralgan savol</b> haqida bo'ladi. Kichik guruhdan butun maktab, shahar yoki «hamma» haqida xulosa chiqarish — xato.</p>",
 q:{t:"3 bola so'raldi, 2 tasi mushukni yaxshi ko'radi. Qaysi xulosa to'g'ri?",opts:["So'ralgan 3 boladan 2 tasi mushukni yaxshi ko'radi","Maktabning 2/3 qismi mushukni yaxshi ko'radi","Hamma bolalar mushukni yaxshi ko'radi","It hech kimga yoqmaydi"],ok:0,why:"Faqat 3 bola haqida aytish mumkin.",hint:"Kim so'ralgan va nima so'ralgan?",full:"Ma'lumot faqat 3 bola haqida — bu juda kichik guruh. Butun maktab yoki «hamma» haqida xulosa chiqarib bo'lmaydi. It haqida umuman so'ralmagan."},
 tn:"Gazeta sarlavhalarini olib keling: «Hamma …», «Ko'pchilik …» — bolalar dalilni so'rasin."},
{h:"Bilasizmi? Xarita hayotni saqlagan",sum:"1854-yil Londonda shifokor Jon Snou kasallik o'choqlarini xaritaga tushirib, sababchi suv nasosini topdi.",a:"m09",
 start:function(){startPh(Y6P9)},fin:function(){S.ph=1;Y6P9[1]()},
 html:"<p>Ma'lumotni to'g'ri ko'rsatish odamlar hayotini qutqargan. Bosing:</p>",btns:[phaser(Y6P9)],
 after:"<p>🗺 1854-yilda Londonda vabo tarqaldi. Shifokor <b>Jon Snou</b> kasallar yashagan uylarni xaritada belgiladi va ular Broad ko'chasidagi bitta suv nasosi atrofida to'planganini ko'rdi. Nasos dastasi olib qo'yildi. Bu — ma'lumotlarni tahlil qilishning eng mashhur namunalaridan biri.</p>",
 tn:"Maktab xaritasini chizib, «qayerda ko'p chiqindi bor» kuzatuvini belgilang — qaror qabul qiling."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>O'rtacha = yig'indi : soni; <b>jami = o'rtacha · soni</b>.</li><li>Yangi / o'chirilgan / yetishmagan qiymat — jamilar farqi.</li><li>Diagrammada o'q boshlanishini tekshiring (0 danmi?).</li><li>Masofa–vaqt: tik — tez, gorizontal — to'xtash; o'rtacha tezlik = jami yo'l : jami vaqt.</li><li>Har xil guruhlar — ulush (foiz) bilan taqqoslanadi.</li><li>Xulosa faqat so'ralgan guruh haqida.</li></ul></div>",
 tn:"Uyga: oiladagilar bo'yi (yoki yoshi) bo'yicha o'rtachani topish."}
];
var PROBS=[
{t:"4, 7, 9, 8 sonlarining o'rta arifmetigi?",o:["7","28","8","6"],k:0,s:"28 : 4 = 7."},
{t:"5 bolaning bo'yi: 130, 128, 135, 132, 125 sm. O'rtacha bo'y?",o:["130 sm","128 sm","135 sm","650 sm"],k:0,s:"650 : 5."},
{t:"4 bolaning o'rtacha vazni 30 kg. 5-bola qo'shilgach, o'rtacha 32 kg bo'ldi. 5-bola vazni?",o:["40 kg","32 kg","34 kg","2 kg"],k:0,s:"160 − 120."},
{t:"5 sonning o'rtachasi 7. To'rttasi: 4, 9, 6, 10. Beshinchisi?",o:["6","7","29","8"],k:0,s:"35 − 29."},
{t:"Sayyoh 3 kunda o'rtacha 40 km yurdi: 1-kun 35 km, 2-kun 42 km. 3-kun necha km yurgan?",o:["43 km","40 km","37 km","77 km"],k:0,s:"120 − 77."},
{t:"Diagrammada o'q 50 dan boshlanadi: A — 52, B — 56. B A dan qanchaga ko'p?",o:["4 taga","3 marta","6 taga","2 marta"],k:0,s:"56 − 52."},
{t:"Kitob o'qiganlar: yanvar 12, fevral 18, mart 15, aprel 24, may 21. Oyiga o'rtacha?",o:["18","15","24","90"],k:0,s:"90 : 5."},
{t:"Kitob o'qiganlar: yanvar 12, fevral 18, mart 15, aprel 24, may 21. Qaysi ketma-ket oylar orasida o'sish eng katta?",o:["Mart – Aprel","Yanvar – Fevral","Aprel – May","Fevral – Mart"],k:0,s:"+9."},
{t:"Grafik: 0 soatda 0 km, 1 soatda 20 km, 2 soatda 20 km, 3 soatda 50 km. 1- va 2-soat orasida velosipedchi nima qilgan?",o:["To'xtab turgan","Eng tez yurgan","Orqaga qaytgan","Sekin yurgan"],k:0,s:"Masofa o'zgarmagan."},
{t:"Grafik: 0 soatda 0 km, 1 soatda 20 km, 2 soatda 20 km, 3 soatda 50 km. Eng katta tezlik qachon?",o:["2 dan 3 soatgacha, 30 km/soat","0 dan 1 soatgacha, 20 km/soat","3-soatda, 50 km/soat","1 dan 2 soatgacha"],k:0,s:"+30 km bir soatda."},
{t:"A sinfda 20 boladan 5 tasi, B sinfda 25 boladan 5 tasi a'lochi. Qayerda a'lochilar ulushi katta?",o:["A sinfda","B sinfda","Teng","B sinfda 5 taga ko'p"],k:0,s:"1/4 > 1/5."},
{t:"Sinfdagi 30 boladan 18 tasi nonushta qiladi. Qaysi xulosa to'g'ri?",o:["Sinfning yarmidan ko'pi nonushta qiladi","Maktabdagi hamma nonushta qiladi","Nonushta qilganlar a'lo o'qiydi","12 bola hech qachon nonushta qilmaydi"],k:0,s:"18 > 15."},
{t:"6 ta sonning o'rtachasi 10. Bittasi o'chirilgach, qolgan 5 tasining o'rtachasi 9. O'chirilgan son?",o:["15","1","10","19"],k:0,s:"60 − 45."},
{t:"A sinfda 20 bola o'rtacha 8 ball, B sinfda 30 bola o'rtacha 9 ball oldi. Hammasining o'rtacha bali?",o:["8,6","8,5","17","9"],k:0,s:"(160 + 270) : 50 = 430 : 50."},
{t:"Ballar: 6, 8, 8, 9, 10, 10, 10. Eng ko'p uchragan ball?",o:["10","8","9","3"],k:0,s:"10 uch marta."},
{t:"Dushanba 15, seshanba 20, chorshanba ?, payshanba 25 ta. To'rt kunning o'rtachasi 20. Chorshanba?",o:["20","25","60","15"],k:0,s:"80 − 60."},
{t:"Do'kon savdosi har oy bir xil miqdorda o'sdi: 40, 45, 50, … 4-oyda qancha?",o:["55","60","50","45"],k:0,s:"+5."},
{t:"Bir haftada (7 kun) o'rtacha harorat 20°. Birinchi 6 kunning o'rtachasi 19°. 7-kun harorati?",o:["26°","20°","21°","1°"],k:0,s:"140 − 114."},
{t:"Doiraviy diagrammada 1/3 qism — 40 o'quvchi. Jami nechta o'quvchi va 1/4 qism nechta?",o:["120 ta va 30 ta","120 ta va 40 ta","160 ta va 40 ta","40 ta va 10 ta"],k:0,s:"40 · 3 = 120; 120 : 4 = 30."},
{t:"Uch o'quvchining o'rtacha bali 7. Hammasining bali 1 tadan oshsa, o'rtacha?",o:["8","10","7","21"],k:0,s:"Jami 3 ga oshadi: 24 : 3."}
];
var PREP_DATA={teach:["O'rta arifmetik: tenglashtirish ma'nosi, jami = o'rtacha · soni.","Yangi, o'chirilgan va yetishmagan qiymat.","Aldovchi diagramma: o'q boshlanishi.","Masofa–vaqt grafigi: to'xtash, eng katta va o'rtacha tezlik.","Ulush bilan taqqoslash; to'g'ri xulosa chiqarish."],
 mist:["O'rtachalar ustida to'g'ridan amal bajaradi (32 − 30 = 2).","Ustun balandligiga qarab «3 marta ko'p» deydi.","O'rtacha tezlikka to'xtash vaqtini qo'shmaydi.","Son va ulushni adashtiradi.","Kichik guruhdan «hamma» haqida xulosa chiqaradi."],
 need:["Qalam, koptok yoki kubiklar (tenglashtirish uchun).","Gazeta diagrammalari, katakli qog'oz."],
 board:["<span class='w2'>o'rtacha = yig'indi : soni</span>; <span class='w2'>jami = o'rtacha · soni</span>.","5 · 32 − 4 · 30 = 40.","O'q 0 dan boshlanadimi?","v o'rt = 60 : 4 = 15 km/soat."]};
