var CODE='4J13',TITLE="4-sinf · Eng kami nechta? (Dirixle prinsipi)";
function q13Rem(nums,m,hl){clear();var g=S.g,w=340/m;for(var r=0;r<m;r++){var x=10+r*w;E('rect',{x:x+2,y:34,width:w-4,height:110,rx:8,fill:'#fff7ea',stroke:'#d9b98a'},g);T(g,x+w/2,26,'qoldiq '+r,{'font-size':10,'font-weight':800,fill:'#8a5a24'})}
 var cnt={};nums.forEach(function(n){var r=n%m;cnt[r]=(cnt[r]||0)+1;var x=10+r*w+w/2,y=58+(cnt[r]-1)*30,on=hl&&hl.indexOf(n)>=0;E('rect',{x:x-20,y:y-15,width:40,height:24,rx:6,fill:on?'#e6f6ee':'#fff',stroke:on?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,y+3,n,{'font-size':13,'font-weight':800,fill:on?C.ok:'#1d2b3a'})})}
function q13Garden(pts,grid,hl){clear();var g=S.g,x0=110,y0=14,s=144;E('rect',{x:x0,y:y0,width:s,height:s,fill:'#eef8e8',stroke:'#5a9a4a','stroke-width':2},g);
 if(grid)for(var i=1;i<3;i++){E('line',{x1:x0+i*s/3,y1:y0,x2:x0+i*s/3,y2:y0+s,stroke:'#5a9a4a','stroke-dasharray':'4 3'},g);E('line',{x1:x0,y1:y0+i*s/3,x2:x0+s,y2:y0+i*s/3,stroke:'#5a9a4a','stroke-dasharray':'4 3'},g)}
 if(hl)E('rect',{x:x0+hl[0]*s/3,y:y0+hl[1]*s/3,width:s/3,height:s/3,fill:'rgba(30,142,90,.18)',stroke:C.ok,'stroke-width':3},g);
 pts.forEach(function(p){T(g,x0+p[0]*s,y0+p[1]*s+6,'🌳',{'font-size':15})});T(g,60,90,'3 m × 3 m',{'font-size':12,'font-weight':800,fill:'#3a6a2a'})}
function q13Pens(cnt,names,hl){clear();var g=S.g,em=["🔴","🔵","🟢"];cnt.forEach(function(n,i){var x=14+i*114,on=hl===i;E('rect',{x:x,y:30,width:104,height:112,rx:10,fill:on?'#fde6e6':'#fff7ea',stroke:on?C.bad:'#d9b98a','stroke-width':on?3:1.6},g);T(g,x+52,22,names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
 for(var k=0;k<n;k++)T(g,x+14+(k%5)*19,58+Math.floor(k/5)*26,em[i],{'font-size':15});T(g,x+52,134,n+' ta',{'font-size':13,'font-weight':800,fill:'#5a4630'})})}
var TREES=[[.1,.15],[.45,.1],[.85,.2],[.2,.5],[.55,.45],[.88,.55],[.12,.86],[.5,.85],[.78,.8],[.62,.62]];
var P1=[function(){q13Rem([],5);j2Msg("Har qanday son 5 ga bo'linganda qoldiq 0, 1, 2, 3 yoki 4 bo'ladi — <b>5 ta quti</b>.")},
 function(){q13Rem([14,27,41,8,30],5);j2Msg("5 ta son — 5 ta qutiga bittadan tushishi mumkin: 14, 27, 41, 8, 30 — hammasi har xil qoldiqli.")},
 function(){q13Rem([14,27,41,8,30,53],5,[8,53]);j2Msg("6-son (53) albatta band qutiga tushadi: 53 va 8 ning qoldig'i bir xil (3) → 53 − 8 = <b>45</b> — 5 ga bo'linadi!")}];
var P2=[function(){q13Garden(TREES,false);j2Msg("3 m × 3 m bog'da 10 ta daraxt. Isbotlang: qaysidir 1 m × 1 m kvadratda kamida <b>2 ta</b> daraxt bor.")},
 function(){q13Garden(TREES,true);j2Msg("Bog'ni <b>9 ta</b> kichik kvadratga bo'lamiz — bular «qutilar».")},
 function(){q13Garden(TREES,true,[1,1]);j2Msg("10 daraxt, 9 quti → biror kvadratda albatta 2 ta. Bu yerda — o'rtadagi kvadrat.")}];
var P3=[function(){q13Pens([0,0,0],["10 qizil","10 ko'k","10 yashil"]);j2Msg("Har rangdan <b>kamida 2 tadan</b> albatta bo'lishi uchun kamida nechta qalam olamiz?")},
 function(){q13Pens([10,10,1],["qizil","ko'k","yashil"]);j2Msg("Eng omadsiz holat: ikki rangning <b>hammasi</b> chiqadi (20 ta), uchinchisidan esa faqat 1 ta. 21 ta — hali yetmaydi!")},
 function(){q13Pens([10,10,2],["qizil","ko'k","yashil"],2);j2Msg("Javob: 10 + 10 + 2 = <b>22</b>. «6» — eng omadli holat.")}];
var P4=[function(){j2Lines([["30 o'quvchi, Ali — 13 xato",C.blue,20],["qolganlarda 13 dan kam",null,16]]);j2Msg("Ali 13 ta xato qildi, qolganlar undan kam. Isbot: kamida 3 o'quvchi bir xil sondagi xato qilgan.")},
 function(){j2Lines([["mumkin bo'lgan xatolar: 0, 1, 2, …, 12",null,16],["= 13 ta «quti»",C.blue,20],["Alidan boshqa 29 o'quvchi",null,16]]);j2Msg("Qutilar — xatolar soni: 0 dan 12 gacha, ya'ni <b>13</b> ta.")},
 function(){j2Lines([["29 = 13 · 2 + 3",C.blue,26],["har qutiga 2 tadan → 26",null,15],["qolgan 3 → biror qutida 3 ta",C.ok,16]]);j2Msg("Teng taqsimlasak har qutiga 2 tadan, 3 ta ortadi → biror qutida <b>kamida 3</b> o'quvchi.")}];
var P5=[function(){j2Lines([["1, 2, 3, … , 20",C.blue,22]]);j2Msg("1 dan 20 gacha sonlardan kamida nechtasini olsak, ikkitasining ayirmasi albatta <b>10</b> bo'ladi?")},
 function(){j2Lines([["(1, 11) (2, 12) (3, 13) (4, 14) (5, 15)",null,14],["(6, 16) (7, 17) (8, 18) (9, 19) (10, 20)",null,14],["10 ta juft = 10 ta quti",C.blue,18]]);j2Msg("Qutilarni o'zimiz yasaymiz: ayirmasi 10 bo'lgan juftlar — 10 ta.")},
 function(){j2Lines([["10 ta son: har juftdan bittadan",null,15],["11-son → juft to'ladi!",C.ok,20]]);j2Msg("10 ta sonni har juftdan bittadan olsak — hali yo'q. <b>11</b>-son albatta juftni to'ldiradi.")}];
var STEPS=[
{h:"Qoldiqlar — qutilar",sum:"5 ga bo'lganda qoldiq 5 xil. 6 ta sondan ikkitasining qoldig'i bir xil, ayirmasi 5 ga bo'linadi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Dirixle prinsipida eng muhim savol — <b>nima «quti» bo'ladi?</b> Sonlar bilan ishlaganda qutilar ko'pincha <b>qoldiqlar</b> bo'ladi.</p>",
 btns:[phaser(P1)],
 after:"<p>Qoldiqlari bir xil ikki sonning ayirmasi bo'luvchiga <b>qoldiqsiz</b> bo'linadi: 53 = 5 · 10 + 3, 8 = 5 · 1 + 3 → 53 − 8 = 5 · 9.</p>",
 q:{t:"Kamida nechta butun son olsak, ikkitasining ayirmasi albatta 7 ga bo'linadi?",opts:["7","8","14","6"],ok:1,why:"7 ga bo'lganda qoldiqlar 7 xil (0–6). 8-son takrorlaydi.",hint:"7 ga bo'lganda nechta har xil qoldiq bo'ladi? Ular — qutilar.",full:"Qoldiqlar: 0, 1, 2, 3, 4, 5, 6 — 7 ta quti. 7 ta son hammasi har xil qoldiqli bo'lishi mumkin. 8-son albatta qaysidir qoldiqni takrorlaydi → ayirma 7 ga bo'linadi. Javob: 8."},
 tn:"Bolalar tasodifiy 6 ta son aytsin, siz doskada qoldiqlar ustunlariga yozing — ikkitasi albatta bir ustunga tushadi."},
{h:"Bog'dagi daraxtlar",sum:"3×3 m bog' = 9 ta 1×1 kvadrat; 10 daraxt → biror kvadratda 2 ta.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Geometriyada qutilar — <b>bo'laklar</b>. Shaklni teng bo'laklarga bo'lamiz.</p>",
 btns:[phaser(P2)],
 after:"<p>Qaysi kvadratda ekanini aytmaymiz — faqat <b>bor ekanini</b> isbotlaymiz. Dirixle prinsipi shunday: «qayerda» emas, «albatta bor».</p>",
 q:{t:"Tomoni 4 m bo'lgan kvadrat maydonda 17 ta ko'chat. Qaysi gap albatta to'g'ri?",opts:["Biror 1×1 m kvadratda kamida 2 ta ko'chat bor","Har 1×1 m kvadratda bittadan ko'chat","Biror 1×1 m kvadratda 3 ta ko'chat bor","Biror 1×1 m kvadrat bo'sh"],ok:0,why:"4 × 4 = 16 ta kvadrat, 17 ko'chat → biror kvadratda 2 ta.",hint:"Maydon nechta 1×1 kvadratga bo'linadi?",full:"4 × 4 = 16 ta kvadrat — 16 quti. 17 > 16 → biror kvadratda kamida 2 ta. «Bo'sh kvadrat» shart emas: 16 tasiga bittadan, 17-si qo'shimcha bo'lishi mumkin."},
 tn:"Doskada katakli kvadrat chizib, bolalar nuqtalarni «hech bir katakda 2 ta bo'lmasin» deb qo'yishga urinsin — iloji yo'qligini o'zlari ko'rsin."},
{h:"Har rangdan kamida 2 ta",sum:"10+10+10 qalam: har rangdan 2 ta uchun 10 + 10 + 2 = 22.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Qutida 10 ta qizil, 10 ta ko'k, 10 ta yashil qalam. Ko'rmasdan olamiz. Bu safar savol boshqacha: <b>har rangdan</b> kamida 2 tadan bo'lsin.</p>",
 btns:[phaser(P3)],
 after:"<p>«Har rangdan» savolida eng omadsiz holat — ko'p ranglarning <b>hammasi</b> chiqib, bitta rang yetishmasligi. Shuning uchun eng ko'p sonli ranglarni to'liq olamiz.</p>",
 q:{t:"Qutida 6 qizil, 8 ko'k, 10 yashil shar. Har rangdan albatta kamida bittadan bo'lishi uchun kamida nechta olish kerak?",opts:["3","19","18","25"],ok:1,why:"Eng omadsiz: 10 yashil + 8 ko'k = 18, keyin 19-si qizil.",hint:"Qaysi ikki rangning hammasi oldin chiqsa, eng ko'p shar ketadi?",full:"Eng yomon holat — eng ko'p ikki rang to'liq chiqadi: 10 + 8 = 18 ta, hali qizil yo'q. 19-shar albatta qizil. Javob: 19. «3» — eng omadli holat."},
 tn:"Bir xil masalaning uch savolini yonma-yon yozing: «2 ta bir xil», «har xil», «har rangdan» — javoblari 4, 11, 22 kabi har xil."},
{h:"Xatolar soni — qutilar",sum:"Ali 13 xato, qolgan 29 kishida 0–12 (13 quti): 29 = 13 · 2 + 3 → kamida 3 kishi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Olimpiada masalasi: sinfda 30 o'quvchi. Ali diktantda 13 ta xato qildi, qolganlar undan kam. Isbotlang: kamida 3 o'quvchi bir xil sondagi xato qilgan.</p>",
 btns:[phaser(P4)],
 after:"<p>Hiyla — 0 ni unutmaslik: xatosiz yozganlar ham bir «quti». Va Alining o'zini hisobdan chiqarish: u yolg'iz «13» qutisida.</p>",
 q:{t:"Sinfda 27 o'quvchi. Eng ko'p xato Valida — 12 ta, qolganlar undan kam. Bir xil xatoli o'quvchilar kamida nechta?",opts:["2","3","4","12"],ok:1,why:"Qolgan 26 kishi, qutilar 0–11 (12 ta): 26 = 12 · 2 + 2 → kamida 3.",hint:"Validan boshqa nechta o'quvchi? Ularning xatolari qanday bo'lishi mumkin (0 ni unutmang)?",full:"Validan boshqa 26 kishi. Ularning xatosi 0, 1, …, 11 — 12 ta quti. 12 · 2 = 24, 26 > 24 → biror qutida kamida 3 ta. Javob: 3. «2» — 0 qutisini yoki qoldiqni unutgan."},
 tn:"«0 — ham quti» degan fikrni alohida ta'kidlang: bolalar ko'pincha xatolar 1 dan 11 gacha deb o'ylaydi."},
{h:"Qutini o'zingiz toping",sum:"1–20 da ayirmasi 10 bo'lgan juftlar 10 ta → 11 ta son tanlansa, juft albatta bor.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Eng qiyin turi: masalada qutilar ko'rinmaydi. Ularni topish — butun yechim.</p>",
 btns:[phaser(P5)],
 after:"<p>Qutilarni shunday tanlaymizki, bir qutidagi <b>istalgan ikki son</b> talabni bajarsin. Bu yerda har qutida ayirmasi 10 bo'lgan juft.</p>",
 q:{t:"1 dan 12 gacha sonlardan kamida nechtasini tanlasak, albatta yig'indisi 13 bo'lgan ikki son bo'ladi?",opts:["6","7","8","12"],ok:1,why:"Juftlar (1,12), (2,11), …, (6,7) — 6 ta quti; 7-son juftni to'ldiradi.",hint:"Yig'indisi 13 bo'lgan juftlarni yozing. Nechta?",full:"(1, 12), (2, 11), (3, 10), (4, 9), (5, 8), (6, 7) — 6 ta quti. 6 ta sonni har juftdan bittadan olsak, juft yo'q. 7-son albatta juftni to'ldiradi. Javob: 7."},
 tn:"Bolalar o'zi juftlarni kartochkalarga yozib, «qutilar»ga solsin."},
{h:"Tug'ilgan kunlar",sum:"Yilda ko'pi bilan 366 kun → 367 kishida ikkitasining tug'ilgan kuni albatta bir xil.",a:"m06",
 start:function(){j2Lines([["📅 366 kun = 366 quti",C.blue,20],["367 kishi → kamida 2 ta bir kunda",C.ok,16]]);j2Msg("Qancha odam bo'lsa, tug'ilgan kuni bir xil ikki kishi <b>albatta</b> bor?")},
 fin:function(){j2Lines([["📅 366 kun = 366 quti",C.blue,20],["367 kishi → kamida 2 ta bir kunda",C.ok,16]]);j2Msg("Javob: <b>367</b> — kabisa yilidagi 29-fevralni ham hisobga oldik.")},
 html:"<p>Tug'ilgan kun (oy va kun) bir xil bo'lgan ikki kishi albatta bo'lishi uchun kamida necha kishi kerak? To'g'ri javobni tanlang.</p>",
 btns:j2Pick(["365","366","367"],2,function(){j2Msg("To'g'ri! Kunlar 366 ta (29-fevral ham bor), 367-kishi takrorlaydi.")},function(i){j2Msg(i===0?"29-fevralni unutdingiz — u ham tug'ilgan kun bo'lishi mumkin.":"366 kishining hammasi har xil kunda tug'ilgan bo'lishi mumkin.")}),
 after:"<p>Kunlar — 366 ta quti (29-fevral bilan). Shuning uchun 367 kishi kerak. Bu — «quti» sonini to'g'ri sanash muhimligi.</p>",
 q:{t:"Kamida nechta odam bo'lsa, ularning 3 tasi haftaning bir kunida tug'ilgani aniq?",opts:["14","15","21","8"],ok:1,why:"7 · 2 = 14 — har kunda 2 tadan; 15-chi uchinchi bo'ladi.",hint:"Har kunga 2 tadan bo'lsa, nechta kishi bo'ladi? Keyin +1.",full:"Hafta kunlari 7 ta. Har kunda 2 tadan — 14 kishi, hali 3 ta yo'q. 15-kishi albatta biror kunda uchinchi. Javob: 15."},
 tn:"Sinf ro'yxatidan tug'ilgan oylarni yig'ib, doskada jadval qiling — prinsip haqiqatda qanday ishlashini ko'rsating."},
{h:"Bilasizmi? 6 kishi va tanishlar",sum:"Har qanday 6 kishi orasida albatta 3 ta o'zaro tanish yoki 3 ta o'zaro notanish bor (Ramsey).",a:"m07",
 start:function(){j2Lines([["👥 6 kishi",C.blue,24],["→ 3 tanish yoki 3 notanish",C.ok,17]]);j2Msg("Ingliz matematigi Frenk Ramsey (1930)")},fin:function(){j2Lines([["👥 6 kishi",C.blue,24],["→ 3 tanish yoki 3 notanish",C.ok,17]]);j2Msg("Ingliz matematigi Frenk Ramsey (1930)")},
 html:"<p>🤝 Har qanday <b>6 kishi</b> orasida albatta yo 3 kishi bir-birini taniydi, yo 3 kishi bir-birini mutlaqo tanimaydi. 5 kishida bu shart emas!</p><p>Isbot Dirixle prinsipiga asoslanadi: bitta odamning qolgan 5 kishi bilan munosabati 2 xil (tanish/notanish), demak ulardan kamida 3 tasi bir xil. Bunday g'oyalardan ingliz matematigi <b>Frenk Ramsey</b> nomi bilan butun bir fan bo'limi o'sib chiqqan.</p>",
 btns:[["🤝 Qiziq!",function(c,done){done()}]],
 tn:"5 = 2 · 2 + 1 → kamida 3 ta: bu yerda ham «teng taqsimlash + qoldiq» ishladi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["quti · k + 1 → kamida k + 1",C.blue,20]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["quti · k + 1 → kamida k + 1",C.blue,20]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Avval <b>qutini toping</b>: qoldiqlar, bo'laklar, juftlar, kunlar.</li><li>n + 1 ta son → ikkitasining ayirmasi n ga bo'linadi.</li><li>Shakl → teng bo'laklarga: 3×3 bog' = 9 quti.</li><li>«Har rangdan k ta»: eng ko'p ranglarning <b>hammasi</b> + k.</li><li>0 ham quti (xatosiz yozganlar)!</li><li>Kunlar 366 ta (29-fevral).</li><li>Narsa = quti · k + qoldiq (qoldiq > 0) → biror qutida kamida k + 1.</li></ul></div>",
 tn:"Uyga: «Sinfingizda bir xil harfdan boshlanuvchi ismli kamida 2 kishi bormi? Nega?» (harflar soni bilan solishtirish)."}
];
var PROBS=[
{t:"Kamida nechta butun son olsak, ikkitasining ayirmasi albatta 5 ga bo'linadi?",o:["6","5","10","4"],k:0,s:"Qoldiqlar 5 xil → 6-son takrorlaydi."},
{t:"Ixtiyoriy 8 ta butun son olindi. Ikkitasining ayirmasi albatta qaysi songa bo'linadi?",o:["7","8","9","10"],k:0,s:"7 ga bo'lganda qoldiqlar 7 xil, sonlar 8 ta."},
{t:"Qutida 10 qizil, 10 ko'k, 10 yashil qalam. Har rangdan albatta kamida 2 tadan bo'lishi uchun kamida nechta olish kerak?",o:["22","6","21","12"],k:0,s:"10 + 10 + 2 = 22."},
{t:"Qutida 6 qizil, 8 ko'k, 10 yashil shar. Har rangdan kamida bittadan bo'lishi uchun kamida nechta?",o:["19","3","18","25"],k:0,s:"10 + 8 + 1 = 19."},
{t:"Qutida 5 qizil va 5 ko'k shar. Ikkala rangdan ham bo'lishi uchun kamida nechta?",o:["6","2","3","10"],k:0,s:"5 + 1 = 6."},
{t:"Kamida nechta odam bo'lsa, ikkitasining tug'ilgan kuni (oy va kun) albatta bir xil?",o:["367","366","365","13"],k:0,s:"366 kun + 1."},
{t:"1 dan 20 gacha sonlardan kamida nechtasini olsak, ikkitasining ayirmasi albatta 10 bo'ladi?",o:["11","10","12","20"],k:0,s:"10 ta juft (1,11)…(10,20) → 11."},
{t:"1 dan 12 gacha sonlardan kamida nechtasini olsak, ikkitasining yig'indisi albatta 13 bo'ladi?",o:["7","6","8","12"],k:0,s:"6 ta juft → 7."},
{t:"3 m × 3 m bog'da 10 ta daraxt. Qaysi gap albatta to'g'ri?",o:["Biror 1×1 m kvadratda kamida 2 daraxt","Har 1×1 m kvadratda bittadan daraxt","Biror 1×1 m kvadratda 3 daraxt","Biror 1×1 m kvadrat bo'sh"],k:0,s:"9 kvadrat, 10 daraxt."},
{t:"27 o'quvchi. Eng ko'p xato Valida — 12 ta, qolganlar undan kam. Bir xil xatoli o'quvchilar kamida nechta?",o:["3","2","4","12"],k:0,s:"26 kishi, 12 quti (0–11): 26 = 12 · 2 + 2 → 3."},
{t:"30 o'quvchi. Eng ko'p xato faqat Alida — 13 ta, qolganlar kam. Bir xil xatoli kamida nechta?",o:["3","2","4","13"],k:0,s:"29 kishi, 13 quti (0–12): 29 = 13 · 2 + 3 → 3."},
{t:"Ixtiyoriy 3 ta butun son olindi. Qaysi gap albatta to'g'ri?",o:["Ikkitasining yig'indisi juft","Ikkitasining yig'indisi toq","Hammasi juft","Ikkitasi teng"],k:0,s:"Juft/toq — 2 quti: ikkitasi bir xil juftlikda, yig'indisi juft."},
{t:"Ixtiyoriy 5 ta butun son. Qaysi gap albatta to'g'ri?",o:["Ikkitasining ayirmasi 4 ga bo'linadi","Ikkitasining ayirmasi 5 ga bo'linadi","Ikkitasi teng","Hammasi toq"],k:0,s:"4 ga bo'lganda 4 xil qoldiq, sonlar 5 ta."},
{t:"Sinfda 35 o'quvchi. Kamida nechtasi bir oyda tug'ilgani aniq?",o:["3","2","4","12"],k:0,s:"35 = 12 · 2 + 11 → 3."},
{t:"61 ta olma 15 ta savatga solindi. Eng to'la savatda kamida nechta olma bor?",o:["5","4","6","15"],k:0,s:"61 = 15 · 4 + 1 → 5."},
{t:"Xaltada 4 xil rangli tugmalar ko'p. 3 ta bir xil rangli albatta bo'lishi uchun kamida nechta?",o:["9","3","12","8"],k:0,s:"4 · 2 + 1 = 9."},
{t:"Kamida nechta o'quvchi bo'lsa, 3 tasi haftaning bir kunida tug'ilgani aniq?",o:["15","14","21","8"],k:0,s:"7 · 2 + 1 = 15."},
{t:"Shaxmat doskasida (64 katak) 65 ta tanga turibdi. Qaysi gap albatta to'g'ri?",o:["Biror katakda kamida 2 tanga","Har katakda 1 tanga","Biror katak bo'sh","Biror katakda 3 tanga"],k:0,s:"64 quti, 65 tanga."},
{t:"Qutida 3 juft qora va 3 juft oq qo'lqop (chap va o'ng). Bir xil rangli juft (chap + o'ng) albatta bo'lishi uchun kamida nechta qo'lqop?",o:["7","3","4","12"],k:0,s:"Eng omadsiz: 6 ta chap qo'lqop. 7-si o'ng — juft tayyor."},
{t:"Qutida 4 qizil, 5 ko'k, 6 yashil shar. Albatta 2 ta qizil bo'lishi uchun kamida nechta?",o:["13","3","12","15"],k:0,s:"5 + 6 + 2 = 13."}
];
function PRACT_STAGE(){j2Lines([["n + 1 → kamida 2",C.blue,24],["qutini toping!",null,16]])}
var PREP_DATA={teach:["Qoldiqlar — qutilar: ayirma bo'linuvchanligi.","Geometrik bo'laklar — qutilar.","«Har rangdan k ta» turi.","Qutini o'zi topish: juftlar, kunlar, xatolar."],
 mist:["Eng omadli holatni oladi («3 ta yetadi»).","0 xatoni quti deb hisoblamaydi.","29-fevralni unutadi (366 o'rniga 365).","«Har rangdan» savolida eng kichik rangni to'liq oladi."],
 need:["Rangli qalamlar/qopqoqlar, xalta.","Katakli kvadrat chizilgan varaq, tugmalar."],
 board:["<span class='w2'>6 ta son → qoldiq 5 xil</span>.","<span class='w2'>3×3 = 9 quti, 10 daraxt</span>.","<span class='w2'>10 + 10 + 2 = 22</span>.","<span class='w2'>29 = 13 · 2 + 3 → 3</span>.","<span class='w2'>(1,11)…(10,20) → 11</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
