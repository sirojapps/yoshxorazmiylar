var CODE='3H1',TITLE='3-sinf · Perimetr: to‘g‘ri to‘rtburchak, muntazam va nostandart shakllar';
// to'g'ri to'rtburchak 5×3 sm, k ta tomon bo'ylab "chumoli" yurgan
function h1Ant(k){clear('#ffffff');var x=100,y=30,w=150,h=90,g=S.g;
 g3Rect(x,y,w,h,{fill:'rgba(240,160,64,.18)'});
 var sd=[[[x,y],[x+w,y],'5 sm',[x+w/2,y-6]],[[x+w,y],[x+w,y+h],'3 sm',[x+w+22,y+h/2+4]],[[x+w,y+h],[x,y+h],'5 sm',[x+w/2,y+h+16]],[[x,y+h],[x,y],'3 sm',[x-22,y+h/2+4]]],sum=[5,8,13,16];
 for(var i=0;i<4;i++){if(i<k)g3Line(sd[i][0],sd[i][1],{w:5,c:C.bad});T(g,sd[i][3][0],sd[i][3][1],sd[i][2],{'font-size':12,'font-weight':800,fill:i<k?C.bad:C.blue})}
 var p=k?sd[k-1][1]:[x,y];T(g,p[0],p[1]+5,'🐜',{'font-size':16});
 g3Msg(k?'Yo‘l: '+['5','5 + 3','5 + 3 + 5','5 + 3 + 5 + 3'][k-1]+' = <b>'+sum[k-1]+' sm</b>'+(k===4?' — bu <b>perimetr</b>':''):'Chumoli burchakdan chiqib, shakl atrofini aylanadi')}
var P1=[function(){h1Ant(0)},function(){h1Ant(1)},function(){h1Ant(2)},function(){h1Ant(3)},function(){h1Ant(4)}];
function h1Half(k){clear('#ffffff');var x=90,y=30,w=180,h=90,g=S.g;g3Rect(x,y,w,h,{fill:'rgba(240,160,64,.18)'});
 T(g,x+w/2,y-6,'bo‘yi 6 sm',{'font-size':12,'font-weight':800,fill:C.bad});T(g,x-8,y+h/2+4,'eni 3 sm',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 if(k>=1){g3Line([x,y],[x+w,y],{w:5,c:C.bad});g3Line([x,y],[x,y+h],{w:5,c:C.blue})}
 if(k>=2){g3Line([x,y+h],[x+w,y+h],{w:5,c:C.bad,d:'8 5'});g3Line([x+w,y],[x+w,y+h],{w:5,c:C.blue,d:'8 5'})}
 g3Msg(['Qarama-qarshi tomonlar teng','Bir bo‘yi + bir eni = 6 + 3 = <b>9</b> (yarim perimetr)','Ikkinchi yarmi ham xuddi shunday: 9','P = (6 + 3) · 2 = <b>18 sm</b>'][k])}
var P2=[function(){h1Half(0)},function(){h1Half(1)},function(){h1Half(2)},function(){h1Half(2);g3Msg('P = (bo‘yi + eni) · 2 = (6 + 3) · 2 = <b>18 sm</b>')}];
function h1Reg(n,a){clear('#ffffff');var pts=g3Reg(n,180,92,62),g=S.g;g3Poly(pts,{fill:'rgba(90,169,230,.2)'});
 for(var i=0;i<n;i++){var p=pts[i],q=pts[(i+1)%n],mx=(p[0]+q[0])/2,my=(p[1]+q[1])/2,dx=mx-180,dy=my-92,l=Math.sqrt(dx*dx+dy*dy);T(g,mx+dx/l*14,my+dy/l*14+4,a+' sm',{'font-size':11,'font-weight':800,fill:C.bad})}
 var nm={3:'teng tomonli uchburchak',4:'kvadrat',5:'muntazam beshburchak',6:'muntazam oltiburchak'}[n];
 g3Msg(nm.charAt(0).toUpperCase()+nm.slice(1)+': P = '+a+' · '+n+' = <b>'+(a*n)+' sm</b>')}
// zinapoya: 1 katak = 1 m, cs=18
function h1Stair(k){clear('#ffffff');var cs=18,x0=110,y0=30,g=S.g;g3Paper(cs,x0-cs,y0-cs,8,8,'#eef3f8');
 function P(a,b){return [x0+a*cs,y0+b*cs]}
 g3Poly([P(0,0),P(2,0),P(2,2),P(4,2),P(4,4),P(6,4),P(6,6),P(0,6)],{fill:'rgba(240,160,64,.25)',stroke:C.line});
 T(g,x0-8,y0+3*cs+4,'6 m',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});T(g,x0+3*cs,y0+6*cs+16,'6 m',{'font-size':12,'font-weight':800,fill:C.blue});
 if(k===0){T(g,x0+cs,y0-5,'2',{'font-size':11,'font-weight':800,fill:C.bad});T(g,x0+3*cs,y0+2*cs-5,'2',{'font-size':11,'font-weight':800,fill:C.bad});T(g,x0+5*cs,y0+4*cs-5,'2',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(k>=1){[[0,2,0],[2,4,2],[4,6,4]].forEach(function(s){g3Line(P(s[0],s[2]),P(s[1],s[2]),{w:4,c:C.bad})});g3Line(P(0,0),P(6,0),{w:2,c:C.bad,d:'5 4'});T(g,x0+3*cs,y0-6,'2 + 2 + 2 = 6 m',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(k>=2){[[0,2,2],[2,4,4],[4,6,6]].forEach(function(s){g3Line(P(s[2],s[0]),P(s[2],s[1]),{w:4,c:C.ok})});g3Line(P(6,0),P(6,6),{w:2,c:C.ok,d:'5 4'});T(g,x0+6*cs+8,y0+3*cs+4,'6 m',{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'})}
 g3Msg(['Zinapoya shaklining perimetri qancha? Barcha burchaklar to‘g‘ri','Gorizontal bo‘laklarni yuqoriga «suramiz»: jami <b>6 m</b>','Vertikal bo‘laklarni o‘ngga suramiz: jami <b>6 m</b>','Xuddi 6 × 6 kvadrat kabi: P = (6 + 6) · 2 = <b>24 m</b>'][k])}
var P4=[function(){h1Stair(0)},function(){h1Stair(1)},function(){h1Stair(2)},function(){h1Stair(3)}];
function h1Inv(k){clear('#ffffff');var x=80,y=36,w=200,h=78,g=S.g;g3Rect(x,y,w,h,{fill:'rgba(240,160,64,.18)'});
 T(g,x+w/2,y-8,k>=2?'bo‘yi 18 sm':'bo‘yi ?',{'font-size':12,'font-weight':800,fill:C.bad});T(g,x-8,y+h/2+4,'14 sm',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 T(g,x+w/2,y+h/2+6,'P = 64 sm',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
 if(k>=1){g3Line([x,y],[x+w,y],{w:5,c:C.bad});g3Line([x,y],[x,y+h],{w:5,c:C.blue})}
 g3Msg(['Perimetr 64 sm, eni 14 sm. Bo‘yi qancha?','Bo‘yi + eni = 64 : 2 = <b>32 sm</b> (yarim perimetr)','Bo‘yi = 32 − 14 = <b>18 sm</b>','Tekshiramiz: (18 + 14) · 2 = 64 ✓'][k])}
var P5=[function(){h1Inv(0)},function(){h1Inv(1)},function(){h1Inv(2)},function(){h1Inv(3)}];
function h1Sq3(m){clear('#ffffff');var x=90,y=40,s=60,g=S.g;for(var i=0;i<3;i++)g3Rect(x+i*s,y,s,s,{fill:'rgba(90,169,230,.22)',stroke:C.blue});
 for(var j=0;j<3;j++)T(g,x+j*s+s/2,y-6,'4 sm',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x-6,y+s/2+4,'4 sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 if(m===1){g3Line([x+s,y],[x+s,y+s],{w:5,c:C.bad});g3Line([x+2*s,y],[x+2*s,y+s],{w:5,c:C.bad});T(g,180,y+s+22,'ichki tomonlar chegara emas!',{'font-size':12,'font-weight':800,fill:C.bad})}
 if(m===2){E('rect',{x:x,y:y,width:3*s,height:s,fill:'none',stroke:C.bad,'stroke-width':5},g);T(g,180,y+s+22,'(12 + 4) · 2 = 32 sm',{'font-size':14,'font-weight':800,fill:C.ok})}
 if(m===3){E('rect',{x:x,y:y,width:s,height:s,fill:'none',stroke:C.bad,'stroke-width':5},g);T(g,180,y+s+22,'bu faqat bitta kvadrat',{'font-size':12,'font-weight':800,fill:C.bad})}}
function h1Rope(a){clear('#ffffff');var b=10-a,cs=14,x0=180-a*cs/2,y0=90-b*cs/2,g=S.g;g3Paper(cs,x0,y0,a,b,'#e6edf5');
 E('rect',{x:x0,y:y0,width:a*cs,height:b*cs,fill:'rgba(240,160,64,.18)',stroke:C.bad,'stroke-width':3.5,rx:2},g);
 T(g,x0+a*cs/2,y0-6,a+' sm',{'font-size':11,'font-weight':800,fill:C.blue});T(g,x0-6,y0+b*cs/2+4,b+' sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 g3Msg('('+a+' + '+b+') · 2 = <b>20 sm</b> · ichida <b>'+(a*b)+'</b> katak')}
function h1Tri(k){clear('#ffffff');var A=[70,150],B=[170,26],Cc=[300,150],g=S.g;g3Poly([A,B,Cc],{fill:'rgba(90,169,230,.18)'});
 T(g,A[0]-10,A[1]+4,'A',{'font-size':13,'font-weight':800});T(g,B[0],B[1]-6,'B',{'font-size':13,'font-weight':800});T(g,Cc[0]+10,Cc[1]+4,'C',{'font-size':13,'font-weight':800});
 T(g,185,166,'AC = 19 sm',{'font-size':12,'font-weight':800,fill:C.blue});
 T(g,100,82,k>=1?'AB = 25':'AB = ?',{'font-size':12,'font-weight':800,fill:k>=1?C.bad:'#5b6b7b','text-anchor':'end'});
 T(g,250,82,k>=2?'BC = 30':'BC = ?',{'font-size':12,'font-weight':800,fill:k>=2?C.bad:'#5b6b7b','text-anchor':'start'});
 g3Msg(['AB tomon AC dan 6 sm uzun, BC dan 5 sm qisqa','AB = 19 + 6 = <b>25 sm</b>','AB BC dan 5 sm qisqa → BC <b>uzunroq</b>: 25 + 5 = <b>30 sm</b>','P = 19 + 25 + 30 = <b>74 sm</b>'][k])}
var P8=[function(){h1Tri(0)},function(){h1Tri(1)},function(){h1Tri(2)},function(){h1Tri(3)}];
function h1Field(on){clear('#ffffff');var g=S.g;E('rect',{x:55,y:22,width:250,height:130,fill:'#5fae5a',stroke:'#fff','stroke-width':3},g);g3Line([180,22],[180,152],{c:'#fff',w:2});E('circle',{cx:180,cy:87,r:22,fill:'none',stroke:'#fff','stroke-width':2},g);
 E('rect',{x:55,y:62,width:30,height:50,fill:'none',stroke:'#fff','stroke-width':2},g);E('rect',{x:275,y:62,width:30,height:50,fill:'none',stroke:'#fff','stroke-width':2},g);
 T(g,180,16,'105 m',{'font-size':12,'font-weight':800,fill:C.bad});T(g,48,91,'68 m',{'font-size':12,'font-weight':800,fill:C.bad,'text-anchor':'end'});
 if(on)E('rect',{x:55,y:22,width:250,height:130,fill:'none',stroke:C.bad,'stroke-width':4},g);
 g3Msg(on?'(105 + 68) · 2 = <b>346 m</b> — maydon atrofini bir aylanish':'Xalqaro o‘yinlar uchun tavsiya etilgan maydon: 105 m × 68 m')}
var STEPS=[
{h:"Perimetr — shakl atrofi",sum:"Perimetr — shakl barcha tomonlari uzunliklarining yig'indisi (atrofini bir aylanish).",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=4;P1[4]()},
 html:"<p>Chumoli to'g'ri to'rtburchak atrofini bir marta aylanib chiqmoqchi. U qancha yo'l yuradi? Har bosishda bitta tomonni bosib o'tadi.</p>",
 btns:[phaser(P1,'🐜 Yur')],
 after:"<p>Shakl atrofini bir aylanish uzunligi — <b>perimetr</b> (P). U barcha tomonlar yig'indisi: 5 + 3 + 5 + 3 = <b>16 sm</b>. Perimetr <b>uzunlik</b> birligida o'lchanadi: mm, sm, dm, m.</p>",
 q:{t:"Uchburchakning tomonlari 4 sm, 5 sm va 7 sm. Perimetri?",opts:["16 sm","140 sm","12 sm","9 sm"],ok:0,why:"4 + 5 + 7 = 16 sm.",hint:"Perimetr — barcha tomonlar yig'indisi.",full:"P = 4 + 5 + 7 = 16 sm. «140» — ko'paytirilgan, «12» va «9» — faqat ikki tomon qo'shilgan."},
 tn:"Bolalar partaning chetini ip bilan aylantirib o'lchasin, keyin ipni chizg'ichga qo'yib uzunligini topsin."},
{h:"To'g'ri to'rtburchak perimetri",sum:"P = (bo'yi + eni) · 2. Qarama-qarshi tomonlar teng.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>To'g'ri to'rtburchakda qarama-qarshi tomonlar <b>teng</b>. Shuning uchun hamma 4 tomonni qo'shmasdan, qisqaroq yo'l bor.</p>",
 btns:[phaser(P2,'▶ Ko‘rish')],
 after:"<p><b>P = (bo'yi + eni) · 2</b>. Kvadratda hamma tomon teng: <b>P = tomon · 4</b>.</p>",
 q:{t:"Bo'yi 9 sm, eni 4 sm bo'lgan to'g'ri to'rtburchakning perimetri?",opts:["13 sm","26 sm","36 sm","22 sm"],ok:1,why:"(9 + 4) · 2 = 26 sm.",hint:"Bo'yi va enini qo'shib, natijani nechaga ko'paytirish kerak?",full:"(9 + 4) · 2 = 26 sm. «13» — faqat yarim perimetr, «36» — bo'yi·eni (bu yuz!), «22» — 9 · 2 + 4."},
 tn:"Doskada «bo'yi + eni» ni bir rangda, ikkinchi yarmini boshqa rangda chizing — ×2 ma'nosi ko'rinsin."},
{h:"Muntazam shakllar",sum:"Barcha tomonlari teng shakl: P = tomon · tomonlar soni.",a:"m03",
 start:function(){h1Reg(3,5);g3Msg('Shaklni tanlang')},fin:function(){h1Reg(6,5)},
 html:"<p>Hamma tomonlari teng shakllar — <b>muntazam</b> shakllar. Har birining tomoni 5 sm. Perimetrini ko'ring:</p>",
 btns:[["△ Uchburchak",function(c,done){h1Reg(3,5);mvK(done,3)}],["□ Kvadrat",function(c,done){h1Reg(4,5);mvK(done,3)}],["⬠ Beshburchak",function(c,done){h1Reg(5,5);mvK(done,3)}],["⬡ Oltiburchak",function(c,done){h1Reg(6,5);mvK(done,3)}]],g2:1,
 after:"<p>Muntazam shaklda <b>P = tomon · tomonlar soni</b>. Teskarisi: <b>tomon = P : tomonlar soni</b>. Masalan, teng tomonli uchburchak perimetri 27 sm bo'lsa, tomoni 27 : 3 = 9 sm.</p>",
 q:{t:"Kvadratning perimetri 36 sm. Teng tomonli uchburchakning perimetri ham 36 sm. Uchburchakning tomoni necha sm?",opts:["9 sm","12 sm","36 sm","18 sm"],ok:1,why:"36 : 3 = 12 sm.",hint:"Uchburchakning nechta tomoni bor?",full:"Uchburchakda 3 tomon: 36 : 3 = 12 sm. «9» — kvadratning tomoni (36 : 4), «18» — 2 ga bo'lingan."},
 tn:"Cho'plardan (gugurt) muntazam shakllar yasating: bitta cho'p — 1 birlik, perimetr = cho'plar soni."},
{h:"Nostandart shakl: zinapoya",sum:"Barcha burchaklari to'g'ri zinapoya shakli perimetri — uni o'rab turgan to'g'ri to'rtburchak perimetriga teng.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Zinapoyaning har bir pog'onasi o'lchamini bilmasak ham perimetrini topish mumkin! Bo'laklarni «surib» ko'ring:</p>",
 btns:[phaser(P4,'↗ Surish')],
 after:"<p>Gorizontal bo'laklar birgalikda <b>pastki tomonga teng</b>, vertikal bo'laklar — <b>chap tomonga teng</b>. Zinapoya perimetri = (6 + 6) · 2 = <b>24 m</b>.</p><p>⚠️ Bu usul faqat chiqiq <b>ichkariga</b> kirmasa ishlaydi (masalan, «П» shaklida ichki chuqurlik devorlari qo'shimcha qo'shiladi).</p>",
 q:{t:"Barcha burchaklari to'g'ri zinapoya shaklining eni 8 m, balandligi 5 m. Perimetri?",opts:["13 m","40 m","26 m","20 m"],ok:2,why:"(8 + 5) · 2 = 26 m.",hint:"Pog'onalarni surib, o'rab turgan to'g'ri to'rtburchakni tasavvur qiling.",full:"Bo'laklarni surganda 8 × 5 to'g'ri to'rtburchak chiqadi: (8 + 5) · 2 = 26 m. «13» — yarmi, «40» — 8 · 5 (yuz bilan adashgan)."},
 tn:"Katakli qog'ozda zinapoya chizdirib, bolalarga kataklarni sanab tekshirtiring — surish usuli to'g'riligiga o'zlari ishonsin."},
{h:"Teskari masala",sum:"Perimetr va eni berilsa: bo'yi = P : 2 − eni.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Masala: <i>«To'g'ri to'rtburchakning perimetri 64 sm, eni 14 sm. Bo'yi necha sm?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>Avval <b>yarim perimetr</b>: 64 : 2 = 32 (bu bo'yi + eni). Keyin <b>ayiramiz</b>: 32 − 14 = <b>18 sm</b>.</p>",
 q:{t:"Perimetri 46 sm, bo'yi 14 sm. Eni qancha?",opts:["32 sm","9 sm","18 sm","23 sm"],ok:1,why:"46 : 2 = 23, 23 − 14 = 9 sm.",hint:"Avval perimetrni 2 ga bo'ling.",full:"46 : 2 = 23 — bo'yi + eni. 23 − 14 = 9 sm. «32» — 46 − 14 (2 ga bo'linmagan), «23» — faqat yarim perimetr."},
 tn:"Eng ko'p xato: P − eni deb hisoblash. Doskada to'rtburchakning ikki «yarmi»ni chizib ko'rsating."},
{h:"Tuzoq: kvadratlarni yonma-yon qo'yish",sum:"Yonma-yon qo'yilganda ichki tomonlar perimetrga kirmaydi: 3 kvadrat (4 sm) → 12 × 4, P = 32 sm.",a:"m06",
 start:function(){h1Sq3(0);g3Msg('Tomoni 4 sm bo‘lgan 3 ta kvadrat yonma-yon. Perimetr qancha?')},fin:function(){h1Sq3(2);g3Msg('P = <b>32 sm</b>')},
 html:"<p>Tomoni <b>4 sm</b> bo'lgan 3 ta kvadrat yonma-yon qo'yilib, to'g'ri to'rtburchak hosil qilindi. Uning perimetri qancha? Javoblarni sinang:</p>",
 btns:[["48 sm",function(){h1Sq3(1);g3Msg('3 · 16 = 48 — ichki tomonlar ham sanaldi ✗')}],["32 sm",function(c,done){h1Sq3(2);g3Msg('To‘g‘ri! Bo‘yi 12, eni 4: <b>32 sm</b>');done()},'u'],["16 sm",function(){h1Sq3(3);g3Msg('16 — faqat bitta kvadratning perimetri ✗')}]],g3:1,
 after:"<p>Perimetr — faqat <b>tashqi chegara</b>. Kvadratlar tutashgan tomonlar ichkarida qoladi. Yangi shakl: bo'yi 4 · 3 = 12 sm, eni 4 sm, P = (12 + 4) · 2 = <b>32 sm</b>.</p>",
 q:{t:"Tomoni 5 sm bo'lgan 2 ta kvadrat yonma-yon qo'yildi. Hosil bo'lgan shakl perimetri?",opts:["40 sm","30 sm","20 sm","50 sm"],ok:1,why:"Bo'yi 10, eni 5: (10 + 5) · 2 = 30 sm.",hint:"Tutashgan tomonlar tashqi chegaraga kiradimi?",full:"Yangi to'g'ri to'rtburchak 10 × 5: P = 30 sm. «40» — 2 · 20 (ichki tomonlar ham sanalgan), «20» — bitta kvadrat."},
 tn:"Qog'ozdan 3 ta kvadrat qirqib, bolalar turli tartibda (qator, burchak) qo'ysin va perimetrni sanasin."},
{h:"Bir ip — turli shakllar",sum:"Perimetri bir xil (20 sm) to'g'ri to'rtburchaklar har xil bo'ladi: 9×1, 8×2, 7×3, 6×4, 5×5.",a:"m07",
 start:function(){S.ra=9;h1Rope(9)},fin:function(){h1Rope(5)},
 html:"<p>Uzunligi <b>20 sm</b> bo'lgan ipdan to'g'ri to'rtburchak yasaymiz. Ipni qayta-qayta tortib, boshqa shakl hosil qiling:</p>",
 btns:[["↻ Boshqa shakl",function(c,done){S.ra=S.ra>5?S.ra-1:9;h1Rope(S.ra);mvK(done,3)}]],
 after:"<p>Hamma shakllarda <b>bo'yi + eni = 10</b>, perimetr doim 20 sm. Lekin ichidagi kataklar soni har xil! Eng ko'p katak — <b>kvadratda</b> (5 × 5 = 25).</p>",
 q:{t:"Perimetri 24 sm bo'lgan to'g'ri to'rtburchakning bo'yi 8 sm. Eni?",opts:["16 sm","4 sm","3 sm","12 sm"],ok:1,why:"24 : 2 = 12, 12 − 8 = 4.",hint:"Bo'yi + eni = P : 2.",full:"Bo'yi + eni = 12, eni = 12 − 8 = 4 sm. «16» — 24 − 8, «3» — 24 : 8, «12» — yarim perimetr."},
 tn:"Har bolaga 20 sm ip bering — katakli daftarda turli to'rtburchak yasab, kataklarni sanasin (Gollandiya RME usuli)."},
{h:"Tuzoq: «dan uzun, dan qisqa»",sum:"AC = 19, AB = 19 + 6 = 25, AB BC dan 5 qisqa → BC = 30; P = 74 sm.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>Masala: <i>«ABC uchburchakda AB tomon BC dan 5 sm qisqa, AC dan esa 6 sm uzun. AC = 19 sm. Perimetrni toping.»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Diqqat: «AB BC dan <b>qisqa</b>» — demak BC <b>uzun</b>, unga qo'shamiz: 25 + 5 = 30. P = 19 + 25 + 30 = <b>74 sm</b>.</p>",
 q:{t:"AB = 20 sm, BC AB dan 7 sm uzun, AC BC dan 9 sm qisqa. Perimetr?",opts:["47 sm","65 sm","83 sm","56 sm"],ok:1,why:"BC = 27, AC = 18, P = 20 + 27 + 18 = 65.",hint:"Har tomonni alohida toping: avval BC, keyin AC.",full:"BC = 20 + 7 = 27, AC = 27 − 9 = 18. P = 65 sm. «83» — AC = 27 + 9 deb olingan, «47» — AC unutilgan."},
 tn:"Har tomonni kesma chizmasi bilan ko'rsating: qaysi kesma uzunroq ekanini chizmada ko'rish oson."},
{h:"Bilasizmi? Futbol maydoni",sum:"«Perimetr» — yunoncha «atrofini o'lchayman». Futbol maydoni 105 × 68 m, perimetri 346 m.",a:"m09",
 start:function(){h1Field(0)},fin:function(){h1Field(1)},
 html:"<p>📜 «Perimetr» so'zi yunoncha: <b>peri</b> — «atrofida», <b>metreo</b> — «o'lchayman».</p><p>⚽ Xalqaro futbol o'yinlari uchun maydon odatda <b>105 m × 68 m</b> bo'ladi. Atrofini aylanib yugursangiz qancha bo'ladi?</p>",
 btns:[["🏃 Aylanib chiqish",function(c,done){h1Field(1);done()}]],
 after:"<p>(105 + 68) · 2 = <b>346 m</b>. 3 marta aylansangiz — 1 km dan ortiq!</p>",
 tn:"Maktab hovlisi yoki sport maydonini qadam bilan o'lchab, perimetrini taxmin qiling."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h1Ant(4)},fin:function(){h1Ant(4)},
 html:"<div class='memo'><ul><li>Perimetr — barcha tomonlar <b>yig'indisi</b> (uzunlik birligida).</li><li>To'g'ri to'rtburchak: <b>P = (bo'yi + eni) · 2</b>; kvadrat: <b>P = tomon · 4</b>.</li><li>Muntazam shakl: <b>P = tomon · soni</b>; tomon = P : soni.</li><li>Teskari: eni = <b>P : 2 − bo'yi</b>.</li><li>Yonma-yon shakllar: ichki tomonlar <b>kirmaydi</b>.</li><li>Zinapoya: pog'onalarni surib — to'g'ri to'rtburchak.</li><li>Birliklar bir xil bo'lsin: 4 sm 6 mm = 46 mm.</li></ul></div>",
 tn:"Uyga vazifa: xonangiz yoki stolingiz perimetrini o'lchab keling."}
];
var PROBS=[
{t:"Kvadratning tomoni 7 sm. Perimetri?",o:["28 sm","49 sm","14 sm","21 sm"],k:0,s:"7 · 4 = 28."},
{t:"To'g'ri to'rtburchakning bo'yi 8 sm, eni 5 sm. Perimetri?",o:["26 sm","13 sm","40 sm","21 sm"],k:0,s:"(8 + 5) · 2 = 26."},
{t:"Teng tomonli uchburchakning tomoni 9 sm. Perimetri?",o:["27 sm","18 sm","36 sm","81 sm"],k:0,s:"9 · 3 = 27."},
{t:"Muntazam oltiburchakning tomoni 5 sm. Perimetri?",o:["30 sm","25 sm","20 sm","35 sm"],k:0,s:"5 · 6 = 30."},
{t:"Teng tomonli uchburchakning perimetri 13 dm 5 sm. Bir tomoni?",o:["45 sm","15 sm","5 sm","135 sm"],k:0,s:"135 : 3 = 45 sm."},
{t:"Uzunligi 24 sm ipdan kvadrat yasaldi. Tomoni?",o:["6 sm","12 sm","8 sm","4 sm"],k:0,s:"24 : 4 = 6."},
{t:"Kvadratning tomoni 1 m 2 dm. Perimetri necha dm?",o:["48 dm","16 dm","44 dm","24 dm"],k:0,s:"12 · 4 = 48 dm."},
{t:"Uchburchakning perimetri 140 mm, ikki tomoni 43 mm dan. Uchinchi tomoni?",o:["54 mm","97 mm","44 mm","64 mm"],k:0,s:"140 − 86 = 54."},
{t:"Teng yonli uchburchakning perimetri 26 sm, asosi 10 sm. Yon tomoni?",o:["8 sm","16 sm","18 sm","13 sm"],k:0,s:"(26 − 10) : 2 = 8."},
{t:"To'g'ri to'rtburchakning perimetri 46 sm, bo'yi 14 sm. Eni?",o:["9 sm","32 sm","18 sm","23 sm"],k:0,s:"46 : 2 − 14 = 9."},
{t:"Bo'yi 64 sm, eni bo'yidan 18 sm qisqa. Perimetri?",o:["220 sm","110 sm","164 sm","128 sm"],k:0,s:"Eni 46; (64 + 46) · 2 = 220."},
{t:"Tomoni 5 sm bo'lgan 3 ta kvadrat yonma-yon qo'yildi. Hosil bo'lgan to'g'ri to'rtburchak perimetri?",o:["40 sm","60 sm","20 sm","45 sm"],k:0,s:"15 × 5: (15 + 5) · 2 = 40."},
{t:"Kvadrat gulzorning tomoni 6 m. Atrofi 3 qator sim bilan o'raldi. Necha metr sim kerak?",o:["72 m","24 m","18 m","108 m"],k:0,s:"24 · 3 = 72."},
{t:"Kvadratning perimetri 36 sm. To'g'ri to'rtburchakning perimetri ham 36 sm, bo'yi 11 sm. Eni?",o:["7 sm","25 sm","9 sm","14 sm"],k:0,s:"36 : 2 − 11 = 7."},
{t:"To'g'ri to'rtburchakning tomonlari 3 sm 4 mm va 2 sm 6 mm. Perimetri necha mm?",o:["120 mm","60 mm","100 mm","12 mm"],k:0,s:"(34 + 26) · 2 = 120."},
{t:"Barcha burchaklari to'g'ri zinapoya shaklining eni 8 m, balandligi 5 m. Perimetri?",o:["26 m","13 m","40 m","20 m"],k:0,s:"(8 + 5) · 2 = 26."},
{t:"AB = 20 sm, BC AB dan 7 sm uzun, AC BC dan 9 sm qisqa. Uchburchak perimetri?",o:["65 sm","83 sm","47 sm","56 sm"],k:0,s:"20 + 27 + 18 = 65."},
{t:"Uchburchakning perimetri 45 sm, bir tomoni 13 sm. Qolgan ikkitasidan biri ikkinchisidan 4 sm uzun. Eng uzun tomoni?",o:["18 sm","14 sm","32 sm","16 sm"],k:0,s:"45 − 13 = 32; 14 va 18."},
{t:"Bo'yi 9 sm, eni 5 sm. Har bir tomoni 3 sm ga uzaytirildi. Yangi perimetr?",o:["40 sm","34 sm","31 sm","46 sm"],k:0,s:"(12 + 8) · 2 = 40."},
{t:"ABCD perimetri 100 sm. AB = 30 sm, BC AB dan 12 sm qisqa, CD BC dan 4 sm uzun. AD?",o:["30 sm","52 sm","22 sm","40 sm"],k:0,s:"BC 18, CD 22; 100 − 70 = 30."}
];
function PRACT_STAGE(){h1Half(2);g3Msg('P = (bo‘yi + eni) · 2')}
var PREP_DATA={teach:["Perimetr — tomonlar yig'indisi; to'g'ri to'rtburchak va kvadrat formulasi.","Muntazam ko'pburchaklar perimetri va teskari masala (tomonni topish).","Nostandart shakllar: zinapoya, yonma-yon qo'yilgan kvadratlar.","Teskari masala: P va bir tomon bo'yicha ikkinchisini topish; «dan uzun/qisqa» masalalari."],
 mist:["P = bo'yi · eni deb hisoblaydi (yuz bilan adashtiradi).","(a + b) · 2 o'rniga a + b yoki a · 2 + b yozadi.","Teskari masalada P − eni qiladi (2 ga bo'lmaydi).","Yonma-yon kvadratlarda ichki tomonlarni ham sanaydi.","Turli birliklarni (sm va mm) bir-biriga qo'shib yuboradi."],
 need:["Ip (20 sm), chizg'ich, katakli qog'oz.","Qog'oz kvadratlar (3 ta), gugurt cho'plari."],
 board:["<span class='w2'>P = (a + b) · 2</span>, <span class='w2'>P = a · 4</span>.","Muntazam: <span class='w2'>P = a · n</span>.","Teskari: <span class='w2'>b = P : 2 − a</span> (64 : 2 − 14 = 18).","3 kvadrat (4 sm): <span class='w2'>(12 + 4) · 2 = 32</span>, 48 emas!","Zinapoya → to'g'ri to'rtburchak: (6 + 6) · 2 = 24."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
