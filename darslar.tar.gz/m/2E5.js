var CODE='2E5',TITLE='2-sinf · Massa (kg) va sig‘im (litr)';
function e5Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// pallali tarozi: L va R — [{t:'🍉',w:5,lab:''}] yoki tosh {kg}
function e5Scale(L,R,o){o=o||{};clear();var g=S.g,sum=function(a){return a.reduce(function(s,x){return s+x.w},0)},l=sum(L),r=sum(R),d=Math.max(-1,Math.min(1,(r-l)/5)),ang=d*12;
 E('path',{d:'M180 150 L160 168 L200 168 Z',fill:'#8a5a24'},g);E('rect',{x:176,y:60,width:8,height:92,fill:'#8a5a24'},g);
 var bm=E('g',{transform:'rotate('+ang+' 180 60)'},g);E('rect',{x:60,y:56,width:240,height:8,rx:4,fill:'#a0703c'},bm);
 [[70,L,-1],[290,R,1]].forEach(function(z){var x=z[0],items=z[1],dy=(z[2]===-1?-1:1)*d*0;var pg=E('g',{},bm);E('line',{x1:x,y1:60,x2:x-30,y2:110,stroke:'#6b4a2a','stroke-width':1.5},pg);E('line',{x1:x,y1:60,x2:x+30,y2:110,stroke:'#6b4a2a','stroke-width':1.5},pg);
  E('path',{d:'M'+(x-40)+' 110 Q'+x+' 130 '+(x+40)+' 110 Z',fill:'#cfd6de',stroke:'#7b8794'},pg);
  items.forEach(function(it,i){var ix=x-28+(i%4)*18,iy=104-Math.floor(i/4)*18;if(it.kg){E('path',{d:'M'+(ix-7)+' '+(iy+6)+' L'+(ix-5)+' '+(iy-8)+' L'+(ix+5)+' '+(iy-8)+' L'+(ix+7)+' '+(iy+6)+' Z',fill:'#5b6b7b'},pg);T(pg,ix,iy+3,it.kg+'',{'font-size':8,'font-weight':800,fill:'#fff'})}else T(pg,ix+(items.length===1?28:0),iy+(items.length===1?-2:4),it.t,{'font-size':items.length===1?30:16})})});
 if(!o.nolab){T(g,70,160,o.ll||'',{'font-size':12,'font-weight':800,fill:C.blue});T(g,290,160,o.rl||'',{'font-size':12,'font-weight':800,fill:C.blue})}
 return {l:l,r:r}}
function e5Stones(arr){return arr.map(function(k){return {kg:k,w:k}})}
// idishlar
function e5Jug(x,y,w,h,cap,fill,lab,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,rx:6,fill:'#f4f8fb',stroke:'#7b8794','stroke-width':2},g);if(fill>0){var fh=h*Math.min(1,fill/cap);E('rect',{x:x+2,y:y+h-fh,width:w-4,height:fh-2,rx:4,fill:'#7fc3f0'},g)}
 if(o.ticks)for(var i=1;i<cap;i++)E('line',{x1:x,y1:y+h-h*i/cap,x2:x+8,y2:y+h-h*i/cap,stroke:'#7b8794'},g);T(g,x+w/2,y+h+16,lab,{'font-size':11,'font-weight':800,fill:'#1d2b3a'})}
var P3=[function(){e5Scale([{t:'☁️',w:1}],[{t:'🔩',w:1}],{ll:'1 kg paxta',rl:'1 kg temir'});e5Msg('Qaysi biri og‘irroq: 1 kg paxtami yoki 1 kg temirmi?')},
 function(){e5Scale([{t:'☁️',w:1}],[{t:'🔩',w:1}],{ll:'1 kg paxta',rl:'1 kg temir'});e5Msg('Tarozi <b>teng</b>! Ikkalasi ham 1 kg. Paxta ko‘proq joy egallaydi, lekin og‘irligi bir xil')}];
var P5=[function(){clear();e5Jug(30,40,60,100,10,0,'chelak 10 l',{ticks:1});e5Jug(250,90,40,50,2,2,'banka 2 l');e5Msg('Chelakka 10 l sig‘adi. 2 litrli banka bilan necha marta quyish kerak?')}];
var P6=[function(){clear();e5Jug(30,30,70,120,20,20,'idish 20 l',{ticks:1});e5Msg('Idishda 20 l suv. 3 litrli chelak bilan necha marta TO‘LA chelak olinadi?')},
 function(){clear();var g=S.g;e5Jug(30,30,70,120,20,2,'qoldi 2 l',{ticks:1});for(var i=0;i<6;i++){e5Jug(120+i*38,96,30,40,3,3,'3 l')}T(g,230,80,'3 · 6 = 18 l',{'font-size':13,'font-weight':800,fill:C.blue});e5Msg('6 ta to‘la chelak = 18 l, <b>2 l</b> qoldi — 7-chelak to‘lmaydi. Javob: <b>6 marta</b>')}];
var STEPS=[
{h:"Og'ir va yengil: tarozi",sum:"Og'ir narsa turgan palla pastga tushadi. Teng bo'lsa — tarozi muvozanatda.",a:"m01",
 start:function(){e5Scale([],[],{});e5Msg('Pallalarga narsa qo‘ying')},fin:function(){e5Scale([{t:'🍉',w:5}],[{t:'🍎',w:1}],{ll:'tarvuz',rl:'olma'});e5Msg('Tarvuz og‘ir — chap palla pastga tushdi')},
 html:"<p>Pallali tarozi qaysi narsa og'irroq ekanini ko'rsatadi. Pallalarga narsa qo'ying:</p>",
 btns:[["🍉 chapga",function(c,done){S.e5l=[{t:'🍉',w:5}];e5Upd(done)}],["🍎 o'ngga",function(c,done){S.e5r=[{t:'🍎',w:1}];e5Upd(done)},'u'],["🍉 o'ngga",function(c,done){S.e5r=[{t:'🍉',w:5}];e5Upd(done)},'u']],g3:1,
 after:"<p><b>Og'ir</b> narsa turgan palla <b>pastga</b> tushadi, yengili ko'tariladi. Pallalar teng tursa — narsalar bir xil og'irlikda, tarozi <b>muvozanatda</b>.</p>",
 q:{t:"Tarozining o'ng pallasi pastga tushdi. Bu nimani bildiradi?",opts:["O'ngdagi narsa yengil","O'ngdagi narsa og'ir","Ikkalasi teng","Tarozi buzilgan"],ok:1,why:"Og'ir narsa pastga tortadi.",hint:"Qaysi narsa pallani pastga tortadi — og'irimi yoki yengilmi?",full:"Palla og'ir narsa tomoniga pastga tushadi. O'ng palla pastda — demak o'ngdagi narsa og'irroq."},
 tn:"Sinfda chizg'ich va qalamdan oddiy tarozi yasang: ikki uchiga paket ilib, narsalarni solishtiring."},
{h:"Kilogramm: toshlar bilan o'lchash",sum:"Qovun = 2 kg + 2 kg + 1 kg = 5 kg — tarozi muvozanatda bo'lganda.",a:"m02",
 start:function(){S.e5s=[];e5W()},fin:function(){S.e5s=[2,2,1];e5W()},
 html:"<p>Massa <b>kilogramm</b> (kg) bilan o'lchanadi. Chap pallada qovun. O'ng pallaga toshlar qo'yib, tarozini <b>muvozanatga</b> keltiring:</p>",
 btns:[["+ 2 kg",function(c,done){e5Ws(2,done)}],["+ 1 kg",function(c,done){e5Ws(1,done)}],["↺",function(){S.e5s=[];e5W()},'u']],g3:1,
 after:"<p>Tarozi teng turdi: qovun = 2 + 2 + 1 = <b>5 kg</b>. Toshlar — o'lchov birligi, xuddi chizg'ichdagi santimetrlar kabi.</p>",
 q:{t:"Chap pallada qovun, o'ngda 2 kg, 2 kg va 1 kg li toshlar. Tarozi teng. Qovun necha kg?",opts:["3 kg","5 kg","4 kg","6 kg"],ok:1,why:"2 + 2 + 1 = 5 kg.",hint:"Muvozanatda ikki palla teng. O'ngdagi toshlarni qo'shing.",full:"Tarozi teng tursa, qovun o'ng palladagi hamma toshlarga teng: 2 + 2 + 1 = 5 kg. «3 kg» — toshlar sonini sanagan."},
 tn:"Do'kon tarozisini eslating. Bolalar uydagi 1 kg li narsani (shakar, un) qo'lda ushlab, «1 kg qancha» ekanini his qilsin."},
{h:"Tuzoq: paxta va temir",sum:"1 kg paxta = 1 kg temir. Hajmi har xil, massasi bir xil.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Mashhur topishmoq: <i>«Qaysi biri og'irroq: 1 kg paxtami yoki 1 kg temirmi?»</i> Ko'pchilik «temir» deydi. Tarozida tekshiramiz:</p>",
 btns:[phaser(P3,'⚖️ Tarozida tortish')],
 after:"<p>Ikkalasi ham <b>1 kg</b> — teng! Paxta katta va yumshoq, temir kichik va qattiq, lekin <b>massa</b> bir xil. Katta narsa har doim og'ir bo'lavermaydi: kichik tosh katta yostiqdan og'irroq bo'lishi mumkin.</p>",
 q:{t:"Qaysi biri og'irroq: 2 kg un yoki 2 kg mix?",opts:["mix","un","teng","aytib bo'lmaydi"],ok:2,why:"Ikkalasi 2 kg.",hint:"Ikkalasining massasi qancha deb aytilgan?",full:"Shartda ikkalasi ham 2 kg deyilgan — massalari teng. Qaysi narsa ekani ahamiyatsiz."},
 tn:"Topishmoq bolalarni «katta = og'ir» degan noto'g'ri fikrdan qaytaradi. Katta shar va kichik tosh bilan ham ko'rsating."},
{h:"Massa bilan amallar",sum:"Tarvuz 7 kg, qovun 3 kg yengil → qovun 4 kg, birga 11 kg.",a:"m04",
 start:function(){e5Bars(0)},fin:function(){e5Bars(2)},
 html:"<p>Masala: <i>«Tarvuz 7 kg, qovun esa tarvuzdan 3 kg yengil. Tarvuz va qovun birgalikda necha kilogramm?»</i></p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.e5b=(S.e5b||0)+1;e5Bars(S.e5b);if(S.e5b>=2){b.disabled=true;done()}}]],
 after:"<p>Ikki qadam: 1) qovun: 7 − 3 = <b>4 kg</b>; 2) birga: 7 + 4 = <b>11 kg</b>. «10 kg» deganlar 7 + 3 ni qo'shgan — «3 kg yengil» qovunning o'zi emas!</p>",
 q:{t:"Bir qopda 25 kg un bor. 3 qop un necha kilogramm?",opts:["28 kg","75 kg","65 kg","50 kg"],ok:1,why:"25 + 25 + 25 = 75 kg.",hint:"Har qopda 25 kg. Uchta qop-chi?",full:"25 + 25 = 50, yana 25 — 75 kg. Yoki 25 · 3 = 75. «28» — 25 + 3 qo'shgan."},
 tn:"«…kg yengil/og'ir» — 2D2 dagi «…ta kam/ko'p» ning massa ko'rinishi. Chizma model bilan chizdiring."},
{h:"Litr: sig'im",sum:"Suyuqlik litr (l) bilan o'lchanadi. 10 l chelakni 2 l banka bilan 5 marta to'ldiramiz.",a:"m05",
 start:function(){S.e5p=0;P5[0]()},fin:function(){S.e5p=5;e5Pour()},
 html:"<p>Suv, sut, benzin kabi suyuqliklar <b>litr</b> (l) bilan o'lchanadi. Chelakka <b>10 l</b> sig'adi. 2 litrli banka bilan quying:</p>",
 btns:[["🫙 Banka quyish (+2 l)",function(c,done,b){if(S.e5p<5){S.e5p++;e5Pour();if(S.e5p===5){b.disabled=true;done()}}}]],
 after:"<p>5 marta quydik: 2 + 2 + 2 + 2 + 2 = <b>10 l</b>. Idishga qancha suyuqlik sig'ishi — uning <b>sig'imi</b>. Bitta katta shisha suv — taxminan 1 litr.</p>",
 q:{t:"Katta chelakka 8 l, kichigiga 3 l sig'adi. 2 ta katta va 3 ta kichik chelakni to'ldirish uchun necha litr suv kerak?",opts:["11 l","25 l","22 l","33 l"],ok:1,why:"16 + 9 = 25 l.",hint:"Avval 2 ta katta chelak, keyin 3 ta kichik chelak uchun alohida hisoblang.",full:"2 ta katta: 8 + 8 = 16 l. 3 ta kichik: 3 + 3 + 3 = 9 l. Jami: 16 + 9 = 25 l. «11» — har biridan bittadan olgan."},
 tn:"1 litrli shisha va chelak bilan amaliy tajriba qiling — bolalar «necha marta quyiladi» ni o'zi sanasin."},
{h:"Tuzoq: to'la chelaklar soni",sum:"20 l dan 3 l lik chelak bilan: 6 ta to'la chelak (18 l), 2 l qoladi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Masala: <i>«Katta idishda 20 l suv bor. Undan 3 litrli chelak bilan necha marta to'la chelak olish mumkin?»</i></p>",
 btns:[phaser(P6,'🪣 Chelaklarga quyish')],
 after:"<p>3 lab sanaymiz: 3, 6, 9, 12, 15, <b>18</b> — 6 ta chelak. 21 bo'lsa 20 dan oshadi. Qolgan <b>2 l</b> chelakni to'ldirmaydi. «To'la chelak» deyilgani uchun javob — <b>6</b> (7 emas).</p>",
 q:{t:"Bochkada 25 l suv bor. 4 litrli chelak bilan necha marta to'la chelak olinadi?",opts:["7","6","5","4"],ok:1,why:"4 · 6 = 24 ≤ 25, 4 · 7 = 28 > 25.",hint:"4 lab sanang: 4, 8, 12 … 25 dan oshmaguncha.",full:"4, 8, 12, 16, 20, 24 — 6 marta. Keyin 28 bo'lardi, bu 25 dan ko'p. 1 l qoladi. Javob: 6."},
 tn:"Bu — keyinroq o'rganiladigan qoldiqli bo'lishning hayotiy ko'rinishi (25 : 4 = 6, qoldiq 1)."},
{h:"Shakl aldaydi: qaysi idishda ko'p?",sum:"Baland ingichka va past keng idishda suv bir xil bo'lishi mumkin. Suvni bitta idishga quyib tekshiring.",a:"m07",
 start:function(){e5Two(false)},fin:function(){e5Two(true)},
 html:"<p>Ikki idishda suv bor. Baland idishda suv balandroq ko'rinadi. Unda suv ko'pmi? Tekshirish uchun ikkalasini bir xil o'lchov idishiga quyamiz:</p>",
 btns:[["🔁 O'lchov idishiga quyish",function(c,done){e5Two(true);done()}]],
 after:"<p>Ikkalasida ham <b>1 l</b> chiqdi! Suv sathi idish <b>shakliga</b> bog'liq: ingichka idishda baland, keng idishda past. Qancha suv borligini bilish uchun uni o'lchash kerak — ko'z bilan chamalash aldaydi.</p>",
 q:{t:"Ingichka stakanda suv balandroq turibdi, keng kosada pastroq. Ikkalasiga 1 l dan quyilgan. Qayerda suv ko'p?",opts:["Stakanda","Kosada","Teng","Kosada, chunki keng"],ok:2,why:"Ikkalasida 1 l — teng.",hint:"Har biriga qancha suv quyilgan?",full:"Ikkalasiga ham 1 l quyilgan — suv teng. Sath balandligi idish eniga bog'liq, suv miqdoriga emas."},
 tn:"Bu — mashhur Piaget tajribasi. Ikki xil idishga bir xil suvni bolalar oldida quying, avval taxmin qilsin."},
{h:"Bilasizmi? Kilogramm qayerda saqlangan",sum:"1889–2019 yillarda kilogramm namunasi Fransiyada saqlangan metall silindr edi.",a:"m08",
 start:function(){e5Kg()},fin:function(){e5Kg()},
 html:"<p>🏛 Uzoq yillar davomida butun dunyo uchun «haqiqiy kilogramm» — Fransiyada, Parij yaqinida shisha qalpoq ostida saqlangan <b>metall silindr</b> edi (1889-yildan).</p><p>🔬 2019-yildan olimlar kilogrammni silindr bilan emas, tabiatning o'zgarmas qonunlari orqali aniqlashga o'tdi — endi u hech qachon yo'qolmaydi yoki o'zgarmaydi.</p><p>⚖️ Bizning bozorlarda qadimda <b>botmon</b> va <b>qadoq</b> kabi o'lchovlar ishlatilgan.</p>",
 tn:"Bolalar uydan «1 kg» yozilgan qadoq olib kelib, qo'lda ushlab solishtirsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.e5s=[2,2,1];e5W()},fin:function(){S.e5s=[2,2,1];e5W()},
 html:"<div class='memo'><ul><li>Massa — <b>kilogramm (kg)</b>, pallali tarozida toshlar bilan o'lchanadi.</li><li>Og'ir narsa pallasi <b>pastga</b> tushadi; teng bo'lsa — muvozanat.</li><li>1 kg paxta = 1 kg temir: <b>katta ≠ og'ir</b>.</li><li>Suyuqlik — <b>litr (l)</b>; idishga sig'adigan suv — sig'im.</li><li>«To'la chelak nechta?»: 3 lab sanang, oshib ketmasin: 20 l → 6 ta (2 l qoladi).</li><li>Suv sathi idish shakliga bog'liq — <b>o'lchab</b> taqqoslang.</li></ul></div>",
 tn:"Keyingi darsni «Tarvuz 6 kg, qovun undan 2 kg og'ir. Birga?» (14 kg) savoli bilan boshlang."}
];
function e5Upd(done){var L=S.e5l||[],R=S.e5r||[],res=e5Scale(L,R,{ll:L.length?(L[0].t==='🍉'?'tarvuz':''):'',rl:R.length?(R[0].t==='🍉'?'tarvuz':'olma'):''});
 if(L.length&&R.length)e5Msg(res.l>res.r?'Chap og‘ir — chap palla pastda':(res.l<res.r?'O‘ng og‘ir — o‘ng palla pastda':'Teng — tarozi <b>muvozanatda</b>'));else e5Msg('Ikkinchi pallaga ham narsa qo‘ying');mvK(done,2)}
function e5W(){var s=S.e5s||[],sum=s.reduce(function(a,b){return a+b},0);e5Scale([{t:'🍈',w:5}],e5Stones(s),{ll:'qovun',rl:sum+' kg'});e5Msg(sum<5?'Toshlar: '+sum+' kg — qovun og‘irroq':(sum===5?'Muvozanat! Qovun = <b>'+s.join(' + ')+' = 5 kg</b>':'Toshlar '+sum+' kg — ko‘p bo‘lib ketdi, ↺ bosing'));return sum}
function e5Ws(k,done){S.e5s=S.e5s||[];if(S.e5s.reduce(function(a,b){return a+b},0)>=7)return;S.e5s.push(k);if(e5W()===5)done()}
function e5Bars(k){clear();var g=S.g;S.e5b=k;E('rect',{x:30,y:30,width:245,height:30,rx:4,fill:'#9fd3a8',stroke:'#2e7d32'},g);T(g,152,50,'tarvuz 7 kg',{'font-size':12,'font-weight':800});
 if(k>=1){E('rect',{x:30,y:80,width:140,height:30,rx:4,fill:'#f6c343',stroke:'#a07a1c'},g);T(g,100,100,'qovun 4 kg',{'font-size':12,'font-weight':800});E('rect',{x:170,y:80,width:105,height:30,rx:4,fill:'none',stroke:C.bad,'stroke-dasharray':'4 3'},g);T(g,222,100,'3 kg yengil',{'font-size':11,'font-weight':800,fill:C.bad})}
 if(k>=2)T(g,180,150,'birga: 7 + 4 = 11 kg',{'font-size':15,'font-weight':800,fill:C.ok});e5Msg(['Tarvuz 7 kg. Qovun undan 3 kg yengil','Qovun: 7 − 3 = <b>4 kg</b>','Birga: 7 + 4 = <b>11 kg</b>'][k])}
function e5Pour(){clear();e5Jug(30,40,60,100,10,S.e5p*2,'chelak: '+S.e5p*2+' l',{ticks:1});e5Jug(250,90,40,50,2,2,'banka 2 l');T(S.g,180,60,S.e5p+' marta',{'font-size':16,'font-weight':800,fill:C.blue});e5Msg(S.e5p<5?S.e5p+' marta · '+(S.e5p*2)+' l':'5 marta · <b>10 l</b> — chelak to‘ldi!')}
function e5Two(on){clear();e5Jug(40,20,40,110,1,1,'ingichka');e5Jug(120,90,90,40,1,1,'keng');if(on){e5Jug(260,40,60,90,2,1,'o‘lchov',{ticks:1});T(S.g,290,32,'1 l = 1 l',{'font-size':12,'font-weight':800,fill:C.ok});e5Msg('Ikkalasidan ham <b>1 l</b> chiqdi — teng!')}else e5Msg('Qaysi idishda suv ko‘p?')}
function e5Kg(){clear();var g=S.g;E('path',{d:'M140 150 L140 70 Q180 20 220 70 L220 150 Z',fill:'rgba(200,225,255,.5)',stroke:'#7b8794','stroke-width':2},g);E('rect',{x:160,y:100,width:40,height:46,rx:4,fill:'#b9bfc6',stroke:'#5b6b7b'},g);E('rect',{x:120,y:150,width:120,height:10,rx:3,fill:'#8a5a24'},g);T(g,180,20,'1 kg namunasi (1889–2019)',{'font-size':12,'font-weight':800,fill:C.blue});e5Msg('Butun dunyo uchun bitta kilogramm')}
var PROBS=[
{t:"Tarozining chap pallasi pastga tushdi. Qaysi pallada narsa og'ir?",o:["chapda","o'ngda","teng","ikkalasi bir xil"],k:0,s:"Og'ir narsa pallani pastga tortadi."},
{t:"Qovun = 2 kg + 2 kg + 1 kg toshlar (tarozi teng). Qovun necha kg?",o:["5 kg","3 kg","4 kg","6 kg"],k:0,s:"2 + 2 + 1 = 5."},
{t:"Qaysi biri og'irroq: 1 kg paxta yoki 1 kg temir?",o:["teng","temir","paxta","temir 2 marta og'ir"],k:0,s:"Ikkalasi 1 kg."},
{t:"Tarvuz 7 kg, qovun undan 3 kg yengil. Birgalikda necha kg?",o:["11 kg","10 kg","4 kg","17 kg"],k:0,s:"Qovun 4 kg; 7 + 4 = 11."},
{t:"Bir qopda 25 kg un. 3 qop necha kg?",o:["75 kg","28 kg","65 kg","50 kg"],k:0,s:"25 · 3 = 75."},
{t:"Chelakka 10 l sig'adi. 2 litrli banka bilan necha marta quyish kerak?",o:["5","8","12","20"],k:0,s:"2 · 5 = 10."},
{t:"Idishda 20 l suv. 3 litrli chelak bilan necha marta to'la chelak olinadi?",o:["6","7","17","23"],k:0,s:"3 · 6 = 18 ≤ 20, 3 · 7 = 21 > 20."},
{t:"Katta chelakka 8 l, kichigiga 3 l. 2 ta katta va 3 ta kichik chelak uchun necha litr?",o:["25 l","22 l","11 l","33 l"],k:0,s:"16 + 9 = 25."},
{t:"Katta idishga 12 l sig'adi, kichigiga undan 3 marta kam. Kichigiga necha litr?",o:["4 l","9 l","15 l","36 l"],k:0,s:"12 : 3 = 4."},
{t:"Sumkada 3 kg kartoshka va 2 kg piyoz. Sumka 1 kg. Hammasi necha kg?",o:["6 kg","5 kg","4 kg","7 kg"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Qaysi biri og'irroq bo'lishi mumkin?",o:["kichkina temir g'o'la","katta ko'pik yostiq","teng","doim kattasi"],k:0,s:"Katta narsa har doim og'ir emas — temir zich va og'ir."},
{t:"Tarozida: chapda 2 ta bir xil qadoq, o'ngda 6 kg tosh. Tarozi teng. Bitta qadoq necha kg?",o:["3 kg","6 kg","2 kg","12 kg"],k:0,s:"2 ta qadoq = 6 kg, bittasi 3 kg."},
{t:"Bochkada 25 l suv. 4 litrli chelak bilan necha marta to'la chelak olinadi?",o:["6","7","5","4"],k:0,s:"4 · 6 = 24 ≤ 25."},
{t:"Sut idishida 5 l sut bor edi. Ertalab 2 l, kechqurun 1 l ichildi. Necha litr qoldi?",o:["2 l","3 l","8 l","1 l"],k:0,s:"5 − 2 − 1 = 2."},
{t:"Olma qutisi 9 kg, nok qutisi undan 4 kg og'ir. Nok qutisi necha kg?",o:["13 kg","5 kg","9 kg","36 kg"],k:0,s:"9 + 4 = 13."},
{t:"Ingichka va keng idishga 1 l dan suv quyildi. Qayerda suv ko'p?",o:["teng","ingichkada","kengda","aytib bo'lmaydi"],k:0,s:"Ikkalasida 1 l."},
{t:"Qaysi narsani kilogrammda o'lchash qulay?",o:["tarvuz","suv","sim uzunligi","vaqt"],k:0,s:"Massa — kg: tarvuz."},
{t:"Qaysi narsani litrda o'lchash qulay?",o:["sharbat","kartoshka","qalam","non"],k:0,s:"Suyuqlik — litr: sharbat."},
{t:"Chelakda 6 l suv bor. Unga yana 3 ta 2 litrli banka suv quyildi. Chelakda necha litr bo'ldi?",o:["12 l","11 l","9 l","8 l"],k:0,s:"6 + 2 · 3 = 12."},
{t:"Tarozida: chapda tarvuz, o'ngda 5 kg va 2 kg toshlar, tarozi teng. Tarvuz qovundan 3 kg og'ir. Qovun necha kg?",o:["4 kg","10 kg","7 kg","3 kg"],k:0,s:"Tarvuz 7 kg; qovun 7 − 3 = 4 kg."}
];
function PRACT_STAGE(){S.e5s=[2,2,1];e5W()}
var PREP_DATA={teach:["Pallali tarozi: og'ir — pastga, teng — muvozanat.","Kilogramm; toshlar bilan o'lchash.","«Katta ≠ og'ir» (paxta va temir); massa bilan amallar.","Litr va sig'im; «to'la chelak nechta?»; idish shakli aldashi."],
 mist:["Katta narsani har doim og'ir deb o'ylaydi.","Toshlar sonini massa deb sanaydi.","«3 kg yengil» ni qovunning massasi deb oladi.","20 l : 3 l da 7 deydi (to'la emasligini hisobga olmaydi)."],
 need:["Pallali tarozi (yoki uydagi oddiy tarozi), 1 kg li qadoq.","1 l shisha, chelak, banka."],
 board:["Tarozi rasmi: <span class='w2'>qovun = 2 + 2 + 1 = 5 kg</span>.","<span class='w2'>1 kg paxta = 1 kg temir</span>.","<span class='w2'>7 − 3 = 4; 7 + 4 = 11 kg</span>.","<span class='w2'>10 l = 2 + 2 + 2 + 2 + 2</span>.","<span class='w2'>3, 6, 9, 12, 15, 18 → 6 ta (2 l qoladi)</span>."]};
