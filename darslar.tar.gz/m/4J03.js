var CODE='4J03',TITLE="4-sinf · Shakllarni sanash";
function k3L(a,b,c,d,col,w){E('line',{x1:a,y1:b,x2:c,y2:d,stroke:col||'#2a4a6a','stroke-width':w||2,'stroke-linecap':'round'},S.g)}
function k3Pts(n,arcs){clear();var x0=40,dx=280/(n-1);for(var i=0;i<n;i++){if(arcs&&i>0)for(var j=0;j<i;j++){if(j!==0)continue;var a=x0+j*dx,b=x0+i*dx;E('path',{d:'M'+a+',82 Q'+(a+b)/2+','+(82-14-i*9)+' '+b+',82',fill:'none',stroke:C.blue,'stroke-width':1.3},S.g)}}k3L(x0,82,x0+280,82,'#2a4a6a',2.5);for(var k=0;k<n;k++){E('circle',{cx:x0+k*dx,cy:82,r:5.5,fill:C.bad},S.g);T(S.g,x0+k*dx,108,'ABCDEFGH'[k],{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}}
function k3Fan(k){clear();var ax=180,ay=16;k3L(40,146,320,146);for(var i=0;i<k;i++){var x=40+i*280/(k-1);k3L(ax,ay,x,146,i===0||i===k-1?'#2a4a6a':C.blue);T(S.g,x,164,String(i+1),{'font-size':11,'font-weight':800,fill:'#3a4a5a'})}}
function k3Grid(r,c,s,hl){clear();s=s||22;var x0=180-c*s/2,y0=88-r*s/2;for(var i=0;i<=r;i++)k3L(x0,y0+i*s,x0+c*s,y0+i*s,'#2a4a6a',1.6);for(var j=0;j<=c;j++)k3L(x0+j*s,y0,x0+j*s,y0+r*s,'#2a4a6a',1.6);if(hl)hl.forEach(function(h){E('rect',{x:x0+h[1]*s,y:y0+h[0]*s,width:h[3]*s,height:h[2]*s,fill:'none',stroke:h[4]||C.bad,'stroke-width':3.5},S.g)})}
function k3Tri(n){clear();var L=150,x0=180-L/2,y0=150,h=L*.866;function P(i,j){return [x0+L*(j+i/2)/n,y0-h*i/n]}for(var i=0;i<=n;i++){var a=P(i,0),b=P(i,n-i);k3L(a[0],a[1],b[0],b[1]);var c=P(0,i),d=P(n-i,i);k3L(c[0],c[1],d[0],d[1]);var e=P(i,0),f=P(0,i);k3L(e[0],e[1],f[0],f[1])}}
function k3Rays(n){clear();var ox=60,oy=146;for(var i=0;i<n;i++){var a=-(i*80/(n-1))*Math.PI/180,x=ox+250*Math.cos(a),y=oy+250*Math.sin(a)*0.52;k3L(ox,oy,x,y,C.blue,2);T(S.g,x+8,y+4,String(i+1),{'font-size':11,'font-weight':800,fill:'#3a4a5a'})}E('circle',{cx:ox,cy:oy,r:5,fill:C.bad},S.g)}
var STEPS=[
J4({h:"Kesmalar: hisoblash yo'li",sum:"6 nuqta: A dan 5 ta, B dan 4 ta yangi, … 5 + 4 + 3 + 2 + 1 = 15 kesma.",a:"m01",
 s:function(){k3Pts(6)},m:"Uchlari shu nuqtalarda bo‘lgan barcha kesmalar nechta?",f:function(){k3Pts(6,1);j3Msg('A dan 5 ta, B dan 4 ta, C dan 3 ta … 5+4+3+2+1 = <b>15</b>')},
 html:"<p>To'g'ri chiziqda 6 ta nuqta belgilangan. Uchlari shu nuqtalarda bo'lgan nechta <b>kesma</b> bor? Kichik kesmalar 5 ta, lekin AC, AD kabi uzunlari ham bor!</p>",
 ch:["5","15","30","21"],ok:1,bad:["5 — faqat qo‘shni nuqtalar orasidagilar. AC, AD-chi?","","6 · 5 = 30 — har kesma ikki marta sanaldi (AB va BA)","21 — bu 7 nuqta uchun"],
 after:"<p>Tartib bilan sanaymiz: A dan boshlanadiganlar 5 ta (AB, AC, AD, AE, AF), B dan yangi 4 ta, C dan 3 ta, … Jami 5 + 4 + 3 + 2 + 1 = <b>15</b>. Boshqa yo'l: har nuqtadan 5 ta, 6 · 5 = 30, lekin har kesma ikki uchidan ikki marta sanaldi: 30 : 2 = 15.</p>",
 q:{t:"To'g'ri chiziqda 8 ta nuqta. Nechta kesma bor?",opts:["28","7","56","36"],ok:0,why:"7 + 6 + … + 1 = 28.",hint:"Birinchi nuqtadan nechta kesma chiqadi?",full:"8 · 7 : 2 = 28 yoki 7 + 6 + 5 + 4 + 3 + 2 + 1 = 28. «56» — ikki marta sanash."},
 tn:"Bu tartibli sanash 4J11 dagi «qo'l siqishlar» bilan bir xil — bolalar o'xshashlikni topsin."}),
J4({h:"Yelpig'ich: uchburchaklar",sum:"Uchidan asosga 5 ta chiziq (yon tomonlar bilan) — har ikki chiziq bitta uchburchak beradi: 4 + 3 + 2 + 1 = 10.",a:"m02",
 s:function(){k3Fan(5)},m:"Har uchburchak — yuqoridagi uchdan chiqqan 2 ta chiziq bilan aniqlanadi",
 f:function(){k3Fan(5);j3Msg('Chiziqlar juftlari: (1,2)…(4,5) — 4+3+2+1 = <b>10</b>')},
 html:"<p>Uchburchakning yuqori uchidan asosga 3 ta chiziq o'tkazilgan (yon tomonlar bilan jami 5 ta chiziq). Rasmda nechta <b>uchburchak</b> bor?</p>",
 ch:["4","7","10","15"],ok:2,bad:["4 — faqat eng kichiklari. Yonma-yon ikkitasi ham uchburchak!","Katta uchburchakni ham, uchtadan birlashganlarini ham sanang","","15 — bu 6 ta chiziq bo‘lganda"],
 after:"<p>Har uchburchakning ikki yon tomoni — yuqori uchdan chiqqan ikkita chiziq, asosi doim pastki chiziq. Demak uchburchaklar soni = 5 ta chiziqdan <b>2 tasini tanlash</b> soni = 4 + 3 + 2 + 1 = 10. Bu kesmalar masalasining o'zi!</p>",
 q:{t:"Uchidan asosga 4 ta chiziq o'tkazildi (yon tomonlar bilan 6 ta chiziq). Nechta uchburchak?",opts:["15","10","5","20"],ok:0,why:"5 + 4 + 3 + 2 + 1 = 15.",hint:"6 ta chiziqdan 2 tasini necha usulda tanlash mumkin?",full:"6 ta chiziq juftlari: 5 + 4 + 3 + 2 + 1 = 15. «5» — faqat kichiklari."},
 tn:"Doskada yelpig'ichni chizing; bolalar har uchburchakni ikki raqam bilan yozsin: (1,3), (2,5) … Shunda hech biri tushib qolmaydi."}),
J4({h:"5×5 to'rdagi kvadratlar",sum:"1×1 — 25, 2×2 — 16, 3×3 — 9, 4×4 — 4, 5×5 — 1. Jami 55.",a:"m03",
 s:function(){k3Grid(5,5,24,[[0,0,2,2,C.bad],[2,1,3,3,C.blue]])},m:"Har o‘lchamdagi kvadratlarni alohida sanaymiz",
 f:function(){j3Lines(['25 + 16 + 9 + 4 + 1','= [55]'],{fs:20,lh:40})},fm:"Har o‘lcham — kvadrat son: 5·5, 4·4, 3·3, 2·2, 1·1",
 html:"<p>5×5 kataklik to'rda nechta <b>kvadrat</b> bor? 2×2 (qizil) va 3×3 (ko'k) kvadratlar ham hisobga kiradi. Har o'lchamni alohida sanang.</p>",
 ch:["25","30","55","50"],ok:2,bad:["25 — faqat 1×1 kataklar","30 — bu 4×4 to‘r uchun","","Qaysidir o‘lcham tushib qoldi: 25+16+9+4+1"],
 after:"<p>2×2 kvadratning chap yuqori burchagi 4 × 4 = 16 joyda turishi mumkin, 3×3 niki 3 × 3 = 9 joyda va hokazo. Shuning uchun javob kvadrat sonlar yig'indisi: 25 + 16 + 9 + 4 + 1 = <b>55</b>.</p>",
 q:{t:"3×3 kataklik to'rda nechta kvadrat bor?",opts:["14","9","13","10"],ok:0,why:"9 + 4 + 1 = 14.",hint:"1×1, 2×2 va 3×3 kvadratlarni alohida sanang.",full:"1×1 — 9, 2×2 — 4, 3×3 — 1. Jami 14. «13» — eng katta kvadratni unutish."},
 tn:"Shaxmat taxtasidagi (8×8) kvadratlar: 64 + 49 + … + 1 = 204 — kuchli o'quvchilarga qo'shimcha."}),
J4({h:"To'g'ri to'rtburchaklar",sum:"2×4 to'r: 3 ta yotiq chiziqdan 2 tasi (3 usul) va 5 ta tik chiziqdan 2 tasi (10 usul): 3 · 10 = 30.",a:"m04",
 s:function(){k3Grid(2,4,30,[[0,1,2,2,C.bad],[1,0,1,3,C.blue]])},m:"To‘g‘ri to‘rtburchak = 2 ta yotiq + 2 ta tik chiziq",
 f:function(){j3Lines(['yotiq chiziqlar: 3 → 3 usul','tik chiziqlar: 5 → 10 usul','3 · 10 = [30]'],{fs:17,lh:34})},fm:"Ko‘paytirish qoidasi: har yotiq juftga har tik juft",
 html:"<p>2×4 kataklik to'rda nechta <b>to'g'ri to'rtburchak</b> bor (kvadratlar ham hisobga kiradi)? Maslahat: har to'g'ri to'rtburchak 2 ta yotiq va 2 ta tik chiziq bilan chegaralangan.</p>",
 ch:["8","18","30","40"],ok:2,bad:["8 — faqat kataklar","Hammasini qo‘lda sanash qiyin — chiziqlar juftini tanlang","","Tik chiziqlar 5 ta: juftlari 4+3+2+1 = 10"],
 after:"<p>Yotiq chiziqlar 3 ta: juft tanlash 2 + 1 = 3 usul. Tik chiziqlar 5 ta: 4 + 3 + 2 + 1 = 10 usul. Har birini har biri bilan birlashtiramiz: 3 · 10 = <b>30</b>. Bu usul to'r qanchalik katta bo'lmasin, ishlaydi.</p>",
 q:{t:"1×5 qatorda (5 ta katak) nechta to'g'ri to'rtburchak bor?",opts:["15","5","10","25"],ok:0,why:"6 ta tik chiziqdan 2 tasi: 15.",hint:"Yotiq chiziqlar 2 ta — bitta usul. Tik chiziqlar nechta?",full:"Tik chiziqlar 6 ta: 5 + 4 + 3 + 2 + 1 = 15. Yotiq — 1 usul. 15 · 1 = 15."},
 tn:"Kichik to'rda (1×3) qo'lda sanab, keyin formula bilan solishtiring: bolalar usulga ishonch hosil qilsin."}),
J4({h:"Tuzoq: teskari uchburchaklar",sum:"Tomoni 3 ga bo'lingan uchburchak: kichik 9 (6 ta ▲, 3 ta ▼), o'rta 3, katta 1 → 13.",a:"m05",
 s:function(){k3Tri(3)},m:"Uchi pastga qaragan ▼ uchburchaklarni ham sanang!",
 f:function(){j3Lines(['kichik: 6 ▲ + 3 ▼ = 9','o‘rta (2 qatorli): 3','katta: 1    jami [13]'],{fs:17,lh:34})},fm:"O‘lcham bo‘yicha va yo‘nalish bo‘yicha alohida sanaymiz",
 html:"<p>Katta uchburchakning har tomoni 3 ga bo'linib, chiziqlar o'tkazilgan. Rasmda <b>jami</b> nechta uchburchak bor?</p>",
 ch:["9","10","13","12"],ok:2,bad:["9 — faqat eng kichiklari","10 — kichiklar va katta. 2 qatorli o‘rta uchburchaklar-chi?","","Bitta o‘lcham tushib qoldi — kattasini ham sanang"],
 after:"<p>Eng kichik: uchi yuqoriga 1 + 2 + 3 = 6, uchi pastga ▼ 3 ta → 9. Ikki qatorli uchburchaklar: 3 ta (pastga qaragan ikki qatorlisi bu shaklga sig'maydi). Eng katta: 1. Jami 9 + 3 + 1 = <b>13</b>. ▼ larni unutish — eng ko'p xato.</p>",
 q:{t:"Uchburchakning har tomoni 2 ga bo'lingan (o'rta chiziqlar). Nechta uchburchak bor?",opts:["5","4","6","3"],ok:0,why:"4 ta kichik + 1 ta katta.",hint:"Kichiklari nechta? Kattasi-chi?",full:"Kichik: 3 ta ▲ va 1 ta ▼ = 4. Katta: 1. Jami 5."},
 tn:"Bolalar har o'lchamdagi uchburchakni boshqa rangda bo'yasin — shunda takror sanash bo'lmaydi."}),
J4({h:"Burchaklar sanash",sum:"Bitta nuqtadan 5 ta nur: har ikki nur — bitta burchak. 4 + 3 + 2 + 1 = 10.",a:"m06",
 s:function(){k3Rays(5)},m:"Har burchak — 2 ta nurdan iborat",f:function(){k3Rays(5);j3Msg('Nurlar juftlari: 4+3+2+1 = <b>10</b> burchak')},
 html:"<p>Bitta nuqtadan bir tomonga 5 ta nur chiqqan. Rasmda nechta <b>burchak</b> bor (har burchak — ikkita nur orasida)?</p>",
 ch:["4","5","10","20"],ok:2,bad:["4 — faqat qo‘shni nurlar orasidagilar","5 — nurlar soni, burchaklar emas","","Har burchak ikki marta sanaldi: 1–3 va 3–1 bitta burchak"],
 after:"<p>Kesmalar, yelpig'ich uchburchaklari, burchaklar — hammasi bitta savolga keladi: <b>n ta narsadan 2 tasini necha usulda tanlash mumkin?</b> Javob: (n − 1) + (n − 2) + … + 1. 5 ta nur → 10.</p>",
 q:{t:"Bitta nuqtadan bir tomonga 7 ta nur chiqqan. Nechta burchak bor?",opts:["21","6","14","42"],ok:0,why:"6 + 5 + 4 + 3 + 2 + 1 = 21.",hint:"Birinchi nur boshqa nurlar bilan nechta burchak hosil qiladi?",full:"7 · 6 : 2 = 21. «42» — har burchakni ikki marta sanash, «6» — faqat qo'shnilar."},
 tn:"Bitta umumiy formula 3 ta masalani hal qiladi — bolalar buni o'zi aytib bersin (yapon usuli: o'quvchi tushuntiradi)."}),
J4info({h:"Bilasizmi? Paskal uchburchagi",a:"m07",s:['1','1\u00a0\u00a0\u00a01','1\u00a0\u00a0\u00a02\u00a0\u00a0\u00a01','1\u00a0\u00a0\u00a03\u00a0\u00a0\u00a03\u00a0\u00a0\u00a01','1\u00a0\u00a0\u00a04\u00a0\u00a0\u00a06\u00a0\u00a0\u00a04\u00a0\u00a0\u00a01'],so:{fs:16,lh:26},m:"Har son — tepasidagi ikki sonning yig‘indisi",
 html:"<p>🔢 Fransuz olimi <b>Blez Paskal</b> (1623–1662) sonli uchburchakni chuqur o'rgangan: har son tepasidagi ikki sonning yig'indisi. Unda «tanlash» sonlari yashiringan: 4-qatordagi 6 — bu 4 ta narsadan 2 tasini tanlash usullari soni. Paskal yoshligida (1642-yil) qo'shish-ayirish bajaradigan hisoblash mashinasini ham yasagan.</p>",
 tn:"Paskal uchburchagini 7-qatorgacha to'ldirtiring. 3-diagonalda 1, 3, 6, 10, 15 — uchburchak sonlar chiqishini ko'rsating."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){k3Grid(3,3,26)},m:"Tartib bilan sanang — o‘lcham bo‘yicha, yo‘nalish bo‘yicha",
 html:"<div class='memo'><ul><li>Sanashni <b>tartib bilan</b>: o'lcham bo'yicha, yo'nalish bo'yicha.</li><li>n ta narsadan 2 tasi: (n − 1) + … + 1 = n · (n − 1) : 2.</li><li>Kesmalar, burchaklar, yelpig'ich uchburchaklari — shu formula.</li><li>n×n to'rdagi kvadratlar: n·n + … + 1·1.</li><li>To'g'ri to'rtburchaklar: yotiq juftlar · tik juftlar.</li><li>▼ uchburchaklarni unutmang!</li></ul></div>",
 tn:"Uyga: 4×4 to'rdagi to'g'ri to'rtburchaklarni sanash (javob 100)."})
];
var PROBS=[
{t:"To'g'ri chiziqda 5 ta nuqta. Uchlari shu nuqtalarda bo'lgan nechta kesma bor?",o:["10","5","4","20"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"To'g'ri chiziqda 7 ta nuqta. Nechta kesma bor?",o:["21","14","7","42"],k:0,s:"6 + 5 + 4 + 3 + 2 + 1 = 21."},
{t:"Tekislikda 6 ta nuqta, hech qaysi uchtasi bir to'g'ri chiziqda emas. Har ikki nuqta kesma bilan tutashtirildi. Nechta kesma?",o:["15","12","30","6"],k:0,s:"6 · 5 : 2 = 15."},
{t:"4×4 kataklik to'rda nechta kvadrat bor?",o:["30","16","25","20"],k:0,s:"16 + 9 + 4 + 1 = 30."},
{t:"2×2 kataklik to'rda nechta kvadrat bor?",o:["5","4","6","8"],k:0,s:"4 ta kichik + 1 ta katta."},
{t:"2×3 kataklik to'g'ri to'rtburchakda nechta kvadrat bor?",o:["8","6","9","7"],k:0,s:"1×1 — 6 ta, 2×2 — 2 ta: jami 8."},
{t:"1×4 qatorda (4 ta katak) nechta to'g'ri to'rtburchak bor?",o:["10","4","8","7"],k:0,s:"5 ta tik chiziqdan 2 tasi: 4 + 3 + 2 + 1 = 10."},
{t:"2×2 kataklik to'rda nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",o:["9","5","4","8"],k:0,s:"Yotiq juftlar 3, tik juftlar 3: 3 · 3 = 9."},
{t:"3×3 kataklik to'rda nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",o:["36","14","18","9"],k:0,s:"4 ta chiziqdan 2 tasi — 6 usul: 6 · 6 = 36."},
{t:"Uchburchakning bir uchidan qarama-qarshi tomonga 2 ta kesma o'tkazildi. Rasmda nechta uchburchak bor?",o:["6","3","4","5"],k:0,s:"Uchdan 4 ta chiziq: 3 + 2 + 1 = 6."},
{t:"Uchburchakning bir uchidan qarama-qarshi tomonga 3 ta kesma o'tkazildi. Nechta uchburchak bor?",o:["10","4","6","8"],k:0,s:"Uchdan 5 ta chiziq: 4 + 3 + 2 + 1 = 10."},
{t:"Uchburchakning har tomoni 2 ga bo'lingan va bo'linish nuqtalari tutashtirilgan. Nechta uchburchak bor?",o:["5","4","6","3"],k:0,s:"4 ta kichik (3 ▲, 1 ▼) + 1 katta = 5."},
{t:"Uchburchakning har tomoni 3 ga bo'linib, tomonlarga parallel chiziqlar o'tkazilgan. Nechta uchburchak bor?",o:["13","9","10","12"],k:0,s:"Kichik 9 (6 ▲, 3 ▼), ikki qatorli 3, katta 1: 13."},
{t:"Bitta nuqtadan bir tomonga 4 ta nur chiqqan. Nechta burchak bor?",o:["6","4","3","8"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Bitta nuqtadan bir tomonga 6 ta nur chiqqan. Nechta burchak bor?",o:["15","6","12","30"],k:0,s:"5 + 4 + 3 + 2 + 1 = 15."},
{t:"Kvadratning ikkala diagonali chizilgan. Rasmda nechta uchburchak bor?",o:["8","4","6","10"],k:0,s:"4 ta kichik + har diagonal 2 tadan katta (4 ta): 8."},
{t:"Kvadrat o'rta chiziqlari (bitta tik, bitta yotiq) bilan bo'lingan. Rasmda nechta kvadrat bor?",o:["5","4","9","6"],k:0,s:"4 ta kichik + 1 katta."},
{t:"Tekislikda 5 ta to'g'ri chiziq, hech qaysi ikkitasi parallel emas, hech qaysi uchtasi bir nuqtadan o'tmaydi. Nechta kesishish nuqtasi bor?",o:["10","5","15","20"],k:0,s:"Har ikki chiziq bir marta kesishadi: 4 + 3 + 2 + 1 = 10."},
{t:"Aylanada 6 ta nuqta belgilangan. Uchlari shu nuqtalarda bo'lgan nechta uchburchak bor?",o:["20","18","6","15"],k:0,s:"A ni o'z ichiga olgan: 10, A siz B bilan: 6, A, B siz C bilan: 3, qolgan D, E, F: 1 → 20."},
{t:"3×3 kataklik to'rda 2×2 o'lchamli nechta kvadrat bor?",o:["4","9","1","3"],k:0,s:"Chap yuqori burchak 2 × 2 joyda: 4."}
];
function PRACT_STAGE(){k3Grid(4,4,26)}
var PREP_DATA={teach:["Tartibli sanash: o'lcham va yo'nalish bo'yicha.","n ta narsadan 2 tasini tanlash: (n − 1) + … + 1.","To'rdagi kvadratlar va to'g'ri to'rtburchaklar.","Bo'lingan uchburchakdagi ▲ va ▼."],
 mist:["Faqat eng kichik shakllarni sanaydi.","Har kesma yoki burchakni ikki marta sanaydi.","▼ uchburchaklarni unutadi."],
 need:["Katakli qog'oz, rangli qalamlar.","Uchburchakli (izometrik) qog'oz."],
 board:["Kesmalar: n · (n − 1) : 2","n×n: kvadratlar 1² + … + n²","to'rtburchak = yotiq juft · tik juft","▲ + ▼ — ikkalasini sanang"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
