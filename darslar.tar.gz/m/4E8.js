var CODE='4E8',TITLE='4-sinf · Yig‘indi va karrali nisbatiga ko‘ra topish';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
function e8u(n,txt,c){var s=[];for(var i=0;i<n;i++)s.push({w:10,txt:txt,c:c||'a'});return s}
var STEPS=[
e4st({h:"Teng bo‘laklar: chizma model",sum:"Akbar Jo‘rabekdan 4 marta ko‘p, jami 75: 5 bo‘lak, 1 bo‘lak 75 : 5 = 15, Akbar 60.",a:"m01",
 frames:[{t:'Jo‘rabek va Akbar birga 75 ta yashik to‘ldirdi. Akbar 4 marta ko‘p to‘ldirdi.',bars:[{lab:'Jo‘rabek',y:48,segs:e8u(1,'?','a')},{lab:'Akbar',y:96,segs:e8u(4,'?','b')}],max:40,note:'Jo‘rabek — 1 bo‘lak, Akbar — 4 ta xuddi shunday bo‘lak'},
  {t:'Jami bo‘laklar: 1 + 4 = 5',bars:[{lab:'Jo‘rabek',y:48,segs:e8u(1,'?','a')},{lab:'Akbar',y:96,segs:e8u(4,'?','b')}],max:40,br:[{b:1,lab:'5 bo‘lak = 75',col:C.blue}],calc:['1 + 4 = 5 ta teng bo‘lak']},
  {t:'1 bo‘lak = 75 : 5 = 15',bars:[{lab:'Jo‘rabek',y:48,segs:e8u(1,'15','g')},{lab:'Akbar',y:96,segs:e8u(4,'15','g')}],max:40,br:[{b:1,lab:'60',col:C.ok}],calc:['1) 1 + 4 = 5 bo‘lak','2) 75 : 5 = <b>15</b> (Jo‘rabek)','3) 15 · 4 = <b>60</b> (Akbar)']}],
 html:"<p>«<b>Necha marta ko'p</b>» bo'lsa, chizmada <b>teng bo'laklar</b> chizamiz. Kichigi — 1 bo'lak. Tugmani bosing.</p>",
 after:"<p>Kalit savol: <b>jami nechta teng bo'lak?</b> Keyin yig'indini bo'laklar soniga bo'lamiz. Tekshiruv: 15 + 60 = 75 ✓, 60 : 15 = 4 ✓.</p>",
 q:{t:"Ikki sinfda 84 ta kitob. 4-A da 4-B dagidan 3 marta ko'p. 4-B da nechta?",opts:["21","28","63","12"],ok:0,why:"84 : (1 + 3) = 21.",hint:"Jami nechta teng bo'lak?",full:"4-B — 1 bo'lak, 4-A — 3 bo'lak, jami 4. 84 : 4 = 21 (4-B), 63 (4-A). «28» — 84 : 3, bo'laklar soni noto'g'ri olingan."},
 tn:"Singapur darsliklarining eng mashhur turi (\"part-whole, multiple\"). Bolalar har doim chizmadan boshlasin. Bank: 200-id."}),
e4st({h:"Tuzoq: 3 marta ko‘p — 3 ta bo‘lak emas!",sum:"48 ta: biri 3 marta ko‘p → 4 bo‘lak; 48 : 4 = 12 va 36 (16 emas).",a:"m02",
 frames:[{t:'Ikki qutida 48 ta qalam. 1-qutida 2-sidan 3 marta ko‘p. 2-qutida nechta?',bars:[{lab:'1-quti',y:48,segs:e8u(3,'','b')},{lab:'2-quti',y:96,segs:e8u(1,'','a')}],max:40,note:'Tanlang:'}],
 html:"<p>Ko'p bolalar bu yerda adashadi. Bo'laklarni sanab tanlang:</p>",
 btns:e4pk(["16 ta","12 ta","24 ta"],1,{t:'Ikki qutida 48 ta qalam. 1-qutida 2-sidan 3 marta ko‘p.',bars:[{lab:'1-quti',y:48,segs:e8u(3,'12','g')},{lab:'2-quti',y:96,segs:e8u(1,'12','g')}],max:40,calc:['3 + 1 = 4 bo‘lak','48 : 4 = <b>12</b> (2-quti),  36 (1-quti)']},["16 = 48 : 3 — bu 2-qutining bo‘lagini ham hisobga olmagan. Bo‘laklarni sanang: 3 + 1.","","24 = 48 : 2 — qutilar teng bo‘lardi."]),
 after:"<p>«3 marta ko'p» → <b>3 + 1 = 4</b> bo'lak. Tekshiruv: 12 · 3 = 36, 36 + 12 = 48 ✓.</p>",
 q:{t:"Ota va o'g'ilning yoshi jami 42. Ota o'g'ildan 6 marta katta. O'g'il necha yoshda?",opts:["6","7","36","8"],ok:0,why:"42 : 7 = 6.",hint:"1 + 6 = 7 bo'lak.",full:"O'g'il — 1 bo'lak, ota — 6 bo'lak: jami 7. 42 : 7 = 6 yosh, ota 36. «7» — 42 : 6 (bo'lak soni 6 deb olingan)."},
 tn:"Bolalar har bir bo'lakni barmoq bilan sanab, «jami … bo'lak» deb ovoz chiqarib aytsin."}),
e4st({h:"Hissalar: sharbat retsepti",sum:"2 hissa shakar + 7 hissa suv = 36 kg: 9 hissa, 1 hissa 4 kg, suv 28 kg.",a:"m03",
 frames:[{t:'Sharbat: 2 hissa shakarga 7 hissa suv. Jami 36 kg. Suv necha kg?',bars:[{lab:'shakar',y:48,segs:e8u(2,'','y')},{lab:'suv',y:96,segs:e8u(7,'','b')}],max:70,note:'Hissa — teng bo‘lak. Qaysi hisob?'}],
 html:"<p>«Hissa» — bu ham teng bo'lak. Hisobni tanlang:</p>",
 btns:e4pk(["36 : 9 · 7","36 : 7","36 : 2 · 7"],0,{t:'2 hissa + 7 hissa = 9 hissa = 36 kg',bars:[{lab:'shakar',y:48,segs:e8u(2,'4','y')},{lab:'suv',y:96,segs:e8u(7,'4','b')}],max:70,br:[{b:1,lab:'28 kg',col:C.ok}],calc:['1) 2 + 7 = 9 hissa','2) 36 : 9 = 4 kg (1 hissa)','3) 4 · 7 = <b>28</b> kg suv']},["","36 : 7 — shakarning 2 hissasi unutildi. Jami hissalar: 2 + 7.","36 : 2 — faqat shakar hissalari olinib, keyin 7 ga ko‘paytirildi. 126 kg — jamidan ham ko‘p!"]),
 after:"<p>Retseptlar, qorishmalar, bo'yoq aralashmalari — hammasi hissalar bilan. Tekshiruv: shakar 8 kg, suv 28 kg, jami 36 ✓.</p>",
 q:{t:"Beton uchun 1 hissa sement, 3 hissa qum va 4 hissa shag'al olinadi. 400 kg beton uchun necha kg qum kerak?",opts:["150 kg","100 kg","133 kg","200 kg"],ok:0,why:"1 + 3 + 4 = 8; 400 : 8 = 50; 50 · 3 = 150.",hint:"Jami hissalar: 1 + 3 + 4.",full:"8 hissa = 400 kg → 1 hissa 50 kg. Qum: 3 · 50 = 150 kg. «133» — 400 : 3, «100» — 400 : 4."},
 tn:"Bank: 1801, 1802-idlar. Real tajriba: 1 qoshiq shakar + 3 qoshiq suv — «1 : 3» nisbat."}),
e4st({h:"Ayirma va karrali nisbat",sum:"Katta kichikdan 5 marta katta, ayirma 48: 4 bo‘lak = 48, kichik 12, katta 60.",a:"m04",
 frames:[{t:'Bir son ikkinchisidan 5 marta katta, ayirmasi 48. Sonlarni toping.',bars:[{lab:'katta',y:62,segs:e8u(5,'','b')},{lab:'kichik',y:110,segs:e8u(1,'','a')}],max:50,note:'Ayirma — chizmaning qaysi qismi?'},
  {t:'Ayirma — ortiqcha 4 ta bo‘lak',bars:[{lab:'katta',y:62,segs:e8u(1,'','b').concat(e8u(4,'','c'))},{lab:'kichik',y:110,segs:e8u(1,'','a')}],max:50,br:[{b:0,from:1,to:4,lab:'4 bo‘lak = 48',up:true,col:C.bad}],calc:['5 − 1 = 4 bo‘lak — ayirma']},
  {t:'1 bo‘lak = 48 : 4 = 12',bars:[{lab:'katta',y:62,segs:e8u(5,'12','g')},{lab:'kichik',y:110,segs:e8u(1,'12','g')}],max:50,br:[{b:0,lab:'60',up:true,col:C.ok}],calc:['1) 5 − 1 = 4','2) 48 : 4 = <b>12</b> (kichik)','3) 12 · 5 = <b>60</b> (katta)']}],
 html:"<p>Endi yig'indi emas, <b>ayirma</b> ma'lum. Bo'laklarni yana sanaymiz — lekin <b>ayirib</b>. Tugmani bosing.</p>",
 after:"<p>Yig'indi bo'lsa — bo'laklar <b>qo'shiladi</b> (5 + 1), ayirma bo'lsa — <b>ayiriladi</b> (5 − 1). Tekshiruv: 60 − 12 = 48 ✓.</p>",
 q:{t:"Ota o'g'lidan 4 marta katta va undan 27 yosh katta. O'g'il necha yoshda?",opts:["9","27","36","7"],ok:0,why:"4 − 1 = 3 bo'lak = 27; 27 : 3 = 9.",hint:"Farq nechta bo'lak?",full:"Farq: 4 − 1 = 3 bo'lak = 27 yosh. 1 bo'lak = 9 — o'g'il, ota 36. «7» — 27 : 4 (bo'laklar ayirilmagan), «36» — otaning yoshi."},
 tn:"Ikki holatni doskada yonma-yon yozing: «jami» → qo'shamiz, «farq» → ayiramiz."}),
e4st({h:"Uch kishi: navbat bilan olish",sum:"180 ta yong‘oq: Diyor 2, Madina 3, Sardor 4 tadan. Har aylanma 9 ta, 20 aylanma; Madina 60.",a:"m05",
 frames:[{t:'Diyor 2 ta, Madina 3 ta, Sardor 4 ta — tugaguncha. Jami 180 ta. Madinaga nechta?',bars:[{lab:'Diyor',y:36,segs:e8u(2,'','a')},{lab:'Madina',y:76,segs:e8u(3,'','c')},{lab:'Sardor',y:116,segs:e8u(4,'','b')}],max:50,gap:40,note:'Tanlang:'}],
 html:"<p>Har bir «aylanmada» uchchalasi birdan oladi. Tanlang:</p>",
 btns:e4pk(["60 ta","40 ta","80 ta"],0,{t:'Har aylanma: 2 + 3 + 4 = 9 ta',bars:[{lab:'Diyor',y:36,segs:e8u(2,'20','a')},{lab:'Madina',y:76,segs:e8u(3,'20','g')},{lab:'Sardor',y:116,segs:e8u(4,'20','b')}],max:50,gap:40,calc:['180 : 9 = 20 aylanma','Madina: 3 · 20 = <b>60</b> ta']},["","40 — Diyorniki (2 · 20).","80 — Sardorniki (4 · 20)."]),
 after:"<p>Bu ham hissalar masalasi: 2 : 3 : 4. Jami 9 hissa, 1 hissa = 20. Tekshiruv: 40 + 60 + 80 = 180 ✓.</p>",
 q:{t:"Uch bola 140 ta markani 1 : 2 : 4 nisbatda bo'lishdi. Eng ko'p olgan bolada nechta?",opts:["80","20","40","35"],ok:0,why:"1 + 2 + 4 = 7; 140 : 7 = 20; 20 · 4 = 80.",hint:"Jami 7 hissa.",full:"7 hissa = 140 → 1 hissa 20. Eng ko'pi: 4 · 20 = 80. «35» — 140 : 4."},
 tn:"Bank: 1804-id. Yong'oq o'rniga tayoqchalar bilan sinfda haqiqatan bo'lib ko'ring — 3–4 aylanmadan keyin qonuniyat ko'rinadi."}),
e4st({h:"Olimpiada: nolni o‘chirsak",sum:"Yig‘indi 594; biri 0 bilan tugaydi, o‘chirsak ikkinchisi chiqadi → 10 marta katta: 11 bo‘lak, 594 : 11 = 54.",a:"m06",
 frames:[{t:'Ikki sonning yig‘indisi 594. Biri 0 bilan tugaydi; shu 0 ni o‘chirsak, ikkinchi son hosil bo‘ladi.',bars:[{lab:'katta',y:48,segs:e8u(10,'','b')},{lab:'kichik',y:96,segs:e8u(1,'','a')}],max:110,note:'0 ni o‘chirish — 10 marta kamaytirish!'},
  {t:'10 + 1 = 11 bo‘lak = 594',bars:[{lab:'katta',y:48,segs:e8u(10,'','b')},{lab:'kichik',y:96,segs:e8u(1,'54','g')}],max:110,br:[{b:0,lab:'540',col:C.ok}],calc:['1) 594 : 11 = <b>54</b> (kichik)','2) 54 · 10 = <b>540</b> (katta)','Tekshiruv: 540 + 54 = 594 ✓']}],
 html:"<p>Yashirin karrali nisbat: oxiridagi <b>0</b> ni o'chirish sonni <b>10 marta</b> kichraytiradi (540 → 54). Tugmani bosing.</p>",
 after:"<p>Olimpiadalarda shart ko'pincha «niqoblangan» bo'ladi. Uni oddiy tilga o'giring: «biri ikkinchisidan 10 marta katta».</p>",
 q:{t:"Ikki sonning yig'indisi 770. Birining oxiriga 0 yozsak, ikkinchisi hosil bo'ladi. Kichik son?",opts:["70","700","77","10"],ok:0,why:"770 : 11 = 70.",hint:"Oxiriga 0 yozish — 10 marta kattalashtirish.",full:"Katta = kichik · 10; 11 bo'lak = 770; kichik 70, katta 700. «77» — 770 : 10."},
 tn:"Bank: 1803-id. Raqamlar kartochkasi bilan ko'rsating: 54 → 540."}),
e4st({h:"Tuzoq: ko‘chirgandan keyin teng",sum:"1-savatda 3 marta ko‘p; undan 20 tasini olsak teng bo‘ladi: 2 bo‘lak = 20, 1 bo‘lak 10, jami 40.",a:"m07",
 frames:[{t:'1-savatda 2-sidan 3 marta ko‘p olma. 1-savatdan 20 tasini olsak, teng bo‘ladi. Jami nechta olma bor edi?',bars:[{lab:'1-savat',y:48,segs:e8u(3,'','b')},{lab:'2-savat',y:96,segs:e8u(1,'','a')}],max:40,note:'Tanlang:'}],
 html:"<p>Chizmaga qarab o'ylang. Qaysi javob to'g'ri?</p>",
 btns:e4pk(["80 ta","40 ta","60 ta"],1,{t:'Olib qo‘yilgan 20 ta = ortiqcha 2 bo‘lak',bars:[{lab:'1-savat',y:48,segs:e8u(1,'10','g').concat(e8u(2,'10','q'))},{lab:'2-savat',y:96,segs:e8u(1,'10','g')}],max:40,br:[{b:0,from:1,to:2,lab:'20 ta',up:true,col:C.bad}],calc:['3 − 1 = 2 bo‘lak = 20 → 1 bo‘lak = 10','Jami: 4 bo‘lak = <b>40</b> ta']},["80 = 20 · 4 — 20 ni bitta bo‘lak deb olingan. Lekin olib qo‘yilgan qism 2 bo‘lak.","","60 = 20 · 3 — bo‘laklar noto‘g‘ri sanalgan."]),
 after:"<p>Tekshiruv: 1-savatda 30, 2-sida 10; 30 − 20 = 10 ✓. Olingan 20 ta — aynan <b>ortiqcha</b> qism.</p>",
 q:{t:"Akada ukasidan 4 marta ko'p pul bor. Aka 15 ming so'm sarflasa, pullari teng bo'ladi. Ukada qancha pul bor?",opts:["5 ming","15 ming","20 ming","3 ming"],ok:0,why:"Ortiqcha 3 bo'lak = 15 ming; 1 bo'lak 5 ming.",hint:"Akaning ortiqchasi nechta bo'lak?",full:"Aka 4 bo'lak, uka 1 bo'lak. Ortiqcha 3 bo'lak = 15 ming → 1 bo'lak 5 ming (uka), aka 20 ming. «3 ming» — 15 : 5, «15 ming» — butun ortiqcha."},
 tn:"Bu tur saralash testlarida ko'p uchraydi. Chizmada ortiqcha bo'laklarni boshqa rangda bo'yang."}),
e4st({h:"Bilasizmi? 3700 yillik masala",sum:"Misrning Rind papirusida (taxminan mil. av. 1650-y.) «son va uning bo‘lagi qo‘shilsa…» turidagi «aha» masalalari bor.",a:"m08",
 frames:[{t:'Rind papirusi (Qadimgi Misr)',bars:[{lab:'son',y:80,segs:e8u(7,'','a').concat(e8u(1,'','c'))}],max:90,note:'«Son va uning 7 dan biri qo‘shilsa — 19»'}],
 html:"<p>📜 Qadimgi Misrning <b>Rind papirusi</b> (taxminan miloddan avvalgi 1650-yil) — dunyodagi eng qadimgi matematika darsliklaridan biri. Unda «<b>aha</b>» deb atalgan masalalar bor, masalan: «Son va uning yettidan biri qo'shilsa, 19 bo'ladi. Son nechaga teng?»</p>",
 after:"<p>Bu ham bo'laklar masalasi: son — 7 bo'lak, yettidan biri — 1 bo'lak, jami 8 bo'lak = 19. Misrliklar ham xuddi siz kabi bo'laklar bilan o'ylashgan!</p>",
 tn:"Papirus rasmini ko'rsating (darslik yoki internetdan). Bolalarga «aha» masalasini o'zi tuzishni topshiring."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Kichik — 1 bo‘lak, katta — k bo‘lak',bars:[{lab:'katta',y:62,segs:e8u(3,'','b')},{lab:'kichik',y:108,segs:e8u(1,'','a')}],max:40,br:[{b:0,lab:'yig‘indi → 1 + k;  ayirma → k − 1',up:true,col:C.blue}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>«k marta ko'p» → kichigi <b>1 bo'lak</b>, kattasi <b>k bo'lak</b>.</li><li>Yig'indi ma'lum: <b>1 bo'lak = yig'indi : (k + 1)</b>.</li><li>Ayirma ma'lum: <b>1 bo'lak = ayirma : (k − 1)</b>.</li><li>Hissalar (2 : 7) — jami hissalarni qo'shing.</li><li>Oxiriga 0 yozish/o'chirish — 10 marta.</li><li>«Olsak teng bo'ladi» → olingan qism = ortiqcha bo'laklar.</li><li>Tekshiring: yig'indi ham, nisbat ham to'g'ri chiqsin.</li></ul></div>",
 tn:"Keyingi mavzu bilan bog'lang: proporsional kattaliklar (birga keltirish) — 1 bo'lak g'oyasi davom etadi."}
];
var PROBS=[
{t:"Jo'rabek va Akbar 75 ta yashik to'ldirdi; Akbar 4 marta ko'p. Jo'rabek nechta?",o:["15","60","19","25"],k:0,s:"75 : 5 = 15."},
{t:"84 ta kitob; 4-A da 4-B dan 3 marta ko'p. 4-B da nechta?",o:["21","28","63","12"],k:0,s:"84 : 4 = 21."},
{t:"48 ta qalam; 1-qutida 2-sidan 3 marta ko'p. 1-qutida nechta?",o:["36","12","16","32"],k:0,s:"48 : 4 · 3 = 36."},
{t:"Ota va o'g'il yoshi jami 42; ota 6 marta katta. O'g'il necha yoshda?",o:["6","7","36","8"],k:0,s:"42 : 7 = 6."},
{t:"2 hissa shakar va 7 hissa suvdan 36 kg sharbat. Suv necha kg?",o:["28 kg","8 kg","32 kg","24 kg"],k:0,s:"36 : 9 · 7 = 28."},
{t:"5 hissa suvga 3 hissa shakar. 24 kg sharbat uchun necha kg shakar?",o:["9 kg","15 kg","8 kg","3 kg"],k:0,s:"24 : 8 · 3 = 9."},
{t:"1 hissa sement, 3 hissa qum, 4 hissa shag'al. 400 kg betonda qum?",o:["150 kg","100 kg","133 kg","200 kg"],k:0,s:"400 : 8 · 3 = 150."},
{t:"Bir son ikkinchisidan 5 marta katta, ayirmasi 48. Kattasi?",o:["60","12","48","53"],k:0,s:"48 : 4 = 12; 60."},
{t:"Ota o'g'lidan 4 marta va 27 yosh katta. O'g'il necha yoshda?",o:["9","27","36","7"],k:0,s:"27 : 3 = 9."},
{t:"180 ta yong'oq: Diyor 2, Madina 3, Sardor 4 tadan oladi. Madinaga nechta?",o:["60","40","80","20"],k:0,s:"180 : 9 = 20; 3 · 20 = 60."},
{t:"140 ta marka 1 : 2 : 4 nisbatda bo'lindi. Eng ko'pi?",o:["80","20","40","35"],k:0,s:"140 : 7 · 4 = 80."},
{t:"Ikki sonning yig'indisi 594; biridagi oxirgi 0 ni o'chirsak, ikkinchisi chiqadi. Kichigi?",o:["54","540","59","66"],k:0,s:"594 : 11 = 54."},
{t:"Ikki sonning yig'indisi 770; kichigining oxiriga 0 yozsak, kattasi chiqadi. Kichigi?",o:["70","700","77","10"],k:0,s:"770 : 11 = 70."},
{t:"1-savatda 3 marta ko'p olma; undan 20 tasini olsak teng bo'ladi. Jami nechta?",o:["40","80","60","30"],k:0,s:"20 : 2 = 10; 10 · 4 = 40."},
{t:"Akada ukasidan 4 marta ko'p pul. Aka 15 ming sarflasa teng bo'ladi. Ukada qancha?",o:["5 ming","15 ming","20 ming","3 ming"],k:0,s:"15 : 3 = 5."},
{t:"Ikki sonning ko'paytmasi 144, biri ikkinchisidan 4 marta katta. Kattasi?",o:["24","36","12","6"],k:0,s:"6 · 24 = 144; 24 = 6 · 4."},
{t:"To'g'ri to'rtburchakning perimetri 48 sm, bo'yi enidan 3 marta uzun. Yuzi?",o:["108 sm²","48 sm²","36 sm²","144 sm²"],k:0,s:"Yarim perimetr 24 = 4 bo'lak; eni 6, bo'yi 18; 6 · 18 = 108."},
{t:"Sinfda 32 o'quvchi; qizlar o'g'il bolalardan 3 marta ko'p. Qizlar o'g'il bolalardan nechta ko'p?",o:["16","24","8","21"],k:0,s:"32 : 4 = 8; 24 − 8 = 16."},
{t:"Ona qizidan 3 marta katta. 12 yildan keyin ona qizidan 2 marta katta bo'ladi. Qiz hozir necha yoshda?",o:["12","24","36","6"],k:0,s:"Farq hozir 2 bo'lak; 12 yildan keyin qiz yoshi = farq: x + 12 = 2x → x = 12."},
{t:"Son va uning yettidan biri qo'shilsa 24 bo'ladi. Son nechaga teng?",o:["21","3","24","28"],k:0,s:"8 bo'lak = 24; 1 bo'lak 3; son 7 · 3 = 21."}
];
function PRACT_STAGE(){bmDraw({t:'Teng bo‘laklar chizing',bars:[{lab:'katta',y:48,segs:e8u(3,'?','b')},{lab:'kichik',y:96,segs:e8u(1,'?','a')}],max:40})}
var PREP_DATA={teach:["Karrali nisbat: kichigi 1 bo'lak, kattasi k bo'lak.","Yig'indi bilan: 1 bo'lak = S : (k + 1); ayirma bilan: 1 bo'lak = A : (k − 1).","Hissalar (retsept, beton), uch kishi nisbati.","Niqoblangan shartlar: 0 ni o'chirish, «olsak teng bo'ladi»."],
 mist:["«3 marta ko'p» da bo'laklarni 3 ta deb oladi (4 emas).","Hissalarda faqat birining hissasiga bo'ladi.","Ayirma masalasida bo'laklarni qo'shadi.","«20 tasini olsak teng» da 20 ni 1 bo'lak deb oladi."],
 need:["Rangli qog'oz tasmalar (bir xil uzunlikdagi bo'laklar).","Tayoqchalar yoki yong'oqlar (navbat bilan olish uchun).","Raqam kartochkalari (0 qo'shish/o'chirish)."],
 board:["<span class='w2'>75 : (1 + 4) = 15</span>.","3 marta ko'p → <span class='w2'>4 bo'lak</span>.","<span class='w2'>36 : (2 + 7) · 7 = 28</span>.","<span class='w2'>48 : (5 − 1) = 12</span>.","<span class='w2'>594 : 11 = 54</span>."]};
