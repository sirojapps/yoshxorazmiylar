var CODE='4J18',TITLE="4-sinf · Labirint, yo'l va xarita";
// panjara: 4 × 3 tugun; v[j][i] — tugundagi son (null — hali yo'q), bl — yopiq tugun [i,j]
function q18Grid(v,bl){clear();var g=S.g,X=function(i){return 70+i*72},Y=function(j){return 140-j*52};
 for(var j=0;j<3;j++)E('line',{x1:X(0),y1:Y(j),x2:X(3),y2:Y(j),stroke:'#b8c4d0','stroke-width':3},g);for(var i=0;i<4;i++)E('line',{x1:X(i),y1:Y(0),x2:X(i),y2:Y(2),stroke:'#b8c4d0','stroke-width':3},g);
 for(var j=0;j<3;j++)for(var i=0;i<4;i++){var b=bl&&bl[0]===i&&bl[1]===j,val=v&&v[j]&&v[j][i];E('circle',{cx:X(i),cy:Y(j),r:13,fill:b?C.bad:(val!=null?'#fff':'#eef2f6'),stroke:b?C.bad:C.blue,'stroke-width':2},g);
  T(g,X(i),Y(j)+5,b?'✕':(val!=null?val:''),{'font-size':13,'font-weight':900,fill:b?'#fff':C.blue})}
 T(g,X(0)-28,Y(0)+5,'🏠',{'font-size':16});T(g,X(3)+28,Y(2)+5,'🏫',{'font-size':16})}
var G1=[[1,1,1,1],[1,2,3,4],[1,3,6,10]],G2=[[1,1,1,1],[1,0,1,2],[1,1,2,4]];
function q18Part(G,k,bl){var v=G.map(function(r,j){return r.map(function(x,i){return i+j<=k?x:null})});q18Grid(v,bl)}
var P1=[function(){q18Grid(null);j2Msg("Uydan maktabga faqat <b>o'ngga</b> va <b>tepaga</b> yurib nechta yo'l bor? (3 o'ngga, 2 tepaga)")},
 function(){q18Part(G1,1);j2Msg("Pastki qator va chap ustunga faqat <b>bitta</b> yo'l bor: 1 lar.")},
 function(){q18Part(G1,3);j2Msg("Har tugunga yo'llar = <b>chapdagi + pastdagi</b>. 1 + 1 = 2, 2 + 1 = 3, …")},
 function(){q18Part(G1,5);j2Msg("Maktabga: 4 + 6 = <b>10</b> ta yo'l. Hammasini chizib sanash shart emas!")}];
var P2=[function(){q18Grid(null,[1,1]);j2Msg("Endi bitta chorraha yopiq (ta'mirlanyapti). Nechta yo'l qoladi?")},
 function(){q18Part(G2,3,[1,1]);j2Msg("Yopiq tugunga 0 yozamiz — undan yo'l o'tmaydi. Qolganini xuddi shunday qo'shamiz.")},
 function(){q18Part(G2,5,[1,1]);j2Msg("Maktabga: 2 + 2 = <b>4</b> ta yo'l (10 tadan 6 tasi yopiq tugundan o'tardi).")}];
function q18Compass(dir){clear();var g=S.g,cx=180,cy=88;E('circle',{cx:cx,cy:cy,r:62,fill:'#fff',stroke:'#c9d3dd','stroke-width':3},g);
 [['Sh',0,-48],['Shq',48,0],['J',0,48],["G'",-48,0]].forEach(function(d){T(g,cx+d[1],cy+d[2]+5,d[0],{'font-size':14,'font-weight':900,fill:'#1f5f9e'})});
 var a={Sh:0,Shq:90,J:180,"G'":270}[dir];E('polygon',{points:(cx-7)+','+cy+' '+(cx+7)+','+cy+' '+cx+','+(cy-34),fill:C.bad,transform:'rotate('+a+' '+cx+' '+cy+')'},g);E('circle',{cx:cx,cy:cy,r:5,fill:'#333'},g)}
var NOD={A:[40,90],B:[150,35],C:[150,140],D:[270,60],E:[330,135]},EDG=[['A','B',4],['A','C',2],['C','B',1],['B','D',5],['C','D',8],['D','E',3],['C','E',10]];
var STEPS=[
{h:"Panjarada yo'llar soni",sum:"Har tugun = chapdagi + pastdagi. 3 o'ngga, 2 tepaga → 10 yo'l.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>3-sinfda yo'llarni chizib sanadik. Ko'p bo'lsa adashamiz. Endi <b>qo'shib</b> sanaymiz.</p>",
 btns:[phaser(P1)],
 after:"<p>Har tugunga faqat chapdan yoki pastdan kelinadi. Shuning uchun yo'llar soni — ikki qo'shnining yig'indisi. Bu jadval «Paskal uchburchagi»ning bir qismi.</p>",
 q:{t:"Faqat o'ngga va tepaga: 2 o'ngga, 2 tepaga. Nechta yo'l?",opts:["4","6","8","3"],ok:1,why:"1, 1, 1 / 1, 2, 3 / 1, 3, 6 → 6.",hint:"3 × 3 tugunli panjaraga sonlarni yozing.",full:"Pastki qator va chap ustun — 1. Markaz: 1 + 1 = 2. O'ng-o'rta: 2 + 1 = 3, tepa-o'rta: 1 + 2 = 3. Burchak: 3 + 3 = 6."},
 tn:"Doskada panjara chizib, bolalar navbat bilan tugunlarga son yozsin — xato qilsa, sinf tuzatadi."},
{h:"Yopiq chorraha",sum:"Yopiq tugunga 0 yozamiz: 10 yo'ldan 4 tasi qoladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Hayotda yo'llar yopiladi. Usul o'zgarmaydi — faqat yopiq tugunga <b>0</b>.</p>",
 btns:[phaser(P2)],
 after:"<p>Tekshirish: yopiq tugundan o'tadigan yo'llar = (unga yo'llar) · (undan maktabga yo'llar) = 2 · 3 = 6. 10 − 6 = 4 ✓.</p>",
 q:{t:"3 o'ngga, 2 tepaga panjarada eng yuqori qatordagi chapdan 2-tugun yopiq. Nechta yo'l qoladi?",opts:["9","7","10","6"],ok:1,why:"Unga 3 ta yo'l keladi, undan maktabga 1 ta: 3 yo'l yopiladi, 10 − 3 = 7.",hint:"Yopiq tugunga nechta yo'l keladi? Undan maktabga-chi?",full:"Yuqori qator odatda 1, 3, 6, 10. Yopiq tugun (3 o'rniga) 0 bo'ladi: 1, 0, 3, 7. Tekshirish: yopiq tugunga 3 ta yo'l keladi, undan maktabga faqat 1 ta (o'ngga, o'ngga) — 3 · 1 = 3 yo'l yopildi, 10 − 3 = 7."},
 tn:"Bolalar o'zi yopiq tugun tanlab, yo'llar sonini hisoblasin — juftlikda tekshirsin."},
{h:"Eng qisqa yo'l (xaritada km)",sum:"A→E: A–C–B–D–E = 2 + 1 + 5 + 3 = 11 km — eng qisqa.",a:"m03",
 start:function(){k4Graph(NOD,EDG);j2Msg("A dan E ga eng qisqa yo'l qaysi? Har bir yo'lni hisoblab, tanlang.")},
 fin:function(){k4Graph(NOD,EDG,[1,2,3,5]);j2Msg("A–C–B–D–E: 2 + 1 + 5 + 3 = <b>11 km</b>.")},
 html:"<p>Xaritada qishloqlar va yo'llar (km). Eng qisqa yo'l har doim «to'g'ridan» emas. A dan E ga qaysi yo'l eng qisqa?</p>",
 btns:j2Pick(["A–C–E","A–B–D–E","A–C–B–D–E","A–C–D–E"],2,function(){k4Graph(NOD,EDG,[1,2,3,5]);j2Msg("To'g'ri! 2 + 1 + 5 + 3 = 11 km.")},function(i){var t=["2 + 10 = 12 km","4 + 5 + 3 = 12 km","","2 + 8 + 3 = 13 km"][i];j2Msg(t+" — qisqarog'i bor.")}),g2:1,
 after:"<p>Usul: har qishloqqa A dan eng qisqa masofani yozib boramiz: C = 2, B = min(4; 2 + 1) = 3, D = min(3 + 5; 2 + 8) = 8, E = min(8 + 3; 2 + 10) = 11. Aylanma yo'l ba'zan qisqa!</p>",
 q:{t:"Shu xaritada A dan D gacha eng qisqa masofa?",opts:["9 km","8 km","10 km","7 km"],ok:1,why:"A–C–B–D: 2 + 1 + 5 = 8.",hint:"A dan B ga eng qisqa yo'l 4 km emas — C orqali-chi?",full:"A–B–D = 4 + 5 = 9. A–C–D = 2 + 8 = 10. A–C–B–D = 2 + 1 + 5 = 8 — eng qisqa."},
 tn:"Tuman xaritasidan haqiqiy qishloqlar bilan shunday jadval tuzing."},
{h:"Masshtab: xaritadan haqiqiy masofaga",sum:"1 : 200 000 → 1 sm = 2 km. 3 sm → 6 km.",a:"m04",
 start:function(){j2Lines([["1 : 200 000",C.blue,26],["1 sm xaritada = 200 000 sm joyda",null,15]]);j2Msg("200 000 sm necha km? Tanlang.")},
 fin:function(){j2Lines([["1 : 200 000",C.blue,26],["200 000 sm = 2 000 m = 2 km",null,16],["3 sm → 6 km",C.ok,22]]);j2Msg("1 sm = <b>2 km</b>, demak 3 sm = 6 km.")},
 html:"<p>Masshtab 1 : 200 000 — xaritadagi 1 sm joyda 200 000 sm. Buni km ga o'tkazing.</p>",
 btns:j2Pick(["20 km","2 km","200 m"],1,function(){j2Lines([["1 : 200 000",C.blue,26],["200 000 sm = 2 000 m = 2 km",null,16],["3 sm → 6 km",C.ok,22]]);j2Msg("To'g'ri! 200 000 sm = 2 000 m = 2 km.")},function(){j2Msg("100 sm = 1 m, 1 000 m = 1 km. 200 000 : 100 = ? m")}),
 after:"<p>Tez usul: sm dan km ga — oxiridagi <b>5 ta nolni</b> o'chiramiz (100 000 sm = 1 km). 1 : 200 000 → 2 km.</p>",
 q:{t:"Haqiqiy masofa 12 km, xaritada 4 sm. Masshtab?",opts:["1 : 3 000","1 : 300 000","1 : 30 000","1 : 48 000"],ok:1,why:"12 km : 4 = 3 km = 300 000 sm.",hint:"1 sm necha km ga to'g'ri keladi? Uni sm ga o'tkazing.",full:"4 sm — 12 km, 1 sm — 3 km. 3 km = 3 000 m = 300 000 sm. Masshtab 1 : 300 000."},
 tn:"Tuman xaritasida chizg'ich bilan maktab va markaz orasini o'lchatib, km ga o'tkazdiring."},
{h:"Burilishlar: qayerga qarayapti?",sum:"Shimol → o'ng (sharq) → o'ng (janub) → chap (sharq) → orqaga (g'arb).",a:"m05",
 start:function(){q18Compass("Sh");j2Msg("Bola shimolga qarab turibdi. U: o'ngga, o'ngga, chapga burildi, keyin orqasiga o'girildi. Qayerga qarayapti?")},
 fin:function(){q18Compass("G'");j2Msg("Har burilishni ketma-ket bajaramiz: <b>g'arbga</b>.")},
 html:"<p>Yo'nalishlar: <b>shimol</b> (Sh), <b>sharq</b> (Shq), <b>janub</b> (J), <b>g'arb</b> (G'). «O'ngga» — soat yo'nalishida 90°, «orqaga» — 180°.</p>",
 btns:j2Pick(["Sharqqa","G'arbga","Janubga","Shimolga"],1,function(){q18Compass("G'");j2Msg("To'g'ri! Sh → Shq → J → Shq → G'.")},function(){j2Msg("Har burilishni alohida yozing: Sh → (o'ng) → ?")}),g2:1,
 after:"<p>Burilishlarni qo'shish ham mumkin: o'ng + o'ng + chap = bitta o'ng (90°), orqaga = 180°. Jami 270° o'ngga = 90° chapga: shimoldan chapga — g'arb.</p>",
 q:{t:"Bola janubga qarab turibdi. Chapga, chapga, chapga burildi. Qayerga qarayapti?",opts:["Sharqqa","G'arbga","Shimolga","Janubga"],ok:1,why:"J → Shq → Sh → G'.",hint:"Janubga qarab turgan odamning chap tomoni qayer?",full:"Janubga qaraganda chap tomon — sharq. Keyin sharqdan chapga — shimol, shimoldan chapga — g'arb. Uchta chap = bitta o'ng: janubdan o'ngga — g'arb."},
 tn:"Sinfda o'rningizdan turib, buyruqlar bilan buriling — bolalar ham bajarsin."},
{h:"Tuzoq: to'g'ri yo'l doim qisqa emasmi?",sum:"Uchburchakda to'g'ri yo'l doim qisqa: A–C 10 km < A–B–C 12 km. Lekin yo'l tarmog'ida aylanma qisqa bo'lishi mumkin.",a:"m06",
 start:function(){k4Graph({A:[50,130],B:[180,40],C:[310,130]},[['A','B',7],['B','C',5],['A','C',10]]);j2Msg("A dan C ga qaysi yo'l qisqa?")},
 fin:function(){k4Graph({A:[50,130],B:[180,40],C:[310,130]},[['A','B',7],['B','C',5],['A','C',10]],[2]);j2Msg("To'g'ri yo'l: 10 km < 7 + 5 = 12 km.")},
 html:"<p>A–B 7 km, B–C 5 km, A–C 10 km. 3-qadamda aylanma yo'l qisqa chiqdi. Bu yerda-chi?</p>",
 btns:j2Pick(["A–B–C","A–C"],1,function(){k4Graph({A:[50,130],B:[180,40],C:[310,130]},[['A','B',7],['B','C',5],['A','C',10]],[2]);j2Msg("To'g'ri: 10 < 12.")},function(){j2Msg("7 + 5 = 12 km — bu 10 dan uzun.")}),
 after:"<p>Uchburchakda ikki tomon yig'indisi har doim uchinchisidan katta. 3-qadamda esa A–C–E yo'li (2 + 10) «to'g'ri» ko'rinsa ham, uzunligi katta edi. Har doim <b>hisoblang</b>, ko'zga ishonmang.</p>",
 q:{t:"5 ta uy bor, har ikki uy alohida yo'l bilan tutashgan. Jami nechta yo'l?",opts:["20","10","5","25"],ok:1,why:"Har uydan 4 ta yo'l: 5 · 4 = 20, har yo'l ikki marta sanalgan: 10.",hint:"Har uydan nechta yo'l chiqadi? Har yo'lning nechta uchi bor?",full:"Har uydan 4 ta yo'l: 5 · 4 = 20. Lekin har yo'l ikki uyni tutashtiradi — ikki marta sanaldi. 20 : 2 = 10."},
 tn:"5 ta bolani doira bo'lib turg'izing, har juft qo'l siqishsin — qo'l siqishlar sonini sanang (10)."},
{h:"Bilasizmi? Navigator qanday ishlaydi",sum:"Telefondagi navigatorlar eng qisqa yo'lni Deykstra (1959) usuliga o'xshash usullar bilan topadi.",a:"m07",
 start:function(){j2Lines([["📱 A → … → E",C.blue,22],["har tugunga eng qisqa masofa",null,15]]);j2Msg("Edsger Deykstra, 1959")},fin:function(){j2Lines([["📱 A → … → E",C.blue,22],["har tugunga eng qisqa masofa",null,15]]);j2Msg("Edsger Deykstra, 1959")},
 html:"<p>📱 Gollandiyalik olim <b>Edsger Deykstra</b> 1959-yilda eng qisqa yo'lni topish usulini e'lon qilgan. U siz 3-qadamda qilgan ishga juda o'xshaydi: har chorrahaga boshlang'ich nuqtadan eng qisqa masofa yozib boriladi.</p><p>Bugun telefondagi xaritalar va navigatorlar shu g'oyaning takomillashgan turlaridan foydalanadi.</p>",
 btns:[["📱 Qiziq!",function(c,done){done()}]],
 tn:"«Maktabdan uyingizgacha eng qisqa yo'l» — bolalar o'z mahallasi xaritasini chizib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["tugun = chap + past",C.blue,24]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["tugun = chap + past",C.blue,24]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Panjarada yo'llar: har tugun = <b>chapdagi + pastdagi</b>. Yopiq tugun = 0.</li><li>Eng qisqa yo'l: har tugunga boshdan eng qisqa masofani yozing; aylanma yo'l qisqa bo'lishi mumkin.</li><li>Masshtab: sm → km uchun 5 ta nolni o'chiring (1 : 200 000 → 2 km).</li><li>Burilishlar: o'ng = soat bo'yicha 90°, 3 ta chap = 1 ta o'ng.</li><li>A → B (m yo'l), B → C (n yo'l): A → C = m · n.</li><li>Har ikki nuqta tutashsa: n · (n − 1) : 2 ta yo'l.</li></ul></div>",
 tn:"Uyga: 3 × 3 panjarada (3 o'ngga, 3 tepaga) yo'llar sonini toping (20)."}
];
var PROBS=[
{t:"Faqat o'ngga va tepaga: 3 o'ngga, 2 tepaga. Nechta yo'l?",o:["10","6","5","20"],k:0,s:"1,1,1,1 / 1,2,3,4 / 1,3,6,10."},
{t:"Faqat o'ngga va tepaga: 2 o'ngga, 2 tepaga. Nechta yo'l?",o:["6","4","8","3"],k:0,s:"1,1,1 / 1,2,3 / 1,3,6."},
{t:"Faqat o'ngga va tepaga: 3 o'ngga, 3 tepaga. Nechta yo'l?",o:["20","9","12","18"],k:0,s:"Oxirgi qator: 1, 4, 10, 20."},
{t:"3 o'ngga, 2 tepaga; (1; 1) tugun yopiq. Nechta yo'l?",o:["4","6","10","8"],k:0,s:"1,1,1,1 / 1,0,1,2 / 1,1,2,4."},
{t:"Masshtab 1 : 200 000. Xaritada 3 sm. Haqiqiy masofa?",o:["6 km","600 m","60 km","3 km"],k:0,s:"1 sm = 2 km."},
{t:"Masshtab 1 : 50 000. Xaritada 8 sm. Haqiqiy masofa?",o:["4 km","40 km","400 m","8 km"],k:0,s:"8 · 50 000 = 400 000 sm = 4 km."},
{t:"Haqiqiy masofa 12 km, xaritada 4 sm. Masshtab?",o:["1 : 300 000","1 : 3 000","1 : 30 000","1 : 48 000"],k:0,s:"1 sm = 3 km = 300 000 sm."},
{t:"Yo'llar: A–B 4 km, A–C 2 km, C–B 1 km, B–D 5 km. A dan D gacha eng qisqa masofa?",o:["8 km","9 km","11 km","7 km"],k:0,s:"A–C–B–D = 2 + 1 + 5."},
{t:"Uydan maktabga 3 ta, maktabdan bozorga 4 ta yo'l. Uydan bozorga maktab orqali nechta yo'l?",o:["12","7","3","4"],k:0,s:"3 · 4 = 12."},
{t:"Shunga uydan bozorga to'g'ri boradigan yana 2 ta yo'l qo'shildi. Jami nechta yo'l?",o:["14","24","12","9"],k:0,s:"12 + 2 = 14."},
{t:"Janubga qarab: chapga, chapga, chapga burildi. Qayerga qarayapti?",o:["G'arbga","Sharqqa","Shimolga","Janubga"],k:0,s:"J → Shq → Sh → G'."},
{t:"Shimolga qarab: o'ngga, o'ngga, chapga, keyin orqaga o'girildi. Qayerga qarayapti?",o:["G'arbga","Sharqqa","Janubga","Shimolga"],k:0,s:"Sh → Shq → J → Shq → G'."},
{t:"Robot (2; 2) da. 4 qadam sharqqa, 3 qadam shimolga, 1 qadam g'arbga yurdi. Qayerda?",o:["(5; 5)","(7; 5)","(5; 3)","(6; 5)"],k:0,s:"x: 2 + 4 − 1 = 5; y: 2 + 3 = 5."},
{t:"Robot (1; 1) dan (5; 4) ga faqat sharq va shimolga yurib boradi. Necha qadam?",o:["7","9","5","12"],k:0,s:"4 + 3 = 7."},
{t:"(1; 1) dan (4; 3) ga faqat sharq va shimolga yurib nechta har xil yo'l bor?",o:["10","5","6","20"],k:0,s:"3 o'ngga, 2 tepaga → 10."},
{t:"Masshtab 1 : 1 200 000. Xaritada 5 sm. Soatiga 60 km tezlikda necha soat yuriladi?",o:["1 soat","5 soat","2 soat","12 soat"],k:0,s:"1 sm = 12 km, 5 sm = 60 km → 1 soat."},
{t:"Bog' 30 m × 40 m. Burchakdan qarama-qarshi burchakka bog' chetidan yurilsa, necha m?",o:["70 m","140 m","50 m","1 200 m"],k:0,s:"30 + 40 = 70."},
{t:"5 ta uy, har ikki uy alohida yo'l bilan tutashgan. Jami nechta yo'l?",o:["10","20","5","25"],k:0,s:"5 · 4 : 2 = 10."},
{t:"A–B 7 km, B–C 5 km, A–C 10 km. A dan C ga eng qisqa yo'l?",o:["10 km","12 km","5 km","22 km"],k:0,s:"To'g'ri yo'l: 10 < 12."},
{t:"Labirintda ketma-ket 4 ta chorraha, har birida 2 ta yo'l (o'ng yoki chap). Nechta har xil marshrut?",o:["16","8","4","6"],k:0,s:"2 · 2 · 2 · 2 = 16."}
];
function PRACT_STAGE(){q18Grid(G1)}
var PREP_DATA={teach:["Panjarada yo'llarni qo'shib sanash.","Yopiq tugun = 0.","Eng qisqa yo'l: tugunlarga masofa yozish.","Masshtab va yo'nalishlar."],
 mist:["Yo'llarni chizib sanaydi va adashadi.","Eng qisqa yo'lni «eng kam qishloqli» yo'l deb o'ylaydi.","sm dan km ga o'tishda nollarni noto'g'ri o'chiradi.","Orqaga o'girilishni 90° deb oladi."],
 need:["Katakli qog'oz, rangli qalam.","Tuman xaritasi, chizg'ich, kompas."],
 board:["<span class='w2'>1,1,1,1 / 1,2,3,4 / 1,3,6,10</span>.","<span class='w2'>1,0,1,2 / 1,1,2,4</span>.","<span class='w2'>A–C–B–D–E = 11</span>.","<span class='w2'>1 : 200 000 → 2 km</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
