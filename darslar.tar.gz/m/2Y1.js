var CODE='2Y1',TITLE='2-sinf yakuni · Uch xonali sonlar bilan jumboqlar';
// ---------- sahna vositalari ----------
function y1Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y1Box(x,y,txt,col,w){w=w||44;E('rect',{x:x-w/2,y:y-28,width:w,height:46,rx:8,fill:col||'#fff',stroke:col?C.line:'#c9d3dd','stroke-width':2},S.g);T(S.g,x,y+6,txt==null?'□':String(txt),{'font-size':26,'font-weight':800,fill:txt==null?'#9aa8b6':'#1d2b3a'})}
function y1Line(txt,y,col,fs){T(S.g,180,y,txt,{'font-size':fs||16,'font-weight':800,fill:col||'#1d2b3a'})}
// 1) yashiringan raqam: 7□4 < 73□ (ikkala □ bir xil)
function y1Hid(d,all){clear();y1Line('7□4  <  73□',38,'#1d2b3a',26);T(S.g,180,58,'(ikkala □ da bir xil raqam)',{'font-size':11,fill:'#5b6b7b'});
 if(d!=null&&!all){var a=700+d*10+4,b=730+d,ok=a<b;y1Line(a+(ok?'  <  ':(a===b?'  =  ':'  >  '))+b,104,ok?C.ok:C.bad,26);y1Line(ok?'✓ to‘g‘ri':'✗ noto‘g‘ri',136,ok?C.ok:C.bad,14)}
 if(all){y1Line('704 < 730,  714 < 731,  724 < 732',100,C.ok,15);y1Line('734 > 733 ✗  — demak faqat 0, 1, 2',130,C.bad,13);y1Line('Javob: 3 ta raqam',158,C.blue,15)}
 y1Msg('Yuzliklar teng (7 = 7). Endi <b>o‘nliklarni</b> solishtiring: □ va 3')}
// 2) raqamlardan son
function y1Make(sl,dig,note){clear();[0,1,2].forEach(function(i){y1Box(120+i*60,52,sl[i],sl[i]!=null?'#f6d9a8':null)});
 T(S.g,120,92,'yuzlik',{'font-size':10,fill:'#5b6b7b'});T(S.g,180,92,'o‘nlik',{'font-size':10,fill:'#5b6b7b'});T(S.g,240,92,'birlik',{'font-size':10,fill:'#5b6b7b'});
 dig.forEach(function(d,i){var used=sl.indexOf(d)>=0;E('circle',{cx:130+i*50,cy:136,r:18,fill:used?'#e8eef5':'#fff',stroke:used?'#c9d3dd':C.blue,'stroke-width':2},S.g);T(S.g,130+i*50,143,String(d),{'font-size':20,'font-weight':800,fill:used?'#aab':'#1d2b3a'})});
 y1Msg(note||'Raqamlarni pastdan tanlab, katta xonadan boshlab qo‘ying')}
// 4) yig'indisi 20 bo'lgan eng kichik
var P4=[function(){clear();[0,1,2].forEach(function(i){y1Box(120+i*60,60,null)});y1Msg('Raqamlari yig‘indisi 20 ga teng <b>eng kichik</b> uch xonali son. Qayerdan boshlaymiz?')},
 function(){clear();y1Box(120,60,null);y1Box(180,60,null);y1Box(240,60,9,'#bfe9e3');y1Line('birlikka eng katta raqam: 9',120,C.u,13);y1Msg('Son kichik bo‘lishi uchun <b>yuzlik iloji boricha kichik</b> bo‘lishi kerak. Buning uchun qolgan xonalarga eng katta raqamlarni beramiz')},
 function(){clear();y1Box(120,60,null);y1Box(180,60,9,'#bfe9e3');y1Box(240,60,9,'#bfe9e3');y1Line('9 + 9 = 18, yana 20 − 18 = 2 kerak',120,C.u,13);y1Msg('O‘nlikka ham 9')},
 function(){clear();y1Box(120,60,2,'#f6d9a8');y1Box(180,60,9,'#bfe9e3');y1Box(240,60,9,'#bfe9e3');y1Line('2 + 9 + 9 = 20 ✓',120,C.ok,16);y1Msg('Javob: <b>299</b>. Tekshiramiz: 389, 479 ham yig‘indisi 20, lekin ular kattaroq')}];
// 5) 0 raqami necha marta
var P5=[function(){clear();y1Line('1, 2, 3, …, 99, 100',50,'#1d2b3a',20);y1Msg('1 dan 100 gacha hamma sonlar yozildi. <b>0</b> raqami necha marta yozildi?')},
 function(){clear();y1Line('1, 2, 3, …, 99, 100',40,'#1d2b3a',16);y1Line('1 0 · 2 0 · 3 0 · 4 0 · 5 0 · 6 0 · 7 0 · 8 0 · 9 0',92,C.blue,15);y1Msg('Ikki xonali sonlarda 0 faqat oxirida: 10, 20, …, 90 — <b>9 marta</b>')},
 function(){clear();y1Line('1, 2, 3, …, 99, 100',40,'#1d2b3a',16);y1Line('10, 20, …, 90 → 9 ta',86,C.blue,15);y1Line('1 0 0 → 2 ta',120,C.bad,18);y1Msg('100 da <b>ikkita</b> nol! Jami: 9 + 2 = <b>11</b> (10 emas!)')}];
// 6) sahifalar raqamlash
var P6=[function(){clear();y1Line('1, 2, 3, …, 25',50,'#1d2b3a',20);y1Msg('Kitob sahifalari 1 dan 25 gacha raqamlangan. Jami nechta <b>raqam</b> yozilgan?')},
 function(){clear();y1Line('1 … 9  →  9 ta son × 1 raqam = 9',76,C.blue,14);y1Msg('Bir xonali sahifalar: 1 dan 9 gacha — 9 ta raqam')},
 function(){clear();y1Line('1 … 9  →  9 × 1 = 9',60,C.blue,14);y1Line('10 … 25  →  16 ta son × 2 raqam = 32',96,C.t1,14);y1Line('9 + 32 = 41',136,C.ok,18);y1Msg('10 dan 25 gacha: 25 − 10 + 1 = <b>16</b> ta son, har birida 2 raqam. Jami <b>41</b>')}];
// 7) eng katta - eng kichik (raqamlari har xil)
var P7=[function(){clear();y1Line('raqamlari har xil:',30,'#5b6b7b',12);y1Line('eng katta uch xonali  −  eng kichik uch xonali',60,'#1d2b3a',13);y1Msg('Raqamlari har xil bo‘lgan eng katta va eng kichik uch xonali sonlar farqi?')},
 function(){clear();y1Line('eng katta: 9 _ _ → 9 8 _ → 987',60,C.blue,15);y1Line('(999 bo‘lmaydi — raqamlar takrorlanadi)',86,'#5b6b7b',11);y1Msg('Eng kattasi: yuzlikka 9, o‘nlikka 8, birlikka 7 — <b>987</b>')},
 function(){clear();y1Line('eng katta: 987',44,C.blue,15);y1Line('eng kichik: 1 _ _ → 1 0 _ → 102',76,C.t1,15);y1Line('(100 va 101 bo‘lmaydi — 0 yoki 1 takrorlanadi)',100,'#5b6b7b',11);y1Line('987 − 102 = 885',140,C.ok,20);y1Msg('Eng kichigi: <b>102</b> (0 birinchi tura olmaydi). Farq: <b>885</b>')}];
// 8) yig'indisi 3 ga teng uch xonali sonlar
var P8=[function(){clear();y1Line('Raqamlari yig‘indisi 3 ga teng uch xonali sonlar nechta?',40,'#1d2b3a',13);y1Msg('Tartib bilan, yuzlik raqamidan boshlab sanaymiz — hech biri tushib qolmasin')},
 function(){clear();y1Line('yuzlik 1:  102, 111, 120',50,C.blue,15);y1Msg('Yuzlik 1 bo‘lsa, qolgan ikkitasining yig‘indisi 2: <b>3 ta</b>')},
 function(){clear();y1Line('yuzlik 1:  102, 111, 120',50,C.blue,15);y1Line('yuzlik 2:  201, 210',84,C.t1,15);y1Msg('Yuzlik 2 bo‘lsa, qolgani 1: <b>2 ta</b>')},
 function(){clear();y1Line('yuzlik 1:  102, 111, 120',44,C.blue,15);y1Line('yuzlik 2:  201, 210',74,C.t1,15);y1Line('yuzlik 3:  300',104,C.u,15);y1Line('3 + 2 + 1 = 6',144,C.ok,20);y1Msg('Jami: <b>6 ta</b>. Tartibli sanash — olimpiadaning asosiy quroli')}];
// Kaprekar
function y1Kap(n){clear();var steps=[],x=n,k=0;while(x!==495&&k<8){var d=String(x).padStart(3,'0').split('').map(Number),hi=+d.slice().sort(function(a,b){return b-a}).join(''),lo=+d.slice().sort(function(a,b){return a-b}).join('');steps.push(hi+' − '+String(lo).padStart(3,'0')+' = '+(hi-lo));x=hi-lo;k++}
 y1Line('Son: '+n,24,'#1d2b3a',15);steps.slice(0,6).forEach(function(s,i){T(S.g,180,48+i*21,s,{'font-size':13,'font-weight':700,fill:i===steps.length-1?C.ok:'#33475b'})});y1Msg('Har safar: raqamlarni kamayish tartibida − o‘sish tartibida. Oxiri doim <b>495</b>!')}
var STEPS=[
{h:"Yashiringan raqam",sum:"7□4 < 73□ (bir xil raqam): yuzliklar teng, o'nliklar □ < 3 → 0, 1, 2 — 3 ta.",a:"m01",
 start:function(){y1Hid(null)},fin:function(){y1Hid(null,true)},
 html:"<p><b>7□4 &lt; 73□</b> — ikkala kvadratda <b>bir xil</b> raqam. Qaysi raqamlar to'g'ri keladi? Raqamlarni sinab ko'ring:</p><div class='digs y1d'></div>",
 act:function(c,done){var box=c.querySelector('.y1d'),seen={};box.innerHTML='';for(var d=0;d<=9;d++)(function(d){var b=document.createElement('button');b.className='dg';b.textContent=d;b.onclick=function(){y1Hid(d);b.className='dg '+((700+d*10+4)<(730+d)?'yes':'no');seen[d]=1;if(Object.keys(seen).length>=5&&!st['a'+cur])done()};box.appendChild(b)})(d)},
 after:"<p>Faqat <b>0, 1, 2</b> — 3 ta raqam. Usul: avval <b>katta xonalarni</b> solishtiramiz. Yuzliklar teng (7 = 7), demak hal qiluvchi — o'nliklar: □ va 3. □ = 3 bo'lsa, 734 va 733 — birliklarda 4 &gt; 3, to'g'ri emas.</p>",
 q:{t:"5□8 > 57□ tengsizlikda ikkala □ da bir xil raqam. Nechta raqam to'g'ri keladi?",opts:["3","2","1","4"],ok:0,why:"□ = 7 (578 > 577), 8 (588 > 578), 9 (598 > 579) — 3 ta.",hint:"Yuzliklar teng. O'nliklarni solishtiring: □ va 7. □ = 7 bo'lsa, birliklarga qarang!",full:"□ < 7 bo'lsa, o'nliklarda □ < 7 — noto'g'ri. □ = 7: 578 va 577 — birliklarda 8 > 7, to'g'ri! □ = 8, 9 — o'nliklarda katta, to'g'ri. Javob: 7, 8, 9 — 3 ta. «2» — chegaradagi 7 ni tekshirmaslik xatosi."},
 tn:"Olimpiada uslubi: bolalar avval taxmin qilsin, keyin har bir raqamni jadvalda tekshirsin."},
{h:"Raqamlardan eng katta son",sum:"Eng katta son — katta raqamlar chapda: 3, 0, 7 → 730. Eng kichik: 0 boshda turmaydi → 307.",a:"m02",
 start:function(){S.sl=[null,null,null];y1Make(S.sl,[3,0,7],'3, 0, 7 raqamlaridan <b>eng katta</b> uch xonali son tuzing')},fin:function(){y1Make([7,3,0],[3,0,7],'Eng katta: <b>730</b>. Eng kichik: <b>307</b>')},
 html:"<p>3, 0, 7 raqamlaridan (har biri bir marta) <b>eng katta</b> uch xonali son tuzing. Raqamlarni katta xonadan boshlab tanlang:</p>",
 btns:[["3",function(c,done){y1Pick(3,done)}],["0",function(c,done){y1Pick(0,done)}],["7",function(c,done){y1Pick(7,done)}],["↺",function(){S.sl=[null,null,null];y1Make(S.sl,[3,0,7])}]],
 after:"<p>Eng katta son: <b>eng katta raqam — yuzliklarga</b>, keyingisi — o'nliklarga: <b>730</b>. Eng kichik son: eng kichik raqam yuzliklarga, lekin <b>0 bo'lmasin</b> (aks holda son ikki xonali bo'lib qoladi): <b>307</b>.</p>",
 q:{t:"5, 0, 2, 8 raqamlaridan (har biri bir marta) tuzilgan eng kichik uch xonali son qaysi?",opts:["025","205","208","250"],ok:1,why:"Yuzlikka 0 dan keyingi eng kichigi — 2, keyin 0, keyin 5: 205.",hint:"0 yuzliklarda tura oladimi? Qolganlaridan eng kichigi qaysi?",full:"0 yuzlikka qo'yilmaydi. Yuzlikka 2, o'nlikka 0, birlikka 5 (8 dan kichik): 205. «025» — uch xonali son emas, «208» — 5 o'rniga 8 olindi."},
 tn:"Raqam kartochkalari bilan o'yin: bolalar navbat bilan eng katta va eng kichik sonni tuzadi."},
{h:"Nechta son tuzish mumkin?",sum:"3 ta har xil raqam (0 siz): 6 ta son. 0 bo'lsa: 4 ta (0 boshda turmaydi).",a:"m03",
 start:function(){y1Tree(false)},fin:function(){y1Tree(true)},
 html:"<p>1, 2, 3 raqamlaridan (har biri bir marta) nechta har xil uch xonali son tuzish mumkin? Tartib bilan yozib chiqamiz:</p>",
 btns:[["🌳 Daraxtni chizish",function(c,done,b){b.disabled=true;y1Tree(true);done()}]],
 after:"<p>Yuzlikka 3 xil raqam, har biridan keyin o'nlikka 2 xil, birlikka qolgan 1 ta: <b>3 · 2 · 1 = 6</b>. Agar raqamlardan biri <b>0</b> bo'lsa, u yuzlikka qo'yilmaydi: masalan 1, 0, 5 dan — 105, 150, 501, 510 — <b>4 ta</b>.</p>",
 q:{t:"1, 0, 5 raqamlaridan (har biri bir marta) nechta uch xonali son tuzish mumkin?",opts:["6","4","3","2"],ok:1,why:"105, 150, 501, 510 — 4 ta (0 boshda turmaydi).",hint:"0 yuzliklar xonasida tura oladimi? Yuzlikka nechta raqam qoladi?",full:"Yuzlikka faqat 1 yoki 5. 1 bo'lsa: 105, 150. 5 bo'lsa: 501, 510. Jami 4 ta. «6» — 0 ni ham boshda deb hisoblash xatosi."},
 tn:"«Daraxt» usuli (tartibli ro'yxat) — kombinatorikaning asosi. Bolalar daftarga daraxt chizsin."},
{h:"Raqamlar yig'indisi sharti",sum:"Yig'indisi 20, eng kichik son: birlik va o'nlikka eng katta (9, 9), yuzlikka qolgani (2) — 299.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Bankdagi qiyin savol: <i>«Raqamlarining yig'indisi 20 ga teng bo'lgan eng kichik uch xonali sonni toping.»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Kalit fikr: son kichik bo'lishi uchun <b>yuzlik iloji boricha kichik</b> bo'lsin. Buning uchun qolgan xonalar eng ko'p «yuk»ni olsin — <b>9</b> lar. Teskarisi: eng katta son uchun yuzlikka 9 dan boshlaymiz.</p>",
 q:{t:"Raqamlari yig'indisi 15 ga teng eng kichik uch xonali son qaysi?",opts:["159","169","96","555"],ok:0,why:"Birlik 9, o'nlik 5 (9 + 5 = 14), yuzlik 1: 159.",hint:"Yuzlik eng kichik bo'lishi uchun nima qilish kerak? Lekin yuzlik 0 bo'la olmaydi!",full:"Yuzlik eng kichigi — 1 (0 bo'lmaydi). Qolgan 14 ni o'nlik va birlik oladi: o'nlik kichik bo'lsin — birlikka 9, o'nlikka 5: 159. «96» — ikki xonali, «169» — yig'indisi 16."},
 tn:"Bolalar avval eng katta sonni topsin (yig'indisi 20: 992), keyin eng kichigini — ikkala strategiyani solishtirsin."},
{h:"Tuzoq: 0 necha marta yozildi?",sum:"1 dan 100 gacha: 10, 20 … 90 da 9 ta nol, 100 da 2 ta — jami 11.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Mashhur olimpiada savoli: <i>«1 dan 100 gacha bo'lgan sonlar ketma-ket yozildi. 0 raqami necha marta yozildi?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>Ko'pchilik «10» deydi — 100 ni unutadi yoki undagi <b>ikkinchi nolni</b> sanamaydi. Raqamlarni sanashda har bir sonning <b>har bir raqamini</b> alohida hisoblang.</p>",
 q:{t:"1 dan 50 gacha sonlar yozildi. 0 raqami necha marta yozildi?",opts:["4","5","6","10"],ok:1,why:"10, 20, 30, 40, 50 — 5 ta nol.",hint:"Qaysi sonlarda 0 bor? 50 kiradimi?",full:"Nol faqat 10, 20, 30, 40, 50 da — 5 marta. 50 ham kiradi (chegarasi «gacha»)."},
 tn:"Ikkinchi qiyinroq variant: «45 dan 125 gacha 0 necha marta?» (50, 60, 70, 80, 90 — 5; 100 — 2; 101–109 — 9; 110, 120 — 2: jami 18)."},
{h:"Tuzoq: sahifalarga nechta raqam?",sum:"1–25 sahifalar: 1–9 da 9 raqam, 10–25 da 16 · 2 = 32 raqam — jami 41.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p><i>«Kitob sahifalari 1 dan 25 gacha raqamlangan. Jami nechta raqam yozilgan?»</i> Javob 25 emas!</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: sonlarni <b>xonalar soni bo'yicha guruhlaymiz</b>: bir xonalilar (har biri 1 raqam), ikki xonalilar (har biri 2 raqam). 10 dan 25 gacha nechta son — «dan … gacha» qoidasi: 25 − 10 + 1 = 16.</p>",
 q:{t:"Kitob sahifalari 1 dan 30 gacha raqamlangan. Jami nechta raqam yozilgan?",opts:["30","51","60","42"],ok:1,why:"9 + 21 · 2 = 9 + 42 = 51.",hint:"Bir xonali sahifalar nechta? Ikki xonalilar nechta (10 dan 30 gacha)?",full:"1–9: 9 ta raqam. 10–30: 30 − 10 + 1 = 21 ta son, har biri 2 raqam — 42. Jami 9 + 42 = 51. «42» — faqat ikki xonalilar."},
 tn:"Bu masala 2A3 dagi «dan … gacha» qoidasi bilan bog'langan — o'sha qoidani eslating."},
{h:"Raqamlari har xil: eng katta − eng kichik",sum:"Raqamlari har xil eng katta uch xonali — 987, eng kichigi — 102; farqi 885.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p><i>«Raqamlari har xil bo'lgan eng katta uch xonali sondan raqamlari har xil bo'lgan eng kichik uch xonali sonni ayiring.»</i></p>",
 btns:[phaser(P7)],
 after:"<p>Tuzoqlar: <b>999</b> va <b>100</b> — raqamlari takrorlangan, ular mos emas! <b>012</b> — uch xonali emas. To'g'ri: 987 va 102, farqi <b>885</b>.</p>",
 q:{t:"Raqamlari har xil bo'lgan eng katta uch xonali son raqamlari har xil bo'lgan eng kichik ikki xonali sondan qancha katta?",opts:["989","977","976","975"],ok:1,why:"987 − 10 = 977.",hint:"Raqamlari har xil eng kichik ikki xonali son — 10 (1 va 0 har xil).",full:"Eng katta uch xonali (raqamlari har xil) — 987. Eng kichik ikki xonali (raqamlari har xil) — 10. 987 − 10 = 977. «989» — 999 − 10, «976» — 987 − 11."},
 tn:"Bolalarga «raqamlari har xil» shartini doira ichiga oldiring — ko'pchilik uni o'qimay o'tib ketadi."},
{h:"Tartibli sanash usuli",sum:"Yig'indisi 3 ga teng uch xonali sonlar: yuzlik 1 → 3 ta, 2 → 2 ta, 3 → 1 ta — jami 6.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p><i>«Raqamlari yig'indisi 3 ga teng bo'lgan nechta uch xonali son bor?»</i> Tasodifan qidirsak, birortasini unutamiz. <b>Tartib bilan</b> sanaymiz.</p>",
 btns:[phaser(P8)],
 after:"<p>Usul: yuzlik raqamini <b>eng kichigidan</b> boshlab o'zgartiramiz va har biri uchun mos sonlarni yozamiz. Shunda birorta son ham tushib qolmaydi va ikki marta ham yozilmaydi.</p>",
 q:{t:"Raqamlari yig'indisi 2 ga teng nechta uch xonali son bor?",opts:["2","3","4","1"],ok:1,why:"101, 110, 200 — 3 ta.",hint:"Yuzlik 1 bo'lsa qolgani 1, yuzlik 2 bo'lsa qolgani 0.",full:"Yuzlik 1: 101, 110 (qolgan yig'indi 1). Yuzlik 2: 200. Jami 3 ta. 011, 020 — uch xonali emas."},
 tn:"Bolalar «Raqamlari yig'indisi 4 ga teng uch xonali sonlar» ni o'zi tartib bilan sanasin (10 ta)."},
{h:"Bilasizmi? Sehrli 495",sum:"Uch xonali sonda (raqamlari bir xil bo'lmasa) «katta − kichik» amali oxiri doim 495 ga keladi.",a:"m09",
 start:function(){y1Kap(752)},fin:function(){y1Kap(752)},
 html:"<p>✨ Hindistonlik matematik <b>Kaprekar</b> qiziq hodisani topgan. Istalgan uch xonali sonni oling (raqamlari hammasi bir xil bo'lmasin). Raqamlarini kamayish tartibida yozib, o'sish tartibida yozilganini ayiring. Natija bilan ham shuni takrorlang… Oxiri doim <b>495</b>! Sinab ko'ring:</p>",
 btns:[["🎲 Boshqa son",function(c,done){var n;do{n=100+Math.floor(Math.random()*900)}while(n%111===0);y1Kap(n);mvK(done,2)}]],
 after:"<p>495 ga kelgandan keyin: 954 − 459 = 495 — u yerdan chiqib ketmaydi. Uni <b>Kaprekar doimiysi</b> deyishadi.</p>",
 tn:"Bolalar o'z tug'ilgan yili yoki sinf raqami bilan sinab ko'rsin — har safar 495 chiqishi ularni hayratga soladi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){y1Make([7,3,0],[3,0,7],'Eng katta 730, eng kichik 307')},fin:function(){y1Make([7,3,0],[3,0,7],'Eng katta 730, eng kichik 307')},
 html:"<div class='memo'><ul><li>Yashiringan raqam: <b>katta xonadan</b> boshlab solishtiring; tenglik chegarasini tekshiring.</li><li>Eng katta son — katta raqamlar chapda; eng kichik — kichiklari chapda, lekin <b>0 boshda emas</b>.</li><li>3 ta har xil raqamdan — 6 ta son; 0 bo'lsa — 4 ta.</li><li>Yig'indi sharti bilan eng kichik son: o'ngdagi xonalarga 9 lar, yuzlikka qolgani (20 → 299).</li><li>Raqamlarni sanashda har bir sonning hamma raqamini hisoblang: 100 da ikkita 0.</li><li>«Raqamlari har xil» — 987 va 102.</li><li>Tartibli sanash: yuzlikdan boshlab, kichigidan kattasiga.</li></ul></div>",
 tn:"Bu dars 2-sinf yakuniy guruhining birinchisi — kuchli o'quvchilar va olimpiadaga tayyorlanuvchilar uchun."}
];
function y1Pick(d,done){var i=S.sl.indexOf(null);if(i<0||S.sl.indexOf(d)>=0)return;S.sl[i]=d;
 var full=S.sl.indexOf(null)<0,n=S.sl.join('');y1Make(S.sl,[3,0,7],full?(n==='730'?'✓ <b>730</b> — eng katta!':'<b>'+n+'</b> — bu eng katta emas. ↺ bosib, eng katta raqamni yuzlikka qo‘ying'):null);if(full&&n==='730')done()}
function y1Tree(on){clear();var g=S.g;if(!on){y1Line('1, 2, 3 → ? ta son',60,'#1d2b3a',18);y1Msg('Daraxt usuli bilan sanaymiz');return}
 var H=[1,2,3];H.forEach(function(h,i){var x=60+i*120;T(g,x,26,String(h),{'font-size':18,'font-weight':800,fill:C.t1});H.filter(function(v){return v!==h}).forEach(function(t,j){var x2=x-28+j*56;E('line',{x1:x,y1:32,x2:x2,y2:58,stroke:'#9aa8b6'},g);T(g,x2,72,String(t),{'font-size':15,'font-weight':800,fill:C.blue});var u=H.filter(function(v){return v!==h&&v!==t})[0];E('line',{x1:x2,y1:78,x2:x2,y2:96,stroke:'#9aa8b6'},g);T(g,x2,112,String(u),{'font-size':15,'font-weight':800,fill:C.u});T(g,x2,140,''+h+t+u,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})})});
 y1Msg('123, 132, 213, 231, 312, 321 — <b>6 ta</b> = 3 · 2 · 1')}
var PROBS=[
{t:"4□6 < 43□ tengsizlikda ikkala □ da bir xil raqam. Nechta raqam to'g'ri keladi?",o:["3","4","2","10"],k:0,s:"□ < 3: 0, 1, 2 to'g'ri (406 < 430 …). □ = 3: 436 < 433 — yo'q. Javob 3."},
{t:"6□ < 64 bo'lishi uchun □ o'rniga qo'yish mumkin bo'lgan barcha raqamlar yig'indisi?",o:["6","10","4","3"],k:0,s:"0, 1, 2, 3; yig'indisi 6."},
{t:"2, 9, 4 raqamlaridan (har biri bir marta) eng katta uch xonali son?",o:["942","924","294","492"],k:0,s:"Kamayish tartibida: 942."},
{t:"6, 0, 3 raqamlaridan (har biri bir marta) eng kichik uch xonali son?",o:["306","036","360","603"],k:0,s:"0 boshda emas: 306."},
{t:"4, 7, 8 raqamlaridan (har biri bir marta) nechta uch xonali son tuzish mumkin?",o:["6","3","9","4"],k:0,s:"3 · 2 · 1 = 6."},
{t:"2, 0, 9 raqamlaridan (har biri bir marta) nechta uch xonali son tuzish mumkin?",o:["4","6","3","2"],k:0,s:"Yuzlikda 0 bo'lmaydi: 209, 290, 902, 920 — 4 ta."},
{t:"Raqamlari yig'indisi 20 ga teng eng kichik uch xonali son?",o:["299","389","479","992"],k:0,s:"Birlik va o'nlik 9: 2 + 9 + 9 = 20 — 299."},
{t:"Raqamlari yig'indisi 20 ga teng eng katta uch xonali son?",o:["992","299","983","920"],k:0,s:"Yuzlik 9, o'nlik 9, birlik 2: 992."},
{t:"Raqamlari yig'indisi 3 ga teng nechta uch xonali son bor?",o:["6","4","5","7"],k:0,s:"102, 111, 120, 201, 210, 300 — 6 ta."},
{t:"1 dan 100 gacha sonlar yozildi. 0 raqami necha marta yozildi?",o:["11","10","9","12"],k:0,s:"10, 20 … 90 — 9; 100 — 2; jami 11."},
{t:"Kitob sahifalari 1 dan 25 gacha raqamlangan. Jami nechta raqam yozilgan?",o:["41","25","50","39"],k:0,s:"9 + 16 · 2 = 41."},
{t:"Raqamlari har xil eng katta uch xonali sondan raqamlari har xil eng kichik uch xonali sonni ayiring.",o:["885","899","887","897"],k:0,s:"987 − 102 = 885."},
{t:"Raqamlari har xil eng katta uch xonali son raqamlari har xil eng kichik ikki xonali sondan qancha katta?",o:["977","989","976","975"],k:0,s:"987 − 10 = 977."},
{t:"7 ta yuzlik, yuzliklardan 6 ta kam o'nlik va o'nliklardan 5 ta ko'p birlikka ega son?",o:["716","761","756","765"],k:0,s:"7 yuzlik, 1 o'nlik, 6 birlik: 716."},
{t:"Uch xonali sonning yuzlar raqami 4, o'nlar raqami undan 3 ta katta, birlar raqami o'nlar va yuzlar raqamlari ayirmasiga teng. Son?",o:["473","471","743","437"],k:0,s:"4, 7, 7 − 4 = 3: 473."},
{t:"Uch xonali son 4 bilan boshlanadi. Shu 4 sonning oxiriga ko'chirilsa, son 189 ga kamayadi. Bu qaysi son?",o:["423","432","243","342"],k:0,s:"423 → 234; 423 − 234 = 189 ✓."},
{t:"Qaysi uch xonali son raqamlari o'rnini teskari almashtirsak o'zgarmaydi?",o:["474","447","744","470"],k:0,s:"474 → 474 (birinchi va oxirgi raqam teng)."},
{t:"Yuzlar va birlar raqami bir xil bo'lgan (masalan, 101, 252) uch xonali sonlar 100 dan 200 gacha nechta?",o:["10","9","11","1"],k:0,s:"1_1: 101, 111, …, 191 — 10 ta."},
{t:"Raqamlari ko'paytmasi 0 ga teng eng katta uch xonali son?",o:["990","999","909","900"],k:0,s:"Nol bo'lishi shart; eng kattasi — 990."},
{t:"45 dan 125 gacha sonlar yozildi. 0 raqami necha marta yozildi?",o:["18","16","9","17"],k:0,s:"50, 60, 70, 80, 90 — 5; 100 — 2; 101–109 — 9; 110, 120 — 2: jami 18."}
];
function PRACT_STAGE(){y1Make([7,3,0],[3,0,7],'Katta xonadan boshlab o‘ylang')}
var PREP_DATA={teach:["Yashiringan raqamli tengsizliklar (bir xil raqam sharti).","Raqamlardan eng katta / eng kichik son; nechta son tuzish mumkin (daraxt usuli).","Raqamlar yig'indisi sharti bilan eng kichik/katta son.","Raqamlarni sanash (0 necha marta, sahifalar), «raqamlari har xil» sharti, tartibli sanash."],
 mist:["Tenglik chegarasini tekshirmaydi (7□4 < 73□ da 3 ni ham oladi).","0 ni yuzlikka qo'yadi (025).","100 dagi ikkinchi nolni sanamaydi.","«Raqamlari har xil» shartini o'tkazib yuborib, 999 va 100 ni oladi."],
 need:["Raqam kartochkalari 0–9 (har bolaga).","Daftar: daraxt chizish uchun."],
 board:["<span class='w2'>7□4 < 73□</span>: □ = 0, 1, 2.","3, 0, 7 → <span class='w2'>730</span> va <span class='w2'>307</span>.","Daraxt: 1, 2, 3 → 6 son.","Yig'indisi 20: <span class='w2'>299</span>.","0 necha marta (1–100): <span class='w2'>9 + 2 = 11</span>.","Sahifalar 1–25: <span class='w2'>9 + 32 = 41</span>.","<span class='w2'>987 − 102 = 885</span>."]};
