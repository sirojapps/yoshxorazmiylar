var CODE='2B9',TITLE='2-sinf · Ifodalar qiymatini taqqoslash';
function b9Two(a,b,sign,va,vb){clear();var g=S.g;[[90,a,va],[270,b,vb]].forEach(function(z){E('rect',{x:z[0]-70,y:40,width:140,height:56,rx:12,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},g);T(g,z[0],76,z[1],{'font-size':20,'font-weight':800,fill:'#1d2b3a'});if(z[2]!=null)T(g,z[0],124,'= '+z[2],{'font-size':20,'font-weight':800,fill:C.blue})});
 E('circle',{cx:180,cy:68,r:16,fill:'#fff',stroke:sign?C.ok:'#c9d3dd','stroke-width':2},g);T(g,180,76,sign||'?',{'font-size':22,'font-weight':800,fill:sign?C.ok:'#9aa8b6'})}
function b9Pick(a,b,va,vb,right){return ['<','=','>'].map(function(s){return [s,function(c,done,btn){if(s===right){b9Two(a,b,s,va,vb);bqMsg('To‘g‘ri: '+a+' '+s+' '+b);c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});done()}else{flashBad(btn);bqMsg('Yo‘q, yana o‘ylang')}}]})}
var P1=[function(){b9Two('46 − 9','18 + 18');bqMsg('Qaysi ifodaning qiymati katta?')},
 function(){b9Two('46 − 9','18 + 18',null,37,36);bqMsg('Har birini hisoblaymiz: 46 − 9 = 37, 18 + 18 = 36')},
 function(){b9Two('46 − 9','18 + 18','>',37,36);bqMsg('37 > 36, demak <b>46 − 9 > 18 + 18</b>')}];
var P4=[function(){b9Two('56 − 19','28 + 13');bqMsg('Qaysi biri katta va <b>qanchaga</b>?')},
 function(){b9Two('56 − 19','28 + 13',null,37,41);bqMsg('56 − 19 = 37 (56 − 20 + 1), 28 + 13 = 41')},
 function(){b9Two('56 − 19','28 + 13','<',37,41);bqMsg('41 − 37 = <b>4</b>: ikkinchisi 4 ga katta')}];
var P6=[function(){bqBar(null,[{v:'d',w:60,col:C.b},{v:'−11',w:11,q:1}],{title:'d − 11'});bqMsg('d — istalgan son. Undan 11 ni olamiz…')},
 function(){bqBar(null,[{v:'d',w:60,col:C.b},{v:'−12',w:12,q:1}],{title:'d − 12'});bqMsg('…yoki 12 ni. Qaysi holatda ko‘proq qoladi?')},
 function(){bqExpr(['d − 11 > d − 12','kamroq olsak — ko‘proq qoladi']);bqMsg('Har qanday d uchun <b>d − 11 > d − 12</b> — hisoblash shart emas!')}];
var STEPS=[
{h:"Hisoblab taqqoslaymiz",sum:"46 − 9 ? 18 + 18: 37 > 36, demak 46 − 9 > 18 + 18.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ikki ifodani solishtirishning birinchi yo'li — <b>har birini hisoblash</b>, keyin sonlarni taqqoslash.</p>",
 btns:[phaser(P1)],
 after:"<p>Ifodalar emas, ularning <b>qiymatlari</b> solishtiriladi. Qaysi ifodaning qiymati katta bo'lsa, belgining ochiq tomoni o'shanga qaraydi.</p>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["46 − 9 < 18 + 18","28 + 7 > 50 − 16","63 − 28 > 17 + 19","24 + 19 = 52 − 8"],ok:1,why:"35 > 34.",hint:"Har bir yozuvda ikkala tomonni hisoblang.",full:"37 < 36? yo'q. 35 > 34 ✓. 35 > 36? yo'q. 43 = 44? yo'q. Faqat ikkinchisi to'g'ri."},
 tn:"Har ifoda ostiga qiymatini yozdiring, keyin belgi qo'ydiring."},
{h:"Hisoblamasdan: qo'shishda",sum:"47 + 28 ? 47 + 30: birinchi qo'shiluvchi bir xil, ikkinchisi katta → yig'indi katta.",a:"m02",
 start:function(){bqBar(null,[{v:'47',w:47},{v:'28',w:28,col:C.b}],{title:'47 + 28  ?  47 + 30',y:50});bqMsg('Hisoblamasdan belgi qo‘ying')},fin:function(){b9Two('47 + 28','47 + 30','<')},
 html:"<p>47 + 28 va 47 + 30. Ikkalasida ham 47 bor. Hisoblamasdan belgini tanlang:</p>",
 btns:b9Pick('47 + 28','47 + 30',null,null,'<'),
 after:"<p>Bir xil songa <b>kattaroq</b> son qo'shilsa — yig'indi <b>katta</b>. 30 > 28, demak 47 + 28 < 47 + 30, aniq 2 ga.</p>",
 q:{t:"Belgini qo'ying: 35 + 19 ... 35 + 21",opts:["<",">","="],ok:0,why:"19 < 21, birinchi qo'shiluvchi bir xil.",hint:"Qaysi ifodaga ko'proq qo'shilyapti?",full:"Ikkalasida 35. 19 qo'shilsa kamroq, 21 qo'shilsa ko'proq. Demak 35 + 19 < 35 + 21 (2 ga)."},
 tn:"Bu — algebraik fikrlashning boshlanishi: bola sonlar munosabatiga qaraydi, hisobga emas."},
{h:"Hisoblamasdan: ayirishda",sum:"80 − 19 ? 80 − 21: ko'proq ayirilsa — kamroq qoladi → 80 − 19 > 80 − 21.",a:"m03",
 start:function(){bqBar(80,[{v:'qoldi',w:61,col:C.a},{v:'19',w:19,q:1}],{title:'80 − 19  ?  80 − 21'});bqMsg('Diqqat: ayirishda teskari!')},fin:function(){b9Two('80 − 19','80 − 21','>')},
 html:"<p>80 − 19 va 80 − 21. Qayerda ko'proq qoladi? Belgini tanlang:</p>",
 btns:b9Pick('80 − 19','80 − 21',null,null,'>'),
 after:"<p>Ayirishda teskari: butun bir xil bo'lsa, <b>kamroq ayirilganda ko'proq qoladi</b>. 19 < 21, demak 80 − 19 > 80 − 21. Bu yerda ko'p bola xato qiladi!</p>",
 q:{t:"Belgini qo'ying: 64 − 28 ... 64 − 30",opts:["<",">","="],ok:1,why:"28 ta olinsa 30 ta olingandan ko'proq qoladi.",hint:"Qaysi holda ko'proq olib tashlanyapti?",full:"64 dan 28 olsak — 36, 30 olsak — 34. 36 > 34. Kamroq ayirdik — ko'proq qoldi."},
 tn:"Konfet misoli: 10 ta konfetdan 3 tasini yesangizmi yoki 5 tasini — qachon ko'proq qoladi?"},
{h:"Qaysi biri katta va qanchaga?",sum:"56 − 19 = 37, 28 + 13 = 41 → ikkinchisi 4 ga katta.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ba'zan nafaqat «qaysi katta», balki «<b>qanchaga</b> katta» ham so'raladi.</p>",
 btns:[phaser(P4)],
 after:"<p>«Qanchaga katta» — <b>ayirma</b>: kattasidan kichigini ayiramiz. 41 − 37 = 4.</p>",
 q:{t:"56 − 19 va 28 + 13 dan qaysi birining qiymati katta va qanchaga?",opts:["birinchisi 4 ga","ikkinchisi 4 ga","ikkinchisi 14 ga","ular teng"],ok:1,why:"37 va 41: 41 − 37 = 4.",hint:"Ikkalasini hisoblang va ayirmasini toping.",full:"56 − 19 = 37, 28 + 13 = 41. Ikkinchisi katta: 41 − 37 = 4."},
 tn:"Taqqoslashni ayirma bilan bog'lang: «qanchaga» — doim ayirish."},
{h:"Eng kattasini toping",sum:"100 − 26 = 74, 48 + 25 = 73, 90 − 19 = 71, 36 + 36 = 72 → eng kattasi 100 − 26.",a:"m05",
 start:function(){b9Max(null)},fin:function(){b9Max(true)},
 html:"<p>To'rtta ifoda. Qaysi birining qiymati <b>eng katta</b>? Har birini bosib, qiymatini ko'ring:</p>",
 act:function(c,done){S.d5=function(){S.d5=null;done()}},
 after:"<p>Qiymatlari: 74, 73, 71, 72. Ular juda yaqin — taxmin bilan emas, <b>aniq hisoblab</b> taqqoslash kerak edi.</p>",
 q:{t:"Qaysi ifodaning qiymati eng kichik?",opts:["90 − 54","17 + 21","64 − 29","18 + 19"],ok:2,why:"36, 38, 35, 37 — eng kichigi 35.",hint:"Har birini hisoblab chiqing.",full:"90 − 54 = 36, 17 + 21 = 38, 64 − 29 = 35, 18 + 19 = 37. Eng kichigi 35 — 64 − 29."},
 tn:"Bolalar har ifodani kartochkaga yozib, qiymati bo'yicha qatorga tersin."},
{h:"Tuzoq: harfli ifodalar",sum:"d − 11 > d − 12 har doim to'g'ri: kamroq ayirilsa, ko'proq qoladi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Harf o'rnida <b>istalgan son</b> bo'lishi mumkin. «d − 11 > d − 12» har doim to'g'rimi? Hisoblay olmaymiz — fikrlaymiz!</p>",
 btns:[phaser(P6)],
 after:"<p>Harfli ifodalarni ham xuddi oldingi qoidalar bilan taqqoslaymiz: bir xil songa ko'proq qo'shilsa — katta; bir xil sondan ko'proq ayirilsa — kichik.</p>",
 q:{t:"Harflar o'rnida istalgan son bo'lishi mumkin. Qaysi yozuv har doim to'g'ri?",opts:["a + 14 > a + 25","d − 11 > d − 12","a − 3 > a","m + 0 < m − 0"],ok:1,why:"11 < 12: kamroq ayirildi — ko'proq qoldi.",hint:"Har birida qaysi tomonga ko'proq qo'shilgan yoki ayirilgan?",full:"a + 14 < a + 25 (kamroq qo'shilgan). a − 3 < a. m + 0 = m − 0. Faqat d − 11 > d − 12 har doim to'g'ri."},
 tn:"Harfni «sirli quti» deb tushuntiring: ichida qanday son bo'lsa ham, munosabat o'zgarmaydi."},
{h:"Tuzoq: teng ifodani toping",sum:"723 − (180 + 120) = 723 − 180 − 120: yig'indini ayirish — ketma-ket ayirish.",a:"m07",
 start:function(){bqExpr(['723 − (180 + 120)']);bqMsg('Qaysi ifoda bunga teng?')},fin:function(){bqExpr(['723 − (180 + 120)','= 723 − 180 − 120','= [423]'])},
 html:"<p>Qavsni ochganda nima bo'ladi? Tanlang:</p>",
 btns:[["723 − 180 + 120",function(c,done,b){flashBad(b);bqMsg('Yo‘q: 120 ni ham ayirish kerak, qo‘shish emas')}],["723 − 180 − 120",function(c,done,b){bqExpr(['723 − (180 + 120)','= 723 − 180 − 120','= [423]']);bqMsg('To‘g‘ri! Ikkala qismni ham ayiramiz');c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});done()}]],g2:1,
 after:"<p>Yig'indini ayirish — <b>har bir qo'shiluvchini ketma-ket ayirish</b>: 723 − (180 + 120) = 723 − 180 − 120 = 423. Qavs oldida «−» bo'lsa, ichidagi «+» ham ayirishga aylanadi.</p>",
 q:{t:"Qaysi ifodaning qiymati 723 − (180 + 120) ga teng?",opts:["723 − 180 + 120","723 + 120 − 180","723 − 180 − 120","723 + 180 − 120"],ok:2,why:"Ikkala qo'shiluvchi ham ayiriladi.",hint:"(180 + 120) — butun bir paket. Uni ayirsak, ikkala qismini ham ayiramiz.",full:"723 − (180 + 120) = 723 − 300 = 423. 723 − 180 − 120 = 423 ✓. Qolganlari: 663, 663, 783."},
 tn:"Bu — 2B12 «Sondan yig'indini ayirish» mavzusiga ko'prik."},
{h:"Bilasizmi? Eng qadimgi taqqoslash asbobi",sum:"Tarozi — taqqoslashning eng qadimgi asbobi: Misrda 4000 yildan ko'proq oldin ishlatilgan.",a:"m08",
 start:function(){bqScale(['46−9'],['18+18'],-1);bqMsg('Og‘ir tomon pastga tushadi: 37 > 36')},fin:function(){bqScale(['46−9'],['18+18'],-1);bqMsg('Og‘ir tomon pastga tushadi: 37 > 36')},
 html:"<p>⚖️ Taqqoslash belgilari paydo bo'lishidan ming yillar oldin odamlar <b>tarozi</b> bilan taqqoslagan. Qadimgi Misr devoriy rasmlarida tarozi 4000 yildan ko'proq oldin chizilgan. Tarozi qaysi tomonga og'ganini ko'ring:</p>",
 btns:[["⚖️ Ko'rdim",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Og'ir tomon pastga tushadi — bu «>» belgisining o'zi! Teng bo'lsa — tarozi to'g'ri turadi, xuddi «=» kabi. Bozorda ham hozirgacha tarozi shu qoida bilan ishlaydi.</p>",
 tn:"Sinfda tarozi bo'lsa, ikki xil miqdordagi kubiklarni qo'yib, belgini bolalar o'zi yozsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){b9Two('47 + 28','47 + 30','<')},fin:function(){b9Two('47 + 28','47 + 30','<')},
 html:"<div class='memo'><ul><li>Ifodalarning <b>qiymatlari</b> taqqoslanadi: avval hisoblang.</li><li>Qo'shishda: bir xil songa <b>ko'proq qo'shilsa — katta</b>: 47 + 28 < 47 + 30.</li><li>Ayirishda: bir xil sondan <b>ko'proq ayirilsa — kichik</b>: 80 − 19 > 80 − 21.</li><li>«Qanchaga katta?» — <b>ayirma</b> toping.</li><li>Harfli ifodalar: d − 11 > d − 12 har doim.</li><li>723 − (180 + 120) = 723 − 180 − 120.</li></ul></div>",
 tn:"Keyingi darsni «Hisoblamasdan: 99 + 45 ? 45 + 100» savoli bilan boshlang."}
];
function b9Max(show){clear();var g=S.g,L=[['100 − 26',74],['48 + 25',73],['90 − 19',71],['36 + 36',72]],seen=S.seen9=show?[0,1,2,3]:(S.seen9&&!show?[]:[]);
 L.forEach(function(it,i){var x=12+i*87,c=E('g',{style:'cursor:pointer'},g);var best=show&&i===0;var r=E('rect',{x:x,y:40,width:80,height:70,rx:10,fill:best?'#e6f6ee':'#fff',stroke:best?C.ok:'#c9d3dd','stroke-width':2},c);T(c,x+40,68,it[0],{'font-size':14,'font-weight':800});var vt=T(c,x+40,96,show?'= '+it[1]:'?',{'font-size':16,'font-weight':800,fill:C.blue});
  c.addEventListener('click',function(){vt.textContent='= '+it[1];if(seen.indexOf(i)<0)seen.push(i);if(seen.length===4){b9Max(true);bqMsg('Eng kattasi: <b>100 − 26 = 74</b>');if(S.d5)S.d5()}})});
 if(!show)bqMsg('Har bir kartochkani bosing');else bqMsg('Eng kattasi: <b>100 − 26 = 74</b>')}
var PROBS=[
{t:"Qaysi yozuv to'g'ri?",o:["28 + 7 > 50 − 16","46 − 9 < 18 + 18","63 − 28 > 17 + 19","24 + 19 = 52 − 8"],k:0,s:"35 > 34."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["100 − 26","48 + 25","90 − 19","36 + 36"],k:0,s:"74, 73, 71, 72."},
{t:"Qaysi ifodaning qiymati 56 − 19 ga teng?",o:["28 + 9","40 − 19","28 + 19","46 − 19"],k:0,s:"56 − 19 = 37 = 28 + 9."},
{t:"Ikki ifodani solishtiring: 47 + 28 ... 100 − 26",o:["47 + 28 > 100 − 26","47 + 28 < 100 − 26","47 + 28 = 100 − 26","100 − 26 > 75"],k:0,s:"75 > 74."},
{t:"Qaysi ifodaning qiymati eng kichik?",o:["64 − 29","90 − 54","17 + 21","18 + 19"],k:0,s:"35, 36, 38, 37."},
{t:"56 − 19 va 28 + 13 dan qaysi biri katta va qanchaga?",o:["ikkinchisi 4 ga","birinchisi 4 ga","ikkinchisi 14 ga","ular teng"],k:0,s:"37 va 41."},
{t:"Qaysi yozuv har doim to'g'ri (d — istalgan son)?",o:["d − 11 > d − 12","d + 14 > d + 25","d − 3 > d","d + 0 < d − 0"],k:0,s:"Kamroq ayirilsa — ko'proq qoladi."},
{t:"Qaysi yozuv to'g'ri?",o:["3 dm 7 sm = 37 sm","5 dm 2 sm > 52 sm","6 dm 4 sm < 46 sm","9 dm 1 sm < 9 dm"],k:0,s:"3 dm = 30 sm, 30 + 7 = 37 sm."},
{t:"Qaysi ifoda 723 − (180 + 120) ga teng?",o:["723 − 180 − 120","723 − 180 + 120","723 + 120 − 180","723 + 180 − 120"],k:0,s:"Yig'indini ayirish — ketma-ket ayirish."},
{t:"Hisoblamasdan belgi qo'ying: 35 + 19 ... 35 + 21",o:["<",">","="],k:0,s:"Kamroq qo'shilgan."},
{t:"Hisoblamasdan belgi qo'ying: 64 − 28 ... 64 − 30",o:[">","<","="],k:0,s:"Kamroq ayirilgan — ko'proq qolgan."},
{t:"Hisoblamasdan belgi qo'ying: 99 + 45 ... 45 + 100",o:["<",">","="],k:0,s:"99 < 100, qolgan qo'shiluvchi bir xil."},
{t:"Hisoblamasdan belgi qo'ying: 72 − 36 ... 70 − 36",o:[">","<","="],k:0,s:"Kattaroq sondan bir xil ayirildi."},
{t:"Hisoblamasdan belgi qo'ying: 38 + 47 ... 47 + 38",o:["=","<",">"],k:0,s:"Qo'shiluvchilar o'rni almashgan — teng."},
{t:"48 + 27 va 90 − 16 dan qaysi biri katta va qanchaga?",o:["birinchisi 1 ga","ikkinchisi 1 ga","birinchisi 11 ga","ular teng"],k:0,s:"75 va 74."},
{t:"□ o'rniga qaysi son qo'yilsa, 30 + □ > 30 + 15 to'g'ri bo'ladi?",o:["16","15","14","10"],k:0,s:"□ 15 dan katta bo'lishi kerak."},
{t:"□ o'rniga qaysi son qo'yilsa, 50 − □ > 50 − 20 to'g'ri bo'ladi?",o:["19","20","21","30"],k:0,s:"20 dan kamroq ayirish kerak."},
{t:"Qaysi yozuv noto'g'ri?",o:["40 − 18 > 40 − 15","29 + 6 > 29 + 5","60 − 7 < 60 − 3","25 + 30 = 30 + 25"],k:0,s:"22 < 25 — noto'g'ri."},
{t:"Qaysi ifodaning qiymati 50 ga eng yaqin?",o:["27 + 24","80 − 33","19 + 28","95 − 49"],k:0,s:"51, 47, 47, 46."},
{t:"a + 9 va a + 6 ifodalari qanchaga farq qiladi (a — istalgan son)?",o:["3 ga","15 ga","9 ga","farq qilmaydi"],k:0,s:"9 − 6 = 3."}
];
function PRACT_STAGE(){b9Two('47 + 28','47 + 30','<');bqMsg('Avval hisoblang yoki munosabatni ko‘ring')}
var PREP_DATA={teach:["Ifodalar qiymatini hisoblab taqqoslash.","Hisoblamasdan taqqoslash: qo'shishda va ayirishda.","«Qanchaga katta» — ayirma.","Harfli ifodalar; qavsni ochib teng ifoda topish."],
 mist:["Ayirishda teskari xulosa qiladi (80 − 19 < 80 − 21).","Qiymat o'rniga ifodadagi sonlarni solishtiradi.","«Qanchaga» savolida faqat belgini aytadi.","Qavs oldidagi «−» ni ichkariga o'tkazmaydi."],
 need:["Tarozi (bo'lsa), kubiklar.","Ifoda kartochkalari."],
 board:["<span class='w2'>46 − 9 ? 18 + 18 → 37 > 36</span>.","<span class='w2'>47 + 28 < 47 + 30</span>.","<span class='w2'>80 − 19 > 80 − 21</span>.","<span class='w2'>41 − 37 = 4</span> — qanchaga.","<span class='w2'>d − 11 > d − 12</span>.","<span class='w2'>723 − (180 + 120) = 723 − 180 − 120</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
