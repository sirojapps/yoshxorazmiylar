var CODE='4J20',TITLE="4-sinf · Shakl = son jumboqlari";
// shakllar jadvali: rows — [[shakllar...], yig'indi]; hl — ajratilgan qator
function q20Grid(rows,hl,vals){clear();var g=S.g,n=rows[0][0].length,cw=46,x0=180-((n+1)*cw)/2;rows.forEach(function(r,j){var y=22+j*46,on=hl===j;
 r[0].forEach(function(sh,i){E('rect',{x:x0+i*cw,y:y,width:cw-4,height:40,rx:8,fill:on?'#fff1df':'#fff',stroke:on?'#e07a2f':'#c9d3dd','stroke-width':2},g);T(g,x0+i*cw+cw/2-2,y+28,vals&&vals[sh]!=null?vals[sh]:sh,{'font-size':vals&&vals[sh]!=null?18:24,'font-weight':900,fill:vals&&vals[sh]!=null?C.ok:'#1f5f9e'})});
 T(g,x0+n*cw+6,y+28,'= '+r[1],{'font-size':18,'font-weight':900,fill:'#1d2b3a','text-anchor':'start'})})}
var R1=[[["○","○","○"],15],[["○","△","△"],13],[["△","□","□"],10]];
var P1=[function(){q20Grid(R1);j2Msg("Bir xil shakl — bir xil son. Qaysi qatordan boshlaymiz? Faqat <b>bitta</b> xil shakl bor qatordan!")},
 function(){q20Grid(R1,0,{"○":5});j2Msg("1-qator: ○ + ○ + ○ = 15 → ○ = <b>5</b>.")},
 function(){q20Grid(R1,1,{"○":5,"△":4});j2Msg("2-qator: 5 + △ + △ = 13 → △ + △ = 8 → △ = <b>4</b>.")},
 function(){q20Grid(R1,2,{"○":5,"△":4,"□":3});j2Msg("3-qator: 4 + □ + □ = 10 → □ = <b>3</b>. Zanjir: har topilgan son keyingisini ochadi.")}];
var R2=[[["★","★","●"],11],[["●","●","★"],13]];
var P2=[function(){q20Grid(R2);j2Msg("Bu safar hech qaysi qatorda bitta xil shakl yo'q. Nima qilamiz?")},
 function(){q20Grid(R2);j2Lines([["★★● + ●●★ = 11 + 13",null,17],["3★ + 3● = 24",C.blue,22],["★ + ● = 8",C.ok,24]],{y0:52});j2Msg("Hiyla: ikkala qatorni <b>qo'shamiz</b> — har shakl 3 tadan: 3 · (★ + ●) = 24 → ★ + ● = 8.")},
 function(){j2Lines([["★★● = ★ + (★ + ●) = ★ + 8 = 11",null,15],["★ = 3,  ● = 5",C.ok,24]]);j2Msg("Endi 1-qatordan bitta «★ + ●» juftni ajratamiz: ★ + 8 = 11 → ★ = 3, ● = 5.")}];
var P3=[function(){j2Lines([["2 ○ = 3 △",C.blue,22],["2 △ = 4 □",C.blue,22],["6 ○ = ? □",null,22]]);j2Msg("Almashtirish zanjiri: 6 ta doirani nechta kvadratga almashtirsa bo'ladi?")},
 function(){j2Lines([["6 ○ = 3 · (2 ○) = 3 · 3 △ = 9 △",null,17],["9 △ … 2 △ = 4 □ → 1 △ = 2 □",null,15],["9 △ = 18 □",C.ok,24]]);j2Msg("Bosqichma-bosqich: 6○ = 9△, 1△ = 2□ → 9△ = <b>18□</b>.")}];
var P5=[function(){j2Lines([["olma + nok = 7",null,18],["nok + behi = 9",null,18],["olma + behi = 8",null,18]]);j2Msg("Uchta meva narxi (ming so'm) juft-juft berilgan. Uchalasi birga qancha?")},
 function(){j2Lines([["hammasini qo'shamiz: 7 + 9 + 8 = 24",null,16],["har meva 2 marta → 2 · (O + N + B) = 24",C.blue,15],["O + N + B = 12",C.ok,24]]);j2Msg("Har meva ikki marta qo'shildi → yig'indini 2 ga bo'lamiz: <b>12</b>.")},
 function(){j2Lines([["behi = 12 − 7 = 5",null,17],["olma = 12 − 9 = 3",null,17],["nok = 12 − 8 = 4",null,17]]);j2Msg("Endi har birini topish oson: jamidan juftni ayiramiz.")}];
var STEPS=[
{h:"Zanjir: bittadan boshlaymiz",sum:"Bitta xil shakl bor qatordan boshlab: ○ = 5, △ = 4, □ = 3.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>3-sinfda ikki shaklli jumboqlarni yechdik. Endi uchta noma'lum. Asosiy savol — <b>qayerdan boshlash</b>?</p>",
 btns:[phaser(P1)],
 after:"<p>Qoida: avval <b>faqat bitta noma'lumli</b> tenglikni toping. Topilgan sonni boshqa tengliklarga qo'yib, zanjirni davom ettiring.</p>",
 q:{t:"□ + □ = 14, □ − ◇ = 2, ◇ · ○ = 15. ○ = ?",opts:["5","3","7","15"],ok:1,why:"□ = 7, ◇ = 5, ○ = 15 : 5 = 3.",hint:"Qaysi tenglikda faqat bitta shakl bor?",full:"□ + □ = 14 → □ = 7. 7 − ◇ = 2 → ◇ = 5. 5 · ○ = 15 → ○ = 3. «5» — ◇ ning qiymati."},
 tn:"Shakllarni rangli kartochkalarga chizib, qiymat topilganda ustiga son yopishtiring."},
{h:"Tuzoq: qatorlarni qo'shish",sum:"★★● = 11, ●●★ = 13: qo'shsak 3★ + 3● = 24 → ★ + ● = 8, ★ = 3, ● = 5.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ba'zan hech qaysi tenglikda bitta shakl qolmaydi. Unda tengliklarni <b>qo'shish</b> yoki <b>ayirish</b> yordam beradi.</p>",
 btns:[phaser(P2)],
 after:"<p>Qo'shganda har shakl bir xil sonda bo'lib qolsa — ularning yig'indisini topamiz. Ayirsak-chi? ●●★ − ★★● → ● − ★ = 2. Yig'indi 8, ayirma 2 → 5 va 3. Ikkala yo'l bir javob beradi!</p>",
 q:{t:"△ + △ + □ = 17 va △ + □ + □ = 19. △ + □ = ?",opts:["36","12","17","6"],ok:1,why:"Qo'shsak 3△ + 3□ = 36 → △ + □ = 12.",hint:"Ikkala tenglikni qo'shing. Har shakl necha marta?",full:"17 + 19 = 36, har shakl 3 marta: 3 · (△ + □) = 36 → 12. (△ = 5, □ = 7: 5 + 5 + 7 = 17 ✓, 5 + 7 + 7 = 19 ✓.) «36» — 3 ga bo'lishni unutgan."},
 tn:"Ikki qatorni bir-birining ustiga yozib, «ustun bo'yicha» qo'shishni ko'rsating."},
{h:"Almashtirish zanjiri",sum:"2○ = 3△, 2△ = 4□ → 6○ = 9△ = 18□.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Bozordagi ayirboshlash kabi: doiralarni uchburchaklarga, uchburchaklarni kvadratlarga almashtiramiz.</p>",
 btns:[phaser(P3)],
 after:"<p>Har bosqichda <b>bitta birlik</b>ka keltirish qulay: 1△ = 2□. Yoki guruhlab: 6○ = 3 guruh (2○) = 3 · 3△.</p>",
 q:{t:"3 ○ = 2 △, 1 △ = 3 □. 6 ○ nechta □ ga teng?",opts:["6","12","9","18"],ok:1,why:"6○ = 2 · (3○) = 4△ = 12□.",hint:"Avval 6○ ni △ ga almashtiring.",full:"6○ = 2 ta (3○) = 2 · 2△ = 4△. 1△ = 3□ → 4△ = 12□. «18» — 6 · 3 deb, uchburchak bosqichini tashlab ketgan."},
 tn:"Bozor o'yini: 2 ta olma = 3 ta konfet, 1 ta konfet = 2 ta qalam. 4 ta olma = ? qalam."},
{h:"Ko'paytma bilan jumboq",sum:"▲·▲ = 36 → ▲ = 6; ▲·■ = 30 → ■ = 5; ■ + ● = 9 → ● = 4.",a:"m04",
 start:function(){j2Lines([["▲ · ▲ = 36",C.blue,22],["▲ · ■ = 30",null,20],["■ + ● = 9",null,20]]);j2Msg("▲ nechaga teng? Tanlang.")},
 fin:function(){j2Lines([["▲ = 6",C.ok,22],["■ = 30 : 6 = 5",C.ok,20],["● = 9 − 5 = 4",C.ok,20]]);j2Msg("Zanjir: ▲ = 6, ■ = 5, ● = 4.")},
 html:"<p>Shakl o'zi bilan ko'paytirilsa — qaysi son o'zi bilan ko'paytirilganda 36 bo'ladi?</p>",
 btns:j2Pick(["18","6","9","4"],1,function(){j2Lines([["▲ = 6",C.ok,22],["■ = 30 : 6 = 5",C.ok,20],["● = 9 − 5 = 4",C.ok,20]]);j2Msg("To'g'ri! 6 · 6 = 36.")},function(i){j2Msg(["18 + 18 = 36, lekin bu ko'paytma emas!","","9 · 9 = 81.","4 · 4 = 16."][i])}),g2:1,
 after:"<p>Tuzoq: ▲ · ▲ ni ▲ + ▲ deb o'qish (18). Ko'paytma jadvalidan «kvadrat»larni eslang: 4 · 4 = 16, 5 · 5 = 25, 6 · 6 = 36…</p>",
 q:{t:"◆ · ◆ · ◆ = 64, ◆ · ⬟ = 20. ⬟ = ?",opts:["4","5","16","80"],ok:1,why:"4 · 4 · 4 = 64 → ◆ = 4, ⬟ = 20 : 4 = 5.",hint:"Qaysi son o'zi bilan uch marta ko'paytirilsa 64?",full:"4 · 4 = 16, 16 · 4 = 64 → ◆ = 4. 4 · ⬟ = 20 → ⬟ = 5."},
 tn:"Kvadrat sonlar jadvalini (1, 4, 9, …, 100) doskaga yozib qo'ying."},
{h:"Uchta juft yig'indi",sum:"O + N = 7, N + B = 9, O + B = 8: hammasi 24 = 2 · (O + N + B) → 12.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Hayotiy jumboq: do'kondor narxlarni juft-juft aytdi. Uchala mevani olsak qancha to'laymiz?</p>",
 btns:[phaser(P5)],
 after:"<p>Hammasini qo'shib, takrorlanish soniga bo'lish — juda kuchli usul. Har noma'lumni alohida topish shart emas!</p>",
 q:{t:"A + B = 10, B + C = 14, A + C = 12. B = ?",opts:["4","6","8","18"],ok:1,why:"A + B + C = 36 : 2 = 18; B = 18 − (A + C) = 18 − 12 = 6.",hint:"Avval uchalasining yig'indisini toping.",full:"10 + 14 + 12 = 36 = 2 · (A + B + C) → 18. B = 18 − 12 = 6. (A = 4, C = 8.)"},
 tn:"Uch bolaning bo'yini juft-juft o'lchab, har birini topish o'yinini o'ynating."},
{h:"Tuzoq: nol va bir",sum:"♦ − ♦ = 0 va ☾ : ☾ = 1 — shaklning qiymatidan qat'iy nazar.",a:"m06",
 start:function(){j2Lines([["♦ − ♦ = ●",C.blue,24],["♦ + ● = 7",null,20],["● · ♣ = ?",null,20]]);j2Msg("● nechaga teng? Diqqat: ♦ noma'lum bo'lsa ham javob aniq!")},
 fin:function(){j2Lines([["● = 0",C.ok,24],["♦ = 7",null,20],["0 · ♣ = 0",C.ok,22]]);j2Msg("Har qanday son o'zidan ayirilsa — 0. Nolga ko'paytma — 0, ♣ nima bo'lsa ham.")},
 html:"<p>Ba'zi jumboqlar noma'lumni bilmasdan ham yechiladi. ● ni toping.</p>",
 btns:j2Pick(["● = 7","● = 0","● = 1"],1,function(){j2Lines([["● = 0",C.ok,24],["♦ = 7",null,20],["0 · ♣ = 0",C.ok,22]]);j2Msg("To'g'ri! Son o'zidan ayirilsa — 0.")},function(i){j2Msg(i===0?"7 — bu ♦. ● = ♦ − ♦.":"1 — son o'ziga bo'linganda chiqadi, ayirganda emas.")}),
 after:"<p>Eslab qoling: a − a = 0, a : a = 1 (a ≠ 0), a · 0 = 0, a · 1 = a. Bu qonunlar har qanday son uchun ishlaydi.</p>",
 q:{t:"☾ : ☾ = ★, ☾ − ★ = 8. ☾ = ?",opts:["8","9","1","7"],ok:1,why:"★ = 1, ☾ = 8 + 1 = 9.",hint:"Son o'ziga bo'linsa nima chiqadi?",full:"☾ : ☾ = 1 → ★ = 1. ☾ − 1 = 8 → ☾ = 9."},
 tn:"Bolalar o'zi «noma'lumni bilmasdan yechiladigan» jumboq tuzsin."},
{h:"Bilasizmi? Diofant jumbog'i",sum:"Qadimgi yunon to'plamidagi jumboqqa ko'ra, Diofant 84 yil yashagan.",a:"m07",
 start:function(){j2Lines([["🏛️ Diofant",C.blue,24],["Iskandariya, III asr",null,16]]);j2Msg("«Arifmetika» muallifi")},fin:function(){j2Lines([["🏛️ Diofant",C.blue,24],["Iskandariya, III asr",null,16]]);j2Msg("«Arifmetika» muallifi")},
 html:"<p>🏛️ <b>Diofant</b> — Iskandariyalik matematik (taxminan III asr), «Arifmetika» kitobi muallifi. U noma'lumlarni maxsus belgilar bilan yozishni boshlaganlardan biri.</p><p>Qadimgi yunon jumboqlar to'plamida uning hayoti haqida jumboq bor: «Umrining oltidan biri bolalik, o'n ikkidan biri yigitlik, yettidan biri o'tgach uylandi…». Uni yechsangiz — 84 yil chiqadi.</p>",
 btns:[["🏛️ Qiziq!",function(c,done){done()}]],
 tn:"Kuchli o'quvchilarga: 84 ning 1/6, 1/12, 1/7 qismlarini topib, jumboqni tekshirish."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["bitta noma'lumdan boshla",C.blue,20]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["bitta noma'lumdan boshla",C.blue,20]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Bitta noma'lumli tenglikdan boshlang, keyin zanjir.</li><li>Bunday tenglik bo'lmasa — tengliklarni <b>qo'shing</b> yoki <b>ayiring</b>.</li><li>Almashtirish: bosqichma-bosqich, bir birlikka keltirib.</li><li>Juft yig'indilar: hammasini qo'shib, 2 ga bo'ling.</li><li>a − a = 0, a : a = 1, a · 0 = 0.</li><li>▲ · ▲ ≠ ▲ + ▲!</li></ul></div>",
 tn:"Uyga: o'z shakl-jumbog'ingizni tuzing va do'stingizga yechtiring."}
];
var PROBS=[
{t:"○ + ○ + ○ = 18, ○ + △ = 10. △ = ?",o:["4","6","10","8"],k:0,s:"○ = 6, △ = 4."},
{t:"○ + ○ + ○ = 18, ○ + △ = 10, △ + □ = 7. □ = ?",o:["3","4","6","7"],k:0,s:"○ = 6, △ = 4, □ = 3."},
{t:"□ + □ = 14, □ − ◇ = 2, ◇ · ○ = 15. ○ = ?",o:["3","5","7","15"],k:0,s:"□ = 7, ◇ = 5, ○ = 3."},
{t:"○○○ = 15, ○△△ = 13, △□□ = 10 (qatorlar yig'indisi). □ = ?",o:["3","4","5","10"],k:0,s:"○ = 5, △ = 4, □ = 3."},
{t:"★★● = 11, ●●★ = 13. ★ + ● = ?",o:["8","24","11","4"],k:0,s:"3★ + 3● = 24."},
{t:"★★● = 11, ●●★ = 13. ● = ?",o:["5","3","8","4"],k:0,s:"★ + ● = 8, ★ = 3, ● = 5."},
{t:"▲ · ▲ = 36, ▲ · ■ = 30, ■ + ● = 9. ● = ?",o:["4","5","6","9"],k:0,s:"▲ = 6, ■ = 5, ● = 4."},
{t:"◆ · ◆ · ◆ = 64, ◆ · ⬟ = 20. ⬟ = ?",o:["5","4","16","80"],k:0,s:"◆ = 4, ⬟ = 5."},
{t:"2 ○ = 3 △, 2 △ = 4 □. 6 ○ nechta □ ga teng?",o:["18","9","12","6"],k:0,s:"6○ = 9△ = 18□."},
{t:"3 ○ = 2 △, 1 △ = 3 □. 6 ○ nechta □ ga teng?",o:["12","6","9","18"],k:0,s:"6○ = 4△ = 12□."},
{t:"♦ − ♦ = ●, ♦ + ● = 7. ● · ♣ = ?",o:["0","7","1","49"],k:0,s:"● = 0, 0 · ♣ = 0."},
{t:"☾ : ☾ = ★, ☾ − ★ = 8. ☾ = ?",o:["9","8","1","7"],k:0,s:"★ = 1, ☾ = 9."},
{t:"A + B = 10, B + C = 14, A + C = 12. B = ?",o:["6","4","8","18"],k:0,s:"A + B + C = 18, B = 18 − 12."},
{t:"Olma + nok = 7, nok + behi = 9, olma + behi = 8 (ming so'm). Uchalasi birga?",o:["12 ming","24 ming","8 ming","16 ming"],k:0,s:"(7 + 9 + 8) : 2 = 12."},
{t:"○ + △ = 12, ○ − △ = 4. ○ = ?",o:["8","4","6","16"],k:0,s:"(12 + 4) : 2 = 8."},
{t:"□ · 4 = ○, ○ + □ = 25. □ = ?",o:["5","20","4","25"],k:0,s:"5□ = 25 → □ = 5."},
{t:"△ + △ + □ = 17, △ + □ + □ = 19. △ + □ = ?",o:["12","36","17","6"],k:0,s:"3 · (△ + □) = 36."},
{t:"● : 3 = ■, ■ + ● = 16. ● = ?",o:["12","4","3","16"],k:0,s:"● = 3■ → 4■ = 16 → ■ = 4, ● = 12."},
{t:"3 ta ○ va 2 ta △ yig'indisi 19, ○ = △ + 3. △ = ?",o:["2","5","3","4"],k:0,s:"3 · (△ + 3) + 2△ = 5△ + 9 = 19 → △ = 2."},
{t:"□□ — ikkala raqami bir xil ikki xonali son. □□ + □ = 36. □ = ?",o:["3","4","6","12"],k:0,s:"11□ + □ = 12□ = 36."}
];
function PRACT_STAGE(){q20Grid(R1)}
var PREP_DATA={teach:["Uch noma'lumli zanjir.","Tengliklarni qo'shish/ayirish.","Almashtirish zanjiri.","Juft yig'indilar va 0/1 xossalari."],
 mist:["▲ · ▲ ni ▲ + ▲ deb o'qiydi.","Qo'shgandan keyin 3 ga bo'lishni unutadi.","Almashtirishda oraliq bosqichni tashlab ketadi.","Juft yig'indilarni qo'shib, 2 ga bo'lmaydi."],
 need:["Shakllar chizilgan rangli kartochkalar, yopishqoq qog'oz.","Mevalar (yoki rasmlari)."],
 board:["<span class='w2'>○ = 5 → △ = 4 → □ = 3</span>.","<span class='w2'>3★ + 3● = 24</span>.","<span class='w2'>6○ = 9△ = 18□</span>.","<span class='w2'>(7 + 9 + 8) : 2 = 12</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
