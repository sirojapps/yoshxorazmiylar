var CODE='2H02',TITLE='2-sinf olimpiada · Shakl va rasmli qonuniyatlar';
// ---------- shakllar ----------
var H2C={c:'#5aa9e6',t:'#f0a040',s:'#1e8e5a',r:'#f08aa8',q:'#e05555',b:'#5aa9e6',y:'#f2c94c'};
function h2sh(p,k,x,y,s,col){s=s||11;var f=col||H2C[k]||'#999';
 if(k==='c'||k==='q'||k==='b'||k==='y')return E('circle',{cx:x,cy:y,r:s,fill:f,stroke:'rgba(0,0,0,.25)'},p);
 if(k==='t')return E('path',{d:'M'+x+' '+(y-s)+' L'+(x+s)+' '+(y+s*.8)+' L'+(x-s)+' '+(y+s*.8)+' Z',fill:f,stroke:'rgba(0,0,0,.25)'},p);
 if(k==='s')return E('rect',{x:x-s*.85,y:y-s*.85,width:s*1.7,height:s*1.7,rx:2,fill:f,stroke:'rgba(0,0,0,.25)'},p);
 if(k==='r')return E('path',{d:'M'+x+' '+(y-s)+' L'+(x+s)+' '+y+' L'+x+' '+(y+s)+' L'+(x-s)+' '+y+' Z',fill:f,stroke:'rgba(0,0,0,.25)'},p);
 if(k==='u'||k==='R'||k==='D'||k==='L'){var a={u:0,R:90,D:180,L:270}[k],g=E('g',{transform:'translate('+x+','+y+') rotate('+a+')'},p);E('path',{d:'M0 -'+s+' L'+(s*.8)+' 0 L'+(s*.3)+' 0 L'+(s*.3)+' '+s+' L-'+(s*.3)+' '+s+' L-'+(s*.3)+' 0 L-'+(s*.8)+' 0 Z',fill:'#5b6b7b'},g);return g}}
// qator: seq — kalitlar; o.q — noma'lum o'rinlar; o.box — blok uzunligi (ramka); o.num — o'rin raqamlari
function h2row(seq,o){o=o||{};clear();var g=S.g,n=seq.length,w=Math.min(30,340/n),x0=180-n*w/2,y=o.y||84;
 if(o.box)for(var b=0;b*o.box<n;b++){var bx=x0+b*o.box*w;E('rect',{x:bx+1,y:y-18,width:Math.min(o.box,n-b*o.box)*w-2,height:36,rx:8,fill:b%2?'#f1f5f9':'#fff8e8',stroke:'#c9d3dd'},g)}
 seq.forEach(function(k,i){var x=x0+i*w+w/2;if(o.q&&o.q.indexOf(i)>=0){E('rect',{x:x-11,y:y-11,width:22,height:22,rx:4,fill:'#fff',stroke:C.bad,'stroke-dasharray':'4 2','stroke-width':2},g);T(g,x,y+5,'?',{'font-size':14,'font-weight':800,fill:C.bad})}else h2sh(g,k,x,y,Math.min(11,w*.36));
  if(o.num)T(g,x,y+32,String(i+1),{'font-size':9,fill:'#5b6b7b'});if(o.hl&&o.hl.indexOf(i)>=0)E('circle',{cx:x,cy:y,r:Math.min(15,w*.5),fill:'none',stroke:C.hi,'stroke-width':3},g)});
 if(o.lab)T(g,180,156,o.lab,{'font-size':13,'font-weight':800,fill:C.blue})}
function h2msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function h2rep(base,n){var a=[];for(var i=0;i<n;i++)a.push(base[i%base.length]);return a}
var B3=['c','t','s'];
var P2=[function(){h2row(h2rep(B3,18),{num:1});h2msg('○ △ □ takrorlanadi. 18-o‘rinda qaysi shakl?')},
 function(){h2row(h2rep(B3,18),{num:1,box:3});h2msg('Har blokda 3 ta shakl. 18 : 3 = <b>6</b> ta to‘liq blok')},
 function(){h2row(h2rep(B3,18),{num:1,box:3,hl:[17]});h2msg('18 — blokning <b>oxirgi</b> shakli: <b>kvadrat</b>')}];
var B4=['s','c','s','t'];
var P6=[function(){h2row(h2rep(B4,15),{num:1});h2msg('□ ○ □ △ takrorlanadi. Dastlabki 15 tada nechta kvadrat?')},
 function(){h2row(h2rep(B4,15),{num:1,box:4});h2msg('Blok — 4 ta shakl, unda <b>2 ta</b> kvadrat. 15 = 3 blok (12) + 3 ta')},
 function(){var hl=[];h2rep(B4,15).forEach(function(k,i){if(k==='s')hl.push(i)});h2row(h2rep(B4,15),{num:1,box:4,hl:hl});h2msg('3 blok · 2 = 6, oxirgi 3 tada (□ ○ □) yana 2 ta → <b>8 ta</b>')}];
var P4=[function(){h2tow(1)},function(){h2tow(3)},function(){h2tow(5)}];
var STEPS=[
{h:"Takrorlanuvchi bo'lak",sum:"Naqshda takrorlanadigan eng qisqa bo'lak — blok: ○ △ □ | ○ △ □ …",a:"m01",
 start:function(){h2row(h2rep(B3,9).concat(['?','?']),{q:[9,10]});h2msg('Keyingi ikki shakl qaysi?')},fin:function(){h2row(h2rep(B3,11),{box:3,hl:[9,10]});h2msg('Blok: ○ △ □. Keyingilari: <b>○ △</b>')},
 html:"<p>Shakllar ma'lum tartibda takrorlanmoqda. Qonuniyatni topish uchun <b>takrorlanuvchi bo'lakni</b> (blokni) toping. Tugmani bosing.</p>",
 btns:[["🧩 Bloklarga ajrat",function(c,done){h2row(h2rep(B3,11),{box:3,hl:[9,10]});h2msg('Blok: ○ △ □ (3 ta shakl). Keyingilari: <b>○ va △</b>');done()}]],
 after:"<p>Blok — <b>○ △ □</b>, uzunligi 3. Har bir yangi blok xuddi shu tartibda boshlanadi. Shuning uchun keyingi ikki shakl: doira va uchburchak.</p>",
 q:{t:"△ ○ ○ △ ○ ○ △ … Keyingi shakl qaysi?",opts:["doira","uchburchak","kvadrat","romb"],ok:0,why:"Blok △ ○ ○: oxirgi blok △ dan boshlandi, keyin ○.",hint:"Blok nechta shakldan iborat? Oxirgi blokda qaysi shakllar bor?",full:"Blok — △ ○ ○ (3 ta). Qatorda 7 ta shakl: 2 ta to'liq blok va yana △. Keyingisi blokning 2-shakli — doira."},
 tn:"Bolalar munchoq yoki rangli kubiklardan o'z naqshini tuzib, bir-biriga topishmoq qilib bersin."},
{h:"Uzoqdagi o'rinni topish",sum:"18-o'rin: 18 : 3 = 6 (qoldiqsiz) → blokning oxirgi shakli. Qoldiq bo'lsa — qoldiq raqamidagi shakl.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>18-o'rindagi shaklni topish uchun hammasini chizish shart emas. Bloklar bilan hisoblaymiz.</p>",
 btns:[phaser(P2)],
 after:"<p>O'rin raqamini blok uzunligiga bo'lamiz: 18 : 3 = 6 — qoldiqsiz, demak blok <b>oxirgisi</b> (□). Agar 20-o'rin bo'lsa: 20 = 6 · 3 + 2 — qoldiq 2, blokning <b>2-shakli</b> (△).</p>",
 q:{t:"○ △ □ takrorlanadi. 20-o'rinda qaysi shakl turadi?",opts:["uchburchak","doira","kvadrat","romb"],ok:0,why:"20 = 6 · 3 + 2: qoldiq 2 → blokning 2-shakli △.",hint:"20 ni 3 ga bo'ling: nechta to'liq blok va nechta ortib qoladi?",full:"6 ta blok = 18 shakl. Yana 2 ta: ○ (19), △ (20). Javob: uchburchak. «Kvadrat» — 18-o'rin, qoldiq hisobga olinmagan."},
 tn:"«3 tadan sanash» — hali bo'lish o'tilmagan bo'lsa, bloklarni 3, 6, 9 … deb sanab boring."},
{h:"Dastlabki N tasida nechta?",sum:"Qizil, ko'k, ko'k, sariq: blokda 2 ko'k. 12 tada 3 blok → 6 ta ko'k.",a:"m03",
 start:function(){h2row(h2rep(['q','b','b','y'],12),{num:1});h2msg('Dastlabki 12 munchoqda nechta ko‘k?')},fin:function(){var s=h2rep(['q','b','b','y'],12),hl=[];s.forEach(function(k,i){if(k==='b')hl.push(i)});h2row(s,{num:1,box:4,hl:hl});h2msg('3 blok · 2 ko‘k = <b>6</b>')},
 html:"<p>Munchoqlar tartibi: <b>qizil, ko'k, ko'k, sariq</b>, va hokazo. Dastlabki 12 tasida nechta ko'k munchoq bor? Sanamasdan topamiz!</p>",
 btns:[["🧮 Bloklab hisobla",function(c,done){var s=h2rep(['q','b','b','y'],12),hl=[];s.forEach(function(k,i){if(k==='b')hl.push(i)});h2row(s,{num:1,box:4,hl:hl});h2msg('12 : 4 = 3 blok, har blokda 2 ko‘k → 3 · 2 = <b>6</b>');done()}]],
 after:"<p>Usul: 1) blokda nechta kerakli narsa borligini sanaymiz (2 ko'k); 2) nechta to'liq blok borligini topamiz (12 : 4 = 3); 3) ko'paytiramiz (3 · 2 = 6). Ortiqcha qism bo'lsa — uni alohida sanaymiz.</p>",
 q:{t:"Bayroqchalar: qizil, sariq, yashil, qizil, sariq, yashil, … Jami 14 ta. Yashil nechta?",opts:["4","5","6","3"],ok:0,why:"14 = 4 · 3 + 2: 4 blok — 4 yashil, ortgan 2 tasi (qizil, sariq) yashil emas.",hint:"14 tada nechta to'liq blok bor? Ortib qolganlar qaysi rangda?",full:"4 ta blok = 12 bayroqcha, 4 ta yashil. Ortgan 2 tasi: qizil, sariq. Yashil — 4 ta. «5» — ortgan qism ham yashil deb hisoblangan."},
 tn:"Bolalar avval chizib sanasin, keyin bloklab hisoblasin — ikkala javob mos kelishi kerak."},
{h:"O'suvchi naqsh",sum:"1, 2, 3, 4, 5 kubikli minoralar: jami 1 + 2 + 3 + 4 + 5 = 15.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ba'zi naqshlar takrorlanmaydi, balki <b>o'sib boradi</b>. Bolalar minoralar qurmoqda: 1-minora 1 kubik, 2-minora 2 kubik, … Dastlabki 5 minoraga nechta kubik ketadi?</p>",
 btns:[phaser(P4,'▶ Minora qo‘shish')],
 after:"<p>Har yangi minora bitta kubik ortiq. Jami: 1 + 2 + 3 + 4 + 5 = <b>15</b>. Tez qo'shish usuli: chetdagilarni juftlaymiz: (1 + 5) + (2 + 4) + 3 = 6 + 6 + 3 = 15.</p>",
 q:{t:"Nuqtalar uchburchak shaklida: 1-rasmda 1, 2-rasmda 3, 3-rasmda 6 nuqta. 4-rasmda nechta?",opts:["10","9","8","12"],ok:0,why:"Har rasmga yangi qator qo'shiladi: 6 + 4 = 10.",hint:"Har rasmda nechta nuqta qo'shilyapti? 1 → 3 (+2), 3 → 6 (+3) …",full:"Qo'shiladigan nuqtalar: +2, +3, keyin +4. 6 + 4 = 10. «9» — +3 takrorlangan, «12» — 6 · 2."},
 tn:"Kubiklardan haqiqiy «zinapoya» qurdiring — bolalar har bosqichda qo'shilganini ko'radi."},
{h:"Aylanuvchi shakl",sum:"Strelka har safar chorak aylanadi: ↑ → ↓ ← (blok 4). 10-o'rin: 10 = 2 · 4 + 2 → →.",a:"m05",
 start:function(){h2row(['u','R','D','L','u','R','?'],{q:[6],num:1});h2msg('Strelka qanday buriladi?')},fin:function(){h2row(h2rep(['u','R','D','L'],10),{num:1,box:4,hl:[9]});h2msg('10-o‘rin: 10 = 2 · 4 + 2 → <b>o‘ngga</b> (→)')},
 html:"<p>Strelka har qadamda soat mili bo'yicha <b>chorak aylanadi</b>: tepaga, o'ngga, pastga, chapga … 10-o'rinda qayerga qarab turadi?</p>",
 btns:[["🔁 10 tagacha davom ettir",function(c,done){h2row(h2rep(['u','R','D','L'],10),{num:1,box:4,hl:[9]});h2msg('Blok — 4 ta holat. 10 = 2 · 4 + 2 → 2-holat: <b>o‘ngga</b>');done()}]],
 after:"<p>To'rt marta chorak aylansa — strelka joyiga qaytadi. Demak blok uzunligi 4. 10-o'rin: 2 ta to'liq aylanish va yana 2 qadam — <b>o'ngga</b>.</p>",
 q:{t:"Strelka ↑ → ↓ ← tartibida aylanadi (1-o'rinda ↑). 13-o'rinda qayerga qaraydi?",opts:["tepaga","o'ngga","pastga","chapga"],ok:0,why:"13 = 3 · 4 + 1 → 1-holat: tepaga.",hint:"13 ni 4 ga bo'ling: qoldiq nechchi?",full:"3 ta to'liq aylanish = 12 qadam, 13-o'rin — yangi aylanishning 1-holati: tepaga."},
 tn:"Bolalar o'rnidan turib, har buyruqda chorak buriladi — tanasi bilan his qiladi."},
{h:"Tuzoq: blokda bir nechta bir xil shakl",sum:"□ ○ □ △: blokda 2 kvadrat. 15 ta = 3 blok + 3 → 6 + 2 = 8 kvadrat.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bank testidagi savol turi: <i>«Shakllar □ ○ □ △ tartibida takrorlanadi. Dastlabki 15 ta shakl ichida nechta kvadrat bor?»</i></p>",
 btns:[phaser(P6)],
 after:"<p>Ikki tuzoq bor: 1) blokda kvadrat <b>ikkita</b>; 2) 15 bloklarga to'liq bo'linmaydi — ortgan 3 ta shaklni (□ ○ □) <b>alohida</b> sanash kerak. 6 + 2 = 8.</p>",
 q:{t:"Mevalar: olma, nok, nok, olma, nok, nok, … Dastlabki 12 tada nechta nok?",opts:["8","6","4","9"],ok:0,why:"Blok olma, nok, nok — 2 nok. 12 : 3 = 4 blok → 8 nok.",hint:"Blokda nechta nok bor? 12 tada nechta blok?",full:"Blok (3 ta) — 2 nok. 12 : 3 = 4 blok. 4 · 2 = 8 nok. «6» — blokdagi 2 nok o'rniga 12 ning yarmi olingan."},
 tn:"Bu masala turi bank va olimpiada testlarida eng ko'p uchraydi. Bloklarni rangli ramkaga olishni o'rgating."},
{h:"Bilasizmi? O'zbek naqshlari",sum:"Samarqand va Buxoro binolaridagi girih naqshlari — takrorlanuvchi geometrik qonuniyatlar.",a:"m07",
 start:function(){h2girih()},fin:function(){h2girih()},
 html:"<p>🕌 Samarqanddagi Registon, Buxorodagi Minorai Kalon devorlaridagi naqshlarga diqqat bilan qarang: ular <b>takrorlanuvchi geometrik bloklardan</b> tuzilgan. Bunday naqshlar <b>girih</b> deyiladi.</p><p>⭐ Qadimgi ustalar chizg'ich va pargardan foydalanib, juda murakkab naqshlarni aniq qonuniyat asosida yaratishgan. Naqsh — bu rasmdagi matematika!</p>",
 tn:"Bolalar katakli qog'ozda o'z «girih» blokini chizib, uni 4 marta takrorlasin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h2row(h2rep(B3,9),{box:3});h2msg('Blokni toping!')},fin:function(){h2row(h2rep(B3,9),{box:3});h2msg('Blokni toping!')},
 html:"<div class='memo'><ul><li>Avval <b>blokni</b> — takrorlanadigan eng qisqa bo'lakni toping.</li><li>N-o'rin: N ni blok uzunligiga bo'ling. Qoldiq 0 — blokning oxirgisi; qoldiq k — blokning k-shakli.</li><li>Dastlabki N tasida nechta: blokdagi soni · bloklar soni + ortgan qismdagi soni.</li><li>Blokda bir xil shakl bir necha marta bo'lishi mumkin — sanab chiqing.</li><li>O'suvchi naqsh: har qadamda qancha qo'shilishini toping.</li><li>Aylanish: 4 ta chorak — to'liq aylanish.</li></ul></div>",
 tn:"Keyingi darsni «A B B C A B B C … 30-harf?» (30 = 7 · 4 + 2 → B) savoli bilan boshlang."}
];
function h2tow(n){clear();var g=S.g,s=14,base=150,tot=0;for(var i=1;i<=n;i++){var x=40+(i-1)*56;for(var k=0;k<i;k++)E('rect',{x:x,y:base-(k+1)*s,width:s*2,height:s-1,rx:2,fill:k===i-1?C.a:C.b,stroke:C.line},g);T(g,x+s,base+14,i+'-',{'font-size':11,'font-weight':700});tot+=i}
 h2msg(Array.from({length:n},function(_,i){return i+1}).join(' + ')+' = <b>'+tot+'</b> kubik')}
function h2girih(){clear('#f3f7ff');var g=S.g;for(var r=0;r<3;r++)for(var c=0;c<7;c++){var x=40+c*46,y=40+r*46;var st=E('path',{d:'M'+x+' '+(y-18)+' L'+(x+5)+' '+(y-5)+' L'+(x+18)+' '+y+' L'+(x+5)+' '+(y+5)+' L'+x+' '+(y+18)+' L'+(x-5)+' '+(y+5)+' L'+(x-18)+' '+y+' L'+(x-5)+' '+(y-5)+' Z',fill:(r+c)%2?'#1f6fb2':'#12a39f',stroke:'#fff','stroke-width':1.5},g)}
 h2msg('Bitta blok takrorlanib, butun devor naqshini hosil qiladi')}
var PROBS=[
{t:"○ △ □ takrorlanadi. 9-o'rinda qaysi shakl?",o:["kvadrat","doira","uchburchak","romb"],k:0,s:"9 : 3 = 3 — qoldiqsiz, blokning oxirgisi: kvadrat."},
{t:"○ △ □ takrorlanadi. 11-o'rinda qaysi shakl?",o:["uchburchak","doira","kvadrat","romb"],k:0,s:"11 = 3 · 3 + 2 → 2-shakl: uchburchak."},
{t:"A B C D takrorlanadi. 18-harf qaysi?",o:["B","A","C","D"],k:0,s:"18 = 4 · 4 + 2 → B."},
{t:"Qizil, ko'k, ko'k, sariq takrorlanadi. Dastlabki 12 tada nechta ko'k?",o:["6","4","3","8"],k:0,s:"12 : 4 = 3 blok · 2 = 6."},
{t:"□ ○ □ △ takrorlanadi. Dastlabki 15 tada nechta kvadrat?",o:["8","9","7","6"],k:0,s:"3 blok · 2 = 6, ortgan □ ○ □ da 2 → 8."},
{t:"Olma, nok, nok takrorlanadi. Dastlabki 12 tada nechta nok?",o:["8","6","4","9"],k:0,s:"4 blok · 2 = 8."},
{t:"Bayroqchalar qizil, sariq, yashil tartibda. 14 ta bayroqchada nechta qizil?",o:["5","4","6","3"],k:0,s:"4 blok (4 qizil) + ortgan qizil, sariq → 5."},
{t:"1, 2, 3, 4, 5 kubikli minoralar qurildi. Jami nechta kubik?",o:["15","10","5","20"],k:0,s:"1 + 2 + 3 + 4 + 5 = 15."},
{t:"Uchburchak nuqtalar: 1, 3, 6, 10, … 5-rasmda nechta nuqta?",o:["15","14","13","20"],k:0,s:"+2, +3, +4, +5: 10 + 5 = 15."},
{t:"Strelka ↑ → ↓ ← tartibida aylanadi. 7-o'rinda qayerga qaraydi?",o:["pastga","tepaga","o'ngga","chapga"],k:0,s:"7 = 4 + 3 → 3-holat: pastga."},
{t:"○ ○ △ ○ ○ △ … 20 ta shakldan nechtasi uchburchak?",o:["6","7","10","5"],k:0,s:"20 = 6 · 3 + 2: 6 blok — 6 △, ortgan ○ ○."},
{t:"Har bir rasmda kvadratlar soni: 1, 4, 9, 16 … 5-rasmda nechta kvadrat?",o:["25","20","24","32"],k:0,s:"1·1, 2·2, 3·3, 4·4 → 5·5 = 25."},
{t:"Gugurt cho'plaridan uchburchaklar qatori: 1 ta — 3 cho'p, 2 ta — 5, 3 ta — 7. 5 ta uchburchak uchun?",o:["11","15","10","9"],k:0,s:"Har yangi uchburchak +2: 7, 9, 11."},
{t:"Munchoqlar: 1 qizil, 2 ko'k, 1 qizil, 2 ko'k … 10-munchoq qaysi rangda?",o:["qizil","ko'k","sariq","yashil"],k:0,s:"Blok 3 ta: q, k, k. 10 = 3 · 3 + 1 → qizil."},
{t:"Dushanba, seshanba, … takrorlanadi. Dushanbadan boshlab 15-kun qaysi?",o:["dushanba","seshanba","yakshanba","chorshanba"],k:0,s:"15 = 2 · 7 + 1 → 1-kun: dushanba."},
{t:"A B B A B B … 30 ta harfda nechta B?",o:["20","10","15","18"],k:0,s:"30 : 3 = 10 blok · 2 = 20."},
{t:"Naqsh: katta doira, kichik doira, kichik doira. 13-doira qanday?",o:["katta","kichik","o'rta","juda kichik"],k:0,s:"13 = 4 · 3 + 1 → 1-shakl: katta."},
{t:"Har qatordagi stullar: 2, 4, 6, 8 … 6-qatorda nechta stul?",o:["12","10","14","16"],k:0,s:"Har qator +2: 6 · 2 = 12."},
{t:"○ △ □ ☆ takrorlanadi. 21-o'rindagi va 22-o'rindagi shakllar?",o:["○ va △","△ va □","□ va ☆","☆ va ○"],k:0,s:"21 = 5 · 4 + 1 → ○, 22 → △."},
{t:"Qizil, ko'k, sariq takrorlanadi. 50-munchoq qaysi rangda?",o:["ko'k","qizil","sariq","yashil"],k:0,s:"50 = 16 · 3 + 2 → 2-rang: ko'k."}
];
function PRACT_STAGE(){h2row(h2rep(B3,12),{box:3,num:1});h2msg('Blokni toping va o‘rinlarni hisoblang')}
var PREP_DATA={teach:["Takrorlanuvchi naqsh va uning bloki.","Uzoqdagi o'rinni bo'lish/qoldiq bilan topish.","Dastlabki N tasida sanash; blokda bir nechta bir xil element.","O'suvchi va aylanuvchi naqshlar."],
 mist:["Blokni noto'g'ri belgilaydi (qisqaroq yoki uzunroq).","Qoldiqni hisobga olmaydi (18 va 20-o'rinni aralashtiradi).","Blokda bir xil shakl ikki marta ekanini sezmaydi.","O'suvchi naqshda qo'shiluvchining ortishini sezmaydi."],
 need:["Rangli munchoqlar yoki kubiklar.","Katakli qog'oz va rangli qalamlar."],
 board:["<span class='w2'>○△□ | ○△□ | …</span> — blok 3.","18-o'rin: <span class='w2'>18 : 3 = 6</span> → oxirgisi.","20-o'rin: <span class='w2'>20 = 6·3 + 2</span> → 2-shakl.","12 munchoq: <span class='w2'>3 blok · 2</span>.","Minoralar: <span class='w2'>1+2+3+4+5 = 15</span>.","Strelka: ↑ → ↓ ← — blok 4."]};
