var CODE='3J05',TITLE="3-sinf · Sehrli kvadrat va sonli krossvordlar";
var J5M=[[8,1,6],[3,5,7],[4,9,2]];
function j5Sq(m,hl,o){o=o||{};var f={};(hl||[]).forEach(function(k){f[k]=o.hc||'#ffe9a8'});j3Tab(m,{cw:52,ch:44,fs:20,fill:f,col:o.col,y0:18})}
function j5Show(kind){var L={q:[['0,0','0,1','0,2'],['1,0','1,1','1,2'],['2,0','2,1','2,2']],u:[['0,0','1,0','2,0'],['0,1','1,1','2,1'],['0,2','1,2','2,2']],d:[['0,0','1,1','2,2'],['0,2','1,1','2,0']]}[kind];
 var all=[].concat.apply([],L);j5Sq(J5M,all);var t=L.map(function(l){return l.map(function(k){var p=k.split(',');return J5M[+p[0]][+p[1]]}).join(' + ')+' = 15'});j3Msg({q:'Qatorlar: ',u:'Ustunlar: ',d:'Diagonallar: '}[kind]+t.join(' · '))}
var P3=[function(){j5Sq([[2,7,'?'],['?',5,'?'],['?','?','?']]);j3Msg('Sehrli yig‘indi 15. Berilgan: 2, 7 va markazda 5')},
 function(){j5Sq([[2,7,6],['?',5,'?'],['?','?',8]],['0,2','2,2']);j3Msg('Yuqori qator: 15 − 2 − 7 = <b>6</b>. Diagonal: 15 − 2 − 5 = <b>8</b>')},
 function(){j5Sq([[2,7,6],['?',5,'?'],[4,'?',8]],['2,0']);j3Msg('Ikkinchi diagonal: 15 − 6 − 5 = <b>4</b>')},
 function(){j5Sq([[2,7,6],[9,5,1],[4,3,8]],['1,0','1,2','2,1']);j3Msg('Qolganlari: 15 − 2 − 4 = <b>9</b>, 15 − 6 − 8 = <b>1</b>, 15 − 4 − 8 = <b>3</b>. Tayyor!')}];
function j5Pyr(b,mid,top,o){o=o||{};clear();var g=S.g,w=62,h=36,y=130,x0=180-1.5*w;
 function br(x,y,v,col){E('rect',{x:x,y:y,width:w-2,height:h-2,rx:4,fill:col||'#fdf0dc',stroke:C.line,'stroke-width':1.4},g);T(g,x+w/2,y+h/2+5,String(v),{'font-size':v.length>5?12:16,'font-weight':800,fill:'#1d2b3a'})}
 b.forEach(function(v,i){br(x0+i*w,y-h,String(v))});mid.forEach(function(v,i){br(x0+w/2+i*w,y-2*h,String(v),'#fde6c8')});br(x0+w,y-3*h,String(top),'#ffe08a')}
var P5=[function(){j5Pyr(['3','x','5'],['?','?'],'20');j3Msg('Har g‘isht — ostidagi ikkitasining yig‘indisi. Tepada 20')},
 function(){j5Pyr(['3','x','5'],['3 + x','x + 5'],'20');j3Msg('O‘rta qator: 3 + x va x + 5')},
 function(){j5Pyr(['3','x','5'],['3 + x','x + 5'],'20');j3Msg('Tepa: 3 + x + x + 5 = 20 → 2x = 12 → <b>x = 6</b>')}];
var STEPS=[
{h:"Sehrli kvadratni tekshiramiz",sum:"Sehrli kvadrat: har qator, ustun va diagonal yig'indisi bir xil (1–9 da — 15).",a:"m01",
 start:function(){S.seen={};j5Sq(J5M);j3Msg('Qatorlar, ustunlar va diagonallarni tekshiring')},fin:function(){j5Show('d')},
 html:"<p>Bu — <b>sehrli kvadrat</b>. Unda 1 dan 9 gacha sonlar bor. Uchala tugmani bosib, yig'indilarni tekshiring.</p>",
 btns:[["Qatorlar",function(c,done){S.seen.q=1;j5Show('q');if(S.seen.q&&S.seen.u&&S.seen.d)done()}],["Ustunlar",function(c,done){S.seen.u=1;j5Show('u');if(S.seen.q&&S.seen.u&&S.seen.d)done()}],["Diagonallar",function(c,done){S.seen.d=1;j5Show('d');if(S.seen.q&&S.seen.u&&S.seen.d)done()}]],g3:1,
 after:"<p>3 ta qator, 3 ta ustun va 2 ta diagonal — 8 ta chiziqning hammasida yig'indi <b>15</b>. Bu son <b>sehrli yig'indi</b> deyiladi. Nega 15? 1 + 2 + … + 9 = 45, uchta qatorga teng bo'lingan: 45 : 3 = 15.</p>",
 q:{t:"1 dan 9 gacha sonlardan tuzilgan sehrli kvadratda markazda qaysi son turadi?",opts:["9","5","1","15"],ok:1,why:"Markaz — 1 dan 9 gacha sonlarning o'rtasi: 5.",hint:"Rasmdagi kvadratda markazda nima turibdi? Bu tasodifmi?",full:"Har qanday 1–9 sehrli kvadratda markazda 5 turadi. Markazdan 4 ta chiziq o'tadi; har bir juftlik markaz bilan 15 ni beradi: 1+9, 2+8, 3+7, 4+6 — har birining yig'indisi 10, demak markaz 15 − 10 = 5."},
 tn:"Bolalar kvadratni daftarga ko'chirib, 8 ta chiziqni turli rangda chizib chiqsin."},
{h:"Markaz qoidasi",sum:"3×3 sehrli kvadratda sehrli yig'indi = 3 × markaz. 2–10 sonlarda markaz 6, yig'indi 18.",a:"m02",
 start:function(){j5Sq([[9,2,7],[4,'?',8],[5,10,3]]);j3Msg('Sonlar 2 dan 10 gacha. Markazda qaysi son?')},fin:function(){j5Sq([[9,2,7],[4,6,8],[5,10,3]],['1,1']);j3Msg('Markaz 6, sehrli yig‘indi 3 · 6 = 18')},
 html:"<p>Bu kvadratda 2 dan 10 gacha sonlar. Markazdagi son qaysi? Tanlang:</p>",
 btns:j3Ch(["5","6","7","9"],1,function(){j5Sq([[9,2,7],[4,6,8],[5,10,3]],['1,1']);j3Msg('To‘g‘ri: 9 + 2 + 7 = 18, 4 + 6 + 8 = 18. Markaz 6')},function(i){return 'Bir qatorni qo‘shing: 9 + 2 + 7 = ? O‘rta qator ham shuncha bo‘lishi kerak'}),
 after:"<p>Qoida: 3 × 3 sehrli kvadratda <b>sehrli yig'indi = 3 × markaz</b>. Bu yerda 18 = 3 · 6. Markaz — barcha sonlarning o'rtasi.</p>",
 q:{t:"Sehrli yig'indisi 24 bo'lgan 3 × 3 sehrli kvadratda markazda qaysi son?",opts:["12","6","8","24"],ok:2,why:"24 : 3 = 8.",hint:"Sehrli yig'indi markazdan necha marta katta?",full:"Sehrli yig'indi = 3 × markaz, demak markaz = 24 : 3 = 8."},
 tn:"Qoidani bolalar o'zi kashf etsin: ikki xil kvadratda markazni yig'indi bilan solishtirsin."},
{h:"Bo'sh kataklarni to'ldiramiz",sum:"Avval ikki soni ma'lum chiziqdan boshlang: 15 − 2 − 7 = 6, keyin diagonallar, keyin qolganlari.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Faqat 3 ta son ma'lum. Qolgan 6 tasini topamiz. Qoida: har safar <b>faqat bitta</b> katagi bo'sh chiziqni toping.</p>",
 btns:[phaser(P3)],
 after:"<p>Kalit — <b>to'g'ri tartib</b>: ikki soni ma'lum chiziq → uchinchisini topamiz → yangi son boshqa chiziqni ochadi. Bu zanjir sudoku va krossvordlarda ham ishlaydi.</p>",
 q:{t:"Sehrli yig'indi 15. Bir qatorda 4 va 9 turibdi. Uchinchi son qaysi?",opts:["13","2","5","6"],ok:1,why:"15 − 4 − 9 = 2.",hint:"Uch son yig'indisi 15 bo'lishi kerak.",full:"4 + 9 = 13, 15 − 13 = 2."},
 tn:"Bolalarga bo'sh kvadrat berib, «qaysi katakdan boshlash mumkin?» deb so'rang — bu strategik fikrlash."},
{h:"Sonli krossvord",sum:"a + b = 9, a + c = 8, c + d = 7, a + d = 9 → a = 5, b = 4, c = 3, d = 4.",a:"m04",
 start:function(){j3Tab([['a','b','9'],['c','d','7'],['8','','']],{cw:56,ch:40,fs:20,fill:{'0,2':'#e8f1fb','1,2':'#e8f1fb','2,0':'#e8f1fb'}});j3Msg('Qatorlar: a + b = 9, c + d = 7. Ustun: a + c = 8. Diagonal: a + d = 9. a nechaga teng?')},fin:function(){j3Tab([[5,4,'9'],[3,4,'7'],['8','','']],{cw:56,ch:40,fs:20,fill:{'0,0':'#e6f6ee'}});j3Msg('a = 5, b = 4, c = 3, d = 4')},
 html:"<p>Kataklarga raqamlar yashiringan. Shartlar pastda. <b>a</b> qaysi son? Har variantni boshqa shartlarga qo'yib tekshiring.</p>",
 btns:j3Ch(["a = 4","a = 5","a = 6","a = 3"],1,function(){j3Tab([[5,4,'9'],[3,4,'7'],['8','','']],{cw:56,ch:40,fs:20,fill:{'0,0':'#e6f6ee'}});j3Msg('a = 5: b = 4, c = 3, d = 7 − 3 = 4, a + d = 9 ✓')},function(i){var a=[4,5,6,3][i],b=9-a,c=8-a,d=7-c;return 'a = '+a+' bo‘lsa: b = '+b+', c = '+c+', d = '+d+', a + d = '+(a+d)+' — 9 emas ✗'}),
 after:"<p>Usul: bitta harfni tanlab, qolganlarini <b>ketma-ket</b> hisoblaymiz va oxirgi shart bilan tekshiramiz. Mos kelmasa — boshqa qiymat. Bu «sinash va tekshirish» usuli.</p>",
 q:{t:"Ikki son: a + b = 10, a − b = 4. a nechaga teng?",opts:["6","7","3","14"],ok:1,why:"Yig'indi va ayirma: (10 + 4) : 2 = 7, b = 3.",hint:"Sinab ko'ring: a = 7 bo'lsa, b = 3. Ikkala shart bajariladimi?",full:"a + b = 10 va a − b = 4. Qo'shsak: 2a = 14, a = 7, b = 3. Tekshiramiz: 7 + 3 = 10, 7 − 3 = 4 ✓."},
 tn:"Kakuro va «sonli krossvord» — Yaponiyada mashhur jumboqlar. Sinfda 2 × 2 krossvordlarni bolalar bir-biriga tuzib bersin."},
{h:"Sonli piramida",sum:"Pastda 3, x, 5; tepada 20 → 3 + 2x + 5 = 20 → x = 6. O'rtadagi son ikki marta sanaladi!",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Piramidada har bir g'isht — ostidagi ikkita g'ishtning yig'indisi. Pastki o'rtadagi son noma'lum. Kuzating.</p>",
 btns:[phaser(P5)],
 after:"<p>Diqqat: pastki <b>o'rtadagi</b> son tepaga <b>ikki marta</b> boradi (chapga ham, o'ngga ham). Shuning uchun 3 + 5 + <b>2 · x</b> = 20.</p>",
 q:{t:"Piramida: pastda 2, x, 4; tepada 16. x nechaga teng?",opts:["10","5","6","4"],ok:1,why:"2 + 2x + 4 = 16 → 2x = 10 → x = 5.",hint:"O'rtadagi son tepaga necha marta qo'shiladi?",full:"O'rta qator: 2 + x va x + 4. Tepa: 2 + 2x + 4 = 16, 2x = 10, x = 5. «10» — x ni bir marta sanash xatosi."},
 tn:"Piramidani pastdan yuqoriga va yuqoridan pastga yechish — tenglama tuzishning eng oson kirish yo'li."},
{h:"Tuzoq: 1 qayerda turishi mumkin?",sum:"1–9 kvadratda 1 burchakda tura olmaydi: unda 3 ta chiziq uchun 14 ga teng 3 juft kerak, lekin faqat 2 ta bor (5+9, 6+8). 1 — tomon o'rtasida.",a:"m06",
 start:function(){j5Sq([['?','?','?'],['?',5,'?'],['?','?','?']]);j3Msg('1 sonini qayerga qo‘yish mumkin?')},fin:function(){j5Sq(J5M,['0,1'],{hc:'#e6f6ee'});j3Msg('1 — tomon o‘rtasida; juft sonlar — burchaklarda')},
 html:"<p>1–9 sehrli kvadratda <b>1</b> qayerda turishi mumkin: burchakdami, tomon o'rtasidami?</p>",
 btns:j3Ch(["Burchakda","Tomon o'rtasida","Markazda"],1,function(){j5Sq(J5M,['0,1'],{hc:'#e6f6ee'});j3Msg('To‘g‘ri! 1 dan 2 ta chiziq o‘tadi: 1 + 5 + 9 va 1 + 6 + 8')},function(i){return i===0?'Burchakdan 3 ta chiziq o‘tadi: har biriga 1 bilan 15 berish uchun yig‘indisi 14 bo‘lgan juft kerak. Bunday juftlar faqat 2 ta: 5 + 9 va 6 + 8 — yetmaydi!':'Markazda doim 5 turadi'}),
 after:"<p>Burchakdan <b>3 ta</b> chiziq o'tadi (qator, ustun, diagonal), tomon o'rtasidan — <b>2 ta</b>. 1 bilan 15 berish uchun qolgan ikki son yig'indisi 14 bo'lishi kerak: faqat 5 + 9 va 6 + 8. Ikkita juft — ikkita chiziq, demak 1 faqat tomon o'rtasida. Xuddi shunday 9 ham. Burchaklarda esa <b>juft sonlar</b> turadi.</p>",
 q:{t:"1–9 sehrli kvadratda juft sonlar (2, 4, 6, 8) qayerda turadi?",opts:["Burchaklarda","Tomon o'rtalarida","Markazda","Bitta qatorda"],ok:0,why:"Toq sonlar (1, 3, 7, 9) tomon o'rtalarida, juftlar burchaklarda, 5 markazda.",hint:"Namunaga qarang: 8, 6, 4, 2 qayerda?",full:"8 1 6 / 3 5 7 / 4 9 2 kvadratida juftlar 8, 6, 4, 2 — to'rttala burchakda. Bu har qanday 1–9 sehrli kvadratda shunday."},
 tn:"Bu — isbotlash elementi: «nega boshqacha bo'lmaydi?» deb so'rash. Kuchli bolalar uchun ajoyib bahs mavzusi."},
{h:"Bilasizmi? Sudoku va Lo Shu",sum:"Lo Shu — eng qadimgi sehrli kvadrat (Xitoy). Zamonaviy sudoku 1979-yilda AQShda paydo bo'lgan, «sudoku» nomini 1984-yilda Yaponiya bergan.",a:"m07",
 start:function(){j5Sq(J5M);j3Msg('Lo Shu: 4 9 2 / 3 5 7 / 8 1 6 — xuddi shu kvadratning aks ko‘rinishi')},fin:function(){j5Sq(J5M);j3Msg('Lo Shu: eng qadimgi sehrli kvadrat')},
 html:"<p>🐢 Xitoy afsonasiga ko'ra, eng qadimgi sehrli kvadrat — <b>Lo Shu</b> — toshbaqa kosasida ko'ringan. U aynan 1–9 sonlardan tuzilgan, sehrli yig'indisi 15.</p><p>🧩 Bugun dunyo bo'ylab mashhur <b>sudoku</b> 1979-yilda AQSh jurnalida «Number Place» nomi bilan chiqqan. «Sudoku» (yaponcha «yolg'iz raqam») nomini unga 1984-yilda Yaponiyadagi Nikoli jurnali bergan.</p>",
 tn:"4 × 4 sudoku (1–4 raqamlar) bilan boshlang — 3-sinf bolasi 5 daqiqada yechadi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j5Sq(J5M)},fin:function(){j5Sq(J5M)},
 html:"<div class='memo'><ul><li>Sehrli kvadrat: qator, ustun, diagonal yig'indisi bir xil.</li><li>1–9: yig'indi <b>15</b> (45 : 3), markaz <b>5</b>.</li><li>3 × 3 da: <b>sehrli yig'indi = 3 × markaz</b>.</li><li>To'ldirish: avval faqat bitta katagi bo'sh chiziqni toping.</li><li>Krossvord: bir harfni sinab, qolganlarini hisoblang, oxirgi shart bilan tekshiring.</li><li>Piramida: pastki o'rtadagi son tepaga <b>2 marta</b> qo'shiladi.</li><li>1–9 kvadratda: juftlar — burchaklarda, toqlar — tomon o'rtalarida.</li></ul></div>",
 tn:"Keyingi darsni «3 dan 11 gacha sonlardan sehrli kvadrat tuzing» (markaz 7, yig'indi 21) topshirig'i bilan boshlang."}
];
var PROBS=[
{t:"1 dan 9 gacha sonlardan tuzilgan sehrli kvadratning sehrli yig'indisi qancha?",o:["15","45","18","9"],k:0,s:"1 + 2 + … + 9 = 45, 45 : 3 = 15."},
{t:"2 dan 10 gacha sonlardan tuzilgan sehrli kvadratda markazda qaysi son?",o:["6","5","9","18"],k:0,s:"Yig'indi 54 : 3 = 18, markaz 18 : 3 = 6."},
{t:"Sehrli yig'indi 30 bo'lgan 3 × 3 kvadratda markaz qaysi son?",o:["10","15","30","5"],k:0,s:"30 : 3 = 10."},
{t:"Markazda 7 turgan 3 × 3 sehrli kvadratning sehrli yig'indisi?",o:["21","14","7","28"],k:0,s:"3 · 7 = 21."},
{t:"Sehrli kvadratda (yig'indi 15) bir qatorda 8 va 1 bor. Uchinchi son?",o:["6","7","9","5"],k:0,s:"15 − 8 − 1 = 6."},
{t:"Diagonalda 2 va markazda 5 turibdi (yig'indi 15). Diagonalning uchinchi soni?",o:["8","7","3","10"],k:0,s:"15 − 2 − 5 = 8."},
{t:"Piramidaning pastida 4, 6, 3. Tepada qaysi son?",o:["19","13","10","20"],k:0,s:"O'rta qator: 10 va 9. Tepa: 19."},
{t:"Piramida: pastda 2, x, 7; tepada 25. x nechaga teng?",o:["8","9","16","7"],k:0,s:"2 + 2x + 7 = 25 → 2x = 16 → x = 8."},
{t:"To'rt qavatli piramida: pastda 1, 2, 3, 4. Tepada qaysi son?",o:["20","10","16","24"],k:0,s:"3, 5, 7 → 8, 12 → 20."},
{t:"1–9 sehrli kvadratda 1 qaysi katakda turadi?",o:["Tomon o'rtasida","Burchakda","Markazda","Istalgan joyda"],k:0,s:"Burchakdan 3 chiziq o'tadi, 14 ga teng juft esa faqat 2 ta — 1 tomon o'rtasida."},
{t:"1–9 sehrli kvadratning burchaklarida qanday sonlar turadi?",o:["Juft sonlar","Toq sonlar","Faqat 1 va 9","5 dan kattalar"],k:0,s:"Burchaklarda 2, 4, 6, 8."},
{t:"Sehrli kvadrat: 4 9 2 / 3 5 7 / 8 1 6. O'rta ustun yig'indisi?",o:["15","14","16","13"],k:0,s:"9 + 5 + 1 = 15."},
{t:"1–9 sehrli kvadratning har katagiga 2 qo'shildi. Yangi sehrli yig'indi?",o:["21","17","15","30"],k:0,s:"Har chiziqda 3 ta katak: 15 + 3 · 2 = 21."},
{t:"1–9 sehrli kvadratning har katagidagi son 2 ga ko'paytirildi. Yangi sehrli yig'indi?",o:["30","17","15","45"],k:0,s:"15 · 2 = 30."},
{t:"Ikki son: yig'indisi 13, ayirmasi 5. Kattasi?",o:["9","8","4","13"],k:0,s:"(13 + 5) : 2 = 9, kichigi 4."},
{t:"Ikki sonning yig'indisi 20, ko'paytmasi 96. Kattasi?",o:["12","16","10","8"],k:0,s:"12 + 8 = 20, 12 · 8 = 96."},
{t:"3 × 3 jadvalning qator yig'indilari 10, 12 va 14. Jadvaldagi hamma sonlar yig'indisi?",o:["36","14","12","24"],k:0,s:"10 + 12 + 14 = 36."},
{t:"3 × 3 sehrli kvadratdagi 9 ta son yig'indisi 72. Sehrli yig'indi?",o:["24","72","8","36"],k:0,s:"72 : 3 = 24."},
{t:"△ + △ + ○ = 13 va △ + ○ = 8. △ nechaga teng?",o:["5","3","8","4"],k:0,s:"Birinchidan ikkinchisini ayiramiz: △ = 13 − 8 = 5."},
{t:"Piramidaning tepasida 30, uning ostida 14 va ?. Noma'lum son?",o:["16","44","15","14"],k:0,s:"30 − 14 = 16."}
];
function PRACT_STAGE(){j5Sq(J5M)}
var PREP_DATA={teach:["Sehrli kvadrat va sehrli yig'indi; markaz qoidasi (3 × markaz).","Bo'sh kataklarni to'g'ri tartibda to'ldirish.","Sonli krossvord va piramida: sinash, tekshirish, tenglama.","Nega 1 burchakda tura olmaydi — isbot elementi."],
 mist:["Bir chiziqni tekshirib, «sehrli» deb qaror qiladi.","Piramidada o'rtadagi sonni bir marta sanaydi.","Kataklarni tasodifiy tartibda to'ldirishga urinadi."],
 need:["Raqamli kartochkalar (1–9).","Bo'sh 3 × 3 to'rlar chizilgan varaq."],
 board:["<span class='w2'>8 1 6 / 3 5 7 / 4 9 2</span>, yig'indi 15.","<span class='w2'>yig'indi = 3 × markaz</span>.","Piramida: <span class='w2'>3 + 2x + 5 = 20</span>.","1 — tomon o'rtasida, juftlar — burchakda."]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
