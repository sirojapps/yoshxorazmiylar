var CODE='2C6',TITLE='2-sinf · Ko‘paytirishning o‘rin almashtirish xossasi';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P3=[function(){c6Chain(['4','·','5','·','2'],null);cMsg('4 · 5 · 2 — qaysi tartibda qulay?')},
 function(){c6Chain(['4','·','(5 · 2)'],[2]);cMsg('5 · 2 = <b>10</b> — o‘nlik chiqdi!')},
 function(){c6Chain(['4','·','10','=','40'],[4]);cMsg('4 · 10 = <b>40</b>. Tartibni almashtirib, oson hisobladik')}];
var STEPS=[
{h:"Massivni buramiz",sum:"3 qator 5 tadan = 5 qator 3 tadan = 15. 5 · 3 = 3 · 5.",a:"m01",
 start:function(){S.rot=0;cArr(3,5,{rowLab:1});cMsg('3 qator, 5 tadan: 5 · 3 = 15')},fin:function(){cArr(5,3,{rowLab:1});cMsg('5 · 3 = 3 · 5 = 15')},
 html:"<p>Nuqtalar 3 qatorda, har qatorda 5 tadan. Rasmni <b>burib</b> ko'ring — nuqtalar soni o'zgaradimi?</p>",
 btns:[["↻ Burish",function(c,done){S.rot=!S.rot;if(S.rot){cArr(5,3,{rowLab:1,col:C.a});cMsg('5 qator, 3 tadan: 3 · 5 = <b>15</b>')}else{cArr(3,5,{rowLab:1});cMsg('3 qator, 5 tadan: 5 · 3 = <b>15</b>')}mvK(done,2)}]],
 after:"<p>Burganda nuqtalar qo'shilmadi ham, kamaymadi ham — 15 ta. Demak <b>5 · 3 = 3 · 5</b>. Bu — <b>o'rin almashtirish xossasi</b>: ko'paytuvchilar o'rnini almashtirsak, ko'paytma o'zgarmaydi.</p>",
 q:{t:"Aziz bankalarni 4 tadan 6 qator, Amir esa 6 tadan 4 qator qilib terdi. Kimda bankalar ko'p?",opts:["Aziz","Amir","Amirda 2 ta ko'p","Teng"],ok:3,why:"4 · 6 = 6 · 4 = 24.",hint:"Ikkalasining ko'paytmasini yozing. O'rni almashgan, xolos.",full:"Aziz: 4 · 6 = 24, Amir: 6 · 4 = 24. Teng. Ko'paytuvchilar o'rni almashsa, ko'paytma o'zgarmaydi."},
 tn:"Qog'ozga massiv chizib, bolalar uni burib ko'rsin. Bu xossa ko'paytirish jadvalini yod olishni ikki barobar osonlashtiradi."},
{h:"Qulay tartibni tanlaymiz",sum:"2 · 9 qiyinmi? 9 · 2 = 9 + 9 = 18. Qulay tartibda hisoblang.",a:"m02",
 start:function(){cPlates(9,2,{lab:1});cMsg('2 · 9 = 2 + 2 + … (9 marta)')},fin:function(){cPlates(2,9,{lab:1});cMsg('9 · 2 = 9 + 9 = 18 — qisqaroq!')},
 html:"<p><b>2 · 9</b> ni hisoblash uchun 2 ni 9 marta qo'shish kerak. Yoki 9 ni 2 marta? Qaysi qulayroq — tanlang:</p>",
 btns:[["2 ni 9 marta",function(c){cPlates(9,2,{lab:1});cMsg('2 + 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2 = 18 — uzun!')}],["9 ni 2 marta",function(c,done){cPlates(2,9,{lab:1});cMsg('9 + 9 = <b>18</b> — tez!');done()}]],g2:1,
 after:"<p>Javob bir xil — 18, lekin <b>9 + 9</b> ancha tez. Hisoblashda doim qulay tartibni tanlang: 2 · 8 o'rniga 8 · 2, 1 · 7 o'rniga 7 · 1.</p>",
 q:{t:"3 · 5 + 5 · 3 = 5 · □ tenglikda □ o'rniga qaysi son yoziladi?",opts:["5","15","6","3"],ok:2,why:"3 · 5 = 5 · 3, demak 5 · 3 + 5 · 3 = 5 · 6.",hint:"3 · 5 ni 5 · 3 deb yozing. Endi nechta uchlik — beshlik?",full:"3 · 5 = 5 · 3. Demak 5 · 3 + 5 · 3 — bu 5 ning 3 ta va yana 3 tasi, ya'ni 5 · 6 = 30. «3» — faqat bitta qismni ko'rish."},
 tn:"Bolalardan «qaysi tartib qulayroq?» deb so'rang va sababini aytdirish — Yaponiya darslarining asosiy usuli."},
{h:"Uch son: o'nlik yasaymiz",sum:"4 · 5 · 2 = 4 · (5 · 2) = 4 · 10 = 40. Avval 10 chiqadigan juftni ko'paytiring.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Uchta son ko'paytirilsa ham, tartibni o'zgartirish mumkin. <b>4 · 5 · 2</b> ni eng qulay yo'l bilan hisoblaymiz:</p>",
 btns:[phaser(P3)],
 after:"<p>Ayyorlik: <b>5 · 2 = 10</b> va <b>2 · 5 = 10</b>. 10 ga ko'paytirish esa juda oson. Shuning uchun avval 5 va 2 ni juftlang.</p>",
 q:{t:"4 · 5 · 2 = 2 · 5 · □ tenglikda □ o'rniga qaysi son yoziladi?",opts:["8","4","40","10"],ok:1,why:"Xuddi shu uchta son: 4, 5, 2.",hint:"Chapda qaysi sonlar bor? O'ngda qaysi biri yetishmaydi?",full:"Chapda 4, 5, 2. O'ngda 2 va 5 bor — yetishmagani 4. Tartib boshqa, sonlar o'sha. «40» — ko'paytmani yozib qo'yish xatosi."},
 tn:"«5 · 2 = 10» juftini bolalar «sehrli juft» deb eslasin."},
{h:"Jadvalning yarmi tayyor",sum:"3 · 7 ni bilsangiz, 7 · 3 ni ham bilasiz. Ko'paytirish jadvali deyarli ikki barobar qisqaradi.",a:"m04",
 start:function(){c6Grid(0,0)},fin:function(){c6Grid(3,7)},
 html:"<p>Ko'paytirish jadvalidan istalgan katakni bosing — uning «egizagi» ham yonadi:</p>",
 act:function(c,done){S.tp=0;S.onCell=function(){if(++S.tp===3)done()};c.querySelector('.hint').textContent='Jadvaldagi katakni bosing.'},
 after:"<p>Har bir katakning egizagi bor: 3 · 7 va 7 · 3, 4 · 9 va 9 · 4. Shuning uchun 81 ta katakning yarmidan ko'pini <b>bilish shart emas</b> — egizagini bilsangiz bas!</p>",
 q:{t:"8 · 3 = 24 ekanini bilsak, qaysi ko'paytmani ham bilamiz?",opts:["8 · 4","3 · 8","24 · 3","3 + 8"],ok:1,why:"3 · 8 = 8 · 3 = 24.",hint:"Qaysi ko'paytmada xuddi shu sonlar, faqat o'rni almashgan?",full:"8 · 3 ning egizagi — 3 · 8, u ham 24. «8 · 4» — boshqa son, «24 · 3» — boshqa amal."},
 tn:"Bo'sh ko'paytirish jadvalini tarqating: bolalar bilgan kataklarini va ularning egizaklarini bo'yasin."},
{h:"Tuzoq: qaysi biri teng emas?",sum:"6 · 4 = 24: 4 · 6, 3 · 8, 2 · 12 ham 24; 3 · 9 = 27 — teng emas.",a:"m05",
 start:function(){cArr(4,6,{rowLab:1});cMsg('6 · 4 = 24')},fin:function(){cArr(3,8,{rowLab:1});cMsg('3 · 8 = 24 — boshqa sonlar, lekin o‘sha ko‘paytma')},
 html:"<p>Bir xil ko'paytma <b>har xil</b> sonlardan ham chiqishi mumkin! 24 ta nuqtani har xil qatorlab tering:</p>",
 btns:[["4 × 6",function(c,done){cArr(4,6,{rowLab:1});cMsg('6 · 4 = <b>24</b>');mvK(done,3)}],["3 × 8",function(c,done){cArr(3,8,{rowLab:1});cMsg('8 · 3 = <b>24</b>');mvK(done,3)}],["2 × 12",function(c,done){cArr(2,12,{rowLab:1});cMsg('12 · 2 = <b>24</b>');mvK(done,3)}],["3 × 9",function(c,done){cArr(3,9,{rowLab:1,col:C.bad});cMsg('9 · 3 = <b>27</b> — 24 emas!');mvK(done,3)}]],g2:1,
 after:"<p>24 = 6 · 4 = 4 · 6 = 3 · 8 = 2 · 12. Lekin <b>3 · 9 = 27</b>. Testda «qaysi biri teng emas?» desa — har birini hisoblab chiqing.</p>",
 q:{t:"Qaysi ko'paytma 6 · 4 ga teng EMAS?",opts:["3 · 9","4 · 6","3 · 8","2 · 12"],ok:0,why:"3 · 9 = 27, qolganlari 24.",hint:"Har birini hisoblang. 24 dan farq qiladigani qaysi?",full:"4 · 6 = 24, 3 · 8 = 24, 2 · 12 = 24. Faqat 3 · 9 = 27 — teng emas."},
 tn:"«Bitta sonni necha xil ko'paytma qilib yozish mumkin?» — 12, 18, 24 bilan o'yin qiling."},
{h:"Tuzoq: jadvalni burish",sum:"3 qator 7 ustunli jadvalni bursak — 7 qator 3 ustun. Kataklar soni o'zgarmaydi: 21.",a:"m06",
 start:function(){c6Table(3,7)},fin:function(){c6Table(7,3)},
 html:"<p>Jadval 3 qator va 7 ustundan iborat. Uni burib qo'ysak, 7 qator va 3 ustun bo'ladi. Kataklar soni o'zgaradimi?</p>",
 btns:[["↻ Jadvalni burish",function(c,done){S.rot=!S.rot;if(S.rot)c6Table(7,3);else c6Table(3,7);mvK(done,2)}]],
 after:"<p>Kataklar o'sha-o'sha — <b>21 ta</b>. Burish — o'rin almashtirishning rasmi: 7 · 3 = 3 · 7.</p>",
 q:{t:"Jadval 3 qator va 7 ustundan iborat. Uni burib qo'ysak, kataklar soni qanday o'zgaradi?",opts:["4 ta ko'payadi","4 ta kamayadi","Ikki baravar oshadi","O'zgarmaydi"],ok:3,why:"3 · 7 = 7 · 3 = 21.",hint:"Burganda biror katak qo'shiladimi yoki yo'qoladimi?",full:"Kataklar: 3 · 7 = 21, burilgandan keyin 7 · 3 = 21. O'zgarmaydi. «4 ta ko'payadi» — 7 − 3 farqini o'ylash xatosi."},
 tn:"Shaxmat taxtasi yoki daftar katagi bilan ko'rsating."},
{h:"Bilasizmi? Xossaning nomi",sum:"O'rin almashtirish xossasi lotincha «kommutativlik» deyiladi; atamani 1814-yilda fransuz olimi Servua kiritgan.",a:"m07",
 start:function(){clear('#f6ead0');T(S.g,180,80,'a · b = b · a',{'font-size':34,'font-weight':800,fill:'#6b3d12'});T(S.g,180,125,'kommutativlik — «o‘rin almashish»',{'font-size':13,fill:'#6b3d12'});cMsg('Xossaning olimlar tilidagi nomi')},fin:function(){STEPS[6].start()},
 html:"<p>📜 Bu xossani odamlar ming yillar davomida ishlatgan, lekin uning ilmiy nomi — <b>«kommutativlik»</b> (lotincha «o'rin almashish») — 1814-yilda fransuz matematigi <b>Fransua Servua</b> tomonidan kiritilgan.</p><p>Qiziq: hamma amallar ham shunday emas! <b>5 − 3 ≠ 3 − 5</b>, <b>6 : 2 ≠ 2 : 6</b>. Faqat qo'shish va ko'paytirishda o'rin almashtirish mumkin.</p>",
 tn:"Ayirish va bo'lishda o'rin almashtirib bo'lmasligini kontrmisol bilan ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){cArr(3,5,{rowLab:1});cMsg('5 · 3 = 3 · 5')},fin:function(){STEPS[7].start()},
 html:"<div class='memo'><ul><li><b>a · b = b · a</b>: ko'paytuvchilar o'rnini almashtirsak, ko'paytma o'zgarmaydi.</li><li>Rasmi — massivni burish: 3 qator 5 tadan = 5 qator 3 tadan.</li><li>Qulay tartibni tanlang: 2 · 9 → 9 + 9 = 18.</li><li>Uch son: avval 10 chiqadigan juftni — 4 · 5 · 2 = 4 · 10 = 40.</li><li>Jadvalda har katakning egizagi bor: 3 · 7 = 7 · 3.</li><li>Ayirish va bo'lishda o'rin almashtirib <b>bo'lmaydi</b>: 5 − 3 ≠ 3 − 5.</li></ul></div>",
 tn:"Keyingi darsni «5 · 7 · 2 ni og'zaki hisoblang» (70) savoli bilan boshlang."}
];
function c6Chain(parts,hl){clear();var n=parts.length,w=Math.min(70,320/n),x0=180-(n-1)*w/2;parts.forEach(function(p,i){var on=hl&&hl.indexOf(i)>=0,op=/^[·=]$/.test(p);T(S.g,x0+i*w,95,p,{'font-size':op?26:(p.length>4?20:28),'font-weight':800,fill:op?'#9aa8b6':(on?C.ok:'#1d2b3a')})})}
function c6Grid(a,b){clear();var x0=56,y0=8,cw=30,ch=16;for(var i=0;i<=9;i++)for(var j=0;j<=9;j++){if(!i&&!j)continue;var x=x0+j*cw,y=y0+i*ch,hd=!i||!j,on=(i===a&&j===b)||(i===b&&j===a),cr=(i===a&&!j)||(j===b&&!i)||(i===b&&!j)||(j===a&&!i);
  var r=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:on?C.hi:(hd?(cr&&a?'#ffe2b8':'#eef3f8'):'#fff'),stroke:'#dde5ee'},S.g);T(S.g,x+cw/2,y+12,hd?String(i||j):(on?String(i*j):''),{'font-size':10,'font-weight':hd||on?800:500,fill:'#33475b','pointer-events':'none'});
  if(!hd)(function(i,j){r.style.cursor='pointer';r.addEventListener('click',function(){c6Grid(i,j);if(S.onCell)S.onCell()})})(i,j)}
 cMsg(a?(a+' · '+b+' = <b>'+a*b+'</b> va '+b+' · '+a+' = <b>'+a*b+'</b> — egizaklar'):'Katakni bosing')}
function c6Table(r,c){clear();var cs=Math.min(18,120/r,300/c),x0=180-c*cs/2,y0=86-r*cs/2;for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('rect',{x:x0+j*cs,y:y0+i*cs,width:cs-1,height:cs-1,fill:(i+j)%2?'#d8eefa':'#fff',stroke:'#9aa8b6'},S.g);cMsg(r+' qator · '+c+' ustun = <b>'+r*c+'</b> ta katak')}
var PROBS=[
{t:"5 · 7 = 35 bo'lsa, 7 · 5 nechaga teng?",o:["35","12","57","75"],k:0,s:"O'rin almashtirish: 7 · 5 = 5 · 7 = 35."},
{t:"Aziz bankalarni 4 tadan 6 qator, Amir 6 tadan 4 qator qilib terdi. Kimda ko'p?",o:["Teng","Aziz","Amir","Amirda 2 ta ko'p"],k:0,s:"4 · 6 = 6 · 4 = 24."},
{t:"3 · 5 + 5 · 3 = 5 · □. □ o'rniga qaysi son?",o:["6","5","15","3"],k:0,s:"5 · 3 + 5 · 3 = 5 · 6."},
{t:"4 · 5 · 2 = 2 · 5 · □. □ o'rniga qaysi son?",o:["4","8","40","10"],k:0,s:"O'sha sonlar: 4, 5, 2."},
{t:"Qaysi ko'paytma 6 · 4 ga teng EMAS?",o:["3 · 9","4 · 6","3 · 8","2 · 12"],k:0,s:"3 · 9 = 27, qolganlari 24."},
{t:"Jadval 3 qator va 7 ustundan iborat. Burib qo'ysak, kataklar soni qanday o'zgaradi?",o:["O'zgarmaydi","4 ta ko'payadi","4 ta kamayadi","Ikki baravar oshadi"],k:0,s:"3 · 7 = 7 · 3 = 21."},
{t:"Og'zaki qulay hisoblang: 5 · 9 · 2",o:["90","45","18","100"],k:0,s:"5 · 2 = 10, 10 · 9 = 90."},
{t:"Og'zaki hisoblang: 2 · 7 · 5",o:["70","35","14","75"],k:0,s:"2 · 5 = 10, 10 · 7 = 70."},
{t:"Qaysi tenglik to'g'ri?",o:["6 · 3 = 3 · 6","6 − 3 = 3 − 6","6 : 3 = 3 : 6","6 · 3 = 6 + 3"],k:0,s:"Faqat ko'paytirishda o'rin almashtirish mumkin."},
{t:"16 · 4 = 64 bo'lsa, quyidagilardan qaysi biri NOTO'G'RI?",o:["16 + 16 + 16 = 64","4 · 16 = 64","64 : 4 = 16","64 : 16 = 4"],k:0,s:"16 + 16 + 16 = 48 — uchta, to'rtta emas."},
{t:"□ · 4 = 4 · 5 va △ = □ + □. △ · 2 nechaga teng?",o:["20","25","10","40"],k:0,s:"□ = 5, △ = 10, △ · 2 = 20."},
{t:"Qaysi son jadvalda 3 · 8 ning egizagi bilan bir xil?",o:["24","11","38","83"],k:0,s:"8 · 3 = 3 · 8 = 24."},
{t:"Bog'da 7 qator, har qatorda 4 tup daraxt. Boshqa bog'da 4 qator, har qatorda 7 tup. Qaysi bog'da ko'p?",o:["Teng","Birinchisida","Ikkinchisida","Birinchisida 3 ta ko'p"],k:0,s:"4 · 7 = 7 · 4 = 28."},
{t:"Og'zaki hisoblang: 5 · 3 · 2 · 4",o:["120","60","14","40"],k:0,s:"5 · 2 = 10, 3 · 4 = 12, 10 · 12 = 120."},
{t:"9 · 2 ni hisoblashning eng qulay usuli qaysi?",o:["9 + 9","2 + 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2","9 + 2","9 − 2"],k:0,s:"9 · 2 = 9 + 9 = 18 — eng qisqa."},
{t:"a · 6 = 6 · 8 bo'lsa, a nechaga teng?",o:["8","6","48","14"],k:0,s:"O'rin almashtirish: a = 8."},
{t:"3 · 4 + 4 · 3 + 3 · 4 qaysi ko'paytmaga teng?",o:["3 · 12","3 · 4","4 · 4","12 · 12"],k:0,s:"Uchtasi ham 12: 12 + 12 + 12 = 36 = 3 · 12."},
{t:"Qaysi juftdagi ko'paytmalar teng?",o:["2 · 9 va 3 · 6","2 · 9 va 2 · 8","3 · 6 va 3 · 5","4 · 4 va 2 · 9"],k:0,s:"2 · 9 = 18, 3 · 6 = 18."},
{t:"Kitob javonida 5 tokcha, har birida 8 tadan kitob. Kitoblar 8 tokchaga teng terilsa, har tokchada nechta bo'ladi?",o:["5","8","40","13"],k:0,s:"Jami 5 · 8 = 40. 8 tokchaga: 40 : 8 = 5."},
{t:"Og'zaki hisoblang: 25 · 3 · 4",o:["300","75","100","32"],k:0,s:"25 · 4 = 100, 100 · 3 = 300."}
];
function PRACT_STAGE(){cArr(3,5,{rowLab:1});cMsg('a · b = b · a')}
var PREP_DATA={teach:["O'rin almashtirish xossasi: massivni burish.","Qulay tartibni tanlab hisoblash; uch ko'paytuvchida 10 chiqadigan juft.","Ko'paytirish jadvalidagi «egizaklar».","Tuzoqlar: bir xil ko'paytma har xil sonlardan; ayirish/bo'lishda xossa ishlamaydi."],
 mist:["4 · 6 va 6 · 4 ni har xil deb o'ylaydi.","4 · 5 · 2 = 2 · 5 · □ da □ ga 40 yozadi.","Xossani ayirishga ham qo'llaydi (5 − 3 = 3 − 5).","«Teng emas» savolida bittasini hisoblamay qoldiradi."],
 need:["Qog'ozdagi nuqtali massiv (burish uchun).","Bo'sh ko'paytirish jadvali."],
 board:["<span class='w2'>5 · 3 = 3 · 5 = 15</span> — massiv chizmasi.","<span class='w2'>2 · 9 → 9 + 9</span>.","<span class='w2'>4 · 5 · 2 = 4 · 10 = 40</span>.","<span class='w2'>24 = 6·4 = 3·8 = 2·12</span>, <span class='w2'>3·9 = 27</span>.","<span class='w2'>5 − 3 ≠ 3 − 5</span>."]};
