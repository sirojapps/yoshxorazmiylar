var CODE='3M2',TITLE='3-sinf · Eyler–Venn diagrammasi: kesishma va birlashma';
function m2msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// A — juft (1..12), B — 3 ga karrali (1..12)
function m2reg(n){return n%6===0?'I':(n%2===0?'A':(n%3===0?'B':'N'))}
var M2R={I:[6,12],A:[2,4,8,10],B:[3,9],N:[1,5,7,11]};
var M2P={I:[[180,86],[180,124]],A:[[98,85],[98,125],[138,62],[138,148]],B:[[262,85],[262,125]],N:[[24,80],[24,130],[336,80],[336,130]]};
var M2LENS='M180 65.3 A60 60 0 0 1 180 144.7 A60 60 0 0 1 180 65.3 Z';
function m2rings(g,o){o=o||{};
 E('circle',{cx:135,cy:105,r:60,fill:o.hiA?'rgba(31,111,178,.20)':'rgba(31,111,178,.05)',stroke:C.blue,'stroke-width':3},g);
 E('circle',{cx:225,cy:105,r:60,fill:o.hiB?'rgba(224,122,47,.20)':'rgba(224,122,47,.05)',stroke:C.a2,'stroke-width':3},g);
 if(o.hiI)E('path',{d:M2LENS,fill:'rgba(30,142,90,.35)',stroke:C.ok,'stroke-width':3},g);
 T(g,40,168,o.la||'A: juft',{'font-size':11,'font-weight':800,fill:C.blue});T(g,318,168,o.lb||'B: 3 ga karrali',{'font-size':11,'font-weight':800,fill:C.a2})}
function m2chip(g,x,y,n,col,tap){var gg=E('g',{style:tap?'cursor:pointer':''},g);if(tap)E('rect',{x:x-14,y:y-16,width:28,height:32,fill:'transparent'},gg);E('circle',{cx:x,cy:y,r:13,fill:'#fff',stroke:col,'stroke-width':2.2},gg);T(gg,x,y+5,''+n,{'font-size':13,'font-weight':800,fill:'#33475b'});if(tap)gg.addEventListener('click',tap);return gg}
function m2pos(n){var r=m2reg(n);return M2P[r][M2R[r].indexOf(n)]}
function m2col(n){var r=m2reg(n);return r==='I'?C.ok:(r==='A'?C.blue:(r==='B'?C.a2:'#9aa7b4'))}
function m2draw(placed,o){o=o||{};clear();var g=S.g;m2rings(g,o);
 for(var n=1;n<=12;n++){(function(n){if(placed.indexOf(n)>=0){var p=m2pos(n);m2chip(g,p[0],p[1],n,m2col(n))}else m2chip(g,26+(n-1)*28.1,20,n,'#9aa7b4',o.tap?function(){o.tap(n)}:null)})(n)}}
function m2t1(n){if(!S.d1)return;var r=m2reg(n);
 if(r==='I'){if(S.s1.indexOf(n)<0)S.s1.push(n);m2draw(S.s1,{tap:m2t1});m2msg('<b>'+n+'</b> — juft ham, 3 ga karrali ham ✓ ('+S.s1.length+' / 2)');if(S.s1.length===2){var d=S.d1;S.d1=null;d()}return}
 m2msg(r==='A'?'<b>'+n+'</b> — juft, lekin 3 ga bo‘linmaydi: faqat A ga tegishli':(r==='B'?'<b>'+n+'</b> — 3 ga bo‘linadi, lekin toq: faqat B ga tegishli':'<b>'+n+'</b> — na juft, na 3 ga karrali'))}
var M2ALL=[1,2,3,4,5,6,7,8,9,10,11,12];
var P2=[function(){m2draw([6,12]);m2msg('Kesishmada: 6 va 12')},
 function(){m2draw([6,12,2,4,8,10]);m2msg('Faqat A (juft, 3 ga bo‘linmaydi): 2, 4, 8, 10')},
 function(){m2draw([6,12,2,4,8,10,3,9]);m2msg('Faqat B (3 ga karrali, toq): 3, 9')},
 function(){m2draw(M2ALL);m2msg('Hech biriga tegishli emas — halqalardan tashqarida: 1, 5, 7, 11')}];
var P3=[function(){m2draw(M2ALL);m2msg('Ikkala halqaning umumiy qismi qayer?')},
 function(){m2draw(M2ALL,{hiI:1});m2msg('A ∩ B = { 6, 12 } — <b>kesishma</b>')},
 function(){m2draw(M2ALL,{hiI:1});m2msg('∩ — «<b>va</b>»: ham juft, <b>ham</b> 3 ga karrali')}];
var P4=[function(){m2draw(M2ALL);m2msg('Endi ikkala halqani birga olamiz')},
 function(){m2draw(M2ALL,{hiA:1,hiB:1});m2msg('A ∪ B = { 2, 3, 4, 6, 8, 9, 10, 12 } — <b>birlashma</b>')},
 function(){m2draw(M2ALL,{hiA:1,hiB:1});calc(['A da 6 ta, B da 4 ta element','6 + 4 = 10 — lekin 6 va 12 ikki marta sanaldi!','A ∪ B: 6 + 4 − 2 = <b>8</b> ta element'])}];
// sonli diagramma
function m2num(o){clear();var g=S.g;E('rect',{x:12,y:24,width:336,height:140,rx:12,fill:'#fff',stroke:'#9aa7b4','stroke-width':2,'stroke-dasharray':'5 4'},g);
 T(g,180,16,o.top,{'font-size':12,'font-weight':800,fill:'#33475b'});
 E('circle',{cx:140,cy:96,r:56,fill:'rgba(31,111,178,.06)',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:220,cy:96,r:56,fill:'rgba(224,122,47,.06)',stroke:C.a2,'stroke-width':3},g);
 T(g,96,40,o.la,{'font-size':11,'font-weight':800,fill:C.blue});T(g,268,40,o.lb,{'font-size':11,'font-weight':800,fill:C.a2});
 [[o.a,112,C.blue],[o.i,180,C.ok],[o.b,248,C.a2]].forEach(function(v){if(v[0]!=null)T(g,v[1],104,''+v[0],{'font-size':22,'font-weight':800,fill:v[2]})});
 if(o.out!=null)T(g,320,150,''+o.out,{'font-size':20,'font-weight':800,fill:'#5a6b7c'})}
var P6=[function(){m2num({top:'Sinfda 25 o‘quvchi',la:'Futbol: 14',lb:'Shaxmat: 9',a:'?',i:'?',b:'?',out:'?'});m2msg('14 futbol, 9 shaxmat, 5 kishi — ikkalasi ham')},
 function(){m2num({top:'Sinfda 25 o‘quvchi',la:'Futbol: 14',lb:'Shaxmat: 9',a:'?',i:5,b:'?',out:'?'});m2msg('Avval <b>kesishmaga</b> yozamiz: 5')},
 function(){m2num({top:'Sinfda 25 o‘quvchi',la:'Futbol: 14',lb:'Shaxmat: 9',a:9,i:5,b:4,out:'?'});calc(['Faqat futbol: 14 − 5 = 9','Faqat shaxmat: 9 − 5 = 4'])},
 function(){m2num({top:'Sinfda 25 o‘quvchi',la:'Futbol: 14',lb:'Shaxmat: 9',a:9,i:5,b:4,out:7});calc(['Kamida bittasi: 9 + 5 + 4 = 18','Hech biri: 25 − 18 = <b>7</b>'])}];
// uch holat
function m2three(k){clear();var g=S.g;
 if(k===0){E('circle',{cx:95,cy:92,r:56,fill:'rgba(31,111,178,.06)',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:265,cy:92,r:56,fill:'rgba(224,122,47,.06)',stroke:C.a2,'stroke-width':3},g);
  [1,3,5].forEach(function(n,i){m2chip(g,70+i*25,92,n,C.blue)});[2,4,6].forEach(function(n,i){m2chip(g,240+i*25,92,n,C.a2)});
  T(g,95,164,'T: toq',{'font-size':11,'font-weight':800,fill:C.blue});T(g,265,164,'J: juft',{'font-size':11,'font-weight':800,fill:C.a2});m2msg('Umumiy element yo‘q: T ∩ J = <b>∅</b>. Halqalar kesishmaydi')}
 else if(k===1){E('circle',{cx:180,cy:90,r:76,fill:'rgba(224,122,47,.06)',stroke:C.a2,'stroke-width':3},g);E('circle',{cx:180,cy:98,r:36,fill:'rgba(31,111,178,.10)',stroke:C.blue,'stroke-width':3},g);
  [4,8].forEach(function(n,i){m2chip(g,166+i*28,100,n,C.blue)});[2,6,10].forEach(function(n,i){var p=[[134,62],[226,62],[180,40]][i];m2chip(g,p[0],p[1],n,C.a2)});
  T(g,180,128,'4 ga karrali',{'font-size':10,'font-weight':800,fill:C.blue});T(g,300,30,'J: 10 gacha juft',{'font-size':11,'font-weight':800,fill:C.a2});m2msg('Kichik halqa kattaning <b>ichida</b>: K ⊂ J, K ∩ J = K, K ∪ J = J')}
 else {m2draw(M2ALL);m2msg('Halqalar <b>kesishadi</b>: umumiy elementlar bor, lekin hammasi emas')}}
// hudud bosish
function m2regAt(x,y){var a=Math.hypot(x-135,y-105)<60,b=Math.hypot(x-225,y-105)<60;return a&&b?'I':(a?'A':(b?'B':'N'))}
var M2RN={I:'ikkala tilni ham',A:'faqat ingliz tilini',B:'faqat rus tilini',N:'hech qaysi tilni'};
function m2s8(){clear();var g=S.g;var f=S.f8||{};
 E('circle',{cx:135,cy:105,r:60,fill:f.A?'rgba(31,111,178,.25)':'rgba(31,111,178,.05)',stroke:C.blue,'stroke-width':3},g);
 E('circle',{cx:225,cy:105,r:60,fill:'rgba(224,122,47,.05)',stroke:C.a2,'stroke-width':3},g);
 if(f.A)E('path',{d:M2LENS,fill:'#fffaf2',stroke:C.a2,'stroke-width':3},g);
 if(f.I)E('path',{d:M2LENS,fill:'rgba(30,142,90,.4)',stroke:C.ok,'stroke-width':3},g);
 T(g,62,32,'I — ingliz tili',{'font-size':12,'font-weight':800,fill:C.blue});T(g,300,32,'R — rus tili',{'font-size':12,'font-weight':800,fill:C.a2});
 var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:pointer'},sv);
 r.addEventListener('click',function(ev){if(!S.d8)return;var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var q=pt.matrixTransform(sv.getScreenCTM().inverse());m2t8(m2regAt(q.x,q.y))})}
function m2t8(rg){var want=S.q8[0];if(rg!==want){m2msg('Bu yer — <b>'+M2RN[rg]+'</b> o‘rganadiganlar. Bizga '+M2RN[want]+' kerak');return}
 S.f8=S.f8||{};S.f8[rg]=1;S.q8.shift();m2s8();
 if(S.q8.length){m2msg('To‘g‘ri! Endi <b>'+M2RN[S.q8[0]]+'</b> o‘rganadiganlar joyini bosing')}else{m2msg('To‘g‘ri! «Faqat» — kesishmasiz, «ham» — kesishma');var d=S.d8;S.d8=null;d()}}
var STEPS=[
{h:"Ikki to'plam — ikki halqa",sum:"Ikkala to'plamga tegishli elementlar halqalarning umumiy qismida turadi.",a:"m01",
 start:function(){S.s1=[];m2draw([],{tap:m2t1});m2msg('Ham juft, ham 3 ga karrali sonlarni bosing')},fin:function(){m2draw([6,12]);m2msg('6 va 12 — ikkala to‘plamda')},
 act:function(c,done){S.d1=done},
 html:"<p>A — 1 dan 12 gacha <b>juft</b> sonlar, B — 1 dan 12 gacha <b>3 ga karrali</b> sonlar. Tepadagi sonlardan <b>ikkala</b> to'plamga ham tegishlilarini bosing.</p>",
 after:"<p>6 va 12 — ham juft, ham 3 ga bo'linadi. Ular ikkala halqaga ham tegishli, shuning uchun halqalar ustma-ust tushgan <b>umumiy qismda</b> turadi. Bunday chizma <b>Eyler–Venn diagrammasi</b> deyiladi.</p>",
 q:{t:"A = { 1, 2, 3, 4, 5 }, B = { 4, 5, 6, 7 }. Ikkala to'plamga tegishli elementlar?",opts:["{ 4, 5 }","{ 1, 2, 3, 4, 5, 6, 7 }","{ 1, 2, 3 }","{ 6, 7 }"],ok:0,why:"4 va 5 — A da ham, B da ham bor.",hint:"Har bir son ikkala ro'yxatda ham bormi?",full:"4 va 5 ikkala ro'yxatda bor — javob { 4, 5 }. { 1, 2, 3 } — faqat A da, { 6, 7 } — faqat B da. Hammasini yozish — bu birlashma, «ikkalasiga» emas."},
 tn:"Polga ikki arqon halqa qo'yib, qisman ustma-ust tushiring. Son kartochkalarini bolalar o'zi joylasin (Montessori, CPA: avval narsa, keyin chizma)."},
{h:"To'rtta joy",sum:"Diagrammada 4 ta joy bor: faqat A, kesishma, faqat B va tashqari.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Qolgan sonlarni joylashtiramiz. Har bir son uchun so'raymiz: «juftmi? 3 ga bo'linadimi?»</p>",
 btns:[phaser(P2)],
 after:"<p>Har bir son <b>to'rt joydan bittasiga</b> tushadi: <b>faqat A</b> (2, 4, 8, 10), <b>ikkalasi</b> (6, 12), <b>faqat B</b> (3, 9), <b>hech biri</b> — halqalardan tashqarida (1, 5, 7, 11). Bitta son ikki joyga yozilmaydi.</p>",
 q:{t:"Shu diagrammada 9 soni qayerda turadi?",opts:["Faqat B da","Kesishmada","Faqat A da","Halqalardan tashqarida"],ok:0,why:"9 — 3 ga bo'linadi, lekin toq.",hint:"9 juftmi? 3 ga bo'linadimi?",full:"9 : 3 = 3 — B ga tegishli. 9 toq — A ga tegishli emas. Demak, faqat B da. Kesishmaga faqat ikkala shartga mos son tushadi."},
 tn:"Doskaga ikki halqa chizing va 4 ta joyni rang bilan bo'yating. Har son uchun ikki savolni ovoz chiqarib bering."},
{h:"Kesishma: ∩",sum:"A ∩ B — ikkala to'plamga ham tegishli elementlar. «va», «ham … ham».",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ikkala to'plamning <b>umumiy</b> elementlarini alohida nom bilan ataymiz:</p>",
 btns:[phaser(P3)],
 after:"<p><b>Kesishma</b> — ikkala to'plamga ham tegishli elementlar: <b>A ∩ B = { 6, 12 }</b>. Belgisi <b>∩</b> («qalpoq»). Gapda «<b>va</b>», «<b>ham …, ham …</b>» so'zlari kesishmani bildiradi.</p>",
 q:{t:"A = { a, b, c, d }, B = { c, d, e }. A ∩ B = ?",opts:["{ c, d }","{ a, b, c, d, e }","{ e }","{ a, b }"],ok:0,why:"c va d — ikkalasida bor.",hint:"Faqat umumiy elementlarni oling.",full:"c va d ham A da, ham B da — A ∩ B = { c, d }. { a, b, c, d, e } — bu birlashma, { a, b } — faqat A, { e } — faqat B."},
 tn:"∩ ni «ko'prik» deb eslating: ikkala qirg'oqqa ham tegadi."},
{h:"Birlashma: ∪",sum:"A ∪ B — kamida bitta to'plamga tegishli elementlar. «yoki». Umumiylari bir marta yoziladi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Endi ikkala halqadagi <b>hamma</b> elementlarni birga olamiz:</p>",
 btns:[phaser(P4)],
 after:"<p><b>Birlashma</b> — A yoki B ga (kamida bittasiga) tegishli elementlar: <b>A ∪ B = { 2, 3, 4, 6, 8, 9, 10, 12 }</b>. Belgisi <b>∪</b> («kosa»). 6 va 12 bir marta yoziladi! Shuning uchun elementlar soni: <b>6 + 4 − 2 = 8</b>.</p>",
 q:{t:"A = { 1, 2, 3, 4 }, B = { 3, 4, 5 }. A ∪ B da nechta element?",opts:["5","7","2","3"],ok:0,why:"{ 1, 2, 3, 4, 5 } — 3 va 4 bir marta.",hint:"Umumiy elementlarni ikki marta sanamang.",full:"A ∪ B = { 1, 2, 3, 4, 5 } — 5 ta. 4 + 3 = 7 — bu 3 va 4 ni ikki marta sanash. 2 — kesishmadagi elementlar soni, 3 — B dagi."},
 tn:"Ikki guruh bolani bitta qatorga tizing: ikkala guruhda bo'lgan bola bir marta turadi — birlashma shu."},
{h:"Tuzoq: ikki marta sanamang",sum:"Birlashma soni = A soni + B soni − kesishma soni.",a:"m05",
 start:function(){m2draw(M2ALL);m2msg('Uchala tugmani bosib, hisobni tekshiring')},fin:function(){m2draw(M2ALL,{hiA:1,hiB:1});calc(['A: 6 ta, B: 4 ta, A ∩ B: 2 ta','A ∪ B = 6 + 4 − 2 = <b>8</b>'])},
 html:"<p>Ali A ∪ B ni shunday sanadi: «A da 6, B da 4 — jami 10». Uchala tugmani bosib, xatoni toping.</p>",
 btns:[["A ni sanash",function(c,done){m2draw(M2ALL,{hiA:1});m2msg('A: 2, 4, <b>6</b>, 8, 10, <b>12</b> — 6 ta');mvK(done,3)}],["B ni sanash",function(c,done){m2draw(M2ALL,{hiB:1});m2msg('B: 3, <b>6</b>, 9, <b>12</b> — 4 ta');mvK(done,3)}],["Ikki marta sanalgan",function(c,done){m2draw(M2ALL,{hiI:1});m2msg('6 va 12 <b>ikkala</b> sanoqda ham bor — 2 ta ortiqcha');mvK(done,3)}]],
 after:"<p>Ali 6 va 12 ni ikki marta sanagan. To'g'ri hisob: <b>A ∪ B soni = A soni + B soni − kesishma soni</b> = 6 + 4 − 2 = <b>8</b>. Bu qoida ko'p masalalarning kaliti.</p>",
 q:{t:"12 kishi rasm, 10 kishi musiqa to'garagiga qatnashadi, 4 kishi — ikkalasiga ham. Kamida bitta to'garakka necha kishi qatnashadi?",opts:["18","22","26","14"],ok:0,why:"12 + 10 − 4 = 18.",hint:"Ikkalasiga qatnashadiganlar ikki marta sanalmasin.",full:"12 + 10 = 22 da 4 kishi ikki marta sanalgan: 22 − 4 = 18. 26 — 4 ni qo'shib yuborish, 14 — 4 ni ikki marta ayirish."},
 tn:"Sinfda so'rang: «Kim olma yaxshi ko'radi? Kim nok?» Ikkala qo'lini ko'targanlarni alohida sanang."},
{h:"Masalani diagrammada yechamiz",sum:"Avval kesishmani yozing, keyin «faqat» qismlarni, oxirida tashqarini.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Sinfda 25 o'quvchi. 14 tasi futbol, 9 tasi shaxmat bilan shug'ullanadi, 5 tasi — ikkalasi bilan. Nechtasi hech biri bilan shug'ullanmaydi?</p>",
 btns:[phaser(P6)],
 after:"<p>Tartib muhim: <b>1)</b> kesishma — 5; <b>2)</b> faqat futbol 14 − 5 = 9, faqat shaxmat 9 − 5 = 4; <b>3)</b> kamida bittasi 9 + 5 + 4 = 18; <b>4)</b> hech biri 25 − 18 = <b>7</b>. Diagramma masalani ko'rinadigan qiladi (Singapur usuli: avval chizma, keyin hisob).</p>",
 q:{t:"30 o'quvchi: 17 tasi suzish, 15 tasi tennis, 6 tasi ikkalasi bilan shug'ullanadi. Hech biri bilan shug'ullanmaydiganlar nechta?",opts:["4","10","26","2"],ok:0,why:"17 + 15 − 6 = 26, 30 − 26 = 4.",hint:"Avval kamida bittasi bilan shug'ullanadiganlarni toping.",full:"Kamida bittasi: 17 + 15 − 6 = 26. Hech biri: 30 − 26 = 4. 26 — bu boshqa savolning javobi, 2 — 17 + 15 = 32 dan 30 ni ayirish, 10 — kesishmani hisobga olmaslik."},
 tn:"Doskada bo'sh diagramma chizib, sonlarni bolalar o'zi yozsin. «Kesishmadan boshlang» qoidasini doskaga yozib qo'ying."},
{h:"Halqalar qanday turadi?",sum:"Kesishmaydi (umumiy yo'q), ichida (qismto'plam), kesishadi (qisman umumiy).",a:"m07",
 start:function(){m2three(2)},fin:function(){m2three(1)},
 html:"<p>Ikki to'plamning halqalari uch xil joylashishi mumkin. Uchalasini ko'ring:</p>",
 btns:[["Kesishmaydi",function(c,done){m2three(0);mvK(done,3)}],["Biri ichida",function(c,done){m2three(1);mvK(done,3)}],["Kesishadi",function(c,done){m2three(2);mvK(done,3)}]],g3:1,
 after:"<p><b>Kesishmaydi</b>: umumiy element yo'q, A ∩ B = ∅ (toq va juft sonlar). <b>Biri ichida</b>: K ⊂ J bo'lsa, K ∩ J = K va K ∪ J = J. <b>Kesishadi</b>: umumiy elementlar bor, lekin hammasi emas.</p>",
 q:{t:"T — toq sonlar, J — juft sonlar. T ∩ J nimaga teng?",opts:["∅ (bo'sh to'plam)","{ 0 }","{ 1, 2 }","Barcha sonlar"],ok:0,why:"Bir son ham toq, ham juft bo'la olmaydi.",hint:"Ham toq, ham juft son bormi?",full:"Hech bir son bir vaqtda toq va juft bo'lmaydi — kesishma bo'sh: ∅. «Barcha sonlar» — bu T ∪ J (birlashma)."},
 tn:"Uchta holatni uch xil ip bilan ko'rsating; har biriga sinfdan misol topinglar (qizlar va o'g'il bolalar — kesishmaydi)."},
{h:"Tuzoq: «faqat» va «ham»",sum:"«Faqat ingliz tili» — kesishmasiz qism; «ikkalasi ham» — kesishma.",a:"m08",
 start:function(){S.f8={};S.q8=['A','I'];m2s8();m2msg('<b>Faqat ingliz tilini</b> o‘rganadiganlar joyini bosing')},fin:function(){S.f8={A:1,I:1};m2s8();m2msg('Ko‘k — faqat ingliz tili, yashil — ikkalasi ham')},
 act:function(c,done){S.d8=done},
 html:"<p>I — ingliz tilini, R — rus tilini o'rganadiganlar. Diagrammada avval <b>faqat ingliz tilini</b>, so'ng <b>ikkala tilni ham</b> o'rganadiganlar joyini bosing.</p>",
 after:"<p>«<b>Faqat</b> ingliz tili» — I halqasining kesishmadan tashqari qismi. «<b>Ingliz tilini</b> o'rganadiganlar» esa butun I halqasi (kesishma bilan birga). Masalada qaysi so'z ishlatilganiga diqqat qiling!</p>",
 q:{t:"Ingliz tilini 11 kishi, rus tilini 8 kishi o'rganadi, 3 kishi ikkalasini. Faqat ingliz tilini necha kishi o'rganadi?",opts:["8","11","14","5"],ok:0,why:"11 − 3 = 8.",hint:"11 ning ichida ikkalasini o'rganadiganlar ham bor.",full:"Ingliz tilini o'rganadigan 11 kishining 3 tasi rus tilini ham o'rganadi. Faqat ingliz: 11 − 3 = 8. 5 = 8 − 3 — bu faqat rus tili."},
 tn:"«Faqat» so'zining tagiga chizdiring. Bolalar masaladagi har bir sonni diagrammaning qaysi qismiga tegishli ekanini ko'rsatsin."},
{h:"Bilasizmi? Eyler va Venn",sum:"Doiralar bilan mulohaza qilishni Leonard Eyler, keng ommalashgan diagrammani Jon Venn kiritgan.",a:"m09",
 start:function(){P3[2]()},fin:function(){P3[2]()},
 html:"<p>🎓 Shveysariyalik matematik <b>Leonard Eyler</b> (1707–1783) mantiqiy fikrlarni doiralar yordamida tushuntirgan — bu haqida u nemis malikasiga yozgan maktublarida (1768) bayon qilgan.</p><p>Ingliz olimi <b>Jon Venn</b> 1880-yilda barcha mumkin bo'lgan holatlarni ko'rsatuvchi diagrammalarni taklif qilgan. Shuning uchun ular «Eyler–Venn diagrammalari» deb ataladi.</p><p>📊 Bugun bunday diagrammalar fan, biznes va kundalik tahlillarda keng qo'llaniladi.</p>",
 tn:"Bolalar uyda oila a'zolari bilan diagramma tuzsin: «choy yaxshi ko'radiganlar» va «qahva yaxshi ko'radiganlar»."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P3[2]()},fin:function(){P3[2]()},
 html:"<div class='memo'><ul><li>Diagrammada 4 joy: <b>faqat A</b>, <b>kesishma</b>, <b>faqat B</b>, <b>tashqari</b>.</li><li><b>A ∩ B</b> — ikkalasiga ham tegishli («va», «ham … ham»).</li><li><b>A ∪ B</b> — kamida bittasiga tegishli («yoki»); umumiylar bir marta.</li><li>A ∪ B soni = A soni + B soni − A ∩ B soni.</li><li>Masalada avval <b>kesishmani</b>, keyin «faqat» qismlarni, oxirida tashqarini toping.</li><li>«Faqat A» ≠ «A»: «faqat» kesishmani o'z ichiga olmaydi.</li><li>Umumiy element yo'q: A ∩ B = ∅.</li></ul></div>",
 tn:"Keyingi darsda mulohazalar (rost/yolg'on) — «va», «yoki» so'zlari yana uchraydi."}
];
var PROBS=[
{t:"A = { 2, 4, 6, 8 }, B = { 4, 8, 12 }. A ∩ B = ?",o:["{ 4, 8 }","{ 2, 4, 6, 8, 12 }","{ 2, 6 }","{ 12 }"],k:0,s:"4 va 8 — ikkalasida bor."},
{t:"A = { 1, 3, 5, 7 }, B = { 5, 7, 9 }. A ∪ B = ?",o:["{ 1, 3, 5, 7, 9 }","{ 5, 7 }","{ 1, 3, 5, 5, 7, 7, 9 }","{ 1, 3, 9 }"],k:0,s:"Hammasi, umumiylar bir marta."},
{t:"A = { a, b, c }, B = { d, e }. A ∩ B = ?",o:["∅","{ a, b, c, d, e }","{ a, d }","{ c, d }"],k:0,s:"Umumiy element yo'q."},
{t:"A = { 1, 2, 3 }, B = { 1, 2, 3, 4, 5 }. A ∩ B = ?",o:["{ 1, 2, 3 }","{ 4, 5 }","{ 1, 2, 3, 4, 5 }","∅"],k:0,s:"A to'liq B ning ichida — kesishma A ning o'zi."},
{t:"A = { 1, 2, 3 }, B = { 1, 2, 3, 4, 5 }. A ∪ B = ?",o:["{ 1, 2, 3, 4, 5 }","{ 1, 2, 3 }","{ 4, 5 }","{ 1, 1, 2, 2, 3, 3, 4, 5 }"],k:0,s:"A ⊂ B bo'lgani uchun birlashma — B."},
{t:"10 gacha juft sonlar va 10 gacha 5 ga karrali sonlar kesishmasi?",o:["{ 10 }","{ 5, 10 }","{ 2, 4, 5, 6, 8, 10 }","∅"],k:0,s:"Juft: 2, 4, 6, 8, 10; 5 ga karrali: 5, 10 — umumiy 10."},
{t:"Faqat A da 6, faqat B da 4, kesishmada 3 element. A da nechta element?",o:["9","6","13","10"],k:0,s:"6 + 3 = 9."},
{t:"Faqat A da 6, faqat B da 4, kesishmada 3 element. A ∪ B da nechta element?",o:["13","16","10","9"],k:0,s:"6 + 4 + 3 = 13."},
{t:"«KITOB» va «TOSH» so'zlari harflari to'plamlarining kesishmasi?",o:["{ T, O }","{ K, I, T, O, B, S, H }","{ O }","{ T, O, S, H }"],k:0,s:"T va O ikkala so'zda bor."},
{t:"«KITOB» va «TOSH» so'zlari harflari birlashmasida nechta element?",o:["7","9","5","2"],k:0,s:"5 + 4 − 2 = 7."},
{t:"A da 7, B da 5 element, A ∩ B da 2 element. A ∪ B da nechta element?",o:["10","12","14","8"],k:0,s:"7 + 5 − 2 = 10."},
{t:"A = { 1, 5 }, B = { 5, 9, 10 }. A ∪ B = ?",o:["{ 1, 5, 9, 10 }","{ 5 }","{ 1, 9, 10 }","{ 1, 5, 5, 9, 10 }"],k:0,s:"5 bir marta yoziladi."},
{t:"A — 20 gacha 4 ga karrali sonlar, B — 20 gacha 6 ga karrali sonlar. A ∩ B = ?",o:["{ 12 }","{ 12, 24 }","{ 4, 6, 8, 12, 16, 18, 20 }","∅"],k:0,s:"A = { 4, 8, 12, 16, 20 }, B = { 6, 12, 18 }."},
{t:"Faqat suzishga 9, faqat shaxmatga 7, ikkalasiga 4 bola qatnashadi. Shaxmatga jami necha bola qatnashadi?",o:["11","7","20","16"],k:0,s:"7 + 4 = 11."},
{t:"Sinfda 28 o'quvchi. 15 tasi olmani, 12 tasi nokni yaxshi ko'radi, 5 tasi ikkalasini. Hech birini yaxshi ko'rmaydiganlar nechta?",o:["6","1","11","22"],k:0,s:"15 + 12 − 5 = 22; 28 − 22 = 6."},
{t:"Guruhda 20 bola, har biri futbol yoki voleybol o'ynaydi (kamida bittasini). Futbol — 16, voleybol — 11 bola. Ikkalasini o'ynaydiganlar nechta?",o:["7","27","5","4"],k:0,s:"16 + 11 = 27; 27 − 20 = 7."},
{t:"Sinfda 26 o'quvchi, hammasi kitob o'qish yoki rasm chizishni yaxshi ko'radi. Kitobni 18, rasmni 14 tasi yaxshi ko'radi. Ikkalasini nechtasi yaxshi ko'radi?",o:["6","4","32","8"],k:0,s:"18 + 14 − 26 = 6."},
{t:"Do'konga 30 xaridor kirdi: 20 tasi non, 15 tasi sut oldi, 3 tasi hech narsa olmadi. Ham non, ham sut olganlar nechta?",o:["8","5","12","35"],k:0,s:"Kamida bittasi: 30 − 3 = 27; 20 + 15 − 27 = 8."},
{t:"A da 8, B da 6 element bor. A ∪ B da eng kami bilan nechta element bo'lishi mumkin?",o:["8","14","6","2"],k:0,s:"B to'liq A ning ichida bo'lsa: A ∪ B = A, 8 ta."},
{t:"A da 8, B da 6 element bor. A ∪ B da eng ko'pi bilan nechta element bo'lishi mumkin?",o:["14","8","48","12"],k:0,s:"Umumiy element yo'q bo'lsa: 8 + 6 = 14."}
];
function PRACT_STAGE(){P3[2]()}
var PREP_DATA={teach:["Eyler–Venn diagrammasi: 4 ta joy (faqat A, kesishma, faqat B, tashqari).","Kesishma ∩ («va»), birlashma ∪ («yoki»).","Birlashma soni = A + B − kesishma.","Sonli masalalar: avval kesishma, keyin «faqat» qismlar, oxirida tashqari.","Halqalarning 3 holati: kesishmaydi, ichida, kesishadi."],
 mist:["Umumiy elementlarni ikki marta sanaydi (A ∪ B = A + B).","«Faqat A» va «A» ni farqlamaydi.","Kesishma va birlashmani adashtiradi.","Tashqaridagi (hech biriga tegishli bo'lmagan) elementlarni unutadi."],
 need:["Ikki arqon/ip halqa yoki hulahup.","1–12 son kartochkalari.","Doskada bo'sh diagramma shabloni."],
 board:["A: juft, B: 3 ga karrali (1–12).","A ∩ B = { 6, 12 }.","A ∪ B = { 2, 3, 4, 6, 8, 9, 10, 12 }.","6 + 4 − 2 = 8.","25 o'q.: 9 | 5 | 4, tashqarida 7."]};
