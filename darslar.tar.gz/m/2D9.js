var CODE='2D9',TITLE='2-sinf · Ortiqcha yoki yetishmaydigan ma’lumotli masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// shart kartochkalari: facts = [[matn, tur]] tur: 'k' kerak, 'o' ortiqcha, 'y' yetishmaydi, 'q' savol
function bm9card(title,facts,show){clear();var g=S.g;T(g,180,18,title,{'font-size':12,'font-weight':800,fill:C.blue});
 facts.forEach(function(f,i){var y=30+i*30,col=!show?'#fff':f[1]==='k'?'#e3f5ea':f[1]==='o'?'#fde3e3':f[1]==='y'?'#fff3c4':'#e8f1fb';
  E('rect',{x:20,y:y,width:320,height:24,rx:7,fill:col,stroke:show&&f[1]==='o'?C.bad:'#c9d3dd','stroke-dasharray':show&&f[1]==='y'?'5 3':''},g);
  T(g,32,y+16,f[0],{'font-size':11.5,'text-anchor':'start','font-weight':f[1]==='q'?800:600,'text-decoration':show===1&&f[1]==='o'?'line-through':''});
  if(show){var m={k:'kerak',o:'ortiqcha',y:'yetishmaydi',q:'savol'}[f[1]];T(g,334,y+16,m,{'font-size':10,'text-anchor':'end','font-weight':800,fill:f[1]==='o'?C.bad:f[1]==='k'?C.ok:f[1]==='y'?C.a2:C.blue})}})}
var F1=[['Bog‘da 4 qator olma daraxti bor.','k'],['Har qatorda 5 tup daraxt.','k'],['Har daraxtning bo‘yi 3 metr.','o'],['Bog‘da nechta daraxt bor?','q']];
var F2=[['Avtobusda 30 kishi bor edi.','k'],['Bekatda bir necha kishi tushdi.','y'],['Avtobusda necha kishi qoldi?','q']];
var F4=[['Lola 45 ta qizil shar oldi.','k'],['U 30 ta ko‘k shar oldi.','k'],['Har shar 2 ming so‘m.','o'],['Qizil sharlar ko‘kdan nechta ko‘p?','q']];
var F5=[['Kemada 26 ta qo‘y va 10 ta echki bor.','o'],['Kapitan necha yoshda?','q'],['Kapitan yoshi haqida hech narsa yo‘q.','y']];
var F7=[['Maktabda 3 ta ikkinchi sinf bor.','o'],['2-A da 28, 2-B da 25 o‘quvchi.','k'],['2-A da 2-B dan nechta ko‘p o‘quvchi?','q']];
var STEPS=[
bmStep({h:"Ortiqcha ma'lumotni topamiz",sum:"4 qator × 5 tup = 20 ta daraxt. Daraxt bo'yi (3 m) — ortiqcha ma'lumot.",a:"m01",frames:[{}],
 start:function(){bm9card('Shartni o‘qing',F1);calc(['Qaysi ma’lumot savolga kerak emas?'])},
 fin:function(){bm9card('Shartni o‘qing',F1,1);calc(['5 · 4 = <b>20</b> ta daraxt','Bo‘yi 3 m — <b>ortiqcha</b>'])},
 html:"<p>Ba'zan masalada savolga <b>kerak bo'lmagan</b> son ham bo'ladi. Uni topish — yaxshi o'quvchining belgisi. Qaysi ma'lumot ortiqcha?</p>",
 g3:1,btns:bmPick(["4 qator","5 tup","bo‘yi 3 m"],2,null,["Qatorlar sonisiz daraxtlarni sanab bo‘lmaydi.","Har qatordagi soni kerak — aks holda hisoblay olmaymiz."]),
 after:"<p>Savol — <b>nechta daraxt</b>. Bo'y bu savolga ta'sir qilmaydi. Yechim: 5 · 4 = 20. Ortiqcha sonni ishlatsangiz (masalan, 20 · 3), javob noto'g'ri bo'ladi.</p>",
 q:{t:"Qutida 6 qator, har qatorda 4 tadan konfet. Har konfet 5 gramm. Qutida nechta konfet bor?",opts:["120","24","10","30"],ok:1,why:"4 · 6 = 24; grammi ortiqcha.",hint:"Savol konfetlar soni haqida. Gramm kerakmi?",full:"Konfetlar soni: 4 · 6 = 24. «5 gramm» — ortiqcha. «120» — ortiqcha sonni ham ko'paytirish xatosi."},
 tn:"O'quvchilar shartdagi kerakli sonlarning tagiga chizsin, ortiqchasini o'chirsin."}),
bmStep({h:"Yetishmaydigan ma'lumot",sum:"«Bir necha kishi tushdi» — necha kishi ekani aytilmagan; masalani yechib bo'lmaydi.",a:"m02",frames:[{}],
 start:function(){bm9card('Bu masalani yechsa bo‘ladimi?',F2);calc(['Javob berish uchun hammasi bormi?'])},
 fin:function(){bm9card('Bu masalani yechsa bo‘ladimi?',F2,1);calc(['30 − ? = ?','Necha kishi tushgani <b>aytilmagan</b>'])},
 html:"<p>Ba'zan esa masalada <b>kerakli son yo'q</b>. Unda uni yechib bo'lmaydi — yetishmayotganini aytish kerak. Bu masalani yechish mumkinmi?</p>",
 btns:bmPick(["Ha, 30 kishi qoldi","Yo‘q, ma’lumot yetarli emas","Ha, 29 kishi qoldi"],1,null,["Kimdir tushgan — demak 30 emas.","","«Bir necha» — bu 1 degani emas. Aniq son yo‘q."]),
 after:"<p>«Bir necha» — aniq son emas. Masalani to'ldirish kerak: masalan, «8 kishi tushdi» desak, 30 − 8 = 22. Taxmin qilib javob yozmang!</p>",
 q:{t:"Qaysi masalani yechib BO'LMAYDI?",opts:["Ali 12 ta, Vali 8 ta olma terdi. Ikkalasi nechta tergan?","Sumkada olmalar bor edi. 5 tasi yeyildi. Nechta qoldi?","Savatda 20 ta olma, 7 tasi yeyildi. Nechta qoldi?","Ali 15 ta olma terdi, 6 tasini berdi. Nechta qoldi?"],ok:1,why:"Sumkadagi olmalar soni aytilmagan.",hint:"Qaysi masalada boshlang'ich son yo'q?",full:"Ikkinchi masalada sumkada nechta olma bo'lgani yo'q — yechib bo'lmaydi. Qolganlarida barcha kerakli sonlar bor."},
 tn:"Bolalar yetishmaydigan masalaga o'zi son qo'shib, uni yechiladigan qilsin."}),
bmStep({h:"Javob shartning o'zida",sum:"«Lola 23 ta savolga to'g'ri javob berdi... Nechta to'g'ri javob bergan?» — hisoblash shart emas: 23.",a:"m03",
 frames:[{t:'Testda 30 ta savol bor edi. Lola 23 tasiga to‘g‘ri, qolganiga xato javob berdi.',lines:['Savol: Lola nechta savolga to‘g‘ri javob bergan?'],hl:{0:'q'}}],
 html:"<p>Shartni diqqat bilan o'qing — ba'zan javob <b>tayyor</b> turadi! Bu masalada nima qilish kerak?</p>",
 btns:bmPick(["30 − 23 = 7","Hisoblash shart emas: 23","30 + 23 = 53"],1,{t:'Testda 30 ta savol bor edi. Lola 23 tasiga to‘g‘ri, qolganiga xato javob berdi.',lines:['Savol: Lola nechta savolga to‘g‘ri javob bergan?','Javob shartda yozilgan: 23'],hl:{1:'ok'}},["7 — bu xato javoblar soni. Savol to‘g‘ri javoblar haqida!","","Qo‘shishga hech qanday sabab yo‘q."]),
 after:"<p>Ko'p bola sonni ko'rsa, darhol amal bajaradi. Avval <b>savolni</b> o'qing: nima so'ralyapti? Bu yerda 30 — ortiqcha ma'lumot.</p>",
 q:{t:"Lola xato javob bergan savollar nechta?",opts:["23","7","53","30"],ok:1,why:"30 − 23 = 7.",hint:"Endi savol o'zgardi — xato javoblarni so'rayapti.",full:"Xato javoblar: 30 − 23 = 7. Bu safar ikkala son ham kerak. Savol o'zgarsa, kerakli ma'lumot ham o'zgaradi."},
 tn:"Bir shartga turli savollar bering — har savolga qaysi sonlar kerakligini muhokama qiling."}),
bmStep({h:"Chizmada faqat keraklisi",sum:"45 qizil, 30 ko'k shar; narx ortiqcha. Chizma: 45 − 30 = 15.",a:"m04",
 frames:[{}, {t:'Qizil 45, ko‘k 30. Qizil ko‘kdan nechta ko‘p?',bars:[{lab:'qizil',y:58,segs:[{w:30,txt:'30',c:'c'},{w:15,txt:'?',c:'q'}]},{lab:'ko‘k',y:104,segs:[{w:30,txt:'30',c:'b'}]}],br:[{b:0,lab:'45',up:true}],note:'Narx chizmaga kirmadi — u savolga kerak emas'},
  {t:'Qizil 45, ko‘k 30. Qizil ko‘kdan nechta ko‘p?',bars:[{lab:'qizil',y:58,segs:[{w:30,txt:'30',c:'c'},{w:15,txt:'15',c:'g'}]},{lab:'ko‘k',y:104,segs:[{w:30,txt:'30',c:'b'}]}],br:[{b:0,lab:'45',up:true}],calc:['45 − 30 = <b>15</b> ta','«2 ming so‘m» — ortiqcha']}],
 start:function(){S.ph=0;bm9card('Shar masalasi',F4);calc(['Chizma chizishdan oldin ortiqchasini ajrating'])},
 html:"<p>Chizmaga faqat <b>savolga kerakli</b> sonlar tushadi. Kuzating.</p>",
 after:"<p>Ortiqcha ma'lumot chizmani chalkashtiradi. Avval ajratib oling, keyin chizing.</p>",
 q:{t:"Lola sharlarga jami qancha pul to'lagan? (45 qizil, 30 ko'k, har biri 2 ming)",opts:["15 ming","150 ming","75 ming","90 ming"],ok:1,why:"45 + 30 = 75 ta, 75 · 2 = 150 ming.",hint:"Endi narx kerakmi? Avval sharlar sonini toping.",full:"Jami shar: 45 + 30 = 75. Narx: 75 · 2 = 150 ming. Bu savolga narx endi KERAK — ortiqcha emas."},
 tn:"Bir xil shartga ikki savol: biriga narx kerak, biriga yo'q."}),
bmStep({h:"Kapitan necha yoshda?",sum:"«26 qo'y va 10 echki. Kapitan necha yoshda?» — sonlar bor, lekin javob yo'q. To'g'ri javob: aniqlab bo'lmaydi.",a:"m05",frames:[{}],
 start:function(){bm9card('Mashhur «tuzoq» masala',F5.slice(0,2));calc(['Qanday javob berasiz?'])},
 fin:function(){bm9card('Mashhur «tuzoq» masala',F5,1);calc(['Sonlar bor, lekin ular kapitan haqida emas','Javob: <b>aniqlab bo‘lmaydi</b>'])},
 html:"<p>Bu mashhur masala. Kemada 26 ta qo'y va 10 ta echki bor. Kapitan necha yoshda?</p>",
 btns:bmPick(["36 yosh","16 yosh","Aniqlab bo‘lmaydi"],2,null,["26 + 10 — bu hayvonlar soni, kapitan yoshi emas!","26 − 10 — hayvonlar ayirmasi yoshni bildirmaydi."]),
 after:"<p>Hamma sonlar — hayvonlar haqida. Kapitan yoshi haqida <b>hech narsa yo'q</b>. «Aniqlab bo'lmaydi» deyish — xato emas, balki <b>aqlli</b> javob!</p>",
 q:{t:"Sinfda 12 qiz va 14 o'g'il bola. O'qituvchi necha yoshda?",opts:["26 yosh","2 yosh","Aniqlab bo'lmaydi","24 yosh"],ok:2,why:"Shartda o'qituvchi yoshi haqida ma'lumot yo'q.",hint:"Sonlar kim haqida?",full:"12 va 14 — o'quvchilar soni. O'qituvchi yoshini ulardan topib bo'lmaydi. «26» — ma'nosiz qo'shish."},
 tn:"Bolalar o'zlari «kapitan» masalasini tuzsin — bu tanqidiy fikrlashni o'stiradi."}),
bmStep({h:"Yetishmaganini to'ldiramiz",sum:"«Nonvoyxonada 50 ta non bor edi. Tushgacha sotildi. Nechta qoldi?» → «32 tasi sotildi» qo'shilsa: 18.",a:"m06",
 frames:[{t:'Nonvoyxonada 50 ta non bor edi. Tushgacha bir qismi sotildi. Nechta qoldi?',lines:['Qaysi ma’lumot qo‘shilsa, masala yechiladi?'],hl:{0:'q'}}],
 html:"<p>Masalani <b>yechiladigan</b> qilish uchun qaysi ma'lumot kerak?</p>",
 btns:bmPick(["Non 3 ming so‘m","32 tasi sotildi","Nonvoy 5 kishi"],1,{t:'Nonvoyxonada 50 ta non bor edi. 32 tasi sotildi. Nechta qoldi?',bars:[{y:72,segs:[{w:32,txt:'32 sotildi',c:'x'},{w:18,txt:'18',c:'g'}]}],br:[{b:0,lab:'50',up:true}],calc:['50 − 32 = <b>18</b> ta non qoldi']},["Narx sotilgan nonlar sonini aytmaydi.","","Nonvoylar soni ham sotilgan nonni bildirmaydi."]),
 after:"<p>Kerakli ma'lumot — <b>nechta sotilgani</b>. Boshqa sonlar qo'shilsa ham masala yechilmaydi: ular ortiqcha bo'lib qoladi.</p>",
 q:{t:"«Ali 20 ta marka yig'di, keyin yana yig'di. Nechta bo'ldi?» Nima yetishmaydi?",opts:["Markalar narxi","Keyin nechta yig'gani","Ali yoshi","Albom rangi"],ok:1,why:"Qo'shiladigan ikkinchi son yo'q.",hint:"Qaysi ikki son qo'shilishi kerak?",full:"20 + ? — keyin yig'ilgan markalar soni kerak. Qolganlari savolga aloqasi yo'q."},
 tn:"Juft bo'lib: biri yetishmaydigan masala tuzadi, ikkinchisi uni to'ldiradi."}),
bmStep({h:"Tuzoq: son ko'p — kerakli kam",sum:"«3 ta ikkinchi sinf» — ortiqcha. 2-A 28, 2-B 25: 28 − 25 = 3.",a:"m07",frames:[{}],
 start:function(){bm9card('Diqqat!',F7);calc(['Uchta son bor. Qaysilari kerak?'])},
 fin:function(){bm9card('Diqqat!',F7,1);calc(['28 − 25 = <b>3</b>','«3 ta sinf» — ortiqcha (javob bilan bir xil bo‘lsa ham!)'])},
 html:"<p>Bu masalada uchta son bor. Qaysi amal to'g'ri?</p>",
 btns:bmPick(["28 + 25 + 3 = 56","28 − 25 = 3","28 − 25 − 3 = 0"],1,null,["Savol — nechta ko‘p. «Jami» emas!","","«3 ta sinf» o‘quvchilar soni emas — uni ayirmang."]),
 after:"<p>Javob 3 chiqdi — shartdagi «3» bilan bir xil, lekin bu <b>tasodif</b>. Sinflar soni yechimda ishlatilmadi.</p>",
 q:{t:"Do'konda 4 ta sotuvchi. Ertalab 35 kg, kechqurun 27 kg shakar sotildi. Kunda jami necha kg shakar sotildi?",opts:["66 kg","62 kg","8 kg","58 kg"],ok:1,why:"35 + 27 = 62; sotuvchilar soni ortiqcha.",hint:"Sotuvchilar soni shakar miqdoriga kerakmi?",full:"35 + 27 = 62 kg. «4 ta sotuvchi» — ortiqcha. «66» — 4 ni ham qo'shib yuborish xatosi."},
 tn:"Har masalada «Bu son nima haqida?» deb so'rashni odat qiling."}),
bmStep({h:"Bilasizmi? Kapitan tajribasi",sum:"1980-yilda Fransiyada o'quvchilarga «kapitan yoshi» masalasi berilgan; ko'pchilik sonlarni qo'shib javob yozgan.",a:"m08",frames:[{}],
 start:function(){bm9card('1980 · Fransiya, Grenobl',[['Kemada 26 qo‘y va 10 echki bor.','o'],['Kapitan necha yoshda?','q'],['97 o‘quvchidan 76 tasi sonlardan «javob» topgan','k']]);calc(['Sizlar endi bu tuzoqqa tushmaysiz!'])},
 fin:function(){bm9card('1980 · Fransiya, Grenobl',[['Kemada 26 qo‘y va 10 echki bor.','o'],['Kapitan necha yoshda?','q'],['97 o‘quvchidan 76 tasi sonlardan «javob» topgan','k']]);calc(['Sizlar endi bu tuzoqqa tushmaysiz!'])},
 html:"<p>🚢 1980-yilda Fransiyaning Grenobl shahridagi matematika o'qitish institutida (IREM) boshlang'ich sinf o'quvchilariga shunday masala berilgan: «Kemada 26 ta qo'y va 10 ta echki bor. Kapitan necha yoshda?»</p><p><b>97</b> o'quvchidan <b>76</b> tasi sonlarni qo'shib yoki ayirib «javob» yozgan! Keyin olima <b>Stella Baryuk</b> bu haqda «Kapitan yoshi» nomli kitob yozgan (1985). Xulosa: avval o'ylash, keyin hisoblash.</p>",
 tn:"Bu tajribani sinfingizda takrorlab ko'ring va natijani bolalar bilan muhokama qiling."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{}],start:function(){bm9card('Masala tekshiruvi',[['1. Savol nima?','q'],['2. Qaysi sonlar kerak?','k'],['3. Qaysi biri ortiqcha?','o'],['4. Nima yetishmaydi?','y']],2);calc(['Avval o‘yla — keyin hisobla'])},fin:function(){bm9card('Masala tekshiruvi',[['1. Savol nima?','q'],['2. Qaysi sonlar kerak?','k'],['3. Qaysi biri ortiqcha?','o'],['4. Nima yetishmaydi?','y']],2);calc(['Avval o‘yla — keyin hisobla'])},
 html:"<div class='memo'><ul><li>Avval <b>savolni</b> o'qing: nima so'ralyapti?</li><li>Har bir son uchun so'rang: «Bu son <b>nima haqida</b>? Savolga kerakmi?»</li><li><b>Ortiqcha</b> sonni o'chiring — u chizmaga kirmaydi.</li><li>Kerakli son yo'q bo'lsa — «<b>ma'lumot yetarli emas</b>» deng, taxmin qilmang.</li><li>Ba'zan javob shartning o'zida yozilgan.</li><li>Savol o'zgarsa — kerakli sonlar ham o'zgaradi.</li></ul></div>",
 tn:"Keyingi darslarda har masalada 4 savollik tekshiruvni qisqa odat qiling."})
];
var PROBS=[
{t:"Bog'da 4 qator, har qatorda 5 tup daraxt. Har daraxt bo'yi 3 m. Bog'da nechta daraxt?",o:["20","60","12","9"],k:0,s:"5 · 4 = 20; bo'yi ortiqcha."},
{t:"Qutida 6 qator, har qatorda 4 tadan konfet. Har konfet 5 g. Nechta konfet bor?",o:["24","120","30","15"],k:0,s:"4 · 6 = 24; gramm ortiqcha."},
{t:"Lola 45 ta qizil, 30 ta ko'k shar oldi; har biri 2 ming. Qizil ko'kdan nechta ko'p?",o:["15","75","30","150"],k:0,s:"45 − 30 = 15; narx ortiqcha."},
{t:"Testda 30 savol. Lola 23 tasiga to'g'ri javob berdi. Nechta to'g'ri javob bergan?",o:["23","7","30","53"],k:0,s:"Javob shartda: 23."},
{t:"Kemada 26 qo'y va 10 echki. Kapitan necha yoshda?",o:["aniqlab bo'lmaydi","36","16","26"],k:0,s:"Kapitan yoshi haqida ma'lumot yo'q."},
{t:"Avtobusda 30 kishi bor edi. Bekatda bir necha kishi tushdi. Necha kishi qoldi?",o:["ma'lumot yetarli emas","29","30","0"],k:0,s:"Necha kishi tushgani aytilmagan."},
{t:"Maktabda 3 ta ikkinchi sinf. 2-A da 28, 2-B da 25 o'quvchi. 2-A da nechta ko'p?",o:["3","53","0","56"],k:0,s:"28 − 25 = 3; sinflar soni ortiqcha."},
{t:"Do'konda 4 sotuvchi. Ertalab 35 kg, kechqurun 27 kg shakar sotildi. Jami necha kg?",o:["62 kg","66 kg","8 kg","58 kg"],k:0,s:"35 + 27 = 62."},
{t:"Ali 9 yoshda. U 16 ta, ukasi 8 ta yong'oq terdi. Ikkalasi nechta tergan?",o:["24","33","8","25"],k:0,s:"16 + 8 = 24; yosh ortiqcha."},
{t:"«Nonvoyxonada 50 ta non bor edi, bir qismi sotildi. Nechta qoldi?» Qaysi ma'lumot kerak?",o:["nechta sotilgani","non narxi","nonvoylar soni","non og'irligi"],k:0,s:"50 − (sotilgan) — sotilgan son kerak."},
{t:"«Ali 20 ta marka yig'di, keyin yana yig'di. Nechta bo'ldi?» Nima yetishmaydi?",o:["keyin nechta yig'gani","marka narxi","Ali yoshi","albom rangi"],k:0,s:"20 + ? — ikkinchi son kerak."},
{t:"Sinfda 12 qiz va 14 o'g'il. O'qituvchi necha yoshda?",o:["aniqlab bo'lmaydi","26","2","24"],k:0,s:"O'qituvchi yoshi haqida ma'lumot yo'q."},
{t:"Velosipedchi soat 9 da yo'lga chiqdi. U 18 km, keyin 14 km yurdi. Jami necha km yurdi?",o:["32 km","41 km","4 km","23 km"],k:0,s:"18 + 14 = 32; vaqt ortiqcha."},
{t:"Bir qutida 7 ta qalam, qalam 3 ming so'm. 5 ta qutida nechta qalam?",o:["35","15","21","105"],k:0,s:"7 · 5 = 35; narx ortiqcha."},
{t:"Savatda olmalar bor edi. 5 tasi yeyildi. Nechta qoldi?",o:["ma'lumot yetarli emas","5","0","10"],k:0,s:"Savatda nechta bo'lgani aytilmagan."},
{t:"Ko'chada 40 ta uy, har uyda 2 qavat. Ko'chadagi 15 uy ko'k rangda. Ko'k bo'lmagan uylar nechta?",o:["25","55","80","30"],k:0,s:"40 − 15 = 25; qavatlar ortiqcha."},
{t:"Vali 3-qavatda yashaydi. U 25 ta kitobdan 9 tasini o'qidi. Nechta kitob o'qilmagan?",o:["16","34","13","22"],k:0,s:"25 − 9 = 16; qavat ortiqcha."},
{t:"Bekatda 6 ta avtobus. Har birida 10 kishi bor. Avtobuslar ko'k rangda. Jami necha kishi?",o:["60","16","4","66"],k:0,s:"10 · 6 = 60; rang ortiqcha."},
{t:"Qaysi masalani yechib BO'LMAYDI?",o:["Idishda suv bor edi, 3 l to'kildi. Necha l qoldi?","Idishda 10 l suv, 3 l to'kildi. Necha l qoldi?","5 l va 4 l suvni qo'shdik. Necha l?","Idishda 8 l suv, 2 l qo'shildi. Necha l?"],k:0,s:"Birinchisida boshlang'ich miqdor yo'q."},
{t:"Ona 36 yoshda. U 18 ta olma oldi, bolalarga 3 tadan bo'lib berdi. Nechta bolaga yetdi?",o:["6","12","15","54"],k:0,s:"18 : 3 = 6; ona yoshi ortiqcha."}
];
function PRACT_STAGE(){bm9card('Har sonni tekshiring',[['Savol nima?','q'],['Qaysi son kerak?','k'],['Qaysi son ortiqcha?','o'],['Nima yetishmaydi?','y']],2);calc(['Avval o‘yla — keyin hisobla'])}
var PREP_DATA={teach:["Ortiqcha ma'lumotni topish va o'chirish.","Yetishmaydigan ma'lumotni aniqlash va to'ldirish.","Javob shartda bo'lgan masalalar.","«Kapitan yoshi» — yechimi yo'q masalalarni tanish."],
 mist:["Shartdagi barcha sonlarni ishlatadi (ortiqchasini ham).","«Bir necha» so'zini aniq son (1) deb oladi.","Savolni o'qimay amal bajaradi (javob shartda bo'lsa ham).","«Aniqlab bo'lmaydi» javobini xato deb qo'rqadi."],
 need:["Shartlar yozilgan kartochkalar, rangli qalamlar (kerakli — yashil, ortiqcha — qizil)."],
 board:["Tekshiruv: <span class='w2'>savol → kerakli → ortiqcha → yetishmaydi</span>.","<span class='w2'>5 · 4 = 20</span> (bo'yi — ortiqcha).","<span class='w2'>30 − ? = ?</span> — yechib bo'lmaydi.","Kapitan masalasi: <span class='w2'>aniqlab bo'lmaydi</span>."]};
