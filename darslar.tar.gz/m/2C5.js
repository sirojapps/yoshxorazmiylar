var CODE='2C5',TITLE='2-sinf · 0 va 1 bilan amallar';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P7=[function(){c5Expr(['24 : 24','−','0 : 9','+','0 · 57'],null);cMsg('Har bir bo‘lakni alohida hisoblang')},
 function(){c5Expr(['1','−','0','+','0'],[0,2,4]);cMsg('24 : 24 = 1 (o‘ziga), 0 : 9 = 0, 0 · 57 = 0')},
 function(){c5Expr(['1'],[0]);cMsg('1 − 0 + 0 = <b>1</b>')}];
var P8=[function(){c5Expr(['(63 − 27)','·','0','+','58'],null);cMsg('Qavs ichini hisoblash shartmi?')},
 function(){c5Expr(['(…)','·','0','+','58'],[0,2]);cMsg('Qavsdagi son nima bo‘lsa ham — 0 ga ko‘paytirilsa, <b>0</b>!')},
 function(){c5Expr(['0','+','58','=','58'],[4]);cMsg('0 + 58 = <b>58</b>. Qavsni hisoblab vaqt yo‘qotmaymiz')}];
var STEPS=[
{h:"1 ga ko'paytirish",sum:"Har bir likopchada 1 tadan: 7 · 1 = 7. Sonni 1 ga ko'paytirsak — o'zi qoladi.",a:"m01",
 start:function(){cPlates(7,1,{lab:1});cMsg('7 ta likopcha, har birida 1 tadan')},fin:function(){cPlates(7,1,{lab:1});cMsg('1 · 7 = 7 va 7 · 1 = 7')},
 html:"<p>Har likopchada faqat <b>bitta</b> olma. Likopchalar sonini tanlang:</p>",
 btns:[["4",function(c,done){cPlates(4,1,{lab:1});cMsg('1 · 4 = <b>4</b>');mvK(done,2)}],["7",function(c,done){cPlates(7,1,{lab:1});cMsg('1 · 7 = <b>7</b>');mvK(done,2)}],["9",function(c,done){cPlates(9,1,{lab:1});cMsg('1 · 9 = <b>9</b>');mvK(done,2)}]],
 after:"<p>1 ni necha marta olsak, shuncha chiqadi: 1 · 7 = 7. O'rin almashtirsak ham: <b>7 · 1 = 7</b> — bitta likopchada 7 ta. Qoida: <b>sonni 1 ga ko'paytirsak, son o'zgarmaydi</b>.</p>",
 q:{t:"Istalgan sonni qaysi songa ko'paytirsak, o'sha sonning o'zi chiqadi?",opts:["10","2","1","0"],ok:2,why:"a · 1 = a.",hint:"1 ta likopchada 7 ta bo'lsa — nechta?",full:"Sonni 1 ga ko'paytirish — uni bir marta olish: 7 · 1 = 7. 0 ga ko'paytirsak — 0, 2 ga — ikki barobar."},
 tn:"«1 marta olish» va «bittadan olish» — ikkala holni narsada ko'rsating."},
{h:"0 ga ko'paytirish",sum:"5 ta bo'sh likopcha — 0 · 5 = 0. 5 ni 0 marta olsak — 5 · 0 = 0.",a:"m02",
 start:function(){cPlates(5,0,{lab:1});cMsg('5 ta bo‘sh likopcha')},fin:function(){cPlates(5,0,{lab:1});cMsg('0 · 5 = 0 va 5 · 0 = 0')},
 html:"<p>Likopchalar bor, lekin ular <b>bo'sh</b>. Nechta olma bor? Bosing:</p>",
 btns:[["🍽 5 ta bo'sh likopcha",function(c,done){cPlates(5,0,{lab:1});cMsg('0 + 0 + 0 + 0 + 0 = 0 · 5 = <b>0</b>');mvK(done,2)}],["🍎 7 ni 0 marta olish",function(c,done){clear();T(S.g,180,90,'7 · 0 = 0',{'font-size':34,'font-weight':800,fill:C.bad});T(S.g,180,130,'hech narsa olmadik',{'font-size':13,fill:'#5b6b7b'});cMsg('7 ni bir marta ham olmadik — <b>0</b>');mvK(done,2)}]],g2:1,
 after:"<p>Qoida: <b>istalgan sonni 0 ga ko'paytirsak — 0</b>; 0 ni istalgan songa ko'paytirsak ham — 0. 25 · 0 = 0, 0 · 100 = 0.</p>",
 q:{t:"Hisoblang: 25 · 0 + 25 · 1",opts:["25","0","50","26"],ok:0,why:"0 + 25 = 25.",hint:"25 · 0 nechchi? 25 · 1 nechchi?",full:"25 · 0 = 0, 25 · 1 = 25. 0 + 25 = 25. «50» — 0 ni ham 25 deb o'ylash, «26» — 1 ni qo'shish."},
 tn:"Bo'sh likopchalar — eng yaxshi ko'rgazma. Bolalar «nol marta» iborasini tushunsin."},
{h:"1 ga va o'ziga bo'lish",sum:"8 : 1 = 8 (bitta bolaga hammasi); 8 : 8 = 1 (har kishiga bittadan).",a:"m03",
 start:function(){cDeal(8,1,0,{who:'bola'});cMsg('8 ta konfet')},fin:function(){cDeal(8,8,8,{who:''});cMsg('8 : 8 = 1')},
 html:"<p>8 ta konfetni bo'lamiz. Kimga bo'lamiz? Tanlang:</p>",
 btns:[["1 ta bolaga",function(c,done){mvK(done,2);cDealAnim(8,1,{who:'bola',fast:1},function(){cMsg('8 : 1 = <b>8</b> — hammasi bitta bolaga')})}],["8 ta bolaga",function(c,done){mvK(done,2);cDealAnim(8,8,{fast:1},function(){cMsg('8 : 8 = <b>1</b> — har biriga bittadan')})}]],g2:1,
 after:"<p>Qoidalar: <b>sonni 1 ga bo'lsak — o'zi qoladi</b> (8 : 1 = 8). <b>Sonni o'ziga bo'lsak — 1</b> (8 : 8 = 1).</p>",
 q:{t:"36 : 36 + 36 · 1 nechaga teng?",opts:["37","36","72","1"],ok:0,why:"36 : 36 = 1, 36 · 1 = 36, 1 + 36 = 37.",hint:"36 : 36 nechchi? 36 · 1 nechchi?",full:"36 : 36 = 1 (o'ziga bo'lish), 36 · 1 = 36. 1 + 36 = 37. «72» — 36 : 36 ni ham 36 deb o'ylash."},
 tn:"Ikki qoidani adashtirmaslik uchun ikkalasini rasm bilan yonma-yon doskaga chizing."},
{h:"Nolni bo'lish",sum:"0 : 7 = 0 — konfet yo'q bo'lsa, 7 bolaga ham hech narsa tegmaydi.",a:"m04",
 start:function(){cDeal(0,7,0,{});cMsg('0 ta konfet, 7 ta bola')},fin:function(){cDeal(0,7,0,{});cMsg('0 : 7 = 0')},
 html:"<p>Konfet <b>yo'q</b>, bolalar esa 7 ta. Har biriga nechta tegadi?</p>",
 btns:[["▶ Tarqatish",function(c,done){cDeal(0,7,0,{});cMsg('Tarqatadigan narsa yo‘q: 0 : 7 = <b>0</b>');done()}]],
 after:"<p>Qoida: <b>0 ni istalgan songa bo'lsak — 0</b>. 0 : 7 = 0, chunki 0 · 7 = 0.</p>",
 q:{t:"0 : 9 + 9 : 9 nechaga teng?",opts:["0","1","9","10"],ok:1,why:"0 : 9 = 0, 9 : 9 = 1, jami 1.",hint:"Har bir bo'lishni alohida hisoblang.",full:"0 : 9 = 0, 9 : 9 = 1. 0 + 1 = 1. «9» — 0 : 9 ni 9 deb o'ylash."},
 tn:"«Bo'sh qopni bo'lish» — bolalar kulib eslab qoladi."},
{h:"Nolga bo'lib bo'lmaydi!",sum:"7 : 0 — ma'nosi yo'q: 0 ta bolaga konfet bo'lib bo'lmaydi va hech bir son · 0 = 7 bo'lmaydi.",a:"m05",
 start:function(){cDeal(7,1,0,{});clear();T(S.g,180,90,'7 : 0 = ?',{'font-size':34,'font-weight':800,fill:'#1d2b3a'});cMsg('7 ta konfet, bolalar yo‘q…')},fin:function(){clear();T(S.g,180,90,'7 : 0  — mumkin emas',{'font-size':26,'font-weight':800,fill:C.bad});cMsg('Nolga bo‘lish mumkin emas')},
 start0:0,html:"<p>7 ta konfetni <b>0 ta</b> bolaga bo'lib ko'ring. Javobni tekshirib ko'ramiz: qaysi son · 0 = 7 bo'ladi?</p>",
 btns:[["0 ?",function(c,done){c5Try(0,done)}],["1 ?",function(c,done){c5Try(1,done)}],["7 ?",function(c,done){c5Try(7,done)}]],
 after:"<p>Har qanday sonni 0 ga ko'paytirsak 0 chiqadi — 7 hech qachon chiqmaydi. Shuning uchun <b>nolga bo'lish mumkin emas</b>. Lekin <b>nolni</b> bo'lish mumkin: 0 : 7 = 0.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["7 : 0 = 0","0 · 7 = 7","7 · 1 = 1","0 : 7 = 0"],ok:3,why:"Nolni bo'lsak — 0.",hint:"Qaysi yozuvda nolni bo'lyapmiz, qaysisida nolga?",full:"7 : 0 — mumkin emas. 0 · 7 = 0 (7 emas). 7 · 1 = 7 (1 emas). Faqat 0 : 7 = 0 to'g'ri."},
 tn:"«0 : 7» va «7 : 0» ni doskada yonma-yon yozib, farqini rasm bilan ko'rsating — eng ko'p adashadigan joy."},
{h:"Tuzoq: aralash ifoda",sum:"24 : 24 − 0 : 9 + 0 · 57 = 1 − 0 + 0 = 1. Har bo'lakni qoida bilan hisoblang.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ifoda: <b>24 : 24 − 0 : 9 + 0 · 57</b>. Katta sonlar qo'rqitmasin — hammasi 0 va 1 qoidalari bilan yechiladi.</p>",
 btns:[phaser(P7)],
 after:"<p>Har bir bo'lakni qoida bilan topamiz: o'ziga bo'lish — 1, nolni bo'lish — 0, nolga ko'paytirish — 0. Keyin: 1 − 0 + 0 = 1.</p>",
 q:{t:"Hisoblang: 0 : 7 + 7 : 7 + 7 : 1",opts:["9","7","8","15"],ok:2,why:"0 + 1 + 7 = 8.",hint:"Uchta bo'lishni alohida hisoblang.",full:"0 : 7 = 0, 7 : 7 = 1, 7 : 1 = 7. 0 + 1 + 7 = 8. «15» — 0 : 7 ni 7 deb o'ylash."},
 tn:"Har bo'lak ustiga natijasini kichik qilib yozdiring — xato kamayadi."},
{h:"Tuzoq: qavsni hisoblash shart emas",sum:"(63 − 27) · 0 + 58 = 0 + 58 = 58 — qavsdagi son 0 ga ko'paytiriladi.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Ifoda: <b>(63 − 27) · 0 + 58</b>. Ko'pchilik avval 63 − 27 ni hisoblashga tushadi. Lekin ayyorroq yo'l bor:</p>",
 btns:[phaser(P8)],
 after:"<p>Qavs ichida nima bo'lsa ham, <b>0 ga ko'paytirilsa — 0</b>. Shuning uchun javob darhol: 0 + 58 = 58. Lekin <b>1 ga</b> ko'paytirilsa, qavsni hisoblash kerak: (82 − 45) · 1 = 37.</p>",
 q:{t:"□ · 9 = 9 va △ · 9 = 0. □ + △ nechaga teng?",opts:["0","18","1","9"],ok:2,why:"□ = 1, △ = 0, 1 + 0 = 1.",hint:"Qaysi son · 9 = 9? Qaysi son · 9 = 0?",full:"□ · 9 = 9 → □ = 1. △ · 9 = 0 → △ = 0. □ + △ = 1. «9» — □ ni 9 deb o'ylash."},
 tn:"«Avval qarab chiq, keyin hisobla» odatini o'rgating — olimpiada masalalarida juda foydali."},
{h:"Bilasizmi? Nol qayerdan kelgan",sum:"Hind olimi Braxmagupta 628-yilda nol bilan amallar qoidalarini yozgan; al-Xorazmiy ularni dunyoga tanitgan.",a:"m08",
 start:function(){clear('#f6ead0');T(S.g,180,95,'0',{'font-size':90,'font-weight':800,fill:'#6b3d12'});T(S.g,180,140,'628-yil · Braxmagupta',{'font-size':13,fill:'#6b3d12'});cMsg('Nolning tarixi')},fin:function(){STEPS[7].start()},
 html:"<p>📜 Qadimgi rimliklar va misrliklarda <b>nol</b> yo'q edi. Hind olimi <b>Braxmagupta</b> 628-yilda nolni haqiqiy son deb, u bilan qo'shish, ayirish va ko'paytirish qoidalarini yozgan: «sonni nolga ko'paytirsak — nol».</p><p>⭐ Vatandoshimiz <b>al-Xorazmiy</b> nol bilan yozish usulini o'z kitobi orqali dunyoga tarqatgan.</p>",
 tn:"Rim raqamlarida 0 yo'qligini eslating (2A1)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){cPlates(5,0,{lab:1});cMsg('a · 0 = 0,  a · 1 = a')},fin:function(){STEPS[8].start()},
 html:"<div class='memo'><ul><li><b>a · 1 = a</b>, 1 · a = a: 7 · 1 = 7.</li><li><b>a · 0 = 0</b>, 0 · a = 0: 25 · 0 = 0.</li><li><b>a : 1 = a</b>: 8 : 1 = 8.</li><li><b>a : a = 1</b>: 8 : 8 = 1.</li><li><b>0 : a = 0</b>: 0 : 7 = 0.</li><li><b>a : 0 — mumkin emas!</b></li><li>(…) · 0 — qavsni hisoblash shart emas: natija 0.</li></ul></div>",
 tn:"Kartochkani sinf devoriga osib qo'ying — butun yil davomida kerak bo'ladi."}
];
function c5Try(n,done){S.tr=S.tr||{};S.tr[n]=1;var k=Object.keys(S.tr).length;clear();T(S.g,180,80,n+' · 0 = 0 ≠ 7',{'font-size':30,'font-weight':800,fill:C.bad});if(k>=2){T(S.g,180,125,'Hech bir son to\u2018g\u2018ri kelmaydi!',{'font-size':15,'font-weight':800,fill:C.bad});cMsg('Har qanday son · 0 = 0. Demak 7 : 0 — <b>mumkin emas</b>');done()}else cMsg(n+' to\u2018g\u2018ri kelmadi. Boshqasini sinang')}
function c5Expr(parts,hl){clear();var n=parts.length,w=Math.min(68,320/n),x0=180-(n-1)*w/2;parts.forEach(function(p,i){var on=hl&&hl.indexOf(i)>=0,op=/^[−+·=:]$/.test(p);T(S.g,x0+i*w,95,p,{'font-size':op?24:(p.length>6?15:22),'font-weight':800,fill:op?'#9aa8b6':(on?C.ok:'#1d2b3a')})})}
var PROBS=[
{t:"9 · 1 nechaga teng?",o:["9","1","10","0"],k:0,s:"Sonni 1 ga ko'paytirsak — o'zi."},
{t:"6 · 0 nechaga teng?",o:["0","6","1","60"],k:0,s:"Sonni 0 ga ko'paytirsak — 0."},
{t:"15 : 15 nechaga teng?",o:["1","15","0","30"],k:0,s:"Sonni o'ziga bo'lsak — 1."},
{t:"0 : 4 nechaga teng?",o:["0","4","1","mumkin emas"],k:0,s:"Nolni bo'lsak — 0."},
{t:"Hisoblang: 0 : 7 + 7 : 7 + 7 : 1",o:["8","9","7","15"],k:0,s:"0 + 1 + 7 = 8."},
{t:"Hisoblang: 24 : 24 − 0 : 9 + 0 · 57",o:["1","25","0","57"],k:0,s:"1 − 0 + 0 = 1."},
{t:"Hisoblang: 36 : 36 + 215 · 0 + 36 · 1",o:["37","36","252","1"],k:0,s:"1 + 0 + 36 = 37."},
{t:"Hisoblang: (82 − 45) · 1 + 48",o:["85","37","84","75"],k:0,s:"37 · 1 = 37, 37 + 48 = 85."},
{t:"Hisoblang: (63 − 27) · 0 + 58",o:["58","36","0","94"],k:0,s:"Qavs · 0 = 0, 0 + 58 = 58."},
{t:"Hisoblang: 1 · 9 + 0 · 9 + 9 · 0 + 9 : 9",o:["10","9","1","19"],k:0,s:"9 + 0 + 0 + 1 = 10."},
{t:"Qaysi yozuv to'g'ri?",o:["47 · 1 > 47 · 0","47 · 0 = 47","47 : 1 = 1","0 : 47 > 0"],k:0,s:"47 > 0 — to'g'ri."},
{t:"Qaysi tenglik to'g'ri?",o:["0 : 7 = 0","7 : 0 = 0","0 · 7 = 7","7 · 1 = 1"],k:0,s:"Nolni bo'lsak — 0."},
{t:"□ · 9 = 9 va △ · 9 = 0. □ + △ nechaga teng?",o:["1","0","18","9"],k:0,s:"□ = 1, △ = 0."},
{t:"Qaysi ifodaning qiymati 0 ga teng EMAS?",o:["5 : 5","0 · 7","9 − 9","0 : 5"],k:0,s:"5 : 5 = 1."},
{t:"Tenglamalarni yeching va ildizlarini qo'shing: x : 8 = 1, a : 5 = 0, 9 : y = 9",o:["9","18","8","14"],k:0,s:"x = 8, a = 0, y = 1: 8 + 0 + 1 = 9."},
{t:"Istalgan sonni qaysi songa ko'paytirsak, o'sha sonning o'zi chiqadi?",o:["1","0","2","10"],k:0,s:"a · 1 = a."},
{t:"Hisoblang: 25 · 0 + 25 · 1",o:["25","0","50","26"],k:0,s:"0 + 25 = 25."},
{t:"Hisoblang: 100 · 0 + 0 : 100 + 100 : 100",o:["1","100","0","201"],k:0,s:"0 + 0 + 1 = 1."},
{t:"Qaysi amalni bajarib bo'lmaydi?",o:["5 : 0","0 : 5","5 · 0","0 · 5"],k:0,s:"Nolga bo'lish mumkin emas."},
{t:"(□ − 4) · 0 + □ = 12 bo'lsa, □ nechaga teng?",o:["12","4","16","0"],k:0,s:"(…) · 0 = 0, demak □ = 12."}
];
function PRACT_STAGE(){cPlates(5,0,{lab:1});cMsg('a · 0 = 0 · a : 1 = a · a : a = 1 · 0 : a = 0')}
var PREP_DATA={teach:["1 ga ko'paytirish va bo'lish; o'ziga bo'lish.","0 ga ko'paytirish; nolni bo'lish.","Nolga bo'lib bo'lmasligi va uning sababi.","Tuzoqlar: aralash ifodalar, qavs · 0."],
 mist:["7 · 0 ni 7 deydi.","8 : 8 ni 0 deydi, 8 : 1 ni 1 deydi.","7 : 0 ni 0 deb yozadi.","(63 − 27) · 0 ni hisoblab vaqt yo'qotadi yoki 36 deb yozadi."],
 need:["Bo'sh likopchalar, konfet/tugma."],
 board:["<span class='w2'>a · 1 = a</span>, <span class='w2'>a · 0 = 0</span>.","<span class='w2'>a : 1 = a</span>, <span class='w2'>a : a = 1</span>.","<span class='w2'>0 : a = 0</span>; <span class='w2'>a : 0</span> — mumkin emas.","<span class='w2'>(63 − 27) · 0 + 58 = 58</span>."]};
