var CODE='4J17',TITLE="4-sinf · Simmetriya, burish, oynadagi aks";
function q17Axis(x1,y1,x2,y2){E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'6 4'},S.g)}
var P1=[function(){clear();k4Glyph(70,80,'F','',C.blue,64);j2Msg("Mana «F» harfi. Uni avval <b>vertikal</b> oynada, keyin <b>gorizontal</b> oynada aks ettiramiz.")},
 function(){clear();k4Glyph(70,80,'F','',C.blue,64);q17Axis(130,20,130,150);k4Glyph(190,80,'F','scale(-1,1)','#e07a2f',64);j2Msg("1-oyna (vertikal): F chapga qaradi.")},
 function(){clear();k4Glyph(70,80,'F','',C.blue,64);q17Axis(130,20,130,150);k4Glyph(190,80,'F','scale(-1,1)','#e07a2f',64);q17Axis(255,128,345,128);k4Glyph(300,80,'F','scale(-1,-1)',C.ok,64);T(S.g,70,160,'asl',{'font-size':11,'font-weight':800});T(S.g,190,160,'1-oyna',{'font-size':11,'font-weight':800});T(S.g,300,160,'2-oyna (yotiq)',{'font-size':11,'font-weight':800});j2Msg("2-oyna (gorizontal): natija — asl F ning <b>180° ga burilgani</b>!")}];
var P3=[function(){clear();k4Glyph(110,70,'0 1 8','',C.blue,34);k4Glyph(260,70,'6 ↔ 9','',C.bad,34);j2Msg("180° ga burilganda o'zgarmaydigan raqamlar: 0, 1, 8. 6 va 9 bir-biriga aylanadi.")},
 function(){clear();k4Glyph(100,80,'986','',C.blue,52);k4Glyph(260,80,'986','rotate(180)',C.ok,52);j2Msg("986 ni 180° ga bursak: raqamlar tartibi teskari bo'ladi va har biri buriladi: 6→9, 8→8, 9→6 → yana <b>986</b>!")}];
function q17Billiard(step){clear();var g=S.g;E('rect',{x:20,y:20,width:320,height:130,rx:6,fill:'#e6f4ea',stroke:'#2e7d4f','stroke-width':4},g);
 E('circle',{cx:70,cy:60,r:9,fill:'#fff',stroke:'#333'},g);T(g,70,45,'A',{'font-size':12,'font-weight':900});E('circle',{cx:290,cy:60,r:9,fill:C.bad},g);T(g,290,45,'B',{'font-size':12,'font-weight':900});
 if(step>=1){E('polyline',{points:'70,60 180,150 290,60',fill:'none',stroke:C.blue,'stroke-width':3},g);T(g,150,138,'∠',{'font-size':14,fill:C.blue});T(g,210,138,'∠',{'font-size':14,fill:C.blue})}
 if(step>=2){E('line',{x1:180,y1:150,x2:290,y2:240,stroke:'#999','stroke-dasharray':'5 4'},g);T(g,250,100,'kirish = qaytish',{'font-size':12,'font-weight':800,fill:C.ok})}}
var STEPS=[
{h:"Ikki oyna = burish",sum:"Vertikal, keyin gorizontal o'qqa aks = 180° ga burish.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>3-sinfda bitta oynani o'rgandik. Ikki oyna ketma-ket qo'yilsa nima bo'ladi?</p>",
 btns:[phaser(P1)],
 after:"<p>Ikki <b>perpendikulyar</b> o'qqa ketma-ket aks ettirish — 180° ga burish bilan bir xil. Bir xil o'qqa ikki marta aks ettirsak esa, shakl joyiga qaytadi.</p>",
 q:{t:"Shakl bir xil o'qqa nisbatan ikki marta aks ettirildi. Natija?",opts:["180° ga buriladi","Shakl joyiga qaytadi","90° ga buriladi","Gorizontal aks bo'ladi"],ok:1,why:"Oynadagi aksning aksi — asl shakl.",hint:"Oynaga qaragan odamning aksi yana oynada aks etsa…",full:"Birinchi aks shaklni teskari qiladi, ikkinchisi xuddi shu o'q bo'yicha yana teskari qiladi — shakl asl holiga qaytadi. 180° faqat ikki xil (perpendikulyar) o'q bo'lganda chiqadi."},
 tn:"Ikki ko'zgu (yoki telefon ekrani) bilan sinab ko'ring: burchakka qo'yilgan ikki oynada narsa «to'g'ri» ko'rinadi."},
{h:"Markaziy simmetriya: 180° da o'zgarmas",sum:"N, S, Z, H, O, X, I — 180° da o'zgarmaydi. SOS ham.",a:"m02",
 start:function(){clear();['N','A','T','E'].forEach(function(c,i){k4Glyph(60+i*80,80,c,'',C.blue,52)});j2Msg("Qaysi harf 180° ga burilganda o'zgarmaydi? Tanlang.")},
 fin:function(){clear();k4Glyph(110,80,'N','',C.blue,60);k4Glyph(250,80,'N','rotate(180)',C.ok,60);j2Msg("N ni 180° ga bursak — yana N. Bu <b>markaziy simmetriya</b>.")},
 html:"<p>Ba'zi harflarning simmetriya o'qi yo'q, lekin ular 180° ga burilganda o'zgarmaydi. Qaysi biri?</p>",
 btns:j2Pick(["N","A","T","E"],0,function(){clear();k4Glyph(110,80,'N','',C.blue,60);k4Glyph(250,80,'N','rotate(180)',C.ok,60);j2Msg("To'g'ri! N — 180° da o'zgarmaydi.")},function(i){clear();var c=['N','A','T','E'][i];k4Glyph(110,80,c,'',C.blue,60);k4Glyph(250,80,c,'rotate(180)',C.bad,60);j2Msg(c+" teskari bo'lib qoldi.")}),g2:1,
 after:"<p>180° da o'zgarmaydigan harflar: <b>H, I, N, O, S, X, Z</b>. Ulardan N, S, Z ning simmetriya o'qi yo'q — faqat markaziy simmetriya bor.</p>",
 q:{t:"Qaysi so'z 180° ga burilganda o'zgarmaydi?",opts:["OTA","SOS","MAMA","ZAR"],ok:1,why:"S → S, O → O, tartib teskari: S O S.",hint:"Burilganda harflar tartibi teskari bo'ladi va har harf buriladi.",full:"SOS: tartib teskari — S, O, S, har harf 180° da o'zgarmaydi → SOS. OTA: T teskari bo'ladi. MAMA: M → W. ZAR: R teskari."},
 tn:"Bolalar harflarni qog'ozga yozib, varaqni 180° ga burib tekshirsin."},
{h:"Burilganda o'zgarmas sonlar",sum:"0, 1, 8 o'zgarmaydi, 6 ↔ 9. 986 — o'zgarmas eng katta uch xonali son.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Elektron soatdagi kabi raqamlar uchun ham qoida bor. Qaysi sonlar 180° da o'zgarmaydi?</p>",
 btns:[phaser(P3)],
 after:"<p>Qoida: birinchi va oxirgi raqam «juftlashgan» bo'lsin (1–1, 8–8, 6–9, 9–6), o'rtadagi raqam o'zi o'zgarmas bo'lsin (0, 1, 8).</p>",
 q:{t:"180° ga burilganda o'zgarmaydigan ikki xonali sonlar nechta?",opts:["3","4","5","9"],ok:1,why:"11, 69, 88, 96.",hint:"Birinchi raqam 0 bo'lolmaydi. Har birinchi raqamga oxirgisi qanday bo'lishi kerak?",full:"Birinchi raqam 1, 6, 8 yoki 9 (0 bo'lmaydi). Oxirgisi uning juftlashgani: 11, 69, 88, 96 — 4 ta. 10 burilsa 01 bo'ladi — ikki xonali emas."},
 tn:"Raqamli kartochkalarni teskari ag'darib o'ynang: qaysilari «sehrli»?"},
{h:"Burilish tartibi",sum:"Kvadrat 90° da, teng tomonli uchburchak 120° da o'ziga tushadi; oltiburchak 6 marta.",a:"m04",
 start:function(){clear();var g=S.g;E('rect',{x:30,y:40,width:80,height:80,fill:'#eaf3fb',stroke:C.blue,'stroke-width':3},g);E('polygon',{points:'180,35 225,120 135,120',fill:'#fff1df',stroke:'#e07a2f','stroke-width':3},g);E('polygon',{points:'290,40 325,60 325,100 290,120 255,100 255,60',fill:'#e6f6ee',stroke:C.ok,'stroke-width':3},g);
  T(g,70,145,'kvadrat',{'font-size':11,'font-weight':800});T(g,180,145,'uchburchak',{'font-size':11,'font-weight':800});T(g,290,145,'oltiburchak',{'font-size':11,'font-weight':800});j2Msg("Teng tomonli uchburchak necha gradusga burilganda birinchi marta o'ziga tushadi?")},
 fin:function(){clear();var g=S.g;E('polygon',{points:'180,35 225,120 135,120',fill:'#fff1df',stroke:'#e07a2f','stroke-width':3},g);T(g,180,150,'360° : 3 = 120°',{'font-size':16,'font-weight':900,fill:C.ok});j2Msg("Uchburchak 3 marta o'ziga tushadi: 360° : 3 = <b>120°</b>.")},
 html:"<p>Shakl to'liq aylanishda (360°) o'ziga necha marta tushsa — shuncha teng bo'lakka bo'linadi. Teng tomonli uchburchak uchun burchakni tanlang.</p>",
 btns:j2Pick(["60°","90°","120°","180°"],2,function(){clear();var g=S.g;E('polygon',{points:'180,35 225,120 135,120',fill:'#fff1df',stroke:'#e07a2f','stroke-width':3},g);T(g,180,150,'360° : 3 = 120°',{'font-size':16,'font-weight':900,fill:C.ok});j2Msg("To'g'ri! 360° : 3 = 120°.")},function(i){j2Msg(["60° da uchi pastga qaraydi.","90° — bu kvadrat uchun.","","180° da uchburchak teskari bo'ladi."][i])}),g2:1,
 after:"<p>Burilish burchagi = 360° : (o'ziga tushish soni). Kvadrat — 4 marta, 90°. Uchburchak — 3 marta, 120°. Muntazam oltiburchak — 6 marta, 60°.</p>",
 q:{t:"Muntazam oltiburchak to'liq aylanishda o'ziga necha marta tushadi?",opts:["3","6","12","2"],ok:1,why:"6 ta teng tomon — har 60° da.",hint:"Nechta bir xil uchi bor?",full:"Muntazam oltiburchakning 6 ta bir xil uchi bor; har 60° burilishda (360° : 6) u o'ziga tushadi — jami 6 marta (360° ni ham hisoblaganda)."},
 tn:"Qog'ozdan kesilgan shaklni bulavka bilan markazidan qadab aylantiring."},
{h:"O'qi yo'q, lekin burilganda o'zgarmas",sum:"Parallelogramm (to'g'ri burchaksiz) — o'qi yo'q, 180° da o'ziga tushadi.",a:"m05",
 start:function(){clear();var g=S.g;E('polygon',{points:'40,120 90,50 200,50 150,120',fill:'#eaf3fb',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:120,cy:85,r:4,fill:C.bad},g);T(g,270,80,'o\'q yo\'q',{'font-size':14,'font-weight':800,fill:C.bad});T(g,270,104,'180° → o\'zi ✓',{'font-size':14,'font-weight':800,fill:C.ok});j2Msg("Parallelogrammni markazi atrofida 180° ga buring — o'ziga tushadi. Lekin buklasangiz, yarmlari ustma-ust tushmaydi.")},
 fin:function(){clear();var g=S.g;E('polygon',{points:'40,120 90,50 200,50 150,120',fill:'#eaf3fb',stroke:C.blue,'stroke-width':3},g);E('circle',{cx:120,cy:85,r:4,fill:C.bad},g);T(g,270,80,'o\'q yo\'q',{'font-size':14,'font-weight':800,fill:C.bad});T(g,270,104,'180° → o\'zi ✓',{'font-size':14,'font-weight':800,fill:C.ok});j2Msg("Simmetriyaning ikki turi: <b>o'q</b> (buklash) va <b>markaziy</b> (burish).")},
 html:"<p>Simmetriya o'qi yo'q, lekin 180° da o'ziga tushadigan shakllar bor. Diagonal bo'yicha buklab ko'rsangiz ham yarmlari mos kelmaydi.</p>",
 btns:[["🔄 180° ga burib ko'rdim",function(c,done){done()}]],
 after:"<p>Kvadrat, to'g'ri to'rtburchak, romb, doira — ikkala simmetriyaga ham ega. Teng yonli trapetsiya va teng yonli uchburchak — faqat o'q. Parallelogramm, S, N, Z — faqat markaziy.</p>",
 q:{t:"Qaysi harfda simmetriya o'qi yo'q, lekin 180° da o'zgarmaydi?",opts:["H","Z","A","E"],ok:1,why:"Z ni buklab bo'lmaydi, lekin 180° da o'zgarmaydi.",hint:"H ning o'qlari bor. A va E 180° da teskari bo'ladi.",full:"Z: hech bir buklashda yarmlari mos kelmaydi, ammo 180° da yana Z. H ning ikkita o'qi bor. A va E burilsa teskari bo'ladi."},
 tn:"Parallelogrammni qog'ozdan kesib, avval buklashga, keyin burishga urinib ko'rsin."},
{h:"Billiard: kirish = qaytish",sum:"To'p devorga qanday burchakda urilsa, xuddi shunday burchakda qaytadi — oyna qoidasi.",a:"m06",
 start:function(){q17Billiard(0);j2Msg("Oq to'pni (A) devorga urib, qizil to'pga (B) tegizish kerak. Qayerga urish kerak?")},
 fin:function(){q17Billiard(2);j2Msg("Devor — oyna: B ning devordagi aksini topib, A dan to'g'ri chiziq o'tkazamiz. Kirish burchagi = qaytish burchagi.")},
 html:"<p>Billiard to'pi, yorug'lik nuri, devorga tashlangan to'p — hammasi bir qoidaga bo'ysunadi. Devorning qaysi nuqtasiga urish kerak?</p>",
 btns:j2Pick(["B ga yaqin joyga","A ga yaqin joyga","A va B ning o'rtasiga"],2,function(){q17Billiard(2);j2Msg("To'g'ri! A va B devordan bir xil uzoqlikda — o'rtasiga uramiz.")},function(i){q17Billiard(0);j2Msg("Burchaklar teng bo'lishi kerak. A va B devordan bir xil uzoqlikda turibdi.")}),
 after:"<p>Kirish burchagi qaytish burchagiga teng. Aks usuli bilan eng qisqa yo'l ham topiladi: «daryodan suv olib uyga qaytish» masalasi xuddi shunday yechiladi.</p>",
 q:{t:"To'p devorga 30° burchak ostida urildi. Qanday burchak ostida qaytadi?",opts:["60°","30°","90°","150°"],ok:1,why:"Kirish burchagi = qaytish burchagi.",hint:"Oyna qoidasi.",full:"Devorga urilgan to'p xuddi oynadagi nur kabi qaytadi: kirish burchagi qaytish burchagiga teng — 30°."},
 tn:"Koptokni devorga turli burchakda urib, qaytish yo'nalishini ko'rsating."},
{h:"Bilasizmi? Registon simmetriyasi",sum:"Samarqanddagi Registon: Ulug'bek va Sherdor madrasalari maydon o'qiga nisbatan bir-biriga qaragan.",a:"m07",
 start:function(){j2Lines([["🕌 ┃ 🕌",C.blue,30],["Ulug'bek ┃ Sherdor",null,15]]);j2Msg("Samarqand, Registon maydoni")},fin:function(){j2Lines([["🕌 ┃ 🕌",C.blue,30],["Ulug'bek ┃ Sherdor",null,15]]);j2Msg("Samarqand, Registon maydoni")},
 html:"<p>🕌 Samarqanddagi <b>Registon</b> maydonida Ulug'bek madrasasi (XV asr) va Sherdor madrasasi (XVII asr) bir-biriga qarama-qarshi qurilgan — maydon o'qiga nisbatan deyarli simmetrik. O'rtada Tillakori madrasasi turadi.</p><p>Sharq naqqoshlari girih naqshlarida burilish simmetriyasini ko'p ishlatgan: 5, 6, 8, 10 va 12 nurli yulduzlar.</p>",
 btns:[["🕌 Qiziq!",function(c,done){done()}]],
 tn:"Registon yoki boshqa yodgorlik rasmini ko'rsatib, simmetriya o'qini topishni so'rang."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["2 oyna = 180°",C.blue,26]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["2 oyna = 180°",C.blue,26]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Ikki perpendikulyar oyna = 180° ga burish. Bir oyna ikki marta = joyiga qaytish.</li><li>180° da o'zgarmas harflar: H, I, N, O, S, X, Z. Raqamlar: 0, 1, 8; 6 ↔ 9.</li><li>Burish burchagi = 360° : o'ziga tushish soni (kvadrat 90°, uchburchak 120°).</li><li>O'q yo'q, lekin markaziy simmetriya bor: parallelogramm, N, S, Z.</li><li>Kirish burchagi = qaytish burchagi (billiard, oyna).</li><li>Oynadagi soat: 12:00 dan ayiring (2:30 → 9:30).</li></ul></div>",
 tn:"Uyga: o'z ismini oynaga yozib ko'rish va 180° da o'zgarmaydigan so'zlar topish."}
];
var PROBS=[
{t:"Shakl avval vertikal, keyin gorizontal o'qqa nisbatan aks ettirildi. Natija qaysi harakatga teng?",o:["180° ga burish","90° ga burish","Hech narsa o'zgarmaydi","Vertikal aks"],k:0,s:"Ikki perpendikulyar aks = 180°."},
{t:"Shakl bir xil o'qqa nisbatan ikki marta aks ettirildi. Natija?",o:["Shakl joyiga qaytadi","180° ga buriladi","90° ga buriladi","Gorizontal aks bo'ladi"],k:0,s:"Aksning aksi — asl shakl."},
{t:"Qaysi harf 180° da o'zgarmaydi?",o:["N","A","T","E"],k:0,s:"N → N."},
{t:"Qaysi so'z 180° ga burilganda o'zgarmaydi?",o:["SOS","OTA","MAMA","ZAR"],k:0,s:"S, O, S — tartib teskari, harflar o'zgarmas."},
{t:"180° ga burilganda o'zgarmaydigan ikki xonali sonlar nechta?",o:["4","3","5","9"],k:0,s:"11, 69, 88, 96."},
{t:"180° ga burilganda o'zgarmaydigan eng katta uch xonali son?",o:["986","996","989","999"],k:0,s:"Chetlari 9–6, o'rtasi 8."},
{t:"86 soni 180° ga burilsa, qaysi son ko'rinadi?",o:["98","89","68","86"],k:0,s:"Tartib teskari: 6 → 9 birinchi, 8 → 8."},
{t:"Muntazam oltiburchak to'liq aylanishda o'ziga necha marta tushadi?",o:["6","3","12","2"],k:0,s:"Har 60° da."},
{t:"Kvadrat necha gradusga burilganda birinchi marta o'ziga tushadi?",o:["90°","180°","45°","360°"],k:0,s:"360° : 4."},
{t:"Teng tomonli uchburchak necha gradusga burilganda birinchi marta o'ziga tushadi?",o:["120°","60°","90°","180°"],k:0,s:"360° : 3."},
{t:"Qaysi harfda simmetriya o'qi yo'q, lekin 180° da o'zgarmaydi?",o:["Z","H","A","E"],k:0,s:"Z — faqat markaziy simmetriya."},
{t:"Qaysi shaklda simmetriya o'qi yo'q, lekin 180° da o'ziga tushadi?",o:["Parallelogramm (to'g'ri burchaksiz, romb emas)","Romb","Teng yonli trapetsiya","To'g'ri to'rtburchak"],k:0,s:"Parallelogramm — faqat markaziy simmetriya."},
{t:"Kvadratning nechta simmetriya o'qi bor?",o:["4","2","8","1"],k:0,s:"2 diagonal + 2 o'rta chiziq."},
{t:"To'g'ri to'rtburchakning (kvadrat emas) nechta simmetriya o'qi bor?",o:["2","4","1","0"],k:0,s:"Faqat o'rta chiziqlar; diagonallar emas."},
{t:"Doiraning nechta simmetriya o'qi bor?",o:["Cheksiz ko'p","4","2","1"],k:0,s:"Har diametr — o'q."},
{t:"Billiard to'pi devorga 30° burchak ostida urildi. Qanday burchak ostida qaytadi?",o:["30°","60°","90°","150°"],k:0,s:"Kirish = qaytish."},
{t:"Oynada strelkali soat 3:00 ni ko'rsatyapti. Aslida soat necha?",o:["9:00","3:00","6:00","12:00"],k:0,s:"12:00 − 3:00 = 9:00."},
{t:"Oynada soat 2:30 ko'rinyapti. Aslida soat necha?",o:["9:30","2:30","10:30","3:30"],k:0,s:"12:00 − 2:30 = 9:30."},
{t:"Katakli tekislikda (2; 3) nuqta x = 5 vertikal to'g'ri chiziqqa nisbatan aks ettirildi. Yangi nuqta?",o:["(8; 3)","(2; 7)","(3; 2)","(7; 3)"],k:0,s:"2 dan 5 gacha 3 katak, yana 3 katak: x = 8."},
{t:"Shakl soat yo'nalishida 90° ga ikki marta burildi. Natija?",o:["180° ga burish","Joyiga qaytdi","Oynadagi aks","90° teskari burish"],k:0,s:"90° + 90° = 180°."}
];
function PRACT_STAGE(){clear();k4Glyph(100,80,'F','',C.blue,56);k4Glyph(260,80,'F','rotate(180)',C.ok,56)}
var PREP_DATA={teach:["Ikki oyna = burish.","Markaziy simmetriya: harflar va raqamlar.","Burilish tartibi: 360° : n.","Billiard qoidasi: kirish = qaytish."],
 mist:["Burishni oynadagi aks bilan chalkashtiradi.","Burilgan sonda raqamlar tartibi teskari bo'lishini unutadi (86 → 98).","To'g'ri to'rtburchak diagonalini o'q deb o'ylaydi.","Oynadagi soatni 6:00 dan ayiradi."],
 need:["Ikkita kichik ko'zgu, qog'oz shakllar, bulavka.","Harf va raqam kartochkalari."],
 board:["<span class='w2'>F → (vertikal) → (gorizontal) = 180°</span>.","<span class='w2'>986 ↻ 180° = 986</span>.","<span class='w2'>360° : 3 = 120°</span>.","<span class='w2'>12:00 − 2:30 = 9:30</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
