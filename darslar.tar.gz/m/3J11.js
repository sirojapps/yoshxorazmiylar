var CODE='3J11',TITLE="3-sinf · Nechta usul bilan? (kombinatorika)";
function j11Out(n){var H=['','🔴 qizil','🔵 ko‘k','🟢 yashil'],R=[['⚫ qora'],['👖 jinsi']],k=0;R.forEach(function(r,i){for(var j=1;j<=3;j++){k++;r.push(k<=n?String(k):'')}});var f={};for(var q=0;q<n;q++){f[(1+Math.floor(q/3))+','+(1+q%3)]='#e6f6ee'}
 j3Tab([H].concat(R),{hr:1,hc:1,cw:80,ch:40,fs:14,fill:f,y0:20})}
var P1=[function(){j11Out(0);j3Msg('3 ta ko‘ylak va 2 ta shim. Nechta xil kiyinish mumkin?')},function(){j11Out(3);j3Msg('Qora shim bilan: 3 xil')},function(){j11Out(6);j3Msg('Jinsi bilan yana 3 xil. Jami: 2 · 3 = <b>6</b>')}];
function j11Hand(all){clear();var g=S.g,N=['A','B','C','D','E'],pts=[];for(var i=0;i<5;i++){var a=-Math.PI/2+i*2*Math.PI/5;pts.push([180+62*Math.cos(a),86+62*Math.sin(a)])}
 var k=0;for(var p=0;p<5;p++)for(var q=p+1;q<5;q++){if(all||p===0){E('line',{x1:pts[p][0],y1:pts[p][1],x2:pts[q][0],y2:pts[q][1],stroke:p===0?C.bad:'#4f86d9','stroke-width':2},g);k++}}
 pts.forEach(function(P,i){E('circle',{cx:P[0],cy:P[1],r:15,fill:'#ffe0bd',stroke:C.line,'stroke-width':1.6},g);T(g,P[0],P[1]+5,N[i],{'font-size':14,'font-weight':800,fill:'#1d2b3a'})});T(g,320,90,k+' ta',{'font-size':15,'font-weight':800,fill:C.blue})}
function j11Road(){clear();var g=S.g,A=[40,90],B=[180,90],Cc=[320,90];[[-34,'#e05a5a'],[0,'#e05a5a'],[34,'#e05a5a']].forEach(function(d){E('path',{d:'M40,90 Q110,'+(90+d[0]*1.6)+' 180,90',fill:'none',stroke:d[1],'stroke-width':3},g)});
 [[-28,'#4f86d9'],[28,'#4f86d9']].forEach(function(d){E('path',{d:'M180,90 Q250,'+(90+d[0]*1.6)+' 320,90',fill:'none',stroke:d[1],'stroke-width':3},g)});
 E('path',{d:'M40,90 Q180,-20 320,90',fill:'none',stroke:'#1e8e5a','stroke-width':3,'stroke-dasharray':'7 4'},g);
 [[A,'A'],[B,'B'],[Cc,'C']].forEach(function(z){E('circle',{cx:z[0][0],cy:z[0][1],r:15,fill:'#ffe08a',stroke:C.line,'stroke-width':1.6},g);T(g,z[0][0],z[0][1]+5,z[1],{'font-size':14,'font-weight':800,fill:'#1d2b3a'})});
 T(g,110,160,'3 yo‘l',{'font-size':13,'font-weight':800,fill:'#e05a5a'});T(g,250,160,'2 yo‘l',{'font-size':13,'font-weight':800,fill:'#4f86d9'});T(g,180,30,'to‘g‘ri yo‘l',{'font-size':12,'font-weight':800,fill:'#1e8e5a'})}
var STEPS=[
{h:"Kiyinish usullari: jadval",sum:"Har ko'ylakni har shim bilan juftlaymiz: 3 · 2 = 6 xil.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Malikada 3 ta ko'ylak va 2 ta shim bor. Nechta xil kiyinishi mumkin? Jadvalni tugma bilan to'ldiring — har katak bitta usul.</p>",
 btns:[phaser(P1)],
 after:"<p><b>Ko'paytirish qoidasi</b>: birinchi narsani 3 usulda, ikkinchisini 2 usulda tanlasak, juftliklar 3 · 2 = <b>6</b>. Jadval hech birini tushirib qoldirmaydi va takrorlamaydi. Xato: 3 + 2 = 5 deb qo'shish.</p>",
 q:{t:"Kafeda 4 xil somsa va 3 xil choy bor. Bitta somsa va bitta choyni necha xil usulda tanlash mumkin?",opts:["7","12","16","9"],ok:1,why:"4 · 3 = 12.",hint:"Har bir somsa bilan nechta choy juftlashadi?",full:"Har somsaga 3 xil choy: 4 · 3 = 12 juftlik. «7» — qo'shish xatosi: tanlov «va» bo'lsa — ko'paytiramiz."},
 tn:"Qog'ozdan kiyim kesib, doskaga yopishtiring; bolalar juftliklarni jadvalga yozsin."},
{h:"Raqamlardan sonlar",sum:"1, 2, 3 dan takrorsiz ikki xonali sonlar: o'nliklar 3 usul, birliklar 2 usul → 6. Takrorlansa — 3 · 3 = 9.",a:"m02",
 start:function(){j3Lines(['Raqamlar: 1, 2, 3','Ikki xonali son, raqamlar takrorlanmaydi','__ __'],{fs:17,lh:34});j3Msg('Nechta shunday son bor?')},fin:function(){j3Lines(['12, 13','21, 23','31, 32'],{fs:20,lh:34});j3Msg('3 · 2 = 6 ta son')},
 html:"<p>1, 2, 3 raqamlaridan foydalanib, nechta <b>ikki xonali</b> son yozish mumkin? Bir sonda raqam <b>takrorlanmaydi</b>.</p>",
 btns:j3Ch(["3","6","8","9"],1,function(){j3Lines(['12, 13','21, 23','31, 32'],{fs:20,lh:34});j3Msg('To‘g‘ri! O‘nliklar: 3 usul, birliklar: qolgan 2 usul → 6')},function(i){return ['3 — faqat o‘nliklar uchun tanlov. Har biriga birliklar ham kerak','','8 — bunday bo‘lmaydi: tartib bilan yozib chiqing','9 — bu 11, 22, 33 bilan birga. Takrorlash taqiqlangan!'][i]}),g2:1,
 after:"<p>Tartib bilan yozamiz: 1 bilan boshlanadigan — 12, 13; 2 bilan — 21, 23; 3 bilan — 31, 32. O'nliklarga 3 tanlov, birliklarga — qolgan 2: 3 · 2 = 6. Agar takrorlash mumkin bo'lsa: 3 · 3 = 9.</p>",
 q:{t:"1, 2, 3, 4 raqamlaridan takrorsiz nechta ikki xonali son yozish mumkin?",opts:["16","12","8","6"],ok:1,why:"4 · 3 = 12.",hint:"O'nliklar xonasiga nechta tanlov? Birliklar xonasiga-chi?",full:"O'nliklarga 4 raqam, birliklarga qolgan 3: 4 · 3 = 12. «16» — takrorlashga ruxsat berish (11, 22, …)."},
 tn:"Raqamli kartochkalarni bolalar qo'lida terib chiqsin — har sonni yozib, tartib bilan."},
{h:"Tuzoq: nol bilan",sum:"0 o'nliklar xonasida tura olmaydi. 0, 1, 2 dan takrorsiz: 10, 12, 20, 21 — 4 ta.",a:"m03",
 start:function(){j3Lines(['Raqamlar: 0, 1, 2','Ikki xonali, takrorsiz','__ __'],{fs:18,lh:34});j3Msg('Nechta shunday son bor?')},fin:function(){j3Lines(['10, 12','20, 21','[01], [02] — ikki xonali emas!'],{fs:19,lh:34});j3Msg('2 · 2 = 4')},
 html:"<p>Endi raqamlar <b>0, 1, 2</b>. Takrorsiz nechta <b>ikki xonali</b> son yozish mumkin? Diqqat!</p>",
 btns:j3Ch(["6","4","9","3"],1,function(){j3Lines(['10, 12','20, 21','[01], [02] — ikki xonali emas!'],{fs:19,lh:34});j3Msg('To‘g‘ri! O‘nliklarga faqat 1 yoki 2 (2 usul), birliklarga qolgan 2 → 4')},function(i){return ['6 ga 01 va 02 ham kirdi. «01» — bu bir xonali 1!','','9 — takrorlash bilan va 0 ni ham o‘nlikka qo‘ydingiz','Hammasini yozib chiqing: 10, 12, 20, …'][i]}),g2:1,
 after:"<p>0 bilan boshlanadigan son ikki xonali emas (01 = 1). Shuning uchun o'nliklarga <b>2</b> tanlov (1 yoki 2), birliklarga qolgan 2 (0 ham mumkin): 2 · 2 = <b>4</b>. Har safar so'rang: «Bu xonaga qaysi raqamlar mumkin?»</p>",
 q:{t:"0, 3, 5 raqamlaridan (takrorlash mumkin) nechta ikki xonali son yozish mumkin?",opts:["9","6","4","8"],ok:1,why:"O'nliklarga 3 yoki 5 (2 usul), birliklarga 0, 3, 5 (3 usul): 6.",hint:"O'nliklarga qaysi raqamlar mumkin?",full:"30, 33, 35, 50, 53, 55 — 6 ta. «9» — 00, 03, 05 ni ham sanash, «4» — takrorlashni taqiqlash."},
 tn:"Bu — eng ko'p yo'l qo'yiladigan xato. Doskaga «__ __» chizib, har xona ostiga mumkin raqamlarni yozing."},
{h:"Qo'l siqishlar",sum:"5 kishi: har biri 4 kishi bilan, lekin har qo'l siqish 2 marta sanaldi: 5 · 4 : 2 = 10.",a:"m04",
 start:function(){j11Hand(0);j3Msg('A to‘rtta qo‘l siqdi. 5 kishi hammasi bir-biri bilan bir martadan qo‘l siqishsa — jami nechta?')},fin:function(){j11Hand(1);j3Msg('5 · 4 = 20 — har qo‘l siqish 2 marta sanaldi → 20 : 2 = 10')},
 html:"<p>5 do'st uchrashib, har biri boshqalar bilan <b>bir martadan</b> qo'l siqishdi. Jami nechta qo'l siqish bo'ldi? (Rasmda — chiziqlar.)</p>",
 btns:j3Ch(["20","10","25","5"],1,function(){j11Hand(1);j3Msg('To‘g‘ri! Chiziqlar 10 ta: 4 + 3 + 2 + 1 = 10')},function(i){return ['20 = 5 · 4 — lekin A ning B bilan va B ning A bilan qo‘l siqishi — bitta qo‘l siqish!','','25 = 5 · 5 — o‘zi bilan qo‘l siqmaydi-ku','5 — har kishi faqat bitta qo‘l siqmaydi'][i]}),g2:1,
 after:"<p>Ikki usul: 1) A — 4 ta, B — yangi 3 ta, C — 2 ta, D — 1 ta: 4 + 3 + 2 + 1 = 10. 2) Har kishi 4 ta, jami 5 · 4 = 20, lekin har qo'l siqishda <b>ikki kishi</b> — 2 marta sanaldi: 20 : 2 = <b>10</b>. Turnirdagi o'yinlar, nuqtalarni tutashtiruvchi kesmalar — xuddi shunday.</p>",
 q:{t:"4 do'st bir-biriga bittadan rasm sovg'a qildi. Jami nechta rasm?",opts:["6","12","16","8"],ok:1,why:"Har biri 3 ta: 4 · 3 = 12. Bu yerda 2 ga bo'lmaymiz!",hint:"A ning B ga va B ning A ga sovg'asi — bitta rasmmi yoki ikkita?",full:"Qo'l siqishdan farqi: A → B va B → A — ikki xil rasm. Har kim 3 ta beradi: 4 · 3 = 12. «6» — qo'l siqish kabi 2 ga bo'lish xatosi."},
 tn:"5 bola chiqib, haqiqatda qo'l siqishsin; qolganlar doskada chiziq chizib sanasin."},
{h:"Qatorga terish",sum:"3 bola: 1-o'ringa 3 usul, 2-o'ringa 2, 3-o'ringa 1 → 3 · 2 · 1 = 6.",a:"m05",
 start:function(){j3Lines(['Ali, Vali, Soli','qatorda necha xil turishi mumkin?'],{fs:18,lh:36});j3Msg('Har xil tartiblarni sanang')},fin:function(){j3Lines(['AVS · ASV','VAS · VSA','SAV · SVA'],{fs:20,lh:34});j3Msg('3 · 2 · 1 = 6')},
 html:"<p>Ali, Vali va Soli rasmga tushish uchun bir qatorga turishmoqchi. Ular necha xil tartibda turishi mumkin?</p>",
 btns:j3Ch(["3","6","9","4"],1,function(){j3Lines(['AVS · ASV','VAS · VSA','SAV · SVA'],{fs:20,lh:34});j3Msg('To‘g‘ri! 1-o‘ringa 3 kishi, 2-o‘ringa qolgan 2, 3-o‘ringa 1')},function(i){return ['3 — faqat kim birinchi turishi. Qolganlari ham joy almashadi','','9 = 3 · 3 — lekin bir kishi ikki joyda tura olmaydi','Har boshlovchi uchun 2 tartib bor. Boshlovchilar nechta?'][i]}),g2:1,
 after:"<p>1-o'rinni 3 usulda tanlaymiz, 2-o'rinni qolgan 2 kishidan, 3-o'ringa 1 kishi qoladi: 3 · 2 · 1 = <b>6</b>. 4 kishi bo'lsa: 4 · 3 · 2 · 1 = 24!</p>",
 q:{t:"4 xil kitobni tokchaga necha xil tartibda terish mumkin?",opts:["16","24","12","10"],ok:1,why:"4 · 3 · 2 · 1 = 24.",hint:"1-o'ringa nechta kitob, 2-o'ringa nechta qoladi?",full:"1-o'ringa 4, 2-ga 3, 3-ga 2, 4-ga 1: 4 · 3 · 2 · 1 = 24. «16» = 4 · 4 — kitobni ikki marta qo'yish, «12» = 4 · 3 — oxirgi o'rinlarni unutish."},
 tn:"Uch bola sinf oldida haqiqatda joy almashsin; qolganlar har tartibni doskaga yozsin."},
{h:"Tuzoq: yo'llar",sum:"A→B→C: 3 · 2 = 6 yo'l, to'g'ri yo'l bilan yana 1: jami 7.",a:"m06",
 start:function(){j11Road();j3Msg('A dan C ga necha xil yo‘l bilan borish mumkin? (Orqaga qaytmasdan)')},fin:function(){j11Road();j3Msg('B orqali: 3 · 2 = 6, to‘g‘ri yo‘l: 1 → jami 7')},
 html:"<p>A qishloqdan B ga 3 ta yo'l, B dan C ga 2 ta yo'l bor. Bundan tashqari A dan C ga B ga kirmasdan <b>to'g'ri</b> yo'l ham bor. A dan C ga necha xil yo'l bilan borish mumkin?</p>",
 btns:j3Ch(["5","6","7","8"],2,function(){j3Msg('To‘g‘ri! B orqali 3 · 2 = 6, to‘g‘ri yo‘l 1: 6 + 1 = 7')},function(i){return ['5 = 3 + 2 — ketma-ket yo‘llar ko‘paytiriladi','6 — B orqali yo‘llar. Yashil to‘g‘ri yo‘lni unutdingiz!','','8 — to‘g‘ri yo‘l faqat bitta'][i]}),g2:1,
 after:"<p>Ikki qoida birga: <b>ketma-ket</b> (avval A→B, <b>keyin</b> B→C) — ko'paytiramiz: 3 · 2 = 6. <b>Yoki u, yoki bu</b> yo'l — qo'shamiz: 6 + 1 = 7.</p>",
 q:{t:"A dan B ga 2 yo'l, B dan C ga 3 yo'l, A dan C ga to'g'ri 2 yo'l. A dan C ga nechta yo'l?",opts:["7","8","12","6"],ok:1,why:"2 · 3 + 2 = 8.",hint:"B orqali nechta? To'g'ri yo'llar nechta?",full:"B orqali: 2 · 3 = 6. To'g'ri: 2. «Yoki» — qo'shamiz: 6 + 2 = 8. «7» — hammasini qo'shish (2 + 3 + 2)."},
 tn:"Doskada xarita chizing, bolalar har yo'lni rangli bo'r bilan chizib sanasin."},
{h:"Bilasizmi? Domino toshlari",sum:"Domino to'plamida 28 ta tosh: 0 dan 6 gacha raqamlarning barcha juftliklari (dubllar bilan).",a:"m07",
 start:function(){j3Lines(['0–0  0–1 … 0–6   7 ta','1–1 … 1–6   6 ta','…   6–6   1 ta','7 + 6 + 5 + 4 + 3 + 2 + 1 = 28'],{fs:15,lh:30});j3Msg('Domino — kombinatorika o‘yini')},fin:function(){j3Lines(['0–0  0–1 … 0–6   7 ta','1–1 … 1–6   6 ta','…   6–6   1 ta','7 + 6 + 5 + 4 + 3 + 2 + 1 = 28'],{fs:15,lh:30});j3Msg('Domino — kombinatorika o‘yini')},
 html:"<p>🎲 Oddiy domino to'plamida <b>28 ta</b> tosh bor. Nega aynan 28? Har toshda 0 dan 6 gacha ikkita son. 0 bilan juftliklar: 0–0, 0–1, …, 0–6 — 7 ta. 1 bilan yangilari: 1–1, …, 1–6 — 6 ta. Va hokazo: 7 + 6 + 5 + 4 + 3 + 2 + 1 = 28.</p><p>Bu — qo'l siqish masalasining o'zi (faqat «o'zi bilan» juftlik — dubl ham bor)!</p>",
 tn:"Sinfda domino bo'lsa, bolalar toshlarni tartib bilan terib, 28 tani tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j11Out(6)},fin:function(){j11Out(6)},
 html:"<div class='memo'><ul><li>«Va» (ketma-ket tanlov) — <b>ko'paytiramiz</b>: 3 ko'ylak · 2 shim = 6.</li><li>«Yoki» — <b>qo'shamiz</b>.</li><li>Hammasini <b>tartib bilan</b> yozib chiqing (jadval, daraxt).</li><li>0 o'nliklar xonasida turmaydi.</li><li>Takrorsiz: har xonaga bittaga kam tanlov.</li><li>Qo'l siqish: n · (n − 1) : 2. Sovg'a (yo'nalishli): n · (n − 1).</li><li>Qatorga terish: 3 · 2 · 1, 4 · 3 · 2 · 1.</li></ul></div>",
 tn:"Har darsda bitta «nechta usul?» savoli — bolalar avval taxmin qilsin, keyin tizimli sanasin."}
];
var PROBS=[
{t:"4 ta ko'ylak va 3 ta shimdan necha xil kiyinish mumkin?",o:["12","7","16","9"],k:0,s:"4 · 3 = 12."},
{t:"2 xil non va 3 xil ichimlikdan bittadan tanlab, necha xil nonushta qilish mumkin?",o:["6","5","8","9"],k:0,s:"2 · 3 = 6."},
{t:"1, 2, 3, 4 raqamlaridan takrorsiz nechta ikki xonali son yozish mumkin?",o:["12","16","8","6"],k:0,s:"4 · 3 = 12."},
{t:"1, 2, 3 raqamlaridan (takrorlash mumkin) nechta ikki xonali son yozish mumkin?",o:["9","6","3","8"],k:0,s:"3 · 3 = 9."},
{t:"0, 1, 2 raqamlaridan takrorsiz nechta ikki xonali son yozish mumkin?",o:["4","6","9","3"],k:0,s:"10, 12, 20, 21."},
{t:"0, 3, 5 raqamlaridan (takrorlash mumkin) nechta ikki xonali son yozish mumkin?",o:["6","9","4","8"],k:0,s:"O'nliklarga 2 tanlov, birliklarga 3: 6."},
{t:"1, 2, 3 raqamlaridan takrorsiz nechta uch xonali son yozish mumkin?",o:["6","9","27","3"],k:0,s:"3 · 2 · 1 = 6."},
{t:"Raqamlari yig'indisi 3 ga teng nechta ikki xonali son bor?",o:["3","2","4","6"],k:0,s:"12, 21, 30."},
{t:"4 kishi bir-biri bilan bir martadan qo'l siqishdi. Jami nechta qo'l siqish?",o:["6","12","16","8"],k:0,s:"4 · 3 : 2 = 6."},
{t:"6 kishi bir-biri bilan bir martadan qo'l siqishdi. Jami nechta qo'l siqish?",o:["15","30","36","12"],k:0,s:"6 · 5 : 2 = 15."},
{t:"Turnirda 5 jamoa, har biri boshqasi bilan bir marta o'ynadi. Nechta o'yin bo'ldi?",o:["10","20","25","15"],k:0,s:"5 · 4 : 2 = 10."},
{t:"4 do'st bir-biriga bittadan rasm sovg'a qildi. Jami nechta rasm?",o:["12","6","16","8"],k:0,s:"4 · 3 = 12 (har sovg'a alohida)."},
{t:"5 ta nuqta berilgan, ularning hech uchtasi bir to'g'ri chiziqda emas. Har ikkisini kesma bilan tutashtirdik. Nechta kesma?",o:["10","20","5","25"],k:0,s:"5 · 4 : 2 = 10."},
{t:"3 bola bir qatorga necha xil tartibda turishi mumkin?",o:["6","3","9","4"],k:0,s:"3 · 2 · 1 = 6."},
{t:"4 xil kitobni tokchaga necha xil tartibda terish mumkin?",o:["24","16","12","10"],k:0,s:"4 · 3 · 2 · 1 = 24."},
{t:"A dan B ga 3 yo'l, B dan C ga 4 yo'l bor. A dan B orqali C ga necha xil yo'l bilan borish mumkin?",o:["12","7","9","16"],k:0,s:"3 · 4 = 12."},
{t:"A dan B ga 2 yo'l, B dan C ga 3 yo'l, A dan C ga to'g'ri 2 yo'l. A dan C ga necha xil yo'l bor?",o:["8","7","12","6"],k:0,s:"2 · 3 + 2 = 8."},
{t:"Uch gorizontal yo'lli bayroqni 3 xil rangdan foydalanib, yo'llar har xil rangda bo'lsin. Nechta xil bayroq?",o:["6","9","27","3"],k:0,s:"3 · 2 · 1 = 6."},
{t:"Uch gorizontal yo'lli bayroq uchun 4 xil rang bor, yo'llar har xil rangda. Nechta xil bayroq?",o:["24","12","64","4"],k:0,s:"4 · 3 · 2 = 24."},
{t:"Ikkita tanga tashlandi. Nechta xil natija bo'lishi mumkin (1-tanga va 2-tanga alohida)?",o:["4","3","2","6"],k:0,s:"G-G, G-R, R-G, R-R."}
];
function PRACT_STAGE(){j11Out(6)}
var PREP_DATA={teach:["Ko'paytirish qoidasi (jadval, daraxt).","Raqamlardan sonlar: takrorli, takrorsiz, 0 bilan.","Qo'l siqish va sovg'a masalalari.","Qatorga terish; «va» — ko'paytirish, «yoki» — qo'shish."],
 mist:["Tanlovlarni ko'paytirish o'rniga qo'shadi.","0 ni o'nliklar xonasiga qo'yadi.","Qo'l siqishda 2 ga bo'lishni unutadi yoki sovg'ada keraksiz bo'ladi."],
 need:["Raqamli kartochkalar.","Qog'ozdan kiyim shakllari."],
 board:["<span class='w2'>«va» → ×, «yoki» → +</span>","__ __: o'nliklarga 0 emas","Qo'l siqish: <span class='w2'>n · (n − 1) : 2</span>","Qator: <span class='w2'>3 · 2 · 1 = 6</span>"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
