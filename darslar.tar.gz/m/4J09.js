var CODE='4J09',TITLE="4-sinf · Kalendar jumboqlari";
var K9D=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function k9Cal(start,days,hl,red){var rows=[K9D.slice()],r=[],c={},f={};for(var i=0;i<start;i++)r.push('');for(var d=1;d<=days;d++){r.push(d);if(r.length===7){rows.push(r);r=[]}}if(r.length){while(r.length<7)r.push('');rows.push(r)}
 rows.forEach(function(row,i){row.forEach(function(v,j){if(hl&&hl.indexOf(v)>=0&&i>0){f[i+','+j]='#ffe9a8'}if(red&&red.indexOf(v)>=0&&i>0){c[i+','+j]=C.bad}})});j3Tab(rows,{hr:1,cw:40,ch:Math.min(24,150/rows.length),fs:12,fill:f,col:c,y0:6})}
function k9Wheel(hl){clear();var cx=180,cy=86,R=58,n=['Du','Se','Ch','Pa','Ju','Sh','Ya'];n.forEach(function(d,i){var a=-Math.PI/2+i*2*Math.PI/7,x=cx+R*Math.cos(a),y=cy+R*Math.sin(a),on=hl===i;E('circle',{cx:x,cy:y,r:17,fill:on?'#ffe9a8':'#fff',stroke:on?C.bad:'#c9d3dd','stroke-width':2},S.g);T(S.g,x,y+5,d,{'font-size':13,'font-weight':800,fill:'#1d2b3a'})});T(S.g,cx,cy+5,'7',{'font-size':22,'font-weight':800,fill:C.blue})}
var STEPS=[
J4({h:"Yil va hafta",sum:"365 = 52 · 7 + 1. Oddiy yil 52 hafta va 1 kun: keyingi yil 1-yanvari 1 kunga suriladi. 2026 — payshanba → 2027 — juma.",a:"m01",
 s:function(){k9Wheel(3)},m:"365 kunda nechta to‘liq hafta va yana nechta kun?",f:function(){k9Wheel(4);j3Msg('365 = 52 · 7 + <b>1</b> → payshanba + 1 = <b>juma</b>')},
 html:"<p>2026-yilning 1-yanvari — payshanba. 2026-yil kabisa emas (365 kun). <b>2027-yilning 1-yanvari</b> qaysi kun?</p>",
 ch:["juma","payshanba","shanba","chorshanba"],ok:0,bad:["","365 kun 7 ga qoldiqsiz bo‘linmaydi","+2 kun faqat kabisa yildan keyin","Kun oldinga suriladi, orqaga emas"],
 after:"<p>365 : 7 = 52 (qoldiq <b>1</b>). 52 ta to'liq hafta hafta kunini o'zgartirmaydi, qolgan 1 kun uni bittaga suradi: payshanba → <b>juma</b>. Kabisa yilida (366 kun) qoldiq 2 — ikki kunga suriladi.</p>",
 q:{t:"2026-yil 1-yanvar — payshanba. 2026-yil 31-dekabr qaysi kun?",opts:["payshanba","juma","chorshanba","yakshanba"],ok:0,why:"31-dekabr 1-yanvardan 364 kun keyin = 52 hafta.",hint:"1-yanvardan 31-dekabrgacha necha kun o'tadi?",full:"364 = 52 · 7 — qoldiq 0, kun o'zgarmaydi: payshanba. «juma» — 365 ni qo'shish xatosi."},
 tn:"Haqiqiy kalendardan tekshiring: bolalar 2026 va 2027 yil kalendarlarining 1-yanvarini solishtirsin."}),
J4({h:"Kabisa yili",sum:"Kabisa yili 366 kun = 52 hafta + 2 kun. 2028 — kabisa, 1-yanvari shanba → 2029-yil 1-yanvar dushanba.",a:"m02",
 s:function(){k9Wheel(5)},m:"2028 — kabisa yili: 366 kun",f:function(){k9Wheel(0);j3Msg('366 = 52 · 7 + <b>2</b> → shanba + 2 = <b>dushanba</b>')},
 html:"<p>2028-yilning 1-yanvari — shanba. 2028 — kabisa yili (fevralda 29 kun). <b>2029-yil 1-yanvar</b> qaysi kun?</p>",
 ch:["dushanba","yakshanba","seshanba","shanba"],ok:0,bad:["","Yakshanba — oddiy yil bo‘lsa. Kabisada 366 kun","Shanba + 3? 366 : 7 qoldig‘i 2","Kun albatta suriladi"],
 after:"<p>366 : 7 = 52 (qoldiq 2) → 2 kunga suriladi: shanba → yakshanba → <b>dushanba</b>. Kabisa yili: yil 4 ga bo'linsa (2024, 2028). Lekin 100 ga bo'linadigan yillar faqat 400 ga ham bo'linsa kabisa: 2000 — kabisa, 1900 va 2100 — kabisa emas.</p>",
 q:{t:"Quyidagi yillardan qaysi biri kabisa?",opts:["2028","2026","2030","2100"],ok:0,why:"2028 : 4 = 507.",hint:"4 ga bo'linishini tekshiring; 100 ga bo'linadiganlarga ehtiyot bo'ling.",full:"2028 — 4 ga bo'linadi. 2100 — 100 ga bo'linadi, lekin 400 ga bo'linmaydi → kabisa emas. 2026, 2030 — 4 ga bo'linmaydi."},
 tn:"Bolalar o'z tug'ilgan yilidan beri nechta kabisa yil o'tganini sanasin."}),
J4({h:"Qaysi kunlar 5 marta?",sum:"31 kun = 4 hafta + 3 kun. Oy chorshanba bilan boshlansa, chorshanba, payshanba, juma 5 martadan keladi.",a:"m03",
 s:function(){k9Cal(2,31)},m:"28 kun — har kun 4 tadan. Ortiqcha 3 kun qaysilar?",f:function(){k9Cal(2,31,[29,30,31,1,2,3]);j3Msg('29, 30, 31 — Ch, Pa, Ju → bu kunlar <b>5 martadan</b>')},
 html:"<p>31 kunlik oy <b>chorshanba</b> bilan boshlandi. Qaysi hafta kunlari bu oyda 5 martadan keladi?</p>",
 ch:["chorshanba, payshanba, juma","faqat chorshanba","chorshanba va payshanba","seshanba, chorshanba, payshanba"],ok:0,bad:["","31 = 28 + 3 — ortiqcha 3 kun bor","3 ta kun ortiqcha: 29, 30, 31","Oy seshanba bilan boshlanmadi"],
 after:"<p>28 kun — aynan 4 hafta, har kun 4 martadan. Qolgan 29-, 30-, 31-sanalar 1-, 2-, 3-sanalar bilan bir xil kunda: chorshanba, payshanba, juma — ular <b>5 martadan</b>. 30 kunlik oyda 2 ta, 29 kunlikda 1 ta kun 5 marta keladi.</p>",
 q:{t:"30 kunlik oy shanba bilan boshlandi. Unda nechta yakshanba bor?",opts:["5","4","6","3"],ok:0,why:"Yakshanbalar: 2, 9, 16, 23, 30.",hint:"Birinchi yakshanba nechanchi sana?",full:"1-sana shanba → yakshanbalar 2, 9, 16, 23, 30 — 5 ta. 30 = 28 + 2: shanba va yakshanba 5 martadan."},
 tn:"Bo'sh kalendar varag'ini bolalar o'zi to'ldirsin va 5 marta keladigan kunlarni bo'yasin."}),
J4({h:"Kalendar varag'idagi sonlar",sum:"Bir ustundagi sanalar 7 tadan farq qiladi: x, x + 7, x + 14, x + 21. Yig'indi 4x + 42 = 70 → x = 7.",a:"m04",
 s:function(){k9Cal(0,30,[7,14,21,28])},m:"Bir ustunda pastga tushsak, sana 7 ga oshadi",f:function(){k9Cal(0,30,[7,14,21,28],[7]);j3Msg('4x + 42 = 70 → x = <b>7</b>')},
 html:"<p>Kalendar varag'ining bitta ustunidagi 4 ta sana yig'indisi 70 ga teng. Ulardan eng kichigi qaysi?</p>",
 ch:["7","14","10","17"],ok:0,bad:["","14 bo‘lsa: 14 + 21 + 28 + 35 — 35-sana yo‘q","70 : 4 ≈ 17 — bu o‘rtacha; sanalar 7 tadan farq qiladi","70 : 4 ni yaxlitlash ish bermaydi"],
 after:"<p>Ustunda sanalar 7 tadan oshadi: x, x + 7, x + 14, x + 21. Yig'indi 4x + 42 = 70 → 4x = 28 → x = <b>7</b>. Sanalar: 7, 14, 21, 28 ✓. Qatorda esa qo'shni sanalar 1 ga farq qiladi.</p>",
 q:{t:"Kalendar varag'ida 3×3 kvadrat ichidagi 9 ta sana yig'indisi 108. Markazdagi sana?",opts:["12","9","13","36"],ok:0,why:"9 ta sana markaz atrofida juft-juft muvozanatda: yig'indi = 9 · markaz.",hint:"Markazga nisbatan qarama-qarshi sanalar yig'indisi qancha?",full:"Qarama-qarshi sanalar (masalan, chap yuqori va o'ng pastki) yig'indisi 2 · markaz. 9 · markaz = 108 → 12."},
 tn:"Haqiqiy kalendarda bolalar 3×3 kvadrat tanlab, yig'indini hisoblasin va 9 ga bo'lib markazni topsin."}),
J4({h:"Katta sonlar: qoldiq bilan",sum:"Bugun dushanba. 100 = 14 · 7 + 2 → 100 kundan keyin dushanba + 2 = chorshanba.",a:"m05",
 s:function(){k9Wheel(0)},m:"7 kundan keyin yana dushanba. 100 da nechta to‘liq hafta?",f:function(){k9Wheel(2);j3Msg('100 = 14 · 7 + <b>2</b> → chorshanba')},
 html:"<p>Bugun dushanba. <b>100 kundan</b> keyin qaysi kun bo'ladi?</p>",
 ch:["chorshanba","seshanba","payshanba","dushanba"],ok:0,bad:["","Qoldiq 2: dushanba + 2","Qoldiqni qayta hisoblang: 14 · 7 = 98","100 kun 7 ga qoldiqsiz bo‘linmaydi"],
 after:"<p>Hafta kunlari 7 kunlik aylanada. To'liq haftalar kunni o'zgartirmaydi — faqat <b>qoldiq</b> muhim: 100 : 7 = 14 (qoldiq 2) → dushanba + 2 = chorshanba.</p>",
 q:{t:"Bugun juma. 1000 kundan keyin qaysi kun?",opts:["payshanba","juma","shanba","chorshanba"],ok:0,why:"1000 = 142 · 7 + 6 → juma + 6.",hint:"1000 ni 7 ga bo'lgandagi qoldiq?",full:"142 · 7 = 994, qoldiq 6. Juma + 6 = payshanba (yoki juma − 1)."},
 tn:"Qoldiq 6 — «bir kun orqaga» bilan bir xil: bolalar ikki usulni solishtirsin."}),
J4({h:"Tuzoq: chalkash so'zlar",sum:"«Ertangi kundan 3 kun oldin» = bugundan 2 kun oldin. U seshanba bo'lsa, bugun payshanba.",a:"m06",
 s:['Ertangi kundan 3 kun oldin','seshanba edi.','Bugun qaysi kun?'],so:{fs:18,lh:36},m:"Har bir so‘zni songa aylantiring: ertaga = +1, 3 kun oldin = −3",
 f:['+1 − 3 = −2','bugun − 2 = seshanba','bugun = [payshanba]'],fso:{fs:18,lh:36},fm:"Son o‘qidagidek: +1, −3",
 html:"<p>«Ertangi kundan 3 kun oldin seshanba edi». <b>Bugun</b> qaysi kun?</p>",
 ch:["payshanba","juma","chorshanba","shanba"],ok:0,bad:["","Seshanba + 3 = juma — «ertangi»ni unutdingiz","Seshanba + 1 — faqat bitta siljish","Seshanba + 4 — yo‘nalishni tekshiring"],
 after:"<p>So'zlarni sonlarga aylantiramiz: «ertangi kun» = bugun + 1; «undan 3 kun oldin» = bugun + 1 − 3 = bugun − 2. Bugun − 2 = seshanba → bugun = <b>payshanba</b>.</p>",
 q:{t:"«Kechagi kundan 2 kun keyin yakshanba bo'ladi». Bugun qaysi kun?",opts:["shanba","juma","yakshanba","dushanba"],ok:0,why:"−1 + 2 = +1: bugun + 1 = yakshanba.",hint:"Kecha = −1, 2 kun keyin = +2.",full:"Bugun − 1 + 2 = bugun + 1 = yakshanba → bugun shanba."},
 tn:"Hafta kunlari bilan son o'qi chizing; bolalar strelka bilan «+1, −3» qadamlarini ko'rsatsin."}),
J4info({h:"Bilasizmi? Yo'qolgan 10 kun",a:"m07",s:['1582-yil oktabr','4-oktabr → 15-oktabr'],so:{fs:20,lh:44},m:"Grigorian kalendari",
 html:"<p>📅 Bugungi kalendarimiz — <b>Grigorian kalendari</b>. Uni 1582-yilda Rim papasi Grigoriy XIII joriy etgan. Eski kalendar Quyosh yilidan orqada qolgani uchun 10 kun «tashlab yuborilgan»: 1582-yil 4-oktabrdan keyin darhol 15-oktabr kelgan. Shu kalendarda yuz yillarning kabisaligi uchun qo'shimcha qoida kiritilgan: 1900 — kabisa emas, 2000 — kabisa.</p>",
 tn:"Kuchli o'quvchilar: nega 1900 kabisa emas? (100 ga bo'linadi, 400 ga bo'linmaydi.)"}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){k9Wheel(-1)},m:"Hafta — 7 kunlik aylana",
 html:"<div class='memo'><ul><li>Hafta — 7 kunlik aylana: faqat <b>qoldiq</b> muhim.</li><li>Oddiy yil: +1 kun, kabisa yil: +2 kun.</li><li>Kabisa: 4 ga bo'linadi; 100 ga bo'linsa — 400 ga ham bo'linishi kerak.</li><li>31 kunlik oy: 3 ta kun 5 martadan; 30 kunlik — 2 ta.</li><li>Kalendar ustuni: +7, qatori: +1.</li><li>«Ertaga», «kecha», «oldin» — son o'qidagi + va −.</li></ul></div>",
 tn:"Uyga: o'z tug'ilgan kuni keyingi yili haftaning qaysi kuniga to'g'ri kelishini topib kelish."})
];
var PROBS=[
{t:"2026-yil 1-yanvar — payshanba. 2026-yil 8-yanvar qaysi kun?",o:["payshanba","juma","chorshanba","yakshanba"],k:0,s:"7 kundan keyin — yana payshanba."},
{t:"Kabisa bo'lmagan yilda nechta to'liq hafta bor?",o:["52","53","50","48"],k:0,s:"365 = 52 · 7 + 1."},
{t:"Kabisa yilida nechta kun bor?",o:["366","365","364","360"],k:0,s:"Fevralda 29 kun: 366."},
{t:"2026-yil 1-sentabr — seshanba. 2026-yil 1-oktabr qaysi kun?",o:["payshanba","seshanba","chorshanba","juma"],k:0,s:"Sentabrda 30 kun = 4 hafta + 2: seshanba + 2."},
{t:"2026-yil 1-mart — yakshanba. 2026-yil 1-fevral qaysi kun edi?",o:["yakshanba","shanba","juma","dushanba"],k:0,s:"2026-yil fevralida 28 kun = 4 hafta: kun o'zgarmaydi."},
{t:"1-may — juma. Shu oyning 25-sanasi qaysi kun?",o:["dushanba","juma","yakshanba","seshanba"],k:0,s:"24 kun = 3 hafta + 3: juma + 3 = dushanba."},
{t:"Bugun dushanba. 50 kundan keyin qaysi kun?",o:["seshanba","dushanba","chorshanba","payshanba"],k:0,s:"50 = 7 · 7 + 1: dushanba + 1."},
{t:"Bugun shanba. 365 kundan keyin qaysi kun?",o:["yakshanba","shanba","juma","dushanba"],k:0,s:"365 = 52 · 7 + 1: shanba + 1."},
{t:"Kalendar varag'ining bitta ustunidagi uchta ketma-ket sana yig'indisi 48. O'rtadagi sana?",o:["16","9","23","15"],k:0,s:"x − 7 + x + x + 7 = 3x = 48 → 16."},
{t:"Kalendar varag'ida 3×3 kvadrat ichidagi 9 ta sana yig'indisi 135. Ulardan eng kattasi?",o:["23","15","21","27"],k:0,s:"Markaz 135 : 9 = 15; eng kattasi — o'ng pastki: 15 + 7 + 1 = 23."},
{t:"Kabisa bo'lmagan yilda qaysi oyda 5 ta yakshanba bo'lishi mumkin emas?",o:["fevral","aprel","iyun","noyabr"],k:0,s:"Fevralda 28 kun — har kun aynan 4 marta."},
{t:"31 kunlik oy juma bilan boshlandi. Oyning oxirgi kuni qaysi?",o:["yakshanba","juma","shanba","dushanba"],k:0,s:"31-sana 1-sanadan 30 kun keyin: 30 = 28 + 2 → juma + 2."},
{t:"31 kunlik oyda 5 ta seshanba, 5 ta chorshanba va 4 ta dushanba bor. Oyning 1-sanasi qaysi kun?",o:["seshanba","dushanba","chorshanba","yakshanba"],k:0,s:"5 marta keladigan 3 kun: 1-sana va keyingi 2 kun. Dushanba 4 ta → boshlanishi seshanba."},
{t:"Ertadan keyingi kun shanba. Kechadan oldingi kun qaysi edi?",o:["seshanba","chorshanba","dushanba","payshanba"],k:0,s:"Bugun + 2 = shanba → bugun payshanba; bugun − 2 = seshanba."},
{t:"Bugundan 3 kun oldin yakshanba edi. Bugundan 3 kun keyin qaysi kun?",o:["shanba","payshanba","juma","yakshanba"],k:0,s:"Bugun chorshanba, + 3 = shanba."},
{t:"Ali 2016-yil 29-fevralda tug'ilgan. 2017–2026-yillar orasida uning tug'ilgan sanasi kalendarda necha marta bo'ldi?",o:["2","3","10","1"],k:0,s:"29-fevral faqat kabisa yillarda: 2020 va 2024."},
{t:"Kabisa yilida yanvar va fevral birgalikda necha kun?",o:["60","59","61","62"],k:0,s:"31 + 29 = 60."},
{t:"2026-yilda 1-yanvardan 1-sentabrgacha necha kun o'tadi?",o:["243","244","240","246"],k:0,s:"31+28+31+30+31+30+31+31 = 243."},
{t:"2026-yil 1-yanvar — payshanba. 2026-yil 1-sentabr qaysi kun?",o:["seshanba","payshanba","dushanba","chorshanba"],k:0,s:"243 = 34 · 7 + 5: payshanba + 5 = seshanba."},
{t:"Qaysi yil kabisa emas?",o:["1900","2000","2024","1996"],k:0,s:"1900 100 ga bo'linadi, lekin 400 ga bo'linmaydi."}
];
function PRACT_STAGE(){k9Cal(3,31)}
var PREP_DATA={teach:["Hafta — 7 kunlik aylana, qoldiq.","Yil siljishi: oddiy +1, kabisa +2.","Kabisa qoidasi (4, 100, 400).","Oyda 5 marta keladigan kunlar.","Kalendar varag'idagi sonlar: +1, +7."],
 mist:["Qoldiq o'rniga bo'linmani ishlatadi.","«Ertangi kundan 3 kun oldin» ni −3 deb oladi.","Har 100 ga bo'linadigan yilni kabisa deb hisoblaydi."],
 need:["Joriy yil kalendari.","Hafta kunlari aylanasi (karton).","Bo'sh kalendar varaqlari."],
 board:["365 = 52 · 7 + 1","366 = 52 · 7 + 2","ustun +7, qator +1","3×3: yig'indi = 9 · markaz"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
