var CODE='4H10',TITLE='4-sinf · Prizma, piramida, shar, silindr, konus va yoyilmalar';
function qamsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var QAF='rgba(240,160,64,.30)',QAB='rgba(31,111,178,.18)';
function qaP(d,f,st,dash){return E('path',{d:d,fill:f||'none',stroke:st||C.a2,'stroke-width':2.2,'stroke-linejoin':'round','stroke-dasharray':dash||'none'},S.g)}
function qaLab(x,y,t,col){T(S.g,x,y,t,{'font-size':11,'font-weight':800,fill:col||'#3a4a5a'})}
// jismlar (markaz x, pastki y, masshtab s)
function qaPrism(x,y,s,c){c=c||C.a2;var a=[x-26*s,y],b=[x+20*s,y],d=[x-4*s,y-12*s],h=56*s;
 qaP('M'+a+' L'+b+' L'+[b[0],b[1]-h]+' L'+[a[0],a[1]-h]+' Z',QAF,c);qaP('M'+[b[0],b[1]-h]+' L'+[d[0],d[1]-h]+' L'+[a[0],a[1]-h]+' Z',QAB,c);qaP('M'+a+' L'+d+' L'+b,'none',c,'4 3');qaP('M'+d+' L'+[d[0],d[1]-h],'none',c,'4 3')}
function qaPyr(x,y,s,c){c=c||C.a2;var A=[x-28*s,y],B=[x+16*s,y],Cc=[x+30*s,y-14*s],D=[x-14*s,y-14*s],S0=[x+1*s,y-62*s];
 qaP('M'+A+' L'+B+' L'+S0+' Z',QAF,c);qaP('M'+B+' L'+Cc+' L'+S0+' Z',QAB,c);qaP('M'+A+' L'+D+' L'+Cc,'none',c,'4 3');qaP('M'+D+' L'+S0,'none',c,'4 3')}
function qaCyl(x,y,s,c){c=c||C.blue;var r=24*s,e=8*s,h=56*s;E('rect',{x:x-r,y:y-h,width:2*r,height:h,fill:QAB,stroke:'none'},S.g);qaP('M'+(x-r)+' '+y+' L'+(x-r)+' '+(y-h)+' M'+(x+r)+' '+y+' L'+(x+r)+' '+(y-h),'none',c);E('ellipse',{cx:x,cy:y-h,rx:r,ry:e,fill:'#dfe9f5',stroke:c,'stroke-width':2.2},S.g);qaP('M'+(x-r)+' '+y+' A'+r+' '+e+' 0 0 0 '+(x+r)+' '+y,'none',c);qaP('M'+(x-r)+' '+y+' A'+r+' '+e+' 0 0 1 '+(x+r)+' '+y,'none',c,'4 3')}
function qaCone(x,y,s,c){c=c||C.u;var r=26*s,e=8*s,h=62*s;qaP('M'+(x-r)+' '+y+' L'+x+' '+(y-h)+' L'+(x+r)+' '+y+' A'+r+' '+e+' 0 0 1 '+(x-r)+' '+y+' Z','rgba(18,163,159,.18)',c);qaP('M'+(x-r)+' '+y+' A'+r+' '+e+' 0 0 1 '+(x+r)+' '+y,'none',c,'4 3')}
function qaSph(x,y,s,c){c=c||C.bad;var r=28*s;E('circle',{cx:x,cy:y-r,r:r,fill:'rgba(217,75,75,.15)',stroke:c,'stroke-width':2.2},S.g);E('ellipse',{cx:x,cy:y-r,rx:r,ry:8*s,fill:'none',stroke:c,'stroke-width':1.5,'stroke-dasharray':'4 3'},S.g)}
function qaCube(x,y,s,c){c=c||C.a2;var a=44*s,d=14*s;qaP('M'+(x-a/2)+' '+y+' h'+a+' v-'+a+' h-'+a+' Z',QAF,c);qaP('M'+(x-a/2)+' '+(y-a)+' l'+d+' -'+d+' h'+a+' l-'+d+' '+d+' Z',QAB,c);qaP('M'+(x+a/2)+' '+y+' l'+d+' -'+d+' v-'+a+' l-'+d+' '+d+' Z','rgba(240,160,64,.18)',c)}
function qaAll(k){clear();var hi=[k===0,k===0,k===0,k===1,k===1,k===1];var g=function(i){return hi[i]?null:C.grey};
 qaCube(34,112,0.9,k<0||hi[0]?C.a2:C.grey);qaPrism(98,112,0.9,k<0||hi[1]?C.a2:C.grey);qaPyr(160,112,0.9,k<0||hi[2]?C.a2:C.grey);qaCyl(220,112,0.85,k<0||hi[3]?C.blue:C.grey);qaCone(280,112,0.85,k<0||hi[4]?C.u:C.grey);qaSph(334,112,0.8,k<0||hi[5]?C.bad:C.grey);
 if(k===0)qaLab(100,150,'ko‘pyoqlar: hamma yoqlari tekis',C.a2);if(k===1)qaLab(276,150,'aylanish jismlari: egri sirt bor',C.blue)}
var QAP2=[function(){clear();qaPrism(110,140,1.7);qamsg('Uchburchakli prizma')},
 function(){clear();qaPrism(110,140,1.7);qaLab(250,50,'2 ta asos — teng uchburchak',C.blue);qaLab(250,80,'3 ta yon yoq — to‘rtburchak',C.a2);qamsg('Yoqlar: 2 + 3 = <b>5</b>')},
 function(){clear();qaPrism(110,140,1.7);[[66,140],[144,140],[103,120],[66,45],[144,45],[103,25]].forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:4.5,fill:C.bad},S.g)});qaLab(260,50,'uchlar: 3 + 3 = 6',C.bad);qaLab(260,80,'qirralar: 3 + 3 + 3 = 9',C.a2);qaLab(260,110,'yoqlar: 5',C.blue);qamsg('Uchburchakli prizma: <b>6</b> uch, <b>9</b> qirra, <b>5</b> yoq')}];
function qaPyrBig(k){clear();qaPyr(110,145,1.9);if(k===1){qaLab(260,50,'asosda 4 ta qirra',C.a2);qaLab(260,76,'cho‘qqiga 4 ta qirra',C.blue);qaLab(260,110,'jami 4 + 4 = 8',C.ok)}}
var QAP4=[function(){qatab(0);qamsg('n burchakli prizma va piramida: sanamay hisoblaymiz')},function(){qatab(1);qamsg('Prizma: uch 2n, qirra 3n, yoq n + 2')},function(){qatab(2);qamsg('Piramida: uch n + 1, qirra 2n, yoq n + 1')}];
function qatab(k){clear();var g=S.g,rows=[['','uchlar','qirralar','yoqlar'],['prizma','2n','3n','n + 2'],['piramida','n + 1','2n','n + 1']];
 rows.forEach(function(r,i){if(i>k)return;r.forEach(function(c,j){E('rect',{x:20+j*82,y:22+i*40,width:80,height:36,rx:6,fill:i===0||j===0?'#eef3f8':(i===1?'rgba(240,160,64,.2)':'rgba(18,163,159,.18)'),stroke:'#d5dde6'},g);T(g,60+j*82,45+i*40,c,{'font-size':13,'font-weight':800,fill:'#33475b'})})});
 if(k>=1)T(g,180,160,k===1?'6 burchakli prizma: 12 uch, 18 qirra, 8 yoq':'5 burchakli piramida: 6 uch, 10 qirra, 6 yoq',{'font-size':12,'font-weight':800,fill:C.ok})}
var QAP5=[function(){clear();qaCyl(90,140,1.9);qamsg('Silindr: 2 ta doira asos va yon sirt')},
 function(){clear();E('ellipse',{cx:60,cy:40,rx:28,ry:28,fill:'#dfe9f5',stroke:C.blue,'stroke-width':2.2},S.g);E('ellipse',{cx:60,cy:130,rx:28,ry:28,fill:'#dfe9f5',stroke:C.blue,'stroke-width':2.2},S.g);E('rect',{x:110,y:58,width:176,height:56,fill:QAB,stroke:C.blue,'stroke-width':2.2},S.g);qaLab(198,52,'aylana uzunligi (≈ 3,14 · d)',C.bad);qaLab(300,90,'h',C.a2);qamsg('Yon sirtini qirqib yoysak — <b>to‘g‘ri to‘rtburchak</b>')},
 function(){clear();E('circle',{cx:198,cy:30,r:24,fill:'#dfe9f5',stroke:C.blue,'stroke-width':2.2},S.g);E('circle',{cx:198,cy:144,r:24,fill:'#dfe9f5',stroke:C.blue,'stroke-width':2.2},S.g);E('rect',{x:110,y:56,width:176,height:62,fill:QAB,stroke:C.blue,'stroke-width':2.2},S.g);qaLab(330,92,'yoyilma',C.ok);qamsg('Silindr yoyilmasi: to‘rtburchak + 2 ta doira')}];
function qanet(k){clear();var g=S.g,F=QAF;
 function sq(x,y,w,c){E('rect',{x:x,y:y,width:w,height:w,fill:c||F,stroke:C.a2,'stroke-width':2},g)}
 function tri(p,c){E('polygon',{points:p,fill:c||'rgba(18,163,159,.2)',stroke:C.u,'stroke-width':2},g)}
 var hl=function(i){return k===i?(i===1?C.ok:C.bad):'#c9d1da'};
 // A: kub yoyilmasi (6 kvadrat)
 [[34,30],[34,58],[34,86],[34,114],[6,58],[62,58]].forEach(function(p){sq(p[0],p[1],28)});
 // B: piramida yoyilmasi (kvadrat + 4 uchburchak)
 sq(156,62,40);tri('156,62 196,62 176,28');tri('156,102 196,102 176,136');tri('156,62 156,102 122,82');tri('196,62 196,102 230,82');
 // D: uchburchakli prizma yoyilmasi
 E('rect',{x:262,y:40,width:84,height:28,fill:F,stroke:C.a2,'stroke-width':2},g);E('rect',{x:262,y:68,width:84,height:28,fill:F,stroke:C.a2,'stroke-width':2},g);E('rect',{x:262,y:96,width:84,height:28,fill:F,stroke:C.a2,'stroke-width':2},g);tri('262,40 262,68 238,54');tri('346,40 346,68 370,54'.replace('370','358'));
 [['A',48,162],['B',176,162],['D',304,162]].forEach(function(l,i){var c=hl(i);E('circle',{cx:l[1],cy:l[2]-4,r:11,fill:k===i?c:'#fff',stroke:c,'stroke-width':2},g);T(g,l[1],l[2],l[0],{'font-size':12,'font-weight':800,fill:k===i?'#fff':'#5a6b7d'})})}
var QAP8=[function(){clear();qaCube(110,140,1.9);qamsg('Kub: U = 8 uch, Q = 12 qirra, Yo = 6 yoq')},
 function(){clear();qaCube(110,140,1.9);qaLab(270,60,'U − Q + Yo',C.blue);qaLab(270,90,'8 − 12 + 6 = 2',C.ok);qamsg('8 − 12 + 6 = <b>2</b>')},
 function(){clear();qaPyr(110,145,1.9);qaLab(270,60,'piramida (asos 4 burchak)',C.blue);qaLab(270,90,'5 − 8 + 5 = 2',C.ok);qamsg('Piramidada ham <b>2</b>! Bu — Eyler formulasi')}];
var STEPS=[
{h:"Ko'pyoqlar va aylanish jismlari",sum:"Hamma yoqlari tekis ko'pburchak bo'lgan jism — ko'pyoq. Silindr, konus, shar — aylanish jismlari, ularda egri sirt bor.",a:"m01",
 start:function(){qaAll(-1);qamsg('Ikkala tugmani bosing')},fin:function(){qaAll(1);qamsg('Kub, prizma, piramida — <b>ko‘pyoqlar</b>. Silindr, konus, shar — <b>aylanish jismlari</b>')},
 btns:[["Ko'pyoqlar",function(c,done){qaAll(0);qamsg('Kub, prizma, piramida: barcha yoqlari <b>tekis ko‘pburchak</b>');mvK(done,2)}],["Aylanish jismlari",function(c,done){qaAll(1);qamsg('Silindr, konus, shar: <b>egri</b> sirti bor — stolda dumalaydi');mvK(done,2)}]],g2:1,
 html:"<p>Fazoviy jismlarni ikki guruhga ajratamiz. Tugmalarni bosing.</p>",
 after:"<p><b>Ko'pyoqlar</b> (kub, prizma, piramida) — barcha yoqlari tekis ko'pburchaklar, ularda <b>uch</b>, <b>qirra</b>, <b>yoq</b> bor. <b>Aylanish jismlari</b> (silindr, konus, shar) — to'g'ri to'rtburchak, uchburchak yoki yarim doirani o'q atrofida aylantirib hosil qilinadi, ularda egri sirt bor.</p>",
 q:{t:"Qaysi jism stolda dumalay oladi?",opts:["Kub","Silindr","Piramida","Prizma"],ok:1,why:"Silindrning egri sirti bor.",hint:"Qaysi jismda egri sirt bor?",full:"Silindrning yon sirti egri — u yonboshlab dumalaydi. Kub, piramida va prizmaning barcha yoqlari tekis, ular dumalamaydi."},
 tn:"Haqiqiy jismlarni (quti, qalam, konus shaklidagi qog'oz qalpoq, koptok) stolga qo'yib, bolalarni ikki guruhga ajratishga undang."},
{h:"Prizma",sum:"Prizmada 2 ta teng asos (ko'pburchak) va yon yoqlar — to'rtburchaklar. Uchburchakli prizma: 6 uch, 9 qirra, 5 yoq.",a:"m02",
 start:function(){startPh(QAP2)},fin:function(){S.ph=2;QAP2[2]()},
 html:"<p>Shokolad qutisi, tom shakli — <b>prizma</b>. Uning qismlarini sanaymiz.</p>",
 btns:[phaser(QAP2)],
 after:"<p><b>Prizma</b>: ikki asosi — teng va parallel ko'pburchaklar, yon yoqlari — to'rtburchaklar. Asos uchburchak bo'lsa — <b>uchburchakli prizma</b>: 6 uch, 9 qirra, 5 yoq. Kub va to'g'ri burchakli parallelepiped ham prizma (asosi to'rtburchak).</p>",
 q:{t:"To'g'ri burchakli parallelepiped ham prizmami? Uning nechta yoqi bor?",opts:["Ha, 6 ta yoq","Yo'q, 6 ta yoq","Ha, 5 ta yoq","Yo'q, 8 ta yoq"],ok:0,why:"Asosi to'rtburchak bo'lgan prizma: 4 + 2 = 6 yoq.",hint:"Uning ikki asosi teng va parallelmi?",full:"Ha, parallelepiped — to'rtburchakli prizma: 2 asos + 4 yon yoq = 6 yoq. 8 — bu uchlar soni."},
 tn:"Qog'ozdan uchburchakli prizma yasab, uch, qirra, yoqlarni turli rangli stikerlar bilan belgilating."},
{h:"Piramida",sum:"Piramidada bitta asos va bir cho'qqida uchrashuvchi uchburchak yon yoqlar bor. To'rtburchakli piramida: 5 uch, 8 qirra, 5 yoq.",a:"m03",
 start:function(){qaPyrBig(0);qamsg('Asosi kvadrat bo‘lgan piramidaning nechta qirrasi bor?')},fin:function(){qaPyrBig(1);qamsg('✓ Qirralar: 4 + 4 = <b>8</b>')},
 btns:[["5",function(c,done){qamsg('5 — bu uchlar (yoki yoqlar) soni. Qirralarni sanang')}],["8",function(c,done){STEPS[2].fin();done()}],["12",function(c,done){qamsg('12 — kubning qirralari. Piramida boshqacha')}],["4",function(c,done){qamsg('4 — faqat asosdagi qirralar. Cho‘qqiga boradiganlari-chi?')}]],g2:1,
 html:"<p>Misr piramidalari shakli — <b>to'rtburchakli piramida</b>. Uning nechta <b>qirrasi</b> bor?</p>",
 after:"<p>Asosda <b>4</b> ta qirra, har bir asos uchidan cho'qqiga yana bittadan — <b>4</b> ta. Jami <b>8</b>. Uchlar: asosda 4 + cho'qqi 1 = <b>5</b>. Yoqlar: asos 1 + yon uchburchaklar 4 = <b>5</b>.</p>",
 q:{t:"Uchburchakli piramidaning (asosi uchburchak) nechta yoqi bor?",opts:["4","3","5","6"],ok:0,why:"Asos 1 + yon yoqlar 3 = 4.",hint:"Asosni sanashni unutmang.",full:"Asos (1 ta uchburchak) va 3 ta yon uchburchak: 4 ta yoq. Uning hamma yoqlari uchburchak. 3 — asosni unutish xatosi."},
 tn:"Plastilin va cho'plardan piramida yasating: cho'plar — qirralar, plastilin sharchalar — uchlar. Sanash juda oson bo'ladi."},
{h:"Qonuniyat: n burchakli prizma va piramida",sum:"Prizma: 2n uch, 3n qirra, n + 2 yoq. Piramida: n + 1 uch, 2n qirra, n + 1 yoq.",a:"m04",
 start:function(){startPh(QAP4)},fin:function(){S.ph=2;QAP4[2]()},
 html:"<p>Asosda n ta burchak bo'lsa, sanamasdan hisoblash mumkin. Jadvalni to'ldiramiz.</p>",
 btns:[phaser(QAP4)],
 after:"<p><b>Prizma</b>: ikki asosda n tadan uch — <b>2n</b>; qirralar: ikki asosda n tadan va n ta yon qirra — <b>3n</b>; yoqlar: n yon + 2 asos — <b>n + 2</b>. <b>Piramida</b>: <b>n + 1</b> uch, <b>2n</b> qirra, <b>n + 1</b> yoq. Masalan, 6 burchakli prizma: 12 uch, 18 qirra, 8 yoq.</p>",
 q:{t:"Prizmaning 15 ta qirrasi bor. Uning asosi necha burchakli?",opts:["5","15","3","7"],ok:0,why:"3n = 15, n = 5.",hint:"Prizmada qirralar soni n ga qanday bog'liq?",full:"Prizmada qirralar 3n: 3n = 15, n = 5 — besh burchakli prizma (10 uch, 7 yoq). 7 — yoqlar soni."},
 tn:"Bu — olimpiada tipidagi qonuniyat. Avval 3, 4, 5 burchakli prizmalarni jadvalga yozib, bolalar o'zlari qonuniyatni topsin."},
{h:"Silindr va uning yoyilmasi",sum:"Silindr yoyilmasi: 2 ta teng doira va to'g'ri to'rtburchak; to'rtburchakning bir tomoni asos aylanasining uzunligiga teng.",a:"m05",
 start:function(){startPh(QAP5)},fin:function(){S.ph=2;QAP5[2]()},
 html:"<p>Konserva bankasining yorlig'ini kesib ochsak, qanday shakl chiqadi?</p>",
 btns:[phaser(QAP5)],
 after:"<p>Silindrning yon sirti yoyilganda <b>to'g'ri to'rtburchak</b> bo'ladi: bir tomoni — silindr <b>balandligi</b>, ikkinchisi — asos <b>aylanasining uzunligi</b> (≈ 3,14 · d). Bunga 2 ta teng doira — asoslar qo'shiladi.</p>",
 q:{t:"Silindr yorlig'i (yon sirti) yoyilganda 30 sm × 10 sm to'rtburchak chiqdi. Banka balandligi 10 sm. Asos aylanasining uzunligi?",opts:["30 sm","10 sm","40 sm","300 sm"],ok:0,why:"To'rtburchakning ikkinchi tomoni — aylana uzunligi.",hint:"To'rtburchakning qaysi tomoni balandlik, qaysi biri — aylana?",full:"Bir tomon balandlik (10 sm), ikkinchisi — asos aylanasi bo'ylab o'ralgan: 30 sm. 300 — yuzi, 40 — tomonlar yig'indisi."},
 tn:"Qog'oz varag'ini o'rab silindr yasang va yana yoying — bolalar to'rtburchakdan silindr chiqishini qo'lda ko'radi."},
{h:"Konus va shar",sum:"Konus yoyilmasi: doira (asos) va doira bo'lagi (yon sirt). Sharni tekis yoyilmaga yoyib bo'lmaydi.",a:"m06",
 start:function(){clear();qaCone(90,140,1.7);qaSph(260,140,1.6);qamsg('Qaysi jismning yoyilmasini yasab bo‘lmaydi?')},fin:function(){clear();qaCone(90,140,1.7);qaSph(260,140,1.6);E('path',{d:'M60 30 L120 30',stroke:'none'},S.g);qaLab(260,160,'yoyilmasi yo‘q',C.bad);qaLab(90,160,'yoyilmasi: doira + doira bo‘lagi',C.u);qamsg('✓ Shar — qog‘ozdan yasalgan to‘p burishib qoladi')},
 btns:[["Konus",function(c,done){clear();qaCone(90,140,1.7,C.ok);E('path',{d:'M200 140 L260 40 A 116 116 0 0 1 330 120 Z',fill:'rgba(18,163,159,.18)',stroke:C.u,'stroke-width':2.2},S.g);E('circle',{cx:330,cy:152,r:14,fill:'rgba(18,163,159,.18)',stroke:C.u,'stroke-width':2.2},S.g);qamsg('Konusni yoyish mumkin: <b>doira bo‘lagi</b> + kichik doira (asos)')}],["Shar",function(c,done){STEPS[5].fin();done()}],["Silindr",function(c,done){qamsg('Silindr yoyiladi: to‘rtburchak + 2 doira (oldingi qadam)')}]],g3:1,
 html:"<p>Muzqaymoq vafli — <b>konus</b>, koptok — <b>shar</b>. Qaysi jismning tekis yoyilmasini yasab <b>bo'lmaydi</b>?</p>",
 after:"<p><b>Konus</b>ning yoyilmasi: asos — doira, yon sirt — <b>doira bo'lagi (sektor)</b>. <b>Shar</b>ni esa tekis qog'ozdan yasab bo'lmaydi — qanchalik qirqsak ham burishadi. Shuning uchun koptoklar besh va olti burchakli bo'laklardan tikiladi, globus xaritasi esa tasmalardan yopishtiriladi.</p>",
 q:{t:"Qalpoq (konus) yasash uchun qog'ozdan qanday shakl qirqiladi?",opts:["Doira bo'lagi","To'g'ri to'rtburchak","Uchburchak","Kvadrat"],ok:0,why:"Konusning yon sirti — doira bo'lagi.",hint:"Konus uchidan asosga qarab sirti qanday kengayadi?",full:"Doira bo'lagini (sektorni) o'rab, chetlarini yopishtirsak — konus chiqadi. To'g'ri to'rtburchakdan silindr chiqadi, uchburchakdan esa qalpoq tekis bo'lmaydi."},
 tn:"Doiradan bo'lak qirqib, konus qalpoq yasang. Keyin apelsin po'stini tekis yoyishga harakat qiling — shar yoyilmaydi."},
{h:"Qaysi yoyilmadan piramida chiqadi?",sum:"Kvadrat va unga yopishgan 4 ta uchburchak — to'rtburchakli piramidaning yoyilmasi.",a:"m07",
 start:function(){qanet(-1);qamsg('A, B, D yoyilmalardan qaysi biri piramida bo‘ladi?')},fin:function(){qanet(1);qamsg('✓ B: kvadrat asos + 4 ta uchburchak — to‘rtburchakli piramida')},
 btns:[["A",function(c,done){qanet(0);qamsg('A — 6 ta kvadrat: bu <b>kub</b> yoyilmasi')}],["B",function(c,done){STEPS[6].fin();done()}],["D",function(c,done){qanet(2);qamsg('D — 3 ta to‘rtburchak va 2 ta uchburchak: <b>uchburchakli prizma</b>')}]],g3:1,
 html:"<p>Uchta yoyilma berilgan. Qaysi biridan <b>piramida</b> yasash mumkin?</p>",
 after:"<p><b>B</b> — kvadrat asos va to'rt tomonidagi uchburchaklar buklanib, bir cho'qqida uchrashadi: to'rtburchakli piramida. <b>A</b> — kub (6 kvadrat). <b>D</b> — uchburchakli prizma (3 to'rtburchak va 2 uchburchak). Yoyilmadagi yoqlar soni jismdagi yoqlar soniga teng bo'lishi shart.</p>",
 q:{t:"Yoyilmada 2 ta besh burchak va 5 ta to'rtburchak bor. Qaysi jism chiqadi?",opts:["Besh burchakli prizma","Besh burchakli piramida","Kub","Silindr"],ok:0,why:"2 ta teng asos + to'rtburchak yon yoqlar — prizma, asos besh burchak.",hint:"Asoslar nechta? Yon yoqlar qanday shakl?",full:"Ikkita teng besh burchak — asoslar, 5 ta to'rtburchak — yon yoqlar: besh burchakli prizma (7 yoq). Piramidaning yon yoqlari uchburchak va asosi bitta bo'ladi."},
 tn:"Yoyilmalarni chop etib bering: bolalar qirqib, buklab, qaysi jism chiqishini oldindan aytib, keyin tekshirsin."},
{h:"Eyler formulasi",sum:"Har qanday qavariq ko'pyoqda: uchlar − qirralar + yoqlar = 2.",a:"m08",
 start:function(){startPh(QAP8)},fin:function(){S.ph=2;QAP8[2]()},
 html:"<p>Ko'pyoqlarning yashirin «siri» bor. Kub va piramidada tekshiramiz.</p>",
 btns:[phaser(QAP8)],
 after:"<p><b>U − Q + Yo = 2</b> (uchlar − qirralar + yoqlar). Kub: 8 − 12 + 6 = 2. Piramida: 5 − 8 + 5 = 2. Uchburchakli prizma: 6 − 9 + 5 = 2. Bu qoidani XVIII asrda Leonard Eyler isbotlagan. Undan yetishmayotgan sonni topish mumkin!</p>",
 q:{t:"Ko'pyoqda 10 ta uch va 15 ta qirra bor. Nechta yoqi bor?",opts:["7","5","25","2"],ok:0,why:"10 − 15 + Yo = 2 → Yo = 7.",hint:"U − Q + Yo = 2 formulasiga qo'ying.",full:"10 − 15 + Yo = 2, ya'ni Yo = 2 + 15 − 10 = 7. Bu — besh burchakli prizma. 25 — uch va qirralarni qo'shish xatosi."},
 tn:"Bolalar kub, prizma, piramida uchun U, Q, Yo jadvalini to'ldirib, U − Q + Yo ni hisoblasin — hammada 2 chiqishi ularni hayratlantiradi."},
{h:"Bilasizmi? Misr piramidalari",sum:"Gizadagi Xeops piramidasi asosi kvadrat bo'lgan piramida; uning dastlabki balandligi taxminan 146 m bo'lgan.",a:"m09",
 start:function(){qaPyrBig(0);qamsg('To‘rtburchakli piramida: 5 uch, 8 qirra, 5 yoq')},fin:function(){qaPyrBig(0);qamsg('To‘rtburchakli piramida: 5 uch, 8 qirra, 5 yoq')},
 html:"<p>🏜 Misrdagi <b>Xeops piramidasi</b> taxminan 4500 yil oldin qurilgan. Uning asosi kvadrat, dastlabki balandligi taxminan <b>146 m</b> bo'lgan. 3800 yildan ko'proq vaqt davomida u Yerdagi eng baland inshoot bo'lib qolgan.</p><p>⚽ An'anaviy futbol to'pi <b>12 ta besh burchak</b> va <b>20 ta olti burchak</b> bo'lakdan tikiladi — shar tekis bo'laklardan shunday «yig'iladi».</p><p>📐 Shveytsariyalik matematik <b>Leonard Eyler</b> U − Q + Yo = 2 formulasini 1750-yillarda e'lon qilgan.</p>",
 tn:"Futbol to'pidagi bo'laklarni sanab, Eyler formulasini tekshiring: 32 yoq, 90 qirra, 60 uch: 60 − 90 + 32 = 2."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){qaAll(-1);qamsg('Ko‘pyoqlar va aylanish jismlari')},fin:function(){qaAll(-1);qamsg('Ko‘pyoqlar va aylanish jismlari')},
 html:"<div class='memo'><ul><li><b>Ko'pyoqlar</b>: kub, prizma, piramida — yoqlari tekis. <b>Aylanish jismlari</b>: silindr, konus, shar.</li><li>Prizma: 2 teng asos, yon yoqlar — to'rtburchak. n burchakli: 2n uch, 3n qirra, n + 2 yoq.</li><li>Piramida: 1 asos, yon yoqlar — uchburchak. n burchakli: n + 1 uch, 2n qirra, n + 1 yoq.</li><li>Silindr yoyilmasi: to'rtburchak (tomoni — aylana uzunligi) + 2 doira.</li><li>Konus yoyilmasi: doira bo'lagi + doira. Shar — yoyilmaydi.</li><li>Eyler: U − Q + Yo = 2.</li></ul></div>",
 tn:"Uyga: uydagi 6 ta narsani jism turiga qarab jadvalga yozish (masalan, choynak qopqog'i — konus)."}
];
var PROBS=[
{t:"Qaysi jism ko'pyoq emas?",o:["Silindr","Kub","Prizma","Piramida"],k:0,s:"Silindrning egri sirti bor."},
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","24"],k:0,s:"Kub: 8 uch, 12 qirra, 6 yoq."},
{t:"Uchburchakli prizmaning nechta uchi bor?",o:["6","5","9","3"],k:0,s:"Ikki asosda 3 tadan: 6."},
{t:"To'rtburchakli piramidaning nechta uchi bor?",o:["5","4","8","6"],k:0,s:"Asosda 4 va cho'qqi 1: 5."},
{t:"Olti burchakli prizmaning nechta yoqi bor?",o:["8","6","12","18"],k:0,s:"n + 2 = 6 + 2 = 8."},
{t:"Olti burchakli piramidaning nechta qirrasi bor?",o:["12","18","7","6"],k:0,s:"2n = 12."},
{t:"Piramidaning 7 ta yoqi bor. Uning asosi necha burchakli?",o:["6","7","5","8"],k:0,s:"n + 1 = 7, n = 6."},
{t:"Prizmaning 12 ta uchi bor. Nechta qirrasi bor?",o:["18","12","24","8"],k:0,s:"2n = 12, n = 6; qirralar 3n = 18."},
{t:"Qaysi jismning faqat bitta asosi bor?",o:["Konus","Silindr","Prizma","Kub"],k:0,s:"Konus va piramidada bitta asos."},
{t:"Silindr yon sirtining yoyilmasi qanday shakl?",o:["To'g'ri to'rtburchak","Doira","Uchburchak","Doira bo'lagi"],k:0,s:"Yon sirt yoyilganda to'g'ri to'rtburchak."},
{t:"Qaysi jismni tekis qog'ozdan buklab yasab bo'lmaydi?",o:["Shar","Konus","Silindr","Piramida"],k:0,s:"Shar sirti tekislikka yoyilmaydi."},
{t:"Yoyilmada 1 ta kvadrat va 4 ta teng uchburchak bor. Qaysi jism?",o:["To'rtburchakli piramida","Kub","Uchburchakli prizma","Konus"],k:0,s:"Kvadrat asos + 4 uchburchak yon yoq."},
{t:"Yoyilmada 2 ta uchburchak va 3 ta to'rtburchak bor. Qaysi jism?",o:["Uchburchakli prizma","Uchburchakli piramida","Kub","To'rtburchakli piramida"],k:0,s:"2 asos uchburchak + 3 yon to'rtburchak."},
{t:"Ko'pyoqda 6 ta uch va 6 ta yoq bor. Nechta qirrasi bor? (U − Q + Yo = 2)",o:["10","12","8","14"],k:0,s:"6 − Q + 6 = 2 → Q = 10 (besh burchakli piramida)."},
{t:"Ko'pyoqda 12 ta qirra va 8 ta uch bor. Nechta yoqi bor?",o:["6","4","20","8"],k:0,s:"8 − 12 + Yo = 2 → Yo = 6 (kub)."},
{t:"Banka balandligi 12 sm, asos aylanasi 25 sm. Yorliqning (yon sirt) yuzi?",o:["300 kv. sm","37 kv. sm","74 kv. sm","150 kv. sm"],k:0,s:"Yorliq — 25 × 12 to'rtburchak: 300 kv. sm."},
{t:"Kub qirrasi 3 sm. Barcha qirralari uzunliklari yig'indisi?",o:["36 sm","27 sm","24 sm","18 sm"],k:0,s:"12 qirra · 3 = 36 sm."},
{t:"Piramida asosi kvadrat, tomoni 4 sm; har bir yon qirrasi 5 sm. Barcha qirralar yig'indisi?",o:["36 sm","20 sm","40 sm","18 sm"],k:0,s:"Asos 4 · 4 = 16, yon 4 · 5 = 20, jami 36 sm."},
{t:"Uchburchakli prizmaning barcha qirralari 2 sm dan. Qirralar yig'indisi?",o:["18 sm","12 sm","10 sm","24 sm"],k:0,s:"9 qirra · 2 = 18 sm."},
{t:"Qaysi jismda uchlar soni yoqlar soniga teng?",o:["Har qanday piramida","Har qanday prizma","Kub","Silindr"],k:0,s:"Piramida: n + 1 uch va n + 1 yoq."}
];
function PRACT_STAGE(){qaAll(-1)}
var PREP_DATA={teach:["Ko'pyoqlar va aylanish jismlari.","Prizma va piramida: uch, qirra, yoq; n burchakli holat uchun qonuniyat.","Silindr, konus, shar va ularning yoyilmalari.","Yoyilmani jism bilan moslashtirish; Eyler formulasi U − Q + Yo = 2."],
 mist:["Piramidaning asosini yoqlar qatoriga qo'shmaydi.","Qirra va uchlarni aralashtiradi.","Prizma qirralarini 2n deb hisoblaydi (yon qirralarni unutadi).","Sharni ham yoyish mumkin deb o'ylaydi.","Silindr yoyilmasida to'rtburchak tomonini diametrga tenglaydi."],
 need:["Jismlar to'plami yoki uydagi narsalar (quti, banka, qalpoq, koptok).","Chop etilgan yoyilmalar, qaychi, yelim.","Plastilin va cho'plar."],
 board:["Ko'pyoq: kub, prizma, piramida.","Aylanish jismlari: silindr, konus, shar.","Prizma: 2n, 3n, n + 2.","Piramida: n + 1, 2n, n + 1.","Silindr yoyilmasi: □ + 2○.","U − Q + Yo = 2."]};
