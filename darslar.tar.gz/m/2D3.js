var CODE='2D3',TITLE='2-sinf · Ikki amalli masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
var HV='Hovuzda 45 bola. 18 tasi chiqdi, keyin 12 tasi tushdi.';
var STEPS=[
bmStep({h:"Bitta amal yetmaydi",sum:"Ikki amalli masalada ikki o'zgarish bor: 45 − 18 = 27, 27 + 12 = 39.",a:"m01",
 frames:[{t:HV+' Nechta bola bor?',bars:[{lab:'boshida',y:34,segs:[{w:45,txt:'45',c:'b'}]}],note:'Hovuzda 45 bola suzyapti'},
  {t:HV+' Nechta bola bor?',bars:[{lab:'boshida',y:34,segs:[{w:27,txt:'27',c:'b'},{w:18,txt:'18 chiqdi',c:'x'}]},{lab:'keyin',y:86,segs:[{w:27,txt:'27',c:'b'}]}],calc:['1) 45 − 18 = <b>27</b> — qoldi (bu hali javob emas)']},
  {t:HV+' Nechta bola bor?',bars:[{lab:'boshida',y:34,segs:[{w:27,txt:'27',c:'b'},{w:18,txt:'18 chiqdi',c:'x'}]},{lab:'keyin',y:86,segs:[{w:27,txt:'27',c:'b'},{w:12,txt:'+12',c:'g'}]}],br:[{b:1,lab:'39',up:false,col:C.ok}],calc:['1) 45 − 18 = 27','2) 27 + 12 = <b>39</b> bola']}],
 html:"<p>Ba'zi masalalarda <b>ikki</b> o'zgarish bo'ladi. Ularni ketma-ket, <b>bittadan</b> bajaramiz. Kuzating.</p>",
 after:"<p>Ikki amalli masala = ikkita bir amalli masala ketma-ket. Birinchi amalning javobi — ikkinchisi uchun <b>yangi son</b>.</p>",
 q:{t:"Avtobusda 30 kishi bor edi. Bekatda 8 kishi tushdi, 5 kishi chiqdi. Avtobusda nechta kishi bo'ldi?",opts:["43","27","22","17"],ok:1,why:"30 − 8 = 22, 22 + 5 = 27.",hint:"Avval tushganlarni, keyin chiqqanlarni hisoblang.",full:"1) Tushdi: 30 − 8 = 22. 2) Chiqdi: 22 + 5 = 27. «22» — birinchi qadamda to'xtab qolish, «43» — ikkalasini qo'shish xatosi."},
 tn:"Bolalar har amalni alohida qatorga raqamlab yozsin: «1)», «2)». Bu yuqori sinflarga tayyorlaydi."}),
bmStep({h:"Reja: avval nimani topamiz?",sum:"Savoldan orqaga o'ylaymiz: qoldiqni bilish uchun avval jami teriganni topamiz.",a:"m02",
 frames:[{t:'Masala',lines:['1-daraxtdan 46 kg, 2-sidan 38 kg xurmo terildi.','59 kg qishga olib qo‘yildi.','Necha kg xurmo qoldi?'],hl:{2:'q'}}],
 html:"<p>Masalani yechishdan oldin <b>reja</b> tuzamiz. Qolganini bilish uchun avval nimani bilishimiz kerak? Tanlang:</p>",
 btns:bmPick(["Jami terilganini","46 − 38 ni","59 − 38 ni"],0,{t:'Reja va yechim',bars:[{y:56,segs:[{w:46,txt:'46',c:'a'},{w:38,txt:'38',c:'g'}]},{y:120,segs:[{w:59,txt:'59 olib qo‘yildi',c:'x'},{w:25,txt:'?',c:'q'}]}],br:[{b:0,lab:'84 kg',up:true}],calc:['1) Jami: 46 + 38 = 84 kg','2) Qoldi: 84 − 59 = <b>25</b> kg']},["Daraxtlar farqi bizga kerak emas.","59 kg ikkala daraxtdan olingan — faqat ikkinchisidan emas."]),
 after:"<p>Reja tuzish usuli: <b>savoldan boshlang</b>. «Qoldi» → butundan qismni ayiramiz → butun (jami terilgan) kerak → uni avval topamiz.</p>",
 q:{t:"90 m arqondan 25 m va 35 m li ikki bo'lak kesildi. Necha metr qoldi?",opts:["20","30","60","40"],ok:1,why:"Kesilgani 25 + 35 = 60, qoldi 90 − 60 = 30.",hint:"Avval jami qancha kesilganini toping.",full:"1) Kesildi: 25 + 35 = 60 m. 2) Qoldi: 90 − 60 = 30 m. Boshqa yo'l: 90 − 25 − 35 = 30. «60» — kesilgani, qolgani emas."},
 tn:"«Savoldan orqaga» fikrlash — Polyaning masala yechish usulining bir qismi. Bolalarga «nimani bilishimiz kerak?» savolini berib turing."}),
bmStep({h:"Bir masala — ikki yo'l",sum:"90 − 25 − 35 = 30 yoki 90 − (25 + 35) = 30. Javob bir xil.",a:"m03",
 frames:[{t:'90 m arqondan 25 m va 35 m kesildi',bars:[{y:66,segs:[{w:25,txt:'25',c:'x'},{w:35,txt:'35',c:'x'},{w:30,txt:'?',c:'q'}]}],br:[{b:0,lab:'90 m',up:true}],note:'1-yo‘l: bo‘laklarni ketma-ket ayiramiz'},
  {t:'90 m arqondan 25 m va 35 m kesildi',bars:[{y:66,segs:[{w:25,txt:'25',c:'x'},{w:35,txt:'35',c:'x'},{w:30,txt:'30',c:'g'}]}],br:[{b:0,lab:'90 m',up:true}],calc:['1-yo‘l: 90 − 25 = 65, 65 − 35 = <b>30</b>']},
  {t:'90 m arqondan 25 m va 35 m kesildi',bars:[{y:66,segs:[{w:60,txt:'60 kesildi',c:'x'},{w:30,txt:'30',c:'g'}]}],br:[{b:0,lab:'90 m',up:true}],calc:['1-yo‘l: 90 − 25 − 35 = 30','2-yo‘l: 90 − (25 + 35) = 90 − 60 = <b>30</b> ✓']}],
 html:"<p>Ko'p masalani bir necha yo'l bilan yechish mumkin. Ikkala yo'lni ko'ramiz.</p>",
 after:"<p>Ikki xil yo'l bilan bir xil javob chiqsa — javob <b>to'g'ri</b>. Bu eng ishonchli tekshirish usuli!</p>",
 q:{t:"Qaysi yozuv «50 ta sharning 12 tasi va yana 18 tasi uchib ketdi, nechta qoldi?» masalasining yechimi EMAS?",opts:["50 − 12 − 18","50 − (12 + 18)","50 − 12 + 18","50 − 30"],ok:2,why:"Uchib ketgani qo'shilmaydi, ayiriladi: «+18» xato.",hint:"Uchib ketgan sharlar qo'shiladimi yoki ayiriladimi?",full:"Ikkala guruh ham uchib ketdi — ikkalasi ham ayiriladi: 50 − 12 − 18 = 20 yoki 50 − (12 + 18) = 20. «50 − 12 + 18» = 56 — sharlar ko'payib qoldi, bu xato."},
 tn:"Bolalarga bitta masalani ikki xil yechib, juftlikda solishtirishni bering — Yaponiya darslarining odatiy usuli."}),
bmStep({h:"Ko'p qismli masala",sum:"42 bola: 11 + 9 + 8 = 28 to'garakda, futbolga 42 − 28 = 14.",a:"m04",
 frames:[{t:'To‘garaklarda 42 bola: rasm 11, raqs 9, shaxmat 8, qolgani futbol',bars:[{y:66,segs:[{w:11,txt:'11',c:'a'},{w:9,txt:'9',c:'c'},{w:8,txt:'8',c:'b'},{w:14,txt:'?',c:'q'}]}],br:[{b:0,lab:'42',up:true}],note:'To‘rt qism, bittasi noma’lum'},
  {t:'To‘garaklarda 42 bola: rasm 11, raqs 9, shaxmat 8, qolgani futbol',bars:[{y:66,segs:[{w:28,txt:'28',c:'x'},{w:14,txt:'14',c:'g'}]}],br:[{b:0,lab:'42',up:true}],calc:['1) Ma’lum qismlar: 11 + 9 + 8 = 28','2) Futbol: 42 − 28 = <b>14</b>']}],
 html:"<p>Qismlar ko'p bo'lsa ham usul bir xil: ma'lum qismlarni birlashtirib, butundan ayiramiz.</p>",
 after:"<p>Tez qo'shish uchun qulay juftlik qidiring: 11 + 9 = 20, keyin 20 + 8 = 28.</p>",
 q:{t:"Sinfda 30 o'quvchi: 12 tasi kitob, 9 tasi rasm, qolganlari o'yin tanladi. Nechta o'quvchi o'yin tanladi?",opts:["21","9","18","51"],ok:1,why:"12 + 9 = 21, 30 − 21 = 9.",hint:"Avval kitob va rasm tanlaganlarni qo'shing.",full:"1) 12 + 9 = 21. 2) 30 − 21 = 9. «21» — bu kitob va rasm, o'yin emas."},
 tn:"Ko'p qismli chizmada har qismni boshqa rangda bo'yatish xatoni kamaytiradi."}),
bmStep({h:"Tuzoq: yashirin odam",sum:"«Laylo sinfdoshlari orasida 11 qiz» — Laylo o'zi ham qiz: 28 − 11 − 1 = 16 o'g'il.",a:"m05",
 frames:[{t:'Masala',lines:['Sinfda 28 ta o‘quvchi bor.','Laylo sinfdoshlari orasida 11 ta qiz bor.','Sinfda nechta o‘g‘il bola bor?'],hl:{1:'q'}}],
 html:"<p>Bankdagi qiyin masala. Ko'pchilik 28 − 11 = 17 deydi. Lekin 2-gapga diqqat qiling: <b>kimning</b> sinfdoshlari? Javobni tanlang:</p>",
 btns:bmPick(["17","16","11"],1,{t:'Laylo ham sinfda!',bars:[{y:66,segs:[{w:11,txt:'11 qiz',c:'c'},{w:1,txt:'L',c:'y'},{w:16,txt:'16 o‘g‘il',c:'b'}]}],br:[{b:0,lab:'28',up:true}],calc:['Qizlar: 11 sinfdosh + Laylo o‘zi = 12','O‘g‘illar: 28 − 12 = <b>16</b>']},["Laylo o‘zini sanadingizmi? U ham qiz!","","11 — qizlar (Laylodan tashqari), o‘g‘illar emas."]),
 after:"<p>Laylo o'zining sinfdoshi emas! «Laylo sinfdoshlari orasida 11 qiz» — Laylodan <b>tashqari</b> 11 qiz. Jami qizlar 12 ta, o'g'illar 28 − 12 = <b>16</b>.</p>",
 q:{t:"Navbatda 15 kishi turibdi. Alidan oldin 6 kishi bor. Alidan keyin nechta kishi bor?",opts:["9","8","6","21"],ok:1,why:"15 − 6 − 1 (Ali o'zi) = 8.",hint:"Ali o'zi ham navbatda turibdi — uni ham hisobga oling.",full:"Navbatda: 6 kishi (Alidan oldin) + Ali + keyingilar = 15. Keyingilar: 15 − 6 − 1 = 8. «9» — Alining o'zini unutish xatosi."},
 tn:"Bunday masalalarni bolalar bilan sahnalashtiring: navbatda turib, sanab ko'ring."}),
bmStep({h:"Tuzoq: avval sonni topamiz",sum:"«Sonning yarmi 14» → son 28; 28 − 9 = 19.",a:"m06",
 frames:[{t:'Bir sonning YARMI 14 ga teng. Shu son 9 dan qancha katta?',bars:[{y:44,segs:[{w:14,txt:'14',c:'a'},{w:14,txt:'14',c:'a'}]}],br:[{b:0,lab:'son = ?',up:true}],note:'Yarmi 14 bo‘lsa, butun son qancha?'},
  {t:'Bir sonning YARMI 14 ga teng. Shu son 9 dan qancha katta?',bars:[{lab:'son',y:44,segs:[{w:9,txt:'9',c:'b'},{w:19,txt:'19',c:'g'}]},{lab:'9',y:108,segs:[{w:9,txt:'9',c:'b'}]}],calc:['1) Son: 14 + 14 = 28','2) Farq: 28 − 9 = <b>19</b>']}],
 html:"<p>Bu masalada son yashiringan. Avval uni ochamiz, keyin savolga javob beramiz. Kuzating.</p>",
 after:"<p>Xato yo'l: 14 − 9 = 5 (yarmini olish). Yarmi — bu sonning <b>teng ikki bo'lagidan biri</b>, butun son ikki marta katta.</p>",
 q:{t:"Bir sonning yarmi 20 ga teng. Shu son 15 dan qancha katta?",opts:["5","25","35","40"],ok:1,why:"Son 40, 40 − 15 = 25.",hint:"Avval butun sonni toping: yarmi 20 bo'lsa, o'zi qancha?",full:"Son: 20 + 20 = 40. Farq: 40 − 15 = 25. «5» — yarmini olish xatosi."},
 tn:"Yarim tushunchasini qog'ozni buklab ko'rsating."}),
bmStep({h:"O'zingiz yeching",sum:"Hovuz: 45 − 18 + 12 = 39. Har qadamni chizmada tekshiramiz.",a:"m07",
 frames:[{t:'Kutubxonada 64 kitob bor edi. 27 tasi berildi, 15 tasi qaytarildi.',bars:[{lab:'boshida',y:40,segs:[{w:64,txt:'64',c:'b'}]},{lab:'oxirida',y:104,segs:[{w:52,txt:'?',c:'q'}]}],note:'Avval qaysi amalni bajarasiz?'}],
 html:"<p>Masala: <i>«Kutubxonada 64 ta kitob bor edi. 27 tasini o'quvchilar olib ketdi, 15 tasini qaytarib olib kelishdi. Kutubxonada nechta kitob bo'ldi?»</i> Birinchi amalni tanlang:</p>",
 btns:bmPick(["64 − 27","64 + 27","27 − 15"],0,{t:'Kutubxonada 64 kitob bor edi. 27 tasi berildi, 15 tasi qaytarildi.',bars:[{lab:'boshida',y:40,segs:[{w:37,txt:'37',c:'b'},{w:27,txt:'27 berildi',c:'x'}]},{lab:'oxirida',y:104,segs:[{w:37,txt:'37',c:'b'},{w:15,txt:'+15',c:'g'}]}],br:[{b:1,lab:'52',up:false,col:C.ok}],calc:['1) 64 − 27 = 37','2) 37 + 15 = <b>52</b> kitob']},["Kitoblar olib ketildi — ko‘paymadi.","Bu ham yo‘l (12 ta kam qaytdi), lekin avval voqea tartibida yechib ko‘ring."]),
 after:"<p>Voqealar qanday tartibda bo'lsa, amallar ham shunday tartibda. Ayyor yo'l: 27 ta ketib, 15 tasi qaytdi — jami 12 ta kam: 64 − 12 = 52.</p>",
 q:{t:"Mashinada 50 litr benzin bor edi. 35 litr sarflandi, keyin 20 litr quyildi. Mashinada necha litr benzin bor?",opts:["35","15","65","5"],ok:0,why:"50 − 35 = 15, 15 + 20 = 35.",hint:"Avval sarflanganini ayiring, keyin quyilganini qo'shing.",full:"1) 50 − 35 = 15 litr qoldi. 2) 15 + 20 = 35 litr. «15» — ikkinchi qadamni unutish."},
 tn:"Bolalarga har qadamdan keyin chizmadagi chiziq qisqaradimi yoki uzayadimi — shuni so'rang."}),
bmStep({h:"Bilasizmi? Eng qadimgi masalalar kitobi",sum:"Misrning Rind papirusi (≈3600 yil oldin) — 80 dan ortiq masala.",a:"m08",
 frames:[{t:'Rind papirusi',bg:'#f6ead0',bars:[{y:50,h:70,segs:[{w:1,txt:'∩∩∩ |||| ∩∩ |||',c:'#e8d5a8',fs:20}]}],note:'Misrlik kotib Axmes ko‘chirib yozgan'}],
 html:"<p>📜 Taxminan <b>3600 yil oldin</b> Misrda kotib <b>Axmes</b> papirusga 80 dan ortiq matematik masala yozgan. Uni bugun «Rind papirusi» deyishadi va London muzeyida saqlanadi.</p><p>Unda non va pivoni bo'lishish, omborni to'ldirish haqida ikki va ko'p amalli masalalar bor — xuddi bizning masalalarga o'xshash!</p>",
 tn:"Bolalarga ayting: matnli masalalar ming yillardan beri hayotiy muammolarni hal qilish uchun yechiladi."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'Ikki amal — ikki qadam',bars:[{lab:'1)',y:40,segs:[{w:27,txt:'',c:'b'},{w:18,txt:'−',c:'x'}]},{lab:'2)',y:100,segs:[{w:27,txt:'',c:'b'},{w:12,txt:'+',c:'g'}]}]}],
 html:"<div class='memo'><ul><li>Ikki amalli masala — <b>ikkita</b> bir amalli masala ketma-ket.</li><li><b>Reja:</b> savoldan boshlang — «buni bilish uchun avval nima kerak?»</li><li>Amallarni raqamlang: <b>1)</b>, <b>2)</b>. Birinchi javob — hali yakuniy javob emas.</li><li>Ko'p qismli: ma'lum qismlarni qo'shib, butundan ayiring.</li><li>Yashirin odam: «Laylo sinfdoshlari» — Layloning o'zi sanalmagan!</li><li>«Sonning yarmi 14» — avval sonni toping (28).</li><li>Ikki xil yo'l bilan tekshiring.</li></ul></div>",
 tn:"Keyingi darsni «Navbatda Alidan oldin 4, keyin 7 kishi. Navbatda jami nechta?» (12 ta) savoli bilan boshlang."})
];
var PROBS=[
{t:"Hovuzda 45 bola suzayotgan edi. 18 tasi chiqib ketdi, keyin 12 tasi suvga tushdi. Endi nechta bola bor?",o:["39","27","51","15"],k:0,s:"45 − 18 = 27, 27 + 12 = 39."},
{t:"1-daraxtdan 46 kg, 2-sidan 38 kg xurmo terildi. 59 kg qishga olib qo'yildi. Necha kg qoldi?",o:["25","35","84","143"],k:0,s:"46 + 38 = 84, 84 − 59 = 25."},
{t:"90 m arqondan 25 m va 35 m li bo'laklar kesildi. Necha metr qoldi?",o:["30","60","20","40"],k:0,s:"25 + 35 = 60, 90 − 60 = 30."},
{t:"42 bola to'garakda: rasmga 11, raqsga 9, shaxmatga 8, qolgani futbolga qatnashadi. Futbolga nechta?",o:["14","13","22","28"],k:0,s:"11 + 9 + 8 = 28, 42 − 28 = 14."},
{t:"Sinfda 28 o'quvchi. Laylo sinfdoshlari orasida 11 ta qiz bor. Sinfda nechta o'g'il bola bor?",o:["16","17","11","15"],k:0,s:"Qizlar 11 + Laylo = 12. O'g'illar 28 − 12 = 16."},
{t:"Bir sonning yarmi 14 ga teng. Shu son 9 dan qancha katta?",o:["19","5","23","37"],k:0,s:"Son 28, 28 − 9 = 19."},
{t:"Avtobusda 30 kishi bor edi. 8 kishi tushdi, 5 kishi chiqdi. Avtobusda nechta kishi bo'ldi?",o:["27","22","43","17"],k:0,s:"30 − 8 = 22, 22 + 5 = 27."},
{t:"Do'konda 70 ta daftar bor edi. Ertalab 24 ta, kechqurun 18 ta sotildi. Nechta daftar qoldi?",o:["28","42","46","52"],k:0,s:"24 + 18 = 42, 70 − 42 = 28."},
{t:"Alida 25 ta, Valida undan 8 ta ko'p yong'oq bor. Ikkalasida jami nechta yong'oq?",o:["58","33","42","17"],k:0,s:"Vali 33, jami 25 + 33 = 58."},
{t:"Navbatda 15 kishi. Alidan oldin 6 kishi bor. Alidan keyin nechta kishi bor?",o:["8","9","6","21"],k:0,s:"15 − 6 − 1 = 8 (Alining o'zi ham sanaladi)."},
{t:"Kutubxonada 64 kitob bor edi. 27 tasi olib ketildi, 15 tasi qaytarildi. Nechta kitob bo'ldi?",o:["52","37","76","22"],k:0,s:"64 − 27 = 37, 37 + 15 = 52."},
{t:"Bir sonning yarmi 20. Shu son 15 dan qancha katta?",o:["25","5","35","40"],k:0,s:"Son 40, 40 − 15 = 25."},
{t:"Sinfda 30 o'quvchi: 12 tasi kitob, 9 tasi rasm, qolganlari o'yin tanladi. Nechtasi o'yin tanladi?",o:["9","21","18","51"],k:0,s:"12 + 9 = 21, 30 − 21 = 9."},
{t:"Mashinada 50 litr benzin bor edi. 35 litri sarflandi, keyin 20 litr quyildi. Necha litr bo'ldi?",o:["35","15","65","5"],k:0,s:"50 − 35 = 15, 15 + 20 = 35."},
{t:"Lentaning uzunligi 80 sm. Undan 26 sm va 19 sm kesib olindi. Lentaning qancha qismi qoldi?",o:["35 sm","45 sm","61 sm","54 sm"],k:0,s:"26 + 19 = 45, 80 − 45 = 35 sm."},
{t:"Zaynab 3 kun kitob o'qidi: 12, 15 va 18 sahifa. Kitobda 60 sahifa bo'lsa, nechta sahifa qoldi?",o:["15","45","25","33"],k:0,s:"12 + 15 + 18 = 45, 60 − 45 = 15."},
{t:"Qatorda 20 ta bola turibdi. Sardor chapdan 7-o'rinda. U o'ngdan nechanchi o'rinda?",o:["14","13","27","7"],k:0,s:"Undan o'ngda 20 − 7 = 13 bola, demak o'ngdan 14-o'rin."},
{t:"Ota 9 000 so'm, ona 6 000 so'm berdi. Bola 11 000 so'mlik kitob oldi. Unda qancha pul qoldi?",o:["4 000 so'm","15 000 so'm","26 000 so'm","3 000 so'm"],k:0,s:"9 000 + 6 000 = 15 000, 15 000 − 11 000 = 4 000."},
{t:"Bekzodda 34 marka bor. U 12 tasini ukasiga berdi, keyin do'stidan 9 ta oldi. Unda nechta marka bo'ldi?",o:["31","13","55","22"],k:0,s:"34 − 12 = 22, 22 + 9 = 31."},
{t:"Sinfda 25 o'quvchi. Ulardan 14 tasi rasm, 13 tasi musiqa to'garagida, har bir o'quvchi kamida bittasida. Nechtasi ikkala to'garakda?",o:["2","27","11","12"],k:0,s:"14 + 13 = 27 — bu 25 dan 2 ta ko'p, demak 2 o'quvchi ikki marta sanalgan."}
];
function PRACT_STAGE(){bmDraw({t:'Har amalni raqamlang: 1), 2)',bars:[{lab:'1)',y:40,segs:[{w:27,txt:'',c:'b'},{w:18,txt:'',c:'x'}]},{lab:'2)',y:100,segs:[{w:27,txt:'',c:'b'},{w:12,txt:'',c:'g'}]}],note:'Reja: savoldan boshlang'})}
var PREP_DATA={teach:["Ikki amalli masala: ikki o'zgarish ketma-ket.","Reja tuzish: savoldan orqaga fikrlash.","Bir masalani ikki xil yechish va tekshirish.","Tuzoqlar: yashirin odam (Laylo), «sonning yarmi», ko'p qismli masala."],
 mist:["Birinchi amaldan keyin to'xtab qoladi.","Barcha sonlarni qo'shib yuboradi.","«Laylo sinfdoshlari» da Layloni sanamaydi.","«Yarmi 14» ni son deb oladi."],
 need:["Rangli tasmalar, navbat o'yini uchun bolalar."],
 board:["<span class='w2'>1) 45 − 18 = 27</span>, <span class='w2'>2) 27 + 12 = 39</span>.","Reja: «qoldi» ← «jami» ← qo'shish.","<span class='w2'>90 − 25 − 35 = 90 − (25 + 35)</span>.","Laylo: <span class='w2'>28 − 11 − 1 = 16</span>.","Navbat: <span class='w2'>15 − 6 − 1 = 8</span>."]};
