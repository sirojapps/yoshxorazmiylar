var CODE='2Y5',TITLE='2-sinf yakuni · Tenglama tuzib yechiladigan masalalar';
// ---------- tarozi sahnasi ----------
// L, R: [{t:'x'} | {n:5}] — chap va o'ng pallalar
function y5scale(L,R,o){o=o||{};clear();var g=S.g;
 E('path',{d:'M180 150 L165 168 L195 168 Z',fill:'#8a5a24'},g);E('line',{x1:180,y1:150,x2:180,y2:62,stroke:'#8a5a24','stroke-width':4},g);
 E('line',{x1:40,y1:62,x2:320,y2:62,stroke:'#8a5a24','stroke-width':4,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:62,r:5,fill:'#5b3b1c'},g);
 [[90,L],[270,R]].forEach(function(z){var cx=z[0];E('line',{x1:cx-50,y1:62,x2:cx-50,y2:100,stroke:'#b9a27c'},g);E('line',{x1:cx+50,y1:62,x2:cx+50,y2:100,stroke:'#b9a27c'},g);E('path',{d:'M'+(cx-60)+' 100 Q'+cx+' 122 '+(cx+60)+' 100 Z',fill:'#e9dcc6',stroke:'#b9a27c','stroke-width':2},g);
  var items=z[1],w=items.length*30,x=cx-w/2+15;items.forEach(function(it){if(it.t){E('rect',{x:x-13,y:70,width:26,height:28,rx:4,fill:it.hl?C.hi:C.a,stroke:C.line,'stroke-width':1.5},g);T(g,x,89,it.t,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}else{E('rect',{x:x-13,y:74,width:26,height:24,rx:6,fill:it.cut?'#ffd0d0':'#cfd6de',stroke:it.cut?C.bad:'#7b8896','stroke-width':1.5,'stroke-dasharray':it.cut?'4 2':''},g);T(g,x,90,String(it.n),{'font-size':12,'font-weight':800,fill:it.cut?C.bad:'#1d2b3a'})}x+=30})});
 if(o.lab)T(g,180,30,o.lab,{'font-size':18,'font-weight':800,fill:C.blue})}
function y5eq(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:19px">'+h+'</div></div>'}
var P1=[function(){y5scale([{t:'x'},{n:5}],[{n:12}],{lab:'x + 5 = 12'});y5eq('x + 5 = 12','Tarozi muvozanatda: chap = o‘ng')},
 function(){y5scale([{t:'x'},{n:5,cut:1}],[{n:7},{n:5,cut:1}],{lab:'ikki tomondan 5 ni olamiz'});y5eq('x + 5 − 5 = 12 − 5','12 ni 7 va 5 ga ajratib, ikkala pallardan 5 ni olamiz')},
 function(){y5scale([{t:'x',hl:1}],[{n:7}],{lab:'x = 7'});y5eq('<b>x = 7</b>. Tekshiramiz: 7 + 5 = 12 ✓')}];
var P3=[function(){y5scale([{t:'x'},{t:'x'},{t:'x'},{t:'x'}],[{n:28}],{lab:'4 · x = 28'});y5eq('4 · x = 28','4 ta bir xil quti — 28 kg')},
 function(){y5scale([{t:'x'},{t:'x'},{t:'x'},{t:'x'}],[{n:7},{n:7},{n:7},{n:7}],{lab:'28 ni 4 ta teng bo‘lakka'});y5eq('28 : 4 = 7','O‘ng tomonni ham 4 ta teng bo‘lakka bo‘lamiz')},
 function(){y5scale([{t:'x',hl:1}],[{n:7}],{lab:'x = 7'});y5eq('<b>x = 7</b>. Tekshiramiz: 4 · 7 = 28 ✓')}];
var P5=[function(){y5chain(0)},function(){y5chain(1)},function(){y5chain(2)}];
var P6=[function(){y5scale([{t:'x'},{t:'x'},{n:3}],[{n:11}],{lab:'2 · x + 3 = 11'});y5eq('x + x + 3 = 11','Ikki bir xil quti va 3 kg tosh = 11 kg')},
 function(){y5scale([{t:'x'},{t:'x'},{n:3,cut:1}],[{n:8},{n:3,cut:1}],{lab:'avval 3 ni olamiz'});y5eq('x + x = 11 − 3 = 8','Ikkala tomondan 3 kg olib tashlaymiz')},
 function(){y5scale([{t:'x'},{t:'x'}],[{n:4},{n:4}],{lab:'8 ni 2 ga bo‘lamiz'});y5eq('x = 8 : 2 = <b>4</b>. Tekshiramiz: 4 + 4 + 3 = 11 ✓')}];
var STEPS=[
{h:"Tenglama — muvozanatdagi tarozi",sum:"x + 5 = 12: ikkala tomondan 5 ni olamiz → x = 7.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Tarozining chap pallasida noma'lum og'irlikdagi quti (<b>x</b>) va 5 kg tosh, o'ng pallasida 12 kg. Tarozi <b>teng</b> turibdi. Quti necha kg? Bunday yozuv — <b>tenglama</b>: x + 5 = 12.</p>",
 btns:[phaser(P1)],
 after:"<p>Asosiy qoida: tarozi muvozanatda qolishi uchun <b>ikkala tomonga bir xil ish</b> qilamiz. Ikkala tomondan 5 ni oldik — quti yolg'iz qoldi: x = 7. Har doim tekshiring: 7 + 5 = 12 ✓</p>",
 q:{t:"x + 9 = 15. x = ?",opts:["6","24","9","5"],ok:0,why:"15 − 9 = 6.",hint:"Ikkala tomondan 9 ni oling.",full:"x + 9 = 15 → x = 15 − 9 = 6. Tekshiramiz: 6 + 9 = 15 ✓. «24» — 15 + 9, teskari amal o'rniga qo'shilgan."},
 tn:"Haqiqiy tarozi bo'lmasa, chizg'ich va qalam bilan «tarozi» yasang. Xalqaro darsliklarda tenglamani tarozi bilan kiritish eng tushunarli usul hisoblanadi."},
{h:"Ayirishli tenglama",sum:"x − 8 = 15: kamayuvchi = ayirma + ayriluvchi → x = 15 + 8 = 23.",a:"m02",
 start:function(){y5bar(0)},fin:function(){y5bar(2)},
 html:"<p><i>«Ipdan 8 sm kesildi, 15 sm qoldi. Ip necha sm edi?»</i> — tenglama: <b>x − 8 = 15</b>. Chizmada ko'ramiz:</p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.y5b=(S.y5b||0)+1;y5bar(S.y5b);if(S.y5b>=2){b.disabled=true;done()}}]],
 after:"<p>Butun ip = kesilgan + qolgan: x = 8 + 15 = <b>23</b>. Noma'lum <b>kamayuvchini</b> topish uchun ayirmaga ayriluvchini qo'shamiz.</p>",
 q:{t:"x − 17 = 20. x = ?",opts:["37","3","20","17"],ok:0,why:"x = 20 + 17 = 37.",hint:"x — butun narsa. Undan 17 olindi, 20 qoldi. Butun qancha?",full:"Kamayuvchi = ayirma + ayriluvchi: 20 + 17 = 37. Tekshiramiz: 37 − 17 = 20 ✓. «3» — 20 − 17, bu xato yo'nalish."},
 tn:"Bolalar har tenglamada «x — qism yoki butun?» deb o'zidan so'rasin: butun bo'lsa — qo'shamiz, qism bo'lsa — ayiramiz."},
{h:"Ko'paytirishli tenglama",sum:"4 · x = 28: 4 ta teng quti → 28 : 4 = 7.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Chap pallada 4 ta <b>bir xil</b> quti, o'ngda 28 kg. Bitta quti necha kg? <b>4 · x = 28</b>.</p>",
 btns:[phaser(P3)],
 after:"<p>O'ng tomonni ham 4 ta teng bo'lakka bo'lsak, har bir qutiga 7 tushadi: x = 28 : 4 = <b>7</b>. Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi.</p>",
 q:{t:"6 · x = 42. x = ?",opts:["7","36","48","6"],ok:0,why:"42 : 6 = 7.",hint:"6 ta bir xil quti 42 kg bo'lsa, bittasi necha kg?",full:"x = 42 : 6 = 7. Tekshiramiz: 6 · 7 = 42 ✓. «36» — 42 − 6, ko'paytirish o'rniga ayirish teskari amal sifatida olingan."},
 tn:"Bo'lishga oid tenglamalar (x : 3 = 5 → x = 15) ham shu tarzda: «3 ta teng bo'lakning biri 5» deb chizing."},
{h:"Masaladan tenglama tuzish",sum:"«Bir nechta olmaga yana 6 ta qo'shilsa — 15»: x + 6 = 15.",a:"m04",
 start:function(){y5story(null)},fin:function(){y5story(1)},
 html:"<p><i>«Savatda bir nechta olma bor edi. Unga yana 6 ta solindi va 15 ta bo'ldi. Savatda nechta olma bor edi?»</i> Qaysi tenglama shu masalaga mos? Tanlang:</p><div class='digs y5o'></div>",
 act:function(c,done){var b=c.querySelector('.y5o');b.innerHTML='';['x − 6 = 15','x + 6 = 15','6 · x = 15','x + 15 = 6'].forEach(function(t,i){var e=document.createElement('button');e.className='dg wide';e.style.width='120px';e.textContent=t;e.onclick=function(){y5story(i);e.className='dg wide '+(i===1?'yes':'no');if(i===1)done();else setTimeout(function(){e.className='dg wide'},1500)};b.appendChild(e)})},
 after:"<p>Noma'lumni <b>x</b> deymiz va masaladagi voqeani tartib bilan yozamiz: «bor edi» — x, «yana 6 ta solindi» — + 6, «15 ta bo'ldi» — = 15. Yechim: x = 15 − 6 = 9.</p>",
 q:{t:"«Avtobusdan 8 kishi tushdi va 23 kishi qoldi.» Avtobusda nechta kishi bor edi? Qaysi tenglama mos?",opts:["x − 8 = 23","x + 8 = 23","8 − x = 23","x − 23 = 8"],ok:0,why:"Bor edi x, 8 tushdi (−8), 23 qoldi.",hint:"Avval nima bor edi? Keyin nima bo'ldi — qo'shildimi yoki kamaydimi?",full:"Bor edi — x, tushdi — ayiramiz: x − 8, qoldi — 23. Tenglama: x − 8 = 23, x = 31. «x + 8 = 23» — kishilar tushgan, kelgan emas."},
 tn:"Masalani bolalar o'z so'zlari bilan qayta aytib bersin, keyin har bir so'zni belgi bilan almashtirsin."},
{h:"Tuzoq: oxiridan yechish",sum:"«Songa 7 qo'shib, 3 ga ko'paytirdim — 30»: orqaga 30 : 3 = 10, 10 − 7 = 3.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p><i>«Men bir son o'yladim. Unga 7 ni qo'shdim, natijani 3 ga ko'paytirdim va 30 hosil bo'ldi. Qaysi sonni o'yladim?»</i> Amallar ketma-ket bo'lsa — <b>oxiridan</b> boshlab teskari amal qilamiz.</p>",
 btns:[phaser(P5,'◀ Orqaga qadam')],
 after:"<p>Oxirgi amal ko'paytirish edi — uni bo'lish bilan bekor qilamiz: 30 : 3 = 10. Undan oldin qo'shish — ayirish bilan: 10 − 7 = <b>3</b>. Tekshiramiz: (3 + 7) · 3 = 30 ✓</p>",
 q:{t:"Men bir son o'yladim, undan 4 ni ayirdim va natijani 2 ga ko'paytirdim — 16 chiqdi. Qaysi son?",opts:["12","4","10","36"],ok:0,why:"16 : 2 = 8, 8 + 4 = 12.",hint:"Oxirgi amaldan boshlang: ko'paytirishni bo'lish bilan bekor qiling.",full:"Orqaga: 16 : 2 = 8, ayirishni qo'shish bilan bekor qilamiz: 8 + 4 = 12. Tekshiramiz: (12 − 4) · 2 = 16 ✓. «4» — 16 : 2 − 4, oxirgi amal xato teskari qilingan."},
 tn:"«Son o'yla» o'yinini o'ynang: bolalar bir-biriga topishmoq tuzib bersin."},
{h:"Ikki bir xil quti",sum:"x + x + 3 = 11: avval 3 ni olamiz (8), keyin 2 ga bo'lamiz — x = 4.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Chap pallada <b>ikkita bir xil</b> quti va 3 kg tosh, o'ngda 11 kg. Bitta quti necha kg?</p>",
 btns:[phaser(P6)],
 after:"<p>Tartib muhim: avval «ortiqcha» toshni ikkala tomondan olamiz (11 − 3 = 8), keyin qolganini qutilar soniga bo'lamiz (8 : 2 = 4). Teskarisini qilsak (11 : 2) — butun son ham chiqmaydi!</p>",
 q:{t:"Uchta bir xil kitob va 2 kg li sumka birga 14 kg. Bitta kitob necha kg?",opts:["4","5","12","6"],ok:0,why:"14 − 2 = 12, 12 : 3 = 4.",hint:"Avval sumkani olib tashlang, keyin kitoblar soniga bo'ling.",full:"3 · x + 2 = 14 → 3 · x = 12 → x = 4. Tekshiramiz: 4 · 3 + 2 = 14 ✓. «12» — bu uchala kitob birga."},
 tn:"Bu 5–6-sinf tenglamalariga to'g'ridan-to'g'ri ko'prik. Bolalar avval tarozi rasmini chizsin."},
{h:"Bilasizmi? Al-jabr — tiklash",sum:"Al-Xorazmiy kitobi «al-jabr va al-muqobala»: tiklash va muvozanatlash. Bundan «algebra» so'zi kelib chiqqan.",a:"m07",
 start:function(){y5scale([{t:'x'},{n:5}],[{n:12}],{lab:'al-jabr va al-muqobala'});y5eq('IX asr · Bag‘dod · al-Xorazmiy')},fin:function(){y5scale([{t:'x'},{n:5}],[{n:12}],{lab:'al-jabr va al-muqobala'});y5eq('IX asr · Bag‘dod · al-Xorazmiy')},
 html:"<p>⭐ Vatandoshimiz <b>Muhammad al-Xorazmiy</b> IX asrda Bag'dodda «Al-jabr va al-muqobala» kitobini yozgan. Uning nomi ikki amal haqida: <b>al-jabr</b> — «tiklash, to'ldirish», <b>al-muqobala</b> — «qarama-qarshi qo'yish, muvozanatlash».</p><p>Biz tarozida qilgan ish aynan shu: ikkala tomonni muvozanatlab, noma'lumni topdik. <b>«Algebra»</b> so'zi shu kitob nomidan kelib chiqqan va butun dunyoga tarqalgan!</p>",
 tn:"Loyiha nomi — «Yosh Xorazmiylar» — aynan shu olim sharafiga. Bolalarga bu bog'liqlikni albatta ayting."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li>Tenglama — muvozanatdagi tarozi: ikkala tomonga <b>bir xil</b> ish qilamiz.</li><li>x + a = b → x = b − a.</li><li>x − a = b → x = b + a (butun = qism + qism).</li><li>a · x = b → x = b : a.</li><li>Masaladan tenglama: voqeani tartib bilan belgilarga aylantiring.</li><li>Ketma-ket amallar — <b>oxiridan</b>, teskari amallar bilan.</li><li>x + x + 3 = 11: avval 3 ni oling, keyin 2 ga bo'ling.</li><li>Har doim <b>tekshiring</b>: javobni tenglamaga qo'ying.</li></ul></div>",
 tn:"Keyingi darsni «x : 4 = 6» (x = 24) tenglamasi bilan boshlang — bo'lishli tenglama."}
];
function y5bar(k){clear();var g=S.g,x0=40;E('rect',{x:x0,y:60,width:280,height:30,rx:4,fill:'#fff3df',stroke:C.line,'stroke-width':1.5},g);T(g,180,52,k>=2?'x = 23':'x = ?',{'font-size':14,'font-weight':800,fill:k>=2?C.ok:C.bad});
 if(k>=1){E('rect',{x:x0,y:60,width:97,height:30,fill:'#ffd0d0',stroke:C.bad,'stroke-width':1.5},g);T(g,x0+48,80,'8 kesildi',{'font-size':12,'font-weight':800,fill:C.bad});E('rect',{x:x0+97,y:60,width:183,height:30,fill:C.b,stroke:C.line,'stroke-width':1.5},g);T(g,x0+188,80,'15 qoldi',{'font-size':12,'font-weight':800})}
 calc(['x − 8 = 15'].concat(k>=1?['Ip = kesilgan + qolgan']:[]).concat(k>=2?['x = 8 + 15 = <b>23</b>']:[]))}
function y5story(i){clear();var g=S.g;for(var k=0;k<6;k++)E('circle',{cx:220+k*18,cy:70,r:7,fill:'#e05555'},g);E('path',{d:'M60 60 h100 l-12 50 h-76 Z',fill:'#c98b45',stroke:'#8a5a24','stroke-width':2},g);T(g,110,90,'x',{'font-size':22,'font-weight':800,fill:'#fff'});T(g,190,75,'+',{'font-size':22,'font-weight':800});T(g,265,110,'6 ta',{'font-size':12,'font-weight':800});T(g,180,150,i===1?'x + 6 = 15  →  x = 9':'= 15 ta',{'font-size':15,'font-weight':800,fill:i===1?C.ok:C.blue});
 y5eq(i==null?'Mos tenglamani tanlang':(i===1?'✓ x + 6 = 15':'✗ Bu masaladagi voqeaga mos emas'))}
function y5chain(k){clear();var g=S.g,bx=[30,140,250],lab=['?','?+7','30'];
 var vals=[k>=2?'3':'?',k>=1?'10':'?','30'];for(var i=0;i<3;i++){E('rect',{x:bx[i],y:60,width:80,height:44,rx:10,fill:i===2||((i===1&&k>=1)||(i===0&&k>=2))?'#e6f6ee':'#fff',stroke:'#9aa8b6','stroke-width':2},g);T(g,bx[i]+40,90,vals[i],{'font-size':22,'font-weight':800,fill:'#1d2b3a'})}
 T(g,125,50,'+ 7',{'font-size':13,'font-weight':800,fill:C.blue});T(g,235,50,'· 3',{'font-size':13,'font-weight':800,fill:C.blue});
 E('path',{d:'M112 82 h24',stroke:C.blue,'stroke-width':2,'marker-end':''},g);E('path',{d:'M222 82 h24',stroke:C.blue,'stroke-width':2},g);
 if(k>=1)T(g,235,130,': 3 ←',{'font-size':14,'font-weight':800,fill:C.bad});if(k>=2)T(g,125,130,'− 7 ←',{'font-size':14,'font-weight':800,fill:C.bad});
 calc(['? → +7 → ·3 → 30'].concat(k>=1?['Orqaga: 30 : 3 = <b>10</b>']:[]).concat(k>=2?['10 − 7 = <b>3</b>. Tekshiramiz: (3 + 7) · 3 = 30 ✓']:[]))}
var PROBS=[
{t:"x + 14 = 30. x = ?",o:["16","44","14","26"],k:0,s:"30 − 14 = 16."},
{t:"x − 25 = 40. x = ?",o:["65","15","40","25"],k:0,s:"40 + 25 = 65."},
{t:"50 − x = 18. x = ?",o:["32","68","18","42"],k:0,s:"Ayriluvchi = kamayuvchi − ayirma: 50 − 18 = 32."},
{t:"7 · x = 56. x = ?",o:["8","49","63","9"],k:0,s:"56 : 7 = 8."},
{t:"x : 4 = 6. x = ?",o:["24","2","10","6"],k:0,s:"Bo'linuvchi = bo'linma · bo'luvchi: 6 · 4 = 24."},
{t:"Savatda bir nechta nok bor edi. 9 tasi olingach, 27 ta qoldi. Nechta nok bor edi?",o:["36","18","27","9"],k:0,s:"x − 9 = 27, x = 36."},
{t:"Ali bir nechta marka oldi, akasi yana 12 ta berdi va 30 ta bo'ldi. Ali nechta marka olgan edi?",o:["18","42","12","30"],k:0,s:"x + 12 = 30, x = 18."},
{t:"5 ta bir xil qalam 40 so'm turadi. Bitta qalam necha so'm?",o:["8","35","45","200"],k:0,s:"5 · x = 40, x = 8."},
{t:"Men bir son o'yladim, uni 3 ga ko'paytirib, 5 qo'shdim — 26 chiqdi. Qaysi son?",o:["7","9","21","31"],k:0,s:"26 − 5 = 21, 21 : 3 = 7."},
{t:"Men bir son o'yladim, unga 6 qo'shib, 2 ga ko'paytirdim — 20 chiqdi. Qaysi son?",o:["4","7","14","10"],k:0,s:"20 : 2 = 10, 10 − 6 = 4."},
{t:"Ikki bir xil quti va 5 kg yuk birga 17 kg. Bitta quti necha kg?",o:["6","12","11","8"],k:0,s:"17 − 5 = 12, 12 : 2 = 6."},
{t:"x + x + x = 27. x = ?",o:["9","24","3","27"],k:0,s:"3 · x = 27, x = 9."},
{t:"x + 8 = 3 · 7. x = ?",o:["13","29","21","5"],k:0,s:"3 · 7 = 21, 21 − 8 = 13."},
{t:"«Qaysi songa 15 ni qo'shsak, 15 dan 3 marta katta son chiqadi?»",o:["30","45","15","60"],k:0,s:"15 · 3 = 45, x + 15 = 45, x = 30."},
{t:"Qaysi tenglamaning yechimi 7?",o:["x + 5 = 12","x − 5 = 12","5 · x = 12","x + 12 = 5"],k:0,s:"7 + 5 = 12 ✓."},
{t:"Ipdan 3 marta 6 sm dan kesildi va 12 sm qoldi. Ip necha sm edi?",o:["30","18","6","24"],k:0,s:"x − 18 = 12, x = 30."},
{t:"Otaning yoshi o'g'lining yoshidan 4 marta katta. Otasi 36 yoshda. O'g'li necha yoshda?",o:["9","32","40","144"],k:0,s:"4 · x = 36, x = 9."},
{t:"x − 7 = 7 + 7. x = ?",o:["21","7","14","0"],k:0,s:"x − 7 = 14, x = 21."},
{t:"Uchta bir xil kubik va 4 g li tosh — 19 g. Bitta kubik necha g?",o:["5","15","7","23"],k:0,s:"19 − 4 = 15, 15 : 3 = 5."},
{t:"Men bir son o'yladim, undan 10 ni ayirib, 4 ga bo'ldim — 5 chiqdi. Qaysi son?",o:["30","20","15","10"],k:0,s:"5 · 4 = 20, 20 + 10 = 30."}
];
function PRACT_STAGE(){y5scale([{t:'x'},{n:5}],[{n:12}],{lab:'tarozi muvozanatda'});y5eq('Ikkala tomonga bir xil ish!')}
var PREP_DATA={teach:["Tenglama — muvozanatdagi tarozi.","Qo'shish, ayirish, ko'paytirishga oid tenglamalar.","Masaladan tenglama tuzish.","Ketma-ket amallar — oxiridan yechish; x + x + 3 = 11 turi."],
 mist:["Teskari amal o'rniga o'sha amalni bajaradi (x + 9 = 15 → 24).","x − 8 = 15 da ayiradi (7).","Masaladagi «tushdi/qo'shildi» ni noto'g'ri belgiga aylantiradi.","Ketma-ket amallarni boshidan teskari qiladi."],
 need:["Tarozi (yoki chizg'ich + qalam), qutichalar, toshlar.","Qog'oz tasmalar."],
 board:["Tarozi: <span class='w2'>x + 5 = 12 → x = 7</span>.","<span class='w2'>x − 8 = 15 → x = 23</span>.","<span class='w2'>4 · x = 28 → x = 7</span>.","Masala → <span class='w2'>x + 6 = 15</span>.","Orqaga: <span class='w2'>30 : 3 = 10, 10 − 7 = 3</span>.","<span class='w2'>x + x + 3 = 11 → x = 4</span>."]};
