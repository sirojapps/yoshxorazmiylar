var CODE='4D2',TITLE='4-sinf · Tenglamalar';
var P1=[function(){w4Bal(['x','1250'],['4000']);w3Msg('Tarozi muvozanatda: x + 1250 = 4000')},
 function(){w4Bal(['x',{t:'1250',c:'#f6c9c9'}],['2750',{t:'1250',c:'#f6c9c9'}]);w3Msg('4000 ni 2750 + 1250 deb yozamiz — ikkala pallada ham 1250')},
 function(){w4Bal(['x'],['2750']);w3Msg('Ikkala palladan 1250 ni olamiz: <b>x = 2750</b>')},
 function(){w4Bal(['2750','1250'],['4000']);w3Msg('Tekshiruv: 2750 + 1250 = 4000 ✓')}];
var P4=[function(){w3Expr(['(x − 150) · 12 = 3600']);w3Msg('Oxirgi amal — ko‘paytirish. Qavsni «bitta son» deb qaraymiz')},
 function(){w3Expr(['[(x − 150)] · 12 = 3600','x − 150 = 3600 : 12 = {300}']);w3Msg('Ko‘paytuvchi = ko‘paytma : ko‘paytuvchi')},
 function(){w3Expr(['x − 150 = 300','x = 300 + 150 = {450}']);w3Msg('Kamayuvchi = ayirma + ayriluvchi')},
 function(){w3Expr(['(450 − 150) · 12','= 300 · 12 = {3600} ✓']);w3Msg('Tekshiruv: <b>x = 450</b>')}];
var P5=[function(){w3Expr(['4800 : (x · 5 + 20) = 16']);w3Msg('x uch qavat ichida. Tashqaridan boshlaymiz')},
 function(){w3Expr(['4800 : [(x · 5 + 20)] = 16','x · 5 + 20 = 4800 : 16 = {300}']);w3Msg('1-qavat: bo‘luvchi = bo‘linuvchi : bo‘linma')},
 function(){w3Expr(['[x · 5] + 20 = 300','x · 5 = 300 − 20 = {280}']);w3Msg('2-qavat: qo‘shiluvchi = yig‘indi − qo‘shiluvchi')},
 function(){w3Expr(['x · 5 = 280','x = 280 : 5 = {56}']);w3Msg('3-qavat: ko‘paytuvchi = ko‘paytma : ko‘paytuvchi')},
 function(){w3Expr(['4800 : (56 · 5 + 20)','= 4800 : 300 = {16} ✓']);w3Msg('Tekshiruv: <b>x = 56</b>')}];
var P7=[function(){w3Bar([{lab:'x · 3',segs:[{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'}],tot:4},{lab:'+ x',segs:[{w:1,t:'x',c:C.a}],tot:4}]);w3Msg('x · 3 + x = 96. Nechta x bor?')},
 function(){w3Bar([{lab:'jami',segs:[{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x',c:C.a}],tot:4,br:'96',brw:1}],{top:60});w3Msg('Uchta x va yana bitta x — jami <b>to‘rtta</b> x: x · 4 = 96')},
 function(){w3Bar([{lab:'jami',segs:[{w:1,t:'24'},{w:1,t:'24'},{w:1,t:'24'},{w:1,t:'24',c:C.a}],tot:4,br:'96',brw:1}],{top:60});w3Msg('x = 96 : 4 = <b>24</b>. Tekshiruv: 72 + 24 = 96 ✓')}];
var STEPS=[
{h:"Tenglama — muvozanatdagi tarozi",sum:"x + 1250 = 4000 → x = 4000 − 1250 = 2750. Ikkala tomondan bir xil sonni olsak, muvozanat buzilmaydi.",a:"m01",
 start:w4St(P1),fin:w4Fin(P1),
 html:"<p><b>Tenglama</b> — noma'lum son (odatda x) qatnashgan tenglik. Uni muvozanatdagi tarozi deb tasavvur qiling. Bosib kuzating:</p>",btns:[phaser(P1)],
 after:"<p>Tenglamani yechish — x ning shunday qiymatini topishki, tenglik to'g'ri bo'lsin. Bu qiymat — tenglamaning <b>ildizi</b>. Oltin qoida: tarozining ikkala pallasi bilan bir xil ish qilsak, muvozanat saqlanadi.</p>",
 q:{t:"x + 1250 = 4000. x = ?",opts:["2750","5250","2850","3750"],ok:0,why:"4000 − 1250 = 2750.",hint:"Ikkala tomondan 1250 ni oling.",full:"x = 4000 − 1250 = 2750. Tekshiruv: 2750 + 1250 = 4000 ✓. «5250» — ayirish o'rniga qo'shish xatosi."},
 tn:"Haqiqiy pallali tarozi yoki chizg'ich + ikki stakan bilan ko'rsating (Singapur CPA: narsa → rasm → belgi)."},
{h:"Qaysi komponent? Qoidani tanlang",sum:"7200 : x = 90 → x — bo'luvchi → x = 7200 : 90 = 80.",a:"m02",
 start:function(){w3Expr(['7200 : x = 90']);w3Msg('x — qaysi komponent?')},fin:function(){w3Expr(['7200 : x = 90','x — bo‘luvchi','x = 7200 : 90 = {80}']);w3Msg('Tekshiruv: 7200 : 80 = 90 ✓')},
 html:"<p><b>7200 : x = 90</b>. Avval x qaysi komponent ekanini tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['bo‘linuvchi','bo‘luvchi','bo‘linma'],'bo‘luvchi',function(){w3Expr(['7200 : x = 90','x — bo‘luvchi','x = 7200 : 90 = {80}']);w3Msg('Bo‘luvchi = bo‘linuvchi : bo‘linma. Tekshiruv: 7200 : 80 = 90 ✓');done()},{'bo‘linuvchi':'Bo‘linuvchi — «:» dan oldingi son (7200)','bo‘linma':'Bo‘linma — natija (90)'})},
 after:"<div class='life'><div>➕<span>qo'shiluvchi = yig'indi − boshqa qo'shiluvchi</span></div><div>➖<span>kamayuvchi = ayirma + ayriluvchi; ayriluvchi = kamayuvchi − ayirma</span></div><div>✖️<span>ko'paytuvchi = ko'paytma : boshqa ko'paytuvchi</span></div><div>➗<span>bo'linuvchi = bo'linma · bo'luvchi; bo'luvchi = bo'linuvchi : bo'linma</span></div></div>",
 q:{t:"x : 16 = 45. x = ?",opts:["720","61","640","3"],ok:0,why:"x — bo'linuvchi: 45 · 16 = 720.",hint:"Bo'linuvchi = bo'linma · bo'luvchi.",full:"x = 45 · 16 = 720. Tekshiruv: 720 : 16 = 45 ✓. «3» — 45 : 16 ni hisoblashga urinish, «61» — qo'shish."},
 tn:"Komponent nomlari kartochkalarini tenglama tagiga qo'ydiring. Uchburchak-kartochka (ko'paytma tepada) ham qo'l keladi."},
{h:"Ayriluvchi yoki kamayuvchi?",sum:"x − 2085 = 3915 → x = 3915 + 2085 = 6000. 5400 − x = 1750 → x = 5400 − 1750 = 3650.",a:"m03",
 start:function(){S.w4={};w3Expr(['x − 2085 = 3915','5400 − x = 1750']);w3Msg('Ikkalasini yeching — qoida har xil!')},fin:function(){w3Expr(['x − 2085 = 3915 → x = {6000}','5400 − x = 1750 → x = {3650}']);w3Msg('Kamayuvchi — qo‘shamiz, ayriluvchi — ayiramiz')},
 html:"<p>Ikkala tenglamada ham ayirish bor, lekin x turli o'rinda. Har birini bosing:</p>",
 btns:[["x − 2085 = 3915",function(c,done){S.w4.a=1;w3Expr(['x − 2085 = 3915','x — kamayuvchi','x = 3915 + 2085 = {6000}']);w3Msg('Kamayuvchi = ayirma + ayriluvchi');if(S.w4.b)done()}],["5400 − x = 1750",function(c,done){S.w4.b=1;w3Expr(['5400 − x = 1750','x — ayriluvchi','x = 5400 − 1750 = {3650}']);w3Msg('Ayriluvchi = kamayuvchi − ayirma');if(S.w4.a)done()},'u']],g2:1,
 after:"<p>Eng ko'p xato shu yerda: «ayirish bor — demak qo'shaman» deb ikkalasini ham qo'shib yuborish. <b>5400 − x = 1750</b> da qo'shsak 7150 chiqadi — lekin 5400 dan 7150 ni ayirib bo'lmaydi! Tekshiruv buni darhol fosh qiladi.</p>",
 q:{t:"5400 − x = 1750. x = ?",opts:["3650","7150","3750","4650"],ok:0,why:"x = 5400 − 1750 = 3650.",hint:"x — ayriluvchi.",full:"Ayriluvchi = kamayuvchi − ayirma = 5400 − 1750 = 3650. Tekshiruv: 5400 − 3650 = 1750 ✓. «7150» — qo'shib yuborish."},
 tn:"«Butun va bo'lak» lentasi: butun 5400, bo'laklar x va 1750. Butundan bo'lakni olsak — ikkinchi bo'lak."},
{h:"Tarkibli tenglama",sum:"(x − 150) · 12 = 3600 → x − 150 = 300 → x = 450.",a:"m04",
 start:w4St(P4),fin:w4Fin(P4),
 html:"<p>x qavs ichida. Usul: hisoblashda <b>eng oxirida</b> bajariladigan amalni topamiz va qavsni «bitta son» deb qaraymiz.</p>",btns:[phaser(P4)],
 after:"<p>x = <b>450</b>. Kalit savol har doim bitta: «Bu ifodani hisoblaganimda oxirgi amal qaysi?» — yechishni o'sha amaldan boshlaymiz.</p>",
 q:{t:"(x − 150) · 12 = 3600. x = ?",opts:["450","300","3450","150"],ok:0,why:"x − 150 = 300 → x = 450.",hint:"Avval qavs ichini toping: 3600 : 12.",full:"x − 150 = 3600 : 12 = 300, x = 300 + 150 = 450. «300» — birinchi qadamda to'xtab qolish; «3450» — 3600 − 150 (qavs ichini noto'g'ri ochish)."},
 tn:"Ifoda ustida amallar tartibini raqamlang (1 — qavs, 2 — ko'paytirish) va yechishni teskari tartibda boshlang."},
{h:"Uch qavatli tenglama",sum:"4800 : (x · 5 + 20) = 16 → x · 5 + 20 = 300 → x · 5 = 280 → x = 56.",a:"m05",
 start:w4St(P5),fin:w4Fin(P5),
 html:"<p>Qiyin daraja: x uch qavat amal ichida. Har qadamda <b>bitta</b> qavatni olib tashlaymiz — piyozni archigandek.</p>",btns:[phaser(P5)],
 after:"<p>x = <b>56</b>. Yechish — hisoblashning <b>teskarisi</b>. Hisoblashda: · 5 → + 20 → 4800 ni bo'lish. Yechishda: 4800 : 16 → − 20 → : 5.</p>",
 q:{t:"1000 − x · 8 = 600. x = ?",opts:["50","200","400","75"],ok:0,why:"x · 8 = 400, x = 50.",hint:"x · 8 — ayriluvchi.",full:"x · 8 = 1000 − 600 = 400, x = 400 : 8 = 50. «400» — oxirgi qadam unutilgan; «75» — 600 : 8 (kamayuvchi bilan ayirmani adashtirish); «200» — 1600 : 8."},
 tn:"Matryoshka metaforasi: tashqi qavatdan ichkariga. Har qavatni bola ovoz chiqarib aytsin: «x · 5 + 20 — bu bo'luvchi»."},
{h:"O'ng tomonda ifoda",sum:"x + 340 = 25 · 40 → avval o'ng tomonni hisoblaymiz: x + 340 = 1000 → x = 660.",a:"m06",
 start:function(){w3Expr(['x + 340 = 25 · 40']);w3Msg('Birinchi qadam qanday bo‘ladi?')},fin:function(){w3Expr(['x + 340 = [25 · 40]','x + 340 = 1000','x = {660}']);w3Msg('Avval ma’lum tomonni soddalashtiramiz')},
 html:"<p><b>x + 340 = 25 · 40</b>. Birinchi qadamni tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['25 · 40 ni hisoblash','340 · 25','x = 25 − 340'],'25 · 40 ni hisoblash',function(){w3Expr(['x + 340 = [25 · 40]','x + 340 = 1000','x = 1000 − 340 = {660}']);w3Msg('To‘g‘ri: avval o‘ng tomon 1000 ga teng');done()},{'340 · 25':'340 x ga qo‘shilgan, 25 ga ko‘paytirilmagan','x = 25 − 340':'25 dan 340 ni ayirib bo‘lmaydi — o‘ng tomon butunlay 25 · 40'})},
 after:"<p>Agar tenglamaning bir tomonida x siz ifoda bo'lsa, avval uni <b>bitta songa</b> aylantiramiz. Keyin oddiy tenglama qoladi: x + 340 = 1000, x = 660.</p>",
 q:{t:"(x + 15) : 5 = 2 · 9. x = ?",opts:["75","105","3","90"],ok:0,why:"2 · 9 = 18; x + 15 = 90; x = 75.",hint:"Avval 2 · 9 ni hisoblang.",full:"O'ng tomon 18. x + 15 = 18 · 5 = 90, x = 90 − 15 = 75. «90» — x + 15 ni x deb olish; «105» — 15 ni qo'shib yuborish."},
 tn:"Doskada ikki rangda: x li tomon — ko'k, ma'lum tomon — yashil. Avval yashilni bitta songa aylantiring."},
{h:"Tuzoq: x bir necha marta",sum:"x · 3 + x = 96: bu to'rtta x → x · 4 = 96 → x = 24.",a:"m07",
 start:w4St(P7),fin:w4Fin(P7),
 html:"<p>Ba'zan x tenglamada ikki marta keladi. Chizma model yordam beradi — bosib kuzating:</p>",btns:[phaser(P7)],
 after:"<p>x · 3 + x = x · 4 — chunki «3 ta x va yana 1 ta x» = 4 ta x. Ko'p bolalar 96 : 3 = 32 deb yuboradi — tekshiruv: 32 · 3 + 32 = 128 ≠ 96 ✗.</p>",
 q:{t:"x + x + x + 250 = 1000. x = ?",opts:["250","750","375","1250"],ok:0,why:"x · 3 = 750, x = 250.",hint:"x + x + x = x · 3.",full:"x · 3 = 1000 − 250 = 750, x = 750 : 3 = 250. «750» — uchta x ni bitta deb olish; «375» — 750 : 2."},
 tn:"Bolalar lentani o'zlari chizsin: bir xil kataklar = bir xil x. Keyin kataklarni sanab, tenglamani yozsin."},
{h:"Ildizni tekshirish",sum:"x · 9 − 18 = 72 ildizi 10: 90 − 18 = 72 ✓.",a:"m08",
 start:function(){w3Expr(['x · 9 − 18 = 72','Qaysi biri ildiz: 8, 9 yoki 10?']);w3Msg('Har bir sonni x o‘rniga qo‘yib ko‘ring')},fin:function(){w3Expr(['8: 72 − 18 = [54] ✗','9: 81 − 18 = [63] ✗','10: 90 − 18 = {72} ✓']);w3Msg('Ildiz — 10')},
 html:"<p><b>x · 9 − 18 = 72</b>. Uch sonni tekshiring — qaysi biri ildiz?</p>",
 btns:[["x = 8",function(c,done){w3Expr(['8 · 9 − 18','= 72 − 18 = [54] ✗']);w3Msg('54 ≠ 72')}],["x = 9",function(c,done){w3Expr(['9 · 9 − 18','= 81 − 18 = [63] ✗']);w3Msg('63 ≠ 72 — 72 : 9 = 8 qilib, 18 ni unutish xatosi')}],["x = 10",function(c,done){w3Expr(['10 · 9 − 18','= 90 − 18 = {72} ✓']);w3Msg('Ildiz topildi: x = 10');done()},'u']],g3:1,
 after:"<p>Tekshirish — x o'rniga sonni <b>asl tenglamaga</b> qo'yish. Test savollarida bu eng tez yo'l: javob variantlarini birma-bir qo'yib ko'rasiz. To'g'ri yechishda ham: x · 9 = 72 + 18 = 90, x = 10.</p>",
 q:{t:"Qaysi son 3600 : x + 40 = 100 tenglamaning ildizi?",opts:["60","36","40","600"],ok:0,why:"3600 : 60 + 40 = 60 + 40 = 100 ✓.",hint:"3600 : x = 60.",full:"3600 : x = 100 − 40 = 60, x = 3600 : 60 = 60. Tekshiruv: 60 + 40 = 100 ✓. «36» — 3600 : 100."},
 tn:"Juftlikda: biri yechadi, ikkinchisi faqat tekshiradi. So'ng almashinadi."},
{h:"Bilasizmi? Diofant jumbog'i",sum:"Qadimgi yunon to'plamidagi jumboq: Diofant umrining qismlari haqida — javobi 84 yil.",a:"m09",
 start:function(){w3Expr(['umr = x yil']);w3Msg('Tenglama yordamida jumboqni yechish mumkin')},fin:function(){w3Expr(['umr = x yil','x = {84}']);w3Msg('Tenglama yordamida jumboqni yechish mumkin')},
 html:"<p>📜 <b>Diofant</b> — qadimgi Iskandariyalik matematik (taxminan III asr), uni «algebraning otasi»laridan biri deyishadi. Qadimgi yunon jumboqlar to'plamida u haqida mashhur masala bor: umrining bolaligi, yoshligi, uylanishi va o'g'lining hayoti qismlar bilan berilgan.</p><p>⭐ Jumboqni tenglama bilan yechsak, javob <b>84 yil</b> chiqadi. Siz uni 5-sinfda kasrlarni o'rganib bo'lgach o'zingiz yecha olasiz!</p>",
 tn:"Diofant va al-Xorazmiyni solishtiring: biri yunon, biri vatandoshimiz — ikkalasi ham tenglamalar yechishni rivojlantirgan."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['1) x qaysi komponent?','2) qoidani qo‘llang','3) tekshiring']);w3Msg('Tarkibli: oxirgi amaldan boshlang')},fin:function(){w3Expr(['1) x qaysi komponent?','2) qoidani qo‘llang','3) tekshiring']);w3Msg('Tarkibli: oxirgi amaldan boshlang')},
 html:"<div class='memo'><ul><li>Qo'shiluvchi = yig'indi − qo'shiluvchi; kamayuvchi = ayirma + ayriluvchi; ayriluvchi = kamayuvchi − ayirma.</li><li>Ko'paytuvchi = ko'paytma : ko'paytuvchi; bo'linuvchi = bo'linma · bo'luvchi; bo'luvchi = bo'linuvchi : bo'linma.</li><li>Tarkibli tenglama: oxirgi bajariladigan amaldan boshlab, qavatma-qavat.</li><li>Bir tomonda x siz ifoda bo'lsa — avval uni hisoblang.</li><li>x · 3 + x = x · 4.</li><li>Doim tekshiring: topilgan sonni asl tenglamaga qo'ying.</li></ul></div>",
 tn:"4D5 (masaladan tenglama tuzish) mavzusida shu kartochka kerak bo'ladi."}
];
var PROBS=[
{t:"x + 1250 = 4000. x = ?",o:["2750","5250","2850","3750"],k:0,s:"4000 − 1250 = 2750."},
{t:"x − 2085 = 3915. x = ?",o:["6000","1830","5000","6100"],k:0,s:"3915 + 2085 = 6000."},
{t:"5400 − x = 1750. x = ?",o:["3650","7150","3750","4650"],k:0,s:"5400 − 1750 = 3650."},
{t:"x · 25 = 2000. x = ?",o:["80","50 000","800","8"],k:0,s:"2000 : 25 = 80."},
{t:"x : 16 = 45. x = ?",o:["720","61","640","3"],k:0,s:"45 · 16 = 720."},
{t:"7200 : x = 90. x = ?",o:["80","648 000","800","8"],k:0,s:"7200 : 90 = 80."},
{t:"(x − 150) · 12 = 3600. x = ?",o:["450","300","3450","150"],k:0,s:"x − 150 = 300 → x = 450."},
{t:"4800 : (x · 5 + 20) = 16. x = ?",o:["56","60","52","300"],k:0,s:"x · 5 + 20 = 300 → x · 5 = 280 → x = 56."},
{t:"x + 340 = 25 · 40. x = ?",o:["660","1340","760","1000"],k:0,s:"x + 340 = 1000 → x = 660."},
{t:"x · 3 + x = 96. x = ?",o:["24","32","48","72"],k:0,s:"x · 4 = 96 → x = 24."},
{t:"(x + 15) : 5 = 2 · 9. x = ?",o:["75","105","3","90"],k:0,s:"x + 15 = 18 · 5 = 90 → x = 75."},
{t:"1000 − x · 8 = 600. x = ?",o:["50","200","400","75"],k:0,s:"x · 8 = 400 → x = 50."},
{t:"x : 4 − 35 = 65. x = ?",o:["400","25","120","140"],k:0,s:"x : 4 = 100 → x = 400."},
{t:"2 · (x + x) = 72. x = ?",o:["18","36","9","34"],k:0,s:"x + x = 36 → x = 18."},
{t:"3600 : x + 40 = 100. x = ?",o:["60","36","40","600"],k:0,s:"3600 : x = 60 → x = 60."},
{t:"Qaysi son x · 9 − 18 = 72 tenglamaning ildizi?",o:["10","9","8","6"],k:0,s:"10 · 9 − 18 = 72."},
{t:"O'ylangan sonni 7 ga ko'paytirib, 350 ni ayirsak, 350 chiqadi. O'ylangan son?",o:["100","0","50","700"],k:0,s:"x · 7 − 350 = 350 → x · 7 = 700 → x = 100."},
{t:"x + x + x + 250 = 1000. x = ?",o:["250","750","375","1250"],k:0,s:"x · 3 = 750 → x = 250."},
{t:"(480 − x) : 6 = 45. x = ?",o:["210","750","270","390"],k:0,s:"480 − x = 270 → x = 210."},
{t:"5 · (x − 7) + 15 = 100. x = ?",o:["24","17","10","31"],k:0,s:"5 · (x − 7) = 85 → x − 7 = 17 → x = 24."}
];
function PRACT_STAGE(){w4Bal(['x','1250'],['4000']);w3Msg('Tarozi muvozanatda')}
var PREP_DATA={teach:["Tenglama va uning ildizi; tarozi modeli.","Komponentlar orasidagi bog'lanish orqali tenglamalarni yechish (ko'p xonali sonlar).","Tarkibli (2–3 qavatli) tenglamalar.","Bir tomonda ifoda bo'lgan va x ikki marta qatnashgan tenglamalar; tekshirish."],
 mist:["Ayriluvchini qo'shib topadi: 5400 − x = 1750 → 7150.","Bo'linuvchini bo'lish bilan topadi.","Tarkibli tenglamada ichki amaldan boshlaydi yoki birinchi qadamda to'xtaydi.","x · 3 + x = 96 ni 96 : 3 deb yechadi."],
 need:["Pallali tarozi yoki chizg'ich + 2 stakan.","Komponent nomlari kartochkalari."],
 board:["<span class='w2'>x + 1250 = 4000 → x = 2750</span>.","<span class='w2'>7200 : x = 90 → x = 80</span>.","<span class='w2'>(x − 150) · 12 = 3600 → x = 450</span>.","<span class='w2'>4800 : (x · 5 + 20) = 16 → x = 56</span>.","<span class='w2'>x · 3 + x = 96 → x = 24</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
