var CODE='3J10',TITLE="3-sinf · Fazoviy tasavvur: kublar, yoyilmalar";
function j10P(ox,oy,s,i,j,k){return [ox+(i-j)*s*0.866,oy+(i+j)*s*0.5-k*s]}
function j10Iso(H,o){o=o||{};clear();var s=o.s||22,ox=o.ox||180,oy=o.oy||60,L=[];H.forEach(function(row,i){row.forEach(function(h,j){for(var k=0;k<h;k++)L.push([i,j,k])})});
 L.sort(function(a,b){return (a[0]+a[1]+a[2])-(b[0]+b[1]+b[2])||a[2]-b[2]});
 L.forEach(function(c){var i=c[0],j=c[1],k=c[2];function P(a,b,d){return j10P(ox,oy,s,a,b,d).join(',')}
  E('polygon',{points:[P(i,j,k+1),P(i+1,j,k+1),P(i+1,j+1,k+1),P(i,j+1,k+1)].join(' '),fill:o.top||'#ffd98a',stroke:'#5b4a2a','stroke-width':1.2},S.g);
  E('polygon',{points:[P(i+1,j,k),P(i+1,j+1,k),P(i+1,j+1,k+1),P(i+1,j,k+1)].join(' '),fill:o.r||'#e9a94e',stroke:'#5b4a2a','stroke-width':1.2},S.g);
  E('polygon',{points:[P(i,j+1,k),P(i+1,j+1,k),P(i+1,j+1,k+1),P(i,j+1,k+1)].join(' '),fill:o.l||'#f4c16c',stroke:'#5b4a2a','stroke-width':1.2},S.g)});return L.length}
function j10Net(cells,x0,y0,s,lab,txt){cells.forEach(function(c,n){E('rect',{x:x0+c[0]*s,y:y0+c[1]*s,width:s,height:s,fill:'#e8f1fb',stroke:'#4f6d8a','stroke-width':1.4},S.g);if(txt)T(S.g,x0+c[0]*s+s/2,y0+c[1]*s+s/2+5,String(txt[n]),{'font-size':s>24?15:10,'font-weight':800,fill:'#1d2b3a'})});if(lab)T(S.g,x0+30,166,lab,{'font-size':14,'font-weight':800,fill:C.blue})}
var J10A=[[0,0],[1,0],[1,1],[2,1],[2,2],[3,2]],J10B=[[0,0],[1,0],[2,0],[0,1],[1,1],[2,1]],J10C=[[0,0],[1,0],[2,0],[3,0],[4,0],[0,1]],J10D=[[0,0],[1,0],[2,0],[3,0],[0,1],[3,1]];
function j10Four(){clear();j10Net(J10B,14,60,14,'A');j10Net(J10C,100,60,14,'B');j10Net(J10A,196,44,14,'C');j10Net(J10D,286,60,14,'D')}
var J10X=[[0,1],[1,1],[2,1],[3,1],[1,0],[1,2]];
function j10Dice(top){clear();var g=S.g;for(var d=0;d<3;d++){var y=120-d*40;E('rect',{x:150,y:y,width:44,height:40,rx:6,fill:'#fff',stroke:C.line,'stroke-width':1.6},g);E('polygon',{points:'150,'+y+' 172,'+(y-12)+' 216,'+(y-12)+' 194,'+y,fill:d===2?'#ffe08a':'#f1f4f7',stroke:C.line,'stroke-width':1.4},g);E('polygon',{points:'194,'+y+' 216,'+(y-12)+' 216,'+(y+28)+' 194,'+(y+40),fill:'#e3e9ef',stroke:C.line,'stroke-width':1.4},g)}
 T(g,183,32,String(top),{'font-size':12,'font-weight':800,fill:C.bad});T(g,270,70,'Qarama-qarshi',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,270,86,'yoqlar: 7',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});T(g,90,86,'3 ta zar',{'font-size':13,'font-weight':800,fill:C.blue})}
function j10Paint(){clear();var g=S.g,s=22,ox=180,oy=38;var c={3:'#e05a5a',2:'#f2a65a',1:'#ffe08a'};
 for(var i=0;i<3;i++)for(var j=0;j<3;j++)for(var k=0;k<3;k++){}
 var L=[];for(var i2=0;i2<3;i2++)for(var j2=0;j2<3;j2++)for(var k2=0;k2<3;k2++)L.push([i2,j2,k2]);L.sort(function(a,b){return (a[0]+a[1]+a[2])-(b[0]+b[1]+b[2])||a[2]-b[2]});
 L.forEach(function(q){var i=q[0],j=q[1],k=q[2];var n=(i===0||i===2?1:0)+(j===0||j===2?1:0)+(k===0||k===2?1:0);var f=c[n]||'#fff';function P(a,b,d){return j10P(ox,oy+40,s,a,b,d).join(',')}
  [[P(i,j,k+1),P(i+1,j,k+1),P(i+1,j+1,k+1),P(i,j+1,k+1)],[P(i+1,j,k),P(i+1,j+1,k),P(i+1,j+1,k+1),P(i+1,j,k+1)],[P(i,j+1,k),P(i+1,j+1,k),P(i+1,j+1,k+1),P(i,j+1,k+1)]].forEach(function(pp){E('polygon',{points:pp.join(' '),fill:f,stroke:'#5b4a2a','stroke-width':1.1},g)})});
 [['3 yoq',c[3]],['2 yoq',c[2]],['1 yoq',c[1]]].forEach(function(z,n){E('rect',{x:270,y:60+n*24,width:16,height:16,fill:z[1],stroke:C.line},g);T(g,292,73+n*24,z[0],{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'})})}
var STEPS=[
{h:"Kubiklarni sanaymiz",sum:"Har ustunni alohida sanang: (3 + 2 + 1) · 2 = 12. Ko'rinmaydigan kubiklar ham bor!",a:"m01",
 start:function(){j10Iso([[3,3],[2,2],[1,1]],{oy:74});j3Msg('Bu shakl nechta kubikdan iborat?')},fin:function(){j10Iso([[3,3],[2,2],[1,1]],{oy:74});j3Msg('Ikki qator, har birida 3 + 2 + 1 = 6 → 12 ta')},
 html:"<p>Zinapoya shaklidagi qurilma. Orqa qatorni ham, ko'rinmaydigan pastki kubiklarni ham hisobga oling. Nechta kubik?</p>",
 btns:j3Ch(["6","9","10","12"],3,function(){j3Msg('To‘g‘ri! Har qatorda 3 + 2 + 1 = 6, ikki qator: 12')},function(i){return ['6 — faqat bitta qator. Orqada yana bir qator bor','9 — faqat ko‘rinadigan kubiklarni sanadingiz. Pastdagilar havoda turmaydi!','Har ustun balandligini yozib chiqing: 3, 2, 1 — ikki qatorda'][i]}),g2:1,
 after:"<p>Usul: shaklni <b>ustunlarga</b> ajrating va har ustun balandligini qo'shing. Ustidagi kubik havoda turmaydi — ostida albatta kubik bor. 3 + 2 + 1 + 3 + 2 + 1 = 12.</p>",
 q:{t:"Minorada 4 qavat: pastki 3 qavatda 2 × 2 dan kubik, eng tepada bitta. Jami nechta kubik?",opts:["16","13","12","10"],ok:1,why:"3 · 4 + 1 = 13.",hint:"Har qavatda nechta kubik?",full:"2 × 2 = 4 kubik — bir qavat. 3 qavat: 12. Tepada 1: jami 13. «16» — tepani ham 4 ta deb olish."},
 tn:"Haqiqiy kubiklardan qurib, bolalar avval taxmin qilsin, keyin qismlarga ajratib sanasin."},
{h:"Kub yoyilmasi",sum:"Yoyilma — kubning 6 yog'ini tekislikka yoyib qo'yilgani. 2 × 3 to'rtburchak va 5 ta qatordagi shakl kub bo'lmaydi.",a:"m02",
 start:function(){j10Four();j3Msg('Qaysi biridan kub yasash mumkin?')},fin:function(){j10Four();j3Msg('C — zinapoya (2-2-2) yoyilmasi kubga yig‘iladi')},
 html:"<p>To'rt shakl, har birida 6 ta kvadrat. Qaysi birini buklab <b>kub</b> yasash mumkin? Xayolan buklab ko'ring!</p>",
 btns:j3Ch(["A","B","C","D"],2,function(){j3Msg('To‘g‘ri! Zinapoya shaklini buklasak, 6 ta yoq bir-birini takrorlamaydi')},function(i){return ['A (2 × 3): buklasak, ikki yoq ustma-ust tushadi, bitta yoq ochiq qoladi','B: qatordagi 5 kvadratning 1-si va 5-si bir joyga tushadi','','D: ikki pastki kvadrat ikkalasi ham kub ostiga tushadi'][i]}),g2:1,
 after:"<p>Kubning <b>11 xil</b> yoyilmasi bor. Tekshirish usuli: bitta kvadratni «ost» deb oling va qolganlarini xayolan buklang. Qatorda 4 tadan ko'p kvadrat bo'lmasligi kerak, 2 × 2 kvadrat bloki ham bo'lmaydi.</p>",
 q:{t:"Kub yoyilmasida qatorda eng ko'pi bilan nechta kvadrat ketma-ket turishi mumkin?",opts:["3","4","5","6"],ok:1,why:"4 ta yoq kub atrofini aylanadi; 5-si birinchisi ustiga tushadi.",hint:"Kubni bir aylantirsangiz, nechta yon yoqni ko'rasiz?",full:"Kubni stol ustida dumalatsak, 4 ta yoq ketma-ket pastga tushadi, 5-si yana birinchisi. Shuning uchun qatorda ko'pi bilan 4 ta."},
 tn:"Karton yoyilmalarni qaychi bilan kesib, bolalar o'zi buklasin. Keyin daftarda 11 yoyilmani topishga urinsin."},
{h:"Qarama-qarshi yoqlar",sum:"Yoyilmada bitta oraliq bilan bir qatorda turgan yoqlar — qarama-qarshi: 1–3, 2–4, 5–6.",a:"m03",
 start:function(){clear();j10Net(J10X,110,22,36,'',['1','2','3','4','5','6']);j3Msg('Yoyilma buklandi. 1 raqamli yoq qarshisida qaysi raqam?')},fin:function(){clear();j10Net(J10X,110,22,36,'',['1','2','3','4','5','6']);j3Msg('Qarama-qarshi: 1–3, 2–4, 5–6')},
 html:"<p>Xoch shaklidagi yoyilma. Uni kubga buklasak, <b>1</b> raqamli yoqning qarshisida (teskari tomonida) qaysi raqam bo'ladi?</p>",
 btns:j3Ch(["2","3","4","5"],1,function(){j3Msg('To‘g‘ri! 1 va 3 orasida bitta kvadrat (2) — ular qarama-qarshi')},function(i){return ['2 — 1 bilan yonma-yon. Qo‘shni yoqlar qarama-qarshi bo‘lmaydi','','4 — 1 bilan qo‘shni bo‘ladi (aylanib keladi)','5 — 2 ning ustida, buklanganda 1 ga tegadi'][i]}),g2:1,
 after:"<p>Qoida: bir qatorda <b>bitta kvadrat oralab</b> turgan yoqlar — qarama-qarshi (1 va 3, 2 va 4). Qatorga tik turgan 5 va 6 — ham qarama-qarshi. Qo'shni kvadratlar hech qachon qarama-qarshi bo'lmaydi.</p>",
 q:{t:"Shu yoyilmada 2 raqamli yoq qarshisida qaysi raqam?",opts:["1","3","4","5"],ok:2,why:"2 va 4 orasida bitta kvadrat (3).",hint:"2 dan bitta kvadrat o'tib, qaysi raqam turibdi?",full:"Qatorda 1, 2, 3, 4. 2 dan bitta o'tib — 4. 1 va 3 — 2 bilan qo'shni, 5 — 2 ning ustida, u ham qo'shni."},
 tn:"Yoyilmaga raqam yozib, buklashdan oldin bolalar bashorat qilsin, keyin tekshirsin."},
{h:"O'yin zari va yashirin yoqlar",sum:"Zarning qarama-qarshi yoqlari yig'indisi 7. Uchta zar: tepa + ost = 3 · 7 = 21; ko'ringan 5 ni ayiramiz → 16.",a:"m04",
 start:function(){j10Dice(5);j3Msg('Uchta zar ustma-ust. Tepada 5. Ko‘rinmaydigan tepa va ost yoqlar yig‘indisi?')},fin:function(){j10Dice(5);j3Msg('3 · 7 = 21; 21 − 5 = 16')},
 html:"<p>O'yin zarida qarama-qarshi yoqlar yig'indisi doim <b>7</b> (1–6, 2–5, 3–4). Uchta zar ustma-ust turibdi, eng tepada <b>5</b> ko'rinadi. Har zarning tepa va ost yoqlaridan qolgan barcha (ko'rinmaydigan) yoqlar yig'indisi qancha?</p>",
 btns:j3Ch(["16","21","15","14"],0,function(){j3Msg('To‘g‘ri! Har zarda tepa + ost = 7, uchtasida 21. Ko‘ringan 5 ni olib tashlaymiz: 16')},function(i){return ['','21 — bu hammasi, lekin tepadagi 5 ko‘rinib turibdi','15 = 3 · 5 — yoqlar 5 emas, juftlar 7 ga teng','14 = 2 · 7 — zarlar 3 ta'][i]}),g2:1,
 after:"<p>Har bir zarning tepa va ost yoqlari — bir juft, yig'indisi 7. Uchta zar: 3 · 7 = 21. Ko'rinadigani faqat eng ustki 5. Yashirinlari: 21 − 5 = <b>16</b>. Har bir yoqni bilmasdan ham javob topildi!</p>",
 q:{t:"Zarning tepasida 6, old tomonida 2. Uning ostida qaysi raqam?",opts:["1","5","4","3"],ok:0,why:"Ost — tepaning qarshisi: 7 − 6 = 1.",hint:"Qaysi yoq tepaning qarama-qarshisi?",full:"Ost yoq tepa yoqning qarshisida: 7 − 6 = 1. «5» — old tomonning (2) qarshisi, u orqa tomonda."},
 tn:"Haqiqiy zar bilan tekshiring: bolalar juftlarni (1–6, 2–5, 3–4) qo'li bilan topsin."},
{h:"Bo'yalgan kub",sum:"3 × 3 × 3 kub bo'yalib 27 ga kesilsa: 3 yog'i — 8 (uchlarda), 2 yog'i — 12 (qirralarda), 1 yog'i — 6 (yoqlarda), 0 — 1 (markazda).",a:"m05",
 start:function(){j10Paint();j3Msg('Kub sirti bo‘yalib, 27 ta kubikka kesildi. Nechta kubikning aynan 2 yog‘i bo‘yalgan?')},fin:function(){j10Paint();j3Msg('8 + 12 + 6 + 1 = 27')},
 html:"<p>Katta kubning sirti bo'yalib, 27 ta kichik kubikka kesildi. Ranglarga qarang: qizil — uchlarda, to'q sariq — qirralarda, sariq — yoqlar o'rtasida. <b>Aynan 2 yog'i</b> bo'yalgan kubiklar nechta?</p>",
 btns:j3Ch(["8","12","6","1"],1,function(){j3Msg('To‘g‘ri! Kubning 12 qirrasi bor, har qirra o‘rtasida bittadan')},function(i){return ['8 — bu uchlardagi kubiklar, ularning 3 yog‘i bo‘yalgan','','6 — yoqlar markazi, faqat 1 yoq bo‘yalgan','1 — eng ichkaridagi, umuman bo‘yalmagan'][i]}),g2:1,
 after:"<p>Kubning <b>8 uchi</b> → 3 yog'i bo'yalgan 8 kubik; <b>12 qirrasi</b> → 2 yog'i bo'yalgan 12; <b>6 yog'i</b> → 1 yog'i bo'yalgan 6; ichida 1 ta bo'yalmagan. Tekshiruv: 8 + 12 + 6 + 1 = 27 ✓.</p>",
 q:{t:"4 × 4 × 4 kub sirti bo'yalib, 64 kubikka kesildi. Nechtasi umuman bo'yalmagan?",opts:["8","27","16","4"],ok:0,why:"Ichki qism 2 × 2 × 2 = 8.",hint:"Har tomondan bitta qatlamni olib tashlasangiz, qanday kub qoladi?",full:"Har tomondan bo'yalgan qatlamni olsak, ichida 2 × 2 × 2 kub qoladi: 8 kubik. «27» — 3 × 3 × 3, «16» — 4 × 4."},
 tn:"Bu — klassik olimpiada masalasi. Shakar kubiklaridan 3 × 3 × 3 yasab, ustini flomaster bilan bo'yab ko'ring."},
{h:"Tuzoq: kubgacha to'ldirish",sum:"3 × 3 × 3 kubda 27 kubik. Shaklda 12 ta bo'lsa, yana 27 − 12 = 15 ta kerak.",a:"m06",
 start:function(){j10Iso([[3,2,1],[2,1,1],[1,1,0]],{oy:68,s:20});j3Msg('Bu shaklni 3 × 3 × 3 kubga to‘ldirish uchun yana nechta kubik kerak?')},fin:function(){j10Iso([[3,2,1],[2,1,1],[1,1,0]],{oy:68,s:20});j3Msg('Shaklda 3+2+1+2+1+1+1+1+0 = 12; 27 − 12 = 15')},
 html:"<p>Shakl 3 × 3 asosda turibdi. Ustunlar balandligini xayolan yozing. Uni to'liq <b>3 × 3 × 3</b> kubga aylantirish uchun yana nechta kubik qo'shish kerak?</p>",
 btns:j3Ch(["12","15","27","13"],1,function(){j3Msg('To‘g‘ri! Ustunlar: 3, 2, 1, 2, 1, 1, 1, 1, 0 → 12. 27 − 12 = 15')},function(i){return ['12 — shakldagi kubiklar soni. Savol: yana nechta kerak?','','27 — butun kub. Bor kubiklarni ayiring','Burchakdagi bo‘sh ustunni (0) unutmang: hamma ustunlarni qayta qo‘shing'][i]}),g2:1,
 after:"<p>Ikki qadam: 1) shakldagi kubiklarni ustunlab sanash (12); 2) to'liq kubdan ayirish: 27 − 12 = <b>15</b>. Yoki har ustunga 3 gacha nechta yetishmasligini qo'shing: 0 + 1 + 2 + 1 + 2 + 2 + 2 + 2 + 3 = 15 ✓.</p>",
 q:{t:"3 × 3 × 3 kubning har bir uchidan bittadan kubik olib tashlandi. Nechta kubik qoldi?",opts:["23","19","21","24"],ok:1,why:"Uchlar 8 ta: 27 − 8 = 19.",hint:"Kubning nechta uchi bor?",full:"Kubning 8 ta uchi bor. 27 − 8 = 19. «23» — 4 ta uch deb olish, «21» — 6 ta (yoqlar soni)."},
 tn:"Bolalar ikkala usulni (ayirish va yetishmaganlarni qo'shish) solishtirsin — bir masalani ikki yo'l bilan tekshirish."},
{h:"Bilasizmi? Rubik kubi",sum:"Rubik kubini 1974-yilda vengriyalik me'mor Erno Rubik ixtiro qilgan. Kubning 11 xil yoyilmasi bor.",a:"m07",
 start:function(){j10Iso([[3,3,3],[3,3,3],[3,3,3]],{oy:64,s:20,top:'#ffffff',l:'#3d7be0',r:'#e05a5a'});j3Msg('Rubik kubi: 3 × 3 × 3')},fin:function(){j10Iso([[3,3,3],[3,3,3],[3,3,3]],{oy:64,s:20,top:'#ffffff',l:'#3d7be0',r:'#e05a5a'});j3Msg('Rubik kubi: 3 × 3 × 3')},
 html:"<p>🧊 Dunyodagi eng mashhur boshqotirma — <b>Rubik kubi</b>. Uni 1974-yilda vengriyalik me'mor va o'qituvchi <b>Erno Rubik</b> talabalarga fazoviy tasavvurni tushuntirish uchun ixtiro qilgan. Uning ko'rinishi — aynan 3 × 3 × 3 kub!</p><p>📦 Kubning <b>11 xil</b> yoyilmasi bor — qadoqlash zavodlarida karton qutilar shunday yoyilmalardan kesiladi.</p>",
 tn:"Sinfda Rubik kubi bo'lsa, «uchdagi kubiklar nechta rangli?» deb so'rang — 3 ta rang, bu bo'yalgan kub masalasining o'zi."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j10Paint()},fin:function(){j10Paint()},
 html:"<div class='memo'><ul><li>Kub: <b>6 yoq, 12 qirra, 8 uch</b>.</li><li>Kubiklarni ustunlab sanang; yashiringanlarini unutmang.</li><li>Yoyilma: qatorda ko'pi bilan 4 kvadrat; 11 xil yoyilma.</li><li>Bitta oralab turgan yoqlar — qarama-qarshi.</li><li>Zar: qarama-qarshi yoqlar yig'indisi <b>7</b>.</li><li>Bo'yalgan 3 × 3 × 3: 8 / 12 / 6 / 1.</li><li>To'ldirish: to'liq kub − bor kubiklar.</li></ul></div>",
 tn:"Uyga vazifa: qutini qirralari bo'yicha qirqib, yoyilmasini daftarga chizish."}
];
var PROBS=[
{t:"Kubning nechta yog'i bor?",o:["6","8","12","4"],k:0,s:"6 ta yoq."},
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","24"],k:0,s:"12 ta qirra."},
{t:"Kubning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"8 ta uch."},
{t:"Kubning bitta uchida nechta qirra uchrashadi?",o:["3","4","2","6"],k:0,s:"Uzunlik, kenglik, balandlik — 3 ta."},
{t:"Kub qirrasi 2 sm. Uning barcha qirralari uzunliklari yig'indisi?",o:["24 sm","8 sm","12 sm","16 sm"],k:0,s:"12 · 2 = 24."},
{t:"O'yin zarida 5 ning qarshisida qaysi raqam?",o:["2","1","6","3"],k:0,s:"7 − 5 = 2."},
{t:"Zarning tepasida 6, old tomonida 2. Ostida qaysi raqam?",o:["1","5","4","3"],k:0,s:"7 − 6 = 1."},
{t:"Uchta zar ustma-ust, eng ustki yoq 4. Barcha zarlarning ko'rinmaydigan tepa va ost yoqlari yig'indisi?",o:["17","21","14","18"],k:0,s:"3 · 7 − 4 = 17."},
{t:"Minorada 4 qavat: pastki 3 qavatda 2 × 2 dan kubik, eng tepada bitta. Jami nechta kubik?",o:["13","16","12","10"],k:0,s:"3 · 4 + 1 = 13."},
{t:"1 sm li kubiklardan qirrasi 3 sm bo'lgan kub yasaldi. Nechta kubik ishlatildi?",o:["27","9","18","36"],k:0,s:"3 · 3 · 3 = 27."},
{t:"3 × 3 × 3 kubning har bir uchidan bittadan kubik olib tashlandi. Nechta kubik qoldi?",o:["19","23","21","24"],k:0,s:"27 − 8 = 19."},
{t:"3 × 3 × 3 kub sirti bo'yalib, 27 kubikka kesildi. Nechtasining 3 yog'i bo'yalgan?",o:["8","12","6","4"],k:0,s:"Uchlardagilar: 8."},
{t:"3 × 3 × 3 kub sirti bo'yalib, 27 kubikka kesildi. Nechtasining aynan 2 yog'i bo'yalgan?",o:["12","8","6","24"],k:0,s:"Har qirrada bittadan: 12."},
{t:"3 × 3 × 3 kub sirti bo'yalib, 27 kubikka kesildi. Nechtasining aynan 1 yog'i bo'yalgan?",o:["6","9","12","8"],k:0,s:"Har yoq markazida bittadan: 6."},
{t:"3 × 3 × 3 kub sirti bo'yalib, 27 kubikka kesildi. Nechtasi umuman bo'yalmagan?",o:["1","0","3","8"],k:0,s:"Markazdagi bitta."},
{t:"4 × 4 × 4 kub sirti bo'yalib, 64 kubikka kesildi. Nechtasi umuman bo'yalmagan?",o:["8","27","16","4"],k:0,s:"Ichki 2 × 2 × 2 = 8."},
{t:"4 × 4 × 4 kub sirti bo'yalib, 64 kubikka kesildi. Nechtasining 3 yog'i bo'yalgan?",o:["8","16","24","12"],k:0,s:"Faqat uchlardagilar — doim 8."},
{t:"Xoch yoyilma: qatorda 1, 2, 3, 4; 2 ning ustida 5, ostida 6. Buklanganda 5 ning qarshisida qaysi raqam?",o:["6","3","1","4"],k:0,s:"Qatorga tik turgan 5 va 6 — qarama-qarshi."},
{t:"Xuddi shu yoyilmada (1, 2, 3, 4 qatorda; 5 va 6 — 2 ning ustida va ostida) 2 ning qarshisida qaysi raqam?",o:["4","3","1","5"],k:0,s:"Bitta oralab: 2 va 4."},
{t:"6 ta kvadratdan iborat qaysi shakl kub yoyilmasi bo'ladi?",o:["Xoch: 4 tasi qatorda, ikkinchisining tepasida va ostida bittadan","2 × 3 to'rtburchak","6 ta kvadrat bitta qatorda","5 tasi qatorda va 1 tasi tepada"],k:0,s:"Xoch (1-4-1) — kub yoyilmasi; qolganlarida yoqlar ustma-ust tushadi."}
];
function PRACT_STAGE(){j10Iso([[3,3],[2,2],[1,1]],{oy:74})}
var PREP_DATA={teach:["Kubiklarni ustunlab sanash, yashirin kubiklar.","Kub yoyilmalari; qarama-qarshi yoqlar.","O'yin zari: qarama-qarshi yoqlar yig'indisi 7.","Bo'yalgan kub: uchlar, qirralar, yoqlar, ichki qism."],
 mist:["Faqat ko'rinadigan kubiklarni sanaydi.","Yoyilmada qo'shni kvadratlarni qarama-qarshi deb o'ylaydi.","Bo'yalgan kubda uchlar sonini 4 yoki qirralar sonini 8 deb oladi."],
 need:["Kubiklar (konstruktor yoki shakar).","Karton yoyilmalar, qaychi, yelim.","O'yin zari."],
 board:["Kub: <span class='w2'>6 yoq · 12 qirra · 8 uch</span>","Zar: <span class='w2'>1–6, 2–5, 3–4</span>","3×3×3: <span class='w2'>8 / 12 / 6 / 1</span>","Yoyilma: bitta oralab — qarama-qarshi"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
