var CODE='4J02',TITLE="4-sinf · Shaklli qonuniyatlar";
function j2Sq(x,y,s,f){E('rect',{x:x,y:y,width:s,height:s,fill:f||C.b,stroke:'#2a4a6a','stroke-width':1.1},S.g)}
function j2L(){clear();var s=11,xs=[22,70,128,198];xs.forEach(function(x0,k){var n=k+1;for(var i=0;i<n;i++)j2Sq(x0,118-(i+1)*s,s);for(var j=1;j<n;j++)j2Sq(x0+j*s,118-s,s);T(S.g,x0+n*s/2,140,(k+1)+'-shakl: '+(2*n-1),{'font-size':11,'font-weight':800,fill:'#1d2b3a'})});T(S.g,310,90,'10-shakl?',{'font-size':15,'font-weight':800,fill:C.bad})}
function j2Fr(){clear();var s=10,xs=[24,84,156];xs.forEach(function(x0,k){var n=k+3;for(var i=0;i<n;i++)for(var j=0;j<n;j++){var e=i===0||j===0||i===n-1||j===n-1;j2Sq(x0+j*s,30+i*s,s,e?C.a:'#fff')}T(S.g,x0+n*s/2,104,n+'×'+n+': '+(4*n-4),{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});T(S.g,300,70,'10×10?',{'font-size':15,'font-weight':800,fill:C.bad})}
var J2D=['up','right','down','left'],J2R={up:0,right:90,down:180,left:270};
function j2Arr(x,y,dir,col){var g=E('g',{transform:'translate('+x+','+y+') rotate('+J2R[dir]+')'},S.g);E('path',{d:'M0,-18 L11,-2 L4,-2 L4,16 L-4,16 L-4,-2 L-11,-2Z',fill:col,stroke:'#33415a','stroke-width':1},g)}
function j2Arrows(n){clear();for(var i=0;i<n;i++){j2Arr(40+i*52,72,J2D[i%4],i%2?C.b:C.bad);T(S.g,40+i*52,118,(i+1)+'',{'font-size':12,'font-weight':800,fill:'#3a4a5a'})}if(n<6)T(S.g,40+n*52+30,78,'… 15?',{'font-size':15,'font-weight':800,fill:C.bad})}
function j2Word(hl){clear();var w='MATEMATIKA';for(var i=0;i<20;i++){var x=18+i*16.6,on=hl&&i===6;if(on)E('rect',{x:x-8,y:52,width:16,height:26,rx:4,fill:'#ffe9a8'},S.g);T(S.g,x,72,w[i%10],{'font-size':16,'font-weight':800,fill:i<10?'#1d2b3a':'#7a8899'});if(i%10===0)T(S.g,x,100,(i+1)+'',{'font-size':10,fill:'#7a8899'})}T(S.g,180,130,hl?'47 = 4 · 10 + 7 → 7-harf: T':'47-harf qaysi?',{'font-size':15,'font-weight':800,fill:hl?C.ok:C.bad})}
function j2Beads(){clear();var c=0,x=20;for(var b=1;b<=5;b++){for(var i=0;i<b;i++){E('circle',{cx:x,cy:70,r:7.5,fill:b%2?C.bad:C.b,stroke:'#33415a','stroke-width':1},S.g);x+=17;c++}x+=6}T(S.g,180,112,'1 qizil, 2 ko‘k, 3 qizil, 4 ko‘k, 5 qizil, …',{'font-size':12,'font-weight':700,fill:'#3a4a5a'})}
function j2Plus(){clear();var xs=[40,110,200];xs.forEach(function(x0,k){var n=k;E('circle',{cx:x0,cy:70,r:4.5,fill:C.a},S.g);for(var d=1;d<=n;d++){[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(v){E('circle',{cx:x0+v[0]*d*11,cy:70+v[1]*d*11,r:4.5,fill:C.a},S.g)})}T(S.g,x0,124,(k+1)+'-shakl: '+(4*k+1),{'font-size':11,'font-weight':800,fill:'#1d2b3a'})});T(S.g,300,74,'81 nuqta?',{'font-size':14,'font-weight':800,fill:C.bad})}
function j2Sier(){clear();function tri(x,y,s,d){if(d===0){E('path',{d:'M'+x+','+y+' l'+s/2+','+(-s*.87)+' l'+s/2+','+(s*.87)+'z',fill:C.a,stroke:'#8a5a24','stroke-width':.6},S.g);return}tri(x,y,s/2,d-1);tri(x+s/2,y,s/2,d-1);tri(x+s/4,y-s*.435,s/2,d-1)}
 [0,1,2,3].forEach(function(d,k){tri(14+k*86,130,72,d);T(S.g,50+k*86,152,String(Math.pow(3,d)),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}
var STEPS=[
J4({h:"O'sib boruvchi L shakl",sum:"Har yangi shaklga 2 ta kvadrat qo'shiladi: 1, 3, 5, 7 … n-shaklda 2 · n − 1 ta. 10-shaklda 19.",a:"m01",
 s:j2L,m:"Har shaklda tepaga 1 ta, o‘ngga 1 ta kvadrat qo‘shiladi",f:function(){j2L();j3Msg('10-shakl: 2 · 10 − 1 = <b>19</b> kvadrat')},
 html:"<p>Kvadratlardan L harfi shaklidagi figuralar terilgan. Har yangi shaklda nima qo'shilyapti? <b>10-shaklda</b> nechta kvadrat bo'ladi?</p>",
 ch:["19","20","21","17"],ok:0,bad:["","2 · 10 = 20 — burchakdagi kvadrat ikki marta sanalmaydi","21 — bu 11-shakl","17 — bu 9-shakl"],
 after:"<p>L shaklning ikki «qo'li» bor: tik va yotiq, har biri n ta kvadratdan. Lekin burchakdagi kvadrat ikkalasiga ham tegishli — u bir marta sanaladi: n + n − 1 = 2 · n − 1. 10-shakl: 19.</p>",
 q:{t:"L shakllarda kvadratlar: 1, 3, 5, 7, … Nechanchi shaklda 25 ta kvadrat bo'ladi?",opts:["13","12","25","14"],ok:0,why:"2 · n − 1 = 25 → n = 13.",hint:"2 · n − 1 = 25 bo'lishi uchun n qanday bo'ladi?",full:"25 + 1 = 26, 26 : 2 = 13. Tekshirish: 2 · 13 − 1 = 25 ✓. «12» — 1 ni qo'shishni unutish."},
 tn:"Katakli daftarda bolalar 5-shaklgacha chizib, jadval to'ldirsin: shakl raqami → kvadratlar soni."}),
J4({h:"Kvadrat ramka",sum:"n×n kvadratning chetidagi kataklar: 4 · n − 4 (burchaklar ikki marta sanalmasin). 10×10 → 36.",a:"m02",
 s:j2Fr,m:"Chetidagi (sariq) kataklarni sanang",f:function(){j2Fr();j3Msg('4 · 10 − 4 = <b>36</b> (yoki 100 − 64)')},
 html:"<p>Kvadratlarning faqat chetidagi kataklari bo'yalgan: 3×3 → 8, 4×4 → 12, 5×5 → 16. <b>10×10</b> kvadratning chetida nechta katak bo'ladi?</p>",
 ch:["40","36","100","32"],ok:1,bad:["4 · 10 = 40 — 4 ta burchak ikki marta sanaldi","","100 — bu barcha kataklar, ichkisi ham","Har tomonga 8 dan emas: yuqori va pastki qatorlar to‘liq 10 tadan"],
 after:"<p>Uch xil yo'l bilan tekshiramiz: 4 · 10 − 4 = 36; yoki 10 + 10 + 8 + 8 = 36; yoki hammasi 100, ichkisi 8 × 8 = 64, 100 − 64 = 36. Uchala yo'l bir xil javob berdi — demak to'g'ri.</p>",
 q:{t:"8×8 kvadratning chetidagi kataklar soni?",opts:["28","32","64","24"],ok:0,why:"4 · 8 − 4 = 28.",hint:"Burchakdagi kataklarni ikki marta sanamang.",full:"8 + 8 + 6 + 6 = 28 yoki 64 − 36 = 28. «32» — burchaklarni ikki marta sanash."},
 tn:"Shaxmat taxtasida (8×8) chetdagi kataklarni sanatib, uchta usulni solishtiring."}),
J4({h:"Ikki qonuniyat birga",sum:"Strelka 4 qadamda aylanib qaytadi, rang 2 qadamda. 15-qadam: yo'nalish 15 → 3-holat (pastga), rang 15 → toq (qizil).",a:"m03",
 s:function(){j2Arrows(5)},m:"Yo‘nalish har 4 qadamda, rang har 2 qadamda takrorlanadi",f:function(){j2Arrows(6);j3Msg('15-qadam: 15 = 4 · 3 + 3 → pastga; 15 toq → qizil')},
 html:"<p>Strelka har qadamda soat mili yo'nalishida chorak aylanadi, rangi esa qizil–ko'k bo'lib almashadi. <b>15-qadamda</b> strelka qanday bo'ladi?</p>",
 ch:["pastga, qizil","pastga, ko‘k","chapga, qizil","yuqoriga, ko‘k"],ok:0,bad:["","Yo‘nalish to‘g‘ri. Rang: 1, 3, 5 … — toq qadamlar qanday rangda?","Rang to‘g‘ri. Yo‘nalish: 15 ni 4 ga bo‘lgandagi qoldiqqa qarang","15 : 4 qoldiq 3 — 3-qadamdagi strelkaga qarang"],
 after:"<p>Ikki qonuniyatni <b>alohida</b> hisoblaymiz. Yo'nalish: 4 ta holat, 15 = 4 · 3 + 3 → 3-holat (pastga). Rang: 2 ta holat, 15 toq → 1-holat (qizil). Ikkalasi bir vaqtda 1-holatga 4 qadamda qaytadi.</p>",
 q:{t:"Xuddi shu strelka (1-qadamda yuqoriga). 22-qadamda qayerga qaraydi?",opts:["o'ngga","chapga","yuqoriga","pastga"],ok:0,why:"22 = 4 · 5 + 2 → 2-holat: o'ngga.",hint:"22 ni 4 ga bo'ling, qoldiqqa qarang.",full:"Yo'nalishlar: 1 — yuqoriga, 2 — o'ngga, 3 — pastga, 4 — chapga. 22 : 4 = 5 (qoldiq 2) → o'ngga."},
 tn:"Bitta bola strelka kartochkasini aylantiradi, boshqasi rang kartochkasini almashtiradi — 12 qadamgacha o'ynab ko'ring."}),
J4({h:"So'z takrorlanadi",sum:"MATEMATIKA (10 harf) takrorlanadi. 47 = 4 · 10 + 7 → so'zning 7-harfi: T.",a:"m04",
 s:function(){j2Word(0)},m:"MATEMATIKA so‘zi qayta-qayta yozilgan",f:function(){j2Word(1)},
 html:"<p>MATEMATIKAMATEMATIKAMATEMATIKA… — so'z qayta-qayta yozilgan. <b>47-harf</b> qaysi?</p>",
 ch:["T","I","A","M"],ok:0,bad:["","I — so‘zning 8-harfi. 47 ni 10 ga bo‘lgandagi qoldiq 7","A — 10-harf; 47 butun bloklar bilan tugamaydi","M — 1-harf, bu 41-harf bo‘ladi"],
 after:"<p>Blok uzunligi — 10. 47 = 4 · 10 + 7: to'rtta to'liq so'zdan keyin yana 7 ta harf. MATEMAT — 7-harf <b>T</b>. Qoldiq 0 bo'lsa — blokning <b>oxirgi</b> harfi olinadi, birinchisi emas!</p>",
 q:{t:"KITOBKITOBKITOB… 33-harf qaysi?",opts:["T","O","I","K"],ok:0,why:"33 = 6 · 5 + 3 → 3-harf: T.",hint:"Blok necha harfli? Qoldiqni toping.",full:"KITOB — 5 harf. 33 : 5 = 6 (qoldiq 3). K-I-T → T."},
 tn:"Bolalar o'z ismini takrorlab yozib, sinfdoshiga «30-harf qaysi?» degan savol bersin."}),
J4({h:"Tuzoq: o'sib boruvchi bloklar",sum:"1 qizil, 2 ko'k, 3 qizil, … Bloklar o'sadi. 30 ta sharda ko'k: 2 + 4 + 6 = 12, keyin 8-blokdan 2 ta → 14.",a:"m05",
 s:j2Beads,m:"Bloklar uzunligi 1, 2, 3, 4, … — har gal bittaga oshadi",
 f:function(){j3Lines(['1+2+…+7 = 28 shar','ko‘k: 2 + 4 + 6 = 12','29, 30 — 8-blok (ko‘k): +2 → [14]'],{fs:16,lh:34})},fm:"Bloklarni to‘liq sanab, qolganini alohida qo‘shamiz",
 html:"<p>Sharlar: 1 qizil, 2 ko'k, 3 qizil, 4 ko'k, 5 qizil, … Bloklar uzunligi o'sib boradi. Dastlabki <b>30 ta</b> sharning nechtasi <b>ko'k</b>?</p>",
 ch:["15","14","12","16"],ok:1,bad:["30 : 2 = 15 — bloklar teng emas, yarmi ko‘k bo‘lmaydi","","12 — 28 tagacha sanadingiz, 29 va 30 qaysi blokda?","8-blokning hammasi 30 ga sig‘maydi"],
 after:"<p>Bloklar 1, 2, 3, … Yig'indilar: 1, 3, 6, 10, 15, 21, 28. 7 ta blok — 28 shar. Ko'k bloklar: 2, 4, 6 → 12 ta. 29- va 30-sharlar 8-blokda (juft → ko'k): yana 2. Jami <b>14</b>.</p>",
 q:{t:"Xuddi shu qatorda dastlabki 21 ta sharning nechtasi qizil?",opts:["9","12","10","11"],ok:0,why:"21 = 1 + 2 + … + 6. Qizil: 1 + 3 + 5 = 9.",hint:"21 ta shar nechta to'liq blokdan iborat?",full:"1 + 2 + 3 + 4 + 5 + 6 = 21. Qizil bloklar — toqlari: 1 + 3 + 5 = 9. Ko'k: 2 + 4 + 6 = 12."},
 tn:"Munchoq yoki rangli qalamlar bilan qatorni terib ko'rsating. Bloklar yig'indisi — 4J01 dagi uchburchak sonlar."}),
J4({h:"Teskari savol: nechanchi shakl?",sum:"1, 5, 9, 13 nuqta — n-shaklda 4 · (n − 1) + 1. 81 nuqta → 4 · (n − 1) = 80 → n = 21.",a:"m06",
 s:j2Plus,m:"Har yangi shaklda 4 ta qo‘lning har biriga 1 nuqta qo‘shiladi",
 f:function(){j3Lines(['81 − 1 = 80 (qo‘llardagi nuqtalar)','80 : 4 = 20 qadam','1-shakl + 20 = [21-shakl]'],{fs:16,lh:34})},fm:"Teskari yo‘l: markazni ayiramiz, 4 ga bo‘lamiz, 1 qo‘shamiz",
 html:"<p>Nuqtalardan «plyus» shakllari terilgan: 1, 5, 9, … nuqta. <b>Nechanchi shaklda</b> 81 ta nuqta bo'ladi?</p>",
 ch:["20","21","81","19"],ok:1,bad:["20 — bu qadamlar soni. 1-shakldan 20 qadam keyin nechanchi shakl?","","81 — nuqtalar soni, shakl raqami emas","19-shaklda 4 · 18 + 1 = 73 nuqta"],
 after:"<p>Markazda 1 nuqta, 4 ta qo'lda qolgani: 80. Har qadamda 4 ta qo'shiladi → 20 qadam. 1-shakldan 20 qadam keyin — <b>21-shakl</b>. Tekshirish: 4 · 20 + 1 = 81 ✓.</p>",
 q:{t:"Xuddi shu plyus shakllar. 15-shaklda nechta nuqta?",opts:["57","60","61","56"],ok:0,why:"4 · 14 + 1 = 57.",hint:"1-shakldan 15-shaklgacha nechta qadam?",full:"14 qadam, har biri +4: 1 + 56 = 57. «61» — 15 ta qadam olish xatosi."},
 tn:"Jadvalda «shakl raqami → nuqtalar» ni yozing, keyin teskari: «nuqtalar → shakl raqami»."}),
J4info({h:"Bilasizmi? Serpinskiy uchburchagi",a:"m07",s:j2Sier,m:"Har qadamda har uchburchak 3 ta kichigiga bo‘linadi",
 html:"<p>📐 Polshalik matematik <b>Vaclav Serpinskiy</b> 1915-yilda shunday shaklni tasvirlagan: uchburchakning o'rtasini olib tashlaymiz — 3 ta uchburchak qoladi; har biriga yana shu ishni qilamiz — 9 ta, keyin 27 ta… Shaklning har bir bo'lagi butunining kichik nusxasi. Bunday shakllar <b>fraktallar</b> deyiladi — ular daraxt shoxlarida, qor parchalarida, karam bargida uchraydi.</p>",
 tn:"Uchburchakli qog'ozda bolalar Serpinskiy uchburchagining 3-qadamini chizsin va sariq uchburchaklarni sanasin (27)."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:j2Fr,m:"Shaklni songa aylantiring — keyin qonuniyat ko‘rinadi",
 html:"<div class='memo'><ul><li>Har shaklni <b>songa</b> aylantiring va jadval tuzing.</li><li>«Nima qo'shilyapti?» — yangi qismni rangli ko'ring.</li><li>Burchak va kesishmalarni <b>ikki marta sanamang</b>.</li><li>Takrorlanuvchi blok: o'rin : blok uzunligi → qoldiq. Qoldiq 0 → blokning oxirgisi.</li><li>Ikki qonuniyat — alohida-alohida hisoblang.</li><li>Teskari savol: amallarni orqadan bajaring va tekshiring.</li></ul></div>",
 tn:"Uyga: o'z shaklli qonuniyatini (5 ta shakl) chizib kelish va qo'shniga «10-shakl» savolini berish."})
];
var PROBS=[
{t:"Shakllardagi kvadratlar soni: 1, 4, 7, 10, … 6-shaklda nechta kvadrat?",o:["16","13","19","18"],k:0,s:"Har shaklda +3: 10, 13, 16."},
{t:"Shakllar navbatlashadi: doira, uchburchak, kvadrat, yulduz, doira, uchburchak, … 50-shakl qaysi?",o:["uchburchak","doira","kvadrat","yulduz"],k:0,s:"Blok 4 ta: 50 = 4 · 12 + 2 → 2-shakl: uchburchak."},
{t:"Kubiklardan zina: 1-shaklda 1 kubik, 2-shaklda 3 (2 + 1), 3-shaklda 6 (3 + 2 + 1). 5-shaklda nechta kubik?",o:["15","10","21","12"],k:0,s:"5 + 4 + 3 + 2 + 1 = 15."},
{t:"6×6 kataklik kvadratning faqat chetidagi kataklari bo'yaldi. Nechta katak bo'yaldi?",o:["20","24","36","16"],k:0,s:"4 · 6 − 4 = 20 (yoki 36 − 16)."},
{t:"Soat mili 12 ni ko'rsatadi. Har qadamda u soat yo'nalishida chorak aylanadi. 10 qadamdan keyin u qaysi sonni ko'rsatadi?",o:["6","3","9","12"],k:0,s:"4 qadamda 12 ga qaytadi; 10 = 4 · 2 + 2 → yarim aylana: 6."},
{t:"QORAKOLQORAKOL… — so'z takrorlanib yozilgan. 30-harf qaysi?",o:["O","R","Q","L"],k:0,s:"Blok 7 harf: 30 = 7 · 4 + 2 → 2-harf: O."},
{t:"QORAKOLQORAKOL… Dastlabki 30 ta harfda nechta O bor?",o:["9","8","10","4"],k:0,s:"Har blokda 2 ta O: 4 blokda 8; 29-harf Q, 30-harf O → 9."},
{t:"Har shaklda nuqtalar oldingisidan 2 marta ko'p: 3, 6, 12, … 6-shaklda nechta nuqta?",o:["96","48","192","36"],k:0,s:"3, 6, 12, 24, 48, 96."},
{t:"Munchoqlar: 2 qizil, 1 oq, 2 qizil, 1 oq, … 40 ta munchoqda nechta qizil?",o:["27","26","28","20"],k:0,s:"Blok 3 ta: 13 blok = 39 ta, qizil 26; 40-munchoq yangi blokning 1-si — qizil: 27."},
{t:"Katta uchburchak kichik uchburchaklarga bo'lingan: 1-shaklda 1 ta, 2-shaklda 4 ta, 3-shaklda 9 ta. 6-shaklda nechta kichik uchburchak?",o:["36","18","21","30"],k:0,s:"Kvadrat sonlar: 6 · 6 = 36."},
{t:"Plyus shakllar kataklardan: 1-shaklda 5 ta, 2-shaklda 9 ta, 3-shaklda 13 ta katak. 10-shaklda nechta katak?",o:["41","45","40","50"],k:0,s:"5 + 9 · 4 = 41."},
{t:"Zina: 1-shaklda 1 kvadrat, 2-shaklda 1 + 3, 3-shaklda 1 + 3 + 5 kvadrat. 7-shaklda jami nechta kvadrat?",o:["49","13","28","36"],k:0,s:"1 + 3 + 5 + … + 13 = 7 · 7 = 49."},
{t:"Strelka yuqoriga qaraydi. Har qadamda u soat yo'nalishida aylananing sakkizdan biriga buriladi. Nechanchi qadamdan keyin birinchi marta yana yuqoriga qaraydi?",o:["8","4","2","6"],k:0,s:"To'liq aylanish 8 qadam."},
{t:"●●○●●○… qatorining dastlabki 100 ta belgisida nechta ○ bor?",o:["33","34","50","66"],k:0,s:"Blok 3 ta: 33 blok = 99 belgi, 33 ta ○; 100-belgi ●."},
{t:"1-shaklda 1 ta doira. Har keyingi shaklda har bir doira o'rniga 3 ta doira chiziladi: 1, 3, 9, … 5-shaklda nechta doira?",o:["81","27","15","243"],k:0,s:"1, 3, 9, 27, 81."},
{t:"n-shaklda pog'onali shakl: 1 + 2 + … + n katak. Nechanchi shaklda birinchi marta 50 dan ko'p katak bo'ladi?",o:["10","9","50","11"],k:0,s:"9-shakl: 45, 10-shakl: 55 > 50."},
{t:"Kvadrat ramkaning chetida 44 ta katak bor. Kvadratning tomoni necha katak?",o:["12","11","10","13"],k:0,s:"4 · n − 4 = 44 → 4 · n = 48 → n = 12."},
{t:"Strelka har qadamda soat yo'nalishida chorak aylanadi, rangi qizil, ko'k, yashil bo'lib navbatlashadi. Boshida: yuqoriga, qizil. Necha qadamdan keyin birinchi marta yana «yuqoriga, qizil» bo'ladi?",o:["12","7","4","3"],k:0,s:"Yo'nalish har 4 da, rang har 3 da qaytadi: ikkalasi birga — 12 da."},
{t:"AB ABB ABBB ABBBB … — har guruhda B bittaga ko'payadi. Dastlabki 5 ta guruhda nechta B bor?",o:["15","5","20","10"],k:0,s:"1 + 2 + 3 + 4 + 5 = 15."},
{t:"Yonma-yon uychalar tayoqchalardan: 1 uy — 6 tayoqcha, 2 uy — 11, 3 uy — 16. 10 ta uy uchun nechta tayoqcha?",o:["51","60","50","56"],k:0,s:"Har yangi uyga 5 ta: 6 + 9 · 5 = 51."}
];
function PRACT_STAGE(){j2Beads()}
var PREP_DATA={teach:["O'sib boruvchi shakllarni songa aylantirish (jadval).","Burchak va umumiy qismlarni bir marta sanash.","Takrorlanuvchi blok va qoldiq.","Ikki qonuniyat bir vaqtda.","Teskari savol: nechanchi shakl?"],
 mist:["Burchakdagi kataklarni ikki marta sanaydi.","Qoldiq 0 bo'lsa blokning 1-elementini oladi.","O'sib boruvchi bloklarni teng deb hisoblaydi."],
 need:["Katakli daftar, rangli qalamlar.","Munchoq yoki tugmachalar.","Strelka va rang kartochkalari."],
 board:["L shakl: 2 · n − 1","Ramka: 4 · n − 4","o'rin = blok · k + qoldiq","Serpinskiy: 1, 3, 9, 27"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
