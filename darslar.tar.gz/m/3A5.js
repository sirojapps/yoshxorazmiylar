var CODE='3A5',TITLE='3-sinf · Xona qo‘shiluvchilari';
function a5(n,hl,o){clear();w3heads();w3blocks(n,40,hl,o)}
function a5txt(t,col){T(S.g,180,150,t,{'font-size':20,'font-weight':800,fill:col||C.blue})}
var P1=[function(){a5(735);msg('735 ni bloklar bilan ko‘ramiz')},function(){a5(735,'h');a5txt('7 yuzlik = 700');msg('Yuzliklar: <b>700</b>')},function(){a5(735,'t');a5txt('3 o‘nlik = 30');msg('O‘nliklar: <b>30</b>')},function(){a5(735,'u');a5txt('5 birlik = 5');msg('Birliklar: <b>5</b>')},function(){a5(735);a5txt('735 = 700 + 30 + 5',C.ok);msg('<b>735 = 700 + 30 + 5</b> — xona qo‘shiluvchilari')}];
var P5=[function(){clear();var g=S.g;T(g,180,70,'7 7 7',{'font-size':54,'font-weight':800,fill:'#1d2b3a','letter-spacing':10});msg('Uchta bir xil raqam. Qiymatlari ham bir xilmi?')},
 function(){clear();var g=S.g;[['7','700',C.t1],['7','70','#b07a33'],['7','7',C.u]].forEach(function(r,i){var x=100+i*80;T(g,x,70,r[0],{'font-size':54,'font-weight':800,fill:r[2]});T(g,x,120,r[1],{'font-size':20,'font-weight':800,fill:r[2]})});msg('700 + 70 + 7 = 777. Raqam bir xil — qiymati <b>joyiga</b> bog‘liq')}];
var STEPS=[
{h:"Sonni xonalarga yoyamiz",sum:"735 = 700 + 30 + 5: har bir raqam o'z xonasining qiymatini beradi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=4;P1[4]()},
 html:"<p>Har bir uch xonali son — yuzliklar, o'nliklar va birliklar <b>yig'indisi</b>. Ularni <b>xona qo'shiluvchilari</b> deymiz. Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>735 = <b>700 + 30 + 5</b>. Diqqat: 7 + 3 + 5 emas! Raqamlar yig'indisi (15) va xona qo'shiluvchilari — boshqa-boshqa narsa.</p>",
 q:{t:"864 ni xona qo'shiluvchilariga ajrating.",opts:["8 + 6 + 4","800 + 60 + 4","800 + 64","80 + 60 + 4"],ok:1,why:"8 yuzlik = 800, 6 o'nlik = 60, 4 birlik = 4.",hint:"Har bir raqam qaysi xonada turibdi?",full:"864 = 800 + 60 + 4. «8 + 6 + 4» — raqamlar yig'indisi; «800 + 64» — to'liq ajratilmagan; «80 + 60 + 4» — yuzlikni o'nlik deb olish."},
 tn:"Montessori «oltin munchoq» yoki ustma-ust qo'yiladigan raqam kartochkalari (700, 30, 5) — kartochkalarni ustma-ust qo'yib 735 ni yasang."},
{h:"Nol bor sonlar",sum:"508 = 500 + 8: o'nliklar yo'q, nolni qo'shiluvchi sifatida yozmaymiz.",a:"m02",
 start:function(){a5(508);msg('508 — o‘nliklar xonasi bo‘sh')},fin:function(){a5(508);a5txt('508 = 500 + 8',C.ok)},
 html:"<p>508 da o'nliklar <b>yo'q</b> — nol ularning joyini saqlaydi. 508 ning xona qo'shiluvchilari qaysi?</p>",
 btns:w3choose(["50 + 8","500 + 8","5 + 0 + 8"],1,function(){a5(508);a5txt('508 = 500 + 8',C.ok);msg('O‘nliklar yo‘q — qo‘shiluvchi ham yo‘q (yoki 500 + 0 + 8)')},function(i){msg(i===0?'50 + 8 = 58 — yuzlik yo‘qolib qoldi!':'5 + 0 + 8 = 13 — bu raqamlar yig‘indisi')}),g3:1,
 after:"<p>Teskarisi ham tuzoq: <b>600 + 4</b> = 604 (64 emas!), <b>900 + 20</b> = 920. Bo'sh xonaga albatta <b>0</b> yozing.</p>",
 q:{t:"300 + 7 qaysi son?",opts:["37","307","370","3007"],ok:1,why:"3 yuzlik, 0 o'nlik, 7 birlik — 307.",hint:"O'nliklar xonasiga nima yoziladi?",full:"300 + 7 = 307. 37 — nolni tushirib qoldirish; 370 — 7 ni o'nlik deb yozish; 3007 — 300 va 7 ni yonma-yon yozish."},
 tn:"Kartochkalar: 300 kartochkasining ustiga 7 ni qo'ying — 307 ko'rinadi."},
{h:"Aralash tartibdagi qo'shiluvchilar",sum:"6 + 400 + 90: avval yuzliklarni topamiz — 496.",a:"m03",
 start:function(){clear();T(S.g,180,80,'6 + 400 + 90 = ?',{'font-size':34,'font-weight':800,fill:'#1d2b3a'});msg('Qo‘shiluvchilar aralash tartibda')},fin:function(){a5(496);a5txt('6 + 400 + 90 = 496',C.ok)},
 html:"<p>Qo'shiluvchilar aralashib ketgan. Tuzoq — ularni yozilgan tartibda «yopishtirish». Sonni tanlang:</p>",
 btns:w3choose(["640","496","694"],1,function(){a5(496);a5txt('6 + 400 + 90 = 496',C.ok);msg('400 → 4 yuzlik, 90 → 9 o‘nlik, 6 → 6 birlik')},function(i){msg(i===0?'640 — raqamlarni yozilgan tartibda qo‘ydingiz':'694 — 6 ni yuzlik deb oldingiz. 6 — bu birliklar')}),g3:1,
 after:"<p>Har bir qo'shiluvchini o'z xonasiga qo'ying: 400 → yuzliklar, 90 → o'nliklar, 6 → birliklar. Tartib ahamiyatsiz — qo'shish o'rin almashtirish xossasiga ega.</p>",
 q:{t:"70 + 2 + 500 = ?",opts:["725","572","527","752"],ok:1,why:"5 yuzlik, 7 o'nlik, 2 birlik — 572.",hint:"Qaysi qo'shiluvchi yuzlik?",full:"500 — yuzliklar (5), 70 — o'nliklar (7), 2 — birliklar. 572. «725» — yozilgan tartib; «527» va «752» — xonalarni almashtirish."},
 tn:"Bolalar raqam kartochkalarini xonalar jadvaliga «uyiga» joylashtirsin."},
{h:"Tuzoq: o'nliklar 9 dan ko'p",sum:"4 yuzlik 15 o'nlik 2 birlik = 400 + 150 + 2 = 552.",a:"m04",
 start:function(){a5(0,null,{h:4,t:15,u:2,label:'?'});msg('4 yuzlik, 15 o‘nlik, 2 birlik')},fin:function(){a5(0,null,{h:4,t:15,u:2,label:'552'});a5txt('400 + 150 + 2 = 552',C.ok)},
 html:"<p>«4 yuzlik, 15 o'nlik va 2 birlik — qaysi son?» Ko'pchilik raqamlarni yonma-yon yozib <b>4152</b> deydi. To'g'ri javobni tanlang:</p>",
 btns:w3choose(["4152","552","452"],1,function(){a5(0,null,{h:4,t:15,u:2,label:'552'});a5txt('400 + 150 + 2 = 552',C.ok);msg('10 o‘nlik = 1 yuzlik: 4 + 1 = 5 yuzlik, 5 o‘nlik qoldi')},function(i){msg(i===0?'4152 — bu to‘rt xonali son! Har bir guruhning qiymatini qo‘shing':'452 — 15 o‘nlikdan faqat 5 tasini oldingiz')}),g3:1,
 after:"<p>15 o'nlik = 150 = 1 yuzlik va 5 o'nlik. Shuning uchun 400 + 150 + 2 = <b>552</b>. Yo'l: har bir guruhni qiymatga aylantiring va qo'shing.</p>",
 q:{t:"3 yuzlik, 2 o'nlik va 17 birlik = ?",opts:["3217","337","327","347"],ok:1,why:"300 + 20 + 17 = 337.",hint:"17 birlik = 1 o'nlik va 7 birlik.",full:"300 + 20 + 17 = 337. «3217» — yonma-yon yozish; «327» — 17 dan faqat 7 ni olish; «347» — o'nlikni ikki marta qo'shish."},
 tn:"Bloklarda: 15 ta tayoqchadan 10 tasini bitta yuzlik kvadratga almashtirib ko'rsating (Yapon «almashtirish»)."},
{h:"Raqamning qiymati uning joyiga bog'liq",sum:"777: chapdagi 7 — 700, o'rtadagi — 70, o'ngdagi — 7.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>777 sonida uchta bir xil raqam bor. Ular bir xil qiymatga egami? Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>Bir xil raqam turli xonada turli qiymat oladi. 474 da: chapdagi 4 — <b>400</b>, o'ngdagi 4 — <b>4</b>. Ularning farqi: 400 − 4 = <b>396</b>.</p>",
 q:{t:"383 sonidagi ikkala 3 raqamining qiymatlari farqi qancha?",opts:["297","0","300","3"],ok:0,why:"300 − 3 = 297.",hint:"Chapdagi 3 — qaysi xonada?",full:"Chapdagi 3 — yuzlik (300), o'ngdagi 3 — birlik (3). 300 − 3 = 297. «0» — raqamlar bir xil, lekin qiymatlar emas."},
 tn:"Bank savollarining sevimli turi: «raqamlar qiymatlari farqi/yig'indisi»."},
{h:"Tuzoq: raqamlar yig'indisi berilgan",sum:"Raqamlar yig'indisi 20, eng kichik uch xonali son: o'nlik va birlik — 9, yuzlik — 2: 299.",a:"m06",
 start:function(){clear();T(S.g,180,60,'□ + □ + □ = 20',{'font-size':30,'font-weight':800,fill:'#1d2b3a'});T(S.g,180,110,'eng kichik uch xonali son?',{'font-size':16,'font-weight':700,fill:'#5b6b7b'});msg('Yuzliklar raqami iloji boricha kichik bo‘lsin')},
 fin:function(){clear();T(S.g,180,60,'2 + 9 + 9 = 20',{'font-size':30,'font-weight':800,fill:C.ok});T(S.g,180,110,'299',{'font-size':30,'font-weight':800,fill:C.ok})},
 html:"<p>«Raqamlari yig'indisi 20 ga teng bo'lgan <b>eng kichik</b> uch xonali son». Son kichik bo'lishi uchun <b>yuzliklar</b> raqami kichik bo'lishi kerak. Tanlang:</p>",
 btns:w3choose(["389","299","479"],1,function(){clear();T(S.g,180,60,'2 + 9 + 9 = 20',{'font-size':30,'font-weight':800,fill:C.ok});T(S.g,180,110,'299',{'font-size':30,'font-weight':800,fill:C.ok});msg('O‘nlik va birlik — eng katta (9 + 9 = 18), yuzlik 20 − 18 = <b>2</b>')},function(i){msg(i===0?'3 + 8 + 9 = 20 ✓, lekin 299 undan kichik — yuzlik 2 ham bo‘ladi':'4 + 7 + 9 = 20 ✓, lekin yuzlikni kichikroq qilsa bo‘ladi')}),g3:1,
 after:"<p>Usul: kichik son — chap raqam kichik. O'ng raqamlarni iloji boricha <b>katta</b> (9) qilamiz, shunda chap raqam kichrayadi: 9 + 9 = 18, 20 − 18 = 2 → <b>299</b>. Eng katta son uchun aksincha: 992.</p>",
 q:{t:"Raqamlari yig'indisi 20 ga teng eng katta uch xonali son?",opts:["992","299","983","911"],ok:0,why:"Yuzlik 9, o'nlik 9, birlik 20 − 18 = 2: 992.",hint:"Chap raqamlarni iloji boricha katta qiling.",full:"Eng katta son — chapdan eng katta raqamlar: 9, 9, keyin 20 − 18 = 2 → 992. 983 ham mos, lekin kichikroq; 299 — eng kichigi; 911 — yig'indisi 11."},
 tn:"Bank (2158). Shu masalani yig'indi 5, 10, 25 uchun takrorlash."},
{h:"Bilasizmi? Cho't — xonalar mashinasi",sum:"Cho'tda (abakda) har bir sim — bitta xona: birlik, o'nlik, yuzlik.",a:"m07",
 start:function(){a5abak()},fin:function(){a5abak()},
 html:"<p>🧮 Ilgari bozorlarda va do'konlarda <b>cho't</b> bilan hisoblashgan. Uning har bir simi — bitta xona: o'ngdagi — birliklar, keyingisi — o'nliklar, keyin yuzliklar.</p><p>🇯🇵 Yaponiyada bunday hisoblagich <b>soroban</b> deyiladi va bolalar hozir ham u bilan og'zaki hisobni mashq qilishadi.</p>",
 tn:"Agar sinfda cho't bo'lsa — 735 ni unda terdiring."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){a5(735);a5txt('735 = 700 + 30 + 5',C.ok)},fin:function(){a5(735);a5txt('735 = 700 + 30 + 5',C.ok)},
 html:"<div class='memo'><ul><li>Xona qo'shiluvchilari: 735 = <b>700 + 30 + 5</b> (7 + 3 + 5 emas!).</li><li>Nol bo'lsa: 508 = 500 + 8; 300 + 7 = 307.</li><li>Aralash tartib: har qo'shiluvchini o'z xonasiga: 6 + 400 + 90 = 496.</li><li>15 o'nlik = 150: 4 yuz 15 o'n 2 bir = 552.</li><li>Raqam qiymati joyiga bog'liq: 777 = 700 + 70 + 7.</li><li>Eng kichik son — chap raqam kichik, o'ngdagilar katta.</li></ul></div>",
 tn:"Keyingi dars — ko'p xonali sonlar."}
];
function a5abak(){clear();var g=S.g,d=[7,3,5],nm=['yuzlik','o‘nlik','birlik'];E('rect',{x:70,y:20,width:220,height:130,rx:8,fill:'#fdf0e1',stroke:'#8a5a2b','stroke-width':4},g);
 d.forEach(function(v,i){var x=115+i*65;E('line',{x1:x,y1:24,x2:x,y2:146,stroke:'#8a5a2b','stroke-width':2},g);for(var k=0;k<v;k++)E('ellipse',{cx:x,cy:136-k*13,rx:18,ry:6,fill:['#c0392b','#2e86c1','#27ae60'][i]},g);T(g,x,166,nm[i]+': '+v,{'font-size':11,'font-weight':700,fill:'#5b6b7b'})});msg('Cho‘tda 735: 7 · 3 · 5')}
var PROBS=[
{t:"864 = ?",o:["800 + 60 + 4","8 + 6 + 4","800 + 64 + 4","80 + 60 + 4"],k:0,s:"8 yuzlik, 6 o'nlik, 4 birlik."},
{t:"300 + 7 = ?",o:["307","37","370","3007"],k:0,s:"O'nliklar xonasida 0."},
{t:"508 ning xona qo'shiluvchilari:",o:["500 + 8","50 + 8","5 + 0 + 8","500 + 80"],k:0,s:"O'nliklar yo'q."},
{t:"6 + 400 + 90 = ?",o:["496","640","694","469"],k:0,s:"4 yuzlik, 9 o'nlik, 6 birlik."},
{t:"70 + 2 + 500 = ?",o:["572","725","527","752"],k:0,s:"5 yuzlik, 7 o'nlik, 2 birlik."},
{t:"900 + 20 = ?",o:["920","902","92","9020"],k:0,s:"Birliklar yo'q."},
{t:"4 yuzlik, 15 o'nlik va 2 birlik — qaysi son?",o:["552","4152","452","562"],k:0,s:"400 + 150 + 2 = 552."},
{t:"3 yuzlik, 2 o'nlik va 17 birlik = ?",o:["337","3217","327","347"],k:0,s:"300 + 20 + 17 = 337."},
{t:"383 dagi ikkala 3 raqami qiymatlarining farqi:",o:["297","0","300","303"],k:0,s:"300 − 3 = 297."},
{t:"474 dagi ikkala 4 raqami qiymatlarining yig'indisi:",o:["404","8","440","444"],k:0,s:"400 + 4 = 404."},
{t:"Raqamlari yig'indisi 20 ga teng eng kichik uch xonali son:",o:["299","389","479","992"],k:0,s:"9 + 9 = 18, yuzlik 2."},
{t:"Raqamlari yig'indisi 20 ga teng eng katta uch xonali son:",o:["992","983","299","999"],k:0,s:"9, 9, 2."},
{t:"Qaysi son 600 + 5 ga teng?",o:["605","65","650","6005"],k:0,s:"O'nliklar xonasida 0."},
{t:"8 yuzlik va 12 birlik = ?",o:["812","8012","820","821"],k:0,s:"800 + 12 = 812."},
{t:"700 + 30 + 5 sonida o'nliklar 4 taga ko'paytirilsa, qaysi son hosil bo'ladi?",o:["775","739","1135","745"],k:0,s:"4 o'nlik = 40 ko'paydi: 735 + 40 = 775."},
{t:"9 yuzlik, 9 o'nlik va 10 birlik = ?",o:["1000","9910","999","990"],k:0,s:"900 + 90 + 10 = 1000."},
{t:"Raqamlari yig'indisi 5 ga teng eng kichik uch xonali son:",o:["104","113","500","140"],k:0,s:"Yuzlik 1, o'nlik 0, birlik 4."},
{t:"25 o'nlik = ?",o:["250","25","2500","205"],k:0,s:"25 · 10 = 250."},
{t:"Qaysi yozuv noto'g'ri?",o:["409 = 400 + 90","409 = 400 + 9","490 = 400 + 90","499 = 400 + 90 + 9"],k:0,s:"400 + 90 = 490, 409 emas."},
{t:"6 yuzlik, 18 o'nlik va 4 birlik = ?",o:["784","6184","684","694"],k:0,s:"600 + 180 + 4 = 784."}
];
function PRACT_STAGE(){a5(735)}
var PREP_DATA={teach:["Uch xonali sonni xona qo'shiluvchilariga ajratish va qaytadan yig'ish.","Nolli sonlar; aralash tartibdagi va 9 dan ortiq guruhli qo'shiluvchilar.","Raqamning qiymati joyiga bog'liqligi; raqamlar yig'indisi bo'yicha eng kichik/katta son."],mist:["735 = 7 + 3 + 5 deb yozadi.","300 + 7 ni 37 deb yozadi.","6 + 400 + 90 ni 640 deb yozadi.","4 yuzlik 15 o'nlikni 4152 deydi."],need:["Raqam kartochkalari (100, 10, 1 lik), o'nlik bloklar, cho't."],board:["<span class='w2'>735 = 700 + 30 + 5</span>.","<span class='w2'>300 + 7 = 307</span>.","<span class='w2'>4 yuz 15 o'n 2 bir = 552</span>.","<span class='w2'>777 = 700 + 70 + 7</span>.","<span class='w2'>yig'indi 20: eng kichigi 299</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
