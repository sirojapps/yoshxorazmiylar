var CODE='2A4',TITLE='2-sinf · Juft va toq sonlar';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// juftlab ko'rsatish: n ta nuqta, ikki qatorda juft-juft
function pairs(n,o){o=o||{};clear();var g=S.g,k=Math.ceil(n/2),step=Math.min(36,300/Math.max(k,1)),x0=180-(k-1)*step/2;
 T(g,180,24,n+' ta',{'font-size':16,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<k;i++){var x=x0+i*step,full=2*i+1<n;
  if(full){E('rect',{x:x-12,y:46,width:24,height:72,rx:12,fill:'none',stroke:C.ok,'stroke-width':2,'stroke-dasharray':'4 3'},g)}
  E('circle',{cx:x,cy:62,r:9,fill:full?C.b:C.bad,stroke:'#fff','stroke-width':2},g);if(full)E('circle',{cx:x,cy:102,r:9,fill:C.b,stroke:'#fff','stroke-width':2},g)}
 var odd=n%2===1;T(g,180,148,odd?'bittasi juftsiz qoldi — TOQ':'hammasi juftlandi — JUFT',{'font-size':14,'font-weight':800,fill:odd?C.bad:C.ok});
 if(!o.nomsg)msg(n+' — '+(odd?'<b style="color:#d94b4b">toq</b> son: juftlab bo‘lmaydi, 1 ta ortib qoladi':'<b style="color:#1e8e5a">juft</b> son: hammasi juft-juft bo‘ldi'))}
function line2(from,to,paint){clear();var x0=18,x1=342,y=96,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=from;v<=to;v++){var ev=v%2===0,f=paint?(ev?C.ok:C.a):'#fff';E('circle',{cx:X(v),cy:y,r:7,fill:f,stroke:'#33475b','stroke-width':1.2},S.g);T(S.g,X(v),y+(v%2?-16:24),String(v),{'font-size':9,'font-weight':700,fill:paint?(ev?C.ok:'#b0601f'):'#5b6b7b'})}
 if(paint){T(S.g,60,30,'● juft',{'font-size':13,'font-weight':800,fill:C.ok});T(S.g,150,30,'● toq',{'font-size':13,'font-weight':800,fill:'#b0601f'})}S.X=X}
var P3=[function(){clear();var g=S.g;for(var i=0;i<3;i++)rod(g,40+i*20,30,100);for(var j=0;j<4;j++)unit(g,120,40+j*24);T(g,90,150,'34',{'font-size':20,'font-weight':800,fill:'#1d2b3a'});msg('34 juftmi? O‘nliklarni va birliklarni alohida tekshiramiz')},
 function(){clear();var g=S.g;for(var i=0;i<3;i++){rod(g,40+i*20,30,100);}E('rect',{x:26,y:24,width:70,height:112,rx:8,fill:'none',stroke:C.ok,'stroke-width':2.5},g);T(g,62,150,'o‘nliklar — doim juft',{'font-size':11,'font-weight':800,fill:C.ok});for(var j=0;j<4;j++)unit(g,170,40+j*24);msg('Har bir o‘nlik = 10 ta = 5 ta juftlik. O‘nliklar <b>hech qachon</b> ortiqcha qoldirmaydi')},
 function(){clear();var g=S.g;for(var i=0;i<3;i++)rod(g,40+i*20,30,100);E('rect',{x:26,y:24,width:70,height:112,rx:8,fill:'none',stroke:C.ok,'stroke-width':2.5},g);for(var j=0;j<4;j++)unit(g,160+(j%2)*26,60+Math.floor(j/2)*30);E('rect',{x:146,y:44,width:54,height:60,rx:10,fill:'none',stroke:C.ok,'stroke-width':2.5},g);T(g,280,80,'34 — juft',{'font-size':20,'font-weight':800,fill:C.ok});msg('Demak faqat <b>oxirgi raqamga</b> qarash kifoya: 4 — juft, demak 34 ham juft')}];
var P5=[function(){line2(22,38,false);msg('23 dan <b>katta</b>, 37 dan <b>kichik</b> juft sonlar nechta?')},
 function(){line2(22,38,true);msg('Juftlar yashil. Chegaralar: 23 va 37 — ikkalasi ham kirmaydi')},
 function(){line2(22,38,true);var X=S.X;[24,26,28,30,32,34,36].forEach(function(v,i){T(S.g,X(v),140,String(i+1),{'font-size':13,'font-weight':800,fill:C.blue})});msg('24, 26, 28, 30, 32, 34, 36 — <b>7 ta</b>')}];
var STEPS=[
{h:"Juftlab ko'ramiz",sum:"Narsalarni juft-juft qo'yamiz: hammasi juftlansa — juft son, bittasi ortib qolsa — toq son.",a:"m01",
 start:function(){pairs(6)},fin:function(){pairs(7)},
 html:"<p>Poyabzal, qo'lqop, paypoq — juft-juft bo'ladi. Sonlarni ham shunday tekshiramiz: narsalarni <b>ikkitadan</b> juftlaymiz. Tugmalarni bosib ko'ring:</p>",
 btns:[["6 ta",function(c,done){pairs(6);mvK(done,3)}],["7 ta",function(c,done){pairs(7);mvK(done,3)}],["8 ta",function(c,done){pairs(8);mvK(done,3)}],["9 ta",function(c,done){pairs(9);mvK(done,3)}]],g2:1,
 after:"<p>6 va 8 — hammasi juftlandi: bular <b>juft sonlar</b>. 7 va 9 — bittasi juftsiz qoldi: bular <b>toq sonlar</b>.</p><p>Boshqacha aytganda: juft sonni <b>2 ta teng bo'lakka</b> bo'lib bo'ladi, toq sonni — yo'q.</p>",
 q:{t:"13 ta olma bor. Ikki do'st teng bo'lishib olsa, olma ortib qoladimi?",opts:["Yo'q, hammasi teng bo'linadi","Ha, 1 ta ortib qoladi","Ha, 3 ta ortib qoladi","Ha, 2 ta ortib qoladi"],ok:1,why:"13 — toq son: 6 juftlik va 1 ta ortiqcha.",hint:"13 ni juft-juft qo'yib ko'ring: 2, 4, 6, … nechta ortib qoladi?",full:"13 ni juftlasak: 6 ta juftlik (12 ta) va 1 ta ortib qoladi. Shuning uchun 13 toq. Har bir do'stga 6 tadan tegadi, 1 ta qoladi."},
 tn:"Juft/toqni «juftlash» orqali kiritish — Montessori va Singapur darsliklarining usuli. Bolalarga qopqoq yoki tugma berib, juft-juft terdiring."},
{h:"Juft va toq raqamlar",sum:"Juft raqamlar: 0, 2, 4, 6, 8. Toq raqamlar: 1, 3, 5, 7, 9. Nol — juft.",a:"m02",
 start:function(){pairs(0,{nomsg:1});msg('Raqamlarni bosing')},fin:function(){digs(true)},
 html:"<p>Bir xonali sonlarni tekshiramiz. Har bir raqamni bosing — u juftmi yoki toq?</p><div class='a4d' style='display:flex;flex-wrap:wrap;gap:6px;margin:8px 0'></div>",
 act:function(c,done){var box=c.querySelector('.a4d'),seen={};box.innerHTML='';for(var d=0;d<=9;d++)(function(d){var b=document.createElement('button');b.textContent=d;b.style.cssText='width:42px;height:42px;border:1px solid #dde5ee;border-radius:10px;background:#fff;font-size:18px;font-weight:700';b.onclick=function(){if(d===0){clear();T(S.g,180,80,'0 ta — juftlab bo‘ladi,',{'font-size':16,'font-weight':800,fill:C.ok});T(S.g,180,106,'hech narsa ortib qolmaydi',{'font-size':16,'font-weight':800,fill:C.ok});msg('<b>0 — juft</b> son: 0 ni 2 ga teng bo‘lsak, har biriga 0 tegadi, ortiqcha yo‘q')}else pairs(d);b.style.background=d%2?'#fff1e0':'#e6f6ee';b.style.color=d%2?'#b0601f':'#1e8e5a';seen[d]=1;if(Object.keys(seen).length>=5&&!st['a'+cur])done()};box.appendChild(b)})(d)},
 after:"<p><b>Juft raqamlar: 0, 2, 4, 6, 8.</b> <b>Toq raqamlar: 1, 3, 5, 7, 9.</b> Ular navbatma-navbat keladi: juft, toq, juft, toq…</p><p>Diqqat: <b>0 — juft</b>! 0 ta narsada ortiqcha narsa qolmaydi.</p>",
 q:{t:"Qaysi qatorda faqat juft raqamlar?",opts:["1, 3, 5","0, 4, 8","2, 5, 6","3, 6, 9"],ok:1,why:"0, 4, 8 — uchalasi ham juftlanadi.",hint:"Har bir raqamni juftlab ko'ring. 0 ni unutmang — u juft.",full:"Juft raqamlar: 0, 2, 4, 6, 8. «0, 4, 8» — hammasi juft. Qolgan qatorlarda toq raqamlar bor: 1, 3, 5, 9."},
 tn:"Ko'p bola 0 ni «hech qanday» deb o'ylaydi. «0 ta konfetni ikki kishi teng bo'ladimi? — Ha, har biriga 0 ta» deb tushuntiring."},
{h:"Katta sonlar: faqat oxirgi raqamga qarang",sum:"O'nliklar doim juftlanadi, shuning uchun sonning juft-toqligini oxirgi raqam hal qiladi: 34 — juft, 57 — toq.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>34 ta narsani bittalab juftlash uzoq. Oson yo'li bor — kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>Har bir o'nlik — 10 ta, ya'ni <b>5 ta juftlik</b>. O'nliklar hech qachon ortiqcha qoldirmaydi. Shuning uchun sonning juft yoki toqligini <b>faqat oxirgi raqam</b> (birliklar) hal qiladi.</p><p>58 — 8 juft → juft. 73 — 3 toq → toq. 100 — 0 juft → juft.</p>",
 q:{t:"Qaysi son juft?",opts:["57","73","86","91"],ok:2,why:"86 ning oxirgi raqami 6 — juft.",hint:"Faqat oxirgi raqamga qarang: qaysi biri 0, 2, 4, 6 yoki 8 bilan tugaydi?",full:"Oxirgi raqamlar: 57 → 7 (toq), 73 → 3 (toq), 86 → 6 (juft), 91 → 1 (toq). Javob: 86. Birinchi raqam (8) muhim emas."},
 tn:"Bolalar ko'pincha birinchi raqamga qaraydi (86 — «8 juft, demak juft»; 85 da ham xuddi shunday deydi). Ikkala sonni yonma-yon solishtiring."},
{h:"Son o'qida: navbatma-navbat",sum:"Son o'qida juft va toq sonlar navbatma-navbat keladi. 30 dan 50 gacha 10 ta toq son bor.",a:"m04",
 start:function(){line2(20,40,false);msg('Tugmani bosing — juftlar yashilga bo‘yaladi')},fin:function(){line2(20,40,true);msg('Juft, toq, juft, toq… — navbatma-navbat')},
 html:"<p>Son o'qida 20 dan 40 gacha sonlar. Juft sonlarni bo'yaymiz:</p>",
 btns:[["🎨 Juftlarni bo'yash",function(c,done,b){b.disabled=true;line2(20,40,true);msg('Juft, toq, juft, toq… — navbatma-navbat. Har ikkinchi son juft');done()}]],
 after:"<p>Juft va toq sonlar <b>navbatma-navbat</b> keladi: har bir juft sonning ikkala qo'shnisi toq, toq sonning qo'shnilari juft. Ko'chalarda uy raqamlari ham shunday: bir tomonda juft, ikkinchi tomonda toq.</p>",
 q:{t:"30 dan 50 gacha bo'lgan sonlar orasida nechta toq son bor?",opts:["20","9","10","11"],ok:2,why:"31, 33, … 49 — har o'nlikda 5 ta toq: 5 + 5 = 10.",hint:"Har bir o'nlikda (30 dan 39 gacha) nechta toq son bor?",full:"30–39 da toq: 31, 33, 35, 37, 39 — 5 ta. 40–49 da: 41, 43, 45, 47, 49 — 5 ta. 50 juft. Jami 10 ta. «20» — barcha sonlar soni, ularning yarmi toq."},
 tn:"Ko'chada uy raqamlarini kuzatishni uyga vazifa qilib bering: qaysi tomonda juft, qaysi tomonda toq?"},
{h:"Tuzoq: oraliqdagi juftlar soni",sum:"23 dan katta va 37 dan kichik juftlar: 24, 26, … 36 — 7 ta. Chegaralarni tekshirish shart.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Testlarda shunday keladi: «23 dan katta, lekin 37 dan kichik juft sonlar nechta?» Shoshilsangiz, 14 yoki 6 deb yuborasiz. Kuzating.</p>",
 btns:[phaser(P5)],
 after:"<p>Usul: <b>birinchi</b> mos juftni toping (24), <b>oxirgisini</b> toping (36) va sanang: 24, 26, 28, 30, 32, 34, 36 — <b>7 ta</b>. Chegaralar (23 va 37) toq, ular baribir kirmaydi.</p>",
 q:{t:"45 dan katta, lekin 52 dan kichik juft sonlar nechta?",opts:["3","4","7","6"],ok:0,why:"46, 48, 50 — 3 ta (52 kirmaydi).",hint:"Birinchi mos juft son qaysi? Oxirgisi-chi? 52 kiradimi?",full:"45 dan katta birinchi juft — 46. 52 dan kichik oxirgi juft — 50 (52 ning o'zi kirmaydi). 46, 48, 50 — 3 ta."},
 tn:"«Dan katta» va «dan kichik» chegarani o'z ichiga olmasligini doim ta'kidlang. Son o'qida chegarani qizil bilan belgilang."},
{h:"Yig'indi juftmi yoki toqmi?",sum:"Toq + toq = juft, juft + juft = juft, juft + toq = toq. Ortib qolganlar juftlashadi.",a:"m06",
 start:function(){sum2(null)},fin:function(){sum2('tt')},
 html:"<p>Ikki sonni qo'shsak, natija juft bo'ladimi yoki toq? Har birini bosib ko'ring:</p>",
 btns:[["toq + toq",function(c,done){sum2('tt');S.s6=S.s6||{};S.s6.tt=1;if(Object.keys(S.s6).length===3)done()}],["juft + toq",function(c,done){sum2('jt');S.s6=S.s6||{};S.s6.jt=1;if(Object.keys(S.s6).length===3)done()}],["juft + juft",function(c,done){sum2('jj');S.s6=S.s6||{};S.s6.jj=1;if(Object.keys(S.s6).length===3)done()}]],
 after:"<p>Ikki toq sonda ham bittadan juftsiz qolgan edi — qo'shilganda ular <b>bir-biri bilan juftlashadi</b>: toq + toq = <b>juft</b>. Juft + toq da bitta ortiqcha qoladi — <b>toq</b>.</p>",
 q:{t:"Uchta toq sonning yig'indisi qanday son bo'ladi?",opts:["Har doim juft","Har doim toq","Ba'zan juft, ba'zan toq","Har doim 3 ga teng"],ok:1,why:"Toq + toq = juft, juft + toq = toq.",hint:"Avval ikkitasini qo'shing (toq + toq = ?), keyin uchinchisini.",full:"Birinchi ikkitasi: toq + toq = juft. Unga uchinchi toqni qo'shamiz: juft + toq = toq. Masalan: 1 + 3 + 5 = 9 — toq."},
 tn:"Bu — isbotning birinchi qadami: bolalar bitta misol emas, «har doim» haqida o'ylaydi. Bir nechta misol bilan tekshirib ko'rsin."},
{h:"Algoritm: juft bo'lsa — bir yo'l, toq bo'lsa — boshqa",sum:"Juft son 2 ga bo'linadi, toq songa 12 qo'shiladi: 18 → 9, 13 → 25; yig'indisi 34.",a:"m07",
 start:function(){algo(null)},fin:function(){algo(13)},
 html:"<p>Mashina sonni oladi: son <b>juft</b> bo'lsa — uni <b>2 ga bo'ladi</b>, <b>toq</b> bo'lsa — unga <b>12 qo'shadi</b>. Sonlarni mashinaga bering:</p>",
 btns:[["18",function(c,done){algo(18);S.a7=S.a7||{};S.a7[18]=1;if(S.a7[13])done()}],["13",function(c,done){algo(13);S.a7=S.a7||{};S.a7[13]=1;if(S.a7[18])done()}],["40",function(c){algo(40)}],["7",function(c){algo(7)}]],g2:1,
 after:"<p>18 — juft → 18 : 2 = <b>9</b>. 13 — toq → 13 + 12 = <b>25</b>. Natijalar yig'indisi: 9 + 25 = <b>34</b>. Avval doim <b>juft-toqligini</b> aniqlaymiz, keyin amalni tanlaymiz.</p>",
 q:{t:"Lolaning yoshi juft son, Alining yoshi toq son. Yoshlari yig'indisi 17. Qaysi javob mos keladi?",opts:["Lola 6, Ali 10","Lola 8, Ali 9","Lola 9, Ali 8","Lola 7, Ali 10"],ok:1,why:"8 — juft, 9 — toq, 8 + 9 = 17.",hint:"Uchta shartni tekshiring: Lola juft, Ali toq, yig'indi 17.",full:"«Lola 6, Ali 10»: yig'indi 16. «Lola 9, Ali 8»: Lola toq — mos emas. «Lola 7, Ali 10»: ikkalasi ham noto'g'ri. «Lola 8, Ali 9»: 8 juft, 9 toq, 8 + 9 = 17 ✓."},
 tn:"Algoritmlar — kelajak matematikasi. Bolalarga «son mashinasi» o'yinini o'ynating: biri son aytadi, boshqasi qoidani bajaradi."},
{h:"Bilasizmi?",sum:"2500 yil oldin yunon olimlari juft va toq sonlarni o'rgangan; Evklid ularning xossalarini isbotlagan.",a:"m08",
 start:function(){street()},fin:function(){street()},
 html:"<p>🏛 Bundan 2500 yil oldin qadimgi yunon olimlari sonlarni <b>juft</b> va <b>toqqa</b> ajratib o'rganishgan. Olim <b>Evklid</b> o'zining mashhur «Negizlar» kitobida «toq + toq = juft» kabi qoidalarni <b>isbotlab</b> bergan — siz ham hozir shuni o'zingiz topdingiz!</p><p>🏠 Bugun ham ko'pchilik shaharlarda ko'chaning bir tomonidagi uylar <b>juft</b>, ikkinchi tomoni <b>toq</b> raqamlanadi. Pochtachi bu qoida bilan uyni tez topadi.</p>",
 tn:"Bolalardan o'z uy raqami juft yoki toq ekanini so'rang va ko'chaning qaysi tomonida turishini aniqlating."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){pairs(7)},fin:function(){pairs(7)},
 html:"<div class='memo'><ul><li><b>Juft</b> son — juft-juft qilib bo'linadi (2 ta teng bo'lakka). <b>Toq</b> son — 1 ta ortib qoladi.</li><li>Juft raqamlar: <b>0, 2, 4, 6, 8</b>. Toq: <b>1, 3, 5, 7, 9</b>. 0 — juft!</li><li>Katta sonda faqat <b>oxirgi raqamga</b> qarang: 86 — juft, 57 — toq.</li><li>Son o'qida juft va toq <b>navbatma-navbat</b> keladi; har o'nlikda 5 ta juft, 5 ta toq.</li><li>Toq + toq = <b>juft</b>; juft + juft = <b>juft</b>; juft + toq = <b>toq</b>.</li><li>Oraliqdagi juftlarni sanashda <b>birinchi</b> va <b>oxirgisini</b> toping, chegaralarni tekshiring.</li></ul></div>",
 tn:"Keyingi darsni «1 dan 20 gacha juft sonlar yig'indisi nechaga teng?» (110) savoli bilan boshlang."}
];
function digs(){clear();for(var d=0;d<=9;d++){var x=24+d*35,ev=d%2===0;E('rect',{x:x-14,y:60,width:28,height:40,rx:8,fill:ev?'#e6f6ee':'#fff1e0',stroke:ev?C.ok:C.a},S.g);T(S.g,x,88,String(d),{'font-size':20,'font-weight':800,fill:ev?C.ok:'#b0601f'})}msg('Juft: 0, 2, 4, 6, 8 · Toq: 1, 3, 5, 7, 9')}
function sum2(k){clear();var g=S.g;if(!k){msg('Tugmalardan birini bosing');T(g,180,90,'toq + toq = ?',{'font-size':22,'font-weight':800,fill:'#9aa8b6'});return}
 var a=k==='jj'?4:(k==='jt'?4:3),b=k==='jj'?6:5,tot=a+b;
 function grp(n,x0,col){for(var i=0;i<n;i++){var cx=x0+Math.floor(i/2)*22,cy=56+(i%2)*30;E('circle',{cx:cx,cy:cy,r:8,fill:(n%2&&i===n-1)?C.bad:col,stroke:'#fff','stroke-width':2},g)}}
 grp(a,30,C.b);T(g,30+Math.ceil(a/2)*22,76,'+',{'font-size':22,'font-weight':800});grp(b,60+Math.ceil(a/2)*22,C.c);
 var res=tot%2===0;T(g,180,140,a+' + '+b+' = '+tot+'  →  '+(res?'JUFT':'TOQ'),{'font-size':18,'font-weight':800,fill:res?C.ok:C.bad});
 msg(k==='tt'?'Ikkala toqdagi <b style="color:#d94b4b">qizil</b> ortiqchalar bir-biri bilan juftlashadi → <b>juft</b>':(k==='jt'?'Bitta qizil ortiqcha juftsiz qoladi → <b>toq</b>':'Hech qanday ortiqcha yo‘q → <b>juft</b>'))}
function algo(n){clear();var g=S.g;E('rect',{x:110,y:40,width:140,height:80,rx:14,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2},g);T(g,180,70,'juft → : 2',{'font-size':15,'font-weight':800,fill:C.ok});T(g,180,96,'toq → + 12',{'font-size':15,'font-weight':800,fill:'#b0601f'});
 if(n==null){msg('Sonni tanlang');return}var ev=n%2===0,r=ev?n/2:n+12;T(g,60,86,String(n),{'font-size':26,'font-weight':800,fill:'#1d2b3a'});T(g,92,86,'→',{'font-size':22});T(g,270,86,'→',{'font-size':22});T(g,310,86,String(r),{'font-size':26,'font-weight':800,fill:ev?C.ok:'#b0601f'});
 msg(n+' — '+(ev?'juft, demak '+n+' : 2 = <b>'+r+'</b>':'toq, demak '+n+' + 12 = <b>'+r+'</b>'))}
function street(){clear();var g=S.g;E('rect',{x:10,y:76,width:340,height:22,fill:'#c9d3dd'},g);T(g,180,92,'ko‘cha',{'font-size':11,fill:'#5b6b7b'});
 for(var i=0;i<5;i++){var x=40+i*70;E('path',{d:'M'+(x-20)+' 66 L'+(x-20)+' 40 L'+x+' 24 L'+(x+20)+' 40 L'+(x+20)+' 66 Z',fill:'#e6f6ee',stroke:C.ok},g);T(g,x,58,String(2+i*2),{'font-size':13,'font-weight':800,fill:C.ok});
  E('path',{d:'M'+(x-20)+' 108 L'+(x-20)+' 134 L'+x+' 150 L'+(x+20)+' 134 L'+(x+20)+' 108 Z',fill:'#fff1e0',stroke:C.a},g);T(g,x,128,String(1+i*2),{'font-size':13,'font-weight':800,fill:'#b0601f'})}
 msg('Bir tomonda juft, ikkinchi tomonda toq raqamlar')}
var PROBS=[
{t:"Qaysi son toq?",o:["47","58","90","36"],k:0,s:"47 ning oxirgi raqami 7 — toq."},
{t:"23, 36, 41, 58, 67, 74, 90 sonlari orasida nechtasi juft?",o:["4","3","5","7"],k:0,s:"Juftlar: 36, 58, 74, 90 — 4 ta."},
{t:"Eng kichik juft ikki xonali son qaysi?",o:["10","12","11","20"],k:0,s:"10 — ikki xonali, oxirgi raqami 0 (juft)."},
{t:"Eng katta toq ikki xonali son qaysi?",o:["99","98","97","89"],k:0,s:"99 — oxirgi raqami 9, toq."},
{t:"23 dan katta, lekin 37 dan kichik bo'lgan juft sonlar nechta?",o:["7","6","8","14"],k:0,s:"24, 26, 28, 30, 32, 34, 36 — 7 ta."},
{t:"45 dan katta, lekin 92 dan kichik bo'lgan juft sonlar nechta?",o:["23","24","22","46"],k:0,s:"46 dan 90 gacha juftlar: (90 − 46) : 2 + 1 = 23."},
{t:"30 dan 50 gacha bo'lgan sonlar orasida nechta toq son bor?",o:["10","11","9","20"],k:0,s:"31, 33, … 49 — 10 ta."},
{t:"1 dan 25 gacha bo'lgan sonlar orasida nechta juft son bor?",o:["12","13","11","25"],k:0,s:"2, 4, … 24 — 12 ta."},
{t:"Ikkita toq sonning yig'indisi qanday son bo'ladi?",o:["Har doim juft","Har doim toq","Ba'zan juft, ba'zan toq","Har doim 10 dan katta"],k:0,s:"Ortiqcha birliklar juftlashadi: toq + toq = juft."},
{t:"Juft son bilan toq sonning yig'indisi qanday son bo'ladi?",o:["Har doim toq","Har doim juft","Ba'zan juft, ba'zan toq","Har doim 10 dan katta"],k:0,s:"Bitta ortiqcha qoladi: juft + toq = toq."},
{t:"Uchta toq sonning yig'indisi qanday son bo'ladi?",o:["Har doim toq","Har doim juft","Ba'zan juft, ba'zan toq","Har doim 3 ga teng"],k:0,s:"Toq + toq = juft, juft + toq = toq."},
{t:"50 dan kichik eng katta toq son bilan 20 dan katta eng kichik juft sonning ayirmasini toping.",o:["27","28","25","29"],k:0,s:"49 − 22 = 27."},
{t:"Son juft bo'lsa 2 ga bo'linadi, toq bo'lsa unga 12 qo'shiladi. 18 va 13 uchun natijalar yig'indisi?",o:["34","43","31","22"],k:0,s:"18 : 2 = 9, 13 + 12 = 25. 9 + 25 = 34."},
{t:"Lolaning yoshi juft, Alining yoshi toq son. Yoshlari yig'indisi 17. Qaysi javob mos?",o:["Lola 8, Ali 9","Lola 6, Ali 10","Lola 9, Ali 8","Lola 7, Ali 10"],k:0,s:"8 — juft, 9 — toq, 8 + 9 = 17."},
{t:"1 dan 20 gacha bo'lgan barcha juft sonlarning yig'indisi?",o:["110","100","120","90"],k:0,s:"2 + 4 + … + 20: juftlab qo'shamiz (2 + 20) + (4 + 18) + … — 5 ta 22 = 110."},
{t:"Ketma-ket kelgan 5 ta juft sonning yig'indisi 60. Eng kichigi qaysi?",o:["8","10","12","6"],k:0,s:"O'rtadagisi 60 : 5 = 12: 8, 10, 12, 14, 16. Eng kichigi 8."},
{t:"6 ta juft va 5 ta toq son qo'shildi. Yig'indi qanday son?",o:["Toq","Juft","Aytib bo'lmaydi, sonlarga bog'liq","Har doim 11"],k:0,s:"Juftlar yig'indisi juft. 5 ta toq: 2 juftlik + 1 ta toq → toq. Juft + toq = toq."},
{t:"Ko'chada uylar 1, 3, 5, … (bir tomon) raqamlangan. 9-uy shu tomondagi nechanchi uy?",o:["5-uy","9-uy","4-uy","6-uy"],k:0,s:"1, 3, 5, 7, 9 — beshinchisi."},
{t:"40 dan katta va 45 dan kichik juft sonlar yig'indisi nechaga teng?",o:["86","84","42","129"],k:0,s:"Juftlar: 42 va 44. 42 + 44 = 86."},
{t:"Qaysi sondan oldingi ham, keyingi ham son juft?",o:["37","40","52","88"],k:0,s:"Toq sonning qo'shnilari juft: 36 va 38."}
];
function PRACT_STAGE(){line2(20,40,true);msg('Kerak bo‘lsa, son o‘qiga qarang')}
var PREP_DATA={teach:["Juft va toq son: juftlash orqali (2 ta teng bo'lakka bo'linadi / 1 ta ortadi).","Juft va toq raqamlar; 0 — juft.","Katta sonlarda oxirgi raqam qoidasi.","Son o'qida navbatma-navbat; oraliqdagi juft/toqlarni sanash; yig'indining juft-toqligi."],
 mist:["Birinchi raqamga qarab aniqlaydi (85 — «8 juft, demak juft»).","0 ni toq yoki «hech qanday» deb hisoblaydi.","Oraliqdagi juftlarni sanashda chegaralarni qo'shadi yoki hammasini sanab, ikkiga bo'lmaydi.","Toq + toq = toq deb o'ylaydi."],
 need:["20–30 ta qopqoq yoki tugma.","Son o'qi (doskada 20–40)."],
 board:["Juftlash rasmlari: 6 (●● ●● ●●) va 7 (●● ●● ●● ●).","<span class='w2'>Juft: 0 2 4 6 8 · Toq: 1 3 5 7 9</span>.","<span class='w2'>34 → 4 juft → juft</span>.","Son o'qida juftlarni bo'yash.","<span class='w2'>toq + toq = juft, juft + toq = toq</span>."]};
