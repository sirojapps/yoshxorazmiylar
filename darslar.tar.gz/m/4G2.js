// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4G2',TITLE='4-sinf · Yuza birliklari: sm², dm², m², ar, gektar';
function g2l1(hi,ar){g4lad(['m²','dm²','sm²','mm²'],[100,100,100],hi,ar,'Yuza birliklari: har qadam ×100')}
function g2l2(hi,ar){g4lad(['km²','ga','a','m²'],[100,100,100],hi,ar,'Yer o‘lchovlari: ar (sotix), gektar')}
// n×n kvadrat, k ta katak bo'yalgan, s — katak
function g2sq(n,k,s,lab,x0,y0){var g=S.g;x0=x0==null?180-n*s/2:x0;y0=y0==null?18:y0;
 for(var i=0;i<n*n;i++){var c=i%n,r=Math.floor(i/n);E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:i<k?C.t2:'#fff',stroke:'#d9b98a','stroke-width':.7},g)}
 E('rect',{x:x0,y:y0,width:n*s,height:n*s,fill:'none',stroke:C.t1,'stroke-width':2},g);
 if(lab){T(g,x0+n*s/2,y0+n*s+14,lab[0],{'font-size':11.5,'font-weight':800,fill:C.bad});T(g,x0-6,y0+n*s/2+4,lab[1],{'font-size':11.5,'font-weight':800,fill:C.blue,'text-anchor':'end'})}}
var P1=[function(){clear();g2sq(10,0,13,['1 dm = 10 sm','1 dm']);g4m('Tomoni 1 dm bo‘lgan kvadrat — <b>1 dm²</b>. Ichida nechta 1 sm² bor?')},
 function(){clear();g2sq(10,10,13,['1 dm = 10 sm','1 dm']);g4m('Bitta qatorda <b>10 ta</b> 1 sm² li katak')},
 function(){clear();g2sq(10,100,13,['1 dm = 10 sm','1 dm']);g4m('10 qator × 10 ta = <b>100 sm²</b>.  1 dm² = 100 sm²')}];
function g2field(w,h,lw,lh,txt){clear();var g=S.g,s=Math.min(250/w,120/h),W=w*s,H=h*s,x0=180-W/2,y0=22;E('rect',{x:x0,y:y0,width:W,height:H,fill:'#d6efc7',stroke:'#3d8b3d','stroke-width':2},g);
 for(var i=1;i<6;i++)E('line',{x1:x0+i*W/6,y1:y0+4,x2:x0+i*W/6,y2:y0+H-4,stroke:'#9fd08a','stroke-width':1},g);
 T(g,180,y0+H+15,lw,{'font-size':12,'font-weight':800,fill:C.bad});T(g,x0-6,y0+H/2+4,lh,{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});if(txt)T(g,180,y0+H/2+5,txt,{'font-size':14,'font-weight':800,fill:'#1d4d1d'})}
var P5=[function(){g2field(50,40,'50 m','40 m','Bog‘');calc(['Bog‘ning yuzi necha ar?'])},
 function(){g2field(50,40,'50 m','40 m','2000 m²');calc(['Yuz = bo‘yi · eni = 50 · 40 = <b>2000 m²</b>'])},
 function(){g2field(50,40,'50 m','40 m','20 a');calc(['50 · 40 = 2000 m²','1 a = 100 m²  →  2000 : 100 = <b>20 a</b> (20 sotix)'])}];
var P8=[function(){g2field(200,100,'200 m','100 m','Dala: 2 ga');calc(['Har 1 ar dan 40 kg kartoshka olindi. Jami necha tonna?'])},
 function(){g2field(200,100,'200 m','100 m','2 ga = 200 a');calc(['1 ga = 100 a  →  2 ga = <b>200 a</b>'])},
 function(){g2field(200,100,'200 m','100 m','8 t');calc(['200 · 40 = 8000 kg','8000 kg = <b>8 t</b>'])}];
function g2ga(k){clear();var g=S.g;if(k===0){E('rect',{x:140,y:30,width:80,height:80,fill:'#d6efc7',stroke:'#3d8b3d','stroke-width':2},g);T(g,180,74,'1 a',{'font-size':18,'font-weight':800,fill:'#1d4d1d'});T(g,180,126,'10 m',{'font-size':12,'font-weight':800,fill:C.bad});T(g,134,74,'10 m',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});return}
 var n=10,s=12,x0=120,y0=16;for(var i=0;i<100;i++)E('rect',{x:x0+(i%n)*s,y:y0+Math.floor(i/n)*s,width:s,height:s,fill:k===1?(i===0?C.hi:'#d6efc7'):'#bfe0ae',stroke:'#3d8b3d','stroke-width':.5},g);
 E('rect',{x:x0,y:y0,width:120,height:120,fill:'none',stroke:'#3d8b3d','stroke-width':2},g);T(g,180,152,k===1?'1 ga = 100 m × 100 m':'1 km² = 1000 m × 1000 m',{'font-size':12,'font-weight':800,fill:C.bad});T(g,110,80,k===1?'100 m':'1 km',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 T(g,300,60,k===1?'har katak':'har katak',{'font-size':11,'font-weight':700,fill:'#3a4a5a'});T(g,300,78,k===1?'= 1 a':'= 1 ga',{'font-size':14,'font-weight':800,fill:C.a2})}
function g2grow(n){clear();g2sq(n,n*n,26,[n+' sm',n+' sm'],180-n*13,22);g4m('Tomoni '+n+' sm → yuzi '+n+' · '+n+' = <b>'+(n*n)+' sm²</b>')}
var STEPS=[
{h:"1 dm² ichida nechta sm²?",sum:"1 dm = 10 sm, shuning uchun 1 dm² = 10 · 10 = 100 sm².",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Kvadrat santimetr (sm²) — tomoni 1 sm bo'lgan kvadrat. Kvadrat detsimetrni sm² larga «bo'lib» chiqamiz:</p>",
 btns:[phaser(P1,'▶ Kataklarni to‘ldirish')],
 after:"<p>Tomoni 10 marta katta bo'lsa, yuzi <b>10 · 10 = 100</b> marta katta. Shuning uchun yuza birliklari orasida ko'paytuvchi <b>100</b>, uzunlikdagidek 10 emas.</p>",
 q:{t:"1 dm = 10 sm. 1 dm² necha sm²?",opts:["10 sm²","20 sm²","100 sm²","40 sm²"],ok:2,why:"10 qator × 10 ta = 100 sm².",hint:"Kvadratda nechta qator va har qatorda nechta katak?",full:"1 dm² kvadratning har tomoniga 10 ta santimetr sig'adi: 10 qator, har birida 10 ta katak — 100 sm². «10» — faqat bitta qator, «40» — perimetr (4 · 10)."},
 tn:"Katakli daftarda 10 × 10 sm kvadrat chizdiring va 1 sm² li kataklarni sanattiring (100). Gazetadan 1 m² kesib, yerga qo'ying — bolalar uning ichiga nechtasi sig'ishini ko'rsin."},
{h:"Yuza birliklari zinapoyasi",sum:"m² ×100 dm² ×100 sm² ×100 mm². 1 m² = 10 000 sm² (100 emas!).",a:"m02",
 start:function(){g2l1([]);g4m('Tugmalarni bosing')},fin:function(){g2l1([0,2],[0,2]);g4m('1 m² = 100 · 100 = 10 000 sm²')},
 html:"<p>Har bir qadamda ×100. Bir necha qadam yursak — ko'paytuvchilar ko'paytiriladi. Bosing:</p>",
 btns:[["m² → dm²",function(c,done){g2l1([0,1],[0,1]);g4m('1 m = 10 dm → 1 m² = 10 · 10 = <b>100 dm²</b>');mvK(done,3)}],["m² → sm²",function(c,done){g2l1([0,2],[0,2]);g4m('1 m = 100 sm → 1 m² = 100 · 100 = <b>10 000 sm²</b>');mvK(done,3)}],["sm² → mm²",function(c,done){g2l1([2,3],[2,3]);g4m('1 sm = 10 mm → 1 sm² = <b>100 mm²</b>');mvK(done,3)}]],g3:1,
 after:"<p><b>Tuzoq:</b> 1 m = 100 sm, lekin <b>1 m² = 10 000 sm²</b>. Chunki kvadratning ikkala tomoni ham 100 sm: 100 · 100.</p>",
 q:{t:"1 m² necha sm²?",opts:["100 sm²","1000 sm²","10 000 sm²","200 sm²"],ok:2,why:"100 sm · 100 sm = 10 000 sm².",hint:"1 m² kvadratning tomoni necha sm?",full:"1 m² — tomoni 1 m = 100 sm bo'lgan kvadrat. Yuzi 100 · 100 = 10 000 sm². «100» — uzunlik birligi bilan aralashtirish (1 m = 100 sm), «1000» — uzunlik zinapoyasidagi m → mm."},
 tn:"Ikki zinapoyani yonma-yon yozing: uzunlik (×10) va yuza (×100). Bolalar farqni o'zi aytsin."},
{h:"Ar va gektar — yer o'lchovlari",sum:"1 a = 10 m × 10 m = 100 m² (sotix). 1 ga = 100 m × 100 m = 10 000 m² = 100 a. 1 km² = 100 ga.",a:"m03",
 start:function(){g2ga(0);g4m('Tugmalarni bosing')},fin:function(){g2ga(1);g4m('1 ga = 100 a = 10 000 m²')},
 html:"<p>Yer, dala, bog' yuzini kvadrat metrda o'lchash noqulay — sonlar juda katta bo'lib ketadi. Shuning uchun maxsus birliklar bor:</p>",
 btns:[["1 ar",function(c,done){g2ga(0);g4m('1 ar = 10 m · 10 m = <b>100 m²</b>. Xalq tilida — <b>1 sotix</b>');mvK(done,3)}],["1 gektar",function(c,done){g2ga(1);g4m('1 ga = 100 m · 100 m = <b>10 000 m²</b> = <b>100 a</b>');mvK(done,3)}],["1 km²",function(c,done){g2ga(2);g4m('1 km² = 1000 m · 1000 m = <b>100 ga</b>');mvK(done,3)}]],g3:1,
 after:"<p>Zinapoya: <b>km² ×100 ga ×100 a ×100 m²</b>. Qishloqda «tomorqa 6 sotix» deyishadi — bu 6 a = 600 m².</p>",
 q:{t:"3 ga necha ar?",opts:["30 a","3000 a","300 a","30 000 a"],ok:2,why:"1 ga = 100 a; 3 · 100 = 300 a.",hint:"1 gektarda nechta ar bor?",full:"1 ga = 100 a, demak 3 ga = 300 a. «30 000» — bu m² dagi javob (3 · 10 000), «30» — ×10 deb o'ylash."},
 tn:"Maktab hovlisida 10 m × 10 m kvadratni arqon bilan belgilang — bu 1 ar. Bolalar uning ichida turib, «sotix» qancha ekanini his qilsin."},
{h:"Tuzoq: almashtirishda nollar",sum:"5 m² 7 dm² = 507 dm². 1 m² = 100 dm² bo'lgani uchun dm² ga 2 ta xona.",a:"m04",
 start:function(){g2l1([0,1],[0,1]);g4m('<b>5 m² 7 dm²</b> = ? dm². To‘g‘risini bosing')},fin:function(){g2l1([0,1],[0,1]);g4m('5 m² 7 dm² = 500 + 7 = <b>507 dm²</b>')},
 html:"<p><b>5 m² 7 dm²</b> ni kvadrat detsimetrda yozing:</p>",
 btns:[["57 dm²",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 5 m² = 500 dm², 5 emas');setTimeout(function(){b.style.background=''},1600)}],["507 dm²",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g4m('To‘g‘ri! 5 · 100 + 7 = <b>507 dm²</b>');done()}],["5007 dm²",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 1 m² = 100 dm² (1000 emas) — dm² ga 2 ta xona');setTimeout(function(){b.style.background=''},1600)}],["57 000 dm²",function(c,done,b){b.style.background='#fde2e2';g4m('❌ Bu 570 m² ga teng — juda katta');setTimeout(function(){b.style.background=''},1600)}]],g2:1,
 after:"<p>Kichik birlik uchun nechta xona ajratiladi? <b>Ko'paytuvchi 100</b> bo'lsa — 2 ta xona: 5 m² 7 dm² = 5<b>07</b> dm². <b>10 000</b> bo'lsa — 4 ta xona: 3 m² 5 sm² = 3<b>0005</b> sm².</p>",
 q:{t:"2 ga 5 a necha ar?",opts:["25 a","205 a","2005 a","250 a"],ok:1,why:"2 ga = 200 a; 200 + 5 = 205 a.",hint:"1 ga = 100 a — arlarga nechta xona?",full:"2 ga = 200 a, plyus 5 a = 205 a. «25» — nolni tushirish, «2005» — 1 ga = 1000 a deb o'ylash, «250» — 5 ni 50 deb yozish."},
 tn:"Xonalar jadvali: [m² | dm² o'nlik | dm² birlik]. Bo'sh katakka 0 yozdiring."},
{h:"Bog' yuzini arda topish",sum:"50 m × 40 m = 2000 m² = 20 a.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bog'ning bo'yi 50 m, eni 40 m. Uning yuzi necha ar (sotix)?</p>",
 btns:[phaser(P5)],
 after:"<p>Avval yuzni <b>m²</b> da topamiz, keyin <b>100 ga bo'lib</b> arga, <b>10 000 ga bo'lib</b> gektarga o'tamiz.</p>",
 q:{t:"Dala 400 m × 250 m. Necha gektar?",opts:["1 ga","100 ga","10 ga","1000 ga"],ok:2,why:"400 · 250 = 100 000 m²; 100 000 : 10 000 = 10 ga.",hint:"Avval m² da toping. 1 ga = 10 000 m².",full:"Yuz 400 · 250 = 100 000 m². 1 ga = 10 000 m², demak 100 000 : 10 000 = 10 ga. «1000 ga» — arga aylantirilgan (1000 a), «100 ga» — 1000 ga bo'lingan."},
 tn:"Haqiqiy hayotiy son bering: maktab yer maydoni hujjatda necha gektar ekanini direktordan bilib keling."},
{h:"Taqqoslash",sum:"3 ga = 30 000 m² > 29 000 m². Avval bitta birlikka keltiramiz.",a:"m06",
 start:function(){g2l2([1,3],[1,3]);g4m('Qaysi yer katta: <b>3 ga</b> yoki <b>29 000 m²</b>?')},fin:function(){g2l2([1,3],[1,3]);g4m('3 ga = 30 000 m² > 29 000 m²')},
 html:"<p>Ikki fermer yeri: birinchisi <b>3 ga</b>, ikkinchisi <b>29 000 m²</b>. Kimning yeri katta?</p>",
 btns:[["3 ga katta",function(c,done,b){b.style.background=C.ok;b.style.color='#fff';g4m('To‘g‘ri! 3 ga = 3 · 10 000 = <b>30 000 m²</b> > 29 000 m²');done()}],["29 000 m² katta",function(c,done,b){b.style.background='#fde2e2';g4m('❌ Son katta ko‘rinadi, lekin 3 ga = 30 000 m²');setTimeout(function(){b.style.background=''},1600)}],["Teng",function(c,done,b){b.style.background='#fde2e2';g4m('❌ 1 ga = 10 000 m², hisoblab ko‘ring');setTimeout(function(){b.style.background=''},1600)}]],
 after:"<p>Katta son har doim katta yuz emas — <b>birligiga</b> qarang. 3 ga = 30 000 m², bu 29 000 m² dan 1000 m² (10 sotix) ko'p.</p>",
 q:{t:"Qaysi kichik: 5 a yoki 600 m²?",opts:["5 a","600 m²","Teng"],ok:0,why:"5 a = 500 m² < 600 m².",hint:"1 a = 100 m².",full:"5 a = 5 · 100 = 500 m², bu 600 m² dan kichik. «Teng» deganlar 1 a = 120 m² deb o'ylashgan yoki taxmin qilishgan."},
 tn:"«Kim katta?» o'yini: juft-juft kartochkalar (2 ga — 190 a, 7 dm² — 700 sm²...)."},
{h:"Tuzoq: tomon 2 marta — yuz 4 marta",sum:"Tomoni 1, 2, 3 sm kvadratlar yuzi: 1, 4, 9 sm². Tomon 2 marta oshsa yuz 4 marta oshadi.",a:"m07",
 start:function(){g2grow(1)},fin:function(){g2grow(3)},
 html:"<p>Kvadrat tomonini oshirib ko'ring. Yuz qanday o'zgaradi?</p>",
 btns:[["Tomon 1 sm",function(c,done){g2grow(1);mvK(done,3)}],["Tomon 2 sm",function(c,done){g2grow(2);mvK(done,3)}],["Tomon 3 sm",function(c,done){g2grow(3);mvK(done,3)}]],g3:1,
 after:"<p>Tomon <b>2 marta</b> oshsa — yuz <b>2 · 2 = 4</b> marta, <b>3 marta</b> oshsa — <b>3 · 3 = 9</b> marta oshadi. Shuning uchun ham 1 m² = 100 dm²: tomon 10 marta, yuz 100 marta.</p>",
 q:{t:"Kvadrat tomoni 3 marta oshirildi. Yuzi necha marta oshdi?",opts:["3 marta","6 marta","9 marta","12 marta"],ok:2,why:"3 · 3 = 9 marta.",hint:"Tomoni 1 sm va 3 sm bo'lgan kvadratlar yuzini solishtiring.",full:"Tomon 1 → yuz 1; tomon 3 → yuz 9. 9 : 1 = 9 marta. «3 marta» — perimetr shunday o'zgaradi, yuz emas."},
 tn:"Bolalar 1, 2, 3 sm li kvadratlarni qog'ozdan kesib, kichigini kattasining ustiga necha marta qo'yish mumkinligini sanasin."},
{h:"Masala: hosildorlik",sum:"2 ga = 200 a; 200 · 40 kg = 8000 kg = 8 t.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p><i>«2 ga dalaning har aridan 40 kg kartoshka yig'ildi. Jami necha tonna kartoshka olindi?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Masalada gektar berilgan, hosil esa <b>har ar</b> uchun. Avval bir xil birlikka (arga) o'tamiz, keyin ko'paytiramiz va javobni tonnaga aylantiramiz.</p>",
 q:{t:"Tomorqa 6 a. Har 1 m² ga 3 ta piyoz ko'chati ekildi. Nechta ko'chat?",opts:["18","180","600","1800"],ok:3,why:"6 a = 600 m²; 600 · 3 = 1800.",hint:"Avval arni m² ga aylantiring.",full:"6 a = 600 m². Har m² ga 3 ta: 600 · 3 = 1800 ta. «18» — arni m² ga aylantirmay ko'paytirish, «600» — faqat m² lar soni."},
 tn:"Dehqonchilik hayotidan misollar oling: paxta hosildorligi «sentner/gektar» bilan aytiladi."},
{h:"Bilasizmi? Gektar va futbol maydoni",sum:"«Gekto» — yuz degani: gektar = 100 ar. Futbol maydoni 105 m × 68 m ≈ 71 a.",a:"m09",
 start:function(){g2field(105,68,'105 m','68 m','⚽ ≈ 71 a');g4m('105 · 68 = 7140 m² ≈ 71 a')},fin:function(){g2field(105,68,'105 m','68 m','⚽ ≈ 71 a');g4m('105 · 68 = 7140 m² ≈ 71 a')},
 html:"<p>📜 «Ar» so'zi lotincha <i>area</i> — «maydon» so'zidan. «Gekto» yunoncha «yuz» degani: <b>gektar = 100 ar</b>.</p><p>⚽ Xalqaro o'yinlar uchun futbol maydoni ko'pincha 105 m × 68 m bo'ladi: 7140 m² — taxminan <b>71 sotix</b>, ya'ni gektardan biroz kichik.</p>",
 tn:"Bolalarga savol: «1 gektar nechta futbol maydoniga teng?» (taxminan 1 tadan sal ko'proq — 10 000 > 7140)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g2l1([0,2],[0,2]);g4m('m² ×100 dm² ×100 sm² ×100 mm²')},fin:function(){g2l1([0,2],[0,2]);g4m('m² ×100 dm² ×100 sm² ×100 mm²')},
 html:"<div class='memo'><ul><li>Yuza birliklari orasida ko'paytuvchi <b>100</b>: 1 m² = 100 dm², 1 dm² = 100 sm², 1 sm² = 100 mm².</li><li><b>1 m² = 10 000 sm²</b> (100 emas!).</li><li><b>1 a = 100 m²</b> (sotix), <b>1 ga = 100 a = 10 000 m²</b>, <b>1 km² = 100 ga</b>.</li><li>Bo'sh xonaga 0: 5 m² 7 dm² = 507 dm², 2 ga 5 a = 205 a.</li><li>Yuzni avval m² da toping, keyin arga (: 100) yoki gektarga (: 10 000).</li><li>Tomon 2 marta oshsa — yuz 4 marta, 3 marta oshsa — 9 marta.</li></ul></div>",
 tn:"Uyga vazifa: xonangiz polining yuzini m² da toping va necha dm² ekanini yozing."}
];
var PROBS=[
{t:"1 dm² necha sm²?",o:["100 sm²","10 sm²","1000 sm²","10 000 sm²"],k:0,s:"10 · 10 = 100 sm²."},
{t:"1 m² necha sm²?",o:["10 000 sm²","100 sm²","1000 sm²","100 000 sm²"],k:0,s:"100 · 100 = 10 000 sm²."},
{t:"7 a necha m²?",o:["700 m²","70 m²","7000 m²","70 000 m²"],k:0,s:"1 a = 100 m²; 7 · 100 = 700 m²."},
{t:"1 ga necha m²?",o:["10 000 m²","1000 m²","100 m²","100 000 m²"],k:0,s:"100 m · 100 m = 10 000 m²."},
{t:"4 ga necha ar?",o:["400 a","40 a","4000 a","40 000 a"],k:0,s:"1 ga = 100 a; 4 · 100 = 400 a."},
{t:"3 m² 8 dm² necha dm²?",o:["308 dm²","38 dm²","380 dm²","3008 dm²"],k:0,s:"300 + 8 = 308 dm²."},
{t:"2500 sm² ni dm² da yozing.",o:["25 dm²","250 dm²","2 dm² 50 sm²","25 m²"],k:0,s:"2500 : 100 = 25 dm²."},
{t:"Xona 6 m × 4 m. Polining yuzi?",o:["24 m²","20 m²","10 m²","240 m²"],k:0,s:"6 · 4 = 24 m²."},
{t:"Bog' 50 m × 30 m. Necha ar?",o:["15 a","150 a","1500 a","160 a"],k:0,s:"50 · 30 = 1500 m²; 1500 : 100 = 15 a."},
{t:"Kvadrat perimetri 36 sm. Yuzi?",o:["81 sm²","36 sm²","324 sm²","18 sm²"],k:0,s:"Tomon 36 : 4 = 9 sm; 9 · 9 = 81 sm²."},
{t:"Qaysi katta: 2 ga yoki 190 a?",o:["2 ga","190 a","Teng"],k:0,s:"2 ga = 200 a > 190 a."},
{t:"Kvadrat tomoni 2 marta oshirildi. Yuzi necha marta oshdi?",o:["4 marta","2 marta","8 marta","6 marta"],k:0,s:"2 · 2 = 4 marta."},
{t:"To'g'ri to'rtburchak yuzi 48 m², eni 6 m. Bo'yi?",o:["8 m","42 m","24 m","12 m"],k:0,s:"48 : 6 = 8 m."},
{t:"2 ga dalaning har aridan 40 kg hosil olindi. Jami?",o:["8 t","80 kg","800 kg","80 t"],k:0,s:"2 ga = 200 a; 200 · 40 = 8000 kg = 8 t."},
{t:"Tomorqa 6 a. Har 1 m² ga 3 ko'chat ekildi. Nechta ko'chat?",o:["1800","18","180","600"],k:0,s:"6 a = 600 m²; 600 · 3 = 1800."},
{t:"1 km² necha gektar?",o:["100 ga","1000 ga","10 ga","10 000 ga"],k:0,s:"1 km² = 1000 m · 1000 m = 1 000 000 m² = 100 ga."},
{t:"Pol 5 m × 4 m. Plitka 50 sm × 50 sm. Nechta plitka kerak?",o:["80","8","800","40"],k:0,s:"Bo'yiga 500 : 50 = 10, eniga 400 : 50 = 8; 10 · 8 = 80 ta."},
{t:"3 m² 5 sm² necha sm²?",o:["30 005 sm²","35 sm²","305 sm²","3005 sm²"],k:0,s:"3 m² = 30 000 sm²; 30 000 + 5 = 30 005 sm²."},
{t:"Dala 400 m × 250 m. Necha gektar?",o:["10 ga","100 ga","1 ga","1000 ga"],k:0,s:"400 · 250 = 100 000 m²; 100 000 : 10 000 = 10 ga."},
{t:"Kvadrat shaklidagi yer yuzi 1 ga. Uning tomoni?",o:["100 m","10 m","1000 m","25 m"],k:0,s:"1 ga = 100 m · 100 m, tomoni 100 m."}
];
function PRACT_STAGE(){g2l2([]);g4m('km² ×100 ga ×100 a ×100 m² ×100 dm² ×100 sm²')}
var PREP_DATA={teach:["1 dm² = 100 sm² — kataklar bilan.","Yuza birliklari zinapoyasi (×100), 1 m² = 10 000 sm².","Ar (sotix), gektar, km² — yer o'lchovlari.","Almashtirish, taqqoslash, masalalar (hosildorlik, plitka)."],
 mist:["1 m² = 100 sm² deb o'ylaydi (uzunlik bilan aralashtiradi).","5 m² 7 dm² = 57 dm² (nolni tushiradi).","Yuz va perimetrni aralashtiradi.","Tomon 2 marta → yuz ham 2 marta deydi."],
 need:["Katakli qog'oz, 1 dm² li kvadrat kartochkalar.","Gazetadan 1 m² kvadrat.","Arqon va qoziqlar (1 ar belgilash uchun)."],
 board:["<span class='w2'>1 dm² = 100 sm²</span>, <span class='w2'>1 m² = 10 000 sm²</span>.","<span class='w2'>km² ×100 ga ×100 a ×100 m²</span>.","<span class='w2'>5 m² 7 dm² = 507 dm²</span>.","<span class='w2'>50 · 40 = 2000 m² = 20 a</span>.","Tomon ×2 → yuz ×4."]};
