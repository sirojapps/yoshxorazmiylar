var CODE='3J19',TITLE='3-sinf · Rost-yolg‘on va mantiqiy xulosa';
// gaplar jadvali: rows [[kim, gap, rost?|null]]
function j19Say(rows,o){o=o||{};clear();var g=S.g;if(o.t)T(g,180,20,o.t,{'font-size':12,'font-weight':800,fill:o.tc||'#33475b'});
 rows.forEach(function(r,i){var y=(o.y0||34)+i*36;E('rect',{x:14,y:y,width:332,height:30,rx:8,fill:r[2]==null?'#fff':(r[2]?'#e3f6ea':'#fde6e6'),stroke:r[2]==null?'#d8e0ea':(r[2]?C.ok:C.bad),'stroke-width':1.6},g);
  T(g,22,y+20,r[0]+':',{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#2a64a8'});T(g,92,y+20,'«'+r[1]+'»',{'font-size':12,'font-weight':700,'text-anchor':'start'});
  if(r[2]!=null)T(g,328,y+21,r[2]?'✓':'✗',{'font-size':16,'font-weight':800,fill:r[2]?C.ok:C.bad})});
 if(o.b)T(g,180,(o.y0||34)+rows.length*36+16,o.b,{'font-size':12,'font-weight':800,fill:o.bc||'#33475b'})}
var J19S=[['Sardor','Jasur sindirdi'],['Jasur','Sardor yolg‘on gapiryapti'],['Bekzod','Men sindirmadim']];
function j19Hyp(k){var v=[k===1,k!==1,k!==2],n=v.filter(Boolean).length;j19Say(J19S.map(function(r,i){return [r[0],r[1],v[i]]}),{t:'Faraz: '+J19S[k][0]+' sindirgan',b:'rost gaplar: '+n+(n===1?' ✓ shartga mos':' — shart: faqat 1 ta ✗'),bc:n===1?C.ok:C.bad})}
// rostgo'y/yolg'onchi
var P2=[function(){j2Lines([['🏝 Orolda:',null,16],['😇 rostgo‘y — doim rost',C.ok,16],['😈 yolg‘onchi — doim yolg‘on',C.bad,16],['Kim «Men yolg‘onchiman» deya oladi?',C.blue,14]],{dy:30})},
 function(){j2Lines([['😇 desa: «Men yolg‘onchiman»',null,15],['bu yolg‘on bo‘lib qoladi',null,14],['rostgo‘y yolg‘on gapirmaydi ✗',C.bad,15]],{dy:32});j2Msg('Rostgo‘y aytsa — u yolg‘on gapirgan bo‘ladi. Mumkin emas')},
 function(){j2Lines([['😈 desa: «Men yolg‘onchiman»',null,15],['bu ROST bo‘lib qoladi',null,14],['yolg‘onchi rost gapirmaydi ✗',C.bad,15]],{dy:32});j2Msg('Yolg‘onchi aytsa — u rost gapirgan bo‘ladi. Bu ham mumkin emas')},
 function(){j2Lines([['Hech kim ayta olmaydi!',C.ok,24],['«Men rostgo‘yman» — ikkalasi ham deya oladi',null,13]]);j2Msg('Javob: <b>hech kim</b>. Taqqoslang: «Men rostgo‘yman» deb ikkalasi ham aytadi')}];
// jadval usuli
var J19K=['Ali','Vali','Soli'],J19C=['futbol','shaxmat','suzish'];
function j19Table(m,note){clear();var g=S.g,x0=104,y0=28,cw=78,rh=34;J19C.forEach(function(c,j){T(g,x0+j*cw+cw/2,y0-6,c,{'font-size':12,'font-weight':800,fill:'#2a64a8'})});
 J19K.forEach(function(k,i){T(g,x0-10,y0+i*rh+22,k,{'font-size':13,'font-weight':800,'text-anchor':'end'});J19C.forEach(function(c,j){var v=m[i][j];E('rect',{x:x0+j*cw,y:y0+i*rh,width:cw-2,height:rh-2,rx:4,fill:v==='✓'?'#c8f0d8':(v==='✗'?'#fde6e6':'#fff'),stroke:'#c8d3de'},g);if(v)T(g,x0+j*cw+cw/2,y0+i*rh+23,v,{'font-size':17,'font-weight':800,fill:v==='✓'?C.ok:C.bad})})});
 if(note)T(g,180,y0+3*rh+22,note,{'font-size':11,'font-weight':800,fill:'#5b6b7b'})}
var P4=[function(){j19Table([['','',''],['','',''],['','','']],'Ali suzmaydi va shaxmat o‘ynamaydi. Vali shaxmat o‘ynamaydi');j2Msg('Har kim bitta sport bilan shug‘ullanadi, hammasi har xil. Jadval tuzamiz')},
 function(){j19Table([['','✗','✗'],['','✗',''],['','','']],'shartlarni ✗ bilan belgilaymiz');j2Msg('Ali: shaxmat ✗, suzish ✗. Vali: shaxmat ✗')},
 function(){j19Table([['✓','✗','✗'],['✗','✗',''],['✗','','']],'Alida faqat futbol qoldi → ✓; ustundagi qolganlar ✗');j2Msg('Ali — <b>futbol</b>. Demak Vali va Soli futbol emas')},
 function(){j19Table([['✓','✗','✗'],['✗','✗','✓'],['✗','✓','✗']],'Vali — suzish, Soli — shaxmat');j2Msg('Vali uchun faqat suzish qoldi, Soli — <b>shaxmat</b>')}];
// qutilar
var J19B=['Sovg‘a shu qutida','Sovg‘a 1-qutida emas','Sovg‘a 2-qutida emas'];
function j19Boxes(hl,res){clear();var g=S.g;for(var i=0;i<3;i++){var x=14+i*114,sel=hl===i,v=res?[[1,0,1],[0,1,0],[0,1,1]][hl][i]:null;
  E('rect',{x:x,y:30,width:104,height:110,rx:10,fill:sel?(res==='ok'?'#c8f0d8':'#fde6e6'):'#fff7ea',stroke:sel?(res==='ok'?C.ok:C.bad):'#d9b98a','stroke-width':sel?3:1.6},g);
  T(g,x+52,54,'🎁 '+(i+1),{'font-size':16,'font-weight':800});var w=J19B[i].split(' ');T(g,x+52,82,w.slice(0,2).join(' '),{'font-size':11,'font-weight':700});T(g,x+52,98,w.slice(2).join(' '),{'font-size':11,'font-weight':700});
  if(v!=null)T(g,x+52,126,v?'rost ✓':'yolg‘on ✗',{'font-size':12,'font-weight':800,fill:v?C.ok:C.bad});
  var r=E('rect',{x:x,y:30,width:104,height:110,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){j19BoxTap(i)})})(i)}
 T(g,180,162,'Faqat BITTA yozuv rost. Sovg‘a qaysi qutida?',{'font-size':12,'font-weight':800,fill:'#33475b'})}
var J19={};
function j19BoxTap(i){var n=[[1,0,1],[0,1,0],[0,1,1]][i].reduce(function(a,b){return a+b});j19Boxes(i,n===1?'ok':'bad');j2Msg(n===1?'✓ Sovg‘a <b>2-qutida</b>: faqat 2-yozuv rost':'Faraz: '+(i+1)+'-qutida → rost yozuvlar: <b>'+n+'</b> ta. Shart buzildi');if(n===1&&J19.done){var d=J19.done;J19.done=null;d()}}
// zanjir yolg'on
var J19L=[['Ali','Vali yolg‘on gapiryapti'],['Vali','G‘ani yolg‘on gapiryapti'],['G‘ani','Ali ham, Vali ham yolg‘on gapiryapti']];
var P7=[function(){j19Say(J19L.map(function(r){return [r[0],r[1],null]}),{t:'Kim rost gapiryapti?'});j2Msg('Faraz qilib, oxirigacha tekshiramiz')},
 function(){j19Say([[J19L[0][0],J19L[0][1],true],[J19L[1][0],J19L[1][1],false],[J19L[2][0],J19L[2][1],true]],{t:'Faraz: Ali rost',b:'G‘ani rost → «Ali yolg‘on» — lekin Ali rost edi! ✗',bc:C.bad});j2Msg('Ali rost → Vali yolg‘on → G‘ani rost → Ali yolg‘on. <b>Qarama-qarshilik</b>')},
 function(){j19Say([[J19L[0][0],J19L[0][1],false],[J19L[1][0],J19L[1][1],true],[J19L[2][0],J19L[2][1],false]],{t:'Faraz: Ali yolg‘on',b:'Hammasi mos ✓ — faqat Vali rost',bc:C.ok});j2Msg('Ali yolg‘on → Vali rost → G‘ani yolg‘on; G‘ani gapi ham yolg‘on (Vali rost) ✓. Javob: <b>faqat Vali</b>')}];
var STEPS=[
{h:"Kim sindirdi? Faraz qilib tekshiramiz",sum:"Faqat bittasi rost: har bir gumondorni faraz qilib, rost gaplarni sanaymiz — faqat Bekzod mos.",a:"m01",
 start:function(){j19Say(J19S.map(function(r){return [r[0],r[1],null]}),{t:'Derazani bittasi sindirdi. Faqat BITTASI rost gapirdi'});j2Msg('Kim sindirdi? Har bir bolani <b>faraz</b> qilib tekshiring')},
 fin:function(){j19Hyp(2)},
 html:"<p>Mantiqiy masalaning asosiy usuli — <b>faraz qilish</b>: «Agar … sindirgan bo'lsa?» deb, har bir gapning rost-yolg'onligini tekshiramiz. Shartga mos keladigan yagona farazni toping:</p>",
 g3:1,btns:j2Pick(["Sardor","Jasur","Bekzod"],2,function(){j19Hyp(2);j2Msg('✓ Bekzod sindirgan: faqat Jasur rost gapirgan')},function(i){j19Hyp(i);j2Msg('Bu farazda rost gaplar <b>2</b> ta — shart «faqat bittasi» ✗')}),
 after:"<p>Uchala farazni ham tekshirdik: faqat <b>Bekzod</b> farazida bitta gap rost. Muhim: bitta mos farazni topgach ham, qolganlarini tekshirish yaxshi — javob <b>yagona</b> ekaniga ishonch hosil qilamiz.</p>",
 q:{t:"Ali, Vali va G'anidan biri derazani sindirdi. Ali: «Vali sindirdi». Vali: «Men sindirmadim». G'ani: «Men sindirmadim». Faqat bittasi rost gapirgan. Kim sindirgan?",opts:["G'ani","Ali","Vali","Ali yoki Vali"],ok:0,why:"G'ani farazida faqat Valining gapi rost.",hint:"Har birini faraz qilib, rost gaplarni sanang.",full:"Ali sindirgan bo'lsa: Vali va G'ani rost (2 ta) ✗. Vali bo'lsa: Ali va G'ani rost (2 ta) ✗. G'ani bo'lsa: faqat Vali rost (1 ta) ✓."},
 tn:"Doskada 3 ustunli jadval: «faraz», «rost gaplar soni». Bolalar to'ldirsin."},
{h:"Rostgo'ylar va yolg'onchilar oroli",sum:"«Men yolg'onchiman» deb hech kim ayta olmaydi; «Men rostgo'yman» — ikkalasi ham.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Orolda faqat ikki xil odam yashaydi: rostgo'ylar (doim rost) va yolg'onchilar (doim yolg'on). Ikkala holatni tekshiramiz:</p>",
 btns:[phaser(P2,'▶ Tekshirish')],
 after:"<p>Usul: «u rostgo'y bo'lsa?» va «u yolg'onchi bo'lsa?» — ikkalasini oxirigacha tekshiramiz. Qarama-qarshilik chiqqan farazni tashlaymiz.</p>",
 q:{t:"Oroldagi A dedi: «Ikkalamiz (men va B) ham yolg'onchimiz». A va B kim?",opts:["A — yolg'onchi, B — rostgo'y","ikkalasi yolg'onchi","ikkalasi rostgo'y","A — rostgo'y, B — yolg'onchi"],ok:0,why:"A rostgo'y bo'lolmaydi (o'zini yolg'onchi degan bo'ladi). Demak A yolg'onchi, gapi yolg'on — B rostgo'y.",hint:"A rostgo'y bo'lishi mumkinmi? U o'zi haqida nima deyapti?",full:"Agar A rostgo'y bo'lsa, «men yolg'onchiman» qismi rost bo'lib qoladi — mumkin emas. Demak A — yolg'onchi va uning gapi yolg'on: «ikkalamiz yolg'onchi» noto'g'ri, demak B — rostgo'y. «Ikkalasi yolg'onchi» — A ning gapini rost deb olish."},
 tn:"Sinfni ikki guruhga bo'ling: «rostgo'ylar» va «yolg'onchilar». Savollar berib o'ynang — bolalar o'zi qarama-qarshilikni sezadi."},
{h:"Gapni inkor qilish",sum:"«Hamma mushuklar oq» ning inkori — «Kamida bitta mushuk oq emas» (hech biri oq emas — emas!).",a:"m03",
 start:function(){j2Lines([['«Hamma mushuklar oq»',C.blue,22],['Bu gapning INKORI qaysi?',null,15]]);j2Msg('Inkor — gap yolg‘on bo‘lganda <b>doim rost</b> bo‘ladigan gap')},
 fin:function(){j2Lines([['«Hamma mushuklar oq»',C.blue,20],['inkori:',null,14],['«Kamida bitta mushuk oq emas»',C.ok,18]])},
 html:"<p>Gap yolg'on bo'lishi uchun nima yetarli? Bitta qora mushuk topilsa — «hamma oq» degan gap yolg'on bo'ladi. Inkorni tanlang:</p>",
 btns:j2Pick(["Kamida bitta mushuk oq emas","Hech bir mushuk oq emas","Hamma mushuklar qora"],0,function(){STEPS[2].fin();j2Msg('✓ «Hamma» ning inkori — «<b>kamida bittasi … emas</b>»')},function(i){j2Msg(i===1?'Ortiqcha! 9 ta oq va 1 ta qora mushuk bo‘lsa — «hamma oq» yolg‘on, lekin «hech biri oq emas» ham yolg‘on':'Qora bo‘lishi shart emas — kulrang ham bo‘lishi mumkin. Va hammasi bo‘lishi ham shart emas')}),
 after:"<p>Juftliklar: «hamma … » ↔ «kamida bittasi … emas»; «kamida bittasi … » ↔ «hech biri … emas». Bu — olimpiadadagi eng ko'p tuzoq.</p>",
 q:{t:"«Kamida bitta o'quvchi kech qoldi» gapining inkori qaysi?",opts:["Hech bir o'quvchi kech qolmadi","Hamma o'quvchi kech qoldi","Kamida bitta o'quvchi kech qolmadi","Faqat bitta o'quvchi kech qoldi"],ok:0,why:"«Kamida bittasi …» ning inkori — «hech biri … emas».",hint:"Qachon «kamida bittasi kech qoldi» yolg'on bo'ladi?",full:"Bu gap faqat bitta holatda yolg'on: hech kim kech qolmasa. Demak inkor: «Hech bir o'quvchi kech qolmadi». «Kamida bittasi kech qolmadi» — u bilan bir vaqtda rost bo'lishi mumkin, inkor emas."},
 tn:"Bolalar o'zlari «hamma …» gaplarni aytib, sherigi inkorini topsin. Misol bilan tekshiring: inkor va asl gap bir vaqtda rost bo'la olmaydi."},
{h:"Jadval usuli",sum:"Ali, Vali, Soli — futbol, shaxmat, suzish: jadvalda ✗ belgilab, Ali — futbol, Vali — suzish, Soli — shaxmat.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Ko'p shartli masalalarda <b>jadval</b> eng ishonchli yordamchi: mumkin emasini ✗, aniqini ✓ bilan belgilaymiz. Har qatorda va ustunda faqat bitta ✓.</p>",
 btns:[phaser(P4,'▶ Keyingi')],
 after:"<p>Kalit: ✓ qo'yilgach, uning <b>qatori va ustunidagi</b> qolgan kataklarga darhol ✗ qo'yamiz. Bu yangi xulosalar ochadi.</p>",
 q:{t:"Malika, Nodira va Oyshaning ko'ylaklari qizil, ko'k va yashil (har xil). Malika qizil kiymagan. Nodira qizil ham, ko'k ham kiymagan. Kim qanday ko'ylakda?",opts:["Malika — ko'k, Nodira — yashil, Oysha — qizil","Malika — yashil, Nodira — ko'k, Oysha — qizil","Malika — ko'k, Nodira — qizil, Oysha — yashil","Malika — qizil, Nodira — yashil, Oysha — ko'k"],ok:0,why:"Nodira — yashil; Malika qizil emas, yashil band → ko'k; Oysha — qizil.",hint:"Avval eng ko'p ma'lumot berilgan qizni toping — Nodira.",full:"Nodira qizil ham, ko'k ham emas → yashil. Malika qizil emas, yashil band → ko'k. Oyshaga qizil qoladi."},
 tn:"Doskada 3×3 jadval chizib, bolalar navbat bilan ✗ va ✓ qo'ysin."},
{h:"Qaysi qutida sovg'a?",sum:"Faqat bitta yozuv rost: har qutini faraz qilib tekshiramiz — sovg'a 2-qutida.",a:"m05",
 start:function(){j19Boxes(-1);j2Msg('Qutini bosing — farazni tekshiramiz')},fin:function(){j19Boxes(1,'ok');j2Msg('✓ Sovg‘a 2-qutida')},
 html:"<p>Uchta qutidan bittasida sovg'a bor. Har qutida yozuv bor, faqat <b>bittasi rost</b>. Qutini bosing: o'sha farazda nechta yozuv rost bo'lishini ko'ring.</p>",
 act:function(c,done){c.querySelector('.hint').textContent='Har qutini bosib ko‘rish mumkin — faqat bitta faraz shartga mos.';J19.done=done},
 after:"<p>1-quti farazi: 1 va 3 yozuv rost (2 ta) ✗. 3-quti farazi: 2 va 3 rost ✗. 2-quti: faqat «1-qutida emas» rost ✓.</p>",
 q:{t:"Uch qutidan birida tanga bor. 1: «Tanga 2-qutida». 2: «Tanga shu qutida emas». 3: «Tanga shu qutida». Faqat bitta yozuv yolg'on. Tanga qayerda?",opts:["3-qutida","2-qutida","1-qutida","hech birida"],ok:0,why:"3-quti farazida faqat 1-yozuv yolg'on.",hint:"Bu safar shart — bitta YOLG'ON. Har farazda yolg'onlarni sanang.",full:"1-qutida: 1 va 3 yolg'on (2 ta) ✗. 2-qutida: 2 va 3 yolg'on ✗. 3-qutida: faqat 1 yolg'on ✓. Shartni diqqat bilan o'qing: «bitta rost» va «bitta yolg'on» — har xil masalalar!"},
 tn:"Uchta haqiqiy quti va konfet bilan sahnalashtiring: bolalar yozuvlarni o'qib, qaror qabul qilsin."},
{h:"Tuzoq: «agar … bo'lsa»",sum:"«Yomg'ir yog'sa — yo'l ho'l». Yo'l ho'l → yomg'ir aniq emas; yo'l quruq → yomg'ir yog'magan.",a:"m06",
 start:function(){j2Lines([['Agar yomg‘ir yog‘sa, yo‘l ho‘l bo‘ladi.',C.blue,15],['Yo‘l ho‘l.',null,18],['Demak…?',C.bad,18]])},
 fin:function(){j2Lines([['Yo‘l ho‘l → yomg‘ir? aniq emas',C.bad,16],['Yo‘l quruq → yomg‘ir yog‘magan ✓',C.ok,16]])},
 html:"<p>«Agar A bo'lsa, B bo'ladi» — bu gap <b>teskari</b> yo'nalishda ishlamaydi! Xulosani tanlang:</p>",
 btns:j2Pick(["Yomg'ir yog'gani aniq emas","Demak, yomg'ir yog'gan","Demak, yomg'ir yog'magan"],0,function(){STEPS[5].fin();j2Msg('✓ Yo‘lni suv sepuvchi mashina ham ho‘llagan bo‘lishi mumkin!')},function(i){j2Msg(i===1?'Shoshildingiz: yo‘lni boshqa narsa ham ho‘llashi mumkin (suv sepuvchi mashina 🚿)':'Bunga ham asos yo‘q: yo‘l ho‘l — yomg‘ir yog‘gan bo‘lishi ham mumkin')}),
 after:"<p>To'g'ri xulosa faqat ikki xil: A rost → B rost; B yolg'on → A yolg'on. «Yo'l <b>quruq</b> — demak yomg'ir yog'magan» — bu to'g'ri xulosa.</p>",
 q:{t:"Hamma olimpiadachilar matematikani yaxshi ko'radi. Ali matematikani yaxshi ko'radi. Qaysi xulosa to'g'ri?",opts:["Ali olimpiadachi ekani aniq emas","Ali — olimpiadachi","Ali olimpiadachi emas","Hamma matematika sevuvchilar olimpiadachi"],ok:0,why:"Matematikani sevuvchilar orasida olimpiadachi bo'lmaganlar ham bor bo'lishi mumkin.",hint:"Gap «olimpiadachi → matematika sevadi» yo'nalishida. Teskarisi rostmi?",full:"Gap faqat olimpiadachilar haqida. Matematikani sevuvchilar ko'p — ularning hammasi olimpiadachi emas. Shuning uchun Ali haqida aniq xulosa yo'q."},
 tn:"Hayotiy misollar: «Mushuk bo'lsa — to'rt oyoqli». To'rt oyoqli hayvon — albatta mushukmi? Bolalar o'zlari misol topsin."},
{h:"Tuzoq: yolg'on zanjiri",sum:"Ali: «Vali yolg'on», Vali: «G'ani yolg'on», G'ani: «Ali ham, Vali ham yolg'on» → faqat Vali rost.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Gaplar bir-biriga bog'langan: biri haqida bilsak, zanjir bo'ylab hammasini bilamiz. Bitta farazdan boshlab, oxirigacha yuring:</p>",
 btns:[phaser(P7,'▶ Faraz')],
 after:"<p>Faqat <b>Vali</b> rost gapiryapti. Bunday zanjirlarda bitta faraz qilish kifoya: qarama-qarshilik chiqsa — teskarisi to'g'ri.</p>",
 q:{t:"A: «B yolg'on gapiryapti». B: «A ham, C ham yolg'on gapiryapti». C: «B rost gapiryapti». Kim rost gapiryapti?",opts:["faqat A","faqat B","A va C","faqat C"],ok:0,why:"A rost → B yolg'on → C yolg'on; B ning gapi ham yolg'on (A rost) ✓. A yolg'on farazi qarama-qarshilikka olib keladi.",hint:"A yolg'on deb faraz qiling: unda B rost — B nima deyapti?",full:"A yolg'on bo'lsa, B rost, demak C yolg'on; lekin C «B rost» degan — bu rost bo'lib qoladi ✗. Demak A rost: B yolg'on, C ham yolg'on («B rost» noto'g'ri), B ning «A ham, C ham yolg'on» gapi yolg'on ✓. Javob: faqat A."},
 tn:"Bolalar o'zlari 3 kishilik zanjir tuzsin va sherigiga yechtirsin."},
{h:"Bilasizmi? Mantiq otasi",sum:"Mantiq fanini Aristotel asoslagan; «Barcha kritliklar yolg'onchi» — Epimenid paradoksi.",a:"m08",
 start:function(){j2Lines([['«Barcha kritliklar',null,20],['yolg‘onchi»',null,20],['— dedi kritlik Epimenid',C.blue,15]])},fin:function(){j2Lines([['«Barcha kritliklar',null,20],['yolg‘onchi»',null,20],['— dedi kritlik Epimenid',C.blue,15]])},
 html:"<p>🏛 Qadimgi yunon olimi <b>Aristotel</b> (miloddan avvalgi IV asr) to'g'ri fikrlash qoidalarini birinchi bo'lib tizimga solgan — u <b>mantiq</b> fanining asoschisi hisoblanadi. Qadimdan mashhur jumboq ham bor: Krit orolidan bo'lgan <b>Epimenid</b> «Barcha kritliklar yolg'onchi» degan. Bu gap o'zi haqida ham!</p>",
 btns:[["Tushundim",function(c,done){j2Msg('Epimenid rost gapirgan bo‘lsa — u ham yolg‘onchi bo‘lib qoladi. Bunday gaplar <b>paradoks</b> deyiladi');done()}]],
 after:"<p>Bugun mantiq kompyuterlarning asosi: har bir protsessor milliardlab «rost/yolg'on» (1/0) amallarini bajaradi.</p>",
 tn:"Bolalarga «Men hozir yolg'on gapiryapman» gapini muhokama qildiring — bu gap rostmi yoki yolg'onmi?"},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){j19Table([['✓','✗','✗'],['✗','✗','✓'],['✗','✓','✗']])},fin:function(){j19Table([['✓','✗','✗'],['✗','✗','✓'],['✗','✓','✗']])},
 html:"<div class='memo'><ul><li><b>Faraz qiling</b> va oxirigacha tekshiring; qarama-qarshilik — faraz xato.</li><li>«Faqat bittasi rost» va «faqat bittasi yolg'on» — <b>har xil</b> shart.</li><li>«Men yolg'onchiman» — hech kim ayta olmaydi.</li><li>Inkor: «hamma» ↔ «kamida bittasi … emas»; «kamida bittasi» ↔ «hech biri … emas».</li><li>«Agar A — B» teskari ishlamaydi: B rost → A aniq emas.</li><li>Ko'p shartli masalaga — <b>jadval</b>.</li></ul></div>",
 tn:"Uyga: oila a'zolari bilan bitta «kim yolg'on gapiryapti?» o'yinini o'ynab kelish."}
];
var PROBS=[
{t:"Orolda faqat rostgo'ylar (doim rost) va yolg'onchilar (doim yolg'on) yashaydi. Kim «Men yolg'onchiman» deb ayta oladi?",o:["hech kim ayta olmaydi","faqat rostgo'y","faqat yolg'onchi","ikkalasi ham"],k:0,s:"Rostgo'y aytsa — yolg'on, yolg'onchi aytsa — rost bo'lib qoladi."},
{t:"Shu orolda kim «Men rostgo'yman» deb ayta oladi?",o:["ikkalasi ham","faqat rostgo'y","faqat yolg'onchi","hech kim"],k:0,s:"Rostgo'y uchun rost, yolg'onchi uchun yolg'on — ikkalasi ham aytadi."},
{t:"Oroldagi A dedi: «Ikkalamiz (men va B) ham yolg'onchimiz». A va B kim?",o:["A — yolg'onchi, B — rostgo'y","ikkalasi yolg'onchi","ikkalasi rostgo'y","A — rostgo'y, B — yolg'onchi"],k:0,s:"A rostgo'y bo'lolmaydi; A yolg'onchi va gapi yolg'on → B rostgo'y."},
{t:"Oroldagi A: «B — yolg'onchi». B: «Ikkalamiz bir xilmiz». A va B kim?",o:["A — rostgo'y, B — yolg'onchi","A — yolg'onchi, B — rostgo'y","ikkalasi rostgo'y","ikkalasi yolg'onchi"],k:0,s:"A rost bo'lsa B yolg'on, B ning gapi yolg'on (ular har xil) ✓. A yolg'on bo'lsa B rost, lekin ular har xil — B ning gapi yolg'on ✗."},
{t:"Ali: «Vali yolg'on gapiryapti». Vali: «G'ani yolg'on gapiryapti». G'ani: «Ali ham, Vali ham yolg'on gapiryapti». Kim rost gapiryapti?",o:["faqat Vali","faqat G'ani","Ali va G'ani","faqat Ali"],k:0,s:"Ali rost faraz → qarama-qarshilik. Ali yolg'on → Vali rost → G'ani yolg'on ✓."},
{t:"Ali, Vali va G'anidan biri derazani sindirdi. Ali: «Vali sindirdi». Vali: «Men sindirmadim». G'ani: «Men sindirmadim». Faqat bittasi rost gapirgan. Kim sindirgan?",o:["G'ani","Ali","Vali","Ali yoki Vali"],k:0,s:"G'ani farazida faqat Vali rost."},
{t:"Sardor: «Jasur sindirdi». Jasur: «Sardor yolg'on gapiryapti». Bekzod: «Men sindirmadim». Faqat bittasi rost. Kim sindirgan?",o:["Bekzod","Sardor","Jasur","aniq bitta odam emas"],k:0,s:"Sardor yoki Jasur farazida 2 ta rost gap; Bekzod farazida faqat Jasur rost."},
{t:"A, B, C, D dan biri kalitni yashirdi. A: «B yashirdi». B: «D yashirdi». C: «Men yashirmadim». D: «B yolg'on gapiryapti». Faqat bittasi rost. Kim yashirgan?",o:["C","A","B","D"],k:0,s:"C farazida faqat D rost. Boshqa farazlarda 2–3 ta rost gap."},
{t:"«Hamma mushuklar oq» gapining inkori qaysi?",o:["Kamida bitta mushuk oq emas","Hech bir mushuk oq emas","Hamma mushuklar qora","Ba'zi mushuklar oq"],k:0,s:"«Hamma» ning inkori — «kamida bittasi … emas»."},
{t:"«Kamida bitta o'quvchi kech qoldi» gapining inkori qaysi?",o:["Hech bir o'quvchi kech qolmadi","Hamma o'quvchi kech qoldi","Kamida bitta o'quvchi kech qolmadi","Faqat bitta o'quvchi kech qoldi"],k:0,s:"«Kamida bittasi» ning inkori — «hech biri … emas»."},
{t:"Uch qutidan birida sovg'a. 1: «Sovg'a shu qutida». 2: «Sovg'a 1-qutida emas». 3: «Sovg'a 2-qutida emas». Faqat bitta yozuv rost. Sovg'a qayerda?",o:["2-qutida","1-qutida","3-qutida","hech birida"],k:0,s:"2-quti farazida faqat 2-yozuv rost."},
{t:"Uch qutidan birida tanga. 1: «Tanga 2-qutida». 2: «Tanga shu qutida emas». 3: «Tanga shu qutida». Faqat bitta yozuv yolg'on. Tanga qayerda?",o:["3-qutida","2-qutida","1-qutida","hech birida"],k:0,s:"3-quti farazida faqat 1-yozuv yolg'on."},
{t:"Ali, Vali, Soli — futbol, shaxmat, suzish (har xil). Ali suzmaydi va shaxmat o'ynamaydi. Vali shaxmat o'ynamaydi. Soli nima bilan shug'ullanadi?",o:["shaxmat","futbol","suzish","futbol yoki suzish"],k:0,s:"Ali — futbol, Vali — suzish, Soli — shaxmat."},
{t:"Anvar, Bobur, Doniyor, Eldor — futbol, shaxmat, suzish, kurash (har xil). Doniyor — kurashchi. Bobur futbol ham, shaxmat ham o'ynamaydi. Anvar shaxmat o'ynamaydi. Eldor nima bilan shug'ullanadi?",o:["shaxmat","futbol","suzish","kurash"],k:0,s:"Bobur — suzish, Anvar — futbol, Eldor — shaxmat."},
{t:"Malika, Nodira, Oysha ko'ylaklari qizil, ko'k, yashil (har xil). Malika qizil kiymagan. Nodira qizil ham, ko'k ham kiymagan. Kim qanday ko'ylakda?",o:["Malika — ko'k, Nodira — yashil, Oysha — qizil","Malika — yashil, Nodira — ko'k, Oysha — qizil","Malika — ko'k, Nodira — qizil, Oysha — yashil","Malika — qizil, Nodira — yashil, Oysha — ko'k"],k:0,s:"Nodira — yashil, Malika — ko'k, Oysha — qizil."},
{t:"«Agar yomg'ir yog'sa, yo'l ho'l bo'ladi». Yo'l quruq. Qaysi xulosa to'g'ri?",o:["Yomg'ir yog'magan","Yomg'ir yog'gan","Yo'l ho'l","Ertaga yomg'ir yog'adi"],k:0,s:"Yomg'ir yog'sa, yo'l ho'l bo'lar edi."},
{t:"«Agar yomg'ir yog'sa, yo'l ho'l bo'ladi». Yo'l ho'l. Qaysi xulosa to'g'ri?",o:["Yomg'ir yog'gani aniq emas","Yomg'ir yog'gan","Yomg'ir yog'magan","Yo'l quruq"],k:0,s:"Yo'lni boshqa narsa ho'llagan bo'lishi mumkin."},
{t:"Ba'zi o'quvchilar shaxmatchi. Hamma shaxmatchilar sabrli. Qaysi xulosa albatta to'g'ri?",o:["Ba'zi o'quvchilar sabrli","Hamma o'quvchilar sabrli","Hech bir o'quvchi sabrli emas","Hamma sabrlilar shaxmatchi"],k:0,s:"Shaxmatchi o'quvchilar sabrli — demak ba'zi o'quvchilar sabrli."},
{t:"Ali Validan katta. Vali G'anidan katta. Soli Alidan katta. Eng kichigi kim?",o:["G'ani","Vali","Ali","Soli"],k:0,s:"Soli > Ali > Vali > G'ani."},
{t:"A B dan baland. C A dan baland. D C dan past, lekin A dan baland. Eng balandi kim?",o:["C","D","A","B"],k:0,s:"C > D > A > B."}
];
function PRACT_STAGE(){j2Lines([['😇 rost · 😈 yolg‘on',C.blue,22],['faraz qiling va tekshiring',null,14]])}
var PREP_DATA={teach:["Faraz qilish va qarama-qarshilik orqali isbot.","Rostgo'ylar va yolg'onchilar masalalari.","Gapning inkori: «hamma», «kamida bittasi», «hech biri».","Jadval usuli.","«Agar … bo'lsa» xulosalari; teskari xulosa tuzog'i."],
 mist:["Birinchi mos farazni topib, qolganlarini tekshirmaydi.","«Bitta rost» va «bitta yolg'on» shartlarini chalkashtiradi.","«Hamma oq» inkorini «hech biri oq emas» deb oladi.","«Yo'l ho'l → yomg'ir yog'gan» deb xulosa qiladi."],
 need:["Uchta quti va sovg'a.","Doskada jadval.","Kartochkalar: 😇 / 😈."],
 board:["<span class='w2'>Faraz → tekshir → qarama-qarshilik?</span>.","<span class='w2'>«Men yolg'onchiman» — hech kim</span>.","<span class='w2'>hamma ↔ kamida bittasi … emas</span>.","<span class='w2'>Ali — futbol, Vali — suzish, Soli — shaxmat</span>.","<span class='w2'>Yo'l ho'l ⇏ yomg'ir</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
