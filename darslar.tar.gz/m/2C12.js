// --- k2c12_ yordamchilari ---
function k2c12_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c12_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c12_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c12_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C12',TITLE='2-sinf · Ko‘paytirish va bo‘lishga oid tenglamalar';
function k2c12_model(n,txt,total,cap,fill){clear();k2c12_bars(56,n,txt,{fill:fill});Br(40,320,52,total,true);if(cap)T(S.g,180,130,cap,{'font-size':14,'font-weight':800,fill:C.ok})}
var P1=[function(){k2c12_model(4,['x','x','x','x'],'28');k2c12_big('x · 4 = 28','4 ta teng quti, har birida x ta — jami 28')},
 function(){k2c12_model(4,['?','?','?','?'],'28','bitta quti = 28 : 4');k2c12_big('x = 28 : 4','Butunni qutilar soniga bo‘lamiz')},
 function(){k2c12_model(4,['7','7','7','7'],'28','x = 7');k2c12_big('x = 28 : 4 = <b>7</b> &nbsp; Tekshiruv: 7 · 4 = 28 ✓')}];
var P2=[function(){k2c12_model(6,['8','8','8','8','8','8'],'x');k2c12_big('x : 6 = 8','x ni 6 ta teng bo‘lakka bo‘ldik, har biri 8')},
 function(){k2c12_model(6,['8','8','8','8','8','8'],'x = 8 · 6','');k2c12_big('x = 8 · 6 = <b>48</b> &nbsp; Tekshiruv: 48 : 6 = 8 ✓','Butun = bo‘lak · bo‘laklar soni')}];
var P3=[function(){k2c12_model(1,['56'],'56');k2c12_big('56 : x = 7','56 ni nechta teng bo‘lakka bo‘lsak, har biri 7 bo‘ladi?')},
 function(){k2c12_model(8,['7','7','7','7','7','7','7','7'],'56','x = 56 : 7 = 8 bo‘lak');k2c12_big('x = 56 : 7 = <b>8</b> &nbsp; Tekshiruv: 56 : 8 = 7 ✓')}];
var P5=[function(){clear();k2c12_bars(56,8,['x','x','x','x','x','x','x','x'],{w:220});E('rect',{x:262,y:56,width:58,height:34,fill:'#e6f6ee',stroke:C.line,'stroke-width':1.5},S.g);T(S.g,291,78,'15',{'font-size':14,'font-weight':800});Br(40,320,52,'87',true);k2c12_big('8 · x + 15 = 87','8 ta teng quti va yana 15 — jami 87')},
 function(){clear();k2c12_bars(56,8,['x','x','x','x','x','x','x','x'],{w:220});E('rect',{x:262,y:56,width:58,height:34,fill:'#e6f6ee',stroke:C.bad,'stroke-width':2},S.g);T(S.g,291,78,'15',{'font-size':14,'font-weight':800,fill:C.bad});Br(40,260,96,'87 − 15 = 72',false);k2c12_big('8 · x = 87 − 15 = <b>72</b>','Avval ortiqcha 15 ni olib tashlaymiz')},
 function(){clear();k2c12_bars(56,8,['9','9','9','9','9','9','9','9'],{w:220});Br(40,260,96,'72',false);k2c12_big('x = 72 : 8 = <b>9</b> &nbsp; Tekshiruv: 8 · 9 + 15 = 87 ✓')}];
var P7=[function(){k2c12_chain(0);k2c12_big('Natija 6. Orqaga qaytamiz!','Har amalni TESKARISI bilan bekor qilamiz')},function(){k2c12_chain(1);k2c12_big('6 + 2 = 8','«2 ni ayirdi» → orqaga: 2 ni qo‘shamiz')},function(){k2c12_chain(2);k2c12_big('8 · 10 = 80','«10 ga bo‘ldi» → orqaga: 10 ga ko‘paytiramiz')},function(){k2c12_chain(3);k2c12_big('80 + 4 = 84','«4 ni ayirdi» → orqaga: 4 ni qo‘shamiz')},function(){k2c12_chain(4);k2c12_big('84 : 12 = <b>7</b> — o‘ylangan son!','«12 ga ko‘paytirdi» → orqaga: 12 ga bo‘lamiz')}];
function k2c12_chain(k){clear();var g=S.g,ops=['· 12','− 4',': 10','− 2'],back=['84 : 12 = 7','80 + 4 = 84','8 · 10 = 80','6 + 2 = 8'],vals=['?','84','80','8','6'];var known=[k>=4,k>=3,k>=2,k>=1,true];
 for(var i=0;i<5;i++){var x=24+i*78;E('circle',{cx:x,cy:70,r:20,fill:known[i]?(i===0?C.hi:'#e6f6ee'):'#fff',stroke:C.line,'stroke-width':2},g);T(g,x,77,known[i]?(i===0?'7':vals[i]):'?',{'font-size':15,'font-weight':800});if(i<4){T(g,x+39,50,ops[i],{'font-size':12,'font-weight':800,fill:C.blue});E('line',{x1:x+22,y1:62,x2:x+56,y2:62,stroke:C.blue,'stroke-width':1.5},g);E('path',{d:'M'+(x+52)+' 58 L'+(x+56)+' 62 L'+(x+52)+' 66',fill:'none',stroke:C.blue,'stroke-width':1.5},g)}}
 for(var j=0;j<4;j++)if(k>=4-j)T(g,24+j*78+39,112,'↶',{'font-size':16,'font-weight':800,fill:C.bad})}
var STEPS=[
{h:"Noma'lum ko'paytuvchi",sum:"x · 4 = 28 → x = 28 : 4 = 7. Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Tenglama — «yashirin son» topishmog'i. <b>x · 4 = 28</b>: 4 ta teng qutida jami 28 ta. Har birida nechtadan? Chizma bilan yechamiz.</p>",btns:[phaser(P1)],
 after:"<p>Qoida: <b>noma'lum ko'paytuvchini topish uchun ko'paytmani ma'lum ko'paytuvchiga bo'lamiz</b>. Har doim <b>tekshiring</b>: topilgan sonni o'rniga qo'yib ko'ring.</p>",
 q:{t:"x · 6 = 42. x nechaga teng?",opts:["7","36","48","252"],ok:0,why:"42 : 6 = 7.",hint:"Ko'paytmani ma'lum ko'paytuvchiga bo'ling.",full:"x = 42 : 6 = 7. Tekshiruv: 7 · 6 = 42 ✓. «36» — 42 − 6 ayirilgan, «48» — qo'shilgan."},
 tn:"Singapur chizma modeli tenglamani rasmga aylantiradi. Bolalar har tenglama uchun avval «qutilar» chizsin."},
{h:"Noma'lum bo'linuvchi",sum:"x : 6 = 8 → x = 8 · 6 = 48. Bo'linuvchi = bo'linma · bo'luvchi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p><b>x : 6 = 8</b> — qandaydir son 6 ta teng bo'lakka bo'lindi, har bo'lak 8 bo'ldi. Butun qancha edi?</p>",btns:[phaser(P2)],
 after:"<p>Qoida: <b>noma'lum bo'linuvchini topish uchun bo'linmani bo'luvchiga ko'paytiramiz</b>. Bo'lingan narsani qayta yig'amiz.</p>",
 q:{t:"y : 9 = 7. y nechaga teng?",opts:["63","16","2","72"],ok:0,why:"7 · 9 = 63.",hint:"Bo'linmani bo'luvchiga ko'paytiring.",full:"y = 7 · 9 = 63. Tekshiruv: 63 : 9 = 7 ✓. «16» — qo'shilgan, «2» — ayirilgan."},
 tn:"Bolalar «bo'linuvchi — eng katta son, uni bo'laklardan yig'amiz» degan xulosaga o'zlari kelsin."},
{h:"Noma'lum bo'luvchi",sum:"56 : x = 7 → x = 56 : 7 = 8. Bo'luvchi = bo'linuvchi : bo'linma.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p><b>56 : x = 7</b> — 56 ni nechaga bo'lsak, 7 chiqadi? Ya'ni: 56 da nechta 7 bor?</p>",btns:[phaser(P3)],
 after:"<p>Qoida: <b>noma'lum bo'luvchini topish uchun bo'linuvchini bo'linmaga bo'lamiz</b>. 56 da sakkizta 7 bor — x = 8.</p>",
 q:{t:"72 : x = 9. x nechaga teng?",opts:["8","648","63","81"],ok:0,why:"72 : 9 = 8.",hint:"72 da nechta 9 bor?",full:"x = 72 : 9 = 8. Tekshiruv: 72 : 8 = 9 ✓. «648» — ko'paytirib yuborilgan (bu bo'linuvchi qoidasi)."},
 tn:"Uchta qoidani bitta jadvalda yozing va har biriga chizma qo'ying. Eng ko'p chalkashlik — bo'linuvchi va bo'luvchi qoidalari o'rtasida."},
{h:"Qoidani tanlaymiz va tekshiramiz",sum:"Avval qaysi komponent noma'lumligini aniqlaymiz, keyin qoida; oxirida doim tekshiruv.",a:"m04",
 start:function(){k2c12_big('Tenglamani tanlang')},fin:function(){k2c12_big('x : 4 = 9 → x = 36 ✓')},
 html:"<p>Har bir tenglamada avval savol: <b>x — qaysi komponent?</b> Tenglamani tanlang va yechimni ko'ring:</p>",
 btns:[["x · 5 = 45",function(c,d){k2c12_model(5,['9','9','9','9','9'],'45','ko‘paytuvchi → bo‘lamiz');k2c12_big('x = 45 : 5 = <b>9</b> &nbsp; ✓ 9 · 5 = 45');mvK(d,3)}],["x : 4 = 9",function(c,d){k2c12_model(4,['9','9','9','9'],'x','bo‘linuvchi → ko‘paytiramiz');k2c12_big('x = 9 · 4 = <b>36</b> &nbsp; ✓ 36 : 4 = 9');mvK(d,3)}],["32 : x = 4",function(c,d){k2c12_model(8,['4','4','4','4','4','4','4','4'],'32','bo‘luvchi → bo‘lamiz');k2c12_big('x = 32 : 4 = <b>8</b> &nbsp; ✓ 32 : 8 = 4');mvK(d,3)}]],
 after:"<p>Tekshiruv — eng ishonchli yordamchi. Agar topilgan sonni qo'yganda tenglik to'g'ri chiqmasa, qoida noto'g'ri tanlangan.</p>",
 q:{t:"Qaysi tenglamaning yechimi x = 6?",opts:["x · 7 = 42","x : 7 = 42","42 : x = 6","x · 6 = 42"],ok:0,why:"6 · 7 = 42 ✓.",hint:"Har biriga 6 ni qo'yib tekshiring.",full:"6 · 7 = 42 ✓. 6 : 7 ≠ 42, 42 : 6 = 7 ≠ 6, 6 · 6 = 36 ≠ 42. Faqat birinchisi to'g'ri."},
 tn:"«O'rniga qo'yish» usulini bolalar o'zi tekshirsin — bu tenglamani tushunishning eng yaxshi isboti."},
{h:"Ikki qadamli tenglama",sum:"8 · x + 15 = 87 → 8 · x = 72 → x = 9. Avval qo'shilganni olib tashlaymiz.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bank savoli: <b>8 · x + 15 = 87</b>. Bu yerda ikki amal bor. Chizmada «qutilar» va «qo'shimcha» ni ajratamiz.</p>",btns:[phaser(P5)],
 after:"<p>Usul: tenglamani <b>tashqaridan ichkariga</b> yechamiz. Avval oxirgi amalni (+15) bekor qilamiz: 87 − 15 = 72. Keyin ko'paytirishni: 72 : 8 = 9.</p>",
 q:{t:"x · 5 + 150 = 1000. x nechaga teng?",opts:["230","170","50","200"],ok:1,why:"x · 5 = 850, x = 850 : 5 = 170.",hint:"Avval 150 ni olib tashlang, keyin 5 ga bo'ling.",full:"x · 5 = 1000 − 150 = 850. x = 850 : 5 = 170. Tekshiruv: 170 · 5 + 150 = 850 + 150 = 1000 ✓. «200» — 150 olib tashlanmagan."},
 tn:"Bu 3-sinf «tarkibli tenglamalar» mavzusiga tayyorlov. Kuchli bolalar uchun."},
{h:"Tuzoq: o'ng tomonda ham amal bor",sum:"4 · x = 96 : 2 → avval o'ng tomon: 48 → x = 12.",a:"m06",
 start:function(){k2c12_big('4 · x = 96 : 2','O‘ng tomonda ham amal bor!');k2c12_model(4,['x','x','x','x'],'96 : 2')},fin:function(){k2c12_model(4,['12','12','12','12'],'48','x = 12');k2c12_big('96 : 2 = 48 → x = 48 : 4 = <b>12</b>')},
 html:"<p>Bank savoli: <b>4 · x = 96 : 2</b>. O'ng tomonda ham amal bor. Nima qilamiz?</p>",
 btns:[["▶ Avval o'ng tomon",function(c,d){k2c12_model(4,['?','?','?','?'],'48');k2c12_big('96 : 2 = <b>48</b> → 4 · x = 48');mvK(d,2)}],["▶ Endi x",function(c,d){k2c12_model(4,['12','12','12','12'],'48','x = 12');k2c12_big('x = 48 : 4 = <b>12</b> &nbsp; ✓ 4 · 12 = 48');mvK(d,2)}]],g2:1,
 after:"<p>Avval <b>ma'lum sonlar</b> bilan amalni bajaring — tenglama soddalashadi: 4 · x = 48. Xato yo'l: 96 ni 4 ga bo'lib, 2 ni unutish (x = 24).</p>",
 q:{t:"7 · x = 563 + 228. x nechaga teng?",opts:["113","103","791","112"],ok:0,why:"563 + 228 = 791, 791 : 7 = 113.",hint:"Avval o'ng tomonni hisoblang.",full:"O'ng tomon: 563 + 228 = 791. x = 791 : 7 = 113. Tekshiruv: 7 · 113 = 791 ✓. «791» — bu o'ng tomonning o'zi."},
 tn:"Bolalar o'ng tomonni hisoblab, tenglamani qayta yozsin: «4 · x = 48». Bir qadam — bir qator."},
{h:"Tuzoq: o'ylangan sonni topamiz",sum:"Son · 12 − 4 : 10 − 2 = 6 → orqaga: 6 + 2 = 8, 8 · 10 = 80, 80 + 4 = 84, 84 : 12 = 7.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=4;P7[4]()},
 html:"<p>Bank savoli: «Anvar son o'yladi: uni 12 ga ko'paytirdi, 4 ni ayirdi, 10 ga bo'ldi, 2 ni ayirdi — <b>6</b> chiqdi. Qaysi son?» Oxiridan orqaga yuramiz!</p>",btns:[phaser(P7,'▶ Orqaga qadam')],
 after:"<p>Har amalning <b>teskarisi</b> bor: qo'shish ↔ ayirish, ko'paytirish ↔ bo'lish. Oxiridan boshlab teskari amallarni bajaramiz: <b>7</b>. Tekshiruv: 7 · 12 = 84, − 4 = 80, : 10 = 8, − 2 = 6 ✓</p>",
 q:{t:"Bir sonni 3 ga ko'paytirib, 15 qo'shilsa, 60 chiqadi. Qaysi son?",opts:["15","25","45","20"],ok:0,why:"60 − 15 = 45, 45 : 3 = 15.",hint:"Oxiridan boshlang: avval 15 ni olib tashlang.",full:"Orqaga: 60 − 15 = 45, 45 : 3 = 15. Tekshiruv: 15 · 3 + 15 = 60 ✓. «25» — 75 : 3, tartib buzilgan; «45» — oxirgi qadam unutilgan."},
 tn:"«Orqaga yechish» — olimpiadalarda eng ko'p ishlatiladigan usul. Bolalar strelkali zanjir chizsin."},
{h:"Bilasizmi? «Al-jabr» — tenglamalar kitobi",sum:"Al-Xorazmiyning «Al-jabr val-muqobala» kitobi tenglamalarni yechish qoidalarini yozgan; «algebra» so'zi shundan.",a:"m08",
 start:function(){k2c12_model(4,['x','x','x','x'],'28');k2c12_big('x · 4 = 28')},fin:function(){k2c12_model(4,['7','7','7','7'],'28','x = 7');k2c12_big('x = 7')},
 html:"<p>⭐ Bundan 1200 yil oldin vatandoshimiz <b>Muhammad al-Xorazmiy</b> «Al-jabr val-muqobala» kitobini yozgan. Unda noma'lum sonni topish qoidalari bor — siz bugun o'rgangan ishning katta akasi!</p><p>📜 «<b>Algebra</b>» so'zi aynan shu kitob nomidan, «<b>algoritm</b>» so'zi esa al-Xorazmiy ismidan kelib chiqqan. Al-Xorazmiy davrida «x» belgisi yo'q edi — u noma'lumni so'z bilan, «narsa» deb atagan.</p>",
 tn:"Bolalarga «siz al-Xorazmiy ishini davom ettiryapsiz» deb ayting — loyiha nomi bilan bog'lanadi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c12_model(4,['7','7','7','7'],'28','x = 7');k2c12_big('x · 4 = 28 → x = 7')},fin:function(){k2c12_model(4,['7','7','7','7'],'28','x = 7');k2c12_big('x · 4 = 28 → x = 7')},
 html:"<div class='memo'><ul><li><b>Noma'lum ko'paytuvchi</b> = ko'paytma : ma'lum ko'paytuvchi (x · 4 = 28 → x = 7).</li><li><b>Noma'lum bo'linuvchi</b> = bo'linma · bo'luvchi (x : 6 = 8 → x = 48).</li><li><b>Noma'lum bo'luvchi</b> = bo'linuvchi : bo'linma (56 : x = 7 → x = 8).</li><li>Ikki amalli: avval tashqi amalni bekor qiling (8 · x + 15 = 87 → 8 · x = 72).</li><li>O'ng tomonda amal bo'lsa — avval uni hisoblang.</li><li>O'ylangan son — oxiridan, teskari amallar bilan.</li><li><b>Doim tekshiring!</b></li></ul></div>",
 tn:"Keyingi darsni «x : 3 = 3 · 3» tenglamasi bilan boshlang (x = 27)."}
];
var PROBS=[
{t:"x · 3 = 27. x nechaga teng?",o:["9","24","30","81"],k:0,s:"x = 27 : 3 = 9."},
{t:"x : 5 = 8. x nechaga teng?",o:["40","13","3","45"],k:0,s:"x = 8 · 5 = 40."},
{t:"36 : x = 4. x nechaga teng?",o:["9","32","144","40"],k:0,s:"x = 36 : 4 = 9."},
{t:"7 · x = 49. x nechaga teng?",o:["7","42","56","343"],k:0,s:"x = 49 : 7 = 7."},
{t:"a : 6 = 12 · 10. a nechaga teng?",o:["720","132","620","20"],k:0,s:"12 · 10 = 120, a = 120 · 6 = 720."},
{t:"4 · x = 96 : 2. x nechaga teng?",o:["12","48","14","192"],k:0,s:"96 : 2 = 48, x = 48 : 4 = 12."},
{t:"8 · x + 15 = 87. x nechaga teng?",o:["9","72","8","7"],k:0,s:"8 · x = 72, x = 9."},
{t:"x : 7 − 23 = 100. x nechaga teng?",o:["861","851","700","539"],k:0,s:"x : 7 = 123, x = 123 · 7 = 861."},
{t:"280 : x + 13 = 20. x nechaga teng?",o:["40","30","4","1960"],k:0,s:"280 : x = 7, x = 280 : 7 = 40."},
{t:"(x · 6) : 10 = 42. x nechaga teng?",o:["70","420","7","80"],k:0,s:"x · 6 = 420, x = 70."},
{t:"Bir sonni 3 ga ko'paytirib, 15 qo'shilsa, 60 chiqadi. Qaysi son?",o:["15","25","45","20"],k:0,s:"60 − 15 = 45, 45 : 3 = 15."},
{t:"Anvar son o'yladi: 12 ga ko'paytirdi, 4 ni ayirdi, 10 ga bo'ldi, 2 ni ayirdi — 6 chiqdi. Qaysi son?",o:["7","8","6","5"],k:0,s:"6 + 2 = 8, 8 · 10 = 80, 80 + 4 = 84, 84 : 12 = 7."},
{t:"24 : (2 + a) = 4. a nechaga teng?",o:["4","6","2","8"],k:0,s:"2 + a = 24 : 4 = 6, a = 4."},
{t:"x : 6 : 2 = 66. x nechaga teng?",o:["792","396","132","782"],k:0,s:"x : 6 = 132, x = 792."},
{t:"Qaysi tenglamaning yechimi 8 ga teng?",o:["64 : x = 8","x · 8 = 8","x : 8 = 64","8 · x = 16"],k:0,s:"64 : 8 = 8 ✓. Qolganlari: 1, 512, 2."},
{t:"Qutilardagi olmalar teng. 5 ta quti va yana 3 ta olma — jami 43 ta. Bir qutida nechta olma?",o:["8","9","10","7"],k:0,s:"5 · x + 3 = 43, 5 · x = 40, x = 8."},
{t:"x · 9 = 81 : 9 · 9. x nechaga teng?",o:["9","1","81","3"],k:0,s:"81 : 9 · 9 = 9 · 9 = 81, x = 81 : 9 = 9."},
{t:"1000 − x : 5 = 873. x nechaga teng?",o:["635","127","625","535"],k:0,s:"x : 5 = 127, x = 635."},
{t:"x · 4 = 7 · 8. x nechaga teng?",o:["14","56","8","32"],k:0,s:"7 · 8 = 56, x = 56 : 4 = 14."},
{t:"Ota o'g'lidan 4 marta katta, ikkalasining yoshi jami 40. O'g'il necha yoshda?",o:["8","10","32","36"],k:0,s:"O'g'il — 1 bo'lak, ota — 4 bo'lak: 5 bo'lak = 40, 1 bo'lak = 8."}
];
function PRACT_STAGE(){k2c12_model(4,['x','x','x','x'],'butun');k2c12_big('Avval chizma, keyin qoida, oxirida tekshiruv')}
var PREP_DATA={teach:["Noma'lum ko'paytuvchi, bo'linuvchi va bo'luvchini topish qoidalari.","Chizma (bar) model bilan tenglamani tasvirlash.","Tekshirish — o'rniga qo'yish.","Ikki qadamli tenglama; o'ng tomonda amal; «o'ylangan son» — orqaga yechish."],
 mist:["Bo'linuvchi va bo'luvchi qoidasini almashtiradi (x : 6 = 8 → x = 8 : 6).","Ikki amalli tenglamada tartibni buzadi.","O'ng tomondagi amalni bajarmaydi.","Tekshirmaydi."],
 need:["Chizma (bar) uchun rangli qog'oz tasmalar.","Tenglama kartochkalari."],
 board:["<span class='w2'>x · 4 = 28 → x = 28 : 4 = 7</span>.","<span class='w2'>x : 6 = 8 → x = 8 · 6 = 48</span>.","<span class='w2'>56 : x = 7 → x = 56 : 7 = 8</span>.","<span class='w2'>8 · x + 15 = 87 → 8 · x = 72 → x = 9</span>.","Orqaga: <span class='w2'>6 → 8 → 80 → 84 → 7</span>."]};
