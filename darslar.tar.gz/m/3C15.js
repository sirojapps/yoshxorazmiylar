var CODE='3C15',TITLE='3-sinf · Burchakli bo‘lish; 0 bilan tugagan va o‘rtasida 0 bor sonlar';
var P1=[function(){w3Expr(['852 : 4 = ?']);w3Msg('Og‘zaki qiyin. Sonni qulay bo‘laklarga ajratamiz')},
 function(){w3Expr(['852 = 800 + 40 + 12','800 : 4 = {200}','40 : 4 = {10}','12 : 4 = {3}']);w3Msg('Har bir bo‘lak 4 ga bo‘linadi')},
 function(){w3Expr(['852 : 4 = 200 + 10 + 3','= {213}']);w3Msg('Burchakli bo‘lish — xuddi shu ishni <b>tartib bilan</b>, xonama-xona bajarish')}];
var P3=w3LongPh(852,4);
var P5=w3LongPh(824,4,'824 : 4 — o‘rtada qiziq joy bor. Kuzating!');
var P6=w3LongPh(840,4,'840 : 4 — oxirida 0 bor');
var P7=w3LongPh(853,4,'853 : 4 — oxirida nima qoladi?');
var STEPS=[
{h:"Nega burchakli bo'lish kerak?",sum:"852 : 4 = 800 : 4 + 40 : 4 + 12 : 4 = 213. Burchakli bo'lish — shuni tartib bilan bajarish.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>852 ta qalamni 4 ta sinfga teng bo'lish kerak. Og'zaki hisoblash qiyin. Avval sonni bo'laklarga ajratib ko'ramiz (bu «Yig'indini songa bo'lish» qoidasi).</p>",
 btns:[phaser(P1)],
 after:"<p>Har bir sinfga <b>213</b> ta qalam. Katta sonlarda bo'laklarni tanlash qiyinlashadi — shuning uchun matematiklar har doim ishlaydigan tartibni o'ylab topishgan: <b>burchakli bo'lish</b>.</p>",
 q:{t:"963 : 3 ni bo'laklab hisoblang: 900 : 3 + 60 : 3 + 3 : 3 = ?",opts:["321","312","301","333"],ok:0,why:"300 + 20 + 1 = 321.",hint:"Har bir bo'lakni alohida 3 ga bo'ling.",full:"900 : 3 = 300, 60 : 3 = 20, 3 : 3 = 1. Yig'indi: 321."},
 tn:"Avval 3C14 (yig'indini songa bo'lish) ni eslating — burchakli bo'lish uning qisqa yozuvi."},
{h:"Burchakni qanday chizamiz",sum:"Bo'linuvchi chapda, burchak ichida o'ngda bo'luvchi, uning ostida bo'linma.",a:"m02",
 start:function(){w3Long(852,4,0);w3Msg('852 — bo‘linuvchi (chapda), 4 — bo‘luvchi (burchak ichida)')},fin:function(){w3Long(852,4,0)},
 html:"<p>Yozuv tartibi: <b>bo'linuvchi</b> chapda, uning o'ng tomonida tik chiziq; chiziqdan o'ngda <b>bo'luvchi</b>, ostiga gorizontal chiziq — bu «burchak». Chiziq ostiga <b>bo'linma</b> yoziladi. Bo'linuvchini bosing.</p>",
 act:function(c,done){c.querySelector('.hint').textContent='Rasmdagi 852 sonini bosing.';var t=S.g.querySelectorAll('text');for(var i=0;i<t.length;i++)(function(e){e.style.cursor='pointer';e.addEventListener('click',function(){done();w3Msg('To‘g‘ri! Endi birinchi qadam: <b>to‘liqsiz bo‘linuvchi</b>ni topish')})})(t[i]);
  var r=E('rect',{x:20,y:0,width:150,height:60,fill:'transparent',style:'cursor:pointer'},S.g);r.addEventListener('click',function(){done()})},
 after:"<p>Bo'lish <b>chapdan</b> (eng katta xonadan) boshlanadi — ko'paytirish va qo'shishdan farqli! Birinchi raqam 8 ni 4 ga bo'lish mumkin — bu <b>birinchi to'liqsiz bo'linuvchi</b>.</p>",
 q:{t:"Burchakli bo'lishda hisob qaysi xonadan boshlanadi?",opts:["Eng katta xonadan (chapdan)","Birliklardan (o'ngdan)","O'rtadan","Istalgan joydan"],ok:0,why:"Bo'lish chapdan — eng katta xonadan boshlanadi.",hint:"Qo'shish birliklardan boshlanadi. Bo'lish-chi?",full:"Qo'shish, ayirish va ko'paytirish birliklardan (o'ngdan) boshlanadi. Bo'lish esa teskari — eng katta xonadan, chapdan boshlanadi."},
 tn:"Doskada burchakni katta qilib chizing; bo'linuvchi, bo'luvchi va bo'linma nomlarini yozib qo'ying."},
{h:"To'rt harakat: bo'l — ko'paytir — ayir — tushir",sum:"852 : 4: 8:4=2, 2·4=8, 8−8=0, 5 ni tushir; 5:4=1 … 12:4=3 → 213.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=P3.length-1;P3[P3.length-1]()},
 html:"<p>Har bir raqam uchun bir xil to'rt harakat takrorlanadi: <b>bo'l → ko'paytir → ayir → tushir</b>. Tugmani bosib, har harakatni kuzating — pastda nima qilinayotgani yoziladi.</p>",
 btns:[phaser(P3,'▶ Keyingi harakat')],
 after:"<p>Sikl: <b>bo'l</b> (bo'linma raqami), <b>ko'paytir</b> (raqam · bo'luvchi), <b>ayir</b> (qoldiq bo'luvchidan kichik bo'lishi shart!), <b>tushir</b> (keyingi raqam). Raqamlar tugaguncha takrorlaymiz.</p><div class='life'><div>🔁<span>Yodlash oson: «Bo'l, ko'paytir, ayir, tushir — yana boshidan!»</span></div></div>",
 q:{t:"Ayirgandan keyin qoldiq 5 chiqdi, bo'luvchi esa 4. Bu nimani bildiradi?",opts:["Bo'linma raqami kichik tanlangan — xato","Hammasi to'g'ri","Bo'luvchini o'zgartirish kerak","Keyingi raqamni tushirish kerak"],ok:0,why:"Qoldiq doim bo'luvchidan kichik bo'lishi kerak.",hint:"Qoldiq bo'luvchidan katta bo'lishi mumkinmi?",full:"5 ning ichida yana bitta 4 bor. Demak bo'linma raqamini 1 ga oshirish kerak edi. Qoida: har ayirishdan keyin qoldiq < bo'luvchi."},
 tn:"Bolalar har harakatni ovoz chiqarib aytsin: «sakkizni to'rtga bo'ldim — ikki…». Yaponiya darslarida bola o'z yechimini sinfga tushuntiradi."},
{h:"Bo'linmada nechta raqam bo'ladi?",sum:"Birinchi to'liqsiz bo'linuvchini topamiz: 156 : 4 da 1 < 4, shuning uchun 15 olinadi → bo'linma ikki xonali.",a:"m04",
 start:function(){w3Expr(['156 : 4']);w3Msg('Birinchi to‘liqsiz bo‘linuvchini tanlang')},fin:function(){w3Expr(['[15]6 : 4','bo‘linma 2 xonali: 39']);w3Msg('156 : 4 = 39')},
 html:"<p>156 : 4. Birinchi qadamda qaysi sonni 4 ga bo'lamiz? Tanlang:</p><div class='digs w3c'></div>",
 act:function(c,done){w3Btns(c,'.w3c',['1','15','156'],function(v,b){if(v==='15'){b.className='dg yes';w3Expr(['[15]6 : 4','15 : 4 ≈ 3 → bo‘linma 2 xonali']);w3Msg('1 &lt; 4 — bo‘lib bo‘lmaydi, shuning uchun ikki raqam olamiz: <b>15</b>');done()}else{b.className='dg no';setTimeout(function(){b.className='dg'},1200);w3Msg(v==='1'?'1 ni 4 ga bo‘lib bo‘lmaydi (1 &lt; 4)':'Butun sonni birdan olish — bu og‘zaki bo‘lish, bizga eng kichik mos boshlanish kerak')}})},
 after:"<p>Qoida: birinchi to'liqsiz bo'linuvchi qancha raqamdan iborat bo'lsa, undan keyin qolgan har bir raqam bo'linmaga yana bitta raqam beradi. 156 da: 15 + yana 1 raqam (6) → bo'linma <b>2 xonali</b>. Javobni oldindan chamalash xatodan saqlaydi!</p>",
 q:{t:"736 : 8 ning bo'linmasi necha xonali bo'ladi?",opts:["2 xonali","3 xonali","1 xonali","4 xonali"],ok:0,why:"7 < 8 → birinchi to'liqsiz bo'linuvchi 73; keyin 1 raqam qoladi → 2 xonali (92).",hint:"7 ni 8 ga bo'lish mumkinmi? Bo'lmasa, nechta raqam olinadi?",full:"7 < 8, shuning uchun 73 olinadi. Undan keyin bitta raqam (6) qoladi. Bo'linma 2 xonali: 736 : 8 = 92."},
 tn:"Har misolda avval «bo'linma nechta xonali?» deb so'rang va bo'linma o'rniga nuqtalar qo'ying (• •). Bu Rossiya va O'zbekiston maktablarining klassik usuli."},
{h:"Tuzoq: o'rtada 0",sum:"824 : 4: 2 : 4 sig'maydi → bo'linmaga 0 yoziladi → 206. 0 ni tashlab ketsak 26 chiqadi!",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=P5.length-1;P5[P5.length-1]()},
 html:"<p>824 : 4 — bu yerda eng ko'p xato qilinadi. Kuzating.</p>",btns:[phaser(P5)],
 after:"<p>2 ni 4 ga bo'lib bo'lmaydi — lekin bu xona <b>bo'sh qolmaydi</b>: bo'linmaga <b>0</b> yozamiz va keyingi raqamni tushiramiz. Javob: <b>206</b>. Tekshiring: 206 · 4 = 824 ✓. «26» — 0 unutilgan, 26 · 4 = 104 ≠ 824.</p>",
 q:{t:"618 : 6 = ?",opts:["13","103","130","1003"],ok:1,why:"6:6=1, 1:6 — sig'maydi → 0, 18:6=3 → 103.",hint:"Ikkinchi raqam 1 ni 6 ga bo'lib bo'ladimi? Bo'linmaga nima yoziladi?",full:"6 : 6 = 1. Keyin 1 ni tushiramiz: 1 : 6 — sig'maydi, bo'linmaga 0. 18 ni olamiz: 18 : 6 = 3. Javob: 103. Tekshiruv: 103 · 6 = 618 ✓."},
 tn:"Javobni chamalab tekshirishni o'rgating: 824 : 4 ≈ 800 : 4 = 200 — demak 26 bo'lishi mumkin emas."},
{h:"Tuzoq: oxirida 0",sum:"840 : 4 = 210: oxirgi 0 ni ham tushirib, 0 : 4 = 0 yoziladi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=P6.length-1;P6[P6.length-1]()},
 html:"<p>840 : 4. Ikkita raqam bo'lingandan keyin qoldiq 0 bo'ladi. Shu yerda to'xtasak bo'ladimi?</p>",btns:[phaser(P6)],
 after:"<p>Yo'q! Bo'linuvchida hali <b>0</b> raqami qolgan edi — uni ham tushiramiz: 0 : 4 = <b>0</b>. Javob: <b>210</b>, 21 emas. Qoida: bo'linuvchining <b>har bir</b> raqami tushiriladi.</p>",
 q:{t:"720 : 6 = ?",opts:["12","120","102","1200"],ok:1,why:"7:6=1 (1 qoldiq), 12:6=2, 0:6=0 → 120.",hint:"Oxirgi 0 ni ham tushirdingizmi?",full:"7 : 6 = 1, qoldiq 1. 12 : 6 = 2. Oxirgi 0 : 6 = 0. Javob: 120. Chamalash: 720 : 6 ≈ 700 : 6 ≈ 117 → 12 bo'lishi mumkin emas."},
 tn:"«Nechta raqam bo'lishi kerak» degan chamalash bu xatoni ham tutadi: 840 : 4 — bo'linma 3 xonali."},
{h:"Qoldiqli burchakli bo'lish",sum:"853 : 4 = 213 (qoldiq 1). Tekshirish: 213 · 4 + 1 = 853.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=P7.length-1;P7[P7.length-1]()},
 html:"<p>853 : 4. Oxirida ayirishdan keyin 0 emas, boshqa son qolsa nima qilamiz?</p>",btns:[phaser(P7)],
 after:"<p>Oxirgi qoldiq — <b>1</b>. Javob: <b>213 (qoldiq 1)</b>. Tekshirish: bo'linma · bo'luvchi + qoldiq = bo'linuvchi: 213 · 4 + 1 = 853 ✓. Qoldiq har doim bo'luvchidan kichik.</p>",
 q:{t:"Son 7 ga bo'linganda bo'linma 23, qoldiq esa mumkin bo'lgan eng katta son. Bo'linuvchini toping.",opts:["167","161","166","168"],ok:0,why:"Eng katta qoldiq 6: 23 · 7 + 6 = 167.",hint:"7 ga bo'lganda eng katta qoldiq nechaga teng bo'lishi mumkin?",full:"Qoldiq bo'luvchidan kichik: 7 ga bo'lganda eng kattasi 6. Bo'linuvchi = 23 · 7 + 6 = 161 + 6 = 167. «168» — 7 qoldiq bo'lmaydi, u yana bitta 7 bo'lib ketadi."},
 tn:"Bank va saralash testlarida «eng katta qoldiq» savoli tez-tez keladi."},
{h:"Ko'paytirib tekshiramiz",sum:"Bo'lishni ko'paytirish bilan tekshiramiz: 236 · 3 = 708 → 708 : 3 = 236 to'g'ri.",a:"m08",
 start:function(){w3Expr(['708 : 3 = ?','Ali: 236   Vali: 226   Soli: 26']);w3Msg('Kim to‘g‘ri? Har birini ko‘paytirib tekshiring')},fin:function(){w3Expr(['236 · 3 = {708} ✓','226 · 3 = [678]','26 · 3 = [78]']);w3Msg('To‘g‘ri javob — Alining 236')},
 html:"<p>708 : 3 ni uch bola uch xil yechdi. Har birining javobini <b>ko'paytirib</b> tekshiring — tugmalarni bosing:</p>",
 btns:[["Ali: 236",function(c,done){w3Expr(['236 · 3 = {708} ✓']);w3Msg('236 · 3 = 708 — bo‘linuvchiga teng. To‘g‘ri!');mvK(done,2)}],["Vali: 226",function(c,done){w3Expr(['226 · 3 = [678]']);w3Msg('678 ≠ 708 — Vali o‘nliklarda xato qilgan');mvK(done,2)}],["Soli: 26",function(c,done){w3Expr(['26 · 3 = [78]']);w3Msg('78 ≠ 708 — Soli o‘rtadagi 0 dan keyingi raqamni unutgan');mvK(done,2)}]],
 after:"<p>Har bo'lishni ko'paytirish bilan tekshirish mumkin: <b>bo'linma · bo'luvchi = bo'linuvchi</b> (qoldiq bo'lsa, uni qo'shamiz). Bu testda xatoni topishning eng ishonchli yo'li.</p>",
 q:{t:"Qaysi bo'lish to'g'ri bajarilgan?",opts:["912 : 4 = 228","912 : 4 = 218","912 : 4 = 238","912 : 4 = 28"],ok:0,why:"228 · 4 = 912.",hint:"Har bir javobni 4 ga ko'paytirib ko'ring.",full:"228 · 4 = 912 ✓. 218 · 4 = 872, 238 · 4 = 952, 28 · 4 = 112 — bular 912 ga teng emas."},
 tn:"Daftarda har bo'lish yonida tekshiruv qatorini yozish odat bo'lsin."},
{h:"Bilasizmi? Har xil davlatda har xil yoziladi",sum:"O'zbekistonda va Yevropada «burchak», AQShda bo'linma tepaga yoziladi; ilgari Yevropada «kema» usuli bo'lgan.",a:"m09",
 start:function(){w3Expr(['O‘zbekiston:  852 | 4','AQSh:  4 ) 852  (213 tepada)','Eski Italiya: «kema» usuli']);w3Msg('Usul bitta — yozuvi har xil')},fin:function(){w3Expr(['O‘zbekiston:  852 | 4','AQSh:  4 ) 852  (213 tepada)','Eski Italiya: «kema» usuli']);w3Msg('Usul bitta — yozuvi har xil')},
 html:"<p>🌍 Biz bo'linmani burchak ostiga yozamiz. AQSh va Angliyada bo'linma bo'linuvchining <b>tepasiga</b> yoziladi. XVII asrgacha Italiyada raqamlarni o'chirib-o'chirib yoziladigan «kema» (galeya) usuli mashhur bo'lgan — yozuvi kemaga o'xshab ketgani uchun shunday atalgan.</p><p>⭐ Lekin barchasining asosi bir: <b>o'nlik pozitsion sanoq sistemasi</b> — al-Xorazmiy kitobi orqali dunyoga tarqalgan usul.</p>",
 tn:"Qiziqqan bolalarga AQSh yozuvida bitta misolni ko'rsating — ular usul bir xil ekanini o'zi ko'radi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Long(852,4,99);w3Msg('852 : 4 = 213')},fin:function(){w3Long(852,4,99);w3Msg('852 : 4 = 213')},
 html:"<div class='memo'><ul><li>Bo'lish <b>chapdan</b> — eng katta xonadan boshlanadi.</li><li>Avval <b>birinchi to'liqsiz bo'linuvchi</b>ni toping va bo'linma necha xonali bo'lishini chamalang.</li><li>Sikl: <b>bo'l → ko'paytir → ayir → tushir</b>.</li><li>Har ayirishdan keyin <b>qoldiq &lt; bo'luvchi</b>.</li><li>Raqam sig'masa — bo'linmaga <b>0</b> yozing: 824 : 4 = <b>206</b>.</li><li>Oxiridagi 0 ni ham tushiring: 840 : 4 = <b>210</b>.</li><li>Tekshirish: bo'linma · bo'luvchi + qoldiq = bo'linuvchi.</li></ul></div>",
 tn:"Keyingi darsni «Bo'linmasi necha xonali?» chamalash mashqi bilan boshlang (5 ta misol, 1 daqiqa)."}
];
var PROBS=[
{t:"684 : 2 = ?",o:["342","324","3042","341"],k:0,s:"6:2=3, 8:2=4, 4:2=2 → 342."},
{t:"936 : 3 = ?",o:["312","321","302","3012"],k:0,s:"9:3=3, 3:3=1, 6:3=2 → 312."},
{t:"756 : 6 = ?",o:["126","136","116","1206"],k:0,s:"7:6=1 (1), 15:6=2 (3), 36:6=6 → 126."},
{t:"915 : 5 = ?",o:["183","173","193","1803"],k:0,s:"9:5=1 (4), 41:5=8 (1), 15:5=3 → 183."},
{t:"824 : 4 = ?",o:["206","26","260","216"],k:0,s:"8:4=2, 2:4 — 0, 24:4=6 → 206."},
{t:"927 : 9 = ?",o:["103","13","130","113"],k:0,s:"9:9=1, 2:9 — 0, 27:9=3 → 103."},
{t:"960 : 8 = ?",o:["120","12","102","112"],k:0,s:"9:8=1 (1), 16:8=2, 0:8=0 → 120."},
{t:"630 : 6 = ?",o:["105","15","150","106"],k:0,s:"6:6=1, 3:6 — 0, 30:6=5 → 105."},
{t:"Bo'linmasi necha xonali: 472 : 8?",o:["2 xonali","3 xonali","1 xonali","4 xonali"],k:0,s:"4 < 8 → 47 dan boshlanadi, keyin 1 raqam → 2 xonali (59)."},
{t:"Bo'linmasi necha xonali: 845 : 5?",o:["3 xonali","2 xonali","1 xonali","4 xonali"],k:0,s:"8 ≥ 5 → 8 dan boshlanadi, keyin 2 raqam → 3 xonali (169)."},
{t:"Qoldiqni toping: 97 : 4",o:["1","24","3","2"],k:0,s:"24 · 4 = 96, 97 − 96 = 1."},
{t:"Qoldiqni toping: 538 : 6",o:["4","89","2","5"],k:0,s:"89 · 6 = 534, 538 − 534 = 4."},
{t:"Son 9 ga bo'linganda bo'linma 14, qoldiq 5. Bo'linuvchini toping.",o:["131","126","135","121"],k:0,s:"14 · 9 + 5 = 126 + 5 = 131."},
{t:"Son 6 ga bo'linganda bo'linma 35, qoldiq mumkin bo'lgan eng katta son. Bo'linuvchi?",o:["215","216","210","211"],k:0,s:"Eng katta qoldiq 5: 35 · 6 + 5 = 215."},
{t:"Qaysi bo'lish to'g'ri?",o:["735 : 7 = 105","735 : 7 = 15","735 : 7 = 150","735 : 7 = 115"],k:0,s:"105 · 7 = 735."},
{t:"860 ta daftar 4 ta sinfga teng bo'lindi. Har sinfga nechtadan?",o:["215","205","225","21"],k:0,s:"860 : 4: 8:4=2, 6:4=1 (2), 20:4=5 → 215."},
{t:"Bir qadoqqa 6 ta tuxum sig'adi. 500 ta tuxumdan nechta qadoq to'ladi va nechta tuxum ortadi?",o:["83 ta, 2 ta ortadi","83 ta, 4 ta ortadi","82 ta, 8 ta ortadi","84 ta, 0 ta ortadi"],k:0,s:"83 · 6 = 498, 500 − 498 = 2."},
{t:"2418 : 6 = ?",o:["403","43","430","4003"],k:0,s:"24 : 6 = 4, 1 : 6 — 0 (bo‘linmaga 0 yoziladi!), 18 : 6 = 3 → 403. Tekshiruv: 403 · 6 = 2418."},
{t:"3 ta qutiga jami 618 ta qalam teng joylandi. Bitta qutida nechta qalam bor?",o:["206","26","260","216"],k:0,s:"6 : 3 = 2, 1 : 3 — 0, 18 : 3 = 6 → 206. Tekshiruv: 206 · 3 = 618."},
{t:"Qaysi sonni 8 ga bo'lganda bo'linma 107 chiqadi?",o:["856","816","867","815"],k:0,s:"107 · 8 = 856."}
];
function PRACT_STAGE(){w3Long(852,4,99);w3Msg('Bo‘l → ko‘paytir → ayir → tushir')}
var PREP_DATA={teach:["Burchakli bo'lish yozuvi va «bo'l–ko'paytir–ayir–tushir» sikli.","Birinchi to'liqsiz bo'linuvchi va bo'linmaning xonalar sonini chamalash.","O'rtasida va oxirida 0 bo'lgan bo'linma (206, 210).","Qoldiqli burchakli bo'lish va ko'paytirib tekshirish."],
 mist:["Bo'lishni o'ngdan (birliklardan) boshlaydi.","Raqam sig'masa bo'linmaga 0 yozmaydi: 824 : 4 = 26.","Oxirgi 0 ni tushirmaydi: 840 : 4 = 21.","Qoldiq bo'luvchidan katta qolganini sezmaydi."],
 need:["Doskada katta burchak shabloni.","Rangli bo'r: bo'linma — yashil, ko'paytma — qizil."],
 board:["<span class='w2'>852 = 800 + 40 + 12</span> → <span class='w2'>200 + 10 + 3</span>.","Burchak: <span class='w2'>852 | 4</span>, ostida <span class='w2'>213</span>.","Sikl: bo'l → ko'paytir → ayir → tushir.","<span class='w2'>824 : 4 = 206</span>, <span class='w2'>840 : 4 = 210</span>.","<span class='w2'>853 : 4 = 213 (q. 1)</span>, tekshirish: <span class='w2'>213 · 4 + 1</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
