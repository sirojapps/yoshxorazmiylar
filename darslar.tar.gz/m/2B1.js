var CODE='2B1',TITLE='2-sinf · O‘nlikdan o‘tmay qo‘shish va ayirish';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ikki to'p o'nlik/birlik: chap va o'ng, natija pastda
function grp(n,x,y,o){o=o||{};var g=S.g,t=Math.floor(n/10),u=n%10;for(var i=0;i<t;i++){var cr=o.ct&&i>=t-o.ct;rod(g,x+i*13,y,70,cr?'#e7e2da':null);if(cr)E('line',{x1:x+i*13-7,y1:y,x2:x+i*13+7,y2:y+70,stroke:C.bad,'stroke-width':2},g)}
 for(var k=0;k<u;k++){var cu=o.cu&&k>=u-o.cu,cx=x+t*13+12+Math.floor(k/5)*12,cy=y+6+(k%5)*14;unit(g,cx,cy,cu?'#e7e2da':o.uc);if(cu)E('line',{x1:cx-6,y1:cy-6,x2:cx+6,y2:cy+6,stroke:C.bad,'stroke-width':2},g)}}
function hd(a,b,op){var g=S.g;T(g,180,22,a+' '+op+' '+b,{'font-size':18,'font-weight':800,fill:'#1d2b3a'})}
var P1=[function(){clear();hd(34,25,'+');grp(34,20,40);grp(25,200,40,{uc:C.c});msg('34 = 3 o‘nlik 4 birlik, 25 = 2 o‘nlik 5 birlik')},
 function(){clear();hd(34,25,'+');grp(59,90,40);T(S.g,180,140,'o‘nliklar: 3 + 2 = 5 · birliklar: 4 + 5 = 9',{'font-size':13,'font-weight':800,fill:C.blue});msg('O‘nliklarni o‘nliklarga, birliklarni birliklarga qo‘shamiz')},
 function(){clear();hd(34,25,'+');grp(59,90,40);T(S.g,180,140,'34 + 25 = 59',{'font-size':20,'font-weight':800,fill:C.ok});msg('5 o‘nlik 9 birlik = <b>59</b>')}];
var P3=[function(){g100(34,[]);msg('100 jadvalida 34 dan boshlaymiz: + 25')},
 function(){g100(34,[44,54]);msg('+ 20 = <b>2 qator pastga</b>: 44, 54')},
 function(){g100(34,[44,54,55,56,57,58,59]);msg('+ 5 = <b>5 qadam o‘ngga</b>: 55, 56, 57, 58, 59. Javob: <b>59</b>')}];
var P4=[function(){clear();hd(68,23,'−');grp(68,90,40);msg('68 = 6 o‘nlik 8 birlik. 23 ni olib tashlaymiz')},
 function(){clear();hd(68,23,'−');grp(68,90,40,{ct:2});msg('2 ta o‘nlikni olamiz: 6 − 2 = 4 o‘nlik')},
 function(){clear();hd(68,23,'−');grp(68,90,40,{ct:2,cu:3});T(S.g,180,140,'68 − 23 = 45',{'font-size':20,'font-weight':800,fill:C.ok});msg('3 ta birlikni olamiz: 8 − 3 = 5. Javob: <b>45</b>')}];
var P5=[function(){jl(40,80,45,[]);msg('45 + 32: avval o‘nliklarni, keyin birliklarni qo‘shamiz')},
 function(){jl(40,80,45,[[45,55],[55,65],[65,75]]);msg('+ 30: uchta katta sakrash (10 dan) — 75')},
 function(){jl(40,80,45,[[45,55],[55,65],[65,75],[75,76],[76,77]]);msg('+ 2: ikkita kichik sakrash — <b>77</b>')}];
var P7=[function(){barm(null);msg('□ + 23 = 68. Noma‘lum son qaysi?')},function(){barm(1);msg('Butun — 68, bir bo‘lagi — 23. Ikkinchi bo‘lak = butun − ma‘lum bo‘lak')},function(){barm(2);msg('68 − 23 = <b>45</b>. Tekshiramiz: 45 + 23 = 68 ✓')}];
var P8=[function(){bar8(0);msg('68 ta shar bor edi. Ertalab 23 tasi, kechqurun 34 tasi sotildi')},function(){bar8(1);msg('Ertalab: 68 − 23 = 45 ta qoldi')},function(){bar8(2);msg('Kechqurun: 45 − 34 = <b>11</b> ta qoldi')}];
var STEPS=[
{h:"Tayoqchalar bilan qo'shamiz",sum:"34 + 25: o'nliklar 3 + 2 = 5, birliklar 4 + 5 = 9 → 59.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>34 va 25 ni qo'shamiz. Ikkala to'pni birlashtiramiz — kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Birlashtirganda tayoqchalar tayoqchalarga, nuqtalar nuqtalarga qo'shiladi: <b>o'nliklar + o'nliklar</b>, <b>birliklar + birliklar</b>. 34 + 25 = <b>59</b>.</p>",
 q:{t:"52 + 36 = ?",opts:["86","88","816","98"],ok:1,why:"O'nliklar 5 + 3 = 8, birliklar 2 + 6 = 8.",hint:"O'nliklarni alohida, birliklarni alohida qo'shing.",full:"52 + 36: o'nliklar 5 + 3 = 8, birliklar 2 + 6 = 8. Javob: 88. «816» — natijalarni yonma-yon yozish xatosi."},
 tn:"Avval narsalar bilan (cho'p bog'lamlari), keyin rasm bilan, oxirida faqat sonlar bilan — Singapur CPA ketma-ketligi."},
{h:"Xonama-xona qo'shish",sum:"Har bir xonani alohida: 43 + 25 → (40 + 20) + (3 + 5) = 60 + 8 = 68.",a:"m02",
 start:function(){tab2(43,25,0)},fin:function(){tab2(43,25,2)},
 html:"<p>Rasmsiz ham bo'ladi: sonlarni <b>xonalarga</b> ajratamiz. 43 + 25 ni bosqichma-bosqich hisoblang:</p>",
 btns:[["1) o'nliklar",function(c,done){tab2(43,25,1);mvK(done,2)}],["2) birliklar",function(c,done){tab2(43,25,2);mvK(done,2)},'u']],g2:1,
 after:"<p>43 + 25 = (40 + 20) + (3 + 5) = 60 + 8 = <b>68</b>. Birliklar yig'indisi <b>10 dan kichik</b> bo'lgani uchun o'nlikdan o'tish yo'q — hisob oson.</p>",
 q:{t:"71 + 16 = ?",opts:["77","87","97","86"],ok:1,why:"70 + 10 = 80, 1 + 6 = 7: 87.",hint:"O'nliklar: 70 + 10. Birliklar: 1 + 6.",full:"71 + 16 = (70 + 10) + (1 + 6) = 80 + 7 = 87."},
 tn:"Bolalar daftarda ikki rangli qalam bilan o'nliklar va birliklarni ajratib yozsin."},
{h:"100 jadvalida qo'shish",sum:"+10 — bir qator pastga, +1 — bir qadam o'ngga. 34 + 25: 2 qator pastga, 5 qadam o'ngga → 59.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>100 jadvalida qo'shish — xuddi xaritada yurishdek. Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>Jadvalda har qator 10 ta, shuning uchun <b>+10 — bir qator pastga</b>, <b>+1 — bir qadam o'ngga</b>. 34 + 25: ikki qator pastga (54), besh qadam o'ngga (59).</p>",
 q:{t:"100 jadvalida 23 dan 3 qator pastga va 4 qadam o'ngga yursak, qaysi songa kelamiz?",opts:["27","53","57","34"],ok:2,why:"23 + 30 = 53, 53 + 4 = 57.",hint:"Har qator — 10. 3 qator pastga = + 30.",full:"3 qator pastga: 23 + 30 = 53. 4 qadam o'ngga: 53 + 4 = 57. Ya'ni 23 + 34 = 57."},
 tn:"100 jadvali — dunyo bo'yicha 2-sinfning asosiy vositasi. Har bolaga qog'oz jadval bering, qalamni «yurgizsin»."},
{h:"Ayirish: olib tashlaymiz",sum:"68 − 23: o'nliklar 6 − 2 = 4, birliklar 8 − 3 = 5 → 45.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>68 tadan 23 tasini olib tashlaymiz. Avval o'nliklarni, keyin birliklarni.</p>",
 btns:[phaser(P4)],
 after:"<p>Ayirishda ham xonama-xona: o'nliklardan o'nliklar, birliklardan birliklar ayiriladi. 68 − 23 = <b>45</b>. Tekshirish: 45 + 23 = 68 ✓.</p>",
 q:{t:"86 − 54 = ?",opts:["22","30","32","42"],ok:2,why:"8 − 5 = 3 o'nlik, 6 − 4 = 2 birlik.",hint:"O'nliklar: 8 − 5. Birliklar: 6 − 4.",full:"86 − 54: o'nliklar 8 − 5 = 3, birliklar 6 − 4 = 2. Javob: 32. Tekshiramiz: 32 + 54 = 86 ✓."},
 tn:"Ayirishni doim qo'shish bilan tekshirtiring — bu odatga aylansin."},
{h:"Son o'qida sakraymiz",sum:"45 + 32: avval o'ntalab sakrash (+30 → 75), keyin bittalab (+2 → 77).",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Son o'qida qo'shish: avval <b>katta sakrashlar</b> (o'ntalab), keyin <b>kichiklari</b>. Kuzating.</p>",
 btns:[phaser(P5,'▶ Sakrash')],
 after:"<p>45 + 32: uchta katta sakrash (+10, +10, +10) — 75, ikkita kichik (+1, +1) — <b>77</b>. Gollandiya maktablarida bu «bo'sh son o'qi» usuli deyiladi — bolalar uni o'zlari chizadi.</p>",
 q:{t:"Son o'qida 27 dan 4 ta katta sakrash (10 dan) va 1 ta kichik sakrash qilindi. Qaysi songa kelindi?",opts:["31","67","68","41"],ok:2,why:"27 + 40 = 67, 67 + 1 = 68.",hint:"4 ta katta sakrash = + 40.",full:"27 + 40 = 67, yana + 1 = 68. «31» — katta sakrashlarni 1 deb sanash xatosi."},
 tn:"«Bo'sh son o'qi» (empty number line) — Gollandiya RME usuli: chiziq chiziladi, faqat kerakli sonlar yoziladi."},
{h:"Qachon o'nlikdan o'tilmaydi?",sum:"Qo'shishda birliklar yig'indisi 10 dan kichik bo'lsa — o'tilmaydi: 34 + 25 (4 + 5 = 9). 38 + 25 da 8 + 5 = 13 — o'tiladi.",a:"m06",
 start:function(){chk(null)},fin:function(){chk('34 va 25')},
 html:"<p>Qaysi juftlikni qo'shganda <b>o'nlikdan o'tilmaydi</b>? Har birini bosib, birliklarni tekshiring:</p>",
 btns:[["47 + 36",function(c,done){chk('47 va 36');mvK(done,3)}],["19 + 23",function(c,done){chk('19 va 23');mvK(done,3)}],["34 + 25",function(c,done){chk('34 va 25');mvK(done,3)}],["38 + 25",function(c,done){chk('38 va 25');mvK(done,3)}]],g2:1,
 after:"<p>Tekshiruv oddiy: <b>birliklarni qo'shing</b>. 10 dan kichik — o'nlikdan o'tilmaydi (bu darsning misollari). 10 yoki undan ko'p — o'tiladi (keyingi darsda o'rganamiz).</p>",
 q:{t:"Qaysi ayirishda o'nlikdan o'tilmaydi (birliklar yetadi)?",opts:["52 − 17","64 − 28","75 − 43","81 − 36"],ok:2,why:"75 − 43: birliklar 5 − 3 — yetadi.",hint:"Har birida kamayuvchining birliklari ayriluvchinikidan ko'pmi?",full:"52 − 17: 2 dan 7 ni olib bo'lmaydi. 64 − 28: 4 < 8. 81 − 36: 1 < 6. 75 − 43: 5 ≥ 3 — yetadi. Javob: 75 − 43 = 32."},
 tn:"Bu qadam keyingi ikki darsga (o'nlikdan o'tib qo'shish/ayirish) ko'prik. Bolalar har misoldan oldin «o'tiladimi?» deb tekshirsin."},
{h:"Noma'lum qo'shiluvchi",sum:"□ + 23 = 68: butun 68, ma'lum bo'lak 23 → □ = 68 − 23 = 45.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>«□ + 23 = 68» — □ qaysi son? Chizma chizamiz (Singapur usuli).</p>",
 btns:[phaser(P7)],
 after:"<p>Chizmada <b>butun</b> (68) va uning <b>ikki bo'lagi</b>. Bir bo'lak ma'lum (23) — ikkinchisini topish uchun butundan ayiramiz: 68 − 23 = <b>45</b>.</p>",
 q:{t:"□ + 32 = 79. □ = ?",opts:["111","57","37","47"],ok:3,why:"79 − 32 = 47.",hint:"Butun qancha? Ma'lum bo'lak qancha? Ikkinchi bo'lakni qanday topamiz?",full:"Butun — 79, ma'lum bo'lak — 32. □ = 79 − 32 = 47. Tekshiramiz: 47 + 32 = 79 ✓. «111» — qo'shib yuborish xatosi."},
 tn:"«Butun va bo'laklar» chizmasi — keyinchalik barcha matnli masalalarning asosi."},
{h:"Ikki amalli masala",sum:"68 shar: ertalab 23, kechqurun 34 sotildi → 68 − 23 = 45, 45 − 34 = 11.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p><i>«Do'konda 68 ta havo shari bor edi. Ertalab 23 tasi, kechqurun 34 tasi sotildi. Nechta shar qoldi?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Masalada <b>ikki amal</b>: avval ertalabgisini, keyin kechqurungisini ayiramiz: 68 − 23 = 45, 45 − 34 = <b>11</b>. Boshqa yo'l: avval sotilganlarni qo'shamiz (23 + 34 = 57), keyin 68 − 57 = 11 — javob bir xil!</p>",
 q:{t:"Lolada 35 ta marka bor edi. Unga 23 ta sovg'a qilishdi. Keyin u 41 tasini albomga yopishtirdi. Nechta marka qoldi?",opts:["13","27","19","17"],ok:3,why:"35 + 23 = 58, 58 − 41 = 17.",hint:"Avval nechta bo'lganini toping (sovg'adan keyin), keyin ayiring.",full:"Sovg'adan keyin: 35 + 23 = 58. Albomga 41 ta: 58 − 41 = 17. Tekshiramiz: 17 + 41 = 58 ✓."},
 tn:"Bolalar masalani avval chizma bilan ifodalasin, keyin amallarni yozsin. Ikki xil yo'l bilan yechishni rag'batlantiring."},
{h:"Bilasizmi?",sum:"Yaponiyada bolalar soroban (cho't) bilan hisoblab, keyin uni xayolan tasavvur qilib, juda tez hisoblashadi.",a:"m09",
 start:function(){abac()},fin:function(){abac()},
 html:"<p>🇯🇵 Yaponiyada ko'p bolalar <b>soroban</b> — yapon cho'ti bilan hisoblashni o'rganadi. Keyin ular cho'tni <b>xayolan</b> tasavvur qilib, ikki xonali sonlarni bir necha soniyada qo'shishadi. Bu usul «anzan» (xayoliy hisob) deyiladi.</p><p>Siz ham xuddi shunday qila olasiz: tayoqchalar va nuqtalarni ko'z oldingizga keltiring — o'nliklar alohida, birliklar alohida!</p>",
 tn:"Ko'zni yumib hisoblash o'yini: «Ko'z oldingizda 4 ta tayoqcha va 3 ta nuqta. Yana 2 tayoqcha va 5 nuqta qo'shing. Nechta?»"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li>Qo'shish: <b>o'nliklar + o'nliklar</b>, <b>birliklar + birliklar</b>: 34 + 25 = 59.</li><li>Ayirish: o'nliklardan o'nliklar, birliklardan birliklar: 68 − 23 = 45.</li><li>100 jadvalida: +10 — pastga, +1 — o'ngga.</li><li>Son o'qida: avval o'ntalab, keyin bittalab sakrang.</li><li>O'nlikdan o'tiladimi? — <b>birliklarni</b> tekshiring (4 + 5 = 9 < 10).</li><li>□ + 23 = 68 → □ = 68 − 23.</li><li>Ayirishni qo'shish bilan <b>tekshiring</b>.</li></ul></div>",
 tn:"Keyingi darsni «38 + 25 — o'nlikdan o'tiladimi?» savoli bilan boshlang (o'tiladi: 8 + 5 = 13)."}
];
function tab2(a,b,k){clear();var g=S.g;T(g,180,30,a+' + '+b,{'font-size':22,'font-weight':800,fill:'#1d2b3a'});var A=Math.floor(a/10)*10,B=Math.floor(b/10)*10;
 if(k>=1)T(g,180,74,'o‘nliklar: '+A+' + '+B+' = '+(A+B),{'font-size':17,'font-weight':800,fill:C.t1});if(k>=2){T(g,180,104,'birliklar: '+(a%10)+' + '+(b%10)+' = '+(a%10+b%10),{'font-size':17,'font-weight':800,fill:C.u});T(g,180,146,(A+B)+' + '+(a%10+b%10)+' = '+(a+b),{'font-size':22,'font-weight':800,fill:C.ok})}msg(k>=2?a+' + '+b+' = <b>'+(a+b)+'</b>':'Tugmalarni ketma-ket bosing')}
function g100(s,path){clear();var x0=40,y0=8,c=28,h=16;for(var n=1;n<=100;n++){var r=Math.floor((n-1)/10),q=(n-1)%10,x=x0+q*c,y=y0+r*h,f=n===s?C.hi:(path.indexOf(n)>=0?(n===path[path.length-1]?'#9fe0b7':'#d6f0e0'):'#fff');E('rect',{x:x,y:y,width:c-1,height:h-1,rx:2,fill:f,stroke:'#dde5ee'},S.g);T(S.g,x+c/2,y+12,String(n),{'font-size':9,'font-weight':(n===s||path.indexOf(n)>=0)?800:500,fill:'#33475b'})}}
function jl(a,b,s,jumps){clear();var x0=20,x1=340,y=120,k=(x1-x0)/(b-a),X=function(v){return x0+(v-a)*k};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=a;v<=b;v+=5){E('line',{x1:X(v),y1:y-(v%10?5:9),x2:X(v),y2:y+(v%10?5:9),stroke:'#33475b','stroke-width':v%10?1.3:2.2},S.g);if(v%10===0)T(S.g,X(v),y+24,String(v),{'font-size':11,'font-weight':700,fill:'#5b6b7b'})}
 E('circle',{cx:X(s),cy:y,r:6,fill:C.blue},S.g);T(S.g,X(s),y+24,String(s),{'font-size':12,'font-weight':800,fill:C.blue});
 jumps.forEach(function(j){var big=j[1]-j[0]===10,h=big?44:20;E('path',{d:'M'+X(j[0])+' '+(y-4)+' Q'+(X(j[0])+X(j[1]))/2+' '+(y-4-h)+' '+X(j[1])+' '+(y-4),fill:'none',stroke:big?C.a:C.ok,'stroke-width':2.2},S.g);T(S.g,(X(j[0])+X(j[1]))/2,y-8-h,big?'+10':'+1',{'font-size':10,'font-weight':800,fill:big?'#b0601f':C.ok})});
 if(jumps.length){var e=jumps[jumps.length-1][1];E('circle',{cx:X(e),cy:y,r:7,fill:C.ok},S.g);T(S.g,X(e),y+38,String(e),{'font-size':14,'font-weight':800,fill:C.ok})}}
function chk(p){clear();var g=S.g;if(!p){msg('Juftlikni tanlang');T(g,180,90,'birliklar + birliklar < 10 ?',{'font-size':18,'font-weight':800,fill:'#9aa8b6'});return}var a=+p.split(' va ')[0],b=+p.split(' va ')[1],s=a%10+b%10,ok=s<10;
 T(g,180,46,a+' + '+b,{'font-size':24,'font-weight':800,fill:'#1d2b3a'});T(g,180,90,'birliklar: '+(a%10)+' + '+(b%10)+' = '+s,{'font-size':18,'font-weight':800,fill:ok?C.ok:C.bad});T(g,180,130,ok?'✓ o‘nlikdan o‘tilmaydi':'✗ o‘nlikdan o‘tiladi (10 dan ko‘p)',{'font-size':15,'font-weight':800,fill:ok?C.ok:C.bad});msg(a+' + '+b+' = '+(a+b))}
function barm(k){clear();var g=S.g,x0=30,W=300;E('rect',{x:x0,y:60,width:W*45/68,height:40,fill:k>=2?C.ok:'#fff7ea',stroke:C.line,'stroke-width':2},g);E('rect',{x:x0+W*45/68,y:60,width:W*23/68,height:40,fill:C.a,stroke:C.line,'stroke-width':2},g);
 T(g,x0+W*45/136,86,k>=2?'45':'□',{'font-size':18,'font-weight':800,fill:k>=2?'#fff':'#1d2b3a'});T(g,x0+W*45/68+W*23/136,86,'23',{'font-size':16,'font-weight':800,fill:'#fff'});if(k>=1)Br(x0,x0+W,56,'68 — butun',true)}
function bar8(k){clear();var g=S.g,x0=20,W=320,f=W/68;var segs=[[23,C.a,'ertalab 23'],[34,C.c,'kechqurun 34'],[11,k>=2?C.ok:'#fff7ea',k>=2?'11 qoldi':'?']];var x=x0;
 segs.forEach(function(s,i){var w=s[0]*f;E('rect',{x:x,y:70,width:w,height:40,fill:(i===0&&k>=0)||(i===1&&k>=1)||i===2?s[1]:'#fff7ea',stroke:C.line,'stroke-width':1.6},g);T(g,x+w/2,95,(i===1&&k<1)?'':s[2],{'font-size':11,'font-weight':800,fill:i===2&&k<2?'#1d2b3a':'#fff'});x+=w});Br(x0,x0+W,66,'68 ta shar',true)}
function abac(){clear();var g=S.g;E('rect',{x:60,y:30,width:240,height:110,rx:10,fill:'#8a5a2b'},g);E('rect',{x:70,y:40,width:220,height:90,rx:6,fill:'#f6ead5'},g);E('line',{x1:70,y1:66,x2:290,y2:66,stroke:'#8a5a2b','stroke-width':4},g);
 for(var c=0;c<5;c++){var x=100+c*40;E('line',{x1:x,y1:40,x2:x,y2:130,stroke:'#8a5a2b','stroke-width':2},g);E('ellipse',{cx:x,cy:54,rx:13,ry:7,fill:'#6b3d12'},g);for(var b=0;b<4;b++)E('ellipse',{cx:x,cy:80+b*13,rx:13,ry:6,fill:'#a0703c'},g)}msg('Soroban — yapon cho‘ti')}
var PROBS=[
{t:"34 + 25 = ?",o:["59","69","58","509"],k:0,s:"30 + 20 = 50, 4 + 5 = 9."},
{t:"68 − 23 = ?",o:["45","35","91","55"],k:0,s:"6 − 2 = 4 o'nlik, 8 − 3 = 5 birlik."},
{t:"Avval qo'shing, keyin ayiring: 45 + 32 − 21",o:["56","98","34","66"],k:0,s:"45 + 32 = 77, 77 − 21 = 56."},
{t:"Qaysi juftlikni qo'shganda o'nlikdan o'tilmaydi?",o:["34 va 25","47 va 36","19 va 23","38 va 25"],k:0,s:"4 + 5 = 9 < 10. Qolganlarida birliklar 10 dan oshadi."},
{t:"□ + 23 = 68. □ = ?",o:["45","55","91","35"],k:0,s:"68 − 23 = 45."},
{t:"Ali 76 ta barg yig'di. Vali Alidan 34 ta kam, Sardor Validan 21 ta kam yig'di. Sardor nechta barg yig'gan?",o:["21","42","55","13"],k:0,s:"Vali: 76 − 34 = 42. Sardor: 42 − 21 = 21."},
{t:"Do'konda 68 ta shar bor edi. Ertalab 23 tasi, kechqurun 34 tasi sotildi. Nechta qoldi?",o:["11","45","57","21"],k:0,s:"68 − 23 = 45, 45 − 34 = 11."},
{t:"Lolada 35 ta marka bor edi, 23 ta sovg'a qilishdi, keyin 41 tasini albomga yopishtirdi. Nechta qoldi?",o:["17","13","27","19"],k:0,s:"35 + 23 = 58, 58 − 41 = 17."},
{t:"100 jadvalida 41 dan 2 qator pastga va 7 qadam o'ngga yursak, qaysi son?",o:["68","48","61","27"],k:0,s:"41 + 20 = 61, 61 + 7 = 68."},
{t:"97 − 45 = ?",o:["52","42","62","53"],k:0,s:"9 − 4 = 5, 7 − 5 = 2."},
{t:"□ − 32 = 46. □ = ?",o:["78","14","68","88"],k:0,s:"Kamayuvchi = ayirma + ayriluvchi: 46 + 32 = 78."},
{t:"79 − □ = 35. □ = ?",o:["44","114","34","54"],k:0,s:"79 − 35 = 44."},
{t:"Qaysi ayirishda o'nlikdan o'tilmaydi?",o:["75 − 43","52 − 17","64 − 28","81 − 36"],k:0,s:"5 ≥ 3 — birliklar yetadi."},
{t:"Ikki son yig'indisi 88. Biri 43. Ikkinchisi qancha?",o:["45","131","55","35"],k:0,s:"88 − 43 = 45."},
{t:"Sinfda 24 ta qiz va 15 ta o'g'il bor. 12 kishi sayrga ketdi. Sinfda nechta qoldi?",o:["27","39","17","51"],k:0,s:"24 + 15 = 39, 39 − 12 = 27."},
{t:"52 + 36 − 41 = ?",o:["47","88","37","57"],k:0,s:"88 − 41 = 47."},
{t:"Avtobusda 46 kishi bor edi. Bekatda 21 kishi tushdi, 13 kishi chiqdi. Avtobusda necha kishi bo'ldi?",o:["38","34","80","12"],k:0,s:"46 − 21 = 25, 25 + 13 = 38."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["43 + 45","62 + 24","51 + 33","70 + 15"],k:0,s:"88, 86, 84, 85 — eng kattasi 43 + 45 = 88."},
{t:"Bir songa 23 qo'shib, keyin 12 ni ayirdik va 50 chiqdi. Boshlang'ich son qaysi?",o:["39","61","85","15"],k:0,s:"Oxiridan: 50 + 12 = 62, 62 − 23 = 39."},
{t:"Ikkita ketma-ket o'nlik sonlarining yig'indisi 70. Ular qaysilar?",o:["30 va 40","20 va 50","35 va 35","60 va 10"],k:0,s:"Ketma-ket o'nliklar: 30 va 40, 30 + 40 = 70."}
];
function PRACT_STAGE(){S.ph=2;P1[2]()}
var PREP_DATA={teach:["O'nlikdan o'tmay qo'shish va ayirish: xonama-xona (o'nliklar bilan o'nliklar, birliklar bilan birliklar).","100 jadvalida va bo'sh son o'qida hisoblash.","O'nlikdan o'tilishini tekshirish (birliklar yig'indisi < 10).","Noma'lum qo'shiluvchi; ikki amalli masalalar."],
 mist:["Natijalarni yonma-yon yozadi (52 + 36 = 816).","O'nliklarni birliklarga qo'shib yuboradi.","Ikki amalli masalada faqat bitta amalni bajaradi.","□ + 23 = 68 da qo'shib yuboradi (91)."],
 need:["Cho'p bog'lamlari va dona cho'plar.","Qog'oz 100 jadvali (har bolaga).","Doskada bo'sh son o'qi."],
 board:["<span class='w2'>34 + 25 = (30 + 20) + (4 + 5) = 59</span>.","100 jadvali: +10 ↓, +1 →.","Son o'qi: 45 → +10 +10 +10 → +1 +1 → 77.","<span class='w2'>68 − 23 = 45</span>, tekshirish 45 + 23 = 68.","Chizma: butun 68 = □ + 23."]};
