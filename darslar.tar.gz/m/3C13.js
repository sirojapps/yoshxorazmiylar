var CODE='3C13',TITLE='3-sinf · Ikki va uch xonali songa ko‘paytirish; o‘rtasida nol bo‘lgan sonlar';
function c13(lines,msg,note){clear();var g=S.g,n=lines.length,dy=Math.min(32,150/n),cw=17,xR=200,red=false;
 if(n===1){W3eq(lines);if(msg)W3msg(msg,note);return}
 lines.forEach(function(l,k){var y=26+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){red=true;continue}if(c===']'){red=false;continue}ch.push([c,red])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*5,y1:y-dy/2+4,x2:xR+cw/2,y2:y-dy/2+4,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' ')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':22,'font-weight':800,fill:q[1]?C.bad:(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(msg)W3msg(msg,note)}
var P1=[function(){W3eq(['23 · 30 = ?'])},
 function(){W3eq(['23 · 30 = 23 · 3 · 10']);W3msg('30 = 3 · 10')},
 function(){W3eq(['23 · 3 = 69','69 · 10 = [690]']);W3msg('Avval 3 ga, keyin 10 ga: 23 · 30 = <b>690</b>')}];
var P2=[function(){W3area([14],23,{lbl:'23 · 14 = ?'});W3msg('14 ni 10 va 4 ga ajratamiz')},
 function(){W3area([10,4],23,{show:1,lbl:'14 = 10 + 4'})},
 function(){W3area([10,4],23,{show:2,lbl:'230 + 92 = 322'});W3msg('23 · 14 = 23 · 10 + 23 · 4 = 230 + 92 = <b>322</b>')}];
var P3=[function(){c13(['   23','×  14','─────'],'Ustun usuli: pastdagi sonning har raqamiga alohida ko‘paytiramiz')},
 function(){c13(['   23','×  14','─────','   [92]'],'1-qator: 23 · <b>4</b> = 92')},
 function(){c13(['   23','×  14','─────','   92','+ [23] '],'2-qator: 23 · <b>1 o‘nlik</b> = 23 o‘nlik — <b>bir xona chapga</b> suriladi','Bo‘sh birlik — aslida 0: 230')},
 function(){c13(['   23','×  14','   92','+ 23 ','  [322]'],'92 + 230 = <b>322</b>')}];
var P5=[function(){W3area([123],12,{lbl:'12 · 123 = ?'})},
 function(){W3area([100,20,3],12,{show:1,lbl:'123 = 100 + 20 + 3'})},
 function(){W3area([100,20,3],12,{show:2,lbl:'1200 + 240 + 36 = 1476'});W3msg('Uch xonali son — uch bo‘lak: 12 · 123 = <b>1476</b>')}];
var P7=[function(){c13(['   35','× 102','─────'],'O‘rtada 0 bo‘lgan ko‘paytuvchi')},
 function(){c13(['   35','× 102','─────','   [70]'],'35 · 2 = 70')},
 function(){c13(['   35','× 102','─────','   70','+[35]  '],'35 · <b>0 o‘nlik</b> = 0 — bu qatorni yozmaymiz! 35 · 1 yuzlik — <b>ikki xona</b> chapga')},
 function(){c13(['   35','× 102','   70','+35  ',' [3570]'],'70 + 3500 = <b>3570</b>','Tekshiruv: 35 · 100 + 35 · 2 = 3500 + 70')}];
var STEPS=[
{h:"Yaxlit o'nlikka ko'paytirish",sum:"23 · 30 = 23 · 3 · 10 = 690.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ikki xonali songa ko'paytirishdan oldin — yaxlit o'nlikka.</p>",btns:[phaser(P1)],
 after:"<p><b>·30 = ·3 ·10</b>. Avval raqamga ko'paytiramiz, keyin oxiriga 0 yozamiz.</p>",
 q:{t:"34 · 20 = ?",opts:["680","68","6 800","54"],ok:0,why:"34 · 2 = 68, ·10 = 680.",hint:"20 = 2 · 10.",full:"34 · 2 = 68, 68 · 10 = 680. «68» — 0 unutilgan, «54» — qo'shilgan."},
 tn:"Bu qadam — ustun usulidagi 2-qatorning ma'nosi: bu yerda 0 «ko'rinadi»."},
{h:"Maydon modeli: 23 · 14",sum:"23 · 14 = 23 · 10 + 23 · 4 = 230 + 92 = 322.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ko'paytuvchini o'nlik va birlikka ajratamiz — ikkita oson ko'paytirish.</p>",btns:[phaser(P2)],
 after:"<p>Ikki xonali songa ko'paytirish = <b>o'nliklarga</b> ko'paytirish + <b>birliklarga</b> ko'paytirish. Bu — taqsimot xossasi.</p>",
 q:{t:"16 · 12 = ?",opts:["192","160","48","1632"],ok:0,why:"160 + 32 = 192.",hint:"16 · 10 + 16 · 2.",full:"16 · 10 = 160, 16 · 2 = 32, 160 + 32 = 192. «160» — faqat bitta bo'lak, «48» — 16 · 2 + 16."},
 tn:"Katakli daftarda 23 × 14 to'rtburchakni chizib, 10 va 4 chiziq bilan bo'ling — Singapur/AQSh «area model»."},
{h:"Ustun usuli",sum:"23 × 14: 92 (23 · 4) va 23 o'nlik (bir xona chapga) → 322.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Maydon modelidagi ikki bo'lak ustunda ikki qatorga aylanadi.</p>",btns:[phaser(P3)],
 after:"<p>1-qator — <b>birliklarga</b> ko'paytma, 2-qator — <b>o'nliklarga</b> ko'paytma (bir xona chapga). So'ng qatorlarni qo'shamiz.</p>",
 q:{t:"Ustunda 31 × 25. Ikkinchi qatorda nima yoziladi (surilgan holda)?",opts:["62","155","31","775"],ok:0,why:"31 · 2 = 62 o'nlik.",hint:"Ikkinchi qator — o'nliklar raqamiga ko'paytma.",full:"1-qator: 31 · 5 = 155; 2-qator: 31 · 2 = 62 (o'nliklar — bir xona chapga, ya'ni 620). Javob: 155 + 620 = 775."},
 tn:"2-qatorning bo'sh birlik o'rniga avval 0 ni kichik qilib yozdiring — keyin uni tashlab yozishga o'tasiz."},
{h:"Tuzoq: surishni unutish",sum:"23 · 14 ≠ 92 + 23 = 115: ikkinchi qator o'nliklar — 230.",a:"m04",start:function(){c13(['   23','×  14','   92','+  23','  ???'],'Bir bola shunday yozdi. Javob nechaga teng?')},fin:function(){c13(['   23','×  14','   92','+ 23 ','  [322]'])},
 html:"<p>Bola ikkinchi qatorni <b>surmasdan</b> yozdi. To'g'ri javobni tanlang:</p>",
 btns:[["322",function(c,done){c13(['   23','×  14','   92','+ 23 ','  [322]'],'To‘g‘ri! 23 — bu 23 <b>o‘nlik</b> = 230. 92 + 230 = 322');done()}],["115",function(){c13(['92 + 23 = 115'],'Yo‘q: bu bolaning xatosi — 23 ni birlik deb qo‘shgan. Baholang: 23 · 14 kamida 23 · 10 = 230 dan katta!','Qayta tanlang')}],["2312",function(){c13(['23 · 1 | 23 · 4'],'Yo‘q: natijalar yonma-yon yozilmaydi, qo‘shiladi','Qayta tanlang')}]],g3:1,
 after:"<p>Tekshirish uchun <b>baholang</b>: 23 · 14 — 20 · 10 = 200 dan katta, 30 · 20 = 600 dan kichik. 115 bu oraliqda emas — xato!</p>",
 q:{t:"42 · 13 = ?",opts:["546","168","426","4 236"],ok:0,why:"126 + 420 = 546.",hint:"42 · 3 va 42 · 10 ni qo'shing.",full:"42 · 3 = 126, 42 · 10 = 420, jami 546. «168» — 126 + 42 (surish unutilgan)."},
 tn:"Har ko'paytirishdan oldin bolalar taxminiy javobni aytsin — baholash xatolarni ushlaydi."},
{h:"Uch xonali songa",sum:"12 · 123 = 1200 + 240 + 36 = 1476.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Uch xonali ko'paytuvchi — uch bo'lak: yuzlik, o'nlik, birlik.</p>",btns:[phaser(P5)],
 after:"<p>Ustunda bu <b>uchta qator</b> bo'ladi: birliklarga, o'nliklarga (bir xona surib), yuzliklarga (ikki xona surib). Qulayi — ko'p xonali sonni yuqoriga yozish: 123 × 12.</p>",
 q:{t:"11 · 214 = ?",opts:["2354","2140","428","2 214"],ok:0,why:"2140 + 214 = 2354.",hint:"214 · 10 + 214 · 1.",full:"214 · 11 = 214 · 10 + 214 = 2140 + 214 = 2354. «2140» — bitta bo'lak unutilgan."},
 tn:"Uch rangli bo'laklar — uch qator. Har qator rangini ustun usulida ham saqlang."},
{h:"O'rtasida nol: ko'paytiriladigan sonda",sum:"204 · 3 = 612: 0 o'nlik · 3 = 0 o'nlik — o'nliklar xonasiga 0 yoziladi (yoki ko'chgan son).",a:"m06",start:function(){c13(['  204','×   3','─────'],'204 · 3 = ?')},fin:function(){c13(['  204','×   3','  [612]'])},
 html:"<p><b>204 · 3</b>. To'g'ri javobni tanlang:</p>",
 btns:[["612",function(c,done){c13(['  204','×   3','  [612]'],'4 · 3 = 12: 2 yoziladi, 1 xotirada. 0 · 3 = 0, + 1 = <b>1</b>. 2 · 3 = 6');done()}],["72",function(){c13(['24 · 3 = 72'],'Yo‘q: 0 ni tashlab yubordingiz — 204 bu 24 emas','Qayta tanlang')}],["6012",function(){c13(['6 | 0 | 12'],'Yo‘q: 12 dan 1 o‘nlik keyingi xonaga ko‘chadi','Qayta tanlang')}]],g3:1,
 after:"<p>0 · 3 = 0, lekin <b>xotiradagi son</b> unga qo'shiladi: 0 + 1 = 1. Xotira bo'lmasa — 0 yoziladi: 302 · 3 = 9<b>0</b>6.</p>",
 q:{t:"507 · 4 = ?",opts:["2028","228","2008","20 028"],ok:0,why:"28 → 8, xotira 2; 0 · 4 + 2 = 2; 5 · 4 = 20.",hint:"7 · 4 = 28 dan 2 ni o'nliklarga ko'chiring.",full:"7 · 4 = 28 (8 yoziladi, 2 xotirada), 0 · 4 + 2 = 2, 5 · 4 = 20 → 2028. «2008» — xotira unutilgan, «228» — 0 tashlangan."},
 tn:"O'nlik bloklar bilan: 204 da o'nlik yo'q, lekin ko'chish o'nlik «paydo qiladi»."},
{h:"O'rtasida nol: ko'paytuvchida",sum:"35 · 102 = 70 + 3500 = 3570: nol qatorini yozmay, ikki xona suriladi.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=3;P7[3]()},
 html:"<p>Ko'paytuvchi <b>102</b> — o'rtasida nol. Qatorlar nechta bo'ladi?</p>",btns:[phaser(P7)],
 after:"<p>Ko'paytuvchida 0 bo'lsa, unga mos qator — faqat nollar. Uni yozmaymiz, lekin keyingi qatorni <b>bir xona ko'proq</b> suramiz. Eng ko'p xato: 35 ni bir xonaga surib, 70 + 350 = 420 deb yozish.</p>",
 q:{t:"24 · 103 = ?",opts:["2472","312","2412","2 400"],ok:0,why:"2400 + 72 = 2472.",hint:"24 · 100 + 24 · 3.",full:"24 · 3 = 72, 24 · 100 = 2400, jami 2472. «312» — 72 + 240: bir xona surilgan (24 · 13)."},
 tn:"Maydon modelida 102 = 100 + 2 — faqat ikki bo'lak. Bu nima uchun 0 qator yozilmasligini ko'rsatadi."},
{h:"Ko'paytuvchilar oxirida nol",sum:"46 · 20 = 920; 125 · 40 = 5000: nollarni chetga qo'yib ko'paytiramiz.",a:"m08",start:function(){W3eq(['125 · 40 = ?']);W3msg('Nolni chetga qo‘yamiz: 125 · 4, keyin 0')},fin:function(){W3eq(['125 · 4 = 500','125 · 40 = [5000]'])},
 html:"<p>Ko'paytuvchi oxirida 0 bo'lsa — uni chetga yozib, nolsiz ko'paytiramiz.</p>",
 btns:[["Hisoblash",function(c,done){W3eq(['125 · 4 = 500','+ 0','125 · 40 = [5000]']);W3msg('125 · 4 = 500 — o‘zida ikkita 0 bor! Yana bitta qo‘shamiz: <b>5000</b>');done()}]],
 after:"<p>Ustunda yaxlit sonni shunday yozamiz: raqamlarni tekislab, <b>nollarni o'ngga chiqarib</b>. 46 × 20: 46 · 2 = 92, keyin 0 → 920.</p>",
 q:{t:"250 · 40 = ?",opts:["10 000","1 000","100 000","1 040"],ok:0,why:"25 · 4 = 100, + ikkita 0.",hint:"25 · 4 = ?",full:"25 · 4 = 100, nollar 1 + 1 = 2 → 10 000. «1 000» — 100 ning o'z nollarini hisoblamagan."},
 tn:"Tez og'zaki tekshiruv: 125 · 8 = 1000, 25 · 4 = 100 — «do'st juftlar»."},
{h:"Bilasizmi? Raqamlar sayohati",sum:"Biz ishlatadigan o'nli pozitsion raqamlar Hindistondan al-Xorazmiy orqali, keyin Fibonachchi (1202) orqali Yevropaga yetib borgan.",a:"m09",start:function(){W3eq(['Hindiston → Bag‘dod','al-Xorazmiy (IX asr)','→ Yevropa (1202)'],{fs:18});W3msg('Ustun usuli — xonalar tizimi bo‘lgani uchun ishlaydi')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Ustunda ko'paytirish faqat <b>o'nli pozitsion</b> sanoqda ishlaydi. Bu tizim Hindistonda paydo bo'lgan; vatandoshimiz <b>al-Xorazmiy</b> IX asrda u haqida arifmetika kitobini yozgan. Italiyalik <b>Fibonachchi</b> 1202-yilda «Liber Abaci» kitobi bilan bu raqamlarni Yevropada keng tarqatgan.</p><p>⭐ Rim raqamlarida (XXIII · XIV) ustunda ko'paytirib bo'lmaydi!</p>",
 tn:"Bolalarga 23 · 14 ni Rim raqamlarida yozib ko'rsating — nega pozitsion tizim qulayligini o'zlari aytsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3area([10,4],23,{show:2,lbl:'23 · 14 = 230 + 92 = 322'})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>23 · 30 = 23 · 3 · 10 = 690.</li><li>23 · 14 = 23 · 10 + 23 · 4 = 230 + 92 = 322.</li><li>Ustunda 2-qator <b>bir xona chapga</b>, 3-qator — ikki xona.</li><li>O'rtada 0: 204 · 3 = 612 (0 ga xotira qo'shiladi), 302 · 3 = 906.</li><li>Ko'paytuvchida 0: 35 · 102 — nol qatori yozilmaydi, keyingisi ikki xona suriladi: 3570.</li><li>Doim baholang: 23 · 14 — 200 dan katta, 600 dan kichik.</li></ul></div>",
 tn:"Keyingi mavzu: burchakli bo'lish."}
];
var PROBS=[
{t:"27 · 30 = ?",o:["810","81","8 100","57"],k:0,s:"27 · 3 = 81, ·10."},
{t:"18 · 11 = ?",o:["198","180","188","1 818"],k:0,s:"180 + 18."},
{t:"25 · 12 = ?",o:["300","250","75","275"],k:0,s:"250 + 50."},
{t:"34 · 21 = ?",o:["714","102","680","748"],k:0,s:"680 + 34."},
{t:"47 · 15 = ?",o:["705","282","235","715"],k:0,s:"470 + 235."},
{t:"306 · 2 = ?",o:["612","72","6012","602"],k:0,s:"6 · 2 = 12; 0 · 2 + 1 = 1; 3 · 2 = 6."},
{t:"408 · 5 = ?",o:["2040","240","2000","20 040"],k:0,s:"40 → 0, xotira 4; 0 + 4 = 4; 20."},
{t:"105 · 6 = ?",o:["630","90","600","6030"],k:0,s:"600 + 30."},
{t:"23 · 102 = ?",o:["2346","276","2326","2 336"],k:0,s:"2300 + 46."},
{t:"41 · 205 = ?",o:["8405","1025","8205","9 225"],k:0,s:"8200 + 205."},
{t:"13 · 120 = ?",o:["1560","156","15 600","1 320"],k:0,s:"13 · 12 = 156, ·10."},
{t:"Ustunda 52 × 34 yozildi: 1-qator 208, 2-qator 156 (surilgan). Javob?",o:["1768","364","1 568","3 640"],k:0,s:"208 + 1560 = 1768."},
{t:"Bola 36 · 24 = 144 + 72 = 216 deb yozdi. To'g'ri javob?",o:["864","216","720","144"],k:0,s:"144 + 720 = 864: 2-qator surilmagan."},
{t:"Qaysi javob 48 · 19 ga eng yaqin bo'lishi mumkin (baholang)?",o:["912","192","9 120","480"],k:0,s:"≈ 50 · 20 = 1000; 48 · 19 = 912."},
{t:"Bir qutida 24 ta qalam. 105 ta qutida nechta?",o:["2520","240","2 400","2 504"],k:0,s:"24 · 100 + 24 · 5 = 2520."},
{t:"Avtobusda 45 o'rin. 12 ta avtobusda nechta o'rin?",o:["540","450","90","4 590"],k:0,s:"450 + 90."},
{t:"1 kg olma 15 ming so'm. 23 kg necha ming so'm?",o:["345","115","45","330"],k:0,s:"300 + 45."},
{t:"□ = 37 · 25. □ : 25 = ?",o:["37","25","925","62"],k:0,s:"Ko'paytmani ko'paytuvchiga bo'lsak — ikkinchisi."},
{t:"Qaysi ko'paytma eng katta?",o:["21 · 50","24 · 40","31 · 30","19 · 50"],k:0,s:"1050; 960; 930; 950."},
{t:"Sinfda 28 ta o'quvchi, har biri 12 ta daftar oldi. Jami 300 dan ko'pmi?",o:["Ha, 336 ta","Yo'q, 280 ta","Ha, 312 ta","Yo'q, 240 ta"],k:0,s:"280 + 56 = 336."}
];
function PRACT_STAGE(){W3area([10,4],23,{show:1,lbl:'Ajrating — ko‘paytiring — qo‘shing'})}
var PREP_DATA={teach:["Yaxlit o'nlikka ko'paytirish.","Ikki xonali songa: maydon modeli va ustun usuli.","Uch xonali songa ko'paytirish.","O'rtasida nol bo'lgan sonlar (ko'paytiriladigan va ko'paytuvchida), baholash."],
 mist:["2-qatorni surmaydi: 23 · 14 = 115.","204 · 3 = 72 (nolni tashlaydi) yoki 602 (xotirani unutadi).","35 · 102 = 420 (nol qatori o'rniga bir xona suradi).","125 · 40 = 500 (natijadagi nollarni hisoblamaydi)."],
 need:["Katakli daftar (maydon modeli, ustun).","Rangli qalamlar — har qator uchun bir rang."],
 board:["<span class='w2'>23 · 30 = 690</span>","<span class='w2'>23 · 14 = 230 + 92 = 322</span>","<span class='w2'>204 · 3 = 612</span>","<span class='w2'>35 · 102 = 3500 + 70 = 3570</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
