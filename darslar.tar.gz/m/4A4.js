var CODE='4A4',TITLE='4-sinf · Million va milliard, raqamlardan son tuzish';
var P1=[function(){a4table(999999999,{top:'999 999 999'});msg('Eng katta to‘qqiz xonali son. Unga 1 qo‘shamiz')},
 function(){a4table(999999999,{hl:[0,1,2,3,4,5,6,7,8],top:'999 999 999 + 1'});msg('Hamma to‘qqizlar 10 ga aylanib, chapga o‘tadi…')},
 function(){a4table(1000000000,{hl:[9],top:'1 000 000 000 — bir milliard'});msg('Yangi, <b>milliardlar sinfi</b> ochildi: 1 milliard = 1 000 million')}];
function a44dig(d,o){o=o||{};a4cards(d,{title:o.title||'Raqamlarni tartib bilan bosing',cw:62,onTap:o.onTap,y:38,h:68,fs:22});var g=S.g;if(o.built!=null){E('rect',{x:70,y:120,width:220,height:40,rx:8,fill:'#fff',stroke:C.blue,'stroke-width':1.6},g);T(g,180,147,o.built||'…',{'font-size':22,'font-weight':800,fill:C.blue})}}
var A44D=['4','0','7','1','9'],A44OK=['1','0','4','7','9'];
function a44act(done){S.a44b='';var used={};var draw=function(){a44dig(A44D,{built:S.a44b,onTap:tap});Object.keys(used).forEach(function(k){a4mark(S.cardEls[k],true)})};
 var tap=function(i,r){if(used[i])return;var need=A44OK[S.a44b.length];if(A44D[i]===need){used[i]=1;S.a44b+=need;draw();if(S.a44b.length===5){msg('Eng kichik son: <b>10 479</b>');done&&done()}else msg(S.a44b.length===1?'0 birinchi bo‘la olmaydi — shuning uchun 1. Endi eng kichigi — 0!':'Qolganlardan eng kichigi')}else{a4mark(r,false);msg(S.a44b.length===0&&A44D[i]==='0'?'0 bilan boshlansa — son besh xonali bo‘lmaydi!':'Hozir qolgan raqamlardan eng kichigini tanlang')}};draw();msg('Birinchi raqamni tanlang')}
var STEPS=[
{h:"Milliard",sum:"999 999 999 + 1 = 1 000 000 000 — bir milliard.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Millionlar sinfi ham to'lsa, nima bo'ladi? Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>Sinflar: birlar → minglar → millionlar → <b>milliardlar</b>. Har biri oldingisidan <b>1 000 marta</b> katta: 1 milliard = 1 000 million = 1 000 000 ming.</p>",
 q:{t:"1 milliardda nechta million bor?",opts:["1 000","100","10","1 000 000"],ok:0,why:"Har sinf oldingisidan 1 000 marta katta.",hint:"1 000 000 000 ni millionlar sinfi bo'yicha o'qing: 1 000 | 000 | 000.",full:"1 000 000 000 = 1 000 · 1 000 000 → 1 000 million. «1 000 000» — bu minglar soni; «100» — nollarni noto'g'ri sanash."},
 tn:"Sinflarni «uy qavatlari» deb tasvirlang: har qavatda 3 xonali kvartira (birlik, o'nlik, yuzlik)."},
{h:"Milliardli sonni o'qish",sum:"2 040 500 300 — ikki milliard qirq million besh yuz ming uch yuz.",a:"m02",
 start:function(){a4table(2040500300,{top:'2 040 500 300'});msg('O‘ngdan uchtadan: 300 | 500 | 040 | 2')},fin:function(){a4table(2040500300,{top:'2 040 500 300'});msg('<b>ikki milliard qirq million besh yuz ming uch yuz</b>')},
 html:"<p>2 040 500 300 ni o'qing. To'g'ri variantni tanlang:</p>",
 btns:a4ch(["ikki milliard qirq million besh yuz ming uch yuz","ikki milliard to'rt yuz million besh yuz ming uch yuz","yigirma milliard qirq besh million uch yuz"],0,function(){msg('2 milliard · 040 million · 500 ming · 300 ✓')},function(i){msg(i===1?'Millionlar sinfi — 040, ya‘ni «qirq»':'Sinflarni o‘ngdan ajrating: milliardlarda faqat 2')}),
 after:"<p>Bir xil usul: sinf + sinf nomi. Milliardlar sinfida ham uchtagacha raqam bo'ladi: 735 000 000 000 — «yetti yuz o'ttiz besh milliard».</p>",
 q:{t:"«O'n besh milliard yetti million» qaysi son?",opts:["15 007 000 000","15 700 000 000","15 000 007 000","1 507 000 000"],ok:0,why:"15 | 007 | 000 | 000.",hint:"Skelet: __ | ___ | ___ | ___.",full:"Milliardlar — 15, millionlar — 007, minglar — 000, birlar — 000: 15 007 000 000. «15 700 000 000» — 7 ni yuz million deb yozish."},
 tn:"Skelet kartochka: __ | ___ | ___ | ___ — diktant uchun."},
{h:"Sinflar orasidagi munosabat",sum:"1 milliard = 1 000 million = 1 000 000 ming.",a:"m03",
 start:function(){a4cards(['1 ming','1 million','1 milliard'],{title:'Har biri oldingisidan necha marta katta?',cw:110});msg('Har qadam — × 1 000')},fin:function(){a4cards(['1 000','1 000 000','1 000 000 000'],{title:'× 1 000 · × 1 000',cw:115,fs:13});msg('1 milliard = 1 000 · 1 000 · 1 000')},
 html:"<p>3 milliard necha millionga teng?</p>",
 btns:a4ch(["3 000 million","300 million","30 million","3 000 000 million"],0,function(){a4cards(['1 000','1 000 000','1 000 000 000'],{title:'× 1 000 · × 1 000',cw:115,fs:13});msg('3 · 1 000 = <b>3 000 million</b>')},function(i){msg(i===1?'1 milliard = 1 000 million, 100 emas':'Har sinf o‘tishida × 1 000')}),g2:1,
 after:"<p>Shuning uchun bitta sinf nomini ikkinchisiga o'tkazish uchun 000 qo'shamiz yoki olib tashlaymiz: 45 million = 45 000 ming = 45 000 000.</p>",
 q:{t:"7 500 million — bu necha milliard va necha million?",opts:["7 milliard 500 million","75 milliard","750 milliard","7 milliard 50 million"],ok:0,why:"7 500 million = 7 000 million + 500 million.",hint:"1 000 million = 1 milliard.",full:"7 500 = 7 · 1 000 + 500 → 7 milliard 500 million (7 500 000 000). «75 milliard» — nollarni yo'qotish."},
 tn:"Pul misoli: 1 000 so'mlik 1 000 dona = 1 million so'm."},
{h:"Eng katta son tuzish",sum:"4, 0, 7, 1, 9 dan eng katta besh xonali son: 97 410.",a:"m04",
 start:function(){a44dig(A44D,{title:'4, 0, 7, 1, 9 — har biri bir marta'});msg('Eng katta son uchun chapga eng katta raqam')},fin:function(){a44dig(A44D,{title:'Kamayish tartibida',built:'97 410'});msg('9 > 7 > 4 > 1 > 0 → <b>97 410</b>')},
 html:"<p>4, 0, 7, 1, 9 raqamlaridan (har biri bir marta) eng katta besh xonali son qaysi?</p>",
 btns:a4ch(["97 410","94 710","90 714","97 401"],0,function(){a44dig(A44D,{title:'Kamayish tartibida',built:'97 410'});msg('Chap xona eng «qimmat» — unga eng katta raqam: <b>97 410</b>')},function(i){msg(i===3?'1 va 0 ni almashtiring: o‘nliklarga katta raqam':'Raqamlarni kamayish tartibida yozing: 9, 7, …')}),g2:1,
 after:"<p>Eng katta son — raqamlar <b>kamayish</b> tartibida. Chunki chapdagi xona qiymati eng katta: chapga qo'yilgan raqam o'n ming marta «og'irroq».</p>",
 q:{t:"5, 0, 0, 3, 8 raqamlaridan eng katta besh xonali son:",opts:["85 300","85 003","80 053","58 300"],ok:0,why:"Kamayish tartibi: 8, 5, 3, 0, 0.",hint:"Nollar qayerga tushadi?",full:"8 > 5 > 3 > 0 = 0 → 85 300. «85 003» — 3 ni oxiriga qo'yish."},
 tn:"Raqam kartochkalari bilan juftlikda o'yin: kim katta son tuzadi."},
{h:"Eng kichik son — tuzoq: 0",sum:"4, 0, 7, 1, 9 dan eng kichik besh xonali son: 10 479.",a:"m05",
 start:function(){a44act(S.a44d)},fin:function(){a44dig(A44D,{title:'Eng kichik besh xonali son',built:'10479'});[0,1,2,3,4].forEach(function(i){a4mark(S.cardEls[i],true)});msg('<b>10 479</b>')},
 act:function(c,done){S.a44d=done;a44act(done)},
 html:"<p>Endi <b>eng kichik</b> besh xonali sonni tuzing: raqamlarni kerakli tartibda <b>bosing</b>. Ehtiyot bo'ling — 0!</p>",
 after:"<p>Qoida: o'sish tartibida yozamiz, lekin <b>0 birinchi turolmaydi</b> (aks holda son to'rt xonali bo'ladi). Shuning uchun: eng kichik nolmas raqam birinchi, keyin 0, keyin qolganlari o'sish tartibida.</p>",
 q:{t:"6, 0, 2, 0, 5 raqamlaridan eng kichik besh xonali son:",opts:["20 056","00 256","20 065","25 006"],ok:0,why:"2, keyin ikkita 0, keyin 5, 6.",hint:"Birinchi raqam — eng kichik nolmas raqam.",full:"Birinchi — 2, keyin 0, 0, 5, 6: 20 056. «00 256» — besh xonali son emas; «20 065» — 5 va 6 tartibi xato."},
 tn:"Bank 4A4 eng ko'p uchraydigan tuzoq — 0 ni birinchiga qo'yish."},
{h:"Tuzoq: eng katta JUFT son",sum:"3, 8, 5, 1 dan eng katta juft son: 5 318 (8531 — toq!).",a:"m06",
 start:function(){a44dig(['3','8','5','1'],{title:'3, 8, 5, 1 — eng katta juft son?'});msg('Juft bo‘lishi uchun oxirgi raqam juft bo‘lishi kerak')},fin:function(){a44dig(['3','8','5','1'],{title:'Oxiri — 8',built:'5 318'});msg('<b>5 318</b>')},
 html:"<p>3, 8, 5, 1 raqamlaridan (har biri bir marta) <b>eng katta juft</b> to'rt xonali son qaysi?</p>",
 btns:a4ch(["8 531","5 318","8 513","3 518"],1,function(){a44dig(['3','8','5','1'],{title:'Oxiri — 8',built:'5 318'});msg('Yagona juft raqam 8 — u oxirga ketadi. Qolganlar kamayish tartibida: 5, 3, 1 → <b>5 318</b>')},function(i){msg(i<2?'Oxirgi raqam 1 yoki 3 — son toq!':'Juft, lekin eng kattasi emas: 5, 3, 1 tartibida bo‘lsin')}),g2:1,
 after:"<p>Shartli masala tartibi: avval <b>shartni bajaradigan</b> joyni to'ldiramiz (juft → oxiriga juft raqam), keyin qolgan joylarga eng yaxshi tartib. «Eng katta» degan so'zga shoshilmang!</p>",
 q:{t:"2, 7, 4, 9 dan eng kichik toq to'rt xonali son:",opts:["2 479","2 497","2 749","4 279"],ok:0,why:"Oxiriga eng katta toq raqamni qo'yamiz, oldinga eng kichiklar.",hint:"Oxirgi raqam 7 yoki 9. Qaysi biri sonni kichik qiladi?",full:"Toq bo'lishi uchun oxirida 7 yoki 9. Oldingi raqamlar kichik bo'lishi uchun kichik raqamlarni oldinga, kattasini (9) oxiriga: 2 479. Agar 7 oxirida bo'lsa: 2 497 — kattaroq."},
 tn:"Bank 4A4 qiyin turi. Bolalar avval «oxirgi o'ringa nima turishi shart?» deb so'rasin."},
{h:"Nechta son tuzish mumkin?",sum:"1, 2, 3 dan (takrorsiz) 6 ta uch xonali son; 0, 1, 2 dan — 4 ta.",a:"m07",
 start:function(){a4cards(['123','132','213','231','312','321'],{title:'1, 2, 3 dan barcha uch xonali sonlar',cols:3,cw:100});msg('Birinchi o‘ringa 3 xil, ikkinchiga 2 xil, uchinchiga 1: 3 · 2 · 1 = 6')},
 fin:function(){a4cards(['102','120','201','210'],{title:'0, 1, 2 dan — 4 ta',cols:4,cw:80});msg('Birinchi o‘ringa 0 qo‘yib bo‘lmaydi: 2 · 2 · 1 = <b>4</b>')},
 html:"<p>1, 2, 3 raqamlaridan 6 ta son chiqdi (sahnada). Endi <b>0, 1, 2</b> raqamlaridan (takrorsiz) nechta uch xonali son tuzish mumkin?</p>",
 btns:a4ch(["6","4","3","2"],1,function(){a4cards(['102','120','201','210'],{title:'0, 1, 2 dan — 4 ta',cols:4,cw:80});msg('012 va 021 — uch xonali emas. Qoladi <b>4 ta</b>')},function(i){msg(i===0?'012 va 021 ni sanadingiz — ular ikki xonali!':'Hammasini yozib chiqing: 102, 120, …')}),g2:1,
 after:"<p>Hisob usuli: har bir o'rin uchun nechta tanlov bor — ko'paytiramiz. 1-o'rin: 0 dan boshqa 2 ta; 2-o'rin: qolgan 2 tadan biri; 3-o'rin: 1 ta. 2 · 2 · 1 = 4.</p>",
 q:{t:"5, 6, 7, 8 raqamlaridan (takrorsiz) nechta ikki xonali son tuzish mumkin?",opts:["12","16","8","6"],ok:0,why:"4 · 3 = 12.",hint:"O'nliklar uchun 4 tanlov, birliklar uchun qolgan …",full:"O'nliklarga 4 xil raqam, birliklarga qolgan 3 tasidan biri: 4 · 3 = 12. «16» — takrorlarga ruxsat bo'lsa (55, 66 …) shuncha bo'lardi."},
 tn:"Daraxt chizma: birinchi raqamdan shoxlar — kombinatorikaga birinchi qadam."},
{h:"Bilasizmi? Milliard qanchalik katta?",sum:"1 milliard soniya — taxminan 31 yil 8 oy.",a:"m08",
 start:function(){a4table(1000000000,{top:'1 000 000 000 soniya'});msg('1 kun = 86 400 soniya')},fin:function(){a4table(1000000000,{top:'1 000 000 000 soniya'});msg('≈ 31 yil 8 oy')},
 html:"<p>⏱ 1 million soniya — atigi 11,5 kun. 1 <b>milliard</b> soniya esa — <b>31 yildan</b> ko'proq! Ya'ni milliard soniya o'tganda siz allaqachon katta odam bo'lasiz.</p><p>🌍 Yer yuzida 8 milliarddan ortiq odam yashaydi. Ularni sekundiga bittadan sanashga 250 yildan ko'proq kerak bo'lardi.</p>",
 tn:"Hisoblab tekshirish: 1 000 000 000 : 86 400 ≈ 11 574 kun ≈ 31,7 yil."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){a4table(2040500300,{top:'2 040 500 300'})},fin:function(){a4table(2040500300,{top:'2 040 500 300'})},
 html:"<div class='memo'><ul><li>Sinflar: birlar, minglar, millionlar, <b>milliardlar</b>; har biri × 1 000.</li><li>1 milliard = 1 000 million = 1 000 000 000.</li><li>Eng katta son — raqamlar kamayish tartibida.</li><li>Eng kichik son — o'sish tartibida, lekin 0 birinchi emas: 10 479.</li><li>Shart (juft/toq) bo'lsa — avval oxirgi raqamni tanlang.</li><li>Nechta son: har o'rindagi tanlovlarni ko'paytiring.</li></ul></div>",
 tn:"Keyingi dars — aniq va taqribiy qiymatlar."}
];
var PROBS=[
{t:"1 milliardda nechta million bor?",o:["1 000","100","10","1 000 000"],k:0,s:"1 000 · 1 000 000."},
{t:"2 040 500 300 qanday o'qiladi?",o:["ikki milliard qirq million besh yuz ming uch yuz","ikki milliard to'rt yuz million besh yuz ming uch yuz","yigirma milliard qirq besh million uch yuz","ikki milliard qirq million ellik ming uch yuz"],k:0,s:"2 | 040 | 500 | 300."},
{t:"«O'n besh milliard yetti million» qaysi son?",o:["15 007 000 000","15 700 000 000","15 000 007 000","1 507 000 000"],k:0,s:"15 | 007 | 000 | 000."},
{t:"3 milliard = ?",o:["3 000 million","300 million","30 million","3 000 ming"],k:0,s:"× 1 000."},
{t:"7 500 million = ?",o:["7 milliard 500 million","75 milliard","750 milliard","7 milliard 50 million"],k:0,s:"7 000 + 500 million."},
{t:"4, 0, 7, 1, 9 dan eng katta besh xonali son:",o:["97 410","94 710","97 401","90 714"],k:0,s:"Kamayish tartibi."},
{t:"4, 0, 7, 1, 9 dan eng kichik besh xonali son:",o:["10 479","01 479","14 079","10 497"],k:0,s:"0 birinchi emas."},
{t:"5, 0, 0, 3, 8 dan eng katta besh xonali son:",o:["85 300","85 003","80 053","58 300"],k:0,s:"8, 5, 3, 0, 0."},
{t:"6, 0, 2, 0, 5 dan eng kichik besh xonali son:",o:["20 056","20 065","25 006","20 506"],k:0,s:"2, 0, 0, 5, 6."},
{t:"3, 8, 5, 1 dan eng katta juft to'rt xonali son:",o:["5 318","8 531","8 513","3 518"],k:0,s:"8 oxirida."},
{t:"2, 7, 4, 9 dan eng kichik toq to'rt xonali son:",o:["2 479","2 497","2 749","4 279"],k:0,s:"9 oxirida."},
{t:"0, 1, 2 dan (takrorsiz) nechta uch xonali son tuzish mumkin?",o:["4","6","3","2"],k:0,s:"2 · 2 · 1."},
{t:"5, 6, 7, 8 dan (takrorsiz) nechta ikki xonali son tuzish mumkin?",o:["12","16","8","6"],k:0,s:"4 · 3."},
{t:"Raqamlari har xil bo'lgan eng kichik olti xonali son:",o:["102 345","123 456","100 000","012 345"],k:0,s:"1, 0, 2, 3, 4, 5."},
{t:"Raqamlari har xil bo'lgan eng katta yetti xonali son:",o:["9 876 543","9 999 999","9 876 540","7 654 321"],k:0,s:"9, 8, 7, 6, 5, 4, 3."},
{t:"Raqamlari yig'indisi 3 bo'lgan eng katta to'rt xonali son:",o:["3 000","2 100","1 110","1 002"],k:0,s:"Birinchi raqam iloji boricha katta: 3."},
{t:"Raqamlari yig'indisi 30 bo'lgan eng kichik to'rt xonali son:",o:["3 999","9 993","6 888","3 989"],k:0,s:"Oxirgi uchta — 9 ga, birinchi 30 − 27 = 3."},
{t:"Milliardlar sinfida 12, millionlar sinfida 5, qolgan sinflar nol. Bu son:",o:["12 005 000 000","12 500 000 000","1 205 000 000","12 000 005 000"],k:0,s:"12 | 005 | 000 | 000."},
{t:"1, 3, 5 raqamlaridan (takrorsiz) tuzilgan barcha uch xonali sonlardan nechtasi 300 dan katta?",o:["4","2","6","3"],k:0,s:"3 yoki 5 bilan boshlanadi: 2 · 2 = 4 (315, 351, 513, 531)."},
{t:"9 ta raqamli eng katta son va 10 xonali eng kichik son farqi:",o:["1","10","0","9"],k:0,s:"1 000 000 000 − 999 999 999."}
];
function PRACT_STAGE(){a4table(2040500300,{top:'2 040 500 300'})}
var PREP_DATA={teach:["Milliardlar sinfi, sinflar orasidagi × 1 000 munosabat.","Milliardli sonlarni o'qish va yozish.","Raqamlardan eng katta/eng kichik son, shartli (juft/toq) son, nechta son tuzish mumkin."],mist:["0 ni birinchi o'ringa qo'yadi.","«Eng katta juft» da avval kattasini, keyin juftlikni o'ylaydi (8 531).","1 milliard = 100 million deb o'ylaydi.","Ikki xonali emas sonlarni (012) ham sanaydi."],need:["Raqam kartochkalari (0–9 ikki to'plam), xonalar jadvali (10 ustun)."],board:["<span class='w2'>2 | 040 | 500 | 300</span>.","<span class='w2'>1 milliard = 1 000 million</span>.","<span class='w2'>97 410</span> / <span class='w2'>10 479</span>.","<span class='w2'>5 318</span> — eng katta juft.","<span class='w2'>2 · 2 · 1 = 4</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
