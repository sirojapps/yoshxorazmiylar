// ===== w_4g umumiy sahna vositalari (4G, 4H) =====
function g4m(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// birliklar zinapoyasi: u — nomlar, f — qo'shnilar orasidagi ko'paytuvchi, hi — ajratilgan indekslar, ar — [i,j] strelka
function g4lad(u,f,hi,ar,ttl){clear();var g=S.g,n=u.length,w=Math.min(Math.max(58,Math.max.apply(null,u.map(function(t){return t.length}))*8.6+10),(340-34*(n-1))/n),gap=(340-n*w)/(n-1||1),x0=10,y=70;hi=hi||[];
 if(ttl)T(g,180,26,ttl,{'font-size':13,'font-weight':800,fill:C.blue});
 for(var i=0;i<n;i++){var x=x0+i*(w+gap),on=hi.indexOf(i)>=0;E('rect',{x:x,y:y,width:w,height:36,rx:9,fill:on?C.hi:'#fff',stroke:on?C.a2:C.grey,'stroke-width':on?2.4:1.4},g);T(g,x+w/2,y+23,u[i],{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
  if(i<n-1){var xm=x+w+gap/2;T(g,xm,y+12,'×'+f[i],{'font-size':11,'font-weight':800,fill:C.ok});E('path',{d:'M'+(x+w+3)+' '+(y+18)+' L'+(x+w+gap-3)+' '+(y+18),stroke:C.ok,'stroke-width':1.6,'marker-end':''},g);E('path',{d:'M'+(x+w+gap-8)+' '+(y+14)+' L'+(x+w+gap-3)+' '+(y+18)+' L'+(x+w+gap-8)+' '+(y+22),fill:'none',stroke:C.ok,'stroke-width':1.6},g)}}
 if(ar){var a=ar[0],b=ar[1],xa=x0+a*(w+gap)+w/2,xb=x0+b*(w+gap)+w/2,up=b>a;E('path',{d:'M'+xa+' '+(y+40)+' Q'+((xa+xb)/2)+' '+(y+74)+' '+xb+' '+(y+40),fill:'none',stroke:up?C.a2:C.blue,'stroke-width':2.2,'stroke-dasharray':'5 3'},g);
  var k=1;for(var j=Math.min(a,b);j<Math.max(a,b);j++)k*=f[j];T(g,(xa+xb)/2,y+76,(up?'× ':': ')+(k>=10000?String(k).replace(/\B(?=(\d{3})+(?!\d))/g,' '):k),{'font-size':14,'font-weight':800,fill:up?C.a2:C.blue})}
 T(g,180,166,'Kattadan kichikka — ko‘paytiramiz · kichikdan kattaga — bo‘lamiz',{'font-size':10.5,'font-weight':600,fill:'#7a6a50'})}
// katakli shakl: cells [[c,r],...], s — katak, x0,y0; o.col, o.grid (cols,rows), o.edge — perimetrni ajratish
function g4cells(cells,o){o=o||{};var g=S.g,s=o.s||16,x0=o.x0||40,y0=o.y0||20,cols=o.cols||14,rows=o.rows||8;
 if(o.grid!==false)for(var c=0;c<=cols;c++)E('line',{x1:x0+c*s,y1:y0,x2:x0+c*s,y2:y0+rows*s,stroke:'#e8dcc6','stroke-width':.8},g);
 if(o.grid!==false)for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*s,x2:x0+cols*s,y2:y0+r*s,stroke:'#e8dcc6','stroke-width':.8},g);
 var set={};cells.forEach(function(p){set[p[0]+','+p[1]]=1});
 cells.forEach(function(p,i){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:s,height:s,fill:(o.colf?o.colf(p,i):o.col)||C.t2,stroke:o.fill===false?'none':'#fff','stroke-width':.8,opacity:o.op||1},g)});
 if(o.edge)cells.forEach(function(p){var x=x0+p[0]*s,y=y0+p[1]*s;[[0,-1,x,y,x+s,y],[0,1,x,y+s,x+s,y+s],[-1,0,x,y,x,y+s],[1,0,x+s,y,x+s,y+s]].forEach(function(d){if(!set[(p[0]+d[0])+','+(p[1]+d[1])])E('line',{x1:d[2],y1:d[3],x2:d[4],y2:d[5],stroke:o.ec||C.bad,'stroke-width':3,'stroke-linecap':'round'},g)})});
 return {x0:x0,y0:y0,s:s}}
function g4rect(c0,r0,w,h){var a=[];for(var c=c0;c<c0+w;c++)for(var r=r0;r<r0+h;r++)a.push([c,r]);return a}
// to'g'ri burchakli ko'pburchak (piksellarda), lab — [[x,y,matn,rang],...]
function g4poly(pts,fill,lab,o){o=o||{};var g=S.g;E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:fill||'#fbe0b4',stroke:o.st||C.t1,'stroke-width':o.sw||2},g);(lab||[]).forEach(function(l){T(g,l[0],l[1],l[2],{'font-size':l[4]||12,'font-weight':800,fill:l[3]||'#5b3b1c'})})}
// izometrik quti (a — uzunlik, b — eni, c — balandlik)
function g4box(a,b,c,o){o=o||{};if(!o.keep)clear();var g=S.g,s=o.s||Math.min(22,170/(a+b*.6),110/(c+b*.4)),W=a*s,H=c*s,dx=b*s*.6,dy=b*s*.4,x0=o.x0!=null?o.x0:(180-(W+dx)/2),y0=(o.y0||150);
 var A=[x0,y0],B=[x0+W,y0],Cc=[x0+W,y0-H],D=[x0,y0-H],A2=[A[0]+dx,A[1]-dy],B2=[B[0]+dx,B[1]-dy],C2=[Cc[0]+dx,Cc[1]-dy],D2=[D[0]+dx,D[1]-dy];
 function P(l){return l.map(function(p){return p[0]+','+p[1]}).join(' ')}
 var ff=o.ff||['#f6c98a','#e8a55d','#fbe0b4'];
 E('polygon',{points:P([A,B,Cc,D]),fill:ff[0],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([B,B2,C2,Cc]),fill:ff[1],stroke:C.t1,'stroke-width':1.2},g);E('polygon',{points:P([D,Cc,C2,D2]),fill:ff[2],stroke:C.t1,'stroke-width':1.2},g);
 if(o.hidden!==false)[[A,A2],[A2,B2],[A2,D2]].forEach(function(e){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:'#a8601f','stroke-width':1,'stroke-dasharray':'4 3'},g)});
 if(o.cubes){for(var i=1;i<a;i++){E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:x0+i*s,y1:y0-H,x2:x0+i*s+dx,y2:y0-H-dy,stroke:C.t1,'stroke-width':.6},g)}
  for(var j=1;j<c;j++){E('line',{x1:x0,y1:y0-j*s,x2:x0+W,y2:y0-j*s,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:B[0],y1:B[1]-j*s,x2:B2[0],y2:B2[1]-j*s,stroke:C.t1,'stroke-width':.6},g)}
  for(var k=1;k<b;k++){var kx=k*s*.6,ky=k*s*.4;E('line',{x1:B[0]+kx,y1:B[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g);E('line',{x1:D[0]+kx,y1:D[1]-ky,x2:Cc[0]+kx,y2:Cc[1]-ky,stroke:C.t1,'stroke-width':.6},g)}}
 if(o.lab!==false){T(g,(A[0]+B[0])/2,y0+15,o.la||(a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,(B[0]+B2[0])/2+18,(B[1]+B2[1])/2+8,o.lb||(b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue});T(g,x0-6,y0-H/2+4,o.lc||(c+' sm'),{'font-size':12,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 return {A:A,B:B,C:Cc,D:D,A2:A2,B2:B2,C2:C2,D2:D2,s:s}}
// soat: h, m; cx, cy, r
function g4clock(h,m,cx,cy,r,lab){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:C.blue,'stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=i*Math.PI/6-Math.PI/2;T(g,cx+(r-11)*Math.cos(a),cy+(r-11)*Math.sin(a)+4,String(i),{'font-size':Math.max(10,r/4.5),'font-weight':700,fill:'#3a4a5a'})}
 var am=m*Math.PI/30-Math.PI/2,ah=((h%12)+m/60)*Math.PI/6-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':4,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.a2,'stroke-width':2.6,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:3,fill:'#1d2b3a'},g);
 if(lab)T(g,cx,cy+r+16,lab,{'font-size':13,'font-weight':800,fill:C.blue})}
// burchak: uch (x,y), a0 va a1 gradusda (0 — o'ngga, soat miliga teskari)
function g4ang(x,y,a0,a1,L,col,lab){var g=S.g,r0=a0*Math.PI/180,r1=a1*Math.PI/180;col=col||C.blue;
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r0),y2:y-L*Math.sin(r0),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 E('line',{x1:x,y1:y,x2:x+L*Math.cos(r1),y2:y-L*Math.sin(r1),stroke:'#1d2b3a','stroke-width':2.4,'stroke-linecap':'round'},g);
 var R=22,d=a1-a0;if(Math.abs(d-90)<.5){var u=[Math.cos(r0),-Math.sin(r0)],v=[Math.cos(r1),-Math.sin(r1)],q=13;E('path',{d:'M'+(x+u[0]*q)+' '+(y+u[1]*q)+' L'+(x+u[0]*q+v[0]*q)+' '+(y+u[1]*q+v[1]*q)+' L'+(x+v[0]*q)+' '+(y+v[1]*q),fill:'none',stroke:col,'stroke-width':2},g)}
 else E('path',{d:'M'+(x+R*Math.cos(r0))+' '+(y-R*Math.sin(r0))+' A'+R+' '+R+' 0 '+(d>180?1:0)+' 0 '+(x+R*Math.cos(r1))+' '+(y-R*Math.sin(r1)),fill:'none',stroke:col,'stroke-width':2.4},g);
 if(lab){var am=(a0+a1)/2*Math.PI/180;T(g,x+(R+16)*Math.cos(am),y-(R+16)*Math.sin(am)+4,lab,{'font-size':11.5,'font-weight':800,fill:col})}}
// tugma bosilganda: to'g'ri bo'lsa done, aks holda xabar
function g4pick(ok,msgOk,msgBad){return function(c,done,b){if(ok){b.style.background=C.ok;b.style.color='#fff';g4m(msgOk);done()}else{b.style.background='#fde2e2';g4m('❌ '+msgBad);setTimeout(function(){b.style.background=''},1600)}}}
var CODE='4H2',TITLE='4-sinf · To‘g‘ri burchakli parallelepiped va kub, hajm';
function h2box(a,b,c,hl,o){o=o||{};var r=g4box(a,b,c,Object.assign({s:o.s||18},o)),g=S.g,P=[r.A,r.B,r.C,r.D,r.A2,r.B2,r.C2,r.D2];
 if(hl==='e'){[[r.A,r.B],[r.D,r.C],[r.D2,r.C2],[r.A2,r.B2],[r.B,r.B2],[r.C,r.C2],[r.D,r.D2],[r.A,r.A2],[r.A,r.D],[r.B,r.C],[r.B2,r.C2],[r.A2,r.D2]].forEach(function(e,i){E('line',{x1:e[0][0],y1:e[0][1],x2:e[1][0],y2:e[1][1],stroke:[C.bad,C.blue,C.ok][Math.floor(i/4)],'stroke-width':4,'stroke-linecap':'round',opacity:.85},g)})}
 if(hl==='v')P.forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:5,fill:C.bad,stroke:'#fff','stroke-width':1.5},g)});
 if(hl==='f'){E('polygon',{points:[r.A,r.B,r.C,r.D].map(function(p){return p.join(',')}).join(' '),fill:C.hi,opacity:.7},g)}
 return r}
function h2net(){clear();var g=S.g,a=6,b=4,c=3,s=10,x0=40,y0=22,cl=['#f6c98a','#bfe3f5','#c9ecd2'],xs=[x0,x0+b*s,x0+(a+b)*s,x0+(a+2*b)*s],ws=[b,a,b,a];
 for(var i=0;i<4;i++){E('rect',{x:xs[i],y:y0+b*s,width:ws[i]*s,height:c*s,fill:i%2?cl[0]:cl[1],stroke:C.t1,'stroke-width':1.3},g);T(g,xs[i]+ws[i]*s/2,y0+b*s+c*s/2+4,ws[i]+'×'+c,{'font-size':10.5,'font-weight':800,fill:'#5b3b1c'})}
 [y0,y0+(b+c)*s].forEach(function(y){E('rect',{x:xs[1],y:y,width:a*s,height:b*s,fill:cl[2],stroke:C.t1,'stroke-width':1.3},g);T(g,xs[1]+a*s/2,y+b*s/2+4,a+'×'+b,{'font-size':10.5,'font-weight':800,fill:'#1d5a2f'})})}
var P2=[function(){h2box(4,3,1,null,{cubes:true,lab:false,s:22});calc(['1-qatlam: 4 · 3 = <b>12</b> ta 1 sm³ li kubik'])},
 function(){h2box(4,3,2,null,{cubes:true,lab:false,s:22});calc(['2 ta qatlam: 12 · 2 = <b>24</b>'])},
 function(){h2box(4,3,2,null,{cubes:true,s:22});calc(['V = uzunlik · eni · balandlik = 4 · 3 · 2 = <b>24 sm³</b>'])}];
var P3=[function(){h2box(5,4,6,null,{lc:'? sm',s:15});calc(['Hajm 120 sm³, uzunlik 5 sm, eni 4 sm. Balandlik = ?'])},
 function(){h2box(5,4,1,null,{cubes:true,lab:false,s:18});calc(['Tub yuzi (bitta qatlam): 5 · 4 = <b>20</b>'])},
 function(){h2box(5,4,6,null,{cubes:true,s:15});calc(['V = tub yuzi · balandlik  →  balandlik = 120 : 20 = <b>6 sm</b>'])}];
var P4=[function(){h2box(4,1,1.2,null,{la:'2 m',lb:'50 sm',lc:'30 sm',s:48,y0:130});calc(['Yashik: 2 m × 50 sm × 30 sm. Hajmi necha dm³?'])},
 function(){h2box(4,1,1.2,null,{la:'20 dm',lb:'5 dm',lc:'3 dm',s:48,y0:130});calc(['Avval hammasini <b>bir xil</b> birlikka: 2 m = 20 dm, 50 sm = 5 dm, 30 sm = 3 dm'])},
 function(){h2box(4,1,1.2,null,{la:'20 dm',lb:'5 dm',lc:'3 dm',s:48,y0:130});calc(['V = 20 · 5 · 3 = <b>300 dm³</b> = 300 l'])}];
var P5=[function(){h2box(6,4,3,null,{s:16});calc(['Qutini rangli qog‘oz bilan o‘rash kerak. Necha sm² qog‘oz?'])},
 function(){h2net();calc(['Qutini «ochamiz» — yoyilma: 3 juft teng to‘rtburchak'])},
 function(){h2net();calc(['2 · (6·4) + 2 · (6·3) + 2 · (4·3)','= 48 + 36 + 24 = <b>108 sm²</b> — sirt'])}];
function h2grow(k){var d=[[2,2,2],[4,2,2],[4,4,2],[4,4,4]][k],v=d[0]*d[1]*d[2];h2box(d[0],d[1],d[2],null,{cubes:true,lab:false,s:15});T(S.g,300,40,d.join(' · ')+' = '+v,{'font-size':14,'font-weight':800,fill:C.a2});g4m(['Boshlang‘ich: <b>8</b> kubik','Uzunlik ×2 → hajm <b>×2</b> (16)','Uzunlik va eni ×2 → hajm <b>×4</b> (32)','Uchala o‘lcham ×2 → hajm <b>×8</b> (64)'][k])}
var P7=[function(){var r=h2box(4,3,1,null,{cubes:true,lab:false,s:20,y0:150});g4box(2,3,1,{cubes:true,lab:false,s:20,y0:130,x0:r.A[0],keep:true,ff:['#bfe3f5','#9fd3f5','#e4f3fc']});calc(['Zinapoya: pastki qavat 4 × 3 × 1, ustki qavat 2 × 3 × 1'])},
 function(){P7[0]();calc(['Pastki: 4 · 3 · 1 = <b>12</b>','Ustki: 2 · 3 · 1 = <b>6</b>'])},
 function(){P7[0]();calc(['12 + 6 = <b>18 sm³</b>','Murakkab jism hajmi = bo‘laklar hajmlari yig‘indisi'])}];
var P8=[function(){h2box(4,4,4,null,{cubes:true,lab:false,s:16});calc(['4 × 4 × 4 kub sirtiga bo‘yoq surtildi va 64 kubchaga kesildi'])},
 function(){h2box(4,4,4,'v',{cubes:true,lab:false,s:16});calc(['Uchlardagi kubchalar — <b>3 ta</b> yog‘i bo‘yalgan: <b>8</b> ta'])},
 function(){h2box(4,4,4,'e',{cubes:true,lab:false,s:16});calc(['3 yoq: 8','Qirralarda (uchlarsiz): 12 qirra · 2 = <b>24</b> ta — 2 yog‘i bo‘yalgan'])},
 function(){h2box(4,4,4,'f',{cubes:true,lab:false,s:16});calc(['3 yoq: 8, 2 yoq: 24','Yoqlar o‘rtasida: 6 · (2 · 2) = <b>24</b> ta — 1 yog‘i bo‘yalgan'])},
 function(){h2box(4,4,4,null,{cubes:true,lab:false,s:16});calc(['Ichkarida: 2 · 2 · 2 = <b>8</b> ta — bo‘yalmagan','Tekshiruv: 8 + 24 + 24 + 8 = 64 ✓'])}];
var STEPS=[
{h:"Kuboid va kub: yoq, qirra, uch",sum:"6 yoq, 12 qirra, 8 uch. 6 + 8 − 12 = 2 (Eyler).",a:"m01",
 start:function(){h2box(5,3,3);g4m('Tugmalarni bosing')},fin:function(){h2box(5,3,3,'e');g4m('Har o‘lcham bo‘yicha 4 tadan qirra')},
 html:"<p>To'g'ri burchakli parallelepiped (kuboid) — g'isht, quti. Barcha o'lchamlari teng bo'lsa — kub. Qismlarini ko'ring:</p>",
 btns:[["Yoqlar",function(c,done){h2box(5,3,3,'f');g4m('Yoq — to‘g‘ri to‘rtburchak. Juft-juft teng: <b>6 ta</b>');mvK(done,3)}],["Qirralar",function(c,done){h2box(5,3,3,'e');g4m('Qizil 4 + ko‘k 4 + yashil 4 = <b>12 ta</b>');mvK(done,3)}],["Uchlar",function(c,done){h2box(5,3,3,'v');g4m('Tepada 4 + pastda 4 = <b>8 ta</b>');mvK(done,3)}]],g3:1,
 after:"<p>Kuboidning <b>3 o'lchami</b> bor: uzunlik, eni, balandlik; har biri bo'yicha <b>4 tadan</b> teng qirra. Qiziq: yoqlar + uchlar − qirralar = 6 + 8 − 12 = <b>2</b> — bu Eyler formulasi, ko'p yoqlilarning barchasida shunday!</p>",
 q:{t:"Kuboid uchun yoqlar soni + uchlar soni − qirralar soni = ?",opts:["0","26","2","4"],ok:2,why:"6 + 8 − 12 = 2.",hint:"6 yoq, 8 uch, 12 qirra.",full:"Yoqlar 6, uchlar 8, qirralar 12: 6 + 8 − 12 = 2. «26» — hammasini qo'shish xatosi."},
 tn:"Plastilin va cho'plardan karkas yasang; Eyler formulasini piramida bilan ham tekshiring (5 + 5 − 8 = 2)."},
{h:"Hajm: qatlamlab sanash",sum:"V = a · b · c. 4 · 3 · 2 = 24 sm³.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Hajm — jism egallagan joy, 1 sm³ li kubiklar soni. Qutini qatlamlab to'ldiramiz:</p>",
 btns:[phaser(P2,'▶ Qatlam')],
 after:"<p><b>V = uzunlik · eni · balandlik</b>. Kub uchun: V = a · a · a. Hajm birliklari: sm³, dm³, m³.</p>",
 q:{t:"Kuboid 5 sm × 4 sm × 3 sm. Hajmi?",opts:["12 sm³","47 sm³","60 sm³","94 sm³"],ok:2,why:"5 · 4 · 3 = 60 sm³.",hint:"Uchala o'lchamni ko'paytiring.",full:"5 · 4 · 3 = 60 sm³. «12» — o'lchamlar yig'indisi, «94» — sirt (2 · (20 + 15 + 12))."},
 tn:"Lego yoki shakar bo'laklaridan 4 × 3 × 2 qutini teramiz — formula oldidan sanash."},
{h:"Teskari masala: balandlikni topish",sum:"V = tub yuzi · balandlik. 120 : (5 · 4) = 6 sm.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Hajm va ikki o'lcham ma'lum. Uchinchisini topamiz:</p>",
 btns:[phaser(P3)],
 after:"<p><b>V = tub yuzi · balandlik</b>. Shuning uchun balandlik = V : (tub yuzi). Tub — bitta qatlam.</p>",
 q:{t:"Kuboid hajmi 96 sm³, tubi 4 sm × 6 sm. Balandligi?",opts:["4 sm","16 sm","86 sm","24 sm"],ok:0,why:"96 : 24 = 4 sm.",hint:"Avval tub yuzini toping.",full:"Tub yuzi 4 · 6 = 24 sm². 96 : 24 = 4 sm. «16» — 96 ni 6 ga bo'lish, «24» — tub yuzini javob deb olish."},
 tn:"Bolalarga «akvarium» masalasi: suv hajmi ma'lum — sath balandligini topish."},
{h:"Tuzoq: o'lchamlar har xil birlikda",sum:"2 m × 50 sm × 30 sm = 20 dm · 5 dm · 3 dm = 300 dm³.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Yashik o'lchamlari: 2 m, 50 sm, 30 sm. Hajmi necha dm³ (litr)?</p>",
 btns:[phaser(P4)],
 after:"<p>Ko'paytirishdan oldin barcha o'lchamlar <b>bir xil birlikda</b> bo'lishi shart! «2 · 50 · 30 = 3000» — ma'nosiz son. Litr kerak bo'lsa — dm ga o'tkazish eng qulay.</p>",
 q:{t:"Quti 1 m × 40 sm × 50 sm. Hajmi necha dm³?",opts:["200 dm³","2000 dm³","20 dm³","91 dm³"],ok:0,why:"10 dm · 4 dm · 5 dm = 200 dm³.",hint:"Hammasini dm ga o'tkazing.",full:"1 m = 10 dm, 40 sm = 4 dm, 50 sm = 5 dm: 10 · 4 · 5 = 200 dm³. «2000» — 1 · 40 · 50 (birliklarni aralashtirish), «91» — qo'shish."},
 tn:"Bolalar sinf xonasini o'lchasin (m da), havosi hajmini m³ da toping."},
{h:"Sirt — hamma yoqlar yuzi",sum:"6 × 4 × 3 quti sirti: 2·24 + 2·18 + 2·12 = 108 sm².",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Hajm — ichidagi joy (sm³). <b>Sirt</b> esa — tashqi qobiq, hamma yoqlar yuzi (sm²). Topamiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Kuboid sirti = <b>2 · (a·b + a·c + b·c)</b>. Kub sirti = <b>6 · a · a</b>. Sirt — sm², hajm — sm³: ularni aralashtirmang!</p>",
 q:{t:"Kubning sirti 54 sm². Uning qirrasi?",opts:["9 sm","6 sm","3 sm","27 sm"],ok:2,why:"Bitta yoq 54 : 6 = 9 sm² → qirra 3 sm.",hint:"Kubda nechta teng yoq bor?",full:"54 : 6 = 9 sm² — bitta yoq (kvadrat). 3 · 3 = 9, demak qirra 3 sm. «9» — bu yoq yuzi, qirra emas."},
 tn:"Choy qutisini yoyib, har yoqning o'lchamini yozdiring."},
{h:"O'lchamlar o'zgarsa hajm qanday o'zgaradi?",sum:"Bitta o'lcham ×2 → V ×2; ikkitasi ×2 → V ×4; uchalasi ×2 → V ×8.",a:"m06",
 start:function(){h2grow(0)},fin:function(){h2grow(3)},
 html:"<p>2 × 2 × 2 kubdan boshlab, o'lchamlarni ikki baravar oshiring:</p>",
 btns:[["Uzunlik ×2",function(c,done){h2grow(1);mvK(done,3)}],["+ eni ×2",function(c,done){h2grow(2);mvK(done,3)}],["+ balandlik ×2",function(c,done){h2grow(3);mvK(done,3)}]],g3:1,
 after:"<p>Har bir oshirilgan o'lcham hajmni o'sha songa ko'paytiradi: 2 · 2 · 2 = 8. Shuning uchun qirrasi 2 marta katta kubga 8 ta kichik kub sig'adi.</p>",
 q:{t:"Kuboidning faqat balandligi 3 marta oshirildi. Hajmi necha marta oshdi?",opts:["9 marta","27 marta","3 marta","6 marta"],ok:2,why:"Bitta o'lcham ×3 → hajm ×3.",hint:"Nechta o'lcham o'zgardi?",full:"Faqat bitta o'lcham 3 marta oshdi — hajm ham 3 marta. 27 marta — uchala o'lcham oshganda bo'lardi."},
 tn:"Kubiklar bilan amalda: 2 × 2 × 2 ni 4 × 2 × 2 ga, keyin 4 × 4 × 4 ga aylantiring."},
{h:"Murakkab jism hajmi",sum:"Zinapoya: 4·3·1 + 2·3·1 = 12 + 6 = 18 sm³.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Jism ikki kuboiddan tuzilgan. Uning hajmini topamiz:</p>",
 btns:[phaser(P7)],
 after:"<p>Murakkab jismni kuboidlarga ajratamiz va hajmlarni <b>qo'shamiz</b>. Yoki to'liq kuboidni olib, kesilgan qismni <b>ayiramiz</b> — xuddi yuzlardagidek.</p>",
 q:{t:"6 × 4 × 5 kuboiddan 2 × 4 × 2 bo'lak kesib olindi. Qolgan hajm?",opts:["136 sm³","16 sm³","104 sm³","120 sm³"],ok:2,why:"120 − 16 = 104 sm³.",hint:"Butun kuboid hajmidan kesilgan bo'lak hajmini ayiring.",full:"6 · 4 · 5 = 120; 2 · 4 · 2 = 16; 120 − 16 = 104 sm³. «136» — qo'shib yuborish, «120» — kesilganni unutish."},
 tn:"Kubiklardan zinapoya qurib, bolalar ikki usulda hisoblasin."},
{h:"Tuzoq: bo'yalgan kub",sum:"4×4×4: 3 yoq — 8, 2 yoq — 24, 1 yoq — 24, bo'yalmagan — 8.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=4;P8[4]()},
 html:"<p>Mashhur olimpiada masalasi. Kub tashqaridan bo'yalib, 4 × 4 × 4 = 64 kubchaga kesildi. Nechta kubchaning nechta yog'i bo'yalgan?</p>",
 btns:[phaser(P8,'▶ Sanash')],
 after:"<p>Joylashuvga qarab: <b>uchlar</b> (har doim 8 ta) — 3 yoq; <b>qirralar</b> — 2 yoq; <b>yoqlar o'rtasi</b> — 1 yoq; <b>ichkari</b> — bo'yalmagan. Yig'indi albatta umumiy songa teng bo'lishi kerak — bu tekshiruv!</p>",
 q:{t:"3 × 3 × 3 bo'yalgan kubda nechta kubchaning roppa-rosa ikki yog'i bo'yalgan?",opts:["8","6","12","24"],ok:2,why:"Har qirrada uchlarsiz 1 ta: 12 · 1 = 12.",hint:"Qirralar soni 12. Har qirrada uchlardan tashqari nechta kubcha?",full:"3 × 3 × 3 da har qirrada 3 ta kubcha, ulardan 2 tasi uch. Qoladi 1 ta, 12 qirra: 12 ta. «8» — uchlar (3 yoq), «6» — yoqlar markazi (1 yoq)."},
 tn:"Rubik kubigi yoki 27 ta kubikdan yig'ilgan kub bilan ko'rsating."},
{h:"Bilasizmi? Eyler va ko'pyoqlar",sum:"Leonard Eyler (18-asr) har qanday qavariq ko'pyoqda Yo + U − Q = 2 ekanini ko'rsatgan.",a:"m09",
 start:function(){h2box(3,3,3,'v',{lab:false,s:26});g4m('6 + 8 − 12 = 2')},fin:function(){h2box(3,3,3,'v',{lab:false,s:26});g4m('6 + 8 − 12 = 2')},
 html:"<p>📐 Shveytsariyalik matematik <b>Leonard Eyler</b> (1707–1783) ajoyib qonuniyatni e'lon qilgan: har qanday qavariq ko'pyoqda <b>yoqlar + uchlar − qirralar = 2</b>.</p><p>Kub: 6 + 8 − 12 = 2. Uchburchakli piramida: 4 + 4 − 6 = 2. To'rtburchakli piramida: 5 + 5 − 8 = 2.</p><p>Eyler bo'yalgan kub kabi masalalar ham yechishni yaxshi ko'rgan — u tarixdagi eng sermahsul matematiklardan biri.</p>",
 tn:"Bolalar boshqa ko'pyoqlarda (prizma, piramida) Eyler formulasini tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h2box(5,4,3,'e')},fin:function(){h2box(5,4,3,'e')},
 html:"<div class='memo'><ul><li>Kuboid va kub: 6 yoq, 12 qirra, 8 uch.</li><li><b>V = a · b · c</b>; kub: a · a · a. <b>V = tub yuzi · balandlik</b>.</li><li>Teskari: balandlik = V : (a · b).</li><li>Ko'paytirishdan oldin o'lchamlar <b>bir xil birlikda</b>!</li><li>Sirt: 2 · (ab + ac + bc); kub: 6 · a · a. Sirt — sm², hajm — sm³.</li><li>Qirralar yig'indisi: 4 · (a + b + c); kub: 12 · a.</li><li>Bitta o'lcham ×k → V ×k; uchalasi ×2 → V ×8.</li><li>Bo'yalgan n×n×n kub: uchlar — 8, ichkari — (n−2)·(n−2)·(n−2).</li></ul></div>",
 tn:"Uyga vazifa: uydagi qutining hajmi va sirtini topish."}
];
var PROBS=[
{t:"Qirrasi 5 sm kubning hajmi?",o:["125 sm³","25 sm³","60 sm³","150 sm³"],k:0,s:"5 · 5 · 5 = 125 sm³."},
{t:"Kuboid 7 sm × 3 sm × 2 sm. Hajmi?",o:["42 sm³","12 sm³","21 sm³","82 sm³"],k:0,s:"7 · 3 · 2 = 42 sm³."},
{t:"Hajm 96 sm³, tub 4 sm × 6 sm. Balandlik?",o:["4 sm","16 sm","86 sm","24 sm"],k:0,s:"96 : 24 = 4 sm."},
{t:"Kubning barcha qirralari yig'indisi 60 sm. Hajmi?",o:["125 sm³","25 sm³","150 sm³","216 sm³"],k:0,s:"Qirra 60 : 12 = 5; 5 · 5 · 5 = 125."},
{t:"Kubning sirti 54 sm². Qirrasi?",o:["3 sm","9 sm","6 sm","27 sm"],k:0,s:"54 : 6 = 9 sm²; 3 · 3 = 9 → 3 sm."},
{t:"Kuboid 6 sm × 4 sm × 3 sm. Sirti?",o:["108 sm²","72 sm²","54 sm²","13 sm²"],k:0,s:"2 · (24 + 18 + 12) = 108 sm²."},
{t:"Quti 1 m × 40 sm × 50 sm. Hajmi necha dm³?",o:["200 dm³","2000 dm³","20 dm³","91 dm³"],k:0,s:"10 · 4 · 5 = 200 dm³."},
{t:"Kuboidning uchala o'lchami 2 marta oshirildi. Hajmi?",o:["8 marta oshdi","2 marta oshdi","6 marta oshdi","4 marta oshdi"],k:0,s:"2 · 2 · 2 = 8."},
{t:"Kuboidning faqat balandligi 3 marta oshirildi. Hajmi?",o:["3 marta oshdi","9 marta oshdi","27 marta oshdi","6 marta oshdi"],k:0,s:"Bitta o'lcham ×3 → hajm ×3."},
{t:"6 × 4 × 5 kuboiddan 2 × 4 × 2 bo'lak kesildi. Qolgan hajm?",o:["104 sm³","136 sm³","16 sm³","120 sm³"],k:0,s:"120 − 16 = 104."},
{t:"Bo'yalgan 3 × 3 × 3 kubda roppa-rosa 2 yog'i bo'yalgan kubchalar?",o:["12","8","6","24"],k:0,s:"Har qirrada 1 ta, 12 qirra."},
{t:"Bo'yalgan 4 × 4 × 4 kubda bitta ham yog'i bo'yalmagan kubchalar?",o:["8","0","16","24"],k:0,s:"Ichkaridagi 2 × 2 × 2 = 8."},
{t:"Xona 5 m × 4 m × 3 m. Undagi havo hajmi?",o:["60 m³","12 m³","94 m³","35 m³"],k:0,s:"5 · 4 · 3 = 60 m³."},
{t:"1 m³ necha sm³?",o:["1 000 000 sm³","1000 sm³","100 000 sm³","10 000 sm³"],k:0,s:"100 · 100 · 100 = 1 000 000."},
{t:"Qirrasi 2 sm kubiklardan 10 sm × 6 sm × 4 sm qutiga nechtasi sig'adi?",o:["30","240","60","15"],k:0,s:"5 · 3 · 2 = 30 ta."},
{t:"Kuboid hajmi 60 sm³, ikki o'lchami 3 sm va 4 sm. Uchinchisi?",o:["5 sm","53 sm","20 sm","12 sm"],k:0,s:"60 : (3 · 4) = 5 sm."},
{t:"Akvarium 60 sm × 30 sm × 40 sm; suv 30 sm balandlikkacha quyilgan. Necha litr suv?",o:["54 l","72 l","540 l","18 l"],k:0,s:"60 · 30 · 30 = 54 000 sm³ = 54 l."},
{t:"Kub hajmi 64 sm³. Sirti?",o:["96 sm²","64 sm²","16 sm²","48 sm²"],k:0,s:"Qirra 4 sm; 6 · 16 = 96 sm²."},
{t:"Qirrasi 3 sm ikki kub yonma-yon yopishtirildi. Hosil jism sirti?",o:["90 sm²","108 sm²","54 sm²","72 sm²"],k:0,s:"6 × 3 × 3: 2 · (18 + 18 + 9) = 90 sm² (yopishgan 2 yoq yo'qoldi)."},
{t:"Kuboid qirralari yig'indisi 48 sm, ikki o'lchami 5 sm va 4 sm. Hajmi?",o:["60 sm³","80 sm³","36 sm³","12 sm³"],k:0,s:"a + b + c = 12 → c = 3; 5 · 4 · 3 = 60."}
];
function PRACT_STAGE(){h2box(5,4,3,null,{s:18});g4m('V = a · b · c · Sirt = 2·(ab + ac + bc)')}
var PREP_DATA={teach:["Kuboid va kub elementlari; Eyler formulasi.","Hajm: qatlamlab va formula; teskari masala.","Birliklarni bir xil qilish; sirt (yoyilma).","O'lcham o'zgarishi; murakkab jism; bo'yalgan kub."],
 mist:["Hajmni o'lchamlar yig'indisi deb hisoblaydi.","Har xil birlikdagi o'lchamlarni ko'paytiradi.","Sirt va hajmni aralashtiradi.","Bo'yalgan kubda uch va qirradagi kubchalarni ikki marta sanaydi."],
 need:["Kubiklar (Lego, shakar).","Qutilar, chizg'ich.","27 kubikli kub yoki Rubik kubigi."],
 board:["<span class='w2'>V = 4 · 3 · 2 = 24</span>.","<span class='w2'>h = 120 : (5 · 4) = 6</span>.","<span class='w2'>20 dm · 5 dm · 3 dm = 300 dm³</span>.","Sirt: <span class='w2'>48 + 36 + 24 = 108</span>.","4×4×4: 8 / 24 / 24 / 8."]};
