var CODE='2H10',TITLE="2-sinf · Simmetriya va oynadagi aks";
function hAMsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function hAAxis(x,y1,y2){E('line',{x1:x,y1:y1,x2:x,y2:y2,stroke:C.blue,'stroke-width':2,'stroke-dasharray':'6 4'},S.g)}
// kapalak
function hAFly(spots,mir){clear();var g=S.g,cx=180;E('ellipse',{cx:cx-58,cy:70,rx:56,ry:42,fill:'#ffd166',stroke:C.line,'stroke-width':1.6},g);E('ellipse',{cx:cx-46,cy:132,rx:40,ry:28,fill:'#ffc045',stroke:C.line,'stroke-width':1.6},g);
 E('ellipse',{cx:cx+58,cy:70,rx:56,ry:42,fill:'#ffd166',stroke:C.line,'stroke-width':1.6},g);E('ellipse',{cx:cx+46,cy:132,rx:40,ry:28,fill:'#ffc045',stroke:C.line,'stroke-width':1.6},g);E('rect',{x:cx-5,y:34,width:10,height:120,rx:5,fill:'#6b3d12'},g);hAAxis(cx,10,170);
 spots.forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:8,fill:'#e85a5a'},g);if(mir)E('circle',{cx:2*cx-p[0],cy:p[1],r:8,fill:'#e85a5a',opacity:.85},g)});
 var hit=E('rect',{x:20,y:20,width:150,height:150,fill:'transparent',style:'cursor:pointer'},g);hit.addEventListener('click',function(ev){if(!S.flyTap)return;var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());S.flyTap(p.x,p.y)})}
// katak to'ldirish: 8x6, o'q o'rtada
var HAL=[[0,1],[1,1],[1,2],[2,2],[2,3],[3,3],[1,4],[0,4]]; // chap yarmidagi bo'yalgan kataklar (ustun 0..3, qator 0..5)
function hAGrid(right,show){clear();var g=S.g,x0=72,y0=4,c=27;S.cellsA=[];
 for(var r=0;r<6;r++)for(var q=0;q<8;q++){var on=q<4?HAL.some(function(p){return p[0]===3-q&&p[1]===r})||HAL.some(function(p){return p[0]===q&&p[1]===r}):false;
  var leftOn=q<4&&HAL.some(function(p){return p[0]===q&&p[1]===r});var rr=q>=4&&right[r+','+q];var need=q>=4&&HAL.some(function(p){return 7-p[0]===q&&p[1]===r});
  var f=leftOn?C.a:(rr?(show&&!need?'#fdeaea':C.b):(show&&need?'#ffe9a8':'#fff'));var e=E('rect',{x:x0+q*c,y:y0+r*c,width:c-1,height:c-1,fill:f,stroke:'#c9d3dd'},g);
  if(q>=4){(function(r,q,e){e.style.cursor='pointer';e.addEventListener('click',function(){if(S.gridTap)S.gridTap(r,q)})})(r,q,e)}}
 hAAxis(x0+4*c-.5,4,y0+6*c+6)}
function hAGridOk(right){var need={};HAL.forEach(function(p){need[p[1]+','+(7-p[0])]=1});for(var k in right)if(right[k]&&!need[k])return false;for(var k2 in need)if(!right[k2])return false;return true}
// harf/raqam oynada
function hAMirror(ch,mode){clear();var g=S.g;T(g,100,110,ch,{'font-size':80,'font-weight':800,fill:'#1d2b3a','font-family':'Arial,Helvetica,sans-serif'});hAAxis(180,20,150);
 var m=E('g',{transform:mode==='flip'?'translate(260,82) rotate(180) translate(-260,-82)':'translate(520,0) scale(-1,1)'},g);T(m,260,110,ch,{'font-size':80,'font-weight':800,fill:C.blue,'font-family':'Arial,Helvetica,sans-serif'});
 T(g,100,156,'asl',{'font-size':11,fill:'#5b6b7b'});T(g,260,156,mode==='flip'?'teskari (boshi pastga)':'oynadagi aksi',{'font-size':11,fill:C.blue})}
var P6=[function(){hAFold(0);hAMsg('Qog‘oz ikki buklandi')},function(){hAFold(1);hAMsg('Buklangan joydan yarim doira qirqildi')},function(){hAFold(2);hAMsg('Ochganda — <b>butun doira</b>! Buklanish chizig‘i — simmetriya o‘qi')}];
function hAFold(k){clear();var g=S.g;if(k<2){E('rect',{x:140,y:30,width:90,height:120,fill:'#fff',stroke:C.line,'stroke-width':1.6},g);E('line',{x1:140,y1:30,x2:140,y2:150,stroke:C.blue,'stroke-width':3},g);T(g,128,95,'bukilgan',{'font-size':10,fill:C.blue,'text-anchor':'end'});if(k===1)E('path',{d:'M140 62 A28 28 0 0 1 140 118 Z',fill:'#fdf3e3',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g)}
 else{E('rect',{x:90,y:30,width:180,height:120,fill:'#fff',stroke:C.line,'stroke-width':1.6},g);hAAxis(180,26,154);E('circle',{cx:180,cy:90,r:28,fill:'#fdf3e3',stroke:C.bad,'stroke-width':2},g)}}
var P7=[function(){hAAxes(0);hAMsg('Kvadratning nechta simmetriya o‘qi bor?')},function(){hAAxes(1);hAMsg('Tik va yotiq — 2 ta')},function(){hAAxes(2);hAMsg('Yana 2 ta diagonal — jami <b>4 ta</b>. Burchakdan tomon o‘rtasiga emas!')}];
function hAAxes(k){clear();var g=S.g,x=120,y=25,s=120;E('rect',{x:x,y:y,width:s,height:s,fill:'#e8f1fb',stroke:C.blue,'stroke-width':2},g);
 function L(a,b,c,d,col){E('line',{x1:a,y1:b,x2:c,y2:d,stroke:col||C.ok,'stroke-width':2.5,'stroke-dasharray':'6 4'},g)}
 if(k>=1){L(x+s/2,y-10,x+s/2,y+s+10);L(x-10,y+s/2,x+s+10,y+s/2)}if(k>=2){L(x-8,y-8,x+s+8,y+s+8,C.a);L(x+s+8,y-8,x-8,y+s+8,C.a)}}
var STEPS=[
{h:"Kapalak qanotlari",sum:"Simmetrik shaklning bir yarmi ikkinchisining oynadagi aksi. Chapda 4 dog' — o'ngda ham 4, jami 8.",a:"m01",
 start:function(){S.sp=[];hAFly([],true);S.flyTap=function(x,y){if(S.sp.length>=6)return;S.sp.push([x,y]);hAFly(S.sp,true);hAMsg('Chap qanotda '+S.sp.length+' ta dog‘ — o‘ngda ham '+S.sp.length+' ta. Jami <b>'+(2*S.sp.length)+'</b>');if(S.sp.length===3&&S.dA){var d=S.dA;S.dA=null;d()}};hAMsg('Chap qanotga bosib dog‘ qo‘ying')},
 fin:function(){hAFly([[110,60],[130,80],[140,132]],true);hAMsg('Chapda 3 — o‘ngda 3 — jami 6')},
 html:"<p>Kapalakning <b>chap</b> qanotiga bosib, dog'lar qo'ying (3 ta). O'ng qanotda nima bo'lishini kuzating.</p>",
 act:function(c,done){S.dA=done;c.querySelector('.hint').textContent='Rasmdagi chap qanotni bosing.'},
 after:"<p>Har bir dog' o'ng qanotda <b>oynadagidek</b> paydo bo'ladi: o'rta chiziqdan bir xil uzoqlikda, teskari tomonda. Bunday shakl <b>simmetrik</b>, o'rtadagi chiziq esa <b>simmetriya o'qi</b> deyiladi.</p>",
 q:{t:"Kapalakning chap qanotida 4 ta dog' bor, qanotlari simmetrik. Ikkala qanotda jami nechta dog'?",opts:["4","8","16","6"],ok:1,why:"O'ngda ham 4 ta: 4 + 4 = 8.",hint:"O'ng qanotda nechta dog' bo'ladi?",full:"Simmetrik bo'lgani uchun o'ngda ham 4 ta: 4 + 4 = 8. «16» — ko'paytirib yuborish xatosi."},
 tn:"Bo'yoqni qog'ozning bir yarmiga tomizib, buklab oching — «kapalak» chiqadi. Bu klassik usul simmetriyani juda yaxshi ko'rsatadi."},
{h:"Buklab tekshirish",sum:"Shakl o'q bo'ylab buklanganda ikki yarmi ustma-ust tushsa — simmetrik.",a:"m02",
 start:function(){hAHeart(false)},fin:function(){hAHeart(true)},
 html:"<p>Shaklning simmetrikligini qanday tekshiramiz? <b>Buklab ko'ramiz!</b> Yurak va bayroqni o'rtasidan buklang:</p>",
 btns:[["📄 Buklash",function(c,done,b){b.disabled=true;hAHeart(true);done()}]],
 after:"<p>Yurakning ikki yarmi ustma-ust tushdi — u <b>simmetrik</b>. Bayroqning yarmlari tushmadi — <b>simmetrik emas</b>. Buklash — eng ishonchli tekshiruv.</p>",
 q:{t:"Qaysi shakl o'rtasidan buklanganda ikki yarmi ustma-ust tushadi?",opts:["F harfi","yurak","3 raqami (yonidan)","L harfi"],ok:1,why:"Yurak — tik o'qqa nisbatan simmetrik.",hint:"Qaysi shaklning chap va o'ng yarmi bir xil?",full:"Yurakning chap yarmi o'ng yarmining oynadagi aksi — buklasa tushadi. F, L harflarining chap va o'ng tomoni har xil."},
 tn:"Qog'ozdan yurak, uchburchak, F harfi kesib, bolalar o'zi buklab tekshirsin."},
{h:"Oynadagi harflar",sum:"A, M, T, H, O oynada o'zgarmaydi; F, R, L, S teskari bo'ladi.",a:"m03",
 start:function(){hAMirror('A');hAMsg('Harflarni bosib, oynadagi aksini ko‘ring')},fin:function(){hAMirror('F');hAMsg('F — oynada teskari')},
 html:"<p>Harf oynaga qaratilsa, aksi qanday ko'rinadi? Harflarni bosing:</p>",
 btns:[["A",function(c,done){hAMirror('A');hAMsg('A — oynada <b>o‘zgarmadi</b>');mvK(done,3)}],["F",function(c,done){hAMirror('F');hAMsg('F — oynada <b>teskari</b> bo‘ldi');mvK(done,3)}],["M",function(c,done){hAMirror('M');hAMsg('M — <b>o‘zgarmadi</b>');mvK(done,3)}],["R",function(c,done){hAMirror('R');hAMsg('R — <b>teskari</b>');mvK(done,3)}],["T",function(c,done){hAMirror('T');hAMsg('T — <b>o‘zgarmadi</b>');mvK(done,3)}],["L",function(c,done){hAMirror('L');hAMsg('L — <b>teskari</b>');mvK(done,3)}]],g3:1,
 after:"<p>Oynada <b>o'zgarmaydigan</b> harflarning o'rtasidan tik simmetriya o'qi o'tadi: A, H, M, O, T, U, V, W, X, Y. Qolganlari (F, R, L, S, N, Z…) teskari ko'rinadi.</p>",
 q:{t:"Qaysi bosma harf oynada o'zgarmay ko'rinadi?",opts:["F","R","L","A"],ok:3,why:"A ning tik simmetriya o'qi bor.",hint:"Qaysi harfni o'rtasidan tik buklasa, yarmlari tushadi?",full:"A ni o'rtasidan tik buklasak, ikki yarmi ustma-ust tushadi — oynada o'zgarmaydi. F, R, L ning o'ng va chap tomoni har xil."},
 tn:"Sinfda kichik oyna bilan har bir bola o'z ismini «oynaga» yozib ko'rsin — qaysi harflar o'zgarmasligini topsin."},
{h:"Raqamlar: oynada va teskari",sum:"8 va 0 boshi pastga qilinsa ham o'zgarmaydi; 6 ↔ 9 bo'lib qoladi.",a:"m04",
 start:function(){hAMirror('8','flip');hAMsg('Raqamni bosing — boshi pastga aylantiramiz')},fin:function(){hAMirror('6','flip');hAMsg('6 teskari aylantirilsa — 9')},
 html:"<p>Raqamni <b>boshi pastga</b> (180°) aylantirsak nima bo'ladi? Bosib ko'ring:</p>",
 btns:[["8",function(c,done){hAMirror('8','flip');hAMsg('8 — <b>o‘zgarmadi</b>');mvK(done,3)}],["6",function(c,done){hAMirror('6','flip');hAMsg('6 → <b>9</b> bo‘lib qoldi!');mvK(done,3)}],["7",function(c,done){hAMirror('7','flip');hAMsg('7 — raqamga o‘xshamay qoldi');mvK(done,3)}],["0",function(c,done){hAMirror('0','flip');hAMsg('0 — <b>o‘zgarmadi</b>');mvK(done,3)}]],g2:1,
 after:"<p>Boshi pastga aylantirilganda <b>0</b> va <b>8</b> o'zgarmaydi, <b>6</b> esa <b>9</b> ga aylanadi (va aksincha). Shuning uchun «86» teskari qilinsa «98» bo'ladi — bunday jumboqlar testda keladi.</p>",
 q:{t:"Qaysi raqam boshi pastga aylantirilganda o'zgarmaydi?",opts:["7","6","8","9"],ok:2,why:"8 ning yuqori va pastki qismi bir xil.",hint:"Qaysi raqamning tepasi va pasti bir xil?",full:"8 ni 180° aylantirsak, yana 8. 6 → 9 ga, 9 → 6 ga aylanadi, 7 esa raqamga o'xshamay qoladi."},
 tn:"Raqam kartochkalarini teskari ushlab ko'rsating — bolalar «qaysi o'zgarmadi?» deb javob bersin."},
{h:"Rasmni simmetrik to'ldiring",sum:"O'qdan bir xil uzoqlikda, teskari tomonda bo'yaymiz.",a:"m05",
 start:function(){S.rt={};hAGrid(S.rt);S.gridTap=function(r,q){var k=r+','+q;S.rt[k]=!S.rt[k];hAGrid(S.rt)};hAMsg('O‘ng yarmidagi kataklarni bosing')},fin:function(){var R={};HAL.forEach(function(p){R[p[1]+','+(7-p[0])]=1});hAGrid(R);hAMsg('To‘g‘ri: rasm simmetrik')},
 html:"<p>Rasmning chap yarmi tayyor. O'ng yarmini <b>simmetrik</b> qilib bo'yang: ko'k o'qdan har bir katak bir xil uzoqlikda bo'lsin. Keyin «Tekshirish»ni bosing.</p>",
 btns:[["✔ Tekshirish",function(c,done){if(hAGridOk(S.rt)){hAMsg('Zo‘r! Rasm simmetrik');done()}else{hAGrid(S.rt,true);hAMsg('Hali emas: sariq — bo‘yalishi kerak, pushti — ortiqcha. O‘qdan sanang: 1-ustun, 2-ustun…')}}]],
 after:"<p>Usul: har bir bo'yalgan katakning o'qdan <b>nechanchi</b> ustunda ekanini sanaymiz va o'ng tomonda ham shuncha uzoqlikda bo'yaymiz. Qator (balandlik) o'zgarmaydi!</p>",
 q:{t:"Chap tomondagi katak o'qdan 3-ustunda, 2-qatorda. Uning simmetrigi qayerda?",opts:["o'ngda 2-ustun, 3-qator","o'ngda 3-ustun, 2-qator","chapda 3-ustun","o'ngda 1-ustun, 2-qator"],ok:1,why:"Uzoqlik va qator saqlanadi, faqat tomon almashadi.",hint:"O'qdan uzoqlik o'zgaradimi? Qator-chi?",full:"Oynada uzoqlik bir xil (3-ustun) va balandlik bir xil (2-qator), faqat tomoni o'zgaradi — o'ngga. «2-ustun, 3-qator» — raqamlarni almashtirib yuborish xatosi."},
 tn:"Katakli daftarda bolalar yarim rasm chizib, sherigiga to'ldirishga bersin."},
{h:"Bukib qirqish",sum:"Ikki buklab yarim doira qirqilsa, ochganda butun doira chiqadi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p><i>«Qog'oz ikki buklandi va buklangan joyidan yarim doira shaklida qirqildi. Qog'oz ochilganda qanday teshik ko'rinadi?»</i></p>",
 btns:[phaser(P6)],
 after:"<p>Buklangan chiziq — simmetriya o'qi. Yarim doira o'qning ikki tomonida takrorlanadi — <b>butun doira</b> chiqadi. «Ikkita yarim doira» deganlar buklanish joyida qirqilganini unutgan.</p>",
 q:{t:"Ikki buklangan qog'oz buklanish chizig'idan uchburchak yarmi shaklida qirqildi. Ochganda nima chiqadi?",opts:["ikkita kichik uchburchak","butun (katta) uchburchak","kvadrat","yarim doira"],ok:1,why:"Yarim shakl o'q bo'ylab ikkiga ko'payib, butun shakl hosil qiladi.",hint:"Qirqilgan joy buklanish chizig'iga tegib turibdimi?",full:"Qirqim buklanish chizig'idan boshlangani uchun ochganda ikki yarmi birlashib, bitta butun uchburchak bo'ladi. Agar chiziqqa tegmaganida ikkita alohida teshik chiqardi."},
 tn:"Albatta amalda qiling: qog'oz, qaychi. Bolalar avval taxmin qilsin, keyin ochib ko'rsin."},
{h:"Nechta simmetriya o'qi?",sum:"Kvadrat — 4 o'q (tik, yotiq, 2 diagonal). To'g'ri to'rtburchak — 2, doira — juda ko'p.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Bitta shaklda bir nechta simmetriya o'qi bo'lishi mumkin. Kvadratni ko'raylik:</p>",
 btns:[phaser(P7)],
 after:"<p>Kvadrat: tik, yotiq va 2 ta diagonal — <b>4 ta o'q</b>. To'g'ri to'rtburchakda faqat <b>2 ta</b> (diagonal bo'ylab buklasa tushmaydi!). Doirada esa markazdan o'tgan <b>har qanday</b> chiziq — o'q.</p>",
 q:{t:"Kvadratni qaysi chiziq bo'ylab buklaganda ikki yarmi ustma-ust TUSHMAYDI?",opts:["diagonal bo'ylab","qarama-qarshi tomonlar o'rtasini tutashtiruvchi chiziq","ikkinchi diagonal bo'ylab","bir uchidan unga tegmaydigan tomon o'rtasiga"],ok:3,why:"Burchakdan qo'shni bo'lmagan tomon o'rtasiga chiziq — o'q emas.",hint:"Kvadratning 4 ta o'qini eslang. Qaysi chiziq ularning ichida yo'q?",full:"Kvadratning o'qlari: 2 diagonal va tomonlar o'rtalarini tutashtiruvchi 2 chiziq. Burchakdan tomon o'rtasiga chiziq — o'q emas, yarmlari tushmaydi."},
 tn:"Qog'oz kvadrat va to'g'ri to'rtburchak bering — bolalar barcha buklash usullarini sinab, o'qlarni sanasin."},
{h:"Bilasizmi? Simmetriya atrofimizda",sum:"Samarqanddagi Registon madrasalari peshtoqlari simmetrik; qor uchqunining 6 ta o'qi bor.",a:"m08",
 start:function(){hAFly([[110,60],[130,80]],true);hAMsg('Tabiat simmetriyani yaxshi ko‘radi')},fin:function(){hAFly([[110,60],[130,80]],true);hAMsg('Tabiat simmetriyani yaxshi ko‘radi')},
 html:"<p>🕌 Samarqanddagi <b>Registon</b> madrasalarining peshtoqlari va naqshlari simmetrik qilib qurilgan — ustalar ming yillardan beri simmetriyadan foydalanadi.</p><p>❄️ Har bir <b>qor uchquni</b> 6 ta nurli bo'ladi va 6 ta simmetriya o'qiga ega. Odam yuzi, kapalak, barglar ham deyarli simmetrik.</p>",
 tn:"Bolalar uyda simmetrik narsalarni topib (gilam naqshi, barg, idish) rasmini chizib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){P7[2]()},fin:function(){P7[2]()},
 html:"<div class='memo'><ul><li><b>Simmetrik</b> shakl o'q bo'ylab buklansa, ikki yarmi ustma-ust tushadi.</li><li>Simmetrik nuqta o'qdan <b>bir xil uzoqlikda</b>, teskari tomonda; balandligi o'zgarmaydi.</li><li>Oynada o'zgarmaydi: A, H, M, O, T, U, V, W, X, Y.</li><li>Teskari (180°): 0, 8 o'zgarmaydi; 6 ↔ 9.</li><li>Buklab qirqilgan yarim shakl ochilganda butun shakl bo'ladi.</li><li>O'qlar soni: kvadrat — 4, to'g'ri to'rtburchak — 2, doira — cheksiz.</li></ul></div>",
 tn:"Keyingi darsni «Ismingizdagi qaysi harflar oynada o'zgarmaydi?» savoli bilan boshlang."}
];
function hAHeart(fold){clear();var g=S.g;var hp='M90 60 C90 40 60 30 50 55 C40 80 70 100 90 120 C110 100 140 80 130 55 C120 30 90 40 90 60 Z';
 if(!fold){E('path',{d:hp,fill:'#f08aa8',stroke:C.line,'stroke-width':1.6},g);hAAxis(90,20,140);E('rect',{x:210,y:40,width:90,height:56,fill:'#5aa9e6',stroke:C.line},g);E('rect',{x:210,y:40,width:40,height:56,fill:'#e85a5a',stroke:C.line},g);E('line',{x1:210,y1:40,x2:210,y2:150,stroke:'#6b3d12','stroke-width':3},g);hAAxis(255,20,150);hAMsg('O‘rtasidan buklaymiz…')}
 else{E('path',{d:'M90 60 C90 40 60 30 50 55 C40 80 70 100 90 120 Z',fill:'#f08aa8',stroke:C.line,'stroke-width':1.6},g);E('path',{d:'M90 60 C90 40 60 30 50 55 C40 80 70 100 90 120 Z',fill:'none',stroke:C.ok,'stroke-width':2.5,'stroke-dasharray':'5 3'},g);T(g,90,150,'✓ ustma-ust tushdi',{'font-size':12,'font-weight':800,fill:C.ok});
  E('rect',{x:210,y:40,width:45,height:56,fill:'#e85a5a',stroke:C.line},g);E('rect',{x:215,y:40,width:40,height:56,fill:'none',stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'5 3'},g);E('rect',{x:250,y:40,width:5,height:56,fill:'#5aa9e6'},g);T(g,255,150,'✗ tushmadi (ranglar har xil)',{'font-size':12,'font-weight':800,fill:C.bad});hAMsg('Yurak — simmetrik, bayroq — simmetrik emas')}}
var PROBS=[
{t:"Kapalakning chap qanotida 5 ta dog' bor, qanotlari simmetrik. Jami nechta dog'?",o:["10","5","25","15"],k:0,s:"5 + 5 = 10."},
{t:"Qaysi bosma harf oynada o'zgarmay ko'rinadi?",o:["T","F","R","L"],k:0,s:"T ning tik o'qi bor."},
{t:"Qaysi raqam boshi pastga aylantirilganda o'zgarmaydi?",o:["8","7","6","9"],k:0,s:"8 — yuqori va pasti bir xil."},
{t:"Qaysi raqamni o'rtasidan tik chiziq bilan bo'lsak, ikki yarmi oynadagidek mos keladi?",o:["8","7","5","3"],k:0,s:"8 ning tik o'qi bor."},
{t:"Qog'oz ikki buklanib, buklanish joyidan yarim doira qirqildi. Ochganda qanday teshik?",o:["doira","yarim doira","ikkita yarim doira","kvadrat"],k:0,s:"Yarim doira o'q bo'ylab to'liq doiraga aylanadi."},
{t:"Kvadratning nechta simmetriya o'qi bor?",o:["4","2","1","8"],k:0,s:"Tik, yotiq, 2 diagonal."},
{t:"To'g'ri to'rtburchakning (kvadrat emas) nechta simmetriya o'qi bor?",o:["2","4","1","0"],k:0,s:"Tik va yotiq. Diagonal — o'q emas."},
{t:"66 sonini boshi pastga aylantirsak qaysi son chiqadi?",o:["99","66","69","96"],k:0,s:"6 → 9, joylari ham almashadi: 99."},
{t:"86 sonini boshi pastga aylantirsak qaysi son ko'rinadi?",o:["98","86","68","89"],k:0,s:"86 → raqamlar 9 va 8 ga, tartib teskari: 98."},
{t:"Qaysi so'z oynada o'zgarmay o'qiladi (bosma katta harflarda)?",o:["OTA","ONA","ARRA","KIT"],k:0,s:"OTA ni o'rtasidan… aslida harflar O, T, A simmetrik va so'z ham teskari o'qilganda «ATO» — diqqat!"},
{t:"Qaysi harfning simmetriya o'qi yo'q?",o:["F","A","H","O"],k:0,s:"F ni hech qanday buklasa yarmlari tushmaydi."},
{t:"Chapdagi katak o'qdan 2-ustunda, 4-qatorda. Simmetrigi qayerda?",o:["o'ngda 2-ustun, 4-qator","o'ngda 4-ustun, 2-qator","chapda 2-ustun, 4-qator","o'ngda 1-ustun, 4-qator"],k:0,s:"Uzoqlik va qator saqlanadi."},
{t:"Doiraning nechta simmetriya o'qi bor?",o:["juda ko'p (cheksiz)","1","2","4"],k:0,s:"Markazdan o'tgan har chiziq — o'q."},
{t:"Teng tomonli uchburchakning nechta simmetriya o'qi bor?",o:["3","1","2","6"],k:0,s:"Har uchidan qarshi tomon o'rtasiga — 3 ta."},
{t:"Soat 3:00 ni ko'rsatmoqda. Oynada qaraganda strelkalar qaysi vaqtni ko'rsatgandek bo'ladi?",o:["9:00","3:00","6:00","12:00"],k:0,s:"O'ngdagi 3 oynada chapga — 9 ga o'tadi."},
{t:"Qaysi raqam oynada (tik o'q bilan) o'zgarmaydi?",o:["0","2","4","7"],k:0,s:"0 ning tik o'qi bor."},
{t:"Qog'oz 2 marta buklandi (4 qavat) va burchagidan kichik teshik ochildi (buklanish chiziqlariga tegmasdan). Ochganda nechta teshik?",o:["4","1","2","8"],k:0,s:"Har qavatda bittadan — 4 ta."},
{t:"Simmetrik gulning bir tomonida 3 ta barg bor. Jami nechta barg?",o:["6","3","9","5"],k:0,s:"3 + 3 = 6."},
{t:"Qaysi shakl simmetrik emas?",o:["bayroq (ikki xil rangli tomonlar)","yurak","kvadrat","doira"],k:0,s:"Bayroqning yarmlari ranglari har xil."},
{t:"Boshi pastga aylantirilsa ham o'zgarmaydigan ikki xonali son qaysi?",o:["88","86","66","81"],k:0,s:"88 → 88. 66 → 99, 86 → 98."}
];
// 10-misol izohini aniqlashtiramiz
PROBS[9]={t:"Qaysi so'zning hamma harflari oynada (tik o'q bilan) o'zgarmaydi?",o:["OTA","ONA","KIT","SUV"],k:0,s:"O, T, A — hammasining tik o'qi bor. N, K, S — yo'q."};
function PRACT_STAGE(){hAAxes(2);hAMsg('Simmetriya: buklab tekshiring')}
var PREP_DATA={teach:["Simmetriya o'qi; simmetrik shakl buklanganda ustma-ust tushadi.","Oynadagi aks: harflar va raqamlar; 180° aylantirish (6 ↔ 9).","Katakda simmetrik to'ldirish: uzoqlik saqlanadi.","Bukib qirqish; shakllarning o'qlari soni."],
 mist:["Simmetrik nuqtani o'qdan boshqa uzoqlikka qo'yadi.","Oynada aksni 180° aylantirish bilan adashtiradi.","To'g'ri to'rtburchakda diagonalni ham o'q deb hisoblaydi.","Bukib qirqishda «ikkita yarim doira» deydi."],
 need:["Qog'oz, qaychi, bo'yoq.","Kichik oyna, katakli daftar."],
 board:["Kapalak: o'q, ikki tomonda bir xil dog'lar.","Harflar: A H M O T U V W X Y — o'zgarmaydi.","Raqamlar (180°): 0, 8 — o'zgarmaydi, 6 ↔ 9.","Katak: o'qdan sanash — 1-, 2-, 3-ustun.","O'qlar: kvadrat 4, to'g'ri to'rtburchak 2."]};
