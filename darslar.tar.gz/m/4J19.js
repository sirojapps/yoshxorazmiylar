var CODE='4J19',TITLE="4-sinf · Algoritmlar va blok-sxemalar";
function q19Cards(a,hl,cap){clear();var g=S.g,n=a.length,w=56,x0=180-(n*w+(n-1)*12)/2;a.forEach(function(v,i){var x=x0+i*(w+12),on=hl&&hl.indexOf(i)>=0;E('rect',{x:x,y:40,width:w,height:70,rx:10,fill:on?'#fff1df':'#fff',stroke:on?'#e07a2f':'#c9d3dd','stroke-width':on?3:2},g);T(g,x+w/2,86,v,{'font-size':28,'font-weight':900,fill:on?'#e07a2f':'#1d2b3a'})});if(cap)T(g,180,140,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
function q19Box(lines){clear();var g=S.g,y=18;lines.forEach(function(l){var w=l[1]||220,h=26;if(l[2]==='r')E('polygon',{points:(180-w/2)+','+(y+h/2)+' 180,'+y+' '+(180+w/2)+','+(y+h/2)+' 180,'+(y+h),fill:'#fff7d6',stroke:'#d9a441','stroke-width':2},g);else E('rect',{x:180-w/2,y:y,width:w,height:h,rx:l[2]==='o'?13:5,fill:l[2]==='o'?'#e6f6ee':'#eaf3fb',stroke:l[2]==='o'?C.ok:C.blue,'stroke-width':2},g);T(g,180,y+18,l[0],{'font-size':12,'font-weight':800,fill:'#1d2b3a'});y+=h+12})}
function q19Table(rows){clear();var g=S.g,n=rows[0].length,w=300/n,x0=30;rows.forEach(function(r,j){r.forEach(function(v,i){var x=x0+i*w,y=50+j*40;E('rect',{x:x,y:y,width:w,height:40,fill:i===0?'#eaf3fb':(j?'#fff':'#f6f8fa'),stroke:'#c9d3dd'},g);T(g,x+w/2,y+26,v,{'font-size':i===0?12:16,'font-weight':900,fill:j&&i?C.blue:'#1d2b3a'})})})}
var P1=[function(){q19Box([["Boshlash: x = 1",150,'o'],["x = x · 2",130],["5 marta bo'ldimi?",190,'r'],["Natija: x",130,'o']]);j2Msg("Sikl: bitta buyruq 5 marta takrorlanadi. Jadval bilan kuzatamiz.")},
 function(){q19Table([["qadam","1","2","3","4","5"],["x","2","4","8","16","32"]]);j2Msg("Har qadamda x ikki barobar: 2, 4, 8, 16, <b>32</b>.")}];
var P2=[[6],[6,3],[6,3,10],[6,3,10,5],[6,3,10,5,16],[6,3,10,5,16,8],[6,3,10,5,16,8,4,2,1]].map(function(a,k,all){return function(){j2Lines([[a.join(" → "),C.blue,a.length>6?14:17],[k===0?"juft → : 2,  toq → · 3 + 1":(k===all.length-1?"8 qadamda 1 ga yetdi!":(a[a.length-1]%2?"toq: · 3 + 1":"juft: : 2")),k===all.length-1?C.ok:null,15]]);j2Msg(k===0?"Qoida: son juft bo'lsa — 2 ga bo'l, toq bo'lsa — 3 ga ko'paytirib 1 qo'sh. 1 ga yetguncha takrorla.":"Davom etamiz…")}});
var P3=[[[5,2,4,1],[0,1],"5 > 2 → almashtiramiz"],[[2,5,4,1],[1,2],"5 > 4 → almashtiramiz"],[[2,4,5,1],[2,3],"5 > 1 → almashtiramiz"],[[2,4,1,5],[3],"1-o'tish: eng kattasi (5) oxiriga «suzib chiqdi»"],[[2,1,4,5],[1,2],"2-o'tish: 4 > 1 → almashtiramiz"],[[1,2,4,5],[0,1],"3-o'tish: 2 > 1 → almashtirish. Jami 5 ta almashtirish"]].map(function(s){return function(){q19Cards(s[0],s[1],s[2]);j2Msg(s[2])}});
var P4=[function(){j2Lines([["1 … 100",C.blue,26],["son o'ylandi: 37",null,15]]);j2Msg("Do'stingiz 1 dan 100 gacha son o'yladi. Faqat «katta» / «kichik» javoblari bilan topamiz.")},
 function(){j2Lines([["50? → kichik  (1–49)",null,15],["25? → katta  (26–49)",null,15],["37? → topdik!",C.ok,17]]);j2Msg("Har savol oraliqni <b>yarmiga</b> qisqartiradi: 100 → 50 → 25 → 13 → 7 → 4 → 2 → 1.")},
 function(){j2Lines([["2 · 2 · 2 · 2 · 2 · 2 · 2 = 128 ≥ 100",C.blue,15],["ko'pi bilan 7 ta savol",C.ok,20]]);j2Msg("7 ta savol 128 tagacha sonni ajratadi — 100 uchun yetadi.")}];
function q19Bridge(L,R,t,cap){clear();var g=S.g;E('rect',{x:130,y:80,width:100,height:16,rx:4,fill:'#a0784a'},g);E('rect',{x:0,y:96,width:130,height:70,fill:'#d9efe0'},g);E('rect',{x:230,y:96,width:130,height:70,fill:'#d9efe0'},g);E('rect',{x:130,y:110,width:100,height:56,fill:'#bfe3f5'},g);
 L.forEach(function(p,i){T(g,25+i*28,80,'🧍',{'font-size':22});T(g,25+i*28,112,p,{'font-size':12,'font-weight':900,fill:'#1d2b3a'})});R.forEach(function(p,i){T(g,255+i*28,80,'🧍',{'font-size':22});T(g,255+i*28,112,p,{'font-size':12,'font-weight':900,fill:'#1d2b3a'})});
 T(g,180,40,'⏱ '+t+' daqiqa',{'font-size':16,'font-weight':900,fill:C.blue});if(cap)T(g,180,150,cap,{'font-size':11,'font-weight':800,fill:'#0b4f7a'})}
var P6=[[[1,2,5,10],[],0,"Fonar chapda"],[[5,10],[1,2],2,"1 va 2 o'tdi (2)"],[[1,5,10],[2],3,"1 fonarni qaytardi (1)"],[[1],[2,5,10],13,"5 va 10 BIRGA o'tdi (10)"],[[1,2],[5,10],15,"2 fonarni qaytardi (2)"],[[],[1,2,5,10],17,"1 va 2 o'tdi (2) — jami 17!"]].map(function(s){return function(){q19Bridge(s[0],s[1],s[2],s[3]);j2Msg(s[3])}});
var STEPS=[
{h:"Sikl: takrorlash",sum:"x = 1, 5 marta x = x · 2 → 32.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>Kompyuter bir ishni ko'p marta takrorlashni yaxshi ko'radi. Bu — <b>sikl</b>. Natijani jadval bilan kuzatamiz.</p>",
 btns:[phaser(P1)],
 after:"<p>Siklni tushunishning eng ishonchli yo'li — <b>jadval</b>: har qadamdan keyin o'zgaruvchining qiymatini yozish.</p>",
 q:{t:"x = 3. 4 marta takrorla: x = x + 5. Natija?",opts:["20","23","35","8"],ok:1,why:"3 → 8 → 13 → 18 → 23.",hint:"Har qadamni yozing: 3 + 5 = …",full:"3 + 5 = 8, 8 + 5 = 13, 13 + 5 = 18, 18 + 5 = 23. «20» — 4 · 5 ni hisoblab, boshlang'ich 3 ni unutgan."},
 tn:"Doskada jadval: «qadam | x». Bolalar navbat bilan to'ldirsin."},
{h:"Shart + sikl: sehrli zanjir",sum:"Juft — 2 ga bo'l, toq — ·3 + 1: 6 → 3 → 10 → 5 → 16 → 8 → 4 → 2 → 1 (8 qadam).",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=6;P2[6]()},
 html:"<p>Algoritm ichida <b>shart</b> («agar … bo'lsa») va <b>sikl</b> («… bo'lguncha takrorla») birga.</p>",
 btns:[phaser(P2)],
 after:"<p>Bu «Kollats zanjiri». Har qanday natural sondan boshlasangiz ham oxiri 1 ga yetadi deb taxmin qilinadi — lekin hali hech kim isbotlay olmagan!</p>",
 q:{t:"Shu qoida bilan 5 dan boshlab necha qadamda 1 ga yetadi?",opts:["4","5","6","16"],ok:1,why:"5 → 16 → 8 → 4 → 2 → 1: 5 qadam.",hint:"5 toq: 5 · 3 + 1 = ?",full:"5 → 16 (toq) → 8 → 4 → 2 → 1 — 5 ta o'tish. «16» — qadam o'rniga eng katta sonni olgan."},
 tn:"Har bola o'z sonidan zanjir tuzsin. 27 dan boshlasa juda uzoq ketadi (111 qadam) — qiziq tajriba."},
{h:"Saralash: pufakcha usuli",sum:"Qo'shnilar taqqoslanadi, kattasi o'ngga: 5, 2, 4, 1 → 5 ta almashtirish.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=5;P3[5]()},
 html:"<p>Kartochkalarni kichikdan kattaga qanday tartiblaymiz? Kompyuterning eng oddiy usuli — <b>pufakcha</b>: qo'shni ikkitasini solishtir, noto'g'ri bo'lsa — almashtir.</p>",
 btns:[phaser(P3)],
 after:"<p>Har o'tishda eng katta son pufakcha kabi oxiriga «suzib chiqadi». Almashtirishlar soni = noto'g'ri tartibdagi juftlar soni.</p>",
 q:{t:"3, 1, 2 ni pufakcha usulida tartiblash uchun nechta almashtirish kerak?",opts:["1","2","3","6"],ok:1,why:"3,1 → 1,3,2; 3,2 → 1,2,3.",hint:"Qaysi juftlar noto'g'ri tartibda: (3,1), (3,2), (1,2)?",full:"3 > 1 — almashtirish: 1, 3, 2. 3 > 2 — almashtirish: 1, 2, 3. Jami 2. Noto'g'ri juftlar ham 2 ta: (3,1) va (3,2)."},
 tn:"4–5 bola qo'lida son kartochkasi bilan qatorga tursin — faqat qo'shnilar joy almashsin."},
{h:"Ikkiga bo'lib qidirish",sum:"Har savol oraliqni yarmiga qisqartiradi: 1–100 uchun ko'pi bilan 7 savol.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«Son top» o'yinida eng aqlli strategiya qanday?</p>",
 btns:[phaser(P4)],
 after:"<p>Bu — <b>ikkilik qidiruv</b>. Lug'atdan so'z, telefon kontaktlaridan ism shu usulda tez topiladi. 1 000 ta sonda ham atigi 10 savol yetadi!</p>",
 q:{t:"1 dan 16 gacha o'ylangan sonni har gal yarmiga bo'lib, ko'pi bilan nechta «katta/kichik» savol bilan aniq topish mumkin?",opts:["4","8","16","5"],ok:0,why:"16 → 8 → 4 → 2 → 1: 4 savol.",hint:"16 ni necha marta yarmiga bo'lsak, 1 qoladi?",full:"16 : 2 = 8, 8 : 2 = 4, 4 : 2 = 2, 2 : 2 = 1 — 4 ta savol. 2 · 2 · 2 · 2 = 16."},
 tn:"Sinf bilan o'ynang: siz son o'ylang, bolalar eng kam savol bilan topsin."},
{h:"Tuzoq: natijadan kirishga",sum:"Juft → : 2, toq → +1. Natija 8 bo'lsa kirish 16 yoki 7 bo'lishi mumkin — ikkala tarmoqni tekshiring!",a:"m05",
 start:function(){q19Box([["Son kirdi",120,'o'],["Juftmi?",120,'r'],["Ha: : 2   |   Yo'q: + 1",210],["Natija: 8",120,'o']]);j2Msg("Natija 8 chiqdi. Kirgan son qaysi bo'lishi mumkin? Tanlang.")},
 fin:function(){q19Box([["16 → juft → 16 : 2 = 8",230,'o'],["7 → toq → 7 + 1 = 8",230,'o']]);j2Msg("Ikkala tarmoq ham ishlaydi: <b>16 yoki 7</b>.")},
 html:"<p>Mashina: son juft bo'lsa 2 ga bo'ladi, toq bo'lsa 1 qo'shadi. Natija <b>8</b>. Qaysi son kirgan?</p>",
 btns:j2Pick(["Faqat 16","Faqat 7","16 yoki 7","4 yoki 9"],2,function(){q19Box([["16 → juft → 16 : 2 = 8",230,'o'],["7 → toq → 7 + 1 = 8",230,'o']]);j2Msg("To'g'ri! Ikkala tarmoqni tekshirdingiz.")},function(i){j2Msg(i===3?"4 juft → 2, 9 toq → 10. Mos emas.":"Boshqa tarmoqni ham tekshiring: "+(i===0?"toq son + 1 = 8 bo'lishi mumkinmi?":"juft son : 2 = 8 bo'lishi mumkinmi?"))}),g2:1,
 after:"<p>Shartli algoritmni orqadan yechganda <b>har bir tarmoqni</b> tekshiring va javob shartga mosligini qarang. Natija 7 bo'lsa: juft tarmoq → 14 ✓, toq tarmoq → 6, lekin 6 juft — mos emas. Demak faqat 14.</p>",
 q:{t:"Mashina: ×3, keyin +4, keyin : 2. Natija 20. Kirgan son?",opts:["36","12","8","14"],ok:1,why:"20 · 2 = 40, 40 − 4 = 36, 36 : 3 = 12.",hint:"Oxiridan boshlang: teskari amallar teskari tartibda.",full:"Teskarisi: : 2 → · 2: 40; + 4 → − 4: 36; · 3 → : 3: 12. Tekshirish: 12 · 3 = 36, + 4 = 40, : 2 = 20 ✓."},
 tn:"Blok-sxemani doskaga chizing, bolalar bo'r bilan ikkala tarmoq bo'ylab «yurishsin»."},
{h:"Tuzoq: ko'prik va fonar",sum:"1, 2, 5, 10 daqiqa: sekinlar BIRGA o'tsin → 17 daqiqa (19 emas).",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=5;P6[5]()},
 html:"<p>Kechasi 4 kishi ko'prikdan o'tishi kerak: 1, 2, 5, 10 daqiqada o'tadi. Fonar bitta, ko'prikda bir vaqtda ko'pi bilan 2 kishi, juftlik sekinrog'ining tezligida yuradi. Eng tez yuradigan hammani olib o'tsa: 2 + 1 + 5 + 1 + 10 = 19. Bundan tezroq bo'ladimi?</p>",
 btns:[phaser(P6,"▶ Keyingi o'tish")],
 after:"<p>Sir: eng sekin ikkisi (5 va 10) <b>birga</b> o'tsa, 5 daqiqa «yashirinadi». Yaxshi algoritm — ko'zga ko'ringan birinchi usul emas.</p>",
 q:{t:"Uch kishi: 1, 2, 5 daqiqada o'tadi. Fonar bitta, ko'prikda ko'pi bilan 2 kishi. Eng kam vaqt?",opts:["7 daqiqa","8 daqiqa","9 daqiqa","10 daqiqa"],ok:1,why:"1+2 o'tadi (2), 1 qaytadi (1), 1+5 o'tadi (5): 8.",hint:"Kimdir fonarni qaytarishi kerak — kim tez?",full:"1 va 2 o'tadi — 2 daqiqa. 1 qaytadi — 1. 1 va 5 o'tadi — 5. Jami 8. 7 bo'lishi mumkin emas: 5 lik kamida bir marta (5), boshqa ikki o'tish ham kamida 1 va 2 daqiqa oladi."},
 tn:"Bolalarni 4 kishilik guruhlarga bo'lib, qalam (fonar) bilan sahnalashtiring."},
{h:"Bilasizmi? Birinchi dasturchi",sum:"Ada Lavleys 1843-yilda hisoblash mashinasi uchun birinchi algoritmlardan birini yozgan.",a:"m07",
 start:function(){j2Lines([["👩‍💻 Ada Lavleys",C.blue,22],["1843",null,18]]);j2Msg("Birinchi dasturchi")},fin:function(){j2Lines([["👩‍💻 Ada Lavleys",C.blue,22],["1843",null,18]]);j2Msg("Birinchi dasturchi")},
 html:"<p>💡 1843-yilda ingliz matematigi <b>Ada Lavleys</b> Charlz Bebbijning hali qurilmagan «Analitik mashinasi» uchun sonlarni hisoblash ketma-ketligini — mashina bajarishi kerak bo'lgan buyruqlarni yozgan. Shuning uchun uni ko'pincha <b>birinchi dasturchi</b> deyishadi.</p><p>«Algoritm» so'zi esa vatandoshimiz al-Xorazmiy ismidan kelib chiqqan.</p>",
 btns:[["💡 Qiziq!",function(c,done){done()}]],
 tn:"Bolalar «nonushta tayyorlash» algoritmini blok-sxema bilan chizsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["qadam | qiymat",C.blue,24]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["qadam | qiymat",C.blue,24]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Siklni <b>jadval</b> bilan kuzating: qadam | qiymat.</li><li>Shart: «agar … bo'lsa — …, aks holda — …». Ikkala tarmoqni tekshiring.</li><li>Orqadan yechish: teskari amallar, teskari tartibda.</li><li>Pufakcha saralash: qo'shnilarni almashtirish; soni = noto'g'ri juftlar.</li><li>Ikkilik qidiruv: har savol yarmini tashlaydi (16 → 4 savol, 100 → 7).</li><li>Yaxshi algoritm — eng birinchi kelgan usul emas (ko'prik: 17).</li></ul></div>",
 tn:"Uyga: 4, 3, 2, 1 ni pufakcha usulida tartiblab, almashtirishlarni sanash (6)."}
];
var PROBS=[
{t:"x = 1. 5 marta takrorla: x = x · 2. Natija?",o:["32","10","16","64"],k:0,s:"2, 4, 8, 16, 32."},
{t:"x = 3. 4 marta takrorla: x = x + 5. Natija?",o:["23","20","35","8"],k:0,s:"3 + 4 · 5 = 23."},
{t:"x = 100. 3 marta takrorla: x = x − 7. Natija?",o:["79","93","86","72"],k:0,s:"100 − 21 = 79."},
{t:"x = 2. 3 marta takrorla: x = x · x. Natija?",o:["256","8","16","64"],k:0,s:"2 → 4 → 16 → 256."},
{t:"s = 0. i = 1 dan 5 gacha: s = s + i. Natija?",o:["15","5","10","25"],k:0,s:"1 + 2 + 3 + 4 + 5 = 15."},
{t:"Juft — 2 ga bo'l, toq — ·3 + 1. 6 dan boshlab necha qadamda 1 ga yetadi?",o:["8","6","9","3"],k:0,s:"6 → 3 → 10 → 5 → 16 → 8 → 4 → 2 → 1."},
{t:"Xuddi shu qoida bilan 7 dan boshlab necha qadamda 1 ga yetadi?",o:["16","8","10","20"],k:0,s:"7 → 22 → 11 → 34 → 17 → 52 → 26 → 13 → 40 → 20 → 10 → 5 → 16 → 8 → 4 → 2 → 1."},
{t:"3, 1, 2 ni pufakcha usulida tartiblash uchun nechta almashtirish?",o:["2","3","1","6"],k:0,s:"(3,1) va (3,2)."},
{t:"4, 3, 2, 1 ni pufakcha usulida tartiblash uchun nechta almashtirish?",o:["6","4","3","10"],k:0,s:"Hamma 6 ta juft noto'g'ri tartibda."},
{t:"1 dan 16 gacha sonni yarmiga bo'lib, ko'pi bilan nechta savol bilan topamiz?",o:["4","8","16","5"],k:0,s:"16 → 8 → 4 → 2 → 1."},
{t:"1 dan 100 gacha sonni yarmiga bo'lib, ko'pi bilan nechta savol bilan topamiz?",o:["7","10","50","6"],k:0,s:"2⁷ = 128 ≥ 100, 2⁶ = 64 < 100."},
{t:"Mashina: juft — 2 ga bo'ladi, toq — 1 qo'shadi. Natija 8. Kirgan son?",o:["16 yoki 7","Faqat 16","Faqat 7","4 yoki 9"],k:0,s:"16 : 2 = 8, 7 + 1 = 8."},
{t:"Mashina: ×3, +4, : 2. Natija 20. Kirgan son?",o:["12","36","8","14"],k:0,s:"20 · 2 − 4 = 36, 36 : 3 = 12."},
{t:"Ko'prik: 1, 2, 5 daqiqa, fonar bitta, ko'pi bilan 2 kishi. Eng kam vaqt?",o:["8 daqiqa","7 daqiqa","9 daqiqa","10 daqiqa"],k:0,s:"2 + 1 + 5."},
{t:"Ko'prik: 1, 2, 5, 10 daqiqa. Eng kam vaqt?",o:["17 daqiqa","19 daqiqa","18 daqiqa","16 daqiqa"],k:0,s:"2 + 1 + 10 + 2 + 2."},
{t:"Agar a > b bo'lsa a ni, aks holda b ni chiqar. a = 7, b = 9. Natija?",o:["9","7","16","2"],k:0,s:"7 > 9 emas → b = 9."},
{t:"n = 20. n > 1 bo'lguncha: n = n : 2 (butun qismi). Sikl necha marta bajariladi?",o:["4","5","10","3"],k:0,s:"20 → 10 → 5 → 2 → 1."},
{t:"n = 1. n < 50 bo'lguncha: n = n · 3. Oxirida n = ?",o:["81","27","50","243"],k:0,s:"1 → 3 → 9 → 27 → 81."},
{t:"Choy damlash algoritmi. To'g'ri tartib qaysi?",o:["Suv qaynatish → choynakka choy solish → qaynoq suv quyish → damlash","Choy solish → damlash → suv quyish → qaynatish","Suv quyish → damlash → qaynatish → choy solish","Damlash → suv qaynatish → choy solish → quyish"],k:0,s:"Avval suv qaynaydi, keyin choyga quyiladi va damlanadi."},
{t:"x = 5. 3 marta: agar x juft bo'lsa x = x : 2, aks holda x = x · 3 + 1. Natija?",o:["4","16","8","2"],k:0,s:"5 → 16 → 8 → 4."}
];
function PRACT_STAGE(){q19Box([["Boshlash",120,'o'],["Shart?",120,'r'],["Amal",120],["Natija",120,'o']])}
var PREP_DATA={teach:["Sikl va jadval bilan kuzatish.","Shart + sikl (Kollats zanjiri).","Saralash va ikkilik qidiruv.","Orqadan yechish, ko'prik masalasi."],
 mist:["Boshlang'ich qiymatni unutadi (3 + 4 · 5 o'rniga 20).","Shartli algoritmda faqat bitta tarmoqni tekshiradi.","Sikl sonini bittaga adashadi.","Birinchi kelgan usulni eng yaxshi deb o'ylaydi (19)."],
 need:["Son kartochkalari (1–10).","Qalam yoki o'yinchoq fonar (sahnalashtirish uchun)."],
 board:["<span class='w2'>qadam | x: 2, 4, 8, 16, 32</span>.","<span class='w2'>6 → 3 → 10 → 5 → 16 → 8 → 4 → 2 → 1</span>.","<span class='w2'>5,2,4,1 → 1,2,4,5 (5 almashtirish)</span>.","<span class='w2'>2 + 1 + 10 + 2 + 2 = 17</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
