// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F8',TITLE='4-sinf · Kasrni natural songa ko‘paytirish';
function f8rep(k){clear();var cols=[],i,cc=[C.a,C.b,C.c];for(i=0;i<7;i++)cols.push(i<2*k?cc[Math.floor(i/2)]:null);f4barC(20,56,320,40,cols);
 var s=[];for(i=0;i<k;i++)s.push('2/7');f4t(180,30,(k?s.join(' + '):'2/7 · 3')+(k===3?' = 6/7':''),16,k===3?C.ok:'#1d2b3a');if(k===3)f4t(180,130,'2/7 · 3 = 6/7  (surat: 2 · 3 = 6)',16,C.blue)}
var F8P1=[function(){f8rep(0);f4c(['2/7 · 3 — bu 2/7 ni 3 marta olish'])},function(){f8rep(1);f4c(['Bir marta: 2/7'])},function(){f8rep(2);f4c(['Ikki marta: 2/7 + 2/7 = 4/7'])},function(){f8rep(3);f4c(['Uch marta: 2/7 + 2/7 + 2/7 = <b>6/7</b>','Surat 3 ga ko‘paydi, maxraj o‘zgarmadi'])}];
function f8pies(st){clear();if(st===0){for(var i=0;i<5;i++)f4pie(36+i*72,64,28,4,3,C.a);f4t(180,126,'5 ta odamga 3/4 tadan pitsa',13);return}
 if(st===1){f4t(180,22,'15 ta chorak bo‘lak',14);for(var j=0;j<15;j++){var x=24+(j%8)*42,y=46+Math.floor(j/8)*48;f4sec(E('g',{},S.g),x,y+18,20,-Math.PI/2,0,C.a)}return}
 for(var k=0;k<3;k++)f4pie(50+k*80,70,32,4,4,C.a);f4pie(290,70,32,4,3,C.a);f4t(180,130,'15/4 = 3 3/4',20,C.ok)}
var F8P3=[function(){f8pies(0);f4c(['3/4 · 5 = ?'])},function(){f8pies(1);f4c(['3/4 · 5: surat 3 · 5 = 15 → 15/4 — 15 ta chorak'])},function(){f8pies(2);f4c(['15/4 dan butunni ajratamiz: 15 : 4 = 3, qoldiq 3 → <b>3 3/4</b>'])}];
var F8P4=[function(){clear();f4t(180,30,'2/5 · 10 = ?',18);for(var i=0;i<10;i++)f4bar(20+(i%5)*66,50+Math.floor(i/5)*44,60,32,5,2,C.b);f4c(['10 ta tasmaning har biridan 2/5'])},
 function(){clear();f4t(180,30,'2/5 · 10 = 20/5',18);f4t(180,80,'20 ta beshdan bir',14,'#33475b');f4c(['surat: 2 · 10 = 20 → 20/5'])},
 function(){clear();for(var i=0;i<4;i++)f4bar(20+i*82,40,76,34,5,5,C.b);f4t(180,110,'20/5 = 20 : 5 = 4',20,C.ok);f4c(['20 : 5 = <b>4</b> — butun son chiqdi!','Tez yo‘l: 10 : 5 · 2 = 4 (sonning 2/5 qismi)'])}];
var F8P5=[function(){clear();f4t(180,30,'1 2/3 · 4 = ?',18);for(var i=0;i<4;i++){f4bar(20+i*84,54,36,30,3,3,C.b);f4bar(60+i*84,54,36,30,3,2,C.a)}f4c(['4 marta 1 2/3: har birida 1 butun va 2/3'])},
 function(){clear();f4t(180,30,'butunlar: 1 · 4 = 4',15,C.blue);f4t(180,62,'kasrlar: 2/3 · 4 = 8/3 = 2 2/3',15,C.a2);f4c(['Butun qismni ham, kasr qismni ham 4 ga ko‘paytiramiz'])},
 function(){clear();f4t(180,40,'4 + 2 2/3 = 6 2/3',20,C.ok);f4t(180,90,'Yoki: 1 2/3 = 5/3;  5/3 · 4 = 20/3 = 6 2/3',13,'#33475b');f4c(['1 2/3 · 4 = <b>6 2/3</b>','Xato: 4 2/3 (kasr qismni ko‘paytirishni unutish)'])}];
function f8milk(st){clear();var g=S.g;for(var i=0;i<6;i++){var x=20+i*56;E('rect',{x:x,y:40,width:40,height:70,rx:6,fill:'#fff',stroke:'#7aa6c9','stroke-width':2},g);E('rect',{x:x+2,y:40+70*(1-3/8),width:36,height:70*3/8-2,fill:'#e8f2fb'},g);for(var q=1;q<8;q++)E('line',{x1:x,y1:40+q*70/8,x2:x+8,y2:40+q*70/8,stroke:'#7aa6c9'},g);f4t(x+20,128,(i+1)+'-kun',10,'#5b6b7b')}
 f4t(180,24,'Har kuni 3/8 litr sut',13);if(st>=1)f4t(180,154,st>=2?'3/8 · 6 = 18/8 = 2 2/8 litr':'3/8 · 6 = 18/8',15,st>=2?C.ok:C.blue)}
var F8P7=[function(){f8milk(0);f4c(['Mushuk har kuni 3/8 l sut ichadi. 6 kunda-chi?'])},function(){f8milk(1);f4c(['Bir xil miqdor 6 marta — ko‘paytirish: 3/8 · 6 = 18/8'])},function(){f8milk(2);f4c(['18 : 8 = 2, qoldiq 2 → <b>2 2/8 l</b> (2 1/4 l)'])}];
function f8waltz(){clear('#f3eefb');for(var t=0;t<4;t++){f4bar(18+t*84,50,78,34,4,3,'#a58bd6');f4t(57+t*84,104,(t+1)+'-takt',11,'#5b3f8f')}f4t(180,30,'Vals: har taktda 3/4',14,'#5b3f8f');f4t(180,146,'3/4 · 4 = 12/4 = 3',18,'#5b3f8f')}
function PRACT_STAGE(){f8rep(3);f4c(['Kasrni songa ko‘paytirish: <b>suratni ko‘paytiramiz, maxraj o‘zgarmaydi</b>'])}
var STEPS=[
{h:"Ko'paytirish — bir xil qo'shish",sum:"2/7 · 3 = 2/7 + 2/7 + 2/7 = 6/7. Surat 3 ga ko'payadi, maxraj o'zgarmaydi.",a:"m01",
 start:function(){startPh(F8P1)},fin:function(){S.ph=3;F8P1[3]()},
 html:"<p>Butun sonlarda 4 · 3 = 4 + 4 + 4. Kasrlarda ham xuddi shunday! 2/7 · 3 ni toping:</p>",btns:[phaser(F8P1)],
 after:"<p>Uch marta 2 ta yettidan bir — bu 6 ta yettidan bir: <b>6/7</b>. Bo'lak nomi (maxraj 7) o'zgarmadi, faqat bo'laklar <b>soni</b> 3 marta ko'paydi.</p><p><b>Qoida:</b> kasrni natural songa ko'paytirish uchun <b>suratni shu songa ko'paytiramiz, maxrajni o'zgartirmaymiz</b>.</p>",
 q:{t:"3/10 · 3 = ?",opts:["9/30","9/10","3/30","6/10"],ok:1,why:"3 · 3 = 9, maxraj 10.",hint:"Faqat suratni ko'paytiring.",full:"3/10 · 3 = 3/10 + 3/10 + 3/10 = 9/10. «9/30» — maxrajni ham ko'paytirish xatosi, «6/10» — qo'shish (3 + 3)."},
 tn:"Ko'paytirishni takroriy qo'shish orqali kiritish — xalqaro dasturlarda standart. Bolalar avval qo'shib yozsin, keyin qisqartmani o'zi kashf etsin."},
{h:"Tuzoq: maxrajni ham ko'paytirish",sum:"2/7 · 3 ≠ 6/21! 6/21 = 2/7 ning o'zi — qiymat o'zgarmay qoladi.",a:"m02",
 start:function(){clear();f4t(180,60,'2/7 · 3 = ?',28);f4msg('Bola: «Ikkalasini ham 3 ga ko‘paytiraman — 6/21». To‘g‘rimi?')},
 fin:function(){clear();f4bar(20,30,320,30,7,2,C.a);f4t(180,80,'2/7',14,C.a2);f4bar(20,96,320,30,21,6,C.bad);f4t(180,146,'6/21 — 2/7 bilan bir xil! 3 marta oshmadi',13,C.bad);f4msg('To‘g‘risi: 2/7 · 3 = <b>6/7</b>')},
 html:"<p>Ali 2/7 · 3 ni hisobladi va <b>6/21</b> deb yozdi. To'g'ri javobni tanlang:</p>",
 btns:f4pick(1,[["6/21","6/21 ni tasmada chizsak, u 2/7 bilan bir xil joyni egallaydi — 3 marta ko'paymadi!"],["6/7","To'g'ri! 2 · 3 = 6 bo'lak, bo'lak nomi — yettidan bir."],["2/21","Bu kasrni kichraytirdi. Ko'paytirganda natija kattaroq bo'lishi kerak."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Agar surat ham, maxraj ham bir xil songa ko'paytirilsa, kasrning <b>qiymati o'zgarmaydi</b>: 6/21 = 2/7 (bo'laklar soni ham, ular kichrayishi ham 3 marta). Shuning uchun ko'paytirishda <b>faqat surat</b> ko'paytiriladi.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["5/12 · 2 = 10/24","5/12 · 2 = 10/12","5/12 · 2 = 7/12","5/12 · 2 = 5/24"],ok:1,why:"Surat 5 · 2 = 10, maxraj 12.",hint:"Qaysi variantda faqat surat ko'paytirilgan?",full:"5/12 · 2 = 10/12. «10/24» — maxrajni ham ko'paytirish (qiymat o'zgarmaydi), «7/12» — qo'shish, «5/24» — maxrajni ko'paytirish (kichrayib ketadi)."},
 tn:"Bu xatoni rasm bilan rad eting: 6/21 va 2/7 ni tasmada ustma-ust qo'ying. Bolalar ular teng ekanini ko'rsin."},
{h:"Natija 1 dan oshsa",sum:"3/4 · 5 = 15/4 = 3 3/4: 15 ta chorakdan 3 ta butun pitsa va yana 3/4.",a:"m03",
 start:function(){startPh(F8P3)},fin:function(){S.ph=2;F8P3[2]()},
 html:"<p>5 ta mehmonning har biriga 3/4 tadan pitsa kerak. Jami qancha pitsa kerak?</p>",btns:[phaser(F8P3)],
 after:"<p>3/4 · 5 = 15/4 — noto'g'ri kasr. Undan butun ajratamiz: 15 : 4 = 3 (qoldiq 3) → <b>3 3/4</b> pitsa. Demak, 4 ta pitsa buyurtma qilish kerak.</p>",
 q:{t:"5/6 · 5 = ?",opts:["4 1/6","25/30","4 5/6","5 5/6"],ok:0,why:"25/6 = 4 1/6.",hint:"Avval suratni ko'paytiring, keyin butunni ajrating.",full:"5/6 · 5 = 25/6. 25 : 6 = 4, qoldiq 1 → 4 1/6. «25/30» — maxrajni ham ko'paytirish, «4 5/6» — qoldiqni noto'g'ri olish."},
 tn:"Hayotiy savol bering: «Necha pitsa buyurtma qilamiz?» — javob 4, chunki 3 3/4 dan kam bo'lmasligi kerak. Bu yaxlitlashga ham ko'prik."},
{h:"Natija butun son bo'lsa",sum:"2/5 · 10 = 20/5 = 4. Tez yo'l: 10 : 5 · 2 = 4.",a:"m04",
 start:function(){startPh(F8P4)},fin:function(){S.ph=2;F8P4[2]()},
 html:"<p>2/5 · 10 ni hisoblaymiz. Natija qanday chiqarkin?</p>",btns:[phaser(F8P4)],
 after:"<p>2/5 · 10 = 20/5 = 4. Diqqat qiling: bu <b>10 ning 2/5 qismi</b> bilan bir xil (10 : 5 · 2 = 4)! Son katta bo'lsa, avval maxrajga bo'lish qulayroq: 35 · 3/7 = 35 : 7 · 3 = 15.</p>",
 q:{t:"3/8 · 16 = ?",opts:["48","6","2","128"],ok:1,why:"16 : 8 · 3 = 6.",hint:"48/8 ni hisoblang yoki avval 16 ni 8 ga bo'ling.",full:"3/8 · 16 = 48/8 = 6 (yoki 16 : 8 = 2, 2 · 3 = 6). «48» — maxrajga bo'lishni unutish, «128» — 8 · 16."},
 tn:"Ko'paytirish va «sonning kasri» bir narsa ekanini doskada yonma-yon ko'rsating: 3/8 · 16 = 16 ning 3/8 qismi."},
{h:"Aralash sonni ko'paytirish",sum:"1 2/3 · 4: butunlar 1 · 4 = 4, kasrlar 2/3 · 4 = 8/3 = 2 2/3 → 6 2/3.",a:"m05",
 start:function(){startPh(F8P5)},fin:function(){S.ph=2;F8P5[2]()},
 html:"<p>Aralash sonni ko'paytirishda <b>butun qismni ham, kasr qismni ham</b> ko'paytiramiz. Bosing:</p>",btns:[phaser(F8P5)],
 after:"<p>Ikki yo'l bor:</p><p>1) Qismlab: 1 · 4 = 4, 2/3 · 4 = 8/3 = 2 2/3, jami <b>6 2/3</b>.<br>2) Noto'g'ri kasrga aylantirib: 1 2/3 = 5/3, 5/3 · 4 = 20/3 = <b>6 2/3</b>.</p><p>Eng ko'p xato: faqat butunni ko'paytirib, kasrni ko'chirib qo'yish (4 2/3).</p>",
 q:{t:"2 1/4 · 3 = ?",opts:["6 1/4","6 3/4","2 3/4","7 1/4"],ok:1,why:"6 + 3/4 = 6 3/4.",hint:"Butunni ham, kasrni ham 3 ga ko'paytiring.",full:"2 · 3 = 6, 1/4 · 3 = 3/4. Jami 6 3/4. «6 1/4» — kasr qismni ko'paytirishni unutish, «2 3/4» — butunni unutish."},
 tn:"Bu — taqsimot qonunining kasrdagi ko'rinishi: (1 + 2/3) · 4 = 1 · 4 + 2/3 · 4. Doskada qavslar bilan yozing."},
{h:"Ko'paytirish doim kattalashtiradimi?",sum:"12 · 3/4 = 9 &lt; 12. 1 dan kichik kasrga ko'paytirsak — natija kichrayadi.",a:"m06",
 start:function(){clear();f4t(180,50,'12 · 3/4 = ?',26);f4t(180,100,'Natija 12 dan katta bo‘ladimi?',13,'#33475b');f4msg('Javobni tanlang')},
 fin:function(){clear();f4bar(20,40,320,36,4,3,C.b,['3','3','3','3']);f4Br(20,340,36,'12',true,'#33475b');f4Br(20,260,80,'9',false,C.blue);f4t(180,146,'12 · 3/4 = 36/4 = 9  — 12 dan kichik!',14,C.ok);f4msg('12 · 3/4 = 12 ning 3/4 qismi = <b>9</b>')},
 html:"<p>«Ko'paytirsak — son kattalashadi» degan gap har doim to'g'rimi? 12 · 3/4 ni hisoblang:</p>",
 btns:f4pick(0,[["9","To'g'ri! 12 · 3/4 = 36/4 = 9. Bu 12 ning 3/4 qismi — 12 dan kichik."],["36","Bu 12 · 3. Maxrajga bo'lishni unutmang: 36/4 = ?"],["16","12 · 4 : 3 — surat va maxraj almashib ketdi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Butun sonlarda ko'paytirish doim kattalashtiradi (1 dan tashqari). Lekin <b>to'g'ri kasrga</b> (1 dan kichik songa) ko'paytirsak — natija <b>kichrayadi</b>: biz sonning bir <b>qismini</b> olamiz.</p>",
 q:{t:"15 · 2/3 va 15 ni taqqoslang.",opts:["15 · 2/3 katta","15 katta","Teng","15 · 2/3 katta, chunki ko'paytirdik"],ok:1,why:"15 · 2/3 = 10 &lt; 15.",hint:"2/3 — 1 dan kichikmi yoki katta?",full:"15 · 2/3 = 30/3 = 10, bu 15 dan kichik. To'g'ri kasrga ko'paytirish sonning bir qismini oladi. «Ko'paytirsak — kattalashadi» faqat 1 dan katta sonlar uchun to'g'ri."},
 tn:"Bu tushuncha — kelajakda o'nli kasr va foizlar uchun juda muhim. Bolalar «× 1/2 = yarmini olish» deb aytib bersin."},
{h:"Matnli masala: har kuni bir xil",sum:"Har kuni 3/8 l, 6 kunda: 3/8 · 6 = 18/8 = 2 2/8 l.",a:"m07",
 start:function(){startPh(F8P7)},fin:function(){S.ph=2;F8P7[2]()},
 html:"<p>Mushukcha har kuni 3/8 litr sut ichadi. 6 kunda qancha sut ichadi?</p>",btns:[phaser(F8P7)],
 after:"<p>«Har kuni bir xil» — demak <b>ko'paytirish</b>. 3/8 · 6 = 18/8 = <b>2 2/8 l</b>. Bunday masalalarda ko'paytirish qo'shishning qisqa yo'li.</p>",
 q:{t:"Bola har kuni 2/5 kg olma yeydi. Bir haftada (7 kunda) necha kilogramm olma yeydi?",opts:["2 4/5 kg","14/35 kg","2 2/5 kg","7 2/5 kg"],ok:0,why:"2/5 · 7 = 14/5 = 2 4/5.",hint:"Bir hafta — necha kun? Har kuni bir xil miqdor.",full:"2/5 · 7 = 14/5. 14 : 5 = 2, qoldiq 4 → 2 4/5 kg. «14/35» — maxrajni ham ko'paytirish, «7 2/5» — qo'shish (7 + 2/5)."},
 tn:"Hayotiy masalalar: dori dozalari (1/2 tabletka kuniga 3 marta), retsept (3/4 stakan × 4 porsiya)."},
{h:"Tuzoq: o'rin almashtirish",sum:"3/5 · 4 = 12/5 va 4/5 · 3 = 12/5 — teng! Surat bilan son o'rin almashsa ham natija o'zgarmaydi.",a:"m08",
 start:function(){clear();f4t(100,60,'3/5 · 4',24,C.a2);f4t(180,62,'?',24);f4t(260,60,'4/5 · 3',24,C.blue);f4msg('Qaysi biri katta?')},
 fin:function(){clear();f4t(100,50,'3/5 · 4 = 12/5',18,C.a2);f4t(260,50,'4/5 · 3 = 12/5',18,C.blue);f4t(180,110,'3 · 4 = 4 · 3 = 12',16,C.ok);f4msg('Teng: ikkalasi ham <b>12/5</b>')},
 html:"<p>Qaysi ko'paytma katta: <b>3/5 · 4</b> yoki <b>4/5 · 3</b>? Hisoblab tanlang:</p>",
 btns:f4pick(2,[["3/5 · 4","Hisoblang: 3 · 4 = ? va 4 · 3 = ?"],["4/5 · 3","4/5 katta kasr, lekin 3 kichik son. Hisoblang!"],["Teng","To'g'ri! Ikkalasida ham surat 12 bo'ladi: 12/5."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Ikkala holda ham surat <b>3 · 4 = 4 · 3 = 12</b>, maxraj 5. Demak ko'paytirishda o'rin almashtirish qonuni bu yerda ham ishlaydi.</p>",
 q:{t:"Qaysi ko'paytma katta: 2/9 · 4 yoki 4/9 · 2?",opts:["2/9 · 4","4/9 · 2","Teng","4/9 · 2, chunki 4/9 katta"],ok:2,why:"Ikkalasi ham 8/9.",hint:"Suratlarni hisoblang: 2 · 4 va 4 · 2.",full:"2/9 · 4 = 8/9, 4/9 · 2 = 8/9. Teng. Faqat kasrga qarab «katta» deyish — tuzoq."},
 tn:"Olimpiada savollari ko'pincha «hisoblamasdan taqqoslang» deydi. Bolalarni avval tuzilmaga qarashga o'rgating."},
{h:"Bilasizmi? Musiqadagi kasrlar",sum:"Vals musiqasi 3/4 o'lchovida: har taktda 3 ta chorak nota. 4 takt = 3/4 · 4 = 3 butun nota.",a:"m09",
 start:function(){clear('#f3eefb');f4t(180,50,'🎵 Vals musiqasi',16,'#5b3f8f');f4msg('Musiqachilar ham kasr bilan ishlaydi')},
 fin:function(){f8waltz();f4msg('4 takt: 3/4 · 4 = 12/4 = <b>3</b> butun nota')},
 html:"<p>🎵 Notalar kitobida <b>3/4</b> yoki <b>4/4</b> degan belgilar turadi. Bu — o'lchov: har bir taktda nechta nota borligi. Vals — <b>3/4</b> o'lchovida. Bosing:</p>",
 btns:[["🎵 Vals",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>Vals — «bir-ikki-uch, bir-ikki-uch» — har taktda 3 ta chorak nota. 4 takt davomida 3/4 · 4 = 12/4 = <b>3 butun nota</b> chalinadi. Marshlar odatda 2/4 yoki 4/4 o'lchovida bo'ladi.</p>",
 tn:"Musiqa o'qituvchisi bilan hamkorlik: bolalar qarsak bilan 3/4 va 4/4 ritmlarini chalsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>Kasr · son: <b>suratni ko'paytiramiz, maxraj o'zgarmaydi</b>: 2/7 · 3 = 6/7.</li><li>Maxrajni ko'paytirish — XATO: 6/21 = 2/7.</li><li>Natija noto'g'ri kasr bo'lsa — butunni ajrating: 15/4 = 3 3/4.</li><li>Kasr · son = sonning kasri: 2/5 · 10 = 10 : 5 · 2 = 4.</li><li>Aralash son: butunni ham, kasrni ham ko'paytiring: 1 2/3 · 4 = 6 2/3.</li><li>To'g'ri kasrga ko'paytirish sonni kichraytiradi: 12 · 3/4 = 9.</li><li>3/5 · 4 = 4/5 · 3.</li></ul></div>",
 tn:"Keyingi dars — o'nli kasrlar: «1/10 ni boshqacha qanday yozish mumkin?» savoli bilan boshlang."}
];
var PROBS=[
{t:"2/9 · 4 = ?",o:["8/9","8/36","6/9","2/36"],k:0,s:"2 · 4 = 8; maxraj 9."},
{t:"3/11 · 3 = ?",o:["9/11","9/33","6/11","3/33"],k:0,s:"3 · 3 = 9."},
{t:"4/7 · 5 = ?",o:["2 6/7","20/35","2 4/7","9/7"],k:0,s:"20/7 = 2 6/7."},
{t:"5/6 · 12 = ?",o:["10","60","2","72"],k:0,s:"12 : 6 · 5 = 10."},
{t:"7/10 · 3 = ?",o:["2 1/10","21/30","2 7/10","1 1/10"],k:0,s:"21/10 = 2 1/10."},
{t:"3/4 · 8 = ?",o:["6","24","32","2"],k:0,s:"8 : 4 · 3 = 6."},
{t:"1 1/2 · 5 = ?",o:["7 1/2","5 1/2","6 1/2","5 5/10"],k:0,s:"5 + 5/2 = 5 + 2 1/2 = 7 1/2."},
{t:"2 3/5 · 2 = ?",o:["5 1/5","4 3/5","4 6/10","5 3/5"],k:0,s:"4 + 6/5 = 4 + 1 1/5 = 5 1/5."},
{t:"Bir qadam 3/4 m. 10 qadam necha metr?",o:["7 2/4 m","30/40 m","3 4/10 m","10 3/4 m"],k:0,s:"3/4 · 10 = 30/4 = 7 2/4."},
{t:"Bitta paketda 2/5 kg shakar bor. 7 ta paketdagi shakarga yana 1/5 kg qo'shildi. Jami necha kilogramm?",o:["3 kg","2 4/5 kg","3 1/5 kg","2 1/5 kg"],k:0,s:"14/5 + 1/5 = 15/5 = 3."},
{t:"□ · 3 = 12/13. Kvadrat o'rnida qaysi kasr?",o:["4/13","36/13","12/39","9/13"],k:0,s:"4/13 · 3 = 12/13."},
{t:"a/9 · 4 = 2 2/9 bo'lsa, a nechaga teng?",o:["5","4","20","2"],k:0,s:"2 2/9 = 20/9; a · 4 = 20, a = 5."},
{t:"Qaysi ko'paytma 1 ga teng?",o:["1/6 · 6","1/6 · 1","6/1 · 6","1/6 · 5"],k:0,s:"6/6 = 1."},
{t:"Qaysi ko'paytma eng katta?",o:["5/6 · 4","3/4 · 4","7/8 · 3","1/2 · 6"],k:0,s:"20/6 = 3 2/6; qolganlari 3, 2 5/8, 3."},
{t:"Kvadratning tomoni 3/4 dm. Uning perimetri necha detsimetr?",o:["3 dm","3/16 dm","12/16 dm","1 3/4 dm"],k:0,s:"3/4 · 4 = 12/4 = 3."},
{t:"Avtobus har soatda yo'lning 2/9 qismini o'tadi. 3 soatdan keyin yo'lning qancha qismi qoladi?",o:["3/9","6/9","6/27","5/9"],k:0,s:"O'tdi: 2/9 · 3 = 6/9; qoldi 3/9."},
{t:"36 · 5/9 = ?",o:["20","180","4","45"],k:0,s:"36 : 9 · 5 = 20."},
{t:"1/3 soatni 5 ga ko'paytirsak, necha minut bo'ladi?",o:["100 minut","20 minut","15 minut","60 minut"],k:0,s:"1/3 soat = 20 minut; 20 · 5 = 100."},
{t:"Bitta g'isht 2 1/2 kg. 6 ta g'isht necha kilogramm?",o:["15 kg","12 1/2 kg","13 kg","8 1/2 kg"],k:0,s:"2 · 6 + 1/2 · 6 = 12 + 3 = 15."},
{t:"3/7 · n = 3 bo'lsa, n nechaga teng?",o:["7","3","21","1"],k:0,s:"3/7 · 7 = 21/7 = 3."}
];
var PREP_DATA={teach:["Kasrni songa ko'paytirish — takroriy qo'shish: 2/7 · 3 = 6/7.","Faqat surat ko'paytiriladi; maxrajni ko'paytirish xatosi.","Natijadan butunni ajratish; butun son chiqishi.","Aralash sonni ko'paytirish (qismlab va noto'g'ri kasr orqali).","To'g'ri kasrga ko'paytirish sonni kichraytiradi; o'rin almashtirish."],
 mist:["Maxrajni ham ko'paytiradi: 2/7 · 3 = 6/21.","Aralash sonda faqat butunni ko'paytiradi: 1 2/3 · 4 = 4 2/3.","«Ko'paytirsak — doim kattalashadi» deb o'ylaydi.","Natijani noto'g'ri kasr ko'rinishida qoldiradi."],
 need:["Qog'oz tasmalar, doiralar.","Stakan va o'lchov idishi (sut masalasi uchun)."],
 board:["<span class='w2'>2/7 · 3 = 2/7 + 2/7 + 2/7 = 6/7</span>.","<span class='w2'>3/4 · 5 = 15/4 = 3 3/4</span>.","<span class='w2'>2/5 · 10 = 20/5 = 4</span>.","<span class='w2'>1 2/3 · 4 = 4 + 8/3 = 6 2/3</span>.","<span class='w2'>12 · 3/4 = 9 &lt; 12</span>."]};
