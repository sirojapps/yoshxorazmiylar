var CODE='3H4',TITLE='3-sinf · Burchak va uchburchak turlari';
function h4Fan(deg){clear('#ffffff');var g=S.g,v=[180,150];for(var d=0;d<=deg;d+=deg/6){var p=[v[0]+120*Math.cos((90+deg/2-d)*Math.PI/180),v[1]-120*Math.sin((90+deg/2-d)*Math.PI/180)];g3Line(v,p,{w:2,c:'#c98a3b'})}
 g3Angle(v,90-deg/2,90+deg/2,120,{c:'#8a5a1f',arc:1});
 g3Msg(['Yelpig‘ich deyarli yopiq — burchak <b>kichik</b>','Biroz ochildi — burchak <b>kattalashdi</b>','Yana ochildi — burchak <b>to‘g‘ri</b>','Keng ochildi — burchak <b>eng katta</b>'][[30,60,90,140].indexOf(deg)])}
var P1=[function(){h4Fan(30)},function(){h4Fan(60)},function(){h4Fan(90)},function(){h4Fan(140)}];
function h4Fold(k){clear('#ffffff');var g=S.g;
 if(k===0){E('path',{d:'M110 40 Q160 20 230 45 Q260 90 220 140 Q150 160 110 130 Q90 80 110 40 Z',fill:'#fdf1d8',stroke:C.line,'stroke-width':2},g);g3Msg('Ixtiyoriy shakldagi qog‘oz varag‘i')}
 if(k===1){E('path',{d:'M110 90 Q105 50 140 40 Q200 25 240 50 L250 90 Z',fill:'#fdf1d8',stroke:C.line,'stroke-width':2},g);g3Line([105,90],[255,90],{w:3,c:C.blue});g3Msg('1-buklash: to‘g‘ri chiziq hosil bo‘ldi')}
 if(k===2){E('path',{d:'M180 90 L180 40 Q210 28 240 50 L250 90 Z',fill:'#fdf1d8',stroke:C.line,'stroke-width':2},g);g3Line([180,90],[255,90],{w:3,c:C.blue});g3Line([180,90],[180,36],{w:3,c:C.bad});g3Msg('2-buklash: chiziqni o‘zining ustiga tushiramiz')}
 if(k===3){g3Corner(150,120,60,-90);T(g,215,95,'to‘g‘ri burchak',{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});g3Msg('<b>To‘g‘ri burchak</b> o‘lchagichi tayyor!')}}
var P2=[function(){h4Fold(0)},function(){h4Fold(1)},function(){h4Fold(2)},function(){h4Fold(3)}];
function h4Type(t){clear('#ffffff');var g=S.g,v=[140,140],deg={1:45,2:90,3:130}[t]||0;
 if(!t){g3Msg('Burchak turini tanlang');return}
 g3Angle(v,0,deg,110,{c:'#33475b'});var cr=E('g',{transform:'translate('+v[0]+','+v[1]+')'},g);E('path',{d:'M0 0 h46 v-14 h-32 v-32 h-14 Z',fill:'rgba(31,111,178,.22)',stroke:C.blue,'stroke-width':1.5},cr);
 T(g,290,60,['','O‘TKIR','TO‘G‘RI','O‘TMAS'][t],{'font-size':16,'font-weight':800,fill:[0,C.ok,C.bad,C.t1][t]});
 g3Msg(['','O‘lchagich ichiga sig‘di — to‘g‘ri burchakdan <b>kichik</b>: o‘tkir','O‘lchagich bilan roppa-rosa ustma-ust: <b>to‘g‘ri</b>','O‘lchagichdan chiqib ketdi — to‘g‘ri burchakdan <b>katta</b>: o‘tmas'][t])}
function h4Rays(m){clear('#ffffff');var g=S.g;g3Angle([40,140],0,35,140,{c:'#33475b'});T(g,90,162,'A',{'font-size':14,'font-weight':800});g3Angle([230,140],0,75,55,{c:'#33475b'});T(g,250,162,'B',{'font-size':14,'font-weight':800});
 if(m===2){g3Line([230,140],[230+130*Math.cos(75*Math.PI/180),140-130*Math.sin(75*Math.PI/180)],{w:2,c:C.ok,d:'5 4'});g3Line([230,140],[360,140],{w:2,c:C.ok,d:'5 4'})}
 g3Msg(['Qaysi burchak katta: A yoki B?','A ning nurlari uzun, lekin <b>ochilishi kichik</b> ✗','To‘g‘ri! B kattaroq — nurlarni uzaytirsak ham burchak o‘zgarmaydi'][m])}
function h4Tri(t){clear('#ffffff');var g=S.g,pts=[[[90,140],[270,140],[200,40]],[[100,140],[260,140],[100,40]],[[70,140],[230,140],[300,70]]][t-1];
 g3Poly(pts,{fill:'rgba(90,169,230,.2)'});
 if(t===2)E('path',{d:'M100 126 h14 v14',fill:'none',stroke:C.bad,'stroke-width':2.2},g);
 if(t===3){E('path',{d:'M212 140 A18 18 0 0 0 243 128',fill:'none',stroke:C.bad,'stroke-width':2.5},g)}
 if(t===1){[[90,140,0,30],[270,140,140,180],[200,40,235,300]].forEach(function(a){var r=16,s=[a[0]+r*Math.cos(a[2]*Math.PI/180),a[1]-r*Math.sin(a[2]*Math.PI/180)],e=[a[0]+r*Math.cos(a[3]*Math.PI/180),a[1]-r*Math.sin(a[3]*Math.PI/180)];})}
 g3Msg(['','<b>O‘tkir burchakli</b> uchburchak: hamma 3 burchagi o‘tkir','<b>To‘g‘ri burchakli</b> uchburchak: bitta burchagi to‘g‘ri','<b>O‘tmas burchakli</b> uchburchak: bitta burchagi o‘tmas'][t])}
function h4Two(k){clear('#ffffff');var g=S.g;g3Line([110,140],[250,140],{w:3});
 if(k===0){g3Line([110,140],[110,20],{w:3,c:C.bad});g3Line([250,140],[250,20],{w:3,c:C.bad});E('path',{d:'M110 126 h14 v14 M250 126 h-14 v14',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,180,60,'hech qachon',{'font-size':12,'font-weight':800,fill:C.bad});T(g,180,76,'kesishmaydi!',{'font-size':12,'font-weight':800,fill:C.bad});g3Msg('Ikki to‘g‘ri burchak: nurlar parallel — uchburchak <b>yopilmaydi</b>')}
 if(k===1){g3Line([110,140],[60,30],{w:3,c:C.bad});g3Line([250,140],[250,20],{w:3,c:C.bad});T(g,180,60,'yana uzoqlashdi',{'font-size':12,'font-weight':800,fill:C.bad});g3Msg('O‘tmas + to‘g‘ri: nurlar <b>tarqalib ketadi</b>')}
 if(k===2){g3Poly([[110,140],[250,140],[110,40]],{fill:'rgba(90,169,230,.2)'});E('path',{d:'M110 126 h14 v14',fill:'none',stroke:C.bad,'stroke-width':2},g);g3Msg('To‘g‘ri + <b>o‘tkir</b>: nurlar uchrashdi — uchburchak!')}
 if(k===3){g3Poly([[110,140],[250,140],[180,40]],{fill:'rgba(90,169,230,.2)'});g3Msg('Uchburchakda ko‘pi bilan <b>bitta</b> to‘g‘ri yoki o‘tmas burchak; qolgan ikkitasi doim <b>o‘tkir</b>')}}
var P6=[function(){h4Two(0)},function(){h4Two(1)},function(){h4Two(2)},function(){h4Two(3)}];
function h4Tick(a,b,n){var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,dx=b[0]-a[0],dy=b[1]-a[1],l=Math.sqrt(dx*dx+dy*dy),ux=dx/l,uy=dy/l,nx=-uy*7,ny=ux*7;for(var i=0;i<n;i++){var o=(i-(n-1)/2)*5;g3Line([mx+ux*o-nx,my+uy*o-ny],[mx+ux*o+nx,my+uy*o+ny],{w:2.2,c:C.bad})}}
function h4Side(t){clear('#ffffff');var pts=[[[100,145],[260,145],[180,6]],[[120,145],[240,145],[180,25]],[[70,145],[290,145],[130,45]]][t-1],g=S.g;g3Poly(pts,{fill:'rgba(240,160,64,.22)',stroke:C.line});
 if(t===1){h4Tick(pts[0],pts[1],1);h4Tick(pts[1],pts[2],1);h4Tick(pts[2],pts[0],1)}
 if(t===2){h4Tick(pts[1],pts[2],1);h4Tick(pts[2],pts[0],1);T(g,180,162,'asos',{'font-size':11,'font-weight':800,fill:C.blue})}
 if(t===3){h4Tick(pts[0],pts[1],1);h4Tick(pts[1],pts[2],2);h4Tick(pts[2],pts[0],3)}
 g3Msg(['','<b>Teng tomonli</b>: 3 tomoni ham teng','<b>Teng yonli</b>: 2 ta yon tomoni teng, uchinchisi — asos','<b>Turli tomonli</b>: hamma tomonlari har xil'][t])}
function h4Count(k){clear('#ffffff');var g=S.g,O=[60,145],A=[300,145],B=[250,55],Cc=[120,20];[A,B,Cc].forEach(function(p){g3Line(O,p,{w:3})});
 T(g,A[0]+10,A[1]+4,'A',{'font-size':13,'font-weight':800});T(g,B[0]+10,B[1],'B',{'font-size':13,'font-weight':800});T(g,Cc[0]+10,Cc[1],'C',{'font-size':13,'font-weight':800});T(g,O[0]-10,O[1]+4,'O',{'font-size':13,'font-weight':800});
 var a1=0,a2=Math.atan2(145-55,250-60)*180/Math.PI,a3=Math.atan2(145-20,120-60)*180/Math.PI;
 function arc(r,f,t2,c){var s=[O[0]+r*Math.cos(f*Math.PI/180),O[1]-r*Math.sin(f*Math.PI/180)],e=[O[0]+r*Math.cos(t2*Math.PI/180),O[1]-r*Math.sin(t2*Math.PI/180)];E('path',{d:'M'+s[0]+' '+s[1]+' A'+r+' '+r+' 0 0 0 '+e[0]+' '+e[1],fill:'none',stroke:c,'stroke-width':3},g)}
 if(k>=1)arc(30,a1,a2,C.bad);if(k>=2)arc(42,a2,a3,C.ok);if(k>=3)arc(56,a1,a3,C.blue);
 g3Msg(['O uchidan 3 ta nur chiqdi. Nechta burchak bor?','1) AOB','2) BOC','3) AOC — katta burchak ham hisob! Jami <b>3</b> ta'][k])}
var P8=[function(){h4Count(0)},function(){h4Count(1)},function(){h4Count(2)},function(){h4Count(3)}];
function h4Clock(h){clear('#ffffff');var g=S.g,cx=180,cy=88,R=70;E('circle',{cx:cx,cy:cy,r:R,fill:'#fffdf7',stroke:'#33475b','stroke-width':3},g);
 for(var i=1;i<=12;i++){var a=(90-i*30)*Math.PI/180;T(g,cx+(R-13)*Math.cos(a),cy-(R-13)*Math.sin(a)+4,String(i),{'font-size':11,'font-weight':800})}
 if(h){var ha=(90-h*30)*Math.PI/180;g3Line([cx,cy],[cx,cy-R+22],{w:3,c:C.blue});g3Line([cx,cy],[cx+38*Math.cos(ha),cy-38*Math.sin(ha)],{w:5,c:C.bad})}
 g3Dot([cx,cy],'#33475b',4);
 g3Msg(h===3?'3:00 — <b>to‘g‘ri</b> burchak':h===1?'1:00 — <b>o‘tkir</b> burchak':h===5?'5:00 — <b>o‘tmas</b> burchak':h===6?'6:00 — millar bir to‘g‘ri chiziqda: <b>yoyiq</b> burchak':'Soat millari burchak hosil qiladi')}
var STEPS=[
{h:"Burchak nima?",sum:"Burchak — bir nuqtadan (uchidan) chiqqan ikki nur. Kattaligi — nurlarning ochilishi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Bir nuqtadan chiqqan ikki nur <b>burchak</b> hosil qiladi. Nuqta — burchak <b>uchi</b>, nurlar — <b>tomonlari</b>. Yelpig'ichni oching:</p>",
 btns:[phaser(P1,'🪭 Ochish')],
 after:"<p>Yelpig'ich qancha keng ochilsa, burchak shuncha <b>katta</b>. Burchak kattaligi nurlarning uzunligiga emas, <b>ochilishiga</b> bog'liq.</p>",
 q:{t:"Qaychi tig'larini kengroq ochsak, ular orasidagi burchak…",opts:["kichrayadi","kattalashadi","o'zgarmaydi","yo'qoladi"],ok:1,why:"Ochilish ortsa — burchak kattalashadi.",hint:"Yelpig'ichni ochganda nima bo'ldi?",full:"Tomonlar kengroq ochilsa burchak kattalashadi. Tig'lar uzunligi o'zgarmasa ham burchak o'zgaradi."},
 tn:"Qog'oz yelpig'ich yoki qaychi bilan ko'rsating; bolalar qo'llari bilan «burchak» yasasin."},
{h:"To'g'ri burchak yasash",sum:"Qog'ozni ikki marta buklab to'g'ri burchak o'lchagichi yasaladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Chizg'ich va sirkulsiz ham <b>to'g'ri burchak</b> yasash mumkin! Qog'ozni buklang:</p>",
 btns:[phaser(P2,'📄 Buklash')],
 after:"<p>Daftar, kitob, eshik, doskaning burchaklari — <b>to'g'ri burchak</b>. Chizmada u kichik kvadratcha belgisi bilan ko'rsatiladi.</p>",
 q:{t:"Kvadratning nechta burchagi to'g'ri?",opts:["2","4","0","1"],ok:1,why:"Kvadratning 4 burchagi ham to'g'ri.",hint:"Daftar varag'ining burchaklarini sanang.",full:"Kvadrat va to'g'ri to'rtburchakning hamma 4 burchagi to'g'ri."},
 tn:"Har bola qog'ozdan o'lchagich yasab, sinfdagi narsalarning burchaklarini tekshirsin."},
{h:"O'tkir, to'g'ri, o'tmas",sum:"O'tkir — to'g'ri burchakdan kichik; o'tmas — to'g'ri burchakdan katta.",a:"m03",
 start:function(){h4Type(0)},fin:function(){h4Type(3)},
 html:"<p>O'lchagichni burchakka qo'yib solishtiramiz. Har bir turni ko'ring:</p>",
 btns:[["O'tkir",function(c,done){h4Type(1);mvK(done,3)}],["To'g'ri",function(c,done){h4Type(2);mvK(done,3)}],["O'tmas",function(c,done){h4Type(3);mvK(done,3)}]],g3:1,
 after:"<div class='life'><div>📐<span><b>o'tkir</b> &lt; to'g'ri</span></div><div>⌐<span><b>to'g'ri</b> — o'lchagich bilan teng</span></div><div>🪭<span><b>o'tmas</b> &gt; to'g'ri</span></div></div>",
 q:{t:"Soat 1:00 da soat millari qanday burchak hosil qiladi?",opts:["To'g'ri","O'tkir","O'tmas","Yoyiq"],ok:1,why:"1:00 da millar yaqin — to'g'ri burchakdan kichik.",hint:"3:00 da to'g'ri burchak. 1:00 da millar yaqinroqmi?",full:"3:00 — to'g'ri burchak. 1:00 da millar ancha yaqin, burchak to'g'ri burchakdan kichik — o'tkir."},
 tn:"Bolalar qo'llari bilan uch turni ko'rsatsin: «o'tkir!», «to'g'ri!», «o'tmas!» — o'yin tarzida."},
{h:"Tuzoq: nurlar uzunligi",sum:"Burchak kattaligi nurlar uzunligiga bog'liq emas.",a:"m04",
 start:function(){h4Rays(0)},fin:function(){h4Rays(2)},
 html:"<p>A burchakning nurlari uzun, B niki qisqa. Qaysi burchak katta?</p>",
 btns:[["A katta",function(){h4Rays(1)}],["B katta",function(c,done){h4Rays(2);done()},'u']],g2:1,
 after:"<p>Nurlar — cheksiz, chizmada ular istalgan uzunlikda chiziladi. Burchakni <b>ochilishi</b> bo'yicha solishtiring: B ning ochilishi kattaroq.</p>",
 q:{t:"Burchak nurlarini 2 marta uzaytirsak, burchak…",opts:["2 marta kattalashadi","o'zgarmaydi","kichrayadi","4 marta kattalashadi"],ok:1,why:"Ochilish o'zgarmaydi.",hint:"Nurlarni uzaytirganda ular orasidagi ochilish o'zgaradimi?",full:"Nurlar uzunligi burchak kattaligiga ta'sir qilmaydi — burchak o'zgarmaydi."},
 tn:"Ikki bir xil burchakni bo'r bilan chizib, birining nurlarini uzaytiring — o'lchagich bilan teng ekanini ko'rsating."},
{h:"Uchburchak burchaklari bo'yicha",sum:"O'tkir burchakli, to'g'ri burchakli, o'tmas burchakli uchburchaklar.",a:"m05",
 start:function(){h4Tri(1)},fin:function(){h4Tri(3)},
 html:"<p>Uchburchaklar eng katta burchagiga qarab nomlanadi. Har birini ko'ring:</p>",
 btns:[["O'tkir burchakli",function(c,done){h4Tri(1);mvK(done,3)}],["To'g'ri burchakli",function(c,done){h4Tri(2);mvK(done,3)}],["O'tmas burchakli",function(c,done){h4Tri(3);mvK(done,3)}]],g3:1,
 after:"<p>Agar bitta burchagi <b>to'g'ri</b> — to'g'ri burchakli; bitta burchagi <b>o'tmas</b> — o'tmas burchakli; hammasi <b>o'tkir</b> — o'tkir burchakli.</p>",
 q:{t:"To'g'ri to'rtburchakni diagonali bo'ylab qirqsak, qanday uchburchaklar hosil bo'ladi?",opts:["O'tmas burchakli","To'g'ri burchakli","Teng tomonli","O'tkir burchakli"],ok:1,why:"Har birida to'rtburchakning bitta to'g'ri burchagi qoladi.",hint:"Har bir bo'lakda to'rtburchakning qaysi burchagi qoladi?",full:"Diagonal bo'yicha qirqilganda har bir uchburchakda to'rtburchakning bitta to'g'ri burchagi bor — to'g'ri burchakli uchburchak."},
 tn:"Qog'oz to'rtburchakni qaychi bilan diagonali bo'yicha qirqib, o'lchagich bilan tekshiring."},
{h:"Tuzoq: ikkita to'g'ri burchak?",sum:"Uchburchakda faqat bitta to'g'ri yoki o'tmas burchak bo'ladi; qolgan ikkitasi doim o'tkir.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Uchburchakda <b>ikkita</b> to'g'ri burchak bo'lishi mumkinmi? Sinab ko'ramiz:</p>",
 btns:[phaser(P6,'✏️ Sinash')],
 after:"<p>Ikki to'g'ri (yoki o'tmas) burchakda tomonlar hech qachon uchrashmaydi. Shuning uchun uchburchakda <b>kamida ikkita o'tkir</b> burchak bor.</p>",
 q:{t:"Uchburchakning bir burchagi to'g'ri. Qolgan ikkitasi qanday?",opts:["biri to'g'ri, biri o'tkir","ikkalasi o'tmas","ikkalasi o'tkir","biri o'tmas, biri o'tkir"],ok:2,why:"Ikkinchi to'g'ri yoki o'tmas burchak bo'lsa uchburchak yopilmaydi.",hint:"Hozir ikkita to'g'ri burchak bilan nima bo'ldi?",full:"Bitta to'g'ri burchak bo'lsa, qolgan ikkitasi faqat o'tkir — aks holda tomonlar uchrashmaydi."},
 tn:"Cho'plar bilan ikki to'g'ri burchakli «uchburchak» yasashga urinib ko'ring — yopilmasligini bolalar o'zi ko'rsin."},
{h:"Uchburchak tomonlari bo'yicha",sum:"Teng tomonli (3 tomon teng), teng yonli (2 tomon teng), turli tomonli.",a:"m07",
 start:function(){h4Side(1)},fin:function(){h4Side(3)},
 html:"<p>Uchburchaklarni <b>tomonlariga</b> qarab ham nomlaymiz. Teng tomonlar bir xil chiziqcha bilan belgilanadi:</p>",
 btns:[["Teng tomonli",function(c,done){h4Side(1);mvK(done,3)}],["Teng yonli",function(c,done){h4Side(2);mvK(done,3)}],["Turli tomonli",function(c,done){h4Side(3);mvK(done,3)}]],g3:1,
 after:"<p>Teng yonli uchburchakda teng tomonlar — <b>yon tomonlar</b>, uchinchisi — <b>asos</b>. Perimetr: P = yon · 2 + asos.</p>",
 q:{t:"Teng yonli uchburchakning perimetri 20 sm, asosi 6 sm. Yon tomoni?",opts:["14 sm","7 sm","13 sm","6 sm"],ok:1,why:"(20 − 6) : 2 = 7.",hint:"Asosni ayirib, qolganini ikki yon tomonga teng bo'ling.",full:"20 − 6 = 14 — ikki yon tomon yig'indisi, 14 : 2 = 7 sm. «14» — 2 ga bo'lish unutilgan."},
 tn:"Turli uzunlikdagi cho'plardan uchala turni yasating."},
{h:"Tuzoq: burchaklarni sanash",sum:"Bir uchdan 3 nur — 3 ta burchak (AOB, BOC va katta AOC).",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=3;P8[3]()},
 html:"<p>O nuqtadan uchta nur chiqqan. Chizmada nechta burchak bor? Ko'pchilik «2» deydi. Sanab chiqamiz:</p>",
 btns:[phaser(P8,'🔍 Sanash')],
 after:"<p>Kichik burchaklar <b>va</b> ulardan tuzilgan katta burchak ham hisob: <b>3 ta</b>. 4 ta nurda: 3 + 2 + 1 = <b>6 ta</b> burchak.</p>",
 q:{t:"Bir uchdan 4 ta nur chiqqan. Nechta burchak hosil bo'lgan?",opts:["3","4","6","8"],ok:2,why:"3 + 2 + 1 = 6.",hint:"Avval kichik, keyin ikkitalik, keyin eng katta burchaklarni sanang.",full:"Qo'shni nurlar: 3 ta, bitta oraliq bilan: 2 ta, eng chetkilari: 1 ta. Jami 6. «3» — faqat kichiklari sanalgan."},
 tn:"Doskada nurlarni rangli bo'r bilan chizib, har burchakni yoy bilan alohida belgilang."},
{h:"Bilasizmi? Soat millari",sum:"3:00 va 9:00 da soat millari to'g'ri burchak, 6:00 da yoyiq burchak hosil qiladi.",a:"m09",
 start:function(){h4Clock(0)},fin:function(){h4Clock(6)},
 html:"<p>🕒 Soat millari ham burchak hosil qiladi! Vaqtni tanlang:</p>",
 btns:[["1:00",function(c,done){h4Clock(1);mvK(done,3)}],["3:00",function(c,done){h4Clock(3);mvK(done,3)}],["5:00",function(c,done){h4Clock(5);mvK(done,3)}],["6:00",function(c,done){h4Clock(6);mvK(done,3)}]],g2:1,
 after:"<p>3:00 va 9:00 — <b>to'g'ri</b> burchak; 1:00, 2:00 — o'tkir; 4:00, 5:00 — o'tmas; 6:00 da millar bir to'g'ri chiziqda — <b>yoyiq</b> burchak (ikkita to'g'ri burchakka teng).</p>",
 tn:"Karton soat bilan bolalar «o'tkir burchakli vaqt»ni ko'rsatsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h4Type(2)},fin:function(){h4Type(2)},
 html:"<div class='memo'><ul><li>Burchak — <b>uch</b> va ikki <b>nur</b>. Kattaligi nur uzunligiga bog'liq emas.</li><li><b>O'tkir</b> &lt; <b>to'g'ri</b> &lt; <b>o'tmas</b> &lt; yoyiq.</li><li>Uchburchak burchaklari bo'yicha: o'tkir, to'g'ri, o'tmas burchakli.</li><li>Uchburchakda ko'pi bilan <b>bitta</b> to'g'ri yoki o'tmas burchak.</li><li>Tomonlari bo'yicha: teng tomonli, teng yonli, turli tomonli.</li><li>Bir uchdan 3 nur — <b>3</b> burchak, 4 nur — <b>6</b>.</li></ul></div>",
 tn:"Keyingi darsda sinfdagi narsalardan har turdagi burchakka misol to'plang."}
];
var PROBS=[
{t:"To'g'ri burchakdan kichik burchak qanday ataladi?",o:["O'tkir","O'tmas","Yoyiq","To'g'ri"],k:0,s:"O'tkir burchak."},
{t:"To'g'ri burchakdan katta, yoyiq burchakdan kichik burchak?",o:["O'tmas","O'tkir","To'g'ri","Nol"],k:0,s:"O'tmas burchak."},
{t:"Kvadratda nechta to'g'ri burchak bor?",o:["4","2","1","0"],k:0,s:"Hammasi to'g'ri."},
{t:"Soat 3:00 da millar qanday burchak hosil qiladi?",o:["To'g'ri","O'tkir","O'tmas","Yoyiq"],k:0,s:"3:00 — to'g'ri."},
{t:"Soat 1:00 da millar qanday burchak hosil qiladi?",o:["O'tkir","To'g'ri","O'tmas","Yoyiq"],k:0,s:"To'g'ri burchakdan kichik."},
{t:"Soat 5:00 da millar qanday burchak hosil qiladi?",o:["O'tmas","O'tkir","To'g'ri","Yoyiq"],k:0,s:"To'g'ri burchakdan katta."},
{t:"Soat 6:00 da millar qanday burchak hosil qiladi?",o:["Yoyiq","To'g'ri","O'tkir","O'tmas"],k:0,s:"Bir to'g'ri chiziqda."},
{t:"Hamma tomonlari teng uchburchak?",o:["Teng tomonli","Teng yonli","Turli tomonli","To'g'ri burchakli"],k:0,s:"3 tomon teng."},
{t:"Tomonlari 5 sm, 5 sm va 8 sm bo'lgan uchburchak?",o:["Teng yonli","Teng tomonli","Turli tomonli","Kvadrat"],k:0,s:"Ikki tomoni teng."},
{t:"Burchak nurlarini 2 marta uzaytirsak, burchak…",o:["o'zgarmaydi","2 marta kattalashadi","kichrayadi","4 marta kattalashadi"],k:0,s:"Ochilish o'zgarmaydi."},
{t:"Uchburchakning bir burchagi to'g'ri. Qolgan ikkitasi?",o:["ikkalasi o'tkir","biri to'g'ri, biri o'tkir","ikkalasi o'tmas","biri o'tmas, biri o'tkir"],k:0,s:"Faqat o'tkir bo'lishi mumkin."},
{t:"Uchburchakda ko'pi bilan nechta o'tmas burchak bo'lishi mumkin?",o:["1","2","3","0"],k:0,s:"Ikkitasida tomonlar uchrashmaydi."},
{t:"Teng tomonli uchburchakning burchaklari qanday?",o:["Hammasi o'tkir","Bittasi to'g'ri","Bittasi o'tmas","Hammasi to'g'ri"],k:0,s:"Uchala burchak teng — o'tkir."},
{t:"To'g'ri to'rtburchak diagonali bo'yicha qirqildi. Qanday uchburchaklar hosil bo'ldi?",o:["To'g'ri burchakli","O'tmas burchakli","Teng tomonli","O'tkir burchakli"],k:0,s:"Har birida bitta to'g'ri burchak."},
{t:"Ikkita to'g'ri burchakni yonma-yon qo'ysak, qanday burchak hosil bo'ladi?",o:["Yoyiq","To'g'ri","O'tkir","O'tmas"],k:0,s:"Bir to'g'ri chiziq — yoyiq."},
{t:"Bir uchdan 3 ta nur chiqqan. Nechta burchak bor?",o:["3","2","1","6"],k:0,s:"AOB, BOC, AOC."},
{t:"Bir uchdan 4 ta nur chiqqan. Nechta burchak bor?",o:["6","3","4","8"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Teng yonli uchburchak perimetri 20 sm, asosi 6 sm. Yon tomoni?",o:["7 sm","14 sm","13 sm","6 sm"],k:0,s:"(20 − 6) : 2 = 7."},
{t:"Teng yonli uchburchakning yon tomoni 8 sm, perimetri 23 sm. Asosi?",o:["7 sm","15 sm","8 sm","6 sm"],k:0,s:"23 − 16 = 7."},
{t:"Kvadratga ikkala diagonali o'tkazildi. Chizmada nechta uchburchak bor?",o:["8","4","6","2"],k:0,s:"4 ta kichik + 4 ta katta (yarim kvadrat) = 8."}
];
function PRACT_STAGE(){h4Type(2)}
var PREP_DATA={teach:["Burchak: uchi, tomonlari; kattaligi ochilishga bog'liq.","To'g'ri burchak o'lchagichi (qog'oz buklash); o'tkir, to'g'ri, o'tmas, yoyiq burchaklar.","Uchburchak turlari: burchaklari va tomonlari bo'yicha.","Uchburchakda ko'pi bilan bitta to'g'ri/o'tmas burchak; burchaklarni sanash."],
 mist:["Nurlari uzun burchakni katta deb o'ylaydi.","Uchburchakda ikki to'g'ri burchak bo'ladi deb o'ylaydi.","Bir uchdagi burchaklarni sanaganda katta burchakni unutadi.","Teng tomonli va teng yonlini adashtiradi."],
 need:["Qog'oz varaqlari (o'lchagich yasash uchun), karton soat.","Cho'plar, qaychi, rangli bo'r."],
 board:["o'tkir &lt; <span class='w2'>to'g'ri</span> &lt; o'tmas &lt; yoyiq.","Uchburchak: o'tkir / to'g'ri / o'tmas burchakli.","Teng tomonli / teng yonli / turli tomonli.","Nurlar: 3 → 3 burchak, 4 → 6 burchak."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
