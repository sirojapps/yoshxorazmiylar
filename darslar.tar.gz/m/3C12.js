var CODE='3C12',TITLE='3-sinf · 10, 100, 1 000 ga ko‘paytirish va bo‘lish';
function c12(rows,msg,note){W3pv(rows,{cols:6});W3msg(msg,note)}
var P1=[function(){c12([{v:47}],'47 · 1000 = ?')},
 function(){c12([{v:47},{v:47000,lab:'·1000',zero:3}],'1000 da <b>uchta</b> 0 — raqamlar <b>uch xona</b> chapga: <b>47 000</b>','4 o‘nlik → 4 o‘n ming, 7 birlik → 7 ming')}];
var P2=[function(){c12([{v:52000}],'52 000 : 1000 = ?')},
 function(){c12([{v:52000},{v:52,lab:':1000'}],'Uch xona o‘ngga — oxiridagi <b>uchta 0</b> olinadi: <b>52</b>')}];
var P3=[function(){c12([{v:7}],'7 ni ketma-ket 10 ga ko‘paytiramiz')},
 function(){c12([{v:7},{v:70,lab:'·10'}],'7 · 10 = 70')},
 function(){c12([{v:7},{v:70,lab:'·10'},{v:700,lab:'·10'}],'70 · 10 = 700 &nbsp; (7 · 100)')},
 function(){c12([{v:7},{v:70,lab:'·10'},{v:700,lab:'·10'},{v:7000,lab:'·10'}],'700 · 10 = 7000 &nbsp; (7 · 1000)','1000 = 10 · 10 · 10')}];
var P4=[function(){W3eq(['30 · 200 = ?'])},
 function(){W3eq(['30 · 200','= 3 · 10 · 2 · 100']);W3msg('Har sonni «raqam · yaxlit» ko‘rinishida yozamiz')},
 function(){W3eq(['30 · 200','= (3 · 2) · (10 · 100)','= 6 · 1000 = [6000]']);W3msg('Raqamlarni ko‘paytiramiz, keyin <b>hamma nollarni</b> qo‘shib yozamiz: 1 + 2 = 3 ta 0')}];
var STEPS=[
{h:"1000 ga ko'paytirish",sum:"47 · 1000 = 47 000: raqamlar uch xona chapga.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>10 ga — bir xona, 100 ga — ikki xona. 1000 ga-chi?</p>",btns:[phaser(P1,'▶ ·1000')],
 after:"<p><b>·1000</b> — oxiriga <b>uchta 0</b>. 47 · 1000 = 47 000 — «qirq yetti ming». Ko'p xonali sonni o'qishda uchtalab ajratamiz.</p>",
 q:{t:"365 · 1000 = ?",opts:["365 000","36 500","3 650 000","3 650"],ok:0,why:"Uch xona chapga.",hint:"Nechta 0 qo'shiladi?",full:"365 · 1000 = 365 000 (uchta 0). «36 500» — 100 ga ko'paytirilgan."},
 tn:"Xonalar jadvalini ming sinfi bilan kengaytiring: birlik, o'nlik, yuzlik | ming, o'n ming, yuz ming."},
{h:"1000 ga bo'lish",sum:"52 000 : 1000 = 52: uch xona o'ngga, uchta 0 olinadi.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>Teskari amal — raqamlar o'ngga.</p>",btns:[phaser(P2,'▶ :1000')],
 after:"<p>1000 ga qoldiqsiz bo'linadigan son oxirida kamida <b>uchta 0</b> bor. 52 000 : 1000 = 52, tekshiruv: 52 · 1000 = 52 000 ✓.</p>",
 q:{t:"Qaysi son 1000 ga qoldiqsiz bo'linadi?",opts:["40 000","4 500","40 050","45 600"],ok:0,why:"Oxirida to'rtta 0 — kamida uchta bor.",hint:"Oxirida kamida nechta 0 kerak?",full:"40 000 : 1000 = 40. 4 500 da ikkita 0, 40 050 da bitta, 45 600 da ikkita — yetarli emas."},
 tn:"Pul bilan: 52 000 so'mda nechta 1000 so'mlik bor?"},
{h:"Zanjir: ·10 ·10 ·10",sum:"7 → 70 → 700 → 7000: har ·10 bir xona; ·1000 = ·10 ·10 ·10.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Har safar 10 ga ko'paytirsak, nima bo'ladi? Bosib boring.</p>",btns:[phaser(P3)],
 after:"<p><b>100 = 10 · 10</b>, <b>1000 = 10 · 10 · 10</b>. Shuning uchun nollar soni — necha marta 10 ga ko'paytirilganini bildiradi.</p>",
 q:{t:"(8 · 10) · 100 = ?",opts:["8000","800","80 000","810"],ok:0,why:"8 · 1000 = 8000.",hint:"Jami nechta 0?",full:"8 · 10 = 80, 80 · 100 = 8000. Jami uchta 0 — bu 8 · 1000. «800» — bitta ko'paytirish unutilgan."},
 tn:"Bolalar «zanjir»ni ovoz chiqarib aytsin: yetti, yetmish, yetti yuz, yetti ming."},
{h:"Yaxlit sonlarni ko'paytirish",sum:"30 · 200 = (3 · 2) · 1000 = 6000: raqamlarni ko'paytirib, nollarni qo'shamiz.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ikkala ko'paytuvchi ham yaxlit. Qadamma-qadam:</p>",btns:[phaser(P4)],
 after:"<p>Qoida: <b>nolsiz qismlarni</b> ko'paytiramiz, keyin ikkala sondagi nollarni <b>birga</b> yozamiz. 60 · 400: 6 · 4 = 24, nollar 1 + 2 = 3 → 24 000.</p>",
 q:{t:"70 · 300 = ?",opts:["21 000","2 100","210 000","10 000"],ok:0,why:"7 · 3 = 21, uchta 0.",hint:"Nollarni sanang: 70 da bitta, 300 da ikkita.",full:"7 · 3 = 21, nollar 1 + 2 = 3: 21 000. «2 100» — bitta 0 unutilgan."},
 tn:"Nollarni barmoq bilan yopish usuli: yopiq barmoqlar soni — natijaga qo'shiladigan nollar."},
{h:"Yaxlit sonlarni bo'lish",sum:"4800 : 600 = 48 : 6 = 8 — ikkalasidan teng sondagi nollarni olamiz.",a:"m05",start:function(){W3eq(['4800 : 600 = ?']);W3msg('Qanday soddalashtiramiz?')},fin:function(){W3eq(['4800 : 600','= 48 : 6 = [8]'])},
 html:"<p><b>4800 : 600</b>. Ikkala sondan nechta 0 olib tashlash mumkin?</p>",
 btns:[["ikkitadan",function(c,done){W3eq(['4800 : 600','= 48 : 6 = [8]']);W3msg('To‘g‘ri: 48 yuzlik : 6 yuzlik = <b>8</b>. Tekshiruv: 8 · 600 = 4800 ✓');done()}],["bittadan",function(){W3eq(['480 : 60 = 8']);W3msg('Javob ham 8, lekin yana soddalashtirsa bo‘ladi','Ko‘proq olib tashlang')}],["hammasini",function(){W3eq(['48 : 6 = 8 ?']);W3msg('600 da faqat ikkita 0 — undan ko‘p olib bo‘lmaydi. Ikkalasidan <b>teng</b> sonda!','Qayta tanlang')}]],g3:1,
 after:"<p>Bo'linuvchi va bo'luvchidan <b>bir xil</b> sondagi nollarni olsak, bo'linma o'zgarmaydi. Lekin bo'linuvchida ortiqcha nol qolsa — u javobda qoladi: 8000 : 40 = 800 : 4 = <b>200</b>.</p>",
 q:{t:"36 000 : 900 = ?",opts:["40","4","400","4000"],ok:0,why:"360 : 9 = 40.",hint:"Ikkalasidan ikkitadan 0 oling.",full:"36 000 : 900 = 360 : 9 = 40. «4» — bo'linuvchidan uchta 0 olingan (ortiqcha)."},
 tn:"Teng sondagi nollarni qizil qalam bilan juft-juft o'chirtiring — ortgan nollar ko'rinib turadi."},
{h:"Tuzoq: natijaning o'z noli",sum:"40 · 500 = 20 000: 4 · 5 = 20 ning o'z noli bor + uchta 0.",a:"m06",start:function(){W3eq(['40 · 500 = ?']);W3msg('Variantni tanlang')},fin:function(){W3eq(['4 · 5 = 20','40 · 500 = [20 000]'])},
 html:"<p><b>40 · 500</b> nechaga teng?</p>",
 btns:[["20 000",function(c,done){W3eq(['4 · 5 = 20','+ 3 ta 0','40 · 500 = [20 000]']);W3msg('To‘g‘ri! 20 ning o‘z noli + uchta 0 = jami to‘rtta 0');done()}],["2 000",function(){W3eq(['40 · 500 = ?']);W3msg('20 ga uchta 0 qo‘shilishi kerak: 20 000','Qayta tanlang')}],["200 000",function(){W3eq(['40 · 500 = ?']);W3msg('Ortiqcha 0. 4 · 5 = 20, nollar: 1 + 2 = 3','Qayta tanlang')}]],g3:1,
 after:"<p>Raqamlar ko'paytmasi 0 bilan tugasa (4 · 5 = 20, 2 · 5 = 10, 6 · 5 = 30, 8 · 5 = 40) — u nol <b>qo'shimcha</b>. Shuning uchun natijadagi nollar ko'proq bo'ladi.</p>",
 q:{t:"50 · 60 = ?",opts:["3000","300","30 000","110"],ok:0,why:"5 · 6 = 30, + 2 ta 0.",hint:"5 · 6 nechaga teng?",full:"5 · 6 = 30, nollar 1 + 1 = 2: 3000. «300» — 30 ning o'z nolini hisoblamagan."},
 tn:"Bu xatoni bolalar ko'p qiladi — har doim «raqamlar ko'paytmasini to'liq yozib, keyin nollarni qo'shing» deb o'rgating."},
{h:"Kattaliklar: km, kg, ming so'm",sum:"1 km = 1000 m, 1 kg = 1000 g: 3 km = 3000 m; 5000 g = 5 kg; 2 km 40 m = 2040 m.",a:"m07",start:function(){W3eq(['1 km = 1000 m','1 kg = 1000 g'],{fs:22})},fin:function(){W3eq(['3 km = [3000] m','5000 g = [5] kg','2 km 40 m = [2040] m'],{fs:20})},
 html:"<p>Har birini bosib, almashtiring:</p>",
 btns:[["3 km → m",function(c,done){W3eq(['3 km = 3 · 1000','= [3000] m'],{fs:22});W3msg('Katta → kichik: ko‘paytiramiz');mvK(done,3)}],["5000 g → kg",function(c,done){W3eq(['5000 g = 5000 : 1000','= [5] kg'],{fs:22});W3msg('Kichik → katta: bo‘lamiz');mvK(done,3)}],["2 km 40 m → m",function(c,done){W3eq(['2 km 40 m = 2000 + 40','= [2040] m'],{fs:22});W3msg('Diqqat: <b>2400</b> emas! 40 m — bu 0 040');mvK(done,3)}]],g3:1,
 after:"<p>«Kilo» — <b>1000</b> degani. Aralash kattalikda bo'sh xonalarga <b>0</b> yozishni unutmang: 2 km 40 m = 2 <b>0</b>40 m, 3 kg 5 g = 3 <b>00</b>5 g.</p>",
 q:{t:"4 kg 50 g = ? g",opts:["4050","4500","450","4005"],ok:0,why:"4000 + 50 = 4050.",hint:"4 kg = 4000 g.",full:"4 kg = 4000 g, + 50 = 4050 g. «4500» — 50 ni 500 deb yozgan, «4005» — 5 g deb olgan."},
 tn:"1 kg shakar va 1 l suv — bolalarga ko'tarib ko'rsating. 1 km — maktabdan qayergacha ekanini ayting."},
{h:"Teskari savol",sum:"□ · 1000 = 82 000 → □ = 82; □ : 100 = 30 → □ = 3000.",a:"m08",start:function(){W3eq(['□ · 1000 = 82 000','□ : 100 = 30'],{fs:22})},fin:function(){W3eq(['□ = 82 000 : 1000 = [82]','□ = 30 · 100 = [3000]'],{fs:20})},
 html:"<p>Ikki tenglamani yeching:</p>",
 btns:[["□ · 1000 = 82 000",function(c,done){W3eq(['□ · 1000 = 82 000','□ = 82 000 : 1000 = [82]'],{fs:20});W3msg('Ko‘paytuvchi noma’lum — bo‘lamiz');mvK(done,2)}],["□ : 100 = 30",function(c,done){W3eq(['□ : 100 = 30','□ = 30 · 100 = [3000]'],{fs:20});W3msg('Bo‘linuvchi noma’lum — ko‘paytiramiz');mvK(done,2)}]],g2:1,
 after:"<p>Noma'lumni topish qoidalari 10, 100, 1000 bilan ham ishlaydi — faqat amal juda tez bajariladi.</p>",
 q:{t:"□ : 1000 = 6 · 7. □ = ?",opts:["42 000","4 200","13 000","42"],ok:0,why:"6 · 7 = 42, 42 · 1000.",hint:"Avval o'ng tomonni hisoblang.",full:"6 · 7 = 42; □ = 42 · 1000 = 42 000. «4 200» — 100 ga ko'paytirilgan, «13 000» — 6 + 7 olingan."},
 tn:"Bolalar har tenglamaning yoniga tekshiruvni yozsin."},
{h:"Bilasizmi? «Kilo» va «milli»",sum:"«Kilo» — yunoncha «ming», «milli» — lotincha «ming»dan: 1 km = 1000 m, 1 m = 1000 mm.",a:"m09",start:function(){W3eq(['kilo- = 1000 ·','milli- = : 1000'],{fs:22});W3msg('1 km = 1000 m &nbsp; 1 m = 1000 mm &nbsp; 1 kg = 1000 g')},fin:function(){STEPS[8].start()},
 html:"<p>🌍 Metrik tizim yaratilganda olimlar old qo'shimchalarni qadimgi tillardan olishgan: <b>«kilo»</b> — yunoncha «ming» so'zidan, <b>«milli»</b> — lotincha «ming» (mille) so'zidan. Shuning uchun <b>kilo</b>metr — 1000 metr, <b>milli</b>metr — metrning mingdan bir qismi.</p>",
 tn:"Bolalar «kilo» bilan boshlanadigan so'zlarni topsin: kilogramm, kilometr, kilovatt."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){c12([{v:7},{v:70,lab:'·10'},{v:700,lab:'·100'},{v:7000,lab:'·1000'}],'·10 — 1 xona, ·100 — 2 xona, ·1000 — 3 xona')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>·1000</b> — uch xona chapga: 47 · 1000 = 47 000; <b>:1000</b> — uch xona o'ngga: 52 000 : 1000 = 52.</li><li>1000 = 10 · 10 · 10.</li><li>Yaxlit sonlar: 30 · 200 = 6 · 1000 = 6000.</li><li>Natijaning o'z noli: 40 · 500 = 20 000.</li><li>Bo'lishda teng sonda 0 olinadi: 4800 : 600 = 48 : 6 = 8.</li><li>1 km = 1000 m, 1 kg = 1000 g; 2 km 40 m = 2040 m.</li></ul></div>",
 tn:"Keyingi mavzu: ikki va uch xonali songa ko'paytirish."}
];
var PROBS=[
{t:"58 · 1000 = ?",o:["58 000","5 800","580 000","580"],k:0,s:"Uchta 0."},
{t:"73 000 : 1000 = ?",o:["73","730","7 300","7"],k:0,s:"Uchta 0 olinadi."},
{t:"409 · 100 = ?",o:["40 900","4 090","49 000","409 000"],k:0,s:"Ikki xona chapga."},
{t:"25 000 : 100 = ?",o:["250","25","2 500","2 050"],k:0,s:"Ikkita 0 olinadi."},
{t:"6 km = ? m",o:["6000","600","60 000","1006"],k:0,s:"6 · 1000."},
{t:"9000 g = ? kg",o:["9","90","900","9000"],k:0,s:"9000 : 1000."},
{t:"20 · 400 = ?",o:["8000","800","80 000","420"],k:0,s:"2 · 4 = 8, uchta 0."},
{t:"60 · 50 = ?",o:["3000","300","30 000","110"],k:0,s:"6 · 5 = 30, ikkita 0."},
{t:"500 · 80 = ?",o:["40 000","4 000","400 000","580"],k:0,s:"5 · 8 = 40, uchta 0."},
{t:"5600 : 700 = ?",o:["8","80","800","9"],k:0,s:"56 : 7 = 8."},
{t:"42 000 : 600 = ?",o:["70","7","700","60"],k:0,s:"420 : 6 = 70."},
{t:"3 km 60 m = ? m",o:["3060","3600","360","3006"],k:0,s:"3000 + 60."},
{t:"7 kg 8 g = ? g",o:["7008","7080","7800","78"],k:0,s:"7000 + 8."},
{t:"4050 m = ? km ? m",o:["4 km 50 m","40 km 50 m","4 km 500 m","405 km"],k:0,s:"4000 m = 4 km, 50 m qoladi."},
{t:"□ · 100 = 36 000. □ = ?",o:["360","36","3 600","36 100"],k:0,s:"36 000 : 100."},
{t:"Qaysi ifoda eng katta?",o:["30 · 400","200 · 50","90 · 100","600 · 10"],k:0,s:"12 000; 10 000; 9 000; 6 000."},
{t:"Bitta daftar 3 000 so'm. 40 ta daftar necha so'm?",o:["120 000","12 000","1 200 000","43 000"],k:0,s:"3 · 4 = 12, to'rtta 0."},
{t:"Velosipedchi 1 soatda 12 km yurdi. 1 soatda necha metr?",o:["12 000","1 200","120","12 100"],k:0,s:"12 · 1000."},
{t:"8 000 g olma 4 ta savatga teng solindi. Har savatda necha kg?",o:["2","20","2000","32"],k:0,s:"8 kg : 4 = 2 kg."},
{t:"Sonni 100 ga ko'paytirib, 1000 ga bo'lsak, 9 chiqdi. Son qaysi?",o:["90","9","900","9000"],k:0,s:"9 · 1000 : 100 = 90."}
];
function PRACT_STAGE(){c12([{v:7},{v:7000,lab:'·1000'}],'·1000 — uch xona chapga')}
var PREP_DATA={teach:["1000 ga ko'paytirish va bo'lish (uch xona).","1000 = 10 · 10 · 10.","Yaxlit sonlarni ko'paytirish va bo'lish.","km, kg kattaliklarini almashtirish."],
 mist:["40 · 500 = 2000 (20 ning o'z nolini unutadi).","36 000 : 900 = 4.","2 km 40 m = 2400 m.","4050 m = 40 km 50 m."],
 need:["Ming sinfi qo'shilgan xonalar jadvali.","Tarozi va 1 kg toshi, metr lentasi."],
 board:["<span class='w2'>47 · 1000 = 47 000</span>","<span class='w2'>30 · 200 = 6000</span>","<span class='w2'>40 · 500 = 20 000</span>","<span class='w2'>4800 : 600 = 8</span>","<span class='w2'>2 km 40 m = 2040 m</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
