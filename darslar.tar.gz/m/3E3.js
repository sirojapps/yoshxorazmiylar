var CODE='3E3',TITLE='3-sinf · Farq va karrali taqqoslash';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w3u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"«Qanchaga ko‘p?» — farq",sum:"1-hafta 150 bet, 2-hafta 260 − 150 = 110 bet; farq 150 − 110 = 40 bet.",a:"m01",
 frames:[{t:'Malika 260 betli kitobning 1-haftada 150 betini, 2-haftada qolganini o‘qidi.',bars:[{lab:'1-hafta',y:62,segs:[{w:150,txt:'150',c:'a'}]},{lab:'2-hafta',y:112,segs:[{w:110,txt:'?',c:'q'}]}],note:'Avval 2-haftani topamiz'},
  {t:'Malika 260 betli kitobning 1-haftada 150 betini, 2-haftada qolganini o‘qidi.',bars:[{lab:'1-hafta',y:62,segs:[{w:150,txt:'150',c:'a'}]},{lab:'2-hafta',y:112,segs:[{w:110,txt:'110',c:'b'}]}],calc:['260 − 150 = 110 bet']},
  {t:'1-haftada 2-haftadagidan necha bet ko‘p o‘qidi?',bars:[{lab:'1-hafta',y:62,segs:[{w:110,txt:'110',c:'x'},{w:40,txt:'40',c:'g'}]},{lab:'2-hafta',y:112,segs:[{w:110,txt:'110',c:'b'}]}],br:[{b:0,from:1,to:1,lab:'farq',up:true,col:C.ok}],calc:['150 − 110 = <b>40</b> bet ko‘p']}],
 html:"<p>Ikki narsani <b>taqqoslaganda</b> chiziqlarni bir-birining ostiga, chap chetini tenglab chizamiz. Kuzating.</p>",
 after:"<p>«<b>Qanchaga</b> ko'p / kam?» — <b>ayirish</b> bilan topiladi: kattasidan kichigini ayiramiz. Farq — uzun chiziqning «ortib qolgan» qismi.</p>",
 q:{t:"Sinfda 28 o'quvchi, ulardan 16 tasi qiz. Qizlar o'g'il bolalardan nechta ko'p?",opts:["12","4","44","16"],ok:1,why:"O'g'il 28 − 16 = 12; 16 − 12 = 4.",hint:"Avval o'g'il bolalar sonini toping.",full:"O'g'il bolalar: 28 − 16 = 12. Farq: 16 − 12 = 4. «12» — bu o'g'il bolalar soni, farq emas."},
 tn:"Bank misoli (730-id). Taqqoslash chizmasini doskada rangli bo'r bilan chizing: ikki chiziq chap chetdan bir xil boshlanishi shart."}),
bmStep({h:"«Necha marta ko‘p?» — karrali taqqoslash",sum:"36 ichida 9 to'rt marta bor: 36 : 9 = 4 marta.",a:"m02",
 frames:[{t:'Akmalda 9 ta marka, Bekzodda 36 ta marka. Bekzodda necha marta ko‘p?',bars:[{lab:'Akmal',y:50,segs:[{w:9,txt:'9',c:'a'}]},{lab:'Bekzod',y:104,segs:[{w:36,txt:'36',c:'b'}]}],note:'Akmalning chizig‘ini Bekzodnikiga «o‘lchab» chiqamiz'},
  {t:'Akmalda 9 ta marka, Bekzodda 36 ta marka. Bekzodda necha marta ko‘p?',bars:[{lab:'Akmal',y:50,segs:[{w:9,txt:'9',c:'a'}]},{lab:'Bekzod',y:104,segs:w3u(4,'9','b',9)}],br:[{b:1,lab:'4 marta',up:false,col:C.ok}],calc:['36 : 9 = <b>4</b> marta ko‘p']}],
 html:"<p>Endi savol boshqacha: <b>necha marta</b>? Kichik chiziq kattasiga necha marta «sig'adi»?</p>",
 after:"<p>«<b>Necha marta</b> ko'p / kam?» — <b>bo'lish</b> bilan topiladi: kattasini kichigiga bo'lamiz. Farqi: 36 − 9 = 27 (ta ko'p), 36 : 9 = 4 (marta ko'p).</p>",
 q:{t:"Ruchka 3000 so'm, kitob 15 000 so'm. Kitob ruchkadan necha marta qimmat?",opts:["12 000 marta","5 marta","3 marta","18 000 marta"],ok:1,why:"15 000 : 3000 = 5.",hint:"«Necha marta» — bo'lish.",full:"15 000 : 3000 = 5 marta. «12 000» — bu «qanchaga qimmat» savolining javobi (ayirish), «necha marta» emas."},
 tn:"Bolalarga ikki savolni yonma-yon yozdiring: «qanchaga?» → ayirish, «necha marta?» → bo'lish. Bu farqni 1 daqiqalik og'zaki mashq bilan mustahkamlang."}),
bmStep({h:"«ta ko‘p» yoki «marta ko‘p»?",sum:"«3 marta ko‘p» — 12 · 3 = 36; «3 ta ko‘p» bo‘lsa 12 + 3 = 15 bo‘lardi.",a:"m03",
 frames:[{t:'Savatda 12 ta olma bor. Nok olmadan 3 marta ko‘p. Nok nechta?',bars:[{lab:'olma',y:50,segs:[{w:12,txt:'12',c:'a'}]},{lab:'nok',y:104,segs:w3u(3,'12','q',12)}],note:'Javobni tanlang:'}],
 html:"<p>Masalani diqqat bilan o'qing — bitta so'z hamma narsani o'zgartiradi:</p>",
 btns:bmPick(["15 ta","36 ta","4 ta"],1,{t:'Nok olmadan 3 marta ko‘p',bars:[{lab:'olma',y:50,segs:[{w:12,txt:'12',c:'a'}]},{lab:'nok',y:104,segs:w3u(3,'12','g',12)}],br:[{b:1,lab:'36 ta',up:false,col:C.ok}],calc:['12 · 3 = <b>36</b> ta nok']},["15 = 12 + 3 — bu «3 ta ko‘p» bo‘lganda. Bu yerda «3 marta».","","4 = 12 : 3 — bu «3 marta kam» bo‘lganda."]),
 after:"<p><b>«ta ko'p» → qo'shish</b>, <b>«marta ko'p» → ko'paytirish</b>. <b>«ta kam» → ayirish</b>, <b>«marta kam» → bo'lish</b>. Chizmada «marta» — bir xil bo'laklar soni.</p>",
 q:{t:"Ukamda 24 ta kitob bor, menda undan 4 marta kam. Menda nechta kitob?",opts:["20","96","6","28"],ok:2,why:"24 : 4 = 6.",hint:"«marta kam» — qaysi amal?",full:"«4 marta kam» — 24 ni 4 ga bo'lamiz: 6 ta. «20» — «4 ta kam» bo'lganda, «96» — «4 marta ko'p» bo'lganda."},
 tn:"Kartochkalar: «ta ko'p», «marta ko'p», «ta kam», «marta kam». O'qituvchi kartochka ko'rsatadi, bolalar amal belgisini ko'rsatadi (+, ·, −, :)."}),
bmStep({h:"Marta ko‘p va jami",sum:"Echki 28 m², poni 4 marta ko‘p = 112; jami 28 + 112 = 140 m² (yoki 28 · 5).",a:"m04",
 frames:[{t:'Echkiga 28 m², poniga undan 4 marta ko‘p joy ajratildi. Jami necha m²?',bars:[{lab:'echki',y:50,segs:[{w:1,txt:'28',c:'a'}]},{lab:'poni',y:104,segs:w3u(4,'28','b',1)}],note:'Poni — 4 bo‘lak, echki — 1 bo‘lak'},
  {t:'Echkiga 28 m², poniga undan 4 marta ko‘p joy ajratildi. Jami necha m²?',bars:[{lab:'jami',y:76,segs:[{w:1,txt:'28',c:'a'}].concat(w3u(4,'28','b',1))}],br:[{b:0,lab:'140 m²',up:true,col:C.ok}],calc:['Poni: 28 · 4 = 112','Jami: 28 + 112 = <b>140</b> m²  (yoki 28 · 5)']}],
 html:"<p>Ko'p bolalar shu yerda xato qiladi: savol <b>jami</b> haqida. Kuzating.</p>",
 after:"<p>Chizmada 1 + 4 = <b>5 bo'lak</b> ko'rinib turibdi: 28 · 5 = 140. Xato javob 112 — bu faqat poniniki, savol esa <b>jami</b>.</p>",
 q:{t:"Fabrika bir kunda 124 ta bolalar kiyimi va undan 5 marta ko'p kattalar kiyimi tikdi. Jami nechta kiyim?",opts:["620","129","744","734"],ok:2,why:"124 · 5 = 620; 124 + 620 = 744.",hint:"Savol — jami nechta.",full:"Kattalar: 124 · 5 = 620. Jami: 124 + 620 = 744 (yoki 124 · 6). «620» — faqat kattalar kiyimi, «129» — «5 ta ko'p» deb o'qish xatosi."},
 tn:"Bank misollari (732, 733-id). Bolalardan savolni ikki marta o'qib, tagiga chizishni so'rang: «jami», «qancha ko'p», «necha marta»."}),
bmStep({h:"Marta kam: bo‘lakdan butunga",sum:"Yurgan yo‘l qolgandan 6 marta kam: 378 : 6 = 63; butun yo‘l 63 + 378 = 441 m.",a:"m05",
 frames:[{t:'Aziz yurgan yo‘l qolgan yo‘ldan 6 marta kam. Qolgan yo‘l 378 m. Uydan maktabgacha necha metr?',bars:[{lab:'yurgan',y:50,segs:[{w:1,txt:'?',c:'q'}]},{lab:'qolgan',y:104,segs:w3u(6,'','b',1)}],br:[{b:1,lab:'378 m',up:false}],note:'Qolgan yo‘l — 6 bo‘lak, yurgani — 1 bo‘lak'},
  {t:'Aziz yurgan yo‘l qolgan yo‘ldan 6 marta kam. Qolgan yo‘l 378 m.',bars:[{lab:'yurgan',y:50,segs:[{w:1,txt:'63',c:'a'}]},{lab:'qolgan',y:104,segs:w3u(6,'63','b',1)}],br:[{b:1,lab:'378 m',up:false}],calc:['1 bo‘lak: 378 : 6 = 63 m']},
  {t:'Uydan maktabgacha bo‘lgan masofa',bars:[{lab:'yo‘l',y:76,segs:[{w:1,txt:'63',c:'a'}].concat(w3u(6,'63','b',1))}],br:[{b:0,lab:'441 m',up:true,col:C.ok}],calc:['63 + 378 = <b>441</b> m']}],
 html:"<p>«6 marta kam» degani — qolgan yo'l <b>6 bo'lak</b>, yurgan yo'l <b>1 bo'lak</b>. Kuzating.</p>",
 after:"<p>Butun yo'l = 1 + 6 = 7 bo'lak = 63 · 7 = 441 m. «378 · 6» qilish — eng ko'p uchraydigan xato: «kam» so'zi ko'paytirishni emas, bo'lishni talab qiladi.</p>",
 q:{t:"Ip ikki bo'lakka kesildi. Kalta bo'lak uzunidan 3 marta kam. Uzun bo'lak 24 sm. Ip necha sm bo'lgan?",opts:["32","96","27","8"],ok:0,why:"24 : 3 = 8; 8 + 24 = 32.",hint:"Avval kalta bo'lakni toping.",full:"Kalta: 24 : 3 = 8 sm. Butun ip: 8 + 24 = 32 sm. «8» — faqat kalta bo'lak, «27» — «3 ta kam» deb o'qilgan."},
 tn:"Bank misoli (731-id), 3-daraja. Ip yoki qog'oz tasmani haqiqatan kesib ko'rsating — bu Singapurning CPA (aniq → rasm → belgi) yondashuvi."}),
bmStep({h:"Tuzoq: birliklar har xil",sum:"Bo'y 1 m 28 sm = 128 sm; sakrash 46 sm past: 128 − 46 = 82 sm.",a:"m06",
 frames:[{t:'Saidning bo‘yi 1 m 28 sm. U sakragan balandlik bo‘yidan 46 sm past. Necha sm sakradi?',bars:[{lab:'bo‘y',y:50,segs:[{w:128,txt:'1 m 28 sm',c:'a'}]},{lab:'sakrash',y:104,segs:[{w:82,txt:'?',c:'q'}]}],note:'Javobni tanlang:'}],
 html:"<p>Bu masalada ikkita tuzoq bor. Chizmaga qarab tanlang:</p>",
 btns:bmPick(["174 sm","82 sm","18 sm"],1,{t:'Avval bir xil birlikka o‘tkazamiz',bars:[{lab:'bo‘y',y:50,segs:[{w:82,txt:'82',c:'x'},{w:46,txt:'46',c:'y'}]},{lab:'sakrash',y:104,segs:[{w:82,txt:'82 sm',c:'g'}]}],br:[{b:0,from:1,to:1,lab:'46 sm past',up:true}],calc:['1 m 28 sm = 128 sm','128 − 46 = <b>82</b> sm']},["174 = 128 + 46 — «past» so‘zi kamroq degani, qo‘shish emas.","","18 = 46 − 28 — metr unutilgan: 1 m 28 sm = 128 sm."]),
 after:"<p>Ikki tuzoq: 1) «past» — kam degani; 2) metr va santimetr aralash — avval <b>bir xil birlikka</b> o'tkazing (1 m = 100 sm).</p>",
 q:{t:"Quti 2 kg 300 g, uning ichidagi kitoblar qutidan 1 kg 800 g yengil. Kitoblar necha gramm?",opts:["500","4100","1500","700"],ok:0,why:"2300 − 1800 = 500.",hint:"Hammasini grammga o'tkazing.",full:"2 kg 300 g = 2300 g, 1 kg 800 g = 1800 g. 2300 − 1800 = 500 g. «4100» — qo'shilgan, «1500» — kilogramm qismlari noto'g'ri ayirilgan."},
 tn:"Bank misoli (729-id). Sinfda bolalarning bo'yini lenta bilan o'lchab, sm ga o'tkazish mashqi."}),
bmStep({h:"Tuzoq: ikki karrali taqqoslash",sum:"40 l : 5 = 8 banka, 40 l : 4 = 10 banka; 10 − 8 = 2 banka ko'p.",a:"m07",
 frames:[{t:'40 l olcha sharbati 5 l li, 40 l qulupnay sharbati 4 l li bankalarga quyildi.',bars:[{lab:'olcha',y:66,segs:w3u(8,'5','a',5)},{lab:'qulupnay',y:112,segs:w3u(10,'4','b',4)}],note:'Har bir to‘rtburchak — bitta banka'},
  {t:'Qulupnay uchun olchaga qaraganda nechta ko‘p banka kerak?',bars:[{lab:'olcha',y:66,segs:w3u(8,'5','a',5)},{lab:'qulupnay',y:112,segs:w3u(10,'4','b',4)}],br:[{b:0,lab:'8 banka',up:true},{b:1,lab:'10 banka',up:false}],calc:['40 : 5 = 8,  40 : 4 = 10','10 − 8 = <b>2</b> banka ko‘p']}],
 html:"<p>Sharbat miqdori bir xil, lekin bankalar soni har xil. Nega? Kuzating.</p>",
 after:"<p>Kichik banka — <b>ko'proq</b> banka kerak. Avval har birini <b>bo'lish</b> bilan topamiz, keyin <b>ayirish</b> bilan farqini. Javob 1 (5 − 4) — bankalar hajmi farqi, savol esa bankalar soni haqida.</p>",
 q:{t:"36 ta tuxum 6 talik va 4 talik qutilarga alohida-alohida joylandi (har biriga 36 tadan). 4 talik qutilar nechta ko'p?",opts:["2","3","9","6"],ok:1,why:"36 : 4 = 9, 36 : 6 = 6; 9 − 6 = 3.",hint:"Har bir xil qutidan nechtadan chiqadi?",full:"4 talik: 36 : 4 = 9 quti, 6 talik: 36 : 6 = 6 quti. Farq: 3. «2» — quti sig'imlari farqi, «9» — faqat 4 talik qutilar soni."},
 tn:"Bank misoli (734-id). Cho'p yoki tugmalar bilan 12 tani 3 tadan va 4 tadan guruhlab ko'rsating."}),
bmStep({h:"Tuzoq: «marta» va «ta» birga",sum:"Aka 3 marta ko'p, ya'ni 24 ta ko'p: 2 bo'lak = 24 → 1 bo'lak 12; uka 12, aka 36.",a:"m08",
 frames:[{t:'Akam ukamdan 3 marta ko‘p yong‘oq terdi — bu 24 ta ko‘p. Har biri nechta terdi?',bars:[{lab:'uka',y:50,segs:[{w:1,txt:'?',c:'q'}]},{lab:'aka',y:104,segs:w3u(3,'?','b',1)}],note:'Uka — 1 bo‘lak, aka — 3 bo‘lak'},
  {t:'Akam ukamdan 3 marta ko‘p yong‘oq terdi — bu 24 ta ko‘p.',bars:[{lab:'uka',y:50,segs:[{w:1,txt:'?',c:'x'}]},{lab:'aka',y:104,segs:[{w:1,txt:'?',c:'x'},{w:1,txt:'?',c:'y'},{w:1,txt:'?',c:'y'}]}],br:[{b:1,from:1,to:2,lab:'24 ta ko‘p',up:false,col:C.bad}],calc:['Farq — 2 bo‘lak = 24','1 bo‘lak: 24 : 2 = 12']},
  {t:'Akam ukamdan 3 marta ko‘p yong‘oq terdi — bu 24 ta ko‘p.',bars:[{lab:'uka',y:50,segs:[{w:1,txt:'12',c:'a'}]},{lab:'aka',y:104,segs:w3u(3,'12','g',1)}],br:[{b:1,lab:'36 ta',up:false,col:C.ok}],calc:['Uka: <b>12</b> ta, aka: 12 · 3 = <b>36</b> ta','Tekshiruv: 36 − 12 = 24 ✓, 36 : 12 = 3 ✓']}],
 html:"<p>Bankdagi eng qiyin xil: ham «marta», ham «ta» bitta masalada. Chizmasiz yechish juda qiyin — kuzating.</p>",
 after:"<p>Kalit: «3 marta ko'p» bo'lsa, farq <b>3 − 1 = 2 bo'lak</b>. 24 ni 3 ga bo'lish (8) — eng ko'p uchraydigan xato.</p>",
 q:{t:"Opamning yoshi mening yoshimdan 4 marta katta, ya'ni 18 yosh katta. Men necha yoshdaman?",opts:["6","18","4","24"],ok:0,why:"Farq 3 bo'lak = 18 → 1 bo'lak 6.",hint:"4 marta katta — farq necha bo'lak?",full:"Men — 1 bo'lak, opam — 4 bo'lak, farq — 3 bo'lak = 18 yosh. 1 bo'lak = 6 yosh (opam 24). «4» — 18 ni 4 ga bo'lishga urinish, «24» — opamning yoshi."},
 tn:"Bu — Singapur chizma modelining eng kuchli tomoni: algebrasiz tenglama. Bolalar o'zi chizib, «farq necha bo'lak?» deb tushuntirsin."}),
bmStep({h:"Bilasizmi? Fil va siz",sum:"Fil taxminan 5000 kg, 3-sinf o'quvchisi taxminan 25 kg: 5000 : 25 = 200 marta.",a:"m09",
 frames:[{t:'Afrika fili taxminan 5000 kg, 3-sinf o‘quvchisi taxminan 25 kg',bars:[{lab:'siz 25',y:50,segs:[{w:25,txt:'',c:'a'}]},{lab:'fil',y:104,segs:[{w:5000,txt:'5000 kg',c:'b'}]}],note:'Fil sizdan taxminan necha marta og‘ir?'}],
 html:"<p>🐘 Afrika fili — quruqlikdagi eng katta hayvon, og'irligi odatda bir necha tonna. Taxminan hisoblaylik:</p>",
 btns:bmPick(["4975 marta","200 marta","20 marta"],1,{t:'Fil sizdan taxminan 200 marta og‘ir',bars:[{lab:'siz 25',y:50,segs:[{w:25,txt:'',c:'a'}]},{lab:'fil',y:104,segs:[{w:5000,txt:'200 ta «siz»',c:'g'}]}],calc:['5000 : 25 = <b>200</b> marta']},["4975 = 5000 − 25 — bu «qanchaga og‘ir», «necha marta» emas.","","20 marta kam: 25 · 20 = 500, 5000 emas."]),
 after:"<p>Bitta filni muvozanatlash uchun tarozining narigi pallasiga butun maktab — taxminan 200 o'quvchi kerak bo'lardi! Chizmada sizning chizig'ingiz juda kichik — «marta» farqi katta bo'lganda shunday ko'rinadi.</p>",
 tn:"Bolalarga o'z og'irligini (taxminan) bilib, boshqa narsalar bilan «necha marta» solishtirish topshirig'i."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){bmDraw({t:'Taqqoslash chizmasi',bars:[{lab:'kichik',y:50,segs:[{w:1,txt:'1 bo‘lak',c:'a'}]},{lab:'katta',y:104,segs:w3u(3,'1 bo‘lak','b',1)}],br:[{b:1,from:1,to:2,lab:'farq — 2 bo‘lak',up:false}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Taqqoslash: chiziqlarni <b>bir-birining ostiga</b>, chap chetini tenglab chizing.</li><li>«<b>Qanchaga</b> ko'p/kam?» → <b>ayirish</b>; «<b>necha marta</b>?» → <b>bo'lish</b>.</li><li>«ta ko'p» → +, «marta ko'p» → ·, «ta kam» → −, «marta kam» → :.</li><li>Savol <b>jami</b> haqida bo'lsa — hamma bo'laklarni qo'shing.</li><li>Birliklar har xil bo'lsa — avval <b>bir xil birlikka</b> o'tkazing.</li><li>«n marta ko'p» → farq <b>n − 1</b> bo'lak.</li></ul></div>",
 tn:"Keyingi dars boshida 4 ta kartochka (ta/marta, ko'p/kam) bilan 2 daqiqalik og'zaki mashq."}
];
var PROBS=[
{t:"Sinfda 28 o'quvchi, 16 tasi qiz. Qizlar o'g'il bolalardan nechta ko'p?",o:["4","12","44","16"],k:0,s:"O'g'il 12; 16 − 12 = 4."},
{t:"Ruchka 3000, kitob 15 000 so'm. Kitob necha marta qimmat?",o:["5 marta","12 000 marta","3 marta","4 marta"],k:0,s:"15 000 : 3000 = 5."},
{t:"Savatda 12 ta olma, nok olmadan 3 marta ko'p. Nok nechta?",o:["36","15","4","9"],k:0,s:"12 · 3 = 36."},
{t:"Ukamda 24 ta kitob, menda undan 4 marta kam. Menda nechta?",o:["6","20","96","28"],k:0,s:"24 : 4 = 6."},
{t:"Echkiga 28 m², poniga undan 4 marta ko'p joy ajratildi. Jami necha m²?",o:["140","112","32","116"],k:0,s:"28 + 112 = 140."},
{t:"Fabrikada 124 ta bolalar kiyimi va undan 5 marta ko'p kattalar kiyimi tikildi. Jami nechta?",o:["744","620","129","734"],k:0,s:"124 + 620 = 744."},
{t:"Malika 260 betli kitobning 1-haftada 150 betini, 2-haftada qolganini o'qidi. 1-haftada necha bet ko'p o'qidi?",o:["40","110","30","50"],k:0,s:"2-hafta 110; 150 − 110 = 40."},
{t:"Yurgan yo'l qolgan yo'ldan 6 marta kam, qolgan yo'l 378 m. Butun yo'l necha metr?",o:["441","63","384","2268"],k:0,s:"378 : 6 = 63; 63 + 378 = 441."},
{t:"Saidning bo'yi 1 m 28 sm, sakragan balandligi bo'yidan 46 sm past. Necha sm sakradi?",o:["82","174","18","72"],k:0,s:"128 − 46 = 82."},
{t:"40 l sharbat 5 l li, yana 40 l sharbat 4 l li bankalarga quyildi. 4 l li bankalar nechta ko'p?",o:["2","1","10","8"],k:0,s:"10 − 8 = 2."},
{t:"Akam ukamdan 3 marta ko'p yong'oq terdi — bu 24 ta ko'p. Ukam nechta terdi?",o:["12","8","36","6"],k:0,s:"2 bo'lak = 24 → 12."},
{t:"Opamning yoshi menikidan 4 marta katta, ya'ni 18 yosh katta. Opam necha yoshda?",o:["24","18","22","6"],k:0,s:"3 bo'lak = 18 → 1 bo'lak 6; opa 24."},
{t:"Ikki sonning biri ikkinchisidan 5 marta katta, yig'indisi 72. Kichik son nechaga teng?",o:["12","14","60","15"],k:0,s:"6 bo'lak = 72 → 12."},
{t:"Ip ikki bo'lakka kesildi, kaltasi uzunidan 3 marta kam, uzuni 24 sm. Ip necha sm?",o:["32","8","96","27"],k:0,s:"24 : 3 = 8; 8 + 24 = 32."},
{t:"Quti 2 kg 300 g, kitoblar qutidan 1 kg 800 g yengil. Kitoblar necha gramm?",o:["500","4100","1500","700"],k:0,s:"2300 − 1800 = 500."},
{t:"Do'konda 450 kg olma, nok olmadan 300 kg kam. Olma nokdan necha marta ko'p?",o:["3 marta","300 marta","150 marta","2 marta"],k:0,s:"Nok 150 kg; 450 : 150 = 3."},
{t:"Bir qutida 48 ta qalam, ikkinchisida undan 8 ta kam, uchinchisida birinchisidan 4 marta kam. Jami nechta?",o:["100","64","52","96"],k:0,s:"48 + 40 + 12 = 100."},
{t:"Otam 36 yoshda, men undan 4 marta yoshman. Otam mendan necha yosh katta?",o:["27","9","32","40"],k:0,s:"Men 36 : 4 = 9; 36 − 9 = 27."},
{t:"Bir bog'da 63 tup olma, bu nokdan 7 marta ko'p. Olma nokdan nechta ko'p?",o:["54","9","56","70"],k:0,s:"Nok 63 : 7 = 9; 63 − 9 = 54."},
{t:"Kitob daftardan 4 marta qimmat, ikkalasi birga 12 500 so'm. Kitob necha so'm?",o:["10 000","2500","3125","12 000"],k:0,s:"5 bo'lak = 12 500 → 2500; kitob 10 000."}
];
function PRACT_STAGE(){bmDraw({t:'Taqqoslash chizmasi',bars:[{lab:'kichik',y:50,segs:[{w:1,txt:'1',c:'a'}]},{lab:'katta',y:104,segs:w3u(3,'1','b',1)}],br:[{b:1,lab:'3 marta ko‘p',up:false}]})}
var PREP_DATA={teach:["Taqqoslash chizmasi: ikki chiziq bir-birining ostida.","«Qanchaga ko'p/kam» — ayirish, «necha marta» — bo'lish.","«ta/marta ko'p/kam» to'rt holat.","Karrali taqqoslash va jami; birliklarni bir xillash; farq bo'laklarda (n − 1)."],
 mist:["«marta» va «ta» ni almashtiradi.","Savol «jami» haqida bo'lsa ham bitta qismni javob qilib beradi.","«marta kam» da ko'paytiradi.","Har xil birliklarni o'tkazmasdan ayiradi.","«3 marta ko'p, ya'ni 24 ta ko'p» da 24 ni 3 ga bo'ladi."],
 need:["Rangli qog'oz tasmalar, qaychi.","«ta ko'p / marta ko'p / ta kam / marta kam» kartochkalari."],
 board:["<span class='w2'>150 − 110 = 40</span> (qanchaga).","<span class='w2'>36 : 9 = 4</span> (necha marta).","<span class='w2'>28 · 5 = 140</span> (jami 5 bo'lak).","<span class='w2'>378 : 6 = 63; 63 · 7 = 441</span>.","<span class='w2'>24 : 2 = 12; 12 · 3 = 36</span>."]};
