var CODE='3J17',TITLE='3-sinf · Eng ko‘p / eng kam bo‘lishi mumkin?';
function j17Boats(a,b,left,ok){clear();var g=S.g;T(g,180,22,'50 o‘quvchi: 6 kishilik va 4 kishilik qayiqlar, hammasi to‘la',{'font-size':11,'font-weight':800,fill:'#33475b'});
 for(var i=0;i<a;i++){var x=24+i*40;E('rect',{x:x,y:40,width:36,height:30,rx:8,fill:'#cfe6fb',stroke:'#4b8fd9','stroke-width':2},g);T(g,x+18,61,'6',{'font-size':16,'font-weight':800,fill:'#2a64a8'})}
 for(var j=0;j<b;j++){var x2=24+j*40;E('rect',{x:x2,y:84,width:36,height:30,rx:8,fill:'#fde6c8',stroke:'#d08a2a','stroke-width':2},g);T(g,x2+18,105,'4',{'font-size':16,'font-weight':800,fill:'#a0601a'})}
 if(left!=null)T(g,180,148,left?('qirg‘oqda '+left+' kishi qoldi — qayiq to‘lmaydi ✗'):'hamma o‘tirdi ✓',{'font-size':14,'font-weight':800,fill:ok?C.ok:C.bad})}
function j17Try(a){var r=50-6*a;return {b:Math.floor(r/4),left:r%4}}
function j17Bars(vals,o){o=o||{};clear();var g=S.g,n=vals.length,w=Math.min(40,300/n),x0=180-n*w/2,mx=o.max||Math.max.apply(null,vals),hl=o.hl;
 vals.forEach(function(v,i){var h=v/mx*(o.h||100),x=x0+i*w;E('rect',{x:x+3,y:136-h,width:w-6,height:h,rx:3,fill:hl===i?'#5cc98a':(o.col||'#9cc7ef')},g);T(g,x+w/2,130-h,v,{'font-size':o.fs||11,'font-weight':800,fill:hl===i?C.ok:'#1d2b3a'});if(o.lab)T(g,x+w/2,152,o.lab[i],{'font-size':10,'font-weight':700,fill:'#5b6b7b'})});
 if(o.t)T(g,180,168,o.t,{'font-size':11,'font-weight':800,fill:o.tc||'#33475b'})}
var P2=[function(){j17Bars([11],{max:36,lab:['1·11']});j2Msg('Yig‘indisi 12 bo‘lgan ikki son. Ko‘paytmasi eng katta qachon? 1 · 11 = 11')},
 function(){j17Bars([11,20,27],{max:36,lab:['1·11','2·10','3·9']});j2Msg('2 · 10 = 20, 3 · 9 = 27 — o‘syapti!')},
 function(){j17Bars([11,20,27,32,35,36],{max:36,lab:['1·11','2·10','3·9','4·8','5·7','6·6']});j2Msg('4 · 8 = 32, 5 · 7 = 35, 6 · 6 = 36')},
 function(){j17Bars([11,20,27,32,35,36],{max:36,hl:5,lab:['1·11','2·10','3·9','4·8','5·7','6·6'],t:'sonlar qancha yaqin — ko‘paytma shuncha katta',tc:C.ok});j2Msg('Eng katta: <b>6 · 6 = 36</b> — sonlar <b>teng</b> bo‘lganda')}];
function j17Seq(a){var r=[];for(var i=0;i<10;i++)r.push(a-i);return r}
var P3=[function(){j17Bars(j17Seq(22),{max:24,h:90,t:'Ali = 22 bo‘lsin: qolganlar ko‘pi bilan 21, 20, … 13'});j2Msg('Ali eng ko‘p oldi. Uni <b>kichik</b> qilish uchun qolganlar unga <b>iloji boricha yaqin</b> bo‘lsin')},
 function(){j17Bars(j17Seq(22),{max:24,h:90,hl:0,t:'22 + 21 + … + 13 = 175 < 180 ✗',tc:C.bad});j2Msg('Eng ko‘pi bilan 175 ta — 180 ga yetmaydi! Demak Ali 22 ta ololmaydi')},
 function(){j17Bars(j17Seq(23),{max:24,h:90,hl:0,t:'23 + 22 + … + 14 = 185 ≥ 180 ✓',tc:C.ok});j2Msg('Ali = 23: eng ko‘pi bilan 185 — yetadi, 5 ta ortiqcha')},
 function(){var v=j17Seq(23);v[9]=9;j17Bars(v,{max:24,h:90,hl:0,t:'eng kichigini 14 → 9 qildik: jami 180 ✓',tc:C.ok});j2Msg('Ortiqcha 5 tani eng kichik nabiradan olamiz: hammasi har xil, jami 180. Javob: <b>23</b>')}];
function j17Strip(a,b,from){clear();var g=S.g,w=12,x0=180-25*w/2;T(g,180,24,'25 o‘quvchi',{'font-size':12,'font-weight':800});
 for(var i=0;i<25;i++)E('rect',{x:x0+i*w,y:70,width:w-1,height:22,fill:'#eef2f6',stroke:'#c8d3de'},g);
 E('rect',{x:x0,y:44,width:a*w-1,height:20,rx:4,fill:'#9cd8b4'},g);T(g,x0+a*w/2,58,'⚽ '+a,{'font-size':11,'font-weight':800});
 var bx=from==='L'?x0:x0+(25-b)*w;E('rect',{x:bx,y:98,width:b*w-1,height:20,rx:4,fill:'#f5c98f'},g);T(g,bx+b*w/2,112,'♟ '+b,{'font-size':11,'font-weight':800});
 var o0=Math.max(x0,bx),o1=Math.min(x0+a*w,bx+b*w);if(o1>o0){E('rect',{x:o0,y:70,width:o1-o0-1,height:22,fill:'#f08a8a'},g);T(g,(o0+o1)/2,140,'ikkalasi: '+Math.round((o1-o0)/w),{'font-size':13,'font-weight':800,fill:C.bad})}}
var P5=[function(){j17Strip(15,13,'R');j2Msg('Futbolchilarni chapdan, shaxmatchilarni <b>o‘ngdan</b> joylaymiz — ustma-ust tushish eng <b>kam</b>')},
 function(){j17Strip(15,13,'R');j2Msg('Kamida: 15 + 13 − 25 = <b>3</b> o‘quvchi ikkalasini o‘ynaydi')},
 function(){j17Strip(15,13,'L');j2Msg('Ikkalasini ham <b>chapdan</b> joylasak — ustma-ust tushish eng <b>ko‘p</b>: ko‘pi bilan <b>13</b> (kichigi)')}];
function j17Coins(a,b,ok,t){clear();var g=S.g;for(var i=0;i<a;i++){E('circle',{cx:30+i*34,cy:56,r:15,fill:'#f4c542',stroke:'#b8901e','stroke-width':2},g);T(g,30+i*34,61,'5',{'font-size':13,'font-weight':800,fill:'#6b4e00'})}
 for(var j=0;j<b;j++){E('circle',{cx:30+j*30,cy:104,r:12,fill:'#d8dde3',stroke:'#8a96a3','stroke-width':2},g);T(g,30+j*30,108,'2',{'font-size':11,'font-weight':800,fill:'#3a4a5a'})}
 T(g,180,150,t,{'font-size':13,'font-weight':800,fill:ok?C.ok:C.bad})}
var P6=[function(){j17Coins(4,0,0,'4 · 5 = 20, yana 3 so‘m kerak — 2 so‘mlik bilan bo‘lmaydi ✗');j2Msg('Ochko‘zlik: iloji boricha ko‘p 5 so‘mlik olamiz… 23 = 20 + 3 — ✗')},
 function(){j17Coins(3,4,1,'3 · 5 + 4 · 2 = 23 → 7 ta tanga ✓');j2Msg('Bitta 5 so‘mlikni kamaytiramiz: qoldiq 8 — <b>4</b> ta 2 so‘mlik. Jami <b>7</b> ta')},
 function(){j17Coins(1,9,0,'1 · 5 + 9 · 2 = 23 → 10 ta tanga');j2Msg('Yana kamaytirsak: 10 ta tanga — ko‘proq. Eng kami — <b>7</b>')}];
var STEPS=[
{h:"Qayiqlar: ko'pi bilan nechta?",sum:"50 o'quvchi 6 va 4 kishilik to'la qayiqlarda: 6 kishilik ko'pi bilan 7 ta (42 + 2 · 4).",a:"m01",
 start:function(){j17Boats(0,0);j2Msg('6 kishilik qayiqlar <b>ko‘pi bilan</b> nechta bo‘lishi mumkin?')},fin:function(){j17Boats(7,2,0,1);j2Msg('✓ 7 · 6 + 2 · 4 = 50')},
 html:"<p>«Ko'pi bilan» savolida eng kattasidan boshlab <b>sinab tushamiz</b> va har safar tekshiramiz: qolgan o'quvchilar 4 kishilik qayiqlarni to'liq to'ldiradimi? Tanlang:</p>",
 g2:1,btns:j2Pick(["8","7","6","5"],1,function(){j17Boats(7,2,0,1);j2Msg('✓ 7 · 6 = 42, qoldi 8 = 2 · 4. Hammasi to‘la!')},function(i){var a=[8,7,6,5][i],t=j17Try(a);j17Boats(a,t.b,t.left,!t.left);j2Msg(i===3?'5 ham bo‘ladi (30 + 20), lekin <b>ko‘proq</b> bo‘lishi mumkinmi?':a+' · 6 = '+(6*a)+', qoldi '+(50-6*a)+' — 4 ga bo‘linmaydi')}),
 after:"<p>8 ta: 48, qoladi 2 ✗. 7 ta: 42, qoladi 8 = 2 qayiq ✓. «5 ta» ham to'g'ri joylashuv, lekin savol <b>eng ko'pi</b> haqida. Shuning uchun yuqoridan boshlash qulay: birinchi mos kelgani — javob.</p>",
 q:{t:"38 o'quvchi 6 kishilik va 4 kishilik qayiqlarga o'tirdi, hammasi to'la. 6 kishilik qayiqlar ko'pi bilan nechta?",opts:["5","6","4","3"],ok:0,why:"5 · 6 = 30, qoldi 8 = 2 · 4.",hint:"6 tadan boshlang: 36, qoladi 2 — to'ladimi?",full:"6 ta: 36, qoladi 2 — ✗. 5 ta: 30, qoladi 8 — 2 ta 4 kishilik ✓. Demak 5. «3» ham mumkin (18 + 20), lekin eng ko'pi emas."},
 tn:"Cho'plar bilan modellashtiring: 50 ta cho'pni 6 talik va 4 talik bog'lamlarga ajrating."},
{h:"Yig'indi berilgan — ko'paytma eng katta",sum:"Yig'indisi 12 bo'lgan ikki son ko'paytmasi 6 · 6 = 36 da eng katta.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Yig'indisi 12 bo'lgan ikki sonni tanlaymiz. Ko'paytmasi qachon eng katta bo'ladi? Barcha holatlarni <b>tartib bilan</b> ko'rib chiqamiz:</p>",
 btns:[phaser(P2,'▶ Keyingi')],
 after:"<p>Qoida: yig'indi o'zgarmasa, sonlar bir-biriga qancha <b>yaqin</b> bo'lsa, ko'paytma shuncha katta. Bu to'g'ri to'rtburchakda ham ishlaydi: perimetr bir xil bo'lsa, <b>kvadratning</b> yuzi eng katta.</p>",
 q:{t:"Yig'indisi 9 bo'lgan ikki natural son ko'paytmasi eng ko'pi bilan nechaga teng?",opts:["20","18","81","14"],ok:0,why:"4 · 5 = 20; teng bo'lishi mumkin emas, eng yaqin — 4 va 5.",hint:"9 ni ikki teng songa bo'lib bo'lmaydi. Eng yaqin ikki son qaysi?",full:"1·8 = 8, 2·7 = 14, 3·6 = 18, 4·5 = 20. Eng katta — 20. «81» — 9 · 9 (yig'indi 18 bo'lib qoladi)."},
 tn:"Bolalar jadval tuzsin: birinchi son, ikkinchi son, ko'paytma. Naqshni o'zi topsin."},
{h:"Tuzoq: Ali eng kamida nechta oldi?",sum:"180 konfet 10 nabiraga har xil: Ali (eng ko'p) kamida 23 — chunki 22 + 21 + … + 13 = 175 < 180.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Buvijon 180 ta konfetni 10 nabirasiga tarqatdi, hech kim bir xil olmadi. Eng ko'pini Ali oldi. Ali <b>eng kamida</b> nechta olgan? Kuzating:</p>",
 btns:[phaser(P3,'▶ Keyingi')],
 after:"<p>Ayyorlik: Ali kam olsin desak, boshqalar ham kam bo'ladi — lekin ular Alidan kichik va <b>har xil</b>. Eng «zich» holat — ketma-ket sonlar. Uning yig'indisi 180 ga yetgan birinchi Ali qiymati — javob.</p>",
 q:{t:"50 ta konfet 5 bolaga tarqatildi, hammasi har xil son oldi. Eng ko'p olgan bola eng kamida nechta olgan?",opts:["12","10","14","11"],ok:0,why:"12 + 11 + 10 + 9 + 8 = 50.",hint:"Eng ko'p olgan a ta bo'lsin. Qolganlar ko'pi bilan a−1, a−2, a−3, a−4.",full:"a = 11: 11 + 10 + 9 + 8 + 7 = 45 < 50 ✗. a = 12: 12 + 11 + 10 + 9 + 8 = 50 ✓. «10» — 50 : 5 (lekin hamma teng bo'lib qoladi)."},
 tn:"Bu — olimpiadaning eng ko'p uchraydigan tuzog'i. Doskada ustunli diagramma chizib tushuntiring."},
{h:"Raqamlardan eng kichik son",sum:"0, 3, 5, 8 dan eng kichik to'rt xonali son — 3058 (0 boshida turolmaydi).",a:"m04",
 start:function(){j2Lines([['0   3   5   8',C.blue,30],['har birini bir marta ishlating',null,13]]);j2Msg('Eng <b>kichik</b> to‘rt xonali son qaysi?')},fin:function(){j2Lines([['3058',C.ok,40]],{mono:1});j2Msg('✓ 3058')},
 html:"<p>Eng kichik son uchun kichik raqamlar <b>chapda</b> (katta xonalarda) turishi kerak. Lekin bitta tuzoq bor! Tanlang:</p>",
 g2:1,btns:j2Pick(["3058","0358","3085","3508"],0,function(){j2Lines([['3058',C.ok,40]],{mono:1});j2Msg('✓ 0 boshda turolmaydi — shuning uchun 3 birinchi, 0 esa <b>ikkinchi</b> o‘rinda')},function(i){j2Msg(['','0358 — bu uch xonali son (358)! 0 boshida turolmaydi','3085 > 3058: oxirgi ikki raqamni almashtiring','3508 > 3058: 0 ni yuzliklarga qo‘ying'][i])}),
 after:"<p>Eng katta: raqamlar kamayish tartibida — <b>8530</b>. Eng kichik: o'sish tartibida, lekin boshiga noldan keyingi eng kichik raqam — <b>3058</b>. Farqi: 8530 − 3058 = 5472.</p>",
 q:{t:"Raqamlari har xil bo'lgan eng katta uch xonali juft son qaysi?",opts:["986","987","998","984"],ok:0,why:"9 va 8 dan keyin juft raqam kerak: 6.",hint:"Oxirgi raqam juft bo'lishi kerak va raqamlar takrorlanmasin.",full:"98? — oxiri juft va 9, 8 dan farqli: 6 → 986. 987 — toq, 998 — 9 takrorlangan, 984 < 986."},
 tn:"Raqam kartochkalari bilan: bolalar kartochkalarni surib, eng katta/kichik sonni yasasin."},
{h:"Kamida va ko'pi bilan nechta?",sum:"25 o'quvchi: 15 futbol, 13 shaxmat → ikkalasini kamida 15 + 13 − 25 = 3, ko'pi bilan 13.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Sinfda 25 o'quvchi. 15 tasi futbol, 13 tasi shaxmat o'ynaydi. Ikkalasini ham o'ynaydiganlar <b>kamida</b> va <b>ko'pi bilan</b> nechta? Har kim kamida bittasini o'ynashi shart emas.</p>",
 btns:[phaser(P5,'▶ Keyingi')],
 after:"<p>15 + 13 = 28 — bu 25 dan 3 ta ortiq. Demak, kamida 3 kishi <b>ikki marta</b> sanalgan. Ko'pi bilan — kichik guruh to'liq katta guruh ichida bo'lganda: 13.</p>",
 q:{t:"Sinfda 30 o'quvchi. 20 tasi rasm, 18 tasi musiqa to'garagiga qatnaydi. Ikkalasiga qatnaydiganlar kamida nechta?",opts:["8","2","18","12"],ok:0,why:"20 + 18 − 30 = 8.",hint:"20 + 18 nechta? Sinfda esa faqat 30 kishi.",full:"20 + 18 = 38 > 30, ortig'i 8 — ular ikki marta sanalgan. «18» — bu ko'pi bilan, «2» — 20 − 18."},
 tn:"25 ta katakli tasma chizib, ikki rangli qalam bilan bo'yating — ustma-ust tushgan kataklar ko'rinadi."},
{h:"Tuzoq: eng kam tanga",sum:"2 va 5 so'mlik tangalar bilan 23 so'm: 4 · 5 bo'lmaydi; 3 · 5 + 4 · 2 = 7 ta tanga — eng kami.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Faqat 2 so'mlik va 5 so'mlik tangalar bor. 23 so'mni <b>eng kam</b> tanga bilan to'lang. «Iloji boricha katta tanga» usuli har doim ishlaydimi?</p>",
 btns:[phaser(P6,'▶ Keyingi')],
 after:"<p>Ochko'z usul (eng katta tangadan boshlash) bu yerda <b>adashtiradi</b>: 20 dan keyin 3 so'm qoladi, uni 2 so'mliklar bilan to'lab bo'lmaydi. Har doim qoldiqni <b>tekshiring</b>.</p>",
 q:{t:"2 so'mlik va 5 so'mlik tangalar bilan 21 so'm to'lash kerak. Eng kamida nechta tanga kerak?",opts:["6","5","7","9"],ok:0,why:"3 · 5 + 3 · 2 = 21 — 6 ta tanga.",hint:"4 ta 5 so'mlik — 20, qoldi 1 ✗. 3 ta 5 so'mlik-chi?",full:"4 · 5 = 20, qoldiq 1 ✗. 3 · 5 = 15, qoldiq 6 = 3 · 2 → 6 ta tanga. 5 ta tanga bilan 21 ni yig'ib bo'lmaydi. «9» — 1 · 5 + 8 · 2."},
 tn:"O'yin pullari bilan bolalar o'zlari to'lab ko'rsin — kim kam tanga ishlatdi?"},
{h:"Bilasizmi? Asalari kataklari",sum:"Olti burchakli kataklar eng kam devor bilan eng ko'p joy beradi — 1999-yilda Tomas Xeyls isbotlagan.",a:"m07",
 start:function(){clear();var g=S.g;for(var r=0;r<3;r++)for(var c=0;c<6;c++){var cx=70+c*44+(r%2)*22,cy=44+r*38,p=[];for(var k=0;k<6;k++){var t=Math.PI/6+k*Math.PI/3;p.push((cx+25*Math.cos(t)).toFixed(1)+','+(cy+25*Math.sin(t)).toFixed(1))}E('polygon',{points:p.join(' '),fill:'#f8d77a',stroke:'#c8941c','stroke-width':2},g)}},
 fin:function(){STEPS[6].start()},
 html:"<p>🐝 Asalarilar mumdan <b>olti burchakli</b> kataklar quradi. Matematiklar uzoq vaqt taxmin qilishgan: tekislikni teng bo'laklarga bo'lishda olti burchak eng <b>kam devor</b> (mum) talab qiladi. Buni 1999-yilda amerikalik matematik <b>Tomas Xeyls</b> to'liq isbotlagan.</p>",
 btns:[["Tushundim",function(c,done){j2Msg('Tabiat ham «eng kam sarflab, eng ko‘p olish» masalasini yechadi');done()}]],
 after:"<p>«Eng ko'p / eng kam» masalalari muhandislikda, logistikada, hatto sport jadvallarida ham yechiladi.</p>",
 tn:"Bolalarga uchburchak, kvadrat va olti burchakli qog'oz kataklarni ko'rsatib, qaysi biri doiraga yaqinligini muhokama qiling."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j17Bars([11,20,27,32,35,36],{max:36,hl:5,lab:['1·11','2·10','3·9','4·8','5·7','6·6']})},fin:function(){j17Bars([11,20,27,32,35,36],{max:36,hl:5,lab:['1·11','2·10','3·9','4·8','5·7','6·6']})},
 html:"<div class='memo'><ul><li>«Ko'pi bilan» — kattasidan boshlab sinang; birinchi mos kelgani javob.</li><li>Yig'indi o'zgarmasa: sonlar <b>yaqinroq</b> — ko'paytma kattaroq.</li><li>«Eng ko'p olgan kamida nechta» — qolganlarni unga <b>yaqin, ketma-ket</b> qiling.</li><li>Eng kichik son: 0 boshda turolmaydi.</li><li>Ikki guruh: kamida <b>a + b − jami</b>, ko'pi bilan — kichigi.</li><li>Ochko'z usulni (eng kattasidan) — qoldiq bilan <b>tekshiring</b>.</li></ul></div>",
 tn:"Keyingi darsni savol bilan boshlang: «Perimetri 20 sm bo'lgan to'g'ri to'rtburchakning yuzi eng ko'pi bilan qancha?» (25 sm²)."}
];
var PROBS=[
{t:"50 o'quvchi 6 kishilik va 4 kishilik qayiqlarga o'tirdi, barcha qayiqlar to'la. 6 kishilik qayiqlar ko'pi bilan nechta?",o:["7","6","8","5"],k:0,s:"7 · 6 = 42, 8 = 2 · 4."},
{t:"38 o'quvchi 6 kishilik va 4 kishilik qayiqlarga o'tirdi, barcha qayiqlar to'la. 6 kishilik qayiqlar ko'pi bilan nechta?",o:["5","6","4","3"],k:0,s:"5 · 6 = 30, 8 = 2 · 4; 6 ta bo'lsa 2 kishi qoladi."},
{t:"Yig'indisi 12 bo'lgan ikki natural son ko'paytmasi eng ko'pi bilan nechaga teng?",o:["36","35","32","11"],k:0,s:"6 · 6 = 36."},
{t:"Yig'indisi 10 bo'lgan ikki natural son ko'paytmasi eng ko'pi bilan nechaga teng?",o:["25","24","9","21"],k:0,s:"5 · 5 = 25."},
{t:"Yig'indisi 9 bo'lgan ikki natural son ko'paytmasi eng ko'pi bilan nechaga teng?",o:["20","18","81","14"],k:0,s:"4 · 5 = 20."},
{t:"180 ta konfet 10 nabiraga tarqatildi, hech kim bir xil son olmadi. Eng ko'pini Ali oldi. Ali eng kamida nechta olgan?",o:["23","18","22","24"],k:0,s:"22 + 21 + … + 13 = 175 < 180; 23 da 185 ≥ 180."},
{t:"50 ta konfet 5 bolaga tarqatildi, hammasi har xil son oldi. Eng ko'p olgan bola eng kamida nechta olgan?",o:["12","10","14","11"],k:0,s:"12 + 11 + 10 + 9 + 8 = 50."},
{t:"20 ta olma 4 bolaga tarqatildi, har biri kamida 1 ta va hammasi har xil son oldi. Eng ko'p olgan ko'pi bilan nechta olgan?",o:["14","17","11","8"],k:0,s:"Qolganlar eng kami 1, 2, 3 → 20 − 6 = 14."},
{t:"0, 3, 5, 8 raqamlaridan bir martadan foydalanib yozilgan eng kichik to'rt xonali son qaysi?",o:["3058","3085","3508","5038"],k:0,s:"0 boshda turolmaydi: 3, keyin 0, 5, 8."},
{t:"Raqamlari har xil bo'lgan eng katta uch xonali juft son qaysi?",o:["986","987","998","984"],k:0,s:"9, 8 va juft raqam 6."},
{t:"Raqamlari yig'indisi 15 bo'lgan eng kichik ikki xonali son qaysi?",o:["69","78","96","87"],k:0,s:"Birliklar eng katta (9) → o'nliklar 6."},
{t:"Raqamlari har xil va yig'indisi 15 bo'lgan eng katta uch xonali son qaysi?",o:["960","951","933","870"],k:0,s:"9, keyin eng katta mumkin raqam 6, oxiri 0."},
{t:"Uch xonali sonning raqamlari ko'paytmasi 12 ga teng. Bunday sonlarning eng kichigi qaysi?",o:["126","134","223","143"],k:0,s:"Yuzliklar 1, keyin 2 va 6: 126 < 134."},
{t:"25 o'quvchidan 15 tasi futbol, 13 tasi shaxmat o'ynaydi. Ikkalasini ham o'ynaydiganlar kamida nechta?",o:["3","13","2","28"],k:0,s:"15 + 13 − 25 = 3."},
{t:"25 o'quvchidan 15 tasi futbol, 13 tasi shaxmat o'ynaydi. Ikkalasini ham o'ynaydiganlar ko'pi bilan nechta?",o:["13","15","3","28"],k:0,s:"Hamma shaxmatchi futbol ham o'ynasa — 13."},
{t:"30 o'quvchidan 20 tasi rasm, 18 tasi musiqa to'garagiga qatnaydi. Ikkalasiga qatnaydiganlar kamida nechta?",o:["8","2","18","12"],k:0,s:"20 + 18 − 30 = 8."},
{t:"Faqat 2 so'mlik va 5 so'mlik tangalar bilan 23 so'm to'lash kerak. Eng kamida nechta tanga kerak?",o:["7","5","6","10"],k:0,s:"3 · 5 + 4 · 2 = 23; 4 · 5 da 3 so'm qoladi."},
{t:"Faqat 2 so'mlik va 5 so'mlik tangalar bilan 21 so'm to'lash kerak. Eng kamida nechta tanga kerak?",o:["6","5","7","9"],k:0,s:"3 · 5 + 3 · 2 = 21."},
{t:"Perimetri 20 sm bo'lgan to'g'ri to'rtburchaklar (tomonlari butun sm) orasida yuzi eng kattasining yuzi qancha?",o:["25 sm²","24 sm²","20 sm²","100 sm²"],k:0,s:"Tomonlar yig'indisi 10: 5 · 5 = 25."},
{t:"Perimetri 20 sm bo'lgan to'g'ri to'rtburchaklar (tomonlari butun sm) orasida yuzi eng kichigining yuzi qancha?",o:["9 sm²","10 sm²","16 sm²","1 sm²"],k:0,s:"Tomonlar 1 va 9: 1 · 9 = 9."}
];
function PRACT_STAGE(){j17Bars([11,20,27,32,35,36],{max:36,hl:5,lab:['1·11','2·10','3·9','4·8','5·7','6·6']})}
var PREP_DATA={teach:["«Ko'pi bilan»/«kamida» savollarini sinab-tekshirish bilan yechish.","Yig'indi o'zgarmas — ko'paytma eng katta: teng sonlar.","«Har xil son» tarqatish masalalari.","Raqamlardan eng katta/kichik son.","Ikki guruh kesishmasi: kamida va ko'pi bilan.","Ochko'z usulning tuzog'i."],
 mist:["Birinchi topilgan mos javobni olib, eng kattasini izlamaydi.","Konfet masalasida 180 : 10 = 18 deb javob beradi.","0 ni boshiga qo'yadi.","Kesishmada a − b deb hisoblaydi.","Eng katta tangadan boshlab, qoldiqni tekshirmaydi."],
 need:["Cho'plar yoki tugmalar.","Raqam kartochkalari.","O'yin pullari (2 va 5)."],
 board:["<span class='w2'>50 = 7 · 6 + 2 · 4</span>.","<span class='w2'>12 = 6 + 6 → 36</span>.","<span class='w2'>22+…+13 = 175 < 180 → Ali ≥ 23</span>.","<span class='w2'>0358 ✗ → 3058</span>.","<span class='w2'>15 + 13 − 25 = 3</span>.","<span class='w2'>23 = 3·5 + 4·2 → 7 tanga</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
