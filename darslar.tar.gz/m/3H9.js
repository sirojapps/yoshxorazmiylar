var CODE='3H9',TITLE='3-sinf · Parallel va perpendikular to‘g‘ri chiziqlar';
function h9msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ikki to'g'ri chiziq: a — gorizontal (y=60), b — markazi (cx,cy), burchagi ang (gradus, soat strelkasiga teskari)
function h9lines(ang,o){o=o||{};clear();var g=S.g,cy=o.cy||118,cx=180;
 E('line',{x1:14,y1:58,x2:346,y2:58,stroke:C.blue,'stroke-width':4,'stroke-linecap':'round'},g);T(g,26,48,'a',{'font-size':14,'font-weight':800,fill:C.blue});
 var r=ang*Math.PI/180,L=200,dx=Math.cos(r)*L,dy=-Math.sin(r)*L;
 E('line',{x1:cx-dx,y1:cy-dy,x2:cx+dx,y2:cy+dy,stroke:C.a2,'stroke-width':4,'stroke-linecap':'round'},g);
 var m=((ang%180)+180)%180;
 if(m!==0){var t=(58-cy)/(-Math.sin(r)),ix=cx+Math.cos(r)*t;if(ix>-200&&ix<560){E('circle',{cx:ix,cy:58,r:6,fill:C.bad},g)}
  if(m===90){E('path',{d:'M'+(cx+14)+' 58 L'+(cx+14)+' 72 L'+cx+' 72',fill:'none',stroke:C.ok,'stroke-width':2.5},g)}}
 var bx=Math.max(20,Math.min(340,cx+dx*.4+12)),by=Math.max(16,Math.min(166,cy+dy*.4-12));if(Math.abs(by-58)<16)by=by<58?40:80;T(g,bx,by,'b',{'font-size':14,'font-weight':800,fill:C.a2});
 var lab=m===0?'a ∥ b — parallel: hech qachon kesishmaydi':(m===90?'a ⊥ b — perpendikular: to‘g‘ri burchak ostida kesishadi':'a va b kesishadi (burchak '+m+'°)');
 h9msg(lab);S.ang=ang;S.m=m}
// katakli qog'oz va kesmalar
function h9grid(segs,hl){clear();var g=S.g,s=20,x0=20,y0=12;for(var i=0;i<=16;i++)E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0+7*s,stroke:'#e3e8ee','stroke-width':1},g);for(var j=0;j<=7;j++)E('line',{x1:x0,y1:y0+j*s,x2:x0+16*s,y2:y0+j*s,stroke:'#e3e8ee','stroke-width':1},g);
 segs.forEach(function(q,i){var on=hl&&hl.indexOf(q[4])>=0;E('line',{x1:x0+q[0]*s,y1:y0+q[1]*s,x2:x0+q[2]*s,y2:y0+q[3]*s,stroke:on?C.bad:'#33475b','stroke-width':on?4:3,'stroke-linecap':'round'},g);T(g,x0+(q[0]+q[2])/2*s+(q[5]!=null?q[5]:8),y0+(q[1]+q[3])/2*s+(q[6]!=null?q[6]:-6),q[4],{'font-size':13,'font-weight':800,fill:on?C.bad:'#33475b'})})}
var GS=[[1,1,6,1,'a'],[1,4,6,4,'b'],[8,1,8,6,'c'],[10,6,14,2,'d',-14,-6],[11,1,15,1,'e'],[13,4,15,6,'f']];
var P6=[function(){clear();var g=S.g;E('line',{x1:20,y1:120,x2:340,y2:120,stroke:C.blue,'stroke-width':4},g);E('circle',{cx:200,cy:60,r:5,fill:C.bad},g);T(g,212,56,'A',{'font-size':13,'font-weight':800,fill:C.bad});h9msg('A nuqtadan a ga perpendikular chizamiz')},
 function(){clear();var g=S.g;E('line',{x1:20,y1:120,x2:340,y2:120,stroke:C.blue,'stroke-width':4},g);E('circle',{cx:200,cy:60,r:5,fill:C.bad},g);E('polygon',{points:'200,120 200,40 120,120',fill:'rgba(240,160,64,.35)',stroke:C.a2,'stroke-width':2},g);E('path',{d:'M200 106 L186 106 L186 120',fill:'none',stroke:C.ok,'stroke-width':2},g);h9msg('Burchakli chizg‘ichning to‘g‘ri burchagini chiziqqa qo‘yamiz, bir tomoni A dan o‘tsin')},
 function(){clear();var g=S.g;E('line',{x1:20,y1:120,x2:340,y2:120,stroke:C.blue,'stroke-width':4},g);E('line',{x1:200,y1:20,x2:200,y2:160,stroke:C.a2,'stroke-width':4},g);E('circle',{cx:200,cy:60,r:5,fill:C.bad},g);E('path',{d:'M214 120 L214 106 L200 106',fill:'none',stroke:C.ok,'stroke-width':2.5},g);h9msg('Chizg‘ich tomoni bo‘ylab chizamiz: <b>b ⊥ a</b> ✓')}];
var P7=[function(){clear();var g=S.g;E('line',{x1:40,y1:50,x2:150,y2:62,stroke:C.blue,'stroke-width':4},g);E('line',{x1:40,y1:110,x2:150,y2:92,stroke:C.a2,'stroke-width':4},g);h9msg('Ikki kesma tegmayapti. Ular parallelmi?')},
 function(){clear();var g=S.g;E('line',{x1:10,y1:47,x2:350,y2:84,stroke:C.blue,'stroke-width':3,'stroke-dasharray':'6 4'},g);E('line',{x1:10,y1:115,x2:350,y2:60,stroke:C.a2,'stroke-width':3,'stroke-dasharray':'6 4'},g);E('line',{x1:40,y1:50,x2:150,y2:62,stroke:C.blue,'stroke-width':4},g);E('line',{x1:40,y1:110,x2:150,y2:92,stroke:C.a2,'stroke-width':4},g);h9msg('Davom ettiramiz…')},
 function(){clear();var g=S.g;E('line',{x1:10,y1:47,x2:350,y2:84,stroke:C.blue,'stroke-width':3,'stroke-dasharray':'6 4'},g);E('line',{x1:10,y1:115,x2:350,y2:60,stroke:C.a2,'stroke-width':3,'stroke-dasharray':'6 4'},g);E('circle',{cx:281,cy:76,r:7,fill:C.bad},g);h9msg('Kesishdi! Kesmalar tegmasa ham, <b>to‘g‘ri chiziqlar</b> parallel bo‘lmasligi mumkin')}];
var P8=[function(){clear();var g=S.g;E('rect',{x:90,y:30,width:180,height:100,fill:'#fbe0b4',stroke:'#33475b','stroke-width':3},g);h9msg('To‘g‘ri to‘rtburchak: tomonlarini juftlaymiz')},
 function(){clear();var g=S.g;E('rect',{x:90,y:30,width:180,height:100,fill:'#fbe0b4',stroke:'#33475b','stroke-width':3},g);E('line',{x1:90,y1:30,x2:270,y2:30,stroke:C.blue,'stroke-width':6},g);E('line',{x1:90,y1:130,x2:270,y2:130,stroke:C.blue,'stroke-width':6},g);E('line',{x1:90,y1:30,x2:90,y2:130,stroke:C.a2,'stroke-width':6},g);E('line',{x1:270,y1:30,x2:270,y2:130,stroke:C.a2,'stroke-width':6},g);h9msg('Parallel juftlar: ko‘k ∥ ko‘k, to‘q sariq ∥ to‘q sariq — <b>2 juft</b>')},
 function(){clear();var g=S.g;E('rect',{x:90,y:30,width:180,height:100,fill:'#fbe0b4',stroke:'#33475b','stroke-width':3},g);[[90,30,1,1],[270,30,-1,1],[270,130,-1,-1],[90,130,1,-1]].forEach(function(p){E('path',{d:'M'+(p[0]+14*p[2])+' '+p[1]+' L'+(p[0]+14*p[2])+' '+(p[1]+14*p[3])+' L'+p[0]+' '+(p[1]+14*p[3]),fill:'none',stroke:C.ok,'stroke-width':2.5},g)});h9msg('Perpendikular juftlar: har burchakda bittadan — <b>4 juft</b>')}];
var STEPS=[
{h:"Parallel chiziqlar",sum:"Bir tekislikda yotib, hech qachon kesishmaydigan to'g'ri chiziqlar parallel: a ∥ b.",a:"m01",
 start:function(){h9lines(30)},fin:function(){h9lines(0)},
 html:"<p>Ko'k chiziq <b>a</b> va to'q sariq chiziq <b>b</b> kesishyapti (qizil nuqta). <b>b</b> ni burab, shunday holatga keltiringki, ular <b>hech qachon kesishmasin</b>.</p>",
 btns:[["↻ b ni 15° burish",function(c,done){h9lines(S.ang-15);if(S.m===0)done()}]],
 after:"<p>Endi <b>a</b> va <b>b</b> yonma-yon ketadi va qancha davom ettirsak ham uchrashmaydi. Bunday chiziqlar <b>parallel</b> deyiladi va <b>a ∥ b</b> deb yoziladi. Ular orasidagi masofa hamma joyda bir xil.</p>",
 q:{t:"Qaysi narsada parallel chiziqlar bor?",opts:["Temir yo'l relslari","Qaychining ochilgan tig'lari","Chorraha","Soat millari 3:00 da"],ok:0,why:"Relslar hamma joyda bir xil masofada, uchrashmaydi.",hint:"Qaysi chiziqlar hech qachon uchrashmaydi?",full:"Temir yo'l relslari hech qachon kesishmaydi — aks holda poyezd yura olmaydi. Qaychi tig'lari, chorraha va 3:00 dagi millar kesishadi."},
 tn:"Daftar chiziqlari, doskaning qarama-qarshi chetlari, eshik romi — sinfdan parallel chiziqlarni bolalar o'zi topsin."},
{h:"Perpendikular chiziqlar",sum:"To'g'ri burchak (90°) ostida kesishadigan chiziqlar perpendikular: a ⊥ b.",a:"m02",
 start:function(){h9lines(45)},fin:function(){h9lines(90)},
 html:"<p>Endi <b>b</b> ni shunday burangki, u <b>a</b> bilan <b>to'g'ri burchak</b> hosil qilsin (xuddi daftar varag'ining burchagidek).</p>",
 btns:[["↺ b ni 15° burish",function(c,done){h9lines(S.ang+15);if(S.m===90)done()}]],
 after:"<p>To'g'ri burchak ostida kesishgan chiziqlar <b>perpendikular</b> deyiladi: <b>a ⊥ b</b>. Kesishgan joyda 4 ta to'g'ri burchak hosil bo'ladi. Yashil belgi — to'g'ri burchak belgisi.</p>",
 q:{t:"Qaysi holatda chiziqlar perpendikular?",opts:["Soat 3:00 da millar","Soat 6:00 da millar","Soat 12:00 da millar","Soat 1:00 da millar"],ok:0,why:"3:00 da millar to'g'ri burchak hosil qiladi.",hint:"Qaysi vaqtda soat millari orasidagi burchak to'g'ri burchak bo'ladi?",full:"3:00 da minut mili 12 da, soat mili 3 da — to'g'ri burchak, perpendikular. 6:00 da millar bir to'g'ri chiziqda, 12:00 da ustma-ust, 1:00 da burchak o'tkir."},
 tn:"Qog'ozni ikki marta buklab (avval yarmiga, keyin yana yarmiga) to'g'ri burchak andozasini yasating — har bola o'z «burchak o'lchagichi»ga ega bo'ladi."},
{h:"Belgilar va kesishish",sum:"∥ — parallel, ⊥ — perpendikular. Parallel bo'lmagan ikki to'g'ri chiziq albatta kesishadi.",a:"m03",
 start:function(){h9lines(60)},fin:function(){h9lines(0)},
 html:"<p>Uch xil holatni ko'ring — tugmalarni bosing:</p>",
 btns:[["∥ parallel",function(c,done){h9lines(0);mvK(done,3)}],["⊥ perpendikular",function(c,done){h9lines(90);mvK(done,3)}],["✕ kesishadi",function(c,done){h9lines(135);mvK(done,3)}]],g3:1,
 after:"<p>Tekislikdagi ikki to'g'ri chiziq yo <b>parallel</b> (kesishmaydi), yo <b>kesishadi</b>. Kesishganlarning maxsus holati — <b>perpendikular</b> (90°). Yozuvda: <b>a ∥ b</b>, <b>a ⊥ b</b>.</p>",
 q:{t:"«c ⊥ d» yozuvi nimani bildiradi?",opts:["c va d parallel","c va d kesishmaydi","c va d to'g'ri burchak ostida kesishadi","c va d teng"],ok:2,why:"⊥ — perpendikular belgisi.",hint:"⊥ belgisining o'zi qanday ko'rinadi? Uning chiziqlari qanday turibdi?",full:"⊥ belgisi — perpendikular: chiziqlar to'g'ri burchak ostida kesishadi. Parallel belgisi — ∥ (ikki tik chiziqcha)."},
 tn:"Belgilarning ko'rinishi o'zi ma'nosini aytadi: ∥ — ikki yonma-yon chiziq, ⊥ — tik va yotiq chiziq."},
{h:"Katakli qog'ozda topamiz",sum:"Katak chiziqlari bo'ylab ketgan yotiq kesmalar o'zaro parallel, yotiq va tik — perpendikular.",a:"m04",
 start:function(){h9grid(GS);h9msg('a va qaysi kesma parallel? Tugmani tanlang')},fin:function(){h9grid(GS,['a','b']);h9msg('a ∥ b ∥ e, a ⊥ c')},
 html:"<p>Katakli qog'ozda 6 ta kesma chizilgan. <b>a</b> ga parallel kesmani toping:</p>",
 btns:[["a va b",function(c,done){h9grid(GS,['a','b']);h9msg('✓ To‘g‘ri! a va b ikkalasi ham yotiq — <b>a ∥ b</b>. (e ham a ga parallel)');done()}],["a va c",function(){h9grid(GS,['a','c']);h9msg('a yotiq, c tik — ular <b>perpendikular</b>, parallel emas')}],["a va d",function(){h9grid(GS,['a','d']);h9msg('d qiya — davom ettirsak, a bilan kesishadi')}],["a va f",function(){h9grid(GS,['a','f']);h9msg('f qiya — davom ettirsak, a bilan kesishadi')}]],g2:1,
 after:"<p>Katak chiziqlari bo'ylab ketgan <b>yotiq</b> kesmalar o'zaro parallel (a, b, e), <b>tik</b> kesmalar ham o'zaro parallel. Yotiq va tik — <b>perpendikular</b> (a ⊥ c).</p>",
 q:{t:"Katakli qog'ozda bitta kesma yotiq, ikkinchisi tik. Ular qanday?",opts:["Parallel","Perpendikular","Hech qanday","Teng"],ok:1,why:"Katak chiziqlari to'g'ri burchak ostida kesishadi.",hint:"Katakning burchagi qanday burchak?",full:"Katakli qog'ozdagi yotiq va tik chiziqlar to'g'ri burchak hosil qiladi — perpendikular. Ikkala yotiq (yoki ikkala tik) — parallel."},
 tn:"Katakli daftarda parallel va perpendikular kesmalarni chizdiring — bu ularning eng oson usuli."},
{h:"Perpendikularni qanday chizamiz",sum:"Burchakli chizg'ichning to'g'ri burchagini chiziqqa qo'yib, uning tomoni bo'ylab chizamiz.",a:"m05",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Oq qog'ozda katak yo'q. Unda perpendikularni qanday chizamiz? Burchakli chizg'ich yordam beradi.</p>",
 btns:[phaser(P6)],
 after:"<p>Burchakli chizg'ichda <b>to'g'ri burchak</b> bor. Uning bir tomonini chiziqqa qo'ysak, ikkinchi tomoni bo'ylab chizilgan chiziq <b>perpendikular</b> bo'ladi. Parallel chizish uchun esa ikki marta perpendikular chizamiz: a ⊥ b va c ⊥ b bo'lsa, <b>a ∥ c</b>.</p>",
 q:{t:"a ⊥ b va c ⊥ b. a va c qanday joylashgan?",opts:["a ⊥ c","a va c kesishadi","a ∥ c","Ular ustma-ust"],ok:2,why:"Bitta chiziqqa perpendikular ikki chiziq o'zaro parallel.",hint:"Daftardagi ikki tik chiziq bitta yotiq chiziqqa perpendikular. Ular o'zaro qanday?",full:"Agar ikkala chiziq ham b ga to'g'ri burchak ostida tushsa, ular bir xil yo'nalishda — parallel: a ∥ c. Masalan, narvonning ikki ustuni yerga perpendikular va o'zaro parallel."},
 tn:"Burchakli chizg'ich bo'lmasa, buklangan qog'oz burchagidan foydalaning."},
{h:"Tuzoq: kesmalar tegmasa ham…",sum:"Kesmalar tegmasa ham, to'g'ri chiziqlar kesishishi mumkin. Davom ettirib tekshiring.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ikki kesma bir-biriga tegmayapti. Demak ular parallelmi? Shoshilmang — davom ettirib ko'ramiz.</p>",
 btns:[phaser(P7)],
 after:"<p><b>To'g'ri chiziq</b> cheksiz davom etadi, kesma esa — uning bir bo'lagi. Kesmalar tegmasa ham, ularni davom ettirsak kesishishi mumkin. Parallel bo'lishi uchun ular hamma joyda bir xil masofada bo'lishi kerak.</p>",
 q:{t:"Ikki kesma bir-biriga tegmaydi. Ular albatta parallelmi?",opts:["Ha, albatta","Yo'q, davom ettirilsa kesishishi mumkin","Ha, agar uzun bo'lsa","Ha, agar qisqa bo'lsa"],ok:1,why:"Kesma chiziqning bo'lagi xolos; davom ettirib tekshirish kerak.",hint:"Kesmalarni davom ettirsak nima bo'lishi mumkin?",full:"Tegmaslik — parallellik belgisi emas. Kesmalarni davom ettirib, ular orasidagi masofa o'zgaradimi, tekshiring. Masofa kamayib borsa — qaysidir joyda kesishadi."},
 tn:"Doskada qiya kesmalarni chizing va bolalardan «parallelmi?» deb so'rang; keyin chizg'ich bilan davom ettiring."},
{h:"Shakllardagi parallel va perpendikular tomonlar",sum:"To'g'ri to'rtburchakda 2 juft parallel tomon va 4 juft perpendikular tomon bor.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>To'g'ri to'rtburchakning tomonlarini tekshiramiz: qaysilari parallel, qaysilari perpendikular?</p>",
 btns:[phaser(P8)],
 after:"<p>To'g'ri to'rtburchak (va kvadrat)da: qarama-qarshi tomonlar <b>parallel</b> (2 juft), qo'shni tomonlar <b>perpendikular</b> (4 juft — har burchakda bittadan).</p>",
 q:{t:"Kvadratda nechta juft perpendikular tomon bor?",opts:["2","4","1","8"],ok:1,why:"Har bir burchakda ikki qo'shni tomon perpendikular: 4 ta burchak — 4 juft.",hint:"Perpendikular tomonlar qayerda uchrashadi? Kvadratda nechta to'g'ri burchak bor?",full:"Kvadratning 4 ta to'g'ri burchagi bor, har birida ikki tomon perpendikular — 4 juft. Parallel juftlar esa 2 ta (qarama-qarshi tomonlar)."},
 tn:"Bolalar daftardagi to'g'ri to'rtburchakning parallel tomonlarini bir rangda, perpendikularlarini boshqa rangda belgilasin."},
{h:"Bilasizmi? Evklid va «parallel» so'zi",sum:"«Parallel» yunoncha «yonma-yon» degani. Evklid 2300 yil oldin parallel chiziqlar haqida yozgan.",a:"m08",
 start:function(){h9lines(0)},fin:function(){h9lines(0)},
 html:"<p>📜 «Parallel» so'zi yunoncha <b>«parallelos»</b> — «bir-birining yonida» degan ma'noni bildiradi.</p><p>📐 Taxminan 2300 yil oldin yunon olimi <b>Evklid</b> «Negizlar» kitobida parallel chiziqlar haqida mashhur qoidasini yozgan. Bu kitob dunyodagi eng ko'p o'rganilgan matematika kitoblaridan biri bo'lgan.</p><p>🏙 Toshkent va Samarqand ko'chalari xaritada ko'pincha parallel va perpendikular joylashgan — bunday shahar rejasi «to'r» reja deyiladi.</p>",
 tn:"Shahar yoki qishloq xaritasini ko'rsatib, parallel va perpendikular ko'chalarni topishni topshiriq qiling."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){h9lines(90)},fin:function(){h9lines(90)},
 html:"<div class='memo'><ul><li><b>Parallel</b> (a ∥ b) — hech qachon kesishmaydi, masofa hamma joyda bir xil.</li><li><b>Perpendikular</b> (a ⊥ b) — to'g'ri burchak (90°) ostida kesishadi.</li><li>Ikki to'g'ri chiziq yo parallel, yo kesishadi.</li><li>Katakli qog'ozda: yotiq ∥ yotiq, yotiq ⊥ tik.</li><li>Burchakli chizg'ich bilan perpendikular chiziladi.</li><li>a ⊥ b va c ⊥ b bo'lsa — <b>a ∥ c</b>.</li><li>Kesmalar tegmasa ham, davom ettirilsa kesishishi mumkin.</li><li>To'g'ri to'rtburchak: 2 juft parallel, 4 juft perpendikular tomon.</li></ul></div>",
 tn:"Keyingi darsni «Sinfda nechta parallel chiziq topa olasiz?» o'yini bilan boshlang (1 daqiqa)."}
];
var PROBS=[
{t:"Qaysi belgi «parallel» degani?",o:["∥","⊥","=","<"],k:0,s:"∥ — parallel, ⊥ — perpendikular."},
{t:"Qaysi belgi «perpendikular» degani?",o:["⊥","∥","≠",">"],k:0,s:"⊥ — to'g'ri burchak ostida kesishadi."},
{t:"Perpendikular chiziqlar qanday burchak ostida kesishadi?",o:["To'g'ri burchak","O'tkir burchak","O'tmas burchak","Kesishmaydi"],k:0,s:"Perpendikular — 90°, to'g'ri burchak."},
{t:"Parallel chiziqlar necha marta kesishadi?",o:["Hech qachon","1 marta","2 marta","Cheksiz ko'p"],k:0,s:"Parallel chiziqlar kesishmaydi."},
{t:"Kvadratda nechta juft parallel tomon bor?",o:["2","4","1","0"],k:0,s:"Qarama-qarshi tomonlar: 2 juft."},
{t:"To'g'ri to'rtburchakda nechta juft perpendikular tomon bor?",o:["4","2","1","8"],k:0,s:"Har burchakda bitta juft: 4 ta."},
{t:"Soat necha bo'lganda millar perpendikular bo'ladi?",o:["9:00","6:00","12:00","2:00"],k:0,s:"9:00 da millar to'g'ri burchak hosil qiladi (3:00 da ham)."},
{t:"Soat 6:00 da millar qanday joylashgan?",o:["Bir to'g'ri chiziqda","Perpendikular","Parallel","Ustma-ust"],k:0,s:"6:00 da millar qarama-qarshi tomonga qaraydi — bir to'g'ri chiziqda."},
{t:"a ⊥ b va c ⊥ b. Qaysi gap to'g'ri?",o:["a ∥ c","a ⊥ c","a va c kesishadi","a = b"],k:0,s:"Bitta chiziqqa perpendikular ikki chiziq parallel."},
{t:"a ∥ b va b ∥ c. Qaysi gap to'g'ri?",o:["a ∥ c","a ⊥ c","a va c kesishadi","a ⊥ b"],k:0,s:"Parallellik zanjir bo'ylab o'tadi: a ∥ c."},
{t:"a ∥ b va c ⊥ a. c va b qanday?",o:["c ⊥ b","c ∥ b","Kesishmaydi","Ustma-ust"],k:0,s:"c a ga perpendikular, b esa a ga parallel — c b ga ham perpendikular."},
{t:"Qaysi harfda perpendikular kesmalar bor?",o:["T","V","O","S"],k:0,s:"T harfida tik va yotiq kesma to'g'ri burchak hosil qiladi."},
{t:"Qaysi harfda parallel kesmalar bor?",o:["H","V","X","A"],k:0,s:"H harfining ikki tik kesmasi parallel."},
{t:"Ikki to'g'ri chiziq kesishib 4 ta teng burchak hosil qildi. Ular qanday?",o:["Perpendikular","Parallel","Hech qanday","Faqat ikkitasi teng"],k:0,s:"4 ta teng burchak — har biri to'g'ri burchak, demak perpendikular."},
{t:"Uchburchakda nechta juft parallel tomon bo'lishi mumkin?",o:["0","1","2","3"],k:0,s:"Uchburchakning har ikki tomoni uchida kesishadi — parallel juft yo'q."},
{t:"Narvonning pog'onalari o'zaro qanday?",o:["Parallel","Perpendikular","Kesishadi","Ustma-ust"],k:0,s:"Pog'onalar bir-biriga parallel."},
{t:"Katakli qog'ozda yotiq kesma va qiya kesma. Ular qanday?",o:["Davom ettirilsa kesishadi","Parallel","Perpendikular","Hech qachon kesishmaydi"],k:0,s:"Qiya chiziq yotiq chiziq bilan albatta kesishadi (davom ettirilsa)."},
{t:"Daftar varag‘ining chap cheti va pastki cheti qanday joylashgan?",o:["Perpendikular","Parallel","Kesishmaydi","Ustma-ust"],k:0,s:"Qo‘shni chetlar varaq burchagida to‘g‘ri burchak hosil qiladi."},
{t:"To'g'ri burchak necha gradus?",o:["90°","180°","45°","60°"],k:0,s:"To'g'ri burchak — 90 gradus."},
{t:"Qog'ozni yarmiga buklab, keyin yana yarmiga buklasak, burchakda qanday burchak hosil bo'ladi?",o:["To'g'ri burchak","O'tkir burchak","O'tmas burchak","Yoyiq burchak"],k:0,s:"Bukilgan chiziq o'z-o'ziga tushganda to'g'ri burchak hosil bo'ladi."}
];
function PRACT_STAGE(){h9lines(90)}
var PREP_DATA={teach:["Parallel (∥) va perpendikular (⊥) to'g'ri chiziqlar.","Katakli qog'ozda va burchakli chizg'ich bilan chizish.","a ⊥ b, c ⊥ b → a ∥ c; shakllardagi parallel va perpendikular tomonlar.","Tuzoq: kesmalar tegmasa ham kesishishi mumkin."],
 mist:["Tegmaydigan kesmalarni parallel deb o'ylaydi.","∥ va ⊥ belgilarini aralashtiradi.","Faqat yotiq-tik holatni perpendikular deb biladi (qiya holatda tanimaydi).","To'g'ri to'rtburchakning diagonallarini tomonlarga perpendikular deb hisoblaydi."],
 need:["Burchakli chizg'ich, oddiy chizg'ich.","Katakli daftar, A4 qog'oz (buklash uchun).","Shahar xaritasi (ixtiyoriy)."],
 board:["Ikki chiziq: <span class='w2'>a ∥ b</span>, <span class='w2'>a ⊥ b</span>.","Hayot: relslar, soat 3:00.","Katakda: yotiq ∥ yotiq, yotiq ⊥ tik.","Chizg'ich bilan perpendikular chizish.","<span class='w2'>a ⊥ b, c ⊥ b → a ∥ c</span>.","Qiya kesmalarni davom ettirish.","To'g'ri to'rtburchak: 2 juft ∥, 4 juft ⊥."]};
