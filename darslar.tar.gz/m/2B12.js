var CODE='2B12',TITLE='2-sinf · Yig‘indidan sonni va sondan yig‘indini ayirish';
var P1=[function(){bqBar(37,[{v:'30',w:30},{v:'7',w:7,col:C.b}],{title:'(30 + 7) − 5'});bqMsg('Yig‘indi: 30 va 7. Undan 5 ni ayiramiz. Qaysi qismdan olamiz?')},
 function(){bqBar(32,[{v:'30',w:30},{v:'7 − 5',w:7,col:C.b,q:1}],{title:'30 + (7 − 5)'});bqMsg('5 ni kichik qism 7 dan olish qulay: 7 − 5 = 2')},
 function(){bqBar(32,[{v:'30',w:30},{v:'2',w:2,col:C.ok}],{title:'30 + 2 = 32'});bqMsg('(30 + 7) − 5 = 30 + (7 − 5) = <b>32</b>')}];
var P2=[function(){bqBar(56,[{v:'40',w:40},{v:'16',w:16,col:C.b}],{title:'(40 + 16) − 9'});bqMsg('9 ni qaysi qismdan olish qulay?')},
 function(){bqBar(47,[{v:'40 − 9',w:31,q:1},{v:'16',w:16,col:C.b}],{title:'(40 − 9) + 16'});bqMsg('16 dan ham olish mumkin, lekin 40 dan olish osonroq: 40 − 9 = 31')},
 function(){bqBar(47,[{v:'31',w:31,col:C.ok},{v:'16',w:16,col:C.b}],{title:'31 + 16 = 47'});bqMsg('31 + 16 = <b>47</b>. Tekshiramiz: 56 − 9 = 47 ✓')}];
var P3=[function(){bqBar(50,[{v:'20',w:20,q:1},{v:'8',w:8,q:1},{v:'?',w:22,col:C.ok}],{title:'50 − (20 + 8)'});bqMsg('50 dan 20 va 8 ning yig‘indisini olamiz')},
 function(){bqBar(50,[{v:'20',w:20,col:'#e9e2d6'},{v:'8',w:8,q:1},{v:'30',w:22,col:C.ok}],{title:'50 − 20 − 8'});bqMsg('Avval 20 ni olamiz: 50 − 20 = 30')},
 function(){bqBar(50,[{v:'20',w:20,col:'#e9e2d6'},{v:'8',w:8,col:'#e9e2d6'},{v:'22',w:22,col:C.ok}],{title:'50 − 20 − 8 = 22'});bqMsg('Keyin 8 ni: 30 − 8 = <b>22</b>. Ya‘ni 50 − (20 + 8) = 50 − 20 − 8')}];
var P5=[function(){bqExpr(['50 − (20 + 8)  ?  50 − 20 + 8']);bqMsg('Ko‘pchilik qavsni shunday ochadi. To‘g‘rimi?')},
 function(){bqExpr(['50 − (20 + 8) = 22','50 − 20 + 8 = [38]']);bqMsg('Natijalar har xil! Ikkinchisida 8 ni <b>qo‘shib</b> yubordik')},
 function(){bqExpr(['50 − (20 + 8) = 50 − 20 [−] 8','= 22']);bqMsg('To‘g‘ri: yig‘indini ayirganda <b>ikkala</b> qo‘shiluvchini ham ayiramiz')}];
var P6=[function(){bqExpr(['63 − 18 − 2']);bqMsg('Ketma-ket ayirish. Qulayroq yo‘l bormi?')},
 function(){bqExpr(['63 − (18 + 2)','63 − 20']);bqMsg('Teskari qoida: ketma-ket ayirishni yig‘indini ayirish bilan almashtiramiz: 18 + 2 = 20')},
 function(){bqExpr(['63 − 20','[43]']);bqMsg('63 − 20 = <b>43</b>')}];
var P7=[function(){bqBar(90,[{v:'30',w:30,lab:'kitob',col:'#e9e2d6'},{v:'15',w:15,lab:'daftar',col:'#e9e2d6'},{v:'?',w:45,q:1,lab:'qoldi'}],{title:'90 ming so‘m'});bqMsg('Alida 90 ming so‘m bor. 30 ming kitobga, 15 ming daftarga sarfladi')},
 function(){bqExpr(['90 − (30 + 15)','90 − 45']);bqMsg('1-usul: avval sarfni qo‘shamiz: 30 + 15 = 45')},
 function(){bqExpr(['90 − 30 − 15','60 − 15 = [45]']);bqMsg('2-usul: ketma-ket ayiramiz. Ikkala usulda ham <b>45 ming so‘m</b> qoldi')}];
var STEPS=[
{h:"Yig'indidan sonni ayirish",sum:"(30 + 7) − 5 = 30 + (7 − 5) = 32: sonni qulay qo'shiluvchidan ayiramiz.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ifoda: <b>(30 + 7) − 5</b>. Qavsdagi yig'indini hisoblamasdan ham ayirish mumkin — qaysi qismdan olishni tanlaymiz.</p>",
 btns:[phaser(P1)],
 after:"<p><b>Qoida:</b> yig'indidan sonni ayirish uchun uni <b>qo'shiluvchilardan biridan</b> ayirib, natijaga ikkinchisini qo'shish mumkin. Qaysi qo'shiluvchidan ayirish qulay bo'lsa — shundan.</p>",
 q:{t:"(60 + 8) − 3 ni qulay usulda hisoblang.",opts:["65","57","71","63"],ok:0,why:"60 + (8 − 3) = 60 + 5 = 65.",hint:"3 ni 8 dan ayirish qulaymi yoki 60 dan?",full:"60 + (8 − 3) = 65. Yoki 68 − 3 = 65. «71» — ayirish o'rniga qo'shib yuborish."},
 tn:"Bu darslikning 34–35-darslari. Sonlarni o'nlik va birlik qismlari bilan ko'rsating: 37 = 30 + 7."},
{h:"Qaysi qo'shiluvchidan ayirish qulay?",sum:"(40 + 16) − 9: 16 dan olsa ham bo'ladi, lekin (40 − 9) + 16 = 47 osonroq.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>(40 + 16) − 9. Endi 9 ni qaysi qismdan olamiz?</p>",
 btns:[phaser(P2)],
 after:"<p>Agar ayiriladigan son kichik qo'shiluvchidan katta bo'lsa yoki o'nlikdan o'tish kerak bo'lsa — <b>yaxlit qo'shiluvchidan</b> olish qulay: 40 − 9 = 31.</p>",
 q:{t:"(50 + 14) − 7 ni qulay usulda hisoblang.",opts:["57","43","71","67"],ok:0,why:"(50 − 7) + 14 = 43 + 14 = 57, yoki 50 + (14 − 7) = 57.",hint:"7 ni 14 dan yoki 50 dan oling.",full:"50 + (14 − 7) = 50 + 7 = 57. Yoki (50 − 7) + 14 = 57. «43» — 14 ni qo'shishni unutish."},
 tn:"Bolalarga ikkala yo'lni ham ko'rsating va «qaysi biri senga oson?» deb so'rang — bu Yaponiya darslaridagi kabi «turli yechimlarni solishtirish»."},
{h:"Sondan yig'indini ayirish",sum:"50 − (20 + 8) = 50 − 20 − 8 = 22: qo'shiluvchilarni ketma-ket ayiramiz.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Endi teskarisi: <b>songa yig'indi</b> ayiriladi: 50 − (20 + 8). Kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p><b>Qoida:</b> sondan yig'indini ayirish — undan <b>har bir qo'shiluvchini ketma-ket</b> ayirish: 50 − (20 + 8) = 50 − 20 − 8.</p>",
 q:{t:"76 − (26 + 18) = ?",opts:["32","68","42","30"],ok:0,why:"76 − 26 = 50, 50 − 18 = 32.",hint:"Avval 26 ni ayiring — yaxlit son chiqadi.",full:"76 − 26 = 50, keyin 50 − 18 = 32. Yoki qavsni hisoblab: 76 − 44 = 32. «68» — 18 ni qo'shib yuborish (76 − 26 + 18)."},
 tn:"Hayotiy misol: «Hamyonda 50 ming. Avval 20 ming, keyin 8 ming sarfladingiz — yoki birdaniga 28 ming. Natija bir xil»."},
{h:"Qaysi yo'l qulay?",sum:"84 − (34 + 25): avval 84 − 34 = 50, keyin 50 − 25 = 25.",a:"m04",
 start:function(){bqExpr(['84 − (34 + 25)']);bqMsg('Qaysi qo‘shiluvchini birinchi ayirish qulay?')},fin:function(){bqExpr(['84 − 34 − 25','50 − 25 = [25]'])},
 html:"<p>84 − (34 + 25). Qaysi qo'shiluvchini <b>birinchi</b> ayirsak, hisob osonlashadi? Tanlang:</p>",
 btns:[["Avval 34",function(c,done,b){bqExpr(['84 − 34 − 25','50 − 25 = [25]']);bqMsg('To‘g‘ri! 84 − 34 = 50 — yaxlit son, keyin 50 − 25 = <b>25</b>');c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});done()}],["Avval 25",function(c,done,b){flashBad(b);bqMsg('Bo‘ladi, lekin 84 − 25 = 59 — qiyinroq. Birliklari bir xil bo‘lgani qulay')}]],g2:1,
 after:"<p>Birliklari bir xil bo'lgan sonni birinchi ayirsak, <b>yaxlit son</b> chiqadi (84 − 34 = 50). Qo'shiluvchilarni istalgan tartibda ayirish mumkin.</p>",
 q:{t:"95 − (25 + 37) ni qulay hisoblang.",opts:["33","43","107","23"],ok:0,why:"95 − 25 = 70, 70 − 37 = 33.",hint:"Qaysi son bilan 95 ning birliklari bir xil?",full:"95 − 25 = 70, 70 − 37 = 33. «107» — 37 ni qo'shib yuborish."},
 tn:"Bolalarga ikkala tartibni sinab ko'rishni taklif qiling — natija bir xil chiqishiga ishonch hosil qilsin."},
{h:"Tuzoq: qavsni noto'g'ri ochish",sum:"50 − (20 + 8) ≠ 50 − 20 + 8. Qavs oldida «−» bo'lsa, ichidagi «+» ham «−» ga aylanadi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Eng ko'p uchraydigan xato — qavsni ochganda belgini unutish. Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>Qavs oldida <b>«−»</b> turgan bo'lsa, qavsni ochganda ichidagi <b>«+» ham «−» bo'ladi</b>: 50 − (20 + 8) = 50 − 20 − 8. Chunki ikkalasi ham olib tashlanadi.</p>",
 q:{t:"Qaysi tenglik to'g'ri?",opts:["70 − (30 + 5) = 70 − 30 + 5","70 − (30 + 5) = 70 − 30 − 5","70 − (30 + 5) = 70 + 30 − 5","70 − (30 + 5) = 70 − 5 + 30"],ok:1,why:"Ikkala qo'shiluvchi ham ayiriladi.",hint:"Qavsdagi ikkala son ham olib tashlanadimi?",full:"70 − (30 + 5) = 35. 70 − 30 − 5 = 35 ✓. 70 − 30 + 5 = 45 ✗. Qolganlari ham noto'g'ri."},
 tn:"Qavsni «paket» deb tushuntiring: paketni olsangiz — ichidagi hamma narsani olasiz."},
{h:"Teskari: ketma-ket ayirishni birlashtiramiz",sum:"63 − 18 − 2 = 63 − (18 + 2) = 63 − 20 = 43.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Qoidani teskari tomonga ham ishlatish mumkin: ketma-ket ayirilayotgan sonlarni <b>birlashtirib</b>, bir marta ayiramiz.</p>",
 btns:[phaser(P6)],
 after:"<p>18 va 2 birlashib 20 bo'ldi — yaxlit son. 63 − 20 ni og'zaki hisoblash juda oson. Bu usul bank testlarida tez-tez kerak bo'ladi.</p>",
 q:{t:"87 − 14 − 6 = ?",opts:["67","79","73","61"],ok:0,why:"87 − (14 + 6) = 87 − 20 = 67.",hint:"14 va 6 ni birlashtirsangiz qanday son chiqadi?",full:"14 + 6 = 20, 87 − 20 = 67. «79» — 6 ni qo'shib yuborish (87 − 14 + 6)."},
 tn:"Musobaqa: kim tezroq — ketma-ket ayirib yoki birlashtirib."},
{h:"Hayotiy masala",sum:"90 ming so'mdan 30 ming va 15 ming sarflandi: 90 − (30 + 15) = 90 − 30 − 15 = 45 ming.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Alida 90 ming so'm bor edi. U 30 ming so'mga kitob, 15 ming so'mga daftar oldi. Qancha puli qoldi? Ikki usulda yechamiz:</p>",
 btns:[phaser(P7)],
 after:"<p>Masalani ikki xil yechish mumkin: <b>sarfni qo'shib, bir marta ayirish</b> yoki <b>ketma-ket ayirish</b>. Natija bir xil — bu qoidaning hayotdagi isboti!</p>",
 q:{t:"Kutubxonada 905 ta kitob bor edi. 378 tasi berildi, keyin ulardan 146 tasi qaytarildi. Endi kutubxonada nechta kitob bor?",opts:["381","527","673","683"],ok:2,why:"905 − 378 = 527, 527 + 146 = 673.",hint:"Qaytarilgan kitoblar qo'shiladimi yoki ayiriladimi?",full:"905 − 378 = 527 qoldi, 146 tasi qaytdi: 527 + 146 = 673. «381» — qaytarilganlarni ham ayirib yuborish xatosi."},
 tn:"Bolalar o'z hayotidan masala tuzsin: cho'ntak puli, konfetlar."},
{h:"Bilasizmi? Do'kondagi qaytim",sum:"Sotuvchilar qaytimni ko'pincha shu qoida bilan hisoblaydi: 50 − (18 + 12) = 50 − 30 = 20.",a:"m08",
 start:function(){bqBar(50,[{v:'18',w:18,col:'#e9e2d6',lab:'non'},{v:'12',w:12,col:'#e9e2d6',lab:'sut'},{v:'20',w:20,col:C.ok,lab:'qaytim'}],{title:'50 ming so‘m'});bqMsg('18 + 12 = 30, 50 − 30 = 20')},fin:function(){bqBar(50,[{v:'18',w:18,col:'#e9e2d6',lab:'non'},{v:'12',w:12,col:'#e9e2d6',lab:'sut'},{v:'20',w:20,col:C.ok,lab:'qaytim'}],{title:'50 ming so‘m'})},
 html:"<p>🛒 Tajribali sotuvchilar xaridlarni avval <b>qulay juftlab qo'shib</b>, keyin pul miqdoridan bir marta ayirishadi. Masalan, non 18 ming, sut 12 ming, xaridor 50 ming berdi: 18 + 12 = 30, qaytim 50 − 30 = <b>20 ming</b>.</p>",
 btns:[["🛒 Ko'rdim",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Siz bu qoidani endi bilasiz — do'konda qaytimni o'zingiz tekshira olasiz!</p>",
 tn:"Sinfda «do'kon» o'yini: o'yinchoq pullar bilan xarid va qaytim."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.ph=2;P3[2]()},fin:function(){S.ph=2;P3[2]()},
 html:"<div class='memo'><ul><li><b>Yig'indidan sonni</b>: biror qo'shiluvchidan ayiring: (30 + 7) − 5 = 30 + (7 − 5) = 32.</li><li>Qaysi qo'shiluvchidan qulay bo'lsa — shundan: (40 + 16) − 9 = (40 − 9) + 16.</li><li><b>Sondan yig'indini</b>: ketma-ket ayiring: 50 − (20 + 8) = 50 − 20 − 8.</li><li><b>Diqqat:</b> 50 − (20 + 8) ≠ 50 − 20 + 8.</li><li>Teskarisi: 63 − 18 − 2 = 63 − (18 + 2) = 43.</li></ul></div>",
 tn:"Bu qoidalar 3-sinfda katta sonlar bilan ishlashda ham asqotadi."}
];
var PROBS=[
{t:"(30 + 7) − 5 = ?",o:["32","42","22","38"],k:0,s:"30 + (7 − 5) = 32."},
{t:"(40 + 16) − 9 = ?",o:["47","65","37","57"],k:0,s:"(40 − 9) + 16 = 47."},
{t:"(60 + 8) − 3 = ?",o:["65","71","57","63"],k:0,s:"60 + 5 = 65."},
{t:"50 − (20 + 8) = ?",o:["22","38","32","28"],k:0,s:"50 − 20 − 8 = 22."},
{t:"76 − (26 + 18) = ?",o:["32","68","42","30"],k:0,s:"76 − 26 = 50, 50 − 18 = 32."},
{t:"84 − (34 + 25) = ?",o:["25","75","35","15"],k:0,s:"84 − 34 = 50, 50 − 25 = 25."},
{t:"95 − (25 + 37) = ?",o:["33","107","43","23"],k:0,s:"95 − 25 = 70, 70 − 37 = 33."},
{t:"63 − 18 − 2 = ?",o:["43","47","41","83"],k:0,s:"63 − 20 = 43."},
{t:"87 − 14 − 6 = ?",o:["67","79","73","61"],k:0,s:"87 − 20 = 67."},
{t:"Qaysi tenglik to'g'ri?",o:["70 − (30 + 5) = 70 − 30 − 5","70 − (30 + 5) = 70 − 30 + 5","70 − (30 + 5) = 70 + 30 − 5","70 − (30 + 5) = 75 − 30"],k:0,s:"Ikkala qo'shiluvchi ayiriladi."},
{t:"Alida 90 ming so'm bor edi. 30 ming kitobga, 15 ming daftarga sarfladi. Qancha qoldi?",o:["45 ming","75 ming","60 ming","135 ming"],k:0,s:"90 − 30 − 15 = 45."},
{t:"Kutubxonada 905 ta kitob bor edi. 378 tasi berildi, keyin 146 tasi qaytarildi. Endi nechta?",o:["673","381","527","683"],k:0,s:"905 − 378 + 146 = 673."},
{t:"(45 + 23) − 13 = ?",o:["55","81","35","45"],k:0,s:"45 + (23 − 13) = 55."},
{t:"100 − (40 + 35) = ?",o:["25","95","35","15"],k:0,s:"100 − 40 = 60, 60 − 35 = 25."},
{t:"Qaysi ifoda 723 − (180 + 120) ga teng?",o:["723 − 180 − 120","723 − 180 + 120","723 + 120 − 180","723 − 300 + 120"],k:0,s:"Ketma-ket ayirish."},
{t:"72 − 15 − 5 = ?",o:["52","62","42","57"],k:0,s:"72 − 20 = 52."},
{t:"(28 + 50) − 8 = ?",o:["70","86","78","60"],k:0,s:"(28 − 8) + 50 = 70."},
{t:"Savatda 64 ta olma bor edi. Ertalab 24 ta, kechqurun 18 ta sotildi. Nechta qoldi?",o:["22","40","46","106"],k:0,s:"64 − 24 = 40, 40 − 18 = 22."},
{t:"58 − (□ + 20) = 30. □ = ?",o:["8","28","48","10"],k:0,s:"□ + 20 = 28, □ = 8."},
{t:"(70 + □) − 6 = 76. □ = ?",o:["12","6","82","2"],k:0,s:"70 + □ = 82, □ = 12."}
];
function PRACT_STAGE(){S.ph=2;P3[2]();bqMsg('Qavs oldida «−» — ichidagilar ham ayiriladi')}
var PREP_DATA={teach:["Yig'indidan sonni ayirish: qulay qo'shiluvchidan.","Sondan yig'indini ayirish: ketma-ket ayirish.","Qavsni ochishdagi belgi qoidasi.","Teskari qo'llash va hayotiy masalalar."],
 mist:["Qavsni ochganda ikkinchi qo'shiluvchini qo'shib yuboradi (50 − 20 + 8).","Yig'indidan sonni ikkala qo'shiluvchidan ham ayiradi.","Qaytarilgan miqdorni ayiradi.","Qulay tartibni tanlay olmaydi."],
 need:["O'yinchoq pullar (do'kon o'yini)."],
 board:["<span class='w2'>(30 + 7) − 5 = 30 + (7 − 5)</span>.","<span class='w2'>(40 + 16) − 9 = (40 − 9) + 16</span>.","<span class='w2'>50 − (20 + 8) = 50 − 20 − 8</span>.","<span class='w2'>50 − (20 + 8) ≠ 50 − 20 + 8</span>.","<span class='w2'>63 − 18 − 2 = 63 − 20</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
