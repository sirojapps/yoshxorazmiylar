var CODE='4J01',TITLE="4-sinf · Sonli qonuniyatlar";
var STEPS=[
J4({h:"Ikkinchi farqlar",sum:"Farqlarning o'zi ham qonuniyat bilan o'zgarsa — farqlar qatorini yozamiz: 3, 5, 7, 9 → keyingi farq 11.",a:"m01",
 s:function(){j4Seq([2,5,10,17,26,'?'],{t:'Keyingi son qaysi?',d:['+3','+5','+7','+9','']})},m:"Farqlar: 3, 5, 7, 9 — ular ham 2 tadan oshyapti",
 f:function(){j4Seq([2,5,10,17,26,37],{t:'26 + 11 = 37',d:['+3','+5','+7','+9','+11']})},fm:"Keyingi farq 11: 26 + 11 = 37",
 html:"<p>Qator: 2, 5, 10, 17, 26, … Qo'shni sonlar orasidagi farqlarga qarang. Farqlarning o'zi qanday o'zgaryapti? Keyingi sonni tanlang.</p>",
 ch:["35","36","37","39"],ok:2,bad:["26 + 9 = 35 — farq takrorlanmaydi, u o‘syapti","Farqlar 3, 5, 7, 9 — toq sonlar. 10 bo‘lishi mumkinmi?","","Farqlar 2 tadan oshadi: 9 dan keyin 11, 13 emas"],
 after:"<p>Agar farqlar o'zgarmasa — bu oddiy qadam. Farqlar ham o'zgarsa, ularning ostiga <b>ikkinchi qator</b> yozamiz: 3, 5, 7, 9 — har biri 2 ga oshadi. Demak keyingi farq 11, son 26 + 11 = <b>37</b>. Qiziq: 2, 5, 10, 17, 26, 37 — bu 1, 4, 9, 16, 25, 36 sonlaridan bittaga ko'p!</p>",
 q:{t:"1, 2, 5, 10, 17, … Keyingi son?",opts:["26","24","25","27"],ok:0,why:"Farqlar 1, 3, 5, 7 → 9: 17 + 9 = 26.",hint:"Farqlarni yozing: 1, 3, 5, 7, …",full:"Farqlar toq sonlar: 1, 3, 5, 7, keyingisi 9. 17 + 9 = 26. «24» — farqni 7 deb qoldirish xatosi."},
 tn:"Doskada ikki qavatli yozuv: sonlar, ostida farqlar, uning ostida farqlarning farqi. Bu usul (chekli ayirmalar) — eng kuchli umumiy usul."}),
J4({h:"Oldingi ikkitasining yig'indisi",sum:"Har son oldingi ikki sonning yig'indisi: 1, 1, 2, 3, 5, 8, 13, 21 — Fibonachchi qatori.",a:"m02",
 s:function(){j4Seq([1,1,2,3,5,8,13,'?'])},m:"Farqlar: 0, 1, 1, 2, 3, 5 — ular ham shu qatorning o‘zi!",
 f:function(){j4Seq([1,1,2,3,5,8,13,21],{t:'8 + 13 = 21'})},fm:"Har son = oldingi ikki sonning yig‘indisi",
 html:"<p>1, 1, 2, 3, 5, 8, 13, … Bu yerda qo'shiladigan son o'zgarib boradi. Qaysi ikki sonni qo'shsak, keyingisi chiqadi? Keyingi sonni tanlang.</p>",
 ch:["18","20","21","26"],ok:2,bad:["13 + 5 = 18 — oxirgi qo‘shilgan 5 emas","13 + 7 = 20? 7 qayerdan keldi?","","13 · 2 = 26 — 8 dan 13 ga ikki marta oshmagan"],
 after:"<p>Qoida: <b>har son — oldingi ikki sonning yig'indisi</b>: 5 + 8 = 13, 8 + 13 = 21. Bu Fibonachchi qatori. Shunday qoidani har qanday boshlanishga qo'llash mumkin: 2, 2, 4, 6, 10, 16, …</p>",
 q:{t:"2, 2, 4, 6, 10, 16, … Keyingi son?",opts:["26","22","32","20"],ok:0,why:"10 + 16 = 26.",hint:"Oxirgi ikki sonni qo'shing.",full:"Har son oldingi ikkitasining yig'indisi: 6 + 10 = 16, 10 + 16 = 26. «32» — 2 marta oshirish xatosi, «22» — farqni 6 deb olish."},
 tn:"Bolalar o'z boshlanishi bilan (masalan, 3 va 4) Fibonachchi turidagi qator tuzib, qo'shnisiga jumboq qilib bersin."}),
J4({h:"Uchburchak sonlar",sum:"Nuqtalar uchburchagi: 1, 3, 6, 10, 15 … n-shaklda 1 + 2 + … + n nuqta. 10-shaklda 55.",a:"m03",
 s:function(){clear();var g=S.g,xs=[30,80,140,215];xs.forEach(function(x0,k){var n=k+1;for(var r=0;r<n;r++)for(var j=0;j<=r;j++)E('circle',{cx:x0+(j-r/2)*16,cy:40+r*16,r:6,fill:C.a},g);T(g,x0,150,String(n*(n+1)/2),{'font-size':15,'font-weight':800,fill:'#1d2b3a'})});T(g,305,90,'10-shakl?',{'font-size':15,'font-weight':800,fill:C.bad})},m:"1, 3, 6, 10 — har qatorda bittadan ko‘p nuqta qo‘shiladi",
 f:function(){j3Lines(['1 + 2 + 3 + … + 10','= (1 + 10) · 10 : 2 = [55]'],{fs:19,lh:40})},fm:"Juftlab qo‘shish: 1+10, 2+9, … — 5 juft, har biri 11",
 html:"<p>Nuqtalar uchburchak shaklida terilgan: 1, 3, 6, 10, … Har yangi shaklda pastga yangi qator qo'shiladi. <b>10-shaklda</b> nechta nuqta bo'ladi?</p>",
 ch:["45","50","55","66"],ok:2,bad:["45 — bu 9-shakl: 1 dan 9 gacha","10 · 5 = 50? Juftlarni qayta sanang: 1+10 = 11","","66 — bu 11-shakl"],
 after:"<p>n-shakldagi nuqtalar = 1 + 2 + … + n. Tez hisoblash: chetidan juftlaymiz — 1 + 10 = 2 + 9 = … = 11, juftlar 5 ta: 11 · 5 = <b>55</b>. Umumiy qoida: (1 + n) · n : 2.</p>",
 q:{t:"Uchburchak sonlar qatorida (1, 3, 6, 10, …) 6-son qaysi?",opts:["21","18","15","28"],ok:0,why:"1 + 2 + 3 + 4 + 5 + 6 = 21.",hint:"6-shaklda pastki qatorda 6 ta nuqta.",full:"15 + 6 = 21 yoki (1 + 6) · 6 : 2 = 21. «15» — 5-son, «28» — 7-son."},
 tn:"Tangalar yoki tugmachalar bilan uchburchak terdiring. Gaussning juftlash usulini doskada ko'rsating."}),
J4({h:"Ikki amalli qadam",sum:"Har qadamda ikki amal: «2 ga ko'paytir, 1 ni ayir»: 2, 3, 5, 9, 17, 33.",a:"m04",
 s:function(){j4Seq([2,3,5,9,17,'?'],{d:['+1','+2','+4','+8','']})},m:"Farqlar 1, 2, 4, 8 — har biri 2 marta oshyapti",
 f:function(){j4Seq([2,3,5,9,17,33],{t:'17 · 2 − 1 = 33',d:['+1','+2','+4','+8','+16']})},fm:"Ikki yo‘l bilan: 17 + 16 = 33 yoki 17 · 2 − 1 = 33",
 html:"<p>2, 3, 5, 9, 17, … Farqlarni yozib ko'ring: ular qanday o'zgaryapti? Keyingi son?</p>",
 ch:["25","33","34","26"],ok:1,bad:["17 + 8 = 25 — farq ham o‘zgaradi","","17 · 2 = 34 — yana 1 ni ayirish kerak","17 + 9 = 26 — farqlar 1 tadan emas, 2 marta oshyapti"],
 after:"<p>Farqlar 1, 2, 4, 8, 16 — har biri 2 marta katta. Boshqacha ko'rinishi: har son = oldingisi · 2 − 1 (9 · 2 − 1 = 17). Bitta qator ikki xil qoida bilan tushuntirilsa ham, javob bir xil chiqsa — ishonchli.</p>",
 q:{t:"1, 4, 13, 40, … (har son = oldingisi · 3 + 1). Keyingi son?",opts:["121","120","80","160"],ok:0,why:"40 · 3 + 1 = 121.",hint:"Qoidani oxirgi songa qo'llang.",full:"40 · 3 = 120, + 1 = 121. «120» — +1 ni unutish, «80» — faqat 2 marta oshirish."},
 tn:"Bolalar «kirish → amal → chiqish» mashinasini o'ynasin: biri qoida o'ylaydi, boshqalar 3–4 son bo'yicha topadi."}),
J4({h:"Uzoqdagi o'rin: formula",sum:"4, 7, 10, 13, … — n-o'rinda 4 + (n − 1) · 3. 50-o'rinda 4 + 49 · 3 = 151.",a:"m05",
 s:function(){j4Seq([4,7,10,13,'…','?'],{t:'50-o‘rindagi son?',d:['+3','+3','+3','','']})},m:"1-o‘rindan 50-o‘ringacha nechta qadam bor?",
 f:function(){j3Lines(['50-o‘ringacha 49 ta qadam','4 + 49 · 3 = [151]'],{fs:19,lh:40})},fm:"Qadamlar o‘rinlardan bittaga kam!",
 html:"<p>4, 7, 10, 13, … Hammasini yozib chiqish uzoq. <b>50-o'rindagi</b> sonni hisoblang. Ehtiyot bo'ling: 1-o'rindan 50-o'ringacha nechta «+3» qadam bor?</p>",
 ch:["150","151","154","148"],ok:1,bad:["50 · 3 = 150 — boshlang‘ich 4 ni hisobga olmadingiz","","4 + 50 · 3 = 154 — qadamlar 50 ta emas, 49 ta","Qayta hisoblang: 49 · 3 = 147, 147 + 4 = ?"],
 after:"<p>1-o'rinda 4 turibdi, keyin har o'ringa +3. 50-o'ringacha <b>49 ta</b> qadam: 4 + 49 · 3 = 151. Umumiy qoida: n-son = birinchi son + (n − 1) · qadam. Eng ko'p xato — qadamlar sonini o'rinlar soniga teng deb olish.</p>",
 q:{t:"7, 12, 17, 22, … 20-o'rindagi son?",opts:["102","107","100","97"],ok:0,why:"7 + 19 · 5 = 102.",hint:"20-o'ringacha nechta qadam?",full:"Qadam 5, qadamlar 19 ta: 7 + 95 = 102. «107» — 20 ta qadam olish xatosi, «100» — 20 · 5."},
 tn:"Kichik o'rinlar bilan tekshirtiring: 2-o'rin = 4 + 1 · 3 = 7 ✓. Formulani bolalar o'zi «kashf» qilsin."}),
J4({h:"Tuzoq: qaysi son qatorda bor?",sum:"5, 9, 13, 17, … sonlari 4 ga bo'linganda 1 qoldiq beradi. 2025 = 4 · 506 + 1 — qatorda bor.",a:"m06",
 s:function(){j4Seq([5,9,13,17,21,'…'],{t:'Qaysi son shu qatorda uchraydi?',d:['+4','+4','+4','+4','']})},m:"Har son 4 ga bo‘linganda qoldiq nechchi?",
 f:function(){j3Lines(['5 = 4 · 1 + [1]','9 = 4 · 2 + [1]','2025 = 4 · 506 + [1] ✓'],{fs:18,lh:36})},fm:"Qatordagi har son: 4 ga bo‘linsa, qoldiq 1",
 html:"<p>5, 9, 13, 17, 21, … qatori cheksiz davom etadi. Quyidagi sonlardan qaysi biri <b>albatta</b> shu qatorda uchraydi?</p>",
 ch:["2025","2026","2027","2028"],ok:0,bad:["","2026 : 4 = 506, qoldiq 2 — qatorda qoldiq 1","2027 : 4 = 506, qoldiq 3","2028 4 ga qoldiqsiz bo‘linadi — qatorda qoldiq 1"],
 after:"<p>Qatordagi sonlar «4 ning karralisi + 1»: 5 = 4 + 1, 9 = 8 + 1, … Katta sonni tekshirish uchun 1 ni ayirib, 4 ga bo'linishini qaraymiz: 2024 = 4 · 506 ✓, demak <b>2025</b> qatorda bor (u 506-o'rinda turadi).</p>",
 q:{t:"3, 7, 11, 15, … qatorida qaysi son bor?",opts:["99","98","100","101"],ok:0,why:"99 − 3 = 96 = 4 · 24.",hint:"Qatordagi sonlar 4 ga bo'linganda qanday qoldiq beradi?",full:"Qatordagi sonlar 4 ga bo'linganda qoldiq 3. 99 = 4 · 24 + 3 ✓. 98 (qoldiq 2), 100 (0), 101 (1) — yo'q."},
 tn:"Bu qadam olimpiadalarda tez-tez uchraydi. Qoldiq tushunchasini 3-sinf «qoldiqli bo'lish» darsi bilan bog'lang."}),
J4info({h:"Bilasizmi? Fibonachchi va quyonlar",a:"m07",s:['1, 1, 2, 3, 5, 8, 13, 21, 34','Liber Abaci, 1202-yil'],so:{fs:17,lh:40},m:"Quyonlar haqidagi masaladan tug‘ilgan qator",
 html:"<p>📜 Italiyalik matematik <b>Leonardo Fibonachchi</b> 1202-yilda «Liber Abaci» (Hisob kitobi) asarini yozgan. Unda quyonlar juftining ko'payishi haqida masala bor — javobi 1, 1, 2, 3, 5, 8, 13, … qatori bo'ladi. Shu kitob orqali Yevropada hind-arab raqamlari (biz yozayotgan 0–9) keng tarqalgan. Bu raqamlar bilan hisoblashni esa undan ancha oldin <b>al-Xorazmiy</b> o'z kitobida tushuntirgan edi.</p>",
 tn:"Kungaboqar savatchasi yoki ananas po'stidagi spirallarni sanatib ko'ring — ko'pincha Fibonachchi sonlari chiqadi (8, 13, 21, 34)."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){j4Seq([2,5,10,17,26,37],{d:['+3','+5','+7','+9','+11']})},m:'Qonuniyat izlash — farqlardan boshlanadi',
 html:"<div class='memo'><ul><li>Avval <b>farqlarni</b> yozing; o'zgarsa — farqlarning farqini.</li><li>Farqlar 2 marta oshsa — ko'paytirish bor (· 2 − 1 kabi).</li><li>Har son = oldingi <b>ikkitasining yig'indisi</b> bo'lishi mumkin.</li><li>n-o'rin: birinchi son + (n − 1) · qadam.</li><li>Uchburchak sonlar: (1 + n) · n : 2.</li><li>«Qatorda bormi?» — qoldiq bilan tekshiring.</li><li>Topgan qoidangizni 2–3 son bilan tekshiring.</li></ul></div>",
 tn:"Uyga: bolalar 3 ta qator tuzib (har xil qoida bilan), ertaga sinfdoshiga topishga beradi."})
];
var PROBS=[
{t:"3, 7, 11, 15, … Keyingi son?",o:["19","18","20","21"],k:0,s:"Har safar +4: 15 + 4 = 19."},
{t:"2, 6, 18, 54, … Keyingi son?",o:["162","108","72","160"],k:0,s:"Har safar · 3: 54 · 3 = 162."},
{t:"1, 4, 9, 16, 25, … Keyingi son?",o:["36","30","35","49"],k:0,s:"Kvadratlar: 6 · 6 = 36."},
{t:"2, 3, 5, 8, 12, 17, … Keyingi son?",o:["23","22","24","21"],k:0,s:"Farqlar 1, 2, 3, 4, 5 → 6: 17 + 6 = 23."},
{t:"1, 1, 2, 3, 5, 8, 13, 21, … Keyingi son?",o:["34","29","35","33"],k:0,s:"13 + 21 = 34."},
{t:"100, 93, 86, 79, … Keyingi son?",o:["72","71","73","70"],k:0,s:"Har safar −7: 79 − 7 = 72."},
{t:"3, 5, 9, 17, 33, … Keyingi son?",o:["65","49","66","64"],k:0,s:"Farqlar 2, 4, 8, 16 → 32: 33 + 32 = 65 (yoki 33 · 2 − 1)."},
{t:"1, 3, 6, 10, 15, 21, … Keyingi son?",o:["28","27","26","36"],k:0,s:"Farqlar 2, 3, 4, 5, 6 → 7: 21 + 7 = 28."},
{t:"4, 7, 10, 13, … 30-o'rindagi son?",o:["91","94","90","88"],k:0,s:"4 + 29 · 3 = 91."},
{t:"5, 9, 13, 17, … qatoridagi 100 dan katta eng kichik son?",o:["101","105","100","97"],k:0,s:"Sonlar 4 ga bo'linganda 1 qoldiq beradi: 97 dan keyin 101."},
{t:"2, 4, 8, 16, … 10-o'rindagi son?",o:["1024","512","2048","20"],k:0,s:"Har safar · 2: 32, 64, 128, 256, 512, 1024 (10-o'rin)."},
{t:"1, 2, 4, 7, 11, 16, … Keyingi son?",o:["22","21","23","32"],k:0,s:"Farqlar 1, 2, 3, 4, 5 → 6: 16 + 6 = 22."},
{t:"7, 12, 10, 15, 13, 18, … Keyingi son?",o:["16","21","23","14"],k:0,s:"Navbat bilan +5, −2: 18 − 2 = 16."},
{t:"1, 8, 27, 64, … Keyingi son?",o:["125","100","81","216"],k:0,s:"Kublar: 5 · 5 · 5 = 125."},
{t:"2, 5, 11, 23, 47, … Keyingi son?",o:["95","94","96","71"],k:0,s:"Har son = oldingisi · 2 + 1: 47 · 2 + 1 = 95."},
{t:"6, 11, 16, 21, … qatorida qaysi son bor?",o:["2026","2025","2027","2024"],k:0,s:"Sonlar 5 ga bo'linganda 1 qoldiq beradi: 2026 = 5 · 405 + 1."},
{t:"1, 2, 6, 24, 120, … Keyingi son?",o:["720","240","600","144"],k:0,s:"· 2, · 3, · 4, · 5, keyingisi · 6: 120 · 6 = 720."},
{t:"3, 4, 7, 11, 18, 29, … Keyingi son?",o:["47","40","46","58"],k:0,s:"Oldingi ikkitasining yig'indisi: 18 + 29 = 47."},
{t:"1 + 3 + 5 + … + 19 (1 dan 19 gacha barcha toq sonlar) yig'indisi?",o:["100","90","99","110"],k:0,s:"10 ta toq son: 1 + 19 = 20, 5 juft · 20 = 100."},
{t:"1 dan 100 gacha sonlar orasida 7 ga qoldiqsiz bo'linadiganlari nechta?",o:["14","15","13","7"],k:0,s:"7, 14, …, 98: 98 : 7 = 14 ta."}
];
function PRACT_STAGE(){j4Seq([1,1,2,3,5,8,13,21])}
var PREP_DATA={teach:["Farqlar va ikkinchi farqlar usuli.","Oldingi ikki son yig'indisi (Fibonachchi).","Uchburchak sonlar va juftlab qo'shish.","n-o'rindagi son: birinchi + (n − 1) · qadam.","Qatorga tegishlilikni qoldiq bilan tekshirish."],
 mist:["Farqlar o'zgarishini ko'rmaydi, oxirgi farqni takrorlaydi.","n-o'rinda n ta qadam deb hisoblaydi (1 ta ortiqcha).","Qoidani faqat 1–2 son bo'yicha topib, tekshirmaydi."],
 need:["Tugmachalar yoki tangalar (uchburchak sonlar uchun).","Raqamli kartochkalar."],
 board:["2, 5, 10, 17, 26 → farqlar 3, 5, 7, 9","n-son = 1-son + (n − 1) · qadam","1 + 2 + … + n = (1 + n) · n : 2","Fibonachchi: 1, 1, 2, 3, 5, 8, 13"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
