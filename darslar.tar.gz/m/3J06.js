var CODE='3J06',TITLE="3-sinf · Mantiqiy masalalar";
function j6Kids(h){clear();var N=['Doniyor','Ali','Vali','Soli'],H=h||[0,0,0,0],col=['#7fb3e6','#f2a65a','#8fd18f','#e58fb4'];
 N.forEach(function(n,i){var x=60+i*80,hh=H[i]||60,y=150-hh;E('rect',{x:x-18,y:y,width:36,height:hh,rx:6,fill:col[i],stroke:C.line,'stroke-width':1.4},S.g);E('circle',{cx:x,cy:y-12,r:11,fill:'#ffe0bd',stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x,166,n,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})}
var J6H=['','Olma','Nok','Uzum'];
function j6T(r){j3Tab([J6H].concat(r),{hr:1,hc:1,cw:66,ch:34,fs:16,y0:16,col:j6Col(r)})}
function j6Col(r){var c={};r.forEach(function(row,i){row.forEach(function(v,j){if(v==='✓')c[(i+1)+','+j]='#1e8e5a';if(v==='✗')c[(i+1)+','+j]=C.bad})});return c}
var P2=[function(){j6T([['Ali','','',''],['Vali','','',''],['Soli','','','']]);j3Msg('Ali nok ham, uzum ham yemadi. Vali uzum yemadi. Har kim boshqa meva yedi')},
 function(){j6T([['Ali','✓','✗','✗'],['Vali','','',''],['Soli','','','']]);j3Msg('Ali: nok ✗, uzum ✗ → demak <b>olma ✓</b>')},
 function(){j6T([['Ali','✓','✗','✗'],['Vali','✗','',''],['Soli','✗','','']]);j3Msg('Olmani Ali yedi → boshqalarga olma ✗')},
 function(){j6T([['Ali','✓','✗','✗'],['Vali','✗','✓','✗'],['Soli','✗','✗','✓']]);j3Msg('Vali: olma ✗, uzum ✗ → <b>nok</b>. Soliga <b>uzum</b> qoldi')}];
function j6Bag(r,b,hl){clear();E('path',{d:'M110,40 Q100,30 120,24 L240,24 Q260,30 250,40 L262,150 Q262,160 250,160 L110,160 Q98,160 98,150 Z',fill:'#efe3cf',stroke:C.line,'stroke-width':1.6},S.g);
 var k=0;for(var i=0;i<r+b;i++){var x=130+(k%5)*25,y=70+Math.floor(k/5)*34;E('circle',{cx:x,cy:y,r:10,fill:i<r?'#e05a5a':'#4f86d9',stroke:'#fff','stroke-width':2},S.g);k++}
 T(S.g,180,150,r+' qizil, '+b+' ko‘k',{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
var STEPS=[
{h:"Kim baland, kim past?",sum:"Shartlarni bitta qatorga terib chiqamiz: Doniyor > Ali > Vali > Soli.",a:"m01",
 start:function(){j6Kids([40,40,40,40]);j3Msg('Ali Validan baland. Soli Validan past. Doniyor Alidan baland. Eng past kim?')},fin:function(){j6Kids([120,95,70,45]);j3Msg('Doniyor > Ali > Vali > Soli')},
 html:"<p>To'rt bola bo'y o'lchashdi. Shartlarni o'qib, <b>eng past</b> bolani toping:</p>",
 btns:j3Ch(["Doniyor","Ali","Vali","Soli"],3,function(){j6Kids([120,95,70,45]);j3Msg('To‘g‘ri! Doniyor > Ali > Vali > Soli')},function(i){return ['Doniyor Alidan baland — u eng baland!','Ali Validan baland — u past bo‘la olmaydi','Soli Validan past ekan-ku'][i]}),g2:1,
 after:"<p>Usul: har bir shartni <b>son o'qidagi kabi</b> bitta qatorga terib chiqamiz. «Ali Validan baland» → Ali Validan o'ngda. Hammasini joylagach, javob ko'rinib qoladi.</p>",
 q:{t:"Olma nokdan og'ir, nok shaftolidan og'ir. Qaysi biri eng yengil?",opts:["Olma","Nok","Shaftoli","O'rik"],ok:2,why:"Olma > nok > shaftoli, shaftoli eng yengil.",hint:"Uchala mevani og'irlik bo'yicha qatorga tering.",full:"Olma > nok va nok > shaftoli, demak olma > nok > shaftoli. Eng yengili — shaftoli. O'rik shartda umuman yo'q."},
 tn:"Bolalarni sinf oldiga chiqarib, shartlar bo'yicha qatorga tizing — jonli model."},
{h:"Mantiqiy jadval",sum:"✓/✗ jadvali: bir katakda ✓ bo'lsa, uning qatori va ustunida qolganlari ✗.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ali, Vali va Soli har xil meva yedi. Kim nima yeganini jadval yordamida topamiz. Tugmani bosib, bosqichma-bosqich to'ldiring.</p>",
 btns:[phaser(P2)],
 after:"<p>Jadval qoidasi: har qatorda va har ustunda <b>bittadan ✓</b>. Bitta ✓ topilsa — uning qatori va ustunidagi qolgan kataklarga ✗ qo'yamiz. ✗ lar yangi ✓ ni ochadi.</p>",
 q:{t:"Jadvalda Vali qatorida ikkita ✗ bor (olma, uzum). Vali nima yedi?",opts:["Olma","Nok","Uzum","Bilmaymiz"],ok:1,why:"Uchta mevadan ikkitasi ✗ — qolgani nok.",hint:"Qaysi katak bo'sh qoldi?",full:"Valida 3 ta variant bor edi. Olma ✗, uzum ✗ — demak nok ✓. «Bilmaymiz» noto'g'ri: ikki ✗ javobni aniq beradi."},
 tn:"Doskaga 3 × 3 jadval chizing; bolalar navbat bilan ✓/✗ qo'ysin va har birini asoslasin."},
{h:"Eng yomon holat: bir xil juftlik",sum:"Qorong'ida bir xil rangli 2 ta olish uchun ranglar sonidan bittaga ko'p: 2 + 1 = 3.",a:"m03",
 start:function(){j6Bag(5,3);j3Msg('Qorong‘ida olamiz. Bir xil rangli 2 ta koptok albatta bo‘lishi uchun kamida nechta olish kerak?')},fin:function(){j6Bag(5,3);j3Msg('3 ta: eng yomoni qizil + ko‘k, uchinchisi albatta juft hosil qiladi')},
 html:"<p>Qopda 5 ta qizil va 3 ta ko'k koptok. Ko'rmasdan olamiz. Bir xil rangli <b>2 ta</b> koptok <b>albatta</b> bo'lishi uchun eng kamida nechta olish kerak?</p>",
 btns:j3Ch(["2","3","5","6"],1,function(){j3Msg('To‘g‘ri! Eng omadsiz holat: 1 qizil + 1 ko‘k. 3-koptok qaysi rang bo‘lmasin — juftlik tayyor')},function(i){return ['2 ta olsangiz, qizil + ko‘k chiqishi mumkin — juftlik yo‘q','','Oshiqcha: 3 tasida ham albatta juftlik bor','6 ta — bu ikkala rangdan kafolat uchun, bu boshqa savol'][i]}),g2:1,
 after:"<p>«<b>Albatta</b>» degan so'z — eng <b>omadsiz</b> holatni o'ylang, degani. Ranglar 2 ta: har rangdan bittadan olib qo'ysak ham, keyingisi juftlik beradi. Bu — <b>Dirixle prinsipi</b> (quyonlar va qafaslar).</p>",
 q:{t:"Qutida qizil, ko'k va sariq qalamlar ko'p. Bir xil rangli 2 ta qalam albatta bo'lishi uchun kamida nechta olish kerak?",opts:["3","4","2","6"],ok:1,why:"Eng yomoni: 3 xil rangdan bittadan. To'rtinchisi juftlik beradi.",hint:"Ranglar nechta? Har rangdan bittadan olsangiz nechta bo'ladi?",full:"Ranglar 3 ta. Eng omadsiz holatda 3 ta qalam har xil rangda. 4-qalam albatta biror rang bilan juft hosil qiladi. Javob 4. «3» — eng yomon holatni hisobga olmaslik xatosi."},
 tn:"Qopga rangli kubiklar solib, bolalar ko'zini yumib olsin. «Omadsiz bo'lsangiz-chi?» — asosiy savol."},
{h:"Tuzoq: ikkala rangdan ham",sum:"Ikkala rangdan bo'lishi uchun — ko'p rangning hammasini olib qo'yib, yana 1: 5 + 1 = 6.",a:"m04",
 start:function(){j6Bag(5,3);j3Msg('Endi savol boshqa: ikkala rangdan ham kamida bittadan bo‘lishi uchun-chi?')},fin:function(){j6Bag(5,3);j3Msg('6 ta: eng yomoni 5 ta qizil ketma-ket, 6-si albatta ko‘k')},
 html:"<p>Xuddi shu qop: 5 qizil, 3 ko'k. Endi <b>ikkala rangdan ham</b> kamida bittadan koptok albatta bo'lishi uchun nechta olish kerak?</p>",
 btns:j3Ch(["2","3","6","8"],2,function(){j3Msg('To‘g‘ri! Omadsiz holat: avval 5 ta qizil chiqadi. 6-si albatta ko‘k')},function(i){return ['2 ta: ikkalasi qizil bo‘lishi mumkin','3 ta: hammasi qizil bo‘lishi mumkin — qizil 5 ta bor!','','8 ta — hammasi. Kamroq ham yetadi'][i]}),g2:1,
 after:"<p>Eng yomon holatda avval <b>ko'p bo'lgan</b> rang to'liq chiqadi (5 qizil). Faqat shundan keyin ko'k kafolatlanadi: 5 + 1 = <b>6</b>. Savolni diqqat bilan o'qing: «bir xil» va «har xil» — butunlay boshqa javob.</p>",
 q:{t:"Qutida 6 qizil va 4 ko'k shar. Kamida 2 ta ko'k shar albatta bo'lishi uchun nechta olish kerak?",opts:["2","6","8","10"],ok:2,why:"Eng yomoni: 6 qizil oldin chiqadi, keyin 2 ko'k: 6 + 2 = 8.",hint:"Avval qaysi rang to'liq chiqib ketishi mumkin?",full:"Omadsiz holat: dastlabki 6 ta hammasi qizil. Keyin qolganlari faqat ko'k, 2 tasini olamiz: 6 + 2 = 8. «2» — omadli holat, «10» — hammasini olish."},
 tn:"Ikki savolni yonma-yon yozing: «bir xil 2 ta» va «har xil 2 ta» — farqini bolalar o'zi aytsin."},
{h:"Kim rost gapiryapti?",sum:"Bir-biriga zid ikki gapdan bittasi albatta rost. Faqat bitta rost bo'lsa — qolgan hamma gap yolg'on.",a:"m05",
 start:function(){j3Lines(['Ali: «Vazani Vali sindirdi»','Vali: «Men sindirmadim»','Soli: «Men sindirmadim»'],{fs:17,lh:32,y0:44});j3Msg('Uchalasidan <b>faqat bittasi</b> rost gapirdi. Vazani kim sindirdi?')},fin:function(){j3Lines(['Ali: «Vali sindirdi» — [yolg‘on]','Vali: «Men emas» — rost','Soli: «Men emas» — [yolg‘on]'],{fs:17,lh:32,y0:44});j3Msg('Vazani <b>Soli</b> sindirgan')},
 html:"<p>Uch bolaning gaplari tepada. Ulardan <b>faqat bittasi</b> rost gapirdi. Har ehtimolni tekshirib, aybdorni toping:</p>",
 btns:j3Ch(["Ali","Vali","Soli"],2,function(){j3Lines(['Ali: «Vali sindirdi» — [yolg‘on]','Vali: «Men emas» — rost','Soli: «Men emas» — [yolg‘on]'],{fs:17,lh:32,y0:44});j3Msg('To‘g‘ri! Faqat Vali rost gapirdi')},function(i){return i===0?'Ali sindirgan bo‘lsa: Vali «men emas» — rost, Soli «men emas» — rost. Ikkita rost — shartga zid':'Vali sindirgan bo‘lsa: Ali rost, Soli ham rost. Ikkita rost — shartga zid'}),g3:1,
 after:"<p>Kalit: Ali «Vali sindirdi», Vali «men emas» — bu gaplar <b>bir-biriga zid</b>, ulardan bittasi albatta rost. Rost faqat bitta, demak Solining gapi <b>yolg'on</b>: «men sindirmadim» yolg'on → Soli sindirgan.</p>",
 q:{t:"Ikki gap: «Bugun dushanba» va «Bugun dushanba emas». Ular haqida nima deyish mumkin?",opts:["Ikkalasi rost","Ikkalasi yolg'on","Aynan bittasi rost","Ikkalasi bir xil"],ok:2,why:"Gap va uning inkori: biri rost bo'lsa, ikkinchisi albatta yolg'on.",hint:"Bugun dushanba bo'lsa nima bo'ladi? Bo'lmasa-chi?",full:"Bugun dushanba bo'lsa — 1-gap rost, 2-si yolg'on. Bo'lmasa — aksincha. Har doim aynan bittasi rost. Bunday gaplar «zid gaplar» deyiladi."},
 tn:"«Har ehtimolni tekshiramiz» usulini doskada jadval bilan yozing: aybdor → kim rost → nechta rost."},
{h:"Yorliqlari xato qutilar",sum:"Barcha yorliq xato bo'lsa, «Aralash» qutida aralash yo'q — undan bitta meva olish hammasini ochadi.",a:"m06",
 start:function(){j3Tab([['Olma','Nok','Aralash']],{cw:96,ch:60,fs:17,y0:56,fill:{'0,0':'#fde6c8','0,1':'#e6f6ee','0,2':'#e8f1fb'}});j3Msg('Uchala yorliq ham XATO. Qaysi qutidan bitta meva olib, hammasini bilib olamiz?')},fin:function(){j3Tab([['Olma → nok','Nok → aralash','Aralash → olma']],{cw:110,ch:60,fs:14,y0:56,fill:{'0,2':'#e6f6ee'}});j3Msg('«Aralash» qutidan olma chiqdi → qolganlari o‘z-o‘zidan topiladi')},
 html:"<p>Uch qutida olma, nok va aralash meva bor. Hamma yorliqlar <b>noto'g'ri</b> yopishtirilgan. Faqat <b>bitta</b> qutidan <b>bitta</b> meva olishingiz mumkin. Qaysi qutini ochasiz?</p>",
 btns:j3Ch(["«Olma»","«Nok»","«Aralash»"],2,function(){j3Tab([['Olma → nok','Nok → aralash','Aralash → olma']],{cw:110,ch:60,fs:14,y0:56,fill:{'0,2':'#e6f6ee'}});j3Msg('Olma chiqdi → bu quti faqat olma. «Nok» quti olma emas, nok emas → aralash. «Olma» quti → nok')},function(i){return '«'+['Olma','Nok'][i]+'» qutidan '+['nok','olma'][i]+' chiqsa, u faqat '+['nok','olma'][i]+'mi yoki aralashmi — bilib bo‘lmaydi'}),g3:1,
 after:"<p>«Aralash» yorlig'i xato → bu qutida <b>faqat bir xil</b> meva. Bitta meva ko'rsak — butun quti ma'lum. Qolgan ikki quti esa yorliqlar xatoligidan topiladi. Usul: <b>eng ko'p ma'lumot beradigan</b> joyni tanlash.</p>",
 q:{t:"«Aralash» qutidan nok chiqdi. «Olma» yorliqli qutida nima bor?",opts:["Olma","Nok","Aralash","Bo'sh"],ok:2,why:"Nok — «Aralash» qutida. «Olma» quti olma emas, nok emas → aralash.",hint:"Nok qayerda ekanini bildik. «Olma» quti nima bo'la olmaydi?",full:"«Aralash» quti = nok. «Olma» yorlig'i xato → unda olma emas; nok ham emas (nok band) → aralash. «Nok» quti esa olma."},
 tn:"Uchta qutiga yorliq yopishtirib, ichiga rangli kubik soling — bolalar haqiqiy qutilar bilan sinasin."},
{h:"Bilasizmi? Rostgo'ylar va yolg'onchilar",sum:"Raymond Smallian 1978-yilda «Bu kitobning nomi nima?» kitobida rostgo'y va yolg'onchilar jumboqlarini mashhur qildi.",a:"m07",
 start:function(){j3Lines(['A: «Ikkalamiz ham yolg‘onchimiz»','A kim? B kim?'],{fs:18,lh:36});j3Msg('Rostgo‘y doim rost, yolg‘onchi doim yolg‘on gapiradi')},fin:function(){j3Lines(['A — [yolg‘onchi]','B — rostgo‘y'],{fs:18,lh:36});j3Msg('Rostgo‘y bunday gapni ayta olmaydi — demak A yolg‘onchi')},
 html:"<p>🏝 Amerikalik matematik <b>Raymond Smallian</b> 1978-yilda «Bu kitobning nomi nima?» degan jumboqlar kitobini chiqardi. Unda bir orol bor: aholining bir qismi doim rost gapiradi (rostgo'ylar), qolgani doim yolg'on (yolg'onchilar).</p><p>Tepadagi jumboq: A «ikkalamiz ham yolg'onchimiz» dedi. Rostgo'y o'zini yolg'onchi demaydi — demak A <b>yolg'onchi</b>, gapi yolg'on → B <b>rostgo'y</b>.</p>",
 tn:"Bolalar o'zi «rostgo'y-yolg'onchi» jumboq tuzib, bir-biriga bersin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j6Kids([120,95,70,45])},fin:function(){j6Kids([120,95,70,45])},
 html:"<div class='memo'><ul><li>Taqqoslashlar: hammasini <b>bitta qatorga</b> tering.</li><li>Jadval: har qator va ustunda bittadan ✓; ✓ topilsa, qolganlariga ✗.</li><li>«Albatta» — eng <b>omadsiz</b> holatni o'ylang.</li><li>Bir xil rangli 2 ta: ranglar soni + 1.</li><li>Ikkala rangdan: ko'p rangning hammasi + 1.</li><li>Rost/yolg'on: har ehtimolni tekshiring; zid gaplardan aynan bittasi rost.</li><li>Eng ko'p ma'lumot beradigan joydan boshlang.</li></ul></div>",
 tn:"Haftada bir marta 5 daqiqalik «mantiq daqiqasi» — bitta jumboq, bolalar yechimni og'zaki asoslaydi."}
];
var PROBS=[
{t:"Ali Validan baland, Vali Solidan baland, Doniyor Alidan past, lekin Validan baland. Eng past kim?",o:["Soli","Vali","Doniyor","Ali"],k:0,s:"Ali > Doniyor > Vali > Soli."},
{t:"Ali Validan baland, Vali Solidan baland, Doniyor Alidan past, lekin Validan baland. Eng baland kim?",o:["Ali","Doniyor","Vali","Soli"],k:0,s:"Ali > Doniyor > Vali > Soli."},
{t:"Olma nokdan og'ir, nok shaftolidan og'ir, o'rik olmadan og'ir. Eng yengil meva?",o:["Shaftoli","Nok","Olma","O'rik"],k:0,s:"O'rik > olma > nok > shaftoli."},
{t:"Navbatda 5 kishi turibdi. Malika boshidan 2-chi. U oxiridan nechanchi?",o:["4-chi","3-chi","2-chi","5-chi"],k:0,s:"5 − 2 + 1 = 4."},
{t:"Qatorda 12 bola. Ali chapdan 5-chi. U o'ngdan nechanchi?",o:["8-chi","7-chi","6-chi","9-chi"],k:0,s:"12 − 5 + 1 = 8."},
{t:"Besh qavatli uy. Ali Validan 2 qavat yuqorida, Vali Solidan 1 qavat pastda, Soli 4-qavatda. Ali nechanchi qavatda?",o:["5","6","3","2"],k:0,s:"Vali 3-qavatda, Ali 5-qavatda."},
{t:"Qopda 4 qizil va 4 yashil koptok. Bir xil rangli 2 ta albatta bo'lishi uchun kamida nechta olish kerak?",o:["3","2","5","4"],k:0,s:"Eng yomoni: 1 qizil + 1 yashil, 3-si juftlik beradi."},
{t:"Qutida qizil, ko'k va sariq paypoqlar ko'p. Bir xil rangli juft albatta bo'lishi uchun kamida nechta olish kerak?",o:["4","3","6","2"],k:0,s:"3 xil rangdan bittadan, 4-si juft hosil qiladi."},
{t:"Qutida 7 qizil va 5 ko'k qalam. Ikkala rangdan ham albatta bo'lishi uchun kamida nechta olish kerak?",o:["8","2","6","12"],k:0,s:"Eng yomoni: 7 qizil oldin, 8-si ko'k."},
{t:"Qutida 6 qizil va 4 ko'k shar. Kamida 2 ta ko'k albatta bo'lishi uchun nechta olish kerak?",o:["8","2","6","10"],k:0,s:"6 qizil + 2 ko'k = 8."},
{t:"Sumkada 3 qizil, 4 ko'k, 5 yashil shar. Kamida bitta yashil albatta bo'lishi uchun nechta olish kerak?",o:["8","6","1","12"],k:0,s:"Eng yomoni: 3 qizil + 4 ko'k = 7, 8-si yashil."},
{t:"Sumkada 3 qizil, 4 ko'k, 5 yashil shar. Bir xil rangli 3 ta albatta bo'lishi uchun kamida nechta olish kerak?",o:["7","9","4","6"],k:0,s:"Eng yomoni: har rangdan 2 tadan = 6, 7-si uchinchisini beradi."},
{t:"Sinfda kamida nechta o'quvchi bo'lsa, ulardan ikkitasi albatta bir oyda tug'ilgan bo'ladi?",o:["13","12","2","24"],k:0,s:"Oylar 12 ta: 12 kishi har xil oyda bo'lishi mumkin, 13-si takrorlaydi."},
{t:"Ali, Vali, Soli, Nodir — futbol, shaxmat, suzish, kurash (har kim boshqasi). Ali — futbolda. Vali shaxmat ham, kurash ham emas. Soli kurash bilan shug'ullanmaydi. Soli nima bilan shug'ullanadi?",o:["Shaxmat","Suzish","Kurash","Futbol"],k:0,s:"Vali — suzish, Soli — shaxmat, Nodir — kurash."},
{t:"Anvar: «Tortni Bobur yedi». Bobur: «Men yemadim». Jasur: «Men yemadim». Faqat bittasi rost gapirdi. Tortni kim yedi?",o:["Jasur","Anvar","Bobur","Anvar va Bobur birga"],k:0,s:"Anvar va Bobur zid — bittasi rost. Demak Jasur yolg'on: u yedi."},
{t:"Uch quti, bittasida tanga. 1-qutida: «Tanga shu yerda». 2-qutida: «Tanga bu yerda emas». 3-qutida: «Tanga 1-qutida emas». Faqat bitta yozuv rost. Tanga qayerda?",o:["2-qutida","1-qutida","3-qutida","1- yoki 3-qutida — ikkalasi ham mos"],k:0,s:"2-qutida bo'lsa: 1 — yolg'on, 2 — yolg'on, 3 — rost. Boshqa hollarda ikkita rost chiqadi."},
{t:"Yorliqlar: «Olma», «Nok», «Aralash» — hammasi xato. «Aralash» qutidan olma chiqdi. Qaysi qutida faqat nok bor?",o:["«Olma» yorliqli","«Nok» yorliqli","«Aralash» yorliqli","Bilish uchun yana bir qutidan olish kerak"],k:0,s:"«Aralash» — olma, «Nok» — aralash, «Olma» — nok."},
{t:"Orolda rostgo'ylar doim rost, yolg'onchilar doim yolg'on gapiradi. A: «Ikkalamiz ham yolg'onchimiz». A va B kim?",o:["A — yolg'onchi, B — rostgo'y","Ikkalasi yolg'onchi","Ikkalasi rostgo'y","A — rostgo'y, B — yolg'onchi"],k:0,s:"Rostgo'y bunday demaydi → A yolg'onchi, gapi yolg'on → B rostgo'y."},
{t:"A: «B — yolg'onchi». B: «A bilan men bir xilmiz». A va B kim?",o:["A — rostgo'y, B — yolg'onchi","Ikkalasi rostgo'y","Ikkalasi yolg'onchi","A — yolg'onchi, B — rostgo'y"],k:0,s:"B rost desak, A ham rostgo'y — lekin A «B yolg'onchi» dedi, zid. Demak B yolg'onchi, ular har xil → A rostgo'y."},
{t:"«Hamma qushlar ucha oladi» — bu gap yolg'on ekanini ko'rsatish uchun nima yetarli?",o:["Bitta uchmaydigan qush","Bitta uchadigan qush","Hamma qushni tekshirish","Ikkita uchadigan qush"],k:0,s:"«Hamma» gapini bitta qarama-qarshi misol (masalan, pingvin) rad etadi."}
];
function PRACT_STAGE(){j6Kids([120,95,70,45])}
var PREP_DATA={teach:["Taqqoslash shartlarini bitta qatorga terish.","Mantiqiy jadval (✓/✗).","Eng yomon holat (Dirixle prinsipi): «albatta», «kamida».","Rost/yolg'on masalalari: har ehtimolni tekshirish."],
 mist:["«Albatta» so'zini e'tiborsiz qoldirib, omadli holatni hisoblaydi.","«Bir xil 2 ta» va «ikkala rangdan» savollarini adashtiradi.","Rost/yolg'onda bitta ehtimolni tekshirib to'xtaydi."],
 need:["Rangli kubiklar va shaffof bo'lmagan qop.","Uchta quti va yorliqlar."],
 board:["<span class='w2'>D > A > V > S</span>","Jadval ✓/✗ (3 × 3)","Bir xil 2 ta: <span class='w2'>ranglar + 1</span>","Ikkala rangdan: <span class='w2'>ko'p rang + 1</span>"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
