var CODE='2F1',TITLE='2-sinf · Nuqta, to‘g‘ri chiziq, kesma, nur';
// ---------- sahna vositalari ----------
function f1_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f1_pt(x,y,lab,col){E('circle',{cx:x,cy:y,r:5,fill:col||C.blue,stroke:'#fff','stroke-width':1.5},S.g);if(lab)T(S.g,x,y-11,lab,{'font-size':14,'font-weight':800,fill:col||C.blue})}
function f1_seg(x1,y1,x2,y2,col,w,dash){return E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:col||'#1d2b3a','stroke-width':w||3,'stroke-linecap':'round','stroke-dasharray':dash||''},S.g)}
function f1_arrow(x,y,ang,col){var a=ang,s=10;E('path',{d:'M'+(x-s*Math.cos(a-0.45))+' '+(y-s*Math.sin(a-0.45))+' L'+x+' '+y+' L'+(x-s*Math.cos(a+0.45))+' '+(y-s*Math.sin(a+0.45)),fill:'none',stroke:col||'#1d2b3a','stroke-width':3,'stroke-linecap':'round'},S.g)}
// A(110,100), B(250,100)
function f1_kind(k){clear();var y=95;
 if(k===0){f1_pt(110,y,'A');f1_pt(250,y,'B');f1_msg('Ikkita nuqta: <b>A</b> va <b>B</b>');return}
 if(k===1){f1_seg(110,y,250,y);f1_pt(110,y,'A');f1_pt(250,y,'B');T(S.g,180,y+30,'kesma AB — 2 ta uchi bor, uzunligini o‘lchash mumkin',{'font-size':11,fill:C.ok,'font-weight':700});f1_msg('<b>Kesma</b>: ikki uchi bor. Chizg‘ich bilan o‘lchanadi');return}
 if(k===2){f1_seg(110,y,345,y);f1_arrow(348,y,0);f1_pt(110,y,'A');f1_pt(250,y,'B');T(S.g,180,y+30,'nur AB — 1 ta uchi (A), ikkinchi tomoni cheksiz',{'font-size':11,fill:C.a2,'font-weight':700});f1_msg('<b>Nur</b>: bitta uchi bor, bir tomonga cheksiz davom etadi');return}
 f1_seg(15,y,345,y);f1_arrow(348,y,0);f1_arrow(12,y,Math.PI);f1_pt(110,y,'A');f1_pt(250,y,'B');T(S.g,180,y+30,'to‘g‘ri chiziq AB — uchi yo‘q, ikki tomonga cheksiz',{'font-size':11,fill:C.bad,'font-weight':700});f1_msg('<b>To‘g‘ri chiziq</b>: uchi yo‘q, ikki tomonga cheksiz')}
var F1_P4=[function(){f1_kind(0)},function(){f1_kind(1)},function(){f1_kind(2)},function(){f1_kind(3)}];
function f1_fan(n){clear();var cx=180,cy=88;for(var i=0;i<n;i++){var a=i*Math.PI/n+0.15;f1_seg(cx-150*Math.cos(a),cy-80*Math.sin(a),cx+150*Math.cos(a),cy+80*Math.sin(a),['#1f6fb2','#e07a2f','#1e8e5a','#d94b4b','#8a5a24','#5aa9e6','#f08aa8'][i%7],2.5)}f1_pt(cx,cy,'O',C.bad);f1_msg(n?'O nuqta orqali <b>'+n+'</b> ta to‘g‘ri chiziq o‘tkazdik — yana ham chizish mumkin!':'O nuqta. Tugmani bosib, u orqali chiziq o‘tkazing')}
var F1_P6=[function(){clear();f1_pt(90,110,'A');f1_pt(270,60,'B');f1_msg('A va B nuqtalar orqali nechta to‘g‘ri chiziq o‘tadi?')},
 function(){clear();E('path',{d:'M90 110 Q180 10 270 60',fill:'none',stroke:'#9aa8b6','stroke-width':2.5,'stroke-dasharray':'5 4'},S.g);E('path',{d:'M90 110 Q200 160 270 60',fill:'none',stroke:'#9aa8b6','stroke-width':2.5,'stroke-dasharray':'5 4'},S.g);f1_pt(90,110,'A');f1_pt(270,60,'B');f1_msg('Egri chiziqlar ko‘p o‘tadi — lekin ular <b>to‘g‘ri</b> emas')},
 function(){clear();E('path',{d:'M90 110 Q180 10 270 60',fill:'none',stroke:'#cfd6de','stroke-width':2,'stroke-dasharray':'5 4'},S.g);E('path',{d:'M90 110 Q200 160 270 60',fill:'none',stroke:'#cfd6de','stroke-width':2,'stroke-dasharray':'5 4'},S.g);f1_seg(20,129.4,345,39.1,C.ok,3);f1_pt(90,110,'A');f1_pt(270,60,'B');f1_msg('<b>To‘g‘ri</b> chiziq esa faqat <b>bitta</b> — chizg‘ichni boshqacha qo‘yib bo‘lmaydi')}];
var F1_SEGS=[['A','B'],['A','C'],['A','D'],['B','C'],['B','D'],['C','D']],F1_X={A:50,B:140,C:220,D:310};
function f1_cnt(k){clear();var y=95;f1_seg(20,y,340,y,'#cfd6de',2);for(var i=0;i<k&&i<6;i++){var s=F1_SEGS[i],last=i===k-1;E('line',{x1:F1_X[s[0]],y1:y-(last?0:0),x2:F1_X[s[1]],y2:y,stroke:last?C.bad:'#9fc6ea','stroke-width':last?6:3},S.g)}
 ['A','B','C','D'].forEach(function(n){f1_pt(F1_X[n],y,n)});
 var list=F1_SEGS.slice(0,k).map(function(s){return s[0]+s[1]}).join(', ');T(S.g,180,140,k?list:'',{'font-size':13,'font-weight':800,fill:C.bad});
 f1_msg(k<6?'Kesmalarni tartib bilan sanaymiz: A dan boshlab, keyin B dan… <b>'+k+'</b> ta':'Hammasi <b>6 ta</b>: A dan 3 ta, B dan 2 ta, C dan 1 ta: 3 + 2 + 1 = 6')}
var F1_P8=[function(){clear();f1_seg(60,95,300,95);f1_pt(60,95,'A');f1_pt(300,95,'B');T(S.g,180,80,'8 sm',{'font-size':13,'font-weight':800,fill:C.blue});f1_msg('AB = 8 sm. C nuqta roppa-rosa o‘rtada. AC = ?')},
 function(){clear();f1_seg(60,95,180,95,C.ok,4);f1_seg(180,95,300,95,C.a,4);f1_pt(60,95,'A');f1_pt(180,95,'C',C.bad);f1_pt(300,95,'B');T(S.g,120,120,'4 sm',{'font-size':13,'font-weight':800,fill:C.ok});T(S.g,240,120,'4 sm',{'font-size':13,'font-weight':800,fill:C.a2});f1_msg('O‘rtada — teng ikki bo‘lak: 4 + 4 = 8. Demak <b>AC = 4 sm</b>')},
 function(){clear();f1_seg(30,95,200,95,C.ok,4);f1_seg(200,95,302,95,C.a,4);f1_pt(30,95,'A');f1_pt(200,95,'B');f1_pt(302,95,'C');T(S.g,115,120,'AB = 10 sm',{'font-size':12,'font-weight':800,fill:C.ok});T(S.g,251,120,'BC = 6 sm',{'font-size':12,'font-weight':800,fill:C.a2});Br(30,302,72,'AC = 10 + 6 = 16 sm',true);f1_msg('B nuqta A va C <b>orasida</b> bo‘lsa: AC = AB + BC')}];
var STEPS=[
{h:"Nuqta",sum:"Nuqta — joyni belgilaydi, uning uzunligi ham, kengligi ham yo'q. Katta harf bilan nomlanadi: A, B, C.",a:"m01",
 start:function(){clear();S.n1=0;f1_msg('Sahnaning istalgan joyini bosing — nuqta qo‘yiladi');var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},S.g);r.addEventListener('click',function(ev){var b=sv.getBoundingClientRect(),x=(ev.clientX-b.left)*360/b.width,y=(ev.clientY-b.top)*174/b.height;if(S.n1>=5)return;f1_pt(x,y,'ABCDE'[S.n1]);S.n1++;f1_msg('Nuqtalar: <b>'+'ABCDE'.slice(0,S.n1).split('').join(', ')+'</b>');if(S.n1===3&&S.d1)S.d1()})},
 fin:function(){clear();f1_pt(80,80,'A');f1_pt(180,120,'B');f1_pt(280,70,'C');f1_msg('Nuqtalar: <b>A, B, C</b>')},
 html:"<p>Qalam uchini qog'ozga bir tekkizsangiz — <b>nuqta</b> hosil bo'ladi. Tepadagi sahnani <b>3 marta</b> bosing va nuqtalar qo'ying.</p>",
 act:function(c,done){S.d1=function(){S.d1=null;done()};c.querySelector('.hint').textContent='Sahnani 3 marta bosing.'},
 after:"<p>Nuqtalarni <b>katta lotin harflari</b> bilan nomlaymiz: A, B, C. Nuqta faqat <b>joyni</b> ko'rsatadi — uning uzunligi yo'q, uni o'lchab bo'lmaydi.</p>",
 q:{t:"Nuqtalar qanday belgilanadi?",opts:["Raqamlar bilan: 1, 2, 3","Katta harflar bilan: A, B, C","Kichik harflar bilan: a, b, c","Hech qanday nom berilmaydi"],ok:1,why:"Geometriyada nuqtalar katta lotin harflari bilan nomlanadi.",hint:"Sahnada qo'ygan nuqtalaringizga qanday nom chiqdi?",full:"Nuqtalar katta lotin harflari bilan nomlanadi: A, B, C. Shunda «A dan B gacha» deb aniq aytish mumkin."},
 tn:"Bolalarga daftarga 3 ta nuqta qo'yib, nomlatib chiqing. «Nuqta — joy, narsa emas» degan fikrni ayting."},
{h:"Kesma, nur va to'g'ri chiziq",sum:"Kesma — 2 ta uchi bor, o'lchanadi. Nur — 1 ta uchi bor. To'g'ri chiziq — uchi yo'q, cheksiz.",a:"m02",
 start:function(){startPh(F1_P4)},fin:function(){S.ph=3;F1_P4[3]()},
 html:"<p>Ikki nuqtani chizg'ich bilan tutashtiramiz, keyin chiziqni cho'zamiz. Har bosqichda chiziqning <b>uchlarini</b> sanang.</p>",
 btns:[phaser(F1_P4,'▶ Davom ettirish')],
 after:"<div class='life'><div>📏<span><b>Kesma</b> — 2 ta uchi bor: tasma, qalam, ip bo'lagi</span></div><div>🔦<span><b>Nur</b> — 1 ta uchi: fonarning yorug'ligi bir joydan chiqib, ketaveradi</span></div><div>↔️<span><b>To'g'ri chiziq</b> — uchi yo'q, ikki tomonga cheksiz</span></div></div>",
 q:{t:"Nurning nechta uchi bor?",opts:["Ikkita","Uchi yo'q","Bitta","Uchta"],ok:2,why:"Nur bitta nuqtadan boshlanadi va bir tomonga cheksiz davom etadi.",hint:"Fonar nurini eslang: u qayerdan boshlanadi va qayerda tugaydi?",full:"Nurning boshlanish nuqtasi bor — bu uning bitta uchi. Ikkinchi tomoni cheksiz, tugamaydi. Ikki uchli — kesma, uchsiz — to'g'ri chiziq."},
 tn:"Doskada uchtasini yonma-yon chizing va uchlarini qizil bo'r bilan belgilang. Strelka «davom etadi» degan belgi ekanini tushuntiring."},
{h:"Qaysi birini o'lchash mumkin?",sum:"Faqat kesmaning uzunligini o'lchash mumkin — chunki faqat uning ikki uchi bor.",a:"m03",
 start:function(){f1_kind(1);f1_msg('Chizg‘ichni qo‘yib ko‘ring')},fin:function(){f1_ruler(3)},
 html:"<p>Chizg'ichni kesma, nur va to'g'ri chiziqqa qo'yib ko'ramiz. Tugmalarni bosing.</p>",
 btns:[["📏 Kesma",function(c,done){f1_ruler(1);mvK(done,3)}],["📏 Nur",function(c,done){f1_ruler(2);mvK(done,3)}],["📏 To'g'ri chiziq",function(c,done){f1_ruler(3);mvK(done,3)}]],
 after:"<p>Kesmaning boshi va oxiri bor — uni o'lchaymiz: <b>AB = 6 sm</b>. Nur va to'g'ri chiziq esa <b>tugamaydi</b> — ularning uzunligi yo'q, o'lchab bo'lmaydi.</p>",
 q:{t:"Kesma, nur va to'g'ri chiziqdan qaysi birining uzunligini chizg'ich bilan o'lchash mumkin?",opts:["Kesma","Nur","To'g'ri chiziq","Uchalasini ham"],ok:0,why:"Faqat kesmaning ikki uchi bor.",hint:"Qaysi birining ham boshi, ham oxiri bor?",full:"O'lchash uchun boshi va oxiri bo'lishi kerak. Faqat kesmada ikkalasi ham bor. Nur bir tomonga, to'g'ri chiziq ikki tomonga cheksiz."},
 tn:"Bolalar chizg'ich bilan kesma chizib, uzunligini yozsin: «AB = 5 sm»."},
{h:"Bitta nuqta orqali nechta chiziq?",sum:"Bitta nuqta orqali cheksiz ko'p to'g'ri chiziq o'tkazish mumkin.",a:"m04",
 start:function(){S.fan=0;f1_fan(0)},fin:function(){f1_fan(7)},
 html:"<p>O nuqta orqali to'g'ri chiziq o'tkazamiz. Tugmani bir necha marta bosing — yana chiziq bo'ladimi?</p>",
 btns:[["✏️ Yana chiziq o'tkazish",function(c,done){if(S.fan<7)S.fan++;f1_fan(S.fan);if(S.fan>=4)done()}]],
 after:"<p>Chiziqlar ketaveradi — <b>cheksiz ko'p</b>! Bitta nuqta orqali istalgancha to'g'ri chiziq o'tkazish mumkin: chizg'ichni nuqta atrofida aylantiravering.</p>",
 q:{t:"Bitta nuqta orqali nechta to'g'ri chiziq o'tkazish mumkin?",opts:["Faqat bitta","Ikkita","To'rtta","Cheksiz ko'p"],ok:3,why:"Chizg'ichni nuqta atrofida aylantirib, istalgancha chiziq chizish mumkin.",hint:"Tugmani bosganingizda chiziqlar tugadimi?",full:"Bitta nuqta orqali cheksiz ko'p to'g'ri chiziq o'tadi. Chegara bo'lmaydi — har safar chizg'ichni ozgina burish kifoya."},
 tn:"Doskada bitta nuqta qo'yib, bolalarni navbat bilan u orqali chiziq chizdiring — chiziqlar «quyosh nurlari»ga o'xshab ketadi."},
{h:"Ikki nuqta orqali — faqat bitta",sum:"Ikki nuqta orqali faqat bitta to'g'ri chiziq o'tadi.",a:"m05",
 start:function(){startPh(F1_P6)},fin:function(){S.ph=2;F1_P6[2]()},
 html:"<p>Endi ikkita nuqta — A va B. Ular orqali nechta to'g'ri chiziq o'tadi? Kuzating.</p>",
 btns:[phaser(F1_P6)],
 after:"<p>Ikki nuqta orqali <b>faqat bitta</b> to'g'ri chiziq o'tadi. Shuning uchun to'g'ri chiziqni ikki nuqtasi bilan nomlaymiz: «AB to'g'ri chiziq».</p>",
 q:{t:"Ikki nuqta orqali nechta to'g'ri chiziq o'tkazish mumkin?",opts:["Cheksiz ko'p","Faqat bitta","Ikkita","Birorta ham"],ok:1,why:"Ikki nuqta to'g'ri chiziqning holatini to'liq belgilaydi.",hint:"Egri chiziqlar emas, faqat to'g'ri chiziqlarni sanang.",full:"Egri chiziqlar ko'p bo'lishi mumkin, lekin to'g'ri chiziq faqat bitta — chizg'ichni ikkala nuqtaga tekkizsak, uni boshqacha qo'yib bo'lmaydi."},
 tn:"Quruvchilar va bog'bonlar ip tortib to'g'ri chiziq yasaydi: ikki qoziq — bitta to'g'ri chiziq."},
{h:"Tuzoq: nechta kesma bor?",sum:"To'g'ri chiziqda 4 ta nuqta — 6 ta kesma (3 + 2 + 1). 5 ta nuqta — 10 ta.",a:"m06",
 start:function(){S.ck=0;f1_cnt(0)},fin:function(){f1_cnt(6)},
 html:"<p>To'g'ri chiziqda A, B, C, D nuqtalar. Ular uchlari bo'lgan nechta kesma bor? Ko'pchilik «3 ta» deydi. Tugmani bosib, bittalab sanang.</p>",
 btns:[["▶ Keyingi kesma",function(c,done,b){if(S.ck<6){S.ck++;f1_cnt(S.ck)}if(S.ck===6){b.disabled=true;done()}}]],
 after:"<p>Faqat qo'shni nuqtalar emas, <b>har ikki nuqta</b> kesma hosil qiladi: AB, AC, AD, BC, BD, CD — <b>6 ta</b>.</p><p>Tartibli sanash: A dan 3 ta, B dan (A ni qayta sanamay) 2 ta, C dan 1 ta: <b>3 + 2 + 1 = 6</b>.</p>",
 q:{t:"To'g'ri chiziqda 5 ta nuqta belgilangan. Ular uchlari bo'lgan nechta kesma bor?",opts:["4","5","8","10"],ok:3,why:"4 + 3 + 2 + 1 = 10.",hint:"Birinchi nuqtadan nechta kesma chiqadi? Ikkinchisidan-chi (birinchisini qayta sanamay)?",full:"Birinchi nuqtadan 4 ta, ikkinchisidan 3 ta, uchinchisidan 2 ta, to'rtinchisidan 1 ta: 4 + 3 + 2 + 1 = 10. «4» — faqat qo'shni nuqtalar sanalgan."},
 tn:"Bu — olimpiada masalalarining asosi. Bolalar ro'yxat tuzib sanasin: AB, AC, AD… Takrorlamaslik qoidasini o'rgating."},
{h:"Tuzoq: kesmaning bo'laklari",sum:"C o'rtada bo'lsa: AC = AB ning yarmi. B nuqta A va C orasida bo'lsa: AC = AB + BC.",a:"m07",
 start:function(){startPh(F1_P8)},fin:function(){S.ph=2;F1_P8[2]()},
 html:"<p>Kesma ichidagi nuqta uni <b>bo'laklarga</b> ajratadi. Bo'laklar qo'shilsa — butun kesma. Kuzating.</p>",
 btns:[phaser(F1_P8)],
 after:"<p>Qoida: kesma ichidagi nuqta uni ikkiga bo'ladi va <b>bo'laklar yig'indisi = butun kesma</b>. Shuning uchun avval chizma chizing: qaysi nuqta qayerda turibdi?</p>",
 q:{t:"A, B, C nuqtalar bir to'g'ri chiziqda, B nuqta A va C orasida. AB = 10 sm, BC esa AB dan 4 sm qisqa. AC kesma necha sm?",opts:["4 sm","6 sm","14 sm","16 sm"],ok:3,why:"BC = 10 − 4 = 6 sm, AC = 10 + 6 = 16 sm.",hint:"Avval BC ni toping. Keyin chizmaga qarang: AC qaysi ikki bo'lakdan iborat?",full:"BC = 10 − 4 = 6 sm. B o'rtada turgani uchun AC = AB + BC = 10 + 6 = 16 sm. «6 sm» — faqat BC, «14 sm» — 10 + 4 qo'shilgan."},
 tn:"Bolalar har masalada avval chiziq chizib, nuqtalarni tartib bilan qo'ysin. Chizmasiz yechilgan masalada xato ko'p bo'ladi."},
{h:"Bilasizmi? Evklidning nuqtasi",sum:"Taxminan 2300 yil oldin yunon olimi Evklid «Negizlar» kitobida nuqtani «qismlari yo'q narsa» deb ta'riflagan.",a:"m08",
 start:function(){f1_hist(false)},fin:function(){f1_hist(true)},
 html:"<p>📜 Bundan taxminan <b>2300 yil oldin</b> yunon olimi <b>Evklid</b> «Negizlar» degan kitob yozdi. U geometriyani eng sodda narsalardan — nuqta va chiziqdan boshlagan.</p>",
 btns:[["📜 Evklid ta'riflari",function(c,done){f1_hist(true);done()}]],
 after:"<p>Evklid yozgan: «<b>Nuqta</b> — qismlari yo'q narsa», «<b>chiziq</b> — kengligi yo'q uzunlik». Bu kitob 2000 yildan ortiq vaqt davomida maktablarda geometriya darsligi bo'lgan!</p>",
 tn:"Bolalarga ayting: «Siz hozir o'rganayotgan narsalarni 2300 yil oldin ham bolalar o'rgangan»."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){f1_kind(1)},fin:function(){f1_kind(1)},
 html:"<div class='memo'><ul><li><b>Nuqta</b> — joyni belgilaydi; katta harf bilan nomlanadi: A, B.</li><li><b>Kesma</b> — 2 ta uchi bor, uzunligini o'lchash mumkin: AB = 6 sm.</li><li><b>Nur</b> — 1 ta uchi bor, bir tomonga cheksiz.</li><li><b>To'g'ri chiziq</b> — uchi yo'q, ikki tomonga cheksiz.</li><li>Bitta nuqta orqali — <b>cheksiz ko'p</b> to'g'ri chiziq; ikki nuqta orqali — <b>faqat bitta</b>.</li><li>Chiziqda 4 ta nuqta — <b>6 ta</b> kesma (3 + 2 + 1); 5 ta nuqta — <b>10 ta</b>.</li><li>Nuqta kesmani bo'lsa: <b>bo'laklar yig'indisi = butun kesma</b>.</li></ul></div>",
 tn:"Keyingi darsni «Uchburchak uchlari orqali nechta kesma o'tadi?» savoli bilan boshlang (3 ta)."}
];
function f1_ruler(k){f1_kind(k);var g=S.g;[].forEach.call(g.querySelectorAll('text'),function(t){if(t.getAttribute('font-size')==='11')t.remove()});E('rect',{x:100,y:104,width:160,height:22,rx:3,fill:'#fff3c4',stroke:'#b8a14a'},g);for(var i=0;i<=6;i++){E('line',{x1:110+i*23.3,y1:104,x2:110+i*23.3,y2:114,stroke:'#6b5a1c','stroke-width':1.2},g);T(g,110+i*23.3,123,String(i),{'font-size':9,fill:'#6b5a1c'})}
 f1_msg(k===1?'Kesma: A — 0 da, B — 6 da. <b>AB = 6 sm</b> ✓':(k===2?'Nur: boshi bor, lekin oxiri yo‘q — <b>o‘lchab bo‘lmaydi</b> ✗':'To‘g‘ri chiziq: boshi ham, oxiri ham yo‘q — <b>o‘lchab bo‘lmaydi</b> ✗'))}
function f1_hist(on){clear('#f6ead0');var g=S.g;E('polygon',{points:'90,140 180,30 270,140',fill:'none',stroke:'#6b3d12','stroke-width':3},g);E('circle',{cx:180,cy:104,r:34,fill:'none',stroke:'#6b3d12','stroke-width':2.5},g);[[90,140],[180,30],[270,140]].forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:5,fill:'#6b3d12'},g)});
 if(on)T(g,180,166,'«Nuqta — qismlari yo‘q narsa» — Evklid',{'font-size':12,'font-weight':800,fill:'#6b3d12'});f1_msg(on?'Evklid «Negizlar» kitobi — 2300 yillik darslik':'Evklid chizmasiga o‘xshash shakl')}
var PROBS=[
{t:"Nurning nechta uchi bor?",o:["bitta","ikkita","uchi yo'q","uchta"],k:0,s:"Nur bitta nuqtadan boshlanadi va bir tomonga cheksiz davom etadi."},
{t:"Kesmaning nechta uchi bor?",o:["ikkita","bitta","uchi yo'q","to'rtta"],k:0,s:"Kesmaning boshi va oxiri bor — 2 ta uchi."},
{t:"To'g'ri chiziqning nechta uchi bor?",o:["uchi yo'q","bitta","ikkita","uchta"],k:0,s:"To'g'ri chiziq ikki tomonga cheksiz — uchi yo'q."},
{t:"Qaysi birining uzunligini o'lchash mumkin?",o:["kesma","nur","to'g'ri chiziq","uchalasini ham"],k:0,s:"Faqat kesmaning ikki uchi bor."},
{t:"Bitta nuqta orqali nechta to'g'ri chiziq o'tkazish mumkin?",o:["cheksiz ko'p","faqat bitta","ikkita","to'rtta"],k:0,s:"Chizg'ichni nuqta atrofida aylantirib, istalgancha chizish mumkin."},
{t:"Ikki nuqta orqali nechta to'g'ri chiziq o'tkazish mumkin?",o:["faqat bitta","ikkita","cheksiz ko'p","birorta ham"],k:0,s:"Ikki nuqta orqali faqat bitta to'g'ri chiziq o'tadi."},
{t:"AB kesma 8 sm. C nuqta uning roppa-rosa o'rtasida. AC kesma necha sm?",o:["4 sm","8 sm","16 sm","2 sm"],k:0,s:"O'rtada — teng ikki bo'lak: 4 + 4 = 8. AC = 4 sm."},
{t:"To'g'ri chiziqda A, B, C, D nuqtalar belgilangan. Shu nuqtalar uchlari bo'lgan nechta kesma bor?",o:["6","3","4","8"],k:0,s:"AB, AC, AD, BC, BD, CD — 3 + 2 + 1 = 6."},
{t:"To'g'ri chiziqda 5 ta nuqta belgilangan. Ular uchlari bo'lgan nechta kesma bor?",o:["10","5","4","8"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"Bir to'g'ri chiziqda yotmaydigan 3 ta nuqtani har ikkitasini kesma bilan tutashtirsak, nechta kesma bo'ladi?",o:["3","2","6","1"],k:0,s:"AB, AC, BC — 3 ta (uchburchak hosil bo'ladi)."},
{t:"A, B, C nuqtalar bir to'g'ri chiziqda, B nuqta A va C orasida. AB = 10 sm, BC esa AB dan 4 sm qisqa. AC necha sm?",o:["16 sm","6 sm","14 sm","4 sm"],k:0,s:"BC = 10 − 4 = 6 sm. AC = 10 + 6 = 16 sm."},
{t:"AC kesma 15 sm. B nuqta A va C orasida, AB = 9 sm. BC necha sm?",o:["6 sm","24 sm","9 sm","5 sm"],k:0,s:"AB + BC = AC: 9 + BC = 15, BC = 15 − 9 = 6 sm."},
{t:"Qaysi narsa nurga o'xshaydi?",o:["fonardan chiqqan yorug'lik","qalam","ip bo'lagi","chizg'ich"],k:0,s:"Yorug'lik bir joydan chiqib, bir tomonga ketaveradi — nur kabi."},
{t:"Qaysi narsa kesmaga o'xshaydi?",o:["qalam","quyosh nuri","cheksiz yo'l","osmon"],k:0,s:"Qalamning boshi va oxiri bor — kesma kabi."},
{t:"Nuqtalar qanday nomlanadi?",o:["katta lotin harflari bilan","raqamlar bilan","so'zlar bilan","nomlanmaydi"],k:0,s:"Nuqtalar katta harflar bilan nomlanadi: A, B, C."},
{t:"MN kesmaning uzunligi 12 sm. K nuqta uning o'rtasida. MK + KN nechaga teng?",o:["12 sm","6 sm","24 sm","18 sm"],k:0,s:"Ikki bo'lak birga — butun kesma: MK + KN = MN = 12 sm."},
{t:"Ikki uchi bor, uzunligini o'lchash mumkin. Bu nima?",o:["kesma","nur","to'g'ri chiziq","nuqta"],k:0,s:"Ikki uchli va o'lchanadigan — kesma."},
{t:"To'g'ri chiziqda 3 ta nuqta belgilangan. Nechta kesma hosil bo'ladi?",o:["3","2","6","1"],k:0,s:"2 + 1 = 3: AB, AC, BC."},
{t:"Bitta nuqtadan chiqqan va bir tomonga cheksiz davom etadigan chiziq nima?",o:["nur","kesma","to'g'ri chiziq","siniq chiziq"],k:0,s:"Boshlanish nuqtasi bor, oxiri yo'q — nur."},
{t:"AB = 7 sm, BC = 5 sm. B nuqta A va C orasida. AC kesma qancha?",o:["12 sm","2 sm","7 sm","5 sm"],k:0,s:"AC = AB + BC = 7 + 5 = 12 sm."}
];
function PRACT_STAGE(){f1_kind(1)}
var PREP_DATA={teach:["Nuqta va uning nomlanishi.","Kesma, nur, to'g'ri chiziq — uchlari va farqlari.","Faqat kesmani o'lchash mumkin.","Bir nuqta orqali — cheksiz ko'p, ikki nuqta orqali — bitta to'g'ri chiziq.","Kesmalarni sanash (3 + 2 + 1) va kesma bo'laklari."],
 mist:["Nur bilan to'g'ri chiziqni aralashtiradi.","Nurning uzunligini o'lchamoqchi bo'ladi.","Kesmalarni sanaganda faqat qo'shnilarini sanaydi (4 nuqtada «3 ta»).","B nuqta qayerdaligini chizmasdan, sonlarni ayirib yuboradi."],
 need:["Chizg'ich, rangli bo'r.","Ip yoki tasma (kesma), fonar (nur uchun misol)."],
 board:["<span class='w2'>• A</span> — nuqta.","<span class='w2'>A———B</span> — kesma, 2 uchi.","<span class='w2'>A———B→</span> — nur, 1 uchi.","<span class='w2'>←A———B→</span> — to'g'ri chiziq, uchi yo'q.","4 nuqta: <span class='w2'>3 + 2 + 1 = 6</span> kesma.","<span class='w2'>AC = AB + BC</span>."]};
