var CODE='2F5',TITLE='2-sinf · Perimetr';
function f5_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f5_grid(){var g=S.g;for(var x=20;x<=340;x+=20)E('line',{x1:x,y1:10,x2:x,y2:170,stroke:'#e3e9f0'},g);for(var y=10;y<=170;y+=20)E('line',{x1:20,y1:y,x2:340,y2:y,stroke:'#e3e9f0'},g)}
// chumoli to'g'ri to'rtburchak atrofida: tomonlar 8, 5, 8, 5 sm
var F5_R=[[60,40],[300,40],[300,130],[60,130]],F5_L=[8,5,8,5];
function f5_walk(k){clear();var g=S.g;E('rect',{x:60,y:40,width:240,height:90,fill:'#e8f1fb',stroke:'#9fc6ea','stroke-width':2},g);
 var labs=[[180,32],[322,90],[180,150],[38,90]];var s=0,parts=[];
 for(var i=0;i<4;i++){var a=F5_R[i],b=F5_R[(i+1)%4];var on=i<k;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.a2:'#9fc6ea','stroke-width':on?5:2,'stroke-linecap':'round'},g);T(g,labs[i][0],labs[i][1],F5_L[i]+' sm',{'font-size':13,'font-weight':800,fill:on?C.a2:'#5b6b7b'});if(on){s+=F5_L[i];parts.push(F5_L[i])}}
 var p=F5_R[k%4];T(g,p[0],p[1]+5,'🐜',{'font-size':18});
 f5_msg(k===0?'Chumoli A burchakdan yo‘lga chiqdi':(parts.join(' + ')+' = <b>'+s+' sm</b>'+(k===4?' — chumoli qaytib keldi! Bu <b>perimetr</b>':'')))}
var F5_P1=[function(){f5_walk(0)},function(){f5_walk(1)},function(){f5_walk(2)},function(){f5_walk(3)},function(){f5_walk(4)}];
function f5_cells(k){clear();f5_grid();var g=S.g,x0=100,y0=50,w=4,h=3,c=20;E('rect',{x:x0,y:y0,width:w*c,height:h*c,fill:'#e6f6ee',stroke:C.ok,'stroke-width':2},g);
 var edges=[];for(var i=0;i<w;i++)edges.push([x0+i*c,y0,x0+(i+1)*c,y0]);for(var j=0;j<h;j++)edges.push([x0+w*c,y0+j*c,x0+w*c,y0+(j+1)*c]);for(var i2=w;i2>0;i2--)edges.push([x0+i2*c,y0+h*c,x0+(i2-1)*c,y0+h*c]);for(var j2=h;j2>0;j2--)edges.push([x0,y0+j2*c,x0,y0+(j2-1)*c]);
 for(var e=0;e<k&&e<edges.length;e++){var d=edges[e];E('line',{x1:d[0],y1:d[1],x2:d[2],y2:d[3],stroke:C.bad,'stroke-width':4,'stroke-linecap':'round'},g);T(g,(d[0]+d[2])/2+(d[0]===d[2]?(d[0]>x0?10:-10):0),(d[1]+d[3])/2+(d[1]===d[3]?(d[1]>y0?14:-5):4),String(e+1),{'font-size':10,'font-weight':800,fill:C.bad})}
 T(g,260,80,'1 katak tomoni = 1 sm',{'font-size':11,fill:'#5b6b7b'});
 f5_msg(k<14?'Katak tomonlarini sanaymiz: <b>'+k+'</b>':'Atrofida <b>14</b> ta katak tomoni: perimetr <b>14 sm</b> (4 + 3 + 4 + 3)')}
var F5_P6=[function(){f5_rect(9,null,0)},function(){f5_rect(9,5,1)},function(){f5_rect(9,5,2)}];
function f5_rect(a,b,k){clear();var g=S.g,x0=60,y0=40,W=a*24,H=(b||5)*16;E('rect',{x:x0,y:y0,width:W,height:H,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);
 T(g,x0+W/2,y0-8,a+' sm (bo‘yi)',{'font-size':13,'font-weight':800,fill:C.blue});T(g,x0+W+10,y0+H/2+4,b?b+' sm':'?',{'font-size':13,'font-weight':800,fill:b?C.ok:C.bad,'text-anchor':'start'});
 if(k>=2){T(g,x0+W/2,y0+H+18,a+' sm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,x0-6,y0+H/2+4,b+' sm',{'font-size':13,'font-weight':800,fill:C.ok,'text-anchor':'end'})}
 f5_msg(k===0?'Bo‘yi 9 sm, eni bo‘yidan 4 sm qisqa. Perimetr?':(k===1?'Avval enini topamiz: 9 − 4 = <b>5 sm</b>':'Perimetr: 9 + 5 + 9 + 5 = <b>28 sm</b>'))}
var F5_P7=[function(){f5_join(0)},function(){f5_join(1)},function(){f5_join(2)}];
function f5_join(k){clear();var g=S.g;
 if(k===0){E('rect',{x:40,y:40,width:120,height:60,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);E('rect',{x:200,y:40,width:120,height:60,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);T(g,100,34,'6 sm',{'font-size':12,'font-weight':800,fill:C.blue});T(g,30,74,'3',{'font-size':12,'font-weight':800,fill:C.ok});T(g,260,34,'6 sm',{'font-size':12,'font-weight':800,fill:C.blue});T(g,190,74,'3',{'font-size':12,'font-weight':800,fill:C.ok});T(g,180,130,'har birining perimetri: 6 + 3 + 6 + 3 = 18 sm',{'font-size':12,'font-weight':700,fill:'#3a4a5a'});f5_msg('Ikkita bir xil to‘g‘ri to‘rtburchak: 6 sm va 3 sm. Ularni uzun tomoni bilan jips qo‘yamiz');return}
 E('rect',{x:120,y:30,width:120,height:60,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);E('rect',{x:120,y:90,width:120,height:60,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);
 if(k===1){E('line',{x1:120,y1:90,x2:240,y2:90,stroke:C.bad,'stroke-width':5},g);T(g,300,94,'ichkariga kirib ketdi',{'font-size':11,'font-weight':800,fill:C.bad});f5_msg('Ikkita 6 sm li tomon <b>ichkarida</b> qoldi — ular endi atrofda emas!');return}
 E('rect',{x:120,y:30,width:120,height:120,fill:'none',stroke:C.a2,'stroke-width':5},g);T(g,180,24,'6',{'font-size':12,'font-weight':800,fill:C.a2});T(g,180,166,'6',{'font-size':12,'font-weight':800,fill:C.a2});T(g,106,94,'3 + 3',{'font-size':12,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,254,94,'3 + 3',{'font-size':12,'font-weight':800,fill:C.a2,'text-anchor':'start'});
 f5_msg('Yangi shakl atrofi: 6 + 6 + 6 + 6 = <b>24 sm</b> (18 + 18 = 36 emas!)')}
function f5_stairs(k){clear();f5_grid();var g=S.g;var pts=k===0?'100,50 260,50 260,150 100,150':'100,50 160,50 160,90 220,90 220,130 260,130 260,150 100,150';
 E('polygon',{points:pts,fill:'#e6f6ee',stroke:C.ok,'stroke-width':3},g);if(k===1){E('path',{d:'M160 50 L260 50 L260 130',fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 4'},g);T(g,290,70,'zinapoya tomonlarini',{'font-size':10,fill:C.bad,'text-anchor':'middle'});T(g,290,82,'surib chiqarsak',{'font-size':10,fill:C.bad})}
 f5_msg(k===0?'To‘g‘ri to‘rtburchak: 8 × 5 katak, perimetr 8 + 5 + 8 + 5 = <b>26</b>':'Zinapoya shakl: zinalarni tashqariga surib qo‘ysak — o‘sha to‘g‘ri to‘rtburchak! Perimetr ham <b>26</b>')}
var STEPS=[
{h:"Chumolining sayohati",sum:"Perimetr — shakl atrofining uzunligi: barcha tomonlar yig'indisi. 8 + 5 + 8 + 5 = 26 sm.",a:"m01",
 start:function(){startPh(F5_P1)},fin:function(){S.ph=4;F5_P1[4]()},
 html:"<p>Chumoli to'g'ri to'rtburchak shaklidagi gilam atrofini aylanib chiqadi. U qancha yo'l yuradi? Har bir tomonni bittalab qo'shib boramiz.</p>",
 btns:[phaser(F5_P1,'▶ Keyingi tomon')],
 after:"<p>Shakl atrofining uzunligi <b>perimetr</b> deyiladi. Uni topish uchun <b>hamma tomonlarni qo'shamiz</b>: 8 + 5 + 8 + 5 = <b>26 sm</b>. Perimetr — bu yopiq siniq chiziqning uzunligi!</p>",
 q:{t:"Uchburchakning tomonlari 5 sm, 6 sm va 7 sm. Uning perimetri qancha?",opts:["11 sm","13 sm","18 sm","15 sm"],ok:2,why:"5 + 6 + 7 = 18 sm.",hint:"Hamma tomonlarni qo'shing — uchtasini ham.",full:"Perimetr — barcha tomonlar yig'indisi: 5 + 6 + 7 = 18 sm. «11» va «13» — faqat ikkita tomon qo'shilgan."},
 tn:"Bolalar ip bilan partaning atrofini o'lchab, keyin ipni chizg'ich bilan o'lchasin. «Perimetr — atrof» degan so'zni hayotiy misollar bilan bog'lang: bog' devori, rasm ramkasi."},
{h:"Katakli qog'ozda perimetr",sum:"Katakli shakl perimetri — atrofidagi katak tomonlari soni. 4 × 3 katakli to'g'ri to'rtburchak: 14.",a:"m02",
 start:function(){S.ce=0;f5_cells(0)},fin:function(){f5_cells(14)},
 html:"<p>Har bir katakning tomoni <b>1 sm</b>. Yashil to'g'ri to'rtburchakning perimetrini topish uchun uning atrofidagi katak tomonlarini sanaymiz. Tugmani bosing.</p>",
 btns:[["▶ Sanash (+2)",function(c,done,b){S.ce=Math.min(14,S.ce+2);f5_cells(S.ce);if(S.ce>=14){b.disabled=true;done()}}]],
 after:"<p>Atrofida <b>14 ta</b> katak tomoni — perimetr <b>14 sm</b>. Tekshirish: 4 + 3 + 4 + 3 = 14 ✓. Faqat <b>tashqi</b> chiziqlar sanaladi, ichidagi katak chiziqlari emas.</p>",
 q:{t:"Katakli qog'ozda bo'yi 5 katak, eni 2 katak bo'lgan to'g'ri to'rtburchak. Perimetri necha sm (1 katak = 1 sm)?",opts:["10 sm","7 sm","14 sm","12 sm"],ok:2,why:"5 + 2 + 5 + 2 = 14 sm.",hint:"To'rtta tomonning hammasini qo'shing.",full:"Tomonlar: 5, 2, 5, 2. Yig'indisi 14 sm. «7» — faqat ikki tomon, «10» — katakchalar soni (bu yuz, perimetr emas)."},
 tn:"Katakli daftarda bolalar shakl chizib, atrofini rangli qalam bilan aylantirib chiqsin va katak tomonlarini sanasin."},
{h:"To'g'ri to'rtburchak va kvadrat",sum:"To'g'ri to'rtburchak: bo'yi + eni + bo'yi + eni. Kvadrat: 4 ta teng tomon qo'shiladi: 6 + 6 + 6 + 6 = 24.",a:"m03",
 start:function(){f5_sq(0)},fin:function(){f5_sq(1)},
 html:"<p>To'g'ri to'rtburchak va kvadratda tomonlarni hammasini o'lchash shart emas — xossalari yordam beradi. Tugmalarni bosing.</p>",
 btns:[["▭ To'g'ri to'rtburchak",function(c,done){f5_sq(0);mvK(done,2)}],["◻ Kvadrat",function(c,done){f5_sq(1);mvK(done,2)}]],g2:1,
 after:"<p><b>To'g'ri to'rtburchak</b>ning faqat bo'yi va enini bilish yetadi — qarama-qarshi tomonlar teng. <b>Kvadrat</b>ning esa bitta tomonini bilish kifoya — to'rttasi ham teng.</p>",
 q:{t:"Bog' kvadrat shaklida, tomoni 9 m. Bog' atrofiga devor qurish uchun necha metr devor kerak?",opts:["18 m","27 m","81 m","36 m"],ok:3,why:"9 + 9 + 9 + 9 = 36 m.",hint:"Kvadratning nechta tomoni bor va ular qanday?",full:"Kvadratning 4 ta teng tomoni: 9 + 9 + 9 + 9 = 36 m. «18» — ikki tomon, «27» — uch tomon qo'shilgan."},
 tn:"Bolalar to'g'ri to'rtburchakda qaysi tomonlar teng ekanini chizmada bir xil rang bilan belgilasin."},
{h:"Teskari masala: tomonni topamiz",sum:"Perimetr va ikki tomon ma'lum bo'lsa: uchinchi tomon = perimetr − ma'lum tomonlar. 15 − (6 + 4) = 5.",a:"m04",
 start:function(){f5_tri(0)},fin:function(){f5_tri(2)},
 html:"<p>Uchburchakning perimetri <b>15 dm</b>. Ikki tomoni 6 dm va 4 dm. Uchinchi tomoni qancha? Tugmalarni bosib yeching.</p>",
 btns:[["1) Ma'lumlarni qo'shish",function(c,done){f5_tri(1);mvK(done,2)}],["2) Perimetrdan ayirish",function(c,done){f5_tri(2);mvK(done,2)}]],g2:1,
 after:"<p>Perimetr — hamma tomonlar birga. Ma'lum tomonlar <b>6 + 4 = 10</b>. Qolgani — noma'lum tomon: <b>15 − 10 = 5 dm</b>. Tekshirish: 6 + 4 + 5 = 15 ✓</p>",
 q:{t:"Uchburchakning ikkita teng tomoni bor, har biri 6 sm. Perimetri 19 sm. Uchinchi tomoni qancha?",opts:["13 sm","6 sm","7 sm","12 sm"],ok:2,why:"6 + 6 = 12, 19 − 12 = 7 sm.",hint:"Teng ikki tomonni qo'shing, keyin perimetrdan ayiring.",full:"Ikki teng tomon: 6 + 6 = 12 sm. Uchinchisi: 19 − 12 = 7 sm. «13» — faqat bitta 6 ayirilgan."},
 tn:"Chizma chizdirib, ma'lum tomonlar ustiga son, noma'lumiga «?» yozdiring."},
{h:"Tuzoq: eni bo'yidan qisqa",sum:"Bo'yi 9 sm, eni 4 sm qisqa: avval eni 9 − 4 = 5, keyin perimetr 9 + 5 + 9 + 5 = 28 sm.",a:"m05",
 start:function(){startPh(F5_P6)},fin:function(){S.ph=2;F5_P6[2]()},
 html:"<p>«To'g'ri to'rtburchakning bo'yi 9 sm, eni esa bo'yidan 4 sm qisqa. Perimetrini toping.» Ko'pchilik 9 + 4 = 13 deb yozadi. Kuzating!</p>",
 btns:[phaser(F5_P6)],
 after:"<p>«4 sm qisqa» — bu eni emas! Avval enini topamiz: 9 − 4 = <b>5 sm</b>. Keyin to'rtta tomonni qo'shamiz: <b>28 sm</b>. Bu masala <b>ikki amalli</b>.</p>",
 q:{t:"To'g'ri to'rtburchak shaklidagi bog'ning bo'yi 18 m, eni esa bo'yidan 6 m qisqa. Bog' atrofini o'rash uchun necha metr to'r kerak?",opts:["48 m","30 m","60 m","72 m"],ok:2,why:"Eni 18 − 6 = 12 m, perimetr 18 + 12 + 18 + 12 = 60 m.",hint:"Avval enini toping: 18 dan 6 kam.",full:"Eni: 18 − 6 = 12 m. Perimetr: 18 + 12 + 18 + 12 = 60 m. «48» — enini 6 deb olingan, «30» — faqat bo'yi va eni qo'shilgan."},
 tn:"Bolalar masaladan avval «eni = ?» ni alohida yozsin. Ko'p xato shu birinchi qadamni tashlab ketishdan."},
{h:"Tuzoq: shakllar birlashsa",sum:"Ikki to'g'ri to'rtburchakni jips qo'ysak, tegib turgan tomonlar ichkarida qoladi: perimetr 18 + 18 = 36 emas, 24.",a:"m06",
 start:function(){startPh(F5_P7)},fin:function(){S.ph=2;F5_P7[2]()},
 html:"<p>Ikkita bir xil to'g'ri to'rtburchak (6 sm va 3 sm) uzun tomonlari bilan jips qo'yildi. Yangi shaklning perimetri qancha? «18 + 18 = 36» degan javob — tuzoq!</p>",
 btns:[phaser(F5_P7)],
 after:"<p>Shakllar birlashganda <b>tegib turgan tomonlar</b> ichkarida qoladi — ular perimetrga kirmaydi. Shuning uchun har doim <b>yangi shaklning atrofini</b> qaytadan sanang: <b>24 sm</b>.</p>",
 q:{t:"Ikkita kvadrat (tomoni 4 sm) yonma-yon jips qo'yildi. Yangi shaklning perimetri qancha?",opts:["32 sm","24 sm","16 sm","20 sm"],ok:1,why:"Yangi shakl — 8 sm va 4 sm li to'g'ri to'rtburchak: 8 + 4 + 8 + 4 = 24 sm.",hint:"Yangi shakl qanday? Uning bo'yi va eni qancha?",full:"Ikki kvadrat yonma-yon — to'g'ri to'rtburchak, bo'yi 4 + 4 = 8 sm, eni 4 sm. Perimetr: 8 + 4 + 8 + 4 = 24 sm. «32» — 16 + 16, tegib turgan tomonlar ham sanalgan."},
 tn:"Ikki qog'oz to'rtburchakni bolalar o'zi jips qo'yib, atrofini ip bilan o'lchasin. Olimpiadalarda tez-tez keladi."},
{h:"Ayyorlik: zinapoya shakl",sum:"Zinapoya shaklning zinalarini tashqariga sursak, to'g'ri to'rtburchak chiqadi — perimetri o'shanga teng.",a:"m07",
 start:function(){f5_stairs(0)},fin:function(){f5_stairs(1)},
 html:"<p>Katakli qog'ozda to'g'ri to'rtburchak va undan «tishlab olingan» zinapoya shakl. Qaysi birining perimetri katta? Tugmalarni bosing.</p>",
 btns:[["▭ To'g'ri to'rtburchak",function(c,done){f5_stairs(0);mvK(done,2)}],["⌐ Zinapoya shakl",function(c,done){f5_stairs(1);mvK(done,2)}]],g2:1,
 after:"<p>Zinapoyaning har bir gorizontal zinasini <b>yuqoriga</b>, vertikal zinasini <b>o'ngga</b> sursak — ular to'g'ri to'rtburchakning tomonlariga aylanadi. Demak perimetrlar <b>teng</b>: 26! Shakl kichrayib ketgan bo'lsa ham.</p>",
 q:{t:"Zinapoya shakl 8 × 5 katakli to'g'ri to'rtburchakdan burchagi «zina» qilib kesib olingan holda chizilgan. Uning perimetri qancha?",opts:["26","Kamroq, chunki shakl kichraydi","Ko'proq, chunki burchaklar ko'p","40"],ok:0,why:"Zinalarni surib chiqarsak, o'sha to'g'ri to'rtburchak: 8 + 5 + 8 + 5 = 26.",hint:"Zinalarni tashqariga surib ko'ring — qanday shakl chiqadi?",full:"Zinapoyaning tomonlarini surib, to'g'ri to'rtburchak tomonlariga aylantirish mumkin. Shuning uchun perimetr o'zgarmaydi: 26. «40» — bu kataklar soni (yuz), perimetr emas."},
 tn:"Bu — olimpiada usuli. Bolalar kataklarda zinapoya chizib, ikkala usulda sanasin va tengligiga ishonch hosil qilsin."},
{h:"Bilasizmi? «Perimetr» so'zi",sum:"«Perimetr» yunoncha: «peri» — atrofida, «metreo» — o'lchayman. Ya'ni «atrofini o'lchash».",a:"m08",
 start:function(){f5_hist(false)},fin:function(){f5_hist(true)},
 html:"<p>📜 «Perimetr» so'zi bizga <b>yunon</b> tilidan kelgan. Qadimgi dehqonlar o'z yerlarini o'rash uchun atrofini o'lchashgan. Tugmani bosing.</p>",
 btns:[["📜 So'zni ochish",function(c,done){f5_hist(true);done()}]],
 after:"<p><b>«Peri»</b> — atrofida, <b>«metreo»</b> — o'lchayman. Perimetr — «atrofini o'lchash». Shu so'zdan «metr» ham kelib chiqqan! Bugun ham perimetr hayotda kerak: bog'ga to'r, rasmga ramka, xonaga plintus olishda.</p>",
 tn:"Uyga vazifa: xonangizning yoki stol ustining perimetrini qadam yoki qarich bilan o'lchab keling."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){f5_walk(4)},fin:function(){f5_walk(4)},
 html:"<div class='memo'><ul><li><b>Perimetr</b> — shakl atrofining uzunligi = barcha tomonlar yig'indisi.</li><li>Uchburchak: 5 + 6 + 7 = 18 sm.</li><li>To'g'ri to'rtburchak: <b>bo'yi + eni + bo'yi + eni</b>: 8 + 5 + 8 + 5 = 26.</li><li>Kvadrat: 4 ta teng tomon: 9 + 9 + 9 + 9 = 36.</li><li>Noma'lum tomon = perimetr − ma'lum tomonlar.</li><li>«Eni bo'yidan … qisqa» — avval enini toping!</li><li>Shakllar birlashsa — tegib turgan tomonlar <b>sanalmaydi</b>.</li><li>Zinapoya shakl perimetri = uni o'rab turgan to'g'ri to'rtburchak perimetri.</li></ul></div>",
 tn:"Keyingi darsni «Perimetri 12 sm bo'lgan qanday to'g'ri to'rtburchaklar bor?» savoli bilan boshlang (5 va 1, 4 va 2, 3 va 3)."}
];
function f5_sq(k){clear();var g=S.g;if(k===0){E('rect',{x:50,y:40,width:260,height:90,fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);T(g,180,32,'8 sm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,180,150,'8 sm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,36,90,'5',{'font-size':13,'font-weight':800,fill:C.ok});T(g,324,90,'5',{'font-size':13,'font-weight':800,fill:C.ok});f5_msg('8 + 5 + 8 + 5 = <b>26 sm</b> — bo‘yi ikki marta, eni ikki marta')}
 else{E('rect',{x:125,y:30,width:110,height:110,fill:'#e6f6ee',stroke:C.ok,'stroke-width':3},g);[[180,24],[180,156],[112,90],[248,90]].forEach(function(p){T(g,p[0],p[1],'6',{'font-size':13,'font-weight':800,fill:C.ok})});f5_msg('Kvadrat: 6 + 6 + 6 + 6 = <b>24 sm</b> — to‘rtta teng tomon')}}
function f5_tri(k){clear();var g=S.g;E('polygon',{points:'70,140 160,30 300,140',fill:'#e8f1fb',stroke:C.blue,'stroke-width':3},g);T(g,100,82,'6 dm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,244,78,'4 dm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,185,158,k>=2?'5 dm':'?',{'font-size':14,'font-weight':800,fill:k>=2?C.ok:C.bad});
 f5_msg(k===0?'P = 15 dm. Tomonlar: 6 dm, 4 dm va ?':(k===1?'Ma’lum tomonlar: 6 + 4 = <b>10 dm</b>':'Uchinchi tomon: 15 − 10 = <b>5 dm</b>'))}
function f5_hist(on){clear('#f6ead0');var g=S.g;E('rect',{x:70,y:40,width:220,height:100,fill:'#d9e8c0',stroke:'#6b3d12','stroke-width':4,'stroke-dasharray':'2 6'},g);for(var x=70;x<=290;x+=27.5){E('line',{x1:x,y1:36,x2:x,y2:44,stroke:'#6b3d12','stroke-width':3},g);E('line',{x1:x,y1:136,x2:x,y2:144,stroke:'#6b3d12','stroke-width':3},g)}
 if(on){T(g,180,88,'peri + metreo',{'font-size':18,'font-weight':800,fill:'#6b3d12'});T(g,180,110,'atrofida + o‘lchayman',{'font-size':13,fill:'#6b3d12'})}f5_msg(on?'«Perimetr» — atrofini o‘lchash':'Dala atrofidagi devor — perimetr')}
var PROBS=[
{t:"Uchburchakning tomonlari 5 sm, 6 sm va 7 sm. Perimetri qancha?",o:["18 sm","13 sm","15 sm","11 sm"],k:0,s:"5 + 6 + 7 = 18 sm."},
{t:"Kvadratning tomoni 9 m. Perimetri qancha?",o:["36 m","27 m","18 m","81 m"],k:0,s:"9 + 9 + 9 + 9 = 36 m."},
{t:"To'g'ri to'rtburchakning bo'yi 8 sm, eni 5 sm. Perimetri qancha?",o:["26 sm","13 sm","40 sm","21 sm"],k:0,s:"8 + 5 + 8 + 5 = 26 sm."},
{t:"To'g'ri to'rtburchakning bo'yi 9 sm, eni bo'yidan 4 sm qisqa. Perimetri qancha?",o:["28 sm","26 sm","13 sm","18 sm"],k:0,s:"Eni 9 − 4 = 5. 9 + 5 + 9 + 5 = 28 sm."},
{t:"Bog'ning bo'yi 18 m, eni bo'yidan 6 m qisqa. Atrofini o'rash uchun necha metr to'r kerak?",o:["60 m","48 m","30 m","72 m"],k:0,s:"Eni 12 m. 18 + 12 + 18 + 12 = 60 m."},
{t:"Uchburchakning perimetri 15 dm, ikki tomoni 6 dm va 4 dm. Uchinchi tomoni?",o:["5 dm","10 dm","11 dm","25 dm"],k:0,s:"15 − (6 + 4) = 5 dm."},
{t:"Uchburchakning ikki teng tomoni 6 sm dan, perimetri 19 sm. Uchinchi tomoni?",o:["7 sm","6 sm","12 sm","13 sm"],k:0,s:"6 + 6 = 12, 19 − 12 = 7 sm."},
{t:"Teng tomonli uchburchakning har tomoni 7 sm. Perimetri?",o:["21 sm","14 sm","28 sm","49 sm"],k:0,s:"7 + 7 + 7 = 21 sm."},
{t:"Beshburchakning hamma tomonlari 6 sm dan. Perimetri?",o:["30 sm","24 sm","36 sm","11 sm"],k:0,s:"6 + 6 + 6 + 6 + 6 = 30 sm."},
{t:"Katakli qog'ozda 4 × 3 katakli to'g'ri to'rtburchak (1 katak = 1 sm). Perimetri?",o:["14 sm","12 sm","7 sm","10 sm"],k:0,s:"4 + 3 + 4 + 3 = 14 sm."},
{t:"Ikkita kvadrat (tomoni 4 sm) yonma-yon jips qo'yildi. Yangi shaklning perimetri?",o:["24 sm","32 sm","16 sm","20 sm"],k:0,s:"Yangi shakl 8 × 4: 8 + 4 + 8 + 4 = 24 sm."},
{t:"Ikkita to'g'ri to'rtburchak (6 sm va 3 sm) uzun tomonlari bilan jips qo'yildi. Yangi shakl perimetri?",o:["24 sm","36 sm","18 sm","30 sm"],k:0,s:"Yangi shakl 6 × 6 kvadrat: 6 + 6 + 6 + 6 = 24 sm."},
{t:"Rasm ramkasining uzun tomoni 10 sm, kalta tomoni 4 sm kam. Ramka perimetri?",o:["32 sm","26 sm","16 sm","40 sm"],k:0,s:"Kalta tomon 6. 10 + 6 + 10 + 6 = 32 sm."},
{t:"Uchburchakning bir tomoni 26 dm, ikkinchisi undan 8 dm uzun, uchinchisi ikkinchisidan 5 dm qisqa. Perimetri?",o:["89 dm","81 dm","60 dm","97 dm"],k:0,s:"Ikkinchisi 34, uchinchisi 29. 26 + 34 + 29 = 89 dm."},
{t:"Hovuzning uzunligi 46 m, eni uzunligidan 18 m qisqa. Hovuz atrofiga necha metr tasma kerak?",o:["148 m","74 m","128 m","184 m"],k:0,s:"Eni 28 m. 46 + 28 + 46 + 28 = 148 m."},
{t:"Uchburchakning tomonlari 7, 7 va 6 sm. Perimetri shu uchburchaknikiga teng kvadratning tomoni qancha?",o:["5 sm","6 sm","4 sm","20 sm"],k:0,s:"Uchburchak perimetri 20 sm. Kvadrat: 5 + 5 + 5 + 5 = 20, tomoni 5 sm."},
{t:"Kvadrat va to'g'ri to'rtburchak perimetrlari teng. Kvadrat tomoni 6 sm, to'g'ri to'rtburchak bo'yi 8 sm. Uning eni?",o:["4 sm","6 sm","8 sm","16 sm"],k:0,s:"Kvadrat perimetri 24. 8 + ? + 8 + ? = 24 → ? + ? = 8, eni 4 sm."},
{t:"Zinapoya shakl 6 × 4 katakli to'g'ri to'rtburchakdan bir burchagini zina qilib kesib olib chizildi. Perimetri qancha?",o:["20","kamroq","ko'proq","24"],k:0,s:"Zinalarni surib chiqarsak — o'sha to'g'ri to'rtburchak: 6 + 4 + 6 + 4 = 20."},
{t:"Sportchi to'g'ri to'rtburchak yo'lakni (300 m va 200 m) bir marta aylandi. Necha metr yugurdi?",o:["1000 m","500 m","600 m","2000 m"],k:0,s:"300 + 200 + 300 + 200 = 1000 m."},
{t:"Perimetri 12 sm bo'lgan to'g'ri to'rtburchakning bo'yi 4 sm. Eni qancha?",o:["2 sm","8 sm","4 sm","3 sm"],k:0,s:"4 + ? + 4 + ? = 12 → ? + ? = 4, eni 2 sm."}
];
function PRACT_STAGE(){f5_walk(4)}
var PREP_DATA={teach:["Perimetr — shakl atrofining uzunligi, tomonlar yig'indisi.","Katakli qog'ozda perimetrni sanash.","To'g'ri to'rtburchak va kvadrat perimetri.","Teskari masalalar: noma'lum tomon.","Tuzoqlar: «eni … qisqa», shakllarni birlashtirish, zinapoya shakl."],
 mist:["Faqat ikkita tomonni qo'shadi (bo'yi + eni).","«4 sm qisqa» sonini eni deb oladi.","Birlashgan shakllarda ichki tomonlarni ham sanaydi.","Katakli shaklda kataklar sonini (yuzni) perimetr deb aytadi."],
 need:["Ip, chizg'ich, katakli qog'oz.","Qog'oz to'g'ri to'rtburchaklar (birlashtirish uchun)."],
 board:["P = barcha tomonlar yig'indisi.","<span class='w2'>8 + 5 + 8 + 5 = 26</span>.","Kvadrat: <span class='w2'>9 + 9 + 9 + 9 = 36</span>.","Noma'lum: <span class='w2'>15 − (6 + 4) = 5</span>.","Eni: <span class='w2'>9 − 4 = 5</span>, keyin P.","Birlashtirish: <span class='w2'>36 emas, 24</span>."]};
