var CODE='4J11',TITLE="4-sinf · Kombinatorika va oddiy ehtimollik";
function c11L(a,b,c,d,col,w){E('line',{x1:a,y1:b,x2:c,y2:d,stroke:col||'#2a4a6a','stroke-width':w||1.6},S.g)}
function c11Tree(){clear();var g=S.g,K=['#e57373','#64b5f6','#81c784'];T(g,24,90,'start',{'font-size':10,'font-weight':700,fill:'#3a4a5a'});
 for(var i=0;i<3;i++){var y1=34+i*50;c11L(44,86,110,y1);E('rect',{x:104,y:y1-9,width:18,height:18,rx:3,fill:K[i]},g);for(var j=0;j<4;j++){var y2=y1-15+j*10;c11L(124,y1,196,y2,'#9aa7b4',1.2);E('rect',{x:198,y:y2-3.5,width:14,height:7,rx:2,fill:'#5c6bc0'},g);for(var k=0;k<2;k++){c11L(214,y2,250,y2-2+k*4,'#c3cbd3',1)}}}
 T(g,112,168,'3 ko‘ylak',{'font-size':10,'font-weight':700,fill:'#3a4a5a'});T(g,206,168,'4 shim',{'font-size':10,'font-weight':700,fill:'#3a4a5a'});T(g,300,90,'· 2 poyabzal',{'font-size':12,'font-weight':800,fill:C.blue})}
function c11Cards(){clear();['0','1','2','3'].forEach(function(d,i){E('rect',{x:70+i*58,y:40,width:44,height:56,rx:8,fill:'#fff',stroke:'#2a4a6a','stroke-width':1.6},S.g);T(S.g,92+i*58,77,d,{'font-size':24,'font-weight':800,fill:d==='0'?C.bad:'#1d2b3a'})});T(S.g,180,130,'□ □ □ — takrorlanmas uch xonali son',{'font-size':12,'font-weight':800,fill:'#3a4a5a'})}
function c11Poly(n){clear();var cx=180,cy=86,R=66,P=[];for(var i=0;i<n;i++){var a=-Math.PI/2+i*2*Math.PI/n;P.push([cx+R*Math.cos(a),cy+R*Math.sin(a)])}for(var i2=0;i2<n;i2++)for(var j=i2+1;j<n;j++)c11L(P[i2][0],P[i2][1],P[j][0],P[j][1],C.blue,1.3);P.forEach(function(p,i){E('circle',{cx:p[0],cy:p[1],r:11,fill:C.a,stroke:'#8a5a24'},S.g);T(S.g,p[0],p[1]+4,String.fromCharCode(65+i),{'font-size':11,'font-weight':800,fill:'#1d2b3a'})})}
function c11Bag(){clear();E('path',{d:'M110,40 Q90,150 180,154 Q270,150 250,40 Z',fill:'#f6e6c9',stroke:'#8a5a24','stroke-width':2},S.g);var B=[[140,80,1],[175,70,0],[210,82,1],[150,112,0],[185,104,0],[220,118,1],[165,136,0],[200,138,0]];B.forEach(function(b){E('circle',{cx:b[0],cy:b[1],r:12,fill:b[2]?C.bad:C.b,stroke:'#33415a'},S.g)});T(S.g,310,80,'3 qizil',{'font-size':13,'font-weight':800,fill:C.bad});T(S.g,310,102,'5 ko‘k',{'font-size':13,'font-weight':800,fill:C.blue})}
function c11Dice(hl){clear();var s=19,x0=100,y0=16;for(var a=1;a<=6;a++){T(S.g,x0+(a-1)*s+s/2,y0+10,String(a),{'font-size':10,'font-weight':800,fill:C.blue});T(S.g,x0-8,y0+14+a*s,String(a),{'font-size':10,'font-weight':800,fill:C.blue})}for(var i=1;i<=6;i++)for(var j=1;j<=6;j++){var on=hl&&i+j===hl;E('rect',{x:x0+(j-1)*s,y:y0+16+(i-1)*s,width:s-1,height:s-1,fill:on?'#ffe9a8':'#fff',stroke:'#c9d3dd'},S.g);T(S.g,x0+(j-1)*s+s/2,y0+29+(i-1)*s,String(i+j),{'font-size':9,'font-weight':700,fill:on?C.bad:'#3a4a5a'})}T(S.g,300,70,'36 ta',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});T(S.g,300,90,'teng imkoniyat',{'font-size':11,'font-weight':700,fill:'#3a4a5a'})}
var STEPS=[
J4({h:"Ko'paytirish qoidasi",sum:"3 ko'ylak × 4 shim × 2 poyabzal: har tanlov keyingi har tanlov bilan birlashadi → 3 · 4 · 2 = 24.",a:"m01",
 s:c11Tree,m:"Har ko‘ylakdan 4 ta shim shoxi, har shimdan 2 ta poyabzal shoxi",f:function(){c11Tree();j3Msg('3 · 4 · 2 = <b>24</b> xil kiyinish')},
 html:"<p>Alida 3 ta ko'ylak, 4 ta shim va 2 juft poyabzal bor. U necha xil usulda kiyinishi mumkin (bitta ko'ylak, bitta shim, bitta poyabzal)?</p>",
 ch:["24","9","12","48"],ok:0,bad:["","3 + 4 + 2 = 9 — qo‘shish emas, har biri har biri bilan birlashadi","3 · 4 = 12 — poyabzalni unutdingiz","Qayta hisoblang: 3 · 4 · 2"],
 after:"<p>Tanlovlar daraxti: 3 ta shox (ko'ylak), har biridan 4 ta (shim) → 12, har biridan 2 ta (poyabzal) → 24. Qoida: ketma-ket mustaqil tanlovlar soni <b>ko'paytiriladi</b>. Bitta guruhdan tanlasak (yoki ko'ylak, yoki shim) — qo'shiladi.</p>",
 q:{t:"A shahardan B ga 3 ta yo'l, B dan C ga 4 ta yo'l bor. A dan C ga (B orqali) necha xil yo'l bilan borish mumkin?",opts:["12","7","6","24"],ok:0,why:"3 · 4 = 12.",hint:"Har A–B yo'lini har B–C yo'li bilan birlashtiring.",full:"Birinchi qism — 3 tanlov, ikkinchisi — 4: 3 · 4 = 12. «7» — qo'shish xatosi."},
 tn:"Daraxt diagrammasini doskada chizing; bolalar o'z kiyimlari bilan masala tuzsin."}),
J4({h:"Raqamlardan sonlar: nol tuzog'i",sum:"0, 1, 2, 3 dan takrorlanmas uch xonali son: 1-xona — 3 (nol emas), 2-xona — 3 (nol endi mumkin), 3-xona — 2: 18.",a:"m02",
 s:c11Cards,m:"Birinchi raqam 0 bo‘lishi mumkin emas!",f:function(){c11Cards();j3Msg('3 · 3 · 2 = <b>18</b>')},
 html:"<p>0, 1, 2, 3 raqamlaridan (har raqam bir martadan) nechta <b>uch xonali</b> son tuzish mumkin?</p>",
 ch:["18","24","27","12"],ok:0,bad:["","4 · 3 · 2 = 24 — 0 bilan boshlanadiganlari ham sanaldi (023 — uch xonali emas)","27 — raqamlar takrorlansa ham, 0 bilan boshlanmasa","Ikkinchi xonaga 0 ham qo‘yilishi mumkin: 3 ta tanlov"],
 after:"<p>Yuzlar xonasi: 1, 2, 3 — 3 tanlov (0 emas). O'nlar xonasi: qolgan 3 raqam (endi 0 ham bor) — 3 tanlov. Birlar xonasi: 2 tanlov. 3 · 3 · 2 = <b>18</b>. Boshqa yo'l: hammasi 4 · 3 · 2 = 24, 0 bilan boshlanadiganlar 3 · 2 = 6, 24 − 6 = 18.</p>",
 q:{t:"1, 2, 3, 4 raqamlaridan (takrorlanmasdan) nechta ikki xonali juft son tuzish mumkin?",opts:["6","12","8","4"],ok:0,why:"Oxiri 2 yoki 4 (2 tanlov), boshi qolgan 3 tadan: 6.",hint:"Avval eng «qattiq» shartli xonani tanlang — birlar xonasini.",full:"Birlar xonasi 2 yoki 4 — 2 tanlov; o'nlar xonasi qolgan 3 raqamdan: 2 · 3 = 6 (12, 32, 42, 14, 24, 34)."},
 tn:"Shartli xonadan boshlash qoidasini ta'kidlang. Raqamli kartochkalar bilan hammasini terib tekshiring."}),
J4({h:"Turnir: har biri har biri bilan",sum:"6 jamoa: har biri 5 ta o'yin, 6 · 5 = 30, lekin har o'yin ikki marta sanaldi: 15.",a:"m03",
 s:function(){c11Poly(6)},m:"Har chiziq — bitta o‘yin",f:function(){c11Poly(6);j3Msg('6 · 5 : 2 = <b>15</b> chiziq')},
 html:"<p>6 ta jamoa turnirda har biri boshqasi bilan bir martadan o'ynaydi. Jami nechta o'yin bo'ladi?</p>",
 ch:["15","30","36","6"],ok:0,bad:["","30 — har o‘yin ikki marta sanaldi (A–B va B–A)","6 · 6 = 36 — jamoa o‘zi bilan o‘ynamaydi","6 — jamoalar soni"],
 after:"<p>Har jamoa 5 ta o'yin o'ynaydi: 6 · 5 = 30. Lekin A–B o'yini A da ham, B da ham sanaldi → 30 : 2 = <b>15</b>. Yoki tartib bilan: 5 + 4 + 3 + 2 + 1 = 15. Bu 4J03 dagi kesmalar masalasining o'zi.</p>",
 q:{t:"8 o'quvchi har biri boshqasi bilan bir marta qo'l berib ko'rishdi. Nechta qo'l berish bo'ldi?",opts:["28","56","64","16"],ok:0,why:"8 · 7 : 2 = 28.",hint:"Har kim nechta odam bilan ko'rishadi?",full:"Har o'quvchi 7 kishi bilan: 8 · 7 = 56, har ko'rishish ikki marta sanaldi: 28."},
 tn:"Sinfda 5 o'quvchini chiqarib, haqiqatan qo'l berishtiring va sanang (10)."}),
J4({h:"Tartib muhimmi?",sum:"5 kishidan 2 navbatchi (tartib muhim emas): 5 · 4 : 2 = 10. Sardor va o'rinbosar (tartib muhim): 5 · 4 = 20.",a:"m04",
 s:['5 kishi: A, B, C, D, E','2 navbatchi tanlash'],so:{fs:18,lh:44},m:"A va B navbatchi = B va A navbatchi — bir xil!",
 f:['tartib bilan: 5 · 4 = 20','AB = BA → 20 : 2 = [10]'],fso:{fs:18,lh:44},fm:"Navbatchilar teng — tartib yo‘q",
 html:"<p>Sinfda 5 kishi. Ulardan 2 ta navbatchi necha usulda tanlanishi mumkin (ikkalasi bir xil vazifada)?</p>",
 ch:["10","20","25","5"],ok:0,bad:["","20 — bu sardor va o‘rinbosar (vazifalari har xil) bo‘lganda","5 · 5 = 25 — bir kishi ikki marta tanlana olmaydi","5 — kishilar soni"],
 after:"<p>Agar vazifalar har xil bo'lsa (sardor va o'rinbosar), AB va BA — boshqa-boshqa: 5 · 4 = 20. Agar teng bo'lsa (ikki navbatchi), AB = BA, shuning uchun 2 ga bo'lamiz: <b>10</b>. Har masalada so'rang: <b>tartib muhimmi?</b></p>",
 q:{t:"Shu 5 kishidan sardor va o'rinbosar necha usulda tanlanadi?",opts:["20","10","25","9"],ok:0,why:"Sardor — 5 tanlov, o'rinbosar — 4: 20.",hint:"Bu yerda vazifalar har xil — tartib muhim.",full:"5 · 4 = 20. «10» — tartibni hisobga olmaslik xatosi."},
 tn:"Ikki kartochka («sardor», «o'rinbosar») va bitta («navbatchi» ×2) bilan farqni o'ynab ko'rsating."}),
J4({h:"Ehtimollik: qopdagi sharlar",sum:"8 ta shardan 3 tasi qizil. Har shar chiqishi teng imkonli: qizil chiqish ehtimoli 3/8.",a:"m05",
 s:c11Bag,m:"Ehtimollik = qulay holatlar : barcha holatlar",f:function(){c11Bag();j3Msg('Qizil: 3 ta, jami 8 ta → <b>3/8</b>')},
 html:"<p>Qopda 3 ta qizil va 5 ta ko'k shar bor. Qaramasdan bitta shar olinadi. <b>Qizil</b> shar chiqish ehtimoli qancha?</p>",
 ch:["3/8","3/5","1/3","5/8"],ok:0,bad:["","3/5 — qizilni ko‘kka solishtirdingiz; jami sharlarga bo‘lish kerak","1/3? Sharlar 3 ta emas, 8 ta","5/8 — bu ko‘k chiqish ehtimoli"],
 after:"<p>Barcha holatlar — 8 ta (har shar bir xil imkoniyatga ega). Qulay holatlar — 3 ta qizil. Ehtimollik = 3/8. Ko'k chiqishi 5/8. Ikkalasi birga: 3/8 + 5/8 = 1 — nimadir albatta chiqadi.</p>",
 q:{t:"Zar tashlandi. 5 dan katta son chiqish ehtimoli qancha?",opts:["1/6","2/6","1/5","5/6"],ok:0,why:"Faqat 6 — 1 ta qulay holat 6 tadan.",hint:"5 dan katta sonlar qaysilar?",full:"5 dan katta: faqat 6. 1 qulay, 6 barcha: 1/6. «2/6» — 5 ni ham qo'shish xatosi."},
 tn:"Qop va rangli sharlar (yoki qog'ozchalar) bilan 40 marta tajriba: qizil necha marta chiqdi? Natijani 3/8 bilan solishtiring."}),
J4({h:"Tuzoq: ikki zar yig'indisi",sum:"Ikki zarda 36 ta teng imkonli juftlik. Yig'indi 7 — 6 usulda (eng ko'p), 2 va 12 — 1 usuldan.",a:"m06",
 s:function(){c11Dice(0)},m:"Har katak — bir juftlik (1-zar, 2-zar)",f:function(){c11Dice(7);j3Msg('7 — diagonal bo‘ylab 6 ta katak: 6/36')},
 html:"<p>Ikkita zar tashlanib, sonlar qo'shiladi. Qaysi yig'indi <b>eng ko'p</b> chiqadi?</p>",
 ch:["7","6","12","2"],ok:0,bad:["","6 — 5 usulda; jadvalda bittasi ko‘proq bor","12 — faqat 6 + 6: bitta usul","2 — faqat 1 + 1: bitta usul"],
 after:"<p>2 dan 12 gacha 11 xil yig'indi bor, lekin ular <b>teng imkonli emas</b>! 36 ta juftlikning 6 tasida yig'indi 7: (1,6), (2,5), (3,4), (4,3), (5,2), (6,1). Ehtimoli 6/36. 12 esa faqat (6,6): 1/36. Teng imkonli holatlarni to'g'ri tanlash — ehtimollikning eng muhim qadami.</p>",
 q:{t:"Ikki zar tashlandi. Yig'indi 12 bo'ladigan juftliklar nechta (36 tadan)?",opts:["1","2","6","12"],ok:0,why:"Faqat (6, 6).",hint:"Qaysi ikki son qo'shilsa 12 bo'ladi?",full:"Har zarda eng kattasi 6: faqat 6 + 6. 1 ta juftlik — ehtimoli 1/36."},
 tn:"Juft-juft bo'lib 36 marta ikki zar tashlang, yig'indilarni chiziqli diagrammaga belgilang — 7 eng balandi chiqadi."}),
J4info({h:"Bilasizmi? Ehtimollik o'yindan tug'ilgan",a:"m07",s:function(){c11Dice(7)},m:"1654-yil: Paskal va Ferma",
 html:"<p>🎲 1654-yilda fransuz olimlari <b>Blez Paskal</b> va <b>Per Ferma</b> o'rtasidagi xatlarda o'yin to'xtatilganda yutuqni qanday adolatli bo'lish masalasi hal qilingan. Shu yozishmalar ehtimollar nazariyasining boshlanishi hisoblanadi. Bugun undan ob-havo prognozida, sug'urtada, tibbiyotda foydalaniladi.</p>",
 tn:"«Ertaga yomg'ir yog'ish ehtimoli 70%» degani nima? — sinfda muhokama qiling."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:c11Tree,m:"Ketma-ket tanlovlar — ko‘paytiriladi",
 html:"<div class='memo'><ul><li>Ketma-ket tanlovlar: <b>ko'paytiramiz</b>; yoki-yoki: qo'shamiz.</li><li>Raqamlardan son: 0 birinchi xonada emas; shartli xonadan boshlang.</li><li>Har biri har biri bilan: n · (n − 1) : 2.</li><li>Tartib muhim (sardor, o'rinbosar) — 2 ga bo'lmaymiz; muhim emas — bo'lamiz.</li><li>Ehtimollik = qulay : barcha (teng imkonli holatlar).</li><li>Ikki zar: 36 juftlik, 7 — eng ko'p.</li></ul></div>",
 tn:"Uyga: oila bilan 20 marta tanga tashlab, gerb necha marta tushganini yozib kelish."})
];
var PROBS=[
{t:"2 ta shapka va 3 ta sharf bor. Nechta xil to'plam (1 shapka + 1 sharf) tuzish mumkin?",o:["6","5","8","9"],k:0,s:"2 · 3 = 6."},
{t:"A dan B ga 4 ta yo'l, B dan C ga 3 ta yo'l. A dan C ga borib, qaytib kelish (B orqali, istalgan yo'llar bilan) necha usulda mumkin?",o:["144","24","12","49"],k:0,s:"Borish 4 · 3 = 12, qaytish ham 12: 12 · 12 = 144."},
{t:"1, 2, 3 raqamlaridan (takrorlanmasdan) nechta uch xonali son tuzish mumkin?",o:["6","9","27","3"],k:0,s:"3 · 2 · 1 = 6."},
{t:"1, 2, 3 raqamlaridan (raqamlar takrorlanishi mumkin) nechta uch xonali son tuzish mumkin?",o:["27","6","9","18"],k:0,s:"3 · 3 · 3 = 27."},
{t:"0, 1, 2 raqamlaridan (takrorlanmasdan) nechta uch xonali son tuzish mumkin?",o:["4","6","3","9"],k:0,s:"Birinchi xona 1 yoki 2: 2 · 2 · 1 = 4 (102, 120, 201, 210)."},
{t:"5 kishi qatorga necha xil tartibda turishi mumkin?",o:["120","25","60","15"],k:0,s:"5 · 4 · 3 · 2 · 1 = 120."},
{t:"4 ta har xil kitobni javonga necha xil tartibda terish mumkin?",o:["24","16","12","10"],k:0,s:"4 · 3 · 2 · 1 = 24."},
{t:"7 ta jamoa har biri boshqasi bilan bir martadan o'ynadi. Nechta o'yin bo'ldi?",o:["21","42","49","14"],k:0,s:"7 · 6 : 2 = 21."},
{t:"Tekislikda 5 ta nuqta, hech qaysi uchtasi bir to'g'ri chiziqda emas. Uchlari shu nuqtalarda bo'lgan nechta uchburchak bor?",o:["10","15","20","5"],k:0,s:"5 · 4 · 3 = 60 tartibli uchlik, har uchburchak 6 marta sanalgan: 10."},
{t:"4 kishidan 2 kishilik guruh necha usulda tanlanadi?",o:["6","12","8","4"],k:0,s:"4 · 3 : 2 = 6."},
{t:"4 kishidan sardor va o'rinbosar necha usulda tanlanadi?",o:["12","6","16","8"],k:0,s:"4 · 3 = 12."},
{t:"Tanga tashlandi. Gerb tushish ehtimoli qancha?",o:["1/2","1/3","1/4","2/3"],k:0,s:"2 ta teng imkonli holatdan 1 ta."},
{t:"Qutida 2 oq, 3 qora va 5 qizil shar. Qaramasdan bitta olinadi. Qora shar chiqish ehtimoli?",o:["3/10","3/7","1/3","3/5"],k:0,s:"Jami 10 ta, qora 3 ta: 3/10."},
{t:"Zar tashlandi. Juft son chiqish ehtimoli qancha?",o:["1/2","1/3","1/6","2/3"],k:0,s:"2, 4, 6 — 3 ta 6 tadan: 3/6 = 1/2."},
{t:"Ikki tanga tashlandi. Ikkalasida ham gerb tushish ehtimoli qancha?",o:["1/4","1/2","1/3","2/3"],k:0,s:"GG, GR, RG, RR — 4 ta teng imkonli holat, qulay 1 ta."},
{t:"Ikki zar tashlandi. Yig'indi 7 bo'ladigan juftliklar nechta?",o:["6","7","3","12"],k:0,s:"(1,6), (2,5), (3,4), (4,3), (5,2), (6,1)."},
{t:"Ikki zar tashlandi. Yig'indi 10 bo'ladigan juftliklar nechta?",o:["3","4","2","6"],k:0,s:"(4,6), (5,5), (6,4)."},
{t:"Qutida 4 ta qizil va bir nechta ko'k shar. Qizil shar chiqish ehtimoli 1/3. Qutida nechta ko'k shar bor?",o:["8","12","4","9"],k:0,s:"Jami 4 · 3 = 12, ko'k 12 − 4 = 8."},
{t:"Raqamlari har xil bo'lgan nechta ikki xonali son bor?",o:["81","90","72","100"],k:0,s:"O'nlar 9 tanlov (1–9), birlar 9 tanlov (0–9 dan biri ishlatilgan): 81."},
{t:"Sinfda 10 o'quvchi. Sardor, o'rinbosar va kotib (har xil kishilar) necha usulda tanlanadi?",o:["720","30","1000","120"],k:0,s:"10 · 9 · 8 = 720."}
];
function PRACT_STAGE(){c11Dice(7)}
var PREP_DATA={teach:["Ko'paytirish qoidasi va tanlovlar daraxti.","Raqamlardan sonlar: 0 tuzog'i, shartli xonadan boshlash.","Har biri har biri bilan: n · (n − 1) : 2.","Tartib muhim / muhim emas.","Klassik ehtimollik: qulay : barcha; ikki zar."],
 mist:["Tanlovlarni qo'shadi (ko'paytirish o'rniga).","0 bilan boshlanadigan «sonlarni» sanaydi.","Ehtimollikda qulayni noqulayga bo'ladi (3/5 o'rniga 3/8).","Ikki zar yig'indilarini teng imkonli deb hisoblaydi."],
 need:["Raqamli kartochkalar.","Rangli sharlar va qop.","Zarlar va tangalar."],
 board:["ketma-ket → ×","n · (n − 1) : 2","ehtimollik = qulay : barcha","ikki zar: 36, yig'indi 7 — 6 ta"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
