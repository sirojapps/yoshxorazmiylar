var CODE='3M1',TITLE='3-sinf · To‘plam, qismto‘plam, tegishlilik';
function m1msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// narsalar: [nom, rang, meva?]
var M1I=[['olma','#e0584f',1],['sabzi','#f08a24',0],['nok','#c5d65a',1],['piyoz','#d9b38c',0],['uzum','#8e6bbf',1],['karam','#7fbf6a',0],['anor','#b03a48',1],['bodring','#4f9d53',0]];
function m1ring(g,cx,cy,rx,ry,lab,col){E('ellipse',{cx:cx,cy:cy,rx:rx,ry:ry,fill:'rgba(47,111,181,.06)',stroke:col||C.blue,'stroke-width':3},g);if(lab)T(g,cx,cy-ry-6,lab,{'font-size':12,'font-weight':800,fill:col||C.blue})}
function m1chip(g,x,y,t,col,o){o=o||{};var w=Math.max(44,t.length*8+14);var gg=E('g',{style:o.tap?'cursor:pointer':''},g);E('rect',{x:x-w/2,y:y-13,width:w,height:26,rx:13,fill:o.dim?'#eef1f4':'#fff',stroke:o.dim?'#cfd8e3':col,'stroke-width':2},gg);E('circle',{cx:x-w/2+12,cy:y,r:6,fill:o.dim?'#cfd8e3':col},gg);T(gg,x+6,y+4,t,{'font-size':11,'font-weight':700,fill:o.dim?'#9aa7b4':'#33475b'});if(o.tap)gg.addEventListener('click',o.tap);return gg}
function m1s1(){clear();var g=S.g;m1ring(g,262,90,86,66,'M — mevalar');var inn=0,out=0;
 M1I.forEach(function(it,i){var on=S.in1[i];if(on){var x=222+(inn%2)*80,y=62+Math.floor(inn/2)*34;inn++;m1chip(g,x,y,it[0],it[1])}else{var x2=40+(out%2)*78,y2=22+Math.floor(out/2)*34;out++;m1chip(g,x2,y2,it[0],it[1],{tap:function(){m1t1(i)}})}})}
function m1t1(i){if(!S.d1)return;var it=M1I[i];if(!it[2]){m1msg('<b>'+it[0]+'</b> — sabzavot, mevalar to‘plamiga tegishli emas');return}S.in1[i]=1;m1s1();var n=M1I.filter(function(x,k){return x[2]&&S.in1[k]}).length;m1msg('M = { '+M1I.filter(function(x,k){return S.in1[k]}).map(function(x){return x[0]}).join(', ')+' } — '+n+' / 4');if(n===4){var d=S.d1;S.d1=null;d()}}
function m1setTxt(a){return '{ '+a.join(', ')+' }'}
// sonlar 1..12 bosiladigan
function m1nums(sel,o){o=o||{};clear();var g=S.g;m1ring(g,180,130,166,32,o.lab||'');for(var n=1;n<=12;n++){(function(n){var x=30+((n-1)%6)*60,y=24+Math.floor((n-1)/6)*44,on=sel.indexOf(n)>=0;var gg=E('g',{style:'cursor:pointer'},g);
  if(on){x=40+sel.indexOf(n)*56;y=130}E('circle',{cx:x,cy:y,r:17,fill:on?'#dff3e3':'#fff',stroke:on?C.ok:'#9aa7b4','stroke-width':2},gg);T(gg,x,y+5,''+n,{'font-size':14,'font-weight':800});if(o.tap&&!on)gg.addEventListener('click',function(){o.tap(n)})})(n)}}
function m1t6(n){if(!S.d6)return;if(n%2){m1msg('<b>'+n+'</b> — toq son, 2 ga bo‘linmaydi');return}if(S.s6.indexOf(n)<0)S.s6.push(n);S.s6.sort(function(a,b){return a-b});m1nums(S.s6,{tap:m1t6,lab:'J — juft sonlar'});m1msg('J = '+m1setTxt(S.s6)+' — '+S.s6.length+' / 6');if(S.s6.length===6){var d=S.d6;S.d6=null;d()}}
var P2=[function(){clear();var g=S.g;m1ring(g,180,88,150,62,'A = { 2, 4, 6, 8 }');[2,4,6,8].forEach(function(n,i){E('circle',{cx:90+i*60,cy:88,r:17,fill:'#dff3e3',stroke:C.ok,'stroke-width':2},g);T(g,90+i*60,93,''+n,{'font-size':14,'font-weight':800})});m1msg('A to‘plamning elementlari: 2, 4, 6, 8')},
 function(){P2[0]();var g=S.g;E('circle',{cx:150,cy:88,r:22,fill:'none',stroke:C.bad,'stroke-width':3},g);m1msg('6 — A ning elementi: <b>6 ∈ A</b> («6 A ga tegishli»)')},
 function(){P2[0]();var g=S.g;E('circle',{cx:340,cy:30,r:17,fill:'#fff',stroke:C.bad,'stroke-width':2},g);T(g,340,35,'5',{'font-size':14,'font-weight':800,fill:C.bad});m1msg('5 A da yo‘q: <b>5 ∉ A</b> («5 A ga tegishli emas»)')}];
var P3=[function(){clear();var g=S.g;T(g,180,40,'«MAKTAB» so‘zining harflari',{'font-size':13,'font-weight':800,fill:C.blue});'MAKTAB'.split('').forEach(function(c,i){E('rect',{x:80+i*36,y:60,width:30,height:34,rx:5,fill:'#fff',stroke:'#9aa7b4'},g);T(g,95+i*36,83,c,{'font-size':16,'font-weight':800})});m1msg('6 ta harf. To‘plamda nechta element?')},
 function(){P3[0]();var g=S.g;[1,4].forEach(function(i){E('rect',{x:80+i*36,y:60,width:30,height:34,rx:5,fill:'#f9d0d0',stroke:C.bad,'stroke-width':2},g);T(g,95+i*36,83,'A',{'font-size':16,'font-weight':800,fill:C.bad})});m1msg('A harfi <b>ikki marta</b> uchraydi')},
 function(){P3[0]();var g=S.g;m1ring(g,180,135,130,24,'');T(g,180,140,'{ M, A, K, T, B }',{'font-size':15,'font-weight':800,fill:C.ok});m1msg('To‘plamda har element <b>bir marta</b> yoziladi: 5 ta element')}];
var P4=[function(){clear();var g=S.g;m1ring(g,180,88,160,70,'M — mevalar');['olma','nok','uzum','anor','shaftoli'].forEach(function(t,i){m1chip(g,70+(i%3)*110,60+Math.floor(i/3)*50,t,'#e0584f')});m1msg('M = { olma, nok, uzum, anor, shaftoli }')},
 function(){clear();var g=S.g;m1ring(g,180,88,160,70,'M — mevalar');m1ring(g,122,88,92,44,'Q — qizil mevalar',C.bad);['olma','anor'].forEach(function(t,i){m1chip(g,92+i*64,92,t,'#e0584f')});['nok','uzum','shaftoli'].forEach(function(t,i){m1chip(g,268,52+i*34,t,'#e08a3c')});m1msg('Q = { olma, anor } — Q ning hamma elementlari M da')},
 function(){P4[1]();m1msg('Q — M ning <b>qismto‘plami</b>: <b>Q ⊂ M</b>')}];
var P7=[function(){clear();var g=S.g;m1ring(g,180,88,160,70,'H — hayvonlar');m1ring(g,126,92,90,44,'Q — qushlar',C.bad);['qarg‘a','burgut'].forEach(function(t,i){m1chip(g,96+i*66,96,t,'#2f6fb5')});['it','mushuk'].forEach(function(t,i){m1chip(g,276,70+i*36,t,'#e08a3c')});m1msg('Har bir qush — hayvon. Qaysi yozuv to‘g‘ri?')},
 function(){P7[0]();m1msg('<b>Q ⊂ H</b> ✓ — qushlar hayvonlarning qismi')},
 function(){P7[0]();var g=S.g;m1chip(g,300,24,'it',C.bad);m1msg('<b>H ⊂ Q</b> ✗ — it hayvon, lekin qush emas!')}];
var P8=[function(){clear();var g=S.g;T(g,180,24,'A = { a, b } ning qismto‘plamlari',{'font-size':13,'font-weight':800,fill:C.blue});m1msg('Ichida nechta qismto‘plam bor? Sanaymiz')},
 function(){P8[0]();var g=S.g;[['{ a }',100],['{ b }',260]].forEach(function(q){m1ring(g,q[1],70,50,22,'');T(g,q[1],75,q[0],{'font-size':14,'font-weight':800})});m1msg('Bitta elementli: { a }, { b }')},
 function(){P8[1]();var g=S.g;m1ring(g,100,130,50,22,'');T(g,100,135,'{ a, b }',{'font-size':14,'font-weight':800});m1ring(g,260,130,50,22,'');T(g,260,135,'∅',{'font-size':16,'font-weight':800,fill:C.bad});m1msg('To‘plamning o‘zi { a, b } va bo‘sh to‘plam ∅ ham — jami <b>4</b> ta')}];
var STEPS=[
{h:"To'plam nima?",sum:"Umumiy belgisi bor narsalar birgalikda to'plam bo'ladi; ular — to'plam elementlari.",a:"m01",
 start:function(){S.in1=[];m1s1();m1msg('Faqat mevalarni M to‘plamga soling')},fin:function(){S.in1=M1I.map(function(x){return x[2]});m1s1();m1msg('M = { olma, nok, uzum, anor }')},
 act:function(c,done){S.d1=done},
 html:"<p>Savatda meva va sabzavotlar aralash. Chapdagi nomlardan faqat <b>mevalarni</b> bosib, «Mevalar» to'plamiga soling.</p>",
 after:"<p>Umumiy belgisi («meva») bo'yicha yig'ilgan narsalar — <b>to'plam</b>. Olma, nok, uzum, anor — uning <b>elementlari</b>. To'plam katta harf bilan belgilanadi va elementlar figurali qavsda yoziladi: <b>M = { olma, nok, uzum, anor }</b>.</p>",
 q:{t:"Qaysi narsa «Haftaning kunlari» to'plamiga tegishli EMAS?",opts:["Seshanba","Juma","Mart","Yakshanba"],ok:2,why:"Mart — oy nomi, hafta kuni emas.",hint:"Haftada qaysi kunlar bor?",full:"Seshanba, juma, yakshanba — hafta kunlari. Mart — yil oyi, u «oylar» to'plamiga tegishli."},
 tn:"Sinfdagi narsalar bilan to'plam tuzing: «qizil narsalar», «yozuv buyumlari». Arqon halqasi to'plam chegarasi bo'ladi (Montessori)."},
{h:"Tegishli: ∈ va ∉",sum:"6 ∈ A — 6 A ning elementi; 5 ∉ A — 5 A ning elementi emas.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>To'plamga tegishlilikni qisqa belgilar bilan yozamiz:</p>",
 btns:[phaser(P2)],
 after:"<p><b>∈</b> — «tegishli»: 6 ∈ A. <b>∉</b> — «tegishli emas»: 5 ∉ A. Belgining chap tomonida <b>element</b>, o'ng tomonida <b>to'plam</b> turadi.</p>",
 q:{t:"B = { 1, 3, 5, 7 }. Qaysi yozuv to'g'ri?",opts:["3 ∉ B","4 ∈ B","7 ∈ B","5 ∉ B"],ok:2,why:"7 — B ning elementi.",hint:"Har bir son B ichida bormi?",full:"7 B da bor — 7 ∈ B to'g'ri. 3 va 5 B da bor, shuning uchun «∉» xato. 4 B da yo'q, «4 ∈ B» xato."},
 tn:"∈ belgisini «E» harfiga o'xshatib «Element» so'zi bilan bog'lang."},
{h:"Elementlar takrorlanmaydi",sum:"To'plamda har bir element faqat bir marta yoziladi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>«MAKTAB» so'zidagi harflar to'plamini tuzamiz. Unda nechta element bo'ladi?</p>",
 btns:[phaser(P3)],
 after:"<p>To'plamda bir xil element <b>takrorlanmaydi</b>. «MAKTAB» da 6 ta harf, lekin A ikki marta — to'plamda 5 ta element: { M, A, K, T, B }. Elementlar tartibi ham muhim emas.</p>",
 q:{t:"«KITOBXONA» so'zidagi harflar to'plamida nechta element?",opts:["9","8","7","6"],ok:1,why:"K, I, T, O, B, X, N, A — O takrorlanadi.",hint:"Qaysi harf ikki marta uchraydi?",full:"K-I-T-O-B-X-O-N-A — 9 ta harf, O ikki marta. To'plam: { K, I, T, O, B, X, N, A } — 8 ta element."},
 tn:"Bolalar o'z ismidagi harflar to'plamini yozsin: «MALIKA» → { M, A, L, I, K }."},
{h:"Qismto'plam: ⊂",sum:"Q ning hamma elementlari M da bo'lsa, Q — M ning qismto'plami: Q ⊂ M.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Mevalar to'plami ichidan <b>qizil mevalarni</b> ajratamiz:</p>",
 btns:[phaser(P4)],
 after:"<p>Q = { olma, anor } ning <b>har bir</b> elementi M da ham bor. Shuning uchun Q — M ning <b>qismto'plami</b>: <b>Q ⊂ M</b>. Chizmada Q halqasi M halqasining ichida.</p>",
 q:{t:"A = { 1, 2, 3, 4, 5 }. Qaysi to'plam A ning qismto'plami?",opts:["{ 2, 4, 6 }","{ 1, 5 }","{ 0, 1 }","{ 5, 6, 7 }"],ok:1,why:"1 va 5 — ikkalasi A da.",hint:"Har bir element A da bormi — tekshiring.",full:"{ 1, 5 }: 1 ∈ A, 5 ∈ A — qismto'plam. { 2, 4, 6 } da 6 ∉ A, { 0, 1 } da 0 ∉ A, { 5, 6, 7 } da 6 va 7 yo'q. Bitta begona element ham qismto'plamlikni buzadi."},
 tn:"Katta halqa ichiga kichik halqa qo'yib, ikkinchisiga ba'zi narsalarni o'tkazing — «ichki to'plam»."},
{h:"Bo'sh to'plam ∅",sum:"Birorta ham elementi yo'q to'plam — bo'sh to'plam, ∅ bilan belgilanadi.",a:"m05",
 start:function(){clear();m1ring(S.g,180,88,140,56,'Sinfdagi 3 metrli bolalar');m1msg('Bu to‘plamda nechta element bor?')},fin:function(){clear();m1ring(S.g,180,88,140,56,'Sinfdagi 3 metrli bolalar');T(S.g,180,100,'∅',{'font-size':40,'font-weight':800,fill:C.bad});m1msg('Element yo‘q — <b>bo‘sh to‘plam ∅</b>')},
 html:"<p>Har bir to'plamni bosing: qaysi birida <b>hech qanday element yo'q</b>?</p>",
 btns:[["3 metrli bolalar",function(c,done){STEPS[4].fin();mvK(done,3)}],["10 dan kichik juft sonlar",function(c,done){clear();m1ring(S.g,180,88,140,56,'10 dan kichik juft sonlar');T(S.g,180,94,'{ 2, 4, 6, 8 }',{'font-size':16,'font-weight':800,fill:C.ok});m1msg('4 ta element (0 ni hisobga olmaganda)');mvK(done,3)}],["Qishda gullaydigan o'rik",function(c,done){clear();m1ring(S.g,180,88,140,56,'Qishda gullaydigan o‘rik daraxtlari');T(S.g,180,100,'∅',{'font-size':40,'font-weight':800,fill:C.bad});m1msg('O‘rik bahorda gullaydi — to‘plam bo‘sh');mvK(done,3)}]],
 after:"<p>Elementi yo'q to'plam — <b>bo'sh to'plam</b>, belgisi <b>∅</b>. Bo'sh to'plam har qanday to'plamning qismto'plami hisoblanadi.</p>",
 q:{t:"Qaysi to'plam bo'sh?",opts:["5 dan kichik natural sonlar","Haftaning «Sh» harfi bilan boshlanadigan kunlari","10 va 11 orasidagi natural sonlar","O'zbekiston viloyatlari"],ok:2,why:"10 va 11 orasida butun son yo'q.",hint:"Qaysi to'plamga birorta ham misol topa olmaysiz?",full:"10 va 11 orasida natural son yo'q — bo'sh to'plam. 5 dan kichik natural sonlar: 1, 2, 3, 4; «Sh» bilan: shanba; viloyatlar ko'p."},
 tn:"Bo'sh qutini ko'rsatib: «Bu ham quti, faqat ichi bo'sh» — bo'sh to'plam ham to'plam."},
{h:"Juft sonlar to'plamini tuzing",sum:"To'plamni xossa bilan berish: «12 gacha juft sonlar» = { 2, 4, 6, 8, 10, 12 }.",a:"m06",
 start:function(){S.s6=[];m1nums([],{tap:m1t6,lab:'J — juft sonlar'});m1msg('1 dan 12 gacha juft sonlarni bosing')},fin:function(){m1nums([2,4,6,8,10,12],{lab:'J — juft sonlar'});m1msg('J = { 2, 4, 6, 8, 10, 12 }')},
 act:function(c,done){S.d6=done},
 html:"<p>J — 1 dan 12 gacha bo'lgan <b>juft</b> sonlar to'plami. Kerakli sonlarni bosib, halqaga o'tkazing.</p>",
 after:"<p>To'plamni ikki xil berish mumkin: <b>xossa</b> bilan («12 gacha juft sonlar») yoki <b>ro'yxat</b> bilan: J = { 2, 4, 6, 8, 10, 12 }. Toq sonlar J ga tegishli emas: 7 ∉ J.</p>",
 q:{t:"20 dan kichik, 5 ga bo'linadigan natural sonlar to'plami?",opts:["{ 5, 10, 15 }","{ 5, 10, 15, 20 }","{ 0, 5, 10, 15, 20 }","{ 1, 5 }"],ok:0,why:"20 kirmaydi — «kichik» deyilgan.",hint:"20 o'zi 20 dan kichikmi?",full:"5 ga bo'linadigan natural sonlar: 5, 10, 15, 20… «20 dan kichik» — 20 kirmaydi: { 5, 10, 15 }."},
 tn:"Bolalar kartochkadagi sonlarni o'zlari saralasin: «juft» qutisi va «toq» qutisi."},
{h:"Tuzoq: qism qaysi biri?",sum:"Q ⊂ H: Q — kichik (ichki), H — katta. «Har bir qush — hayvonmi?» deb tekshiramiz.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Q — qushlar, H — hayvonlar. Qaysi biri qaysining qismi?</p>",
 btns:[phaser(P7)],
 after:"<p><b>Q ⊂ H</b>: har bir qush — hayvon. Lekin <b>H ⊂ Q</b> emas: it, mushuk hayvon, ammo qush emas. Belgi «ochiq og'zi» bilan <b>katta</b> to'plamga qaraydi.</p>",
 q:{t:"K — kvadratlar, T — to'rtburchaklar. Qaysi yozuv to'g'ri?",opts:["K ⊂ T","T ⊂ K","K = T","Hech biri"],ok:0,why:"Har bir kvadrat — to'rtburchak.",hint:"Har bir to'rtburchak kvadratmi?",full:"Har bir kvadrat to'rtburchak — K ⊂ T. Lekin to'rtburchakning hammasi kvadrat emas (masalan, to'g'ri to'rtburchak), shuning uchun T ⊂ K xato."},
 tn:"«Har bir … — …mi?» savolini ikki tomonga berib ko'ring. Faqat bir tomonga «ha» bo'lsa, qism aniq."},
{h:"Nechta qismto'plam?",sum:"{ a, b } ning qismto'plamlari: ∅, { a }, { b }, { a, b } — jami 4 ta.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>A = { a, b } to'plamning barcha qismto'plamlarini sanaymiz. Ikkitasini unutmang!</p>",
 btns:[phaser(P8)],
 after:"<p>Qismto'plamlar: <b>∅</b> (bo'sh), <b>{ a }</b>, <b>{ b }</b>, <b>{ a, b }</b> (to'plamning o'zi). Jami <b>4</b> ta. Ko'pchilik bo'sh to'plamni va to'plamning o'zini unutadi.</p>",
 q:{t:"{ 1, 2, 3 } ning nechta qismto'plami bor?",opts:["8","6","3","7"],ok:0,why:"∅; {1}, {2}, {3}; {1,2}, {1,3}, {2,3}; {1,2,3} — 8 ta.",hint:"Bo'sh to'plamni va to'plamning o'zini ham sanang.",full:"0 ta elementli — 1, 1 ta elementli — 3, 2 ta elementli — 3, 3 ta elementli — 1: jami 8. 6 — bo'sh va to'liq to'plamni unutish, 7 — bittasini unutish."},
 tn:"Ikki xil meva bilan «tanlovlar»ni ko'rsating: hech narsa, faqat olma, faqat nok, ikkalasi."},
{h:"Bilasizmi? Georg Kantor",sum:"To'plamlar nazariyasini XIX asr oxirida nemis matematigi Georg Kantor yaratgan.",a:"m09",
 start:function(){P4[2]()},fin:function(){P4[2]()},
 html:"<p>🎓 Nemis matematigi <b>Georg Kantor</b> (1845–1918) XIX asr oxirida <b>to'plamlar nazariyasini</b> yaratgan. Bugun bu nazariya deyarli butun matematikaning asosi hisoblanadi.</p><p>∅ belgisini 1939-yilda fransuz matematiklar guruhi (Burbaki nomi bilan) kiritgan; u norveg alifbosidagi Ø harfiga o'xshatib olingan.</p><p>📚 Kutubxonadagi kitoblar, telefoningizdagi kontaktlar, sinf ro'yxati — bularning hammasi to'plam.</p>",
 tn:"Bolalarga «Sinfimiz to'plami» plakati: ism-familiyalar, ichida qismto'plamlar (qizlar, o'g'il bolalar, a'lochilar)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P4[2]()},fin:function(){P4[2]()},
 html:"<div class='memo'><ul><li><b>To'plam</b> — umumiy belgili narsalar; ular — <b>elementlar</b>: A = { 2, 4, 6 }.</li><li><b>∈</b> — tegishli (6 ∈ A), <b>∉</b> — tegishli emas (5 ∉ A).</li><li>Elementlar takrorlanmaydi, tartib muhim emas.</li><li><b>Q ⊂ M</b> — Q ning hamma elementlari M da.</li><li><b>∅</b> — bo'sh to'plam; u har qanday to'plamning qismi.</li><li>{ a, b } ning 4 ta qismto'plami: ∅, {a}, {b}, {a, b}.</li><li>Qism yo'nalishini «har bir … — …mi?» bilan tekshiring.</li></ul></div>",
 tn:"Keyingi dars (Eyler–Venn) uchun ikki halqa tayyorlang: endi to'plamlar kesishadi."}
];
var PROBS=[
{t:"A = { 3, 6, 9 }. Qaysi yozuv to'g'ri?",o:["6 ∈ A","4 ∈ A","9 ∉ A","3 ∉ A"],k:0,s:"6 A da bor."},
{t:"B = { qizil, sariq, yashil }. Qaysi yozuv to'g'ri?",o:["ko'k ∉ B","sariq ∉ B","ko'k ∈ B","yashil ∉ B"],k:0,s:"Ko'k B da yo'q."},
{t:"«Haftaning kunlari» to'plamida nechta element?",o:["7","5","12","30"],k:0,s:"Dushanbadan yakshanbagacha — 7 ta."},
{t:"«ANANAS» so'zidagi harflar to'plamida nechta element?",o:["3","6","4","2"],k:0,s:"{ A, N, S } — 3 ta."},
{t:"«ALIFBO» so'zidagi harflar to'plami?",o:["{ A, L, I, F, B, O }","{ A, L, I, F }","{ A, B, O }","{ A, A, L, I, F, B, O }"],k:0,s:"Har harf bir marta: 6 ta."},
{t:"Qaysi to'plam bo'sh?",o:["7 va 8 orasidagi natural sonlar","10 dan kichik toq sonlar","Yil fasllari","Uchburchakning uchlari"],k:0,s:"7 va 8 orasida natural son yo'q."},
{t:"1 dan 15 gacha 3 ga bo'linadigan sonlar to'plami?",o:["{ 3, 6, 9, 12, 15 }","{ 3, 6, 9, 12 }","{ 1, 3, 6, 9 }","{ 0, 3, 6, 9, 12, 15 }"],k:0,s:"15 ham kiradi («gacha»)."},
{t:"10 dan kichik toq natural sonlar to'plamida nechta element?",o:["5","4","10","6"],k:0,s:"{ 1, 3, 5, 7, 9 }."},
{t:"A = { 1, 2, 3, 4 }. Qaysi to'plam A ning qismto'plami?",o:["{ 2, 4 }","{ 4, 5 }","{ 0, 2 }","{ 1, 2, 3, 4, 5 }"],k:0,s:"2 va 4 — ikkalasi A da."},
{t:"A = { a, b, c }. Qaysi to'plam A ning qismto'plami EMAS?",o:["{ a, d }","{ a, c }","{ b }","∅"],k:0,s:"d ∉ A."},
{t:"Q — qizlar, S — sinf o'quvchilari. Qaysi yozuv to'g'ri?",o:["Q ⊂ S","S ⊂ Q","Q = S","Q ∈ S"],k:0,s:"Har bir qiz — sinf o'quvchisi."},
{t:"T — to'g'ri to'rtburchaklar, K — kvadratlar. Qaysi yozuv to'g'ri?",o:["K ⊂ T","T ⊂ K","T = K","K ∉ T"],k:0,s:"Har bir kvadrat — to'g'ri to'rtburchak."},
{t:"Qaysi gap to'g'ri?",o:["∅ har qanday to'plamning qismto'plami","∅ da bitta element bor","{ 0 } — bo'sh to'plam","∅ hech qanday to'plamning qismi emas"],k:0,s:"Bo'sh to'plam — har qanday to'plamning qismi; { 0 } da 0 elementi bor."},
{t:"{ x, y } to'plamning nechta qismto'plami bor?",o:["4","2","3","1"],k:0,s:"∅, {x}, {y}, {x, y}."},
{t:"{ 5, 6, 7 } to'plamning nechta qismto'plami bor?",o:["8","6","7","3"],k:0,s:"1 + 3 + 3 + 1 = 8."},
{t:"{ 5, 6, 7 } ning ikki elementli qismto'plamlari nechta?",o:["3","2","6","1"],k:0,s:"{5, 6}, {5, 7}, {6, 7}."},
{t:"A = { 2, 4, 6, 8 }, B = { 4, 8 }. Qaysi gap to'g'ri?",o:["B ⊂ A","A ⊂ B","A = B","B da A dan ko'p element bor"],k:0,s:"4 va 8 — A da."},
{t:"M = { 1, 2, 3 } va N = { 3, 2, 1 }. Ular haqida qaysi gap to'g'ri?",o:["M = N","M ≠ N","M ⊂ N emas","N bo'sh"],k:0,s:"Tartib muhim emas — elementlari bir xil."},
{t:"A — 20 gacha juft sonlar, B — 20 gacha 4 ga bo'linadigan sonlar. Qaysi gap to'g'ri?",o:["B ⊂ A","A ⊂ B","A = B","A va B ning umumiy elementi yo'q"],k:0,s:"4 ga bo'linadigan har bir son juft."},
{t:"A = { 1, 2, 3, 4, 5, 6 }. A ning juft elementlaridan iborat qismto'plamda nechta element?",o:["3","6","2","4"],k:0,s:"{ 2, 4, 6 }."}
];
function PRACT_STAGE(){P4[2]()}
var PREP_DATA={teach:["To'plam va uning elementlari; ro'yxat va xossa bilan berish.","∈, ∉ belgilari; elementlar takrorlanmasligi.","Qismto'plam ⊂, bo'sh to'plam ∅.","Tuzoqlar: qism yo'nalishi, qismto'plamlar sonida ∅ va to'plamning o'zini unutish."],
 mist:["To'plamda takroriy elementlarni sanaydi («ANANAS» → 6).","⊂ yo'nalishini teskari yozadi (H ⊂ Q).","Qismto'plamlarni sanashda ∅ va to'plamning o'zini tashlab ketadi.","{ 0 } ni bo'sh to'plam deb o'ylaydi."],
 need:["Arqon yoki ip halqalar (2–3 ta).","Meva/sabzavot rasmli kartochkalar, son kartochkalari.","Bo'sh quti (∅ uchun)."],
 board:["M = { olma, nok, uzum, anor }.","<span class='w2'>6 ∈ A</span>, 5 ∉ A.","MAKTAB → { M, A, K, T, B }.","Q ⊂ M.","∅ — bo'sh to'plam.","Q ⊂ H, lekin H ⊄ Q.","{ a, b }: ∅, {a}, {b}, {a, b}."]};
