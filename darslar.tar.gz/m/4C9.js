var CODE='4C9',TITLE='4-sinf · Bo‘linish alomatlari: 2, 3, 4, 5, 9, 10';
function c9grid(m){W3grid(function(n){var a=m[2]&&n%2===0,b=m[5]&&n%5===0;return a&&b?'#9fd8b0':a?'#cfe6f7':b?'#fde6c8':null},{n:60})}
function c9tap(c,done,b,k){S.m9=S.m9||{};S.m9[k]=1;b.disabled=true;c9grid(S.m9);
 var t={2:'2 ga bo‘linadiganlar — <b>juft</b>: oxiri 0, 2, 4, 6, 8',5:'5 ga — oxiri <b>0 yoki 5</b>',10:'10 ga — oxiri <b>0</b>: ham 2 ga, ham 5 ga (yashil)'};
 if(k===10){S.m9[2]=1;S.m9[5]=1;c9grid(S.m9)}W3msg(t[k]);if(S.m9[2]&&S.m9[5]&&S.m9[10])done()}
var P2=[function(){W3eq(['7 316 : 4 = ?']);W3msg('Butun sonni bo‘lmay, faqat oxiriga qaraymiz')},
 function(){W3eq(['7 316 = 7 300 + 16']);W3msg('7 300 — yuzliklar. <b>100 = 4 · 25</b>, demak har qanday yuzlik 4 ga bo‘linadi')},
 function(){W3eq(['16 : 4 = 4 ✓','7 316 — 4 ga [bo‘linadi]']);W3msg('<b>Oxirgi ikki raqamdan</b> tuzilgan son 4 ga bo‘linsa — butun son 4 ga bo‘linadi')}];
var P3=[function(){W3eq(['4 572 — 3 ga? 9 ga?']);W3msg('Endi oxirgi raqam yordam bermaydi')},
 function(){W3eq(['4 + 5 + 7 + 2 = 18']);W3msg('Raqamlarni qo‘shamiz')},
 function(){W3eq(['18 : 3 = 6 ✓','18 : 9 = 2 ✓']);W3msg('Raqamlar yig‘indisi 3 ga bo‘linsa — son 3 ga, 9 ga bo‘linsa — son 9 ga bo‘linadi')},
 function(){W3eq(['4 572 : 9 = [508]']);W3msg('Tekshiruv: 4 572 : 9 = 508 ✓')}];
var STEPS=[
{h:"2, 5 va 10 ga: oxirgi raqam",sum:"2 ga — oxiri juft; 5 ga — oxiri 0 yoki 5; 10 ga — oxiri 0.",a:"m01",start:function(){S.m9={};c9grid({});W3msg('Tugmalarni bosib, sonlarni bo‘yang')},fin:function(){c9grid({2:1,5:1})},
 html:"<p>Uchala tugmani bosing va qaysi sonlar bo'yalishini kuzating.</p>",
 btns:[["2 ga",function(c,done,b){c9tap(c,done,b,2)}],["5 ga",function(c,done,b){c9tap(c,done,b,5)}],["10 ga",function(c,done,b){c9tap(c,done,b,10)}]],g3:1,
 after:"<p>Bu uch alomat faqat <b>oxirgi raqamga</b> qaraydi, chunki 10 ning o'zi 2 ga ham, 5 ga ham bo'linadi. 10 ga bo'linadigan son — ham 2 ga, ham 5 ga bo'linadi (yashil kataklar).</p>",
 q:{t:"Qaysi son 2 ga ham, 5 ga ham bo'linadi?",opts:["3 570","3 575","3 572","3 557"],ok:0,why:"Oxiri 0.",hint:"2 va 5 ga birga — 10 ga.",full:"2 ga ham, 5 ga ham bo'linadigan son 10 ga bo'linadi — oxiri 0: 3 570. 3 575 — 5 ga, lekin toq; 3 572 — 2 ga, lekin 5 ga emas."},
 tn:"Sinf jadvali (1–100) bilan bo'yatish — Eratosfen g'oyasiga yaqin. Bolalar naqshlarni o'zi topsin (ustunlar!)."},
{h:"4 ga: oxirgi ikki raqam",sum:"7 316: 16 : 4 = 4, demak 7 316 4 ga bo'linadi (100 = 4 · 25).",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>4 ga bo'linishni tekshirish uchun butun sonni bo'lish shart emas.</p>",btns:[phaser(P2)],
 after:"<p>Nima uchun ikki raqam? Chunki 100, 1 000, 10 000 — hammasi 4 ga bo'linadi. Faqat oxirgi ikki raqam «qo'shimcha» bo'lib qoladi.</p>",
 q:{t:"Qaysi son 4 ga bo'linadi?",opts:["9 124","9 142","9 126","9 130"],ok:0,why:"24 : 4 = 6.",hint:"Oxirgi ikki raqamga qarang.",full:"24 — 4 ga bo'linadi → 9 124 ✓. 42, 26, 30 — 4 ga bo'linmaydi (juft bo'lsa ham)."},
 tn:"4 ga bo'linadigan ikki xonali sonlar ro'yxatini (04, 08, 12, …, 96) bolalar o'zi tuzsin."},
{h:"3 va 9 ga: raqamlar yig'indisi",sum:"4 572: 4 + 5 + 7 + 2 = 18 — 3 ga ham, 9 ga ham bo'linadi.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>3 va 9 ning alomati butunlay boshqacha — raqamlarni qo'shamiz.</p>",btns:[phaser(P3)],
 after:"<p><b>3 ga:</b> raqamlar yig'indisi 3 ga bo'linsa. <b>9 ga:</b> raqamlar yig'indisi 9 ga bo'linsa. 9 ga bo'linadigan son doim 3 ga ham bo'linadi (teskarisi emas!).</p>",
 q:{t:"Qaysi son 9 ga bo'linadi?",opts:["7 236","7 328","7 235","7 232"],ok:0,why:"7 + 2 + 3 + 6 = 18.",hint:"Raqamlarni qo'shing.",full:"7 236: 18 → 9 ga ✓. 7 235: 17 ✗; 7 232: 14 ✗."},
 tn:"Raqamlar yig'indisi katta bo'lsa (masalan 36), uni ham qayta qo'shish mumkin: 3 + 6 = 9."},
{h:"Tuzoq: 3 ga — ha, 9 ga — yo'q",sum:"1 245: yig'indi 12 — 3 ga bo'linadi, 9 ga emas; oxiri 5 — 5 ga bo'linadi.",a:"m04",start:function(){W3eq(['1 245']);W3msg('Bu son qaysilarga bo‘linadi?')},fin:function(){W3eq(['1+2+4+5 = 12','12 : 3 ✓   12 : 9 ✗','oxiri 5 → 5 ga ✓'])},
 html:"<p><b>1 245</b> qaysi sonlarga bo'linadi? To'g'ri to'plamni tanlang:</p>",
 btns:[["3 va 5",function(c,done){W3eq(['1+2+4+5 = 12','12 : 3 ✓   12 : 9 ✗','oxiri 5 → 5 ga ✓']);W3msg('To‘g‘ri: 1 245 = 3 · 415 = 5 · 249');done()}],["3, 5 va 9",function(){W3eq(['12 : 9 — bo‘linmaydi']);W3msg('3 ga bo‘linsa, 9 ga bo‘linishi shart emas!','Qayta tanlang')}],["faqat 5",function(){W3eq(['1+2+4+5 = 12','12 : 3 = 4 ✓']);W3msg('3 ga ham bo‘linadi','Qayta tanlang')}]],g3:1,
 after:"<p>Ko'p bolalar «3 ga bo'linsa, 9 ga ham» deb o'ylaydi. Aksincha: <b>9 ga → 3 ga</b>, lekin <b>3 ga → 9 ga emas</b>. Xuddi shunday: 4 ga → 2 ga, lekin 2 ga → 4 ga emas.</p>",
 q:{t:"2 451 qaysilarga bo'linadi?",opts:["Faqat 3 ga","3 va 9 ga","3 va 5 ga","Hech qaysiga"],ok:0,why:"Yig'indi 12; oxiri 1.",hint:"Yig'indi va oxirgi raqam.",full:"2 + 4 + 5 + 1 = 12 → 3 ga ✓, 9 ga ✗. Oxiri 1 → 2, 5, 10 ga ✗. 51 → 4 ga ✗."},
 tn:"Venn diagrammasi: «3 ga» halqasi ichida «9 ga» halqasi — bolalar sonlarni joylashtirsin."},
{h:"Tuzoq: juft, lekin 4 ga emas",sum:"1 234 juft, lekin 34 : 4 — bo'linmaydi. 5 316 — 16 : 4 ✓.",a:"m05",start:function(){W3eq(['1 234   5 316   7 330']);W3msg('Uchala son juft. Qaysi biri 4 ga bo‘linadi?')},fin:function(){W3eq(['1 2[34] ✗   5 3{16} ✓   7 3[30] ✗'])},
 html:"<p>Uchala son <b>juft</b>. Qaysi biri <b>4 ga</b> bo'linadi?</p>",
 btns:[["5 316",function(c,done){W3eq(['1 2[34] ✗   5 3{16} ✓   7 3[30] ✗']);W3msg('16 : 4 = 4 ✓. 34 va 30 — 4 ga bo‘linmaydi');done()}],["1 234",function(){W3eq(['34 : 4 = 8 (q. 2)']);W3msg('Juft, lekin 4 ga emas','Qayta tanlang')}],["7 330",function(){W3eq(['30 : 4 = 7 (q. 2)']);W3msg('Oxiri 0 — 10 ga bo‘linadi, lekin 4 ga emas!','Qayta tanlang')}]],g3:1,
 after:"<p>«Oxiri 0 — demak hamma narsaga bo'linadi» degan xato ham ko'p: 7 330 — 2, 5, 10 ga, lekin 4 ga emas.</p>",
 q:{t:"Qaysi son 4 ga BO'LINMAYDI?",opts:["3 450","3 400","3 448","3 412"],ok:0,why:"50 : 4 — qoldiq 2.",hint:"Oxirgi ikki raqam.",full:"3 450: 50 ✗. 3 400: 00 ✓; 3 448: 48 ✓; 3 412: 12 ✓."},
 tn:"«Juft — lekin 4 ga emas» sonlarini (2, 6, 10, 14, …) son o'qida belgilating — har ikkinchi juft son."},
{h:"Yashirin raqam",sum:"52□ 3 ga ham, 5 ga ham bo'linsin: □ = 0 yoki 5; 520 → 7 ✗, 525 → 12 ✓. □ = 5.",a:"m06",start:function(){W3eq(['52□']);W3msg('Son 3 ga ham, 5 ga ham bo‘linsin. □ = ?')},fin:function(){W3eq(['52{5}','5+2+5 = 12 ✓','oxiri 5 ✓'])},
 html:"<p><b>52□</b> soni 3 ga ham, 5 ga ham bo'linishi kerak. □ o'rniga qaysi raqam?</p>",
 btns:[["5",function(c,done){W3eq(['52{5}','5+2+5 = 12 ✓','oxiri 5 ✓']);W3msg('5 ga uchun □ = 0 yoki 5. 520: 7 ✗; 525: 12 ✓');done()}],["0",function(){W3eq(['520: 5+2+0 = 7']);W3msg('5 ga bo‘linadi, lekin 3 ga emas','Qayta tanlang')}],["2",function(){W3eq(['522: oxiri 2']);W3msg('3 ga bo‘linadi (9), lekin 5 ga emas','Qayta tanlang')}]],g3:1,
 after:"<p>Ikki shartli masalada avval <b>qattiqroq</b> shartdan boshlang (5 ga — faqat 2 ta variant), keyin ikkinchisini tekshiring.</p>",
 q:{t:"3□6 soni 9 ga bo'linsin. □ = ?",opts:["0 yoki 9","Faqat 0","Faqat 9","3"],ok:0,why:"3 + □ + 6 = 9 yoki 18.",hint:"Yig'indi 9 yoki 18 bo'lishi kerak.",full:"3 + 6 = 9. □ = 0 → 9 ✓; □ = 9 → 18 ✓. Ikkala javob ham to'g'ri: 306 va 396."},
 tn:"Bu — olimpiadaning klassik turi. Bolalar barcha variantlarni jadvalda sinab ko'rsin."},
{h:"Eng kichik son",sum:"2, 3 va 5 ga bo'linadigan eng kichik to'rt xonali son: 1 020 (30 ga karrali).",a:"m07",start:function(){W3eq(['2, 3, 5 ga → ?','eng kichik 4 xonali']);W3msg('Uchala shartni birga bajaring')},fin:function(){W3eq(['2 · 3 · 5 = 30','1 020 = 30 · 34','1+0+2+0 = 3 ✓'])},
 html:"<p>2, 3 va 5 ga bo'linadigan <b>eng kichik to'rt xonali</b> son?</p>",
 btns:[["1 020",function(c,done){W3eq(['2 · 3 · 5 = 30','1 020 = 30 · 34','1+0+2+0 = 3 ✓']);W3msg('Oxiri 0 (2 va 5) va yig‘indi 3 ga bo‘linadi ✓');done()}],["1 000",function(){W3eq(['1+0+0+0 = 1']);W3msg('3 ga bo‘linmaydi','Qayta tanlang')}],["1 030",function(){W3eq(['1+0+3+0 = 4']);W3msg('3 ga bo‘linmaydi. Undan kichigi ham bor','Qayta tanlang')}]],g3:1,
 after:"<p>2 ga va 5 ga bo'linsa — 10 ga, ya'ni oxiri 0. Keyin 3 ga: 1 000, 1 010, 1 020 — yig'indisi 3 ga bo'linadigan birinchisi <b>1 020</b>.</p>",
 q:{t:"9 ga va 10 ga bo'linadigan eng katta uch xonali son?",opts:["990","999","900","980"],ok:0,why:"Oxiri 0, yig'indi 18.",hint:"Oxiri 0 bo'lsin, raqamlar yig'indisi 9 ga bo'linsin.",full:"Oxiri 0: □□0. Eng kattasi 990: 9 + 9 = 18 ✓. 999 — 10 ga bo'linmaydi."},
 tn:"«Avval oxiri, keyin yig'indi» — strategiyani doskaga yozing."},
{h:"Raqamlardan son tuzish",sum:"2, 7, 0, 6 raqamlaridan 4 ga bo'linadigan eng katta son: 7 620.",a:"m08",start:function(){W3eq(['2   7   0   6']);W3msg('Har raqam bir martadan. 4 ga bo‘linadigan eng katta son?')},fin:function(){W3eq(['76{20}','20 : 4 = 5 ✓'])},
 html:"<p><b>2, 7, 0, 6</b> raqamlari bir martadan ishlatiladi. 4 ga bo'linadigan <b>eng katta</b> to'rt xonali son?</p>",
 btns:[["7 620",function(c,done){W3eq(['76{20}','20 : 4 = 5 ✓']);W3msg('Eng katta boshlanish 76; qolgan 2 va 0 dan: 20 ✓ (02 ✗)');done()}],["7 602",function(){W3eq(['02 : 4 — bo‘linmaydi']);W3msg('Kattaroq, lekin 4 ga emas','Qayta tanlang')}],["7 260",function(){W3eq(['60 : 4 = 15 ✓','7 260 < 7 620']);W3msg('4 ga bo‘linadi, lekin eng kattasi emas','Qayta tanlang')}]],g3:1,
 after:"<p>Strategiya: chapdagi raqamlarni iloji boricha katta qilamiz, oxirgi ikki raqamni esa 4 ga bo'linadigan qilib tanlaymiz.</p>",
 q:{t:"3, 2, 5, 6 raqamlaridan (bir martadan) 4 ga bo'linadigan eng katta son?",opts:["6 532","6 523","6 352","5 632"],ok:0,why:"Oxiri 32, oldida eng katta 6 va 5.",hint:"Qaysi ikki raqamli oxirlar 4 ga bo'linadi?",full:"4 ga bo'linadigan oxirlar: 32, 36, 52, 56. Har biri bilan eng katta son: 6 532, 5 236, 6 352, 3 256. Eng kattasi 6 532. 6 523 — 23 ga tugaydi, 4 ga bo'linmaydi."},
 tn:"Avval barcha mumkin bo'lgan ikki raqamli oxirlarni ro'yxatga oldiring."},
{h:"Bilasizmi? Nega alomatlar ishlaydi",sum:"10 = 9 + 1, 100 = 99 + 1: shuning uchun son 9 ga bo'lganda raqamlar yig'indisi bilan bir xil qoldiq beradi.",a:"m09",start:function(){W3eq(['4 572 = 4·1000 + 5·100 + 7·10 + 2','1000 = 999 + 1','100 = 99 + 1,  10 = 9 + 1'],{fs:16});W3msg('999, 99, 9 — hammasi 9 ga bo‘linadi')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Alomat «sehr» emas. 4 572 = 4 · 1000 + 5 · 100 + 7 · 10 + 2. Har bir 1000 = <b>999 + 1</b>, 100 = <b>99 + 1</b>, 10 = <b>9 + 1</b>. 999, 99, 9 — 9 ga bo'linadi. Ulardan keyin qoladigani: 4 + 5 + 7 + 2 — raqamlar yig'indisi!</p><p>⭐ Shuning uchun son va uning raqamlari yig'indisi 9 ga (va 3 ga) bo'lganda <b>bir xil qoldiq</b> beradi.</p>",
 tn:"Kuchli o'quvchilar bilan: 4 572 ni o'nlik bloklar bilan tasvirlab, har blokdan «bittasini» ajrating — qolgani 9 ga bo'linadi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){c9grid({2:1,5:1})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>2 ga:</b> oxiri 0, 2, 4, 6, 8. <b>5 ga:</b> oxiri 0 yoki 5. <b>10 ga:</b> oxiri 0.</li><li><b>4 ga:</b> oxirgi ikki raqamdan tuzilgan son 4 ga bo'linsa (7 316 → 16).</li><li><b>3 ga:</b> raqamlar yig'indisi 3 ga. <b>9 ga:</b> yig'indi 9 ga.</li><li>9 ga → 3 ga; 3 ga → 9 ga <b>emas</b>. 4 ga → 2 ga; juft → 4 ga <b>emas</b>.</li><li>Ikki shartda qattiqroq shartdan boshlang.</li></ul></div>",
 tn:"Bu alomatlar kasrlarni qisqartirishda juda kerak bo'ladi."}
];
var PROBS=[
{t:"Qaysi son 5 ga bo'linadi, lekin 10 ga bo'linmaydi?",o:["4 375","4 370","4 372","4 357"],k:0,s:"Oxiri 5."},
{t:"Qaysi son 3 ga bo'linadi?",o:["5 412","5 411","5 413","5 414"],k:0,s:"5 + 4 + 1 + 2 = 12."},
{t:"Qaysi son 9 ga bo'linadi?",o:["8 136","8 146","8 135","8 134"],k:0,s:"8 + 1 + 3 + 6 = 18."},
{t:"Qaysi son 4 ga bo'linadi?",o:["6 528","6 526","6 530","6 518"],k:0,s:"28 : 4 = 7."},
{t:"Qaysi son 3 ga bo'linadi, lekin 9 ga bo'linmaydi?",o:["2 112","2 115","2 016","2 223"],k:0,s:"6 → 3 ga; 9 → 9 ga; 9 → 9 ga; 9 → 9 ga."},
{t:"7□5 soni 9 ga bo'linadi. □ = ?",o:["6","3","5","9"],k:0,s:"7 + □ + 5 = 18."},
{t:"4□ soni 4 ga bo'linadi va □ > 5. □ = ?",o:["8","6","4","9"],k:0,s:"48 : 4 = 12; 46 ✗."},
{t:"1□3□ soni 10 ga va 9 ga bo'linadi. Ikkinchi □ = 0. Birinchi □ = ?",o:["5","0","9","3"],k:0,s:"1 + □ + 3 + 0 = 9 → □ = 5."},
{t:"2, 3, 5 ga bo'linadigan eng kichik uch xonali son?",o:["120","100","105","150"],k:0,s:"30 · 4 = 120."},
{t:"4 ga va 9 ga bo'linadigan eng kichik ikki xonali son?",o:["36","18","72","27"],k:0,s:"36 = 4 · 9."},
{t:"10 dan 50 gacha (ikkalasi ham) nechta son 5 ga bo'linadi?",o:["9","8","10","5"],k:0,s:"10, 15, …, 50."},
{t:"1 dan 100 gacha nechta son 4 ga bo'linadi?",o:["25","24","50","20"],k:0,s:"100 : 4."},
{t:"Qaysi da'vo NOTO'G'RI?",o:["3 ga bo'linadigan har son 9 ga bo'linadi","9 ga bo'linadigan har son 3 ga bo'linadi","10 ga bo'linadigan har son 5 ga bo'linadi","4 ga bo'linadigan har son juft"],k:0,s:"12 — 3 ga, 9 ga emas."},
{t:"3, 0, 7 raqamlaridan (bir martadan) 5 ga bo'linadigan nechta uch xonali son tuziladi?",o:["2","1","3","4"],k:0,s:"370, 730."},
{t:"Bir qutida 4 tadan, ikkinchisida 9 tadan qalam bor. Qaysi son ikkala usulda ham qoldiqsiz qadoqlanadi?",o:["108","100","96","126"],k:0,s:"108 = 4 · 27 = 9 · 12."},
{t:"Raqamlar yig'indisi 27 bo'lgan eng kichik to'rt xonali son?",o:["1 899","9 990","999","1 989"],k:0,s:"1 + 8 + 9 + 9 = 27, eng kichigi 1 899."},
{t:"Sinfda 30 dan ko'p, 40 dan kam o'quvchi bor. Ular 4 tadan ham, 9 tadan ham qatorga qoldiqsiz turadi. Nechta o'quvchi?",o:["36","32","40","27"],k:0,s:"4 va 9 ga bo'linadigan: 36."},
{t:"Son 9 ga bo'linganda qoldiq qancha: 5 234?",o:["5","4","2","0"],k:0,s:"5 + 2 + 3 + 4 = 14; 14 : 9 = 1 (q. 5)."},
{t:"2 · 3 · 4 · 5 ko'paytma qaysiga bo'linMAYDI?",o:["9","10","8","12"],k:0,s:"120 : 9 = 13 (q. 3)."},
{t:"6 ga bo'linadigan son qaysi?",o:["4 512","4 514","4 515","4 520"],k:0,s:"Juft va yig'indi 12 → 3 ga."}
];
function PRACT_STAGE(){W3eq(['2, 5, 10 → oxiri','4 → oxirgi ikki','3, 9 → yig‘indi'],{fs:19})}
var PREP_DATA={teach:["2, 5, 10 ga bo'linish alomati (oxirgi raqam).","4 ga — oxirgi ikki raqam.","3 va 9 ga — raqamlar yig'indisi.","Tuzoqlar: 3 ga → 9 ga emas; juft → 4 ga emas.","Yashirin raqam, eng kichik/katta son, raqamlardan son tuzish."],
 mist:["3 ga bo'linsa, 9 ga ham deb o'ylaydi.","Juft son 4 ga bo'linadi deb o'ylaydi (1 234).","Oxiri 0 bo'lsa hamma narsaga bo'linadi deb o'ylaydi.","4 ga alomatda faqat oxirgi raqamga qaraydi."],
 need:["1–100 sonlar jadvali va rangli qalamlar.","Raqam kartochkalari (0–9)."],
 board:["<span class='w2'>2, 5, 10 → oxiri</span>","<span class='w2'>4 → oxirgi ikki raqam</span>","<span class='w2'>3, 9 → raqamlar yig'indisi</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
