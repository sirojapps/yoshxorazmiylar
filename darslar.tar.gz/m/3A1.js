var CODE='3A1',TITLE='3-sinf · Uch xonali sonlar: o‘qish, yozish, xona birliklari';
function a1(n,hl,o){clear();w3heads();w3blocks(n,62,hl,o);var h=Math.floor(n/100),t=Math.floor(n/10)%10,u=n%10;if(!(o&&o.nostrip))msg('<b>'+n+'</b> = '+h+' yuzlik, '+t+' o‘nlik, '+u+' birlik · «'+w3a(n)+'»')}
var P3=[function(){clear();w3heads();w3blocks(0,40,null,{h:6,t:14,u:7,label:'?'});msg('6 yuzlik, 14 o‘nlik, 7 birlik — o‘nliklar 9 tadan ko‘p!')},
 function(){clear();w3heads();w3blocks(0,40,'t',{h:6,t:14,u:7,label:'?'});msg('14 o‘nlik = 10 o‘nlik + 4 o‘nlik. 10 o‘nlik — bitta yuzlik!')},
 function(){a1(747,'h');msg('<b>747</b> = 600 + 140 + 7. Javob: 747 (6147 emas!)')}];
var P4=[function(){clear();w3heads();w3blocks(0,40,null,{h:0,t:23,u:0,label:'23 o‘nlik'});msg('23 ta o‘nlik — qaysi son?')},
 function(){clear();w3heads();w3blocks(0,40,'t',{h:0,t:23,u:0,label:'23 o‘nlik'});msg('20 ta o‘nlik = 2 yuzlik, yana 3 o‘nlik')},
 function(){a1(230,'h');msg('23 o‘nlik = <b>230</b>. Sonda «23» ta o‘nlik bor, o‘nliklar xonasidagi raqam esa — 3!')}];
var P6=[function(){a1(415);msg('Topishmoq: 400 dan katta, 420 dan kichik, oxirgi raqami 5, raqamlar yig‘indisi 10')},
 function(){w3line(400,420,1,[[405,C.a],[415,C.a]],{big:5});msg('400 va 420 orasida 5 bilan tugaydigan sonlar: <b>405</b> va <b>415</b>')},
 function(){w3line(400,420,1,[[405,C.bad,'4+0+5=9'],[415,C.ok,'4+1+5=10']],{big:5});msg('Raqamlar yig‘indisi: 405 → 9, 415 → 10. Javob: <b>415</b>')}];
var STEPS=[
{h:"Takror: uch xonali son tarkibi",sum:"Uch xonali son: yuzliklar, o'nliklar, birliklar. 538 = 5 yuzlik, 3 o'nlik, 8 birlik.",a:"m01",
 start:function(){a1(538)},fin:function(){a1(538)},
 html:"<p>2-sinfda uch xonali sonlarni o'rgandingiz. Eslab olamiz: tugmalar bilan sonni o'zgartiring va har gal pastdagi tarkibiga qarang.</p>",
 btns:[["🎲 Yangi son",function(c,done){var n=100+Math.floor(Math.random()*900);a1(n);mvK(done,3)}]],
 after:"<p>Har bir raqam o'z <b>xonasida</b> turadi: chapda yuzliklar, o'rtada o'nliklar, o'ngda birliklar. Eng kichik uch xonali son — <b>100</b>, eng kattasi — <b>999</b>.</p>",
 q:{t:"Uch xonali sonlar jami nechta?",opts:["999","899","900","1000"],ok:2,why:"100 dan 999 gacha: 999 − 100 + 1 = 900.",hint:"100 dan 999 gacha. «Dan … gacha» — chetlari kiradi.",full:"Birinchisi 100, oxirgisi 999. Ikkalasi ham kiradi: 999 − 100 + 1 = 900. 999 — oxirgi sonning o'zi, 899 — birinchisi tushib qolgan."},
 tn:"Darsni tez og'zaki takror bilan boshlang: «Men son aytaman, siz uni yuzlik, o'nlik, birlikka ajrating»."},
{h:"Xona birligi va xonadagi raqam",sum:"485 da o'nliklar xonasida 8, lekin o'nliklar jami 48 ta (480 = 48 o'nlik).",a:"m02",
 start:function(){a1(485)},fin:function(){a1(485,'t')},
 html:"<p>Ikki xil savolni farqlash muhim: «o'nliklar <b>xonasida</b> qaysi raqam?» va «sonda <b>jami nechta</b> o'nlik bor?». 485 ni ko'raylik — tugmalarni bosing:</p>",
 btns:[["O'nliklar xonasidagi raqam",function(c,done){a1(485,'t');msg('O‘nliklar <b>xonasida</b> — <b>8</b>');mvK(done,2)}],["Jami nechta o'nlik?",function(c,done){a1(485,'h');msg('Jami o‘nliklar: 4 yuzlikda 40 ta + 8 ta = <b>48</b> ta (485 = 48 o‘nlik va 5 birlik)');mvK(done,2)}]],g2:1,
 after:"<p>Xonadagi raqam — <b>8</b>. Jami o'nliklar — <b>48</b>, chunki har bir yuzlik ham 10 ta o'nlikdan iborat. Tez usul: oxirgi raqamni yoping — 48|5.</p>",
 q:{t:"736 sonida jami nechta o'nlik bor?",opts:["3","73","7","36"],ok:1,why:"Oxirgi raqamni yopamiz: 73|6 — 73 ta o'nlik.",hint:"«Xonadagi raqam» emas, «jami nechta» so'ralyapti. Yuzliklar ham o'nliklardan iborat.",full:"7 yuzlik = 70 o'nlik, yana 3 o'nlik — jami 73. Xonadagi raqam esa 3. Savolni diqqat bilan o'qing!"},
 tn:"Bu farq 3-sinf testlarida eng ko'p uchraydigan tuzoq. Doskada 485 ni yozib, «48» ni doiraga oling."},
{h:"Tuzoq: xona birligi 9 tadan ko'p",sum:"6 yuzlik + 14 o'nlik + 7 birlik = 600 + 140 + 7 = 747.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Testda: <b>□ = 6 yuzlik + 14 o'nlik + 7 birlik</b>. Raqamlarni yonma-yon yozib «6147» deb qo'ymang. Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>14 o'nlik — bu 1 yuzlik va 4 o'nlik. Shuning uchun son <b>747</b>. Ishonchli usul: har birini qiymatiga aylantirib qo'shish: 600 + 140 + 7.</p>",
 q:{t:"5 yuzlik + 13 o'nlik + 16 birlik — qaysi son?",opts:["51316","646","546","656"],ok:1,why:"500 + 130 + 16 = 646.",hint:"Har birini qiymatiga aylantiring: 5 yuzlik = 500, 13 o'nlik = 130…",full:"500 + 130 + 16 = 646. Yoki: 16 birlik = 1 o'nlik 6 birlik → 14 o'nlik = 1 yuzlik 4 o'nlik → 6 yuzlik 4 o'nlik 6 birlik."},
 tn:"Bank misoli (397): «6 yuzlik + 14 o'nlik + 7 birlik». Bolalar avval qiymatlarni yozsin, keyin qo'shsin."},
{h:"«23 ta o'nlik» qaysi son?",sum:"23 o'nlik = 230; 40 yuzlik = 4000. Birlikni xona birligiga aylantirish.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Teskari savol: «23 ta o'nlik» yoki «45 ta o'nlik» — qaysi son? Kuzating.</p>",
 btns:[phaser(P4)],
 after:"<p>Qoida: <b>o'nliklar soniga bitta 0</b> qo'shamiz: 23 o'nlik = 230. Yuzliklar soniga — ikkita 0: 7 yuzlik = 700, 12 yuzlik = 1200.</p>",
 q:{t:"58 ta o'nlik va 4 ta birlik — qaysi son?",opts:["5804","584","58","854"],ok:1,why:"58 o'nlik = 580, + 4 = 584.",hint:"58 o'nlik — bu nechta? Bitta 0 qo'shing.",full:"58 o'nlik = 580. Yana 4 birlik: 584. Tekshiramiz: 584 da oxirgi raqamni yopsak — 58|4 — 58 ta o'nlik ✓."},
 tn:"Pul bilan bog'lang: «10 so'mlik tangalardan 23 ta — necha so'm?»"},
{h:"Shartlar bo'yicha sonni topish",sum:"Yuzlar 7, o'nlar yuzlardan 6 ta kam (1), birlar o'nlardan 5 ta ko'p (6): 716.",a:"m05",
 start:function(){S.d=[null,null,null];digs()},fin:function(){S.d=[7,1,6];digs()},
 html:"<p>«Sonda <b>7 yuzlik</b>, o'nliklar yuzliklardan <b>6 ta kam</b>, birliklar o'nliklardan <b>5 ta ko'p</b>». Raqamlarni xonama-xona toping:</p>",
 btns:[["Yuzlar: 7",function(c,done){S.d[0]=7;digs();chk(done)}],["O'nlar: 7 − 6 = 1",function(c,done){S.d[1]=1;digs();chk(done)}],["Birlar: 1 + 5 = 6",function(c,done){S.d[2]=6;digs();chk(done)},'u']],
 after:"<p>Shartdagi har bir gapni <b>bittadan</b> bajaramiz, har biri oldingisiga tayanadi: 7 → 1 → 6. Son: <b>716</b>. Diqqat: «o'nliklardan 5 ta ko'p» — 7 dan emas, 1 dan!</p>",
 q:{t:"Uch xonali sonning yuzlar raqami 4, o'nlar raqami undan 3 ta katta, birlar raqami o'nlar va yuzlar raqamlari ayirmasiga teng. Son?",opts:["471","743","473","437"],ok:2,why:"4; 4 + 3 = 7; 7 − 4 = 3 → 473.",hint:"Avval yuzlar, keyin o'nlar, oxirida birlar — shartdagi tartibda.",full:"Yuzlar — 4. O'nlar — 4 + 3 = 7. Birlar — 7 − 4 = 3. Son: 473. «743» — raqamlar tartibi buzilgan."},
 tn:"Bolalar uchta katakni chizib, har shartni bittadan to'ldirsin."},
{h:"Topishmoq: men qaysi sonman?",sum:"400 < son < 420, 5 bilan tugaydi, raqamlar yig'indisi 10 → 415.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>«Men uch xonali sonman. 400 dan kattaman, 420 dan kichikman. Oxirgi raqamim 5, raqamlarim yig'indisi 10. Men kimman?» Shartlarni bittadan qo'llaymiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: avval <b>oraliqni</b> toramiz, keyin har bir shart bilan nomzodlarni <b>elab</b> chiqamiz. Oxirida tekshiramiz: 415 — barcha shartlar bajarildi ✓.</p>",
 q:{t:"Men uch xonali sonman: 300 dan katta, 320 dan kichik, juftman va raqamlarim yig'indisi 5. Men kimman?",opts:["311","302","310","320"],ok:2,why:"300–320 orasidagi juftlar, raqamlar yig'indisi 5: 3 + 1 + 0 = 4? Yo'q… 302: 5 ✓? 3+0+2=5, juft ✓ — lekin 310: 3+1+0=4.",hint:"Har bir nomzodning raqamlar yig'indisini hisoblang.",full:"x"},
 tn:"Bolalar o'zlari topishmoq tuzib, sinfdoshiga bersin."},
{h:"Raqamlar yig'indisi bo'yicha sanash",sum:"Raqamlari yig'indisi 3 bo'lgan uch xonali sonlar: 300, 210, 201, 120, 102, 111 — 6 ta.",a:"m07",
 start:function(){S.f=[];sumList()},fin:function(){S.f=[300,210,201,120,111,102];sumList()},
 html:"<p>«Raqamlari yig'indisi 3 ga teng uch xonali sonlar nechta?» Tartib bilan qidiramiz — avval yuzlar raqamini tanlang:</p>",
 btns:[["Yuzlar = 3",function(c,done){add([300]);fdone(done)}],["Yuzlar = 2",function(c,done){add([210,201]);fdone(done)}],["Yuzlar = 1",function(c,done){add([120,111,102]);fdone(done)}]],
 after:"<p>Tartibli qidiruv hech birini tushirib qoldirmaydi: yuzlar 3 → 1 ta, 2 → 2 ta, 1 → 3 ta. Jami <b>6 ta</b>. Yuzlar 0 bo'lolmaydi — unda son uch xonali bo'lmaydi.</p>",
 q:{t:"Raqamlari yig'indisi 2 ga teng uch xonali sonlar nechta?",opts:["2","3","4","1"],ok:1,why:"200, 110, 101 — 3 ta.",hint:"Yuzlar raqami 2 yoki 1 bo'lishi mumkin. Har birida nechta son chiqadi?",full:"Yuzlar 2: 200 (1 ta). Yuzlar 1: 110, 101 (2 ta). Jami 3 ta. 011 — uch xonali emas."},
 tn:"Tartibli qidiruv (daraxt usuli) — kombinatorikaning asosi. Doskada jadval qilib yozdiring."},
{h:"Bilasizmi? Raqamlar sayohati",sum:"Biz ishlatadigan raqamlar Hindistonda paydo bo'lib, al-Xorazmiy kitobi orqali dunyoga tarqalgan.",a:"m08",
 start:function(){clear('#f6ead0');hist3()},fin:function(){clear('#f6ead0');hist3()},
 html:"<p>🌍 0, 1, 2 … 9 raqamlari va raqamning o'rniga qarab yozish usuli <b>Hindistonda</b> paydo bo'lgan. IX asrda vatandoshimiz <b>Muhammad al-Xorazmiy</b> bu usulni kitobida tushuntirgan, u lotin tiliga tarjima qilinib, Yevropaga tarqalgan.</p><p>📜 O'shandan beri bu raqamlar «arab raqamlari» deb ham ataladi.</p>",
 tn:"Bolalar Rim raqamlari (keyingi dars) bilan solishtirib ko'rishi uchun shu yerda qisqa tanishtiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){a1(485)},fin:function(){a1(485)},
 html:"<div class='memo'><ul><li>Uch xonali son: <b>yuzliklar | o'nliklar | birliklar</b>. 100 — eng kichigi, 999 — eng kattasi, jami <b>900</b> ta.</li><li><b>Xonadagi raqam</b> ≠ <b>jami nechta</b>: 485 da o'nliklar xonasida 8, jami o'nliklar 48.</li><li>Xona birligi 9 tadan ko'p bo'lsa — qiymatlarni qo'shing: 6 yuzlik + 14 o'nlik + 7 = <b>747</b>.</li><li>23 o'nlik = <b>230</b>; 12 yuzlik = <b>1200</b>.</li><li>Shartli masala — har shartni bittadan, tartib bilan.</li><li>Sanashda tartibli qidiruv: yuzlar raqamidan boshlang.</li></ul></div>",
 tn:"Keyingi dars — taqqoslash va yaxlitlash."}
];
// to'g'ri javobni tuzatamiz (6-qadam savoli)
STEPS[5].q={t:"Men uch xonali sonman: 300 dan katta, 320 dan kichik, juftman va raqamlarim yig'indisi 5. Men kimman?",opts:["311","312","302","320"],ok:2,why:"302: juft ✓, 3 + 0 + 2 = 5 ✓, 300 < 302 < 320 ✓.",hint:"Avval juft nomzodlarni toping, keyin raqamlar yig'indisini tekshiring.",full:"Juft va yig'indisi 5: 302 (3+0+2=5) ✓; 312 — 3+1+2=6 ✗; 311 — toq ✗; 320 — 320 dan kichik emas ✗. Javob: 302."};
function digs(){clear();var g=S.g,lab=['yuzlar','o‘nlar','birlar'];for(var i=0;i<3;i++){var x=80+i*80;E('rect',{x:x-30,y:40,width:60,height:70,rx:10,fill:S.d[i]==null?'#fff':'#e6f6ee',stroke:S.d[i]==null?'#c9d3dd':C.ok,'stroke-width':2},g);T(g,x,30,lab[i],{'font-size':12,fill:'#5b6b7b'});T(g,x,90,S.d[i]==null?'?':String(S.d[i]),{'font-size':34,'font-weight':800,fill:S.d[i]==null?'#9aa8b6':C.ok})}
 msg(S.d.every(function(v){return v!=null})?'Son: <b>'+S.d.join('')+'</b>':'Raqamlarni tartib bilan toping')}
function chk(done){if(S.d.every(function(v){return v!=null}))done()}
function sumList(){clear();var g=S.g;T(g,180,24,'Raqamlari yig‘indisi 3 ga teng',{'font-size':13,'font-weight':800,fill:C.blue});S.f.forEach(function(v,i){var x=40+(i%3)*110,y=50+Math.floor(i/3)*52;E('rect',{x:x,y:y,width:90,height:40,rx:9,fill:'#e6f6ee',stroke:C.ok},g);T(g,x+45,y+27,String(v),{'font-size':20,'font-weight':800,fill:C.ok})});msg('Topildi: <b>'+S.f.length+'</b> ta')}
function add(l){l.forEach(function(v){if(S.f.indexOf(v)<0)S.f.push(v)});sumList()}
function fdone(done){if(S.f.length>=6)done()}
function hist3(){var g=S.g;T(g,180,40,'१ २ ३ ४ ५ ६ ७ ८ ९ ०',{'font-size':22,fill:'#6b3d12'});T(g,180,60,'Hind raqamlari',{'font-size':11,fill:'#6b3d12'});T(g,180,100,'١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠',{'font-size':22,fill:'#6b3d12'});T(g,180,120,'Arab yozuvi',{'font-size':11,fill:'#6b3d12'});T(g,180,156,'1 2 3 4 5 6 7 8 9 0',{'font-size':22,'font-weight':800,fill:'#1d2b3a'});msg('Raqamlar Hindistondan — al-Xorazmiy orqali — butun dunyoga')}
var PROBS=[
{t:"7 yuzlik, 0 o'nlik va 9 birlik — qaysi son?",o:["709","790","79","7009"],k:0,s:"700 + 9 = 709."},
{t:"«To'qqiz yuz o'n» qanday yoziladi?",o:["910","9010","901","919"],k:0,s:"900 + 10 = 910."},
{t:"628 sonida jami nechta o'nlik bor?",o:["62","2","6","28"],k:0,s:"Oxirgi raqamni yopamiz: 62|8 — 62 ta o'nlik."},
{t:"815 sonida yuzliklar xonasidagi raqam qaysi?",o:["8","81","5","1"],k:0,s:"815: 8 yuzlik, 1 o'nlik, 5 birlik."},
{t:"6 yuzlik + 14 o'nlik + 7 birlik — qaysi son?",o:["747","6147","657","754"],k:0,s:"600 + 140 + 7 = 747."},
{t:"4 yuzlik + 23 o'nlik + 5 birlik — qaysi son?",o:["635","4235","455","625"],k:0,s:"400 + 230 + 5 = 635."},
{t:"37 ta o'nlik — qaysi son?",o:["370","37","3070","307"],k:0,s:"37 o'nlik = 370."},
{t:"Uch xonali sonlar jami nechta?",o:["900","999","899","1000"],k:0,s:"999 − 100 + 1 = 900."},
{t:"Raqamlari har xil bo'lgan eng katta uch xonali son qaysi?",o:["987","999","998","978"],k:0,s:"Eng katta raqamlar 9, 8, 7 — kamayish tartibida: 987."},
{t:"Raqamlari har xil bo'lgan eng kichik uch xonali son qaysi?",o:["102","100","123","012"],k:0,s:"Yuzlar 1, keyin 0, keyin 2: 102."},
{t:"7 yuzlik, o'nliklari yuzliklardan 6 ta kam, birliklari o'nliklardan 5 ta ko'p. Son?",o:["716","761","756","765"],k:0,s:"7; 7 − 6 = 1; 1 + 5 = 6 → 716."},
{t:"Raqamlari yig'indisi 3 ga teng uch xonali sonlar nechta?",o:["6","4","5","7"],k:0,s:"300, 210, 201, 120, 111, 102 — 6 ta."},
{t:"Men 400 dan katta, 420 dan kichik, 5 bilan tugayman, raqamlarim yig'indisi 10. Men kimman?",o:["415","405","425","514"],k:0,s:"Nomzodlar 405, 415. Yig'indisi 10 — 415."},
{t:"583 ga 2 ta yuzlik va 3 ta o'nlik qo'shilsa, qaysi son chiqadi?",o:["813","786","616","853"],k:0,s:"583 + 230 = 813."},
{t:"Qaysi sonda 45 ta o'nlik bor?",o:["452","45","4500","405"],k:0,s:"452 = 45 o'nlik va 2 birlik."},
{t:"Raqamlari har xil bo'lgan eng katta uch xonali son eng kichik ikki xonali sondan (raqamlari har xil) qancha katta?",o:["977","989","976","975"],k:0,s:"987 − 10 = 977."},
{t:"3, 0, 7 raqamlaridan (takrorlanmasdan) nechta uch xonali son tuzish mumkin?",o:["4","6","3","2"],k:0,s:"307, 370, 703, 730 — 4 ta (0 boshida turolmaydi)."},
{t:"Uch xonali sonning birinchi va oxirgi raqami 5, o'rtadagisi ulardan 3 ta kam. Son?",o:["525","535","555","252"],k:0,s:"5 − 3 = 2: 525."},
{t:"999 dan 1 ta yuzlik ayirilsa, qaysi son qoladi?",o:["899","998","989","900"],k:0,s:"999 − 100 = 899."},
{t:"Qaysi yozuv to'g'ri?",o:["560 = 56 o'nlik","560 = 6 o'nlik","560 = 5 o'nlik 6 birlik","560 = 506"],k:0,s:"560: oxirgi raqamni yopsak 56 — 56 o'nlik."}
];
function PRACT_STAGE(){a1(485)}
var PREP_DATA={teach:["Uch xonali sonlar takrori: xonalar, o'qish, yozish.","Xonadagi raqam va jami xona birliklari farqi (485: 8 va 48).","Xona birligi 9 dan ko'p bo'lgan yozuvlar; shartli topishmoqlar; tartibli sanash."],mist:["«Jami nechta o'nlik» savoliga xonadagi raqamni aytadi.","6 yuzlik + 14 o'nlik + 7 ni 6147 deb yozadi.","Shartli masalada «o'nliklardan 5 ta ko'p» ni yuzliklardan hisoblaydi.","Sanashda ba'zi sonlarni tushirib qoldiradi."],need:["Yuzlik, o'nlik, birlik kartochkalari yoki o'nlik bloklar."],board:["<span class='w2'>485 = 4 yuzlik 8 o'nlik 5 birlik</span>; jami o'nlik: <span class='w2'>48|5</span>.","<span class='w2'>600 + 140 + 7 = 747</span>.","<span class='w2'>23 o'nlik = 230</span>.","Shartlar: <span class='w2'>7 → 1 → 6</span>.","Daraxt: yuzlar 3 / 2 / 1 → 1 + 2 + 3 = 6."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
