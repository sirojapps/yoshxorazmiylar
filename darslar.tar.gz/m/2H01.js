var CODE='2H01',TITLE='2-sinf olimpiada · Sonli qonuniyatlar: keyingi son qaysi?';
// ---------- sahna: sonlar qatori ----------
// v: qiymatlar (null = noma'lum), o.d: farqlar yozuvlari, o.top: tepadagi yozuvlar
function h1seq(v,o){o=o||{};clear();var g=S.g,n=v.length,w=Math.min(46,330/n),x0=180-(n*w)/2;
 v.forEach(function(x,i){var cx=x0+i*w+w/2,un=x===null||x==='?',hl=o.hl&&o.hl.indexOf(i)>=0;E('rect',{x:cx-w/2+3,y:70,width:w-6,height:38,rx:8,fill:un?'#fff':(hl?C.hi:'#e8f1fb'),stroke:un?C.bad:'#9fbbd8','stroke-width':un?2.5:1.5,'stroke-dasharray':un?'5 3':''},g);T(g,cx,95,un?'?':String(x),{'font-size':w<36?12:16,'font-weight':800,fill:un?C.bad:'#1d2b3a'})});
 if(o.d)o.d.forEach(function(t,i){if(t==null)return;var a=x0+i*w+w/2,b=a+w;E('path',{d:'M'+(a+4)+' 66 Q'+(a+b)/2+' 40 '+(b-4)+' 66',fill:'none',stroke:o.dc||C.ok,'stroke-width':1.8},g);T(g,(a+b)/2,44,t,{'font-size':11,'font-weight':800,fill:o.dc||C.ok})});
 if(o.d2)o.d2.forEach(function(t,i){if(t==null)return;var a=x0+i*w+w,b=a+w;T(g,(a+b)/2,26,t,{'font-size':11,'font-weight':800,fill:C.a2})});
 if(o.lab)T(g,180,150,o.lab,{'font-size':13,'font-weight':800,fill:C.blue})}
function h1msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var P3=[function(){h1seq([7,10,16,25,null]);h1msg('7, 10, 16, 25, ? — qadam bir xil emas…')},
 function(){h1seq([7,10,16,25,null],{d:['+3','+6','+9',null]});h1msg('Farqlar: +3, +6, +9 — farqlarning o‘zi qonuniyat!')},
 function(){h1seq([7,10,16,25,37],{d:['+3','+6','+9','+12'],d2:['+3','+3','+3'],hl:[4]});h1msg('Farqlar 3 tadan ortadi: keyingisi +12 → 25 + 12 = <b>37</b>')}];
var P6=[function(){h1seq([10,'K',20,25,'L','M','N','P',50]);h1msg('Harflar o‘rnida qaysi sonlar? M + N = ?')},
 function(){h1seq([10,'K',20,25,'L','M','N','P',50],{d:[null,null,'+5']});h1msg('20 dan 25 ga: <b>+5</b>. Demak qadam — 5')},
 function(){h1seq([10,15,20,25,30,35,40,45,50],{hl:[1,4,5,6,7],d:['+5','+5','+5','+5','+5','+5','+5','+5']});h1msg('K = 15, L = 30, <b>M = 35</b>, <b>N = 40</b>, P = 45 → M + N = <b>75</b>')}];
var P7=[function(){h1sym(0)},function(){h1sym(1)},function(){h1sym(2)}];
var STEPS=[
{h:"Qadamni toping",sum:"Har safar bir xil son qo'shilsa yoki ayirilsa — qadamni topamiz: 52, 46, 40 … (−6).",a:"m01",
 start:function(){h1seq([10,15,20,25,null]);h1msg('Qonuniyatni toping')},fin:function(){h1seq([10,15,20,25,30],{d:['+5','+5','+5','+5'],hl:[4]});h1msg('Har safar +5: keyingi son <b>30</b>')},
 html:"<p>Sonlar qatori ma'lum <b>qoida</b> bilan yozilgan. Qoidani topish uchun qo'shni sonlar orasidagi <b>farqqa</b> qarang. Tugmani bosing.</p>",
 btns:[["🔍 Farqlarni ko'rsat",function(c,done){h1seq([10,15,20,25,30],{d:['+5','+5','+5','+5'],hl:[4]});h1msg('Har safar <b>+5</b>: 25 + 5 = 30');done()}]],
 after:"<p>Qoida: har safar <b>+5</b>. Bunday qatorlarda farq doim bir xil. Kamayib borsa — farq minus bo'ladi: 52, 46, 40 … — har safar <b>−6</b>.</p>",
 q:{t:"52, 46, 40, …, 28, 22. Nuqtalar o'rnida qaysi son?",opts:["34","32","36","30"],ok:0,why:"Har safar −6: 40 − 6 = 34, 34 − 6 = 28 ✓.",hint:"52 dan 46 ga qancha kamaydi? Shu qadam bilan davom eting.",full:"Qadam: 52 − 46 = 6. 40 − 6 = 34, tekshiramiz: 34 − 6 = 28 ✓, 28 − 6 = 22 ✓. «36» — qadam −4 deb olingan."},
 tn:"Bolalar farqlarni sonlar ustiga yoy chizib yozsin — xalqaro olimpiada tayyorgarligida standart usul."},
{h:"Ko'paytirib borish",sum:"3, 6, 12, 24 … — har safar 2 marta: keyingisi 48. Farqlar ham ikki barobar o'sadi.",a:"m02",
 start:function(){h1seq([3,6,12,24,null]);h1msg('Farqlar: 3, 6, 12 — bir xil emas. Boshqa qoida bormi?')},fin:function(){h1seq([3,6,12,24,48],{d:['·2','·2','·2','·2'],dc:C.a2,hl:[4]});h1msg('Har safar <b>2 marta</b>: 24 · 2 = 48')},
 html:"<p>3, 6, 12, 24, … Farqlar 3, 6, 12 — bir xil emas. Balki qo'shish emas, <b>ko'paytirish</b>dir? Tugmani bosing.</p>",
 btns:[["✖ Marta qoidasini tekshirish",function(c,done){h1seq([3,6,12,24,48],{d:['·2','·2','·2','·2'],dc:C.a2,hl:[4]});h1msg('6 = 3 · 2, 12 = 6 · 2, 24 = 12 · 2 → <b>48</b>');done()}]],
 after:"<p>Agar farqlar bir xil bo'lmasa — <b>marta</b> qoidasini tekshiring: har bir son oldingisidan necha marta katta? 3 → 6 → 12 → 24: har safar 2 marta.</p>",
 q:{t:"2, 6, 18, 54, … Keyingi son?",opts:["162","108","90","72"],ok:0,why:"Har safar 3 marta: 54 · 3 = 162.",hint:"6 ni 2 dan, 18 ni 6 dan necha marta katta?",full:"2 · 3 = 6, 6 · 3 = 18, 18 · 3 = 54, 54 · 3 = 162. «90» — farqni (36) qo'shish, lekin farqlar o'zgaryapti."},
 tn:"Ikki savolni doimo navbat bilan bering: «qancha ko'p?» va «necha marta ko'p?»"},
{h:"Farqlar ham qonuniyatli",sum:"7, 10, 16, 25: farqlar 3, 6, 9 → keyingi farq 12 → 37.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>7, 10, 16, 25, … — na qadam bir xil, na marta. Ikkinchi qavatga qaraymiz: <b>farqlarning farqi</b>.</p>",
 btns:[phaser(P3)],
 after:"<p>Agar farqlar ham o'zgarsa, <b>farqlar qatori</b>ning qonuniyatini qidiramiz: 3, 6, 9 — har safar +3. Demak keyingi farq 12 va son 25 + 12 = 37.</p>",
 q:{t:"2, 4, 8, 14, 22, … Keyingi son?",opts:["32","30","34","36"],ok:0,why:"Farqlar 2, 4, 6, 8 → keyingisi 10: 22 + 10 = 32.",hint:"Farqlarni yozing: 4 − 2, 8 − 4, …",full:"Farqlar: 2, 4, 6, 8 — har safar 2 ga ortadi. Keyingi farq 10: 22 + 10 = 32. «30» — farq 8 takrorlangan; «44» — ikki marta deb olingan."},
 tn:"Farqlarni sonlar qatori ostiga ikkinchi qator qilib yozdiring — bu «farqlar jadvali»."},
{h:"Ikki qator aralashgan",sum:"1, 10, 2, 20, 3, 30, … — toq o'rinlarda 1, 2, 3; juft o'rinlarda 10, 20, 30.",a:"m04",
 start:function(){h1seq([1,10,2,20,3,30,null]);h1msg('Bitta qoida ko‘rinmayapti…')},fin:function(){h1seq([1,10,2,20,3,30,4],{hl:[0,2,4,6]});h1msg('Sariq — 1, 2, 3, <b>4</b>; ko‘k — 10, 20, 30')},
 html:"<p>1, 10, 2, 20, 3, 30, … Qo'shni sonlar orasida tartib yo'qqa o'xshaydi. Balki bu yerda <b>ikkita qator</b> aralashgandir? Tugmani bosing.</p>",
 btns:[["🎨 Ajratib ko'rsat",function(c,done){h1seq([1,10,2,20,3,30,4],{hl:[0,2,4,6]});h1msg('Sariq qator: 1, 2, 3 → <b>4</b>. Ko‘k qator: 10, 20, 30 → keyin 40');done()}]],
 after:"<p>Bir o'rindan sakrab qarasak, ikki alohida qator ko'rinadi: 1, 2, 3, … va 10, 20, 30, … Keyingi son birinchi qatordan — <b>4</b>.</p>",
 q:{t:"5, 50, 6, 45, 7, 40, … Keyingi son?",opts:["8","35","41","9"],ok:0,why:"Birinchi qator 5, 6, 7 → 8; ikkinchi 50, 45, 40.",hint:"Har ikkinchi sonni alohida yozing.",full:"Qatorlar: 5, 6, 7, … (+1) va 50, 45, 40, … (−5). Navbat birinchi qatorda: 8. «35» — ikkinchi qatorning keyingisi, lekin hozir uning navbati emas."},
 tn:"Bunday qatorlarni ikki rangli qalam bilan bo'yatib ko'ring."},
{h:"Fibonachchi qatori",sum:"1, 1, 2, 3, 5, 8, 13 … — har bir son oldingi ikkitasining yig'indisi.",a:"m05",
 start:function(){h1seq([1,1,2,3,5,8,null]);h1msg('Farqlar: 0, 1, 1, 2, 3 — tanishmi?')},fin:function(){h1seq([1,1,2,3,5,8,13],{hl:[4,5,6]});h1msg('5 + 8 = <b>13</b>')},
 html:"<p>1, 1, 2, 3, 5, 8, … Bu mashhur qator! Har bir son qanday hosil bo'lishini ko'ring — tugmani bosing.</p>",
 btns:[["➕ Qoidani ko'rsat",function(c,done){h1seq([1,1,2,3,5,8,13],{hl:[4,5,6]});h1msg('1 + 1 = 2, 1 + 2 = 3, 2 + 3 = 5, 3 + 5 = 8, <b>5 + 8 = 13</b>');done()}]],
 after:"<p>Har bir son — <b>oldingi ikkita sonning yig'indisi</b>. Bu qatorni 800 yil oldin italiyalik olim Fibonachchi kitobida yozgan.</p>",
 q:{t:"0, 1, 1, 2, 3, 5, 8, 13, 21, 34, … Keyingi son?",opts:["55","47","42","68"],ok:0,why:"21 + 34 = 55.",hint:"Oxirgi ikki sonni qo'shing.",full:"Fibonachchi qatori: 21 + 34 = 55. «47» — farq 13 qo'shilgan, «68» — 34 ikki marta."},
 tn:"Kungaboqar va qarag'ay qubbasidagi spirallar soni ko'pincha Fibonachchi sonlari bo'ladi — rasm ko'rsating."},
{h:"Tuzoq: harflar o'rnida sonlar",sum:"10, K, 20, 25, L, M, N, P, 50: qadam 5 → M = 35, N = 40, M + N = 75.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bank testidagi savol: <i>«10, K, 20, 25, L, M, N, P, 50 sonlar qatorida harflar o'rniga mos sonlarni qo'ying va M + N ni toping.»</i></p>",
 btns:[phaser(P6)],
 after:"<p>Qadamni <b>yonma-yon turgan ikki ma'lum sondan</b> topamiz: 20 va 25 — qadam 5. Tekshiramiz: 10 dan 50 gacha 8 ta qadam, 8 · 5 = 40 ✓. Keyin harflar bittalab to'ldiriladi.</p>",
 q:{t:"4, A, 12, B, 20, C. A + C = ?",opts:["32","24","28","36"],ok:0,why:"Qadam 4: A = 8, B = 16, C = 24. 8 + 24 = 32.",hint:"4 dan 12 gacha ikki qadam. Bitta qadam qancha?",full:"4 → 12 — ikki qadam = 8, bitta qadam 4. A = 8, B = 16, C = 24. A + C = 32."},
 tn:"Bolalar avval qadamni topib, ikki ma'lum son bilan tekshirsin — keyin to'ldirsin."},
{h:"Tuzoq: yangi amal belgisi",sum:"7 ☺ 9 = 15, 38 ☺ 4 = 41: qoida a + b − 1 → 8 ☺ 3 = 10.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Olimpiada savoli: <i>«7 ☺ 9 = 15; 38 ☺ 4 = 41; 6 ☺ 11 = 16. 8 ☺ 3 = ?»</i> ☺ — yangi, o'ylab topilgan amal. Uning qoidasini topamiz.</p>",
 btns:[phaser(P7)],
 after:"<p>Usul: oddiy amallarni sinab ko'ramiz. 7 + 9 = 16, javob 15 — 1 kam. 38 + 4 = 42, javob 41 — yana 1 kam. Qoida: <b>a ☺ b = a + b − 1</b>. Albatta <b>hamma</b> misolda tekshiring!</p>",
 q:{t:"5 ★ 3 = 16, 4 ★ 2 = 9, 6 ★ 1 = 7. 3 ★ 3 = ?",opts:["10","9","6","12"],ok:0,why:"Qoida a · b + 1: 3 · 3 + 1 = 10.",hint:"Ko'paytmani sinab ko'ring: 5 · 3 = 15, javob 16 — farqi qancha?",full:"5 · 3 = 15 → 16, 4 · 2 = 8 → 9, 6 · 1 = 6 → 7: har safar ko'paytmaga 1 qo'shilgan. Qoida a · b + 1: 3 · 3 + 1 = 10. «9» — 1 qo'shish unutilgan, «6» — qo'shilgan."},
 tn:"Topilgan qoidani albatta barcha misollarda tekshirish odatini singdiring."},
{h:"Bilasizmi? Fibonachchi va quyonlar",sum:"Fibonachchi 1202-yili «Hisob kitobi»da quyonlar haqidagi masala orqali bu qatorni yozgan.",a:"m08",
 start:function(){h1seq([1,1,2,3,5,8,13,21]);h1msg('1202-yil · «Liber Abaci»')},fin:function(){h1seq([1,1,2,3,5,8,13,21]);h1msg('1202-yil · «Liber Abaci»')},
 html:"<p>🐇 Italiyalik matematik <b>Leonardo Fibonachchi</b> 1202-yili «Hisob kitobi» (Liber Abaci) asarida quyonlar ko'payishi haqidagi masalani yozgan — javobi aynan 1, 1, 2, 3, 5, 8 … qatori bo'lib chiqqan.</p><p>⭐ Qiziq: Fibonachchi aynan shu kitobi orqali Yevropaga biz ishlatadigan <b>0–9 raqamlarini</b> tanitgan. U bu raqamlarni arab olimlarining asarlaridan, jumladan, <b>al-Xorazmiy</b> an'anasidan o'rgangan!</p>",
 tn:"Ananasning po'stidagi, kungaboqarning urug'laridagi spirallarni sanab ko'ring — ko'pincha 8, 13, 21 chiqadi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){h1seq([10,15,20,25,30],{d:['+5','+5','+5','+5']});h1msg('Qonuniyatlar')},fin:function(){h1seq([10,15,20,25,30],{d:['+5','+5','+5','+5']});h1msg('Qonuniyatlar')},
 html:"<div class='memo'><ul><li>1) <b>Farqni</b> toping: bir xil bo'lsa — qadam (+5, −6).</li><li>2) Farq o'zgarsa — <b>marta</b>ni tekshiring (·2, ·3).</li><li>3) Bo'lmasa — <b>farqlar qatori</b>ning qonuniyati (3, 6, 9 …).</li><li>4) Sakrab qarang — <b>ikki qator</b> aralashgan bo'lishi mumkin.</li><li>5) Oldingi ikkitasining <b>yig'indisi</b> — Fibonachchi.</li><li>Harflar o'rnida: qadamni ikki qo'shni ma'lum sondan toping.</li><li>Yangi belgi: oddiy amallarni sinang va <b>hamma</b> misolda tekshiring.</li></ul></div>",
 tn:"Keyingi darsni «1, 4, 9, 16, ?» (25 — kvadratlar) savoli bilan boshlang."}
];
function h1sym(k){clear();var g=S.g,R=[['7 ☺ 9','15','7 + 9 = 16 → 15'],['38 ☺ 4','41','38 + 4 = 42 → 41'],['6 ☺ 11','16','6 + 11 = 17 → 16'],['8 ☺ 3','?','8 + 3 − 1 = 10']];
 R.forEach(function(r,i){var y=34+i*34,last=i===3;T(g,70,y,r[0]+' = '+(last&&k>=2?'10':r[1]),{'font-size':16,'font-weight':800,fill:last?(k>=2?C.ok:C.bad):'#1d2b3a'});if(k>=1&&!last)T(g,240,y,r[2],{'font-size':13,'font-weight':700,fill:C.blue});if(k>=2&&last)T(g,240,y,r[2],{'font-size':13,'font-weight':800,fill:C.ok})});
 h1msg(['☺ qanday amal? Oddiy amallarni sinaymiz','Qo‘shamiz: har safar natijadan <b>1 kam</b>','Qoida: <b>a ☺ b = a + b − 1</b> → 8 ☺ 3 = <b>10</b>'][k])}
var PROBS=[
{t:"3, 7, 11, 15, … Keyingi son?",o:["19","18","20","17"],k:0,s:"Har safar +4: 15 + 4 = 19."},
{t:"90, 81, 72, 63, … Keyingi son?",o:["54","53","56","45"],k:0,s:"Har safar −9: 63 − 9 = 54."},
{t:"1, 2, 4, 8, 16, … Keyingi son?",o:["32","24","20","18"],k:0,s:"Har safar 2 marta: 16 · 2 = 32."},
{t:"7, 10, 16, 25, … Keyingi son?",o:["37","36","34","39"],k:0,s:"Farqlar 3, 6, 9 → 12: 25 + 12 = 37."},
{t:"2, 4, 8, 14, 22, … Keyingi son?",o:["32","30","34","36"],k:0,s:"Farqlar 2, 4, 6, 8 → 10: 22 + 10 = 32."},
{t:"1, 3, 6, 10, 15, … Keyingi son?",o:["21","20","19","25"],k:0,s:"Farqlar 2, 3, 4, 5 → 6: 15 + 6 = 21."},
{t:"1, 4, 9, 16, 25, … Keyingi son?",o:["36","34","30","49"],k:0,s:"1·1, 2·2, 3·3, 4·4, 5·5 → 6·6 = 36."},
{t:"0, 1, 1, 2, 3, 5, 8, 13, 21, 34, … Keyingi son?",o:["55","47","42","68"],k:0,s:"21 + 34 = 55."},
{t:"2, 20, 3, 30, 4, 40, … Keyingi son?",o:["5","50","44","6"],k:0,s:"Ikki qator: 2, 3, 4 → 5; 20, 30, 40."},
{t:"10, K, 20, 25, L, M, N, P, 50. M + N = ?",o:["75","40","45","35"],k:0,s:"Qadam 5: M = 35, N = 40, 35 + 40 = 75."},
{t:"7 ☺ 9 = 15; 38 ☺ 4 = 41; 6 ☺ 11 = 16; 8 ☺ 3 = ?",o:["10","11","12","14"],k:0,s:"a ☺ b = a + b − 1: 8 + 3 − 1 = 10."},
{t:"5, 10, 9, 18, 17, 34, … Keyingi son?",o:["33","68","35","32"],k:0,s:"Navbat bilan: ·2, −1, ·2, −1 … → 34 − 1 = 33."},
{t:"5, 15, 45, … Keyingi son?",o:["135","75","90","60"],k:0,s:"Har safar 3 marta: 45 · 3 = 135."},
{t:"Qushlar galasi: oldinda 1, keyin 2, keyin 3 … oxirgi qatorda 7 ta. Jami nechta qush?",o:["28","27","21","36"],k:0,s:"1 + 2 + 3 + 4 + 5 + 6 + 7 = 28."},
{t:"1, 2, 6, 24, … Keyingi son?",o:["120","48","96","30"],k:0,s:"·2, ·3, ·4 → ·5: 24 · 5 = 120."},
{t:"11, 22, 33, 44, … 9-o'rindagi son?",o:["99","88","90","110"],k:0,s:"n-o'rinda n · 11: 9 · 11 = 99."},
{t:"Sanoq 0 dan boshlanib har safar 14 ga ortadi: 0, 14, 28, 42 … 7-o'rinda qaysi son (0 — 1-o'rinda)?",o:["84","98","70","56"],k:0,s:"7-o'rin: 6 ta qadam · 14 = 84."},
{t:"3, 5, 9, 15, 23, … Keyingi son?",o:["33","31","29","35"],k:0,s:"Farqlar 2, 4, 6, 8 → 10: 23 + 10 = 33."},
{t:"64, 32, 16, 8, … Keyingi son?",o:["4","0","6","2"],k:0,s:"Har safar 2 marta kamayadi: 8 : 2 = 4."},
{t:"4 ◊ 2 = 10; 5 ◊ 3 = 18; 6 ◊ 1 = 7. 3 ◊ 4 = ?",o:["16","15","12","19"],k:0,s:"Qoida a · b + b: 8 + 2 = 10, 15 + 3 = 18, 6 + 1 = 7 ✓. 3 · 4 + 4 = 16."}
];
function PRACT_STAGE(){h1seq([10,15,20,25,null],{d:['+5','+5','+5',null]});h1msg('Avval farqlarni yozing')}
var PREP_DATA={teach:["Qadam (farq) bo'yicha qatorlar; kamayuvchi qatorlar.","Marta bo'yicha qatorlar; farqlar qatori.","Aralash (ikki qatorli) qatorlar; Fibonachchi qatori.","Harflar o'rnidagi sonlar; yangi amal belgisi qoidasini topish."],
 mist:["Faqat oxirgi ikki songa qarab qoida tuzadi.","Farq o'zgarsa, darhol taslim bo'ladi.","Topilgan qoidani barcha misolda tekshirmaydi.","Aralash qatorni bitta qator deb o'ylaydi."],
 need:["Raqamli kartochkalar.","Ikki rangli qalam."],
 board:["<span class='w2'>10, 15, 20, 25 → +5</span>.","<span class='w2'>3, 6, 12, 24 → ·2</span>.","<span class='w2'>7, 10, 16, 25: +3, +6, +9 → +12</span>.","<span class='w2'>1, 10, 2, 20, 3, 30</span> — ikki qator.","Fibonachchi: <span class='w2'>1, 1, 2, 3, 5, 8, 13</span>.","<span class='w2'>a ☺ b = a + b − 1</span>."]};
