var CODE='2D1',TITLE='2-sinf · Bir amalli masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
var F1={t:'Masala',lines:['Avtobusda 40 ta o‘rin bor.','27 kishi o‘tirib bo‘ldi.','Yana nechta kishi o‘tira oladi?']};
var F1ok={t:'Masala',lines:['Avtobusda 40 ta o‘rin bor.','27 kishi o‘tirib bo‘ldi.','Yana nechta kishi o‘tira oladi?'],hl:{0:'ok',1:'ok',2:'q'},note:'Yashil — <b>shart</b> (ma’lum narsalar), sariq — <b>savol</b> (topish kerak)'};
var STEPS=[
bmStep({h:"Masala nimadan iborat?",sum:"Masalada shart (ma'lum sonlar) va savol (nima topiladi) bor.",a:"m01",frames:[F1],
 html:"<p>Har bir masalada ikki qism bor: <b>shart</b> — biz biladigan narsalar va <b>savol</b> — topishimiz kerak bo'lgan narsa. Tepadagi masalada qaysi gap <b>savol</b>?</p>",
 btns:bmPick(["1-gap","2-gap","3-gap"],2,F1ok,["Bu gapda biz biladigan son bor — bu shart.","Bu ham shart: 27 kishi o‘tirgani ma’lum.",""]),
 after:"<p>Savol odatda <b>«nechta?», «qancha?»</b> so'zlari bilan tugaydi va oxirida <b>«?»</b> turadi. Masalani o'qiganda avval savolni toping: nima topishimiz kerak?</p>",
 q:{t:"«Bog'da 12 ta olma daraxti bor. 5 tasi gulladi.» Bu masalada nima yetishmaydi?",opts:["Shart","Savol","Sonlar","Hech narsa"],ok:1,why:"Savol yo'q — nimani topish kerakligi aytilmagan.",hint:"Gaplarda «nechta?» yoki «?» bormi?",full:"Ikkala gapda ham ma'lum narsalar — bu shart. Lekin «nechta gullamagan?» kabi savol yo'q. Savolsiz masala bo'lmaydi."},
 tn:"Bolalarga masalani ovoz chiqarib o'qitib, savolni chizg'ich bilan tagiga chizdiring. Bu odat yuqori sinflarda ham asqotadi."}),
bmStep({h:"Qismlar ma'lum — butunni topamiz",sum:"Ikki qism qo'shilsa — butun: 25 + 17 = 42.",a:"m02",
 frames:[{t:'Bog‘da 25 ta olma va 17 ta nok daraxti. Jami nechta?',bars:[{y:62,segs:[{w:25,txt:'25 olma',c:'a'},{w:17,txt:'17 nok',c:'g'}]}],note:'Ikki qismni bitta chiziqqa chizamiz'},
  {t:'Bog‘da 25 ta olma va 17 ta nok daraxti. Jami nechta?',bars:[{y:62,segs:[{w:25,txt:'25 olma',c:'a'},{w:17,txt:'17 nok',c:'g'}]}],br:[{b:0,lab:'jami = ?',up:true}],note:'Butun — qavs bilan. U noma’lum'},
  {t:'Bog‘da 25 ta olma va 17 ta nok daraxti. Jami nechta?',bars:[{y:62,segs:[{w:25,txt:'25 olma',c:'a'},{w:17,txt:'17 nok',c:'g'}]}],br:[{b:0,lab:'jami = 42',up:true,col:C.ok}],calc:['Qismlar ma’lum, butun noma’lum → <b>qo‘shamiz</b>','25 + 17 = <b>42</b> ta daraxt']}],
 html:"<p>Masalani <b>chizma</b> bilan yechamiz: sonlarni chiziq bo'laklari qilib chizamiz. Bu usul Singapurda o'ylab topilgan va butun dunyoda ishlatiladi. Tugmani bosib, chizmani quring.</p>",
 after:"<p><b>Qoida:</b> butunning qismlari ma'lum bo'lsa, butunni topish uchun qismlarni <b>qo'shamiz</b>.</p>",
 q:{t:"Lolada 18 ta, Zarinada 15 ta marka bor. Ikkalasida jami nechta marka bor?",opts:["3","33","23","35"],ok:1,why:"Ikki qism qo'shiladi: 18 + 15 = 33.",hint:"Qismlar ma'lummi yoki butunmi? Butunni topish uchun qaysi amal kerak?",full:"Lolaniki va Zarinaniki — ikki qism, jami — butun. Butunni topish uchun qo'shamiz: 18 + 15 = 33. «3» — bu farq, savolda farq so'ralmagan."},
 tn:"Singapur usuli: «qism — qism — butun» chizmasini har masalada chizdiring. Bola chizmadan amalni o'zi topadi."}),
bmStep({h:"Butun ma'lum — qismni topamiz",sum:"Butundan ma'lum qism ayiriladi: 40 − 27 = 13.",a:"m03",
 frames:[{t:'Avtobusda 40 o‘rin, 27 kishi o‘tirdi. Yana nechta o‘tira oladi?',bars:[{y:66,segs:[{w:27,txt:'27 band',c:'b'},{w:13,txt:'?',c:'q'}]}],br:[{b:0,lab:'40 o‘rin',up:true}],note:'Butun (40) ma’lum, bitta qism (27) ma’lum'},
  {t:'Avtobusda 40 o‘rin, 27 kishi o‘tirdi. Yana nechta o‘tira oladi?',bars:[{y:66,segs:[{w:27,txt:'27 band',c:'b'},{w:13,txt:'13 bo‘sh',c:'g'}]}],br:[{b:0,lab:'40 o‘rin',up:true}],calc:['Butun ma’lum, qism noma’lum → <b>ayiramiz</b>','40 − 27 = <b>13</b> kishi']}],
 html:"<p>Endi teskarisi: <b>butun</b> ma'lum, bitta <b>qism</b> noma'lum. Chizmani kuzating.</p>",
 after:"<p><b>Qoida:</b> butun va bitta qism ma'lum bo'lsa, ikkinchi qismni topish uchun butundan ma'lum qismni <b>ayiramiz</b>. Tekshirish: 27 + 13 = 40 ✓</p>",
 q:{t:"Savatda 34 ta tuxum bor edi, 16 tasi pishirildi. Nechta tuxum qoldi?",opts:["50","18","22","16"],ok:1,why:"34 − 16 = 18.",hint:"Butun qaysi son? Qism qaysi? Qolganini topish uchun nima qilamiz?",full:"Butun — 34 ta tuxum, pishirilgani — bitta qism (16). Qolgani: 34 − 16 = 18. «50» — qo'shib yuborilgan, tuxum ko'paymaydi-ku!"},
 tn:"Bolalarga savol bering: «Javob butundan katta bo'ladimi yoki kichik?» Bu oddiy tekshiruv ko'p xatoni to'xtatadi."}),
bmStep({h:"Tuzoq: so'zga emas, ma'noga qarang",sum:"«Qo'shildi» so'zi bor, lekin noma'lum qism — ayirish kerak: 34 − 25 = 9.",a:"m04",
 frames:[{t:'Darsda 25 o‘quvchi bor edi. Yana bir nechtasi QO‘SHILDI, 34 ta bo‘ldi.',bars:[{y:70,segs:[{w:25,txt:'25 bor edi',c:'b'},{w:9,txt:'?',c:'q'}]}],br:[{b:0,lab:'34 bo‘ldi',up:true}],note:'Nechta o‘quvchi qo‘shilgan? Qaysi amal kerak?'}],
 html:"<p>«Qo'shildi» so'zini ko'rib, ko'pchilik darrov qo'shadi: 25 + 34 = 59. Chizmaga qarang va to'g'ri amalni tanlang:</p>",
 btns:bmPick(["25 + 34","34 − 25","34 + 9"],1,{t:'Darsda 25 o‘quvchi bor edi. Yana bir nechtasi QO‘SHILDI, 34 ta bo‘ldi.',bars:[{y:70,segs:[{w:25,txt:'25 bor edi',c:'b'},{w:9,txt:'9 qo‘shildi',c:'g'}]}],br:[{b:0,lab:'34 bo‘ldi',up:true}],calc:['34 — butun, 25 — qism. Qo‘shilganlar — ikkinchi qism','34 − 25 = <b>9</b> o‘quvchi']},["Unda 59 o‘quvchi bo‘lib qoladi — lekin 34 ta bo‘lgan-ku!","","9 ni hali bilmaymiz — uni topyapmiz."]),
 after:"<p>So'zlar aldashi mumkin! «Qo'shildi», «ko'p», «berdi» so'zlari amalni aytmaydi. Amalni <b>chizma</b> aytadi: butun noma'lum bo'lsa — qo'shamiz, qism noma'lum bo'lsa — ayiramiz.</p>",
 q:{t:"Alida bir nechta konfet bor edi. Onasi yana 8 ta berdi va 23 ta bo'ldi. Boshida nechta konfet bor edi?",opts:["31","15","8","23"],ok:1,why:"23 — butun, 8 — qism: 23 − 8 = 15.",hint:"«Berdi» so'ziga emas, chizmaga qarang: noma'lum — butunmi yoki qismmi?",full:"Oxirida 23 ta — bu butun. Onasi bergani 8 — bitta qism. Boshidagisi — ikkinchi qism: 23 − 8 = 15. Tekshiramiz: 15 + 8 = 23 ✓."},
 tn:"Bolalar «kalit so'zlar» orqali amal tanlashga o'rganib qolmasin — xalqaro tadqiqotlar bu usul xato berishini ko'rsatgan. Doim chizma chizdiring."}),
bmStep({h:"Tuzoq: «…dan … ta ko'p» teskari aytilsa",sum:"«16 — bu Validan 5 ta ko'p» → Vali kam: 16 − 5 = 11.",a:"m05",
 frames:[{t:'Alida 16 ta baliq. Bu Valining baliqlaridan 5 ta KO‘P.',bars:[{lab:'Ali',y:44,segs:[{w:16,txt:'16',c:'a'}]},{lab:'Vali',y:104,segs:[{w:11,txt:'?',c:'q'}]}],txt:[[300,121,'5 ta kam',{fill:C.bad,'font-size':11}]],note:'Kimda ko‘p? Alidami yoki Validami?'}],
 html:"<p>«Ko'p» so'zi bor — demak qo'shamizmi? Chizmaga qarang: kimning chizig'i uzun? To'g'ri amalni tanlang:</p>",
 btns:bmPick(["16 + 5","16 − 5"],1,{t:'Alida 16 ta baliq. Bu Valining baliqlaridan 5 ta KO‘P.',bars:[{lab:'Ali',y:44,segs:[{w:11,txt:'11',c:'a'},{w:5,txt:'5',c:'c'}]},{lab:'Vali',y:104,segs:[{w:11,txt:'11',c:'b'}]}],calc:['Alida ko‘p → Valida <b>kam</b>','16 − 5 = <b>11</b> ta baliq']},["Unda Valida 21 ta bo‘ladi — Validan ko‘p bo‘lib qoladi. Lekin Ali ko‘p-ku!"]),
 after:"<p>«Bu Valinikidan 5 ta ko'p» — demak <b>Alida</b> ko'p, <b>Valida</b> kam. Valinikini topish uchun ayiramiz: 16 − 5 = 11.</p>",
 q:{t:"Lola 45 ochko to'pladi. Bu Alining ochkosidan 12 ta kam. Ali nechta ochko to'plagan?",opts:["33","57","12","45"],ok:1,why:"Lolada kam — demak Alida ko'p: 45 + 12 = 57.",hint:"Kimda ko'p: Lolada yoki Alida? Chizmada kimning chizig'i uzun bo'ladi?",full:"«Bu Alinikidan 12 ta kam» — Lolada kam, Alida ko'p. Alini topish: 45 + 12 = 57. «33» — «kam» so'zini ko'rib ayirib yuborish xatosi."},
 tn:"Bu — eng ko'p xato qilinadigan tur. Doskada ikki chiziq chizib, avval «kim ko'p?» degan savolga javob berdiring."}),
bmStep({h:"Tuzoq: «…tasidan tashqari»",sum:"«7 tasidan tashqari hammasini sotdi» → 7 ta qoldi. Hisoblash shart emas!",a:"m06",
 frames:[{t:'Fermerda 16 ta echki. U 7 TASIDAN TASHQARI hammasini sotdi.',bars:[{y:70,segs:[{w:9,txt:'sotildi',c:'x'},{w:7,txt:'7 qoldi',c:'g'}]}],br:[{b:0,lab:'16 ta echki',up:true}],calc:['«7 tasidan tashqari hammasi» sotildi → <b>7 tasi qoldi</b>','Sotilgani: 16 − 7 = 9 ta, qolgani — 7 ta']}],
 html:"<p>Masala: <i>«Fermerda 16 ta echki bor edi. U 7 tasidan tashqari hammasini sotdi. Nechta echki qoldi?»</i> Javobni tanlang:</p>",
 btns:bmPick(["9 ta","7 ta","23 ta"],1,null,["9 tasi sotildi — savol esa qolganlarni so‘rayapti.","","Echki ko‘paymaydi-ku!"]),
 after:"<p>Shoshilgan bola 16 − 7 = 9 deydi. Lekin «7 tasidan <b>tashqari</b> hammasi sotildi» — demak <b>7 tasi qoldi</b>. Bunday masalada hisoblash umuman kerak emas — faqat diqqat bilan o'qish!</p>",
 q:{t:"Savatda 20 ta olma bor edi. Bolalar 4 tasidan tashqari hammasini yeyishdi. Nechta olma yeyildi?",opts:["4","16","24","20"],ok:1,why:"4 tasi qoldi, yeyilgani 20 − 4 = 16.",hint:"Nechtasi qoldi? Savol qoldigini so'rayaptimi yoki yeyilganini?",full:"«4 tasidan tashqari hammasi yeyildi» — 4 tasi qoldi. Yeyilgani: 20 − 4 = 16. Bu safar savol yeyilganini so'rayapti, shuning uchun hisoblaymiz."},
 tn:"Bunday tuzoq olimpiada testlarida tez-tez keladi. Bolalarga savolni ikki marta o'qishni odat qildiring."}),
bmStep({h:"Javobni tekshiramiz",sum:"Javobni shartga qo'yib tekshiramiz: 27 + 13 = 40 ✓.",a:"m07",
 frames:[{t:'Tekshirish: javobni shartga qo‘yamiz',bars:[{y:66,segs:[{w:27,txt:'27',c:'b'},{w:13,txt:'13',c:'g'}]}],br:[{b:0,lab:'40 ?',up:true}],note:'Topgan javobimiz — 13. Qismlarni qo‘shsak, butun chiqadimi?'},
  {t:'Tekshirish: javobni shartga qo‘yamiz',bars:[{y:66,segs:[{w:27,txt:'27',c:'b'},{w:13,txt:'13',c:'g'}]}],br:[{b:0,lab:'40 ✓',up:true,col:C.ok}],calc:['27 + 13 = 40 — shartdagi butun chiqdi','Demak javob <b>to‘g‘ri</b> ✓']}],
 html:"<p>Har bir masala oxirida 10 soniya vaqt ajrating: javobni <b>shartga qo'yib</b> tekshiring. Kuzating.</p>",
 after:"<p>Ayirish bilan topilgan javob — qo'shish bilan, qo'shish bilan topilgani — ayirish bilan tekshiriladi. Yana bir tez tekshiruv: <b>javob mantiqqa to'g'ri keladimi?</b> (Avtobusga 67 kishi sig'masligi aniq-ku!)</p>",
 q:{t:"Ali masalani yechib 46 − 18 = 32 deb yozdi. Tekshirsak nima chiqadi?",opts:["32 + 18 = 50, xato","32 + 18 = 46, to'g'ri","46 + 18 = 64","32 − 18 = 14"],ok:0,why:"32 + 18 = 50, 46 emas — javob xato. To'g'risi 28.",hint:"Javobga ayirilgan sonni qo'shing. Kamayuvchi chiqadimi?",full:"Tekshirish: 32 + 18 = 50. Lekin 46 chiqishi kerak edi — demak xato. To'g'ri javob: 46 − 18 = 28, chunki 28 + 18 = 46 ✓."},
 tn:"Bolalarga «tekshirdim» belgisini (✓) har javob yoniga qo'yishni o'rgating."}),
bmStep({h:"Bilasizmi? Chizma usulining tarixi",sum:"Chizma (bar model) usulini 1980-yillarda Singapur o'qituvchilari yaratgan.",a:"m08",
 frames:[{t:'Singapur chizma modeli',bars:[{lab:'qism',y:40,segs:[{w:3,txt:'',c:'a'},{w:2,txt:'',c:'g'}]},{lab:'taqqoslash',y:100,segs:[{w:3,txt:'',c:'b'}]},{y:130,off:0,segs:[{w:5,txt:'',c:'c'}]}],note:'Ikkita asosiy chizma: «qism–butun» va «taqqoslash»'}],
 html:"<p>🇸🇬 1980-yillarda Singapurda ko'p bolalar matnli masalalarni yecha olmas edi. O'qituvchilar guruhi (rahbari — <b>Kho Tek Hong</b>) masalani <b>chiziqlar bilan chizish</b> usulini o'ylab topdi.</p><p>Natija: bugun Singapur o'quvchilari matematika bo'yicha xalqaro reytinglarda doim birinchilar qatorida. Bu usul AQSh, Angliya va boshqa ko'p mamlakatlar darsliklariga kirgan.</p>",
 tn:"Bolalarga ayting: «Biz ham dunyodagi eng kuchli usul bilan o'qiyapmiz»."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'Qism — qism — butun',bars:[{y:66,segs:[{w:25,txt:'qism',c:'a'},{w:17,txt:'qism',c:'g'}]}],br:[{b:0,lab:'butun',up:true}]}],
 html:"<div class='memo'><ul><li>Masala = <b>shart</b> (ma'lum) + <b>savol</b> (topiladi). Avval savolni toping.</li><li><b>Chizma chizing:</b> qismlar — chiziq bo'laklari, butun — qavs.</li><li>Qismlar ma'lum, butun noma'lum → <b>qo'shamiz</b>.</li><li>Butun ma'lum, qism noma'lum → <b>ayiramiz</b>.</li><li>So'zlarga ishonmang («qo'shildi», «ko'p»), <b>chizmaga</b> ishoning.</li><li>«Bu … dan 5 ta ko'p» — avval <b>kim ko'p</b> ekanini aniqlang.</li><li>«…tasidan tashqari» — diqqat bilan o'qing.</li><li>Javobni <b>tekshiring</b>: shartga qo'yib ko'ring.</li></ul></div>",
 tn:"Keyingi darsni «Valida 23 ta marka bor, bu Alinikidan 7 ta kam. Alida nechta?» savoli bilan boshlang."})
];
var PROBS=[
{t:"Do'konda 56 ta non bor edi. 28 tasi sotildi. Nechta non qoldi?",o:["28","84","38","18"],k:0,s:"56 − 28 = 28."},
{t:"1-sinfda 24 ta, 2-sinfda 27 ta o'quvchi bor. Ikkala sinfda jami nechta o'quvchi bor?",o:["51","41","3","61"],k:0,s:"24 + 27 = 51."},
{t:"Avtobusda 40 ta o'rin bor. 27 kishi o'tirib bo'ldi. Yana nechta kishi o'tira oladi?",o:["13","67","23","27"],k:0,s:"40 − 27 = 13."},
{t:"Onlayn darsda 25 o'quvchi bor edi. Yana bir nechtasi qo'shildi va 34 ta bo'ldi. Nechta o'quvchi qo'shilgan?",o:["9","59","11","34"],k:0,s:"34 − 25 = 9."},
{t:"Alining akvariumida 16 ta baliq bor. Bu Valining baliqlaridan 5 ta ko'p. Valida nechta baliq bor?",o:["11","21","5","16"],k:0,s:"Alida ko'p, Valida kam: 16 − 5 = 11."},
{t:"Lola 45 ochko to'pladi. Bu Alining ochkosidan 12 ta kam. Ali nechta ochko to'plagan?",o:["57","33","12","45"],k:0,s:"Lolada kam, Alida ko'p: 45 + 12 = 57."},
{t:"Fermerda 16 ta echki bor edi. U 7 tasidan tashqari hammasini sotdi. Nechta echki qoldi?",o:["7","9","16","23"],k:0,s:"7 tasidan tashqari hammasi sotildi — 7 tasi qoldi."},
{t:"Jamoa bu mavsumda 23 ta gol urdi. O'tgan mavsumda 9 ta kam gol urgan edi. O'tgan mavsumda nechta gol?",o:["14","32","9","23"],k:0,s:"23 − 9 = 14."},
{t:"Kutubxonada 63 ta kitob bor edi. Yana bir nechta keltirildi va 80 ta bo'ldi. Nechta kitob keltirildi?",o:["17","143","27","23"],k:0,s:"80 − 63 = 17."},
{t:"Zaynab 38 sahifa o'qidi, unga yana 19 sahifa o'qish qoldi. Kitobda nechta sahifa bor?",o:["57","19","47","67"],k:0,s:"O'qilgani va qolgani — qismlar: 38 + 19 = 57."},
{t:"Sardorda 72 ta stiker bor. Bu Jasurnikidan 18 ta ko'p. Jasurda nechta stiker bor?",o:["54","90","64","18"],k:0,s:"Sardorda ko'p, Jasurda kam: 72 − 18 = 54."},
{t:"Bog'da 90 tup daraxt bor, ulardan 47 tasi olma, qolganlari o'rik. Nechta o'rik daraxti bor?",o:["43","137","53","47"],k:0,s:"90 − 47 = 43."},
{t:"Bekzod 6 yoshda. U akasidan 5 yosh kichik. Akasi necha yoshda?",o:["11","1","5","6"],k:0,s:"Bekzod kichik, akasi katta: 6 + 5 = 11."},
{t:"Savatda 20 ta olma bor edi. Bolalar 4 tasidan tashqari hammasini yeyishdi. Nechta olma yeyildi?",o:["16","4","24","20"],k:0,s:"4 tasi qoldi, yeyilgani: 20 − 4 = 16."},
{t:"Ali masalani yechib 61 − 27 = 44 deb yozdi. To'g'ri javob qaysi?",o:["34","44","88","24"],k:0,s:"Tekshiramiz: 44 + 27 = 71 ≠ 61. To'g'risi: 61 − 27 = 34, chunki 34 + 27 = 61."},
{t:"Poyezdda 85 yo'lovchi bor edi. Bekatda bir nechta kishi tushdi va 58 kishi qoldi. Nechta kishi tushdi?",o:["27","143","37","33"],k:0,s:"85 − 58 = 27."},
{t:"Bahor 47 ta gul terdi. Bu Gulnoranikidan 9 ta kam. Gulnora nechta gul tergan?",o:["56","38","9","47"],k:0,s:"Bahorda kam, Gulnorada ko'p: 47 + 9 = 56."},
{t:"Ipning uzunligi 100 sm edi. Undan bir bo'lak kesildi va 64 sm qoldi. Kesilgan bo'lak necha santimetr?",o:["36","164","46","64"],k:0,s:"100 − 64 = 36 sm."},
{t:"Sinfda 30 ta o'quvchi bor. Ulardan 13 tasi qiz bolalar. O'g'il bolalar nechta?",o:["17","43","13","27"],k:0,s:"30 − 13 = 17."},
{t:"Murodda bir nechta yong'oq bor edi. U 15 tasini ukasiga berdi va o'zida 29 ta qoldi. Boshida nechta yong'oq bor edi?",o:["44","14","29","34"],k:0,s:"Berilgani va qolgani — qismlar: 15 + 29 = 44."}
];
function PRACT_STAGE(){bmDraw({t:'Avval chizma chizing ✏️',bars:[{y:66,segs:[{w:3,txt:'qism',c:'a'},{w:2,txt:'qism',c:'g'}]}],br:[{b:0,lab:'butun',up:true}],note:'Qismlar ma’lum → qo‘shamiz · butun ma’lum → ayiramiz'})}
var PREP_DATA={teach:["Masala tuzilishi: shart va savol.","«Qism — qism — butun» chizmasi: qachon qo'shamiz, qachon ayiramiz.","Taqqoslash chizmasi: «… ta ko'p / kam».","Tuzoqlar: so'z amalni aytmaydi; «…dan 5 ta ko'p» teskari aytilishi; «…tasidan tashqari»; javobni tekshirish."],
 mist:["«Qo'shildi», «ko'p» so'zini ko'rib darrov qo'shadi.","«Bu Validan 5 ta ko'p» da kim ko'p ekanini adashtiradi.","«7 tasidan tashqari hammasi» da 16 − 7 qiladi.","Javobni tekshirmaydi, mantiqsiz javob yozadi."],
 need:["Rangli qog'oz tasmalar (chizma uchun).","Doskada chizg'ich bilan chiziqlar."],
 board:["Masala: shart tagiga to'g'ri chiziq, savol tagiga to'lqinli chiziq.","Chizma: <span class='w2'>[25 | 17] = ?</span> → qo'shamiz.","<span class='w2'>[27 | ?] = 40</span> → ayiramiz.","Taqqoslash: ikki chiziq, farq qizil bilan.","Tekshirish: <span class='w2'>27 + 13 = 40 ✓</span>."]};
