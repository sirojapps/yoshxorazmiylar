var CODE='4H7',TITLE='4-sinf · Parallel va perpendikular to‘g‘ri chiziqlar';
function q7msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function q7X(i){return 30+30*i}function q7Y(j){return 156-24*j}
// o: lines [[x1,y1,x2,y2,col,lab]] (cheksiz davom ettiriladi), segs, pts, tap
function q7grid(o){o=o||{};clear();var g=S.g,i,j;
 for(i=0;i<=10;i++)E('line',{x1:q7X(i),y1:q7Y(0),x2:q7X(i),y2:q7Y(6),stroke:'#e6ebf0','stroke-width':1},g);
 for(j=0;j<=6;j++)E('line',{x1:q7X(0),y1:q7Y(j),x2:q7X(10),y2:q7Y(j),stroke:'#e6ebf0','stroke-width':1},g);
 (o.lines||[]).forEach(function(q){var dx=q[2]-q[0],dy=q[3]-q[1],k=40;var a=[q7X(q[0]-dx*k),q7Y(q[1]-dy*k),q7X(q[2]+dx*k),q7Y(q[3]+dy*k)];E('line',{x1:a[0],y1:a[1],x2:a[2],y2:a[3],stroke:q[4]||C.blue,'stroke-width':2.8,'clip-path':'url(#q7c)'},g);if(q[5])T(g,q7X(q[6]),q7Y(q[7]),q[5],{'font-size':13,'font-weight':800,fill:q[4]||C.blue})});
 (o.segs||[]).forEach(function(q){E('line',{x1:q7X(q[0]),y1:q7Y(q[1]),x2:q7X(q[2]),y2:q7Y(q[3]),stroke:q[4]||C.a2,'stroke-width':q[5]?2:3.5,'stroke-dasharray':q[5]?'5 4':'none','stroke-linecap':'round'},g)});
 (o.rt||[]).forEach(function(q){E('path',{d:q,fill:'none',stroke:C.bad,'stroke-width':2},g)});
 (o.pts||[]).forEach(function(p){E('circle',{cx:q7X(p[0]),cy:q7Y(p[1]),r:5,fill:p[3]||C.bad,stroke:'#fff','stroke-width':1.5},g);if(p[2])T(g,q7X(p[0])+(p[4]||10),q7Y(p[1])+(p[5]||-8),p[2],{'font-size':12,'font-weight':800,fill:p[3]||C.bad})});
 var cp=E('clipPath',{id:'q7c'},sv);E('rect',{x:q7X(0),y:q7Y(6),width:300,height:144},cp);
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var x=Math.max(0,Math.min(10,Math.round((p.x-30)/30))),y=Math.max(0,Math.min(6,Math.round((156-p.y)/24)));o.tap(x,y)})}}
function q7sq(x,y){var X=q7X(x),Y=q7Y(y);return 'M'+X+' '+(Y-10)+' h10 v10'}
var Q7P2=[function(){q7grid({lines:[[0,3,10,3,C.blue,'a',9.6,3.4],[5,0,5,6,C.u,'b',5.3,5.6]]});q7msg('a va b kesishdi. Hosil bo‘lgan burchaklarga qarang')},
 function(){q7grid({lines:[[0,3,10,3,C.blue,'a',9.6,3.4],[5,0,5,6,C.u,'b',5.3,5.6]],rt:[q7sq(5,3)]});q7msg('Burchak — <b>to‘g‘ri burchak</b> (90°). Belgisi — kichik kvadratcha')},
 function(){q7grid({lines:[[0,3,10,3,C.blue,'a',9.6,3.4],[5,0,5,6,C.u,'b',5.3,5.6]],rt:[q7sq(5,3)]});q7msg('To‘rttala burchak ham to‘g‘ri. Yoziladi: <b>a ⊥ b</b>')}];
var Q7P6=[function(){q7grid({lines:[[0,1,10,1,C.blue,'c',9.6,1.4]]});q7msg('c to‘g‘ri chiziq berilgan')},
 function(){q7grid({lines:[[0,1,10,1,C.blue,'c',9.6,1.4],[3,0,3,6,C.u,'a',3.3,5.6]],rt:[q7sq(3,1)]});q7msg('a ⊥ c')},
 function(){q7grid({lines:[[0,1,10,1,C.blue,'c',9.6,1.4],[3,0,3,6,C.u,'a',3.3,5.6],[7,0,7,6,C.a2,'b',7.3,5.6]],rt:[q7sq(3,1),q7sq(7,1)]});q7msg('b ⊥ c. Unda <b>a ∥ b</b>: ular hech qachon kesishmaydi')}];
function q7rect(k){var o={segs:[[1,1,9,1,k===1?C.bad:C.a2],[9,1,9,5,k===2?C.ok:C.a2],[9,5,1,5,k===1?C.bad:C.a2],[1,5,1,1,k===2?C.ok:C.a2]],pts:[[1,1,'A',C.bad,-14,14],[9,1,'B',C.bad,6,14],[9,5,'C',C.bad,6,-6],[1,5,'D',C.bad,-14,-6]]};if(k===3){var A=[q7X(1),q7Y(1)],B=[q7X(9),q7Y(1)],Cc=[q7X(9),q7Y(5)],D=[q7X(1),q7Y(5)];o.rt=['M'+A[0]+' '+(A[1]-10)+' h10 v10','M'+(B[0]-10)+' '+B[1]+' v-10 h10','M'+(Cc[0]-10)+' '+Cc[1]+' v10 h10','M'+D[0]+' '+(D[1]+10)+' h10 v-10']}q7grid(o)}
function q7dist(k){var c=[C.grey,C.grey,C.grey];if(k>=0)c[k]=k===1?C.ok:C.bad;q7grid({lines:[[0,1,10,1,C.blue,'a',9.6,1.4],[0,5,10,5,C.blue,'b',9.6,5.4]],segs:[[1,1,3,5,c[0]],[5,1,5,5,c[1]],[7,1,9,5,c[2]]],pts:[[2,3,'k',c[0],-16,4],[5,3,'m',c[1],-16,4],[8,3,'n',c[2],8,4]]});if(k===1)E('path',{d:q7sq(5,1),fill:'none',stroke:C.bad,'stroke-width':2},S.g)}
var STEPS=[
{h:"Kesishadi yoki kesishmaydi",sum:"Tekislikdagi ikki to'g'ri chiziq yo kesishadi, yo hech qachon kesishmaydi — parallel bo'ladi.",a:"m01",
 start:function(){q7grid();q7msg('Ikkala tugmani bosing')},fin:function(){q7grid({lines:[[0,1,10,2,C.blue,'a',9.5,2.4],[0,3,10,4,C.u,'b',9.5,4.4]]});q7msg('a ∥ b — qancha davom ettirsak ham <b>kesishmaydi</b>')},
 btns:[["Kesishuvchi",function(c,done){q7grid({lines:[[0,1,10,5,C.blue,'m',9.4,4.9],[0,5,10,2,C.u,'n',9.4,2.9]]});q7msg('m va n <b>bitta nuqtada</b> kesishdi');mvK(done,2)}],["Parallel",function(c,done){q7grid({lines:[[0,1,10,2,C.blue,'a',9.5,2.4],[0,3,10,4,C.u,'b',9.5,4.4]]});q7msg('a va b orasidagi masofa hamma joyda bir xil. Ular <b>parallel</b>: a ∥ b');mvK(done,2)}]],g2:1,
 html:"<p>To'g'ri chiziq ikki tomonga <b>cheksiz</b> davom etadi. Ikki to'g'ri chiziq qanday joylashishi mumkin? Tugmalarni bosing.</p>",
 after:"<p>Tekislikda ikki to'g'ri chiziq yoki <b>kesishadi</b> (bitta umumiy nuqtasi bor), yoki <b>parallel</b> bo'ladi (umumiy nuqtasi yo'q). Parallellik belgisi: <b>a ∥ b</b>.</p>",
 q:{t:"Rasmda ikki to'g'ri chiziq ko'rinadigan qismida kesishmagan. Ular albatta parallelmi?",opts:["Ha, albatta","Yo'q, davom ettirsak kesishishi mumkin","Faqat yotiq bo'lsa","Faqat uzun bo'lsa"],ok:1,why:"To'g'ri chiziq cheksiz: rasmdan tashqarida kesishishi mumkin.",hint:"To'g'ri chiziq qayergacha davom etadi?",full:"To'g'ri chiziqlar cheksiz davom etadi. Agar ular sal qiya bo'lsa, rasmdan tashqarida kesishadi. Parallel — hech qayerda kesishmaydigani."},
 tn:"Ikki chizg'ichni partada turli holatda qo'yib, «Ular uchrashadimi?» deb so'rang. Qiya qo'yilganda chizg'ich chetidan davom ettirib chizib ko'rsating."},
{h:"Perpendikular to'g'ri chiziqlar",sum:"To'g'ri burchak ostida kesishgan to'g'ri chiziqlar perpendikular: a ⊥ b.",a:"m02",
 start:function(){startPh(Q7P2)},fin:function(){S.ph=2;Q7P2[2]()},
 html:"<p>Kesishuvchi chiziqlarning maxsus holati bor. Kuzating.</p>",
 btns:[phaser(Q7P2)],
 after:"<p>Agar to'g'ri chiziqlar kesishganda <b>to'g'ri burchak</b> (90°) hosil bo'lsa, ular <b>perpendikular</b>: <b>a ⊥ b</b>. Bunda to'rttala burchak ham to'g'ri. Tekshirish uchun <b>uchburchak chizg'ich</b> yoki qog'ozni ikki marta buklab yasalgan to'g'ri burchak ishlatiladi.</p>",
 q:{t:"Ikki to'g'ri chiziq kesishib, bitta burchak 90° chiqdi. Qolgan uchta burchak-chi?",opts:["Ular ham 90°","Biri 90°, qolganlari har xil","Hammasi 45°","Aniq emas — o'lchash kerak"],ok:0,why:"Bitta burchak to'g'ri bo'lsa, to'rttalasi ham to'g'ri.",hint:"Yoyiq burchak 180°. Undan 90° ni ayirsak?",full:"Qo'shni burchaklar birga yoyiq burchak — 180° ni tashkil qiladi: 180 − 90 = 90. Demak to'rttala burchak ham 90°."},
 tn:"Qog'ozni ikki marta buklab «qog'oz go'niya» yasating. Bolalar sinfdagi perpendikular chiziqlarni (eshik qirrasi, doska burchagi) shu bilan tekshirsin."},
{h:"Katakli qog'ozda parallel chizamiz",sum:"Parallel qiya chiziq chizish uchun bir xil «qadam»ni takrorlaymiz: o'ngga 3, yuqoriga 2.",a:"m03",
 start:function(){q7grid({tap:q7t3,segs:[[1,1,4,3,C.blue]],pts:[[1,1,'A'],[4,3,'B'],[5,1,'C',C.ok]]});q7msg('CD ∥ AB bo‘lishi uchun D ni bosing')},fin:function(){q7grid({lines:[[1,1,4,3,C.blue],[5,1,8,3,C.ok]],pts:[[1,1,'A'],[4,3,'B'],[5,1,'C',C.ok],[8,3,'D(8; 3)',C.ok,-20,-10]]});q7msg('✓ A→B: o‘ngga 3, yuqoriga 2. C→D ham xuddi shunday')},
 act:function(c,done){S.d3=done},
 html:"<p>AB kesma qiya chizilgan. C nuqtadan AB ga <b>parallel</b> kesma o'tkazish uchun <b>D</b> nuqtani to'rdan toping va bosing.</p>",
 after:"<p>A dan B ga: <b>o'ngga 3, yuqoriga 2</b> katak. C dan ham aynan shunday yursak, D ga yetamiz. Bir xil «qadam» — bir xil qiyalik, demak <b>CD ∥ AB</b>. Bu katakli qog'ozda chizg'ichsiz ham aniq parallel chizish usuli.</p>",
 q:{t:"MN kesma: M dan o'ngga 4, yuqoriga 1. K nuqtadan MN ga parallel kesma chizish uchun K dan qanday yuramiz?",opts:["O'ngga 4, yuqoriga 1","O'ngga 1, yuqoriga 4","O'ngga 4, pastga 1","O'ngga 5, yuqoriga 0"],ok:0,why:"Parallel — xuddi shu qadam: (4; 1).",hint:"Parallel chiziqlar qiyaligi qanday bo'ladi?",full:"Parallel kesmalarda qadam bir xil: o'ngga 4, yuqoriga 1. «O'ngga 1, yuqoriga 4» — boshqacha qiyalik, «pastga 1» — teskari tomonga qiya."},
 tn:"Bolalar daftarda bir nechta parallel qiya kesma chizib, ularni bitta chizg'ich bilan davom ettirsin — hech biri kesishmasligini ko'radi."},
{h:"Qiya chiziqqa perpendikular (qiyin)",sum:"Qadam «o'ngga 3, yuqoriga 2» bo'lsa, perpendikular qadam — «chapga 2, yuqoriga 3»: sonlar almashadi, bitta yo'nalish teskari.",a:"m04",
 start:function(){q7grid({tap:q7t4,segs:[[2,1,5,3,C.blue]],pts:[[2,1,'A'],[5,3,'B',C.bad,8,10]]});q7msg('BE ⊥ AB bo‘lishi uchun E ni bosing')},fin:function(){q7grid({segs:[[2,1,5,3,C.blue],[5,3,3,6,C.ok]],pts:[[2,1,'A'],[5,3,'B',C.bad,8,10],[3,6,'E(3; 6)',C.ok,-48,4]]});E('path',{d:'M'+(q7X(5)-8.3)+' '+(q7Y(3)-5.5)+' l-5.5 -8.3 l8.3 5.5',fill:'none',stroke:C.bad,'stroke-width':2},S.g);q7msg('✓ A→B: (3 o‘ngga, 2 yuqoriga). B→E: (2 chapga, 3 yuqoriga)')},
 act:function(c,done){S.d4=done},
 html:"<p>Endi qiyinrog'i. AB qiya kesma: <b>o'ngga 3, yuqoriga 2</b>. B nuqtadan AB ga <b>perpendikular</b> kesma chizish uchun <b>E</b> nuqtani bosing. Sirli qoida: sonlar o'rnini almashtiring va bitta yo'nalishni teskari qiling.</p>",
 after:"<p>AB ning qadami (3; 2). Perpendikular qadam: sonlar almashadi — <b>2 va 3</b>, va bittasi teskari — <b>chapga 2, yuqoriga 3</b>. B(5; 3) dan: E(3; 6). Uchburchak chizg'ich bilan tekshirsangiz, burchak to'g'ri chiqadi. Daftarni chorak aylantirsangiz, AB kesma aynan BE ustiga tushadi.</p>",
 q:{t:"PQ kesma: P dan o'ngga 4, yuqoriga 1. Q dan PQ ga perpendikular yo'nalish qaysi?",opts:["Chapga 1, yuqoriga 4","O'ngga 4, yuqoriga 1","O'ngga 1, yuqoriga 4","Chapga 4, yuqoriga 1"],ok:0,why:"Sonlar almashadi (1 va 4) va bitta yo'nalish teskari.",hint:"Qoida: sonlarni almashtiring, keyin bitta yo'nalishni teskari qiling.",full:"(4; 1) qadamdan perpendikular: sonlar almashadi → 1 va 4, bitta yo'nalish teskari → chapga 1, yuqoriga 4. «O'ngga 1, yuqoriga 4» — sonlar almashgan, lekin yo'nalish teskari qilinmagan: burchak to'g'ri chiqmaydi."},
 tn:"Bu qoidani daftarni 90° burib ko'rsating: kesma «yotgan» holatdan «tik» holatga o'tadi. Burchagini uchburchak chizg'ich bilan albatta tekshiring."},
{h:"Atrofimizdagi parallel va perpendikularlar",sum:"Harflar, deraza, ko'cha — hamma joyda parallel va perpendikular chiziqlar bor.",a:"m05",
 start:function(){q7letters(-1);q7msg('Qaysi harfda <b>ham parallel, ham perpendikular</b> kesmalar bor?')},fin:function(){q7letters(0);q7msg('✓ H: ikki tik kesma parallel, o‘rtadagisi ularga perpendikular')},
 btns:[["H",function(c,done){STEPS[4].fin();done()}],["V",function(c,done){q7letters(1);q7msg('V — ikki kesma kesishadi, lekin to‘g‘ri burchak emas')}],["X",function(c,done){q7letters(2);q7msg('X — kesishadi, lekin parallel kesma yo‘q')}],["Z",function(c,done){q7letters(3);q7msg('Z — tepa va pastki kesmalar parallel, lekin perpendikular yo‘q')}]],g2:1,
 html:"<p>Bosma harflarga qarang. Qaysi birida <b>ham parallel, ham perpendikular</b> kesmalar bor?</p>",
 after:"<p><b>H</b> harfida ikki tik kesma <b>parallel</b>, o'rtadagi yotiq kesma ularning har biriga <b>perpendikular</b>. Z da faqat parallel juft bor, V va X da faqat kesishuvchi (perpendikular emas) kesmalar.</p>",
 q:{t:"E harfida nechta perpendikular juft kesma bor (tik kesma bilan uchta yotiq kesma)?",opts:["3","2","1","4"],ok:0,why:"Har bir yotiq kesma tik kesmaga perpendikular: 3 juft.",hint:"Har bir yotiq kesma tik kesma bilan qanday burchak hosil qiladi?",full:"E da 1 ta tik va 3 ta yotiq kesma. Har bir yotiq kesma tikka perpendikular — 3 juft. Yotiq kesmalar o'zaro parallel (bu 3 ta parallel juft, perpendikular emas)."},
 tn:"Sinfda «ov» o'yini: 2 daqiqada bolalar sinfdan parallel va perpendikular chiziqlarni topib, ro'yxat yozsin."},
{h:"Tuzoq: ikkita perpendikular — parallel!",sum:"Bitta to'g'ri chiziqqa perpendikular ikki to'g'ri chiziq o'zaro parallel.",a:"m06",
 start:function(){startPh(Q7P6)},fin:function(){S.ph=2;Q7P6[2]()},
 html:"<p>Ikki to'g'ri chiziq ham c ga perpendikular bo'lsa, ular o'zaro qanday joylashadi?</p>",
 btns:[phaser(Q7P6)],
 after:"<p>Agar <b>a ⊥ c</b> va <b>b ⊥ c</b> bo'lsa, unda <b>a ∥ b</b>. Ko'pchilik «ikkalasi perpendikular bo'lgani uchun o'zaro ham perpendikular» deb xato qiladi. Shu qoida bilan chizmachilar va duradgorlar parallel chiziqlarni yasaydi: go'niyani chizg'ich bo'ylab surib chizish.</p>",
 q:{t:"m ⊥ k va n ⊥ k. m va n qanday joylashgan?",opts:["m ∥ n","m ⊥ n","Ular kesishadi, lekin to'g'ri burchak emas","m va n ustma-ust tushadi"],ok:0,why:"Bitta chiziqqa perpendikular chiziqlar parallel.",hint:"Rasmda chizib ko'ring: k yotiq, m va n tik.",full:"k ni yotiq chizing; m va n unga perpendikular — demak ikkalasi tik. Tik chiziqlar o'zaro parallel: m ∥ n. «m ⊥ n» — eng ko'p uchraydigan xato."},
 tn:"Uchburchak chizg'ichni chizg'ich bo'ylab surib, 3–4 ta perpendikular chizing — ular parallel chiqadi. Bolalar o'zlari ham qilsin."},
{h:"To'g'ri to'rtburchakda",sum:"To'g'ri to'rtburchakda qarama-qarshi tomonlar parallel (2 juft), qo'shni tomonlar perpendikular (4 juft).",a:"m07",
 start:function(){q7rect(0);q7msg('Ikkala tugmani bosing')},fin:function(){q7rect(3);q7msg('AB ∥ DC, AD ∥ BC — 2 juft. Burchaklarda — 4 ta perpendikular juft')},
 btns:[["Parallel juftlar",function(c,done){q7rect(1);q7msg('AB ∥ DC (qizil). AD ∥ BC ham — <b>2 juft</b>');mvK(done,2)}],["Perpendikular juftlar",function(c,done){q7rect(3);q7msg('AB ⊥ BC, BC ⊥ CD, CD ⊥ DA, DA ⊥ AB — <b>4 juft</b>');mvK(done,2)}]],g2:1,
 html:"<p>ABCD to'g'ri to'rtburchak. Uning tomonlari orasida nechta parallel va nechta perpendikular juft bor?</p>",
 after:"<p>To'g'ri to'rtburchakda <b>qarama-qarshi</b> tomonlar parallel: AB ∥ DC, AD ∥ BC — <b>2 juft</b>. <b>Qo'shni</b> tomonlar perpendikular: har bir uchida bittadan — <b>4 juft</b>. Kvadratda ham xuddi shunday.</p>",
 q:{t:"Kubning bitta qirrasiga nechta qirra parallel?",opts:["3 ta","1 ta","4 ta","2 ta"],ok:0,why:"Kubning 12 qirrasi 3 ta to'rtlikka bo'linadi: har to'rtlikda qirralar parallel.",hint:"Kubning tik qirralarini sanang: ular nechta?",full:"Kubda tik qirralar 4 ta va ular o'zaro parallel. Demak bitta tik qirraga qolgan 3 tasi parallel. 1 ta — faqat bitta yoqqa qarash xatosi."},
 tn:"Gugurt qutisi yoki kub ushlab, parallel qirralarni barmoq bilan ko'rsating — fazodagi parallellik ham shunday."},
{h:"Parallel chiziqlar orasidagi masofa",sum:"Parallel to'g'ri chiziqlar orasidagi masofa — ularga perpendikular kesma uzunligi; u hamma joyda bir xil.",a:"m08",
 start:function(){q7dist(-1);q7msg('k, m, n kesmalardan qaysi biri a va b orasidagi <b>masofa</b>?')},fin:function(){q7dist(1);q7msg('✓ m ⊥ a va m ⊥ b. Masofa = 4 katak — eng qisqa kesma')},
 btns:[["k",function(c,done){q7dist(0);q7msg('k — qiya. U m dan uzunroq: masofa emas')}],["m",function(c,done){STEPS[7].fin();done()}],["n",function(c,done){q7dist(2);q7msg('n — qiya, uzunroq. Masofa — perpendikular kesma')}]],g3:1,
 html:"<p>a ∥ b. Ular orasida uchta kesma bor. Qaysi biri chiziqlar orasidagi <b>masofa</b>?</p>",
 after:"<p>Ikki parallel chiziq orasidagi <b>masofa</b> — ularga <b>perpendikular</b> kesmaning uzunligi (m = 4 katak). U eng qisqa va qayerdan o'lchasak ham bir xil. Qiya kesmalar (k, n) har doim uzunroq.</p>",
 q:{t:"Daftar chiziqlari parallel, oraliq 8 mm. 1-chiziqdan 6-chiziqqacha masofa?",opts:["40 mm","48 mm","32 mm","56 mm"],ok:0,why:"1 dan 6 gacha 5 ta oraliq: 5 · 8 = 40.",hint:"1-chiziqdan 6-chiziqqacha nechta oraliq bor?",full:"Oraliqlar soni 6 − 1 = 5, masofa 5 · 8 = 40 mm. 48 mm — oraliqlarni 6 ta deb sanash xatosi."},
 tn:"Daftar chiziqlari orasini chizg'ich bilan to'g'ri (perpendikular) va qiya qo'yib o'lchating — qiya o'lchov katta chiqadi."},
{h:"Bilasizmi? Yevklid va temir yo'l",sum:"Parallel chiziqlar haqidagi qoidani qadimgi yunon olimi Yevklid «Negizlar» kitobida yozgan.",a:"m09",
 start:function(){q7grid({lines:[[0,2,10,2,C.blue],[0,4,10,4,C.blue],[3,0,3,6,C.u]],rt:[q7sq(3,2),q7sq(3,4)]});q7msg('a ∥ b, c ⊥ a, c ⊥ b')},fin:function(){q7grid({lines:[[0,2,10,2,C.blue],[0,4,10,4,C.blue],[3,0,3,6,C.u]],rt:[q7sq(3,2),q7sq(3,4)]});q7msg('a ∥ b, c ⊥ a, c ⊥ b')},
 html:"<p>📜 Qadimgi yunon olimi <b>Yevklid</b> (miloddan avvalgi III asr) «Negizlar» kitobida parallel to'g'ri chiziqlar haqidagi mashhur qoidani yozgan. Bu kitob 2000 yildan ortiq geometriya darsligi bo'lib xizmat qilgan.</p><p>🚆 Temir yo'l relslari — parallel chiziqlarning eng yaxshi namunasi. O'zbekistonda relslar orasidagi masofa <b>1520 mm</b>. Shpallar (yog'och yoki beton to'sinlar) relslarga perpendikular yotqiziladi.</p>",
 tn:"Temir yo'l rasmini ko'rsatib so'rang: relslar uzoqda «birlashib» ko'rinadi — lekin ular parallel. Bu ko'z aldanishi (perspektiva)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){q7grid({lines:[[0,2,10,2,C.blue],[0,4,10,4,C.blue],[3,0,3,6,C.u]],rt:[q7sq(3,2),q7sq(3,4)]});q7msg('a ∥ b, c ⊥ a, c ⊥ b')},fin:function(){q7grid({lines:[[0,2,10,2,C.blue],[0,4,10,4,C.blue],[3,0,3,6,C.u]],rt:[q7sq(3,2),q7sq(3,4)]});q7msg('a ∥ b, c ⊥ a, c ⊥ b')},
 html:"<div class='memo'><ul><li><b>Parallel</b> (a ∥ b) — hech qachon kesishmaydi.</li><li><b>Perpendikular</b> (a ⊥ b) — to'g'ri burchak (90°) ostida kesishadi; to'rttala burchak to'g'ri.</li><li>Katakli qog'ozda parallel: bir xil qadam, masalan (3; 2) va (3; 2).</li><li>Perpendikular: sonlar almashadi, bitta yo'nalish teskari: (3 o'ngga; 2 yuqoriga) → (2 chapga; 3 yuqoriga).</li><li>a ⊥ c va b ⊥ c bo'lsa — a ∥ b.</li><li>To'g'ri to'rtburchak: 2 parallel juft, 4 perpendikular juft.</li><li>Parallel chiziqlar orasidagi masofa — perpendikular kesma.</li></ul></div>",
 tn:"Uyga: uydagi 5 ta parallel va 5 ta perpendikular chiziqqa misol yozish."}
];
function q7letters(k){clear();var g=S.g,cs=[C.grey,C.grey,C.grey,C.grey];if(k>=0)cs[k]=k===0?C.ok:C.bad;
 function L(x1,y1,x2,y2,c){E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:c,'stroke-width':8,'stroke-linecap':'round'},g)}
 L(30,40,30,130,cs[0]);L(80,40,80,130,cs[0]);L(30,85,80,85,cs[0]);
 L(115,40,140,130,cs[1]);L(165,40,140,130,cs[1]);
 L(200,40,250,130,cs[2]);L(250,40,200,130,cs[2]);
 L(285,40,335,40,cs[3]);L(335,40,285,130,cs[3]);L(285,130,335,130,cs[3]);
 if(k===0){E('path',{d:'M36 71 h10 v10',fill:'none',stroke:C.bad,'stroke-width':2},g)}}
function q7t3(x,y){if(x===8&&y===3){STEPS[2].fin();if(S.d3){var d=S.d3;S.d3=null;d()}}else if(S.d3){q7grid({tap:q7t3,segs:[[1,1,4,3,C.blue],[5,1,x,y,C.grey]],pts:[[1,1,'A'],[4,3,'B'],[5,1,'C',C.ok],[x,y,'('+x+'; '+y+')',C.grey]]});q7msg(x===7&&y===4?'C dan o‘ngga 2, yuqoriga 3 — sonlar almashdi':'C→('+x+'; '+y+') qiyaligi AB nikidan boshqacha. A→B: o‘ngga 3, yuqoriga 2')}}
function q7t4(x,y){if(x===3&&y===6){STEPS[3].fin();if(S.d4){var d=S.d4;S.d4=null;d()}}else if(S.d4){q7grid({tap:q7t4,segs:[[2,1,5,3,C.blue],[5,3,x,y,C.grey]],pts:[[2,1,'A'],[5,3,'B',C.bad,8,10],[x,y,'('+x+'; '+y+')',C.grey]]});q7msg(x===7&&y===6?'O‘ngga 2, yuqoriga 3 — burchak to‘g‘ri emas. Bitta yo‘nalishni teskari qiling':(x===8&&y===5?'Bu AB ning davomi — parallel, perpendikular emas':'Qoida: (3; 2) → chapga 2, yuqoriga 3'))}}
var PROBS=[
{t:"Qaysi belgi «parallel» degani?",o:["∥","⊥","=","∠"],k:0,s:"a ∥ b — parallel, a ⊥ b — perpendikular."},
{t:"Perpendikular to'g'ri chiziqlar kesishganda qanday burchak hosil bo'ladi?",o:["To'g'ri (90°)","O'tkir","O'tmas","Yoyiq"],k:0,s:"Perpendikular — 90°."},
{t:"Parallel to'g'ri chiziqlarning nechta umumiy nuqtasi bor?",o:["Birorta ham yo'q","1 ta","2 ta","Cheksiz ko'p"],k:0,s:"Parallel chiziqlar kesishmaydi."},
{t:"Kvadratning nechta juft parallel tomoni bor?",o:["2 juft","4 juft","1 juft","3 juft"],k:0,s:"AB ∥ DC va AD ∥ BC."},
{t:"To'g'ri to'rtburchakda nechta juft perpendikular tomon bor?",o:["4 juft","2 juft","8 juft","1 juft"],k:0,s:"Har bir uchida bitta juft: 4."},
{t:"a ⊥ b va b ⊥ c. a va c qanday joylashgan?",o:["a ∥ c","a ⊥ c","Kesishadi, 45°","Ustma-ust"],k:0,s:"Bitta chiziqqa (b) perpendikular chiziqlar parallel."},
{t:"a ∥ b va b ∥ c. a va c qanday?",o:["a ∥ c","a ⊥ c","Kesishadi","Ustma-ust tushadi"],k:0,s:"Bitta chiziqqa parallel chiziqlar o'zaro parallel."},
{t:"a ∥ b va c ⊥ a. c va b qanday joylashgan?",o:["c ⊥ b","c ∥ b","c va b kesishmaydi","c b bilan 45° hosil qiladi"],k:0,s:"Parallel chiziqlardan biriga perpendikular chiziq ikkinchisiga ham perpendikular."},
{t:"Katakli qog'ozda AB: A dan o'ngga 2, yuqoriga 5. AB ga parallel kesmaning qadami?",o:["O'ngga 2, yuqoriga 5","O'ngga 5, yuqoriga 2","Chapga 5, yuqoriga 2","O'ngga 2, pastga 5"],k:0,s:"Parallel — bir xil qadam."},
{t:"AB: o'ngga 2, yuqoriga 5. AB ga perpendikular qadam?",o:["Chapga 5, yuqoriga 2","O'ngga 5, yuqoriga 2","O'ngga 2, yuqoriga 5","Chapga 2, yuqoriga 5"],k:0,s:"Sonlar almashadi va bitta yo'nalish teskari: chapga 5, yuqoriga 2."},
{t:"Qaysi harfda perpendikular kesmalar bor?",o:["T","V","O","S"],k:0,s:"T: tik kesma yotiqqa perpendikular."},
{t:"L, T, H harflaridagi perpendikular juftlar soni jami?",o:["4","3","5","6"],k:0,s:"L — 1, T — 1, H — 2 (o'rtadagi kesma ikki tik kesmaga). Jami 4."},
{t:"Kubning bitta qirrasiga nechta qirra perpendikular (u bilan kesishib, to'g'ri burchak hosil qiladigan)?",o:["4 ta","2 ta","3 ta","8 ta"],k:0,s:"Har bir uchida 2 ta qirra uchrashadi: 2 + 2 = 4."},
{t:"Daftar chiziqlari orasi 9 mm. 2-chiziqdan 7-chiziqqacha masofa?",o:["45 mm","63 mm","54 mm","36 mm"],k:0,s:"7 − 2 = 5 oraliq, 5 · 9 = 45 mm."},
{t:"Ikki parallel chiziq orasidagi qiya kesma 7 sm. Ular orasidagi masofa qanday bo'lishi mumkin?",o:["7 sm dan kichik","Aynan 7 sm","7 sm dan katta","14 sm"],k:0,s:"Perpendikular kesma eng qisqa: masofa 7 sm dan kichik."},
{t:"Ko'chada 5 ta parallel ustun qatorda turibdi, qo'shnilari orasi 4 m. Chetkilari orasidagi masofa?",o:["16 m","20 m","24 m","12 m"],k:0,s:"4 oraliq · 4 m = 16 m."},
{t:"Tekislikda 3 ta to'g'ri chiziq o'zaro parallel. Ularning hammasini kesuvchi 4-chiziq chizildi. Nechta kesishish nuqtasi bor?",o:["3","4","6","0"],k:0,s:"Parallellar o'zaro kesishmaydi; 4-chiziq har birini bir marta kesadi: 3."},
{t:"Tekislikda 2 ta gorizontal va 3 ta vertikal to'g'ri chiziq chizildi. Nechta kesishish nuqtasi bor?",o:["6","5","3","9"],k:0,s:"Har bir gorizontal 3 ta vertikalni kesadi: 2 · 3 = 6."},
{t:"Shu 2 ta gorizontal va 3 ta vertikal chiziq nechta to'g'ri to'rtburchak hosil qiladi (kataklar va ularning birlashmalari)?",o:["3","2","6","4"],k:0,s:"Ikki gorizontal juft — 1 tanlov; 3 vertikaldan juft — 3 tanlov: 1 · 3 = 3."},
{t:"Soat 3:00 da strelkalar qanday joylashadi?",o:["Perpendikular","Parallel","Ustma-ust","Bir to'g'ri chiziqda, qarama-qarshi"],k:0,s:"Soat 3:00 — 90°, perpendikular."}
];
function PRACT_STAGE(){q7grid({lines:[[0,2,10,2,C.blue],[0,4,10,4,C.blue],[3,0,3,6,C.u]],rt:[q7sq(3,2),q7sq(3,4)]})}
var PREP_DATA={teach:["Kesishuvchi va parallel to'g'ri chiziqlar; belgilar ∥ va ⊥.","Perpendikular chiziqlar va to'g'ri burchak; uchburchak chizg'ich bilan tekshirish.","Katakli qog'ozda parallel va perpendikular (qiya) chiziq yasash.","Bitta chiziqqa perpendikular chiziqlar parallel; to'rtburchak va kubdagi juftlar; parallel chiziqlar orasidagi masofa."],
 mist:["Rasmda kesishmagan chiziqlarni albatta parallel deb o'ylaydi.","a ⊥ c, b ⊥ c dan a ⊥ b deb xulosa qiladi.","Perpendikular qadamda sonlarni almashtiradi, lekin yo'nalishni teskari qilmaydi.","Masofani qiya kesma bo'yicha o'lchaydi.","Chiziqlar orasidagi oraliqlarni bittaga ko'p sanaydi."],
 need:["Uchburchak chizg'ich (go'niya), chizg'ich.","Katakli daftar, rangli qalam.","Qog'oz varag'i (go'niya buklash uchun).","Kub yoki gugurt qutisi."],
 board:["a ∥ b — kesishmaydi.","a ⊥ b — 90°, kvadratcha belgisi.","Parallel qadam: (3; 2) → (3; 2).","Perpendikular qadam: (3 →; 2 ↑) → (2 ←; 3 ↑).","a ⊥ c, b ⊥ c ⇒ a ∥ b.","To'rtburchak: 2 ∥ juft, 4 ⊥ juft.","Masofa — perpendikular kesma."]};
