var CODE='4D3',TITLE='4-sinf · Harfli ifodalar va formulalar';
function d3Rect(w,h,la,lb,col,inside){clear();var g=S.g,x=180-w/2,y=24;E('rect',{x:x,y:y,width:w,height:h,fill:col||'#dbeefb',stroke:C.blue,'stroke-width':2.5},g);
 T(g,180,y-6,la,{'font-size':14,'font-weight':800,fill:C.blue});T(g,x+w+6,y+h/2+5,lb,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(inside)T(g,180,y+h/2+6,inside,{'font-size':16,'font-weight':800,fill:'#1d2b3a'})}
function d3Tri(hi){clear();var g=S.g;E('path',{d:'M180 14 L290 150 L70 150 Z',fill:'#fff7e6',stroke:'#8a5a24','stroke-width':2.5},g);E('line',{x1:110,y1:100,x2:250,y2:100,stroke:'#8a5a24','stroke-width':2},g);E('line',{x1:180,y1:100,x2:180,y2:150,stroke:'#8a5a24','stroke-width':2},g);
 [['s',180,78],['v',140,135],['t',220,135]].forEach(function(z){T(g,z[1],z[2],z[0],{'font-size':26,'font-weight':800,fill:hi===z[0]?C.bad:'#1d2b3a'})});T(g,180,135,'·',{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
function d3Tab(){clear();var g=S.g,cols=['n','0','1','2','3','4','…'],vals=['100 − 4 · n','100','96','92','88','84','…'],x0=14,w0=110,cw=38,y=46,h=36;
 cols.forEach(function(c,i){var x=i?x0+w0+(i-1)*cw:x0,w=i?cw:w0;E('rect',{x:x,y:y,width:w,height:h,fill:i?'#fff':'#e9eef3',stroke:'#8a99a8'},g);E('rect',{x:x,y:y+h,width:w,height:h,fill:i?'#fff':'#e9eef3',stroke:'#8a99a8'},g);
  T(g,x+w/2,y+24,c,{'font-size':15,'font-weight':800,fill:C.blue});T(g,x+w/2,y+h+24,vals[i],{'font-size':i?15:13,'font-weight':800,fill:'#1d2b3a'})})}
var P3=[function(){d3Rect(200,90,'a','b');w3Msg('To‘g‘ri to‘rtburchak: bo‘yi a, eni b')},
 function(){d3Rect(200,90,'a','b',null,'P = (a + b) · 2');w3Msg('Perimetr — hamma tomonlar yig‘indisi: a + b + a + b')},
 function(){d3Rect(200,90,'a = 15 sm','b = 9 sm',null,'P = (15 + 9) · 2');w3Msg('Harflar o‘rniga sonlarni qo‘yamiz')},
 function(){d3Rect(200,90,'a = 15 sm','b = 9 sm','#e3f6ea','P = 24 · 2 = 48 sm');w3Msg('Formula — har qanday to‘g‘ri to‘rtburchak uchun tayyor «retsept»')}];
var STEPS=[
{h:"Harfli ifoda: bitta ifoda — ko'p qiymat",sum:"15 + a: a = 5 da 20, a = 10 da 25, a = 20 da 35. Harf o'rniga qo'yilgan songa qarab qiymat o'zgaradi.",a:"m01",
 start:function(){S.w4={};w3Expr(['15 + a']);w3Msg('a — istalgan son o‘rnini bosuvchi harf')},fin:function(){w3Expr(['a = 5 → 15 + 5 = {20}','a = 10 → 15 + 10 = {25}','a = 20 → 15 + 20 = {35}']);w3Msg('Bitta ifoda — uchta qiymat')},
 html:"<p><b>15 + a</b> — harfli ifoda. Harf (a) istalgan son o'rnida turadi. Uchta qiymatni ham bosib hisoblang:</p>",
 btns:[["a = 5",function(c,done){S.w4[5]=1;w3Expr(['a = 5','15 + 5 = {20}']);w3Msg('a = 5 bo‘lsa, ifoda qiymati 20');if(S.w4[10]&&S.w4[20])done()}],["a = 10",function(c,done){S.w4[10]=1;w3Expr(['a = 10','15 + 10 = {25}']);w3Msg('a = 10 bo‘lsa, ifoda qiymati 25');if(S.w4[5]&&S.w4[20])done()}],["a = 20",function(c,done){S.w4[20]=1;w3Expr(['a = 20','15 + 20 = {35}']);w3Msg('a = 20 bo‘lsa, ifoda qiymati 35');if(S.w4[5]&&S.w4[10])done()},'u']],g3:1,
 after:"<p>Harfli ifoda — «bo'sh katakli» ifoda. Katakka son qo'yilsa, ifoda <b>qiymat</b>ga ega bo'ladi. Harfni almashtirish = <b>o'rniga qo'yish</b>.</p>",
 q:{t:"a = 27 bo'lsa, 15 + a ning qiymati?",opts:["42","12","405","52"],ok:0,why:"15 + 27 = 42.",hint:"a o'rniga 27 ni qo'ying.",full:"15 + 27 = 42. «12» — ayirib yuborish, «405» — ko'paytirish (15 · 27)."},
 tn:"Doskaga «15 + □» yozing, kartochkalardagi sonlarni katakka navbat bilan qo'ying. So'ng □ ni «a» bilan almashtiring."},
{h:"Bir nechta harf",sum:"a · b − c: a = 12, b = 5, c = 18 → 60 − 18 = 42. Amallar tartibi o'zgarmaydi.",a:"m02",
 start:function(){w3Expr(['a · b − c','a = 12,  b = 5,  c = 18']);w3Msg('Qiymatni toping')},fin:function(){w3Expr(['12 · 5 − 18','60 − 18 = {42}']);w3Msg('Avval o‘rniga qo‘yamiz, keyin amallar tartibi bilan hisoblaymiz')},
 html:"<p><b>a · b − c</b> ifodaning qiymatini toping: a = 12, b = 5, c = 18.</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['42','78','35','24'],'42',function(){w3Expr(['12 · 5 − 18','60 − 18 = {42}']);w3Msg('To‘g‘ri!');done()},{'78':'60 + 18 — ayirish o‘rniga qo‘shildi','35':'12 + 5 + 18 — amallar belgilari e’tiborsiz qoldi','24':'Hisobni qayta tekshiring: 12 · 5 = 60'})},
 after:"<p>Usul: 1) har harf o'rniga uning sonini yozing (qavs ichida bo'lsa ham); 2) oddiy ifodani amallar tartibi bilan hisoblang. <b>a · b</b> ni ko'pincha nuqtasiz <b>ab</b> deb ham yozishadi — lekin bu «a va b raqamlari» emas, ko'paytma!</p>",
 q:{t:"m = 40, n = 8 bo'lsa, m : n + m ning qiymati?",opts:["45","48","5","320"],ok:0,why:"40 : 8 = 5, 5 + 40 = 45.",hint:"Avval bo'lish.",full:"40 : 8 + 40 = 5 + 40 = 45. «48» — 40 + 8; «5» — oxirgi qo'shish unutilgan."},
 tn:"Har bir harfga rangli kartochka bering: a — qizil, b — ko'k. Bolalar kartochkani ko'tarib, o'rniga qo'yish jarayonini o'ynasin."},
{h:"Formula: perimetr",sum:"P = (a + b) · 2. a = 15 sm, b = 9 sm → P = 48 sm.",a:"m03",
 start:w4St(P3),fin:w4Fin(P3),
 html:"<p><b>Formula</b> — harflar bilan yozilgan qoida. U har qanday son uchun ishlaydi. To'g'ri to'rtburchak perimetri formulasini kuzating:</p>",btns:[phaser(P3)],
 after:"<p>Asosiy formulalar:</p><div class='life'><div>▭<span>To'g'ri to'rtburchak: <b>P = (a + b) · 2</b>, <b>S = a · b</b></span></div><div>◻<span>Kvadrat: <b>P = a · 4</b>, <b>S = a · a</b></span></div></div>",
 q:{t:"a = 15 sm, b = 9 sm. P = (a + b) · 2 = ?",opts:["48 sm","33 sm","135 sm","24 sm"],ok:0,why:"(15 + 9) · 2 = 48.",hint:"Avval qavs ichi.",full:"(15 + 9) · 2 = 24 · 2 = 48 sm. «33» — qavssiz 15 + 9 · 2; «135» — yuzi (a · b); «24» — 2 ga ko'paytirish unutilgan."},
 tn:"Sinf partasining bo'yi va enini o'lchab, formulaga qo'ying — formula «hayotiy» bo'ladi."},
{h:"Kvadrat: perimetr va yuz",sum:"a = 9: P = a · 4 = 36, S = a · a = 81. Perimetr va yuzni adashtirmang!",a:"m04",
 start:function(){d3Rect(110,110,'a = 9','a = 9');w3Msg('Kvadrat tomoni 9 sm. P va S ni toping')},fin:function(){d3Rect(110,110,'a = 9','a = 9','#e3f6ea','S = 81');w3Msg('P = 9 · 4 = 36 sm,  S = 9 · 9 = 81 sm²')},
 html:"<p>Kvadrat tomoni <b>a = 9 sm</b>. To'g'ri juftlikni tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['P = 36, S = 81','P = 81, S = 36','P = 18, S = 81','P = 36, S = 18'],'P = 36, S = 81',function(){d3Rect(110,110,'a = 9','a = 9','#e3f6ea','S = 81');w3Msg('P = 9 · 4 = 36 sm,  S = 9 · 9 = 81 sm²');done()},{'P = 81, S = 36':'Perimetr va yuz adashib ketdi','P = 18, S = 81':'P = a · 4 — to‘rtta tomon, ikkita emas','P = 36, S = 18':'S = a · a = 9 · 9, a · 2 emas'})},
 after:"<p><b>Perimetr</b> — chegara uzunligi (sm), <b>yuz</b> — ichidagi kvadratchalar soni (sm²). Tuzoq: a · a ni a · 2 bilan adashtirish. a = 2 bo'lsagina ular teng (4 = 4)!</p>",
 q:{t:"Kvadratning perimetri 36 sm. Uning yuzi?",opts:["81 sm²","36 sm²","324 sm²","18 sm²"],ok:0,why:"a = 36 : 4 = 9, S = 81.",hint:"Avval tomonni toping: P : 4.",full:"a = 36 : 4 = 9 sm, S = 9 · 9 = 81 sm². «324» — 36 · 9; «36» — perimetrni yuz deb olish."},
 tn:"Katakli qog'ozda 9×9 kvadrat chizdiring: chegarasini sanash — 36, ichidagi kataklar — 81."},
{h:"Harakat formulasi: s = v · t",sum:"s = v · t, v = s : t, t = s : v. Uchburchakda kerakli harfni yoping — qolgani formulani ko'rsatadi.",a:"m05",
 start:function(){S.w4={};d3Tri();w3Msg('s — masofa, v — tezlik, t — vaqt')},fin:function(){d3Tri();w3Msg('s = v · t,  v = s : t,  t = s : v')},
 html:"<p>Sehrli uchburchak: topmoqchi bo'lgan harfni «yoping». Uchala holatni ham bosing:</p>",
 btns:[["s = ?",function(c,done){S.w4.s=1;d3Tri('s');w3Msg('s = v · t:  v = 70 km/soat, t = 4 soat → s = <b>280 km</b>');if(S.w4.v&&S.w4.t)done()}],["v = ?",function(c,done){S.w4.v=1;d3Tri('v');w3Msg('v = s : t:  s = 360 km, t = 4 soat → v = <b>90 km/soat</b>');if(S.w4.s&&S.w4.t)done()}],["t = ?",function(c,done){S.w4.t=1;d3Tri('t');w3Msg('t = s : v:  s = 240 km, v = 60 km/soat → t = <b>4 soat</b>');if(S.w4.s&&S.w4.v)done()},'u']],g3:1,
 after:"<p>Tepadagi harf (s) — pastdagi ikkitasining <b>ko'paytmasi</b>. Pastdagi har biri — tepadagini ikkinchisiga <b>bo'lish</b>. Xuddi shu uchburchak narx-miqdor-qiymat va ish unumi masalalarida ham ishlaydi.</p>",
 q:{t:"s = 360 km, t = 4 soat. v = ?",opts:["90 km/soat","1440 km/soat","364 km/soat","356 km/soat"],ok:0,why:"v = s : t = 360 : 4 = 90.",hint:"v ni yoping: s : t.",full:"v = 360 : 4 = 90 km/soat. «1440» — ko'paytirish (s · t) xatosi."},
 tn:"Uchburchakni kartondan kesib, uch bo'lakka bo'ling. Bola bitta bo'lakni olib, qolganidan formulani o'qisin."},
{h:"Tuzoq: 4 · a ni «46» deb o'qish",sum:"a = 6 da 4 · a = 24 (46 emas!), 4 · a + a = 30, 4 · (a + a) = 48.",a:"m06",
 start:function(){w3Expr(['a = 6','4 · a + a = ?']);w3Msg('Ehtiyot bo‘ling!')},fin:function(){w3Expr(['4 · 6 + 6','24 + 6 = {30}']);w3Msg('4 · a — bu «4 marta a», raqam yonma-yon yozish emas')},
 html:"<p>a = 6 bo'lsa, <b>4 · a + a</b> nechaga teng?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['30','46','48','52'],'30',function(){w3Expr(['4 · 6 + 6','24 + 6 = {30}']);w3Msg('To‘g‘ri: 4 · 6 = 24, 24 + 6 = 30');done()},{'46':'4 · a ni «4 va 6 raqamlari» deb o‘qish — bu ko‘paytma! 4 · 6 = 24','48':'Bu 4 · (a + a) — qavs yo‘q, avval ko‘paytirish','52':'«46» + 6 — 4 · a ko‘paytma ekanini unutmang'})},
 after:"<p>Harfli ifodada <b>4a</b> yozuvi — <b>4 · a</b> degani. Shuningdek: a + a + a + a = 4 · a, lekin a · a · a · a ≠ 4 · a. a = 6 da: 4 · a = 24, a · a = 36.</p>",
 q:{t:"m + m + m + m ni qisqa qanday yozamiz?",opts:["4 · m","m · m · m · m","m + 4","4 + m"],ok:0,why:"To'rtta bir xil qo'shiluvchi — 4 ga ko'paytirish.",hint:"Bir xil qo'shiluvchilar yig'indisi — ko'paytma.",full:"m + m + m + m = 4 · m. «m · m · m · m» — bu m ni o'ziga 4 marta ko'paytirish, boshqa narsa."},
 tn:"Ikki xil yozuvni doskaga qo'ying: «a + a + a» va «a · a · a». Kubchalar bilan farqni ko'rsating (qator va kub)."},
{h:"Masaladan harfli ifoda",sum:"Kitob a so'm, daftar 3 marta arzon: 2 kitob va 3 daftar — 2 · a + 3 · (a : 3). a = 1200 da 3600.",a:"m07",
 start:function(){w3Bar([{segs:[{w:3,t:'kitob: a'}],tot:3},{segs:[{w:1,t:'a : 3',c:C.a}],tot:3}]);T(S.g,140,98,'← daftar',{'font-size':13,'font-weight':700,fill:'#5b6b7b','text-anchor':'start'});w3Msg('Daftar kitobdan 3 marta arzon')},
 fin:function(){w3Expr(['2 · a + 3 · (a : 3)','a = 1200:  2400 + 3 · 400','= 2400 + 1200 = {3600}']);w3Msg('Javob: 3600 so‘m')},
 html:"<p>«Kitob <b>a</b> so'm, daftar kitobdan <b>3 marta arzon</b>. 2 ta kitob va 3 ta daftar necha so'm?» Mos ifodani tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['2 · a + 3 · (a : 3)','2 · a + 3 · a · 3','(2 + 3) · a','2 · a + a : 3'],'2 · a + 3 · (a : 3)',function(){w3Expr(['2 · a + 3 · (a : 3)','a = 1200:  2400 + 3 · 400','= 2400 + 1200 = {3600}']);w3Msg('To‘g‘ri — a = 1200 bo‘lsa, 3600 so‘m');done()},{'2 · a + 3 · a · 3':'«3 marta arzon» — bo‘lish, ko‘paytirish emas','(2 + 3) · a':'Daftar kitob bilan bir xil narxda emas','2 · a + a : 3':'Bu faqat bitta daftar narxi — 3 ta kerak'})},
 after:"<p>«3 marta arzon» → <b>a : 3</b>; «3 marta qimmat» → <b>a · 3</b>; «300 so'm arzon» → <b>a − 300</b>. Harfli ifoda masalaning «qolipi»: endi a ning istalgan qiymati uchun javob tayyor.</p>",
 q:{t:"Kitob a so'm, daftar kitobdan 3 marta arzon. a = 1200 bo'lsa, 2 ta kitob va 3 ta daftar necha so'm?",opts:["3600","13 200","6000","2800"],ok:0,why:"2 · 1200 + 3 · 400 = 3600.",hint:"Bitta daftar 1200 : 3 = 400.",full:"Daftar 400 so'm. 2400 + 1200 = 3600. «13 200» — daftarni 3 marta qimmat deb hisoblash; «2800» — faqat bitta daftar qo'shilgan."},
 tn:"Singapur chizma modeli: kitob lentasi 3 katak, daftar — 1 katak. Bolalar avval chizadi, keyin ifoda yozadi."},
{h:"Qiymatlar jadvali va teskari savol",sum:"100 − 4 · n: n = 0, 1, 2, … da 100, 96, 92, … Qiymat 76 bo'lsa: 4 · n = 24, n = 6.",a:"m08",
 start:function(){d3Tab();w3Msg('Har qadamda 4 ga kamayadi')},fin:function(){w3Expr(['100 − 4 · n = 76','4 · n = 24','n = {6}']);w3Msg('Teskari savol tenglamaga aylandi')},
 html:"<p>Jadvalda <b>100 − 4 · n</b> ning qiymatlari: 100, 96, 92, 88, … n ning qaysi qiymatida ifoda <b>76</b> ga teng?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['6','19','24','4'],'6',function(){w3Expr(['100 − 4 · n = 76','4 · n = 100 − 76 = 24','n = 24 : 4 = {6}']);w3Msg('To‘g‘ri! Tekshiruv: 100 − 24 = 76 ✓');done()},{'19':'76 : 4 = 19 — lekin 76 ifodaning qiymati, 4 · n emas','24':'24 — bu 4 · n. n ning o‘zi kerak','4':'n = 4 da 100 − 16 = 84'})},
 after:"<p>«Harfning qaysi qiymatida ifoda shu songa teng?» — bu aslida <b>tenglama</b>: 100 − 4 · n = 76. Harfli ifoda va tenglama — aka-uka.</p>",
 q:{t:"100 − 4 · n = 72 bo'lsa, n = ?",opts:["7","18","28","25"],ok:0,why:"4 · n = 28, n = 7.",hint:"4 · n = 100 − 72.",full:"4 · n = 28 → n = 7. «28» — 4 · n ni n deb olish; «18» — 72 : 4."},
 tn:"Jadvalni doskaga chizing va bolalar navbat bilan keyingi katakni to'ldirsin — naqshni o'zlari sezishadi."},
{h:"Bilasizmi? Harflarni kim «ishga solgan»?",sum:"Fransuz matematigi Fransua Viyet XVI asrda sonlar o'rniga harflarni tizimli ishlatishni boshlagan.",a:"m09",
 start:function(){w3Expr(['a + b = b + a']);w3Msg('Bitta yozuv — cheksiz ko‘p misol')},fin:function(){w3Expr(['a + b = b + a']);w3Msg('Bitta yozuv — cheksiz ko‘p misol')},
 html:"<p>📜 Uzoq vaqt matematiklar qoidalarni so'z bilan yozishgan: «birinchi songa ikkinchisini qo'shsak…». XVI asrda fransuz matematigi <b>Fransua Viyet</b> noma'lum va ma'lum kattaliklarni <b>harflar</b> bilan belgilashni tizimli qo'llay boshlagan.</p><p>⭐ Shu tufayli <b>a + b = b + a</b> kabi bitta qisqa yozuv cheksiz ko'p misolni bir yo'la ifodalaydi. Formulalar — matematikaning «stenografiyasi»!</p>",
 tn:"Bolalarga o'rin almashtirish qoidasini so'z bilan va harf bilan yozdirib, qaysi biri qisqaligini solishtiring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['P = (a + b) · 2,  S = a · b','P = a · 4,  S = a · a','s = v · t']);w3Msg('Asosiy formulalar')},fin:function(){w3Expr(['P = (a + b) · 2,  S = a · b','P = a · 4,  S = a · a','s = v · t']);w3Msg('Asosiy formulalar')},
 html:"<div class='memo'><ul><li>Harfli ifoda: harf o'rniga son qo'yib, amallar tartibi bilan hisoblanadi.</li><li>4a = 4 · a (raqamlarni yonma-yon yozish emas!).</li><li>a + a + a = 3 · a; a · a — boshqa narsa.</li><li>To'g'ri to'rtburchak: P = (a + b) · 2, S = a · b. Kvadrat: P = a · 4, S = a · a.</li><li>s = v · t; v = s : t; t = s : v.</li><li>«n marta arzon» → : n; «n marta qimmat» → · n.</li></ul></div>",
 tn:"Formulalar varag'ini sinf devoriga osib qo'ying — 4E (masalalar) mavzularida doimiy kerak bo'ladi."}
];
var PROBS=[
{t:"a = 27 bo'lsa, 15 + a ning qiymati?",o:["42","12","405","52"],k:0,s:"15 + 27 = 42."},
{t:"a = 12, b = 5, c = 18. a · b − c = ?",o:["42","78","35","24"],k:0,s:"60 − 18 = 42."},
{t:"a = 15 sm, b = 9 sm. P = (a + b) · 2 = ?",o:["48 sm","33 sm","135 sm","24 sm"],k:0,s:"24 · 2 = 48."},
{t:"Kvadrat tomoni 9 sm. Uning yuzi?",o:["81 sm²","36 sm²","18 sm²","27 sm²"],k:0,s:"S = 9 · 9 = 81."},
{t:"v = 70 km/soat, t = 4 soat. s = v · t = ?",o:["280 km","74 km","66 km","2800 km"],k:0,s:"70 · 4 = 280."},
{t:"s = 360 km, t = 4 soat. v = ?",o:["90 km/soat","1440 km/soat","364 km/soat","356 km/soat"],k:0,s:"360 : 4 = 90."},
{t:"a = 6 bo'lsa, 4 · a + a = ?",o:["30","48","46","24"],k:0,s:"24 + 6 = 30."},
{t:"a ning qaysi qiymatida a · a = a + a?",o:["2","1","3","4"],k:0,s:"2 · 2 = 4 va 2 + 2 = 4."},
{t:"n = 7 bo'lsa, 100 − 4 · n = ?",o:["72","672","93","28"],k:0,s:"100 − 28 = 72."},
{t:"100 − 4 · n = 76. n = ?",o:["6","19","24","4"],k:0,s:"4 · n = 24 → n = 6."},
{t:"Kitob a so'm, daftar kitobdan 3 marta arzon. a = 1200 bo'lsa, 2 ta kitob va 3 ta daftar necha so'm?",o:["3600","13 200","6000","2800"],k:0,s:"2400 + 3 · 400 = 3600."},
{t:"Kvadratning perimetri 36 sm. Uning yuzi?",o:["81 sm²","36 sm²","324 sm²","18 sm²"],k:0,s:"a = 9, S = 81."},
{t:"To'g'ri to'rtburchak yuzi 72 sm², bo'yi 9 sm. Perimetri?",o:["34 sm","17 sm","81 sm","63 sm"],k:0,s:"b = 72 : 9 = 8; P = (9 + 8) · 2 = 34."},
{t:"m + m + m + m ni qisqa qanday yozamiz?",o:["4 · m","m · m · m · m","m + 4","4 + m"],k:0,s:"To'rtta bir xil qo'shiluvchi — 4 · m."},
{t:"Daftar a so'm, ruchka b so'm. 5 ta daftar va 2 ta ruchka: a = 3000, b = 2500 bo'lsa, necha so'm?",o:["20 000","38 500","11 000","17 500"],k:0,s:"5 · 3000 + 2 · 2500 = 15 000 + 5000 = 20 000."},
{t:"x = 25, y = 8 bo'lsa, x · 0 + y · 1 = ?",o:["8","33","0","25"],k:0,s:"0 + 8 = 8."},
{t:"P = (a + b) · 2 = 50 sm, a = 15 sm. b = ?",o:["10 sm","35 sm","20 sm","25 sm"],k:0,s:"a + b = 25 → b = 10."},
{t:"Ikki xonali son: o'nliklari a, birliklari b. Uni a · 10 + b deb yozish mumkin. a = 7, b = 3 bo'lsa, son?",o:["73","37","100","21"],k:0,s:"70 + 3 = 73."},
{t:"Teng yonli uchburchakning ikki tomoni a, uchinchisi b: P = 2 · a + b. a = 13 sm, b = 10 sm bo'lsa, P = ?",o:["36 sm","23 sm","46 sm","33 sm"],k:0,s:"26 + 10 = 36."},
{t:"Kubning 12 ta qirrasi bor, har biri a sm. Barcha qirralar yig'indisi 12 · a. a = 7 bo'lsa?",o:["84 sm","49 sm","343 sm","42 sm"],k:0,s:"12 · 7 = 84."}
];
function PRACT_STAGE(){d3Tri();w3Msg('s = v · t,  v = s : t,  t = s : v')}
var PREP_DATA={teach:["Harfli ifoda va uning qiymati (o'rniga qo'yish).","Formulalar: perimetr, yuz, s = v · t.","Masala shartidan harfli ifoda tuzish.","Qiymatlar jadvali; harfning berilgan qiymatga mos qiymatini topish."],
 mist:["4 · a ni «4a» deb raqamlar yonma-yon yozilgan son sifatida o'qiydi (a = 6 → 46).","a · a ni a · 2 bilan adashtiradi.","Perimetr va yuzni almashtiradi.","«3 marta arzon» ni ko'paytirish bilan yozadi."],
 need:["Son kartochkalari va harf kartochkalari.","Kartondan s–v–t uchburchagi.","Katakli qog'oz."],
 board:["<span class='w2'>15 + a: a = 5 → 20; a = 10 → 25</span>.","<span class='w2'>P = (a + b) · 2; S = a · b</span>.","<span class='w2'>s = v · t</span>.","<span class='w2'>a = 6: 4 · a + a = 30</span>.","<span class='w2'>100 − 4 · n = 76 → n = 6</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
