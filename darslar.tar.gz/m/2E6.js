var CODE='2E6',TITLE='2-sinf · Kattaliklarni taqqoslash va almashtirish';
function e6Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// uzunlik ustunlari (sm da), kartochkalar
function e6Bars(items,conv,o){o=o||{};clear();var g=S.g,mx=Math.max.apply(null,items.map(function(x){return x[1]})),W=180;
 items.forEach(function(it,i){var y=16+i*38,w=Math.max(6,it[1]/mx*W),best=o.hl===i;E('rect',{x:110,y:y,width:conv?w:0,height:24,rx:4,fill:best?C.ok:'#8fc6f0',stroke:'#2b6ca3'},g);
  E('rect',{x:8,y:y-2,width:96,height:28,rx:6,fill:'#fff',stroke:best?C.ok:'#c9d3dd','stroke-width':best?2.5:1.2},g);T(g,56,y+17,it[0],{'font-size':12,'font-weight':800,fill:'#1d2b3a'});
  if(conv)T(g,110+w+6,y+17,it[2],{'font-size':12,'font-weight':800,'text-anchor':'start',fill:best?C.ok:C.blue})})}
var L1=[['1 m',100,'100 sm'],['95 sm',95,'95 sm'],['9 dm 9 sm',99,'99 sm'],['10 dm 2 sm',102,'102 sm']];
var T1=[['65 min',65,'65 min'],['75 min',75,'75 min'],['1 soat 10 min',70,'70 min'],['1 soat',60,'60 min']];
var P1=[function(){e6Bars(L1,false);e6Msg('Qaysi uzunlik eng katta? Har xil birliklarda yozilgan…')},
 function(){e6Bars(L1,true);e6Msg('Hammasini <b>santimetr</b>ga aylantirdik: 100, 95, 99, 102')},
 function(){e6Bars(L1,true,{hl:3});e6Msg('Eng kattasi — <b>10 dm 2 sm = 102 sm</b>. «1 m» deganlar aldangan!')}];
var P3=[function(){e6Bars(T1,false);e6Msg('Qaysi vaqt oralig‘i eng uzun?')},
 function(){e6Bars(T1,true);e6Msg('Hammasini <b>minut</b>ga: 1 soat = 60 min, 1 soat 10 min = 70 min')},
 function(){e6Bars(T1,true,{hl:1});e6Msg('Eng uzuni — <b>75 minut</b>')}];
var P5=[function(){clear();var g=S.g;E('rect',{x:30,y:40,width:300,height:30,rx:4,fill:'#f08aa8',stroke:'#b03060'},g);T(g,180,60,'qizil lenta 4 dm',{'font-size':12,'font-weight':800,fill:'#fff'});E('rect',{x:30,y:100,width:60,height:30,rx:4,fill:'#8fc6f0',stroke:'#2b6ca3'},g);T(g,60,120,'8 sm',{'font-size':12,'font-weight':800});e6Msg('Ko‘k lenta qizildan necha marta qisqa? 4 va 8 ni solishtirib bo‘lmaydi — birliklar har xil!')},
 function(){clear();var g=S.g;for(var i=0;i<5;i++){E('rect',{x:30+i*60,y:40,width:60,height:30,fill:'#f08aa8',stroke:'#fff','stroke-width':2},g);T(g,60+i*60,60,'8 sm',{'font-size':11,'font-weight':800,fill:'#fff'})}Br(30,330,36,'4 dm = 40 sm',true);E('rect',{x:30,y:100,width:60,height:30,rx:4,fill:'#8fc6f0',stroke:'#2b6ca3'},g);T(g,60,120,'8 sm',{'font-size':12,'font-weight':800});e6Msg('4 dm = 40 sm. 40 sm da 8 sm <b>5 marta</b> sig‘adi: 40 : 8 = 5')}];
var STEPS=[
{h:"Bir xil birlikka keltiramiz",sum:"Taqqoslashdan oldin hamma kattaliklarni bir xil birlikka (masalan, sm ga) aylantiring.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Masala: <i>«Qaysi uzunlik eng katta: 1 m, 95 sm, 9 dm 9 sm, 10 dm 2 sm?»</i> Sonlar har xil birlikda — ularni to'g'ridan-to'g'ri solishtirib bo'lmaydi. Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>Qoida: <b>avval bir xil birlikka keltiring, keyin taqqoslang</b>. 1 m = 100 sm, 9 dm 9 sm = 99 sm, 10 dm 2 sm = 102 sm. Eng kattasi — 102 sm. «95 katta son-ku» deb aldanmang!</p>",
 q:{t:"Qaysi uzunlik eng kichik?",opts:["1 m","48 sm","5 dm","6 dm"],ok:1,why:"100, 48, 50, 60 sm — eng kichigi 48 sm.",hint:"Hammasini santimetrga aylantiring.",full:"1 m = 100 sm, 5 dm = 50 sm, 6 dm = 60 sm. 48 sm — eng kichik. «1 m» — 1 soni kichik bo'lgani uchun aldanish."},
 tn:"Doskaga ikki ustun chizing: «berilgan» va «santimetrda». Bolalar har kattalikni ikkinchi ustunga ko'chirib yozsin."},
{h:"Teng kattaliklar",sum:"70 sm = 7 dm; 2 soat = 120 minut — yozilishi har xil, qiymati bir xil.",a:"m02",
 start:function(){S.e6k=0;e6Pair(0)},fin:function(){e6Pair(3)},
 html:"<p>Ba'zan yozuvlari har xil kattaliklar aslida <b>teng</b> bo'ladi. Juftlarni ko'ring:</p>",
 btns:[["🔄 Keyingi juft",function(c,done){S.e6k=(S.e6k+1)%4;e6Pair(S.e6k);mvK(done,3)}]],
 after:"<p>70 sm = 7 dm, 2 soat = 120 min, 1 m = 10 dm, 1 dm 5 sm = 15 sm. Belgini to'g'ri qo'yish uchun <b>bir xil birlikka</b> keltiramiz: «=» bo'lishi ham mumkin!</p>",
 q:{t:"70 sm va 7 dm — qaysi biri uzunroq?",opts:["70 sm","7 dm","teng","70 sm 10 marta uzun"],ok:2,why:"7 dm = 70 sm — teng.",hint:"7 dm necha santimetr?",full:"1 dm = 10 sm, 7 dm = 70 sm. Demak 70 sm = 7 dm. «70 katta son» deb aldanmang."},
 tn:"Bolalar o'zlari «teng juftlar» tuzib, bir-biriga topshiriq bersin."},
{h:"Vaqtni taqqoslash",sum:"Vaqtni minutga aylantiring: 1 soat 10 min = 70 min, 75 min — eng uzun.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Vaqt oraliqlari ham turli yozilishi mumkin: <i>65 min, 75 min, 1 soat 10 min, 1 soat</i>. Qaysi biri eng uzun?</p>",
 btns:[phaser(P3)],
 after:"<p>Vaqt uchun yagona birlik — <b>minut</b>: 1 soat = 60 min. Shunda 60, 65, 70, 75 — tartib aniq ko'rinadi. Diqqat: 1 soat = 60 min, 100 emas!</p>",
 q:{t:"Qaysi biri uzun: 1 soat 20 minut yoki 90 minut?",opts:["1 soat 20 min","90 minut","teng","aytib bo'lmaydi"],ok:1,why:"1 soat 20 min = 80 min < 90 min.",hint:"1 soat 20 minutni minutga aylantiring.",full:"1 soat 20 minut = 60 + 20 = 80 minut. 80 < 90, demak 90 minut uzunroq."},
 tn:"Bolalar ko'pincha 1 soat 20 minutni «120» deb o'ylaydi — 60 ni eslatib turing."},
{h:"Tartib bilan teramiz",sum:"9 sm, 1 dm 2 sm (12 sm), 15 sm — o'sish tartibi. Avval sm ga aylantiramiz.",a:"m04",
 start:function(){e6Ord([])},fin:function(){e6Ord(['9 sm','1 dm 2 sm','15 sm'])},
 html:"<p>Uzunliklarni <b>kichikdan kattaga</b> tering. Pastdagi kartochkalarni tartib bilan bosing:</p><div class='digs e6b'></div>",
 act:function(c,done){var box=c.querySelector('.e6b'),need=['9 sm','1 dm 2 sm','15 sm'],got=[];box.innerHTML='';['15 sm','1 dm 2 sm','9 sm'].forEach(function(v){var b=document.createElement('button');b.className='dg wide';b.style.width='96px';b.textContent=v;b.onclick=function(){if(b.disabled)return;if(v===need[got.length]){got.push(v);b.disabled=true;b.className='dg wide yes';b.style.width='96px';e6Ord(got);if(got.length===3)done()}else{b.className='dg wide no';b.style.width='96px';setTimeout(function(){b.className='dg wide';b.style.width='96px'},1200);e6Msg('Hali eng kichigi emas — santimetrga aylantirib solishtiring')}};box.appendChild(b)})},
 after:"<p>1 dm 2 sm = <b>12 sm</b>. Demak tartib: 9 sm &lt; 12 sm &lt; 15 sm. «1 dm 2 sm» ni birinchi qo'yganlar «1» va «2» ga qarab aldangan.</p>",
 q:{t:"Qaysi qatorda uzunliklar o'sish tartibida?",opts:["1 dm 2 sm, 9 sm, 15 sm","9 sm, 15 sm, 1 dm 2 sm","9 sm, 1 dm 2 sm, 15 sm","15 sm, 9 sm, 1 dm 2 sm"],ok:2,why:"9 < 12 < 15.",hint:"1 dm 2 sm necha santimetr?",full:"1 dm 2 sm = 12 sm. O'sish tartibi: 9, 12, 15 sm — ya'ni 9 sm, 1 dm 2 sm, 15 sm."},
 tn:"Kartochkalarni doskaga osib, bolalarni navbat bilan chiqarib tartiblang."},
{h:"«Necha marta» — avval bir xil birlik",sum:"4 dm va 8 sm: 4 dm = 40 sm, 40 : 8 = 5 marta.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Masala: <i>«Qizil lenta 4 dm, ko'k lenta 8 sm. Ko'k lenta qizildan necha marta qisqa?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>«8 : 4 = 2» yoki «4 · 8» — xato! Avval <b>40 sm</b> ga aylantiramiz, keyin 8 sm necha marta sig'ishini topamiz: 40 : 8 = <b>5 marta</b>.</p>",
 q:{t:"Ip 2 m, tasma 20 sm. Tasma ipdan necha marta qisqa?",opts:["10 marta","2 marta","18 marta","100 marta"],ok:0,why:"2 m = 200 sm, 200 : 20 = 10.",hint:"2 metrni santimetrga aylantiring.",full:"2 m = 200 sm. 200 sm da 20 sm necha marta bor? 20, 40, … 200 — 10 marta. «2 marta» — birliklarni hisobga olmagan."},
 tn:"«Necha marta» masalalari (2D5) bilan bog'lang: avval birlik, keyin bo'lish."},
{h:"Tuzoq: har xil birliklar bilan amal",sum:"1 m − 45 sm: 100 − 45 = 55 sm (1 − 45 emas!).",a:"m06",
 start:function(){e6Sub(0)},fin:function(){e6Sub(2)},
 html:"<p>Qo'shish va ayirishda ham birliklar bir xil bo'lishi shart. <i>«1 m − 45 sm = ?»</i></p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.e6s=(S.e6s||0)+1;e6Sub(S.e6s);if(S.e6s>=2){b.disabled=true;done()}}]],
 after:"<p>1 m = 100 sm, demak 100 − 45 = <b>55 sm</b>. Yoki 2 soat − 30 min = 120 − 30 = 90 min = 1 soat 30 min. Javobni qulay ko'rinishda yozing.</p>",
 q:{t:"2 soat − 30 minut = ?",opts:["1 soat 30 minut","1 soat 70 minut","170 minut","30 minut"],ok:0,why:"120 − 30 = 90 min = 1 soat 30 min.",hint:"2 soatni minutga aylantiring.",full:"2 soat = 120 minut. 120 − 30 = 90 minut = 1 soat 30 minut. «1 soat 70 minut» — soatni 100 deb hisoblagan."},
 tn:"Darslikda kattaliklar bilan amallar ko'p uchraydi — har doim «aylantirish» qadamini yozdiring."},
{h:"Bilasizmi? O'nlik va oltmishlik",sum:"Uzunlikda 10 lab (mm → sm → dm → m), vaqtda 60 lab (sekund → minut → soat).",a:"m07",
 start:function(){e6Two()},fin:function(){e6Two()},
 html:"<p>📏 Uzunlik birliklari <b>10 lab</b> o'zgaradi: 10 mm = 1 sm, 10 sm = 1 dm, 10 dm = 1 m. Xuddi sonlarning o'nliklari kabi!</p><p>⏰ Vaqt esa <b>60 lab</b>: 60 sekund = 1 minut, 60 minut = 1 soat. Bu qadimgi Bobildan qolgan hisob.</p><p>💡 Shuning uchun 1 m 50 sm = 150 sm (oson), lekin 1 soat 50 min = 110 min (60 + 50) — ehtiyot bo'ling!</p>",
 tn:"Bolalar ikki zinapoya chizsin: biri 10 lab (mm, sm, dm, m), biri 60 lab (sekund, minut, soat)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){e6Bars(L1,true,{hl:3});e6Msg('Avval bir xil birlik — keyin taqqoslash')},fin:function(){e6Bars(L1,true,{hl:3});e6Msg('Avval bir xil birlik — keyin taqqoslash')},
 html:"<div class='memo'><ul><li>Taqqoslash va amaldan oldin — <b>bir xil birlik</b>.</li><li>Uzunlik: 1 m = 10 dm = 100 sm; 1 dm = 10 sm; 1 sm = 10 mm.</li><li>Vaqt: 1 soat = <b>60</b> min (100 emas).</li><li>70 sm = 7 dm; 1 dm 2 sm = 12 sm.</li><li>«Necha marta»: 4 dm va 8 sm → 40 : 8 = 5.</li><li>1 m − 45 sm = 100 − 45 = 55 sm.</li></ul></div>",
 tn:"Keyingi darsni «3 dm 5 sm ○ 40 sm — qaysi belgi?» (35 < 40) savoli bilan boshlang."}
];
var E6P=[['70 sm','7 dm','70 sm = 70 sm'],['2 soat','120 min','120 min = 120 min'],['1 m','10 dm','100 sm = 100 sm'],['1 dm 5 sm','15 sm','15 sm = 15 sm']];
function e6Pair(k){clear();var g=S.g,p=E6P[k];E('rect',{x:30,y:50,width:120,height:50,rx:10,fill:'#fff',stroke:'#c9d3dd','stroke-width':1.5},g);T(g,90,82,p[0],{'font-size':18,'font-weight':800});E('rect',{x:210,y:50,width:120,height:50,rx:10,fill:'#fff',stroke:'#c9d3dd','stroke-width':1.5},g);T(g,270,82,p[1],{'font-size':18,'font-weight':800});T(g,180,84,'=',{'font-size':30,'font-weight':800,fill:C.ok});T(g,180,140,p[2],{'font-size':13,fill:'#5b6b7b'});e6Msg(p[0]+' = '+p[1]+' (<b>'+p[2]+'</b>)')}
function e6Ord(got){clear();var g=S.g;for(var i=0;i<3;i++){var x=60+i*120;E('rect',{x:x-50,y:56,width:100,height:44,rx:10,fill:got[i]?'#e6f6ee':'#fff',stroke:got[i]?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x,84,got[i]||'?',{'font-size':15,'font-weight':800,fill:got[i]?C.ok:'#9aa8b6'});if(i<2)T(g,x+60,84,'<',{'font-size':18,'font-weight':800,fill:'#9aa8b6'})}e6Msg('Kichikdan kattaga tering')}
function e6Sub(k){S.e6s=k;clear();var g=S.g;var rows=['1 m − 45 sm = ?','1 m = 100 sm','100 sm − 45 sm = 55 sm'];for(var i=0;i<=k;i++)T(g,180,50+i*40,rows[i],{'font-size':18,'font-weight':800,fill:i===2?C.ok:'#1d2b3a'});e6Msg(['Birliklar har xil!','Avval metrni santimetrga aylantiramiz','Javob: <b>55 sm</b>'][k])}
function e6Two(){clear();var g=S.g;['mm','sm','dm','m'].forEach(function(u,i){E('rect',{x:20+i*40,y:130-i*30,width:38,height:24,rx:4,fill:'#8fc6f0'},g);T(g,39+i*40,146-i*30,u,{'font-size':11,'font-weight':800});if(i)T(g,20+i*40,124-i*30+12,'×10',{'font-size':8,fill:C.blue})});
 ['sek','min','soat'].forEach(function(u,i){E('rect',{x:220+i*44,y:130-i*30,width:42,height:24,rx:4,fill:'#f6c343'},g);T(g,241+i*44,146-i*30,u,{'font-size':11,'font-weight':800});if(i)T(g,220+i*44,124-i*30+12,'×60',{'font-size':8,fill:'#a07a1c'})});e6Msg('Uzunlik — 10 lab, vaqt — 60 lab')}
var PROBS=[
{t:"Qaysi uzunlik eng katta?",o:["10 dm 2 sm","1 m","95 sm","9 dm 9 sm"],k:0,s:"102, 100, 95, 99 sm — eng kattasi 10 dm 2 sm."},
{t:"Qaysi uzunlik eng kichik?",o:["48 sm","1 m","5 dm","6 dm"],k:0,s:"48 < 50 < 60 < 100."},
{t:"70 sm va 7 dm — qaysi biri uzunroq?",o:["teng","70 sm","7 dm","70 sm 10 marta uzun"],k:0,s:"7 dm = 70 sm."},
{t:"5 m necha detsimetr?",o:["50 dm","500 dm","5 dm","15 dm"],k:0,s:"1 m = 10 dm, 5 m = 50 dm."},
{t:"2 soat necha minut?",o:["120 minut","200 minut","100 minut","60 minut"],k:0,s:"60 · 2 = 120."},
{t:"1 soat 15 minut necha minut?",o:["75 minut","115 minut","65 minut","90 minut"],k:0,s:"60 + 15 = 75."},
{t:"Qaysi vaqt oralig'i eng uzun?",o:["75 minut","1 soat 10 minut","65 minut","1 soat"],k:0,s:"75 > 70 > 65 > 60."},
{t:"Qizil lenta 4 dm, ko'k lenta 8 sm. Ko'k lenta qizildan necha marta qisqa?",o:["5","2","32","4"],k:0,s:"40 : 8 = 5."},
{t:"Qaysi qatorda o'sish tartibi?",o:["9 sm, 1 dm 2 sm, 15 sm","1 dm 2 sm, 9 sm, 15 sm","9 sm, 15 sm, 1 dm 2 sm","15 sm, 9 sm, 1 dm 2 sm"],k:0,s:"9 < 12 < 15."},
{t:"1 m − 45 sm = ?",o:["55 sm","44 sm","65 sm","1 m 45 sm"],k:0,s:"100 − 45 = 55."},
{t:"2 soat − 30 minut = ?",o:["1 soat 30 minut","1 soat 70 minut","30 minut","170 minut"],k:0,s:"120 − 30 = 90 min."},
{t:"Qaysi belgi to'g'ri: 3 dm 5 sm ○ 40 sm",o:["<",">","="],k:0,s:"3 dm 5 sm = 35 sm < 40 sm."},
{t:"Qaysi belgi to'g'ri: 1 soat 20 min ○ 90 min",o:["<",">","="],k:0,s:"80 < 90."},
{t:"Ip 2 m, tasma 20 sm. Tasma ipdan necha marta qisqa?",o:["10","2","18","100"],k:0,s:"200 : 20 = 10."},
{t:"Qaysi yozuv noto'g'ri?",o:["1 soat = 100 minut","1 m = 100 sm","1 dm = 10 sm","1 sm = 10 mm"],k:0,s:"1 soat = 60 minut."},
{t:"Ali 1 m 5 sm, Vali 98 sm sakradi. Kim uzoq va qanchaga?",o:["Ali, 7 sm","Vali, 7 sm","Ali, 93 sm","teng"],k:0,s:"105 − 98 = 7."},
{t:"45 mm va 5 sm — qaysi biri uzun?",o:["5 sm","45 mm","teng","aytib bo'lmaydi"],k:0,s:"5 sm = 50 mm > 45 mm."},
{t:"Dars 45 minut, tanaffus 15 minut. Ikki dars va bitta tanaffus necha minut?",o:["105 minut","60 minut","1 soat 15 minut","90 minut"],k:0,s:"45 + 15 + 45 = 105 min (1 soat 45 min)."},
{t:"Qaysi uzunlik 1 m dan qisqa?",o:["9 dm 8 sm","10 dm","1 m 1 sm","110 sm"],k:0,s:"98 sm < 100 sm."},
{t:"3 ta bir xil tayoq birga 1 m 20 sm. Bitta tayoq necha santimetr?",o:["40 sm","4 sm","60 sm","123 sm"],k:0,s:"120 : 3 = 40."}
];
function PRACT_STAGE(){e6Bars(L1,true,{hl:3});e6Msg('Avval bir xil birlik — keyin taqqoslash')}
var PREP_DATA={teach:["Kattaliklarni bir xil birlikka keltirib taqqoslash.","Teng kattaliklar (70 sm = 7 dm).","Vaqtni minutga aylantirib taqqoslash.","Tartiblash; «necha marta»; har xil birliklar bilan amal."],
 mist:["«95 sm» ni «1 m» dan katta deb o'ylaydi (95 > 1).","1 soatni 100 minut deb oladi.","4 dm va 8 sm ni 8 : 4 = 2 deb hisoblaydi.","1 m − 45 sm ni bajara olmaydi."],
 need:["Kattalik yozilgan kartochkalar."],
 board:["Ikki ustun: <span class='w2'>berilgan | santimetrda</span>.","<span class='w2'>1 m = 100 sm, 9 dm 9 sm = 99 sm, 10 dm 2 sm = 102 sm</span>.","<span class='w2'>1 soat 10 min = 70 min</span>.","<span class='w2'>4 dm = 40 sm, 40 : 8 = 5</span>.","<span class='w2'>1 m − 45 sm = 55 sm</span>."]};
