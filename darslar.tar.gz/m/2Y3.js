var CODE='2Y3',TITLE='2-sinf yakuni · Ko‘p bosqichli matnli masalalar (chizma model)';
// ---------- chizma model yordamchilari ----------
function y3bar(x,y,w,lab,col,txt,o){o=o||{};var g=S.g;T(g,x-8,y+16,lab,{'font-size':12,'font-weight':800,fill:'#33475b','text-anchor':'end'});
 E('rect',{x:x,y:y,width:w,height:24,rx:3,fill:col||C.b,stroke:C.line,'stroke-width':1.5,'stroke-dasharray':o.dash?'5 3':''},g);if(txt)T(g,x+w/2,y+16,txt,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}
function y3seg(x,y,w,col,txt){E('rect',{x:x,y:y,width:w,height:24,rx:3,fill:col,stroke:C.line,'stroke-width':1.5},S.g);if(txt)T(S.g,x+w/2,y+16,txt,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}
function y3q(t){var a=t,b='';if(t.length>52){var k=t.lastIndexOf(' ',52);a=t.slice(0,k);b=t.slice(k+1)}T(S.g,8,14,a,{'font-size':11,'text-anchor':'start',fill:'#5b6b7b','font-weight':600});if(b)T(S.g,8,27,b,{'font-size':11,'text-anchor':'start',fill:'#5b6b7b','font-weight':600})}
var X=80;
var P1=[function(){clear();y3q('Alida 24 ta yong‘oq, Valida 8 ta ko‘p. Ikkalasida jami?');y3bar(X,40,120,'Ali',C.b,'24');calc(['Avval Alining chizig‘ini chizamiz: 24'])},
 function(){clear();y3q('Alida 24 ta yong‘oq, Valida 8 ta ko‘p. Ikkalasida jami?');y3bar(X,40,120,'Ali',C.b,'24');y3bar(X,80,120,'Vali',C.b,'24');y3seg(X+120,80,40,C.a,'8');calc(['Vali — Alicha va yana 8 ta: 24 + 8 = <b>32</b> (1-bosqich)'])},
 function(){clear();y3q('Alida 24 ta yong‘oq, Valida 8 ta ko‘p. Ikkalasida jami?');y3bar(X,40,120,'Ali',C.b,'24');y3bar(X,80,120,'Vali',C.b,'24');y3seg(X+120,80,40,C.a,'8');E('path',{d:'M'+(X+170)+' 40 q10 0 10 10 v44 q0 10 -10 10',fill:'none',stroke:C.ok,'stroke-width':2},S.g);T(S.g,X+215,72,'jami = ?',{'font-size':13,'font-weight':800,fill:C.ok});calc(['Vali: 24 + 8 = 32','Jami: 24 + 32 = <b>56</b> (2-bosqich)'])}];
var P2=[function(){clear();y3q('Olma 6 kg, nok 3 marta ko‘p. Jami necha kg meva?');y3bar(X,40,50,'Olma',C.c,'6');calc(['Olma — 1 bo‘lak: 6 kg'])},
 function(){clear();y3q('Olma 6 kg, nok 3 marta ko‘p. Jami necha kg meva?');y3bar(X,40,50,'Olma',C.c,'6');for(var i=0;i<3;i++)y3seg(X+i*50,80,50,C.ok,'6');T(S.g,X-8,96,'Nok',{'font-size':12,'font-weight':800,'text-anchor':'end'});calc(['«3 marta ko‘p» — 3 ta xuddi shunday bo‘lak: 6 · 3 = <b>18</b> kg'])},
 function(){clear();y3q('Olma 6 kg, nok 3 marta ko‘p. Jami necha kg meva?');y3bar(X,40,50,'Olma',C.c,'6');for(var i=0;i<3;i++)y3seg(X+i*50,80,50,C.ok,'6');T(S.g,X-8,96,'Nok',{'font-size':12,'font-weight':800,'text-anchor':'end'});Br(X,X+200,112,'jami: 4 bo‘lak = 24 kg',false,C.blue);calc(['Nok: 6 · 3 = 18','Jami: 6 + 18 = <b>24</b> kg (yoki 4 bo‘lak · 6)'])}];
var P3=[function(){clear();y3q('Ikki savatda jami 30 ta olma. Birinchisida 6 ta ko‘p. Har birida nechta?');y3bar(X,40,110,'1-savat',C.b,'?');y3seg(X+110,40,40,C.a,'6');y3bar(X,80,110,'2-savat',C.b,'?');E('path',{d:'M'+(X+160)+' 40 q10 0 10 10 v44 q0 10 -10 10',fill:'none',stroke:C.blue,'stroke-width':2},S.g);T(S.g,X+200,72,'30',{'font-size':15,'font-weight':800,fill:C.blue});calc(['Chizma: ikkita teng bo‘lak va ortiqcha 6. Hammasi 30'])},
 function(){clear();y3q('Ikki savatda jami 30 ta olma. Birinchisida 6 ta ko‘p. Har birida nechta?');y3bar(X,40,110,'1-savat',C.b,'?');y3seg(X+110,40,40,'#ffd0d0','6');E('line',{x1:X+112,y1:42,x2:X+148,y2:62,stroke:C.bad,'stroke-width':2.5},S.g);y3bar(X,80,110,'2-savat',C.b,'?');calc(['Ortiqcha 6 ni olib qo‘yamiz: 30 − 6 = <b>24</b> — endi ikki teng bo‘lak'])},
 function(){clear();y3q('Ikki savatda jami 30 ta olma. Birinchisida 6 ta ko‘p. Har birida nechta?');y3bar(X,40,110,'1-savat',C.b,'12');y3seg(X+110,40,40,C.a,'6');y3bar(X,80,110,'2-savat',C.b,'12');calc(['24 : 2 = 12 — 2-savat','1-savat: 12 + 6 = <b>18</b>. Tekshiramiz: 18 + 12 = 30 ✓'])}];
var P4=[function(){clear();y3q('Jami 24 ta qalam. Ali Validan 2 marta ko‘p oldi. Har biri nechta?');y3bar(X,40,60,'Vali',C.b,'?');y3seg(X,80,60,C.ok,'?');y3seg(X+60,80,60,C.ok,'?');T(S.g,X-8,96,'Ali',{'font-size':12,'font-weight':800,'text-anchor':'end'});calc(['Vali — 1 bo‘lak, Ali — 2 bo‘lak (2 marta ko‘p)'])},
 function(){clear();y3q('Jami 24 ta qalam. Ali Validan 2 marta ko‘p oldi. Har biri nechta?');y3bar(X,40,60,'Vali',C.b,'?');y3seg(X,80,60,C.ok,'?');y3seg(X+60,80,60,C.ok,'?');T(S.g,X-8,96,'Ali',{'font-size':12,'font-weight':800,'text-anchor':'end'});Br(X,X+120,112,'3 bo‘lak = 24',false);calc(['Jami bo‘laklar: 1 + 2 = <b>3</b>. 3 bo‘lak = 24'])},
 function(){clear();y3q('Jami 24 ta qalam. Ali Validan 2 marta ko‘p oldi. Har biri nechta?');y3bar(X,40,60,'Vali',C.b,'8');y3seg(X,80,60,C.ok,'8');y3seg(X+60,80,60,C.ok,'8');T(S.g,X-8,96,'Ali',{'font-size':12,'font-weight':800,'text-anchor':'end'});calc(['1 bo‘lak: 24 : 3 = 8 — Vali','Ali: 8 · 2 = <b>16</b>. Tekshiramiz: 8 + 16 = 24 ✓'])}];
var P5=[function(){clear();y3q('Alida 25 ta marka bor. Bu Valinikidan 7 ta KO‘P. Valida nechta?');y3bar(X,40,160,'Ali',C.b,'25');calc(['«Ko‘p» so‘zi bor — lekin kim ko‘p? ALI ko‘p!'])},
 function(){clear();y3q('Alida 25 ta marka bor. Bu Valinikidan 7 ta KO‘P. Valida nechta?');y3bar(X,40,160,'Ali',C.b,'25');y3bar(X,80,115,'Vali',C.c,'?');E('rect',{x:X+115,y:80,width:45,height:24,fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 3'},S.g);T(S.g,X+137,96,'7',{'font-size':12,'font-weight':800,fill:C.bad});calc(['Vali qisqaroq: Alidan 7 ta kam'])},
 function(){clear();y3q('Alida 25 ta marka bor. Bu Valinikidan 7 ta KO‘P. Valida nechta?');y3bar(X,40,160,'Ali',C.b,'25');y3bar(X,80,115,'Vali',C.c,'18');calc(['Vali: 25 − 7 = <b>18</b>. «Ko‘p» so‘zi bor, lekin AYIRDIK!'])}];
var STEPS=[
{h:"Chizma — masalaning rasmi",sum:"Har bir miqdor — chiziq. «Ko'p» — chiziq uzunroq. Avval chizma, keyin hisob.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ko'p bosqichli masalada adashmaslik uchun dunyodagi eng kuchli usul — <b>chizma model</b> (Singapur usuli). Har bir miqdorni <b>chiziq</b> qilib chizamiz. Masala: <i>«Alida 24 ta yong'oq, Valida 8 ta ko'p. Ikkalasida jami nechta?»</i></p>",
 btns:[phaser(P1)],
 after:"<p>Bu masala <b>ikki bosqichli</b>: avval Valinikini topamiz (24 + 8 = 32), keyin jamini (24 + 32 = 56). Ko'pchilik «24 + 8 = 32» deb to'xtab qoladi — chizma ikkinchi bosqich borligini ko'rsatadi.</p>",
 q:{t:"Sinfda 14 ta qiz, o'g'il bolalar 5 ta kam. Sinfda jami nechta bola?",opts:["23","9","19","33"],ok:0,why:"O'g'illar 14 − 5 = 9, jami 14 + 9 = 23.",hint:"Avval o'g'il bolalar sonini toping. Keyin nima qilish kerak?",full:"1-bosqich: o'g'illar 14 − 5 = 9. 2-bosqich: jami 14 + 9 = 23. «9» — faqat birinchi bosqich, «19» — 14 + 5, «kam» o'rniga qo'shilgan."},
 tn:"Har masalada bolalar avval chizma chizsin va noma'lumni «?» bilan belgilasin. Singapur darsliklari buni 1-sinfdan o'rgatadi."},
{h:"«Marta ko'p» — teng bo'laklar",sum:"Olma 6, nok 3 marta ko'p: nok 3 bo'lak (18), jami 4 bo'lak (24).",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p><i>«Olma 6 kg, nok 3 marta ko'p. Jami necha kg meva?»</i> «Marta ko'p» bo'lganda chizma qanday bo'lishini ko'ring.</p>",
 btns:[phaser(P2)],
 after:"<p>«3 marta ko'p» — bu olmaning chizig'i <b>3 marta</b> takrorlanadi. Nok: 6 · 3 = 18. Jami: 6 + 18 = 24, yoki 4 ta bo'lak · 6 = 24.</p>",
 q:{t:"Ali 5 ta kitob o'qidi, Vali 4 marta ko'p. Ikkalasi jami nechta kitob o'qidi?",opts:["25","20","9","24"],ok:0,why:"Vali 5 · 4 = 20, jami 5 + 20 = 25.",hint:"Avval Valini toping (marta ko'p — ko'paytiramiz), keyin qo'shing.",full:"Vali: 5 · 4 = 20. Jami: 5 + 20 = 25. «20» — faqat Vali, «9» — 5 + 4, «marta» o'rniga qo'shilgan."},
 tn:"«…ta ko'p» va «…marta ko'p» ni yonma-yon chizdiring: birinchisida chiziq oxiriga kichik bo'lak qo'shiladi, ikkinchisida butun chiziq takrorlanadi."},
{h:"Jami va farq ma'lum",sum:"Jami 30, farq 6: 30 − 6 = 24, 24 : 2 = 12 (kichigi), 12 + 6 = 18 (kattasi).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Endi qiyinrog'i: <i>«Ikki savatda jami 30 ta olma. Birinchisida ikkinchisidan 6 ta ko'p. Har birida nechta?»</i> Bu yerda hech bir savat ma'lum emas!</p>",
 btns:[phaser(P3)],
 after:"<p>Usul: ortiqchasini olib tashlaymiz — ikki <b>teng</b> bo'lak qoladi. 30 − 6 = 24, 24 : 2 = 12. Ortiqchasini qaytaramiz: 12 + 6 = 18. Bu usul 4-sinfdagi «yig'indi va ayirmasiga ko'ra» masalalarning asosi.</p>",
 q:{t:"Akasi va ukasida jami 20 ta mashinka. Akasida 4 ta ko'p. Ukasida nechta?",opts:["8","12","10","16"],ok:0,why:"(20 − 4) : 2 = 8 — ukasi, akasi 12.",hint:"Ortiqcha 4 ni olib tashlang — qolganini ikkiga bo'ling.",full:"20 − 4 = 16, 16 : 2 = 8 — ukasi. Akasi 8 + 4 = 12. Tekshiramiz: 8 + 12 = 20 ✓. «10» — farqni hisobga olmasdan teng bo'lgan."},
 tn:"Bolalar ikki qog'oz tasmani yonma-yon qo'yib, uzunini kesib tenglashtirsin — g'oya qo'l bilan his qilinadi."},
{h:"Jami va «marta» ma'lum",sum:"Jami 24, biri 2 marta ko'p: 3 bo'lak = 24, 1 bo'lak = 8, ikkinchisi 16.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p><i>«Jami 24 ta qalam. Ali Validan 2 marta ko'p oldi. Har biri nechta oldi?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Kalit fikr: hammasini <b>bir xil bo'laklarda</b> sanaymiz. Vali 1 bo'lak, Ali 2 bo'lak — jami 3 bo'lak = 24. 1 bo'lak = 8.</p>",
 q:{t:"Savatda jami 20 ta meva: nok olmadan 4 marta ko'p. Olma nechta?",opts:["4","5","16","10"],ok:0,why:"1 + 4 = 5 bo'lak = 20, 1 bo'lak = 4 — olma.",hint:"Olma — 1 bo'lak, nok — 4 bo'lak. Jami nechta bo'lak?",full:"Olma 1 bo'lak, nok 4 bo'lak — jami 5 bo'lak = 20. 1 bo'lak = 20 : 5 = 4 — olma, nok 16. «5» — 20 : 4, bo'laklar soni xato sanalgan."},
 tn:"Bo'laklarni kubiklar bilan ko'rsating: 1 kubik va 4 kubik — jami 5 kubik."},
{h:"Tuzoq: «ko'p» bor, lekin ayiramiz",sum:"«Alida 25 ta, bu Validan 7 ta ko'p» → Vali 25 − 7 = 18. So'zga emas, ma'noga qarang!",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Eng mashhur tuzoq: <i>«Alida 25 ta marka bor. Bu Valinikidan 7 ta ko'p. Valida nechta?»</i> «Ko'p» so'zini ko'rib, darhol qo'shmang!</p>",
 btns:[phaser(P5)],
 after:"<p>Kim ko'p? <b>Ali</b>. Demak Vali <b>kam</b>: 25 − 7 = 18. Bunday masalalarni «teskari ifodalangan» masalalar deyishadi. Chizma doim haqiqatni ko'rsatadi: kim uzunroq bo'lsa — o'sha ko'p.</p>",
 q:{t:"Nonvoy bugun 40 ta non yopdi. Bu kechagidan 8 ta kam. Kecha nechta non yopgan?",opts:["48","32","40","8"],ok:0,why:"Bugun kam — kecha ko'p: 40 + 8 = 48.",hint:"Qaysi kun ko'p yopilgan: bugunmi yoki kecha?",full:"«Bugun kechagidan kam» — demak kecha ko'p: 40 + 8 = 48. «32» — «kam» so'zini ko'rib ayirilgan, bu tuzoq."},
 tn:"Bolalar har masalada «kim ko'p?» degan savolga og'zaki javob bersin, keyin chizsin."},
{h:"Uch bosqichli masala",sum:"Har bosqich — bitta savol. Avtobus: 40 − 12 + 7 = 35.",a:"m06",
 start:function(){y3bus(0)},fin:function(){y3bus(3)},
 html:"<p><i>«Avtobusda 40 yo'lovchi bor edi. Bekatda 12 kishi tushdi, 7 kishi chiqdi. Keyingi bekatda yana 5 kishi tushdi. Avtobusda nechta yo'lovchi qoldi?»</i> Har bekatni bittalab bosing.</p>",
 btns:[["🚌 Keyingi bekat",function(c,done,b){S.y3k=(S.y3k||0)+1;y3bus(S.y3k);if(S.y3k>=3){b.disabled=true;done()}}]],
 after:"<p>Har bekat — bitta amal: 40 − 12 = 28, 28 + 7 = 35, 35 − 5 = 30. Uzun masalani <b>bo'laklarga</b> ajratib, har birini alohida yozsak — adashmaymiz.</p>",
 q:{t:"Do'konda 50 kg un bor edi. Ertalab 18 kg sotildi, tushda 20 kg keltirildi, kechqurun 15 kg sotildi. Qancha un qoldi?",opts:["37","17","53","47"],ok:0,why:"50 − 18 = 32, 32 + 20 = 52, 52 − 15 = 37.",hint:"Har bir hodisani alohida bajaring: sotildi — ayiring, keltirildi — qo'shing.",full:"50 − 18 = 32; 32 + 20 = 52; 52 − 15 = 37. «17» — keltirilgani ham ayirilgan, «53» — sotilgan ham qo'shilgan."},
 tn:"Masalani hikoya qilib, bolalar qo'lida kubiklarni qo'shib-olib tursin — har bosqichdan keyin «hozir nechta?» deb so'rang."},
{h:"Bilasizmi? Chizma model",sum:"Chizma model (bar model) Singapurda 1980-yillarda ishlab chiqilgan.",a:"m07",
 start:function(){y3sg()},fin:function(){y3sg()},
 html:"<p>🇸🇬 Chizma model Singapurda 1980-yillarda matematik o'qituvchilar tomonidan ishlab chiqilgan. O'shandan beri Singapur maktab o'quvchilari xalqaro TIMSS va PISA tadqiqotlarida doim eng yuqori o'rinlardan birini egallab keladi.</p><p>⭐ Chizma — bu «rasmli tenglama». Keyinchalik siz noma'lum bo'lakni <b>x</b> harfi bilan belgilaysiz — bu al-Xorazmiy asos solgan <b>algebra</b>ga yo'l ochadi.</p>",
 tn:"Bolalarga har uyga vazifadagi masalaga albatta chizma chizish odatini singdiring."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li>Avval <b>chizma</b>, keyin hisob. Noma'lum — «?».</li><li><b>…ta ko'p</b> — chiziq oxiriga bo'lak qo'shiladi; <b>…marta ko'p</b> — chiziq takrorlanadi.</li><li>Savol «jami» bo'lsa — ikkinchi bosqichni unutmang.</li><li>Jami va farq: ortiqchani oling → ikkiga bo'ling → ortiqchani qaytaring.</li><li>Jami va «marta»: hammasini bo'laklarda sanang → 1 bo'lakni toping.</li><li>«Ko'p» so'zi har doim qo'shish emas — <b>kim ko'p?</b> deb so'rang.</li><li>Oxirida javobni shartga qo'yib tekshiring.</li></ul></div>",
 tn:"Keyingi darsni «Jami 35, biri ikkinchisidan 4 marta ko'p» (7 va 28) masalasi bilan boshlang."}
];
function y3bus(k){clear();var g=S.g,stops=[['Boshida',40],['−12 +7',35],['−5',30]];
 E('rect',{x:40,y:46,width:180,height:60,rx:12,fill:'#ffd24d',stroke:'#b08a1a','stroke-width':2},g);for(var i=0;i<4;i++)E('rect',{x:52+i*40,y:56,width:30,height:22,rx:3,fill:'#e8f1fb',stroke:'#b08a1a'},g);E('circle',{cx:75,cy:110,r:10,fill:'#33475b'},g);E('circle',{cx:185,cy:110,r:10,fill:'#33475b'},g);
 var v=[40,28,35,30][k];T(g,130,98,v+' yo‘lovchi',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
 var L=['40 yo‘lovchi','40 − 12 = 28','28 + 7 = 35','35 − 5 = 30'];T(g,290,70,L[k],{'font-size':14,'font-weight':800,fill:C.blue});
 calc(L.slice(0,k+1).map(function(x,i){return (i?i+'-bosqich: ':'')+x}))}
function y3sg(){clear('#eef6ff');var g=S.g;y3bar(X,60,90,'Ali',C.b,'?');y3seg(X+90,60,40,C.a,'5');y3bar(X,100,90,'Vali',C.b,'?');T(g,180,150,'Chizma → tenglama: x + x + 5 = 25',{'font-size':13,'font-weight':800,fill:C.blue});calc(['Singapur usuli: «rasmli tenglama»'])}
var PROBS=[
{t:"Alida 18 ta qalam, Valida 6 ta ko'p. Ikkalasida jami nechta?",o:["42","24","30","12"],k:0,s:"Vali 18 + 6 = 24, jami 18 + 24 = 42."},
{t:"Qutida 30 ta konfet, ikkinchisida 8 ta kam. Ikkalasida jami nechta?",o:["52","22","38","68"],k:0,s:"2-quti 30 − 8 = 22, jami 30 + 22 = 52."},
{t:"Kitobda 7 ta rasm, daftarda 3 marta ko'p. Jami nechta rasm?",o:["28","21","10","24"],k:0,s:"Daftarda 7 · 3 = 21, jami 7 + 21 = 28."},
{t:"Ikki sinfda jami 50 bola. Birinchisida 6 ta ko'p. Ikkinchisida nechta?",o:["22","28","25","44"],k:0,s:"(50 − 6) : 2 = 22."},
{t:"Ikki sinfda jami 50 bola. Birinchisida 6 ta ko'p. Birinchisida nechta?",o:["28","22","25","56"],k:0,s:"Ikkinchisi 22, birinchisi 22 + 6 = 28."},
{t:"Jami 30 ta shar: qizil sharlar ko'kdan 2 marta ko'p. Ko'k sharlar nechta?",o:["10","15","20","5"],k:0,s:"3 bo'lak = 30, 1 bo'lak = 10 — ko'k."},
{t:"Jami 36 ta daftar: Ali Validan 3 marta ko'p oldi. Ali nechta oldi?",o:["27","9","12","33"],k:0,s:"4 bo'lak = 36, 1 bo'lak = 9 — Vali, Ali 27."},
{t:"Bugun 32 ta gul uzildi. Bu kechagidan 9 ta ko'p. Kecha nechta gul uzilgan?",o:["23","41","32","9"],k:0,s:"Bugun ko'p — kecha kam: 32 − 9 = 23."},
{t:"Ukam 15 ta rasm chizdi. Bu akamnikidan 6 ta kam. Akam nechta chizgan?",o:["21","9","15","30"],k:0,s:"Uka kam — aka ko'p: 15 + 6 = 21."},
{t:"Avtobusda 35 kishi bor edi. 10 kishi tushdi, 8 kishi chiqdi. Nechta bo'ldi?",o:["33","17","53","25"],k:0,s:"35 − 10 = 25, 25 + 8 = 33."},
{t:"Ali 40 so'm oldi. 15 so'mga qalam, 12 so'mga daftar sotib oldi. Qancha qoldi?",o:["13","27","25","67"],k:0,s:"15 + 12 = 27, 40 − 27 = 13."},
{t:"Bog'da 8 ta olma daraxti, nok 2 marta ko'p, o'rik nokdan 5 ta kam. O'rik nechta?",o:["11","16","21","3"],k:0,s:"Nok 8 · 2 = 16, o'rik 16 − 5 = 11."},
{t:"Ikki qutida jami 24 ta kubik. Ulardagi kubiklar teng. Bittasidan 3 tasi ikkinchisiga olindi. Endi ikkinchisida nechta?",o:["15","12","9","27"],k:0,s:"Har birida 12. 12 + 3 = 15."},
{t:"Ali Validan 4 ta ko'p olma oldi. Ali Valiga 2 ta bersa, kimda ko'p bo'ladi?",o:["Teng bo'ladi","Alida 2 ta ko'p","Valida 2 ta ko'p","Alida 4 ta ko'p"],k:0,s:"Farq 4, Ali 2 tasini bersa, unda 2 kamayadi, Valida 2 ortadi — farq 0."},
{t:"Jami 40 ta: qizlar o'g'illardan 3 marta ko'p. Qizlar o'g'illardan nechta ko'p?",o:["20","30","10","3"],k:0,s:"4 bo'lak = 40, 1 bo'lak = 10. Qizlar 30, o'g'il 10, farq 20."},
{t:"Ikki sonning yig'indisi 17, biri ikkinchisidan 5 ta katta. Kichigi?",o:["6","11","12","8"],k:0,s:"(17 − 5) : 2 = 6."},
{t:"Do'konga 3 ta qutida 9 tadan sharbat keldi. 15 tasi sotildi. Nechta qoldi?",o:["12","27","42","6"],k:0,s:"3 · 9 = 27, 27 − 15 = 12."},
{t:"Ali 5 ta, Vali Alidan 3 marta ko'p, Hasan Validan 4 ta kam konfet oldi. Hasanda nechta?",o:["11","15","19","4"],k:0,s:"Vali 15, Hasan 15 − 4 = 11."},
{t:"Ip 30 sm. Undan 3 marta 6 sm dan kesildi. Qancha qoldi?",o:["12","24","18","21"],k:0,s:"3 · 6 = 18, 30 − 18 = 12."},
{t:"Jami 27 ta: ko'k, qizil va yashil qalamlar teng. Ko'kdan 4 tasi yo'qoldi. Endi nechta qalam?",o:["23","9","5","31"],k:0,s:"27 − 4 = 23 (har biri 9 ta edi, faqat ko'k kamaydi)."}
];
function PRACT_STAGE(){clear();y3q('Har masalaga avval chizma chizing ✏️');y3bar(X,50,120,'Ali',C.b,'?');y3bar(X,90,80,'Vali',C.c,'?');calc(['Chizma → bosqichlar → tekshirish'])}
var PREP_DATA={teach:["Chizma model: har bir miqdor — chiziq.","«…ta ko'p/kam» va «…marta ko'p» chizmalari.","Jami va farq; jami va «marta» masalalari.","Teskari ifodalangan masalalar; uch bosqichli masalalar."],
 mist:["Ikki bosqichli masalada birinchi bosqichda to'xtaydi.","«Ko'p» so'zini ko'rib darhol qo'shadi.","«Marta ko'p» va «ta ko'p» ni aralashtiradi.","Jami va farq masalasida jamini ikkiga bo'lib qo'yadi."],
 need:["Qog'oz tasmalar (uzun-qisqa).","Kubiklar yoki tayoqchalar."],
 board:["Chizma: <span class='w2'>Ali [24]  Vali [24][8]</span>.","«3 marta»: <span class='w2'>[6][6][6]</span>.","Jami 30, farq 6: <span class='w2'>(30 − 6) : 2 = 12</span>.","Jami 24, 2 marta: <span class='w2'>3 bo'lak = 24</span>.","Tuzoq: «bu Validan 7 ta ko'p» → ayirish.","Avtobus: <span class='w2'>40 − 12 + 7 − 5</span>."]};
