var CODE='3B6',TITLE='3-sinf · Qo‘shish va ayirish xossalari, natijani chamalash';
function w3b6c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
var P1=[function(){bqBar(600,[{v:'250',w:250,col:C.a,lab:'qizil'},{v:'350',w:350,col:C.b,lab:'ko‘k'}],{title:'250 + 350'});bqMsg('Avval qizil, keyin ko‘k')},
 function(){bqBar(600,[{v:'350',w:350,col:C.b,lab:'ko‘k'},{v:'250',w:250,col:C.a,lab:'qizil'}],{title:'350 + 250'});bqMsg('Joyini almashtirdik — uzunlik o‘sha-o‘sha: 600')},
 function(){bqExpr(['250 + 350 = 350 + 250','a + b = b + a']);bqMsg('<b>O‘rin almashtirish</b> xossasi')}];
var P2=[function(){bqExpr(['(278 + 300) + 22']);bqMsg('Qaysi ikkitasini avval qo‘shish qulay?')},function(){bqExpr(['278 + (300 + 22)','= 278 + 322']);bqMsg('Qavsni ko‘chirsak ham bo‘ladi…')},function(){bqExpr(['(278 + 22) + 300','= 300 + 300 = [600]']);bqMsg('…va o‘rin almashtirsak — eng oson!')}];
var P4=[function(){bqLine(400,600,[],[[487,C.blue]],{step:50});bqMsg('487 qaysi yaxlit yuzlikka yaqin?')},function(){bqLine(400,600,[[487,500,'13',C.ok],[487,400,'87',C.bad]],[[487,C.blue]],{step:50});bqMsg('500 gacha 13, 400 gacha 87 — 500 yaqinroq')},function(){bqExpr(['487 + 312','≈ 500 + 300 = [800]']);bqMsg('Chama: taxminan 800. Aniq javob: 799')}];
var STEPS=[
{h:"O'rin almashtirish xossasi",sum:"a + b = b + a: qo'shiluvchilarning o'rni almashganda yig'indi o'zgarmaydi. Ayirishda bunday emas.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ikki bo'lak lentani qo'shib qo'yamiz. Tartibini almashtirsak, umumiy uzunlik o'zgaradimi?</p>",btns:[phaser(P1)],
 after:"<p><b>a + b = b + a</b>. Qo'shiluvchilar o'rnini almashtirsa ham yig'indi o'zgarmaydi. Lekin <b>ayirishda</b> o'rin almashtirib bo'lmaydi: 500 − 200 = 300, 200 dan 500 ni esa ayirib bo'lmaydi.</p>",
 q:{t:"Qaysi tenglik NOTO'G'RI?",opts:["700 − 300 = 300 − 700","456 + 0 = 0 + 456","128 + 372 = 372 + 128","90 + 510 = 510 + 90"],ok:0,why:"Ayirishda o'rin almashtirish xossasi yo'q.",hint:"Qaysi amalda o'rin almashtirish mumkin emas?",full:"700 − 300 = 400, 300 dan 700 ni esa ayirib bo'lmaydi. Qolgan uchtasi — qo'shish, ular to'g'ri."},
 tn:"Singapur usuli: ikki rangli qog'oz lenta. Bolalar o'zi lentalarni almashtirib, uzunlikni o'lchasin."},
{h:"Guruhlash xossasi",sum:"(a + b) + c = a + (b + c). O'rin almashtirish bilan birga: (278 + 22) + 300 = 600.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Uchta sonni qo'shishda qavsni xohlagan joyga qo'yish mumkin. Qaysi biri eng qulay?</p>",btns:[phaser(P2)],
 after:"<p><b>(a + b) + c = a + (b + c)</b>. Ikki xossa birga — qo'shiluvchilarni <b>istalgan tartibda</b> qo'shish mumkin. Shuning uchun avval «do'st juftlar»ni qo'shing.</p>",
 q:{t:"164 + 289 + 36 + 11 = ?",opts:["500","490","510","400"],ok:0,why:"(164 + 36) + (289 + 11) = 200 + 300 = 500.",hint:"Birliklari 4 va 6, 9 va 1 bo'lgan juftlarni toping.",full:"164 + 36 = 200, 289 + 11 = 300. Jami 500."},
 tn:"«Uchta son, bitta javob» o'yini: guruhlar uchta sonni turli tartibda qo'shib, javob bir xil chiqishini ko'rsin."},
{h:"Nol va teng sonlar",sum:"a + 0 = a, a − 0 = a, a − a = 0. Ayirmaga qo'shish: (a − b) + b = a.",a:"m03",start:function(){bqExpr(['345 + 0 = ?','345 − 0 = ?','345 − 345 = ?']);bqMsg('Har biriga javob bering')},fin:function(){bqExpr(['345 + 0 = [345]','345 − 0 = [345]','345 − 345 = [0]']);bqMsg('Nol bilan amallar')},
 html:"<p><b>345 − 345</b> nechaga teng?</p>",g3:1,
 btns:[["345",function(c,d,b){w3b6c(b,d,0,'','345 − 345: hamma narsani olib qo‘ydik — nima qoldi?')}],["0",function(c,d,b){bqExpr(['345 + 0 = [345]','345 − 0 = [345]','345 − 345 = [0]']);w3b6c(b,d,1,'To‘g‘ri: o‘zidan o‘zini ayirsak — 0','')}],["690",function(c,d,b){w3b6c(b,d,0,'','Bu qo‘shish emas, ayirish!')}]],
 after:"<p>Nol bilan: <b>a + 0 = a</b>, <b>a − 0 = a</b>, <b>a − a = 0</b>. Yana bir foydali xossa: <b>(a − b) + b = a</b> — ayirib, keyin qaytarib qo'shsak, boshlang'ich son qaytadi.</p>",
 q:{t:"(856 − 279) + 279 = ?",opts:["856","577","1135","279"],ok:0,why:"279 ni ayirib, yana qo'shdik — 856 qaytdi.",hint:"Ayirib, keyin xuddi shu sonni qo'shsak nima bo'ladi?",full:"(a − b) + b = a. Hisoblash shart emas: 856. «577» — faqat qavs ichi hisoblangan."},
 tn:"Bolalar hisoblamasdan javob topadigan misollarni o'zlari tuzsin: (500 − 123) + 123."},
{h:"Natijani chamalash",sum:"Sonlarni yaxlit yuzlikkacha yaxlitlab, javobni taxminan topamiz: 487 + 312 ≈ 500 + 300 = 800.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Chamalash — aniq hisoblashdan <b>oldin</b> javob taxminan qancha bo'lishini bilish. Son o'qida ko'ring:</p>",btns:[phaser(P4)],
 after:"<p>Yaxlitlash qoidasi: o'nliklar raqami <b>5 va undan katta</b> bo'lsa — yuqoriga (487 → 500), <b>5 dan kichik</b> bo'lsa — pastga (312 → 300). So'ng yaxlit sonlarni og'zaki qo'shamiz.</p>",
 q:{t:"628 + 245 natijasini chamalang (yuzliklargacha yaxlitlab).",opts:["900","800","700","1000"],ok:0,why:"628 ≈ 600, 245 ≈ 200: 800? Yo'q — tekshiring!",hint:"628 → 600, 245 → 200. Lekin aniq javob 873 — chama yaqinmi?",full:"628 ≈ 600, 245 ≈ 200, chama 800. Aniq javob 873."},
 tn:"Har yechimdan oldin «Chama qancha?» deb so'rash odat bo'lsin. Doskaga ikki ustun: «Chama» va «Aniq»."},
{h:"Chamalab xatoni topish",sum:"Javob chamadan juda uzoq bo'lsa — hisobda xato bor. 386 + 425 = 711? Chama: 400 + 400 = 800 — xato!",a:"m05",start:function(){bqExpr(['386 + 425 = 711','704 − 298 = 406','519 + 287 = 906']);bqMsg('Qaysi biri aniq xato? Chamalab toping')},fin:function(){bqExpr(['386 + 425 = 711 ≠ ~800','704 − 298 = 406 ✓','519 + 287 = 906 ≠ ~800']);bqMsg('Chama xatoni darhol ushlaydi')},
 html:"<p>Hisoblamasdan, faqat chamalab: qaysi misolda xato <b>yo'q</b>?</p>",g3:1,
 btns:[["386 + 425 = 711",function(c,d,b){w3b6c(b,d,0,'','Chama: 400 + 400 = 800. 711 juda kam — xato')}],["704 − 298 = 406",function(c,d,b){bqExpr(['386 + 425 = 711 ≠ ~800','704 − 298 = 406 ✓','519 + 287 = 906 ≠ ~800']);w3b6c(b,d,1,'700 − 300 = 400 — yaqin. Bu to‘g‘ri','')}],["519 + 287 = 906",function(c,d,b){w3b6c(b,d,0,'','Chama: 500 + 300 = 800. 906 juda ko‘p — xato')}]],
 after:"<p>Chama — <b>xavfsizlik kamari</b>. 386 + 425 aslida 811: o'nlikdan o'tkazilgan 1 yuzlikka qo'shilmagan. 519 + 287 = 806: ortiqcha yuzlik qo'shilgan. Chamasiz bunday xatolar sezilmay qoladi.</p>",
 q:{t:"Kalkulyatorda 492 + 307 ni bosganda ekranda 7992 chiqdi. Nima bo'lgan?",opts:["Bitta raqam ortiqcha bosilgan — javob ~800 bo'lishi kerak","Javob to'g'ri","Ayirish bosilgan","Javob ~8000 bo'lishi kerak"],ok:0,why:"500 + 300 = 800. 7992 o'n marta katta — tugma xato bosilgan.",hint:"Chamalang: 492 ≈ 500, 307 ≈ 300.",full:"Chama 800, aniq javob 799. 7992 — taxminan 10 marta katta: biror raqam ortiqcha bosilgan (masalan 4927 + …). Kalkulyatorga ham chamasiz ishonmang."},
 tn:"Doskaga 5 ta «o'quvchi yechimi» yozing (2 tasi xato). Sinf faqat chamalab xatolarni topsin — vaqt 1 daqiqa."},
{h:"Ayirishni chamalash",sum:"812 − 395 ≈ 800 − 400 = 400. Aniq javob 417.",a:"m06",start:function(){bqExpr(['812 − 395 ≈ ?']);bqMsg('Ikkalasini yuzliklargacha yaxlitlang')},fin:function(){bqExpr(['812 ≈ 800','395 ≈ 400','800 − 400 = [400]']);bqMsg('Aniq javob: 417 — chamaga yaqin')},
 html:"<p>812 − 395 ning chamasi qancha?</p>",g3:1,
 btns:[["400",function(c,d,b){bqExpr(['812 ≈ 800','395 ≈ 400','800 − 400 = [400]']);w3b6c(b,d,1,'To‘g‘ri! Aniq javob 417','')}],["500",function(c,d,b){w3b6c(b,d,0,'','395 qaysi yuzlikka yaqin: 300 mi, 400 mi?')}],["1200",function(c,d,b){w3b6c(b,d,0,'','Bu ayirish — javob 812 dan kichik bo‘ladi')}]],
 after:"<p>Ayirishda ham xuddi shunday: ikkalasini yaxlitlab, og'zaki ayiramiz. Chama aniq javobdan biroz farq qiladi — bu normal. <b>Muhimi — javob «o'sha atrofda» bo'lishi.</b></p>",
 q:{t:"Ruxsorada 905 so'm bor edi. U 488 so'mlik daftar oldi. Taxminan qancha qoldi?",opts:["400 so'mga yaqin","500 so'mga yaqin","1400 so'mga yaqin","100 so'mga yaqin"],ok:0,why:"900 − 500 = 400. Aniq: 417.",hint:"905 ≈ 900, 488 ≈ 500.",full:"900 − 500 = 400, aniq javob 905 − 488 = 417 — 400 ga yaqin. «500» — 488 pastga (400 ga) yaxlitlangan: 88 > 50, demak yuqoriga."},
 tn:"Bozor o'yini: narxlar yozilgan kartochkalar, «hamyonda 1000 so'm — taxminan nechta narsa olsa bo'ladi?»"},
{h:"Tuzoq: chegarani bilish",sum:"346 + 358: kamida 300 + 300 = 600, ko'pi bilan 400 + 400 = 800. Aniq 704 — 700 dan katta.",a:"m07",start:function(){bqExpr(['346 + 358 … 700']);bqMsg('Yig‘indi 700 dan katta, kichik yoki teng?')},fin:function(){bqExpr(['300 + 300 = 600','40 + 50 + 6 + 8 = 104','600 + 104 = [704] > 700']);bqMsg('Faqat yuzliklarga qarash yetmaydi!')},
 html:"<p>Yuzliklar: 300 + 300 = 600 — «700 dan kichik» deyishga shoshilmang! <b>346 + 358</b> va <b>700</b> ni taqqoslang:</p>",g3:1,
 btns:[["kichik",function(c,d,b){w3b6c(b,d,0,'','O‘nliklar va birliklar ham bor: 46 + 58 = ?')}],["teng",function(c,d,b){w3b6c(b,d,0,'','46 + 58 ni hisoblang — 100 bo‘ladimi?')}],["katta",function(c,d,b){bqExpr(['300 + 300 = 600','40 + 50 + 6 + 8 = 104','600 + 104 = [704] > 700']);w3b6c(b,d,1,'46 + 58 = 104 — yana bir yuzlik! 704 > 700','')}]],
 after:"<p>Chama <b>qo'pol</b> bo'lsa, chegaraga yaqin savollarda adashtiradi. Unda «qolgan qismlar»ni ham qarang: 46 + 58 = 104 &gt; 100, demak yig'indi 700 dan oshadi. Bu olimpiada savollarining sevimli tuzog'i.</p>",
 q:{t:"Qaysi yig'indi 1000 dan katta?",opts:["548 + 463","498 + 497","387 + 612","455 + 545"],ok:0,why:"48 + 63 = 111 > 100: 548 + 463 = 1011.",hint:"Yuzliklar har birida 900. Qolgan qismlarni (o'nlik + birlik) qo'shib, 100 bilan taqqoslang.",full:"548 + 463 = 1011 > 1000. 498 + 497 = 995, 387 + 612 = 999, 455 + 545 = 1000 (teng, katta emas)."},
 tn:"Bolalarga «pastki va yuqori chegara»ni ko'rsating: 346 + 358 kamida 600, ko'pi bilan 800. Chegarada esa aniq hisob kerak."},
{h:"Yig'indi va ayirma qanday o'zgaradi?",sum:"Qo'shiluvchi +70, ikkinchisi −30 → yig'indi +40. Kamayuvchi oshsa ayirma oshadi, ayriluvchi oshsa ayirma kamayadi.",a:"m08",start:function(){bqBar(500,[{v:'?',w:3,col:C.a,lab:'1-qo‘shiluvchi'},{v:'?',w:2,col:C.b,lab:'2-qo‘shiluvchi'}],{title:'Yig‘indi 500'});bqMsg('Birinchisi 70 ga oshdi, ikkinchisi 30 ga kamaydi')},fin:function(){bqExpr(['500 + 70 − 30','= [540]']);bqMsg('Sonlarni bilmasak ham, o‘zgarishni bilamiz')},
 html:"<p>Ikki son yig'indisi <b>500</b>. Birinchi qo'shiluvchi <b>70 ga oshirildi</b>, ikkinchisi <b>30 ga kamaytirildi</b>. Yangi yig'indi?</p>",g3:1,
 btns:[["540",function(c,d,b){bqExpr(['500 + 70 − 30','= [540]']);w3b6c(b,d,1,'+70 va −30: jami +40. 500 + 40 = 540','')}],["600",function(c,d,b){w3b6c(b,d,0,'','Ikkinchisi kamaydi — 30 ni ham qo‘shib bo‘lmaydi')}],["400",function(c,d,b){w3b6c(b,d,0,'','Birinchisi oshdi — 70 ni ayirmang')}]],
 after:"<p>Yig'indi qo'shiluvchilar bilan <b>birga</b> o'zgaradi: +70 − 30 = +40. Ayirmada esa: <b>kamayuvchi</b> n ga oshsa — ayirma ham n ga <b>oshadi</b>; <b>ayriluvchi</b> n ga oshsa — ayirma n ga <b>kamayadi</b>; ikkalasi bir xil oshsa — ayirma <b>o'zgarmaydi</b>.</p>",
 q:{t:"Ayirma 250 ga teng. Kamayuvchi 40 ga, ayriluvchi 15 ga oshirildi. Yangi ayirma?",opts:["275","305","225","290"],ok:0,why:"Kamayuvchi +40 → ayirma +40; ayriluvchi +15 → ayirma −15. 250 + 25 = 275.",hint:"Ayriluvchi oshsa, ayirma kamayadi.",full:"250 + 40 − 15 = 275. «305» — ikkala o'zgarish qo'shilgan; «225» — ikkalasi teskari olingan; «290» — faqat kamayuvchi hisobga olingan."},
 tn:"Lenta modelida ko'rsating: bo'lakni uzaytirsak — butun uzayadi; ayirmada «ortiqcha qism» qanday o'zgarishini chizing."},
{h:"Bilasizmi? Fermi savollari",sum:"Fizik Enriko Fermi talabalariga «Chikagoda nechta pianino sozlovchi bor?» kabi chamalash savollarini bergan.",a:"m09",start:function(){bqExpr(['Sinfingizdagi hamma','o‘quvchining yoshi','yig‘indisi ≈ ?']);bqMsg('Chamalash — olimlar quroli')},fin:function(){bqExpr(['30 o‘quvchi × 9 yosh','≈ [270]']);bqMsg('Aniq bilmasak ham, taxminiy javob topiladi')},
 html:"<p>🎓 Nobel mukofoti sovrindori, fizik <b>Enriko Fermi</b> talabalariga «Chikago shahrida nechta pianino sozlovchi bor?» kabi savollar bergan. Aniq ma'lumot yo'q — lekin aqlli chamalash bilan javobni taxminan topish mumkin. Bunday savollar hozir ham <b>«Fermi savollari»</b> deb ataladi.</p>",
 btns:[["💡 Sinf yoshlarining yig'indisi?",function(c,done){bqExpr(['30 o‘quvchi × 9 yosh','≈ [270]']);bqMsg('Taxminan 30 o‘quvchi, har biri 9 yoshga yaqin');done()}]],
 after:"<p>Fermi aytgan: «Avval taxminan bil, keyin aniq hisobla». Muhandislar ko'prik qurishdan oldin, oshpazlar to'yga osh damlashdan oldin ham chamalaydi.</p>",
 tn:"Haftada bir «Fermi savoli»: maktabda nechta deraza bor? Bir yilda necha marta nonushta qilamiz?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)','487 + 312 ≈ 500 + 300']);bqMsg('Xossalar va chama')},fin:function(){bqExpr(['a + b = b + a','(a + b) + c = a + (b + c)','487 + 312 ≈ 500 + 300']);bqMsg('Xossalar va chama')},
 html:"<div class='memo'><ul><li><b>a + b = b + a</b> — o'rin almashtirish (faqat qo'shishda!).</li><li><b>(a + b) + c = a + (b + c)</b> — guruhlash.</li><li>a + 0 = a, a − 0 = a, a − a = 0, (a − b) + b = a.</li><li>Yig'indi: +70 va −30 → +40. Ayriluvchi oshsa — ayirma kamayadi.</li><li><b>Chama</b>: yuzliklargacha yaxlitlang (o'nlik ≥ 5 — yuqoriga).</li><li>Javob chamadan juda uzoq — hisobni qayta tekshiring.</li><li>Chegaraga yaqin savolda chama yetmaydi — qolgan qismni ham qo'shing.</li></ul></div>",
 tn:"Har uy vazifasi yonida «chama» katakchasi bo'lsin."}
];
STEPS[3].q={t:"628 + 245 natijasini chamalang (yuzliklargacha yaxlitlab).",opts:["800","900","700","1000"],ok:0,why:"628 ≈ 600, 245 ≈ 200: 600 + 200 = 800. Aniq javob 873.",hint:"628 → 600 (o'nliklar 2 < 5), 245 → 200 (o'nliklar 4 < 5).",full:"628 ≈ 600, 245 ≈ 200, chama 800. Aniq javob 873. «900» — 245 yuqoriga (300 ga) yaxlitlangan, lekin o'nliklar raqami 4 — pastga yaxlitlanadi."};
var PROBS=[
{t:"Ikki son yig'indisi 640. Birinchisi 85 ga oshirildi, ikkinchisi 45 ga kamaytirildi. Yangi yig'indi?",o:["680","770","600","510"],k:0,s:"640 + 85 − 45 = 680."},
{t:"Qaysi tenglik to'g'ri?",o:["387 + 245 = 245 + 387","387 − 245 = 245 − 387","387 + 245 = 387 − 245","387 + 0 = 0"],k:0,s:"Qo'shishda o'rin almashtirish mumkin."},
{t:"(536 − 128) + 128 = ?",o:["536","408","664","128"],k:0,s:"(a − b) + b = a."},
{t:"Ayirma 320. Ayriluvchi 60 ga oshirilsa, ayirma nechaga teng bo'ladi?",o:["260","380","320","60"],k:0,s:"Ayriluvchi oshsa, ayirma shuncha kamayadi: 320 − 60 = 260."},
{t:"183 + 256 + 17 = ?",o:["456","446","466","356"],k:0,s:"(183 + 17) + 256 = 200 + 256 = 456."},
{t:"413 + 389 ning chamasi (yuzliklargacha)?",o:["800","700","900","750"],k:0,s:"400 + 400 = 800."},
{t:"879 − 312 ning chamasi (yuzliklargacha)?",o:["600","500","700","1200"],k:0,s:"900 − 300 = 600."},
{t:"561 + 237 ning chamasi (yuzliklargacha)?",o:["800","700","900","1000"],k:0,s:"600 + 200 = 800."},
{t:"Qaysi javob chamaga ko'ra aniq xato?",o:["398 + 405 = 703","398 + 405 = 803","502 − 199 = 303","301 + 299 = 600"],k:0,s:"400 + 400 = 800 — 703 juda kam."},
{t:"Qaysi ifoda 250 + (450 + 128) ga teng?",o:["(250 + 450) + 128","(250 − 450) + 128","250 + 450 − 128","250 · 450 + 128"],k:0,s:"Guruhlash: (250 + 450) + 128 = 828."},
{t:"Qaysi yig'indi 900 dan katta?",o:["456 + 467","412 + 437","399 + 499","350 + 549"],k:0,s:"456 + 467 = 923. Qolganlari: 849, 898, 899."},
{t:"Qaysi ayirma 300 dan kichik?",o:["612 − 315","700 − 399","800 − 498","650 − 349"],k:0,s:"612 − 315 = 297. Qolganlari: 301, 302, 301."},
{t:"Do'kondan 296 so'm va 412 so'mlik narsa olindi. 700 so'm yetadimi?",o:["Yo'q, 708 so'm kerak","Ha, 8 so'm ortadi","Ha, aynan yetadi","Yo'q, 800 so'm kerak"],k:0,s:"296 + 412 = 708 > 700. Chama 300 + 400 = 700 adashtiradi."},
{t:"Ali 573 + 249 ni hisobladi: 722. Chama nima deydi?",o:["Xato: ~800 bo'lishi kerak","To'g'ri","Xato: ~900 bo'lishi kerak","Xato: ~600 bo'lishi kerak"],k:0,s:"600 + 200 = 800, aniq javob 822: o'tkazilgan yuzlik qo'shilmagan."},
{t:"a + 357 = 357 + 618. a = ?",o:["618","357","975","261"],k:0,s:"O'rin almashtirish: a = 618."},
{t:"125 + 348 + 275 + 52 = ?",o:["800","700","900","790"],k:0,s:"(125 + 275) + (348 + 52) = 400 + 400 = 800."},
{t:"Qaysi yig'indi 1000 ga eng yaqin?",o:["489 + 509","512 + 509","398 + 589","602 + 412"],k:0,s:"489 + 509 = 998 (farq 2). Qolganlari: 1021, 987, 1014."},
{t:"Bir sonni 300 ga yaxlitlagan. Bu son qaysi bo'lishi MUMKIN EMAS?",o:["352","251","299","349"],k:0,s:"352 → 400 (o'nliklar 5). 251, 299, 349 → 300."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["498 + 307","807 − 3","795 + 0","812 − 10"],k:0,s:"805, 804, 795, 802 — eng kattasi 498 + 307 = 805."},
{t:"Chama 700 chiqdi (ikkala son yuzliklargacha yaxlitlangan). Qaysi misol bo'lishi mumkin?",o:["348 + 351","348 + 362","452 + 351","265 + 349"],k:0,s:"300 + 400 = 700 ✓. 348 + 362 → 300 + 400 = 700 ham! Tekshiring."}
];
PROBS[19]={t:"Ikkala son yuzliklargacha yaxlitlanganda chama 700 chiqdi. Qaysi misol bo'lishi mumkin?",o:["348 + 381","452 + 351","265 + 249","551 + 349"],k:0,s:"348 → 300, 381 → 400: 700 ✓. 452 + 351 → 500 + 400 = 900; 265 + 249 → 300 + 200 = 500; 551 + 349 → 600 + 300 = 900."};
function PRACT_STAGE(){bqExpr(['Avval chamala,','keyin hisobla']);bqMsg('Xossalar hisobni osonlashtiradi')}
var PREP_DATA={teach:["O'rin almashtirish va guruhlash xossalari (faqat qo'shishda).","Nol bilan amallar; (a − b) + b = a.","Yuzliklargacha yaxlitlab chamalash (qo'shish va ayirish).","Chama orqali xatoni topish; chegaraga yaqin taqqoslash."],
 mist:["Ayirishda ham o'rin almashtiradi.","Yaxlitlashda 5 dan katta/kichikni adashtiradi (245 → 300).","Faqat yuzliklarga qarab taqqoslaydi (346 + 358 < 700).","Chamani aniq javob deb yozadi."],
 need:["Rangli qog'oz lentalar.","Son o'qi 0–1000.","«Chama / Aniq» jadvali doskada."],
 board:["<span class='w2'>a + b = b + a</span>","<span class='w2'>(a + b) + c = a + (b + c)</span>","<span class='w2'>487 + 312 ≈ 500 + 300 = 800</span>","<span class='w2'>346 + 358 = 704 > 700</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
