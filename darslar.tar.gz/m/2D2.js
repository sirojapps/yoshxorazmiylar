var CODE='2D2',TITLE='2-sinf · «…ta ko‘p / …ta kam» masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else if(f.note)calc([f.note])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
var TQ='Ozodada 34 ta qalam. Malikada 9 ta KAM.';
var STEPS=[
bmStep({h:"Ikki chiziq — taqqoslash chizmasi",sum:"Taqqoslashda ikki chiziq bir-birining ostiga chiziladi, farq — ortiqcha bo'lak.",a:"m01",
 frames:[{t:'Ozodada 34 ta, Malikada 25 ta qalam',bars:[{lab:'Ozoda',y:46,segs:[{w:34,txt:'34',c:'a'}]},{lab:'Malika',y:106,segs:[{w:25,txt:'25',c:'b'}]}],note:'Ikki chiziqni bir xil joydan boshlab chizamiz'},
  {t:'Ozodada 34 ta, Malikada 25 ta qalam',bars:[{lab:'Ozoda',y:46,segs:[{w:25,txt:'25',c:'a'},{w:9,txt:'9',c:'c'}]},{lab:'Malika',y:106,segs:[{w:25,txt:'25',c:'b'}]}],calc:['Chiziqlar teng joygacha bir xil, Ozodaniki <b>9 ta uzun</b>','Bu bo‘lak — <b>farq</b>: 34 − 25 = 9']}],
 html:"<p>«Ko'p» va «kam» masalalarida ikki narsa <b>taqqoslanadi</b>. Ularni ikki chiziq qilib, bir-birining ostiga chizamiz. Kuzating.</p>",
 after:"<p>Uzun chiziqning ortiqcha bo'lagi — <b>farq</b>. Ozodada Malikadan <b>9 ta ko'p</b>, Malikada Ozodadan <b>9 ta kam</b> — bu bitta gapning ikki xil aytilishi!</p>",
 q:{t:"Alida 52 ta, Valida 40 ta yong'oq bor. Alida Validan nechta ko'p?",opts:["92","12","40","2"],ok:1,why:"Farq: 52 − 40 = 12.",hint:"«Nechta ko'p?» — bu farq. Farqni qaysi amal bilan topamiz?",full:"«Nechta ko'p?» — ortiqcha bo'lak, ya'ni farq: 52 − 40 = 12. «92» — qo'shib yuborilgan, lekin jami so'ralmagan."},
 tn:"Singapur «taqqoslash modeli»: ikki chiziq chap tomondan bir tekisda boshlanadi. Bolalar farqni rangli qalam bilan bo'yasin."}),
bmStep({h:"«…ta kam» — ayiramiz",sum:"Malikada 9 ta kam: 34 − 9 = 25.",a:"m02",
 frames:[{t:TQ+' Malikada nechta?',bars:[{lab:'Ozoda',y:46,segs:[{w:34,txt:'34',c:'a'}]},{lab:'Malika',y:106,segs:[{w:25,txt:'?',c:'q'}]}],txt:[[312,123,'9 ta kam',{fill:C.bad,'font-size':11}]],note:'Malikaning chizig‘i 9 ta qisqa'},
  {t:TQ+' Malikada nechta?',bars:[{lab:'Ozoda',y:46,segs:[{w:25,txt:'25',c:'a'},{w:9,txt:'9',c:'c'}]},{lab:'Malika',y:106,segs:[{w:25,txt:'25',c:'b'}]}],calc:['Malika — kam: 34 − 9 = <b>25</b> ta qalam']}],
 html:"<p>«Malikada Ozodadan 9 ta kam» — Malikaning chizig'i qisqa bo'ladi. Kuzating.</p>",
 after:"<p>«… ta kam» — noma'lum son <b>kichik</b>, shuning uchun <b>ayiramiz</b>: 34 − 9 = 25.</p>",
 q:{t:"Do'konda 60 ta olma, nok esa 15 ta kam. Nechta nok bor?",opts:["75","45","15","55"],ok:1,why:"Nok kam: 60 − 15 = 45.",hint:"Nok olmadan ko'pmi yoki kam? Chiziq uzun bo'ladimi yoki qisqa?",full:"Nok 15 ta kam — chizig'i qisqa: 60 − 15 = 45. Tekshiramiz: 45 + 15 = 60 ✓."},
 tn:"Bolalardan har doim so'rang: «Topiladigan son kattami yoki kichikmi?» Javobdan amal o'zi kelib chiqadi."}),
bmStep({h:"«…ta ko'p» — qo'shamiz",sum:"Sevarada Malikadan 15 ta ko'p: 25 + 15 = 40.",a:"m03",
 frames:[{t:'Malikada 25 ta qalam. Sevarada 15 ta KO‘P. Sevarada nechta?',bars:[{lab:'Malika',y:46,segs:[{w:25,txt:'25',c:'b'}]},{lab:'Sevara',y:106,segs:[{w:25,txt:'25',c:'g'},{w:15,txt:'+15',c:'c'}]}],br:[{b:1,lab:'?',up:false}],note:'Sevaraning chizig‘i 15 ta uzun'},
  {t:'Malikada 25 ta qalam. Sevarada 15 ta KO‘P. Sevarada nechta?',bars:[{lab:'Malika',y:46,segs:[{w:25,txt:'25',c:'b'}]},{lab:'Sevara',y:106,segs:[{w:25,txt:'25',c:'g'},{w:15,txt:'15',c:'c'}]}],br:[{b:1,lab:'40',up:false,col:C.ok}],calc:['Sevara — ko‘p: 25 + 15 = <b>40</b> ta qalam']}],
 html:"<p>«Sevarada Malikadan 15 ta ko'p» — Sevaraning chizig'i uzun: Malikaniki va yana 15 ta. Kuzating.</p>",
 after:"<p>«… ta ko'p» — noma'lum son <b>katta</b>, shuning uchun <b>qo'shamiz</b>.</p>",
 q:{t:"Ukamda 18 ta mashina bor, menda undan 7 ta ko'p. Menda nechta mashina bor?",opts:["11","25","7","18"],ok:1,why:"Menda ko'p: 18 + 7 = 25.",hint:"Kimda ko'p? Ko'p bo'lganini topish uchun nima qilamiz?",full:"Menda 7 ta ko'p — chizig'im uzun: 18 + 7 = 25. «11» — ayirib yuborilgan, lekin unda menda kam bo'lib qoladi."},
 tn:"Chizmada «+15» bo'lagini boshqa rang bilan bo'yating — ortiqcha qism ko'zga tashlansin."}),
bmStep({h:"Tuzoq: «bu … dan … ta ko'p»",sum:"«Alida 16, bu Validan 5 ta ko'p» → Ali ko'p, Vali kam: 16 − 5 = 11.",a:"m04",
 frames:[{t:'Alida 16 ta baliq. BU Valining baliqlaridan 5 ta KO‘P.',bars:[{lab:'Ali',y:46,segs:[{w:16,txt:'16',c:'a'}]},{lab:'Vali',y:106,segs:[{w:11,txt:'?',c:'q'}]}],note:'Kimning chizig‘i uzun? Amalni tanlang'}],
 html:"<p>Eng ayyor tur: «ko'p» so'zi bor, lekin <b>noma'lum son kichik</b>! Chizmaga qarab amalni tanlang:</p>",
 btns:bmPick(["16 + 5","16 − 5"],1,{t:'Alida 16 ta baliq. BU Valining baliqlaridan 5 ta KO‘P.',bars:[{lab:'Ali',y:46,segs:[{w:11,txt:'11',c:'a'},{w:5,txt:'5',c:'c'}]},{lab:'Vali',y:106,segs:[{w:11,txt:'11',c:'b'}]}],calc:['«Bu (Alining 16 tasi) Validan 5 ta ko‘p» → Vali kam','16 − 5 = <b>11</b>']},["Unda Valida 21 ta bo‘ladi — Validan ko‘p bo‘lib qoladi. Lekin gapda Ali ko‘p deyilgan!"]),
 after:"<p>Usul: avval «<b>kim ko'p?</b>» degan savolga javob bering. «Alida 16, bu Validan 5 ta ko'p» — Ali ko'p. Demak Vali kam, ayiramiz.</p>",
 q:{t:"Bekatdan bog'gacha 37 km. Bu bekatdan ko'lgacha bo'lgan yo'ldan 9 km uzun. Bekatdan ko'lgacha necha km?",opts:["46 km","28 km","9 km","38 km"],ok:1,why:"Bog'gacha uzun, ko'lgacha qisqa: 37 − 9 = 28.",hint:"Qaysi yo'l uzun: bog'gachami yoki ko'lgacha?",full:"«Bu (37 km) ko'lgacha bo'lgan yo'ldan 9 km uzun» — bog'gacha uzun, ko'lgacha qisqa. 37 − 9 = 28 km. «46» — «uzun» so'zini ko'rib qo'shish xatosi."},
 tn:"Bunday gaplarni bolalar o'z so'zi bilan qayta aytsin: «Demak Vali Alidan 5 ta kam». Shunda xato yo'qoladi."}),
bmStep({h:"Zanjir: uchta odam",sum:"Ozoda 34 → Malika 9 ta kam (25) → Sevara Malikadan 15 ta ko'p (40).",a:"m05",
 frames:[{t:'Ozoda 34. Malika 9 ta kam. Sevara MALIKADAN 15 ta ko‘p.',bars:[{lab:'Ozoda',y:34,segs:[{w:34,txt:'34',c:'a'}]},{lab:'Malika',y:82,segs:[{w:25,txt:'?',c:'q'}]},{lab:'Sevara',y:130,segs:[{w:40,txt:'?',c:'q'}]}],note:'Avval kimni topamiz?'},
  {t:'Ozoda 34. Malika 9 ta kam. Sevara MALIKADAN 15 ta ko‘p.',bars:[{lab:'Ozoda',y:34,segs:[{w:34,txt:'34',c:'a'}]},{lab:'Malika',y:82,segs:[{w:25,txt:'25',c:'b'}]},{lab:'Sevara',y:130,segs:[{w:40,txt:'?',c:'q'}]}],calc:['1) Malika: 34 − 9 = <b>25</b>']},
  {t:'Ozoda 34. Malika 9 ta kam. Sevara MALIKADAN 15 ta ko‘p.',bars:[{lab:'Ozoda',y:34,segs:[{w:34,txt:'34',c:'a'}]},{lab:'Malika',y:82,segs:[{w:25,txt:'25',c:'b'}]},{lab:'Sevara',y:130,segs:[{w:25,txt:'25',c:'g'},{w:15,txt:'15',c:'c'}]}],calc:['1) Malika: 34 − 9 = 25','2) Sevara: 25 + 15 = <b>40</b>']}],
 html:"<p>Masala: <i>«Ozodada 34 ta qalam. Malikada Ozodadan 9 ta kam, Sevarada esa <b>Malikadan</b> 15 ta ko'p. Sevarada nechta qalam bor?»</i> Sevara kim bilan taqqoslanyapti?</p>",
 after:"<p>Diqqat: Sevara <b>Malika</b> bilan taqqoslangan, Ozoda bilan emas! Shuning uchun avval Malikani topamiz. Xato yo'l: 34 + 15 = 49.</p>",
 q:{t:"Alining yo'li 48 m. Valining yo'li undan 15 m qisqa. Sardorning yo'li Valinikidan 20 m uzun. Kimning yo'li eng uzun?",opts:["Ali","Vali","Sardor","Ali va Sardor teng"],ok:2,why:"Vali 33 m, Sardor 53 m — Sardorniki eng uzun.",hint:"Avval Valinikini, keyin Sardornikini toping va solishtiring.",full:"Vali: 48 − 15 = 33 m. Sardor: 33 + 20 = 53 m. Ali 48 m. Eng uzuni — Sardor (53 m)."},
 tn:"Zanjirli masalalarda chizmani yuqoridan pastga chizdiring: har bir odam o'zidan oldingisi bilan taqqoslansin."}),
bmStep({h:"Tuzoq: savol jamini so'rasa",sum:"1-uyda 400, 2-uyda 200 ta kam (200). Jami: 400 + 200 = 600.",a:"m06",
 frames:[{t:'1-uyda 400 xonadon, 2-uyda 200 ta KAM. Ikkalasida JAMI nechta?',bars:[{lab:'1-uy',y:44,segs:[{w:400,txt:'400',c:'a'}]},{lab:'2-uy',y:100,segs:[{w:200,txt:'?',c:'q'}]}],note:'1-qadam: 2-uyni topamiz'},
  {t:'1-uyda 400 xonadon, 2-uyda 200 ta KAM. Ikkalasida JAMI nechta?',bars:[{lab:'1-uy',y:44,segs:[{w:400,txt:'400',c:'a'}]},{lab:'2-uy',y:100,segs:[{w:200,txt:'200',c:'b'}]}],calc:['1) 2-uy: 400 − 200 = 200 — bu hali javob emas!']},
  {t:'1-uyda 400 xonadon, 2-uyda 200 ta KAM. Ikkalasida JAMI nechta?',bars:[{lab:'jami',y:70,segs:[{w:400,txt:'400',c:'a'},{w:200,txt:'200',c:'b'}]}],br:[{b:0,lab:'600',up:false,col:C.ok}],calc:['1) 2-uy: 400 − 200 = 200','2) Jami: 400 + 200 = <b>600</b>']}],
 html:"<p>Ko'p bola 2-uydagini topib, to'xtab qoladi. Lekin savol — <b>jami</b>! Kuzating.</p>",
 after:"<p>Masalani yechib bo'lgach, savolni <b>qayta o'qing</b>: topgan soningiz savolga javob beryaptimi? Bu masalada 200 — faqat yarim yo'l.</p>",
 q:{t:"Birinchi qutida 25 ta sharbat, ikkinchisida undan 6 ta ko'p. Ikkala qutida jami nechta sharbat?",opts:["31","56","6","50"],ok:1,why:"2-quti 31, jami 25 + 31 = 56.",hint:"Avval ikkinchi qutini toping. Savol nimani so'rayapti?",full:"2-quti: 25 + 6 = 31. Jami: 25 + 31 = 56. «31» — faqat ikkinchi quti, savol esa jamini so'rayapti."},
 tn:"Bolalarga «javob gapi»ni yozishni o'rgating: «Ikkala uyda jami 600 ta xonadon bor». Shunda savolga javob berilganini tekshiradi."}),
bmStep({h:"Ko'tarilish va tushish",sum:"12° → 9° issiq (21°) → 6° sovuq (15°). Har o'zgarish — bitta amal.",a:"m07",
 frames:[{t:'Ertalab 12°. Tushda 9° issiqroq. Kechqurun tushdagidan 6° sovuq.',bars:[{lab:'ertalab',y:34,segs:[{w:12,txt:'12°',c:'b'}]},{lab:'tush',y:82,segs:[{w:12,txt:'12°',c:'b'},{w:9,txt:'+9',c:'c'}]},{lab:'kechqurun',y:130,segs:[{w:15,txt:'?',c:'q'}]}],calc:['Tushda: 12 + 9 = <b>21°</b>']},
  {t:'Ertalab 12°. Tushda 9° issiqroq. Kechqurun tushdagidan 6° sovuq.',bars:[{lab:'ertalab',y:34,segs:[{w:12,txt:'12°',c:'b'}]},{lab:'tush',y:82,segs:[{w:15,txt:'15°',c:'g'},{w:6,txt:'−6',c:'x'}]},{lab:'kechqurun',y:130,segs:[{w:15,txt:'15°',c:'g'}]}],calc:['Tushda: 12 + 9 = 21°','Kechqurun: 21 − 6 = <b>15°</b>']}],
 html:"<p>Hayotdagi masala: havo harorati kun davomida o'zgaradi. «Issiqroq» — ko'p, «sovuqroq» — kam. Kuzating.</p>",
 after:"<p>Ketma-ket o'zgarishlarda har birini <b>alohida</b> bajaramiz. Tez usul ham bor: 9° ko'tarilib, 6° tushdi — jami 3° ko'tarildi: 12 + 3 = 15°.</p>",
 q:{t:"Liftda 9 kishi bor edi. 1-qavatda 4 kishi chiqdi, 2-qavatda 6 kishi tushdi. Liftda nechta kishi qoldi?",opts:["19","7","11","1"],ok:1,why:"9 + 4 = 13, 13 − 6 = 7.",hint:"«Chiqdi» liftga kirdi — ko'paydi. «Tushdi» — kamaydi.",full:"Liftga 4 kishi chiqdi: 9 + 4 = 13. 6 kishi tushdi: 13 − 6 = 7. «19» — ikkalasini ham qo'shib yuborish xatosi."},
 tn:"Termometr chizib, ko'tarilish va tushishni strelkalar bilan ko'rsating."}),
bmStep({h:"Bilasizmi? 4000 yillik masalalar",sum:"Qadimgi Bobil loy taxtachalarida taqqoslash masalalari bor.",a:"m08",
 frames:[{t:'Bobil loy taxtachasi',bg:'#f6ead0',bars:[{y:50,h:70,segs:[{w:1,txt:'▼ ◀◀ ▼▼▼',c:'#d9b98a',fs:24}]}],note:'Bobilliklar sonlarni mixsimon belgilar bilan yozgan'}],
 html:"<p>🏺 Taxminan <b>4000 yil oldin</b> Bobil (hozirgi Iroq) maktablarida bolalar loy taxtachalarga masalalar yozib yechgan. Ularda ham «biri ikkinchisidan shuncha ko'p» degan masalalar bor edi!</p><p>Demak siz yechayotgan masalalar — insoniyatning eng qadimiy bilimlaridan biri.</p>",
 tn:"Bolalarga qadimgi maktab haqida gapirib bering — tarixiy kontekst qiziqishni oshiradi."}),
bmStep({h:"Eslatma kartochka",sum:"",a:"m09",memo:1,frames:[{t:'Taqqoslash chizmasi',bars:[{lab:'katta',y:46,segs:[{w:25,txt:'kichik',c:'a'},{w:9,txt:'farq',c:'c'}]},{lab:'kichik',y:106,segs:[{w:25,txt:'kichik',c:'b'}]}]}],
 html:"<div class='memo'><ul><li>Taqqoslashda <b>ikki chiziq</b> bir-birining ostiga chiziladi.</li><li>«… ta <b>ko'p</b>» — noma'lum katta → <b>qo'shamiz</b>.</li><li>«… ta <b>kam</b>» — noma'lum kichik → <b>ayiramiz</b>.</li><li>«<b>Nechta ko'p / kam?</b>» — farq → kattadan kichikni ayiramiz.</li><li>«Bu … dan 5 ta ko'p» — avval <b>kim ko'p</b> ekanini aniqlang!</li><li>Zanjirda: kim <b>kim bilan</b> taqqoslanganiga qarang.</li><li>Oxirida <b>savolni qayta o'qing</b>: jami so'ralganmi?</li></ul></div>",
 tn:"Keyingi darsni «Menda 30 ta, bu sendan 8 ta ko'p. Senda nechta?» savoli bilan boshlang."})
];
var PROBS=[
{t:"Ozodada 34 ta rangli qalam bor. Malikada Ozodadan 9 ta kam. Malikada nechta qalam bor?",o:["25","43","9","35"],k:0,s:"Malika kam: 34 − 9 = 25."},
{t:"Ukamda 18 ta mashina bor, menda undan 7 ta ko'p. Menda nechta mashina bor?",o:["25","11","7","26"],k:0,s:"Menda ko'p: 18 + 7 = 25."},
{t:"Alida 52 ta, Valida 40 ta yong'oq bor. Alida Validan nechta ko'p yong'oq bor?",o:["12","92","40","22"],k:0,s:"Farq: 52 − 40 = 12."},
{t:"Alida 16 ta baliq. Bu Valining baliqlaridan 5 ta ko'p. Valida nechta baliq bor?",o:["11","21","5","16"],k:0,s:"Ali ko'p, Vali kam: 16 − 5 = 11."},
{t:"Lolada 45 ochko. Bu Alinikidan 12 ta kam. Alida nechta ochko?",o:["57","33","12","47"],k:0,s:"Lola kam, Ali ko'p: 45 + 12 = 57."},
{t:"Ozodada 34 ta qalam. Malikada 9 ta kam, Sevarada esa Malikadan 15 ta ko'p. Sevarada nechta qalam?",o:["40","49","28","58"],k:0,s:"Malika 34 − 9 = 25, Sevara 25 + 15 = 40."},
{t:"Birinchi uyda 400 xonadon, ikkinchisida 200 ta kam. Ikkala uyda jami nechta xonadon?",o:["600","200","800","1000"],k:0,s:"2-uy 200, jami 400 + 200 = 600."},
{t:"Ertalab 12°, tushda 9° issiqroq, kechqurun tushdagidan 6° sovuqroq bo'ldi. Kechqurun necha daraja?",o:["15","27","21","3"],k:0,s:"12 + 9 = 21, 21 − 6 = 15."},
{t:"Bekatdan bog'gacha 37 km. Bu ko'lgacha bo'lgan yo'ldan 9 km uzun. Bekatdan ko'lgacha necha km?",o:["28","46","9","38"],k:0,s:"Bog'gacha uzun: 37 − 9 = 28."},
{t:"Sinfda 14 ta qiz, o'g'il bolalar esa 3 ta ko'p. Sinfda jami nechta o'quvchi?",o:["31","17","11","28"],k:0,s:"O'g'illar 17, jami 14 + 17 = 31."},
{t:"Birinchi qutida 25 ta sharbat, ikkinchisida 6 ta ko'p. Ikkala qutida jami nechta?",o:["56","31","50","6"],k:0,s:"2-quti 31, jami 25 + 31 = 56."},
{t:"Archa 120 sm, qayin undan 35 sm baland. Qayin necha santimetr?",o:["155","85","35","145"],k:0,s:"Qayin baland: 120 + 35 = 155."},
{t:"Otam 38 yoshda, onam undan 4 yosh kichik. Onam necha yoshda?",o:["34","42","4","36"],k:0,s:"Onam kichik: 38 − 4 = 34."},
{t:"Do'konda 60 ta olma, nok esa 15 ta kam. Olma va nok jami nechta?",o:["105","45","75","15"],k:0,s:"Nok 45, jami 60 + 45 = 105."},
{t:"Liftda 9 kishi bor edi. 4 kishi chiqdi, keyin 6 kishi tushdi. Liftda nechta kishi qoldi?",o:["7","19","11","1"],k:0,s:"9 + 4 = 13, 13 − 6 = 7."},
{t:"Nodirda 26 ta marka, bu Akmalnikidan 8 ta kam. Akmalda Nodirdan nechta ko'p marka bor?",o:["8","34","18","26"],k:0,s:"Farq aytilgan: Akmalda 8 ta ko'p (Akmalda 34 ta)."},
{t:"Alining yo'li 48 m. Valiniki 15 m qisqa, Sardorniki Valinikidan 20 m uzun. Kimning yo'li eng uzun?",o:["Sardor","Ali","Vali","Ali va Sardor teng"],k:0,s:"Vali 33 m, Sardor 53 m, Ali 48 m — Sardor."},
{t:"Bir savatda 30 ta tuxum. Ikkinchisida 12 ta kam, uchinchisida ikkinchisidan 5 ta ko'p. Uchinchi savatda nechta?",o:["23","35","18","47"],k:0,s:"2-savat 30 − 12 = 18, 3-savat 18 + 5 = 23."},
{t:"Laylo va ukasi 84 ta ertak o'qishdi. 37 tasi o'zbek ertaklari. Jahon ertaklari o'zbek ertaklaridan nechta ko'p?",o:["10","47","37","121"],k:0,s:"Jahon ertaklari 84 − 37 = 47. Farq: 47 − 37 = 10."},
{t:"Ali Validan 6 ta ko'p, Vali Sardordan 4 ta ko'p olma terdi. Ali Sardordan nechta ko'p olma tergan?",o:["10","2","6","4"],k:0,s:"Chizmada farqlar qo'shiladi: 6 + 4 = 10."}
];
function PRACT_STAGE(){bmDraw({t:'Avval kim ko‘p ekanini aniqlang',bars:[{lab:'ko‘p',y:46,segs:[{w:25,txt:'',c:'a'},{w:9,txt:'farq',c:'c'}]},{lab:'kam',y:106,segs:[{w:25,txt:'',c:'b'}]}],note:'Ko‘p → qo‘shamiz · kam → ayiramiz · farq → ayiramiz'})}
var PREP_DATA={teach:["Taqqoslash chizmasi: ikki chiziq, farq.","«… ta ko'p» — qo'shish, «… ta kam» — ayirish, «nechta ko'p/kam?» — farq.","Tuzoqlar: «bu … dan ko'p» teskari ifodasi, zanjirli taqqoslash, jamini so'rash."],
 mist:["«Ko'p» so'zini ko'rib har doim qo'shadi.","Zanjirda noto'g'ri odam bilan taqqoslaydi.","Yarim yo'lda to'xtaydi (jami so'ralganini unutadi).","«Nechta ko'p?» savolida qo'shib yuboradi."],
 need:["Ikki rangdagi qog'oz tasmalar.","Doskada ikki chiziq chizish uchun chizg'ich."],
 board:["<span class='w2'>[34] / [25|9]</span> — farq 9.","Kam: <span class='w2'>34 − 9 = 25</span>; ko'p: <span class='w2'>25 + 15 = 40</span>.","«Alida 16, bu Validan 5 ta ko'p» → <span class='w2'>16 − 5 = 11</span>.","Zanjir: Ozoda → Malika → Sevara.","Jami: <span class='w2'>400 + 200 = 600</span>."]};
