var CODE='3H2',TITLE='3-sinf · Kvadrat va to‘g‘ri to‘rtburchak yuzi';
// katakli to'rtburchak: a×b, rows — nechta qator to'ldirilgan
function h2Grid(a,b,rows,o){o=o||{};var cs=o.cs||20,x0=o.x!=null?o.x:180-a*cs/2,y0=o.y!=null?o.y:84-b*cs/2,g=S.g;
 for(var r=0;r<b;r++)for(var c=0;c<a;c++)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs,height:cs,fill:r<rows?(o.fill||'#f6c98a'):'#ffffff',stroke:'#c9d6e3','stroke-width':1},g);
 E('rect',{x:x0,y:y0,width:a*cs,height:b*cs,fill:'none',stroke:o.edge||C.line,'stroke-width':o.ew||2.4},g);
 if(!o.nol){T(g,x0+a*cs/2,y0-6,(o.la||a+' sm'),{'font-size':12,'font-weight':800,fill:C.bad});T(g,x0-6,y0+b*cs/2+4,(o.lb||b+' sm'),{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
 return [x0,y0]}
var P1=[function(){clear('#ffffff');h2Grid(5,3,0);g3Msg('Har katak — 1 sm². To‘g‘ri to‘rtburchakda nechta katak?')},
 function(){clear('#ffffff');h2Grid(5,3,1);g3Msg('1-qator: <b>5</b> katak')},
 function(){clear('#ffffff');h2Grid(5,3,2);g3Msg('2 qator: 5 · 2 = <b>10</b>')},
 function(){clear('#ffffff');h2Grid(5,3,3);g3Msg('3 qator: 5 · 3 = <b>15 sm²</b>. Yuz = bo‘yi · eni')}];
function h2Dyn(){clear('#ffffff');var a=S.ra,b=S.rb;h2Grid(a,b,b,{cs:16});g3Msg('S = '+a+' · '+b+' = <b>'+(a*b)+' sm²</b> &nbsp;·&nbsp; P = ('+a+' + '+b+') · 2 = <b>'+((a+b)*2)+' sm</b>'+(a===b?' — <b>kvadrat</b>':''))}
function h2PS(m){clear('#ffffff');var g=S.g;var p=h2Grid(4,4,m===2?4:0,{cs:24});
 if(m===1){E('rect',{x:p[0],y:p[1],width:96,height:96,fill:'none',stroke:C.bad,'stroke-width':5},g);g3Msg('<b>Perimetr</b> — chegara: 4 · 4 = <b>16 sm</b> (chiziq)')}
 else if(m===2)g3Msg('<b>Yuz</b> — ichki joy: 4 · 4 = <b>16 sm²</b> (kataklar)');else g3Msg('Kvadrat: tomoni 4 sm')}
function h2Sq(k){clear('#ffffff');var g=S.g;h2Grid(9,9,k>=2?9:0,{cs:12,y:30,la:k>=1?'9 sm':'?',lb:k>=1?'9 sm':'?'});T(g,300,60,'P = 36 sm',{'font-size':14,'font-weight':800,fill:C.bad});
 g3Msg(['Kvadratning perimetri 36 sm. Yuzi qancha?','Tomoni: 36 : 4 = <b>9 sm</b>','Yuzi: 9 · 9 = <b>81 sm²</b>','⚠️ 36 : 4 = 9 — bu tomon, yuz emas! S = <b>81 sm²</b>'][k])}
var P4=[function(){h2Sq(0)},function(){h2Sq(1)},function(){h2Sq(2)},function(){h2Sq(3)}];
function h2Inv(k){clear('#ffffff');var g=S.g;h2Grid(8,7,k>=1?7:0,{cs:16,la:'8 sm',lb:k>=1?'7 sm':'?'});T(g,320,60,'S = 56 sm²',{'font-size':13,'font-weight':800,fill:C.ok});
 g3Msg(['Yuzi 56 sm², bo‘yi 8 sm. Perimetri qancha?','Eni: 56 : 8 = <b>7 sm</b> (har qatorda 8 katak, 7 qator)','P = (8 + 7) · 2 = <b>30 sm</b>'][k])}
var P5=[function(){h2Inv(0)},function(){h2Inv(1)},function(){h2Inv(2)}];
function h2Dbl(k){clear('#ffffff');var g=S.g,cs=14;
 if(k===0){h2Grid(3,3,3,{cs:cs,x:150,y:40,la:'3',lb:'3'});g3Msg('Kvadrat 3 × 3: yuzi <b>9</b> katak')}
 else{var p=h2Grid(6,6,6,{cs:cs,x:138,y:36,la:'6',lb:'6',fill:'#fbe0b4'});E('rect',{x:p[0],y:p[1],width:3*cs,height:3*cs,fill:'#f2b766',stroke:C.line,'stroke-width':2},g);
  if(k>=2){g3Line([p[0]+3*cs,p[1]],[p[0]+3*cs,p[1]+6*cs],{w:2.5,c:C.bad});g3Line([p[0],p[1]+3*cs],[p[0]+6*cs,p[1]+3*cs],{w:2.5,c:C.bad})}
  g3Msg(k===1?'Tomonini 2 marta oshirdik: 6 × 6. Yuz necha marta oshdi?':'Ichiga <b>4 ta</b> eski kvadrat sig‘di: 36 = 9 · 4. Yuz <b>4 marta</b> oshdi, 2 emas!')}}
var P6=[function(){h2Dbl(0)},function(){h2Dbl(1)},function(){h2Dbl(2)}];
function h2Unit(m){clear('#ffffff');var g=S.g;g3Rect(80,40,200,90,{fill:'rgba(240,160,64,.2)'});T(g,180,34,'240 mm',{'font-size':12,'font-weight':800,fill:C.bad});T(g,74,90,'15 sm',{'font-size':12,'font-weight':800,fill:C.blue,'text-anchor':'end'});
 if(m)T(g,180,92,m,{'font-size':14,'font-weight':800,fill:m.indexOf('✓')>=0?C.ok:C.bad})}
function h2Eq(k){clear('#ffffff');var g=S.g;h2Grid(6,6,6,{cs:14,x:40,y:30,la:'6 sm',lb:'6 sm',fill:'#cfe6f8'});
 h2Grid(9,4,k>=1?4:0,{cs:14,x:190,y:44,la:k>=1?'9 sm':'?',lb:'4 sm'});T(g,82,132,'S = 36 sm²',{'font-size':12,'font-weight':800,fill:C.blue});if(k>=1)T(g,253,120,'S = 36 sm²',{'font-size':12,'font-weight':800,fill:C.ok});
 g3Msg(['Yuzlar teng. Kvadrat tomoni 6 sm, to‘g‘ri to‘rtburchak eni 4 sm. Uning perimetri?','Yuz: 6 · 6 = 36. Bo‘yi: 36 : 4 = <b>9 sm</b>','P = (9 + 4) · 2 = <b>26 sm</b>'][k])}
var P8=[function(){h2Eq(0)},function(){h2Eq(1)},function(){h2Eq(2)}];
function h2Sotix(on){clear('#ffffff');var g=S.g;var p=h2Grid(10,10,on?10:0,{cs:13,y:20,la:'10 m',lb:'10 m',fill:'#b9dfa6'});
 T(g,300,70,'1 sotix',{'font-size':15,'font-weight':800,fill:C.ok});T(g,300,90,'= 100 m²',{'font-size':13,'font-weight':800,fill:C.t1});
 g3Msg(on?'10 · 10 = <b>100 m²</b> = 1 sotix. 100 sotix = 1 gektar':'Kvadrat yer: tomoni 10 m')}
var STEPS=[
{h:"Yuz — kataklar soni",sum:"Yuz — shakl ichini qoplaydigan birlik kvadratlar (sm²) soni. Qator · qatorlar soni.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Shakl <b>yuzi</b> — uning ichini qoplash uchun nechta <b>birlik kvadrat</b> kerakligi. Tomoni 1 sm bo'lgan katak — <b>1 sm²</b>. Qatorlab to'ldiring:</p>",
 btns:[phaser(P1,'▦ Qator')],
 after:"<p>Har qatorda 5 katak, 3 qator: 5 · 3 = <b>15 sm²</b>. Sanashning qisqa yo'li: <b>S = bo'yi · eni</b>.</p>",
 q:{t:"Har qatorda 7 katak, 4 qator. Yuz?",opts:["11 sm²","28 sm²","22 sm²","28 sm"],ok:1,why:"7 · 4 = 28 sm².",hint:"Qatordagi kataklarni qatorlar soniga ko'paytiring.",full:"7 · 4 = 28 sm². «11» — qo'shilgan, «22» — perimetr, «28 sm» — birligi noto'g'ri (yuz sm² da)."},
 tn:"Daftar katagi taxminan 5 mm — 1 sm² = 4 katak ekanini ko'rsating; yaxshisi 1 sm li katakli qog'oz bering."},
{h:"Formula: S = a · b",sum:"To'g'ri to'rtburchak: S = bo'yi · eni; kvadrat: S = tomon · tomon.",a:"m02",
 start:function(){S.ra=4;S.rb=3;h2Dyn()},fin:function(){S.ra=5;S.rb=5;h2Dyn()},
 html:"<p>O'lchamlarni o'zgartiring — yuz (S) va perimetr (P) qanday o'zgarishini kuzating:</p>",
 btns:[["➡ Bo'yi +1",function(c,done){S.ra=S.ra>=9?2:S.ra+1;h2Dyn();mvK(done,4)}],["⬇ Eni +1",function(c,done){S.rb=S.rb>=6?2:S.rb+1;h2Dyn();mvK(done,4)}]],g2:1,
 after:"<p><b>S = bo'yi · eni</b> (sm²), <b>P = (bo'yi + eni) · 2</b> (sm). Bo'yi = eni bo'lsa — <b>kvadrat</b>: S = a · a.</p>",
 q:{t:"Kvadratning tomoni 8 sm. Yuzi?",opts:["32 sm²","16 sm²","64 sm²","64 sm"],ok:2,why:"8 · 8 = 64 sm².",hint:"Kvadratda bo'yi ham, eni ham 8.",full:"S = 8 · 8 = 64 sm². «32» — perimetr (8 · 4), «16» — 8 · 2, «64 sm» — birlik noto'g'ri."},
 tn:"Singapur usuli: avval kataklar (konkret), keyin chizma (tasviriy), so'ng formula (abstrakt)."},
{h:"Tuzoq: yuz ≠ perimetr",sum:"Perimetr — chegara chizig'i (sm), yuz — ichki joy (sm²). Son bir xil chiqsa ham ular har xil!",a:"m03",
 start:function(){h2PS(0)},fin:function(){h2PS(2)},
 html:"<p>Tomoni 4 sm bo'lgan kvadrat. Ikkala o'lchovni ko'ring:</p>",
 btns:[["🔴 Perimetr",function(c,done){h2PS(1);mvK(done,2)}],["🟧 Yuz",function(c,done){h2PS(2);mvK(done,2)}]],g2:1,
 after:"<p>Ikkalasi ham «16», lekin <b>16 sm</b> — chegara uzunligi (ip bilan o'lchanadi), <b>16 sm²</b> — ichki joy (kataklar). Devorni o'rashga — perimetr, polga gilam — yuz kerak.</p>",
 q:{t:"Xonaga gilam to'shash uchun nima hisoblanadi?",opts:["Perimetr","Yuz","Hajm","Diagonal"],ok:1,why:"Gilam polni qoplaydi — bu yuz.",hint:"Gilam xona atrofini emas, polni qoplaydimi?",full:"Gilam pol sathini qoplaydi — yuz (m²). Perimetr — devor bo'ylab, masalan plintus yoki hoshiya uchun."},
 tn:"Doskada bir shakl: chegara — bo'r bilan qizil, ichi — sariq. «Ip yoki katak?» savolini bering."},
{h:"Perimetrdan yuzga",sum:"Kvadrat P = 36 → tomoni 36 : 4 = 9 → S = 81 sm².",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Masala: <i>«Kvadratning perimetri 36 sm. Uning yuzini toping.»</i> Bu ikki bosqichli masala.</p>",
 btns:[phaser(P4)],
 after:"<p>1) Tomon = P : 4 = 9 sm. 2) S = 9 · 9 = <b>81 sm²</b>. Eng ko'p xato — 9 ni javob deb yozish.</p>",
 q:{t:"Kvadratning perimetri 28 sm. Yuzi?",opts:["7 sm²","49 sm²","196 sm²","28 sm²"],ok:1,why:"Tomoni 7, 7 · 7 = 49.",hint:"Avval kvadrat tomonini toping.",full:"Tomoni 28 : 4 = 7 sm, yuzi 7 · 7 = 49 sm². «7» — tomon, «196» — 28 · 7."},
 tn:"Bank misollarida bu turi eng ko'p — bolalar ikki qadamni alohida qatorda yozsin."},
{h:"Yuzdan perimetrga",sum:"S = 56, bo'yi 8 → eni 56 : 8 = 7 → P = (8 + 7) · 2 = 30.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Masala: <i>«To'g'ri to'rtburchakning yuzi 56 sm², bo'yi 8 sm. Perimetrini toping.»</i></p>",
 btns:[phaser(P5)],
 after:"<p>Eni = <b>S : bo'yi</b> = 56 : 8 = 7 sm. Keyin P = (8 + 7) · 2 = <b>30 sm</b>.</p>",
 q:{t:"Kvadratning yuzi 49 sm². Perimetri?",opts:["14 sm","28 sm","49 sm","196 sm"],ok:1,why:"Tomoni 7 (7 · 7 = 49), P = 28.",hint:"Qaysi son o'ziga ko'paytirilsa 49 chiqadi?",full:"7 · 7 = 49, demak tomoni 7 sm. P = 7 · 4 = 28 sm. «14» — 7 · 2."},
 tn:"Ko'paytirish jadvalidagi kvadratlar (4, 9, 16, …, 81) ni doskaga yozib qo'ying."},
{h:"Tuzoq: tomon 2 marta — yuz 4 marta",sum:"Kvadrat tomoni 2 marta ortsa, yuzi 4 marta ortadi; bir tomoni ortsa — yuz ham shuncha marta.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Kvadrat tomonini 2 marta oshirsak, yuzi necha marta oshadi? Ko'pchilik «2 marta» deydi. Tekshiramiz:</p>",
 btns:[phaser(P6)],
 after:"<p>3 × 3 = 9, 6 × 6 = 36 — <b>4 marta</b>. Chunki ham bo'yi, ham eni 2 marta oshdi. Agar faqat <b>bitta</b> tomon 2 marta oshsa, yuz 2 marta oshadi: 9 × 4 = 36 → 18 × 4 = 72.</p>",
 q:{t:"Bo'yi 6 sm, eni 3 sm. Enini 3 marta orttirsak, yuz necha sm² ga ortadi?",opts:["54 sm²","36 sm²","18 sm²","9 sm²"],ok:1,why:"Avval 18, keyin 6 · 9 = 54; 54 − 18 = 36.",hint:"Savol «qanchaga» — yangi yuzdan eskisini ayiring.",full:"Eski yuz 6 · 3 = 18, yangi 6 · 9 = 54. Ortgani 54 − 18 = 36 sm². «54» — yangi yuz (ayirish unutilgan)."},
 tn:"Qog'ozdan 4 ta bir xil kvadrat qirqib, ulardan 2 marta katta kvadrat yig'dirib ko'ring."},
{h:"Tuzoq: turli birliklar",sum:"Avval bir xil birlikka: 240 mm = 24 sm; S = 24 · 15 = 360 sm².",a:"m07",
 start:function(){h2Unit('');g3Msg('Yuzi necha sm²?')},fin:function(){h2Unit('24 · 15 = 360 sm² ✓');g3Msg('240 mm = 24 sm')},
 html:"<p>Taglikning bo'yi <b>240 mm</b>, eni <b>15 sm</b>. Yuzi necha sm²? Javoblarni sinab ko'ring:</p>",
 btns:[["3 600",function(){h2Unit('240 · 15 = 3 600 ?');g3Msg('mm va sm aralashib ketdi ✗')}],["360 sm²",function(c,done){h2Unit('24 · 15 = 360 sm² ✓');g3Msg('To‘g‘ri: 240 mm = 24 sm');done()},'u'],["39",function(){h2Unit('24 + 15 = 39 ?');g3Msg('Bu qo‘shish — yuz emas ✗')}]],g3:1,
 after:"<p>Qoida: ko'paytirishdan <b>oldin</b> o'lchamlarni bir xil birlikka keltiring. 240 mm = 24 sm, S = 24 · 15 = <b>360 sm²</b>.</p>",
 q:{t:"Bo'yi 2 dm, eni 7 sm. Yuzi?",opts:["14 sm²","140 sm²","27 sm²","18 sm²"],ok:1,why:"2 dm = 20 sm, 20 · 7 = 140.",hint:"2 dm necha sm?",full:"2 dm = 20 sm, S = 20 · 7 = 140 sm². «14» — dm va sm aralashgan, «18» — perimetr (2 + 7) · 2."},
 tn:"Chizg'ich bilan daftar o'lchamini mm va sm da o'lchatib, birlik almashtirishni mashq qiling."},
{h:"Teng yuzli shakllar",sum:"Kvadrat 6 × 6 = 36; eni 4 bo'lgan teng yuzli to'rtburchak: bo'yi 9, P = 26.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Masala: <i>«Kvadrat va to'g'ri to'rtburchakning yuzlari teng. Kvadrat tomoni 6 sm, to'g'ri to'rtburchak eni 4 sm. To'g'ri to'rtburchak perimetrini toping.»</i></p>",
 btns:[phaser(P8)],
 after:"<p>Uch bosqich: kvadrat yuzi 36 → bo'yi 36 : 4 = 9 → P = (9 + 4) · 2 = <b>26 sm</b>. Yuzlari teng bo'lsa ham, perimetrlari har xil (kvadratniki 24)!</p>",
 q:{t:"Kvadrat perimetri tomonlari 13 sm va 7 sm bo'lgan to'g'ri to'rtburchak perimetriga teng. Kvadrat yuzi to'g'ri to'rtburchak yuzidan necha sm² katta?",opts:["0","9","4","91"],ok:1,why:"P = 40, kvadrat tomoni 10, 100 − 91 = 9.",hint:"Avval perimetrni, keyin kvadrat tomonini toping.",full:"P = (13 + 7) · 2 = 40. Kvadrat tomoni 10, yuzi 100. To'rtburchak yuzi 13 · 7 = 91. Farq 9 sm². «0» — perimetrlar teng bo'lsa yuzlar ham teng deb o'ylash."},
 tn:"Bu — 3-sinfning eng qiyin turi. Har bosqichni alohida chizmada ko'rsating."},
{h:"Bilasizmi? Sotix",sum:"1 sotix = 100 m² — tomoni 10 m bo'lgan kvadrat; 100 sotix = 1 gektar.",a:"m09",
 start:function(){h2Sotix(0)},fin:function(){h2Sotix(1)},
 html:"<p>🏡 Tomorqa yerlari ko'pincha <b>sotix</b>da o'lchanadi. 1 sotix = <b>100 m²</b>. Kvadrat shaklidagi 1 sotix yerni to'ldiring:</p>",
 btns:[["🌱 Ekish",function(c,done){h2Sotix(1);done()}]],
 after:"<p>10 m × 10 m = 100 m² = <b>1 sotix</b> (1 ar). 100 sotix = <b>1 gektar</b> (100 m × 100 m).</p>",
 tn:"Bolalardan uylari tomorqasi necha sotix ekanini so'rab keling — m² ga o'tkazing."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){P1[3]()},fin:function(){P1[3]()},
 html:"<div class='memo'><ul><li>Yuz — ichini qoplaydigan birlik kvadratlar soni (sm², dm², m²).</li><li>To'g'ri to'rtburchak: <b>S = a · b</b>; kvadrat: <b>S = a · a</b>.</li><li>Teskari: <b>b = S : a</b>.</li><li>Kvadrat P → tomon (P : 4) → yuz.</li><li>Yuz (sm²) ≠ perimetr (sm).</li><li>Tomon 2 marta → kvadrat yuzi <b>4 marta</b>.</li><li>Ko'paytirishdan oldin birliklarni tenglang.</li></ul></div>",
 tn:"Uyga: o'z xonangiz polining yuzini m² da hisoblang."}
];
var PROBS=[
{t:"Bo'yi 6 sm, eni 4 sm. Yuzi?",o:["24 sm²","20 sm²","10 sm²","48 sm²"],k:0,s:"6 · 4 = 24."},
{t:"Kvadratning tomoni 8 sm. Yuzi?",o:["64 sm²","32 sm²","16 sm²","24 sm²"],k:0,s:"8 · 8 = 64."},
{t:"Yuzi 42 sm², eni 6 sm. Bo'yi?",o:["7 sm","36 sm","48 sm","21 sm"],k:0,s:"42 : 6 = 7."},
{t:"Kvadratning perimetri 28 sm. Yuzi?",o:["49 sm²","14 sm²","28 sm²","196 sm²"],k:0,s:"Tomon 7, 7 · 7 = 49."},
{t:"Kvadratning yuzi 49 sm². Perimetri?",o:["28 sm","14 sm","49 sm","32 sm"],k:0,s:"Tomon 7, 7 · 4 = 28."},
{t:"Yuzi 56 sm², bo'yi 8 sm. Perimetri?",o:["30 sm","15 sm","22 sm","64 sm"],k:0,s:"Eni 7; (8 + 7) · 2 = 30."},
{t:"Perimetri 46 sm, bo'yi 14 sm. Yuzi?",o:["126 sm²","32 sm²","448 sm²","98 sm²"],k:0,s:"Eni 9; 14 · 9 = 126."},
{t:"Perimetri 2 dm 2 sm, eni 4 sm. Yuzi?",o:["28 sm²","88 sm²","18 sm²","22 sm²"],k:0,s:"22 : 2 − 4 = 7; 7 · 4 = 28."},
{t:"Yuzi 54 dm² bo'lgan to'g'ri to'rtburchak 6 ta teng kvadratga bo'lindi. Har kvadrat tomoni?",o:["3 dm","9 dm","6 dm","48 dm"],k:0,s:"54 : 6 = 9 dm², tomoni 3."},
{t:"Maydonning bo'yi 16 m, eni bo'yining yarmiga teng. Yuzi?",o:["128 m²","24 m²","48 m²","256 m²"],k:0,s:"Eni 8; 16 · 8 = 128."},
{t:"Bo'yi 9 dm, eni 4 dm. Bo'yi 2 marta orttirilsa, yuzi qanchaga ortadi?",o:["36 dm²","18 dm²","72 dm²","26 dm²"],k:0,s:"72 − 36 = 36."},
{t:"Bo'yi 6 sm, eni 3 sm. Eni 3 marta orttirilsa, yuz qanchaga ortadi?",o:["36 sm²","54 sm²","18 sm²","9 sm²"],k:0,s:"54 − 18 = 36."},
{t:"Kvadrat perimetri 13 sm va 7 sm li to'g'ri to'rtburchak perimetriga teng. Kvadrat yuzi necha sm² katta?",o:["9","0","4","91"],k:0,s:"100 − 91 = 9."},
{t:"Bo'yi 240 mm, eni 15 sm. Yuzi necha sm²?",o:["360 sm²","3 600 sm²","39 sm²","78 sm²"],k:0,s:"24 · 15 = 360."},
{t:"1 sotix = 100 m². Kvadrat shaklidagi 1 sotix yerning tomoni?",o:["10 m","100 m","1 m","25 m"],k:0,s:"10 · 10 = 100."},
{t:"Kvadrat (tomoni 6 sm) va to'g'ri to'rtburchak (eni 4 sm) yuzlari teng. To'g'ri to'rtburchak perimetri?",o:["26 sm","24 sm","36 sm","18 sm"],k:0,s:"Bo'yi 9; (9 + 4) · 2 = 26."},
{t:"1-to'rtburchak: yuzi 35 sm², eni 5 sm. 2-to'rtburchak: yuzi 24 sm², eni 3 sm. Qaysi birining bo'yi uzun?",o:["Ikkinchisiniki, 1 sm ga","Birinchisiniki, 1 sm ga","Ikkinchisiniki, 2 sm ga","Bo'ylari teng"],k:0,s:"7 va 8."},
{t:"Perimetri 24 sm, bo'yi enidan 2 marta uzun. Yuzi?",o:["32 sm²","48 sm²","24 sm²","36 sm²"],k:0,s:"Bo'yi + eni = 12: 8 va 4, 32."},
{t:"Kvadratning yuzi 64 sm². Perimetrining yarmi?",o:["16 sm","32 sm","8 sm","28 sm"],k:0,s:"Tomon 8, P 32, yarmi 16."},
{t:"Kvadrat tomoni 2 marta orttirilsa, yuzi necha marta ortadi?",o:["4 marta","2 marta","8 marta","3 marta"],k:0,s:"2 · 2 = 4."}
];
function PRACT_STAGE(){P1[3]()}
var PREP_DATA={teach:["Yuz — birlik kvadratlar soni; S = a · b, kvadratda S = a · a.","Yuz va perimetr farqi.","Ikki bosqichli masalalar: P → tomon → S; S → tomon → P.","Tomonlar o'zgarganda yuz qanday o'zgaradi; birliklarni tenglash."],
 mist:["Yuzni (a + b) · 2 bilan hisoblaydi.","Kvadrat P = 36 da tomonni (9) yuz deb yozadi.","Kvadrat tomoni 2 marta ortsa, yuz ham 2 marta deydi.","mm va sm ni aralashtirib ko'paytiradi.","«Qanchaga ortdi» savolida yangi yuzni yozib qo'yadi."],
 need:["1 sm li katakli qog'oz, rangli qalam.","Qog'oz kvadratlar (4 ta bir xil)."],
 board:["<span class='w2'>S = a · b</span>, <span class='w2'>S = a · a</span>.","<span class='w2'>b = S : a</span>.","P 36 → 9 → <span class='w2'>81 sm²</span>.","3 × 3 = 9 → 6 × 6 = 36 (×4).","240 mm × 15 sm = 24 · 15 = 360 sm²."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
