var CODE='2H17',TITLE='2-sinf · Shakl = son jumboqlari';
// ---------- sahna: tenglik qatorlari ----------
// rows: [[token...], ...]  token: 'star','circ','tri','sq' yoki son/belgi matni; vals: {star:8,...} — ko'rsatilsa shakl ichida son
var H17S={star:['☆','#f2b766'],circ:['○','#9ad0f0'],tri:['△','#f6a5b5'],sq:['□','#b7e2b0'],q:['?','#e9e2d6']};
function h17Eq(rows,vals,o){o=o||{};clear();var g=S.g;vals=vals||{};var n=rows.length,rh=Math.min(46,150/n);
 rows.forEach(function(r,ri){var y=16+ri*rh+rh/2,tot=0;var ws=r.map(function(t){return H17S[t]?34:(String(t).length*10+10)});tot=ws.reduce(function(a,b){return a+b},0);var x=180-tot/2;
  if(o.hl&&o.hl.indexOf(ri)>=0)E('rect',{x:x-8,y:y-20,width:tot+16,height:40,rx:10,fill:'#fff4d6',stroke:'#f1d58a'},g);
  if(o.done&&o.done.indexOf(ri)>=0)E('rect',{x:x-8,y:y-20,width:tot+16,height:40,rx:10,fill:'#e6f6ee',stroke:C.ok},g);
  r.forEach(function(t,i){var w=ws[i];if(H17S[t]){var sh=H17S[t];E('rect',{x:x+2,y:y-15,width:30,height:30,rx:t==='circ'?15:6,fill:sh[1],stroke:'rgba(0,0,0,.2)'},g);T(g,x+17,y+6,vals[t]!=null?String(vals[t]):sh[0],{'font-size':vals[t]!=null?15:18,'font-weight':800,fill:'#1d2b3a'})}
   else T(g,x+w/2,y+6,String(t),{'font-size':18,'font-weight':800,fill:'#1d2b3a'});x+=w})})}
function h17Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ---------- bosqichlar ----------
var R2=[['star','+','star','=','16'],['star','−','circ','=','3']];
var P2=[function(){h17Eq(R2,{});h17Msg('Qaysi qatordan boshlaymiz? Bitta shakl qatnashgan qatordan!')},
 function(){h17Eq(R2,{},{hl:[0]});h17Msg('☆ + ☆ = 16 — ikkita bir xil son 16 ni beradi: 16 : 2 = <b>8</b>')},
 function(){h17Eq(R2,{star:8},{done:[0],hl:[1]});h17Msg('☆ o‘rniga 8 ni qo‘yamiz: 8 − ○ = 3')},
 function(){h17Eq(R2,{star:8,circ:5},{done:[0,1]});h17Msg('8 − ○ = 3 → ○ = 8 − 3 = <b>5</b>. Tekshiramiz: 8 − 5 = 3 ✓')}];
var R3=[['tri','+','tri','+','tri','+','8','=','26'],['sq','+','sq','+','sq','+','sq','=','tri','+','tri']];
var P3=[function(){h17Eq(R3,{});h17Msg('△ ham, □ ham noma’lum. Qayerdan boshlaymiz?')},
 function(){h17Eq(R3,{},{hl:[0]});h17Msg('1-qator: uchta △ + 8 = 26 → uchta △ = 26 − 8 = 18')},
 function(){h17Eq(R3,{tri:6},{done:[0],hl:[1]});h17Msg('18 : 3 = <b>6</b>, demak △ = 6. Endi 2-qator: to‘rtta □ = 6 + 6 = 12')},
 function(){h17Eq(R3,{tri:6,sq:3},{done:[0,1]});h17Msg('12 : 4 = <b>3</b>, demak □ = 3, △ = 6')}];
var R4=[['circ','+','circ','=','tri'],['tri','+','circ','=','12']];
var P4=[function(){h17Eq(R4,{});h17Msg('Ikkala qatorda ham ikkita noma’lum… Hech bir qatorda bitta shakl yo‘q!')},
 function(){h17Eq([['circ','+','circ','=','tri'],['circ','+','circ','+','circ','=','12']],{},{hl:[1]});h17Msg('Ayyorlik: 2-qatordagi △ o‘rniga <b>○ + ○</b> ni qo‘yamiz (1-qatordan)')},
 function(){h17Eq([['circ','+','circ','=','tri'],['circ','+','circ','+','circ','=','12']],{circ:4},{done:[1]});h17Msg('Uchta ○ = 12 → ○ = <b>4</b>, △ = 4 + 4 = 8')}];
var R5=[['15','−','sq','=','9'],['circ','−','sq','=','7'],['tri','−','5','=','circ']];
var P5=[function(){h17Eq(R5,{});h17Msg('Uchta tenglik. Savol: □ + ○ + △ = ?')},
 function(){h17Eq(R5,{sq:6},{done:[0]});h17Msg('15 − □ = 9 → □ = 15 − 9 = <b>6</b>')},
 function(){h17Eq(R5,{sq:6,circ:13},{done:[0,1]});h17Msg('○ − 6 = 7 → ○ = 7 + 6 = <b>13</b>')},
 function(){h17Eq(R5,{sq:6,circ:13,tri:18},{done:[0,1,2]});h17Msg('△ − 5 = 13 → △ = <b>18</b>. Yig‘indi: 6 + 13 + 18 = <b>37</b>')}];
var STEPS=[
{h:"Shakl ortida son yashiringan",sum:"Bir xil shakllar — bir xil son. ? + ? + ? + 9 + 4 = 25 → uchta ? = 12 → ? = 4.",a:"m01",
 start:function(){S.v=1;h17Show()},fin:function(){h17Eq([['9','+','q','+','q','+','q','+','4','=','25']],{q:4},{done:[0]});h17Msg('9 + 4 + 4 + 4 + 4 = 25 ✓')},
 html:"<p>Har bir <b>?</b> o'rnida <b>bir xil</b> son yashiringan: <b>9 + ? + ? + ? + 4 = 25</b>. Sonni o'zgartirib, tenglikni to'g'ri qiling.</p>",
 btns:[["− 1",function(c,done){if(S.v>0){S.v--;h17Show(done)}}],["+ 1",function(c,done){if(S.v<12){S.v++;h17Show(done)}},'u']],g2:1,
 after:"<p>Sinab topdik: ? = 4. Lekin hisoblab ham topsa bo'ladi: 9 + 4 = 13, 25 − 13 = 12 — bu uchta bir xil son, 12 : 3 = <b>4</b>.</p>",
 q:{t:"7 + ? + ? = 19. Har bir ? da bir xil son. ? nechaga teng?",opts:["12","6","5","19"],ok:1,why:"19 − 7 = 12, ikkita bir xil son: 12 : 2 = 6.",hint:"Avval 7 ni olib tashlang. Qolgan son nechta ? ga teng?",full:"? + ? = 19 − 7 = 12. Ikkita bir xil son 12 ni beradi: 6. Tekshiramiz: 7 + 6 + 6 = 19 ✓. «12» — ikkalasining yig'indisi, bittasi emas."},
 tn:"Bu — tenglamaning rasmli ko'rinishi. Shakl o'rniga kartochka yopib, bolalardan uni «ochishni» so'rang."},
{h:"Oson qatordan boshlaymiz",sum:"☆ + ☆ = 16 → ☆ = 8; 8 − ○ = 3 → ○ = 5. Avval bitta shakl qatnashgan qator.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ikki tenglik: <b>☆ + ☆ = 16</b> va <b>☆ − ○ = 3</b>. ○ nechaga teng? Asosiy qoida: <b>faqat bitta xil shakl</b> qatnashgan qatordan boshlang.</p>",
 btns:[phaser(P2)],
 after:"<p>Topilgan sonni keyingi qatorga <b>qo'yamiz</b> — shunda u qatorda ham bitta noma'lum qoladi. Zanjirdek: ☆ → ○.</p>",
 q:{t:"■ + ■ + ■ = 15 va ▲ + ■ = 12. ▲ nechaga teng?",opts:["5","3","7","12"],ok:2,why:"■ = 15 : 3 = 5, ▲ = 12 − 5 = 7.",hint:"Qaysi qatorda bitta xil shakl? Avval ■ ni toping.",full:"■ + ■ + ■ = 15 → ■ = 5. ▲ + 5 = 12 → ▲ = 7. «5» — bu ■, savol esa ▲ ni so'rayapti."},
 tn:"Bolalarga «avval qaysi qatorni yechamiz?» deb so'rang va sababini tushuntirsin."},
{h:"Ikki xil shakl — ikki qadam",sum:"Uchta △ + 8 = 26 → △ = 6; to'rtta □ = △ + △ = 12 → □ = 3.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p><b>△ + △ + △ + 8 = 26</b> va <b>□ + □ + □ + □ = △ + △</b>. □ va △ ni toping.</p>",
 btns:[phaser(P3)],
 after:"<p>Usul o'sha: 1-qatorda faqat △ — u yerdan boshlaymiz. △ topilgach, 2-qatorning o'ng tomoni son bo'lib qoladi (6 + 6 = 12) va □ ni topamiz.</p>",
 q:{t:"○ + ○ + 5 = 17 va △ + △ + △ = ○. △ nechaga teng?",opts:["6","2","4","12"],ok:1,why:"○ = (17 − 5) : 2 = 6, △ = 6 : 3 = 2.",hint:"Avval ○ ni toping: 17 dan 5 ni oling va ikkiga bo'ling.",full:"○ + ○ = 12 → ○ = 6. Uchta △ = 6 → △ = 2. «6» — bu ○ ning qiymati."},
 tn:"Doskada shakllarni rangli bo'r bilan chizing va topilgan sonni shakl ichiga yozing."},
{h:"Tuzoq: almashtirib qo'yamiz",sum:"○ + ○ = △ va △ + ○ = 12: △ o'rniga ○ + ○ → uchta ○ = 12 → ○ = 4.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p><b>○ + ○ = △</b> va <b>△ + ○ = 12</b>. Bu yerda hech bir qatorda bitta shakl yo'q! Qanday yechamiz?</p>",
 btns:[phaser(P4)],
 after:"<p>Kalit: 1-qator aytadi — <b>△ — bu ○ + ○</b>. Shuni 2-qatorga qo'ysak, faqat ○ qoladi: ○ + ○ + ○ = 12. Bu — tarozida almashtirish bilan bir xil fikr!</p>",
 q:{t:"△ = □ + □ + □ va △ + □ = 20. □ nechaga teng?",opts:["4","5","15","10"],ok:1,why:"△ o'rniga □□□: to'rtta □ = 20 → □ = 5.",hint:"△ o'rniga □ + □ + □ ni qo'ying. Nechta □ bo'ladi?",full:"△ + □ = □ + □ + □ + □ = 20 → □ = 5, △ = 15. «15» — bu △."},
 tn:"Bu qadam keyingi sinflardagi «o'rniga qo'yish usuli»ning asosi."},
{h:"Uch qatorli zanjir",sum:"15 − □ = 9 → □ = 6; ○ − □ = 7 → ○ = 13; △ − 5 = ○ → △ = 18; yig'indi 37.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p><b>15 − □ = 9</b>, <b>○ − □ = 7</b>, <b>△ − 5 = ○</b>. □ + ○ + △ yig'indisini toping. Zanjir bo'ylab boramiz.</p>",
 btns:[phaser(P5)],
 after:"<p>Ayirishda noma'lumni topish: <b>15 − □ = 9</b> → □ = 15 − 9; <b>○ − 6 = 7</b> → ○ = 7 + 6. Har topilgan son keyingi qatorni «ochadi».</p>",
 q:{t:"20 − ◇ = 12, ☆ − ◇ = 5. ◇ + ☆ nechaga teng?",opts:["13","8","21","17"],ok:2,why:"◇ = 8, ☆ = 5 + 8 = 13, yig'indi 21.",hint:"Avval ◇ ni toping: 20 dan nechani olsak, 12 qoladi?",full:"◇ = 20 − 12 = 8. ☆ − 8 = 5 → ☆ = 13. ◇ + ☆ = 8 + 13 = 21. «13» — faqat ☆."},
 tn:"Kamayuvchi va ayriluvchini topish qoidasini (2B5) shu yerda takrorlang."},
{h:"Rasmli jadval",sum:"Qatorlar va ustunlar yig'indisi berilgan jadvalda avval bitta shaklli qatorni toping.",a:"m06",
 start:function(){S.k6=0;h17Grid(0)},fin:function(){h17Grid(2)},
 html:"<p>Jadvalda har bir shakl — son, qator oxirida — qator yig'indisi. Avval qaysi qator oson?</p>",
 btns:[["▶ Keyingi harakat",function(c,done,b){S.k6++;h17Grid(S.k6);if(S.k6>=2){b.disabled=true;b.textContent='✓ Tayyor';done()}}]],
 after:"<p>1-qatorda faqat ☆: uchta ☆ = 12 → ☆ = 4. 2-qatorda ☆ ma'lum, ○ topiladi: 4 + ○ + ○ = 14 → ○ = 5. 3-qator endi hisoblanadi: ○ + ☆ + ○ = 5 + 4 + 5 = 14.</p>",
 q:{t:"☆ ☆ ☆ = 12, ☆ ○ ○ = 14 (qatorlar yig'indisi). ○ + ○ + ○ nechaga teng?",opts:["14","12","15","10"],ok:2,why:"☆ = 4, ○ = 5, uchta ○ = 15.",hint:"Avval ☆ ni toping, keyin ○ ni.",full:"☆ + ☆ + ☆ = 12 → ☆ = 4. 4 + ○ + ○ = 14 → ○ + ○ = 10 → ○ = 5. Uchta ○ = 15."},
 tn:"Bankdagi rasmli jadval masalalari (2230, 2492, 2588) aynan shunday yechiladi."},
{h:"Bilasizmi? Nega «x»?",sum:"Noma'lumni harf bilan belgilashni Fransua Viyet boshlagan; «x, y, z» ni Rene Dekart ommalashtirgan.",a:"m07",
 start:function(){h17Eq([['q','+','3','=','10']],{});h17Msg('? + 3 = 10')},fin:function(){h17Eq([['x','+','3','=','10']],{});h17Msg('x + 3 = 10 → x = 7')},
 html:"<p>📜 Biz noma'lum sonni shakl bilan belgiladik. Matematiklar asrlar davomida uni <b>so'z</b> bilan yozishgan: al-Xorazmiy noma'lumni «<b>shay'</b>» (narsa) deb atagan.</p><p>✒️ XVI asrda fransuz olimi <b>Fransua Viyet</b> noma'lumlarni <b>harflar</b> bilan belgilay boshlagan, XVII asrda <b>Rene Dekart</b> esa bugungi <b>x, y, z</b> ni ommalashtirgan. Siz hozir qilgan ish — haqiqiy algebra!</p>",
 tn:"Bolalarga o'z belgisini o'ylab topishga ruxsat bering: 🍎 + 3 = 10."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h17Eq(R2,{star:8,circ:5},{done:[0,1]});h17Msg('☆ = 8, ○ = 5')},fin:function(){h17Eq(R2,{star:8,circ:5},{done:[0,1]});h17Msg('☆ = 8, ○ = 5')},
 html:"<div class='memo'><ul><li>Bir xil shakl — <b>bir xil son</b>.</li><li><b>Bitta xil shakl</b> qatnashgan qatordan boshlang.</li><li>Bir xil shakllar yig'indisi: ? + ? + ? = 12 → ? = 12 : 3.</li><li>Topgan sonni <b>keyingi qatorga qo'ying</b>.</li><li>Bitta shaklli qator bo'lmasa — biror shaklni boshqasi bilan <b>almashtiring</b> (△ = ○ + ○).</li><li>Ayirishda: 15 − □ = 9 → □ = 15 − 9; ○ − 6 = 7 → ○ = 7 + 6.</li><li>Oxirida <b>tekshiring</b>.</li></ul></div>",
 tn:"Keyingi darsni «△ + △ = □, □ + □ = 20, △ = ?» (5) savoli bilan boshlang."}
];
function h17Show(done){h17Eq([['9','+','q','+','q','+','q','+','4','=','25']],{q:S.v});var s=9+3*S.v+4;
 if(s===25){h17Msg('9 + '+S.v+' + '+S.v+' + '+S.v+' + 4 = <b>25</b> ✓');if(done)done()}else h17Msg('9 + '+S.v+' + '+S.v+' + '+S.v+' + 4 = <b>'+s+'</b> — '+(s<25?'kam':'ko‘p'))}
function h17Grid(k){clear();var g=S.g,rows=[['star','star','star','12'],['star','circ','circ','14'],['circ','star','circ','?']],val={};if(k>=1)val.star=4;if(k>=2)val.circ=5;
 rows.forEach(function(r,ri){var y=22+ri*46;r.forEach(function(t,i){var x=70+i*56;if(H17S[t]){E('rect',{x:x,y:y,width:40,height:40,rx:t==='circ'?20:8,fill:H17S[t][1],stroke:'rgba(0,0,0,.2)'},g);T(g,x+20,y+27,val[t]!=null?String(val[t]):H17S[t][0],{'font-size':val[t]!=null?18:22,'font-weight':800,fill:'#1d2b3a'})}
  else{var v=t==='?'&&k>=2?'14':t;E('rect',{x:x,y:y,width:44,height:40,rx:8,fill:t==='?'&&k<2?'#fff4d6':'#f1f5f9',stroke:'#c9d3dd'},g);T(g,x+22,y+27,v,{'font-size':18,'font-weight':800,fill:t==='?'&&k>=2?C.ok:'#1d2b3a'})}})});
 h17Msg(k===0?'Qator yig‘indilari berilgan. 3-qator yig‘indisi nechaga teng?':(k===1?'1-qator: uchta ☆ = 12 → ☆ = <b>4</b>':'2-qator: 4 + ○ + ○ = 14 → ○ = <b>5</b>. 3-qator: 5 + 4 + 5 = <b>14</b>'))}
var PROBS=[
{t:"9 + ? + ? + ? + 4 = 25. Har ? da bir xil son. ? = ?",o:["4","12","3","6"],k:0,s:"25 − 13 = 12, 12 : 3 = 4."},
{t:"☆ + ☆ = 16 va ☆ − ○ = 3. ○ nechaga teng?",o:["5","8","13","3"],k:0,s:"☆ = 8, ○ = 8 − 3 = 5."},
{t:"■ + ■ + ■ = 15 va ▲ + ■ = 12. ▲ nechaga teng?",o:["7","5","3","12"],k:0,s:"■ = 5, ▲ = 7."},
{t:"△ + △ + △ + 8 = 26 va □ + □ + □ + □ = △ + △. □ nechaga teng?",o:["3","6","4","12"],k:0,s:"△ = 6, to'rtta □ = 12, □ = 3."},
{t:"○ + ○ = △ va △ + ○ = 12. ○ nechaga teng?",o:["4","6","8","3"],k:0,s:"Uchta ○ = 12 → ○ = 4."},
{t:"15 − ■ = 9, ● − ■ = 7, ▲ − 5 = ●. ■ + ● + ▲ = ?",o:["37","31","43","25"],k:0,s:"■ = 6, ● = 13, ▲ = 18. Yig'indi 37."},
{t:"7 + ? + ? = 19. ? nechaga teng?",o:["6","12","5","19"],k:0,s:"12 : 2 = 6."},
{t:"△ = □ + □ + □ va △ + □ = 20. △ nechaga teng?",o:["15","5","20","10"],k:0,s:"To'rtta □ = 20 → □ = 5, △ = 15."},
{t:"○ + ○ + 5 = 17 va △ + △ + △ = ○. △ = ?",o:["2","6","4","3"],k:0,s:"○ = 6, △ = 2."},
{t:"20 − ◇ = 12, ☆ − ◇ = 5. ◇ + ☆ = ?",o:["21","13","8","17"],k:0,s:"◇ = 8, ☆ = 13, yig'indi 21."},
{t:"☆ ☆ ☆ = 12, ☆ ○ ○ = 14 (qator yig'indilari). ○ + ○ + ○ = ?",o:["15","14","12","10"],k:0,s:"☆ = 4, ○ = 5, 3 · 5 = 15."},
{t:"□ + □ + □ + □ + □ = 35. □ + □ = ?",o:["14","7","10","70"],k:0,s:"□ = 7, ikkitasi 14."},
{t:"△ + 6 = 15 va △ + □ = 20. □ = ?",o:["11","9","5","14"],k:0,s:"△ = 9, □ = 11."},
{t:"○ − 4 = 10 va ○ + ☆ = 20. ☆ = ?",o:["6","14","10","4"],k:0,s:"○ = 14, ☆ = 6."},
{t:"△ + △ = □, □ + □ = 20. △ = ?",o:["5","10","4","20"],k:0,s:"□ = 10, △ = 5."},
{t:"☆ + ○ = 10 va ☆ − ○ = 4. ☆ = ?",o:["7","3","6","5"],k:0,s:"Sinaymiz: 7 + 3 = 10, 7 − 3 = 4. ☆ = 7."},
{t:"? + ? + ? = ? + 12. ? = ?",o:["6","12","4","3"],k:0,s:"Ikkala tomondan bitta ? ni olsak: ? + ? = 12, ? = 6."},
{t:"■ + ■ = 18, ■ + ▲ = 15, ▲ + ● = 10. ● = ?",o:["4","6","9","1"],k:0,s:"■ = 9, ▲ = 6, ● = 4."},
{t:"□ + □ + □ = 21 va □ − △ = 3. □ + △ = ?",o:["11","7","4","10"],k:0,s:"□ = 7, △ = 4, yig'indi 11."},
{t:"○ + ○ + ○ + ○ = 24 va ○ + ☆ = ☆ + ☆. ☆ = ?",o:["6","12","3","24"],k:0,s:"○ = 6. 6 + ☆ = ☆ + ☆ → ikkala tomondan ☆ ni olsak, 6 = ☆."}
];
function PRACT_STAGE(){h17Eq(R2,{star:8,circ:5},{done:[0,1]});h17Msg('Bitta shaklli qatordan boshlang')}
var PREP_DATA={teach:["Bir xil shakl — bir xil son.","Bitta xil shaklli qatordan boshlash; topilganini keyingisiga qo'yish.","Almashtirish (△ = ○ + ○).","Uch qatorli zanjir; rasmli jadval."],
 mist:["Yig'indini bitta shaklning qiymati deb aytadi (? + ? = 12 → 12).","Qiyin qatordan boshlab adashadi.","Topilgan sonni savolda so'ralgan shakl o'rniga beradi.","Ayirishda noma'lumni noto'g'ri topadi (○ − 6 = 7 → 1)."],
 need:["Rangli shakl kartochkalari (yuzi yopiladigan)."],
 board:["<span class='w2'>9 + ? + ? + ? + 4 = 25 → ? = 4</span>.","<span class='w2'>☆ + ☆ = 16 → ☆ = 8; 8 − ○ = 3 → ○ = 5</span>.","<span class='w2'>△ + △ + △ + 8 = 26 → △ = 6</span>.","Almashtirish: <span class='w2'>○ + ○ + ○ = 12</span>.","Zanjir: <span class='w2'>□ = 6, ○ = 13, △ = 18</span>."]};
