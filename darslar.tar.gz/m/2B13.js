var CODE='2B13',TITLE='2-sinf · Uch xonali sonlarni qo‘shish va ayirish';
function b13Ph(a,b,op,msgs){var P=[];for(var i=0;i<=3;i++)(function(k){P.push(function(){bqCol(a,b,op,k,{hl:k<3?k:null});bqMsg(msgs[k])})})(i);return P}
var P1=[function(){bqExpr(['300 + 200']);bqMsg('3 yuzlik + 2 yuzlik')},function(){bqExpr(['3 yuz + 2 yuz = 5 yuz']);bqMsg('Yuzliklarni birliklar kabi qo‘shamiz')},function(){bqExpr(['300 + 200 = [500]','700 − 400 = [300]']);bqMsg('Ayirish ham xuddi shunday: 7 yuz − 4 yuz = 3 yuz')}];
var P2=[function(){bqExpr(['340 + 25']);bqMsg('Xona birliklarini alohida qo‘shamiz')},function(){bqExpr(['300 + (40 + 20) + 5','= [365]']);bqMsg('Yuzlik o‘zgarmaydi, o‘nlik: 4 + 2 = 6, birlik: 0 + 5 = 5')},function(){bqExpr(['456 − 200 = [256]']);bqMsg('Faqat yuzliklar o‘zgaradi: 4 − 2 = 2. O‘nlik va birlik joyida qoladi')}];
var P3=b13Ph(324,152,'+',['Xonalar ostma-ost: birlik ostida birlik','Birliklar: 4 + 2 = 6','O‘nliklar: 2 + 5 = 7','Yuzliklar: 3 + 1 = 4. Javob: <b>476</b>']);
var P4=b13Ph(458,367,'+',['Ikki marta o‘nlikdan o‘tish bor!','Birliklar: 8 + 7 = 15 → 5 yozamiz, 1 o‘nlik eslab qolamiz','O‘nliklar: 5 + 6 + 1 = 12 → 2 yozamiz, 1 yuzlik eslab qolamiz','Yuzliklar: 4 + 3 + 1 = 8. Javob: <b>825</b>']);
var P5=b13Ph(573,318,'−',['Ayirish: birliklardan boshlaymiz','3 dan 8 ayirib bo‘lmaydi: 1 o‘nlik olamiz, 13 − 8 = 5','O‘nliklar: 7 − 1 = 6, 6 − 1 = 5','Yuzliklar: 5 − 3 = 2. Javob: <b>255</b>']);
var P6=b13Ph(700,248,'−',['Tuzoq: 700 da o‘nlik ham, birlik ham yo‘q!','0 dan 8 olmaydi. O‘nlik ham 0 — yuzlikdan olamiz: 7 yuz → 6 yuz + 10 o‘nlik → 9 o‘nlik + 10 birlik. 10 − 8 = 2','O‘nliklar: 9 − 4 = 5','Yuzliklar: 6 − 2 = 4. Javob: <b>452</b>']);
var P8=[function(){bqBar(905,[{v:'378',w:378,col:'#e9e2d6',lab:'berildi'},{v:'?',w:527,q:1,lab:'qoldi'}],{title:'905 ta kitob'});bqMsg('905 ta kitobdan 378 tasi berildi')},
 function(){bqCol(905,378,'−',null);bqMsg('905 − 378 = 527 qoldi')},
 function(){bqCol(527,146,'+',null);bqMsg('146 tasi qaytarildi: 527 + 146 = <b>673</b>')}];
var STEPS=[
{h:"Yuzliklarni qo'shish va ayirish",sum:"300 + 200 = 500: 3 yuz + 2 yuz = 5 yuz. Ayirish ham shunday.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Yuzliklarni <b>oddiy birliklar kabi</b> qo'shamiz: 3 yuz + 2 yuz = 5 yuz.</p>",btns:[phaser(P1)],
 after:"<p>Yuzliklar bilan hisoblash 3 + 2 = 5 kabi oson — faqat oxiriga ikkita nol qo'shiladi.</p>",
 q:{t:"600 + 300 = ?",opts:["900","90","9000","800"],ok:0,why:"6 yuz + 3 yuz = 9 yuz = 900.",hint:"6 + 3 nechaga teng?",full:"6 yuz + 3 yuz = 9 yuz = 900. «90» — nolni yo'qotish."},
 tn:"Pul bilan ko'rsating: 300 so'mlik va 200 so'mlik — 5 ta yuzlik tanga."},
{h:"Og'zaki: xona birliklari bo'yicha",sum:"340 + 25 = 365; 456 − 200 = 256: har bir xona alohida.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ba'zi misollarni yozmasdan, <b>xonalab</b> hisoblash mumkin.</p>",btns:[phaser(P2)],
 after:"<p>Faqat bir xona o'zgarganda (masalan, yuzliklar) qolgan xonalar o'z joyida qoladi.</p>",
 q:{t:"682 − 300 = ?",opts:["382","652","679","982"],ok:0,why:"Yuzliklar: 6 − 3 = 3. Javob 382.",hint:"Qaysi xona o'zgaradi?",full:"682 = 6 yuz 8 o'n 2. 3 yuz ayirsak: 3 yuz 8 o'n 2 = 382. «679» — 3 ni birliklardan ayirish."},
 tn:"Abakus yoki xona jadvalida ko'rsating."},
{h:"Ustunda qo'shish",sum:"324 + 152 = 476: birlik ostida birlik, o'ngdan chapga.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Katta sonlarni <b>ustunda</b> qo'shamiz — ikki xonali sonlardagi kabi, faqat yuzlik ustuni qo'shiladi.</p>",btns:[phaser(P3)],
 after:"<p>Hisoblash har doim <b>birliklardan</b> boshlanadi: birlik → o'nlik → yuzlik.</p>",
 q:{t:"231 + 546 = ?",opts:["777","767","787","677"],ok:0,why:"1+6=7, 3+4=7, 2+5=7.",hint:"Har bir ustunni alohida qo'shing.",full:"Birlik 1+6=7, o'nlik 3+4=7, yuzlik 2+5=7: 777."},
 tn:"Katakli daftarda har raqam alohida katakka yozilsin."},
{h:"Ikki marta o'nlikdan o'tish",sum:"458 + 367 = 825: birlikdan 1 o'nlik, o'nlikdan 1 yuzlik o'tadi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>458 + 367. Bu yerda <b>ikkita</b> eslab qolish bor. Diqqat bilan kuzating:</p>",btns:[phaser(P4)],
 after:"<p>10 dan oshsa — birini yozamiz, «1» ni keyingi xonaga o'tkazamiz. Bu qoida har bir xonada ishlaydi.</p>",
 q:{t:"276 + 158 = ?",opts:["434","324","424","334"],ok:0,why:"6+8=14 (4, 1 o'tadi); 7+5+1=13 (3, 1 o'tadi); 2+1+1=4.",hint:"Eslab qolingan birlarni unutmang.",full:"Birlik 14 → 4; o'nlik 7+5+1 = 13 → 3; yuzlik 2+1+1 = 4. Javob 434. «324» — o'tkazmalarni unutish."},
 tn:"«Eslab qolingan» 1 ni ustunning tepasiga kichik qilib yozishni o'rgating."},
{h:"Ustunda ayirish",sum:"573 − 318 = 255: birlik yetmasa, o'nlikdan 1 ta olamiz.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>573 − 318. Birliklarda 3 − 8 — yetmaydi. Nima qilamiz?</p>",btns:[phaser(P5)],
 after:"<p>Olingan o'nlik ustiga nuqta qo'yamiz — keyingi ustunda uni <b>1 ga kamaytirishni</b> unutmaslik uchun.</p>",
 q:{t:"642 − 271 = ?",opts:["371","431","471","381"],ok:0,why:"2−1=1; 4 dan 7 olmaydi → yuzlikdan: 14−7=7; 6−1−2=3.",hint:"O'nliklarda yuzlikdan olish kerak.",full:"Birlik 2 − 1 = 1; o'nlik 14 − 7 = 7; yuzlik 6 − 1 − 2 = 3. Javob 371. «431» — kichikdan kattani teskari ayirish (7 − 4 = 3)."},
 tn:"Eng ko'p xato: «kichikdan kattani ayirolmaymiz — teskarisini olamiz». Tekshirish bilan buni ushlang: 371 + 271 = 642 ✓."},
{h:"Tuzoq: nollar bor son",sum:"700 − 248 = 452: yuzlikdan olamiz, u 9 o'nlik va 10 birlikka bo'linadi.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>700 − 248. Birlik ham, o'nlik ham — 0. Qayerdan olamiz?</p>",btns:[phaser(P6)],
 after:"<p>700 = 6 yuz + 9 o'nlik + 10 birlik. Shunday «maydalab» olsak, ayirish oson bo'ladi. Tekshiring: 452 + 248 = 700 ✓.</p>",
 q:{t:"500 − 163 = ?",opts:["337","447","347","463"],ok:0,why:"10−3=7; 9−6=3; 4−1=3.",hint:"500 = 4 yuz + 9 o'n + 10 bir.",full:"500 = 4 yuz 9 o'n 10 bir. 10−3=7, 9−6=3, 4−1=3: 337. «463» — teskari ayirish; «447» — yuzlikni kamaytirishni unutish."},
 tn:"100 so'mlikni 10 ta 10 so'mlikka, 10 so'mlikni 10 ta 1 so'mlikka maydalash o'yini."},
{h:"Yashirin raqamlar",sum:"3□7 + 24□ = 625: birliklardan boshlab har xonani tiklaymiz.",a:"m07",
 start:function(){bqExpr(['  3 □ 7','+ 2 4 □','  6 2 5']);bqMsg('Birliklardan boshlaymiz: 7 + □ = …5')},fin:function(){bqExpr(['  3 [7] 7','+ 2 4 [8]','  6 2 5'])},
 html:"<p>Ba'zi raqamlar yashiringan. Birlik ustunini ko'ring: 7 + □ ning birligi 5. Bu raqam qaysi?</p>",
 btns:[["8",function(c,done,b){bqExpr(['  3 □ 7','+ 2 4 [8]','  6 2 5']);bqMsg('To‘g‘ri! 7 + 8 = 15, 1 o‘tadi. O‘nliklar: □ + 4 + 1 = 12 → □ = 7');setTimeout(function(){bqExpr(['  3 [7] 7','+ 2 4 [8]','  6 2 5'])},1400);c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});done()}],["2",function(c,done,b){flashBad(b);bqMsg('7 + 2 = 9, oxiri 5 emas')}],["5",function(c,done,b){flashBad(b);bqMsg('7 + 5 = 12, oxiri 2')}],["−2",function(c,done,b){flashBad(b);bqMsg('Raqam manfiy bo‘lmaydi')}]],g2:1,
 after:"<p>377 + 248 = 625 ✓. Har bir yashirin raqamni topishda <b>o'tkazma</b>ni hisobga olamiz.</p>",
 q:{t:"4□3 + 2□5 = 718. Ikki yashirin raqamning yig'indisi nechaga teng?",opts:["11","1","7","9"],ok:0,why:"Birlik 3+5=8. Yuzlik 4+2=6, lekin javobda 7 — demak o'nlikdan 1 o'tgan: □+□=11.",hint:"Yuzliklarga qarang: 4 + 2 = 6, javobda esa 7.",full:"Birliklar 3 + 5 = 8, o'tkazma yo'q. O'nliklar: □ + □ ning birligi 1. Yuzliklar 4 + 2 = 6, javobda 7 — demak o'nliklardan 1 o'tgan, □ + □ = 11 (masalan 453 + 265 = 718). «1» — o'tkazmani sezmaslik."},
 tn:"Japoniya darsliklaridagi «mushi-kui zan» (qurt yegan misollar) — mantiqni rivojlantiradi."},
{h:"Masala: ikki amal",sum:"905 − 378 = 527; 527 + 146 = 673.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Kutubxonada 905 ta kitob bor edi. 378 tasi o'quvchilarga berildi, keyin 146 tasi qaytarildi. Endi nechta kitob bor?</p>",btns:[phaser(P8)],
 after:"<p>Ifoda: <b>905 − 378 + 146 = 673</b>. Har bir amalni ustunda bajarib, natijani tekshirish mumkin.</p>",
 q:{t:"Bog'da 640 ta daraxt bor edi. 185 tasi kesildi, 230 tasi ekildi. Endi nechta?",opts:["685","225","1055","595"],ok:0,why:"640 − 185 = 455, 455 + 230 = 685.",hint:"Kesilganini ayiring, ekilganini qo'shing.",full:"640 − 185 = 455; 455 + 230 = 685. «225» — ekilganini ham ayirish."},
 tn:"Masalani avval bar model (lenta) bilan chizdiring."},
{h:"Bilasizmi? Sharqona hisob",sum:"Qadimda savdogarlar uch xonali sonlarni cho'tda (abakusda) qo'shgan — har sim bir xona.",a:"m09",
 start:function(){bqCol(458,367,'+',null);bqMsg('Cho‘tda ham xuddi shunday: har sim — bir xona')},fin:function(){bqCol(458,367,'+',null)},
 html:"<p>🧮 Bozorlarda yaqin-yaqingacha <b>cho'tdan</b> foydalanilgan. Har bir simdagi 10 ta tosh: birinchi sim — birliklar, ikkinchisi — o'nliklar, uchinchisi — yuzliklar. 10 tosh to'lsa, keyingi simga <b>bitta</b> tosh suriladi — bu bizning «eslab qolish» qoidamiz!</p>",
 btns:[["🧮 Qiziq!",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Ustunda qo'shish — cho'tning qog'ozdagi ko'rinishi.</p>",
 tn:"Sinfda cho'tingiz bo'lsa, 458 + 367 ni unda ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.ph=3;P4[3]()},fin:function(){S.ph=3;P4[3]()},
 html:"<div class='memo'><ul><li>Xonalar ostma-ost: <b>birlik ostida birlik</b>.</li><li>Hisob <b>birliklardan</b> boshlanadi.</li><li>10 dan oshsa — 1 ni keyingi xonaga o'tkazamiz: 458 + 367 = 825.</li><li>Yetmasa — keyingi xonadan 1 olamiz: 573 − 318 = 255.</li><li>Nollar bo'lsa: 700 = 6 yuz + 9 o'n + 10 bir.</li><li>Tekshirish: 452 + 248 = 700 ✓.</li></ul></div>",
 tn:"Keyingi mavzular: 1000 gacha sonlar, ko'paytirish."}
];
var PROBS=[
{t:"300 + 200 = ?",o:["500","50","5000","100"],k:0,s:"3 yuz + 2 yuz = 5 yuz."},
{t:"700 − 400 = ?",o:["300","30","1100","400"],k:0,s:"7 yuz − 4 yuz = 3 yuz."},
{t:"340 + 25 = ?",o:["365","590","345","375"],k:0,s:"300 + 60 + 5."},
{t:"456 − 200 = ?",o:["256","454","436","656"],k:0,s:"Yuzliklar: 4 − 2 = 2."},
{t:"324 + 152 = ?",o:["476","466","486","376"],k:0,s:"Har ustun alohida."},
{t:"458 + 367 = ?",o:["825","715","815","725"],k:0,s:"Ikki o'tkazma."},
{t:"276 + 158 = ?",o:["434","324","424","334"],k:0,s:"14, 13, 4."},
{t:"573 − 318 = ?",o:["255","265","245","355"],k:0,s:"13 − 8 = 5; 6 − 1 = 5; 5 − 3 = 2."},
{t:"642 − 271 = ?",o:["371","431","471","381"],k:0,s:"Yuzlikdan olish."},
{t:"700 − 248 = ?",o:["452","552","548","462"],k:0,s:"700 = 6 yuz 9 o'n 10 bir."},
{t:"500 − 163 = ?",o:["337","447","463","347"],k:0,s:"4 yuz 9 o'n 10 bir."},
{t:"3□7 + 24□ = 625. Yashirin raqamlar: ",o:["7 va 8","2 va 8","7 va 2","8 va 7"],k:0,s:"377 + 248 = 625."},
{t:"Kutubxonada 905 ta kitob bor edi. 378 tasi berildi, 146 tasi qaytarildi. Endi nechta?",o:["673","381","527","683"],k:0,s:"905 − 378 + 146."},
{t:"Bog'da 640 ta daraxt bor edi. 185 tasi kesildi, 230 tasi ekildi. Endi nechta?",o:["685","225","595","455"],k:0,s:"640 − 185 + 230."},
{t:"Qaysi tekshirish 825 − 367 = 458 ni tasdiqlaydi?",o:["458 + 367 = 825","825 + 367 = 1192","458 − 367 = 91","825 − 458 = 357"],k:0,s:"Ayirma + ayriluvchi = kamayuvchi."},
{t:"Eng katta uch xonali son va eng kichik uch xonali son yig'indisi:",o:["1099","999","1000","1100"],k:0,s:"999 + 100 = 1099."},
{t:"□ − 254 = 368. □ = ?",o:["622","114","612","522"],k:0,s:"368 + 254 = 622."},
{t:"435 + □ = 900. □ = ?",o:["465","575","565","475"],k:0,s:"900 − 435 = 465."},
{t:"Poyezdda 312 yo'lovchi bor edi. Bekatda 87 kishi tushdi, 129 kishi chiqdi. Endi nechta?",o:["354","96","270","528"],k:0,s:"312 − 87 = 225, 225 + 129 = 354."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["398 + 405","999 − 205","412 + 379","1000 − 210"],k:0,s:"803, 794, 791, 790."}
];
function PRACT_STAGE(){S.ph=3;P4[3]();bqMsg('Birliklardan boshlang, o‘tkazmani unutmang')}
var PREP_DATA={teach:["Yuzliklarni qo'shish va ayirish.","Xonalab og'zaki hisoblash.","Ustunda o'tkazmali qo'shish (ikki marta).","Ustunda ayirish, nolli kamayuvchi.","Yashirin raqamlar va masalalar."],
 mist:["Eslab qolingan 1 ni unutadi.","Kichikdan kattani teskari ayiradi (3 − 8 → 5).","Nolli sondan ayirishda yuzlikni kamaytirmaydi.","Xonalarni noto'g'ri tekislaydi."],
 need:["Xona jadvali, cho't yoki 100/10/1 kartochkalar."],
 board:["<span class='w2'>458 + 367 = 825</span>.","<span class='w2'>573 − 318 = 255</span>.","<span class='w2'>700 − 248 = 452</span>.","<span class='w2'>377 + 248 = 625</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
