var CODE='4C6',TITLE='4-sinf · Qoldiqli bo‘lish';
var P1=[function(){W3groups(23,5,{q:0});W3msg('23 ta yong‘oqni 5 tadan qopchalarga solamiz')},
 function(){W3groups(23,5,{q:2,lbl:'2 ta qopcha…'});W3msg('5, 10 …')},
 function(){W3groups(23,5,{q:4,lbl:'4 ta qopcha, 3 ta ortdi'});W3msg('4 ta qopcha to‘ldi, <b>3</b> ta yong‘oq qoldi — beshinchiga yetmaydi')},
 function(){W3eq(['23 : 5 = 4 (qoldiq 3)','23 = 5 · 4 + 3']);W3msg('<b>a = b · q + r</b>, bunda qoldiq <b>r &lt; b</b>')}];
var P2=w4LongPh(4547,6,'4 547 : 6 — oxirida qoldiq chiqadi');
var P4=w4LongPh(2000,37,'2 000 : 37 — ikki xonali bo‘luvchi, qoldiq bilan');
var STEPS=[
{h:"Qoldiq nima?",sum:"23 : 5 = 4 (qoldiq 3), chunki 23 = 5 · 4 + 3 va 3 < 5.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Har doim ham teng bo'linavermaydi. Tugmani bosib kuzating.</p>",btns:[phaser(P1)],
 after:"<p>Bo'linuvchi = bo'luvchi · bo'linma + qoldiq: <b>a = b · q + r</b>. Qoldiq har doim bo'luvchidan <b>kichik</b>: 5 ga bo'lganda qoldiq faqat 0, 1, 2, 3, 4 bo'lishi mumkin.</p>",
 q:{t:"7 ga bo'lganda qanday qoldiqlar bo'lishi mumkin?",opts:["0, 1, 2, 3, 4, 5, 6","1, 2, 3, 4, 5, 6, 7","0 dan 7 gacha","Faqat 0"],ok:0,why:"r < 7.",hint:"Qoldiq bo'luvchidan kichik.",full:"Qoldiq 7 dan kichik: 0, 1, 2, 3, 4, 5, 6 — jami 7 xil. 7 qoldiq bo'lolmaydi — yana bitta guruh chiqadi."},
 tn:"Haqiqiy narsalar (yong'oq, cho'p) bilan guruhlash. «Qolgan narsa yana bir guruhga yetadimi?» — har doim so'rang."},
{h:"Burchakda qoldiq",sum:"4 547 : 6 = 757 (qoldiq 5).",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=P2.length-1;P2[P2.length-1]()},
 html:"<p>Burchakli bo'lishda oxirgi ayirma — qoldiq.</p>",btns:[phaser(P2)],
 after:"<p>Hamma raqamlar tushirilgandan keyin qolgan son — <b>qoldiq</b>. Tekshiruv: 757 · 6 + 5 = 4 542 + 5 = 4 547 ✓</p>",
 q:{t:"3 125 : 4 = ?",opts:["781 (qoldiq 1)","78 (qoldiq 5)","781 (qoldiq 5)","780 (qoldiq 1)"],ok:0,why:"781 · 4 = 3 124, + 1.",hint:"Oxirgi qadamda 5 : 4.",full:"31 : 4 = 7 (q. 3); 32 : 4 = 8; 5 : 4 = 1 (q. 1). Javob 781 (qoldiq 1). «qoldiq 5» — qoldiq bo'luvchidan katta bo'lolmaydi."},
 tn:"Javobni yozish shakli: «781 (qoldiq 1)» yoki «781 q. 1». Bir xil shaklni talab qiling."},
{h:"Tuzoq: qoldiq bo'luvchidan katta",sum:"38 : 7 = 5 (qoldiq 3), «4 (qoldiq 10)» xato — 10 > 7.",a:"m03",start:function(){W3eq(['38 : 7 = ?']);W3msg('Uchta yozuv. Qaysi biri to‘g‘ri?')},fin:function(){W3eq(['38 = 7 · 5 + 3','3 < 7 ✓'])},
 html:"<p><b>38 : 7</b> ni uch bola uch xil yozdi. To'g'risini tanlang:</p>",
 btns:[["5 (qoldiq 3)",function(c,done){W3eq(['38 = 7 · 5 + 3','3 < 7 ✓']);W3msg('To‘g‘ri: 35 + 3 = 38 va 3 &lt; 7');done()}],["4 (qoldiq 10)",function(){W3eq(['7 · 4 + 10 = 38','10 > 7 ✗']);W3msg('Hisob to‘g‘ri, lekin qoldiq 10 &gt; 7 — yana bitta 7 sig‘adi!','Qayta tanlang')}],["6 (qoldiq 4)",function(){W3eq(['7 · 6 = 42 > 38']);W3msg('42 bo‘linuvchidan katta — 6 sig‘maydi','Qayta tanlang')}]],g3:1,
 after:"<p>Ikkala tekshiruv kerak: <b>b · q + r = a</b> va <b>r &lt; b</b>. «4 (qoldiq 10)» birinchisidan o'tadi, ikkinchisidan o'tmaydi.</p>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["60 : 8 = 7 (qoldiq 4)","60 : 8 = 6 (qoldiq 12)","60 : 8 = 7 (qoldiq 6)","60 : 8 = 8 (qoldiq 4)"],ok:0,why:"56 + 4 = 60, 4 < 8.",hint:"8 · 7 = 56.",full:"8 · 7 = 56, 60 − 56 = 4 < 8 ✓. «6 (q. 12)» — 12 > 8. «7 (q. 6)» — 56 + 6 = 62 ≠ 60."},
 tn:"«Qoldiq politsiyasi» o'yini: doskadagi yozuvlardan qoidabuzarlarni topish."},
{h:"Ikki xonali bo'luvchi",sum:"2 000 : 37 = 54 (qoldiq 2).",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=P4.length-1;P4[P4.length-1]()},
 html:"<p>Ikki xonali songa qoldiqli bo'lish.</p>",btns:[phaser(P4)],
 after:"<p>Tekshiruv: 37 · 54 = 1 998, + 2 = 2 000 ✓. Nollar bilan tugaydigan bo'linuvchida ham har bir nol tushiriladi.</p>",
 q:{t:"1 000 : 23 = ?",opts:["43 (qoldiq 11)","43 (qoldiq 1)","44 (qoldiq 12)","4 (qoldiq 108)"],ok:0,why:"23 · 43 = 989, + 11.",hint:"100 : 23 = 4 (q. 8).",full:"100 : 23 = 4 (q. 8); 80 : 23 = 3 (q. 11). Javob 43 (qoldiq 11). Tekshiruv: 989 + 11 = 1 000."},
 tn:"Kalkulyatorsiz tekshiruvni har doim bajarish — 4-sinfning asosiy ko'nikmasi."},
{h:"Masala: yuqoriga yaxlitlash",sum:"250 o'quvchi, 45 o'rinli avtobus: 250 : 45 = 5 (q. 25) → 6 ta avtobus kerak.",a:"m05",start:function(){W3eq(['250 : 45 = 5 (qoldiq 25)']);W3msg('Ekskursiyaga 250 o‘quvchi boradi. Avtobus 45 o‘rinli. Nechta avtobus kerak?')},fin:function(){W3eq(['5 avtobus → 225 kishi','25 kishi qoldi → +1','Javob: [6] avtobus'])},
 html:"<p><b>250</b> o'quvchi, avtobus <b>45</b> o'rinli. Nechta avtobus buyurtma qilish kerak?</p>",
 btns:[["6",function(c,done){W3eq(['5 avtobus → 225 kishi','25 kishi qoldi → +1','Javob: [6] avtobus']);W3msg('Qolgan 25 o‘quvchini uyda qoldirib bo‘lmaydi — yana bitta avtobus!');done()}],["5",function(){W3eq(['45 · 5 = 225 < 250']);W3msg('25 ta bola qayerga o‘tiradi?','Qayta tanlang')}],["25",function(){W3eq(['25 — qoldiq']);W3msg('25 — sig‘may qolgan bolalar soni, avtobuslar emas','Qayta tanlang')}]],g3:1,
 after:"<p>Masalada qoldiq bilan nima qilish — <b>savolga bog'liq</b>: hammasini joylash kerak bo'lsa, bo'linmaga <b>1 qo'shamiz</b>.</p>",
 q:{t:"Bir qutiga 12 ta tuxum sig'adi. 100 ta tuxum uchun nechta quti kerak?",opts:["9","8","4","12"],ok:0,why:"100 : 12 = 8 (q. 4) → 9.",hint:"Qolgan 4 ta tuxum ham qutiga kerak.",full:"100 : 12 = 8 (qoldiq 4). 8 quti 96 ta tuxumni oladi, qolgan 4 ta uchun yana bitta quti: 9. «4» — qoldiq."},
 tn:"Bu — xalqaro testlarda (PISA, TIMSS) eng ko'p xato qilinadigan tur. Har masalada «Qoldiq bilan nima qilamiz?» deb so'rang."},
{h:"Masala: pastga va qoldiqning o'zi",sum:"10 000 so'mga 3 000 so'mlik kitob: 3 ta (1 000 so'm qoladi). 100 kundan keyin: 100 : 7 = 14 (q. 2).",a:"m06",start:function(){W3eq(['Bugun — dushanba','100 kundan keyin — ?']);W3msg('Qoldiq ba‘zan javobning o‘zi bo‘ladi')},fin:function(){W3eq(['100 : 7 = 14 (qoldiq 2)','dushanba + 2 = [chorshanba]'])},
 html:"<p>Bugun <b>dushanba</b>. <b>100 kundan</b> keyin haftaning qaysi kuni bo'ladi?</p>",
 btns:[["Chorshanba",function(c,done){W3eq(['100 : 7 = 14 (qoldiq 2)','dushanba + 2 = [chorshanba]']);W3msg('14 to‘liq hafta — yana dushanba. Qoldiq 2: seshanba, <b>chorshanba</b>');done()}],["Dushanba",function(){W3eq(['100 : 7 = 14 (q. 2)']);W3msg('14 hafta — dushanba, lekin yana 2 kun bor!','Qayta tanlang')}],["Seshanba",function(){W3eq(['dushanba + 1 = seshanba']);W3msg('Qoldiq 2, 1 emas','Qayta tanlang')}]],g3:1,
 after:"<p>Qoldiq bilan uch xil holat: <b>1)</b> bo'linmaga 1 qo'shiladi (avtobus); <b>2)</b> qoldiq tashlanadi (10 000 so'mga 3 000 so'mlik kitobdan 3 ta); <b>3)</b> javob — qoldiqning o'zi (hafta kuni).</p>",
 q:{t:"Ali 10 000 so'mga 1 300 so'mlik daftarlar olmoqchi. Ko'pi bilan nechta daftar oladi?",opts:["7","8","6","9"],ok:0,why:"10 000 : 1 300 = 7 (q. 900).",hint:"Qolgan pulga daftar yetadimi?",full:"1 300 · 7 = 9 100, qoldiq 900 so'm — yana bitta daftarga yetmaydi. Javob 7. «8» — 10 400 so'm kerak bo'lardi."},
 tn:"Uch holatni uch rangli kartochkaga yozdiring: «+1», «tashla», «qoldiq — javob»."},
{h:"Tuzoq: eng katta bo'linuvchi",sum:"5 ga bo'lganda bo'linma 12 bo'ladigan eng katta son: 5 · 12 + 4 = 64.",a:"m07",start:function(){W3eq(['□ : 5 = 12 (qoldiq ?)']);W3msg('□ ning eng katta qiymati qancha?')},fin:function(){W3eq(['eng katta qoldiq = 4','5 · 12 + 4 = [64]'])},
 html:"<p>Son 5 ga bo'linganda bo'linma <b>12</b> chiqadi. Bu sonning <b>eng katta</b> qiymati qancha?</p>",
 btns:[["64",function(c,done){W3eq(['eng katta qoldiq = 4','5 · 12 + 4 = [64]']);W3msg('Qoldiq eng ko‘pi <b>4</b> (5 dan kichik). 60 + 4 = 64');done()}],["65",function(){W3eq(['65 : 5 = 13']);W3msg('65 da bo‘linma 13 bo‘lib ketdi','Qayta tanlang')}],["60",function(){W3eq(['60 : 5 = 12 (q. 0)']);W3msg('Bu — eng kichigi. 61, 62, 63, 64 da ham bo‘linma 12','Qayta tanlang')}]],g3:1,
 after:"<p>Bo'linma q, bo'luvchi b bo'lsa: eng kichik son <b>b · q</b>, eng katta son <b>b · q + (b − 1)</b>. Bunday sonlar b ta: 60, 61, 62, 63, 64.</p>",
 q:{t:"8 ga bo'lganda bo'linma 25 chiqadigan sonlar nechta?",opts:["8","7","25","9"],ok:0,why:"200, 201, …, 207.",hint:"Qoldiq 0 dan 7 gacha.",full:"200 dan (q. 0) 207 gacha (q. 7) — jami 8 ta son. 208 da bo'linma 26 bo'lib qoladi."},
 tn:"Bu tur olimpiadalarda tez-tez uchraydi. Son o'qida 60–64 ni bir rangga bo'yatib ko'rsating."},
{h:"Qoldiqli tenglama",sum:"□ : 9 = 47 (qoldiq 5) → □ = 9 · 47 + 5 = 428.",a:"m08",start:function(){W3eq(['□ : 9 = 47 (qoldiq 5)']);W3msg('Bo‘linuvchini topamiz')},fin:function(){W3eq(['□ = 9 · 47 + 5','□ = 423 + 5 = [428]'])},
 html:"<p><b>□ : 9 = 47 (qoldiq 5)</b>. □ = ?</p>",
 btns:[["428",function(c,done){W3eq(['□ = 9 · 47 + 5','□ = 423 + 5 = [428]']);W3msg('a = b · q + r: 9 · 47 + 5 = <b>428</b>');done()}],["423",function(){W3eq(['423 : 9 = 47 (q. 0)']);W3msg('Qoldiq qo‘shilmagan','Qayta tanlang')}],["418",function(){W3eq(['9 · 47 − 5 = 418']);W3msg('Qoldiq ayirilmaydi, qo‘shiladi','Qayta tanlang')}]],g3:1,
 after:"<p>Formula bilan: <b>a = b · q + r</b>. Tekshiruv: 428 : 9 = 47 (qoldiq 5) ✓</p>",
 q:{t:"□ : 15 = 62 (qoldiq 14). □ = ?",opts:["944","930","916","944 (q. 14)"],ok:0,why:"15 · 62 + 14.",hint:"930 + 14.",full:"15 · 62 = 930, + 14 = 944. Tekshiruv: 944 : 15 = 62 (q. 14)."},
 tn:"Formulani doskaning burchagida doim yozib qo'ying."},
{h:"Bilasizmi? Kalendar va qoldiq",sum:"365 : 7 = 52 (qoldiq 1) — shuning uchun oddiy yilda tug'ilgan kuningiz har yili haftaning keyingi kuniga suriladi.",a:"m09",start:function(){W3eq(['365 : 7 = 52 (qoldiq 1)','366 : 7 = 52 (qoldiq 2)'],{fs:20});W3msg('Kabisa yilida — 2 kunga suriladi')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Oddiy yilda <b>365</b> kun: 365 : 7 = 52 hafta va <b>1</b> kun qoladi. Shuning uchun tug'ilgan kuningiz har yili haftaning <b>keyingi</b> kuniga to'g'ri keladi (masalan, bu yil seshanba bo'lsa, keyingi yil chorshanba).</p><p>⭐ Kabisa yilida (366 kun) qoldiq <b>2</b> — kun ikki pog'ona suriladi.</p>",
 tn:"Bolalar o'z tug'ilgan kunining keyingi yili qaysi kunga tushishini hisoblasin (kabisa yilni ham hisobga olib)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3eq(['a = b · q + r','r < b'],{fs:24})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>a = b · q + r</b>, qoldiq <b>r &lt; b</b>.</li><li>4 547 : 6 = 757 (q. 5); tekshiruv 757 · 6 + 5.</li><li>Masalada qoldiq: <b>+1</b> (avtobus), <b>tashla</b> (pulga nechta), <b>qoldiq — javob</b> (hafta kuni).</li><li>Bo'linma q bo'ladigan sonlar: b · q dan b · q + b − 1 gacha.</li><li>□ : 9 = 47 (q. 5) → □ = 9 · 47 + 5.</li></ul></div>",
 tn:"Keyingi mavzu: ko'paytirish va bo'lish xossalari."}
];
var PROBS=[
{t:"47 : 6 = ?",o:["7 (qoldiq 5)","7 (qoldiq 1)","6 (qoldiq 11)","8 (qoldiq 1)"],k:0,s:"42 + 5."},
{t:"1 234 : 5 = ?",o:["246 (qoldiq 4)","246 (qoldiq 1)","24 (qoldiq 34)","247 (qoldiq 1)"],k:0,s:"246 · 5 = 1 230."},
{t:"5 003 : 8 = ?",o:["625 (qoldiq 3)","625 (qoldiq 8)","62 (qoldiq 3)","626 (qoldiq 5)"],k:0,s:"625 · 8 = 5 000."},
{t:"7 777 : 9 = ?",o:["864 (qoldiq 1)","864 (qoldiq 7)","86 (qoldiq 4)","863 (qoldiq 10)"],k:0,s:"864 · 9 = 7 776."},
{t:"3 000 : 26 = ?",o:["115 (qoldiq 10)","115 (qoldiq 1)","11 (qoldiq 14)","116 (qoldiq 6)"],k:0,s:"26 · 115 = 2 990."},
{t:"9 999 : 50 = ?",o:["199 (qoldiq 49)","199 (qoldiq 9)","200 (qoldiq 1)","19 (qoldiq 49)"],k:0,s:"50 · 199 = 9 950."},
{t:"Qaysi yozuv XATO?",o:["85 : 9 = 8 (qoldiq 13)","85 : 9 = 9 (qoldiq 4)","85 = 9 · 9 + 4","9 · 9 < 85"],k:0,s:"13 > 9 — qoldiq bo'luvchidan katta."},
{t:"6 ga bo'lganda eng katta qoldiq qancha bo'lishi mumkin?",o:["5","6","1","0"],k:0,s:"r < 6."},
{t:"□ : 7 = 125 (qoldiq 6). □ = ?",o:["881","875","869","131"],k:0,s:"875 + 6."},
{t:"□ : 24 = 30 (qoldiq 23). □ = ?",o:["743","720","697","53"],k:0,s:"720 + 23."},
{t:"9 ga bo'lganda bo'linma 11 bo'ladigan eng katta son?",o:["107","108","99","100"],k:0,s:"99 + 8."},
{t:"4 ga bo'lganda bo'linma 50 chiqadigan sonlar nechta?",o:["4","3","5","50"],k:0,s:"200, 201, 202, 203."},
{t:"Qayiqqa 6 kishi sig'adi. 45 turistni o'tkazish uchun qayiq kamida necha marta qatnashi kerak?",o:["8","7","3","9"],k:0,s:"45 : 6 = 7 (q. 3) → 8."},
{t:"1 metr lentadan 15 sm li bo'laklar kesildi. Nechta to'liq bo'lak chiqadi?",o:["6","7","10","5"],k:0,s:"100 : 15 = 6 (q. 10)."},
{t:"Bugun shanba. 50 kundan keyin haftaning qaysi kuni?",o:["Yakshanba","Shanba","Juma","Dushanba"],k:0,s:"50 : 7 = 7 (q. 1)."},
{t:"Sinfda 29 o'quvchi. Ular 4 kishilik guruhlarga bo'linsa, nechta guruh to'liq bo'ladi va nechta o'quvchi ortadi?",o:["7 guruh, 1 o'quvchi","8 guruh, 3 o'quvchi","7 guruh, 3 o'quvchi","6 guruh, 5 o'quvchi"],k:0,s:"4 · 7 = 28."},
{t:"Bir son 5 ga bo'linganda qoldiq 3. Shu sonni 2 ga ko'paytirib 5 ga bo'lsak, qoldiq qancha?",o:["1","3","6","0"],k:0,s:"Masalan 8 · 2 = 16, 16 : 5 = 3 (q. 1)."},
{t:"Qatorda 2, 5, 8, 2, 5, 8, … takrorlanadi. 100-son qaysi?",o:["2","5","8","1"],k:0,s:"100 : 3 = 33 (q. 1) — 1-o'rin: 2."},
{t:"Do'kon 1 000 ta olmani 6 tadan paketlarga soldi va har paketni 2 500 so'mdan sotdi. Barcha to'liq paketlardan necha so'm tushadi?",o:["415 000","417 500","416 000","2 500"],k:0,s:"1 000 : 6 = 166 (q. 4); 166 · 2 500."},
{t:"a : 6 = 13 (qoldiq 4) bo'lsa, a : 3 = ?",o:["27 (qoldiq 1)","26 (qoldiq 4)","13 (qoldiq 2)","27 (qoldiq 0)"],k:0,s:"a = 82; 82 : 3 = 27 (q. 1)."}
];
function PRACT_STAGE(){W3eq(['a = b · q + r','r < b'],{fs:24})}
var PREP_DATA={teach:["Qoldiq ma'nosi: a = b · q + r, r < b.","Burchakli bo'lishda qoldiq (bir va ikki xonali bo'luvchi).","Tekshiruv: b · q + r = a.","Masalada qoldiqni talqin qilish (+1, tashlash, qoldiqning o'zi).","Qoldiqli tenglama va 'eng katta son' masalalari."],
 mist:["Qoldiq bo'luvchidan katta: 38 : 7 = 4 (q. 10).","Avtobus masalasida 5 deb javob beradi (qoldiqni unutadi).","□ : 9 = 47 (q. 5) da qoldiqni qo'shmaydi.","Hafta kuni masalasida 14 to'liq haftani sanab adashadi."],
 need:["Yong'oq yoki cho'plar.","Kalendar varag'i."],
 board:["<span class='w2'>a = b · q + r, r &lt; b</span>","<span class='w2'>4 547 : 6 = 757 (q. 5)</span>","<span class='w2'>250 : 45 = 5 (q. 25) → 6</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
