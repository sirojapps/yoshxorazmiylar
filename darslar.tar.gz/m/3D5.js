var CODE='3D5',TITLE='3-sinf · Koordinata nuri: taqqoslash, qo‘shish-ayirish, masalalar';
function d5Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
function d5Tap(from,to,ok,marks,okLab,msg,done,okMsg,o){o=o||{};function draw(bad){var m=marks.slice();if(bad!=null)m.push([bad,'?',C.bad]);w3Ray(from,to,1,m,{all:o.all,every:o.every,tap:tap});if(o.extra)o.extra()}
 function tap(v){if(v===ok){w3Ray(from,to,1,marks.concat([[ok,okLab,C.ok]]),{all:o.all,every:o.every});if(o.extra)o.extra();w3Msg(okMsg);done()}else{draw(v);w3Msg(msg(v));setTimeout(function(){draw()},1200)}}draw()}
var P4=[function(){w3Ray(0,15,1,[[7,'7',C.blue]],{all:1});w3Msg('7 + 5: 7 nuqtadan boshlaymiz')},
 function(){w3Ray(0,15,1,[[7,'',C.blue],[12,'12',C.ok]],{all:1});w3Jump(7,12,'+5',C.ok);w3Msg('+5 — o‘ngga 5 birlik sakraymiz')},
 function(){w3Ray(0,15,1,[[7,'',C.blue],[12,'12',C.ok]],{all:1});for(var i=7;i<12;i++)w3Jump(i,i+1,'',C.ok,100,12);w3Msg('Birma-bir: 8, 9, 10, 11, <b>12</b>. 7 + 5 = 12')}];
var P5=[function(){w3Ray(0,15,1,[[12,'12',C.blue]],{all:1});w3Msg('12 − 4: 12 nuqtadan boshlaymiz')},
 function(){w3Ray(0,15,1,[[12,'',C.blue],[8,'8',C.bad]],{all:1});w3Jump(12,8,'−4',C.bad);w3Msg('−4 — chapga 4 birlik')},
 function(){w3Ray(0,15,1,[[12,'',C.blue],[8,'8',C.bad]],{all:1});for(var i=12;i>8;i--)w3Jump(i,i-1,'',C.bad,100,12);w3Msg('11, 10, 9, <b>8</b>. 12 − 4 = 8')}];
var P8=[function(){w3Ray(0,12,1,[[0,'🤖',C.blue]],{all:1});w3Msg('Robot 0 da. Buyruqlar: +5, −3, +6')},
 function(){w3Ray(0,12,1,[[5,'🤖',C.blue]],{all:1});w3Jump(0,5,'+5',C.ok);w3Msg('+5 → 0 + 5 = <b>5</b>')},
 function(){w3Ray(0,12,1,[[2,'🤖',C.blue]],{all:1});w3Jump(5,2,'−3',C.bad);w3Msg('−3 → 5 − 3 = <b>2</b>')},
 function(){w3Ray(0,12,1,[[8,'🤖',C.blue]],{all:1});w3Jump(2,8,'+6',C.ok);w3Msg('+6 → 2 + 6 = <b>8</b>')},
 function(){w3Ray(0,12,1,[[8,'🤖 8',C.ok]],{all:1});w3Msg('Qisqa yo‘l: 0 + 5 − 3 + 6 = <b>8</b> — bitta ifoda!')}];
function d5Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Koordinata nuri: nuqtani joylashtiramiz",sum:"Koordinata nuri: boshlanish nuqtasi O(0), birlik kesma, yo'nalish. A(4) — 0 dan 4 birlik o'ngda.",a:"m01",
 start:function(){w3Ray(0,10,1,[[0,'O',C.blue]],{all:1});w3Msg('A(4) nuqtani son nurida bosing')},fin:function(){w3Ray(0,10,1,[[0,'O',C.blue],[4,'A(4)',C.ok]],{all:1});w3Msg('A(4) — O dan 4 birlik kesma o‘ngda')},
 html:"<p><b>Koordinata nuri</b> — boshlanish nuqtasi <b>O(0)</b>, teng <b>birlik kesmalar</b> va strelka (yo'nalish) belgilangan nur. Nuqtaning <b>koordinatasi</b> — O dan necha birlik uzoqda turgani. <b>A(4)</b> ni bosing:</p>",
 act:function(c,done){d5Tap(0,10,4,[[0,'O',C.blue]],'A(4)',function(v){return v===0?'Bu O — boshlanish nuqtasi':v===5?'5-chiziq — 4 ta kesmani emas, 5 ta chiziqni sanadingiz. 0 dan boshlab kesmalarni sanang':'Bu '+v+' — A(4) emas'},done,'To‘g‘ri: A(4)')},
 after:"<p>Kesmalarni sanaymiz, chiziqlarni emas! O(0) dan 1-kesma oxiri — 1, 4-kesma oxiri — 4. Yozuv: <b>A(4)</b> — «A nuqta, koordinatasi 4».</p>",
 q:{t:"B(7) nuqta O dan necha birlik kesma uzoqda?",opts:["7","6","8","0"],ok:0,why:"Koordinata — O dan masofa.",hint:"Koordinata nima bildiradi?",full:"B(7) — O dan 7 birlik kesma. «8» — chiziqlarni (0 bilan birga) sanash xatosi."},
 tn:"Sinf polida lenta bilan nur chizing: «Siz A(4) ga turing» o'yini."},
{h:"Masshtab: birlik kesma 10 yoki 100 bo'lsa",sum:"Har bo'linma 10 ga teng bo'lsa, 7-bo'linma — 70. 100 ga teng bo'lsa — 700.",a:"m02",
 start:function(){w3Ray(0,100,10,[[70,'?',C.bad]],{all:1});w3Msg('Har bo‘linma 10. «?» nuqtaning koordinatasi?')},fin:function(){w3Ray(0,100,10,[[70,'70',C.ok]],{all:1});w3Msg('7 ta bo‘linma · 10 = <b>70</b>')},
 html:"<p>Katta sonlar uchun birlik kesmani <b>10</b> yoki <b>100</b> deb olamiz. Bu nurda har bo'linma 10 ga teng. «?» nuqtaning koordinatasi qancha?</p><div class='digs w3c'></div>",
 act:function(c,done){d5Sel(c,'.w3c',['7','70','700'],'70',function(){w3Ray(0,100,10,[[70,'70',C.ok]],{all:1});w3Msg('7 ta bo‘linma · 10 = <b>70</b>');done()},{'7':'7 — bo‘linmalar soni. Har biri 10 ga teng!','700':'Har bo‘linma 100 emas, 10'})},
 after:"<p>Koordinata = bo'linmalar soni · bitta bo'linma qiymati. Avval nurdagi <b>yozuvlarga</b> qarang: qadam 1, 10, 100 yoki boshqa son bo'lishi mumkin (masalan 5).</p>",
 q:{t:"Nurda har bo'linma 100 ga teng. Nuqta 4-bo'linmada. Koordinatasi?",opts:["400","4","40","104"],ok:0,why:"4 · 100 = 400.",hint:"Bo'linmalar soni · qadam.",full:"4 · 100 = 400. «4» — faqat bo'linmalar soni, «40» — qadam 10 deb o'ylash."},
 tn:"Termometr va o'lchov lentasi — masshtabli nurning hayotiy misollari."},
{h:"Taqqoslash: o'ngdagi son katta",sum:"Koordinata nurida o'ngdagi nuqtaning koordinatasi katta: D(8) < C(13).",a:"m03",
 start:function(){w3Ray(0,15,1,[[13,'C',C.u],[8,'D',C.blue]],{all:1});w3Msg('Qaysi nuqtaning koordinatasi katta?')},fin:function(){w3Ray(0,15,1,[[13,'C(13)',C.ok],[8,'D(8)',C.blue]],{all:1});w3Msg('C o‘ngda → 13 > 8')},
 html:"<p>Nurda C va D nuqtalar. Qaysi birining koordinatasi <b>katta</b>?</p><div class='digs w3c'></div>",
 act:function(c,done){d5Sel(c,'.w3c',['C','D'],'C',function(){w3Ray(0,15,1,[[13,'C(13)',C.ok],[8,'D(8)',C.blue]],{all:1});w3Msg('C o‘ngroqda: <b>13 > 8</b>');done()},{'D':'D chaproqda — u O ga yaqin, demak kichik'})},
 after:"<p>Qoida: nur bo'ylab <b>o'ngga</b> yursak, sonlar <b>kattalashadi</b>. Shuning uchun ikki sonni taqqoslash — ularning nurdagi o'rnini solishtirish.</p>",
 q:{t:"M(23), N(32), K(19), O(0). Qaysi nuqta eng o'ngda?",opts:["N(32)","M(23)","K(19)","O(0)"],ok:0,why:"32 — eng katta koordinata.",hint:"Eng katta son eng o'ngda.",full:"32 > 23 > 19 > 0, demak N eng o'ngda. «M(23)» — 23 va 32 raqamlarini adashtirish."},
 tn:"Sinfdagi «tirik nur»: bolalar kartochkadagi sonlariga qarab saf tortsin."},
{h:"Qo'shish — o'ngga sakrash",sum:"7 + 5: 7 dan o'ngga 5 birlik → 12.",a:"m04",
 start:function(){startPh(P4)},fin:d5Fin(P4),
 html:"<p>Koordinata nurida qo'shish — <b>o'ngga</b> sakrash. Bosib kuzating:</p>",btns:[phaser(P4)],
 after:"<p>7 + 5 = <b>12</b>. Katta sakrash ham, birlik sakrashlar ham bir joyga olib keladi. Bu — Gollandiyada «bo'sh son nuri» usuli.</p>",
 q:{t:"Chigirtka 7 nuqtada edi, o'ngga 5 birlik sakradi. Endi qayerda?",opts:["12","2","13","75"],ok:0,why:"7 + 5 = 12.",hint:"O'ngga — qo'shish.",full:"7 + 5 = 12. «2» — chapga sakrash (ayirish), «13» — 7 ni ham sanab qo'yish."},
 tn:"Bo'sh nur chizib, sakrashlarni yoylar bilan ko'rsating (sonlar yozilmagan nur — RME)."},
{h:"Ayirish — chapga sakrash",sum:"12 − 4: 12 dan chapga 4 birlik → 8.",a:"m05",
 start:function(){startPh(P5)},fin:d5Fin(P5),
 html:"<p>Ayirish — <b>chapga</b> sakrash:</p>",btns:[phaser(P5)],
 after:"<p>12 − 4 = <b>8</b>. Diqqat: chapga sakrashda 0 dan o'tib bo'lmaydi — koordinata nuri 0 dan boshlanadi.</p>",
 q:{t:"D(20) nuqtadan 7 birlik chapda qaysi nuqta?",opts:["13","27","14","3"],ok:0,why:"20 − 7 = 13.",hint:"Chapga — ayirish.",full:"20 − 7 = 13. «27» — o'ngga sakrash; «14» — 20 ning o'zini ham sanash."},
 tn:"«Lift» metaforasi: yuqoriga (+), pastga (−)."},
{h:"Ikki nuqta orasidagi masofa",sum:"A(3) va B(11) orasidagi masofa: 11 − 3 = 8 birlik.",a:"m06",
 start:function(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u]],{all:1});w3Msg('A va B orasida necha birlik?')},fin:function(){w3Ray(0,12,1,[[3,'A(3)',C.blue],[11,'B(11)',C.u]],{all:1});w3Jump(3,11,'8 birlik',C.ok,100,30);w3Msg('AB = 11 − 3 = <b>8</b>')},
 html:"<p><b>A(3)</b> va <b>B(11)</b>. Ular orasidagi masofa necha birlik kesma?</p><div class='digs w3c'></div>",
 act:function(c,done){d5Sel(c,'.w3c',['14','8','9'],'8',function(){w3Ray(0,12,1,[[3,'A(3)',C.blue],[11,'B(11)',C.u]],{all:1});w3Jump(3,11,'8 birlik',C.ok,100,30);w3Msg('Katta koordinatadan kichigini ayiramiz: 11 − 3 = <b>8</b>');done()},{'14':'14 = 3 + 11 — qo‘shish emas, ayirish kerak','9':'Chiziqlarni sanadingiz (3 dan 11 gacha 9 ta chiziq). Kesmalar — 8 ta'})},
 after:"<p>Masofa = <b>katta koordinata − kichik koordinata</b>. Tuzoq: chiziqlarni sanash (9 ta) — kesmalar har doim bittaga kam.</p>",
 q:{t:"A(15) va B(42) orasidagi masofa?",opts:["27","57","37","42"],ok:0,why:"42 − 15 = 27.",hint:"Katta − kichik.",full:"42 − 15 = 27. «57» — qo'shish xatosi, «37» — ayirishda o'tish xatosi."},
 tn:"Chizg'ich — tayyor koordinata nuri: 3 sm dan 11 sm gacha qalam uzunligini o'lchash."},
{h:"O'rtadagi nuqta",sum:"A(3) va B(11) ning o'rtasi: masofa 8, yarmi 4 → 3 + 4 = 7.",a:"m07",
 start:function(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u]],{all:1});w3Msg('A va B ning o‘rtasini bosing')},fin:function(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u],[7,'M(7)',C.ok]],{all:1});w3Jump(3,7,'4',C.ok,100,26);w3Jump(7,11,'4',C.ok,100,26);w3Msg('M(7): A dan ham, B dan ham 4 birlik')},
 html:"<p>A(3) va B(11) ning <b>aynan o'rtasidagi</b> nuqtani bosing:</p>",
 act:function(c,done){d5Tap(0,12,7,[[3,'A',C.blue],[11,'B',C.u]],'M(7)',function(v){var a=Math.abs(v-3),b=Math.abs(11-v);return 'A gacha '+a+', B gacha '+b+' — teng emas'},function(){w3Jump(3,7,'4',C.ok,100,26);w3Jump(7,11,'4',C.ok,100,26);done()},'M(7): A dan ham, B dan ham <b>4</b> birlik',{all:1})},
 after:"<p>Usul: 1) masofa 11 − 3 = 8, 2) yarmi 8 : 2 = 4, 3) A dan o'ngga 4: 3 + 4 = <b>7</b>. Qisqa yo'l: (3 + 11) : 2 = 7.</p>",
 q:{t:"A(20) va B(60) ning o'rtasidagi nuqta koordinatasi?",opts:["40","80","30","20"],ok:0,why:"(20 + 60) : 2 = 40.",hint:"Masofaning yarmini A ga qo'shing.",full:"Masofa 40, yarmi 20, 20 + 20 = 40. «20» — faqat masofaning yarmi (nuqta emas), «80» — yig'indi."},
 tn:"Ip bilan: A va B ni bog'lab, ipni ikki buklab o'rtani toping."},
{h:"Robot buyruqlari: bir necha sakrash",sum:"Robot 0 dan: +5, −3, +6 → 8. Bitta ifoda: 0 + 5 − 3 + 6 = 8.",a:"m08",
 start:function(){startPh(P8)},fin:d5Fin(P8),
 html:"<p>Robot koordinata nurida buyruqlarni bajaradi. Har bosishda bitta buyruq:</p>",btns:[phaser(P8)],
 after:"<p>Robot <b>8</b> da to'xtadi. Bir nechta sakrash — bitta ifoda: chapdan o'ngga hisoblaymiz. Olimpiadada: «Robot 10 dan −4, −4, +7 bajardi» → 10 − 4 − 4 + 7 = 9.</p>",
 q:{t:"Robot 10 da. Buyruqlar: −4, −4, +7. Qayerda to'xtaydi?",opts:["9","25","1","17"],ok:0,why:"10 − 4 − 4 + 7 = 9.",hint:"Chapdan o'ngga: 10 − 4 = 6, …",full:"6 → 2 → 9. «25» — hammasini qo'shish, «1» — 7 ni ham ayirish."},
 tn:"Juftlikda: biri buyruq kartochkalarini oladi, ikkinchisi polda yuradi."},
{h:"Bilasizmi? Dekart va koordinatalar",sum:"Koordinatalar usulini fransuz olimi Rene Dekart 1637-yilda «Geometriya» asarida bayon qilgan.",a:"m09",
 start:function(){w3Ray(0,10,1,[[0,'O',C.blue],[4,'A(4)',C.ok]],{all:1});w3Msg('Son — joy, joy — son')},fin:function(){w3Ray(0,10,1,[[0,'O',C.blue],[4,'A(4)',C.ok]],{all:1});w3Msg('Son — joy, joy — son')},
 html:"<p>📜 Fransuz faylasufi va matematigi <b>Rene Dekart</b> 1637-yilda «Geometriya» asarida nuqtaning o'rnini <b>sonlar</b> bilan belgilash g'oyasini bayon qilgan. Shuning uchun koordinatalar ko'pincha <b>«Dekart koordinatalari»</b> deyiladi.</p><p>🗺️ Bugun xaritalar, GPS, kompyuter o'yinlari va robotlar aynan shu g'oya bilan ishlaydi.</p>",
 tn:"Keyingi mavzu — koordinata burchagi: ikkita nur, ikkita son (shaxmat taxtasi kabi)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u]],{all:1});w3Jump(3,11,'11 − 3 = 8',C.ok,100,30);w3Msg('O‘ngga — katta')},fin:function(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u]],{all:1});w3Jump(3,11,'11 − 3 = 8',C.ok,100,30);w3Msg('O‘ngga — katta')},
 html:"<div class='memo'><ul><li>Koordinata nuri: O(0), birlik kesma, yo'nalish.</li><li>A(4) — O dan 4 kesma; kesmalarni sanang, chiziqlarni emas.</li><li>Masshtab: koordinata = bo'linmalar · qadam.</li><li>O'ngdagi son katta; + o'ngga, − chapga.</li><li>Masofa = katta − kichik; o'rta = (a + b) : 2.</li></ul></div>",
 tn:"Daftarga 1 katak = 1 birlik qilib nur chizish odatini shakllantiring."}
];
var PROBS=[
{t:"A(6) nuqta O dan necha birlik kesma uzoqda?",o:["6","5","7","0"],k:0,s:"Koordinata — O dan masofa."},
{t:"Nurda har bo'linma 10. Nuqta 4-bo'linmada. Koordinatasi?",o:["40","4","14","400"],k:0,s:"4 · 10 = 40."},
{t:"Nurda har bo'linma 100. Nuqta 7-bo'linmada. Koordinatasi?",o:["700","7","70","107"],k:0,s:"7 · 100 = 700."},
{t:"M(23), N(32), K(19), O(0). Qaysi nuqta eng o'ngda?",o:["N(32)","M(23)","K(19)","O(0)"],k:0,s:"32 — eng katta."},
{t:"7 nuqtadan o'ngga 5 birlik sakraldi. Qayerga tushildi?",o:["12","2","75","13"],k:0,s:"7 + 5 = 12."},
{t:"12 nuqtadan chapga 4 birlik sakraldi. Qayerga tushildi?",o:["8","16","3","9"],k:0,s:"12 − 4 = 8."},
{t:"A(3) va B(11) orasidagi masofa?",o:["8","14","11","9"],k:0,s:"11 − 3 = 8."},
{t:"A(15) va B(42) orasidagi masofa?",o:["27","57","37","42"],k:0,s:"42 − 15 = 27."},
{t:"A(3) va B(11) ning o'rtasidagi nuqta?",o:["7","8","4","14"],k:0,s:"(3 + 11) : 2 = 7."},
{t:"A(20) va B(60) ning o'rtasidagi nuqta?",o:["40","80","30","20"],k:0,s:"(20 + 60) : 2 = 40."},
{t:"Robot 0 da: +5, −3, +6. Qayerda to'xtaydi?",o:["8","14","2","11"],k:0,s:"0 + 5 − 3 + 6 = 8."},
{t:"Robot 10 da: −4, −4, +7. Qayerda to'xtaydi?",o:["9","25","1","17"],k:0,s:"10 − 4 − 4 + 7 = 9."},
{t:"B nuqta A(9) dan 6 birlik o'ngda. B ning koordinatasi?",o:["15","3","54","16"],k:0,s:"9 + 6 = 15."},
{t:"C nuqta D(20) dan 7 birlik chapda. C ning koordinatasi?",o:["13","27","14","3"],k:0,s:"20 − 7 = 13."},
{t:"A(8) dan 5 birlik uzoqlikdagi nuqtalar?",o:["3 va 13","faqat 13","faqat 3","5 va 8"],k:0,s:"8 − 5 = 3 va 8 + 5 = 13 — ikki tomonda."},
{t:"O(0) va P(25) orasida nechta birlik kesma bor?",o:["25","26","24","5"],k:0,s:"25 − 0 = 25."},
{t:"A(14). B nuqta O dan A ga qaraganda 3 marta uzoqroq. B ning koordinatasi?",o:["42","17","11","44"],k:0,s:"14 · 3 = 42."},
{t:"C(4) va D(16) orasida (ularsiz) nechta butun koordinatali nuqta bor?",o:["11","12","13","20"],k:0,s:"5 dan 15 gacha: 15 − 5 + 1 = 11."},
{t:"Chigirtka 0 dan har gal 3 birlik o'ngga sakraydi. Necha sakrashda 27 ga yetadi?",o:["9","27","24","30"],k:0,s:"27 : 3 = 9."},
{t:"Ali 24 da, Vali 40 da turibdi. Ular o'rtada uchrashishdi. Uchrashuv nuqtasi?",o:["32","64","16","8"],k:0,s:"(24 + 40) : 2 = 32."}
];
function PRACT_STAGE(){w3Ray(0,12,1,[[3,'A',C.blue],[11,'B',C.u]],{all:1});w3Msg('O‘ngga — katta')}
var PREP_DATA={teach:["Koordinata nuri: boshlanish nuqtasi, birlik kesma, yo'nalish; nuqta koordinatasi.","Masshtab (qadam 10, 100).","Taqqoslash; qo'shish va ayirish — sakrashlar.","Masofa va o'rtadagi nuqta; ketma-ket harakatlar (robot)."],
 mist:["Kesmalar o'rniga chiziqlarni sanaydi (0 bilan birga).","Masshtabni e'tiborsiz qoldiradi: 7-bo'linmani 7 deydi.","Masofani qo'shish bilan topadi: 3 + 11.","O'rta nuqta o'rniga masofaning yarmini javob qiladi."],
 need:["Polda lenta bilan nur, kartochkalar.","Chizg'ich, ip."],
 board:["<span class='w2'>A(4)</span> — O dan 4 kesma.","<span class='w2'>7 + 5 = 12</span> — o'ngga.","<span class='w2'>AB = 11 − 3 = 8</span>.","O'rta: <span class='w2'>(3 + 11) : 2 = 7</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
