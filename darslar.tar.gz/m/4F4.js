var CODE='4F4',TITLE='4-sinf · Kasrli masalalar: eng murakkab turlari';

function pad(n){return n<10?'0'+n:''+n}
// ===================== SAHNA: chizma model (Singapur "bar model") =====================
var NS='http://www.w3.org/2000/svg',sv=document.getElementById('sv'),strip=document.getElementById('strip');
function E(t,a,p){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
function T(p,x,y,txt,a){a=a||{};var m_=/^(\d{1,3})\/(\d{1,3})$/.exec(String(txt));if(m_&&!a.nofr){var fs=+(a['font-size']||12)*.8,g_=E('g',{},p),aa=Object.assign({},a,{'font-size':fs});delete aa.nofr;var n_=E('text',Object.assign({x:x,y:y-fs*.45,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);n_.textContent=m_[1];var d_=E('text',Object.assign({x:x,y:y+fs*.75,'text-anchor':'middle',fill:'#3a4a5a','font-weight':700},aa),g_);d_.textContent=m_[2];var w_=Math.max(m_[1].length,m_[2].length)*fs*.62+4,ax=(a['text-anchor']==='start')?x+w_/2-2:((a['text-anchor']==='end')?x-w_/2+2:x);n_.setAttribute('x',ax);d_.setAttribute('x',ax);E('line',{x1:ax-w_/2,y1:y-fs*.18,x2:ax+w_/2,y2:y-fs*.18,stroke:aa.fill||'#3a4a5a','stroke-width':Math.max(1.2,fs/9)},g_);g_.textContent;return g_}var e=E('text',Object.assign({x:x,y:y,'text-anchor':'middle','font-size':12,fill:'#3a4a5a','font-weight':600},a),p);e.textContent=txt;return e}
function wait(ms){return new Promise(function(r){setTimeout(r,ms)})}
function rnd(s){return function(){s=(s*16807)%2147483647;return (s-1)/2147483646}}
var C={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',x:'#e9e2d6',off:'#fff7ea',line:'#8a5a24',bad:'#d94b4b',ok:'#1e8e5a',blue:'#1f6fb2',grey:'#cfd6de'};
var S={tok:0};
function clear(){S.tok++;sv.innerHTML='';E('rect',{x:2,y:2,width:356,height:170,rx:14,fill:'#fffaf2',stroke:'#f0e4cc'},sv);S.g=E('g',{class:'fade'},sv)}
// n ta teng bo'lakli chiziq: fills[i] rang, txt[i] yozuv
function B(x,y,w,h,n,fills,txt,opt){opt=opt||{};var g=S.g;for(var i=0;i<n;i++){var f=fills&&fills[i]||C.off;E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:f,stroke:C.line,'stroke-width':1.4},g);
  if(f==='X'){}
  if(opt.cross&&opt.cross.indexOf(i)>=0){E('line',{x1:x+i*w/n+3,y1:y+3,x2:x+(i+1)*w/n-3,y2:y+h-3,stroke:C.bad,'stroke-width':2},g);E('line',{x1:x+(i+1)*w/n-3,y1:y+3,x2:x+i*w/n+3,y2:y+h-3,stroke:C.bad,'stroke-width':2},g)}
  if(txt&&txt[i]!=null&&txt[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+4,txt[i],{'font-size':opt.fs||12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g)}
// qavs: x1..x2, y da; up=true bo'lsa tepada
function Br(x1,x2,y,label,up,col){var g=S.g,d=up?-1:1,m=(x1+x2)/2;col=col||C.blue;
 E('path',{d:'M'+x1+' '+y+' q0 '+(6*d)+' 6 '+(6*d)+' L'+(m-6)+' '+(y+6*d)+' q6 0 6 '+(6*d)+' q0 '+(-6*d)+' 6 '+(-6*d)+' L'+(x2-6)+' '+(y+6*d)+' q6 0 6 '+(-6*d),fill:'none',stroke:col,'stroke-width':1.8},g);
 T(g,m,up?y-16:y+26,label,{'font-size':13,'font-weight':800,fill:col})}
function L(x,y,txt,a){return T(S.g,x,y,txt,Object.assign({'text-anchor':'start','font-size':12,fill:'#3a4a5a'},a||{}))}
// hisob qatorlari (sahna ostida)
function calc(lines,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+lines.map(function(l,i){return '<div class="cl'+(i===lines.length-1?' last':'')+'">'+l+'</div>'}).join('')+'</div>'}
// bosqichli sahna: phases[k]() chiziladi; tugma har bosilganda keyingisi
function phaser(phases,label){return [label||'▶ Keyingi harakat',function(c,done,b){if(S.ph==null)S.ph=0;S.ph++;if(S.ph<phases.length){phases[S.ph]();if(S.ph===phases.length-1){b.disabled=true;b.textContent='✓ Yechildi';done()}else b.textContent=(label||'▶ Keyingi harakat')+' ('+(S.ph+1)+'/'+phases.length+')'}}]}
function startPh(phases){S.ph=0;phases[0]()}

// ===================== BOSQICHLAR (sahnalar) =====================
var X0=40,W=280;
var P1=[function(){clear();L(14,24,'120 ning 3/4 qismi?');B(X0,60,W,40,1,[C.off],['']);Br(X0,X0+W,56,'120',true);calc(['Butun — 120. Uni 4 ta teng bo‘lakka bo‘lamiz…'])},
 function(){clear();L(14,24,'120 ning 3/4 qismi?');B(X0,60,W,40,4,null,['30','30','30','30']);Br(X0,X0+W,56,'120',true);calc(['120 : 4 = <b>30</b> — bitta bo‘lak (maxrajga bo‘ldik)'])},
 function(){clear();L(14,24,'120 ning 3/4 qismi?');B(X0,60,W,40,4,[C.a,C.a,C.a],['30','30','30','30']);Br(X0,X0+W,56,'120',true);Br(X0,X0+W*3/4,104,'3 bo‘lak = 90',false,C.ok);calc(['120 : 4 = 30 — bitta bo‘lak','30 · 3 = <b>90</b> — uchta bo‘lak (suratga ko‘paytirdik)'])}];
var P2=[function(){clear();L(14,24,'Yo‘lning 2/5 qismi — 48 km. Butun yo‘l?');B(X0,64,W,40,5,[C.a,C.a],['','']);Br(X0,X0+W,60,'butun yo‘l = ?',true);Br(X0,X0+W*2/5,108,'48 km',false,C.ok);calc(['Bizga butun emas, uning <b>2 ta bo‘lagi</b> ma’lum.'])},
 function(){clear();L(14,24,'Yo‘lning 2/5 qismi — 48 km. Butun yo‘l?');B(X0,64,W,40,5,[C.a,C.a],['24','24']);Br(X0,X0+W,60,'butun yo‘l = ?',true);Br(X0,X0+W*2/5,108,'48 km',false,C.ok);calc(['48 : 2 = <b>24</b> km — bitta bo‘lak (suratga bo‘ldik)'])},
 function(){clear();L(14,24,'Yo‘lning 2/5 qismi — 48 km. Butun yo‘l?');B(X0,64,W,40,5,[C.a,C.a,C.b,C.b,C.b],['24','24','24','24','24']);Br(X0,X0+W,60,'butun yo‘l = 120 km',true);Br(X0,X0+W*2/5,108,'48 km',false,C.ok);calc(['48 : 2 = 24 km — bitta bo‘lak','24 · 5 = <b>120</b> km — butun yo‘l (maxrajga ko‘paytirdik)'])}];
var P3=[function(){clear();L(12,22,'80 non: yarmi, keyin QOLGANINING 4/5 qismi',{'font-size':11});B(X0,40,W,32,2,[C.a,C.off],['40 sotildi','40 qoldi']);Br(X0,X0+W,36,'',true);T(S.g,X0+W/2,30,'80',{'font-size':12,'font-weight':800,fill:C.blue});calc(['80 : 2 = <b>40</b> — tushgacha sotildi, 40 ta qoldi'])},
 function(){clear();L(12,22,'80 non: yarmi, keyin QOLGANINING 4/5 qismi',{'font-size':11});B(X0,40,W,32,2,[C.a,C.off],['40 sotildi','40 qoldi']);E('path',{d:'M'+(X0+W*.75)+' 74 L'+(X0+W*.75)+' 92',stroke:C.blue,'stroke-width':2,'marker-end':''},S.g);
  B(X0+W/2-60,100,W/2+60,32,5,null,['8','8','8','8','8']);Br(X0+W/2-60,X0+W,136,'yangi butun — 40',false);calc(['80 : 2 = 40 — qoldi','Endi <b>qolgan 40</b> — yangi butun! 40 : 5 = <b>8</b>'])},
 function(){clear();L(12,22,'80 non: yarmi, keyin QOLGANINING 4/5 qismi',{'font-size':11});B(X0,40,W,32,2,[C.a,C.off],['40 sotildi','40 qoldi']);
  B(X0+W/2-60,100,W/2+60,32,5,[C.b,C.b,C.b,C.b],['8','8','8','8','8']);Br(X0+W/2-60+(W/2+60)*4/5,X0+W,136,'qoldi: 8',false,C.ok);calc(['80 : 2 = 40 — qoldi','40 : 5 = 8, 8 · 4 = 32 — tushdan keyin sotildi','40 − 32 = <b>8</b> ta non qoldi'])}];
function olma(k){clear();var x=70,w=230;L(10,20,'Oxiridan boshlaymiz ↑',{fill:C.blue,'font-weight':800,'font-size':11});
 var rows=[{n:5,take:2,y:28,lab:'1-xaridor',v:'4',tot:'20 kg',need:3,show:2},{n:4,take:3,y:80,lab:'2-xaridor',v:'3',tot:'12 kg',need:2,show:1},{n:3,take:2,y:132,lab:'3-xaridor',v:'1',tot:'3 kg',need:1,show:0}];
 rows.forEach(function(r){if(k<r.show)return;var f=[],tx=[];for(var j=0;j<r.n;j++){f.push(j<r.take?C.x:C.a);tx.push(k>=r.need?r.v:(j>=r.take&&r.n===3?'1 kg':''))}
  B(x,r.y,w,26,r.n,f,tx);L(6,r.y+17,r.lab,{'font-size':11});var ok=k>=r.need;T(S.g,x+w+28,r.y+17,ok?r.tot:'?',{'font-size':12,'font-weight':800,fill:ok?C.ok:C.bad})})}
var P4=[function(){olma(0);calc(['Oxirida <b>1 kg</b> qoldi. 3-xaridor qolganining 2/3 qismini oldi — demak 1/3 qismi qoldi.'],'Kul rang — olingan, sariq — qolgan')},
 function(){olma(1);calc(['1/3 qism = 1 kg → 3-xaridor kelganda: 1 · 3 = <b>3 kg</b>'],'Kul rang — olingan, sariq — qolgan')},
 function(){olma(2);calc(['1/3 = 1 kg → 3 kg','2-xaridor 3/4 qismini oldi, 1/4 qoldi = 3 kg → 3 · 4 = <b>12 kg</b>'],'Kul rang — olingan, sariq — qolgan')},
 function(){olma(3);calc(['1/3 = 1 kg → 3 kg','1/4 = 3 kg → 12 kg','1-xaridor 2/5 ni oldi, 3/5 qoldi = 12 kg → 1/5 = 4 kg → 4 · 5 = <b>20 kg</b>'],'Kul rang — olingan, sariq — qolgan')}];
function idish(k){clear();var x=70,w=200;
 L(8,40,'To‘la:',{'font-size':12});E('rect',{x:x,y:22,width:40,height:30,fill:'#c9d3dd',stroke:C.line,'stroke-width':1.5},S.g);T(S.g,x+20,41,k>=2?'2 kg':'idish',{'font-size':10});B(x+40,22,w,30,4,[C.a,C.a,C.a,C.a],k>=1?['3','3','3','3']:[]);T(S.g,x+w+64,42,'14 kg',{'font-size':13,'font-weight':800,fill:C.blue});
 L(8,100,'3/4 to‘la:',{'font-size':12});E('rect',{x:x,y:82,width:40,height:30,fill:'#c9d3dd',stroke:C.line,'stroke-width':1.5},S.g);T(S.g,x+20,101,k>=2?'2 kg':'idish',{'font-size':10});B(x+40,82,w*3/4,30,3,[C.a,C.a,C.a],k>=1?['3','3','3']:[]);T(S.g,x+w+64,102,'11 kg',{'font-size':13,'font-weight':800,fill:C.blue});
 if(k>=1){E('rect',{x:x+40+w*3/4,y:22,width:w/4,height:30,fill:'none',stroke:C.bad,'stroke-width':3},S.g);T(S.g,x+40+w*7/8,132,'farq: 14 − 11 = 3 kg',{'font-size':12,'font-weight':800,fill:C.bad})}
 if(k>=2)T(S.g,180,160,'meva: 3 · 4 = 12 kg, idish: 14 − 12 = 2 kg',{'font-size':12,'font-weight':800,fill:C.ok})}
var P5=[function(){idish(0);calc(['Ikki tortishda <b>idish bir xil</b>. Farq faqat mevada.'])},
 function(){idish(1);calc(['14 − 11 = <b>3 kg</b> — bu mevaning 1/4 qismi (to‘la bilan 3/4 orasidagi farq)'])},
 function(){idish(2);calc(['1/4 meva = 3 kg','Butun meva: 3 · 4 = 12 kg','Narxi: 12 · 6 000 = <b>72 000 so‘m</b>'])}];
function ferma(k){clear();var x=78,w=180,h=22,names=['Sigir','Qo‘y','Tovuq'],ys=[22,62,102];
 ys.forEach(function(y,i){var f=[],cr=[];for(var j=0;j<6;j++){f.push(i===0?C.b:(i===1?C.a:C.c))}if(k>=1){if(i===1)cr=[4,5];if(i===2)cr=[3,4,5]}
  var tx=k>=3?['3','3','3','3','3','3']:[];B(x,y,w,h,6,f,tx,{cross:cr,fs:10});L(8,y+15,names[i],{'font-size':12})});
 if(k>=1){E('rect',{x:x+w+6,y:22,width:34,height:h,fill:C.b,stroke:C.line,rx:3},S.g);T(S.g,x+w+23,37,'+4',{'font-size':11,'font-weight':800});E('rect',{x:x,y:136,width:56,height:h,fill:'#b9e3c6',stroke:C.line,rx:3},S.g);T(S.g,x+28,151,'echki 8',{'font-size':10,'font-weight':800});L(8,151,'Yangi',{'font-size':12})}
 if(k>=2)T(S.g,x+w/2+60,160,'13 bo‘lak + 12 = 51',{'font-size':12,'font-weight':800,fill:C.blue})}
var P6=[function(){ferma(0);calc(['Uchalasi <b>teng</b>. 1/3 va 1/2 ni olish uchun har birini <b>6</b> bo‘lakka bo‘lamiz (6 ham 3 ga, ham 2 ga bo‘linadi).'])},
 function(){ferma(1);calc(['Qo‘y: 6 ning 1/3 i — 2 bo‘lak sotildi, 4 qoldi','Tovuq: yarmi — 3 bo‘lak sotildi, 3 qoldi','+4 sigir, +8 echki'])},
 function(){ferma(2);calc(['Bo‘laklar: 6 + 4 + 3 = 13','Bo‘lakdan tashqari: 4 + 8 = 12','13 bo‘lak = 51 − 12 = <b>39</b>'])},
 function(){ferma(3);calc(['13 bo‘lak = 39 → 1 bo‘lak = 39 : 13 = 3','Boshida sigir: 6 · 3 = 18','Hozir: 18 + 4 = <b>22 ta sigir</b>'])}];
function sayr(k){clear();var x=30,w=300;L(10,20,'Sinf: 13 qiz + 17 o‘g‘il = 30',{'font-size':12});
 var f=[];for(var i=0;i<30;i++)f.push(i<13?C.c:C.b);B(x,30,w,24,30,f,[]);
 if(k>=1){Br(x,x+w*18/30,58,'3/5 qismi sayrga: 30 : 5 · 3 = 18',false,C.blue)}
 if(k>=2){var g=[];for(var j=0;j<18;j++)g.push(j<13?C.c:C.b);B(x,112,w*18/30,24,18,g,[]);L(x,106,'Eng yomon holat: hamma qiz sayrda',{'font-size':11,fill:C.bad});Br(x+w*13/30,x+w*18/30,140,'5 o‘g‘il',false,C.ok)}}
var P7=[function(){sayr(0);calc(['Pushti — qizlar (13), ko‘k — o‘g‘illar (17).'])},
 function(){sayr(1);calc(['Sayrga: 30 : 5 · 3 = <b>18</b> nafar'])},
 function(){sayr(2);calc(['18 ta joyga avval iloji boricha ko‘p qiz: 13 tasining hammasi','Qolgan joylar: 18 − 13 = <b>5</b> — bundan kam o‘g‘il bo‘lishi mumkin emas'])}];
var P8=[function(){clear();B(X0,50,W,40,5,null,['?','?','?','?','?']);Br(X0,X0+W,46,'120',true);calc(['Chizma: 5 ta teng bo‘lak — 120'])},
 function(){clear();B(X0,50,W,40,5,null,['x','x','x','x','x']);Br(X0,X0+W,46,'120',true);T(S.g,180,140,'5 · x = 120   →   x = 24',{'font-size':18,'font-weight':800,fill:C.blue});calc(['Bo‘lakni <b>x</b> desak — bu allaqachon <b>tenglama</b>!','Al-Xorazmiyning «al-jabr» kitobi aynan shunday masalalarni yechish haqida.'])}];
var PRAISE=[["ok1","Barakalla!"],["ok2","Ha, aynan shunday!"],["ok3","Zo'r, topdingiz!"],["ok4","Juda yaxshi!"]];
var STEPS=[
{h:"Asos: sonning kasri",sum:"120 ning 3/4 qismi: 120 : 4 = 30 (bitta bo'lak), 30 · 3 = 90. Maxrajga bo'l — suratga ko'paytir.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har bir murakkab masala shu poydevorga tayanadi. Masalani <b>chizma</b> bilan yechamiz: butunni chiziq qilib chizamiz va teng bo'laklarga bo'lamiz. Tugmani bosib, har harakatni kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Yodda tuting: <b>sonning kasri</b> = son : maxraj · surat. Chizmada: butunni maxrajcha bo'lakka bo'lamiz, suratcha bo'lakni olamiz.</p>",
 q:{t:"240 ning 3/8 qismi nechaga teng?",opts:["80","90","30","640"],ok:1,why:"240 : 8 = 30, 30 · 3 = 90.",hint:"Avval bitta bo'lakni toping: 240 ni nechaga bo'lamiz?",full:"Butun 240, uni 8 bo'lakka bo'lamiz: 240 : 8 = 30. Bizga 3 bo'lak kerak: 30 · 3 = 90. «30» — bu faqat bitta bo'lak."},
 tn:"Singapurda «bar model» 1980-yillardan beri asosiy usul; Singapur TIMSS va PISA reytinglarida doim birinchilar qatorida. Har masalada bolalar avval chizma chizsin, keyin hisoblasin."},
{h:"Teskari: qismi ma'lum, butun noma'lum",sum:"2/5 qismi = 48 → 1 bo'lak = 48 : 2 = 24 → butun = 24 · 5 = 120. Suratga bo'l — maxrajga ko'paytir.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Endi teskarisi: <b>butun noma'lum</b>, uning bir qismi ma'lum. Bolalar ko'pincha shu yerda 48 ni 5 ga bo'lib yoki 2/5 ga «ko'paytirib» adashadi. Chizma xatoga yo'l qo'ymaydi.</p>",
 btns:[phaser(P2)],
 after:"<p>Chizmaga qarang: 48 — bu <b>2 ta bo'lak</b>, butun emas. Shuning uchun avval 48 ni <b>2 ga</b> (suratga) bo'lamiz, keyin <b>5 ga</b> (maxrajga) ko'paytiramiz.</p><p>Tekshirish: 120 ning 2/5 qismi = 120 : 5 · 2 = 48 ✓</p>",
 q:{t:"Kitobning 3/8 qismi 90 bet. Kitob necha bet?",opts:["270","34","240","30"],ok:2,why:"90 : 3 = 30 bet — bitta bo'lak, 30 · 8 = 240.",hint:"90 — butunmi yoki uning 3 bo'lagimi? Avval bitta bo'lakni toping.",full:"90 bet — 3 ta bo'lak. Bitta bo'lak: 90 : 3 = 30. Butun kitob 8 bo'lak: 30 · 8 = 240. Tekshiramiz: 240 : 8 · 3 = 90 ✓."},
 tn:"Ikki qoidani yonma-yon yozing va bolalardan qaysi biri qachon ishlatilishini so'rang. Eng muhimi — chizma: «ma'lum son chizmaning qaysi qismiga yoziladi?»"},
{h:"Tuzoq: «hammasining» emas, «qolganining»",sum:"«Qolganining 4/5 qismi» — qolgan 40 yangi butun bo'ladi: 40 : 5 · 4 = 32; 8 ta qoladi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Masala: <i>«Novvoyxona 80 ta non yopdi. Yarmi tushgacha, <b>qolganining</b> 4/5 qismi tushdan keyin sotildi. Nechta non qoldi?»</i></p><p>Bitta so'z hammasini o'zgartiradi: <b>qolganining</b>. Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>«Qolganining» deyilsa — <b>qolgan qism yangi butun</b> bo'ladi va endi kasr shundan olinadi.</p><p>Xato yo'l: 80 ning 4/5 qismi = 64. Lekin tushgacha sotilgandan keyin 40 ta qolgan edi — 64 ta sotib bo'lmaydi! Shart bo'yicha tekshirish xatoni darhol ko'rsatadi.</p>",
 q:{t:"Kitob 120 bet. 1-kuni 1/3 qismi, 2-kuni qolganining 1/2 qismi o'qildi. Necha bet qoldi?",opts:["20","60","40","0"],ok:2,why:"120 : 3 = 40 o'qildi, 80 qoldi; 80 ning yarmi 40 o'qildi, 40 qoldi.",hint:"2-kuni «qolganining» yarmi o'qildi. 1-kundan keyin necha bet qolgan edi?",full:"1-kuni: 120 : 3 = 40 bet, qoldi 80. 2-kuni qolganining yarmi: 80 : 2 = 40 bet, qoldi 40. «20» — bu ikkala kasrni ham 120 dan olgan xato yo'l."},
 tn:"Bolalarga masaladagi «qolganining» so'zini doira ichiga olishni o'rgating. Har «qolganining»dan keyin yangi chizma chiziladi."},
{h:"Oxiridan boshlab yechish",sum:"Oxirgi qoldiqdan orqaga: 1/3 = 1 kg → 3 kg; 1/4 = 3 kg → 12 kg; 3/5 = 12 kg → 20 kg.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Masala: <i>«Yashikdagi olmaning 1-xaridor 2/5 qismini, 2-xaridor qolganining 3/4 qismini, 3-xaridor qolganining 2/3 qismini oldi. 1 kg qoldi. Yashikda necha kg olma bo'lgan?»</i></p><p>Boshi noma'lum, <b>oxiri ma'lum</b> — shuning uchun oxiridan, pastdan yuqoriga qarab yechamiz.</p>",
 btns:[phaser(P4,'▶ Orqaga qadam')],
 after:"<p>Har qadamda faqat bitta savol: <b>qolgan qism butunning qanchasi?</b> Agar 2/3 olingan bo'lsa — 1/3 qolgan. Qolgan bo'lak ma'lum — butunni topamiz.</p><p>Tekshirish: 20 → 8 kg olindi, 12 qoldi → 9 olindi, 3 qoldi → 2 olindi, 1 qoldi ✓</p>",
 q:{t:"Koptok har safar oldingi balandligining 3/5 qismiga sakraydi. 3-sakrashda 54 sm ga ko'tarildi. U qanday balandlikdan tashlangan?",opts:["90 sm","150 sm","250 sm","330 sm"],ok:2,why:"54 → 90 → 150 → 250: har safar 3 ga bo'lib, 5 ga ko'paytiramiz.",hint:"Oxiridan boshlang: 54 sm — oldingi balandlikning 3/5 qismi. Oldingi balandlik qancha?",full:"54 — 3 bo'lak, 1 bo'lak 18, oldingi 18 · 5 = 90. 90 — 3 bo'lak, 1 bo'lak 30, oldingi 150. 150 — 3 bo'lak, 1 bo'lak 50, boshlang'ich 250 sm. «90» va «150» — bu oraliq sakrashlar."},
 tn:"«Oxiridan yechish» — olimpiada masalalarining asosiy usullaridan biri. Doskada chizmalarni pastdan yuqoriga chizing, bolalar yo'nalishni ko'rsin."},
{h:"Ikki o'lchovdan farq",sum:"To'la 14 kg, 3/4 to'la 11 kg: farq 3 kg = mevaning 1/4 qismi → meva 12 kg, idish 2 kg.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Masala: <i>«Meva bilan to'la idish 14 kg. Idishning 3/4 qismi to'la bo'lsa — 11 kg. 1 kg meva 6 000 so'm. To'la idishdagi mevaning narxi?»</i></p><p>Bu yerda idishning o'zi ham og'irlik qiladi — ayyorlik shunda.</p>",
 btns:[phaser(P5)],
 after:"<p>Usul: ikki holatni <b>yonma-yon</b> chizamiz. Bir xil narsa (idish) qisqarib ketadi, <b>farq</b> faqat o'zgargan qismni ko'rsatadi: 14 − 11 = 3 kg — bu chorak meva.</p><p>Xato yo'l: 14 kg ni meva deb 14 · 6 000 = 84 000 deyish. Idishni unutmang!</p>",
 q:{t:"Suv bilan to'la idish 20 kg, yarmi to'la idish 12 kg. Bo'sh idish necha kg?",opts:["4 kg","8 kg","16 kg","2 kg"],ok:0,why:"Farq 8 kg — suvning yarmi; suv 16 kg, idish 20 − 16 = 4 kg.",hint:"20 − 12 = ? Bu farq suvning qancha qismi?",full:"To'la va yarim to'la orasidagi farq: 20 − 12 = 8 kg — bu suvning yarmi. Butun suv: 8 · 2 = 16 kg. Idish: 20 − 16 = 4 kg. Tekshiramiz: 4 + 8 = 12 ✓."},
 tn:"Farq usuli keyinchalik tenglamalar tizimini yechishning asosi bo'ladi. Bolalar ikki chizmani bir-birining ostiga chizsin."},
{h:"Hammasini teng bo'laklarga keltiramiz",sum:"1/3 va 1/2 birga kelsa — butunni 6 bo'lakka bo'lamiz. 13 bo'lak = 39 → 1 bo'lak = 3 → sigir 18 + 4 = 22.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Masala: <i>«Fermerning sigir, qo'y va tovuqlari soni teng edi. U qo'ylarining 1/3 qismini, tovuqlarining yarmini sotdi, keyin 8 ta echki va 4 ta sigir sotib oldi. Endi jami 51 ta hayvon. Hozir nechta sigir bor?»</i></p><p>Eng qiyin joyi: 1/3 va 1/2 — har xil bo'laklar. Ularni bitta o'lchovga keltiramiz.</p>",
 btns:[phaser(P6)],
 after:"<p>Kalit fikr: har birini <b>6 bo'lakka</b> bo'ldik, chunki 6 ni ham 3 ga, ham 2 ga bo'lish mumkin. Endi hamma narsa bir xil «bo'lak»larda sanaladi.</p><p>Tekshirish: sigir 22, qo'y 12, tovuq 9, echki 8 → 22 + 12 + 9 + 8 = 51 ✓</p>",
 q:{t:"Ali va Valida teng miqdorda yong'oq bor edi. Ali o'zinikining 1/2 qismini, Vali 1/3 qismini yedi. Ikkalasida jami 35 ta qoldi. Boshida har birida nechta bo'lgan?",opts:["35","20","42","30"],ok:3,why:"6 bo'lak: Alida 3, Valida 4 qoldi — 7 bo'lak = 35, 1 bo'lak 5, boshida 6 · 5 = 30.",hint:"Har birini 6 bo'lakka bo'ling. Alida nechta bo'lak qoldi, Valida nechta?",full:"6 bo'lakdan Ali yarmini (3) yedi — 3 qoldi; Vali 1/3 ni (2) yedi — 4 qoldi. 3 + 4 = 7 bo'lak = 35, 1 bo'lak = 5. Boshida: 6 · 5 = 30. Tekshiramiz: 15 + 20 = 35 ✓."},
 tn:"Bu — umumiy maxraj g'oyasining chizmadagi ko'rinishi. 5-sinfda «umumiy maxraj» o'tilganda bolalar bu chizmani eslaydi."},
{h:"«Eng kamida» — eng yomon holatni o'ylaymiz",sum:"30 dan 18 tasi sayrda; qizlar ko'pi bilan 13 → o'g'illar eng kamida 18 − 13 = 5.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Masala: <i>«Sinfda 13 qiz va 17 o'g'il bor. O'quvchilarning 3/5 qismi sayrga chiqdi. Sayrdagilar orasida <b>eng kamida</b> nechta o'g'il bor?»</i></p><p>«Eng kamida» degan savolda biz <b>eng yomon holatni</b> qidiramiz.</p>",
 btns:[phaser(P7)],
 after:"<p>O'g'illar eng kam bo'lishi uchun joylarni iloji boricha <b>qizlar</b> egallashi kerak. Qizlar 13 tadan ko'p emas — qolgan 5 ta joyga albatta o'g'il chiqadi.</p>",
 q:{t:"Savatda 12 ta olma va 8 ta nok bor. Mevalarning 3/4 qismi olindi. Olinganlar orasida eng kamida nechta nok bor?",opts:["6","3","8","15"],ok:1,why:"20 ning 3/4 i — 15 ta; olma ko'pi bilan 12 → nok kamida 3.",hint:"Avval nechta meva olinganini toping. Keyin nok eng kam bo'lishi uchun nimani ko'p olish kerak?",full:"Jami 20 ta, 3/4 qismi: 20 : 4 · 3 = 15 ta olindi. Nok kam bo'lishi uchun olmani ko'p olamiz — hammasi 12 ta. Qolgan 15 − 12 = 3 ta albatta nok."},
 tn:"«Eng kamida / eng ko'pi bilan» masalalari mantiqiy fikrlashni o'stiradi. Bolalar avval eng yomon holatni rasm qilib chizsin."},
{h:"Bilasizmi? Chizmadan tenglamagacha",sum:"Chizmadagi noma'lum bo'lakni x desak — tenglama: 5 · x = 120. Bu al-Xorazmiyning «al-jabr»i.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=1;P8[1]()},
 html:"<p>🇸🇬 Biz ishlatgan chizma usuli Singapurda o'ylab topilgan. Singapur o'quvchilari matematika bo'yicha xalqaro reytinglarda doim birinchilar qatorida.</p><p>⭐ Lekin bu fikrning ildizi ming yildan ham qadimiy. Tugmani bosing.</p>",
 btns:[phaser(P8,'▶ Chizmani tenglamaga')],
 after:"<p>Noma'lum bo'lakni <b>x</b> deb belgilasak, chizma tenglamaga aylanadi: <b>5 · x = 120</b>. Noma'lumni topishning shunday qoidalarini vatandoshimiz <b>Muhammad al-Xorazmiy</b> o'zining «Al-jabr val-muqobala» kitobida yozgan. «Algebra» so'zi aynan shu kitob nomidan kelib chiqqan!</p>",
 tn:"Kuchli bolalarga bir xil masalani ham chizma, ham «x» bilan yechib ko'rsatish mumkin — bu 5–6-sinf algebrasiga ko'prik bo'ladi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li><b>Har masalada avval chizma</b>: butun — chiziq, teng bo'laklarga bo'lingan.</li><li><b>Sonning kasri</b>: son : maxraj · surat. 120 ning 3/4 i = 90.</li><li><b>Qismi ma'lum</b>: qism : surat · maxraj. 2/5 i = 48 → 120.</li><li><b>«Qolganining»</b> — qolgan qism <b>yangi butun</b>, yangi chizma.</li><li><b>Oxiri ma'lum</b> — oxiridan boshlab, orqaga yeching.</li><li><b>Ikki o'lchov</b> — farqini oling, bir xil narsa qisqaradi.</li><li><b>Har xil kasrlar</b> (1/3 va 1/2) — butunni ikkalasiga bo'linadigan bo'lakka (6) bo'ling.</li><li><b>«Eng kamida»</b> — eng yomon holatni o'ylang.</li><li>Oxirida doim <b>tekshiring</b>: javobni shartga qo'yib ko'ring.</li></ul></div>",
 tn:"Kartochkani daftar muqovasiga yopishtirish tavsiya etiladi — kasrli masalalarning barcha turlari shu yerda."}
];
var PROBS=[
{t:"360 ning 5/6 qismini toping.",o:["300","60","432","310"],k:0,s:"360 : 6 = 60 — bitta bo'lak, 60 · 5 = 300."},
{t:"Sonning 4/7 qismi 48 ga teng. Sonni toping.",o:["84","27","42","96"],k:0,s:"48 : 4 = 12 — bitta bo'lak, 12 · 7 = 84."},
{t:"Yo'lning 3/8 qismi bosib o'tildi, yana 60 km qoldi. Butun yo'l necha km?",o:["96","160","100","72"],k:0,s:"Qolgan 5/8 qism = 60 km. 60 : 5 = 12, 12 · 8 = 96 km."},
{t:"Do'konda 240 kg un bor edi. 1-kuni 1/4 qismi, 2-kuni qolganining 1/3 qismi sotildi. Necha kg qoldi?",o:["120","100","140","60"],k:0,s:"1-kuni 60 kg, qoldi 180. 2-kuni 180 : 3 = 60, qoldi 120 kg."},
{t:"Ali pulining yarmiga kitob, qolganining 1/3 qismiga qalam oldi. Unda 8 000 so'm qoldi. Boshida qancha puli bo'lgan?",o:["24 000 so'm","16 000 so'm","12 000 so'm","48 000 so'm"],k:0,s:"Oxiridan: qolganining 2/3 qismi = 8 000 → qolgani 12 000. Bu pulning yarmi → 24 000."},
{t:"Koptok har safar oldingi balandligining yarmiga sakraydi. 2-sakrashda 40 sm ga ko'tarildi. U qanday balandlikdan tashlangan?",o:["160 sm","80 sm","120 sm","320 sm"],k:0,s:"Oxiridan: 40 → 80 → 160 sm."},
{t:"Suv bilan to'la idish 10 kg, suvning yarmi to'kilgach 6 kg chiqdi. Bo'sh idish necha kg?",o:["2 kg","4 kg","8 kg","6 kg"],k:0,s:"Farq 4 kg — suvning yarmi, suv 8 kg. Idish: 10 − 8 = 2 kg."},
{t:"Sinfda 28 o'quvchi, ulardan 3/7 qismi qizlar. O'g'il bolalar qizlardan nechta ko'p?",o:["4","12","16","7"],k:0,s:"Qizlar 28 : 7 · 3 = 12, o'g'illar 16. Farq: 4."},
{t:"Kitobning 2/5 qismi o'qilgach, o'qilmagan qismi o'qilganidan 30 bet ko'p bo'ldi. Kitob necha bet?",o:["150","75","90","60"],k:0,s:"O'qilmagan 3/5, o'qilgan 2/5. Farq 1/5 = 30 bet → kitob 150 bet."},
{t:"Bog'dagi daraxtlarning 1/3 qismi olma, 1/4 qismi o'rik, qolgan 25 tasi nok. Bog'da nechta daraxt bor?",o:["60","48","36","100"],k:0,s:"12 bo'lak: olma 4, o'rik 3, nok 5 bo'lak = 25 → 1 bo'lak 5 → 60 ta."},
{t:"Ikki qutida teng konfet bor edi. Birinchisidan yarmi, ikkinchisidan 1/4 qismi olindi. Jami 30 ta qoldi. Boshida bitta qutida nechta bo'lgan?",o:["24","30","12","20"],k:0,s:"4 bo'lak: 1-qutida 2, 2-qutida 3 qoldi — 5 bo'lak = 30, 1 bo'lak 6 → 24."},
{t:"Savatda 15 ta olma va 10 ta nok bor. Mevalarning 4/5 qismi olindi. Olinganlar orasida eng kamida nechta olma bor?",o:["10","15","5","12"],k:0,s:"25 ning 4/5 i — 20 ta. Nok ko'pi bilan 10 → olma kamida 10."},
{t:"To'la bidon 13 kg, sutning 1/3 qismi quyib olingach 10 kg. Bidonda boshida necha kg sut bo'lgan?",o:["9 kg","3 kg","10 kg","12 kg"],k:0,s:"13 − 10 = 3 kg — sutning 1/3 qismi. Sut: 3 · 3 = 9 kg."},
{t:"Mashina 1-soatda yo'lning 1/3 qismini, 2-soatda qolganining yarmini bosdi. Yana 40 km qoldi. Butun yo'l necha km?",o:["120 km","80 km","240 km","160 km"],k:0,s:"Oxiridan: qolganining yarmi = 40 → qolgani 80. 80 — yo'lning 2/3 qismi → 1/3 = 40 → 120 km."},
{t:"Zarina 600 so'mning 2/3 qismini, Kamola 900 so'mning 1/3 qismini sarfladi. Kim ko'p sarfladi va qanchaga?",o:["Zarina, 100 so'mga","Kamola, 100 so'mga","Teng sarflashdi","Zarina, 300 so'mga"],k:0,s:"Zarina: 600 : 3 · 2 = 400. Kamola: 900 : 3 = 300. Zarina 100 so'm ko'p."},
{t:"Sonning 3/4 qismi uning yarmidan 15 ga ko'p. Sonni toping.",o:["60","30","45","20"],k:0,s:"3/4 va 2/4 (yarmi) farqi — 1/4 = 15. Son: 15 · 4 = 60."},
{t:"Ombordagi kartoshkaning 5/8 qismi sotildi, sotilgani qolganidan 60 kg ko'p. Omborda qancha kartoshka bo'lgan?",o:["240 kg","160 kg","96 kg","480 kg"],k:0,s:"Sotilgan 5/8, qolgan 3/8. Farq 2/8 = 60 → 1/8 = 30 → 240 kg."},
{t:"Ota 40 yoshda, o'g'li otasi yoshining 1/4 qismicha. Necha yildan keyin o'g'il otasi yoshining 1/3 qismicha bo'ladi?",o:["5","10","3","15"],k:0,s:"O'g'il 10 yoshda, farq doim 30. O'g'il 1 bo'lak, ota 3 bo'lak → farq 2 bo'lak = 30 → o'g'il 15. 15 − 10 = 5 yil."},
{t:"Kitobxon 1-kuni kitobning 1/4 qismini, 2-kuni 1/3 qismini o'qidi. 2-kuni 12 bet ko'p o'qidi. Kitob necha bet?",o:["144","48","72","96"],k:0,s:"12 bo'lak: 1-kuni 3, 2-kuni 4 bo'lak. Farq 1 bo'lak = 12 → 144 bet."},
{t:"Tovuq va o'rdaklar soni teng edi. Tovuqlarning 1/3 qismi, o'rdaklarning yarmi sotildi. Qolgan tovuqlar qolgan o'rdaklardan 6 ta ko'p. Boshida nechta tovuq bo'lgan?",o:["36","18","12","24"],k:0,s:"6 bo'lak: tovuq 4, o'rdak 3 qoldi. Farq 1 bo'lak = 6 → 36 ta."}
];
(function(){var R=rnd(17);PROBS.forEach(function(p,i){p.a='p'+pad(i+1);var idx=[0,1,2,3];for(var j=3;j>0;j--){var r=Math.floor(R()*(j+1));var t=idx[j];idx[j]=idx[r];idx[r]=t}var o=idx.map(function(x){return p.o[x]});p.k=idx.indexOf(p.k);p.o=o;p._sh=1})})();
var LOCK_SEC=20;
function PRACT_STAGE(){clear();B(X0,60,W,40,4,[C.a,C.a,C.a],['','','','']);Br(X0,X0+W,56,'butun',true);calc(['Har masalada avval chizma chizing ✏️'])}
var PREP='<div class="st prep"><div class="bd" style="padding-top:12px"><h3 style="margin-top:0">Darsga tayyorlanish</h3><p>Bu dars kasrli masalalarning <b>eng qiyin turlariga</b> bag\'ishlangan. Bolalar «Kasr» va «Sonning kasrini topish» mavzularini bilishi kerak.</p><h3>Bolalar odatda qayerda adashadi</h3><ul><li>Qismi ma\'lum bo\'lganda butun deb hisoblaydi (48 ni 5 ga bo\'ladi).</li><li>«Qolganining» so\'zini e\'tiborsiz qoldiradi.</li><li>Oxiri ma\'lum masalani boshidan yechishga urinadi.</li><li>Idish, quti kabi «bir xil» narsani unutadi.</li><li>«Eng kamida»da o\'rtacha holatni oladi.</li></ul><h3>Doskaga nima yoziladi</h3><ol><li>Chizma: <span class="w2">[30|30|30|30] = 120</span>, 3 bo\'lak = 90.</li><li>Teskari: <span class="w2">2 bo\'lak = 48 → 1 = 24 → 5 = 120</span>.</li><li>«Qolganining»: ikki qavatli chizma.</li><li>Orqaga: <span class="w2">1 → 3 → 12 → 20</span>.</li><li>Farq: <span class="w2">14 − 11 = 3 = 1/4</span>.</li><li>6 bo\'lak: <span class="w2">13 bo\'lak = 39</span>.</li><li>Eng yomon holat: <span class="w2">18 − 13 = 5</span>.</li></ol><button class="printbtn" onclick="window.print()">🖨 Chop etish</button><h3>Mashq varaqasi (javoblari bilan)</h3><ol class="plist">'+PROBS.map(function(p){return '<li>'+p.t+'<br><span class="pnum">'+p.o.map(function(o,j){return String.fromCharCode(65+j)+') '+o}).join(' &nbsp; ')+' — <b>'+String.fromCharCode(65+p.k)+'</b></span></li>'}).join('')+'</ol></div></div>';

