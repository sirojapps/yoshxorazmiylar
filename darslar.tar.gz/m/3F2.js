
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3F2',TITLE='3-sinf · Sonning ulushini va ulushiga ko‘ra sonni topish';
// chizma: butun (total yoki '?'), n bo'lak, k bo'yalgan, vals — bo'laklar ichidagi yozuv
function f2bm(title,total,n,k,vals,lines,o){o=o||{};clear();T(S.g,14,22,title,{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});var x=30,w=300,y=o.y||62;
 f3bar(x,y,w,40,n,k,o.col,vals);Br(x,x+w,y-4,total,true);if(o.part)Br(x,x+w*k/n,y+44,o.part,false,C.ok);if(o.rest)Br(x+w*k/n,x+w,y+44,o.rest,false,C.bad);f3calc(lines)}
function f2rep(n,v){var a=[];for(var i=0;i<n;i++)a.push(v);return a}
var F2P1=[function(){f2candy(0);f3calc(['12 ta konfet, 3 ta bola. Har biriga teng!'])},function(){f2candy(1);f3calc(['Har bolaga bittadan tarqatamiz…'])},function(){f2candy(2);f3calc(['12 : 3 = <b>4</b> — har biriga 4 ta. Bu 12 ning <b>1/3</b> qismi'])}];
var F2P3=[function(){f2bm('24 ning 3/4 qismi?','24',4,0,null,['Butun — 24. Avval 4 ta teng bo‘lakka bo‘lamiz'])},function(){f2bm('24 ning 3/4 qismi?','24',4,0,f2rep(4,6),['24 : 4 = <b>6</b> — bitta bo‘lak (1/4)'])},function(){f2bm('24 ning 3/4 qismi?','24',4,3,f2rep(4,6),['24 : 4 = 6 — bitta bo‘lak','6 · 3 = <b>18</b> — uchta bo‘lak (3/4)'],{part:'3/4 = 18'})}];
var F2P4=[function(){f2bm('Sonning 1/4 qismi 6 ga teng. Son?','?',4,1,['6','','',''],['Bizga BITTA bo‘lak ma’lum: 6'],{part:'6'})},function(){f2bm('Sonning 1/4 qismi 6 ga teng. Son?','?',4,1,f2rep(4,6),['Hamma bo‘laklar teng — har biri 6'],{part:'6'})},function(){f2bm('Sonning 1/4 qismi 6 ga teng. Son?','24',4,1,f2rep(4,6),['6 · 4 = <b>24</b> — butun son'],{part:'6'})}];
var F2P5=[function(){f2bm('Yo‘l 270 m. 1/3 qismi bosildi. Qancha qoldi?','270 m',3,0,null,['Yo‘l 3 ta teng bo‘lak'])},function(){f2bm('Yo‘l 270 m. 1/3 qismi bosildi. Qancha qoldi?','270 m',3,1,f2rep(3,90),['270 : 3 = <b>90</b> m — bosib o‘tildi'],{part:'90'})},function(){f2bm('Yo‘l 270 m. 1/3 qismi bosildi. Qancha qoldi?','270 m',3,1,f2rep(3,90),['270 : 3 = 90 m — bosildi','270 − 90 = <b>180</b> m qoldi (yoki 90 · 2)'],{part:'90',rest:'180 m'})}];
var F2P6=[function(){f2bm('24 olma: 1/3 Aliga, QOLGANINING yarmi Valiga','24',3,1,f2rep(3,8),['24 : 3 = 8 — Aliga. Qoldi 24 − 8 = <b>16</b>'],{part:'Ali 8',rest:'qoldi 16'})},
 function(){clear();T(S.g,14,22,'Endi QOLGAN 16 — yangi butun',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});f3bar(80,62,200,40,2,1,C.b,['8','8']);Br(80,280,58,'16',true);Br(80,180,106,'Vali 8',false,C.ok);Br(180,280,106,'qoldi 8',false,C.bad);f3calc(['16 ning yarmi: 16 : 2 = 8 — Valiga','Qoldi: 16 − 8 = <b>8</b> ta olma'])}];
var F2P7=[function(){f2bm('Lentaning 1/3 qismi 24 sm. 1/4 qismi?','?',3,1,['24','',''],['1/3 qism = 24 sm — bitta bo‘lak'],{part:'24 sm'})},function(){f2bm('Lentaning 1/3 qismi 24 sm. 1/4 qismi?','72 sm',3,1,f2rep(3,24),['Butun: 24 · 3 = <b>72</b> sm'])},function(){f2bm('Lentaning 1/3 qismi 24 sm. 1/4 qismi?','72 sm',4,1,f2rep(4,18),['Endi 72 ni 4 ga bo‘lamiz: 72 : 4 = <b>18</b> sm'],{part:'18 sm',col:C.b})}];
var F2P8=[function(){f2bm('Pulning 1/4 qismiga — 1500 so‘mga daftar olindi. Qancha qoldi?','?',4,1,['1500','','',''],['1500 so‘m — bu 1 ta bo‘lak (1/4)'],{part:'daftar'})},function(){f2bm('Pulning 1/4 qismiga — 1500 so‘mga daftar olindi. Qancha qoldi?','6000',4,1,f2rep(4,1500),['Hamma pul: 1500 · 4 = 6000 so‘m'],{part:'daftar'})},function(){f2bm('Pulning 1/4 qismiga — 1500 so‘mga daftar olindi. Qancha qoldi?','6000',4,1,f2rep(4,1500),['Qoldi 3 bo‘lak: 1500 · 3 = <b>4500</b> so‘m'],{part:'daftar',rest:'qoldi 4500'})}];
var STEPS=[
{h:"Teng tarqatamiz",sum:"12 konfetni 3 bolaga teng bo'lsak — har biriga 4 ta. 4 — bu 12 ning 1/3 qismi.",a:"m01",
 start:function(){startPh(F2P1)},fin:function(){S.ph=2;F2P1[2]()},
 html:"<p>12 ta konfetni 3 ta bolaga <b>teng</b> tarqatamiz. Har biriga nechta tegadi? Tarqatishni kuzating.</p>",btns:[phaser(F2P1,'▶ Tarqatish')],
 after:"<p>Har bir bolaga tegishi — bu 12 ning <b>uchdan bir</b> qismi (1/3). Uni topish uchun 12 ni <b>3 ga bo'ldik</b>: 12 : 3 = 4.</p>",
 q:{t:"20 ta olmaning 1/4 qismi nechta?",opts:["4","5","16","80"],ok:1,why:"20 : 4 = 5.",hint:"20 ni 4 ta teng guruhga bo'lsangiz, bitta guruhda nechta bo'ladi?",full:"1/4 — 4 ta teng bo'lakdan bittasi. 20 : 4 = 5. «16» — 20 dan 4 ni ayirish, «80» — ko'paytirish xatosi."},
 tn:"Bolalar haqiqiy narsalarni (tugma, loviya) likopchalarga bittalab tarqatsin — bu bo'lishning eng tushunarli modeli."},
{h:"Qoida: sonni maxrajga bo'lamiz",sum:"Sonning 1/n qismi = son : n. 24 ning 1/4 qismi = 6, 1/6 qismi = 4.",a:"m02",
 start:function(){S.n=4;f2rule()},fin:function(){S.n=4;f2rule()},
 html:"<p>24 ni necha bo'lakka bo'lishni tanlang va bitta bo'lak qanchaga tengligini ko'ring:</p>",
 btns:[["1/2",function(c,done){S.n=2;f2rule();mvK(done)}],["1/3",function(c,done){S.n=3;f2rule();mvK(done)}],["1/4",function(c,done){S.n=4;f2rule();mvK(done)}],["1/6",function(c,done){S.n=6;f2rule();mvK(done)}],["1/8",function(c,done){S.n=8;f2rule();mvK(done)}],["1/12",function(c,done){S.n=12;f2rule();mvK(done)}]],g3:1,
 after:"<p><b>Qoida:</b> sonning 1/n qismini topish uchun sonni <b>n ga bo'lamiz</b>. Bo'laklar ko'p bo'lsa, har biri kichik: 24 ning 1/12 qismi atigi 2.</p>",
 q:{t:"36 ning 1/9 qismi nechaga teng?",opts:["9","27","4","45"],ok:2,why:"36 : 9 = 4.",hint:"36 ni 9 ta teng bo'lakka bo'ling.",full:"1/9 qism = 36 : 9 = 4. «27» = 36 − 9, «45» = 36 + 9 — bular ulush emas."},
 tn:"Doskaga bir xil son uchun har xil ulushlar jadvalini yozing: 24 → 12, 8, 6, 4, 3, 2."},
{h:"Bir nechta ulush",sum:"24 ning 3/4 qismi: 24 : 4 = 6 (bitta bo'lak), 6 · 3 = 18.",a:"m03",
 start:function(){startPh(F2P3)},fin:function(){S.ph=2;F2P3[2]()},
 html:"<p>Endi bitta emas, bir nechta bo'lak kerak: <b>24 ning 3/4 qismi</b>. Chizma bilan yechamiz.</p>",btns:[phaser(F2P3)],
 after:"<p>Ikki qadam: 1) <b>maxrajga bo'lamiz</b> — bitta bo'lak (24 : 4 = 6); 2) <b>suratga ko'paytiramiz</b> — kerakli bo'laklar (6 · 3 = 18).</p>",
 q:{t:"30 ning 2/5 qismi nechaga teng?",opts:["6","12","15","75"],ok:1,why:"30 : 5 = 6, 6 · 2 = 12.",hint:"Avval bitta bo'lakni toping: 30 ni nechaga bo'lamiz?",full:"1/5 qism: 30 : 5 = 6. 2/5 qism: 6 · 2 = 12. «6» — faqat bitta bo'lak, «15» — 30 ning yarmi."},
 tn:"Har masalada avval chizma chizdiring: butun — uzun to'rtburchak, maxrajcha bo'lak."},
{h:"Ulushiga ko'ra sonni topamiz",sum:"Sonning 1/4 qismi 6 bo'lsa, son = 6 · 4 = 24 (teskari amal).",a:"m04",
 start:function(){startPh(F2P4)},fin:function(){S.ph=2;F2P4[2]()},
 html:"<p>Teskari masala: butun <b>noma'lum</b>, uning bitta bo'lagi ma'lum. <i>«Sonning 1/4 qismi 6 ga teng. Son nechaga teng?»</i></p>",btns:[phaser(F2P4)],
 after:"<p>Bitta bo'lak 6 ga teng, butunda 4 ta shunday bo'lak — <b>ko'paytiramiz</b>: 6 · 4 = 24. Tekshirish: 24 ning 1/4 qismi = 6 ✓</p><p>Farqi: «sonning ulushi» — <b>bo'lamiz</b>, «ulushiga ko'ra son» — <b>ko'paytiramiz</b>.</p>",
 q:{t:"Sonning 1/5 qismi 9 ga teng. Shu son nechaga teng?",opts:["45","14","4","9"],ok:0,why:"9 · 5 = 45.",hint:"9 — butun emas, bitta bo'lak. Butunda nechta bo'lak bor?",full:"Butun 5 ta bo'lak, har biri 9: 9 · 5 = 45. Tekshiramiz: 45 : 5 = 9 ✓. «4» — 9 ni 5 ga bo'lmoqchi bo'lish xatosi."},
 tn:"Ikkala turini yonma-yon yozdiring va bolalar o'zi qoida chiqarsin: qachon bo'lamiz, qachon ko'paytiramiz."},
{h:"Qolgan qismni topish",sum:"270 m yo'lning 1/3 qismi = 90 m bosildi, qoldi 270 − 90 = 180 m (yoki 2/3 qism).",a:"m05",
 start:function(){startPh(F2P5)},fin:function(){S.ph=2;F2P5[2]()},
 html:"<p><i>«Maktabdan uygacha 270 m. O'quvchi yo'lning uchdan bir qismini bosib o'tdi. Uyigacha yana necha metr qoldi?»</i></p>",btns:[phaser(F2P5)],
 after:"<p>Savol <b>qolgan</b> qism haqida! 90 m — bu bosilgani, javob emas. Qolgan qism: 270 − 90 = 180 m yoki 2/3 qism: 90 · 2 = 180 m.</p>",
 q:{t:"Kitob 60 bet. Ali uning 1/4 qismini o'qidi. Necha bet qoldi?",opts:["15","45","56","240"],ok:1,why:"60 : 4 = 15 o'qildi, 60 − 15 = 45 qoldi.",hint:"Avval nechta bet o'qilganini toping, keyin qolganini.",full:"O'qildi: 60 : 4 = 15 bet. Qoldi: 60 − 15 = 45 bet (3/4 qism). «15» — bu o'qilgani, savol qolgani haqida."},
 tn:"Savolni oxirigacha o'qishni o'rgating: «qancha bosildi?» va «qancha qoldi?» — har xil savol."},
{h:"Tuzoq: «qolganining» ulushi",sum:"24 olma: 1/3 = 8 Aliga, qoldi 16; QOLGANINING yarmi = 8 Valiga; qoldi 8.",a:"m06",
 start:function(){startPh(F2P6)},fin:function(){S.ph=1;F2P6[1]()},
 html:"<p><i>«24 ta olmaning 1/3 qismi Aliga berildi, <b>qolganining</b> yarmi Valiga. Nechta olma qoldi?»</i> «Qolganining» so'zi hammasini o'zgartiradi!</p>",btns:[phaser(F2P6)],
 after:"<p>«Qolganining yarmi» — bu 24 ning yarmi emas, <b>qolgan 16</b> ning yarmi. Qolgan qism <b>yangi butun</b> bo'ladi — yangi chizma chizamiz.</p>",
 q:{t:"30 ta konfetning 1/5 qismi yeyildi, qolganining yarmi do'stlarga berildi. Nechta qoldi?",opts:["15","12","9","24"],ok:1,why:"30 : 5 = 6 yeyildi, qoldi 24; 24 ning yarmi 12 berildi; qoldi 12.",hint:"Avval yeyilgandan keyin nechta qolganini toping. Keyin O'SHANING yarmini.",full:"Yeyildi: 30 : 5 = 6. Qoldi: 24. Qolganining yarmi: 24 : 2 = 12 berildi. Qoldi: 24 − 12 = 12. «15» — 30 ning yarmini olish xatosi."},
 tn:"«Qolganining» so'zini doira ichiga olishni o'rgating. Har bir «qolganining»dan keyin yangi chizma."},
{h:"Tuzoq: bir ulushdan boshqa ulushga",sum:"1/3 qismi 24 sm → butun 72 sm → 1/4 qismi 18 sm.",a:"m07",
 start:function(){startPh(F2P7)},fin:function(){S.ph=2;F2P7[2]()},
 html:"<p><i>«Lentaning 1/3 qismi 24 sm. Shu lentaning 1/4 qismi necha santimetr?»</i> Ko'pchilik 24 : 4 = 6 deydi. Tekshiramiz!</p>",btns:[phaser(F2P7)],
 after:"<p>Ikki qadam: avval <b>butunni</b> topamiz (24 · 3 = 72), keyin undan <b>yangi ulushni</b> (72 : 4 = 18). 24 — butun emas, uni 4 ga bo'lib bo'lmaydi!</p>",
 q:{t:"Sonning 1/2 qismi 30 ga teng. Shu sonning 1/3 qismi nechaga teng?",opts:["10","20","15","90"],ok:1,why:"Son = 30 · 2 = 60, 60 : 3 = 20.",hint:"Avval butun sonni toping.",full:"Butun: 30 · 2 = 60. Uning 1/3 qismi: 60 : 3 = 20. «10» — 30 ni 3 ga bo'lish xatosi, 30 butun emas."},
 tn:"Bu bank testidagi (3F2) eng qiyin tur. Bolalar avval «butun»ni so'z bilan topsin: «butun lenta qancha?»"},
{h:"Tuzoq: puldan qoldiq",sum:"Pulning 1/4 qismi 1500 so'm → butun 6000 → qoldi 3/4 = 4500 so'm.",a:"m08",
 start:function(){startPh(F2P8)},fin:function(){S.ph=2;F2P8[2]()},
 html:"<p><i>«Bola pulining to'rtdan biriga — 1500 so'mga daftar oldi. Unda necha so'm qoldi?»</i></p>",btns:[phaser(F2P8)],
 after:"<p>Ikki usul: 1) hamma pul 1500 · 4 = 6000, qoldi 6000 − 1500 = 4500; 2) qolgan qism 3 ta bo'lak: 1500 · 3 = 4500. Ikkinchisi tezroq!</p>",
 q:{t:"Ona pulining 1/3 qismiga — 20 000 so'mga go'sht oldi. Qancha pul qoldi?",opts:["60 000","40 000","20 000","10 000"],ok:1,why:"Qoldi 2 bo'lak: 20 000 · 2 = 40 000.",hint:"20 000 — nechta bo'lak? Nechta bo'lak qoldi?",full:"1/3 qism = 20 000. Butun = 60 000. Qoldi 2/3 qism: 20 000 · 2 = 40 000 so'm. «60 000» — bu hamma pul, qolgani emas."},
 tn:"Pulga oid masalalarni bolalar oilaviy xarid bilan bog'lasin."},
{h:"Bilasizmi? 3600 yillik masalalar",sum:"Qadimgi Misrning Rind papirusida nonlarni teng bo'lishga oid masalalar bor.",a:"m09",
 start:function(){f2hist()},fin:function(){f2hist()},
 html:"<p>📜 Qadimgi Misrda yozilgan <b>Rind papirusi</b> — taxminan 3600 yillik matematika kitobi. Unda bugungi masalalarga juda o'xshash topshiriqlar bor: bir nechta <b>nonni bir necha kishiga teng bo'lish</b>.</p><p>⭐ Ulushlarni topish — savdo, meros taqsimlash va yer o'lchashda kerak bo'lgan. Vatandoshimiz <b>al-Xorazmiy</b> o'z kitobida aynan meros taqsimlash masalalariga katta bo'lim ajratgan.</p>",
 tn:"Bolalarga sinfda «10 ta nonni 4 kishiga teng bo'lish» masalasini bering: har biriga 2 ta butun va yarim non."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.ph=2;F2P3[2]()},fin:function(){S.ph=2;F2P3[2]()},
 html:"<div class='memo'><ul><li><b>Sonning 1/n qismi</b> = son : n. 24 ning 1/4 qismi = 6.</li><li><b>Sonning k/n qismi</b> = son : n · k. 24 ning 3/4 qismi = 18.</li><li><b>Ulushiga ko'ra son</b>: 1/4 qismi 6 → son = 6 · 4 = 24.</li><li><b>Qolgan qism</b>: butun − olingan (yoki qolgan bo'laklar soni · bitta bo'lak).</li><li><b>«Qolganining»</b> — qolgan qism yangi butun.</li><li><b>Bir ulushdan boshqasiga</b>: avval butunni toping.</li><li>Doim chizma chizing va javobni tekshiring.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring."}
];
function f2rule(){var n=S.n,v=24/n;clear();T(S.g,14,22,'24 ning 1/'+n+' qismi',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});f3bar(30,62,300,40,n,1,null,f2rep(n,n<=8?v:''));Br(30,330,58,'24',true);Br(30,30+300/n,106,String(v),false,C.ok);f3calc(['24 : '+n+' = <b>'+v+'</b>'])}
function f2candy(st){clear();var g=S.g;for(var p=0;p<3;p++){E('ellipse',{cx:70+p*110,cy:130,rx:44,ry:14,fill:'#eef2f6',stroke:'#c9d3dd'},g);T(g,70+p*110,160,(p+1)+'-bola',{'font-size':11})}
 for(var i=0;i<12;i++){var x,y;if(st===0){x=60+i*20;y=40}else if(st===1){var p2=i%3,j=Math.floor(i/3);if(j<1){x=55+p2*110+j*12;y=124}else{x=60+i*20;y=40}}else{var p3=i%3,j3=Math.floor(i/3);x=46+p3*110+j3*15;y=124}
  E('circle',{cx:x,cy:y,r:7,fill:['#f08aa8','#5aa9e6','#f0a040'][i%3],stroke:'#fff','stroke-width':1.5},g)}}
function f2hist(){clear('#f6ead0');var g=S.g;for(var i=0;i<10;i++)E('ellipse',{cx:40+i*30,cy:60,rx:12,ry:8,fill:'#d9a35a',stroke:'#8a5a24'},g);for(var p=0;p<4;p++){E('circle',{cx:65+p*76,cy:120,r:14,fill:'#cfd6de'},g);T(g,65+p*76,150,'2½ non',{'font-size':11,'font-weight':700,fill:'#6b3d12'})}f3msg('10 non, 4 kishi: har biriga 2 ta butun va yarim non')}
var PROBS=[
{t:"18 ning 1/3 qismi nechaga teng?",o:["6","15","9","54"],k:0,s:"18 : 3 = 6."},
{t:"40 ning 1/8 qismi nechaga teng?",o:["5","32","8","48"],k:0,s:"40 : 8 = 5."},
{t:"28 ning 3/4 qismi nechaga teng?",o:["21","7","24","12"],k:0,s:"28 : 4 = 7, 7 · 3 = 21."},
{t:"Sonning 1/6 qismi 7 ga teng. Son?",o:["42","13","1","36"],k:0,s:"7 · 6 = 42."},
{t:"Sonning 2/3 qismi 16 ga teng. Son?",o:["24","8","32","48"],k:0,s:"16 : 2 = 8 — 1/3 qism, 8 · 3 = 24."},
{t:"Sinfda 36 o'quvchi, ularning 1/4 qismi o'g'il bolalar. Qizlar nechta?",o:["27","9","32","18"],k:0,s:"O'g'illar 36 : 4 = 9, qizlar 36 − 9 = 27."},
{t:"Sinfda 36 o'quvchi, 1/4 qismi a'lochi. A'lochi bo'lmaganlar a'lochilardan nechta ko'p?",o:["18","9","27","12"],k:0,s:"A'lochi 9, qolgan 27. 27 − 9 = 18."},
{t:"270 m yo'lning 1/3 qismi bosildi. Necha metr qoldi?",o:["180","90","267","170"],k:0,s:"270 : 3 = 90 bosildi, 270 − 90 = 180 qoldi."},
{t:"Bola pulining 1/4 qismiga — 1500 so'mga daftar oldi. Necha so'm qoldi?",o:["4500","6000","1500","375"],k:0,s:"Qoldi 3 bo'lak: 1500 · 3 = 4500."},
{t:"24 ta olmaning 1/3 qismi Aliga, qolganining yarmi Valiga berildi. Nechta qoldi?",o:["8","4","12","16"],k:0,s:"Ali 8, qoldi 16; Vali 8, qoldi 8."},
{t:"Lentaning 1/3 qismi 24 sm. Shu lentaning 1/4 qismi?",o:["18 sm","8 sm","6 sm","24 sm"],k:0,s:"Butun 72 sm, 72 : 4 = 18 sm."},
{t:"Bir sutkaning 1/3 qismi necha soat?",o:["8","3","12","6"],k:0,s:"24 : 3 = 8 soat."},
{t:"1 metrning 1/5 qismi necha santimetr?",o:["20","5","50","15"],k:0,s:"1 m = 100 sm, 100 : 5 = 20 sm."},
{t:"1 kg ning 3/4 qismi necha gramm?",o:["750","250","300","34"],k:0,s:"1000 : 4 = 250, 250 · 3 = 750 g."},
{t:"Ali 48 betli kitobning 1/4 qismini, Vali 30 betli kitobning 1/3 qismini o'qidi. Kim ko'p o'qidi va nechta?",o:["Ali, 2 bet","Vali, 2 bet","Teng","Ali, 10 bet"],k:0,s:"Ali 12, Vali 10. Ali 2 bet ko'p."},
{t:"Sonning 1/2 qismi 30. Shu sonning 1/3 qismi?",o:["20","10","15","90"],k:0,s:"Son 60, 60 : 3 = 20."},
{t:"Do'konda 60 kg un bor edi. 1/3 qismi sotildi, qolganining 1/4 qismi ham sotildi. Necha kg qoldi?",o:["30","40","35","25"],k:0,s:"Sotildi 20, qoldi 40; 40 : 4 = 10 sotildi; qoldi 30."},
{t:"Ona pulining 1/5 qismiga — 8 000 so'mga non oldi. Unda qancha pul bor edi?",o:["40 000","1 600","13 000","32 000"],k:0,s:"8 000 · 5 = 40 000 so'm."},
{t:"Arqonning 3/5 qismi 30 m. Butun arqon necha metr?",o:["50","18","10","90"],k:0,s:"30 : 3 = 10 — 1/5 qism, 10 · 5 = 50 m."},
{t:"Bog'da 40 tup daraxt: 1/4 qismi olma, 1/5 qismi nok, qolgani o'rik. O'rik nechta?",o:["22","18","10","8"],k:0,s:"Olma 10, nok 8, o'rik 40 − 18 = 22."}
];
function PRACT_STAGE(){S.ph=2;F2P3[2]();f3msg('Avval chizma chizing: butun — tasma')}
var PREP_DATA={teach:["Sonning ulushini topish (bo'lish orqali) va bir nechta ulush (bo'lib, ko'paytirish).","Ulushiga ko'ra sonni topish (ko'paytirish).","Qolgan qism; «qolganining» ulushi; bir ulushdan boshqa ulushga o'tish."],
 mist:["Ikki turini aralashtiradi: ulushiga ko'ra sonni topishda bo'ladi.","Savol «qancha qoldi?» bo'lsa ham olingan qismni javob qiladi.","«Qolganining yarmi»da butunning yarmini oladi.","«1/3 qismi 24 → 1/4 qismi?»da 24 ni 4 ga bo'ladi."],
 need:["Tugma yoki loviya (tarqatish uchun), likopchalar.","Qog'oz tasmalar."],
 board:["Tarqatish: <span class='w2'>12 : 3 = 4</span> — 1/3 qism.","<span class='w2'>24 ning 3/4 = 24 : 4 · 3 = 18</span>.","<span class='w2'>1/4 qismi 6 → 6 · 4 = 24</span>.","Qolgan: <span class='w2'>270 − 90 = 180</span>.","«Qolganining»: ikki qavatli chizma.","<span class='w2'>1/3 = 24 → butun 72 → 1/4 = 18</span>."]};
