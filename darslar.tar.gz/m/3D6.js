var CODE='3D6',TITLE='3-sinf · Tarkibli tenglamalar va ularni soddalashtirish';
function d6Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
var P1=[function(){w3Bal(['x','x','x'],['24']);w3Msg('Pallada 3 ta bir xil quti — har birida x')},
 function(){w3Bal([{t:'3 · x',c:C.a}],['24']);w3Msg('x + x + x = <b>3 · x</b> (qisqacha 3x)')},
 function(){w3Bal(['x'],['8']);w3Msg('3x = 24 → x = 24 : 3 = <b>8</b>')}];
var P4=[function(){w3Expr(['(x + 3) · 4 = 36']);w3Msg('Oxirgi amal — ko‘paytirish')},
 function(){w3Expr(['[(x + 3)] · 4 = 36','x + 3 = 36 : 4 = {9}']);w3Msg('Ko‘paytuvchi = ko‘paytma : ko‘paytuvchi')},
 function(){w3Expr(['x + 3 = 9','x = 9 − 3 = {6}']);w3Msg('Qo‘shiluvchi = yig‘indi − qo‘shiluvchi')},
 function(){w3Expr(['(6 + 3) · 4 = 9 · 4 = {36} ✓']);w3Msg('Tekshiruv — <b>x = 6</b>')}];
var P5=[function(){w3Expr(['246 : (7 · (x + 1) − 15) = 6']);w3Msg('Bankdagi eng qiyin tur. Qavatma-qavat archiymiz')},
 function(){w3Expr(['246 : [( … )] = 6','7 · (x + 1) − 15 = {41}']);w3Msg('1: bo‘luvchi = bo‘linuvchi : bo‘linma = 246 : 6 = 41')},
 function(){w3Expr(['[7 · (x + 1)] − 15 = 41','7 · (x + 1) = {56}']);w3Msg('2: kamayuvchi = ayirma + ayriluvchi: 41 + 15 = 56')},
 function(){w3Expr(['7 · [(x + 1)] = 56','x + 1 = 56 : 7 = {8}']);w3Msg('3: ko‘paytuvchi = ko‘paytma : 7')},
 function(){w3Expr(['x + 1 = 8','x = {7}']);w3Msg('4: x = 8 − 1 = <b>7</b>')},
 function(){w3Expr(['7 · (7 + 1) − 15 = 56 − 15 = 41','246 : 41 = {6} ✓']);w3Msg('Tekshiruv: to‘g‘ri!')}];
var P6=[function(){w3Bal(['3x','2x','6'],['3x','20']);w3Msg('5x + 6 = 3x + 20 — ikkala tomonda ham x bor!')},
 function(){w3Bal([{t:'3x',c:'#f6c9c9'},'2x','6'],[{t:'3x',c:'#f6c9c9'},'20']);w3Msg('Ikkala pallada ham 3x bor — ularni olib tashlaymiz')},
 function(){w3Bal(['2x','6'],['20']);w3Msg('Qoldi: 2x + 6 = 20')},
 function(){w3Bal(['2x'],['14']);w3Msg('Ikkala tomondan 6 ni olamiz: 2x = 14')},
 function(){w3Bal(['x'],['7']);w3Msg('x = 14 : 2 = <b>7</b>')}];
var P7=[function(){w3Bar([{lab:'1-son',segs:[{w:1,t:'x',c:'#cfe6f7'}],tot:4},{lab:'2-son',segs:[{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'}],tot:4}],{top:30,gap:60});w3Msg('2-son 1-sondan 3 marta katta')},
 function(){w3Bar([{lab:'1-son',segs:[{w:1,t:'x',c:'#cfe6f7'}],tot:4},{lab:'2-son',segs:[{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'}],tot:4},{lab:'jami',segs:[{w:1,t:'x',c:'#cfe6f7'},{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'},{w:1,t:'x',c:'#f2b766'}],br:'48'}],{top:10,gap:58});w3Msg('x + 3x = 4x = 48')},
 function(){w3Expr(['x + 3x = 48','4x = 48 → x = {12}','2-son: 3 · 12 = {36}']);w3Msg('Tekshiruv: 12 + 36 = 48 ✓, 36 : 12 = 3 ✓')}];
function d6Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Bir xil qo'shiluvchilarni birlashtiramiz",sum:"x + x + x = 3x. 3x = 24 → x = 8.",a:"m01",
 start:function(){startPh(P1)},fin:d6Fin(P1),
 html:"<p>Tarozining chap pallasida 3 ta bir xil quti, o'ngida 24 kg. Bitta quti necha kg? Bosib kuzating:</p>",btns:[phaser(P1)],
 after:"<p><b>Soddalashtirish</b>: bir xil qo'shiluvchilarni ko'paytirish bilan yozamiz: x + x + x = <b>3x</b>. Shundan keyin tenglama oddiy bo'lib qoladi: 3x = 24, x = 8.</p>",
 q:{t:"x + x + x + x = 28. x = ?",opts:["7","24","112","4"],ok:0,why:"4x = 28 → x = 7.",hint:"x nechta? Ularni ko'paytirish bilan yozing.",full:"x + x + x + x = 4x. 4x = 28 → x = 28 : 4 = 7. «24» — 28 − 4."},
 tn:"Bir xil gugurt qutichalari va tarozi (yoki «tarozi» rasmi) bilan ishlang."},
{h:"O'xshash hadlarni qo'shamiz: 3x + 2x",sum:"3x + 2x = 5x. 5x = 45 → x = 9.",a:"m02",
 start:function(){w3Expr(['3x + 2x = 45']);w3Msg('3x + 2x nechta x?')},fin:function(){w3Expr(['3x + 2x = 45','5x = 45','x = 45 : 5 = {9}']);w3Msg('Tekshiruv: 27 + 18 = 45 ✓')},
 html:"<p><b>3x + 2x = 45</b>. 3 ta quti va yana 2 ta quti — jami nechta quti? Soddalashtiring:</p><div class='digs w3c'></div>",
 act:function(c,done){d6Sel(c,'.w3c',['5x','6x','5'],'5x',function(){w3Expr(['3x + 2x = 45','5x = 45','x = 45 : 5 = {9}']);w3Msg('Tekshiruv: 3 · 9 + 2 · 9 = 27 + 18 = 45 ✓');done()},{'6x':'3 · 2 = 6 emas — qutilarni qo‘shamiz: 3 + 2','5':'x lar yo‘qolmaydi: 3 ta x + 2 ta x = 5 ta x'})},
 after:"<p>Qoida: <b>3x + 2x = (3 + 2)x = 5x</b>. «3 ta olma + 2 ta olma = 5 ta olma» kabi. x yo'qolib ketmaydi!</p>",
 q:{t:"7x − 2x = 35. x = ?",opts:["7","5","35","4"],ok:0,why:"5x = 35 → x = 7.",hint:"7 ta x dan 2 ta x olib tashlansa?",full:"7x − 2x = 5x. 5x = 35 → x = 7. «5» — 5x ni javob deb qoldirish."},
 tn:"«x» deb yozilgan kartochkalar bilan: 3 tasi + 2 tasi — bolalar o'zi sanasin."},
{h:"Tuzoq: yolg'iz x — bu 1x",sum:"4x + x = 5x (4x emas!). 5x = 50 → x = 10.",a:"m03",
 start:function(){w3Expr(['4x + x = 50']);w3Msg('4x + x = ?')},fin:function(){w3Expr(['4x + x = 4x + 1x','= 5x = 50','x = {10}']);w3Msg('Yolg‘iz x oldida «1» yashiringan')},
 html:"<p><b>4x + x = 50</b>. Yolg'iz turgan <b>x</b> nechta x? Soddalashtiring:</p><div class='digs w3c'></div>",
 act:function(c,done){d6Sel(c,'.w3c',['4x','5x','4x²'],'5x',function(){w3Expr(['4x + x = 4x + 1x','= 5x = 50','x = 50 : 5 = {10}']);w3Msg('Tekshiruv: 40 + 10 = 50 ✓');done()},{'4x':'Yolg‘iz x ham hisob — u 1 ta x','4x²':'Bu boshqa narsa — biz qo‘shyapmiz, ko‘paytirmayapmiz'})},
 after:"<p><b>x = 1x</b> — oldidagi 1 yozilmaydi, lekin u bor. Shuning uchun 4x + x = 5x, x · 3 + x = 4x.</p>",
 q:{t:"x · 3 + x = 64. x = ?",opts:["16","21","32","61"],ok:0,why:"4x = 64 → x = 16.",hint:"x · 3 = 3x, yana bitta x.",full:"3x + x = 4x = 64 → x = 16. «21» — 64 : 3 ni urinish (yolg'iz x unutilgan)."},
 tn:"Bu — eng ko'p uchraydigan xato. Doskada «x = 1x» ni katta yozib qo'ying."},
{h:"Qavsli tenglama: (x + 3) · 4 = 36",sum:"x + 3 = 36 : 4 = 9 → x = 6.",a:"m04",
 start:function(){startPh(P4)},fin:d6Fin(P4),
 html:"<p>Qavs ichidagi ifodani «bitta son» deb qaraymiz va oxirgi amaldan boshlaymiz:</p>",btns:[phaser(P4)],
 after:"<p>x = <b>6</b>. Tez-tez qilinadigan xato: 36 : 4 = 9 ni topib, x = 9 deb to'xtash. Hali qavs ichidagi «+ 3» qoldi!</p>",
 q:{t:"(x − 5) · 6 = 42. x = ?",opts:["12","7","2","37"],ok:0,why:"x − 5 = 7 → x = 12.",hint:"Avval x − 5 = 42 : 6.",full:"42 : 6 = 7 → x − 5 = 7 → x = 12. «7» — bitta qadamda to'xtab qolish; «2» — 7 − 5."},
 tn:"Amallarni ustiga raqamlang (1 — qavs, 2 — · 4), yechish — teskari tartibda."},
{h:"Bank misoli: to'rt qavatli tenglama",sum:"246 : (7 · (x + 1) − 15) = 6 → 7 · (x + 1) − 15 = 41 → 7 · (x + 1) = 56 → x + 1 = 8 → x = 7.",a:"m05",
 start:function(){startPh(P5)},fin:d6Fin(P5),
 html:"<p>Bankdagi eng murakkab tur: x to'rt qavat ichida. Har bosishda bitta qavat:</p>",btns:[phaser(P5)],
 after:"<p>x = <b>7</b>. Har qadamda faqat bitta savol: «<b>eng tashqi</b> amal qaysi va bu yerda noma'lum qaysi komponent?» Qavatlar qancha bo'lsa ham, usul o'sha.</p>",
 q:{t:"(96 − x) : 4 = 18. x = ?",opts:["24","168","78","22"],ok:0,why:"96 − x = 72 → x = 24.",hint:"Bo'linuvchi = 18 · 4.",full:"96 − x = 72, x — ayriluvchi: 96 − 72 = 24. «168» — 72 + 96 (ayriluvchini qo'shib topish)."},
 tn:"Har qavatni alohida qatorda, chap tomonda qolgan «piyoz»ni yozib boring."},
{h:"x ikkala tomonda: 5x + 6 = 3x + 20",sum:"Ikkala tomondan 3x ni olamiz: 2x + 6 = 20 → 2x = 14 → x = 7.",a:"m06",
 start:function(){startPh(P6)},fin:d6Fin(P6),
 html:"<p>Olimpiada darajasi: x ikkala tomonda. Tarozi yordam beradi — ikkala palladan bir xil narsani olsak, muvozanat buzilmaydi.</p>",btns:[phaser(P6)],
 after:"<p>x = <b>7</b>. Tekshiruv: 5 · 7 + 6 = 41, 3 · 7 + 20 = 41 ✓. Bu usulni al-Xorazmiy <b>«al-muqobala»</b> (qarama-qarshi qo'yish, tenglashtirish) deb atagan.</p>",
 q:{t:"4x + 3 = 2x + 15. x = ?",opts:["6","3","9","18"],ok:0,why:"2x + 3 = 15 → 2x = 12 → x = 6.",hint:"Ikkala tomondan 2x ni oling.",full:"2x + 3 = 15 → 2x = 12 → x = 6. Tekshiruv: 27 = 27 ✓. «3» — 2x = 12 da 12 : 4."},
 tn:"Tarozida kartochkalarni ikkala tomondan bir vaqtda olib tashlang — bolalar «adolatli» harakatni his qilsin."},
{h:"Masala: ikki son, biri 3 marta katta",sum:"x + 3x = 48 → 4x = 48 → x = 12; ikkinchi son 36.",a:"m07",
 start:function(){startPh(P7)},fin:d6Fin(P7),
 html:"<p>«Ikki sonning yig'indisi 48. Ikkinchi son birinchisidan <b>3 marta</b> katta. Sonlarni toping.» Chizma model bilan:</p>",btns:[phaser(P7)],
 after:"<p>Birinchi son <b>12</b>, ikkinchisi <b>36</b>. Singapur usuli: lentada x ni «bir bo'lak» deb olsak, jami 4 bo'lak = 48. Tenglama va chizma — bir fikrning ikki ko'rinishi.</p>",
 q:{t:"Vali Alidan 2 marta ko'p yong'oq terdi. Birga 54 ta. Ali nechta terdi?",opts:["18","27","36","9"],ok:0,why:"x + 2x = 3x = 54 → x = 18.",hint:"Ali — x, Vali — 2x.",full:"3x = 54 → x = 18 (Ali), Vali 36. «27» — 54 : 2 (2 marta ko'p ≠ teng yarim)."},
 tn:"Avval lenta chizish, keyin tenglama — tartibni buzmang."},
{h:"Tekshirish: ildiz qaysi?",sum:"5x + 6 = 3x + 20: x = 6 → 36 ≠ 38 ✗; x = 7 → 41 = 41 ✓.",a:"m08",
 start:function(){S.w8={};w3Expr(['5x + 6 = 3x + 20','x = 6 ?   x = 7 ?']);w3Msg('Ikkala sonni tekshiring')},fin:function(){w3Expr(['x = 6:  36 ≠ 38 [✗]','x = 7:  41 = 41 {✓}']);w3Msg('Ildiz — <b>7</b>')},
 html:"<p>Ikki o'quvchi har xil javob topdi: <b>6</b> va <b>7</b>. Har birini tenglamaga qo'yib tekshiring — <b>ikkala tomonni</b> alohida hisoblang:</p>",
 btns:[["x = 6",function(c,done){S.w8.a=1;w3Expr(['chap: 5 · 6 + 6 = 36','o‘ng: 3 · 6 + 20 = 38','36 ≠ 38 [✗]']);w3Msg('Tomonlar teng emas — 6 ildiz emas');if(S.w8.b)done()}],["x = 7",function(c,done){S.w8.b=1;w3Expr(['chap: 5 · 7 + 6 = 41','o‘ng: 3 · 7 + 20 = 41','41 = 41 {✓}']);w3Msg('Tomonlar teng — <b>7</b> ildiz');if(S.w8.a)done()},'u']],g2:1,
 after:"<p>x ikkala tomonda bo'lsa, tekshirishda <b>ikkala tomonni</b> alohida hisoblang va solishtiring. Olimpiadada variantlarni shunday tez tekshirish mumkin.</p>",
 q:{t:"4x − 3 = 2x + 9 tenglamaning ildizi qaysi?",opts:["6","3","12","5"],ok:0,why:"4 · 6 − 3 = 21, 2 · 6 + 9 = 21 ✓.",hint:"Har bir variantni ikkala tomonga qo'ying.",full:"x = 6: 21 = 21 ✓. x = 3: 9 ≠ 15; x = 5: 17 ≠ 19; x = 12: 45 ≠ 33."},
 tn:"Juftlikda: biri chap tomonni, ikkinchisi o'ng tomonni hisoblaydi — keyin solishtirishadi."},
{h:"Bilasizmi? Diofant topishmog'i",sum:"Qadimgi yunon olimi Diofant qabriga uning umri haqidagi tenglama-topishmoq yozilgan, deyiladi: javob — 84 yil.",a:"m09",
 start:function(){w3Expr(['x : 6 + x : 12 + x : 7 + 5','+ x : 2 + 4 = x','x = {84}']);w3Msg('Diofant umri haqidagi topishmoq')},fin:function(){w3Expr(['x : 6 + x : 12 + x : 7 + 5','+ x : 2 + 4 = x','x = {84}']);w3Msg('Diofant umri haqidagi topishmoq')},
 html:"<p>📜 Iskandariyalik <b>Diofant</b> (taxminan III asr) — «algebraning otalaridan biri». Rivoyatga ko'ra uning qabr toshiga topishmoq yozilgan: «Umrining 1/6 qismi bolalikda, 1/12 qismi yigitlikda o'tdi, 1/7 qismidan keyin uylandi, 5 yildan so'ng o'g'li tug'ildi; o'g'li otasi umrining yarmicha yashadi; o'g'lidan 4 yil keyin Diofant vafot etdi.»</p><p>⭐ Bu tenglamaning yechimi — <b>84</b> yil. Tekshiring: 14 + 7 + 12 + 5 + 42 + 4 = 84!</p>",
 tn:"Kuchli o'quvchilar bilan 84 ni tekshirib ko'ring: 84 : 6 = 14, 84 : 12 = 7, 84 : 7 = 12, 84 : 2 = 42."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['x + x + x = 3x','3x + 2x = 5x,  4x + x = 5x']);w3Msg('Avval soddalashtiring, keyin yeching')},fin:function(){w3Expr(['x + x + x = 3x','3x + 2x = 5x,  4x + x = 5x']);w3Msg('Avval soddalashtiring, keyin yeching')},
 html:"<div class='memo'><ul><li>Bir xil hadlarni birlashtiring: 3x + 2x = 5x, 7x − 2x = 5x.</li><li>Yolg'iz x = 1x: 4x + x = 5x.</li><li>Qavsli tenglama: oxirgi amaldan boshlab, qavatma-qavat.</li><li>x ikkala tomonda: ikkala tomondan bir xil narsani oling (tarozi).</li><li>Masala: kichik sonni x deb, boshqasini x orqali yozing (3x, x + 4).</li><li>Doim tekshiring — ikkala tomonni alohida hisoblab.</li></ul></div>",
 tn:"Bu mavzu 4-sinf tenglamalariga to'g'ridan-to'g'ri ko'prik."}
];
var PROBS=[
{t:"x + x + x = 24. x = ?",o:["8","21","72","6"],k:0,s:"3x = 24 → x = 8."},
{t:"3x + 2x = 45. x = ?",o:["9","15","225","5"],k:0,s:"5x = 45 → x = 9."},
{t:"4x + x = 50. x = ?",o:["10","12","25","5"],k:0,s:"5x = 50 → x = 10."},
{t:"7x − 2x = 35. x = ?",o:["7","5","35","4"],k:0,s:"5x = 35 → x = 7."},
{t:"(x + 3) · 4 = 36. x = ?",o:["6","9","33","3"],k:0,s:"x + 3 = 9 → x = 6."},
{t:"(x − 5) · 6 = 42. x = ?",o:["12","7","2","37"],k:0,s:"x − 5 = 7 → x = 12."},
{t:"x · 3 + x = 64. x = ?",o:["16","21","32","61"],k:0,s:"4x = 64 → x = 16."},
{t:"6x − x − x = 28. x = ?",o:["7","14","28","4"],k:0,s:"4x = 28 → x = 7."},
{t:"312 : (5 · (x − 2) + 9) = 8. x = ?",o:["8","6","10","39"],k:0,s:"5 · (x − 2) + 9 = 312 : 8 = 39 → 5 · (x − 2) = 30 → x − 2 = 6 → x = 8. Tekshiruv: 5 · 6 + 9 = 39, 312 : 39 = 8."},
{t:"5x + 6 = 3x + 20. x = ?",o:["7","13","3","14"],k:0,s:"2x + 6 = 20 → 2x = 14 → x = 7."},
{t:"Ikki son yig'indisi 48, ikkinchisi birinchisidan 3 marta katta. Kichik son?",o:["12","16","36","24"],k:0,s:"x + 3x = 48 → x = 12."},
{t:"Ikki son yig'indisi 48, ikkinchisi birinchisidan 3 marta katta. Katta son?",o:["36","12","32","45"],k:0,s:"x = 12, 3x = 36."},
{t:"2x + 3x + 10 = 60. x = ?",o:["10","14","12","50"],k:0,s:"5x = 50 → x = 10."},
{t:"(2x + x) : 3 = 15. x = ?",o:["15","5","45","9"],k:0,s:"3x : 3 = x = 15."},
{t:"x + 2x + 3x = 120. x = ?",o:["20","40","60","114"],k:0,s:"6x = 120 → x = 20."},
{t:"4x − 3 = 2x + 9 tenglamaning ildizi?",o:["6","3","12","5"],k:0,s:"21 = 21 ✓."},
{t:"Vali Alidan 2 marta ko'p yong'oq terdi, birga 54 ta. Ali nechta terdi?",o:["18","27","36","9"],k:0,s:"3x = 54 → x = 18."},
{t:"Sinfda 30 o'quvchi, qizlar o'g'il bolalardan 4 ta ko'p. O'g'il bolalar nechta?",o:["13","17","15","26"],k:0,s:"x + x + 4 = 30 → 2x = 26 → x = 13."},
{t:"9x − 4x + 2x = 63. x = ?",o:["9","21","7","63"],k:0,s:"7x = 63 → x = 9."},
{t:"(x + x) · 5 = 100. x = ?",o:["10","20","50","5"],k:0,s:"2x · 5 = 100 → 2x = 20 → x = 10."}
];
function PRACT_STAGE(){w3Bal(['3x','2x','6'],['3x','20']);w3Msg('Avval soddalashtiring')}
var PREP_DATA={teach:["Bir xil hadlarni birlashtirish: x + x + x = 3x, 3x + 2x = 5x.","Yolg'iz x = 1x.","Ko'p qavatli tarkibli tenglamalar (oxirgi amaldan boshlab).","x ikkala tomonda — tarozi usuli; masalalarni tenglama bilan yechish."],
 mist:["4x + x = 4x deb yolg'iz x ni tashlab yuboradi.","3x + 2x = 6x (koeffitsiyentlarni ko'paytiradi).","Qavsli tenglamada birinchi qadamda to'xtaydi: (x + 3) · 4 = 36 → x = 9.","Tekshirishda faqat bitta tomonni hisoblaydi."],
 need:["«x» yozilgan kartochkalar, tarozi.","Lenta modeli uchun rangli qog'oz tasmalar."],
 board:["<span class='w2'>x + x + x = 3x</span>.","<span class='w2'>4x + x = 5x</span>.","<span class='w2'>(x + 3) · 4 = 36 → x = 6</span>.","<span class='w2'>5x + 6 = 3x + 20 → x = 7</span>.","<span class='w2'>x + 3x = 48 → 12 va 36</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
