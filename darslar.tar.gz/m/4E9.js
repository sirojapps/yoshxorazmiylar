var CODE='4E9',TITLE='4-sinf · Daryo oqimi bo‘yicha harakat (sodda)';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
var STEPS=[
e4st({h:"Oqim yordam beradi yoki xalaqit beradi",sum:"Qayiq 15 km/soat, oqim 3 km/soat: oqim bo‘ylab 15 + 3 = 18, oqimga qarshi 15 − 3 = 12 km/soat.",a:"m01",
 frames:[{road:1,water:1,L:36,t:'Qayiqning turg‘un suvdagi tezligi 15 km/soat, oqim tezligi 3 km/soat',marks:[[0,'0'],[18,'18'],[36,'36 km']],obj:[{p:0,ic:'🚤',lab:'qayiq'}],note:'Daryo o‘ngga oqadi →'},
  {road:1,water:1,L:36,t:'1 soat oqim bo‘ylab',marks:[[0,'0'],[15,'15'],[18,'18'],[36,'36 km']],obj:[{p:18,ic:'🚤',lab:'qayiq'}],seg:[{a:0,b:15,lab:'o‘zi 15',up:true,col:C.blue},{a:15,b:18,lab:'+3',up:true,lv:1,col:'#12a39f'}],calc:['Oqim bo‘ylab: 15 + 3 = <b>18</b> km/soat']},
  {road:1,water:1,L:36,t:'1 soat oqimga qarshi',marks:[[0,'0'],[24,'24'],[36,'36 km']],obj:[{p:24,ic:'🚤',lab:'qayiq'}],seg:[{a:36,b:21,lab:'o‘zi 15',col:C.blue},{a:21,b:24,lab:'−3',lv:1,col:C.bad}],calc:['Oqimga qarshi: 15 − 3 = <b>12</b> km/soat','(36 dan chiqib, 12 km yurdi → 24 da)']}],
 html:"<p>Daryo suvi o'zi ham <b>harakatlanadi</b>. Qayiq oqim bilan birga yursa — suv uni itaradi, qarshi yursa — orqaga suradi. Tugmani bosing.</p>",
 after:"<p>Ikki qoida: <b>oqim bo'ylab = o'z tezligi + oqim</b>, <b>oqimga qarshi = o'z tezligi − oqim</b>. «Turg'un suvdagi tezlik» — qayiqning o'z tezligi (ko'lda).</p>",
 q:{t:"Katerning o'z tezligi 24 km/soat, oqim 4 km/soat. Oqimga qarshi tezligi?",opts:["20 km/soat","28 km/soat","24 km/soat","6 km/soat"],ok:0,why:"24 − 4 = 20.",hint:"Qarshi — ayiramiz.",full:"Oqimga qarshi: 24 − 4 = 20 km/soat. «28» — oqim bo'ylab tezlik."},
 tn:"Gollandiya RME uslubi: hayotiy kontekst. Sinfda yuruvchi zinapoya (eskalator) yoki yugurish yo'lakchasi misolini keltiring: u bilan yursangiz tezroq, qarshi — sekinroq."}),
e4st({h:"Masofani topish",sum:"Oqim bo‘ylab 18 km/soat, 4 soat: 18 · 4 = 72 km.",a:"m02",
 frames:[{road:1,water:1,L:72,t:'Qayiq (15 km/soat) oqim (3 km/soat) bo‘ylab 4 soat suzdi',marks:[[0,'0'],[18,'18'],[36,'36'],[54,'54'],[72,'72 km']],obj:[{p:0,ic:'🚤'}],note:'Avval qaysi tezlik bilan yurganini toping'},
  {road:1,water:1,L:72,t:'Qayiq (15 km/soat) oqim (3 km/soat) bo‘ylab 4 soat suzdi',marks:[[0,'0'],[18,'18'],[36,'36'],[54,'54'],[72,'72 km']],obj:[{p:72,ic:'🚤'}],seg:[{a:0,b:18,lab:'1 soat',col:'#12a39f'},{a:18,b:36,lab:'2',col:'#12a39f'},{a:36,b:54,lab:'3',col:'#12a39f'},{a:54,b:72,lab:'4',col:'#12a39f'}],calc:['1) 15 + 3 = 18 km/soat','2) 18 · 4 = <b>72</b> km']}],
 html:"<p>Masofa = tezlik · vaqt. Lekin <b>qaysi</b> tezlik? Tugmani bosing.</p>",
 after:"<p>Xato: 15 · 4 = 60 km — oqim yordamini unutish. Oqim har soatda qayiqni yana 3 km olib boradi: 4 soatda 12 km.</p>",
 q:{t:"Qayiqning o'z tezligi 12 km/soat, oqim 2 km/soat. Oqimga qarshi 3 soatda necha km yuradi?",opts:["30 km","42 km","36 km","10 km"],ok:0,why:"(12 − 2) · 3 = 30.",hint:"Avval qarshi tezlik.",full:"Qarshi tezlik: 12 − 2 = 10 km/soat; 10 · 3 = 30 km. «42» — oqim bo'ylab, «36» — oqim hisobga olinmagan."},
 tn:"Son o'qini doskada soatlarga bo'lib chizing; har soat — bir sakrash."}),
e4st({h:"Tuzoq: orqaga qaytish",sum:"Oqim bo‘ylab 4 soatda 72 km; orqaga 12 km/soat: 72 : 12 = 6 soat (4 emas!).",a:"m03",
 frames:[{road:1,water:1,L:72,t:'Qayiq 72 km ni oqim bo‘ylab 4 soatda o‘tdi. Orqaga (oqimga qarshi) necha soatda qaytadi? (o‘z tezligi 15, oqim 3)',marks:[[0,'A'],[72,'B']],obj:[{p:72,ic:'🚤'}],seg:[{a:72,b:0,lab:'orqaga ?',col:C.bad}],note:'Tanlang:'}],
 html:"<p>Yo'l o'sha, lekin endi suv qarshi. Tanlang:</p>",
 btns:e4pk(["4 soat","6 soat","5 soat"],1,{road:1,water:1,L:72,t:'Orqaga: 15 − 3 = 12 km/soat',marks:[[0,'A'],[12,''],[24,''],[36,''],[48,''],[60,''],[72,'B']],obj:[{p:0,ic:'🚤'}],seg:[{a:72,b:0,lab:'72 : 12 = 6 soat',col:C.ok}],calc:['Qarshi tezlik: 15 − 3 = 12 km/soat','72 : 12 = <b>6</b> soat']},["Yo‘l bir xil bo‘lsa ham, tezlik boshqa! Oqimga qarshi sekinroq — ko‘proq vaqt ketadi.","","72 : 15 ≈ 5 — oqim hisobga olinmadi."]),
 after:"<p>Borish 4 soat, qaytish 6 soat — jami 10 soat. Oqim bir tomonga yordam berib, ikkinchi tomonga ko'proq xalaqit beradi.</p>",
 q:{t:"Kater 60 km ni oqim bo'ylab 3 soatda o'tdi. Oqim 4 km/soat. Orqaga necha soatda qaytadi?",opts:["5 soat","3 soat","4 soat","6 soat"],ok:0,why:"60 : 3 = 20; o'z tezligi 16; qarshi 12; 60 : 12 = 5.",hint:"Avval katerning o'z tezligi: bo'ylab tezlikdan oqimni ayiring.",full:"Oqim bo'ylab: 60 : 3 = 20 km/soat. O'z tezligi: 20 − 4 = 16. Qarshi: 16 − 4 = 12 km/soat. 60 : 12 = 5 soat. «3 soat» — qaytish ham borishdek deb olingan; «4» — qarshi tezlikni 15 deb xato hisoblash."},
 tn:"Bank: 2294-id. Bolalardan avval «qaytish tezroqmi yoki sekinroqmi?» deb so'rang — taxmin, keyin hisob."}),
e4st({h:"Sol — o‘z tezligi yo‘q",sum:"Solni faqat oqim olib boradi: tezligi = oqim tezligi. 3 km/soat, 5 soat → 15 km.",a:"m04",
 frames:[{road:1,water:1,L:30,t:'Sol daryo oqimida 5 soat suzdi. Oqim 3 km/soat.',marks:[[0,'0'],[15,'15'],[30,'30 km']],obj:[{p:0,ic:'🪵',lab:'sol'}],note:'Solning o‘z motori yoki eshkagi yo‘q'},
  {road:1,water:1,L:30,t:'Sol daryo oqimida 5 soat suzdi. Oqim 3 km/soat.',marks:[[0,'0'],[15,'15'],[30,'30 km']],obj:[{p:15,ic:'🪵',lab:'sol'}],seg:[{a:0,b:15,lab:'3 · 5 = 15 km',col:'#12a39f'}],calc:['Solning tezligi = oqim tezligi = 3 km/soat','3 · 5 = <b>15</b> km']}],
 html:"<p>Sol, daraxt shoxi, qog'oz qayiqcha — ularning <b>o'z tezligi 0</b>. Ularni faqat suv olib boradi.</p>",
 after:"<p>Tuzoq: «Sol oqimga qarshi suzdi» — bo'lishi mumkin emas! Sol faqat oqim bo'ylab ketadi.</p>",
 q:{t:"Daraxt shoxi oqim bilan 4 soatda 8 km suzib ketdi. Qayiqning o'z tezligi 10 km/soat bo'lsa, u oqim bo'ylab qanday tezlikda suzadi?",opts:["12 km/soat","10 km/soat","8 km/soat","18 km/soat"],ok:0,why:"Oqim: 8 : 4 = 2; 10 + 2 = 12.",hint:"Shox tezligi = oqim tezligi.",full:"Shox tezligi = oqim = 8 : 4 = 2 km/soat. Qayiq oqim bo'ylab: 10 + 2 = 12 km/soat. «18» — 10 + 8 (masofa tezlik deb olingan)."},
 tn:"Ariqda qog'oz qayiqcha qo'yib, 10 metrni necha soniyada o'tishini o'lchang — oqim tezligini topasiz!"}),
e4st({h:"Ikki tezlikdan o‘z tezlikni topish",sum:"Oqim bo‘ylab 20, qarshi 14 km/soat: o‘z tezligi (20 + 14) : 2 = 17, oqim (20 − 14) : 2 = 3.",a:"m05",
 frames:[{t:'Kater oqim bo‘ylab 20 km/soat, oqimga qarshi 14 km/soat tezlikda suzadi.',bars:[{lab:'bo‘ylab',y:48,segs:[{w:14,txt:'14',c:'a'},{w:3,txt:'',c:'c'},{w:3,txt:'',c:'c'}]},{lab:'qarshi',y:96,segs:[{w:14,txt:'14',c:'a'}]}],max:20,note:'Farq 6 — bu oqim ikki marta'},
  {t:'Kater oqim bo‘ylab 20 km/soat, oqimga qarshi 14 km/soat tezlikda suzadi.',bars:[{lab:'bo‘ylab',y:48,segs:[{w:14,txt:'14',c:'a'},{w:3,txt:'3',c:'c'},{w:3,txt:'3',c:'c'}]},{lab:'qarshi',y:96,segs:[{w:14,txt:'14',c:'a'}]}],max:20,br:[{b:0,from:0,to:1,lab:'o‘z tezligi 17',up:true,col:C.ok}],calc:['Oqim: (20 − 14) : 2 = <b>3</b> km/soat','O‘z tezligi: 14 + 3 = <b>17</b> km/soat']}],
 html:"<p>Bu — «yig'indi va ayirma» masalasining o'zi! Tugmani bosing.</p>",
 after:"<p>Bo'ylab va qarshi tezliklar farqi = <b>2 ta oqim</b>. Shuning uchun oqim = farq : 2, o'z tezligi = ularning o'rtasi.</p>",
 q:{t:"Qayiq oqim bo'ylab 16 km/soat, qarshi 10 km/soat suzadi. Oqim tezligi?",opts:["3 km/soat","6 km/soat","13 km/soat","26 km/soat"],ok:0,why:"(16 − 10) : 2 = 3.",hint:"Farqni 2 ga bo'ling.",full:"Farq 6 — ikkita oqim. Oqim: 6 : 2 = 3 km/soat; o'z tezligi 13. «6» — farqni 2 ga bo'lish unutilgan, «13» — o'z tezligi."},
 tn:"4E7 «Yig'indi va ayirma» mavzusi bilan bog'lang — bolalar usulni o'zi taniydi."}),
e4st({h:"Tuzoq: bordi-keldi vaqti",sum:"24 km, o‘z tezligi 10, oqim 2: borish 24 : 12 = 2 soat, qaytish 24 : 8 = 3 soat, jami 5 soat.",a:"m06",
 frames:[{road:1,water:1,L:24,t:'Qayiq A dan B ga (24 km, oqim bo‘ylab) borib, qaytib keldi. O‘z tezligi 10, oqim 2 km/soat.',marks:[[0,'A'],[24,'B']],obj:[{p:0,ic:'🚤'}],seg:[{a:0,b:24,lab:'borish',up:true,col:'#12a39f'},{a:24,b:0,lab:'qaytish',col:C.bad}],note:'Jami necha soat? Tanlang:'}],
 html:"<p>«Oqim borishda yordam beradi, qaytishda xalaqit beradi — teng bo'lib qoladi» deb o'ylaysizmi? Tekshiring!</p>",
 btns:e4pk(["4 soat 48 daq","5 soat","4 soat"],1,{road:1,water:1,L:24,t:'Borish 12 km/soat, qaytish 8 km/soat',marks:[[0,'A'],[24,'B']],obj:[{p:0,ic:'🚤'}],seg:[{a:0,b:24,lab:'24 : 12 = 2 soat',up:true,col:'#12a39f'},{a:24,b:0,lab:'24 : 8 = 3 soat',col:C.bad}],calc:['Borish: 24 : (10 + 2) = 2 soat','Qaytish: 24 : (10 − 2) = 3 soat','Jami: <b>5</b> soat']},["4 soat 48 daq = 48 : 10 — oqim yo‘q deb hisoblangan. Lekin oqim bor!","","4 soat — borish va qaytish teng deb olingan (2 + 2)."]),
 after:"<p>Ko'lda (oqimsiz) 48 km ni 4 soat 48 daqiqada o'tardi. Daryoda esa 5 soat — <b>ko'proq</b>! Chunki qarshi yo'lda ko'proq vaqt o'tkaziladi.</p>",
 q:{t:"Kater 45 km ni oqim bo'ylab borib qaytdi. O'z tezligi 12, oqim 3 km/soat. Jami necha soat?",opts:["8 soat","6 soat","7 soat 30 daq","9 soat"],ok:0,why:"45 : 15 = 3; 45 : 9 = 5; 3 + 5 = 8.",hint:"Borish va qaytishni alohida hisoblang.",full:"Borish: 45 : (12 + 3) = 3 soat. Qaytish: 45 : (12 − 3) = 5 soat. Jami 8 soat. «6» — ikkala yo'l ham 3 soat deb olingan; «7 soat 30 daq» — 90 : 12, oqim hisobga olinmagan."},
 tn:"Bu xulosa (oqim har doim bordi-keldini sekinlashtiradi) — haqiqiy olimpiada g'oyasi. Kuchli o'quvchilar bilan muhokama qiling."}),
e4st({h:"Masofa va vaqtdan oqimni topish",sum:"36 km ni bo‘ylab 3 soatda, qarshi 6 soatda: 12 va 6 km/soat; oqim (12 − 6) : 2 = 3.",a:"m07",
 frames:[{road:1,water:1,L:36,t:'Qayiq 36 km ni oqim bo‘ylab 3 soatda, qaytishda 6 soatda o‘tdi. Oqim tezligi?',marks:[[0,'A'],[36,'B']],obj:[{p:0,ic:'🚤'}],seg:[{a:0,b:36,lab:'3 soat',up:true,col:'#12a39f'},{a:36,b:0,lab:'6 soat',col:C.bad}],note:'Tanlang:'}],
 html:"<p>Tezliklar berilmagan — ularni o'zingiz topasiz. Tanlang:</p>",
 btns:e4pk(["6 km/soat","9 km/soat","3 km/soat"],2,{road:1,water:1,L:36,t:'Bo‘ylab 36 : 3 = 12, qarshi 36 : 6 = 6 km/soat',marks:[[0,'A'],[36,'B']],obj:[{p:0,ic:'🚤'}],seg:[{a:0,b:36,lab:'12 km/soat',up:true,col:'#12a39f'},{a:36,b:0,lab:'6 km/soat',col:C.bad}],calc:['Oqim: (12 − 6) : 2 = <b>3</b> km/soat','O‘z tezligi: 6 + 3 = 9 km/soat']},["6 = 12 − 6 — bu ikkita oqim. Yana 2 ga bo‘ling.","9 km/soat — bu qayiqning o‘z tezligi.",""]),
 after:"<p>Uch bosqich: 1) har yo'nalishdagi tezlik (masofa : vaqt), 2) farqning yarmi — oqim, 3) o'rtasi — o'z tezligi.</p>",
 q:{t:"Qayiq 48 km ni oqim bo'ylab 4 soatda, qarshi 6 soatda o'tdi. Qayiqning o'z tezligi?",opts:["10 km/soat","2 km/soat","12 km/soat","8 km/soat"],ok:0,why:"12 va 8; (12 + 8) : 2 = 10.",hint:"Avval ikki tezlik.",full:"Bo'ylab: 48 : 4 = 12, qarshi: 48 : 6 = 8 km/soat. O'z tezligi: (12 + 8) : 2 = 10, oqim 2. «12» — bo'ylab tezlik, «8» — qarshi tezlik."},
 tn:"Doskada jadval: yo'nalish | masofa | vaqt | tezlik. Ikki qator — bo'ylab va qarshi."}),
e4st({h:"Bilasizmi? «Kon-Tiki» soli",sum:"1947-yilda Tur Xeyerdal «Kon-Tiki» solida Tinch okeanni 101 kunda, taxminan 7000 km suzib o‘tgan.",a:"m08",
 frames:[{road:1,water:1,L:7000,t:'«Kon-Tiki»: 101 kunda ≈ 7000 km',marks:[[0,'Peru'],[7000,'Polineziya']],obj:[{p:3500,ic:'🪵',lab:'sol'}],note:'Kuniga o‘rtacha ≈ 70 km — oqim va shamol bilan'}],
 html:"<p>⛵ 1947-yilda norvegiyalik sayyoh <b>Tur Xeyerdal</b> va hamrohlari motorsiz, yog'ochdan yasalgan «<b>Kon-Tiki</b>» solida Janubiy Amerikadan Polineziya orollarigacha suzib borishdi. Ular <b>101 kunda</b> taxminan <b>7000 km</b> yo'l bosishdi — solni okean oqimi va shamol olib bordi.</p>",
 after:"<p>Hisoblab ko'ring: 7000 : 101 ≈ 70 km kuniga. Soatiga esa taxminan 3 km — xuddi piyodaning tezligi!</p>",
 tn:"Xaritada yo'lni ko'rsating. Bolalar o'rtacha tezlikni o'zi hisoblasin (4E6 mavzusi bilan bog'lanish)."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){e4road({water:1,L:30,t:'v — o‘z tezlik,  o — oqim',marks:[[0,''],[30,'']],obj:[{p:15,ic:'🚤'}],seg:[{a:6,b:24,lab:'bo‘ylab: v + o',up:true,col:'#12a39f'},{a:24,b:6,lab:'qarshi: v − o',col:C.bad}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Oqim bo'ylab: <b>v + o</b>; oqimga qarshi: <b>v − o</b>.</li><li>Sol, shox: tezligi = <b>oqim</b> tezligi.</li><li>Oqim = (bo'ylab − qarshi) : 2.</li><li>O'z tezligi = (bo'ylab + qarshi) : 2.</li><li>Bordi-keldi: har yo'nalishni <b>alohida</b> hisoblang.</li><li>Oqim bordi-keldini doim <b>sekinlashtiradi</b>.</li></ul></div>",
 tn:"Keyingi darsda 5-sinf uchun «quvish» masalalariga ko'prik: ikki qayiq bir-biriga qarab suzsa, oqim ta'sir qilmaydi — nima uchun?"}
];
var PROBS=[
{t:"Qayiqning o'z tezligi 15 km/soat, oqim 3 km/soat. Oqim bo'ylab tezligi?",o:["18 km/soat","12 km/soat","15 km/soat","45 km/soat"],k:0,s:"15 + 3 = 18."},
{t:"Katerning o'z tezligi 24 km/soat, oqim 4 km/soat. Oqimga qarshi tezligi?",o:["20 km/soat","28 km/soat","24 km/soat","6 km/soat"],k:0,s:"24 − 4 = 20."},
{t:"Qayiq (15 km/soat) oqim (3 km/soat) bo'ylab 4 soat suzdi. Necha km?",o:["72 km","60 km","48 km","18 km"],k:0,s:"18 · 4 = 72."},
{t:"Qayiq (12 km/soat) oqimga (2 km/soat) qarshi 3 soat suzdi. Necha km?",o:["30 km","42 km","36 km","10 km"],k:0,s:"10 · 3 = 30."},
{t:"Qayiq (15) oqim (3) bo'ylab 4 soat suzdi. Orqaga necha soatda qaytadi?",o:["6 soat","4 soat","5 soat","8 soat"],k:0,s:"72 : 12 = 6."},
{t:"Sol oqim bilan 5 soat suzdi, oqim 3 km/soat. Necha km?",o:["15 km","8 km","2 km","0 km"],k:0,s:"3 · 5 = 15."},
{t:"Shox 4 soatda 8 km suzdi. Qayiq (10 km/soat) oqim bo'ylab qanday tezlikda suzadi?",o:["12 km/soat","10 km/soat","18 km/soat","8 km/soat"],k:0,s:"Oqim 2; 10 + 2 = 12."},
{t:"Kater oqim bo'ylab 20, qarshi 14 km/soat suzadi. O'z tezligi?",o:["17 km/soat","3 km/soat","6 km/soat","34 km/soat"],k:0,s:"(20 + 14) : 2 = 17."},
{t:"Qayiq oqim bo'ylab 16, qarshi 10 km/soat. Oqim tezligi?",o:["3 km/soat","6 km/soat","13 km/soat","26 km/soat"],k:0,s:"(16 − 10) : 2 = 3."},
{t:"Qayiq 24 km borib qaytdi (o'z tezligi 10, oqim 2). Jami necha soat?",o:["5 soat","4 soat","6 soat","2 soat"],k:0,s:"24 : 12 + 24 : 8 = 2 + 3 = 5."},
{t:"Qayiq 36 km ni bo'ylab 3 soatda, qarshi 6 soatda o'tdi. Oqim tezligi?",o:["3 km/soat","6 km/soat","9 km/soat","12 km/soat"],k:0,s:"(12 − 6) : 2 = 3."},
{t:"Qayiq 48 km ni bo'ylab 4 soatda, qarshi 6 soatda o'tdi. O'z tezligi?",o:["10 km/soat","2 km/soat","12 km/soat","8 km/soat"],k:0,s:"(12 + 8) : 2 = 10."},
{t:"Kater 60 km ni oqim bo'ylab 3 soatda o'tdi. Oqim 4 km/soat. Orqaga necha soatda qaytadi?",o:["5 soat","3 soat","4 soat","6 soat"],k:0,s:"20 − 4 = 16 (o'z), qarshi 12; 60 : 12 = 5."},
{t:"Qayiqning oqim bo'ylab tezligi 14 km/soat, oqim 2 km/soat. Oqimga qarshi tezligi?",o:["10 km/soat","12 km/soat","16 km/soat","8 km/soat"],k:0,s:"O'z 12; 12 − 2 = 10."},
{t:"Qayiq oqimga qarshi 2 soatda 18 km suzdi. Oqim 3 km/soat. Oqim bo'ylab 2 soatda necha km suzadi?",o:["30 km","24 km","18 km","36 km"],k:0,s:"Qarshi 9, o'z 12, bo'ylab 15; 15 · 2 = 30."},
{t:"Sol A dan B ga 10 soatda yetdi. Qayiq shu yo'lni oqim bo'ylab 2 soatda o'tadi. A–B 20 km. Qayiqning o'z tezligi?",o:["8 km/soat","10 km/soat","12 km/soat","2 km/soat"],k:0,s:"Oqim 20 : 10 = 2; bo'ylab 20 : 2 = 10; o'z 10 − 2 = 8."},
{t:"Kater (o'z tezligi 18) oqim (2) bo'ylab 3 soat, keyin qarshi 2 soat suzdi. Boshlang'ich joydan qancha uzoqda?",o:["28 km","92 km","60 km","32 km"],k:0,s:"60 − 32 = 28."},
{t:"Qayiq oqim bo'ylab 4 soatda, qarshi 6 soatda bir xil masofani o'tadi. Oqim 2 km/soat. Masofa?",o:["48 km","24 km","40 km","60 km"],k:0,s:"Farq 4 km/soat; bo'ylab v + 2, qarshi v − 2: (v + 2) · 4 = (v − 2) · 6 → v = 10; 12 · 4 = 48."},
{t:"Oqim 3 km/soat. Qayiq oqimga qarshi umuman oldinga yura olmasligi uchun o'z tezligi qancha bo'lishi kerak?",o:["3 km/soat","0 km/soat","6 km/soat","1 km/soat"],k:0,s:"3 − 3 = 0 — joyida turadi."},
{t:"Qayiq 30 km ni oqim bo'ylab borib qaytdi (o'z tezligi 8, oqim 2). Jami necha soat?",o:["8 soat","7 soat 30 daq","6 soat","10 soat"],k:0,s:"30 : 10 + 30 : 6 = 3 + 5 = 8."}
];
function PRACT_STAGE(){e4road({water:1,L:30,t:'Bo‘ylab: v + o,  qarshi: v − o',marks:[[0,'A'],[30,'B']],obj:[{p:15,ic:'🚤'}]})}
var PREP_DATA={teach:["Turg'un suvdagi (o'z) tezlik va oqim tezligi.","Oqim bo'ylab v + o, qarshi v − o; sol tezligi = oqim.","Masofa, vaqt; ikki tezlikdan o'z tezlik va oqimni topish (yig'indi-ayirma).","Bordi-keldi vaqtini alohida hisoblash."],
 mist:["Oqimni hisobga olmay o'z tezlik bilan hisoblaydi.","Qaytish vaqtini borish vaqtiga teng deb oladi.","Tezliklar farqini oqim deb oladi (2 ga bo'lmaydi).","Solga o'z tezligi bor deb hisoblaydi."],
 need:["Doskada daryo chizmasi (strelkalar bilan oqim).","Qog'oz qayiqcha (ariq tajribasi uchun).","Jadval: yo'nalish | masofa | vaqt | tezlik."],
 board:["Bo'ylab: <span class='w2'>15 + 3 = 18</span>; qarshi: <span class='w2'>15 − 3 = 12</span>.","<span class='w2'>18 · 4 = 72</span> km; orqaga <span class='w2'>72 : 12 = 6</span> soat.","<span class='w2'>(20 − 14) : 2 = 3</span> — oqim.","<span class='w2'>24 : 12 + 24 : 8 = 5</span> soat."]};
