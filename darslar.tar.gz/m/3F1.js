
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3F1',TITLE='3-sinf · Ulush tushunchasi';
var F1N={2:'ikkidan bir (yarim)',3:'uchdan bir',4:'to‘rtdan bir (chorak)',5:'beshdan bir',6:'oltidan bir',8:'sakkizdan bir',10:'o‘ndan bir',12:'o‘n ikkidan bir'};
function f1two(pick){clear();var g=S.g;
 var a=-Math.PI/2,cuts=[.4,.25,.2,.15],sh=pick==='L'?[0]:[];for(var i=0;i<4;i++){var b=a+cuts[i]*2*Math.PI;f3sector(g,90,82,56,a,b,i===0&&pick==='L'?C.bad:'#f3d29b');a=b}
 for(var j=0;j<4;j++)f3sector(g,270,82,56,-Math.PI/2+j*Math.PI/2,-Math.PI/2+(j+1)*Math.PI/2,j===0&&pick==='R'?C.ok:'#f3d29b');
 T(g,90,158,'A',{'font-size':15,'font-weight':800});T(g,270,158,'B',{'font-size':15,'font-weight':800})}
var F1P7=[function(){clear();f3circle(180,80,58,4,3,null);T(S.g,180,160,'bo‘yalgan qism — 27 sm²',{'font-size':13,'font-weight':800,fill:C.a2});f3calc(['Doira 4 ta teng bo‘lakka bo‘lingan, 3 tasi bo‘yalgan — 27 sm²'])},
 function(){clear();var c=f3circle(180,80,58,4,3,null);[0,1,2].forEach(function(i){var a=-Math.PI/2+(i+.5)*Math.PI/2;T(S.g,180+32*Math.cos(a),84+32*Math.sin(a),'9',{'font-size':16,'font-weight':800})});f3calc(['3 bo‘lak = 27 sm²','1 bo‘lak = 27 : 3 = <b>9</b> sm²'])},
 function(){clear();f3circle(180,80,58,4,4,null);[0,1,2,3].forEach(function(i){var a=-Math.PI/2+(i+.5)*Math.PI/2;T(S.g,180+32*Math.cos(a),84+32*Math.sin(a),'9',{'font-size':16,'font-weight':800})});f3calc(['1 bo‘lak = 9 sm²','Butun doira = 4 bo‘lak = 9 · 4 = <b>36</b> sm²'])}];
var F1P5=[function(){clear();f3bar(30,60,300,50,5,1);f3calc(['1 ta ulush: <b>1/5</b>'])},function(){clear();f3bar(30,60,300,50,5,3);f3calc(['3 ta ulush: <b>3/5</b>'])},function(){clear();f3bar(30,60,300,50,5,5);f3calc(['5 ta ulush: <b>5/5 = 1 butun</b> — hammasi'])}];
var STEPS=[
{h:"Ulush — teng bo'lak",sum:"Butun TENG bo'laklarga bo'linsa, har bir bo'lak — ulush. Teng bo'lmasa, ulush emas.",a:"m01",
 start:function(){f1two(null);f3msg('Qaysi non 4 ta <b>teng</b> bo‘lakka bo‘lingan?')},fin:function(){f1two('R');f3msg('B — 4 ta teng bo‘lak. Har biri — <b>chorak</b>')},
 html:"<p>Ikkita non 4 tadan bo'lakka bo'lindi. To'rt do'stga <b>adolatli</b> bo'lish uchun qaysi nonni olish kerak? Tanlang:</p>",
 btns:[["A non",function(c,done){f1two('L');f3msg('A da bo‘laklar har xil — kimgadir katta, kimgadir kichik tegadi. Qayta qarang')}],["B non",function(c,done){f1two('R');f3msg('To‘g‘ri! B — 4 ta <b>teng</b> bo‘lak');done()},'u']],g2:1,
 after:"<p>Butunni <b>teng</b> bo'laklarga bo'lsak, har bir bo'lak <b>ulush</b> deyiladi. B nonning har bir bo'lagi — <b>to'rtdan bir</b> ulush (chorak), yoziladi: <b>1/4</b>. A non ham 4 bo'lak, lekin ular teng emas — ular ulush emas.</p>",
 q:{t:"Tort 3 bo'lakka bo'lindi: biri katta, ikkitasi kichik. Har bir bo'lak tortning 1/3 ulushimi?",opts:["Ha, 3 ta bo'lak bor","Yo'q, bo'laklar teng emas","Faqat kattasi 1/3","Faqat kichiklari 1/3"],ok:1,why:"Ulush bo'lishi uchun bo'laklar teng bo'lishi shart.",hint:"A nonni eslang: 4 bo'lak bor edi — ular chorak bo'ldimi?",full:"1/3 — butun 3 ta TENG bo'lakka bo'linganda bittasi. Bo'laklar har xil bo'lsa, birortasi ham 1/3 emas. Bo'laklar soni emas, ularning tengligi muhim."},
 tn:"Xalqaro tavsiya (AQSh IES): ulushni «adolatli bo'lishish»dan boshlang. Qog'oz doira va tasmalarni bolalar o'zi buklab, teng va teng emas bo'laklarni solishtirsin."},
{h:"Ulushlarning nomi",sum:"Butun n ta teng bo'lakka bo'linsa, bitta bo'lak — «n dan bir» (1/n): yarim, chorak, uchdan bir…",a:"m02",
 start:function(){S.n=4;f1name()},fin:function(){S.n=4;f1name()},
 html:"<p>Doirani necha bo'lakka bo'lishni o'zingiz tanlang. Bitta bo'lak bo'yalgan — uning nomi va yozilishi pastda chiqadi.</p>",
 btns:[["2",function(c,done){S.n=2;f1name();mvK(done)}],["3",function(c,done){S.n=3;f1name();mvK(done)}],["4",function(c,done){S.n=4;f1name();mvK(done)}],["6",function(c,done){S.n=6;f1name();mvK(done)}],["8",function(c,done){S.n=8;f1name();mvK(done)}],["12",function(c,done){S.n=12;f1name();mvK(done)}]],g3:1,
 after:"<p>Ulush shunday yoziladi: <b>1/4</b> — chiziq ostida butun nechta teng bo'lakka bo'linganini, ustida — nechta bo'lak olinganini yozamiz. O'qilishi: avval pastdagi son: «<b>to'rtdan</b> bir». Maxsus nomlar: 1/2 — <b>yarim</b>, 1/4 — <b>chorak</b>.</p><p>Ko'rdingizmi: bo'laklar <b>ko'p</b> bo'lgan sari, bitta ulush <b>kichrayadi</b>.</p>",
 q:{t:"Qaysi ulush katta: 1/3 yoki 1/6?",opts:["1/6","1/3","Teng","6 katta, demak 1/6"],ok:1,why:"3 ga bo'linganda bo'laklar kattaroq.",hint:"Bitta tortni 3 kishi bo'lishsa ko'p tegadimi, yoki 6 kishi?",full:"1/3 — tort 3 bo'lakka, 1/6 — 6 bo'lakka bo'lingan. Bo'laklar ko'p bo'lsa, har biri kichik. 1/3 > 1/6. «6 katta, demak 1/6 katta» — eng ko'p uchraydigan xato."},
 tn:"«n dan bir» — o'zbek tilida ulushning nomi o'zi ma'noni beradi: «oltidan bir» = olti bo'lakdan bittasi. Shu o'qilishni doim ishlating."},
{h:"Bir nechta ulush",sum:"8 bo'lakdan 3 tasi — 3/8 («sakkizdan uch»). Qolgani 5/8.",a:"m03",
 start:function(){S.k=0;clear();f3circle(180,82,62,8,[],function(i,cells){S.k=cells.filter(function(c){return c._on}).length;f1three()});f1three()},fin:function(){clear();f3circle(180,82,62,8,3,null);S.k=3;f1three()},
 html:"<p>Pitsa 8 ta teng bo'lakka bo'lingan. Uning <b>3/8</b> qismini bo'yang — bo'laklarni bosing.</p>",
 act:function(c,done){var h=c.querySelector('.hint');h.textContent='Pitsa bo‘laklarini bosing. Kerak: 3 ta.';S.f1d=function(){if(S.k===3){S.f1d=null;h.textContent='';done()}}},
 after:"<p><b>3/8</b> — «sakkizdan uch»: pitsa 8 ta teng bo'lakka bo'lingan, 3 tasi olingan. Qolgani — <b>5/8</b>. Birgalikda: 3/8 + 5/8 = 8/8 — butun pitsa.</p>",
 q:{t:"Doiraning 5/8 qismi bo'yalmagan. Qancha qismi bo'yalgan?",opts:["5/8","3/8","3/5","5/3"],ok:1,why:"8/8 dan 5/8 ni olsak, 3/8 qoladi.",hint:"Butun doira — 8/8. Bo'yalmagani 5 bo'lak. Bo'yalgani nechta bo'lak?",full:"Doira 8 bo'lak. Bo'yalmagan — 5 bo'lak, demak bo'yalgan 8 − 5 = 3 bo'lak: 3/8. «3/5» — maxrajni almashtirib yuborish xatosi."},
 tn:"Bolalar doiradan bo'yalgan va bo'yalmagan qismni ikki xil rangda ko'rsatsin va ikkala ulushni yozsin."},
{h:"Soatdagi ulushlar",sum:"Soat = 60 minut. Yarim soat = 30 min, chorak soat = 15 min, soatning 1/3 qismi = 20 min.",a:"m04",
 start:function(){f1clock(15,'chorak soat')},fin:function(){f1clock(20,'soatning uchdan biri')},
 html:"<p>Siferblat ham doira! Soat 60 minut. Ulushni tanlang va minutlarni sanang:</p>",
 btns:[["yarim soat",function(c,done){f1clock(30,'yarim soat (1/2)');mvK(done)}],["chorak soat",function(c,done){f1clock(15,'chorak soat (1/4)');mvK(done)}],["1/3 soat",function(c,done){f1clock(20,'soatning uchdan biri (1/3)');mvK(done)}],["3/4 soat",function(c,done){f1clock(45,'uch chorak soat (3/4)');mvK(done)}]],g2:1,
 after:"<p>Soatning ulushini topish uchun 60 ni ulush maxrajiga bo'lamiz: 1/4 soat = 60 : 4 = <b>15</b> minut, 1/3 soat = 60 : 3 = <b>20</b> minut. 3/4 soat = 15 · 3 = <b>45</b> minut.</p><p>«To'rtga chorak kam» — 3 soat 45 minut!</p>",
 q:{t:"Soatning 1/6 qismi necha minut?",opts:["6","10","16","60"],ok:1,why:"60 : 6 = 10 minut.",hint:"Soatda 60 minut. Uni 6 ta teng bo'lakka bo'ling.",full:"1 soat = 60 minut. 60 : 6 = 10. Demak soatning 1/6 qismi — 10 minut. Siferblatda: 12 dan 2 gacha."},
 tn:"Haqiqiy soat ko'rsatib, «chorak», «yarim» so'zlarini kundalik hayot bilan bog'lang: «Darsning yarmi o'tdi» — 20 minutmi, 22,5 minutmi (45 daqiqali dars)?"},
{h:"Butun — barcha ulushlar",sum:"5/5 = 1 butun. Nechta 1/n ulush butunni tashkil qiladi? — n ta.",a:"m05",
 start:function(){startPh(F1P5)},fin:function(){S.ph=2;F1P5[2]()},
 html:"<p>Lenta 5 ta teng bo'lakka bo'lingan. Ulushlarni bittalab qo'shib boramiz:</p>",
 btns:[phaser(F1P5)],
 after:"<p>Barcha bo'laklar olinsa — <b>butun</b>: 5/5 = 1. 2/2, 4/4, 10/10 — hammasi bir butunga teng.</p>",
 q:{t:"Nechta 1/7 ulush bir butunni tashkil qiladi?",opts:["1","7","70","14"],ok:1,why:"7/7 = 1 butun.",hint:"Butun 7 ta teng bo'lakka bo'lingan. Hammasini olish uchun nechta bo'lak kerak?",full:"1/7 — butunning 7 ta teng bo'lagidan bittasi. Butunni yig'ish uchun 7 tasini olamiz: 7/7 = 1."},
 tn:"Tasmani buklab, «1/5 + 1/5 + … = 1» ni qo'l bilan ko'rsating."},
{h:"Tuzoq: butunlar har xil bo'lsa",sum:"Ulushning kattaligi butunga bog'liq: katta tortning yarmi kichik tortning yarmidan katta.",a:"m06",
 start:function(){f1cake(false)},fin:function(){f1cake(true)},
 html:"<p>Alida katta tort, Valida kichik tort. Ikkalasi ham tortining <b>yarmini</b> berdi. Ular bir xil miqdor berdimi? Tugmani bosing.</p>",
 btns:[["🎂 Yarmini ko'rsat",function(c,done){f1cake(true);done()}]],
 after:"<p>Ikkalasi ham 1/2, lekin bo'laklar <b>teng emas</b>: katta tortning yarmi katta. Shuning uchun ulushlarni faqat <b>bir xil butun</b> uchun solishtirish mumkin.</p>",
 q:{t:"Ali 1 kg olmaning yarmini, Vali 4 kg olmaning yarmini oldi. Kim ko'p oldi?",opts:["Ali","Vali","Teng — ikkalasi ham yarim","Aniqlash uchun olma kerak"],ok:1,why:"Ali 500 g, Vali 2 kg oldi.",hint:"Har birining yarmini grammda yoki kilogrammda hisoblang.",full:"1 kg ning yarmi — 500 g. 4 kg ning yarmi — 2 kg. Ikkalasi ham «yarim», lekin butunlar har xil, shuning uchun Vali ko'p oldi."},
 tn:"Bu tuzoq olimpiada va xalqaro testlarda (TIMSS) uchraydi. Ikki xil kattalikdagi qog'oz doirani yarmini kesib ko'rsating."},
{h:"Ulushidan butunni topish",sum:"3/4 qism = 27 → 1/4 = 27 : 3 = 9 → butun = 9 · 4 = 36.",a:"m07",
 start:function(){startPh(F1P7)},fin:function(){S.ph=2;F1P7[2]()},
 html:"<p>Testda shunday keladi: <i>«Doira 4 ta teng bo'lakka bo'lingan, 3 tasi bo'yalgan. Bo'yalgan qismning yuzi 27 sm². Butun doiraning yuzi?»</i> Qadamlab yechamiz.</p>",
 btns:[phaser(F1P7)],
 after:"<p>Usul: 1) ma'lum son nechta bo'lakka to'g'ri keladi — <b>bitta bo'lakni</b> topamiz (27 : 3 = 9); 2) butunda nechta bo'lak bor — <b>ko'paytiramiz</b> (9 · 4 = 36).</p><p>Xato yo'l: 27 : 4 yoki 27 · 3. Doim chizma chizing!</p>",
 q:{t:"Lentaning 2/5 qismi 10 sm. Butun lenta necha santimetr?",opts:["4","50","25","20"],ok:2,why:"10 : 2 = 5 sm — bitta bo'lak, 5 · 5 = 25 sm.",hint:"10 sm — nechta bo'lak? Bitta bo'lakni toping.",full:"2/5 — 2 ta bo'lak = 10 sm. Bitta bo'lak: 10 : 2 = 5 sm. Butun lenta 5 bo'lak: 5 · 5 = 25 sm. «50» — 10 ni 5 ga ko'paytirish xatosi."},
 tn:"Singapur «chizma model» usuli: lentani chizib, ma'lum qismini qavs bilan belgilang. Bolalar bu masalada ko'pincha 27 ni 4 ga bo'ladi."},
{h:"Bilasizmi? «Chorak» qayerdan keldi",sum:"«Chorak» — forscha «chahor» (to'rt) so'zidan. Qadimgi Misrda asosan 1/n ulushlar ishlatilgan.",a:"m08",
 start:function(){f1hist()},fin:function(){f1hist()},
 html:"<p>📜 «<b>Chorak</b>» so'zi forscha «<b>chahor</b>» — «to'rt» so'zidan kelgan: to'rtdan bir. Maktabda yil ham 4 chorakka bo'linadi!</p><p>🏺 Qadimgi Misrda, 4000 yil oldin, ulushlarni asosan surati 1 bo'lgan shaklda yozishgan: 1/2, 1/3, 1/4… Masalan, 3/4 ni ular <b>1/2 + 1/4</b> deb yozishgan.</p><p>⭐ Vatandoshimiz <b>al-Xorazmiy</b> arifmetika kitobida ulushlar bilan hisoblashni ham tushuntirgan.</p>",
 tn:"Bolalardan «chorak» so'zi ishlatiladigan joylarni so'rang: chorak soat, o'quv choragi, chorak non."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){clear();f3circle(180,82,62,8,3,null);S.k=3;f1three()},fin:function(){clear();f3circle(180,82,62,8,3,null);S.k=3;f1three()},
 html:"<div class='memo'><ul><li><b>Ulush</b> — butunning <b>teng</b> bo'laklaridan biri yoki bir nechtasi.</li><li>1/4 — «to'rtdan bir»: butun 4 ta teng bo'lakka bo'lingan, 1 tasi olingan. 1/2 — yarim, 1/4 — chorak.</li><li>Bo'laklar ko'p — ulush kichik: 1/3 > 1/6.</li><li>3/8 + 5/8 = 8/8 = 1 butun.</li><li>Soat ulushlari: 1/2 soat = 30 min, 1/4 = 15 min, 1/3 = 20 min, 3/4 = 45 min.</li><li>Ulushlarni faqat <b>bir xil butun</b> uchun solishtiring.</li><li>Qismdan butunga: 3/4 = 27 → 1/4 = 9 → butun = 36.</li></ul></div>",
 tn:"Keyingi dars «Sonning ulushini topish» (3F2) — bu kartochka unga asos."}
];
function f1name(){clear();f3circle(180,82,62,S.n,1,null);f3msg('Butun <b>'+S.n+'</b> ta teng bo‘lak · bitta bo‘lak: <b>1/'+S.n+'</b> — «'+F1N[S.n]+'»')}
function f1three(){f3msg('Bo‘yaldi: <b>'+S.k+'/8</b> · bo‘yalmagan: <b>'+(8-S.k)+'/8</b>');if(S.f1d)S.f1d()}
function f1clock(m,lab){clear();f3clock(180,84,70,0,m,{shade:[0,m]});T(S.g,316,90,m+' min',{'font-size':16,'font-weight':800,fill:C.a2});f3msg(lab+' = <b>'+m+'</b> minut')}
function f1cake(on){clear();var g=S.g;E('circle',{cx:105,cy:85,r:62,fill:'#f6d9a8',stroke:C.line,'stroke-width':2},g);E('circle',{cx:270,cy:95,r:34,fill:'#f6d9a8',stroke:C.line,'stroke-width':2},g);
 if(on){f3sector(g,105,85,62,-Math.PI/2,Math.PI/2,C.a);f3sector(g,270,95,34,-Math.PI/2,Math.PI/2,C.a)}T(g,105,166,'Ali: katta tort',{'font-size':12,'font-weight':700});T(g,270,150,'Vali: kichik tort',{'font-size':12,'font-weight':700});
 f3msg(on?'Ikkalasi ham <b>1/2</b>, lekin Alining yarmi <b>katta</b>!':'Ikkalasi ham tortining yarmini beradi…')}
function f1hist(){clear('#f6ead0');var g=S.g;f3bar(40,40,280,40,4,3,C.a);T(g,180,30,'3/4',{'font-size':15,'font-weight':800,fill:'#6b3d12'});E('rect',{x:40,y:100,width:140,height:40,fill:C.a,stroke:C.line,'stroke-width':2},g);E('rect',{x:180,y:100,width:70,height:40,fill:C.a2,stroke:C.line,'stroke-width':2},g);E('rect',{x:40,y:100,width:280,height:40,fill:'none',stroke:C.line,'stroke-width':2.5},g);T(g,110,126,'1/2',{'font-size':15,'font-weight':800,fill:'#fff'});T(g,215,126,'1/4',{'font-size':15,'font-weight':800,fill:'#fff'});f3msg('Misrcha: 3/4 = 1/2 + 1/4')}
var PROBS=[
{t:"Doira 6 ta teng bo'lakka bo'lindi. Bitta bo'lak qanday yoziladi?",o:["1/6","6/1","1/5","6"],k:0,s:"Butun 6 ta teng bo'lak, bittasi — 1/6."},
{t:"Qaysi ulush eng katta?",o:["1/2","1/3","1/5","1/9"],k:0,s:"Bo'laklar kam — har biri katta: 1/2."},
{t:"Qaysi ulush eng kichik?",o:["1/10","1/4","1/7","1/2"],k:0,s:"10 ta bo'lakka bo'lingani eng kichik: 1/10."},
{t:"Soatning yarmi necha minut?",o:["30","50","20","15"],k:0,s:"60 : 2 = 30 minut."},
{t:"Chorak soat necha minut?",o:["15","25","4","40"],k:0,s:"60 : 4 = 15 minut."},
{t:"Soatning 1/5 qismi necha minut?",o:["12","5","15","20"],k:0,s:"60 : 5 = 12 minut."},
{t:"Tort 8 ta teng bo'lakka bo'lindi, 3 tasi yeyildi. Qancha qismi qoldi?",o:["5/8","3/8","8/5","5/3"],k:0,s:"8 − 3 = 5 bo'lak: 5/8."},
{t:"Nechta 1/9 ulush bir butunni tashkil qiladi?",o:["9","1","18","90"],k:0,s:"9/9 = 1."},
{t:"Shakl 12 ta teng katakka bo'lingan, 5 tasi bo'yalgan. Bo'yalmagan qism?",o:["7/12","5/12","7/5","12/7"],k:0,s:"12 − 5 = 7 katak: 7/12."},
{t:"Qaysi rasmda doiraning 1/4 qismi to'g'ri ko'rsatilgan bo'ladi?",o:["4 ta teng bo'lakdan 1 tasi bo'yalgan","4 ta har xil bo'lakdan 1 tasi bo'yalgan","3 ta teng bo'lakdan 1 tasi bo'yalgan","1 ta bo'lakdan 4 tasi"],k:0,s:"Ulush faqat teng bo'laklarda: 4 ta teng bo'lakdan 1 tasi."},
{t:"Doira 4 ta teng bo'lakka bo'lingan, 3 tasi bo'yalgan va bo'yalgan qism 27 sm². Butun doira yuzi?",o:["36 sm²","30 sm²","9 sm²","108 sm²"],k:0,s:"27 : 3 = 9 — bir bo'lak, 9 · 4 = 36."},
{t:"Lentaning 1/3 qismi 24 sm. Butun lenta?",o:["72 sm","8 sm","27 sm","48 sm"],k:0,s:"Butun = 3 ta shunday bo'lak: 24 · 3 = 72 sm."},
{t:"Lentaning 1/3 qismi 24 sm. Shu lentaning 1/4 qismi necha santimetr?",o:["18 sm","8 sm","6 sm","24 sm"],k:0,s:"Butun 24 · 3 = 72 sm. 72 : 4 = 18 sm."},
{t:"Uch chorak soat necha minut?",o:["45","34","75","30"],k:0,s:"Chorak — 15 min, uch chorak — 15 · 3 = 45 min."},
{t:"1/4 soat va 1/3 soat birgalikda necha minut?",o:["35","7","20","25"],k:0,s:"15 + 20 = 35 minut."},
{t:"Ali 2 kg olmaning yarmini, Vali 6 kg olmaning yarmini oldi. Vali Alidan necha kg ko'p oldi?",o:["2 kg","4 kg","3 kg","Teng oldi"],k:0,s:"Ali 1 kg, Vali 3 kg. 3 − 1 = 2 kg."},
{t:"Tasma 10 ta teng bo'lakka bo'lindi. 3/10 qismi qizil, 4/10 qismi ko'k, qolgani sariq. Sariq qism?",o:["3/10","7/10","4/10","1/10"],k:0,s:"10 − 3 − 4 = 3 bo'lak: 3/10."},
{t:"Darsning 1/3 qismi 15 minut. Dars necha minut davom etadi?",o:["45","5","30","18"],k:0,s:"15 · 3 = 45 minut."},
{t:"Minut mili 12 dan boshlab soatning chorak qismini aylandi. U qaysi raqamni ko'rsatadi?",o:["3","15","4","6"],k:0,s:"Chorak soat — 15 minut, minut mili 3 raqamida turadi."},
{t:"Pitsaning 3/8 qismi yeyildi, keyin yana 2/8 qismi. Qancha qismi qoldi?",o:["3/8","5/8","1/8","2/8"],k:0,s:"Yeyildi 3 + 2 = 5 bo'lak, qoldi 8 − 5 = 3 bo'lak: 3/8."}
];
function PRACT_STAGE(){clear();f3circle(180,82,62,8,3,null);f3msg('Kerak bo‘lsa, doiraga qarab o‘ylang')}
var PREP_DATA={teach:["Ulush — butunning teng bo'laklari; teng bo'lmasa — ulush emas.","Ulushning yozilishi va o'qilishi (1/4 — «to'rtdan bir»), yarim va chorak.","Bir nechta ulush (3/8), butun = barcha ulushlar (8/8).","Soat ulushlari; ulushidan butunni topish; butunlar har xil bo'lsa solishtirib bo'lmasligi."],
 mist:["Teng bo'lmagan bo'laklarni ham ulush deb hisoblaydi.","1/6 ni 1/3 dan katta deydi («6 katta»).","Bo'yalgan/bo'yalmagan qismni almashtirib yozadi (3/5 kabi).","Qismdan butunni topishda 27 ni 4 ga bo'ladi."],
 need:["Qog'oz doiralar va tasmalar (buklash uchun).","O'quv soati (siferblat).","Rangli qalamlar."],
 board:["Teng va teng emas bo'lingan ikki doira.","<span class='w2'>1/4</span>: pastda — nechta teng bo'lak, ustida — nechtasi olindi.","<span class='w2'>1/2 > 1/3 > 1/4 > 1/6</span>.","<span class='w2'>3/8 + 5/8 = 8/8 = 1</span>.","Soat: <span class='w2'>1/4 soat = 15 min</span>, <span class='w2'>1/3 soat = 20 min</span>.","Qismdan butunga: <span class='w2'>27 : 3 · 4 = 36</span>."]};
