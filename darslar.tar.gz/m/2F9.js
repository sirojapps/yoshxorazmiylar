var CODE='2F9',TITLE='2-sinf · Yuz tushunchasi, katakda yuz, yuz birliklari';
// ---------- katakli sahna ----------
var YG={x0:20,y0:12,cs:16,cols:20,rows:9};
function y9Paper(){clear('#ffffff');var g=S.g,K=YG;for(var c=0;c<=K.cols;c++)E('line',{x1:K.x0+c*K.cs,y1:K.y0,x2:K.x0+c*K.cs,y2:K.y0+K.rows*K.cs,stroke:'#cfe0f2'},g);for(var r=0;r<=K.rows;r++)E('line',{x1:K.x0,y1:K.y0+r*K.cs,x2:K.x0+K.cols*K.cs,y2:K.y0+r*K.cs,stroke:'#cfe0f2'},g)}
function y9Cell(r,c,col,num){var K=YG;var e=E('rect',{x:K.x0+c*K.cs+1,y:K.y0+r*K.cs+1,width:K.cs-2,height:K.cs-2,rx:2,fill:col||C.a},S.g);if(num!=null)T(S.g,K.x0+c*K.cs+K.cs/2,K.y0+r*K.cs+12,String(num),{'font-size':10,'font-weight':800,fill:'#fff','pointer-events':'none'});return e}
function y9Half(r,c,dir,col){var K=YG,x=K.x0+c*K.cs,y=K.y0+r*K.cs,s=K.cs,p=dir==='a'?[[x,y],[x+s,y],[x,y+s]]:[[x+s,y],[x+s,y+s],[x,y+s]];E('path',{d:'M'+p.map(function(v){return v.join(' ')}).join('L')+'Z',fill:col||'#5aa9e6',stroke:'#2f6f9f','stroke-width':1},S.g)}
function y9Rect(r0,c0,h,w){var l=[];for(var r=0;r<h;r++)for(var c=0;c<w;c++)l.push([r0+r,c0+c]);return l}
function y9Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// 1-qadam: ikki gilam
function y9Rugs(cover){clear('#fbf7ef');var g=S.g;
 var A={x:30,y:30,w:120,h:72},B={x:200,y:22,w:96,h:96};
 [A,B].forEach(function(R,i){E('rect',{x:R.x,y:R.y,width:R.w,height:R.h,rx:4,fill:i?'#c9e6f5':'#f6c98a',stroke:C.line,'stroke-width':2},g);T(g,R.x+R.w/2,R.y+R.h+18,i?'B gilam':'A gilam',{'font-size':12,'font-weight':800});
  if(cover){var s=24,n=0;for(var y=R.y;y<R.y+R.h-1;y+=s)for(var x=R.x;x<R.x+R.w-1;x+=s){n++;E('rect',{x:x+1,y:y+1,width:s-2,height:s-2,rx:2,fill:'rgba(255,255,255,.55)',stroke:'#7a8a9a','stroke-width':.8},g);T(g,x+s/2,y+s/2+4,String(n),{'font-size':9,'font-weight':800,fill:'#33475b'})}R.n=n}});
 y9Msg(cover?'A gilamni <b>'+A.n+'</b> ta, B gilamni <b>'+B.n+'</b> ta bir xil plitka qopladi: B ko‘proq joy egallaydi':'Qaysi gilam polda ko‘proq joy egallaydi? Ko‘z bilan aytish qiyin…')}
var P3=[function(){y9Paper();[[3,6],[3,7],[4,6],[4,7],[5,6]].forEach(function(p){y9Cell(p[0],p[1])});y9Half(5,7,'a');y9Half(3,8,'a');y9Msg('Butun kataklar va yarim kataklar (uchburchaklar). Yuzi necha katak?')},
 function(){y9Paper();[[3,6],[3,7],[4,6],[4,7],[5,6]].forEach(function(p,i){y9Cell(p[0],p[1],C.a,i+1)});y9Half(5,7,'a');y9Half(3,8,'a');y9Msg('Butun kataklar: <b>5</b> ta')},
 function(){y9Paper();[[3,6],[3,7],[4,6],[4,7],[5,6]].forEach(function(p,i){y9Cell(p[0],p[1],C.a,i+1)});y9Half(5,7,'a',C.ok);y9Half(3,8,'a',C.ok);y9Msg('2 ta yarim katak = <b>1</b> butun katak. Yuz: 5 + 1 = <b>6</b> katak')}];
var P6=[function(){y9Paper();y9Rect(3,8,2,3).forEach(function(p){y9Cell(p[0],p[1])});y9Msg('To‘g‘ri to‘rtburchak 3 × 2 (katak tomoni 1 sm)')},
 function(){y9Paper();y9Rect(3,8,2,3).forEach(function(p,i){y9Cell(p[0],p[1],C.a,i+1)});y9Msg('<b>Yuz</b> — ichidagi kataklar: <b>6 sm²</b>')},
 function(){y9Paper();y9Rect(3,8,2,3).forEach(function(p,i){y9Cell(p[0],p[1],C.a,i+1)});var K=YG;E('rect',{x:K.x0+8*K.cs,y:K.y0+3*K.cs,width:3*K.cs,height:2*K.cs,fill:'none',stroke:C.bad,'stroke-width':3},S.g);y9Msg('<b>Perimetr</b> — chegara uzunligi: 3 + 2 + 3 + 2 = <b>10 sm</b>. Yuz 6 sm², perimetr 10 sm — har xil narsa!')}];
function y9Units(k){clear();var g=S.g;
 E('rect',{x:30,y:60,width:16,height:16,fill:C.a,stroke:C.line},g);T(g,38,96,'1 sm²',{'font-size':12,'font-weight':800});T(g,38,112,'tomoni 1 sm',{'font-size':9,fill:'#5b6b7b'});
 if(k>=1){var x0=90,y0=14,s=11;for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:(r===0&&c===0)?C.a:'#fff3df',stroke:'#e0c49a','stroke-width':.6},g);E('rect',{x:x0,y:y0,width:110,height:110,fill:'none',stroke:C.line,'stroke-width':2},g);T(g,x0+55,y0+128,'1 dm² = 100 sm²',{'font-size':12,'font-weight':800,fill:C.t1});T(g,x0+55,y0+142,'tomoni 1 dm = 10 sm',{'font-size':9,fill:'#5b6b7b'})}
 if(k>=2){E('rect',{x:240,y:20,width:100,height:100,fill:'#e3f5f3',stroke:C.u,'stroke-width':2,'stroke-dasharray':'6 4'},g);T(g,290,74,'1 m²',{'font-size':18,'font-weight':800,fill:C.u});T(g,290,138,'tomoni 1 m',{'font-size':10,fill:'#5b6b7b'});T(g,290,152,'(xona, hovli uchun)',{'font-size':9,fill:'#5b6b7b'})}
 y9Msg(['<b>1 sm²</b> — tomoni 1 sm kvadrat (daftar katagi kabi kichik)','1 dm² ichiga 10 × 10 = <b>100</b> ta sm² sig‘adi','Katta yuzlar uchun — <b>1 m²</b> (tomoni 1 metr kvadrat)'][k])}
var P5=[function(){y9Units(0)},function(){y9Units(1)},function(){y9Units(2)}];
var STEPS=[
{h:"Qaysi biri ko'p joy egallaydi?",sum:"Yuz — shakl egallagan joy. Ikkita shaklni bir xil plitkalar bilan qoplab solishtiramiz.",a:"m01",
 start:function(){y9Rugs(false)},fin:function(){y9Rugs(true)},
 html:"<p>Polda ikkita gilam bor. A uzunroq, B kengroq. Qaysi biri polda <b>ko'proq joy</b> egallaydi? Ko'z bilan aytish qiyin. Ularni <b>bir xil plitkalar</b> bilan qoplab ko'ramiz.</p>",
 btns:[["🧱 Plitkalar bilan qoplash",function(c,done,b){b.disabled=true;y9Rugs(true);done()}]],
 after:"<p>Shakl egallagan joy uning <b>yuzi</b> deyiladi. Yuzni bilish uchun shaklni <b>bir xil kvadratchalar</b> bilan qoplab, ularni sanaymiz. Kvadratcha ko'p sig'sa — yuz katta.</p>",
 q:{t:"Ikkita shakl bir xil kvadratchalar bilan qoplandi: birinchisiga 12 ta, ikkinchisiga 15 ta sig'di. Qaysi birining yuzi katta?",opts:["birinchisining","ikkinchisining","teng","uzunrog'ining"],ok:1,why:"Ko'proq kvadratcha sig'gan shaklning yuzi katta: 15 > 12.",hint:"Yuz — nechta kvadratcha sig'ishi. Qayerga ko'p sig'di?",full:"Yuz kvadratchalar soni bilan o'lchanadi. Ikkinchisiga 15 ta, birinchisiga 12 ta sig'di — ikkinchisining yuzi 3 katak katta. Uzunlik yuzni hal qilmaydi."},
 tn:"Bolalar ikkita varaqni (biri uzun-tor, biri kvadrat) bir xil kartochkalar bilan qoplab solishtirsin. «Uzunroq — kattaroq» degan xato fikrni shu yo'qotadi."},
{h:"Katakda yuzni sanaymiz",sum:"Katakli qog'ozda shaklning yuzi — ichidagi kataklar soni.",a:"m02",
 start:function(){S.n9=0;y9Paper();S.g.setAttribute('transform','translate(-31.2,-34.6) scale(1.6)');var sh=[[2,5],[2,6],[2,7],[3,5],[3,6],[3,7],[3,8],[4,5],[4,6],[5,5],[5,6],[5,7],[5,8]];S.sh9=sh;S.c9={};
  sh.forEach(function(p){var e=y9Cell(p[0],p[1],'#f6d9a8');e.style.cursor='pointer';e.addEventListener('click',function(){var k=p[0]+','+p[1];if(S.c9[k])return;S.c9[k]=1;S.n9++;y9Cell(p[0],p[1],C.a,S.n9);y9Msg('Sanaldi: <b>'+S.n9+'</b> / ?');if(S.n9===sh.length){y9Msg('Hammasi sanaldi: yuz <b>'+sh.length+' katak</b>');if(S.d9)S.d9()}})});y9Msg('Mozaika shaklining har bir katagini bosib sanang')},
 fin:function(){y9Paper();S.g.setAttribute('transform','translate(-31.2,-34.6) scale(1.6)');S.sh9=S.sh9||[];[[2,5],[2,6],[2,7],[3,5],[3,6],[3,7],[3,8],[4,5],[4,6],[5,5],[5,6],[5,7],[5,8]].forEach(function(p,i){y9Cell(p[0],p[1],C.a,i+1)});y9Msg('Yuz: <b>13 katak</b>')},
 html:"<p>Usta polni kvadrat plitkalardan mozaika qilib terdi. Shaklning yuzi necha katak? Har bir katakni <b>bosib</b> sanang.</p>",
 act:function(c,done){S.d9=function(){S.d9=null;done()};c.querySelector('.hint').textContent='Rasmdagi har bir sariq katakni bosing.'},
 after:"<p>Shaklning yuzi — <b>13 katak</b>. Katakli qog'ozda istalgan shaklning yuzini shunday topamiz: ichidagi kataklarni sanaymiz.</p>",
 q:{t:"Shakl 3 qatordan iborat: 4 ta, 4 ta va 2 ta katak. Uning yuzi necha katak?",opts:["10","12","8","3"],ok:0,why:"4 + 4 + 2 = 10.",hint:"Har qatordagi kataklarni qo'shing.",full:"4 + 4 + 2 = 10 katak. «12» — uchala qatorni 4 tadan deb hisoblash xatosi."},
 tn:"Bolalar katakli qog'ozda o'z ismining bosh harfini chizib, uning yuzini sanasin."},
{h:"Yarim kataklar",sum:"2 ta yarim katak (uchburchak) = 1 butun katak. 5 butun + 2 yarim = 6 katak.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ba'zan shaklning chetlari kataklarni <b>qiya</b> kesib o'tadi va yarim kataklar (uchburchaklar) hosil bo'ladi. Ularni qanday sanaymiz?</p>",
 btns:[phaser(P3)],
 after:"<p>Kvadrat katakni diagonal bo'yicha kessak — ikkita bir xil uchburchak chiqadi. Demak, <b>ikkita yarim katak = bitta butun katak</b>. Avval butunlarni, keyin yarimlarni juftlab sanaymiz.</p>",
 q:{t:"Shakl 4 ta butun katak va 4 ta yarim katakdan iborat. Uning yuzi necha katak?",opts:["8","6","4","5"],ok:1,why:"4 yarim = 2 butun; 4 + 2 = 6.",hint:"Nechta yarim katak bitta butunni beradi?",full:"4 ta yarim katak — 2 juft, ya'ni 2 butun katak. 4 + 2 = 6 katak. «8» — yarimlarni butun deb sanash xatosi."},
 tn:"Bitta katakni qog'ozdan kesib, uni ikkita uchburchakka bo'ling va qaytib qo'shib ko'rsating."},
{h:"Shakl har xil, yuz bir xil",sum:"6 katakli to'rtburchak va 6 katakli L-shakl — shakli har xil, yuzi bir xil.",a:"m04",
 start:function(){y9Same(0)},fin:function(){y9Same(2)},
 html:"<p>Yuz shaklga bog'liqmi? Bir xil sonli kataklardan har xil shakl yasab ko'ring:</p>",
 btns:[["▭ to'rtburchak",function(c,done){y9Same(0);mvK(done,2)}],["┗ L-shakl",function(c,done){y9Same(1);mvK(done,2)}],["⊔ U-shakl",function(c,done){y9Same(2);mvK(done,2)}]],g3:1,
 after:"<p>Uchala shakl ham <b>6 katakdan</b> iborat — ularning yuzi bir xil, garchi ko'rinishi har xil bo'lsa ham. Shaklni qirqib, bo'laklarini boshqacha joylasak ham <b>yuz o'zgarmaydi</b>.</p>",
 q:{t:"Kvadrat 3 × 3 ni kesib, bo'laklaridan uzun tasma yasaldi. Tasmaning yuzi necha katak?",opts:["3","9","12","6"],ok:1,why:"Bo'laklar o'sha — yuz o'zgarmaydi: 3 · 3 = 9.",hint:"Kesib qayta yig'ganda kataklar yo'qoladimi?",full:"Kvadratda 3 · 3 = 9 katak. Kesib qayta joylashtirganda kataklar soni o'zgarmaydi — tasmaning yuzi ham 9 katak. «12» — perimetrni aralashtirish."},
 tn:"Bolalarga 6 ta qog'oz kvadratcha bering: nechta har xil shakl yasashlarini sanang. Hammasining yuzi — 6."},
{h:"Yuz birliklari: sm², dm², m²",sum:"1 sm² — tomoni 1 sm kvadrat; 1 dm² = 100 sm²; katta yuzlar m² bilan o'lchanadi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Kataklar har xil kattalikda bo'lishi mumkin. Hamma bir-birini tushunishi uchun <b>yuz birliklari</b> kelishib olingan.</p>",
 btns:[phaser(P5,'▶ Kattaroq birlik')],
 after:"<p><b>1 sm²</b> («bir kvadrat santimetr») — tomoni 1 sm kvadrat. <b>1 dm²</b> — tomoni 10 sm kvadrat, unga <b>100</b> ta sm² sig'adi. <b>1 m²</b> — tomoni 1 metr. Daftar varag'i — sm² da, gilam — dm² yoki m² da, xona — m² da o'lchanadi.</p>",
 q:{t:"Sinf xonasining polining yuzini qaysi birlikda o'lchash qulay?",opts:["sm²","m²","dm²","sm"],ok:1,why:"Xona katta — m² qulay.",hint:"Xona juda katta. Kichik birlik bilan sanasa, son juda katta chiqadi.",full:"Xona poli katta, shuning uchun m² qulay (masalan, 48 m²). sm² da million chiqib ketadi. «sm» esa uzunlik birligi, yuz emas."},
 tn:"Gazetadan 1 m² kvadrat (1 m × 1 m) kesib, polga qo'ying — bolalar uning ichiga necha kishi sig'ishini ko'rsin."},
{h:"Tuzoq: yuz va perimetr",sum:"3 × 2 to'rtburchak: yuz 6 sm² (ichi), perimetr 10 sm (chegarasi).",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Eng ko'p uchraydigan xato — <b>yuz</b> bilan <b>perimetrni</b> aralashtirish. Bitta shaklda ikkalasini ham ko'raylik.</p>",
 btns:[phaser(P6)],
 after:"<p><b>Yuz</b> — ichini qoplovchi kvadratlar, birligi <b>sm²</b>. <b>Perimetr</b> — chegara uzunligi, birligi <b>sm</b>. Bog'ga panjara olish uchun — perimetr, maysa ekish uchun — yuz kerak.</p>",
 q:{t:"Hovliga maysa ekish uchun nimani bilish kerak?",opts:["hovlining perimetrini","hovlining yuzini","hovli devorining balandligini","hovlining uzunligini"],ok:1,why:"Maysa hovli ichini qoplaydi — bu yuz.",hint:"Maysa hovlining ichiga ekiladimi yoki chetiga?",full:"Maysa hovli ichini to'ldiradi — buning uchun yuz kerak. Panjara o'rnatish uchun esa perimetr kerak bo'lardi."},
 tn:"Hayotiy savollar bering: «gilam sotib olish» — yuz, «rasm ramkasi» — perimetr, «devorni bo'yash» — yuz."},
{h:"Tuzoq: 1 dm² = 100 sm²",sum:"1 dm = 10 sm, lekin 1 dm² = 10 × 10 = 100 sm². 3 dm² 6 sm² = 306 sm².",a:"m07",
 start:function(){y9Units(1)},fin:function(){y9Units(1);y9Msg('3 dm² 6 sm² = 300 + 6 = <b>306 sm²</b>')},
 html:"<p>1 dm = 10 sm. Demak, 1 dm² = 10 sm² mi? Tekshiramiz: rasmdagi katta kvadratni sanab ko'ring — har qatorda nechta, nechta qator?</p>",
 btns:[["🔢 Qatorlab sanash",function(c,done,b){b.disabled=true;y9Msg('10 ta qator × 10 ta = <b>100 sm²</b>. Demak, 1 dm² = 100 sm² (10 emas!)');done()}]],
 after:"<p>Kvadrat ikki tomonga ham 10 tadan bo'linadi: 10 × 10 = <b>100</b>. Shuning uchun <b>3 dm² 6 sm²</b> = 300 + 6 = <b>306 sm²</b> (36 emas!).</p>",
 q:{t:"2 dm² 5 sm² necha kvadrat santimetr?",opts:["25 sm²","205 sm²","250 sm²","2005 sm²"],ok:1,why:"2 dm² = 200 sm², + 5 = 205 sm².",hint:"1 dm² necha sm²? 2 dm² chi?",full:"1 dm² = 100 sm², demak 2 dm² = 200 sm². Yana 5 sm²: 205 sm². «25» — 1 dm² ni 10 sm² deb olish xatosi."},
 tn:"Bu tuzoq 3–4-sinflarda ham keladi. 10 × 10 to'rni albatta chizib ko'rsating."},
{h:"Bilasizmi? Sotix va gektar",sum:"Yerni sotix (100 m²) va gektar (10 000 m²) bilan o'lchashadi.",a:"m08",
 start:function(){y9Sotix()},fin:function(){y9Sotix()},
 html:"<p>🏡 Uy-joy va tomorqa yerlarini <b>sotix</b> bilan o'lchashadi. <b>1 sotix = 100 m²</b> — masalan, tomoni 10 metr bo'lgan kvadrat yer. Dalalarni esa <b>gektar</b> bilan o'lchashadi: <b>1 gektar = 100 sotix = 10 000 m²</b> — tomoni 100 metr kvadrat, futbol maydonidan sal kattaroq.</p><p>📜 «Geometriya» so'zi yunoncha <b>«yer o'lchash»</b> degani. Qadimgi Misrda Nil daryosi toshgandan keyin dehqonlarning yer maydonlarini qayta o'lchashga to'g'ri kelgan.</p>",
 tn:"Bolalardan uylarining tomorqasi necha sotix ekanini so'rab kelishni topshiring."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){y9Units(2)},fin:function(){y9Units(2)},
 html:"<div class='memo'><ul><li><b>Yuz</b> — shakl egallagan joy; bir xil kvadratchalar bilan qoplab sanaymiz.</li><li>Katakli qog'ozda yuz = <b>ichidagi kataklar soni</b>.</li><li>2 ta yarim katak = 1 butun katak.</li><li>Shakl har xil bo'lsa ham, kataklar soni teng bo'lsa — yuz teng. Kesib qayta yig'sak — yuz o'zgarmaydi.</li><li>Birliklar: <b>1 sm²</b>, <b>1 dm² = 100 sm²</b>, <b>1 m²</b>.</li><li><b>Yuz</b> (ichi, sm²) ≠ <b>perimetr</b> (chegarasi, sm).</li></ul></div>",
 tn:"Keyingi dars: to'g'ri to'rtburchakning yuzini kataklarni bittalab sanamasdan, ko'paytirish bilan topamiz."}
];
function y9Same(k){y9Paper();var S1=[y9Rect(3,8,2,3),[[2,7],[3,7],[4,7],[5,7],[5,8],[5,9]],[[3,6],[4,6],[4,7],[4,8],[4,9],[3,9]]][k];S1.forEach(function(p,i){y9Cell(p[0],p[1],[C.a,'#5aa9e6','#1e8e5a'][k],i+1)});y9Msg(['To‘rtburchak','L-shakl','U-shakl'][k]+': <b>6 katak</b>')}
function y9Sotix(){clear('#f3f8ec');var g=S.g;E('rect',{x:30,y:30,width:100,height:100,fill:'#cfe8b8',stroke:'#5f8f3a','stroke-width':2},g);T(g,80,84,'1 sotix',{'font-size':14,'font-weight':800,fill:'#3d6b1f'});T(g,80,148,'10 m × 10 m = 100 m²',{'font-size':10,fill:'#3d6b1f'});
 for(var r=0;r<10;r++)for(var c=0;c<10;c++)E('rect',{x:180+c*13,y:12+r*13,width:12,height:12,fill:r===0&&c===0?'#5f8f3a':'#e3f1d6'},g);T(g,245,160,'1 gektar = 100 sotix',{'font-size':11,'font-weight':800,fill:'#3d6b1f'});y9Msg('1 sotix = 100 m² · 1 gektar = 100 sotix = 10 000 m²')}
var PROBS=[
{t:"Shakl 3 qatordan iborat, har qatorda 5 tadan katak. Uning yuzi necha katak?",o:["15","8","10","20"],k:0,s:"5 + 5 + 5 = 15 katak."},
{t:"Ikki shakl bir xil kataklar bilan qoplandi: A ga 18 ta, B ga 14 ta sig'di. Qaysi birining yuzi katta va nechta katakka?",o:["A, 4 katakka","B, 4 katakka","A, 32 katakka","teng"],k:0,s:"18 − 14 = 4, A katta."},
{t:"Shakl 6 ta butun va 2 ta yarim katakdan iborat. Yuzi necha katak?",o:["7","8","6","10"],k:0,s:"2 yarim = 1 butun: 6 + 1 = 7."},
{t:"Shakl 5 ta butun va 6 ta yarim katakdan iborat. Yuzi necha katak?",o:["8","11","5","14"],k:0,s:"6 yarim = 3 butun: 5 + 3 = 8."},
{t:"1 dm² necha kvadrat santimetr?",o:["100 sm²","10 sm²","1000 sm²","20 sm²"],k:0,s:"10 × 10 = 100."},
{t:"3 dm² 6 sm² necha kvadrat santimetr?",o:["306 sm²","36 sm²","360 sm²","316 sm²"],k:0,s:"300 + 6 = 306."},
{t:"400 sm² necha kvadrat detsimetr?",o:["4 dm²","40 dm²","400 dm²","10 dm²"],k:0,s:"100 sm² = 1 dm², 400 sm² = 4 dm²."},
{t:"Daftar varag'ining yuzini qaysi birlikda o'lchash qulay?",o:["sm²","m²","km","kg"],k:0,s:"Varaq kichik — sm²."},
{t:"Panjara qurish uchun hovlining nimasini bilish kerak?",o:["perimetrini","yuzini","balandligini","og'irligini"],k:0,s:"Panjara chegara bo'ylab o'tadi — perimetr."},
{t:"Devorni bo'yash uchun qancha bo'yoq kerakligi nimaga bog'liq?",o:["devorning yuziga","devorning perimetriga","devorning rangiga","devor qalinligiga"],k:0,s:"Bo'yoq devor sirtini qoplaydi — yuz."},
{t:"3 × 2 to'g'ri to'rtburchakning yuzi (katak tomoni 1 sm)?",o:["6 sm²","10 sm","5 sm²","6 sm"],k:0,s:"6 katak — 6 sm². Birligi sm² bo'ladi."},
{t:"3 × 2 to'g'ri to'rtburchakning perimetri (katak tomoni 1 sm)?",o:["10 sm","6 sm²","5 sm","12 sm"],k:0,s:"3 + 2 + 3 + 2 = 10 sm."},
{t:"Kvadrat 4 × 4 kesilib, bo'laklaridan boshqa shakl yasaldi. Yangi shaklning yuzi necha katak?",o:["16","8","12","20"],k:0,s:"Kesib yig'ganda yuz o'zgarmaydi: 16."},
{t:"Bir xil yuzli shakllarni toping: A — 2 × 6, B — 3 × 4, C — 3 × 3.",o:["A va B","A va C","B va C","hammasi"],k:0,s:"A = 12, B = 12, C = 9."},
{t:"1 sotix necha kvadrat metr?",o:["100 m²","10 m²","1000 m²","10 000 m²"],k:0,s:"1 sotix = 100 m²."},
{t:"1 gektar necha sotix?",o:["100","10","1000","50"],k:0,s:"1 gektar = 10 000 m² = 100 sotix."},
{t:"12 ta katakdan iborat shakldan 3 ta katak qirqib olindi, keyin 2 ta yarim katak qo'shildi. Yuzi necha katak bo'ldi?",o:["10","11","9","13"],k:0,s:"12 − 3 = 9; 2 yarim = 1: 9 + 1 = 10."},
{t:"Ikki gilam: biri 4 ta, ikkinchisi 6 ta bir xil plitka qopladi. Ikkalasi birga nechta plitka joyni egallaydi?",o:["10","24","2","12"],k:0,s:"4 + 6 = 10 plitka."},
{t:"Qaysi yozuv to'g'ri?",o:["1 dm² = 100 sm²","1 dm² = 10 sm²","1 m² = 100 sm²","1 sm² = 10 dm²"],k:0,s:"Kvadrat birlik: 10 × 10 = 100."},
{t:"Shakl 2 qatordan iborat: tepada 7 ta katak, pastda 3 ta kam. Yuzi necha katak?",o:["11","10","14","4"],k:0,s:"Pastda 7 − 3 = 4; 7 + 4 = 11."}
];
function PRACT_STAGE(){y9Units(1)}
var PREP_DATA={teach:["Yuz — shakl egallagan joy; bir xil kvadratlar bilan qoplab taqqoslash.","Katakli qog'ozda yuzni sanash; yarim kataklar.","Shakl o'zgarsa ham yuz saqlanishi.","Yuz birliklari: sm², dm², m²; 1 dm² = 100 sm². Yuz va perimetr farqi."],
 mist:["«Uzunroq shakl — kattaroq» deb o'ylaydi.","Yarim kataklarni butun deb sanaydi.","1 dm² ni 10 sm² deydi.","Yuz va perimetrni aralashtiradi, birliklarni (sm va sm²) chalkashtiradi."],
 need:["Bir xil kartochkalar yoki qog'oz kvadratchalar (qoplash uchun).","Katakli varaqlar; 10 × 10 sm kvadrat (1 dm²); gazetadan 1 m² kvadrat."],
 board:["A va B gilam: plitkalar soni — yuz.","Mozaika: 13 katak.","2 yarim = 1 butun: <span class='w2'>5 + 1 = 6</span>.","Bir xil yuz: to'rtburchak, L, U — 6 katak.","<span class='w2'>1 dm² = 10 × 10 = 100 sm²</span>.","Yuz <span class='w2'>6 sm²</span> ≠ perimetr <span class='w2'>10 sm</span>."]};
