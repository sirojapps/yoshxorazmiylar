var CODE='3J12',TITLE="3-sinf · Tarozi va muvozanat masalalari";
function j12It(g,it,x,y){var t=it[0];if(t==='k'){E('rect',{x:x-12,y:y-24,width:24,height:24,rx:3,fill:'#7fb3e6',stroke:C.line,'stroke-width':1.4},g);T(g,x,y-7,it[1]||'?',{'font-size':12,'font-weight':800,fill:'#1d2b3a'});return 26}
 if(t==='w'){E('path',{d:'M'+(x-13)+','+y+' L'+(x-9)+','+(y-24)+' L'+(x+9)+','+(y-24)+' L'+(x+13)+','+y+' Z',fill:'#6b7a89',stroke:'#33404c','stroke-width':1.2},g);T(g,x,y-7,it[1],{'font-size':11,'font-weight':800,fill:'#fff'});return 28}
 if(t==='a'||t==='n'||t==='o'){var col={a:'#e05a5a',n:'#a8d46b',o:'#9b3d6e'}[t];E('circle',{cx:x,cy:y-11,r:11,fill:col,stroke:C.line,'stroke-width':1.2},g);T(g,x,y-7,{a:'O',n:'N',o:'Ch'}[t],{'font-size':10,'font-weight':800,fill:'#fff'});return 24}
 if(t==='t'){E('polygon',{points:(x-12)+','+y+' '+x+','+(y-22)+' '+(x+12)+','+y,fill:'#f2a65a',stroke:C.line,'stroke-width':1.2},g);return 26}
 if(t==='s'){E('rect',{x:x-11,y:y-22,width:22,height:22,fill:'#8fd18f',stroke:C.line,'stroke-width':1.2},g);return 24}return 24}
function j12Bal(L,R,tilt,lab){clear();var g=S.g,dy=(tilt||0)*12;E('polygon',{points:'180,60 166,160 194,160',fill:'#c9d3dd',stroke:C.line,'stroke-width':1.4},g);E('line',{x1:70,y1:60+dy,x2:290,y2:60-dy,stroke:'#53687c','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:5,fill:'#53687c'},g);
 [[L,85,60+dy],[R,275,60-dy]].forEach(function(p){var px=p[1],py=p[2]+56;E('line',{x1:px-50,y1:py,x2:px,y2:p[2],stroke:'#8aa0b4','stroke-width':1.4},g);E('line',{x1:px+50,y1:py,x2:px,y2:p[2],stroke:'#8aa0b4','stroke-width':1.4},g);E('path',{d:'M'+(px-56)+','+py+' Q'+px+','+(py+16)+' '+(px+56)+','+py+' Z',fill:'#e8d3a8',stroke:C.line,'stroke-width':1.4},g);
  var w=0,ws=p[0].map(function(it){return it[0]==='w'?28:(it[0]==='k'?26:24)});ws.forEach(function(v){w+=v});var row=Math.ceil(p[0].length/4)>1;var x=px-Math.min(w,4*26)/2+12,yy=py,c=0;p[0].forEach(function(it,i){if(c===4){c=0;yy-=26;x=px-Math.min(w-4*26,4*26)/2+12}var d=j12It(g,it,x,yy);x+=d;c++})});
 if(lab)T(g,180,172,lab,{'font-size':12,'font-weight':800,fill:C.blue})}
function j12K(n){var a=[];for(var i=0;i<n;i++)a.push(['k']);return a}
var P2=[function(){j12Bal(j12K(3).concat([['w','2']]),j12K(1).concat([['w','8']]));j3Msg('3 kubik + 2 kg = 1 kubik + 8 kg. Kubik og‘irligi?')},
 function(){j12Bal(j12K(2).concat([['w','2']]),[['w','8']]);j3Msg('Ikkala palladan 1 tadan kubik oldik — muvozanat saqlandi: 2 kubik + 2 = 8')},
 function(){j12Bal(j12K(2),[['w','6']]);j3Msg('Ikkala palladan 2 kg oldik: 2 kubik = 6 kg')},
 function(){j12Bal(j12K(1),[['w','3']]);j3Msg('Ikkala tomonni 2 ga bo‘ldik: 1 kubik = <b>3 kg</b>')}];
function j12Coins(){clear();var g=S.g;[[0,3],[1,3],[2,3]].forEach(function(gr,i){for(var k=0;k<3;k++){var x=70+i*110+k*24;E('circle',{cx:x,cy:70,r:10,fill:'#ffd34d',stroke:'#8a5a2b','stroke-width':1.6},g)}T(g,94+i*110,104,['1-guruh','2-guruh','3-guruh'][i],{'font-size':12,'font-weight':800,fill:C.blue})});T(g,180,140,'9 tanga = 3 · 3 · 1',{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
var STEPS=[
{h:"Tarozi muvozanati",sum:"Tarozi muvozanatda bo'lsa, ikki palladagi og'irlik teng: 2 kubik = 6 kg → 1 kubik = 3 kg.",a:"m01",
 start:function(){j12Bal(j12K(2),[['w','6']],0,'muvozanat');j3Msg('Ikki bir xil kubik 6 kg toshni muvozanatlaydi. Bitta kubik necha kg?')},fin:function(){j12Bal(j12K(2),[['w','6']],0,'2 kubik = 6 kg');j3Msg('6 : 2 = 3 kg')},
 html:"<p>Pallali tarozi <b>muvozanatda</b>: chapda ikkita bir xil kubik, o'ngda 6 kg li tosh. Bitta kubik necha kilogramm?</p>",
 btns:j3Ch(["2 kg","3 kg","6 kg","12 kg"],1,function(){j12Bal(j12K(1),[['w','3']],0,'1 kubik = 3 kg');j3Msg('To‘g‘ri! 6 : 2 = 3 kg')},function(i){return ['2 kubik · 2 kg = 4 kg — 6 kg emas','','6 kg — bu ikkala kubik birga','12 = 6 · 2 — ko‘paytirish emas, bo‘lish kerak'][i]}),g2:1,
 after:"<p>Muvozanat = <b>tenglik</b>. Tarozi tenglamaga o'xshaydi: chap tomon = o'ng tomon. Ikkala tomonni bir xil songa bo'lsak ham, muvozanat saqlanadi.</p>",
 q:{t:"Kubik va 5 kg tosh 12 kg toshni muvozanatlaydi. Kubik necha kg?",opts:["17","7","12","5"],ok:1,why:"12 − 5 = 7.",hint:"Ikkala palladan 5 kg olib tashlang.",full:"Kubik + 5 = 12 → kubik = 12 − 5 = 7. «17» — qo'shish xatosi."},
 tn:"Sinfda chizg'ich va qalamdan oddiy tarozi yasang; bir xil tangalar bilan muvozanatni ko'rsating."},
{h:"Ikkala palladan bir xil olamiz",sum:"3 kubik + 2 = 1 kubik + 8 → har tomondan 1 kubik va 2 kg olamiz: 2 kubik = 6 → kubik = 3 kg.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ikkala pallada ham kubik bor. Muvozanatni buzmasdan, <b>ikkala palladan bir xil narsani</b> olib tashlaymiz. Tugmani bosib kuzating.</p>",
 btns:[phaser(P2)],
 after:"<p>Oltin qoida: ikkala palladan <b>bir xil</b> narsani olsak (yoki qo'shsak), muvozanat saqlanadi. Shunday qilib noma'lumni yolg'iz qoldiramiz. Tekshirish: 3 · 3 + 2 = 11, 3 + 8 = 11 ✓.</p>",
 q:{t:"4 kubik = 1 kubik + 9 kg. Kubik necha kg?",opts:["9","3","2","4"],ok:1,why:"Har tomondan 1 kubik: 3 kubik = 9 → 3 kg.",hint:"Ikkala palladan bittadan kubik oling.",full:"4 kubik − 1 kubik = 3 kubik = 9 kg, demak kubik = 3 kg. Tekshiruv: 12 = 3 + 9 ✓. «9» — kubiklarni olib tashlashni unutish."},
 tn:"Tarozi modelini doskada chizing va har qadamda ikkala tomonni bir xil o'chirib boring."},
{h:"Almashtirish zanjiri",sum:"1 olma = 2 nok, 1 nok = 3 olcha → 1 olma = 2 · 3 = 6 olcha.",a:"m03",
 start:function(){j12Bal([['a']],[['n'],['n']],0,'1 olma = 2 nok');j3Msg('1 olma = 2 nok. 1 nok = 3 olcha. 1 olma necha olchaga teng?')},fin:function(){j12Bal([['a']],[['o'],['o'],['o'],['o'],['o'],['o']],0,'1 olma = 6 olcha');j3Msg('Har nok o‘rniga 3 olcha: 2 · 3 = 6')},
 html:"<p>Bir olma ikki nokni muvozanatlaydi, bir nok esa uchta olchani. <b>Bir olma</b> nechta olchaga teng?</p>",
 btns:j3Ch(["5","6","3","9"],1,function(){j12Bal([['a']],[['o'],['o'],['o'],['o'],['o'],['o']],0,'1 olma = 6 olcha');j3Msg('To‘g‘ri! Har nokni 3 olcha bilan almashtirdik: 2 · 3 = 6')},function(i){return ['5 = 2 + 3 — almashtirishda ko‘paytiramiz','','3 — bu bitta nok. Olma 2 nokka teng','9 = 3 · 3 — olma 3 nok emas, 2 nok'][i]}),g2:1,
 after:"<p>Almashtirish: o'ng palladagi har bir nokni 3 olcha bilan almashtiramiz. 2 nok → 2 · 3 = 6 olcha. Zanjir qancha uzun bo'lsa ham — ko'paytirib boramiz.</p>",
 q:{t:"2 olma = 3 nok. 6 olma nechta nokka teng?",opts:["6","9","12","18"],ok:1,why:"6 olma = 3 marta 2 olma = 3 · 3 = 9 nok.",hint:"6 olmada nechta «2 olma» bor?",full:"6 = 3 · 2, demak 6 olma = 3 · 3 nok = 9 nok. «18» — 6 · 3."},
 tn:"Sinfda «almashuv bozori» o'yini: kartochkalar bilan almashtirish zanjiri."},
{h:"Shakllar tizimi",sum:"△ + △ = □ va □ + △ = 12 → □ o'rniga △ + △ qo'yamiz: 3 ta △ = 12 → △ = 4.",a:"m04",
 start:function(){j12Bal([['t'],['t']],[['s']],0,'△ + △ = □');j3Msg('Ikkinchi tarozi: □ + △ = 12 kg. △ necha kg?')},fin:function(){j12Bal([['t'],['t'],['t']],[['w','12']],0,'3 △ = 12');j3Msg('□ = △ + △, demak 3 △ = 12 → △ = 4 kg, □ = 8 kg')},
 html:"<p>Birinchi tarozida: ikki uchburchak = bitta kvadrat. Ikkinchi tarozida: kvadrat va uchburchak birga 12 kg ni muvozanatlaydi. Bitta <b>uchburchak</b> necha kg?</p>",
 btns:j3Ch(["6 kg","4 kg","3 kg","12 kg"],1,function(){j12Bal([['t'],['t'],['t']],[['w','12']],0,'3 △ = 12');j3Msg('To‘g‘ri! □ ni △ + △ bilan almashtirdik: 3 △ = 12, △ = 4')},function(i){return ['6 = 12 : 2 — □ va △ teng emas! □ = 2 ta △','','3 = 12 : 4 — uchburchaklar 4 ta emas, 3 ta','12 — bu □ + △ birga'][i]}),g2:1,
 after:"<p>Usul: kvadratni uchburchaklar bilan <b>almashtiramiz</b>: □ + △ = △ + △ + △ = 12. Endi faqat bir xil shakllar: △ = 12 : 3 = 4, □ = 8. Tekshiruv: 8 + 4 = 12 ✓.</p>",
 q:{t:"Kub + shar = 10 kg, kub = shar + 2 kg. Kub necha kg?",opts:["4","6","8","5"],ok:1,why:"Shar + 2 + shar = 10 → 2 shar = 8 → shar 4, kub 6.",hint:"Kubni «shar + 2» bilan almashtiring.",full:"Kub o'rniga shar + 2: shar + 2 + shar = 10 → 2 shar = 8 → shar = 4, kub = 6. «4» — sharni javob deb olish, «5» — 10 : 2."},
 tn:"Doskada shakllarni rangli magnit bilan almashtiring — bolalar almashtirish g'oyasini ko'z bilan ko'rsin."},
{h:"Soxta tanga: 9 dan topamiz",sum:"9 tanga → 3 ta guruh (3 tadan). 1-tortish yengil guruhni, 2-tortish yengil tangani topadi.",a:"m05",
 start:function(){j12Coins();j3Msg('9 tangadan biri yengilroq (soxta). Pallali tarozida kamida necha tortishda topamiz?')},fin:function(){j12Coins();j3Msg('1-tortish: 1-guruh va 2-guruh. 2-tortish: yengil guruhdan 1 va 1 tanga')},
 html:"<p>9 ta bir xil ko'rinishdagi tangadan bittasi <b>yengilroq</b>. Toshsiz pallali tarozi bor. Kamida necha marta tortib, soxta tangani albatta topish mumkin?</p>",
 btns:j3Ch(["1","2","3","4"],1,function(){j3Msg('To‘g‘ri! 3 ta guruh: ikkitasini tortamiz. Teng bo‘lsa — soxta 3-guruhda. So‘ng guruhdagi 3 tangadan ikkitasini tortamiz')},function(i){return ['1 marta tortish 9 tadan faqat guruhni topadi, tangani emas','','3 ham bo‘ladi, lekin kamroq — 2 marta yetadi. 3 ta guruhga bo‘ling!','4 — tangalarni juftlab tortish: kamroq ham mumkin'][i]}),g2:1,
 after:"<p>Sir: tarozi <b>uch xil</b> javob beradi — chap yengil, o'ng yengil yoki teng. Shuning uchun tangalarni <b>3 guruhga</b> bo'lamiz. 3 tanga — 1 tortish, 9 tanga — 2 tortish, 27 tanga — 3 tortish.</p>",
 q:{t:"3 tangadan biri yengil. Kamida necha tortishda topiladi?",opts:["1","2","3","0"],ok:0,why:"Ikkitasini tortamiz: yengili — soxta; teng bo'lsa — uchinchisi.",hint:"Agar tarozi teng tursa, nima bilib olamiz?",full:"1-tanga va 2-tanga tortiladi. Biri yengil bo'lsa — u soxta. Teng bo'lsa — soxta 3-tanga. Bitta tortish yetadi."},
 tn:"Bir xil tangalar va bitta qog'oz qistirilgan «og'irroq» tanga bilan sinfda haqiqiy tajriba o'tkazing."},
{h:"Tuzoq: tosh ikkala pallada",sum:"1 kg va 3 kg toshlar bilan 2 kg: 3 kg bir pallaga, 1 kg — shakar bilan ikkinchi pallaga: shakar + 1 = 3.",a:"m06",
 start:function(){j12Bal([['w','1'],['w','3']],[],1,'1 kg va 3 kg');j3Msg('Faqat 1 kg va 3 kg toshlar bor. 2 kg shakarni bir tortishda qanday o‘lchaymiz?')},fin:function(){j12Bal([['k','2?'],['w','1']],[['w','3']],0,'shakar + 1 = 3');j3Msg('Shakar = 3 − 1 = 2 kg')},
 html:"<p>Sizda faqat <b>1 kg</b> va <b>3 kg</b> li ikkita tosh bor. 2 kg shakarni <b>bir tortishda</b> qanday o'lchaysiz?</p>",
 btns:j3Ch(["Mumkin emas","1 + 3 bir pallaga","3 kg bir pallaga, 1 kg shakar bilan","1 kg ni ikki marta"],2,function(){j12Bal([['k','2?'],['w','1']],[['w','3']],0,'shakar + 1 = 3');j3Msg('To‘g‘ri! Shakar + 1 kg = 3 kg → shakar = 2 kg')},function(i){return ['Mumkin! Toshni shakar turgan pallaga ham qo‘yish mumkin','1 + 3 = 4 kg — bu 4 kg shakarni o‘lchaydi','','Bu ikki tortish bo‘ladi, bizga bitta kerak'][i]}),
 after:"<p>Tosh shakar turgan pallada bo'lsa — uning og'irligi <b>ayiriladi</b>: shakar = 3 − 1 = 2. Shunday qilib 1 va 3 kg toshlar bilan 1, 2, 3, 4 kg ni o'lchash mumkin. 1, 3, 9 kg toshlar bilan — 1 dan 13 kg gacha hammasini!</p>",
 q:{t:"1 kg va 3 kg toshlar bilan (ikkala pallaga qo'yish mumkin) bir tortishda qaysi og'irlikni o'lchab BO'LMAYDI?",opts:["2 kg","4 kg","5 kg","1 kg"],ok:2,why:"Mumkinlari: 1, 3, 1 + 3 = 4, 3 − 1 = 2. 5 kg — yo'q.",hint:"Toshlar bilan qanday yig'indi va ayirmalar hosil bo'ladi?",full:"Toshlar bilan: 1, 3, 1 + 3 = 4 va 3 − 1 = 2. 5 kg uchun 1 + 3 = 4 yetmaydi. Javob: 5 kg."},
 tn:"Bu — «Bashe toshlari» masalasining sodda ko'rinishi. Kuchli bolalarga 1, 3, 9 kg bilan 7 kg ni topishni bering."},
{h:"Bilasizmi? Kilogramm qanday aniqlanadi",sum:"130 yil davomida kilogramm Parij yaqinida saqlanadigan platina-iridiy silindrga teng bo'lgan. 2019-yildan u tabiat doimiysi orqali aniqlanadi.",a:"m07",
 start:function(){j12Bal([['w','1']],[['k','1']],0,'1 kg = 1 kg');j3Msg('Kilogramm etaloni')},fin:function(){j12Bal([['w','1']],[['k','1']],0,'1 kg = 1 kg');j3Msg('Kilogramm etaloni')},
 html:"<p>⚖️ 1889-yildan 2019-yilgacha butun dunyoda «1 kilogramm» — Fransiyaning Sevr shahrida shisha qalpoqlar ostida saqlanadigan kichik <b>platina-iridiy silindrning</b> og'irligi edi. Barcha mamlakatlarning tarozilari unga solishtirilgan.</p><p>🔬 2019-yil 20-maydan boshlab olimlar kilogrammni buyumga emas, tabiatning o'zgarmas soniga — <b>Plank doimiysiga</b> bog'lashdi. Endi kilogramm hech qachon yo'qolmaydi va o'zgarmaydi.</p>",
 tn:"Sinfga 1 kg li paket (shakar/tuz) olib keling; bolalar qo'lida ushlab, 500 g bilan solishtirsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j12Bal(j12K(1),[['w','3']])},fin:function(){j12Bal(j12K(1),[['w','3']])},
 html:"<div class='memo'><ul><li>Muvozanat = <b>tenglik</b>.</li><li>Ikkala palladan <b>bir xil</b> narsani olsak/qo'shsak — muvozanat saqlanadi.</li><li>Ikkala tomonni bir xil songa bo'lish mumkin.</li><li>Almashtirish: 1 olma = 2 nok, 1 nok = 3 olcha → 1 olma = 6 olcha.</li><li>Shakllar: ko'p shaklni kam shakl bilan almashtiring.</li><li>Soxta tanga: <b>3 guruhga</b> bo'ling (3 → 1, 9 → 2, 27 → 3 tortish).</li><li>Tosh noma'lum bilan bir pallada — ayiriladi.</li></ul></div>",
 tn:"Tarozi — tenglamalarning eng yaxshi modeli. 4-sinfdagi tenglamalarda ham shu rasmga qaytib turing."}
];
var PROBS=[
{t:"Ikki bir xil kubik 8 kg toshni muvozanatlaydi. Bitta kubik necha kg?",o:["4","8","16","6"],k:0,s:"8 : 2 = 4."},
{t:"3 ta bir xil olma 600 g. Bitta olma necha gramm?",o:["200 g","300 g","1800 g","600 g"],k:0,s:"600 : 3 = 200."},
{t:"Kubik + 5 kg = 12 kg. Kubik necha kg?",o:["7","17","12","5"],k:0,s:"12 − 5 = 7."},
{t:"2 kubik + 3 kg = 11 kg. Kubik necha kg?",o:["4","7","8","5"],k:0,s:"11 − 3 = 8, 8 : 2 = 4."},
{t:"3 kubik + 2 kg = 1 kubik + 8 kg. Kubik necha kg?",o:["3","2","5","6"],k:0,s:"2 kubik = 6 → 3 kg."},
{t:"4 kubik = 1 kubik + 9 kg. Kubik necha kg?",o:["3","9","2","4"],k:0,s:"3 kubik = 9 → 3 kg."},
{t:"Tarozida: chapda 2 olma va 1 nok, o'ngda 1 olma va 3 nok. 1 olma nechta nokka teng?",o:["2","3","4","1"],k:0,s:"Har tomondan 1 olma va 1 nok: olma = 2 nok."},
{t:"1 olma = 2 nok, 1 nok = 3 olcha. 1 olma nechta olchaga teng?",o:["6","5","3","9"],k:0,s:"2 · 3 = 6."},
{t:"2 olma = 3 nok. 6 olma nechta nokka teng?",o:["9","6","12","18"],k:0,s:"3 · 3 = 9."},
{t:"1 tarvuz = 3 qovun, 1 qovun = 2 ananas. 2 tarvuz nechta ananasga teng?",o:["12","6","10","7"],k:0,s:"2 · 3 · 2 = 12."},
{t:"△ + △ = □ va □ + △ = 12 kg. △ necha kg?",o:["4","6","3","12"],k:0,s:"3 △ = 12."},
{t:"3 ta ○ = 2 ta △, bitta △ = 6 kg. Bitta ○ necha kg?",o:["4","6","2","9"],k:0,s:"2 △ = 12 kg = 3 ○ → ○ = 4."},
{t:"Kub + shar = 10 kg, kub = shar + 2 kg. Kub necha kg?",o:["6","4","8","5"],k:0,s:"2 shar + 2 = 10 → shar 4, kub 6."},
{t:"Suv to'la chelak 10 kg, yarmigacha suvli chelak 6 kg. Bo'sh chelak necha kg?",o:["2","4","3","6"],k:0,s:"Yarim suv 4 kg, to'la suv 8 kg, chelak 2 kg."},
{t:"Quti 4 ta bir xil to'p bilan 1100 g, 2 ta to'p bilan 700 g. Bo'sh quti necha gramm?",o:["300 g","200 g","400 g","500 g"],k:0,s:"2 to'p = 400 g, to'p 200 g, quti 700 − 400 = 300 g."},
{t:"3 tangadan biri yengil. Toshsiz pallali tarozida kamida necha tortishda uni albatta topish mumkin?",o:["1","2","3","0"],k:0,s:"Ikkitasini tortamiz; teng bo'lsa — uchinchisi."},
{t:"9 tangadan biri yengil. Kamida necha tortishda uni albatta topish mumkin?",o:["2","3","4","1"],k:0,s:"3 guruh → 1 guruh → 1 tanga."},
{t:"27 tangadan biri yengil. Kamida necha tortishda uni albatta topish mumkin?",o:["3","4","9","2"],k:0,s:"27 → 9 → 3 → 1."},
{t:"1 kg va 3 kg toshlar bilan (ikkala pallaga qo'yish mumkin) bir tortishda qaysi og'irlikni o'lchab bo'lmaydi?",o:["5 kg","2 kg","4 kg","1 kg"],k:0,s:"Mumkin: 1, 2 (3 − 1), 3, 4."},
{t:"1, 3 va 9 kg toshlar bor (ikkala pallaga qo'yish mumkin). Bir tortishda eng ko'pi bilan necha kg ni o'lchash mumkin?",o:["13 kg","9 kg","12 kg","10 kg"],k:0,s:"1 + 3 + 9 = 13."}
];
function PRACT_STAGE(){j12Bal(j12K(2),[['w','6']])}
var PREP_DATA={teach:["Tarozi muvozanati = tenglik.","Ikkala palladan bir xil narsani olib tashlash.","Almashtirish zanjirlari va shakllar tizimi.","Soxta tanga (3 guruh), toshlar ikkala pallada."],
 mist:["Bir palladan olib, ikkinchisidan olmaydi.","Almashtirishda ko'paytirish o'rniga qo'shadi.","Soxta tangada 2 guruhga bo'ladi."],
 need:["Pallali tarozi (yoki chizg'ich-tarozi).","Bir xil tangalar, kubiklar."],
 board:["3K + 2 = K + 8 → <span class='w2'>2K = 6</span>","1 olma = 2 nok = <span class='w2'>6 olcha</span>","△ + △ = □: <span class='w2'>3△ = 12</span>","Tangalar: <span class='w2'>3 → 1, 9 → 2, 27 → 3</span>"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
