var CODE='3D1',TITLE='3-sinf · Amallar tartibi va qavslar';
function d1Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){if(v===ok){b.className=b.className.replace(/ (no|yes)/g,'')+' yes';okFn()}else{var k=b.className.replace(/ (no|yes)/g,'');b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
var P4=[function(){w3Expr(['8 + 2 · 5','(8 + 2) · 5']);w3Msg('Bir xil sonlar, bir xil amallar — faqat qavs farq qiladi')},
 function(){w3Expr(['8 + [2 · 5] = 8 + 10 = {18}','(8 + 2) · 5']);w3Msg('Qavssiz: avval ko‘paytirish')},
 function(){w3Expr(['8 + 2 · 5 = {18}','[(8 + 2)] · 5 = 10 · 5 = {50}']);w3Msg('Qavs bor: avval qavs ichi!')},
 function(){w3Expr(['8 + 2 · 5 = 18','(8 + 2) · 5 = 50','18 ≠ 50']);w3Msg('Qavs amallar tartibini <b>o‘zgartiradi</b>')}];
var P6=[function(){w3Expr(['300 · 3 − 250 − 50 · 4']);w3Msg('Avval ko‘paytirishlarni topamiz. Bosib boring')},
 function(){w3Expr(['[300 · 3] − 250 − [50 · 4]','900 − 250 − 200']);w3Msg('1, 2: ko‘paytirishlar: 900 va 200')},
 function(){w3Expr(['900 − 250 − 200','[900 − 250] − 200','650 − 200']);w3Msg('3: chapdan o‘ngga — avval 900 − 250 = 650')},
 function(){w3Expr(['650 − 200','= {450}']);w3Msg('4: 650 − 200 = <b>450</b>')}];
var P7=[function(){w3Expr(['400 : 4 + 380 : 4 · 2']);w3Msg('Bankdagi qiyin misol. Bo‘lish va ko‘paytirish — birinchi bosqich')},
 function(){w3Expr(['[400 : 4] + 380 : 4 · 2','100 + 380 : 4 · 2']);w3Msg('1: 400 : 4 = 100')},
 function(){w3Expr(['100 + [380 : 4] · 2','100 + 95 · 2']);w3Msg('2: 380 : 4 = 95 (360 : 4 + 20 : 4)')},
 function(){w3Expr(['100 + [95 · 2]','100 + 190']);w3Msg('3: 95 · 2 = 190 — bo‘lish va ko‘paytirish chapdan o‘ngga')},
 function(){w3Expr(['100 + 190','= {290}']);w3Msg('4: qo‘shish oxirida: <b>290</b>')}];
function d1Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Bir misol — ikki javob?",sum:"8 + 2 · 5: avval ko'paytirsak 18, chapdan o'ngga 50. To'g'risi — 18.",a:"m01",
 start:function(){S.w1={};w3Expr(['8 + 2 · 5 = ?']);w3Msg('Ikki xil usulda hisoblab ko‘ring')},fin:function(){w3Expr(['8 + 2 · 5','= 8 + 10 = {18}']);w3Msg('Kelishuv: avval ko‘paytirish')},
 html:"<p>Savatda 8 ta olma bor edi. Yana 2 ta qopcha keltirildi, har birida 5 tadan. Jami: <b>8 + 2 · 5</b>. Ikki xil hisoblab ko'ring:</p>",
 btns:[["Chapdan o'ngga",function(c,done){S.w1.a=1;w3Expr(['8 + 2 · 5','(8 + 2) · 5 = [50]']);w3Msg('50 ta? Unda 10 ta qopcha bo‘lishi kerak edi!');if(S.w1.b)done()}],["Avval ko'paytirish",function(c,done){S.w1.b=1;w3Expr(['8 + 2 · 5','8 + 10 = {18}']);w3Msg('8 + 2 qopcha · 5 = 8 + 10 = <b>18</b> ✓');if(S.w1.a)done()},'u']],g2:1,
 after:"<p>Hayotda javob bitta: 8 + 10 = <b>18</b> ta olma. Butun dunyo matematiklari kelishgan: <b>ko'paytirish va bo'lish qo'shish va ayirishdan oldin</b> bajariladi. Aks holda bitta misolni har kim har xil yechardi.</p>",
 q:{t:"20 + 4 · 5 = ?",opts:["40","120","29","100"],ok:0,why:"4 · 5 = 20, 20 + 20 = 40.",hint:"Avval ko'paytirish.",full:"Ko'paytirish birinchi: 4 · 5 = 20. Keyin 20 + 20 = 40. «120» — chapdan o'ngga: 24 · 5."},
 tn:"Olmalar va qopchalar bilan sahnalashtiring — bolalar «50 ta olma» bo'lishi mumkin emasligini o'zlari ko'rsin."},
{h:"Qoida: qaysi amal birinchi?",sum:"Qavssiz ifodada: 1) ko'paytirish va bo'lish (chapdan o'ngga), 2) qo'shish va ayirish (chapdan o'ngga).",a:"m02",
 start:function(){w3Expr(['36 − 12 : 3 · 2 + 5']);w3Msg('Birinchi qaysi amal bajariladi?')},fin:function(){w3Expr(['36 − 12 : 3 · 2 + 5','36 − 4 · 2 + 5','36 − 8 + 5','28 + 5 = {33}'],{top:24,gap:36});w3Msg('Tartib: : → · → − → +')},
 html:"<p><b>36 − 12 : 3 · 2 + 5</b>. Qaysi amal <b>birinchi</b> bajariladi? Tanlang:</p><div class='digs w3c'></div>",
 act:function(c,done){d1Sel(c,'.w3c',['36 − 12','12 : 3','3 · 2','2 + 5'],'12 : 3',function(){w3Expr(['36 − [12 : 3] · 2 + 5','36 − [4 · 2] + 5','[36 − 8] + 5','28 + 5 = {33}'],{top:24,gap:36});w3Msg('1) 12 : 3 = 4 → 2) 4 · 2 = 8 → 3) 36 − 8 = 28 → 4) 28 + 5 = <b>33</b>');done()},{'36 − 12':'Ayirish — ikkinchi bosqich. Avval : va ·','3 · 2':'Bo‘lish ham, ko‘paytirish ham bir bosqichda — chapdan o‘ngga, : chaproqda','2 + 5':'Qo‘shish — eng oxirida'})},
 after:"<p>Ikki bosqich:</p><div class='life'><div>1️⃣<span><b>·</b> va <b>:</b> — chapdan o'ngga</span></div><div>2️⃣<span><b>+</b> va <b>−</b> — chapdan o'ngga</span></div></div><p>Daftarda amallar ustiga tartib raqamini yozing: 1, 2, 3, 4.</p>",
 q:{t:"50 − 30 : 5 · 2 da birinchi qaysi amal?",opts:["30 : 5","50 − 30","5 · 2","Hammasi birga"],ok:0,why:"Bo'lish va ko'paytirish birinchi, chapdan o'ngga — 30 : 5 chaproqda.",hint:"Qaysi amallar 1-bosqichda? Ulardan qaysi biri chapda?",full:"1) 30 : 5 = 6, 2) 6 · 2 = 12, 3) 50 − 12 = 38. «5 · 2» — bo'lish va ko'paytirishda «ko'paytirish birinchi» degan xato tasavvur."},
 tn:"Kartochkalar: «·» va «:» qizil, «+» va «−» ko'k. Bolalar avval qizillarni, keyin ko'klarni ishlasin."},
{h:"Bir bosqichdagi amallar: chapdan o'ngga",sum:"24 : 4 · 2 = 6 · 2 = 12 (3 emas). 20 − 5 − 3 = 12 (18 emas).",a:"m03",
 start:function(){S.w3={};w3Expr(['24 : 4 · 2 = ?','20 − 5 − 3 = ?']);w3Msg('Ikkala misolni yeching')},fin:function(){w3Expr(['24 : 4 · 2 = 6 · 2 = {12}','20 − 5 − 3 = 15 − 3 = {12}']);w3Msg('Bir bosqichda — faqat chapdan o‘ngga')},
 html:"<p>Ko'paytirish va bo'lish <b>teng huquqli</b>. Qo'shish va ayirish ham. Ular orasida — faqat chapdan o'ngga. Ikkala misolni yeching:</p>",
 btns:[["24 : 4 · 2",function(c,done){S.w3.a=1;w3Expr(['24 : 4 · 2','[24 : 4] · 2 = 6 · 2 = {12}','24 : [4 · 2] = [3] ✗']);w3Msg('Chapdagi bo‘lish birinchi: <b>12</b>');if(S.w3.b)done()}],["20 − 5 − 3",function(c,done){S.w3.b=1;w3Expr(['20 − 5 − 3','[20 − 5] − 3 = 15 − 3 = {12}','20 − [5 − 3] = [18] ✗']);w3Msg('Chapdagi ayirish birinchi: <b>12</b>');if(S.w3.a)done()},'u']],g2:1,
 after:"<p>Mantiq: 20 so'mdan avval 5, keyin yana 3 so'm sarflandi — qoldi 12. «5 − 3» ni birinchi hisoblash — boshqa voqea! 24 : 4 · 2 da ham: 24 ni 4 ga bo'lib, natijani 2 marta oshiramiz.</p>",
 q:{t:"48 : 6 · 2 = ?",opts:["16","4","96","8"],ok:0,why:"Chapdan o'ngga: 48 : 6 = 8, 8 · 2 = 16.",hint:"Bo'lish chapda turibdi.",full:"48 : 6 = 8, 8 · 2 = 16. «4» — avval 6 · 2 = 12 qilib, 48 : 12 hisoblash xatosi."},
 tn:"Bu — PEMDAS/BODMAS qisqartmalaridan kelib chiqadigan eng mashhur xato. «Ko'paytirish bo'lishdan oldin» emas — ular teng!"},
{h:"Qavslar tartibni o'zgartiradi",sum:"8 + 2 · 5 = 18, (8 + 2) · 5 = 50. Qavs ichidagi amal eng birinchi.",a:"m04",
 start:function(){startPh(P4)},fin:d1Fin(P4),
 html:"<p>Agar bizga aynan «chapdan o'ngga» kerak bo'lsa-chi? Buning uchun <b>qavs</b> bor. Bosib kuzating:</p>",btns:[phaser(P4)],
 after:"<p>To'liq qoida:</p><div class='life'><div>0️⃣<span><b>( )</b> — qavs ichi eng birinchi</span></div><div>1️⃣<span><b>·</b> va <b>:</b></span></div><div>2️⃣<span><b>+</b> va <b>−</b></span></div></div>",
 q:{t:"(15 + 5) · 3 = ?",opts:["60","30","45","23"],ok:0,why:"Qavs: 20, keyin 20 · 3 = 60.",hint:"Qavs ichini birinchi hisoblang.",full:"15 + 5 = 20, 20 · 3 = 60. «30» — qavsga e'tibor bermay, 15 + 15 = 30 hisoblash."},
 tn:"Qavsni «quti» deb tushuntiring: quti ichidagi ish birinchi bajariladi."},
{h:"Qavsni o'zingiz qo'ying",sum:"6 + 4 · 3 − 1 = 29 bo'lishi uchun: (6 + 4) · 3 − 1 = 30 − 1 = 29.",a:"m05",
 start:function(){w3Expr(['6 + 4 · 3 − 1 = 29']);w3Msg('Qavsni qayerga qo‘yamiz?')},fin:function(){w3Expr(['{(}6 + 4{)} · 3 − 1','= 10 · 3 − 1 = {29}']);w3Msg('To‘g‘ri tenglik')},
 html:"<p>Qavssiz: 6 + 12 − 1 = 17. Lekin <b>29</b> chiqishi kerak. Qavsni qayerga qo'yish kerak?</p><div class='digs w3c'></div>",
 act:function(c,done){d1Sel(c,'.w3c',['(6 + 4) · 3 − 1','6 + 4 · (3 − 1)','(6 + 4) · (3 − 1)'],'(6 + 4) · 3 − 1',function(){w3Expr(['{(}6 + 4{)} · 3 − 1','= 10 · 3 − 1 = {29}']);w3Msg('29 ✓');done()},{'6 + 4 · (3 − 1)':'6 + 4 · 2 = 14 — kichik','(6 + 4) · (3 − 1)':'10 · 2 = 20 — 29 emas'})},
 after:"<p>Strategiya: javob katta bo'lsa — qo'shishni ko'paytirishdan oldin bajarish kerak (qavs). Har bir variantni hisoblab, tekshiramiz. Olimpiadalarda bunday «qavs qo'y» masalalari tez-tez uchraydi.</p>",
 q:{t:"2 + 3 · 4 = 20 bo'lishi uchun qavs qayerga?",opts:["(2 + 3) · 4","2 + (3 · 4)","Qavs kerak emas","(2 + 3 · 4)"],ok:0,why:"5 · 4 = 20.",hint:"Qavssiz 14 chiqadi — kattaroq kerak.",full:"(2 + 3) · 4 = 5 · 4 = 20 ✓. «2 + (3 · 4)» — baribir 14, qavs tartibni o'zgartirmadi."},
 tn:"Juftlikda o'yin: biri ifoda va javob yozadi, ikkinchisi qavs qo'yadi."},
{h:"Uzun ifoda: tartib raqamlari",sum:"300 · 3 − 250 − 50 · 4 = 900 − 250 − 200 = 450.",a:"m06",
 start:function(){startPh(P6)},fin:d1Fin(P6),
 html:"<p>Uzun ifodada avval <b>tartib raqamlarini</b> qo'yib chiqamiz, keyin hisoblaymiz.</p>",btns:[phaser(P6)],
 after:"<p><b>450</b>. Tez-tez qilinadigan xato: 250 − 50 ni birinchi hisoblash (chunki ular yonma-yon). Yo'q — 50 · 4 bir butun, avval u hisoblanadi.</p>",
 q:{t:"7 · 8 − 6 · 5 = ?",opts:["26","250","34","76"],ok:0,why:"56 − 30 = 26.",hint:"Ikkala ko'paytirish birinchi.",full:"7 · 8 = 56, 6 · 5 = 30, 56 − 30 = 26. «250» — chapdan o'ngga: 56 − 6 = 50, 50 · 5 = 250."},
 tn:"Ifodani «yoylar» bilan bo'laklang: ko'paytirish/bo'lish guruhlari ustiga yoy chizing — ular «bitta son» kabi."},
{h:"Murakkab: bo'lish va ko'paytirish zanjiri",sum:"400 : 4 + 380 : 4 · 2 = 100 + 95 · 2 = 100 + 190 = 290.",a:"m07",
 start:function(){startPh(P7)},fin:d1Fin(P7),
 html:"<p>Bank misoli: <b>400 : 4 + 380 : 4 · 2</b>. Ikkita tuzoq bor — qaysilarini topa olasizmi?</p>",btns:[phaser(P7)],
 after:"<p><b>290</b>. Tuzoqlar: 1) «380 : 4 · 2» ni «380 : 8» deb hisoblash (= 47 va qoldiq) — xato; 2) «400 : 4 + 380» ni birga qo'shib yuborish. Chapdan o'ngga va bosqichlarga qat'iy rioya qilamiz.</p>",
 q:{t:"100 − 36 : 6 · 4 = ?",opts:["76","94","64","124"],ok:0,why:"36 : 6 = 6, 6 · 4 = 24, 100 − 24 = 76.",hint:"Bo'lish → ko'paytirish → ayirish.",full:"36 : 6 = 6, 6 · 4 = 24, 100 − 24 = 76. «94» — 6 · 4 ni unutib 100 − 6."},
 tn:"Har qadamni yangi qatorda yozish odatini talab qiling — xatolarning yarmi «boshda hisoblash»dan."},
{h:"Qavs ichida qavs",sum:"96 : (2 · (10 − 6)) = 96 : (2 · 4) = 96 : 8 = 12. Eng ichki qavsdan boshlaymiz.",a:"m08",
 start:function(){w3Expr(['96 : (2 · (10 − 6))']);w3Msg('Birinchi qaysi amal?')},fin:function(){w3Expr(['96 : (2 · [(10 − 6)])','96 : (2 · 4)','96 : 8 = {12}']);w3Msg('Ichkaridan tashqariga')},
 html:"<p><b>96 : (2 · (10 − 6))</b>. Qavs ichida yana qavs bor. Qaysi amal birinchi?</p><div class='digs w3c'></div>",
 act:function(c,done){d1Sel(c,'.w3c',['96 : 2','2 · 10','10 − 6'],'10 − 6',function(){w3Expr(['96 : (2 · [(10 − 6)])','96 : (2 · 4)','96 : 8 = {12}']);w3Msg('1) 10 − 6 = 4 → 2) 2 · 4 = 8 → 3) 96 : 8 = <b>12</b>');done()},{'96 : 2':'96 : 2 qavsdan tashqarida — u oxirgi','2 · 10':'10 − 6 ichki qavsda — u bir butun'})},
 after:"<p>Qavslar — «matryoshka»: eng ichkisini birinchi ochamiz. Katta sinflarda kvadrat [ ] va figurali { } qavslar ham ishlatiladi — tartib o'sha.</p>",
 q:{t:"3 · (20 − 4 · 3) + 6 = ?",opts:["30","54","42","24"],ok:0,why:"Qavs ichida: 4 · 3 = 12, 20 − 12 = 8. Keyin 3 · 8 = 24, 24 + 6 = 30.",hint:"Qavs ichida ham tartib bor: avval ko'paytirish.",full:"Qavs ichi: 20 − 12 = 8 (16 · 3 emas!). 3 · 8 = 24, + 6 = 30. «54» — qavs ichida chapdan o'ngga: (20 − 4) · 3 = 48 → 3 · 16 + 6 = 54."},
 tn:"Matryoshka yoki ichma-ich qutilar bilan ko'rsating."},
{h:"Bilasizmi? Qavslar tarixi",sum:"Qavslar keng tarqalishidan oldin ifoda ustiga chiziq (vinkulum) chizilgan. Qavslarni Leybnits va Eyler ommalashtirgan.",a:"m09",
 start:function(){w3Expr(['(8 + 2) · 5','PEMDAS · BODMAS']);w3Msg('Har xil mamlakat — bitta qoida')},fin:function(){w3Expr(['(8 + 2) · 5','PEMDAS · BODMAS']);w3Msg('Har xil mamlakat — bitta qoida')},
 html:"<p>📜 Bir necha yuz yil oldin qavs o'rniga ifoda <b>ustiga chiziq</b> chizilgan — u <b>vinkulum</b> deyiladi. Bugungi dumaloq qavslarni XVII–XVIII asrlarda <b>Leybnits</b> va <b>Eyler</b> ommalashtirgan.</p><p>🌍 AQShda tartibni <b>PEMDAS</b>, Angliyada <b>BODMAS</b> so'zi bilan yodlashadi. Lekin diqqat: ikkalasida ham ko'paytirish va bo'lish — <b>teng</b>, chapdan o'ngga!</p>",
 tn:"Internetda tarqalgan «6 : 2(1 + 2) = ?» kabi misollar aynan shu qoidani bilmaslikdan bahs chiqaradi — kuchli o'quvchilar bilan muhokama qiling."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['( )  →  · :  →  + −']);w3Msg('Har bosqichda chapdan o‘ngga')},fin:function(){w3Expr(['( )  →  · :  →  + −']);w3Msg('Har bosqichda chapdan o‘ngga')},
 html:"<div class='memo'><ul><li>0) <b>Qavs</b> ichi — eng birinchi (ichki qavsdan boshlab).</li><li>1) <b>·</b> va <b>:</b> — chapdan o'ngga.</li><li>2) <b>+</b> va <b>−</b> — chapdan o'ngga.</li><li>Avval amallar ustiga tartib raqamini yozing.</li><li>⚠️ 24 : 4 · 2 = 12, 3 emas. 20 − 5 − 3 = 12, 18 emas.</li><li>⚠️ Qavs ichida ham tartib: (20 − 4 · 3) = 8.</li></ul></div>",
 tn:"Kartochkani sinf devoriga osib qo'ying — keyingi «tenglamalar» mavzusida ham kerak bo'ladi."}
];
var PROBS=[
{t:"15 + 5 · 3 = ?",o:["30","60","23","45"],k:0,s:"5 · 3 = 15, 15 + 15 = 30."},
{t:"40 − 20 : 4 = ?",o:["35","5","10","15"],k:0,s:"20 : 4 = 5, 40 − 5 = 35."},
{t:"(15 + 5) · 3 = ?",o:["60","30","45","23"],k:0,s:"20 · 3 = 60."},
{t:"48 : 6 · 2 = ?",o:["16","4","96","8"],k:0,s:"Chapdan o'ngga: 8 · 2 = 16."},
{t:"50 − 10 − 5 = ?",o:["35","45","55","25"],k:0,s:"40 − 5 = 35."},
{t:"7 · 8 − 6 · 5 = ?",o:["26","250","34","76"],k:0,s:"56 − 30 = 26."},
{t:"100 − 36 : 6 · 4 = ?",o:["76","94","64","124"],k:0,s:"36 : 6 · 4 = 24, 100 − 24 = 76."},
{t:"720 : (8 + 1) = ?",o:["80","91","81","9"],k:0,s:"720 : 9 = 80."},
{t:"45 + 15 : 5 · (7 − 4) da birinchi qaysi amal bajariladi?",o:["7 − 4","45 + 15","15 : 5","5 · 7"],k:0,s:"Qavs ichi birinchi."},
{t:"45 + 15 : 5 · (7 − 4) = ?",o:["54","36","48","63"],k:0,s:"7 − 4 = 3, 15 : 5 = 3, 3 · 3 = 9, 45 + 9 = 54."},
{t:"2 + 3 · 4 = 20 bo'lishi uchun qavs qayerga qo'yiladi?",o:["(2 + 3) · 4","2 + (3 · 4)","Qavs kerak emas","(2 + 3 · 4)"],k:0,s:"5 · 4 = 20."},
{t:"300 · 3 − 250 − 50 · 4 = ?",o:["450","850","400","650"],k:0,s:"900 − 250 − 200 = 450."},
{t:"400 : 4 + 380 : 4 · 2 = ?",o:["290","195","240","390"],k:0,s:"100 + 95 · 2 = 100 + 190 = 290."},
{t:"96 : (2 · (10 − 6)) = ?",o:["12","192","6","24"],k:0,s:"10 − 6 = 4, 2 · 4 = 8, 96 : 8 = 12."},
{t:"Qaysi ifodaning qiymati 100 ga teng?",o:["(70 − 20) · 2","70 − 20 · 2","70 − (20 · 2)","70 + 20 : 2"],k:0,s:"50 · 2 = 100. Qolganlari: 30, 30, 80."},
{t:"1000 − 25 · 4 · 9 = ?",o:["100","900","8775","0"],k:0,s:"25 · 4 · 9 = 900, 1000 − 900 = 100."},
{t:"Ali 250 so'mlik 4 ta daftar va 300 so'mlik 1 ta ruchka oldi. 2000 so'm berdi. Qancha qaytim oldi?",o:["700","1000","1700","1450"],k:0,s:"2000 − (4 · 250 + 300) = 2000 − 1300 = 700."},
{t:"(56 − 8 · 6) · 7 = ?",o:["56","336","0","2016"],k:0,s:"8 · 6 = 48, 56 − 48 = 8, 8 · 7 = 56."},
{t:"3 · (20 − 4 · 3) + 6 = ?",o:["30","54","42","24"],k:0,s:"Qavs: 20 − 12 = 8; 3 · 8 + 6 = 30."},
{t:"12 ? 4 · 2 = 20. «?» o'rniga qaysi belgi?",o:["+","−",":","·"],k:0,s:"12 + 8 = 20. Boshqalari: 4, 6, 96."}
];
function PRACT_STAGE(){w3Expr(['( )  →  · :  →  + −']);w3Msg('Har bosqichda chapdan o‘ngga')}
var PREP_DATA={teach:["Qavssiz ifodalarda amallar tartibi: · : birinchi, + − keyin.","Bir bosqichdagi amallar chapdan o'ngga.","Qavslar va ichma-ich qavslar.","Qavs qo'yib tenglikni to'g'rilash; uzun ifodalarda tartib raqamlari."],
 mist:["Chapdan o'ngga hisoblaydi: 8 + 2 · 5 = 50.","«Ko'paytirish bo'lishdan oldin» deb o'ylaydi: 24 : 4 · 2 = 3.","Yonma-yon ayirishlarni noto'g'ri guruhlaydi: 20 − 5 − 3 = 18.","Qavs ichida tartibni unutadi: (20 − 4 · 3) = 48."],
 need:["Qizil (· :) va ko'k (+ −) kartochkalar.","Matryoshka yoki ichma-ich qutilar."],
 board:["<span class='w2'>8 + 2 · 5 = 18</span>, <span class='w2'>(8 + 2) · 5 = 50</span>.","<span class='w2'>24 : 4 · 2 = 12</span>.","<span class='w2'>300 · 3 − 250 − 50 · 4 = 450</span>.","<span class='w2'>96 : (2 · (10 − 6)) = 12</span>."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
