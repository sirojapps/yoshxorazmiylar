var CODE='2H09',TITLE="2-sinf · Kesish va bo'laklash (arra, lenta, ustunlar)";
function h9Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// yog'och: kesish joylari (0..1 oralig'ida)
function h9Log(cuts,o){o=o||{};clear();var g=S.g,x0=30,w=300,y=70,h=40;var xs=[0].concat(cuts.slice().sort(function(a,b){return a-b})).concat([1]);
 for(var i=0;i<xs.length-1;i++){var a=x0+xs[i]*w+(i?3:0),b=x0+xs[i+1]*w-(i<xs.length-2?3:0);E('rect',{x:a,y:y,width:b-a,height:h,rx:6,fill:i%2?'#c98b45':'#d9a35a',stroke:C.line,'stroke-width':1.5},g);if(o.lab)T(g,(a+b)/2,y+h/2+5,o.lab,{'font-size':12,'font-weight':800,fill:'#fff'})}
 cuts.forEach(function(c){E('line',{x1:x0+c*w,y1:y-10,x2:x0+c*w,y2:y+h+10,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g)});
 if(o.tap){var r=E('rect',{x:x0,y:y-14,width:w,height:h+28,fill:'transparent',style:'cursor:crosshair'},g);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());o.tap((p.x-x0)/w)})}
 T(g,180,150,'kesish: '+cuts.length+'   ·   bo‘lak: '+(cuts.length+1),{'font-size':15,'font-weight':800,fill:C.blue})}
function h9Posts(n,gap,o){o=o||{};clear();var g=S.g,x0=30,w=300,y=100,k=n>1?w/(n-1):0;E('line',{x1:x0,y1:y-28,x2:x0+w,y2:y-28,stroke:'#a0703c','stroke-width':4},g);
 for(var i=0;i<n;i++){E('rect',{x:x0+i*k-4,y:y-50,width:8,height:56,rx:2,fill:'#6b3d12'},g);T(g,x0+i*k,y+22,String(i+1),{'font-size':11,'font-weight':800,fill:C.ok})}
 for(var j=0;j<n-1;j++)T(g,x0+(j+.5)*k,y-34,gap+' m',{'font-size':10,fill:C.blue,'font-weight':700});
 if(o.br)Br(x0,x0+w,y+34,o.br,false)}
var P2=[function(){h9Log([]);h9Msg('Yog‘ochni 5 bo‘lakka bo‘lamiz. 1 marta arralash — 3 daqiqa')},
 function(){h9Log([.2,.4,.6,.8]);h9Msg('5 bo‘lak uchun <b>4 ta</b> kesish kerak')},
 function(){h9Log([.2,.4,.6,.8]);h9Msg('4 kesish × 3 daqiqa = <b>12 daqiqa</b> (15 emas!)')}];
var P3=[function(){h9Log([.25,.5,.75]);h9Msg('Lenta 3 joyidan qirqildi')},function(){h9Log([.25,.5,.75],{lab:'12 sm'});h9Msg('3 kesish → <b>4 ta</b> bo‘lak, har biri 12 sm')},function(){h9Log([.25,.5,.75],{lab:'12 sm'});h9Msg('Lenta: 12 · 4 = <b>48 sm</b>')}];
var P5=[function(){h9Square(0);h9Msg('Kvadrat maydon: har burchakda va har tomon o‘rtasida ustun')},function(){h9Square(1);h9Msg('Burchaklar: 4 ta')},function(){h9Square(2);h9Msg('Tomon o‘rtalari: 4 ta. Jami <b>8 ta</b>. Yopiq chiziqda ustunlar = oraliqlar!')}];
function h9Square(k){clear();var g=S.g,x=120,y=20,s=130;E('rect',{x:x,y:y,width:s,height:s,fill:'#e8f5e0',stroke:'#7aa86a','stroke-width':3},g);
 var pts=[];if(k>=1)pts=pts.concat([[x,y],[x+s,y],[x+s,y+s],[x,y+s]]);if(k>=2)pts=pts.concat([[x+s/2,y],[x+s,y+s/2],[x+s/2,y+s],[x,y+s/2]]);
 pts.forEach(function(p,i){E('circle',{cx:p[0],cy:p[1],r:8,fill:i<4?C.a:C.blue,stroke:'#fff','stroke-width':2},g)})}
var P6=[function(){h9Stairs(0);h9Msg('1-qavatdan 5-qavatga chiqamiz')},function(){h9Stairs(1);h9Msg('Qavatlar orasi: 1→2, 2→3, 3→4, 4→5 — <b>4 ta</b> (5 emas!)')},function(){h9Stairs(2);h9Msg('Har orada 2 qism × 9 = 18 zinapoya. 4 × 18 = <b>72</b>')}];
function h9Stairs(k){clear();var g=S.g;for(var f=0;f<5;f++){var y=150-f*30;E('rect',{x:110,y:y-28,width:140,height:28,fill:f%2?'#f6e7d0':'#fdf3e3',stroke:C.line},g);T(g,90,y-10,(f+1)+'-qavat',{'font-size':11,'font-weight':800,'text-anchor':'end'});if(k>=1&&f<4){E('path',{d:'M262 '+(y-14)+' q20 -15 0 -30',fill:'none',stroke:C.blue,'stroke-width':2},g);T(g,300,y-26,k>=2?'18':'1 ta',{'font-size':11,'font-weight':800,fill:C.blue})}}}
var P7=[function(){h9Pizza([1,1,1,1,1,1,1,1]);h9Msg('Pitsa 8 bo‘lakka bo‘lindi')},function(){h9Pizza([4,1,1,1,1,1,1,1]);h9Msg('Bitta bo‘lak 4 ga: 1 bo‘lak o‘rniga 4 ta — <b>+3</b>. Jami 11')},function(){h9Pizza([4,3,3,1,1,1,1,1]);h9Msg('Yana ikkitasi 3 tadan: har biri <b>+2</b>. Jami 11 + 4 = <b>15</b>')}];
function h9Pizza(parts){clear();var g=S.g,cx=180,cy=88,r=72;E('circle',{cx:cx,cy:cy,r:r+5,fill:'#e0a84f'},g);var a=-Math.PI/2,step=2*Math.PI/8,tot=0;
 parts.forEach(function(p,i){for(var j=0;j<p;j++){var a0=a+i*step+j*step/p,a1=a0+step/p;var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1);E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 0 1 '+x1+' '+y1+' Z',fill:p>1?'#f7d48b':'#f2c46b',stroke:'#b0702a','stroke-width':1.4},g);tot++}});
 T(g,320,90,tot+' ta',{'font-size':18,'font-weight':800,fill:C.blue})}
var STEPS=[
{h:"Kesishlar va bo'laklar",sum:"1 kesish — 2 bo'lak, 2 kesish — 3 bo'lak. Bo'laklar har doim kesishdan bitta ko'p.",a:"m01",
 start:function(){S.cuts=[];h9Log([],{tap:h9Cut});h9Msg('Yog‘ochni bosib kesing (kamida 3 marta)')},fin:function(){h9Log([.3,.55,.8]);h9Msg('3 kesish → 4 bo‘lak')},
 html:"<p>Mana yog'och. Uni istalgan joyidan <b>bosib arralang</b>. Har kesishdan keyin bo'laklar sonini kuzating.</p>",
 act:function(c,done){S.d1=done;c.querySelector('.hint').textContent='Rasmdagi yog‘ochni bosing.'},
 after:"<p>Qarang: 1 kesish — 2 bo'lak, 2 kesish — 3 bo'lak, 3 kesish — 4 bo'lak. <b>Bo'laklar har doim kesishdan bitta ko'p</b>: bo'lak = kesish + 1.</p>",
 q:{t:"Uzun arqon 4 joyidan qirqildi. Nechta bo'lak hosil bo'ldi?",opts:["4","3","5","8"],ok:2,why:"Bo'lak = kesish + 1 = 5.",hint:"1 kesishda 2 bo'lak bo'lardi. 4 kesishda-chi?",full:"Har kesish bitta bo'lakni ikkiga ajratadi: boshida 1 bo'lak, har kesishda +1. 4 kesish: 1 + 4 = 5 bo'lak."},
 tn:"Qog'oz tasma va qaychi bering — bolalar 1, 2, 3 marta kesib, bo'laklarni sanasin. Jadvalga yozing: kesish | bo'lak."},
{h:"Kesish vaqti: tuzoq",sum:"5 bo'lak uchun 4 kesish: 4 · 3 = 12 daqiqa.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p><i>«Yog'ochni bir marta arralashga 3 daqiqa ketadi. Yog'ochni 5 bo'lakka bo'lish uchun necha daqiqa kerak?»</i> Ko'pchilik 5 · 3 = 15 deydi…</p>",
 btns:[phaser(P2)],
 after:"<p>Vaqt <b>kesishlarga</b> sarflanadi, bo'laklarga emas. 5 bo'lak — 4 kesish: 4 · 3 = <b>12 daqiqa</b>.</p>",
 q:{t:"Akmal simni 10 bo'lakka bo'ldi va 90 sekund sarfladi. Shunday simni 3 bo'lakka bo'lish uchun necha sekund kerak?",opts:["27","30","20","50"],ok:2,why:"10 bo'lak — 9 kesish, 1 kesish 10 s. 3 bo'lak — 2 kesish: 20 s.",hint:"10 bo'lak uchun nechta kesish kerak edi? Bitta kesish necha sekund?",full:"10 bo'lak = 9 kesish, 90 : 9 = 10 sekund bitta kesish. 3 bo'lak = 2 kesish: 2 · 10 = 20 s. «30» — bo'laklarni sanash xatosi."},
 tn:"Jadvalni davom ettiring: bo'lak 5 → kesish 4. Bolalar «vaqt — kesishga» deb takrorlasin."},
{h:"Teskari: bo'lakdan butunga",sum:"3 joyidan qirqilsa — 4 bo'lak. 4 · 12 = 48 sm.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p><i>«Lenta 3 joyidan qirqilib, teng bo'laklarga bo'lindi. Har bo'lak 12 sm. Lentaning uzunligi qancha?»</i></p>",
 btns:[phaser(P3)],
 after:"<p>«3 joyidan» — bu 3 ta <b>kesish</b>, demak <b>4 ta bo'lak</b>. 4 · 12 = <b>48 sm</b>. «36 sm» deganlar kesishni bo'lak deb olgan.</p>",
 q:{t:"36 m arqon 3 joyidan qirqilib, teng bo'laklarga bo'lindi. Har bo'lak necha metr?",opts:["12","9","6","8"],ok:1,why:"3 kesish → 4 bo'lak: 36 : 4 = 9.",hint:"Nechta bo'lak chiqdi? 3 ta emas!",full:"3 kesish — 4 bo'lak. 36 : 4 = 9 m. «12» — 36 ni 3 ga bo'lish xatosi."},
 tn:"Bolalar har masalada avval «kesish nechta, bo'lak nechta?» degan ikki qatorni yozsin."},
{h:"Ustunlar va oraliqlar",sum:"7 ta ustun — 6 ta oraliq. 6 · 4 = 24 m.",a:"m04",
 start:function(){S.np=2;h9Posts(2,4);h9Msg('Ustun qo‘shing va oraliqlarni sanang')},fin:function(){h9Posts(7,4,{br:'6 oraliq · 6 × 4 = 24 m'});h9Msg('7 ustun → 6 oraliq')},
 html:"<p>Yo'l chetiga ustunlar qo'yamiz, ikki qo'shni ustun orasi 4 m. 7 ta ustun bo'lguncha qo'shing:</p>",
 btns:[["+ ustun",function(c,done){if(S.np<7){S.np++;h9Posts(S.np,4,{br:(S.np-1)+' oraliq · '+(S.np-1)+' × 4 = '+((S.np-1)*4)+' m'});h9Msg(S.np+' ustun → <b>'+(S.np-1)+'</b> oraliq');if(S.np===7)done()}},'u']],
 after:"<p>Ustunlar oraliqlardan <b>bitta ko'p</b>: 7 ustun — 6 oraliq. Birinchidan oxirgi ustungacha: 6 · 4 = <b>24 m</b> (28 emas). Bu kesish masalasining aynan o'zi: ustun = kesish joyi + chetlar.</p>",
 q:{t:"Qatorda 5 ta daraxt, qo'shnilar orasi 3 m. Birinchi daraxtdan oxirgisigacha necha metr?",opts:["15","12","18","9"],ok:1,why:"5 daraxt — 4 oraliq: 4 · 3 = 12.",hint:"5 ta daraxt orasida nechta oraliq bor?",full:"5 daraxt orasida 4 ta oraliq. 4 · 3 = 12 m. «15» — daraxtlarni oraliq deb sanash xatosi."},
 tn:"5 ta bolani qatorga qo'ying va orasidagi bo'shliqlarni sanating — «barmoqlar va oraliqlar» bilan ham ko'rsating."},
{h:"Yopiq chiziq: ustun = oraliq",sum:"Aylana yoki kvadrat bo'ylab ustunlar soni oraliqlar soniga teng. Kvadratda burchak + o'rta = 8.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p><i>«Kvadrat maydon chetiga ustunlar qo'yildi: har burchakda bittadan va har tomon o'rtasida bittadan. Hammasi nechta ustun?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>Burchakdagi ustun <b>ikkita tomonga</b> tegishli — uni ikki marta sanab qo'ymang! 4 burchak + 4 o'rta = <b>8</b>. Yopiq chiziqda ustunlar oraliqlarga teng: 8 ustun — 8 oraliq.</p>",
 q:{t:"Dumaloq gulzor atrofiga 10 ta o'rindiq qo'yildi, har ikki qo'shni o'rindiq orasida bitta gul. Nechta gul?",opts:["9","10","11","20"],ok:1,why:"Yopiq doira: oraliqlar = o'rindiqlar = 10.",hint:"Doira yopiq — oxirgi o'rindiq birinchisi bilan qo'shni.",full:"Doira bo'ylab 10 o'rindiq — 10 oraliq (oxirgisi birinchisi bilan yonma-yon). Gullar 10 ta. «9» — to'g'ri chiziq deb o'ylash xatosi."},
 tn:"Bolalarni doira bo'lib qo'l ushlab turg'izing: qo'llar (oraliqlar) soni bolalar soniga teng."},
{h:"Qavatlar va zinapoyalar",sum:"1-qavatdan 5-qavatga — 4 ta qavatlar orasi. 4 · 18 = 72 zinapoya.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p><i>«Qavatlar orasidagi zina 2 qismdan iborat, har qismda 9 tadan zinapoya. 1-qavatdan 5-qavatga chiqish uchun nechta zinapoya bosiladi?»</i></p>",
 btns:[phaser(P6)],
 after:"<p>1-qavatda turibmiz — unga chiqish shart emas! 5 qavat orasida <b>4 ta</b> «oraliq». Har birida 2 · 9 = 18. Jami 4 · 18 = <b>72</b>. «90» — 5 ta oraliq deb sanash xatosi.</p>",
 q:{t:"1-qavatdan 3-qavatga chiqish uchun 36 ta zinapoya bosiladi (qavatlar orasi bir xil). 1-qavatdan 5-qavatga necha zinapoya?",opts:["60","72","90","54"],ok:1,why:"1→3: 2 oraliq = 36, bitta oraliq 18. 1→5: 4 oraliq = 72.",hint:"1-qavatdan 3-qavatgacha nechta qavatlar orasi bor?",full:"1→3 — 2 ta oraliq: 36 : 2 = 18 bittasi. 1→5 — 4 ta oraliq: 4 · 18 = 72. «60» — 36 ni 3 ga bo'lish xatosi."},
 tn:"Maktab zinasida bolalar bilan sanab chiqing — eng esda qoladigan dars bo'ladi."},
{h:"Bo'laklarni yana bo'lsak",sum:"8 bo'lak; birini 4 ga (+3), ikkitasini 3 dan (+2, +2) → 8 + 3 + 4 = 15.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p><i>«Aziz pitsani 8 bo'lakka bo'ldi. Keyin bir bo'lagini yana 4 bo'lakka bo'ldi. Keyin yana ikkita katta bo'lakni olib, har birini 3 bo'lakka bo'ldi. Hammasi nechta bo'lak?»</i></p>",
 btns:[phaser(P7)],
 after:"<p>Kalit: bitta bo'lakni 4 ga bo'lsak, bitta bo'lak <b>yo'qoladi</b>, 4 ta paydo bo'ladi — demak <b>+3</b>. 3 ga bo'lsak <b>+2</b>. 8 + 3 + 2 + 2 = <b>15</b>. «18» deganlar eski bo'laklarni ham qo'shib qo'ygan.</p>",
 q:{t:"Qog'ozni 2 ga kesdik. Keyin har bir bo'lakni yana 2 ga kesdik. Nechta bo'lak bo'ldi?",opts:["3","4","6","8"],ok:1,why:"2 bo'lak, har biri 2 ga: 2 · 2 = 4.",hint:"Birinchi kesishdan keyin nechta bo'lak? Har biri ikkiga bo'linsa-chi?",full:"Birinchi kesish: 2 bo'lak. Har birini 2 ga bo'lsak, har biri o'rniga 2 ta: 2 + 2 = 4."},
 tn:"Haqiqiy qog'oz doira bilan qiling: «bitta bo'lakni olaman — u yo'qoladi — o'rniga 4 ta keladi»."},
{h:"Qadimiy masala: shilliqqurt",sum:"Kunduzi +3, kechasi −2: kuniga +1. Lekin oxirgi kuni chiqib ketadi — 8-kun.",a:"m08",
 start:function(){S.day=0;S.hh=0;h9Well(0,0)},fin:function(){h9Well(8,10)},
 html:"<p><i>«Shilliqqurt chuqurligi 10 m quduqdan chiqmoqda: kunduzi 3 m ko'tariladi, kechasi 2 m pastga sirg'anadi. U necha kunda quduqdan chiqadi?»</i> Kunlarni o'tkazing:</p>",
 btns:[["☀ Keyingi kun",function(c,done){if(S.hh>=10)return;S.day++;var top=S.hh+3;if(top>=10){S.hh=10;h9Well(S.day,10);h9Msg(S.day+'-kun kunduzi 10 m ga yetdi — <b>chiqib ketdi!</b>');done()}else{S.hh=top-2;h9Well(S.day,S.hh);h9Msg(S.day+'-kun: kunduzi '+top+' m gacha, kechasi '+S.hh+' m ga tushdi')}}]],
 after:"<p>Ko'pchilik «kuniga 1 m, demak 10 kun» deydi. Lekin 7-kunning oxirida u 7 m da, 8-kun kunduzi 7 + 3 = 10 — <b>chiqib ketadi</b>, kechasi sirg'anishga ulgurmaydi. Javob: <b>8 kun</b>.</p><p>📜 Bu masala juda qadimiy — u ko'p asrlar davomida turli xalqlarning masala kitoblarida uchraydi.</p>",
 q:{t:"Chumoli 6 m ustunga chiqmoqda: kunduzi 3 m chiqadi, kechasi 1 m tushadi. Necha kunda tepaga chiqadi?",opts:["3","2","4","6"],ok:0,why:"1-kun oxiri 2 m, 2-kun oxiri 4 m, 3-kun kunduzi 4 + 3 = 7 ≥ 6 — chiqdi.",hint:"Kun-kun yozing: kunduzi qayergacha, kechasi qayergacha?",full:"1-kun: 3 ga chiqib, 2 ga tushdi. 2-kun: 5 ga chiqib, 4 ga tushdi. 3-kun: 4 + 3 = 7 — 6 dan oshdi, chiqdi. Javob: 3 kun."},
 tn:"Jadval: kun | kunduzi | kechasi. Bolalar har qatorni to'ldirsin — oxirgi kunni hech kim unutmaydi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){h9Log([.25,.5,.75]);h9Msg('3 kesish → 4 bo‘lak')},fin:function(){h9Log([.25,.5,.75]);h9Msg('3 kesish → 4 bo‘lak')},
 html:"<div class='memo'><ul><li><b>Bo'lak = kesish + 1</b> (to'g'ri chiziqda).</li><li>Vaqt kesishlarga sarflanadi: 5 bo'lak — 4 kesish.</li><li>«3 joyidan qirqildi» — 3 kesish, 4 bo'lak.</li><li><b>Ustun = oraliq + 1</b>: 7 ustun — 6 oraliq.</li><li>Yopiq chiziqda (doira, kvadrat): ustun = oraliq. Burchakdagi ustunni ikki marta sanamang.</li><li>1-qavatdan 5-qavatga — 4 ta qavatlar orasi.</li><li>Bitta bo'lak 4 ga bo'linsa — +3.</li><li>Shilliqqurt: oxirgi kunni alohida tekshiring.</li></ul></div>",
 tn:"Keyingi darsni «Qaychi bilan qog'ozni 6 bo'lakka necha marta kesasiz?» savoli bilan boshlang."}
];
function h9Cut(x){if(x<.04||x>.96||S.cuts.length>=6)return;S.cuts.push(x);h9Log(S.cuts,{tap:h9Cut});h9Msg(S.cuts.length+' kesish → <b>'+(S.cuts.length+1)+'</b> bo‘lak');if(S.cuts.length>=3&&S.d1){var d=S.d1;S.d1=null;d()}}
function h9Well(day,hh){clear();var g=S.g,x=150,y0=14,H=150;E('rect',{x:x,y:y0,width:60,height:H,fill:'#e9e2d6',stroke:'#8a7a60','stroke-width':2},g);for(var m=0;m<=10;m+=2){var y=y0+H-m*H/10;E('line',{x1:x-6,y1:y,x2:x,y2:y,stroke:'#8a7a60'},g);T(g,x-10,y+4,m+' m',{'font-size':10,'text-anchor':'end',fill:'#5b6b7b'})}
 T(g,x+30,y0+H-hh*H/10+4,'🐌',{'font-size':20});T(g,280,90,day?day+'-kun':'boshlanish',{'font-size':16,'font-weight':800,fill:C.blue})}
var PROBS=[
{t:"Arqon 4 joyidan qirqildi. Nechta bo'lak?",o:["5","4","3","8"],k:0,s:"Bo'lak = kesish + 1 = 5."},
{t:"Yog'ochni bir marta arralashga 3 daqiqa ketadi. 5 bo'lakka bo'lish uchun necha daqiqa?",o:["12","15","18","9"],k:0,s:"4 kesish · 3 = 12."},
{t:"Simni 10 bo'lakka bo'lishga 90 sekund ketdi. 3 bo'lakka bo'lish uchun necha sekund?",o:["20","30","27","50"],k:0,s:"9 kesish = 90 s, 1 kesish 10 s. 2 kesish = 20 s."},
{t:"Lenta 3 joyidan qirqilib, teng bo'laklarga bo'lindi, har bo'lak 12 sm. Lenta uzunligi?",o:["48 sm","36 sm","24 sm","60 sm"],k:0,s:"4 bo'lak · 12 = 48."},
{t:"36 m arqon 3 joyidan qirqilib, teng bo'laklarga bo'lindi. Har bo'lak necha metr?",o:["9","12","6","8"],k:0,s:"4 bo'lak: 36 : 4 = 9."},
{t:"7 ta ustun, qo'shnilar orasi 4 m. Birinchidan oxirgisigacha necha metr?",o:["24 m","28 m","20 m","32 m"],k:0,s:"6 oraliq · 4 = 24."},
{t:"5 ta daraxt, orasi 3 m. Birinchidan oxirgisigacha?",o:["12 m","15 m","18 m","9 m"],k:0,s:"4 · 3 = 12."},
{t:"Har 5 metrda fonar bor. Birinchi va oltinchi fonar orasidagi masofa?",o:["25 m","30 m","35 m","20 m"],k:0,s:"1-dan 6-gacha 5 oraliq: 25 m."},
{t:"To'g'ri chiziq bo'ylab 7 daraxt, har ikki qo'shni orasida bitta gul. Nechta gul?",o:["6","7","8","14"],k:0,s:"Oraliqlar 6 ta."},
{t:"Kvadrat maydon: har burchakda va har tomon o'rtasida ustun. Jami nechta?",o:["8","12","6","4"],k:0,s:"4 burchak + 4 o'rta = 8."},
{t:"Qavatlar orasidagi zina 2 qism, har biri 9 zinapoya. 1-qavatdan 5-qavatga necha zinapoya?",o:["72","90","81","54"],k:0,s:"4 oraliq · 18 = 72."},
{t:"1-qavatdan 3-qavatga 36 zinapoya. 1-qavatdan 5-qavatga?",o:["72","60","90","54"],k:0,s:"Bir oraliq 18, 4 oraliq 72."},
{t:"Pitsa 8 bo'lakka, keyin bittasi 4 ga, so'ng yana ikkitasi 3 tadan bo'lindi. Jami bo'lak?",o:["15","17","18","14"],k:0,s:"8 + 3 + 2 + 2 = 15."},
{t:"Shilliqqurt 10 m quduqdan: kunduzi +3 m, kechasi −2 m. Necha kunda chiqadi?",o:["8","10","7","5"],k:0,s:"7-kun oxiri 7 m, 8-kun kunduzi 10 m."},
{t:"12 m lentani 3 m dan bo'laklarga kesish kerak. 1 kesish — 2 minut. Necha minut?",o:["6","8","4","3"],k:0,s:"4 bo'lak — 3 kesish · 2 = 6."},
{t:"Devorda 5 rozetka bir xil masofada, 1- va 2- orasi 90 sm. Chetki rozetkalar orasi?",o:["360 sm","450 sm","270 sm","540 sm"],k:0,s:"4 oraliq · 90 = 360."},
{t:"Ko'chatlar 4 m dan, birinchisi darvozadan 4 m da. Darvozadan 20 m dagi ko'chat nechanchi?",o:["5-","4-","6-","16-"],k:0,s:"4, 8, 12, 16, 20 — 5-ko'chat."},
{t:"Yo'lning ikki tomoniga 8 tadan chiroq, har ikki qo'shni chiroq orasida bitta o'rindiq. Jami o'rindiq?",o:["14","7","16","18"],k:0,s:"Har tomonda 7: 7 · 2 = 14."},
{t:"Dumaloq gulzor atrofida 10 o'rindiq, har ikki qo'shnisi orasida bitta gul. Nechta gul?",o:["10","9","11","20"],k:0,s:"Yopiq: oraliq = 10."},
{t:"Qog'oz 2 ga kesildi, keyin har bo'lak yana 2 ga. Necha bo'lak?",o:["4","3","6","8"],k:0,s:"2 · 2 = 4."}
];
function PRACT_STAGE(){h9Log([.25,.5,.75]);h9Msg('Bo‘lak = kesish + 1 · Ustun = oraliq + 1')}
var PREP_DATA={teach:["Bo'lak = kesish + 1; vaqt kesishlarga sarflanadi.","Ustunlar va oraliqlar: ustun = oraliq + 1; yopiq chiziqda teng.","Qavatlar orasidagi zinalar; bo'laklarni qayta bo'lish.","Qadimiy «shilliqqurt» masalasi — oxirgi kunni alohida tekshirish."],
 mist:["5 bo'lak uchun 5 kesish deb hisoblaydi.","«3 joyidan qirqildi» ni 3 bo'lak deb oladi.","Ustunlarni oraliq deb sanaydi (7 · 4 = 28).","1-qavatdan 5-qavatgacha 5 oraliq deydi.","Shilliqqurtda 10 kun deydi."],
 need:["Qog'oz tasmalar, qaychi.","Qog'oz doira (pitsa)."],
 board:["Jadval: <span class='w2'>kesish | bo'lak</span> — 1|2, 2|3, 3|4.","<span class='w2'>5 bo'lak → 4 kesish → 4 · 3 = 12</span>.","Ustunlar: <span class='w2'>| _ | _ | _ |</span> — 4 ustun, 3 oraliq.","Kvadrat: 4 burchak + 4 o'rta = 8.","Qavatlar: 1→5 = 4 oraliq."]};
