var CODE='4J12',TITLE="4-sinf · Tarozi, quyish va o'lchash jumboqlari";
var P12b=[function(){j2Lines([["27 ta tanga, 1 tasi yengil",C.blue,20],["tarozi — 3 marta",null,16]]);j2Msg("27 tangadan bittasi yengilroq. Uni <b>3 ta</b> tortishda topamiz.")},
 function(){k4Bal(["9 ta"],["9 ta"],0,"1-tortish: 9 | 9   (9 tasi chetda)");j2Msg("27 ni <b>uch</b> guruhga: 9, 9, 9. Ikkitasini tortamiz. Teng bo'lsa — soxta chetdagi 9 tada, bo'lmasa — yengil pallada.")},
 function(){k4Bal(["3 ta"],["3 ta"],-1,"2-tortish: 3 | 3   (3 tasi chetda)");j2Msg("Endi 9 ta qoldi → yana uchga: 3, 3, 3. Bu safar o'ng palla yengil — soxta o'sha 3 tada.")},
 function(){k4Bal(["1"],["1"],1,"3-tortish: 1 | 1   (1 tasi chetda)");j2Msg("3 ta → 1, 1, 1. Chap palla ko'tarildi — soxta tanga o'sha! <b>27 → 9 → 3 → 1</b>: har tortish qolganni <b>3 ga</b> bo'ladi.")}];
var P12c=[function(){j2Lines([["10 ta tanga — 3 ga bo'linmaydi!",C.bad,18],["10 = 3 + 3 + 4",C.blue,22]]);j2Msg("10 ni teng uchga bo'lib bo'lmaydi. Lekin teng bo'lishi shart emas: <b>3 | 3</b> tortamiz, <b>4</b> tasi chetda.")},
 function(){k4Bal(["3 ta"],["3 ta"],0,"1-tortish: 3 | 3, chetda 4 ta");j2Msg("Eng omadsiz holat: tarozi teng → soxta chetdagi <b>4 ta</b> ichida.")},
 function(){k4Bal(["1"],["1"],0,"2-tortish: 1 | 1, chetda 2 ta");j2Msg("4 ta → 1 | 1, chetda 2 ta. Yana teng chiqsa — soxta chetdagi 2 tada.")},
 function(){k4Bal(["1"],["1"],-1,"3-tortish: 1 | 1");j2Msg("2 ta → 1 | 1: yengili ko'tariladi. Jami <b>3 tortish</b>. 2 tortish yetmaydi: 2 tortish ko'pi bilan 9 ta tangani tekshiradi.")}];
var P12d=[function(){j2Boxes([["1"],["2"],["3"],["4"],["5"]],{names:["1-xalta","2-xalta","3-xalta","4-xalta","…10-xalta"]});j2Msg("10 xalta tanga. Haqiqiy tanga 10 g, bitta xaltadagilar soxta — 9 g. <b>Bitta</b> tortishda qaysi xalta?")},
 function(){j2Lines([["1 + 2 + 3 + … + 10 = 55 ta tanga",C.blue,18],["hammasi haqiqiy bo'lsa: 550 g",null,16]]);j2Msg("Hiyla: 1-xaltadan 1 ta, 2-xaltadan 2 ta, … 10-xaltadan 10 ta tanga olib, hammasini birga tortamiz.")},
 function(){j2Lines([["tarozi: 546 g",C.bad,24],["550 − 546 = 4 g kam",null,18],["→ 4 ta soxta → 4-xalta",C.ok,18]]);j2Msg("Har soxta tanga 1 g kam. 4 g kam bo'lsa — soxtalar 4 ta, ular faqat <b>4-xaltadan</b> olingan.")}];
var P12e=[[8,0,0,"Boshida: 8 L idish to'la"],[3,5,0,"8 → 5: 5 L idish to'ldi"],[3,2,3,"5 → 3: 3 L idish to'ldi"],[6,2,0,"3 → 8: qaytarib quydik"],[6,0,2,"5 → 3: 2 L ni o'tkazdik"],[1,5,2,"8 → 5: yana to'ldirdik"],[1,4,3,"5 → 3: faqat 1 L sig'di"],[4,4,0,"3 → 8: 4 L va 4 L — teng!"]].map(function(s){return function(){k4Jugs([8,5,3],s.slice(0,3));j2Msg(s[3])}});
var P12f=[function(){j2Lines([["⏳ 7 daq   ⏳ 11 daq",C.blue,22],["15 daqiqani o'lchang",null,16]]);j2Msg("Tuxum 15 daqiqa qaynashi kerak. Faqat 7 va 11 daqiqalik qum soatlar bor.")},
 function(){j2Lines([["0-daqiqa: ikkalasini ag'daramiz",null,17],["7-daqiqa: 7 tugadi → uni yana ag'daramiz",C.blue,15],["(11 likda yana 4 daqiqa qum bor)",null,13]]);j2Msg("7-daqiqada 7 daqiqalik tugaydi — darhol ag'daramiz.")},
 function(){j2Lines([["11-daqiqa: 11 tugadi",null,17],["7 likning pastiga 4 daqiqalik qum tushgan",null,14],["→ uni ag'daramiz: 4 daqiqa",C.blue,15],["11 + 4 = 15 ✓",C.ok,22]],{dy:30});j2Msg("11-daqiqada 7 likni yana ag'daramiz: unda 4 daqiqalik qum bor. U tugaganda — <b>15</b>.")}];
var STEPS=[
{h:"Toshlarni ikkala pallaga qo'yamiz",sum:"1, 3, 9 kg toshlar: tosh yuk tomonda bo'lsa — ayiriladi. 5 = 9 − 3 − 1.",a:"m01",
 start:function(){k4Bal(["5 kg?"],[],-1,"1 kg, 3 kg, 9 kg toshlar bor");j2Msg("5 kg shakarni qanday tortamiz? To'g'ri usulni tanlang.")},
 fin:function(){k4Bal(["shakar","1","3"],["9"],0,"shakar + 1 + 3 = 9 → shakar = 5 kg");j2Msg("Tosh <b>shakar tomonda</b> bo'lsa, u ayiriladi: 9 − 3 − 1 = <b>5</b>")},
 html:"<p>Bizda faqat <b>1 kg, 3 kg va 9 kg</b> toshlar bor (har biridan bittadan). Toshlarni <b>ikkala</b> pallaga qo'yish mumkin. 5 kg shakarni qanday tortamiz?</p>",
 btns:j2Pick(["Chapda: shakar + 1 + 3; o'ngda: 9","Chapda: shakar; o'ngda: 3 + 1","Chapda: shakar + 9; o'ngda: 3 + 1"],0,function(){k4Bal(["shakar","1","3"],["9"],0,"shakar + 1 + 3 = 9 → shakar = 5 kg");j2Msg("To'g'ri! 5 + 1 + 3 = 9")},function(i){j2Msg(i===1?"3 + 1 = 4 kg — bu 5 emas.":"Shakar + 9 = 4? Bunday bo'lmaydi — chap palla og'ir bo'lib qoladi.")}),
 after:"<p>Tosh yuk bilan <b>bir pallada</b> bo'lsa, u ayiriladi; qarshi pallada bo'lsa — qo'shiladi. Shunda 1, 3, 9 kg bilan 1 dan <b>13 kg</b> gacha istalgan yukni tortish mumkin.</p>",
 q:{t:"1, 3, 9 kg toshlar (ikkala pallaga qo'yish mumkin). 7 kg ni qanday tortamiz?",opts:["Chapda: yuk + 3; o'ngda: 9 + 1","Chapda: yuk + 1; o'ngda: 9","Chapda: yuk; o'ngda: 3 + 1 + 1","Chapda: yuk + 9; o'ngda: 3 + 1"],ok:0,why:"7 + 3 = 10 = 9 + 1.",hint:"Har variantda chap va o'ng pallani hisoblang: yuk o'rniga 7 qo'yib tekshiring.",full:"7 + 3 = 10 va 9 + 1 = 10 — teng. 2-variant: 7 + 1 = 8 ≠ 9. 3-variant: 1 kg tosh bitta, ikki marta qo'yib bo'lmaydi. 4-variant: 7 + 9 = 16 ≠ 4."},
 tn:"Doskaga tarozi chizing, toshlarni magnit kartochka qilib ikkala pallaga ko'chiring. «Tosh yuk yonida — minus» qoidasini bolalar o'zi aytsin."},
{h:"Soxta tanga: 27 ta, 3 tortish",sum:"Tangalarni 3 guruhga bo'lamiz: 27 → 9 → 3 → 1. Har tortish qolganni 3 ga bo'ladi.",a:"m02",
 start:function(){startPh(P12b)},fin:function(){S.ph=3;P12b[3]()},
 html:"<p>27 ta bir xil ko'rinishdagi tangadan bittasi <b>yengilroq</b> (soxta). Toshsiz pallali tarozida kamida necha tortishda topamiz?</p>",
 btns:[phaser(P12b)],
 after:"<p>Asosiy fikr: tarozining <b>uch</b> javobi bor (chap og'ir, o'ng og'ir, teng). Shuning uchun tangalarni <b>ikkiga emas, uchga</b> bo'lamiz. 1 tortish — 3 ta, 2 tortish — 9 ta, 3 tortish — 27 ta tanga.</p>",
 q:{t:"81 ta tangadan bittasi yengil. Kamida necha tortishda topiladi?",opts:["3","4","5","9"],ok:1,why:"81 → 27 → 9 → 3 → 1: 4 ta tortish.",hint:"Har tortishda tangalar soni 3 marta kamayadi. 81 ni necha marta 3 ga bo'lsak, 1 qoladi?",full:"81 : 3 = 27, 27 : 3 = 9, 9 : 3 = 3, 3 : 3 = 1 — 4 marta bo'ldik, demak 4 tortish. 3 tortish faqat 27 tagacha yetadi."},
 tn:"Bolalarga 9 ta bir xil qopqoq bering, bittasining ichiga kichik plastilin yopishtiring (og'irroq). Ular tarozida (yoki qo'lda) topsin."},
{h:"Tuzoq: 10 ta tanga",sum:"10 = 3 + 3 + 4: guruhlar teng bo'lishi shart emas. 2 tortish ko'pi bilan 9 tani tekshiradi, shuning uchun 3 tortish.",a:"m03",
 start:function(){startPh(P12c)},fin:function(){S.ph=3;P12c[3]()},
 html:"<p>Agar tangalar soni 3 ga bo'linmasa-chi? 10 ta tangadan bittasi yengil. Ko'pchilik «uchga bo'lib bo'lmaydi» deb adashadi.</p>",
 btns:[phaser(P12c)],
 after:"<p>Qoida: 2 tortish ko'pi bilan <b>9</b> ta, 3 tortish ko'pi bilan <b>27</b> ta tangani tekshiradi. 10 ta 9 dan ko'p, 27 dan kam → <b>3 tortish</b>. Guruhlarni iloji boricha teng qilamiz.</p>",
 q:{t:"15 ta tangadan bittasi yengil. Kamida necha tortishda albatta topiladi?",opts:["2","3","4","5"],ok:1,why:"9 < 15 ≤ 27 → 3 tortish.",hint:"2 tortish nechta tangagacha yetadi? 3 tortish-chi?",full:"2 tortish ko'pi bilan 9 tani, 3 tortish 27 tani tekshiradi. 15 ta — 9 dan ko'p, demak 3 tortish kerak. Masalan: 5 | 5, chetda 5 → 2 | 2, chetda 1 → 1 | 1."},
 tn:"Jadval yozdiring: 1 tortish — 3, 2 tortish — 9, 3 tortish — 27, 4 tortish — 81. Bu 3 ning darajalari."},
{h:"Xaltalar hiylasi: bitta tortish",sum:"1-xaltadan 1, 2-dan 2 … tanga olinadi. Necha gramm kam bo'lsa — o'sha xalta.",a:"m04",
 start:function(){startPh(P12d)},fin:function(){S.ph=2;P12d[2]()},
 html:"<p>Endi gramm ko'rsatadigan tarozi bor, lekin faqat <b>bitta</b> tortish mumkin. 10 xaltadan qaysi biridagi tangalar soxta (9 g)?</p>",
 btns:[phaser(P12d)],
 after:"<p>Har xaltadan <b>har xil</b> sondagi tanga olganimiz uchun, kamomad bizga xalta raqamini «aytib beradi». 55 ta haqiqiy tanga 550 g bo'lardi.</p>",
 q:{t:"Xuddi shunday tortilganda tarozi 543 g ko'rsatdi. Qaysi xalta soxta?",opts:["3-xalta","7-xalta","5-xalta","4-xalta"],ok:1,why:"550 − 543 = 7 g kam → 7 ta soxta tanga → 7-xalta.",hint:"Hammasi haqiqiy bo'lsa necha gramm bo'lardi? Farqi nechta?",full:"55 ta tanga · 10 g = 550 g. 550 − 543 = 7 g. Har soxta tanga 1 g kam, demak 7 ta soxta tanga bor. 7 ta tanga faqat 7-xaltadan olingan. «3» — 543 ning oxirgi raqamini olgan xato."},
 tn:"Tarozi bo'lmasa, «og'irlik» o'rniga ochko bilan o'ynang: har qopqoq 10 ochko, soxtasi 9 ochko."},
{h:"Quyish: 8 litrni teng bo'lamiz",sum:"8, 5, 3 L idishlar: 7 ta quyishda 4 L + 4 L.",a:"m05",
 start:function(){startPh(P12e)},fin:function(){S.ph=7;P12e[7]()},
 html:"<p>8 L idish sutga to'la. Bo'sh 5 L va 3 L idishlar bor. Sutni <b>teng ikkiga</b> (4 L va 4 L) qanday bo'lamiz? Har quyishni kuzating.</p>",
 btns:[phaser(P12e,"▶ Quyish")],
 after:"<p>Hiyla: kichik idish (3 L) «o'lchov» bo'lib ishlaydi — u to'lganda aniq son paydo bo'ladi. 5 − 3 = 2, 2 + 3 + … qadamlar orqali 4 ga yetdik.</p>",
 q:{t:"5 L va 3 L idish, suv jo'mrakdan cheksiz, to'kish ham mumkin. Qaysi usul aniq 4 L beradi?",opts:["5 ni to'ldirib 3 ga quyamiz (5 da 2 qoladi); 3 ni to'kib, 2 ni 3 ga o'tkazamiz; 5 ni to'ldirib 3 to'lguncha quyamiz","5 ni to'ldirib, ko'z bilan 1 L to'kib tashlaymiz","3 ni ikki marta to'ldirib, 5 ga quyamiz","5 ni ham, 3 ni ham yarmigacha to'ldiramiz"],ok:0,why:"Oxirida 3 L idishda 2 L bor, unga faqat 1 L sig'adi: 5 − 1 = 4.",hint:"«Ko'z bilan» va «yarmigacha» — aniq emas. Faqat to'liq to'ldirish va to'liq bo'shatish aniq.",full:"1-usul: 5 → 3 (5 da 2), 3 ni to'kamiz, 2 ni 3 ga (3 da 2), 5 ni to'ldiramiz, 3 ga 1 L sig'adi → 5 da 4 L. 3-usul: 3 + 3 = 6, 5 ga faqat 5 sig'adi, 3 L idishda 1 L qoladi — 4 emas."},
 tn:"Uchta plastik butilkaga 8, 5, 3 belgisini yozing, suv bilan sinfda haqiqiy quying."},
{h:"Qum soatlar: 7 + 11 = 15",sum:"7 tugaganda ag'daramiz, 11 tugaganda 7 likni yana ag'daramiz: 11 + 4 = 15.",a:"m06",
 start:function(){startPh(P12f)},fin:function(){S.ph=2;P12f[2]()},
 html:"<p>Vaqtni ham «quyib» o'lchaymiz: qum soat — vaqt idishi.</p>",
 btns:[phaser(P12f)],
 after:"<p>Qum soatni ag'darish — qumni «qaytarib quyish». 7 daqiqalik soat 7-daqiqadan 11-daqiqagacha 4 daqiqa ishladi, ag'darsak — aynan 4 daqiqa ishlaydi.</p>",
 q:{t:"4 va 7 daqiqalik qum soatlar birga ag'darildi. 4 lik tugaganda u yana ag'darildi. 7 lik tugaganda 4 likning tepasida necha daqiqalik qum bor?",opts:["0","1","3","4"],ok:1,why:"4 lik 4-daqiqada ag'darilib, 7-daqiqagacha 3 daqiqa ishladi: tepada 4 − 3 = 1.",hint:"7-daqiqagacha 4 lik ikkinchi marta necha daqiqa ishladi?",full:"4-daqiqada 4 lik ag'darildi. 7-daqiqagacha u 3 daqiqa ishladi, ya'ni 3 daqiqalik qum pastga tushdi, tepada 1 daqiqalik qoldi. Javob: 1. Shu orqali 9 daqiqani ham o'lchash mumkin."},
 tn:"Telefon taymeri bilan 7 va 11 o'rniga 1 va 2 daqiqalik «qum soat» o'yinini o'ynating."},
{h:"Bilasizmi? 1, 3, 9, 27",sum:"Bashe de Meziriak (1612): 1, 3, 9, 27 kg toshlar bilan 1 dan 40 kg gacha har qanday yuk tortiladi.",a:"m07",
 start:function(){j2Lines([["1 · 3 · 9 · 27",C.blue,26],["1 + 3 + 9 + 27 = 40",null,18]]);j2Msg("4 ta tosh — 40 xil yuk")},fin:function(){j2Lines([["1 · 3 · 9 · 27",C.blue,26],["1 + 3 + 9 + 27 = 40",null,18]]);j2Msg("4 ta tosh — 40 xil yuk")},
 html:"<p>📜 Fransuz matematigi <b>Klod Gaspar Bashe de Meziriak</b> 1612-yilda chiqqan jumboqlar kitobida shunday masala bergan: eng kam toshlar bilan 1 dan 40 kg gacha har qanday yukni tortish. Javob — <b>4 ta</b> tosh: 1, 3, 9 va 27 kg (ikkala pallaga qo'yiladi).</p><p>Toshlarni faqat bitta pallaga qo'ysak, 1, 2, 4, 8, 16, 32 kerak bo'lardi — 6 ta.</p>",
 btns:[["⚖️ Qiziq!",function(c,done){done()}]],
 tn:"Bolalar 1, 3, 9, 27 bilan 20 kg ni o'zi topsin: 20 + 9 + 1 = 27 + 3."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["27 → 9 → 3 → 1",C.blue,26]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["27 → 9 → 3 → 1",C.blue,26]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Tosh yuk bilan bir pallada — <b>ayiriladi</b>, qarshi pallada — qo'shiladi.</li><li>1, 3, 9 kg → 1–13 kg; 1, 3, 9, 27 → 1–40 kg.</li><li>Soxta tanga: <b>uchga</b> bo'lamiz. 1 tortish — 3, 2 — 9, 3 — 27, 4 — 81 tanga.</li><li>Soni 3 ga bo'linmasa ham: 10 = 3 + 3 + 4.</li><li>Bitta tortish: har xaltadan har xil son → kamomad = xalta raqami.</li><li>Quyish: faqat <b>to'liq</b> to'ldirish/bo'shatish aniq. Kichik idish — o'lchov.</li><li>Qum soat: tugaganda ag'daring; qolgan qum — yangi o'lchov.</li></ul></div>",
 tn:"Uyga: «5 va 3 L idish bilan 1, 2, 4, 7 L ni oling» — har biriga quyishlar zanjiri."}
];
var PROBS=[
{t:"1, 3, 9 kg toshlar ikkala pallaga qo'yilsa, eng ko'pi bilan necha kg yukni tortish mumkin?",o:["13","9","12","27"],k:0,s:"1 + 3 + 9 = 13 kg."},
{t:"1 va 3 kg toshlar (ikkala pallaga). 2 kg yukni qanday tortamiz?",o:["Yuk + 1 | 3","Yuk | 1 + 1","Yuk + 3 | 1","Yuk | 3"],k:0,s:"2 + 1 = 3."},
{t:"1, 3, 9 kg toshlar. 11 kg yukni qanday tortamiz?",o:["Yuk + 1 | 9 + 3","Yuk | 9 + 1","Yuk + 3 | 9 + 1","Yuk + 9 | 3 + 1"],k:0,s:"11 + 1 = 12 = 9 + 3."},
{t:"2 kg va 5 kg toshlar (ikkala pallaga). 3 kg yukni qanday tortamiz?",o:["Yuk + 2 | 5","Yuk | 5 + 2","Yuk + 5 | 2","Yuk | 2 + 2"],k:0,s:"3 + 2 = 5."},
{t:"27 tangadan bittasi yengil. Kamida necha tortishda topiladi?",o:["3","9","4","2"],k:0,s:"27 → 9 → 3 → 1."},
{t:"9 tangadan bittasi yengil. Kamida necha tortish?",o:["2","3","4","1"],k:0,s:"9 → 3 → 1."},
{t:"10 tangadan bittasi yengil. Kamida necha tortishda albatta topiladi?",o:["3","2","4","5"],k:0,s:"2 tortish 9 tagacha yetadi; 10 > 9 → 3."},
{t:"28 tangadan bittasi yengil. Kamida necha tortishda albatta topiladi?",o:["4","3","5","28"],k:0,s:"3 tortish 27 tagacha; 28 > 27 → 4."},
{t:"10 xalta: bittasida tangalar 9 g, boshqalarida 10 g. 1-xaltadan 1, 2-dan 2, …, 10-dan 10 tanga tortildi: 548 g. Qaysi xalta soxta?",o:["2-xalta","8-xalta","5-xalta","4-xalta"],k:0,s:"550 − 548 = 2 → 2-xalta."},
{t:"Xuddi shu usulda tarozi 540 g ko'rsatdi. Qaysi xalta soxta?",o:["10-xalta","4-xalta","1-xalta","5-xalta"],k:0,s:"550 − 540 = 10 → 10-xalta."},
{t:"5 L va 3 L idish, suv cheksiz. 2 L ni qanday olamiz?",o:["5 ni to'ldirib 3 ga quyamiz — 5 da 2 qoladi","3 ni to'ldirib 5 ga quyamiz","5 ni yarmigacha to'ldiramiz","3 ni ikki marta to'ldiramiz"],k:0,s:"5 − 3 = 2."},
{t:"5 L va 3 L idish. 3 ni to'ldirib 5 ga quydik, yana 3 ni to'ldirib, 5 to'lguncha quydik. 3 L idishda necha L qoldi?",o:["1 L","2 L","3 L","0 L"],k:0,s:"5 da 3 L bor, unga 2 L sig'adi: 3 − 2 = 1."},
{t:"8, 5, 3 L idishlar (8 L to'la). 8 → 5 quyildi, keyin 5 → 3. 5 L idishda necha L?",o:["2 L","3 L","5 L","0 L"],k:0,s:"5 − 3 = 2."},
{t:"7 L va 4 L idish. 7 ni to'ldirib 4 ga quydik, 4 ni to'kdik, 7 dagini 4 ga o'tkazdik, 7 ni yana to'ldirib 4 to'lguncha quydik. 7 L idishda necha L?",o:["6 L","3 L","4 L","5 L"],k:0,s:"7 → 4: 3 qoladi; 3 ni 4 ga; 7 ni to'ldiramiz, 4 ga 1 sig'adi: 7 − 1 = 6."},
{t:"7 va 11 daqiqalik qum soatlar birga ag'darildi. 7 tugaganda ag'darildi, 11 tugaganda 7 lik yana ag'darildi. U qachon tugaydi?",o:["15-daqiqada","14-daqiqada","18-daqiqada","22-daqiqada"],k:0,s:"7 lik 7–11 da 4 daqiqa ishladi; ag'darsak yana 4: 11 + 4 = 15."},
{t:"4 va 7 daqiqalik qum soatlar birga ag'darildi, 4 lik tugaganda ag'darildi. 7 lik tugaganda 4 likning tepasida necha daqiqalik qum?",o:["1","3","4","0"],k:0,s:"4 lik 4 dan 7 gacha 3 daqiqa ishladi: 4 − 3 = 1."},
{t:"3 daqiqalik qum soat bilan 9 daqiqa o'lchash uchun uni necha marta ag'darish kerak (birinchi qo'yishdan tashqari)?",o:["2","3","9","1"],k:0,s:"3 + 3 + 3: 3- va 6-daqiqada ag'daramiz."},
{t:"Toshsiz pallali tarozida 16 kg unni teng bo'lib, 4 kg li qop olish uchun kamida necha tortish?",o:["2","4","1","3"],k:0,s:"16 → 8 | 8, keyin 8 → 4 | 4."},
{t:"1, 2, 4, 8 kg toshlar (faqat bitta pallaga). Eng katta yuk?",o:["15","8","16","14"],k:0,s:"1 + 2 + 4 + 8 = 15."},
{t:"1, 3, 9, 27 kg toshlar (ikkala pallaga). Eng katta yuk?",o:["40","27","39","81"],k:0,s:"1 + 3 + 9 + 27 = 40."}
];
function PRACT_STAGE(){k4Bal(["?"],["1","3","9"],0,"tarozi, quyish, qum soat")}
var PREP_DATA={teach:["Toshlar ikkala pallada: qo'shish va ayirish.","Soxta tanga: uchga bo'lish (3, 9, 27, 81).","Bitta tortish hiylasi: har xaltadan har xil son.","Quyish va qum soat jumboqlari."],
 mist:["Tangalarni ikkiga bo'ladi (uchinchi javob — «teng»ni unutadi).","10 tangani «uchga bo'linmaydi» deb tashlab qo'yadi.","Kamomad o'rniga og'irlikning oxirgi raqamini oladi.","«Ko'z bilan yarmi» kabi noaniq quyishni taklif qiladi."],
 need:["Pallali tarozi yoki ilgichli o'yinchoq tarozi.","8, 5, 3 belgili 3 ta butilka va suv.","Bir xil qopqoqlar, plastilin."],
 board:["<span class='w2'>yuk + 1 + 3 = 9 → 5</span>.","<span class='w2'>27 → 9 → 3 → 1</span>.","<span class='w2'>10 = 3 + 3 + 4</span>.","<span class='w2'>550 − 546 = 4 → 4-xalta</span>.","<span class='w2'>(8,0,0) → … → (4,4,0)</span>.","<span class='w2'>11 + 4 = 15</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
