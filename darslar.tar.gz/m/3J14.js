var CODE='3J14',TITLE='3-sinf · Raqamli jumboqlar (yulduzcha o‘rniga raqam)';
// ustun shaklidagi jumboq: rows — satrlar (★ bilan), hl — belgilangan ustun (o'ngdan 0), sol — ochilgan raqamlar {r_c: raqam}
function j14Col(rows,op,o){o=o||{};clear();var g=S.g,cw=36,x1=236,y0=48,rh=36,n=Math.max.apply(null,rows.map(function(r){return r.length}));
 var lab=['birlik','o‘nlik','yuzlik','ming'];for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-26,width:cw-2,height:rh*3+28,rx:6,fill:o.hl===i?'#fff1c9':['#e1f4f2','#fdf0e1','#fde6c8','#eef'][i]},g);T(g,x,y0-14,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,ri){for(var k=0;k<r.length;k++){var ch=r[r.length-1-k],key=ri+'_'+k,show=o.sol&&o.sol[key]!=null?String(o.sol[key]):ch,star=ch==='★';
  T(g,x1-k*cw,y0+ri*rh+(ri===2?6:0)+4,show,{'font-size':24,'font-weight':800,fill:star?(o.sol&&o.sol[key]!=null?C.ok:C.bad):(ri===2?C.blue:'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}});
 T(g,x1-n*cw+2,y0+rh+4,op,{'font-size':24,'font-weight':800,fill:C.blue});E('line',{x1:x1-n*cw+10,y1:y0+rh+14,x2:x1+cw/2,y2:y0+rh+14,stroke:'#33475b','stroke-width':2.5},g);
 (o.carry||[]).forEach(function(c){T(g,x1-c[0]*cw+14,y0-6,c[1],{'font-size':12,'font-weight':800,fill:C.bad})})}
// raqam sinash tugmalari (html ichidagi .digs)
function j14Digits(c,test,ok,show){var box=c.querySelector('.digs');box.innerHTML='';for(var d=0;d<=9;d++)(function(d){var b=document.createElement('button');b.className='dg';b.textContent=d;b.style.cssText='min-width:34px;min-height:34px;margin:3px;font-size:18px;font-weight:800;border-radius:8px;border:2px solid #c9d6e3;background:#fff';b.onclick=function(){var r=test(d);show(d,r);b.style.background=r?'#c8f0d8':'#fbd5d5';if(r&&ok)ok()};box.appendChild(b)})(d)}
var P2=[function(){j14Col(['3★8','★47','785'],'+');j2Msg('Har ★ — <b>o‘z</b> raqami (har xil bo‘lishi mumkin). Har doim <b>birliklardan</b> boshlaymiz')},
 function(){j14Col(['3★8','★47','785'],'+',{hl:0,carry:[[1,'1']]});j2Msg('Birliklar: 8 + 7 = 15 → 5 yoziladi, <b>1</b> o‘nlik keyingi xonaga o‘tadi')},
 function(){j14Col(['3★8','★47','785'],'+',{hl:1,carry:[[1,'1']],sol:{'0_1':3}});j2Msg('O‘nliklar: ★ + 4 + 1 = 8 → ★ = <b>3</b>')},
 function(){j14Col(['3★8','★47','785'],'+',{hl:2,carry:[[1,'1']],sol:{'0_1':3,'1_2':4}});j2Msg('Yuzliklar: 3 + ★ = 7 → ★ = <b>4</b>. Tekshiramiz: 338 + 447 = 785 ✓')}];
var P3=[function(){j14Col(['8★3','25★','584'],'−');j2Msg('Ayirishda ham birliklardan boshlaymiz. Qarz olishni unutmang!')},
 function(){j14Col(['8★3','25★','584'],'−',{hl:0,sol:{'1_0':9}});j2Msg('Birliklar: 3 dan ★ ni ayirib 4 chiqishi uchun qarz kerak: 13 − ★ = 4 → ★ = <b>9</b> (o‘nlikdan 1 qarz)')},
 function(){j14Col(['8★3','25★','584'],'−',{hl:1,sol:{'1_0':9,'0_1':4}});j2Msg('O‘nliklar: (★ − 1) − 5 = 8 bo‘lmaydi → yana qarz: ★ − 1 + 10 − 5 = 8 → ★ = <b>4</b>')},
 function(){j14Col(['8★3','25★','584'],'−',{hl:2,sol:{'1_0':9,'0_1':4}});j2Msg('Yuzliklar: 8 − 1 − 2 = 5 ✓. Tekshiramiz: 843 − 259 = 584 ✓')}];
var P5=[function(){j2Lines([['ccc · 555 = 431d35',C.bad,24],['c va d — raqamlar',null,15]],{mono:1});j2Msg('Juda qiyin ko‘rinadi… Lekin <b>ccc</b> ni boshqacha yozamiz')},
 function(){j2Lines([['ccc = c · 111',C.blue,22],['ccc · 555 = c · 111 · 555',null,17],['111 · 555 = 61 605',C.ok,17]],{mono:1});j2Msg('Uch xil raqamli son = raqam · 111. Demak, 61 605 · c = 431d35')},
 function(){j2Lines([['61 605 · c = 431d35',C.blue,22],['oxiri 5 · c → …35',null,16],['5 · 7 = 35 → c = 7',C.ok,17]],{mono:1});j2Msg('Oxirgi raqamlarga qaraymiz: 5 · c oxiri 5 — c toq. Taxminan 61 605 · 7 ≈ 431 000 → c = <b>7</b>')},
 function(){j2Lines([['61 605 · 7 = 431 235',C.ok,22],['d = 2,   c = 7',C.blue,18],['d + c = 9',C.bad,20]],{mono:1});j2Msg('Tekshiramiz: 777 · 555 = 431 235 ✓. Javob: d + c = <b>9</b>')}];
var P6=[function(){j2Lines([['1, 2, 3, … 25',C.blue,24],['nechta RAQAM yozilgan?',null,16]]);j2Msg('Kitob betlari 1 dan 25 gacha raqamlangan. Jami nechta <b>raqam</b> yozilgan? («25» emas!)')},
 function(){j2Lines([['1 … 9 → 9 ta son · 1 = 9',null,18],['10 … 25 → 16 ta son · 2 = 32',null,18]]);j2Msg('Bir xonali va ikki xonali sonlarni <b>alohida</b> sanaymiz. 10 dan 25 gacha: 25 − 10 + 1 = 16 ta')},
 function(){j2Lines([['9 + 32 = 41',C.ok,30]]);j2Msg('Jami: <b>41</b> ta raqam')}];
var STEPS=[
{h:"Yashirin raqamni sinab topamiz",sum:"1★ + ★3 = 57 (bir xil ★): sinab ko'ramiz — ★ = 4, chunki 14 + 43 = 57.",a:"m01",
 start:function(){j2Lines([['1★ + ★3 = 57',C.bad,30]],{mono:1});j2Msg('Ikkala ★ — <b>bir xil</b> raqam. Pastdagi raqamlarni sinab ko‘ring')},fin:function(){j2Lines([['14 + 43 = 57',C.ok,30]],{mono:1});j2Msg('★ = 4')},
 html:"<p>Raqamli jumboqda yulduzcha (★) o'rniga raqam yashiringan. Bir xil belgi — bir xil raqam. Eng oddiy usul — <b>sinab ko'rish</b>. Raqamlarni bosing:</p><div class='digs'></div>",
 act:function(c,done){j14Digits(c,function(d){return (10+d)+(10*d+3)===57},function(){done()},function(d,r){j2Lines([[ '1'+d+' + '+d+'3 = '+((10+d)+(10*d+3)),r?C.ok:C.bad,30]],{mono:1});j2Msg(r?'To‘g‘ri! ★ = <b>'+d+'</b>':'1'+d+' + '+d+'3 = '+((10+d)+(10*d+3))+' — 57 emas')})},
 after:"<p>★ = <b>4</b>: 14 + 43 = 57. Lekin har safar 10 ta raqamni sinash — sekin. Keyingi qadamlarda <b>ayyorroq</b> usullarni o'rganamiz.</p>",
 q:{t:"★6 + 2★ = 81 (bir xil ★). ★ nechaga teng?",opts:["4","5","6","2"],ok:1,why:"56 + 25 = 81.",hint:"Birliklarga qarang: 6 + ★ oxiri 1 bo'lishi kerak.",full:"6 + ★ oxiri 1 bo'lishi uchun ★ = 5 (6 + 5 = 11). Tekshiramiz: 56 + 25 = 81 ✓. 4 bo'lsa 46 + 24 = 70."},
 tn:"Avval bolalar sinash usulini o'zi qilsin — keyin «birliklardan boshlash» tezroq ekanini o'zlari sezadi."},
{h:"Qo'shish: birliklardan boshlaymiz",sum:"3★8 + ★47 = 785: 8+7=15 (1 o'tadi), ★+4+1=8 → 3, 3+★=7 → 4.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ustun shaklidagi jumboqni xonama-xona, <b>o'ngdan chapga</b> yechamiz — xuddi oddiy qo'shishdagi kabi. Har xonada bitta noma'lum bo'lsa, u darhol topiladi.</p>",
 btns:[phaser(P2,'▶ Keyingi xona')],
 after:"<p>Eng muhimi — <b>o'tuvchi 1</b> ni unutmaslik. Birliklar 15 bo'lgani uchun o'nliklarga 1 qo'shildi: ★ + 4 + 1 = 8.</p>",
 q:{t:"2★6 + 3★7 = 643 (har ★ — o'z raqami). Ikkala ★ ning yig'indisi nechaga teng?",opts:["12","13","3","4"],ok:1,why:"6+7=13 (1 o'tadi); yuzliklarga ham 1 o'tishi kerak (2+3+1=6) → ★+★+1=14 → 13.",hint:"Yuzliklarga qarang: 2 + 3 = 5, lekin 6 chiqqan. Demak o'nliklardan nima o'tgan?",full:"Birliklar: 6 + 7 = 13, 1 o'tadi. Yuzliklar: 2 + 3 = 5, javobda 6 — demak o'nliklardan ham 1 o'tgan, ya'ni o'nliklar yig'indisi 14: ★ + ★ + 1 = 14 → ★ + ★ = 13. Har ★ alohida topilmaydi, lekin yig'indisi aniq."},
 tn:"«Har ★ o'z raqami» va «bir xil ★» shartlarini doskaga yozib qo'ying — olimpiadada ikkalasi ham uchraydi."},
{h:"Ayirish: qarzni unutmang",sum:"8★3 − 25★ = 584: 13−9=4 (qarz), ★−1+10−5=8 → 4 (qarz), 8−1−2=5.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Ayirishdagi jumboqlarda ko'pincha <b>qarz</b> yashiringan. Kuzating.</p>",
 btns:[phaser(P3,'▶ Keyingi xona')],
 after:"<p>Birliklar: 3 dan katta son ayrilyapti — qarz oldik. O'nliklar: qarzdan keyin yana yetmadi — yana qarz. Har qarz keyingi xonada <b>1 ga kamaytiradi</b>.</p>",
 q:{t:"7★1 − 286 = 445. ★ nechaga teng?",opts:["4","3","1","7"],ok:1,why:"Birliklar: 11−6=5 (qarz). O'nliklar: ★−1 < 8 → qarz: ★−1+10−8 = 4 → ★ = 3.",hint:"Birliklarda qarz olindi. Endi o'nliklarda: (★ − 1) dan 8 ni ayirib 4 chiqishi kerak.",full:"1 − 6 bo'lmaydi → 11 − 6 = 5, o'nlikdan 1 qarz. O'nliklar: (★ − 1) − 8 = 4 bo'lmaydi → yana qarz: ★ − 1 + 10 − 8 = 4 → ★ = 3. Yuzliklar: 7 − 1 − 2 = 4 ✓. 731 − 286 = 445 ✓."},
 tn:"Bolalar qarzni ustun tepasida kichik nuqta bilan belgilasin — jumboqlarda bu xatoni keskin kamaytiradi."},
{h:"Ko'paytirishdagi jumboq",sum:"★7 · 3 = 1★1 (bir xil ★): sinab — faqat ★ = 4 (47 · 3 = 141).",a:"m04",
 start:function(){j2Lines([['★7 · 3 = 1★1',C.bad,30]],{mono:1});j2Msg('Ikkala ★ bir xil. Raqamlarni sinang')},fin:function(){j2Lines([['47 · 3 = 141',C.ok,30]],{mono:1});j2Msg('★ = 4')},
 html:"<p>Ko'paytirishda chegarani o'ylaymiz: natija <b>1★1</b> — 100 dan 199 gacha. Demak ★7 ni 3 ga ko'paytirib shu oraliqqa tushish kerak. Sinab ko'ring:</p><div class='digs'></div>",
 act:function(c,done){j14Digits(c,function(d){var p=(10*d+7)*3;return p>=100&&p<=199&&Math.floor(p/10)%10===d},function(){done()},function(d,r){var p=(10*d+7)*3;j2Lines([[d+'7 · 3 = '+p,r?C.ok:C.bad,30],[r?'✓ 1'+d+'1':(p<100||p>199?'1★1 oralig‘idan tashqarida':'o‘rtadagi raqam '+(Math.floor(p/10)%10)+' — ★ bilan teng emas'),r?C.ok:C.bad,14]],{mono:1});j2Msg(r?'Topildi: ★ = <b>'+d+'</b>':'Yana sinab ko‘ring')})},
 after:"<p>Faqat <b>★ = 4</b> mos: 47 · 3 = 141. ★ = 3 bo'lsa 111 (o'rtada 1, 3 emas), ★ = 5 bo'lsa 171 (o'rtada 7). «Bir xil belgi — bir xil raqam» sharti javobni yagona qiladi.</p>",
 q:{t:"★3 · 3 = 1★9 (bir xil ★). ★ = ?",opts:["3","5","9","6"],ok:1,why:"53 · 3 = 159.",hint:"Natija 100 dan 199 gacha. ★3 · 3 shu oraliqda bo'lishi uchun ★ qanday bo'lishi kerak?",full:"★3 · 3 = 30·★ + 9. 100…199 oralig'i uchun ★ = 4, 5 yoki 6: 129, 159, 189. O'rtadagi raqam ★ ga teng bo'lishi kerak — faqat 159 (★ = 5)."},
 tn:"Chegarani baholash (taxminiy hisob) sinash variantlarini keskin kamaytiradi — buni bolalarga alohida ko'rsating."},
{h:"Tuzoq: ccc · 555 = 431d35",sum:"ccc = c · 111; 111 · 555 = 61 605; 61 605 · 7 = 431 235 → c = 7, d = 2.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Olimpiada jumbog'i: <b>ccc · 555 = 431d35</b>, c va d — raqamlar. d + c ni toping. 10 marta ko'paytirib ko'rish — uzoq. Ayyorlik bor!</p>",
 btns:[phaser(P5)],
 after:"<p>Kalit: <b>ccc = c · 111</b> (masalan, 777 = 7 · 111). Shunda masala bitta ko'paytirishga keladi, oxirgi raqamlar va taxminiy hisob esa c ni darhol ko'rsatadi.</p>",
 q:{t:"aaa · 3 = 1b65 (a va b — raqamlar). a + b nechaga teng?",opts:["10","11","8","13"],ok:1,why:"aaa · 3 = a · 333; 333 · 5 = 1665 → a = 5, b = 6.",hint:"aaa = a · 111. Demak aaa · 3 = a · 333. Oxiri 5 bo'lishi uchun a qanday?",full:"aaa · 3 = a · 333. Oxiri 5 — 3 · a oxiri 5 → a = 5. 333 · 5 = 1665 → b = 6. a + b = 11."},
 tn:"«Bir xil raqamli son = raqam · 111» — olimpiadada juda ko'p ishlatiladi. Doskaning chetiga yozib qo'ying."},
{h:"Nechta raqam yozilgan?",sum:"1–25 betlar: 9 ta bir xonali (9 raqam) + 16 ta ikki xonali (32 raqam) = 41.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Boshqa turdagi jumboq: <b>sonlar</b> emas, <b>raqamlar</b> sanaladi. Kuzating.</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: sonlarni <b>xonaliligi bo'yicha</b> guruhlaymiz — bir xonalilar, ikki xonalilar, uch xonalilar — va har guruhni xonalar soniga ko'paytiramiz.</p>",
 q:{t:"Kitob betlari 1 dan 40 gacha raqamlangan. Jami nechta raqam yozilgan?",opts:["40","71","80","62"],ok:1,why:"9 + 31 · 2 = 9 + 62 = 71.",hint:"10 dan 40 gacha nechta son bor? Har biri nechta raqamli?",full:"1–9: 9 ta son, 9 raqam. 10–40: 40 − 10 + 1 = 31 ta son, har biri 2 raqam — 62. Jami 71. «40» — sonlar soni, raqamlar emas; «62» — bir xonalilar unutilgan."},
 tn:"Bolalardan o'z kitobining betlari uchun hisoblashni so'rang — keyin oxirgi betdan tekshirib ko'rishadi."},
{h:"Bilasizmi? SEND + MORE = MONEY",sum:"Mashhur harfli jumboq: SEND + MORE = MONEY (1924, Dyudeni) — 9567 + 1085 = 10652.",a:"m07",
 start:function(){j2Lines([['\u00a0\u00a0\u00a0SEND',null,24],['+\u00a0\u00a0MORE',null,24],['= MONEY',C.blue,24]],{mono:1})},fin:function(){j2Lines([['\u00a0\u00a0\u00a09567',null,24],['+\u00a0\u00a01085',null,24],['= 10652',C.ok,24]],{mono:1})},
 html:"<p>📜 1924-yilda ingliz jumboqchisi <b>Genri Dyudeni</b> mashhur jumboqni chop etgan: <b>SEND + MORE = MONEY</b> (inglizcha «pul yuboring»). Har harf — o'z raqami. Tugmani bosib javobni ko'ring.</p>",
 btns:[["🔓 Javobni ochish",function(c,done){j2Lines([['\u00a0\u00a0\u00a09567',null,24],['+\u00a0\u00a01085',null,24],['= 10652',C.ok,24]],{mono:1});j2Msg('S=9, E=5, N=6, D=7, M=1, O=0, R=8, Y=2');done()}]],
 after:"<p>Yechim kaliti: ikki to'rt xonali son yig'indisi besh xonali bo'lsa, birinchi raqami albatta <b>1</b> (M = 1). Bunday jumboqlar «kriptaritmlar» deyiladi — ular bilan bugun kompyuterlar ham sinab ko'riladi.</p>",
 tn:"Kuchli bolalarga o'z ismi bilan harfli jumboq tuzishni taklif qiling."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([['★ → raqam',C.blue,28]])},fin:function(){j2Lines([['★ → raqam',C.blue,28]])},
 html:"<div class='memo'><ul><li>Bir xil belgi — <b>bir xil</b> raqam; «har ★ o'z raqami» — har xil bo'lishi mumkin.</li><li>Ustun jumboqni <b>birliklardan</b> boshlang, o'tuvchi 1 va qarzni unutmang.</li><li>Ko'paytirishda natija <b>chegarasi</b> va <b>oxirgi raqam</b> variantlarni kamaytiradi.</li><li><b>ccc = c · 111</b>, <b>ab + ba = 11 · (a + b)</b>.</li><li>Raqamlar soni: bir xonalilar · 1 + ikki xonalilar · 2 + uch xonalilar · 3.</li><li>Oxirida doim <b>tekshiring</b>: topilgan raqamlarni qo'yib hisoblang.</li></ul></div>",
 tn:"Keyingi darsni «AB + BA = 99 bo'lsa, A + B = ?» savoli bilan boshlang (9)."}
];
var PROBS=[
{t:"★3 + 4★ = 98 (bir xil ★). ★ = ?",o:["5","4","9","3"],k:0,s:"53 + 45 = 98."},
{t:"2★ + ★2 = 66 (bir xil ★). ★ = ?",o:["4","3","6","2"],k:0,s:"24 + 42 = 66."},
{t:"★★ + ★ = 36 (bir xil ★). ★ = ?",o:["3","6","2","4"],k:0,s:"33 + 3 = 36."},
{t:"5★ − ★5 = 27 (bir xil ★). ★ = ?",o:["2","3","7","5"],k:0,s:"52 − 25 = 27."},
{t:"★3 · 3 = 1★9 (bir xil ★). ★ = ?",o:["5","3","6","9"],k:0,s:"53 · 3 = 159."},
{t:"4★7 + 365 = 832. ★ = ?",o:["6","7","5","4"],k:0,s:"Birliklar 7+5=12 (1 o'tadi), o'nliklar ★+6+1=13 → ★=6. 467 + 365 = 832."},
{t:"★52 − 278 = 374. ★ = ?",o:["6","5","7","4"],k:0,s:"Ikki marta qarz: ★ − 1 − 2 = 3 → ★ = 6. 652 − 278 = 374."},
{t:"Kitob betlari 1 dan 25 gacha raqamlangan. Jami nechta raqam yozilgan?",o:["41","25","50","39"],k:0,s:"9 · 1 + 16 · 2 = 41."},
{t:"Kitob betlari 1 dan 120 gacha raqamlangan. Jami nechta raqam yozilgan?",o:["252","240","360","189"],k:0,s:"9 + 90 · 2 + 21 · 3 = 9 + 180 + 63 = 252."},
{t:"1 dan 50 gacha sonlarni yozganda 5 raqami necha marta yoziladi?",o:["6","5","10","11"],k:0,s:"5, 15, 25, 35, 45 va 50 — 6 marta."},
{t:"Kitob betlarini raqamlash uchun 39 ta raqam ishlatildi. Kitobda nechta bet bor?",o:["24","39","15","20"],k:0,s:"1–9: 9 raqam; qolgan 30 raqam — 15 ta ikki xonali bet (10–24). Jami 24 bet."},
{t:"ccc · 555 = 431d35 (c, d — raqamlar). d + c = ?",o:["9","6","8","11"],k:0,s:"ccc = c · 111; 61 605 · 7 = 431 235 → c = 7, d = 2."},
{t:"AB + BA = 99 (A, B — raqamlar). A + B = ?",o:["9","11","99","18"],k:0,s:"AB + BA = 11 · (A + B) = 99 → A + B = 9."},
{t:"AB + BA = 121 va A − B = 5. AB qaysi son?",o:["83","38","74","92"],k:0,s:"11 · (A + B) = 121 → A + B = 11; A − B = 5 → A = 8, B = 3: 83."},
{t:"Uch xonali son 4 bilan boshlanadi. 4 ni oxiriga ko'chirsak, son 189 ga kamayadi. Son qaysi?",o:["423","432","234","412"],k:0,s:"423 → 234: 423 − 234 = 189."},
{t:"★ + ★ + ★ = 1★ (bir xil ★). ★ = ?",o:["5","3","6","9"],k:0,s:"5 + 5 + 5 = 15."},
{t:"Ikki xonali sonning raqamlari yig'indisi 11. Raqamlari o'rni almashsa, son 27 ga ortadi. Son qaysi?",o:["47","74","38","29"],k:0,s:"Farq 9 · (b − a) = 27 → b − a = 3, a + b = 11 → 47."},
{t:"Raqamlari yig'indisi 20 bo'lgan eng kichik uch xonali son qaysi?",o:["299","389","479","992"],k:0,s:"Oxirgi ikki raqam eng katta bo'lsin: 9 va 9 → birinchisi 2: 299."},
{t:"★7 · 3 = 1★1 (bir xil ★). ★ = ?",o:["4","3","5","7"],k:0,s:"47 · 3 = 141."},
{t:"8★3 − 25★ = 584 (har ★ — o'z raqami). Ikkala ★ yig'indisi?",o:["13","4","9","12"],k:0,s:"843 − 259 = 584: ★ = 4 va ★ = 9, yig'indisi 13."}
];
function PRACT_STAGE(){j2Lines([['★ → raqam',C.blue,26],['birliklardan boshlang',null,15]])}
var PREP_DATA={teach:["Bir xil belgi — bir xil raqam; har ★ o'z raqami.","Ustun jumboqlarni birliklardan yechish, o'tuvchi 1 va qarz.","Ko'paytirishda chegara va oxirgi raqam.","ccc = c · 111 hiylasi; sahifalardagi raqamlar soni."],
 mist:["O'tuvchi 1 ni yoki qarzni unutadi.","«Bir xil ★» shartini e'tiborsiz qoldirib, bir necha javob topadi.","Sonlar soni bilan raqamlar sonini chalkashtiradi.","Tekshirmaydi."],
 need:["Raqam kartochkalari (0–9).","Doska: ustun jadvali."],
 board:["<span class='w2'>1★ + ★3 = 57 → ★ = 4</span>.","<span class='w2'>3★8 + ★47 = 785</span> — o'ngdan chapga.","<span class='w2'>8★3 − 25★ = 584</span> — qarz.","<span class='w2'>★7 · 3 = 1★1</span> — chegara.","<span class='w2'>ccc = c · 111</span>.","<span class='w2'>1–25: 9 + 32 = 41</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
