// --- k2c16_ yordamchilari ---
function k2c16_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c16_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c16_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c16_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C16',TITLE='2-sinf · Ikki xonali sonni bir xonali songa ko‘paytirish';
// k guruh, har birida n soni (o'nlik tayoqcha + birlik nuqta)
function k2c16_gr(n,k,o){o=o||{};clear();var g=S.g,t=Math.floor(n/10),u=n%10,gw=Math.min(t*13+Math.ceil(u/5)*12+26,340/k),x0=180-gw*k/2;
 for(var i=0;i<k;i++){var x=x0+i*gw;E('rect',{x:x+2,y:10,width:gw-4,height:116,rx:9,fill:'#fff7ea',stroke:'#e6d0a8'},g);
  for(var j=0;j<t;j++)rod(g,x+12+j*13,20,90);for(var q=0;q<u;q++)unit(g,x+12+t*13+Math.floor(q/5)*12+4,26+(q%5)*18,o.uc);T(g,x+gw/2,140,String(n),{'font-size':11,'font-weight':800,fill:C.blue})}
 if(o.cap)T(g,180,164,o.cap,{'font-size':13,'font-weight':800,fill:C.ok})}
function k2c16_area2(r,a,b,ta,tb,cap){clear();var g=S.g,tot=a+b,u=Math.min(290/tot,24),h=Math.min(110,r*18),x0=180-u*tot/2,y0=24;
 E('rect',{x:x0,y:y0,width:u*a,height:h,fill:C.b,stroke:C.line,'stroke-width':1.5},g);E('rect',{x:x0+u*a,y:y0,width:u*b,height:h,fill:C.a,stroke:C.line,'stroke-width':1.5},g);
 T(g,x0+u*a/2,y0-6,String(a),{'font-size':12,'font-weight':800,fill:'#2c5d8a'});T(g,x0+u*a+u*b/2,y0-6,String(b),{'font-size':12,'font-weight':800,fill:C.a2});T(g,x0-12,y0+h/2+4,String(r),{'font-size':13,'font-weight':800});
 if(ta)T(g,x0+u*a/2,y0+h/2+5,ta,{'font-size':14,'font-weight':800,fill:'#fff'});if(tb)T(g,x0+u*a+u*b/2,y0+h/2+5,tb,{'font-size':14,'font-weight':800,fill:'#fff'});if(cap)T(g,180,162,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
var P2=[function(){k2c16_area2(3,20,3,'','','23 = 20 + 3');k2c16_big('23 · 3 = ?','23 ni o‘nliklar va birliklarga ajratamiz')},
 function(){k2c16_area2(3,20,3,'60','9','20 · 3 = 60, 3 · 3 = 9');k2c16_big('23 · 3 = 20 · 3 + 3 · 3 = 60 + 9 = <b>69</b>')}];
var P3=[function(){k2c16_gr(26,3,{});k2c16_big('26 · 3 = ?','3 ta guruh, har birida 26')},
 function(){k2c16_gr(26,3,{uc:C.hi});k2c16_big('o‘nliklar: 2 · 3 = 6 o‘nlik = 60 &nbsp; birliklar: 6 · 3 = <b>18</b>','Birliklar 10 tadan oshdi!')},
 function(){k2c16_area2(3,20,6,'60','18','60 + 18 = 78');k2c16_big('26 · 3 = 60 + 18 = <b>78</b>','18 = 1 o‘nlik 8 birlik → jami 7 o‘nlik 8 birlik')}];
var P5=[function(){k2c16_col(0);k2c16_big('Ustun ko‘rinishida: 47 · 2')},function(){k2c16_col(1);k2c16_big('Birliklar: 7 · 2 = 14 → 4 ni yozamiz, 1 ni eslab qolamiz')},function(){k2c16_col(2);k2c16_big('O‘nliklar: 4 · 2 = 8, yana 1 → 9. Javob: <b>94</b>')}];
function k2c16_col(k){clear();var g=S.g,x=200;T(g,x,44,'4 7',{'font-size':28,'font-weight':800,'text-anchor':'end','font-family':'ui-monospace,monospace'});T(g,x-58,62,'×',{'font-size':22,'font-weight':800});T(g,x,78,'2',{'font-size':28,'font-weight':800,'text-anchor':'end','font-family':'ui-monospace,monospace'});
 E('line',{x1:x-60,y1:88,x2:x+4,y2:88,stroke:'#1d2b3a','stroke-width':2},g);if(k>=1){T(g,x,120,k>=2?'9 4':'  4',{'font-size':28,'font-weight':800,'text-anchor':'end',fill:C.ok,'font-family':'ui-monospace,monospace'});T(g,x-34,22,'1',{'font-size':14,'font-weight':800,fill:C.bad})}}
var P7=[function(){k2c16_big('91 = ? · ? (ikki xonali · bir xonali, bir xonali 1 dan katta)');clear();T(S.g,180,90,'91',{'font-size':48,'font-weight':800})},
 function(){clear();['91 : 2 ✗','91 : 3 ✗','91 : 5 ✗','91 : 7 = 13 ✓'].forEach(function(t,i){T(S.g,180,34+i*32,t,{'font-size':18,'font-weight':800,fill:i===3?C.ok:C.bad})});k2c16_big('Bir xonali sonlarni sinab ko‘ramiz')},
 function(){k2c16_gr(13,7,{cap:'13 · 7 = 91'});k2c16_big('Javob: <b>13</b> (13 · 7 = 91)')}];
var STEPS=[
{h:"Guruhlab ko'paytiramiz",sum:"23 · 3: uch guruh, har birida 2 o'nlik 3 birlik → 6 o'nlik 9 birlik = 69.",a:"m01",
 start:function(){S.k=1;k2c16_gr(23,1,{});k2c16_big('23 · 3 = ?','Guruh qo‘shing')},fin:function(){k2c16_gr(23,3,{cap:'6 o‘nlik 9 birlik = 69'});k2c16_big('23 · 3 = <b>69</b>')},
 html:"<p>23 · 3 — bu «23 dan 3 ta». Guruhlarni qo'shib boring va o'nlik hamda birliklarni sanang:</p>",
 btns:[["+ yana bir 23",function(c,d,b){S.k=(S.k||1)+1;k2c16_gr(23,S.k,S.k===3?{cap:'6 o‘nlik 9 birlik = 69'}:{});k2c16_big(S.k===3?'23 · 3 = <b>69</b>':('23 · '+S.k+' = '+23*S.k));if(S.k>=3){b.disabled=true;d()}}]],
 after:"<p>Har guruhda 2 o'nlik 3 birlik. Uch guruhda: <b>2 · 3 = 6 o'nlik</b> va <b>3 · 3 = 9 birlik</b> → 69. O'nlik va birliklarni <b>alohida</b> ko'paytirdik.</p>",
 q:{t:"32 · 3 nechaga teng?",opts:["96","66","35","906"],ok:0,why:"3 o'nlik · 3 = 9 o'nlik, 2 · 3 = 6 birlik: 96.",hint:"O'nliklarni va birliklarni alohida ko'paytiring.",full:"32 · 3: 30 · 3 = 90, 2 · 3 = 6, jami 96. «906» — xonalar alohida yozilgan, «35» — qo'shilgan."},
 tn:"O'nlik tayoqchalari bilan bolalar 3 ta 23 ni stolga qo'ysin va sanasin — bu CPA (narsa → rasm → yozuv) usulining «narsa» bosqichi."},
{h:"Maydon modeli",sum:"23 · 3 = 20 · 3 + 3 · 3 = 60 + 9 = 69.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>Rasm qilib chizamiz: to'rtburchakning bir tomoni 3, ikkinchisi 23 = 20 + 3. Uni ikki bo'lakka ajratamiz.</p>",btns:[phaser(P2)],
 after:"<p>Bu — taqsimot xossasi (2C15): <b>23 · 3 = (20 + 3) · 3 = 20 · 3 + 3 · 3</b>. Maydon modeli — ko'paytirishning eng aniq rasmi, Singapur va Yaponiya darsliklari aynan shunday o'rgatadi.</p>",
 q:{t:"41 · 2 ni qanday hisoblaymiz?",opts:["40 · 2 + 1 · 2","40 + 1 · 2","41 + 2","4 · 2 + 1"],ok:0,why:"41 = 40 + 1, ikkalasini 2 ga ko'paytiramiz: 80 + 2 = 82.",hint:"41 ni o'nlik va birlikka ajrating, ikkalasini ham ko'paytiring.",full:"41 · 2 = 40 · 2 + 1 · 2 = 80 + 2 = 82. Ikkinchi variantda 40 ko'paytirilmagan."},
 tn:"Katakli qog'ozda to'rtburchak chizdiring va ikki rangga bo'ldiring."},
{h:"Birliklar 10 dan oshsa",sum:"26 · 3 = 60 + 18 = 78. 18 birlik = 1 o'nlik 8 birlik.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>26 · 3 — birliklar: 6 · 3 = 18. Bu 9 dan ko'p! Nima qilamiz?</p>",btns:[phaser(P3)],
 after:"<p>18 birlik — bu 1 o'nlik va 8 birlik. Uni o'nliklarga qo'shamiz: 60 + 18 = <b>78</b>. Bo'laklarni qo'shganda o'tishni unutmang.</p>",
 q:{t:"17 · 4 nechaga teng?",opts:["68","48","428","64"],ok:0,why:"10 · 4 = 40, 7 · 4 = 28, 40 + 28 = 68.",hint:"Birliklar: 7 · 4 = 28. Uni o'nliklarga qo'shing.",full:"17 · 4 = 40 + 28 = 68. «428» — 4 va 28 yonma-yon yozilgan, «48» — faqat 40 + 8."},
 tn:"«428» xatosi juda ko'p uchraydi — bo'laklarni yonma-yon emas, ustma-ust qo'shishni ko'rsating."},
{h:"O'zingiz hisoblang",sum:"Har doim: o'nliklarni ko'paytir, birliklarni ko'paytir, qo'sh.",a:"m04",
 start:function(){k2c16_big('Misolni tanlang')},fin:function(){k2c16_area2(4,30,5,'120','20','120 + 20 = 140');k2c16_big('35 · 4 = 120 + 20 = <b>140</b>')},
 html:"<p>Misolni tanlang — maydon modeli va yechim chiqadi:</p>",
 btns:[["14 · 5",function(c,d){k2c16_area2(5,10,4,'50','20','50 + 20 = 70');k2c16_big('14 · 5 = 50 + 20 = <b>70</b>');mvK(d,3)}],["29 · 3",function(c,d){k2c16_area2(3,20,9,'60','27','60 + 27 = 87');k2c16_big('29 · 3 = 60 + 27 = <b>87</b>');mvK(d,3)}],["35 · 4",function(c,d){k2c16_area2(4,30,5,'120','20','120 + 20 = 140');k2c16_big('35 · 4 = 120 + 20 = <b>140</b>');mvK(d,3)}],["48 · 2",function(c,d){k2c16_area2(2,40,8,'80','16','80 + 16 = 96');k2c16_big('48 · 2 = 80 + 16 = <b>96</b>');mvK(d,3)}]],g2:1,
 after:"<p>35 · 4 = 140 — natija uch xonali bo'lishi mumkin. Javobni <b>chamalang</b>: 35 · 4 — taxminan 40 · 4 = 160 dan sal kam. 140 — mos!</p>",
 q:{t:"25 · 4 nechaga teng?",opts:["100","80","120","820"],ok:0,why:"20 · 4 = 80, 5 · 4 = 20, 80 + 20 = 100.",hint:"20 · 4 va 5 · 4 ni qo'shing.",full:"25 · 4 = 80 + 20 = 100. «820» — 80 va 20 yonma-yon yozilgan. 25 · 4 = 100 ni yodlab oling — juda ko'p kerak bo'ladi."},
 tn:"Chamalash: «javob qancha atrofida bo'lishi kerak?» savolini har misolda bering."},
{h:"Ustun ko'rinishida",sum:"47 · 2: 7 · 2 = 14 → 4, 1 yodda; 4 · 2 + 1 = 9 → 94.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Xuddi shu ishni qisqa — <b>ustun</b> ko'rinishida yozish mumkin. Avval birliklar, keyin o'nliklar.</p>",btns:[phaser(P5)],
 after:"<p>Ustunda: birliklardan boshlaymiz. 7 · 2 = 14: <b>4 ni yozamiz, 1 ni «yodda» tutamiz</b>. O'nliklar: 4 · 2 = 8, yodagi 1 bilan 9. Javob: 94. Bu — maydon modelining qisqa yozuvi.</p>",
 q:{t:"Ustunda 36 · 2 ni hisoblaganda o'nliklar xonasiga qaysi raqam yoziladi?",opts:["7","6","2","1"],ok:0,why:"6 · 2 = 12 → 1 yodda; 3 · 2 + 1 = 7. Javob 72.",hint:"Birliklardan o'tgan 1 ni unutmang.",full:"Birliklar: 6 · 2 = 12 → 2 yoziladi, 1 yodda. O'nliklar: 3 · 2 = 6, + 1 = 7. Javob: 72. «6» — yodagi 1 unutilgan."},
 tn:"Ustun usuli 3-sinfda asosiy bo'ladi. Hozir maydon modeli bilan yonma-yon ko'rsating."},
{h:"Tuzoq: masalada qadoq va dona",sum:"4 quti × 24 ta + 7 dona = 96 + 7 = 103.",a:"m06",
 start:function(){k2c16_gr(24,4,{});k2c16_big('4 quti, har birida 24 ta qalam. Yana 7 ta alohida')},fin:function(){k2c16_gr(24,4,{cap:'24 · 4 = 96, + 7 = 103'});k2c16_big('24 · 4 + 7 = 96 + 7 = <b>103</b>')},
 html:"<p>Bank savoli: «Bir qutida 24 ta qalam. Lolada 4 quti qalam va yana 7 ta alohida qalam bor. Lolada jami nechta qalam?»</p>",
 btns:[["▶ Hisobla",function(c,d,b){b.disabled=true;STEPS[5].fin();d()}]],
 after:"<p>Avval qutilardagi: 24 · 4 = 20 · 4 + 4 · 4 = 80 + 16 = <b>96</b>. Keyin alohidalar: 96 + 7 = <b>103</b>. Xato yo'l: 24 + 4 + 7 = 35 yoki 24 · 4 ni unutish.</p>",
 q:{t:"Sardor 1 daqiqada 74 ta so'z o'qiydi, Malika undan 8 ta kam. Ikkalasi 5 daqiqada jami nechta so'z o'qiydi?",opts:["700","370","330","820"],ok:0,why:"Malika 66 ta; birga 1 daqiqada 140, 5 daqiqada 700.",hint:"Avval Malika 1 daqiqada nechta o'qishini toping, keyin ikkalasini qo'shing.",full:"Malika: 74 − 8 = 66. Birga 1 daqiqada: 74 + 66 = 140. 5 daqiqada: 140 · 5 = 700. «370» — faqat Sardor (74 · 5)."},
 tn:"Ko'p bosqichli masalada har qadamni alohida qatorga yozdiring (2D3)."},
{h:"Tuzoq: ko'paytma ma'lum — qaysi son?",sum:"Ikki xonali · bir xonali (1 dan katta) = 91 → 13 · 7.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Bank savoli: «Anvar ikki xonali sonni 1 dan katta bir xonali songa ko'paytirib, <b>91</b> ni hosil qildi. U qaysi ikki xonali sonni ko'paytirgan?»</p>",btns:[phaser(P7,'▶ Sinab ko‘ramiz')],
 after:"<p>Bir xonali sonlarni bittalab sinaymiz: 91 juft emas (2 bo'lmaydi), raqamlari yig'indisi 10 (3 bo'lmaydi), 1 bilan tugaydi (5 bo'lmaydi). 7: 7 · 13 = 91 ✓. Javob: <b>13</b>.</p>",
 q:{t:"Ikki xonali son 4 ga ko'paytirilsa 92 chiqadi. Bu qaysi son?",opts:["23","22","24","88"],ok:0,why:"92 : 4 = 23. Tekshiruv: 23 · 4 = 92.",hint:"Teskari amal — bo'lish: 92 ni 4 ga bo'ling.",full:"92 : 4: 80 : 4 = 20, 12 : 4 = 3 → 23. Tekshiruv: 23 · 4 = 80 + 12 = 92 ✓."},
 tn:"«Sinab ko'rish» — ham matematik usul. Bolalar sinashni tartibli (2, 3, 4 …) qilsin."},
{h:"Bilasizmi? Panjara usuli",sum:"O'rta asrlarda Sharq olimlari ko'paytirishni katakli «panjara» chizib bajarishgan.",a:"m08",
 start:function(){k2c16_lat(false)},fin:function(){k2c16_lat(true)},
 html:"<p>🕌 O'rta asrlarda Sharq olimlarining kitoblarida ko'paytirishning chiroyli usuli bor edi: <b>panjara</b> (katakli jadval) chiziladi, har katakka bir xona ko'paytmasi yoziladi. Tugmani bosing:</p>",
 btns:[["▶ Panjarani to'ldir",function(c,d){k2c16_lat(true);d()}]],
 after:"<p>47 · 2: katakchalarda 4 · 2 = 08 va 7 · 2 = 14. Qiyshiq chiziqlar bo'ylab qo'shamiz: 9 va 4 → <b>94</b>. Bu usul Yevropaga ham Sharqdan borgan.</p>",
 tn:"Kuchli bolalar uchun qiziqarli: panjara usulida 36 · 3 ni hisoblab ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c16_area2(3,20,3,'60','9','23 · 3 = 69');k2c16_big('23 · 3 = 60 + 9 = 69')},fin:function(){k2c16_area2(3,20,3,'60','9','23 · 3 = 69');k2c16_big('23 · 3 = 60 + 9 = 69')},
 html:"<div class='memo'><ul><li>Ikki xonali sonni <b>o'nlik va birlikka</b> ajrating: 23 = 20 + 3.</li><li>Ikkalasini ko'paytiring va qo'shing: 23 · 3 = 60 + 9 = 69.</li><li>Birliklar 10 dan oshsa: 26 · 3 = 60 + 18 = 78.</li><li>Ustunda: avval birliklar, «yodda» tutilganini o'nliklarga qo'shing.</li><li>Javobni chamalang: 35 · 4 ≈ 40 · 4 = 160 → 140 mos.</li><li>Yodlab oling: 25 · 4 = 100.</li></ul></div>",
 tn:"Keyingi darsni «Eng kichik ikki xonali toq sonni eng katta bir xonali juft songa ko'paytiring» bilan boshlang (11 · 8 = 88)."}
];
function k2c16_lat(on){clear();var g=S.g,x0=120,y0=30,s=50;for(var i=0;i<2;i++){E('rect',{x:x0+i*s,y:y0,width:s,height:s,fill:'#fff',stroke:C.line,'stroke-width':1.5},g);E('line',{x1:x0+i*s+s,y1:y0,x2:x0+i*s,y2:y0+s,stroke:'#c9a764','stroke-width':1},g)}
 T(g,x0+25,y0-8,'4',{'font-size':16,'font-weight':800});T(g,x0+75,y0-8,'7',{'font-size':16,'font-weight':800});T(g,x0+2*s+12,y0+30,'2',{'font-size':16,'font-weight':800});
 if(on){T(g,x0+14,y0+20,'0',{'font-size':14,'font-weight':800,fill:C.blue});T(g,x0+36,y0+42,'8',{'font-size':14,'font-weight':800,fill:C.blue});T(g,x0+64,y0+20,'1',{'font-size':14,'font-weight':800,fill:C.blue});T(g,x0+86,y0+42,'4',{'font-size':14,'font-weight':800,fill:C.blue});
  T(g,x0-10,y0+70,'0',{'font-size':16,'font-weight':800,fill:'#9aa8b6'});T(g,x0+40,y0+80,'9',{'font-size':18,'font-weight':800,fill:C.ok});T(g,x0+92,y0+80,'4',{'font-size':18,'font-weight':800,fill:C.ok});T(g,180,150,'8 + 1 = 9 → 94',{'font-size':13,'font-weight':800,fill:C.ok})}
 k2c16_big(on?'47 · 2 = <b>94</b>':'Panjara: 47 · 2')}
var PROBS=[
{t:"21 · 4 nechaga teng?",o:["84","25","804","48"],k:0,s:"80 + 4 = 84."},
{t:"13 · 3 nechaga teng?",o:["39","16","33","309"],k:0,s:"30 + 9 = 39."},
{t:"16 · 5 nechaga teng?",o:["80","55","30","530"],k:0,s:"50 + 30 = 80."},
{t:"24 · 3 nechaga teng?",o:["72","62","612","27"],k:0,s:"60 + 12 = 72."},
{t:"38 · 2 nechaga teng?",o:["76","66","616","40"],k:0,s:"60 + 16 = 76."},
{t:"25 · 4 nechaga teng?",o:["100","80","820","29"],k:0,s:"80 + 20 = 100."},
{t:"45 · 2 nechaga teng?",o:["90","80","810","47"],k:0,s:"80 + 10 = 90."},
{t:"19 · 5 nechaga teng?",o:["95","55","545","100"],k:0,s:"50 + 45 = 95 (yoki 100 − 5)."},
{t:"Qaysi ko'paytma eng katta?",o:["27 · 3","19 · 4","16 · 5","38 · 2"],k:0,s:"81, 76, 80, 76 — eng kattasi 27 · 3 = 81."},
{t:"Bir qutida 24 ta qalam. Lolada 4 quti va yana 7 ta qalam bor. Jami nechta qalam?",o:["103","96","31","175"],k:0,s:"24 · 4 = 96, 96 + 7 = 103."},
{t:"Hisoblang: 37 · 2 + 26 · 3",o:["152","142","162","300"],k:0,s:"74 + 78 = 152."},
{t:"Hisoblang: 3 · 26 − 4 · 19",o:["2","12","22","154"],k:0,s:"78 − 76 = 2."},
{t:"Ikki xonali sonni 1 dan katta bir xonali songa ko'paytirib 91 hosil qilishdi. Qaysi ikki xonali son?",o:["13","17","19","31"],k:0,s:"91 = 7 · 13."},
{t:"Eng kichik ikki xonali toq sonni eng katta bir xonali juft songa ko'paytiring.",o:["88","80","99","90"],k:0,s:"11 · 8 = 88."},
{t:"Sardor 1 daqiqada 74 ta so'z o'qiydi, Malika undan 8 ta kam. Ikkalasi 5 daqiqada jami nechta so'z o'qiydi?",o:["700","370","330","820"],k:0,s:"(74 + 66) · 5 = 140 · 5 = 700."},
{t:"328 dan 28 ni ketma-ket 5 marta ayirilsa, nechchi qoladi?",o:["188","108","198","118"],k:0,s:"28 · 5 = 140, 328 − 140 = 188."},
{t:"Ustunda 46 · 2 ni hisoblaganda o'nliklar xonasiga qaysi raqam yoziladi?",o:["9","8","2","1"],k:0,s:"6 · 2 = 12 → 1 yodda; 4 · 2 + 1 = 9. Javob 92."},
{t:"□ · 3 = 57. □ nechaga teng?",o:["19","18","17","54"],k:0,s:"57 : 3 = 19. Tekshiruv: 19 · 3 = 57."},
{t:"Bir bilet 15 ming so'm. 6 ta bilet uchun 100 ming so'm berildi. Qancha qaytim?",o:["10","90","15","85"],k:0,s:"15 · 6 = 90, 100 − 90 = 10 ming so'm."},
{t:"Qaysi ifoda 34 · 3 ga teng?",o:["30 · 3 + 4 · 3","30 + 4 · 3","3 · 3 + 4 · 3","34 + 3"],k:0,s:"34 · 3 = 90 + 12 = 102."}
];
function PRACT_STAGE(){k2c16_area2(3,20,3,'60','9','23 · 3 = 60 + 9');k2c16_msg('O‘nliklarni va birliklarni ko‘paytiring, keyin qo‘shing')}
var PREP_DATA={teach:["Ikki xonali sonni bir xonaliga: guruhlar (narsa), maydon modeli (rasm), yozuv.","O'nlik va birliklarni alohida ko'paytirish; birliklar 10 dan oshganda o'tish.","Ustun ko'rinishi bilan tanishuv; chamalash.","Tuzoqlar: ko'p bosqichli masala, ko'paytma bo'yicha sonni topish."],
 mist:["Faqat birliklarni ko'paytiradi: 23 · 3 = 29.","Bo'laklarni yonma-yon yozadi: 17 · 4 = 428.","Ustunda «yodda»gi sonni unutadi.","Masalada qo'shimcha donalarni unutadi."],
 need:["O'nlik tayoqchalari va birlik kubiklari.","Katakli qog'oz."],
 board:["Guruhlar: <span class='w2'>23 + 23 + 23 = 69</span>.","Maydon: <span class='w2'>23 · 3 = 60 + 9</span>.","O'tish: <span class='w2'>26 · 3 = 60 + 18 = 78</span>.","Ustun: <span class='w2'>47 · 2 = 94</span> (1 yodda).","<span class='w2'>24 · 4 + 7 = 103</span>."]};
