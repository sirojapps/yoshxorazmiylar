var CODE='2B3',TITLE='2-sinf · O‘nlikdan o‘tib ayirish';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// t o'nlik, u birlik; o.open: bitta o'nlik yechilgan (u+10 birlik), o.cross: nechta birlik o'chirildi, o.crossT: nechta o'nlik o'chirildi
function sub(t,u,o){o=o||{};clear();var g=S.g;T(g,180,20,o.title||'',{'font-size':16,'font-weight':800,fill:'#1d2b3a'});
 var tt=o.open?t-1:t,uu=o.open?u+10:u;
 for(var i=0;i<tt;i++){rod(g,26+i*15,34,96);if(o.crossT&&i>=tt-o.crossT)E('line',{x1:18+i*15,y1:40,x2:34+i*15,y2:124,stroke:C.bad,'stroke-width':3},g)}
 if(o.ghost)E('rect',{x:20+tt*15,y:34,width:12,height:96,rx:5,fill:'none',stroke:C.hi,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 for(var k=0;k<uu;k++){var x=200+(k%5)*24,y=44+Math.floor(k/5)*24,hl=o.open&&k>=u;unit(g,x,y,hl?C.hi:null);if(o.cross&&k>=uu-o.cross)E('line',{x1:x-7,y1:y-7,x2:x+7,y2:y+7,stroke:C.bad,'stroke-width':2.5},g)}
 if(o.note)T(g,180,160,o.note,{'font-size':13,'font-weight':800,fill:o.nc||C.blue})}
function nl(a,b,jumps,start,lab){clear();var x0=20,x1=340,y=120,k=(x1-x0)/(b-a),X=function(v){return x0+(v-a)*k};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=a;v<=b;v++){E('line',{x1:X(v),y1:y-(v%10?4:9),x2:X(v),y2:y+(v%10?4:9),stroke:'#33475b','stroke-width':v%10?1:2.2},S.g);if(v%10===0||(lab&&lab.indexOf(v)>=0))T(S.g,X(v),y+24,String(v),{'font-size':12,'font-weight':800,fill:v===start?C.blue:'#5b6b7b'})}
 E('circle',{cx:X(start),cy:y,r:6,fill:C.blue},S.g);var cols=[C.bad,C.a,C.c],tc=[C.bad,'#b0601f','#c0507a'];
 jumps.forEach(function(j,i){var h=[26,52,32][i%3];E('path',{d:'M'+X(j[0])+' '+(y-4)+' Q'+(X(j[0])+X(j[1]))/2+' '+(y-4-h)+' '+X(j[1])+' '+(y-4),fill:'none',stroke:cols[i%3],'stroke-width':2.4},S.g);T(S.g,(X(j[0])+X(j[1]))/2,y-10-h,j[2],{'font-size':12,'font-weight':800,fill:tc[i%3]})});
 if(jumps.length){var e=jumps[jumps.length-1][1];E('circle',{cx:X(e),cy:y,r:7,fill:C.ok},S.g);T(S.g,X(e),y+40,String(e),{'font-size':15,'font-weight':800,fill:C.ok})}}
var P1=[function(){sub(5,2,{title:'52 − 17',note:'2 ta birlikdan 7 tani olib bo‘lmaydi!',nc:C.bad});msg('Birliklar yetmaydi: 2 − 7 ?')},
 function(){sub(5,2,{title:'52 − 17',open:1,ghost:1,note:'1 o‘nlikni yechamiz → 10 birlik'});msg('5 o‘nlik 2 birlik = <b>4 o‘nlik 12 birlik</b>')},
 function(){sub(5,2,{title:'52 − 17',open:1,ghost:1,cross:7,note:'12 − 7 = 5 birlik'});msg('Birliklar: 12 − 7 = <b>5</b>')},
 function(){sub(5,2,{title:'52 − 17 = 35',open:1,ghost:1,cross:7,crossT:1,note:'4 − 1 = 3 o‘nlik, 5 birlik',nc:C.ok});msg('O‘nliklar: 4 − 1 = 3. Javob: <b>35</b>')}];
var P3=[function(){nl(30,56,[],52,[52,35]);msg('52 − 17. Avval yaxlit o‘nlikkacha tushamiz')},function(){nl(30,56,[[52,50,'−2']],52,[52]);msg('52 − 2 = <b>50</b>. 17 dan 2 ni ayirdik, 15 qoldi')},function(){nl(30,56,[[52,50,'−2'],[50,40,'−10']],52,[52]);msg('50 − 10 = 40')},function(){nl(30,56,[[52,50,'−2'],[50,40,'−10'],[40,35,'−5']],52,[52]);msg('40 − 5 = <b>35</b>')}];
var P4=[function(){cu(0);msg('61 − 28: 28 dan 61 gacha qancha yurish kerak?')},function(){cu(1);msg('28 → 30: <b>+2</b>')},function(){cu(2);msg('30 → 60: <b>+30</b>')},function(){cu(3);msg('60 → 61: <b>+1</b>. Jami 2 + 30 + 1 = <b>33</b>')}];
var P5=[function(){clear();T(S.g,180,50,'73 − 29',{'font-size':28,'font-weight':800});msg('29 — 30 ga juda yaqin')},function(){clear();T(S.g,180,50,'73 − 29',{'font-size':28,'font-weight':800});T(S.g,180,96,'73 − 30 = 43',{'font-size':22,'font-weight':800,fill:C.blue});msg('30 ni ayirdik — 1 ta ortiqcha ayirdik')},function(){clear();T(S.g,180,50,'73 − 29',{'font-size':28,'font-weight':800});T(S.g,180,96,'73 − 30 = 43',{'font-size':22,'font-weight':800,fill:C.blue});T(S.g,180,140,'43 + 1 = 44',{'font-size':22,'font-weight':800,fill:C.ok});msg('Ortiqcha ayirilgan 1 ni qaytaramiz: <b>44</b>')}];
var P8=[function(){b8(0);msg('Lentada 100 sm. Avval 37 sm, keyin 28 sm kesildi')},function(){b8(1);msg('100 − 37 = <b>63</b> (0 dan 7 olib bo‘lmaydi — o‘nlik yechiladi)')},function(){b8(2);msg('63 − 28 = <b>35</b> sm qoldi')}];
var STEPS=[
{h:"Birliklar yetmasa",sum:"52 − 17: 2 dan 7 ni olib bo'lmaydi → 1 o'nlikni 10 birlikka yechamiz: 4 o'nlik 12 birlik. 12 − 7 = 5, 4 − 1 = 3 → 35.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>52 − 17. Birliklardan boshlaymiz: 2 tadan 7 tani olish kerak... Lekin bu mumkin emas! Nima qilamiz? Kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Bitta o'nlik tayoqchani <b>yechib</b>, 10 ta birlikka aylantirdik: 52 = 4 o'nlik <b>12</b> birlik. Endi 12 − 7 = 5, o'nliklar 4 − 1 = 3. Javob: <b>35</b>. Bu «o'nlikdan o'tib ayirish» deyiladi.</p>",
 q:{t:"43 − 18 = ?",opts:["35","25","23","15"],ok:1,why:"13 − 8 = 5; 3 − 1 = 2: 25.",hint:"3 dan 8 ni olib bo'lmaydi. Bitta o'nlikni yeching: 3 o'nlik 13 birlik.",full:"43 = 3 o'nlik 13 birlik. 13 − 8 = 5, 3 − 1 = 2: 25. «35» — o'nliklardan yechilgan 1 ayirilmagan (eng ko'p uchraydigan xato)."},
 tn:"Bolalar cho'p bog'lamini haqiqatan yechsin — rezinkani olib tashlash «o'nlikni maydalash» ni ko'rinarli qiladi."},
{h:"Tuzoq: kichikdan kattani ayirish",sum:"52 − 17 ni «7 − 2 = 5» deb yechish — eng ko'p xato: 45 chiqadi. Birliklarda doim yuqoridagidan pastdagini ayiramiz.",a:"m02",
 start:function(){trap(0)},fin:function(){trap(1)},
 html:"<p>Anvar shunday yechdi: <b>52 − 17 = 45</b>. «2 dan 7 olib bo'lmaydi, shuning uchun 7 − 2 = 5 qildim», — dedi. Kimning javobi to'g'ri — Anvarnikimi yoki tayoqchalar ko'rsatgan <b>35</b> mi?</p>",
 btns:[["Anvar haq — 45",function(c,done){trap(0);msg('Tekshiring: 45 + 17 = 62, 52 emas!');}],["Tayoqchalar haq — 35",function(c,done){trap(1);msg('To‘g‘ri! 35 + 17 = 52 ✓');done()}]],
 after:"<p>Birliklarni <b>almashtirib</b> ayirish mumkin emas: 52 dan 17 ni ayiryapmiz, 17 dan 52 ni emas. Tekshirish usuli — <b>qo'shib ko'rish</b>: ayirma + ayriluvchi = kamayuvchi. 35 + 17 = 52 ✓.</p>",
 q:{t:"Kim to'g'ri hisobladi: 64 − 28?",opts:["Ali: 44","Vali: 46","Soli: 36","Doni: 34"],ok:2,why:"14 − 8 = 6, 5 − 2 = 3: 36. Tekshirish: 36 + 28 = 64.",hint:"Har bir javobga 28 ni qo'shib ko'ring — qaysi biri 64 beradi?",full:"64 = 5 o'nlik 14 birlik. 14 − 8 = 6, 5 − 2 = 3: 36. Ali «8 − 4 = 4» qilgan (44), Vali o'nlikni yechmagan (46)."},
 tn:"«7 − 2» xatosi xalqaro tadqiqotlarda eng ko'p uchraydigan «bug» (Brown & Burton, 1978). Har doim qo'shib tekshirtiring."},
{h:"Son o'qida: o'nlikkacha tushamiz",sum:"52 − 17 = 52 − 2 − 15: avval 50 ga (−2), keyin −10, −5 → 35.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Boshqa usul — son o'qida chapga sakraymiz. Avval <b>yaxlit o'nlikkacha</b> tushamiz.</p>",
 btns:[phaser(P3,'▶ Sakrash')],
 after:"<p>17 ni bo'laklarga ajratdik: 2 + 10 + 5. Avval 52 → 50 (yaxlit son!), keyin 50 → 40 → <b>35</b>. Yaxlit o'nlikdan ayirish ancha oson.</p>",
 q:{t:"81 − 26 ni son o'qida hisoblaymiz. Birinchi sakrash qanday bo'lishi qulay?",opts:["− 6 → 75","− 20 → 61","− 1 → 80","− 10 → 71"],ok:2,why:"81 dan yaxlit 80 gacha 1. Keyin 80 − 25 = 55.",hint:"81 ga eng yaqin yaxlit o'nlik qaysi? Unga yetish uchun nechta ayirish kerak?",full:"81 − 1 = 80, 26 dan 25 qoldi: 80 − 20 = 60, 60 − 5 = 55. Birinchi sakrash − 1."},
 tn:"Bolalar bir misolni ikki xil sakrash yo'li bilan chizib, natijalar bir xil chiqishini ko'rsin."},
{h:"Sanab chiqish: kichikdan kattaga",sum:"61 − 28: 28 dan 61 gacha yuramiz: +2 → 30, +30 → 60, +1 → 61. Jami 33.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Do'kondor usuli: 61 − 28 ni topish uchun <b>28 dan 61 gacha qancha qo'shish</b> kerakligini sanaymiz.</p>",
 btns:[phaser(P4,'▶ Yurish')],
 after:"<p>2 + 30 + 1 = <b>33</b>. Ayirish — bu sonlar orasidagi <b>masofa</b>. Sonlar bir-biriga yaqin bo'lsa (61 − 58), sanab chiqish eng tez usul: 58 → 60 → 61, atigi 3!</p>",
 q:{t:"Do'kondor usulida: 70 − 46 = ?",opts:["34","36","26","24"],ok:3,why:"46 → 50 (+4), 50 → 70 (+20): 24.",hint:"46 dan 50 gacha nechta? 50 dan 70 gacha-chi?",full:"46 + 4 = 50, 50 + 20 = 70. Jami 4 + 20 = 24. «36» — 0 − 6 ni 6 − 0 deb olgan xato."},
 tn:"Bozorda qaytim berish aynan shunday: 46 so'mlik narsaga 70 berilsa, sotuvchi 46 dan 70 gacha sanaydi."},
{h:"Qulay usul: yaxlitlab, keyin tuzatamiz",sum:"73 − 29 = 73 − 30 + 1 = 44. Ortiqcha ayirilganini qaytaramiz.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>73 − 29. 29 o'rniga 30 ni ayirsak oson. Lekin keyin nima qilish kerak — qo'shishmi, ayirishmi?</p>",
 btns:[phaser(P5)],
 after:"<p>30 ni ayirdik — bu kerakidan <b>1 ta ko'p</b>. Demak ko'p olib qo'ydik, 1 ni <b>qaytaramiz</b>: 43 + 1 = <b>44</b>. Diqqat: qo'shishda «− 1», ayirishda «+ 1» bo'ladi!</p>",
 q:{t:"62 − 19 ni qulay usulda hisoblang.",opts:["62 − 20 − 1 = 41","62 − 20 + 1 = 43","62 − 10 = 52","62 − 19 = 57"],ok:1,why:"20 ni ayirdik — 1 ta ortiqcha. Qaytaramiz: 42 + 1 = 43.",hint:"20 ni ayirsangiz, kerakidan ko'p ayirdingizmi yoki kam?",full:"62 − 20 = 42. 19 o'rniga 20 ayirdik, ya'ni 1 ta ortiqcha. 42 + 1 = 43. «− 1» — tuzatish teskari qilingan."},
 tn:"Kompensatsiyani «olma» bilan tushuntiring: 20 ta olma oldingiz, lekin 19 ta kerak edi — 1 tasini qaytarasiz."},
{h:"Masala: 100 dan ayirish",sum:"Lenta 100 sm, 37 va 28 sm kesildi: 100 − 37 = 63, 63 − 28 = 35.",a:"m06",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p><i>«Lentaning uzunligi 1 m (100 sm). Avval undan 37 sm, keyin 28 sm kesib olindi. Lentadan qancha qoldi?»</i></p>",
 btns:[phaser(P8)],
 after:"<p>100 − 37 = <b>63</b>, 63 − 28 = <b>35</b> sm. Boshqa yo'l: avval kesilganlarni qo'shamiz 37 + 28 = 65, keyin 100 − 65 = <b>35</b>. Ikkala yo'l ham bir xil javob beradi!</p>",
 q:{t:"90 − 27 − 38 = ?",opts:["25","35","15","63"],ok:0,why:"90 − 27 = 63, 63 − 38 = 25. Yoki 27 + 38 = 65, 90 − 65 = 25.",hint:"Avval 90 − 27 ni toping yoki 27 va 38 ni qo'shing.",full:"90 − 27 = 63 (10 − 7 = 3, 8 − 2 = 6). 63 − 38 = 25 (13 − 8 = 5, 5 − 3 = 2). «63» — ikkinchi amal unutilgan."},
 tn:"«100 dan ayirish» (100 − 37) — nollar ustida o'nlik yechish. Bolalarga «1 m = 10 ta 10 sm» lentasi bilan ko'rsating."},
{h:"Qaysi ayirma katta?",sum:"52 − 17 = 35, 61 − 28 = 33 → birinchisi 2 ga katta. Avval hisoblab, keyin solishtiramiz.",a:"m07",
 start:function(){cmp(0)},fin:function(){cmp(3)},
 html:"<p>Qaysi ayirma katta: <b>52 − 17</b> yoki <b>61 − 28</b>? 61 katta-ku — demak ikkinchisi kattami? Hisoblab ko'ring:</p>",
 btns:[["52 − 17",function(c,done){cmp(1);mvK(done,2)}],["61 − 28",function(c,done){cmp(2);mvK(done,2)},'u']],
 after:"<p>52 − 17 = <b>35</b>, 61 − 28 = <b>33</b>. Birinchi ayirma <b>2 ga katta</b>! Kamayuvchi katta bo'lsa ham, ayriluvchi ham katta bo'lishi mumkin. «Ko'z bilan» emas, hisoblab solishtiramiz.</p>",
 q:{t:"Qaysi ayirma eng kichik?",opts:["81 − 46 = ?","72 − 38 = ?","90 − 54 = ?","63 − 27 = ?"],ok:1,why:"35, 34, 36, 36 → eng kichigi 72 − 38 = 34.",hint:"Har birini hisoblang: 81 − 46, 72 − 38, 90 − 54, 63 − 27.",full:"81 − 46 = 35; 72 − 38 = 34; 90 − 54 = 36; 63 − 27 = 36. Eng kichigi 34."},
 tn:"Sinfda «ayirmalar poygasi»: har guruh bitta misol oladi, keyin natijalarni kattadan kichikka tizishadi."},
{h:"Bilasizmi?",sum:"Qaytim berish usuli — «sanab chiqish». Avstriyacha (yechish) va Amerikacha (qarz) usullar bor.",a:"m08",
 start:function(){clear();T(S.g,180,70,'🪙 46 → 50 → 70',{'font-size':24,'font-weight':800,fill:C.blue});T(S.g,180,120,'qaytim: 4 + 20 = 24',{'font-size':18,'font-weight':800,fill:C.ok});msg('Sotuvchining hisobi')},fin:function(){STEPS[7].start()},
 html:"<p>🛒 Kalkulyatorlar bo'lmagan davrda sotuvchilar qaytimni <b>sanab chiqish</b> bilan berishgan: xaridor 70 so'm bersa va narsa 46 so'm bo'lsa, «47, 48, 49, 50 — va yana 20» deb tanga sanashgan.</p><p>🌍 Dunyoda o'nlikdan o'tib ayirishning bir necha usuli bor: biz o'rgangan «o'nlikni yechish», Yevropada esa «ikkala songa 10 qo'shish» usuli ham ishlatilgan.</p>",
 tn:"Sinfda «do'kon» o'yini: o'yinchoq pullar bilan qaytim berib ko'rishsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){S.ph=3;P1[3]()},fin:function(){S.ph=3;P1[3]()},
 html:"<div class='memo'><ul><li>Birliklar <b>yetmasa</b> — 1 o'nlikni yechamiz: 52 = 4 o'nlik 12 birlik.</li><li>12 − 7 = 5, 4 − 1 = 3 → 52 − 17 = <b>35</b>.</li><li>Birliklarni <b>almashtirmang</b>: «7 − 2» emas!</li><li>Son o'qida: 52 → 50 → 40 → 35.</li><li>Sanab chiqish: 28 → 30 → 60 → 61, jami 33.</li><li>Qulay usul: 73 − 29 = 73 − 30 <b>+ 1</b>.</li><li>Tekshirish: ayirma + ayriluvchi = kamayuvchi.</li></ul></div>",
 tn:"Keyingi darsda komponentlar nomlari: kamayuvchi, ayriluvchi, ayirma — bugungi tekshirish usuli shunga ko'prik."}
];
function trap(k){clear();var g=S.g;T(g,100,36,'Anvar',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});T(g,260,36,'Tayoqchalar',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});
 T(g,100,80,'52 − 17 = 45',{'font-size':22,'font-weight':800,fill:k?C.bad:'#1d2b3a'});T(g,260,80,'52 − 17 = 35',{'font-size':22,'font-weight':800,fill:k?C.ok:'#1d2b3a'});
 T(g,100,118,'45 + 17 = 62',{'font-size':15,'font-weight':800,fill:C.bad});T(g,260,118,'35 + 17 = 52',{'font-size':15,'font-weight':800,fill:C.ok});
 T(g,100,146,'✗',{'font-size':22,fill:C.bad});T(g,260,146,'✓',{'font-size':22,fill:C.ok})}
function cu(k){clear();var x0=20,x1=340,y=120,a=25,b=64,K=(x1-x0)/(b-a),X=function(v){return x0+(v-a)*K};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=a;v<=b;v++){E('line',{x1:X(v),y1:y-(v%10?4:9),x2:X(v),y2:y+(v%10?4:9),stroke:'#33475b','stroke-width':v%10?1:2.2},S.g);if(v%10===0||v===28||v===61)T(S.g,X(v),y+(v===28||v===61?40:24),String(v),{'font-size':12,'font-weight':800,fill:v===28?C.blue:v===61?C.bad:'#5b6b7b'})}
 E('circle',{cx:X(28),cy:y,r:6,fill:C.blue},S.g);E('circle',{cx:X(61),cy:y,r:6,fill:'none',stroke:C.bad,'stroke-width':2},S.g);
 var J=[[28,30,'+2'],[30,60,'+30'],[60,61,'+1']],cols=[C.ok,C.a,C.c],tc=[C.ok,'#b0601f','#c0507a'],H=[24,54,24];
 for(var i=0;i<k;i++){var j=J[i];E('path',{d:'M'+X(j[0])+' '+(y-4)+' Q'+(X(j[0])+X(j[1]))/2+' '+(y-4-H[i])+' '+X(j[1])+' '+(y-4),fill:'none',stroke:cols[i],'stroke-width':2.4},S.g);T(S.g,(X(j[0])+X(j[1]))/2+(i===2?8:0),y-10-H[i],j[2],{'font-size':12,'font-weight':800,fill:tc[i]})}
 if(k>=3)T(S.g,180,26,'2 + 30 + 1 = 33',{'font-size':18,'font-weight':800,fill:C.ok})}
function b8(k){clear();var g=S.g,f=3.2,x=20;E('rect',{x:x,y:60,width:100*f,height:36,fill:'#fff7ea',stroke:C.line,'stroke-width':1.5},g);T(g,x+50*f,50,'100 sm',{'font-size':13,'font-weight':800,fill:'#5b6b7b'});
 if(k>=1){E('rect',{x:x,y:60,width:37*f,height:36,fill:'#ddd',stroke:C.bad,'stroke-width':2},g);T(g,x+18.5*f,83,'−37',{'font-size':13,'font-weight':800,fill:C.bad});T(g,x+68.5*f,83,k>=2?'':'63',{'font-size':14,'font-weight':800,fill:C.blue})}
 if(k>=2){E('rect',{x:x+37*f,y:60,width:28*f,height:36,fill:'#eee',stroke:C.bad,'stroke-width':2},g);T(g,x+51*f,83,'−28',{'font-size':13,'font-weight':800,fill:C.bad});E('rect',{x:x+65*f,y:60,width:35*f,height:36,fill:C.b,stroke:C.line,'stroke-width':1.5},g);T(g,x+82.5*f,83,'35',{'font-size':15,'font-weight':800,fill:'#fff'});T(g,180,130,'qoldi: 35 sm',{'font-size':17,'font-weight':800,fill:C.ok})}}
function cmp(k){clear();var g=S.g,c=STEPS[6];if(k===0){c._a=0;c._b=0}if(k===1)c._a=1;if(k===2)c._b=1;if(k===3){c._a=1;c._b=1}var A=c._a,B=c._b;T(g,100,60,'52 − 17',{'font-size':24,'font-weight':800});T(g,260,60,'61 − 28',{'font-size':24,'font-weight':800});
 if(A)T(g,100,104,'= 35',{'font-size':24,'font-weight':800,fill:C.ok});if(B)T(g,260,104,'= 33',{'font-size':24,'font-weight':800,fill:C.ok});
 if(A&&B)T(g,180,150,'35 > 33 — birinchisi 2 ga katta',{'font-size':15,'font-weight':800,fill:C.blue});if(!A&&!B)T(g,180,104,'?',{'font-size':28,'font-weight':800,fill:C.bad});msg(A&&B?'52 − 17 = 35 > 61 − 28 = 33':'Ikkala ayirmani hisoblang')}
var PROBS=[
{t:"52 − 17 = ?",o:["35","45","25","39"],k:0,s:"12 − 7 = 5, 4 − 1 = 3: 35."},
{t:"91 − 46 = ?",o:["45","55","35","47"],k:0,s:"11 − 6 = 5, 8 − 4 = 4: 45."},
{t:"100 − 37 − 28 = ?",o:["35","45","25","63"],k:0,s:"100 − 37 = 63, 63 − 28 = 35."},
{t:"Qaysi ayirma eng kichik?",o:["72 − 38","81 − 46","90 − 54","63 − 27"],k:0,s:"34, 35, 36, 36."},
{t:"52 − 17 va 61 − 28 ayirmalarini solishtiring.",o:["Birinchisi 2 ga katta","Ikkinchisi 2 ga katta","Teng","Birinchisi 9 ga kichik"],k:0,s:"35 va 33."},
{t:"90 − 27 − 38 = ?",o:["25","35","15","63"],k:0,s:"90 − 27 = 63, 63 − 38 = 25."},
{t:"43 − 18 = ?",o:["25","35","15","24"],k:0,s:"13 − 8 = 5, 3 − 1 = 2."},
{t:"Kim to'g'ri hisobladi: 64 − 28?",o:["36","44","46","34"],k:0,s:"14 − 8 = 6, 5 − 2 = 3: 36."},
{t:"73 − 29 ni qulay usulda hisoblang.",o:["73 − 30 + 1 = 44","73 − 30 − 1 = 42","73 − 20 = 53","73 − 29 = 56"],k:0,s:"30 ni ayirib, ortiqcha 1 ni qaytaramiz."},
{t:"70 − 46 = ?",o:["24","36","34","26"],k:0,s:"46 → 50 → 70: 4 + 20 = 24."},
{t:"Avtobusda 54 kishi bor edi. Bekatda 27 kishi tushdi. Avtobusda necha kishi qoldi?",o:["27","37","33","81"],k:0,s:"54 − 27 = 27."},
{t:"Sinfda 32 ta o'quvchi bor, ulardan 15 tasi qiz. O'g'il bolalar qizlardan nechta ko'p?",o:["2","17","15","13"],k:0,s:"O'g'il bolalar 32 − 15 = 17. 17 − 15 = 2."},
{t:"Qaysi misolda o'nlikdan o'tib ayiriladi?",o:["63 − 28","68 − 23","75 − 41","49 − 16"],k:0,s:"3 dan 8 ni olib bo'lmaydi."},
{t:"□ − 26 = 37. □ = ?",o:["63","11","53","73"],k:0,s:"37 + 26 = 63."},
{t:"81 − □ = 45. □ = ?",o:["36","46","126","44"],k:0,s:"81 − 45 = 36."},
{t:"Lolada 60 so'm bor edi. U 34 so'mga daftar va 18 so'mga qalam oldi. Qancha qoldi?",o:["8","26","18","12"],k:0,s:"34 + 18 = 52, 60 − 52 = 8."},
{t:"Son o'qida 72 dan chapga 35 birlik yurildi. Qaysi songa kelindi?",o:["37","47","43","107"],k:0,s:"72 − 35 = 37."},
{t:"Eng katta ikki xonali sondan 47 ni ayiring.",o:["52","53","42","62"],k:0,s:"99 − 47 = 52."},
{t:"Qaysi tenglik noto'g'ri?",o:["82 − 37 = 55","82 − 45 = 37","45 + 37 = 82","37 + 45 = 82"],k:0,s:"82 − 37 = 45, 55 emas."},
{t:"Ikki son yig'indisi 80. Biri 46. Ular orasidagi farq nechaga teng?",o:["12","34","46","26"],k:0,s:"Ikkinchisi 80 − 46 = 34. 46 − 34 = 12."}
];
function PRACT_STAGE(){S.ph=3;P1[3]()}
var PREP_DATA={teach:["O'nlikdan o'tib ayirish: birliklar yetmasa 1 o'nlikni 10 birlikka yechish (52 = 4 o'nlik 12 birlik).","Son o'qida yaxlit o'nlikkacha tushish; sanab chiqish (do'kondor usuli).","Qulay usul: 73 − 29 = 73 − 30 + 1.","Qo'shish orqali tekshirish; ayirmalarni solishtirish."],
 mist:["Birliklarni almashtirib ayiradi: 52 − 17 = 45 (7 − 2).","O'nlikni yechadi, lekin o'nliklardan 1 ni ayirmaydi: 43 − 18 = 35.","Qulay usulda tuzatishni teskari qiladi (− 1 o'rniga + 1 kerak).","«Kamayuvchi katta — ayirma ham katta» deb o'ylaydi."],
 need:["Cho'p bog'lamlari (rezinka bilan) va donalar.","Doskada bo'sh son o'qi.","O'yinchoq pullar (qaytim o'yini)."],
 board:["<span class='w2'>52 − 17</span>: 52 = 4 o'nlik 12 birlik.","12 − 7 = 5, 4 − 1 = 3 → <span class='w2'>35</span>.","Son o'qi: 52 → 50 → 40 → 35.","Sanab chiqish: 28 → 30 → 60 → 61 = 33.","Tekshirish: 35 + 17 = 52 ✓."]};
