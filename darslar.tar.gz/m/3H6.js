var CODE='3H6',TITLE='3-sinf · Fazoviy shakllar: kub, shar, silindr, konus';
function h6Flat(m){clear('#ffffff');var g=S.g;
 if(m===1){g3Rect(40,50,60,60,{fill:'rgba(90,169,230,.3)',stroke:C.blue});E('circle',{cx:180,cy:80,r:32,fill:'rgba(90,169,230,.3)',stroke:C.blue,'stroke-width':2.2},g);g3Poly([[255,112],[325,112],[290,48]]);g3Msg('<b>Tekis</b> shakllar: qog‘ozda yotadi — bo‘yi va eni bor')}
 else if(m===2){g3Solid('cube',70,82,56);g3Solid('sphere',180,82,66);g3Solid('cyl',290,82,56);g3Msg('<b>Fazoviy</b> jismlar: bo‘yi, eni va <b>balandligi</b> bor — qo‘lga olsa bo‘ladi')}
 else g3Msg('Ikki guruhni solishtiring')}
// katta kub: m — 1 uchlar, 2 qirralar, 3 yoqlar
function h6Cube(m){clear('#ffffff');var g=S.g,s=84,dx=40,dy=-28,F=[[110,140],[110+s,140],[110+s,140-s],[110,140-s]],B=F.map(function(p){return [p[0]+dx,p[1]+dy]});
 if(m===3){g3Poly(F,{fill:'rgba(240,160,64,.55)',stroke:C.line});g3Poly([F[3],F[2],B[2],B[3]],{fill:'rgba(240,160,64,.35)',stroke:C.line});g3Poly([F[1],B[1],B[2],F[2]],{fill:'rgba(240,160,64,.45)',stroke:C.line})}
 var ec=m===2?C.bad:'#33475b',ew=m===2?3.5:2.2;
 [[F[0],F[1]],[F[1],F[2]],[F[2],F[3]],[F[3],F[0]],[B[1],B[2]],[B[2],B[3]],[F[1],B[1]],[F[2],B[2]],[F[3],B[3]]].forEach(function(e){g3Line(e[0],e[1],{w:ew,c:ec})});
 [[B[0],B[1]],[B[0],B[3]],[F[0],B[0]]].forEach(function(e){g3Line(e[0],e[1],{w:ew-0.6,c:ec,d:'5 4'})});
 if(m===1)F.concat(B).forEach(function(p){g3Dot(p,C.bad,5.5)});
 T(g,300,60,['','8 ta uch','12 ta qirra','6 ta yoq'][m]||'',{'font-size':17,'font-weight':800,fill:C.bad});
 g3Msg(['Kub — hamma yoqlari teng kvadrat','<b>Uchlar</b> — qirralar uchrashadigan nuqtalar: 8 ta','<b>Qirralar</b> — yoqlar tutashgan kesmalar: 12 ta (4 old, 4 orqa, 4 bog‘lovchi)','<b>Yoqlar</b> — kvadratlar: 6 ta (3 tasi ko‘rinmaydi)'][m])}
var H6N=[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]];
function h6Net(cells,o){o=o||{};var s=o.s||30,x0=o.x||120,y0=o.y||20,g=S.g;cells.forEach(function(c,i){E('rect',{x:x0+c[0]*s,y:y0+c[1]*s,width:s,height:s,fill:o.fill||['#f2b766','#cfe6f8','#f6c98a','#d4edc9','#fbe0b4','#e3f0fb'][i],stroke:o.st||C.line,'stroke-width':2},g);if(o.num)T(g,x0+c[0]*s+s/2,y0+c[1]*s+s/2+5,String(i+1),{'font-size':13,'font-weight':800})})}
var P3=[function(){clear('#ffffff');g3Solid('cube',180,86,70);g3Msg('Karton kub. Uni qirralari bo‘ylab qirqib, tekislikka yoyamiz')},
 function(){clear('#ffffff');g3Cube(150,130,70,{});var g=S.g;g3Line([150,60],[220,60],{w:4,c:C.bad,d:'6 4'});g3Line([220,60],[251.5,39],{w:4,c:C.bad,d:'6 4'});g3Line([220,130],[220,60],{w:4,c:C.bad,d:'6 4'});g3Msg('Ba‘zi qirralar bo‘ylab qirqamiz (qizil)')},
 function(){clear('#ffffff');h6Net(H6N,{x:120,y:40});g3Msg('Yoyib tekislikka qo‘ydik')},
 function(){clear('#ffffff');h6Net(H6N,{x:120,y:40,num:1});g3Msg('<b>Kub yoyilmasi</b>: 6 ta teng kvadrat')}];
function h6Two(m){clear('#ffffff');var g=S.g;h6Net(H6N,{x:20,y:30,s:26,fill:m===1?'#d4edc9':'#e3f0fb'});T(g,85,158,'A',{'font-size':14,'font-weight':800});
 h6Net([[0,0],[1,0],[2,0],[0,1],[1,1],[2,1]],{x:220,y:50,s:30,fill:m===2?'#f9d3cd':'#e3f0fb'});T(g,265,158,'B',{'font-size':14,'font-weight':800});
 g3Msg(m===1?'A — to‘g‘ri! Buklasak, 6 yoq ustma-ust tushmay kub yopiladi':m===2?'B buklansa, ikki yoq ustma-ust tushadi, bir tomon ochiq qoladi ✗':'Qaysi biri kub yoyilmasi?')}
function h6Box(k){clear('#ffffff');var g=S.g;g3Box(90,140,140,70,60,{la:'4 sm',lb:'3 sm',lc:'2 sm',front:k===1?'#f2b766':'#e3f0fb',top:k===2?'#f2b766':'#cfe6f8',side:k===3?'#f2b766':'#9cc8ec'});
 g3Msg(['Quti: 4 × 3 × 2 sm. 6 yog‘i yuzlari yig‘indisi?','Old va orqa: 4 · 2 = 8, ikkitasi: <b>16</b>','Ust va ost: 4 · 3 = 12, ikkitasi: <b>24</b>','Yon yoqlar: 3 · 2 = 6, ikkitasi: <b>12</b>. Jami 16 + 24 + 12 = <b>52 sm²</b>'][k])}
var P5=[function(){h6Box(0)},function(){h6Box(1)},function(){h6Box(2)},function(){h6Box(3)}];
function h6Kind(k){clear('#ffffff');var g=S.g;
 if(k==='sphere'){g3Solid('sphere',120,85,100);g3Msg('<b>Shar</b>: yuzasi butunlay egri, tekis yog‘i yo‘q — har tomonga yumalaydi')}
 if(k==='cyl'){g3Solid('cyl',120,85,90);g3Msg('<b>Silindr</b>: 2 ta asosi — teng <b>doiralar</b>; yonboshlab yumalaydi, asosida tik turadi')}
 if(k==='cone'){g3Solid('cone',120,85,100);g3Msg('<b>Konus</b>: 1 ta asosi — doira, tepasida <b>uchi</b> bor')}
 if(k)T(g,270,90,{sphere:'SHAR',cyl:'SILINDR',cone:'KONUS'}[k],{'font-size':18,'font-weight':800,fill:C.t1})}
function h6Obj(n){clear('#ffffff');var g=S.g,a=[['⚽','Futbol to‘pi','sphere','shar'],['🥫','Konserva bankasi','cyl','silindr'],['🍦','Muzqaymoq vaflisi','cone','konus'],['🎲','O‘yin kubigi','cube','kub']][n];
 T(g,90,105,a[0],{'font-size':60});T(g,180,95,'→',{'font-size':28,'font-weight':800,fill:'#9aa8b6'});g3Solid(a[2],270,85,80);
 g3Msg(a[1]+' — <b>'+a[3]+'</b>')}
function h6Nets(m){clear('#ffffff');var g=S.g;
 if(m===1){g3Rect(110,50,140,70,{fill:'rgba(240,160,64,.35)'});E('circle',{cx:145,cy:28,r:22,fill:'rgba(90,169,230,.35)',stroke:C.blue,'stroke-width':2},g);E('circle',{cx:145,cy:142,r:22,fill:'rgba(90,169,230,.35)',stroke:C.blue,'stroke-width':2},g);g3Solid('cyl',310,85,50);g3Msg('<b>Silindr</b> yoyilmasi: to‘g‘ri to‘rtburchak + 2 ta doira')}
 else if(m===2){E('path',{d:'M180 20 L110 110 A110 110 0 0 0 250 110 Z',fill:'rgba(240,160,64,.35)',stroke:C.line,'stroke-width':2},g);E('circle',{cx:180,cy:148,r:22,fill:'rgba(90,169,230,.35)',stroke:C.blue,'stroke-width':2},g);g3Solid('cone',310,85,60);g3Msg('<b>Konus</b> yoyilmasi: doira bo‘lagi (yelpig‘ich) + 1 ta doira')}
 else g3Msg('Silindr va konusni ham yoyamiz')}
function h6Euler(k){clear('#ffffff');var g=S.g;
 if(k===1){g3Solid('cube',100,86,70);T(g,250,60,'8 + 6 − 12 = 2',{'font-size':17,'font-weight':800,fill:C.bad});T(g,250,84,'uch + yoq − qirra',{'font-size':11,'fill':'#5b6b7b'});g3Msg('Kub: 8 uch, 6 yoq, 12 qirra')}
 else if(k===2){var A=[100,30],b1=[50,135],b2=[120,150],b3=[160,120],b4=[90,108];g3Poly([b1,b2,A],{fill:'#f2b766',stroke:C.line});g3Poly([b2,b3,A],{fill:'#d9954a',stroke:C.line});g3Line(b1,b4,{d:'4 3'});g3Line(b4,b3,{d:'4 3'});g3Line(b4,A,{d:'4 3'});
  T(g,250,60,'5 + 5 − 8 = 2',{'font-size':17,'font-weight':800,fill:C.bad});T(g,250,84,'uch + yoq − qirra',{'font-size':11,fill:'#5b6b7b'});g3Msg('Piramida (asosi kvadrat): 5 uch, 5 yoq, 8 qirra')}
 else g3Msg('Uchlar, yoqlar va qirralarni sanab, sirli qoidani toping')}
var STEPS=[
{h:"Tekis va fazoviy shakllar",sum:"Tekis shakl qog'ozda yotadi (kvadrat, doira); fazoviy jism joy egallaydi (kub, shar, silindr).",a:"m01",
 start:function(){h6Flat(0)},fin:function(){h6Flat(2)},
 html:"<p>Kvadrat va kubning farqi nimada? Ikki guruhni ko'ring:</p>",
 btns:[["▢ Tekis",function(c,done){h6Flat(1);mvK(done,2)}],["🧊 Fazoviy",function(c,done){h6Flat(2);mvK(done,2)}]],g2:1,
 after:"<p>Tekis shakllarning faqat bo'yi va eni bor. Fazoviy jismlarning <b>balandligi</b> ham bor — ular hajmga ega. Kubning har bir yog'i — kvadrat, silindr asosi — doira.</p>",
 q:{t:"Qaysi biri fazoviy jism?",opts:["Kvadrat","Doira","Kub","Uchburchak"],ok:2,why:"Kubning balandligi bor.",hint:"Qaysi birini qo'lga olib, aylantirib ko'rish mumkin?",full:"Kub — fazoviy jism. Kvadrat, doira, uchburchak — tekis shakllar (kubning yog'i kvadrat, lekin kub emas)."},
 tn:"Sinfga haqiqiy narsalar olib keling: kubik, to'p, banka, vafli stakancha."},
{h:"Kub: yoq, qirra, uch",sum:"Kubning 6 yog'i, 12 qirrasi, 8 uchi bor.",a:"m02",
 start:function(){h6Cube(0)},fin:function(){h6Cube(3)},
 html:"<p>Kubning qismlarini sanaymiz. Har birini bosing:</p>",
 btns:[["• Uchlar",function(c,done){h6Cube(1);mvK(done,3)}],["— Qirralar",function(c,done){h6Cube(2);mvK(done,3)}],["▣ Yoqlar",function(c,done){h6Cube(3);mvK(done,3)}]],g3:1,
 after:"<p><b>6 yoq</b> (kvadratlar), <b>12 qirra</b>, <b>8 uch</b>. Shtrix chiziqlar — ko'rinmaydigan qirralar. Qirralar uchlardan 12 − 8 = <b>4 ta</b> ko'p.</p>",
 q:{t:"Kubning qirralari uchlaridan nechta ko'p?",opts:["8","4","6","2"],ok:1,why:"12 − 8 = 4.",hint:"Qirralar va uchlar sonini eslang.",full:"Qirralar 12, uchlar 8: 12 − 8 = 4. «6» — yoqlar soni bilan adashgan."},
 tn:"Plastilin sharchalar (uchlar) va cho'plar (qirralar) bilan kub yasating: 8 sharcha, 12 cho'p kerak bo'ladi."},
{h:"Kub yoyilmasi",sum:"Kubni qirralari bo'ylab qirqib yoysak — 6 kvadratdan iborat yoyilma.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Karton qutini qirralari bo'ylab qirqsak, u tekis bo'lib yoyiladi. Bu — <b>yoyilma</b>:</p>",
 btns:[phaser(P3,'✂️ Yoyish')],
 after:"<p>Kub yoyilmasi — <b>6 ta teng kvadrat</b>. Uni buklab, qirralarini yopishtirsak, yana kub bo'ladi. Kub yoyilmasining <b>11 xil</b> ko'rinishi bor!</p>",
 q:{t:"Kub qirrasi 2 sm. Yoyilmasi yuzi (6 yog'i yuzlari yig'indisi)?",opts:["8 sm²","24 sm²","16 sm²","12 sm²"],ok:1,why:"Bir yoq 4 sm², 6 · 4 = 24.",hint:"Bitta kvadrat yuzini topib, nechaga ko'paytirish kerak?",full:"Bir yoq 2 · 2 = 4 sm², 6 ta yoq: 24 sm². «8» — hajm (2 · 2 · 2), «16» — 4 ta yoq."},
 tn:"Bolalar qog'ozga kub yoyilmasini chizib, qirqib, buklasin (yopishtirish uchun «quloqcha» qoldiring)."},
{h:"Tuzoq: har qanday 6 kvadrat yoyilmami?",sum:"6 kvadrat har doim kub yoyilmasi bo'lmaydi: 2 × 3 to'rtburchak buklanmaydi.",a:"m04",
 start:function(){h6Two(0)},fin:function(){h6Two(1)},
 html:"<p>Ikkala shakl ham 6 ta kvadratdan iborat. Qaysi biridan kub yasash mumkin?</p>",
 btns:[["A",function(c,done){h6Two(1);done()},'u'],["B",function(){h6Two(2)}]],g2:1,
 after:"<p>Yoyilma bo'lishi uchun buklanganda hech bir yoq <b>ustma-ust tushmasligi</b> kerak. Belgi: yoyilmada 2 × 2 kvadrat bloki bo'lmaydi, qatorda 4 tadan ko'p kvadrat bo'lmaydi.</p>",
 q:{t:"Kub yoyilmasida nechta kvadrat bor?",opts:["4","6","8","12"],ok:1,why:"Kubning 6 yog'i bor.",hint:"Kubning nechta yog'i bor?",full:"Har bir yoq — bitta kvadrat: 6 ta. «12» — qirralar, «8» — uchlar soni."},
 tn:"B shaklini qirqib, buklab ko'rsating — bolalar o'z ko'zi bilan ishonsin."},
{h:"Parallelepiped (quti)",sum:"Quti ham 6 yoq, 12 qirra, 8 uchga ega; qarama-qarshi yoqlari teng. 4×3×2: yoqlar yig'indisi 52 sm².",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Gugurt qutisi, g'isht — <b>to'g'ri burchakli parallelepiped</b>. Kub kabi 6 yoq, 12 qirra, 8 uch, lekin yoqlari to'g'ri to'rtburchaklar. Yoqlar yuzlarini hisoblang:</p>",
 btns:[phaser(P5)],
 after:"<p>Qarama-qarshi yoqlar <b>teng</b>, shuning uchun har juftni 2 marta olamiz: (8 + 12 + 6) · 2 = <b>52 sm²</b>.</p>",
 q:{t:"Quti 5 × 3 × 2 sm. Barcha qirralari uzunliklari yig'indisi?",opts:["10 sm","40 sm","30 sm","20 sm"],ok:1,why:"Har o'lchamdan 4 ta qirra: (5 + 3 + 2) · 4 = 40.",hint:"Qutida bo'yiga teng nechta qirra bor?",full:"12 qirra: 4 tasi 5 sm, 4 tasi 3 sm, 4 tasi 2 sm. (5 + 3 + 2) · 4 = 40 sm. «10» — har biridan bittadan olingan."},
 tn:"Haqiqiy qutini ko'rsatib, bir xil qirralarni bir rangdagi lenta bilan belgilang."},
{h:"Shar, silindr, konus",sum:"Shar — butunlay egri; silindr — 2 doira asos; konus — 1 doira asos va uch.",a:"m06",
 start:function(){h6Kind('sphere')},fin:function(){h6Kind('cone')},
 html:"<p>Dumaloq jismlar ham bor. Har birini ko'ring:</p>",
 btns:[["⚪ Shar",function(c,done){h6Kind('sphere');mvK(done,3)}],["🥫 Silindr",function(c,done){h6Kind('cyl');mvK(done,3)}],["🔺 Konus",function(c,done){h6Kind('cone');mvK(done,3)}]],g3:1,
 after:"<div class='life'><div>⚪<span><b>shar</b>: asos yo'q, har tomonga yumalaydi</span></div><div>🥫<span><b>silindr</b>: 2 doira, tik turadi va yumalaydi</span></div><div>🔺<span><b>konus</b>: 1 doira + uch</span></div></div>",
 q:{t:"Qaysi jismning ikkita teng doira asosi bor?",opts:["Shar","Konus","Silindr","Kub"],ok:2,why:"Silindr — ikki doira asos.",hint:"Konserva bankasining usti va ostini eslang.",full:"Silindrning ikki asosi — teng doiralar. Konusda bitta, sharda umuman yo'q, kubda kvadratlar."},
 tn:"Jismlarni stol ustida yumalatib ko'ring: qaysi biri yumalaydi, qaysi biri turadi?"},
{h:"Atrofimizdagi jismlar",sum:"To'p — shar, banka — silindr, vafli stakancha — konus, kubik — kub.",a:"m07",
 start:function(){h6Obj(0)},fin:function(){h6Obj(3)},
 html:"<p>Kundalik narsalar qaysi jismga o'xshaydi?</p>",
 btns:[["⚽",function(c,done){h6Obj(0);mvK(done,4)}],["🥫",function(c,done){h6Obj(1);mvK(done,4)}],["🍦",function(c,done){h6Obj(2);mvK(done,4)}],["🎲",function(c,done){h6Obj(3);mvK(done,4)}]],g2:1,
 after:"<p>Tarvuz, olma — shar; quvur, qalam — silindr; qo'ng'iroq qalpoq, svetofor konuslari — konus; g'isht, gugurt qutisi — parallelepiped.</p>",
 q:{t:"Qaysi narsa konusga o'xshaydi?",opts:["Tarvuz","Quvur","Bayram qalpog'i","G'isht"],ok:2,why:"Bayram qalpog'i — konus.",hint:"Qaysi narsaning bitta dumaloq asosi va uchi bor?",full:"Bayram qalpog'i — konus (doira asos + uch). Tarvuz — shar, quvur — silindr, g'isht — parallelepiped."},
 tn:"«Jism ovi»: bolalar 2 daqiqada sinfdan har jismga bittadan misol topsin."},
{h:"Silindr va konus yoyilmasi",sum:"Silindr: to'g'ri to'rtburchak + 2 doira. Konus: yelpig'ichsimon doira bo'lagi + 1 doira.",a:"m08",
 start:function(){h6Nets(0)},fin:function(){h6Nets(2)},
 html:"<p>Silindr va konusni ham qog'ozdan yasash mumkin. Ularning yoyilmalari qanday?</p>",
 btns:[["🥫 Silindr",function(c,done){h6Nets(1);mvK(done,2)}],["🔺 Konus",function(c,done){h6Nets(2);mvK(done,2)}]],g2:1,
 after:"<p>Silindrning yon sirti yoyilsa — <b>to'g'ri to'rtburchak</b> (banka yorlig'ini ko'chirib oling!). Konusning yon sirti — <b>doira bo'lagi</b>.</p>",
 q:{t:"Yoyilma: yelpig'ichsimon bo'lak va bitta doira. Bu qaysi jism yoyilmasi?",opts:["Silindr","Konus","Shar","Piramida"],ok:1,why:"Konus: doira bo'lagi + doira asos.",hint:"Qaysi jismning bitta doira asosi bor?",full:"Bitta doira asos va uchga yig'iladigan yon sirt — konus. Silindrda 2 doira va to'g'ri to'rtburchak."},
 tn:"Banka yorlig'ini ehtiyotkorlik bilan ko'chirib, to'g'ri to'rtburchak ekanini ko'rsating."},
{h:"Bilasizmi? Eyler qoidasi",sum:"Ko'pyoqlarda: uchlar + yoqlar − qirralar = 2 (L. Eyler).",a:"m09",
 start:function(){h6Euler(0)},fin:function(){h6Euler(2)},
 html:"<p>🧮 XVIII asrda shveytsariyalik matematik <b>Leonard Eyler</b> ajoyib qoidani e'lon qilgan. Tekshiring:</p>",
 btns:[["🧊 Kub",function(c,done){h6Euler(1);mvK(done,2)}],["🔺 Piramida",function(c,done){h6Euler(2);mvK(done,2)}]],g2:1,
 after:"<p>Tekis yoqli jismlarda doim: <b>uchlar + yoqlar − qirralar = 2</b>. Kub: 8 + 6 − 12 = 2, piramida: 5 + 5 − 8 = 2, quti: 8 + 6 − 12 = 2.</p>",
 tn:"Bolalar boshqa jismlarni (uchburchakli prizma: 6 uch, 5 yoq, 9 qirra) tekshirib ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h6Flat(2)},fin:function(){h6Flat(2)},
 html:"<div class='memo'><ul><li>Kub va quti: <b>6 yoq, 12 qirra, 8 uch</b>.</li><li>Kub yoyilmasi — 6 kvadrat (lekin har qanday 6 kvadrat emas!).</li><li>Quti yoqlari: (ab + ac + bc) · 2; qirralari: (a + b + c) · 4.</li><li><b>Shar</b> — egri, asos yo'q; <b>silindr</b> — 2 doira; <b>konus</b> — 1 doira + uch.</li><li>Silindr yoyilmasi: to'rtburchak + 2 doira; konus: doira bo'lagi + doira.</li></ul></div>",
 tn:"Uyga: qog'ozdan kub yoki silindr yasab keling."}
];
var PROBS=[
{t:"Kubning nechta yog'i bor?",o:["6","4","8","12"],k:0,s:"6 yoq."},
{t:"Kubning nechta qirrasi bor?",o:["12","6","8","4"],k:0,s:"12 qirra."},
{t:"Kubning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"8 uch."},
{t:"Kubning qirralari uchlaridan nechta ko'p?",o:["4","8","6","2"],k:0,s:"12 − 8 = 4."},
{t:"Futbol to'pi qaysi jismga o'xshaydi?",o:["Shar","Silindr","Konus","Kub"],k:0,s:"Shar."},
{t:"Konserva bankasi qaysi jismga o'xshaydi?",o:["Silindr","Shar","Konus","Kub"],k:0,s:"Silindr."},
{t:"Muzqaymoq vafli stakanchasi qaysi jismga o'xshaydi?",o:["Konus","Silindr","Shar","Piramida"],k:0,s:"Konus."},
{t:"Bitta doira asosi va uchi bor jism?",o:["Konus","Silindr","Kub","Shar"],k:0,s:"Konus."},
{t:"Ikkita teng doira asosli jism?",o:["Silindr","Konus","Shar","Kub"],k:0,s:"Silindr."},
{t:"Tekis yog'i umuman yo'q jism?",o:["Shar","Kub","Silindr","Konus"],k:0,s:"Shar butunlay egri."},
{t:"Kub yoyilmasi nechta kvadratdan iborat?",o:["6","4","8","12"],k:0,s:"6 yoq."},
{t:"Silindr yoyilmasi nimalardan iborat?",o:["To'g'ri to'rtburchak va 2 doira","3 ta doira","Uchburchak va doira","6 ta kvadrat"],k:0,s:"Yon sirt + 2 asos."},
{t:"Yoyilma: doira bo'lagi (yelpig'ich) va bitta doira. Qaysi jism?",o:["Konus","Silindr","Shar","Kub"],k:0,s:"Konus."},
{t:"2 × 3 qilib joylashgan 6 kvadratdan kub yasash mumkinmi?",o:["Yo'q, buklanmaydi","Ha, mumkin","Faqat kvadratlar katta bo'lsa","Faqat qirqilsa"],k:0,s:"Ikki yoq ustma-ust tushadi."},
{t:"Kub qirrasi 3 sm. Barcha qirralari uzunliklari yig'indisi?",o:["36 sm","12 sm","27 sm","24 sm"],k:0,s:"12 · 3 = 36."},
{t:"Kub qirrasi 2 sm. Barcha yoqlari yuzlari yig'indisi?",o:["24 sm²","8 sm²","16 sm²","12 sm²"],k:0,s:"6 · 4 = 24."},
{t:"Quti 4 × 3 × 2 sm. 6 yog'i yuzlari yig'indisi?",o:["52 sm²","24 sm²","26 sm²","48 sm²"],k:0,s:"(12 + 8 + 6) · 2 = 52."},
{t:"Quti 5 × 3 × 2 sm. Barcha qirralari yig'indisi?",o:["40 sm","10 sm","30 sm","20 sm"],k:0,s:"(5 + 3 + 2) · 4 = 40."},
{t:"Asosi kvadrat bo'lgan piramidaning nechta uchi bor?",o:["5","4","8","6"],k:0,s:"4 asosda + 1 tepada."},
{t:"Kub uchun: uchlar + yoqlar − qirralar = ?",o:["2","0","26","14"],k:0,s:"8 + 6 − 12 = 2."}
];
function PRACT_STAGE(){h6Flat(2)}
var PREP_DATA={teach:["Tekis va fazoviy shakllar farqi.","Kub va parallelepiped: yoq, qirra, uch; kub yoyilmasi.","Shar, silindr, konus: belgilari va hayotdagi misollar.","Silindr va konus yoyilmalari; quti yoqlari yuzlari va qirralari yig'indisi."],
 mist:["Kvadrat va kubni, doira va sharni adashtiradi.","Kub qirralarini 8 yoki 6 deydi (ko'rinmaydiganlarni sanamaydi).","Har qanday 6 kvadratni kub yoyilmasi deb o'ylaydi.","Quti qirralari yig'indisida har o'lchamni bir marta oladi."],
 need:["Kubik, to'p, banka, vafli stakancha, gugurt qutisi.","Plastilin va cho'plar, qog'oz, qaychi, yelim."],
 board:["Kub: <span class='w2'>6 yoq, 12 qirra, 8 uch</span>.","Quti: yoqlar (ab + ac + bc) · 2, qirralar (a + b + c) · 4.","Shar / silindr (2 doira) / konus (1 doira + uch).","Eyler: 8 + 6 − 12 = 2."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
