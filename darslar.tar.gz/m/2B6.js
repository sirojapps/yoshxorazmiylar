var CODE='2B6',TITLE='2-sinf · Qulay usulda og‘zaki hisoblash';
var P3=[function(){bqLine(50,90,[],[[58,C.blue]]);bqMsg('58 + 29 = ? &nbsp; 29 — bu deyarli <b>30</b>')},
 function(){bqLine(50,90,[[58,88,'+30',C.ok]],[[58,C.blue],[88,'#9aa8b6']]);bqMsg('Avval qulay son qo‘shamiz: 58 + 30 = 88')},
 function(){bqLine(50,90,[[58,88,'+30',C.ok],[88,87,'−1',C.bad]],[[58,C.blue],[87,C.ok]]);bqMsg('Lekin 1 ta ortiqcha qo‘shdik — qaytaramiz: 88 − 1 = <b>87</b>')}];
var P4=[function(){bqLine(40,80,[],[[75,C.blue]]);bqMsg('75 − 19 = ? &nbsp; 19 — deyarli <b>20</b>')},
 function(){bqLine(40,80,[[75,55,'−20',C.bad]],[[75,C.blue],[55,'#9aa8b6']]);bqMsg('75 − 20 = 55 — lekin 1 ta ko‘p ayirdik')},
 function(){bqLine(40,80,[[75,55,'−20',C.bad],[55,56,'+1',C.ok]],[[75,C.blue],[56,C.ok]]);bqMsg('Ortiqcha ayirilganini qaytaramiz: 55 + 1 = <b>56</b>')}];
var P5=[function(){bqExpr(['99 + 37 − 99 + 63']);bqMsg('Shoshilmang! Ifodaga diqqat bilan qarang')},
 function(){bqExpr(['[99] + 37 − [99] + 63']);bqMsg('+99 va −99 — bir-birini yo‘q qiladi: qo‘shib, yana olib tashladik')},
 function(){bqExpr(['37 + 63','[100]']);bqMsg('Qolgani: 37 + 63 = <b>100</b> (7 + 3 = 10 — yaxlit!)')}];
var P6=[function(){bqExpr(['98 + 47 − 97']);bqMsg('98 va 97 — deyarli bir xil sonlar')},
 function(){bqExpr(['[98 − 97] + 47','1 + 47']);bqMsg('Avval 98 − 97 = 1 (o‘rinlarini almashtirib hisoblash mumkin)')},
 function(){bqExpr(['1 + 47','[48]']);bqMsg('Javob: <b>48</b> — og‘ir hisob kerak bo‘lmadi')}];
var STEPS=[
{h:"Yaxlit o'nlik yasaymiz",sum:"39 + 25 + 1: avval 39 + 1 = 40 (yaxlit), keyin 40 + 25 = 65.",a:"m01",
 start:function(){bqPairs([39,25,1],function(a,b){return (a+b)%10===0},function(){bqMsg('39 + 1 = <b>40</b>, keyin 40 + 25 = <b>65</b>');if(S.d1)S.d1()},{title:'39 + 25 + 1 — qaysi ikkitasi yaxlit son beradi?'});bqMsg('Yig‘indisi 0 bilan tugaydigan ikki sonni bosing')},
 fin:function(){bqExpr(['39 + 25 + 1','[39 + 1] + 25','40 + 25 = 65'])},
 html:"<p>Hisobni osonlashtirishning eng kuchli siri — <b>yaxlit o'nlik</b> (10, 20, 30, …) yasash. Qaysi ikki son qo'shilib yaxlit son beradi? Ikkalasini bosing.</p>",
 act:function(c,done){S.d1=function(){S.d1=null;done()}},
 after:"<p>39 + 1 = 40 — yaxlit son. Endi 40 + 25 ni hisoblash juda oson: <b>65</b>. Qo'shishda sonlar o'rnini almashtirish mumkin, shuning uchun qulay juftni birinchi qo'shamiz.</p>",
 q:{t:"58 + 29 + 2 = ?",opts:["79","89","88","99"],ok:1,why:"58 + 2 = 60, 60 + 29 = 89.",hint:"Qaysi ikki son yaxlit o'nlik beradi?",full:"58 + 2 = 60 (yaxlit), keyin 60 + 29 = 89. «79» — o'nlikni yo'qotish xatosi."},
 tn:"Yaponiya va Singapurda «10 ni yasash» (make ten) — og'zaki hisobning asosi. Har kuni 2 daqiqa «juftini top» o'yini: o'qituvchi son aytadi (37), bolalar yaxlitgacha to'ldiruvchini aytadi (3)."},
{h:"Juftlab qo'shish",sum:"29 + 46 + 71 + 54 = (29 + 71) + (46 + 54) = 100 + 100 = 200.",a:"m02",
 start:function(){bqPairs([29,46,71,54],function(a,b){return (a+b)%100===0},function(){bqMsg('(29 + 71) + (46 + 54) = 100 + 100 = <b>200</b>');if(S.d2)S.d2()},{title:'29 + 46 + 71 + 54 — yuzlikka to‘ldiruvchi juftlarni toping'});bqMsg('Yig‘indisi 100 bo‘ladigan juftlarni bosing')},
 fin:function(){bqExpr(['29 + 46 + 71 + 54','(29 + 71) + (46 + 54)','100 + 100 = 200'])},
 html:"<p>Bu ifodani tartib bilan qo'shish qiyin. Lekin unda <b>yaxlit yuzlik</b> beradigan juftlar yashiringan. Toping:</p>",
 act:function(c,done){S.d2=function(){S.d2=null;done()}},
 after:"<p>Birliklarga qarang: 9 + 1 = 10, 6 + 4 = 10. Shunday juftlar doim yaxlit son beradi. Bu usul «juftlab qo'shish» deyiladi.</p>",
 q:{t:"17 + 26 + 33 + 24 = ?",opts:["90","100","110","99"],ok:1,why:"(17 + 33) + (26 + 24) = 50 + 50 = 100.",hint:"Birliklari qo'shilib 10 bo'ladigan juftlarni toping: 7 va 3, 6 va 4.",full:"17 + 33 = 50, 26 + 24 = 50, jami 100. Tartib bilan qo'shganda ham shunday chiqadi, lekin bu yo'l tezroq va xatosiz."},
 tn:"Bolalar sonlarni kartochkaga yozib, stolda juftlasin. Qaysi raqamlar 10 ga to'ldiradi: 1–9, 2–8, 3–7, 4–6, 5–5."},
{h:"Yaxlitlab qo'shish",sum:"58 + 29 = 58 + 30 − 1 = 87: ko'proq qo'shib, ortiqchasini qaytaramiz.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>29 ni qo'shish qiyin, 30 ni qo'shish oson. Ayyorlik: <b>30 qo'shamiz, keyin 1 ni qaytaramiz</b>. Son o'qida kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p>Bu usul «kompensatsiya» (tenglashtirish) deyiladi: 29, 39, 48, 99 kabi yaxlitga yaqin sonlarni avval yaxlit qilib qo'shamiz, keyin farqini tuzatamiz.</p>",
 q:{t:"47 + 19 = ?",opts:["67","66","56","76"],ok:1,why:"47 + 20 = 67, 67 − 1 = 66.",hint:"19 ni 20 deb qo'shing. Keyin nimani tuzatish kerak?",full:"47 + 20 = 67, lekin 1 ta ortiqcha qo'shdik: 67 − 1 = 66. «67» — tuzatishni unutish xatosi."},
 tn:"Son o'qida ikki sakrashni chizing: katta (+30) va kichik orqaga (−1). Gollandiya RME dasturida bu «bo'sh son o'qi» deyiladi."},
{h:"Yaxlitlab ayirish",sum:"75 − 19 = 75 − 20 + 1 = 56: ko'proq ayirsak — ortiqchasini qaytarib qo'shamiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ayirishda ham shunday: 19 o'rniga 20 ni ayiramiz. Lekin keyin <b>qo'shamizmi yoki ayiramizmi</b>? Kuzating:</p>",
 btns:[phaser(P4)],
 after:"<p>Diqqat: ayirishda ko'proq ayirsak, natija <b>kichrayib</b> ketadi — shuning uchun ortiqchasini <b>qaytarib qo'shamiz</b>. Bu eng ko'p xato qilinadigan joy!</p>",
 q:{t:"85 − 29 = ?",opts:["54","56","66","64"],ok:1,why:"85 − 30 = 55, 55 + 1 = 56.",hint:"30 ni ayirdingiz — 1 ta ko'p ayirdingiz. Uni nima qilish kerak?",full:"85 − 30 = 55. 1 ta ortiqcha ayirdik, demak uni qaytarib qo'shamiz: 55 + 1 = 56. «54» — 1 ni yana ayirib yuborish xatosi."},
 tn:"Hayotiy misol: do'konda 19 ming so'mlik narsaga 20 ming berasiz — 1 ming qaytim oladingiz. Ayirishda kompensatsiya aynan shunday."},
{h:"Tuzoq: bir-birini yo'qotadigan sonlar",sum:"99 + 37 − 99 + 63: +99 va −99 yo'qoladi → 37 + 63 = 100.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Ba'zi ifodalarda hisoblash umuman shart emas. Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>Biror sonni qo'shib, keyin xuddi shu sonni ayirsak — hech narsa o'zgarmaydi. Shuning uchun ifodani hisoblashdan oldin <b>unga diqqat bilan qarang</b>.</p>",
 q:{t:"64 − 19 + 19 = ?",opts:["26","64","102","45"],ok:1,why:"−19 va +19 bir-birini yo'qotadi.",hint:"19 ni ayirib, yana 19 ni qo'shsak nima o'zgaradi?",full:"Avval 19 ni olib, keyin qaytarib qo'ydik — son o'zgarmadi: 64. Hisoblab ham tekshirish mumkin: 64 − 19 = 45, 45 + 19 = 64."},
 tn:"Bu — olimpiada va bank testlarida keladigan tur. Bolalarni «avval ko'z bilan qarash» odatiga o'rgating."},
{h:"Tuzoq: o'xshash sonlar",sum:"98 + 47 − 97: avval 98 − 97 = 1, keyin 1 + 47 = 48.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>98 + 47 − 97 — tartib bilan hisoblasak, 145 dan 97 ni ayirish kerak. Qulayroq yo'l bor:</p>",
 btns:[phaser(P6)],
 after:"<p>Qo'shish va ayirishdan iborat ifodada sonlarni <b>o'z belgisi bilan birga</b> o'rnini almashtirish mumkin: 98 + 47 − 97 = 98 − 97 + 47.</p>",
 q:{t:"76 + 35 − 75 = ?",opts:["36","34","186","40"],ok:0,why:"76 − 75 = 1, 1 + 35 = 36.",hint:"76 va 75 — deyarli teng. Ularni avval ayiring.",full:"76 − 75 = 1, keyin 1 + 35 = 36. Tartib bilan: 76 + 35 = 111, 111 − 75 = 36 — javob bir xil, lekin qiyinroq."},
 tn:"Belgini son bilan birga «ko'chirish»ni kartochkalar bilan ko'rsating: «+47», «−97» kartochkalari o'rnini almashtiradi."},
{h:"Ketma-ket sonlarni qo'shish",sum:"1 + 2 + … + 9: chetlardan juftlaymiz (1 + 9, 2 + 8, 3 + 7, 4 + 6) — 4 ta o'nlik + 5 = 45.",a:"m07",
 start:function(){bqPairs([1,2,3,4,5,6,7,8,9],function(a,b){return a+b===10},function(){bqMsg('4 ta juft — 40, o‘rtada yolg‘iz 5: <b>45</b>');if(S.d7)S.d7()},{title:'1 + 2 + 3 + … + 9 — yig‘indisi 10 bo‘ladigan juftlar'});bqMsg('Yig‘indisi 10 bo‘ladigan juftlarni bosing (5 juftsiz qoladi)')},
 fin:function(){bqExpr(['(1+9)+(2+8)+(3+7)+(4+6)+5','10+10+10+10+5','[45]'])},
 html:"<p>1 dan 9 gacha hamma sonlarni qo'shamiz. Bittalab qo'shish uzoq. Juftlab ko'ring:</p>",
 act:function(c,done){S.d7=function(){S.d7=null;done()}},
 after:"<p>Chetdagi sonlar juft bo'lib 10 beradi: 1 + 9, 2 + 8, 3 + 7, 4 + 6. To'rtta o'nlik — 40, o'rtadagi 5 — jami <b>45</b>.</p>",
 q:{t:"2 + 4 + 6 + 8 + 10 + 12 + 14 + 16 + 18 = ?",opts:["80","90","100","88"],ok:1,why:"(2+18)+(4+16)+(6+14)+(8+12) = 4 · 20 = 80, + 10 = 90.",hint:"Chetlardan juftlang: 2 + 18, 4 + 16 …",full:"Juftlar: 2 + 18 = 20, 4 + 16 = 20, 6 + 14 = 20, 8 + 12 = 20 — 80. O'rtadagi 10 — jami 90."},
 tn:"Bu — keyingi qadamdagi Gauss hikoyasining kichik nusxasi. Bolalar juftlarni kamalak yoylari bilan chizsin."},
{h:"Bilasizmi? Kichik Gaussning sirri",sum:"Rivoyatga ko'ra, kichik Gauss 1 dan 100 gacha sonlarni juftlab bir zumda qo'shgan: 50 · 101 = 5050.",a:"m08",
 start:function(){gaussB(false)},fin:function(){gaussB(true)},
 html:"<p>📜 Rivoyat qilinishicha, nemis matematigi <b>Karl Fridrix Gauss</b> maktabda o'qib yurgan paytida o'qituvchi bolalarga 1 dan 100 gacha barcha sonlarni qo'shishni topshirdi. Gauss bir necha daqiqada javob berdi. Qanday qilib?</p>",
 btns:[["🔍 Gaussning usuli",function(c,done){gaussB(true);done()}]],
 after:"<p>Gauss juftladi: 1 + 100, 2 + 99, 3 + 98 … — har biri <b>101</b>. Bunday juftlar 50 ta. 50 · 101 = <b>5050</b>. Siz hozirgina xuddi shu usulda 1 dan 9 gacha qo'shdingiz! Keyinchalik Gauss dunyoning eng buyuk matematiklaridan biri bo'ldi.</p>",
 tn:"Bolalarga 1 dan 20 gacha yig'indini Gauss usulida topishni topshiring: 10 juft · 21 = 210."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqExpr(['39 + 25 + 1','[39 + 1] + 25','65'])},fin:function(){bqExpr(['39 + 25 + 1','[39 + 1] + 25','65'])},
 html:"<div class='memo'><ul><li><b>Yaxlit o'nlik yasang</b>: 39 + 25 + 1 = (39 + 1) + 25 = 65.</li><li><b>Juftlang</b>: 29 + 46 + 71 + 54 = 100 + 100 = 200.</li><li><b>Yaxlitlab qo'shing</b>: 58 + 29 = 58 + 30 − 1.</li><li><b>Yaxlitlab ayiring</b>: 75 − 19 = 75 − 20 <b>+ 1</b> (ortiqcha ayirilgan qaytariladi).</li><li>+99 va −99 kabi sonlar <b>bir-birini yo'qotadi</b>.</li><li>Ifodada sonlar <b>o'z belgisi bilan</b> o'rin almashadi: 98 + 47 − 97 = 98 − 97 + 47.</li><li>Ketma-ket sonlar: chetlardan juftlang (Gauss usuli).</li></ul></div>",
 tn:"Har kuni darsning birinchi 3 daqiqasini og'zaki hisobga ajrating — bitta usul, 5 ta misol."}
];
function gaussB(on){clear();var g=S.g;T(g,180,26,'1 + 2 + 3 + … + 98 + 99 + 100',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});
 if(!on){bqMsg('Gauss qanday qilib tez qo‘shdi?');return}
 var pr=[[1,100],[2,99],[3,98],[4,97]];pr.forEach(function(p,i){var y=56+i*24;T(g,120,y,p[0]+' + '+p[1],{'font-size':14,'font-weight':700,fill:C.blue});T(g,215,y,'= 101',{'font-size':14,'font-weight':800,fill:C.ok})});T(g,165,154,'… jami 50 ta juft',{'font-size':13,fill:'#5b6b7b'});
 bqMsg('50 juft · 101 = <b>5050</b>')}
var PROBS=[
{t:"36 + 47 + 8 = ?",o:["91","81","90","101"],k:0,s:"36 + 47 = 83, 83 + 8 = 91."},
{t:"58 + 29 + 2 = ?",o:["89","79","88","99"],k:0,s:"58 + 2 = 60, 60 + 29 = 89."},
{t:"29 + 46 + 71 + 54 = ?",o:["200","190","210","180"],k:0,s:"(29 + 71) + (46 + 54) = 100 + 100."},
{t:"99 + 37 − 99 + 63 = ?",o:["100","136","198","26"],k:0,s:"+99 va −99 yo'qoladi: 37 + 63 = 100."},
{t:"1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 = ?",o:["45","40","50","55"],k:0,s:"4 juft · 10 + 5 = 45."},
{t:"17 + 26 + 33 + 24 = ?",o:["100","90","110","99"],k:0,s:"(17 + 33) + (26 + 24) = 50 + 50."},
{t:"63 − 18 − 2 = ?",o:["43","41","83","47"],k:0,s:"63 − (18 + 2) = 63 − 20 = 43."},
{t:"39 + 25 + 1 = ?",o:["65","75","64","55"],k:0,s:"39 + 1 = 40, 40 + 25 = 65."},
{t:"98 + 47 − 97 = ?",o:["48","46","142","50"],k:0,s:"98 − 97 = 1, 1 + 47 = 48."},
{t:"47 + 19 = ?",o:["66","67","56","76"],k:0,s:"47 + 20 − 1 = 66."},
{t:"85 − 29 = ?",o:["56","54","66","64"],k:0,s:"85 − 30 + 1 = 56."},
{t:"24 + 38 + 16 + 22 = ?",o:["100","90","110","96"],k:0,s:"(24 + 16) + (38 + 22) = 40 + 60."},
{t:"76 − 26 − 18 = ?",o:["32","68","42","30"],k:0,s:"76 − 26 = 50, 50 − 18 = 32."},
{t:"45 + 45 + 10 = ?",o:["100","90","95","110"],k:0,s:"45 + 45 = 90, 90 + 10 = 100."},
{t:"100 − 37 − 63 = ?",o:["0","26","74","100"],k:0,s:"37 + 63 = 100, 100 − 100 = 0."},
{t:"13 + 14 + 15 + 16 + 17 = ?",o:["75","70","65","80"],k:0,s:"(13 + 17) + (14 + 16) + 15 = 30 + 30 + 15."},
{t:"88 + 7 + 12 + 3 = ?",o:["110","100","120","105"],k:0,s:"(88 + 12) + (7 + 3) = 100 + 10."},
{t:"64 − 19 + 19 = ?",o:["64","26","102","45"],k:0,s:"−19 va +19 yo'qoladi."},
{t:"49 + 49 = ?",o:["98","88","99","100"],k:0,s:"50 + 50 − 2 = 98."},
{t:"2 + 4 + 6 + 8 + 10 + 12 + 14 + 16 + 18 = ?",o:["90","80","100","88"],k:0,s:"4 juft · 20 + 10 = 90."}
];
function PRACT_STAGE(){bqExpr(['39 + 25 + 1','[39 + 1] + 25','65']);bqMsg('Avval qulay juftni toping')}
var PREP_DATA={teach:["Yaxlit o'nlik yasash va juftlab qo'shish.","Yaxlitlab qo'shish va ayirish (kompensatsiya).","Bir-birini yo'qotadigan sonlar; belgisi bilan o'rin almashtirish.","Ketma-ket sonlar yig'indisi (Gauss usuli)."],
 mist:["Yaxlitlab ayirishda tuzatishni noto'g'ri tomonga qiladi (85 − 29 = 54).","Yaxlitlab qo'shishda tuzatishni unutadi (47 + 19 = 67).","Ifodaga qaramay, uzun hisobga kirishadi.","Belgisiz o'rin almashtiradi (98 + 47 − 97 ni 97 − 98 deb)."],
 need:["Son kartochkalari (juftlash uchun).","Doskada bo'sh son o'qi."],
 board:["<span class='w2'>39 + 25 + 1 = (39 + 1) + 25</span>.","<span class='w2'>29 + 71 = 100</span>, <span class='w2'>46 + 54 = 100</span>.","<span class='w2'>58 + 29 = 58 + 30 − 1</span>.","<span class='w2'>75 − 19 = 75 − 20 + 1</span>.","<span class='w2'>99 + 37 − 99 + 63 = 100</span>.","Gauss: <span class='w2'>1 + 100 = 2 + 99 = … = 101</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
