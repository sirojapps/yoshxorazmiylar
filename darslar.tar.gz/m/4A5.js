var CODE='4A5',TITLE='4-sinf · Aniq va taqribiy qiymatlar';
// chizg'ich: mm uzunlikdagi qalam
function a45R(mm,o){o=o||{};clear();var g=S.g,x0=24,k=20,y=96;if(o.title)T(g,180,22,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 E('rect',{x:x0-8,y:y,width:16*k+16,height:44,rx:4,fill:'#fdf3d6',stroke:'#c9a54a','stroke-width':1.4},g);
 for(var m=0;m<=150;m++){var X=x0+m*k/10,big=m%10===0,mid=m%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?16:(mid?11:6)),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+32,String(m/10),{'font-size':11,fill:'#5b4a1e'})}
 T(g,x0+15.75*k,y+32,'sm',{'font-size':10,fill:'#5b4a1e'});
 var L=mm*k/10;E('rect',{x:x0,y:y-26,width:L-10,height:18,rx:3,fill:'#f2b705',stroke:'#8a6a00','stroke-width':1},g);E('path',{d:'M'+(x0+L-10)+' '+(y-26)+' L'+(x0+L)+' '+(y-17)+' L'+(x0+L-10)+' '+(y-8)+' Z',fill:'#e9cfa0',stroke:'#8a6a00','stroke-width':1},g);
 E('line',{x1:x0+L,y1:y-30,x2:x0+L,y2:y+2,stroke:C.bad,'stroke-width':1.2,'stroke-dasharray':'3 2'},g);
 if(o.mark)o.mark.forEach(function(v){E('line',{x1:x0+v*k,y1:y-34,x2:x0+v*k,y2:y+44,stroke:C.ok,'stroke-width':2},g);T(g,x0+v*k,y-38,v+' sm',{'font-size':12,'font-weight':800,fill:C.ok})})}
var A45C=['Sinfda 28 o‘quvchi','Aholi ≈ 50 000 kishi','Daftarda 12 varaq','Bo‘yim 135 sm','Hafta 7 kun','Tarvuz 6 kg'],A45T=[1,3,5];
function a45cards(sel){a4cards(A45C,{title:'Taqribiy qiymatlarni bosing (3 ta)',cols:2,cw:170,fs:13,h:34,onTap:function(i,r){if(A45T.indexOf(i)>=0){a4mark(r,true);S.a45s[i]=1;var k=Object.keys(S.a45s).length;msg(i===1?'≈ — taxminan, demak taqribiy':(i===3?'Bo‘y o‘lchanadi — o‘lchash doim taqribiy':'Tarozi aniq ko‘rsatmaydi — taqribiy'));if(k===3&&S.a45d)S.a45d()}else{a4mark(r,false);msg('Bu sanaladi — sanash natijasi <b>aniq</b>')}}});(sel||[]).forEach(function(i){a4mark(S.cardEls[i],true)})}
var STEPS=[
{h:"Aniq yoki taqribiy?",sum:"Sanash — aniq natija; o'lchash va «taxminan» — taqribiy.",a:"m01",
 start:function(){S.a45s={};a45cards();msg('Sanaladigan narsa — aniq; o‘lchanadigan — taqribiy')},fin:function(){S.a45s={1:1,3:1,5:1};a45cards(A45T);msg('Taqribiy: aholi, bo‘y, tarvuz og‘irligi')},
 act:function(c,done){S.a45d=done},
 html:"<p>Ba'zi sonlar <b>aniq</b> (o'quvchilarni sanab chiqish mumkin), ba'zilari <b>taqribiy</b> (o'lchov yoki chamalash). Sahnadagi taqribiy qiymatlarni bosing:</p>",
 after:"<p>O'lchash asbobi qanchalik yaxshi bo'lmasin, natija <b>taqribiy</b>: chizg'ich mm gacha, tarozi g gacha ko'rsatadi, undan kichigini «sezmaydi». Taqribiy tenglik belgisi — <b>≈</b>.</p>",
 q:{t:"Qaysi qiymat aniq?",opts:["Sumkada 9 ta olma","Olma og'irligi 180 g","Daraxt bo'yi 4 m","Shahargacha 30 km"],ok:0,why:"Olmalarni sanash mumkin.",hint:"Qaysi birini sanab chiqish mumkin?",full:"9 ta olma — sanash natijasi, aniq. Og'irlik, bo'y, masofa — o'lchash natijasi, taqribiy."},
 tn:"Sinfda: o'quvchilar sonini sanang (aniq) va partaning uzunligini o'lchang (taqribiy) — farqni muhokama qiling."},
{h:"O'lchash natijasi",sum:"Qalam uchi 13 va 14 sm orasida, 14 ga yaqin: ≈ 14 sm.",a:"m02",
 start:function(){a45R(137,{title:'Qalam uzunligi necha sm?'});msg('Uchi qayerda turibdi?')},fin:function(){a45R(137,{title:'≈ 14 sm (sm aniqligida)',mark:[14]});msg('13 sm 7 mm ≈ <b>14 sm</b>')},
 html:"<p>Qalamni chizg'ichda o'lchadik. Santimetrlar aniqligida uzunligi qancha?</p>",
 btns:a4ch(["13 sm","14 sm","15 sm"],1,function(){a45R(137,{title:'≈ 14 sm (sm aniqligida)',mark:[14]});msg('Uchi 13 sm 7 mm da — 14 ga yaqinroq: <b>≈ 14 sm</b>')},function(i){msg(i===0?'13 sm ga 7 mm, 14 sm ga atigi 3 mm — qaysi yaqin?':'15 sm — juda uzoq')}),g3:1,
 after:"<p>«<b>Santimetr aniqligida</b>» — eng yaqin butun santimetrni aytish demak (yaxlitlash kabi). Millimetr aniqligida esa: 13 sm 7 mm = <b>137 mm</b>.</p>",
 q:{t:"Kitob eni 21 sm 4 mm. Santimetr aniqligida:",opts:["≈ 21 sm","≈ 22 sm","≈ 214 sm","≈ 20 sm"],ok:0,why:"4 mm < 5 mm → 21 sm.",hint:"4 mm yarim santimetrdan kammi, ko'pmi?",full:"21 sm 4 mm: 4 mm < 5 mm → pastga: 21 sm. «22» — yuqoriga yaxlitlash; «214 sm» — mm ni sm deb olish."},
 tn:"Har bir bola o'z qalamini o'lchab, sm va mm aniqligida yozsin."},
{h:"Kami bilan va ortig'i bilan",sum:"13 sm < qalam < 14 sm: 13 — kami bilan, 14 — ortig'i bilan.",a:"m03",
 start:function(){a45R(137,{title:'13 sm < qalam < 14 sm',mark:[13,14]});msg('Qalam ikki butun son orasida')},fin:function(){a45R(137,{title:'kami bilan 13 · ortig‘i bilan 14',mark:[13,14]});msg('Kami bilan — kichigi, ortig‘i bilan — kattasi')},
 html:"<p>Qalam uzunligi 13 sm dan katta, 14 sm dan kichik. «<b>Ortig'i bilan</b>» olingan taqribiy qiymat qaysi?</p>",
 btns:a4ch(["13 sm","14 sm"],1,function(){a45R(137,{title:'kami bilan 13 · ortig‘i bilan 14',mark:[13,14]});msg('Ortig‘i bilan — aniq qiymatdan <b>katta</b>: 14 sm')},function(){msg('13 sm — bu kami bilan (aniqdan kichik)')}),g2:1,
 after:"<p>Hayotda qaysi birini olish vaziyatga bog'liq: matoni sotib olayotganda <b>ortig'i bilan</b> (yetishi uchun), yuk ko'tarish chegarasini hisoblaganda — xavfsizlik uchun ham ortig'i bilan.</p>",
 q:{t:"Avtobusga 47 o'quvchi chiqishi kerak, bitta avtobusga 20 kishi sig'adi. Nechta avtobus kerak?",opts:["3","2","2 ta va qoldiq 7","4"],ok:0,why:"47 : 20 = 2 (qoldiq 7) → ortig'i bilan: 3.",hint:"7 ta o'quvchi qolib ketsinmi?",full:"2 ta avtobusga 40 kishi sig'adi, 7 kishi qoladi — ularga ham avtobus kerak: 3. Bu yerda faqat «ortig'i bilan» olish to'g'ri."},
 tn:"Bank 4A5-turi: qachon kami bilan, qachon ortig'i bilan — hayotiy vaziyatlar ro'yxati."},
{h:"Xatolik",sum:"Xatolik = aniq va taqribiy qiymatlar farqi: 4 382 ≈ 4 400, xatolik 18.",a:"m04",
 start:function(){bqLine(4370,4410,[],[[4382,C.bad],[4400,C.ok]],{step:10});T(S.g,180,26,'Aniq 4 382 · taqribiy 4 400',{'font-size':13,'font-weight':800,fill:C.blue});msg('Ular orasida qancha masofa?')},
 fin:function(){bqLine(4370,4410,[[4382,4400,'18',C.ok]],[[4382,C.bad],[4400,C.ok]],{step:10});T(S.g,180,26,'Xatolik = 4 400 − 4 382 = 18',{'font-size':13,'font-weight':800,fill:C.ok});msg('Xatolik <b>18</b>')},
 html:"<p>Omborda aniq 4 382 kg un bor. Hisobotda «≈ 4 400 kg» deb yozildi. <b>Xatolik</b> qancha?</p>",
 btns:a4ch(["18 kg","82 kg","28 kg","4 400 kg"],0,function(){bqLine(4370,4410,[[4382,4400,'18',C.ok]],[[4382,C.bad],[4400,C.ok]],{step:10});msg('4 400 − 4 382 = <b>18 kg</b>')},function(i){msg(i===1?'82 — oxirgi raqamlar. Ayirmani to‘liq hisoblang':i===3?'Bu taqribiy qiymatning o‘zi':'Ayirmani tekshiring: 4 400 − 4 382')}),g2:1,
 after:"<p>Xatolik — <b>kattasidan kichigini</b> ayirish: taqribiy katta bo'lsa (taqribiy − aniq), kichik bo'lsa (aniq − taqribiy). Xatolik qancha kichik bo'lsa — taqribiy qiymat shuncha <b>aniqroq</b>.</p>",
 q:{t:"Aniq qiymat 7 615, taqribiy 7 600. Xatolik:",opts:["15","85","5","7 600"],ok:0,why:"7 615 − 7 600 = 15.",hint:"Qaysi biri katta?",full:"Aniq qiymat katta: 7 615 − 7 600 = 15. «85» — 7 600 dan 7 615 gacha emas, 7 700 gacha hisoblash."},
 tn:"Son o'qida ikki nuqta orasidagi «masofa» sifatida ko'rsating."},
{h:"Qaysi taqribiy qiymat aniqroq?",sum:"4 382 ≈ 4 380 (xatolik 2) eng aniq; ≈ 4 400 (18); ≈ 4 000 (382).",a:"m05",
 start:function(){a4cards(['≈ 4 380','≈ 4 400','≈ 4 000'],{title:'4 382 uchun qaysi biri eng aniq?',cw:110});msg('Har birining xatoligini hisoblang')},fin:function(){a4cards(['xatolik 2','xatolik 18','xatolik 382'],{title:'≈ 4 380 eng aniq',cw:110,fs:14});a4mark(S.cardEls[0],true);msg('Kichik xona bo‘yicha yaxlitlash — aniqroq')},
 html:"<p>4 382 ni uch xil yaxlitlashdi. Qaysi taqribiy qiymat <b>eng aniq</b>?</p>",
 btns:a4ch(["≈ 4 380","≈ 4 400","≈ 4 000"],0,function(){a4cards(['xatolik 2','xatolik 18','xatolik 382'],{title:'≈ 4 380 eng aniq',cw:110,fs:14});a4mark(S.cardEls[0],true);msg('Xatoliklar: 2, 18, 382. Eng kichigi — <b>≈ 4 380</b>')},function(i){msg(i===1?'4 400 − 4 382 = 18, 4 382 − 4 380 = ? — qaysi kichik?':'4 382 − 4 000 = 382 — juda katta xatolik')}),g3:1,
 after:"<p>O'nliklargacha yaxlitlash — xatolik 5 dan oshmaydi; yuzliklargacha — 50 dan; minglargacha — 500 dan. Qaysi aniqlik kerak — vazifaga bog'liq: aholi soni uchun minglar ham yetadi, dori dozasi uchun esa juda aniq bo'lishi shart.</p>",
 q:{t:"Yuzliklargacha yaxlitlanganda xatolik eng katta bo'lishi mumkin bo'lgan qiymat:",opts:["50","100","10","99"],ok:0,why:"O'rtadagi son (masalan 4 350 ≈ 4 400) — xatolik 50.",hint:"Son qo'shni yuzliklardan biriga eng uzog'i bilan qancha uzoqlikda bo'ladi?",full:"Son ikki yuzlik orasida; eng uzoq holat — aynan o'rtasi: 4 350 ≈ 4 400, xatolik 50. Undan uzoq bo'lsa, boshqa yuzlik yaqinroq bo'lardi."},
 tn:"Bank 4A5 qiyin turi. Son o'qida «yarim qadam» bilan ko'rsating."},
{h:"Tuzoq: taqribiy qiymatlar bilan hisoblash",sum:"3 ta tarvuz ≈ 2 kg dan (aslida 2 kg 400 g dan): xatolik 3 marta oshadi — 1 kg 200 g.",a:"m06",
 start:function(){bqBar(null,[{v:'2 kg 400 g'},{v:'2 kg 400 g'},{v:'2 kg 400 g'}],{title:'3 ta tarvuz, har biri ≈ 2 kg'});msg('Har birida 400 g «yo‘qoldi»')},fin:function(){bqBar('7 kg 200 g',[{v:'2 kg 400 g'},{v:'2 kg 400 g'},{v:'2 kg 400 g'}],{title:'taqribiy jami 6 kg · aniq 7 kg 200 g'});msg('Xatolik: 400 g · 3 = <b>1 kg 200 g</b>')},
 html:"<p>Har bir tarvuz «≈ 2 kg» deb yozildi, aslida har biri 2 kg 400 g. 3 ta tarvuzning taqribiy jami (6 kg) aniq jamidan qancha farq qiladi?</p>",
 btns:a4ch(["400 g","1 kg 200 g","1 kg","200 g"],1,function(){bqBar('7 kg 200 g',[{v:'2 kg 400 g'},{v:'2 kg 400 g'},{v:'2 kg 400 g'}],{title:'taqribiy jami 6 kg · aniq 7 kg 200 g'});msg('Har bir tarvuzning xatoligi qo‘shiladi: 400 + 400 + 400 = <b>1 200 g</b>')},function(i){msg(i===0?'Bu bitta tarvuzning xatoligi. Uchtasi-chi?':'Hisoblang: 400 g · 3')}),g2:1,
 after:"<p>Muhim xulosa: taqribiy qiymatlarni qo'shsak yoki ko'paytirsak, <b>xatoliklar ham qo'shiladi</b>. 100 ta narsani ≈ qiymat bilan hisoblasak, kichik xatolik juda katta bo'lib ketishi mumkin. Shuning uchun pul hisobida aniq qiymat ishlatiladi.</p>",
 q:{t:"Do'kon kuniga ≈ 300 ta non sotadi (aslida 312 ta). 30 kunlik taqribiy hisob aniqidan qancha kam?",opts:["360 ta","12 ta","300 ta","9 000 ta"],ok:0,why:"12 · 30 = 360.",hint:"Har kuni nechta non «yo'qolyapti»?",full:"Har kuni 312 − 300 = 12 ta. 30 kunda 12 · 30 = 360 ta. «12» — bir kunlik xatolik; «9 000» — taqribiy jami."},
 tn:"Bolalar kunlik xarajatni yaxlitlab, oylik farqni hisoblasin — moliyaviy savodxonlik."},
{h:"Qaysi birligi aniqroq?",sum:"Kichik birlik — aniqroq o'lchash: 1 m 35 sm 4 mm = 1 354 mm.",a:"m07",
 start:function(){a4cards(['≈ 1 m','≈ 14 dm','≈ 135 sm','1 354 mm'],{title:'Bitta bo‘y — to‘rt xil aniqlik',cw:84,fs:14});msg('Qaysi yozuv eng aniq?')},fin:function(){a4cards(['≈ 1 m','≈ 14 dm','≈ 135 sm','1 354 mm'],{title:'mm — eng kichik birlik',cw:84,fs:14});a4mark(S.cardEls[3],true);msg('Eng kichik birlik — eng aniq')},
 html:"<p>Bolaning bo'yi 1 m 35 sm 4 mm. Qaysi yozuv eng aniq?</p>",
 btns:a4ch(["≈ 1 m","≈ 14 dm","≈ 135 sm","1 354 mm"],3,function(){a4cards(['≈ 1 m','≈ 14 dm','≈ 135 sm','1 354 mm'],{title:'mm — eng kichik birlik',cw:84,fs:14});a4mark(S.cardEls[3],true);msg('1 354 mm — barcha bo‘laklar saqlangan')},function(i){msg(i===0?'1 m — 35 sm yo‘qoldi!':i===1?'≈ 14 dm = 1 400 mm — xatolik 46 mm':'135 sm — 4 mm yo‘qoldi')}),g2:1,
 after:"<p>Shuning uchun duradgor mm da, yo'l quruvchi m da, kosmonavtika muhandisi esa mm ning ulushlarida o'lchaydi. Birlikni tanlash — aniqlikni tanlash.</p>",
 q:{t:"5 m 7 sm ni santimetrlarda ifodalang:",opts:["507 sm","57 sm","570 sm","5 007 sm"],ok:0,why:"5 · 100 + 7 = 507.",hint:"1 m = 100 sm.",full:"5 m = 500 sm, + 7 sm = 507 sm. «57» — metrlarni o'nlik deb olish; «570» — 7 sm ni 70 deb yozish."},
 tn:"Bitta partani m, dm, sm va mm da o'lchab, natijalarni solishtiring."},
{h:"Ortig'i bilanmi, kami bilanmi?",sum:"2 kg 700 g: kami bilan 2 kg (xatolik 700 g), ortig'i bilan 3 kg (xatolik 300 g).",a:"m08",
 start:function(){bqLine(2000,3000,[],[[2700,C.bad]],{step:500});T(S.g,180,26,'2 kg 700 g — 2 kg mi, 3 kg mi?',{'font-size':13,'font-weight':800,fill:C.blue});msg('Grammlarda: 2 000 … 3 000')},
 fin:function(){bqLine(2000,3000,[[2700,3000,'300 g',C.ok]],[[2700,C.bad]],{step:500});T(S.g,180,26,'ortig‘i bilan 3 kg aniqroq',{'font-size':13,'font-weight':800,fill:C.ok});msg('300 g < 700 g')},
 html:"<p>Paket 2 kg 700 g. Kilogramm aniqligida kami bilan (2 kg) yoki ortig'i bilan (3 kg) — qaysi biri <b>aniqroq</b>?</p>",
 btns:a4ch(["kami bilan: 2 kg","ortig'i bilan: 3 kg"],1,function(){bqLine(2000,3000,[[2700,3000,'300 g',C.ok]],[[2700,C.bad]],{step:500});msg('3 kg gacha 300 g, 2 kg gacha 700 g — <b>3 kg</b> aniqroq')},function(){msg('2 kg dan 700 g uzoqda. 3 kg dan-chi?')}),g2:1,
 after:"<p>Yaxlitlash aslida — kami bilan va ortig'i bilan qiymatlardan <b>xatoligi kichigini</b> tanlash. Shuning uchun yaxlitlashda xatolik doim xona birligining yarmidan oshmaydi.</p>",
 q:{t:"Masofa 6 km 450 m. Km aniqligida ortig'i bilan olingan qiymat va xatoligi:",opts:["7 km, 550 m","6 km, 450 m","7 km, 450 m","6 km, 550 m"],ok:0,why:"7 km − 6 km 450 m = 550 m.",hint:"Ortig'i bilan — kattasi.",full:"Ortig'i bilan — 7 km. Xatolik: 7 000 − 6 450 = 550 m. «6 km, 450 m» — kami bilan va uning xatoligi."},
 tn:"Tarozida olma tortib, kami/ortig'i bilan qiymatlarini yozdirish."},
{h:"Bilasizmi?",sum:"Metr Yer meridiani uzunligidan hosil qilingan.",a:"m09",
 start:function(){a45R(100,{title:'Metr qanday paydo bo‘lgan?'});msg('XVIII asr oxiri, Fransiya')},fin:function(){a45R(100,{title:'Metr qanday paydo bo‘lgan?'});msg('XVIII asr oxiri, Fransiya')},
 html:"<p>📏 Avvallari uzunlik qadam, tirsak, oyoq bilan o'lchangan — har kimniki har xil! XVIII asr oxirida Fransiyada olimlar <b>metr</b>ni Shimoliy qutbdan ekvatorgacha bo'lgan meridian uzunligining <b>o'n milliondan bir</b> qismi deb belgiladilar. Bu masofani o'lchash uchun ular yillar davomida ekspeditsiyada yurishgan.</p><p>🌍 Shuning uchun Yer aylanasi taxminan <b>40 000 km</b>.</p>",
 tn:"Bolalar o'z qadamini o'lchab, sinf uzunligini qadamda va metrda solishtirsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a45R(137,{title:'≈ 14 sm',mark:[14]})},fin:function(){a45R(137,{title:'≈ 14 sm',mark:[14]})},
 html:"<div class='memo'><ul><li>Sanash — aniq; o'lchash, «taxminan» — taqribiy (≈).</li><li>Kami bilan — kichik qiymat, ortig'i bilan — katta qiymat.</li><li>Xatolik = katta qiymat − kichik qiymat.</li><li>Xatoligi kichik — aniqroq; kichik birlik — aniqroq.</li><li>Taqribiy qiymatlar qo'shilsa — xatoliklar ham qo'shiladi.</li><li>Ba'zan faqat ortig'i bilan to'g'ri: 47 kishiga 20 kishilik avtobuslar → 3 ta.</li></ul></div>",
 tn:"Keyingi bo'lim — ko'p xonali sonlarni qo'shish va ayirish."}
];
var PROBS=[
{t:"Qaysi qiymat aniq?",o:["Sumkada 9 ta olma","Olma og'irligi 180 g","Daraxt bo'yi 4 m","Shahargacha 30 km"],k:0,s:"Sanaladi."},
{t:"Kitob eni 21 sm 4 mm. Santimetr aniqligida:",o:["≈ 21 sm","≈ 22 sm","≈ 214 sm","≈ 20 sm"],k:0,s:"4 mm < 5 mm."},
{t:"13 sm < qalam < 14 sm. Ortig'i bilan taqribiy qiymat:",o:["14 sm","13 sm","13 sm 5 mm","15 sm"],k:0,s:"Kattasi."},
{t:"47 o'quvchi, avtobusga 20 kishi sig'adi. Nechta avtobus kerak?",o:["3","2","4","5"],k:0,s:"Ortig'i bilan."},
{t:"Aniq 4 382, taqribiy 4 400. Xatolik:",o:["18","82","28","22"],k:0,s:"4 400 − 4 382."},
{t:"Aniq 7 615, taqribiy 7 600. Xatolik:",o:["15","85","5","25"],k:0,s:"7 615 − 7 600."},
{t:"4 382 uchun eng aniq taqribiy qiymat:",o:["4 380","4 400","4 000","4 390"],k:0,s:"Xatolik 2."},
{t:"Yuzliklargacha yaxlitlashda xatolik ko'pi bilan:",o:["50","100","99","10"],k:0,s:"Yarim yuzlik."},
{t:"3 ta tarvuz ≈ 2 kg dan (aslida 2 kg 400 g dan). Jami xatolik:",o:["1 kg 200 g","400 g","1 kg","1 kg 400 g"],k:0,s:"400 · 3."},
{t:"Kuniga ≈ 300 ta non (aslida 312). 30 kunda xatolik:",o:["360 ta","12 ta","300 ta","3 600 ta"],k:0,s:"12 · 30."},
{t:"1 m 35 sm 4 mm uchun eng aniq yozuv:",o:["1 354 mm","135 sm","14 dm","1 m"],k:0,s:"Eng kichik birlik."},
{t:"5 m 7 sm = ?",o:["507 sm","57 sm","570 sm","5 007 sm"],k:0,s:"500 + 7."},
{t:"2 kg 700 g — kilogramm aniqligida eng yaxshi taqribiy qiymat:",o:["3 kg","2 kg","2 kg 500 g","27 kg"],k:0,s:"Xatolik 300 g < 700 g."},
{t:"6 km 450 m — ortig'i bilan (km) va xatolik:",o:["7 km, 550 m","6 km, 450 m","7 km, 450 m","6 km, 550 m"],k:0,s:"7 000 − 6 450."},
{t:"Har bir kitob ≈ 300 g (xatolik ko'pi bilan 5 g). 20 ta kitob og'irligida xatolik ko'pi bilan:",o:["100 g","5 g","20 g","6 kg"],k:0,s:"5 · 20."},
{t:"Hovli uzunligi qadamda o'lchandi: 48 qadam, 1 qadam ≈ 60 sm. Taqribiy uzunlik:",o:["≈ 28 m 80 sm","≈ 48 m","≈ 2 880 m","≈ 108 m"],k:0,s:"48 · 60 = 2 880 sm."},
{t:"Taqribiy qiymat 600, xatolik 25. Aniq qiymat qaysi bo'lishi mumkin?",o:["575","600","650","525"],k:0,s:"600 − 25 yoki 600 + 25 = 625."},
{t:"Matodan 3 ta ko'ylak tikiladi, har biriga 1 m 70 sm. Mato metr bilan sotiladi. Necha metr sotib olish kerak?",o:["6 m","5 m","5 m 10 sm","4 m"],k:0,s:"5 m 10 sm → ortig'i bilan 6 m."},
{t:"Sinfdagi 32 o'quvchiga 5 tadan qalam. Qalamlar 12 talik qutida. Nechta quti kerak?",o:["14","13","12","15"],k:0,s:"160 : 12 = 13 (qoldiq 4) → 14."},
{t:"Ali bo'yini ≈ 1 m 40 sm deb aytdi (sm aniqligida). Uning haqiqiy bo'yi qaysi bo'lishi mumkin EMAS?",o:["1 m 40 sm 6 mm","1 m 39 sm 5 mm","1 m 40 sm 4 mm","1 m 39 sm 8 mm"],k:0,s:"140,6 sm ≈ 141 sm."}
];
function PRACT_STAGE(){a45R(137,{title:'≈ 14 sm',mark:[14]})}
var PREP_DATA={teach:["Aniq va taqribiy qiymatlar (sanash va o'lchash).","Kami bilan va ortig'i bilan taqribiy qiymat, xatolik.","Aniqlikni tanlash, xatoliklar to'planishi, hayotiy vaziyatlar (avtobus, mato)."],mist:["O'lchov natijasini aniq deb hisoblaydi.","Xatolikni oxirgi raqamlardan hisoblaydi (82).","Avtobus masalasida qoldiqni tashlab yuboradi.","Kami/ortig'i bilan atamalarini adashtiradi."],need:["Chizg'ich, tarozi, o'lchov lentasi, sinfdagi buyumlar."],board:["<span class='w2'>13 sm < l < 14 sm</span>; kami bilan 13, ortig'i bilan 14.","<span class='w2'>xatolik = 4 400 − 4 382 = 18</span>.","<span class='w2'>47 : 20 → 3 avtobus</span>.","<span class='w2'>1 354 mm</span> — eng aniq."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
