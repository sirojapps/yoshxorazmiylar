var CODE='4J21',TITLE="4-sinf · Qadimiy va xalq masalalari (al-Xorazmiy masalalari)";
// chizma model: bo'laklar [[uzunlik, rang, yozuv], ...]
function q21Bar(rows){clear();var g=S.g;rows.forEach(function(r,j){var y=24+j*44,x=70;T(g,62,y+21,r[0],{'font-size':11,'font-weight':800,'text-anchor':'end',fill:'#5a6a7a'});r[1].forEach(function(p){E('rect',{x:x,y:y,width:p[0],height:28,rx:4,fill:p[1],stroke:'#fff','stroke-width':2},g);if(p[2])T(g,x+p[0]/2,y+19,p[2],{'font-size':11,'font-weight':900,fill:'#1d2b3a'});x+=p[0]});if(r[2])T(g,x+6,y+19,r[2],{'font-size':13,'font-weight':900,fill:C.blue,'text-anchor':'start'})})}
// al-Xorazmiy kvadrati: ph 0 — x² + 10x, 1 — 5x + 5x bo'lingan, 2 — 25 qo'shilgan
function q21Sq(ph){clear();var g=S.g,x0=100,y0=20,a=70,b=40;E('rect',{x:x0,y:y0,width:a,height:a,fill:'#cfe6f7',stroke:C.blue,'stroke-width':2},g);T(g,x0+a/2,y0+a/2+5,'x²',{'font-size':16,'font-weight':900,fill:C.blue});
 if(ph===0){E('rect',{x:x0+a,y:y0,width:2*b+10,height:a,fill:'#fde2c4',stroke:'#e07a2f','stroke-width':2},g);T(g,x0+a+b+5,y0+a/2+5,'10x',{'font-size':16,'font-weight':900,fill:'#a8601f'});T(g,180,130,'x² + 10x = 39',{'font-size':18,'font-weight':900,fill:'#1d2b3a'});return}
 E('rect',{x:x0+a,y:y0,width:b,height:a,fill:'#fde2c4',stroke:'#e07a2f','stroke-width':2},g);T(g,x0+a+b/2,y0+a/2+5,'5x',{'font-size':13,'font-weight':900,fill:'#a8601f'});
 E('rect',{x:x0,y:y0+a,width:a,height:b,fill:'#fde2c4',stroke:'#e07a2f','stroke-width':2},g);T(g,x0+a/2,y0+a+b/2+5,'5x',{'font-size':13,'font-weight':900,fill:'#a8601f'});
 E('rect',{x:x0+a,y:y0+a,width:b,height:b,fill:ph>=2?'#d9f2e5':'none',stroke:ph>=2?C.ok:'#bbb','stroke-width':2,'stroke-dasharray':ph>=2?'':'5 4'},g);T(g,x0+a+b/2,y0+a+b/2+5,ph>=2?'25':'?',{'font-size':13,'font-weight':900,fill:ph>=2?C.ok:'#999'});
 T(g,x0+a/2,y0-6,'x',{'font-size':12,'font-weight':800});T(g,x0+a+b/2,y0-6,'5',{'font-size':12,'font-weight':800});
 if(ph>=2){T(g,300,60,'39 + 25 = 64',{'font-size':15,'font-weight':900,fill:'#1d2b3a'});T(g,300,88,'tomoni 8',{'font-size':15,'font-weight':900,fill:C.ok});T(g,300,116,'x = 8 − 5 = 3',{'font-size':15,'font-weight':900,fill:C.ok})}}
var P1=[function(){q21Bar([["son",[[60,'#cfe6f7','x'],[100,'#fde2c4','10']]],["3 hissa",[[60,'#cfe6f7','x'],[60,'#cfe6f7','x'],[60,'#cfe6f7','x']]]]);j2Msg("«Son va 10 ning yig'indisi sonning 3 hissasiga teng». Ikki qator — teng uzunlik.")},
 function(){q21Bar([["son",[[60,'#e9edf1','x'],[100,'#fde2c4','10']]],["3 hissa",[[60,'#e9edf1','x'],[60,'#cfe6f7','x'],[60,'#cfe6f7','x']]]]);j2Msg("<b>al-muqobala</b> (qarama-qarshi qo'yish): ikkala tomondan bir xil x ni olib tashlaymiz.")},
 function(){q21Bar([["qoldi",[[100,'#fde2c4','10']],"="],["qoldi",[[50,'#cfe6f7','x'],[50,'#cfe6f7','x']],"→ x = 5"]]);j2Msg("10 = 2x → x = <b>5</b>. Tekshirish: 5 + 10 = 15 = 3 · 5 ✓.")}];
var P2=[function(){j2Lines([["🏠 7 uy",null,20]]);j2Msg("Misr, Rind papirusi (taxminan miloddan avvalgi 1650-yil), 79-masala.")},
 function(){j2Lines([["🏠 7 uy",null,18],["🐈 7 · 7 = 49 mushuk",null,18],["🐁 49 · 7 = 343 sichqon",C.blue,18]]);j2Msg("Har uyda 7 mushuk, har mushuk 7 sichqon tutdi…")},
 function(){j2Lines([["🌾 343 · 7 = 2 401 boshoq",null,16],["🫘 2 401 · 7 = 16 807 o'lchov don",null,16],["jami: 19 607",C.ok,20]]);j2Msg("Har sichqon 7 boshoq yegan bo'lardi, har boshoqdan 7 o'lchov don. Hammasi qo'shilsa — 19 607.")}];
var P3=[function(){j2Lines([["«Salom, yuz g'oz!»",C.blue,20]]);j2Msg("Rus xalq masalasi (L. Magnitskiy «Arifmetika», 1703): g'ozlar to'dasiga «Salom, yuz g'oz!» deyishdi.")},
 function(){j2Lines([["«Biz 100 emasmiz. Bizlar, yana shuncha,",null,13],["yana yarmimiz, yana choragimiz",null,13],["va sen qo'shilsang — 100 bo'lamiz»",null,13]]);j2Msg("To'dada nechta g'oz bor?")},
 function(){q21Bar([["",[[64,'#cfe6f7','4'],[64,'#cfe6f7','4'],[32,'#fde2c4','2'],[16,'#fff1a8','1'],[14,'#d9f2e5','1']],"= 100"]]);j2Msg("To'dani 4 bo'lak deb olamiz: 4 + 4 + 2 + 1 = <b>11</b> bo'lak va yana 1 g'oz = 100.")},
 function(){j2Lines([["11 bo'lak = 99",null,18],["1 bo'lak = 9",null,18],["to'da = 4 · 9 = 36",C.ok,24]]);j2Msg("To'dada <b>36</b> g'oz. Tekshirish: 36 + 36 + 18 + 9 + 1 = 100 ✓.")}];
var P4=[function(){j2Lines([["35 bosh, 94 oyoq",C.blue,22],["🐔 tovuq va 🐇 quyon",null,18]]);j2Msg("Xitoy, Sunzi kitobi (taxminan V asr): qafasda tovuq va quyonlar.")},
 function(){j2Lines([["hammasi tovuq desak: 35 · 2 = 70 oyoq",null,15],["94 − 70 = 24 oyoq ortiq",C.bad,17]]);j2Msg("Faraz qilamiz: hammasi tovuq. Unda oyoqlar 70 ta bo'lardi — 24 ta yetmaydi.")},
 function(){j2Lines([["har quyon +2 oyoq",null,16],["24 : 2 = 12 quyon",C.ok,20],["35 − 12 = 23 tovuq",C.ok,20]]);j2Msg("Har tovuqni quyonga almashtirsak, 2 oyoq qo'shiladi: 24 : 2 = <b>12</b> quyon.")}];
var P5=[function(){j2Lines([["17 tuya 🐪",C.blue,22],["katta o'g'il — 1/2",null,15],["o'rtancha — 1/3,  kenja — 1/9",null,15]]);j2Msg("Xalq masalasi: ota 17 tuyani shunday bo'lishni vasiyat qildi. 17 ning yarmi 8,5 — tuyani bo'lib bo'lmaydi!")},
 function(){j2Lines([["donishmand o'z tuyasini qo'shdi: 18",C.blue,16],["18 : 2 = 9,  18 : 3 = 6,  18 : 9 = 2",null,15],["9 + 6 + 2 = 17",C.ok,20]]);j2Msg("18 ta bo'lsa: 9, 6, 2 — jami 17. Bitta tuya ortib qoldi — donishmand o'zinikini qaytarib oldi!")}];
var P6=[function(){q21Sq(0);j2Msg("Al-Xorazmiyning o'z kitobidagi masala: «kvadrat va o'nta ildiz 39 ga teng». Ya'ni x² + 10x = 39.")},
 function(){q21Sq(1);j2Msg("10x ni ikkiga bo'lib, kvadratning ikki yoniga qo'yamiz: 5x va 5x. Burchakda bo'sh joy qoldi.")},
 function(){q21Sq(2);j2Msg("Bo'sh burchak 5 × 5 = 25. Uni qo'shsak — katta kvadrat: 39 + 25 = 64, tomoni 8. Demak x = 8 − 5 = <b>3</b>.")}];
var STEPS=[
{h:"Al-jabr va al-muqobala",sum:"x + 10 = 3x: ikkala tomondan x ni olib tashlaymiz → 10 = 2x → x = 5.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Al-Xorazmiyning mashhur kitobi «Al-jabr va al-muqobala» deb ataladi. <b>Al-muqobala</b> — ikkala tomondan bir xil narsani olib tashlash. Chizma bilan ko'ramiz.</p>",
 btns:[phaser(P1)],
 after:"<p>Tenglik — tarozi kabi: ikkala tomondan bir xil narsani olsak, muvozanat buzilmaydi. <b>Al-jabr</b> (tiklash) esa ayirilgan narsani boshqa tomonga qo'shish.</p>",
 q:{t:"Bir son 12 ga orttirilsa, o'zining 4 hissasiga teng bo'ladi. Son?",opts:["3","4","12","16"],ok:1,why:"x + 12 = 4x → 12 = 3x → x = 4.",hint:"Chizma: x + 12 va x + x + x + x. Ikkala tomondan bitta x ni oling.",full:"x + 12 = 4x. Ikkala tomondan x ni olsak: 12 = 3x → x = 4. Tekshirish: 4 + 12 = 16 = 4 · 4 ✓."},
 tn:"Chizma modelini kartondan kesilgan tasmalar bilan ko'rsating: bir xil tasmalarni ikkala qatordan oling."},
{h:"Misr: 7 uy, 49 mushuk",sum:"Rind papirusi 79-masalasi: 7, 49, 343, 2 401, 16 807 → yig'indi 19 607.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>3 600 yildan ko'proq yoshli masala! Qadimgi Misr kotibi Ahmes yozgan papirusda shunday zanjir bor.</p>",
 btns:[phaser(P2)],
 after:"<p>Har bosqichda 7 ga ko'paytiramiz — sonlar juda tez o'sadi. «Bitta uydan» boshlangan zanjir minglab donni «qutqaradi».</p>",
 q:{t:"7 ta uy, har uyda 7 ta mushuk, har mushuk 7 ta sichqon tutdi. Jami nechta sichqon?",opts:["21","343","49","147"],ok:1,why:"7 · 7 · 7 = 343.",hint:"Mushuklar: 7 · 7. Sichqonlar: mushuklar · 7.",full:"Mushuklar: 7 · 7 = 49. Sichqonlar: 49 · 7 = 343. «21» — 7 + 7 + 7, qo'shib yuborgan."},
 tn:"Zanjirni daraxt chizmasi bilan ko'rsating: 1 uy → 7 mushuk → 49 sichqon."},
{h:"Yuz g'oz masalasi",sum:"x + x + x/2 + x/4 + 1 = 100: 11 bo'lak = 99 → bo'lak 9, to'da 36.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Mashhur xalq masalasi. Kasrlar qo'rqitmasin — chizma model bilan oson yechiladi.</p>",
 btns:[phaser(P3)],
 after:"<p>Hiyla: to'dani shunday bo'laklarga bo'lamizki, yarmi va choragi butun bo'lsin (4 bo'lak). Keyin hammasi oddiy bo'lish.</p>",
 q:{t:"Savatdagi olmalar, yana shuncha, yana ularning yarmi va yana 2 ta — jami 52. Savatda nechta olma?",opts:["25","20","10","26"],ok:1,why:"2 + 2 + 1 = 5 bo'lak = 50 → bo'lak 10, savat 20.",hint:"Savatni 2 bo'lak deb oling (yarmi — 1 bo'lak).",full:"Savat = 2 bo'lak. 2 + 2 + 1 = 5 bo'lak va 2 ta = 52 → 5 bo'lak = 50 → 1 bo'lak = 10, savat = 20. Tekshirish: 20 + 20 + 10 + 2 = 52 ✓."},
 tn:"Chizma modelni rangli qog'oz tasmalar bilan quring — yarmi va choragi buklash orqali ko'rinadi."},
{h:"Tovuq va quyonlar",sum:"35 bosh, 94 oyoq: hammasi tovuq → 70; 24 ortiqcha oyoq : 2 = 12 quyon.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>1 500 yildan ortiq yoshli Xitoy masalasi. Usul — <b>faraz qilish</b>.</p>",
 btns:[phaser(P4)],
 after:"<p>«Hammasi bir xil deb faraz qil, keyin farqni tuzat» — juda kuchli usul. Xuddi shu usul tanga, chipta, mashina g'ildiraklari masalalarida ham ishlaydi.</p>",
 q:{t:"Hovlida tovuq va qo'ylar: 20 bosh, 56 oyoq. Qo'y nechta?",opts:["12","8","14","36"],ok:1,why:"20 · 2 = 40, 56 − 40 = 16, 16 : 2 = 8.",hint:"Hammasini tovuq deb oling. Nechta oyoq yetmaydi?",full:"Hammasi tovuq bo'lsa: 40 oyoq. 56 − 40 = 16 oyoq ortiq. Har qo'y 2 oyoq qo'shadi: 16 : 2 = 8 qo'y, 12 tovuq. Tekshirish: 8 · 4 + 12 · 2 = 32 + 24 = 56 ✓."},
 tn:"Bolalar o'zi rasmda 35 ta «bosh» chizib, avval hammasiga 2 oyoq, keyin qolganini 2 tadan qo'shib chiqsin."},
{h:"17 tuya meros",sum:"1/2, 1/3, 1/9 → 18 bilan: 9 + 6 + 2 = 17, bir tuya qaytariladi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Sharqda mashhur hikoya. Al-Xorazmiy kitobining katta qismi ham <b>meros</b> masalalariga bag'ishlangan.</p>",
 btns:[phaser(P5)],
 after:"<p>Sir: 1/2 + 1/3 + 1/9 = 17/18 — butun emas! Ota tuyalarning hammasini bo'lib bermagan, 1/18 qism ortib qolgan. Shuning uchun 18 bilan hammasi butun chiqadi va bitta ortadi.</p>",
 q:{t:"11 ta ot: o'g'illarga 1/2, 1/4 va 1/6 qismi. Qo'shnidan 1 ot olib bo'lishdi. Katta o'g'il nechta ot oldi?",opts:["5","6","3","2"],ok:1,why:"12 : 2 = 6, 12 : 4 = 3, 12 : 6 = 2 → 6 + 3 + 2 = 11.",hint:"12 ta otni 1/2, 1/4, 1/6 ga bo'ling.",full:"12 ta ot: 1/2 — 6, 1/4 — 3, 1/6 — 2. Jami 11, qo'shnining oti qaytariladi. Katta o'g'il — 6 ta."},
 tn:"Kasrlarni qo'shishni tekshirtiring: 1/2 + 1/3 + 1/9 = 9/18 + 6/18 + 2/18 = 17/18."},
{h:"Al-Xorazmiy kvadrati",sum:"x² + 10x = 39: 10x ni 5x + 5x qilib, burchakka 25 qo'shamiz → 64 = 8², x = 3.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bu — al-Xorazmiy kitobidagi haqiqiy misol. U uni <b>chizma bilan</b> — kvadrat va to'g'ri to'rtburchaklar yordamida yechgan. Kuzating!</p>",
 btns:[phaser(P6)],
 after:"<p>«Kvadratni to'ldirish» — al-Xorazmiyning mashhur usuli. Bugun ham maktabda (8-sinfda) shu g'oya o'rgatiladi. Siz uni 4-sinfda chizma bilan tushundingiz!</p>",
 q:{t:"Kvadratning yuzi va tomonining 6 hissasi yig'indisi 40 ga teng. Kvadratning tomoni?",opts:["5","4","7","10"],ok:1,why:"x² + 6x = 40: 3 × 3 = 9 qo'shamiz → 49 = 7², x = 7 − 3 = 4.",hint:"6x ni 3x va 3x ga bo'ling. Burchakda 3 × 3 qo'shiladi.",full:"6x → 3x + 3x, burchak 3 · 3 = 9. 40 + 9 = 49, katta kvadrat tomoni 7. x = 7 − 3 = 4. Tekshirish: 16 + 24 = 40 ✓. «7» — katta kvadratning tomoni, x emas."},
 tn:"Katakli qog'ozda 3 × 3 kvadrat va ikki 3 × 5 to'g'ri to'rtburchak qirqib, katta kvadrat yig'dirib ko'ring."},
{h:"Bilasizmi? Al-Xorazmiy",sum:"Muhammad ibn Muso al-Xorazmiy (taxm. 783–850) — algebra asoschisi; «algoritm» so'zi uning ismidan.",a:"m07",
 start:function(){j2Lines([["📚 al-Xorazmiy",C.blue,24],["«al-jabr» → algebra",null,17],["al-Xorazmiy → algoritm",null,17]]);j2Msg("Xorazm — Bag'dod, «Bayt ul-hikma»")},fin:function(){j2Lines([["📚 al-Xorazmiy",C.blue,24],["«al-jabr» → algebra",null,17],["al-Xorazmiy → algoritm",null,17]]);j2Msg("Xorazm — Bag'dod, «Bayt ul-hikma»")},
 html:"<p>📚 <b>Muhammad ibn Muso al-Xorazmiy</b> (taxminan 783–850) — Xorazmda tug'ilgan, Bag'doddagi «Bayt ul-hikma» (Donishmandlar uyi)da ishlagan olim. Uning «Al-jabr va al-muqobala» kitobidan <b>algebra</b> so'zi kelib chiqqan.</p><p>Hind raqamlari haqidagi kitobi lotin tiliga tarjima qilinib, Yevropaga o'nli sanoq tizimini olib kirgan. Uning ismi lotincha «Algoritmi» deb yozilgan — <b>algoritm</b> so'zi shundan.</p><p>Bizning loyiha — «Yosh Xorazmiylar» — ham uning nomi bilan atalgan!</p>",
 btns:[["📚 Faxrlanaman!",function(c,done){done()}]],
 tn:"Xiva shahridagi al-Xorazmiy haykali rasmini ko'rsating; bolalar uning hayoti haqida qisqa xabar tayyorlasin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["al-jabr · al-muqobala",C.blue,22]]);j2Msg("Asosiy usullar")},fin:function(){j2Lines([["al-jabr · al-muqobala",C.blue,22]]);j2Msg("Asosiy usullar")},
 html:"<div class='memo'><ul><li><b>Al-muqobala</b>: ikkala tomondan bir xil narsani olib tashlang (x + 10 = 3x → 10 = 2x).</li><li>Chizma model: noma'lumni bo'laklarga bo'ling (yarmi, choragi — butun bo'lsin).</li><li><b>Faraz usuli</b>: hammasi bir xil deb oling, farqni tuzating (tovuq–quyon).</li><li>Meros: kasrlar yig'indisi 1 ga teng bo'lmasa — hiyla bor.</li><li><b>Kvadratni to'ldirish</b>: x² + 10x = 39 → +25 → 64 → x = 3.</li><li>Har javobni shartga qo'yib tekshiring!</li></ul></div>",
 tn:"Uyga: oiladagi kattalardan bitta xalq masalasini so'rab, sinfga olib kelish."}
];
var PROBS=[
{t:"Bir son 12 ga orttirilsa, o'zining 4 hissasiga teng bo'ladi. Son?",o:["4","3","12","16"],k:0,s:"x + 12 = 4x → 12 = 3x → 4."},
{t:"Son va 10 ning yig'indisi sonning 3 hissasiga teng. Son?",o:["5","10","3","15"],k:0,s:"10 = 2x → 5."},
{t:"7 ta uy, har uyda 7 ta mushuk, har mushuk 7 ta sichqon tutdi. Jami nechta sichqon?",o:["343","21","49","147"],k:0,s:"7 · 7 · 7 = 343."},
{t:"7 + 49 + 343 = ?",o:["399","389","499","343"],k:0,s:"56 + 343 = 399."},
{t:"G'ozlar: «Biz, yana shuncha, yana yarmimiz, yana choragimiz va sen — 100». To'dada nechta g'oz?",o:["36","100","25","40"],k:0,s:"11 bo'lak = 99 → 9 · 4 = 36."},
{t:"Savatdagi olmalar, yana shuncha, yana ularning yarmi va yana 2 ta — jami 52. Savatda nechta?",o:["20","25","10","26"],k:0,s:"5 bo'lak = 50 → 20."},
{t:"Tovuq va qo'ylar: 20 bosh, 56 oyoq. Qo'y nechta?",o:["8","12","14","36"],k:0,s:"(56 − 40) : 2 = 8."},
{t:"Tovuq va quyonlar: 35 bosh, 94 oyoq. Quyon nechta?",o:["12","23","24","47"],k:0,s:"(94 − 70) : 2 = 12."},
{t:"17 tuya: 1/2, 1/3, 1/9. Donishmand 1 tuya qo'shdi. Kenja o'g'il (1/9) nechta tuya oldi?",o:["2","9","6","1"],k:0,s:"18 : 9 = 2."},
{t:"11 ta ot: 1/2, 1/4, 1/6 (qo'shnidan 1 ot qo'shib). Katta o'g'il nechta oldi?",o:["6","5","3","2"],k:0,s:"12 : 2 = 6."},
{t:"Al-Xorazmiy masalasi: x² + 10x = 39. x = ?",o:["3","5","8","39"],k:0,s:"39 + 25 = 64 = 8², x = 8 − 5."},
{t:"Kvadratning yuzi va tomonining 6 hissasi yig'indisi 40. Tomoni?",o:["4","5","7","10"],k:0,s:"40 + 9 = 49 = 7², x = 7 − 3."},
{t:"Ota 40 yoshda, o'g'li 10 yoshda. Necha yildan keyin ota o'g'lidan 3 marta katta bo'ladi?",o:["5","10","20","3"],k:0,s:"45 = 3 · 15."},
{t:"Uch aka-uka 30 ta olmani bo'lishdi: kattasi o'rtanchasidan 3 ta ko'p, o'rtanchasi kichigidan 3 ta ko'p. Kattasi nechta oldi?",o:["13","10","7","12"],k:0,s:"7 + 10 + 13 = 30."},
{t:"Bir yo'lovchi kuniga 20 km yuradi. Bir kundan keyin ikkinchisi xuddi shu joydan kuniga 30 km yurib ortidan chiqdi. Ikkinchisi necha kunda yetib oladi?",o:["2","3","1","6"],k:0,s:"Oraliq 20 km, har kuni 10 km qisqaradi."},
{t:"Hovuzni birinchi quvur 3 soatda, ikkinchisi 6 soatda to'ldiradi. Ikkalasi birga necha soatda to'ldiradi?",o:["2 soat","4,5 soat","9 soat","3 soat"],k:0,s:"1 soatda 1/3 + 1/6 = 1/2 hovuz."},
{t:"Bir odam pulining yarmini va yana 1 so'm sarfladi, 5 so'm qoldi. Avval qancha puli bor edi?",o:["12 so'm","10 so'm","11 so'm","8 so'm"],k:0,s:"Yarmi = 5 + 1 = 6 → 12."},
{t:"Qarg'alar har daraxtga bittadan qo'nsa, bitta qarg'a ortadi; ikkitadan qo'nsa, bitta daraxt bo'sh qoladi. Daraxt nechta?",o:["3","4","2","5"],k:0,s:"Qarg'a = d + 1 = 2 · (d − 1) → d = 3."},
{t:"«Mening yoshim va otamning yoshi birga 50 yil, otam mendan 30 yosh katta». Mening yoshim?",o:["10","20","40","15"],k:0,s:"(50 − 30) : 2 = 10."},
{t:"Al-Xorazmiy masalasi: 10 ni ikki bo'lakka bo'ling, biri ikkinchisidan 4 ta katta bo'lsin. Katta bo'lak?",o:["7","6","4","5"],k:0,s:"(10 + 4) : 2 = 7."}
];
function PRACT_STAGE(){q21Sq(2)}
var PREP_DATA={teach:["Al-jabr va al-muqobala — chizma bilan.","Qadimiy zanjir masalalari (Misr).","Chizma model: yarmi, choragi bilan.","Faraz usuli, meros masalasi, kvadratni to'ldirish."],
 mist:["Tenglikning faqat bir tomonidan ayiradi.","Kasrli bo'laklarni butun qilib olmaydi.","Faraz usulida farqni 2 ga bo'lishni unutadi.","Kvadratni to'ldirishda katta kvadrat tomonini javob deb oladi."],
 need:["Karton tasmalar (chizma model).","Katakli qog'oz, qaychi.","Al-Xorazmiy haykali yoki kitobi rasmi."],
 board:["<span class='w2'>x + 10 = 3x → 10 = 2x → 5</span>.","<span class='w2'>7 → 49 → 343</span>.","<span class='w2'>11 bo'lak = 99 → 36</span>.","<span class='w2'>(94 − 70) : 2 = 12</span>.","<span class='w2'>39 + 25 = 64 → x = 3</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
