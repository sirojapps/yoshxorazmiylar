var CODE='3Y4',TITLE='3-sinf · Yuz, hajm va yoyilmalarga oid nostandart masalalar';
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli shakl: cells — [ustun, qator] ro'yxati
function y4cells(g,x0,y0,s,cells,o){o=o||{};cells.forEach(function(c){E('rect',{x:x0+c[0]*s,y:y0+c[1]*s,width:s,height:s,fill:(o.fill&&o.fill(c))||'#ffe2b8',stroke:'#c08a4a','stroke-width':1},g)})}
function y4dim(g,x,y,t,col){T(g,x,y,t,{'font-size':11,'font-weight':800,fill:col||C.blue})}
function y4rect(w,h){var a=[];for(var r=0;r<h;r++)for(var c=0;c<w;c++)a.push([c,r]);return a}
// 1) L shakl
var Y4L=y4rect(6,4).filter(function(c){return !(c[0]>=4&&c[1]<2)});
var P1=[function(){clear();var g=S.g;y4cells(g,126,30,18,Y4L);y4dim(g,180,150,'6 sm');y4dim(g,108,70,'4 sm');y4dim(g,216,24,'2 sm');y4dim(g,250,52,'2 sm');y4msg('Bu shaklning yuzi qancha? (1 katak = 1 sm²)')},
 function(){clear();var g=S.g;y4cells(g,126,30,18,Y4L,{fill:function(c){return c[0]<4?'#cfe3f6':'#d7f0dc'}});E('line',{x1:198,y1:66,x2:198,y2:102,stroke:C.bad,'stroke-width':3,'stroke-dasharray':'5 3'},g);T(g,162,70,'4 × 4 = 16',{'font-size':12,'font-weight':800,fill:C.blue});T(g,216,124,'2 × 2',{'font-size':11,'font-weight':800,fill:C.ok});calc(['1-usul: bo‘laklarga ajratamiz','16 + 4 = <b>20 sm²</b>'])},
 function(){clear();var g=S.g;y4cells(g,126,30,18,Y4L);E('rect',{x:198,y:30,width:36,height:36,fill:'rgba(217,75,75,.12)',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);T(g,216,52,'−4',{'font-size':12,'font-weight':800,fill:C.bad});y4dim(g,180,150,'6 × 4 = 24');calc(['2-usul: butun to‘rtburchakdan kesilganini ayiramiz','24 − 4 = <b>20 sm²</b>'])}];
// 2) yuzi bir xil, perimetri har xil
function y4per(w,h){clear();var g=S.g;var s=Math.min(18,Math.floor(300/w));var x0=180-w*s/2,y0=80-h*s/2;y4cells(g,x0,y0,s,y4rect(w,h));y4dim(g,180,y0+h*s+16,w+' sm');T(g,x0-20,y0+h*s/2+4,h+' sm',{'font-size':11,'font-weight':800,fill:C.blue});calc([w+' × '+h+' = <b>'+(w*h)+' sm²</b>','P = 2 · ('+w+' + '+h+') = <b>'+(2*(w+h))+' sm</b>'])}
// 3) kesib ko'chirish
var Y4Q=y4rect(4,4),Y4M=y4rect(2,4).concat([[2,2],[3,2],[2,3],[3,3],[4,2],[5,2],[4,3],[5,3]]);
var P3=[function(){clear();var g=S.g;y4cells(g,140,26,20,Y4Q,{fill:function(c){return c[0]>=2&&c[1]<2?'#f9d0d0':'#ffe2b8'}});y4msg('Kvadrat 4 × 4: yuz 16 sm², perimetr 16 sm. Qizil bo‘lakni kesamiz')},
 function(){clear();var g=S.g;y4cells(g,100,26,20,Y4M,{fill:function(c){return c[0]>=4?'#f9d0d0':'#ffe2b8'}});E('path',{d:'M170 40 q50 -10 52 40',fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);y4msg('Bo‘lakni pastga, o‘ngga yopishtirdik')},
 function(){clear();var g=S.g;y4cells(g,100,26,20,Y4M,{fill:function(c){return c[0]>=4?'#f9d0d0':'#ffe2b8'}});y4dim(g,160,126,'6 sm');calc(['Yuz: kataklar soni o‘zgarmadi — <b>16 sm²</b>','Perimetr: 6 + 4 + 6 + 4 = <b>20 sm</b> (16 emas!)'])}];
// 4) paletka
function y4in(x,y){return Math.pow((x-180)/70,2)+Math.pow((y-92)/50,2)<1}
function y4kind(c){var x=100+c[0]*16,y=36+c[1]*16;var k=[[x,y],[x+16,y],[x,y+16],[x+16,y+16]].filter(function(p){return y4in(p[0],p[1])}).length;if(k===4)return 2;for(var a=0;a<=8;a++)for(var b=0;b<=8;b++)if(y4in(x+a*2,y+b*2))return 1;return 0}
function y4pal(mode){clear();var g=S.g;var nf=0,np=0;y4rect(10,7).forEach(function(c){var k=y4kind(c);if(k===2)nf++;if(k===1)np++;E('rect',{x:100+c[0]*16,y:36+c[1]*16,width:16,height:16,fill:(mode>=1&&k===2)?'#cfe9d6':((mode>=2&&k===1)?'#fff0b8':'#fff'),stroke:'#b8c4d0','stroke-width':1},g)});
 E('ellipse',{cx:180,cy:92,rx:70,ry:50,fill:'rgba(31,111,178,.10)',stroke:C.blue,'stroke-width':3},g);T(g,180,24,'Ko‘l (1 katak = 1 sm²)',{'font-size':11,'font-weight':800,fill:C.blue});return [nf,np]}
var P4=[function(){y4pal(0);y4msg('Ko‘lning chegarasi egri — kataklar to‘liq sig‘maydi')},
 function(){var n=y4pal(1);calc(['To‘liq kataklar (yashil): <b>'+n[0]+'</b>'])},
 function(){var n=y4pal(2);calc(['To‘liq: '+n[0]+', chala kataklar (sariq): <b>'+n[1]+'</b>'])},
 function(){var n=y4pal(2);calc(['Chala kataklarni yarimta deb olamiz: '+n[1]+' : 2 = '+(n[1]/2),'Yuz ≈ '+n[0]+' + '+(n[1]/2)+' = <b>'+(n[0]+n[1]/2)+' sm²</b>'])}];
// izometrik kublar
function y4P(i,j,k,o){return [o.x+(i-j)*o.s*.866,o.y+(i+j)*o.s*.5-k*o.s]}
function y4cube(g,i,j,k,o,col){col=col||{t:'#ffe2b8',r:'#f0a040',l:'#f7c27a'};var f=function(a){return a.map(function(p){var q=y4P(p[0],p[1],p[2],o);return q[0].toFixed(1)+','+q[1].toFixed(1)}).join(' ')};
 E('polygon',{points:f([[i,j,k+1],[i+1,j,k+1],[i+1,j+1,k+1],[i,j+1,k+1]]),fill:col.t,stroke:'#8a5a24','stroke-width':1},g);
 E('polygon',{points:f([[i+1,j,k],[i+1,j+1,k],[i+1,j+1,k+1],[i+1,j,k+1]]),fill:col.r,stroke:'#8a5a24','stroke-width':1},g);
 E('polygon',{points:f([[i,j+1,k],[i+1,j+1,k],[i+1,j+1,k+1],[i,j+1,k+1]]),fill:col.l,stroke:'#8a5a24','stroke-width':1},g)}
function y4cubes(g,list,o,colf){list.slice().sort(function(a,b){return (a[0]+a[1]+a[2])-(b[0]+b[1]+b[2])}).forEach(function(c){y4cube(g,c[0],c[1],c[2],o,colf?colf(c):null)})}
var Y4BL=[],Y4TP=[];for(var i=0;i<3;i++)for(var j=0;j<2;j++){Y4BL.push([i,j,0]);if(!(j===0&&i>0))Y4TP.push([i,j,1])}
var Y4HI={t:'#cfe3f6',r:'#5aa9e6',l:'#9ccbee'},Y4HI2={t:'#d7f0dc',r:'#3fae74',l:'#8fd3a8'};
var P5=[function(){clear();y4cubes(S.g,Y4BL.concat(Y4TP),{x:170,y:70,s:24});y4msg('Shakl nechta kubchadan yasalgan? Orqadagilarni ham o‘ylang')},
 function(){clear();y4cubes(S.g,Y4BL.concat(Y4TP),{x:170,y:70,s:24},function(c){return c[2]===0?Y4HI:null});calc(['Pastki qatlam: 3 × 2 = <b>6</b> kub (biri ko‘rinmaydi!)'])},
 function(){clear();y4cubes(S.g,Y4BL.concat(Y4TP),{x:170,y:70,s:24},function(c){return c[2]===1?Y4HI2:Y4HI});calc(['Pastki qatlam: 6 kub','Ustki qatlam: <b>4</b> kub'])},
 function(){clear();y4cubes(S.g,Y4BL.concat(Y4TP),{x:170,y:70,s:24},function(c){return c[2]===1?Y4HI2:Y4HI});calc(['Hajm qatlamlab sanaladi: 6 + 4 = <b>10</b> kub','Butun 3 × 2 × 2 = 12 bo‘lardi, 2 tasi yo‘q: 12 − 2 = 10'])}];
// bo'yalgan kub
var Y4K=[];for(var a=0;a<3;a++)for(var b=0;b<3;b++)for(var c=0;c<3;c++)Y4K.push([a,b,c]);
function y4ext(c){return c.filter(function(v){return v===0||v===2}).length}
var Y4CAT={3:{t:'#f9d0d0',r:'#d94b4b',l:'#ef8f8f'},2:{t:'#cfe3f6',r:'#2f6fb5',l:'#7fb3e6'},1:{t:'#d7f0dc',r:'#1e8e5a',l:'#79c79a'}};
function y4paint(cat){clear();var g=S.g;y4cubes(g,Y4K,{x:130,y:88,s:22},function(c){return cat&&y4ext(c)===cat?Y4CAT[cat]:{t:'#fff3e0',r:'#e8c49a',l:'#f3dcbf'}});
 var n={3:8,2:12,1:6};T(g,280,40,'3 × 3 × 3 = 27',{'font-size':12,'font-weight':800,fill:'#33475b'});if(cat)T(g,280,90,n[cat]+' ta',{'font-size':22,'font-weight':800,fill:Y4CAT[cat].r})}
var P6=[function(){y4paint(0);y4msg('Kub sirti bo‘yaldi va 27 kubchaga kesildi')},
 function(){y4paint(3);calc(['Uchlardagi kubchalar — <b>3 tomoni</b> bo‘yalgan','Kubda 8 ta uch → <b>8</b> ta'])},
 function(){y4paint(2);calc(['Qirralar o‘rtasidagilar — <b>2 tomoni</b> bo‘yalgan','Kubda 12 ta qirra, har birida 1 ta → <b>12</b> ta'])},
 function(){y4paint(1);calc(['Yoqlar markazidagilar — <b>1 tomoni</b> bo‘yalgan → <b>6</b> ta','Ichkarida bitta kubcha <b>bo‘yalmagan</b>: 27 − 8 − 12 − 6 = 1'])}];
// kub yoyilmasi: [ustun, qator]
var Y4N=[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]],Y4OPP={'1,1':'3,1','1,0':'1,2','0,1':'2,1'};
function y4net(){clear();var g=S.g;var s=36,x0=108,y0=12;var f=S.f7||{};
 Y4N.forEach(function(c){var key=c[0]+','+c[1];var gg=E('g',{style:'cursor:pointer'},g);
  var fill=key===S.mk7?'#ffd24d':(f[key]?'#cfe9d6':'#fff');E('rect',{x:x0+c[0]*s,y:y0+c[1]*s,width:s,height:s,fill:fill,stroke:'#8a5a24','stroke-width':2},gg);
  if(key===S.mk7)T(gg,x0+c[0]*s+s/2,y0+c[1]*s+s/2+6,'★',{'font-size':18,fill:'#8a5a24'});if(f[key])T(gg,x0+c[0]*s+s/2,y0+c[1]*s+s/2+6,'✓',{'font-size':18,'font-weight':800,fill:C.ok});
  gg.addEventListener('click',function(){y4t7(key)})})}
function y4t7(key){if(!S.d7)return;var want=Y4OPP[S.mk7];if(key===S.mk7){y4msg('Bu ★ ning o‘zi. Qarshisidagi yoqni toping');return}
 if(key!==want){y4msg('Bu yoq ★ ga <b>qo‘shni</b> — kub yig‘ilganda ular bitta qirrada tutashadi');return}
 S.f7=S.f7||{};S.f7[key]=1;S.n7=(S.n7||0)+1;
 if(S.n7===1){S.mk7='1,0';S.f7={};y4net();y4msg('To‘g‘ri! Endi yangi ★ — tepadagi yoqning qarshisini bosing')}
 else{y4net();y4msg('To‘g‘ri! Qarama-qarshi yoqlar yoyilmada <b>yonma-yon turmaydi</b>');var d=S.d7;S.d7=null;d()}}
// quti va uning yoyilmasi
function y4box(st){clear();var g=S.g;var bl=[];for(var i=0;i<3;i++)for(var j=0;j<2;j++)bl.push([i,j,0]);y4cubes(g,bl,{x:80,y:70,s:22});
 T(g,60,150,'3 × 2 × 1 dm',{'font-size':11,'font-weight':800,fill:'#33475b'});
 if(st<1)return;var s=14,x0=210,y0=20;var parts=[[1,0,3,1,'3'],[0,1,1,2,'2'],[1,1,3,2,'6'],[4,1,1,2,'2'],[1,3,3,1,'3'],[1,4,3,2,'6']];
 parts.forEach(function(p){E('rect',{x:x0+p[0]*s,y:y0+p[1]*s,width:p[2]*s,height:p[3]*s,fill:p[4]==='6'?'#ffe2b8':(p[4]==='3'?'#cfe3f6':'#d7f0dc'),stroke:'#8a5a24','stroke-width':1.5},g);if(st>=2)T(g,x0+(p[0]+p[2]/2)*s,y0+(p[1]+p[3]/2)*s+4,p[4],{'font-size':11,'font-weight':800,fill:'#33475b'})})}
var P8=[function(){y4box(0);y4msg('Qutining sirtini o‘rash uchun qancha qog‘oz kerak?')},function(){y4box(1);y4msg('Qutini «ochamiz» — 6 ta yoqdan iborat yoyilma')},
 function(){y4box(2);calc(['Juft-juft teng yoqlar: 6 + 6, 3 + 3, 2 + 2','Sirt: 2 · (6 + 3 + 2) = <b>22 dm²</b>'])}];
var STEPS=[
{h:"Murakkab shakl yuzi: ikki usul",sum:"Shaklni bo'laklarga ajratamiz yoki butun to'rtburchakdan ortiqchasini ayiramiz.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Shakl to'g'ri to'rtburchak emas — formulani to'g'ridan-to'g'ri qo'llab bo'lmaydi. Ikki xil yo'l bilan yechamiz:</p>",
 btns:[phaser(P1)],
 after:"<p><b>1-usul</b>: bo'laklarga ajratish — 16 + 4 = 20. <b>2-usul</b>: to'ldirib ayirish — 24 − 4 = 20. Ikkala yo'l bir xil javob beradi — bu <b>tekshirish</b> usuli ham. Yuz sm² da, uzunlik sm da o'lchanadi.</p>",
 q:{t:"8 sm × 5 sm li to'g'ri to'rtburchakning burchagidan 3 sm × 2 sm li bo'lak kesib olindi. Qolgan shaklning yuzi?",opts:["34 sm²","40 sm²","26 sm²","46 sm²"],ok:0,why:"40 − 6 = 34.",hint:"Butun yuzdan kesilgan bo'lak yuzini ayiring.",full:"Butun: 8 · 5 = 40 sm², kesilgan: 3 · 2 = 6 sm², qolgan: 40 − 6 = 34 sm². 26 — bu to'rtburchak perimetri (2 · 13), yuz emas! 46 — ayirish o'rniga qo'shish."},
 tn:"Katakli qog'ozda shakl chizdiring va qaychi bilan kesdirib, bo'laklarni sanating (Singapur CPA: qog'oz → rasm → hisob)."},
{h:"Yuz bir xil — perimetr har xil",sum:"12 ta kvadratdan har xil to'rtburchak yasash mumkin: yuz 12 sm², perimetr esa turlicha.",a:"m02",
 start:function(){y4per(4,3)},fin:function(){y4per(12,1)},
 html:"<p>12 ta 1 sm² li kvadratcha bor. Ulardan uch xil to'g'ri to'rtburchak yasang va har birining perimetrini solishtiring:</p>",
 btns:[["4 × 3",function(c,done){y4per(4,3);mvK(done,3)}],["6 × 2",function(c,done){y4per(6,2);mvK(done,3)}],["12 × 1",function(c,done){y4per(12,1);mvK(done,3)}]],g3:1,
 after:"<p>Uchalasining <b>yuzi bir xil</b> — 12 sm². Perimetrlari esa: 14 sm, 16 sm, 26 sm. Shakl <b>cho'zilgan</b> sari perimetr ortadi, <b>kvadratga yaqin</b> bo'lsa — eng kichik bo'ladi. Yuz va perimetr — boshqa-boshqa narsalar!</p>",
 q:{t:"Ikki to'g'ri to'rtburchak: 2 sm × 8 sm va 4 sm × 4 sm. Qaysi gap to'g'ri?",opts:["Yuzlari teng, perimetrlari har xil","Perimetrlari ham teng","4 × 4 ning perimetri kattaroq","Ikkalasining yuzi 20 sm²"],ok:0,why:"Yuz: 16 va 16; perimetr: 20 va 16.",hint:"Har birining yuzi va perimetrini alohida hisoblang.",full:"2 · 8 = 16 va 4 · 4 = 16 — yuzlar teng. Perimetr: 2 · (2 + 8) = 20 sm va 2 · (4 + 4) = 16 sm — har xil. Cho'zilgani (2 × 8) ning perimetri katta."},
 tn:"Bolalarga 12 ta kvadrat kartochka bering — barcha to'rtburchaklarni o'zlari topsin va jadvalga yozsin (yapon usuli: bola o'zi kashf qiladi)."},
{h:"Kesib ko'chirsak nima o'zgaradi?",sum:"Bo'lakni kesib boshqa joyga qo'ysak yuz o'zgarmaydi, perimetr o'zgarishi mumkin.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>4 × 4 kvadratdan 2 × 2 bo'lakni kesib, boshqa joyga yopishtiramiz:</p>",
 btns:[phaser(P3)],
 after:"<p>Kataklar soni o'zgarmadi — <b>yuz 16 sm²</b> qoldi. Lekin chegara uzaydi: <b>perimetr 16 sm dan 20 sm ga</b> oshdi. «Yuz bir xil bo'lsa, perimetr ham bir xil» — noto'g'ri fikr.</p>",
 q:{t:"Kvadratdan uchburchak bo'lak kesib, uni qarama-qarshi tomonga yopishtirdik. Shakl yuzi qanday o'zgaradi?",opts:["O'zgarmaydi","Ortadi","Kamayadi","Ikki marta ortadi"],ok:0,why:"Hech narsa qo'shilmadi va olib tashlanmadi.",hint:"Qog'oz miqdori o'zgardimi?",full:"Bo'lak faqat ko'chirildi — qog'oz miqdori bir xil, demak yuz o'zgarmaydi. Perimetr esa o'zgarishi mumkin."},
 tn:"Qog'oz kvadratdan bo'lak kesib, yopishtirib ko'rsating; ip bilan perimetrni o'lchang."},
{h:"Egri chegarali shakl: paletka",sum:"To'liq kataklar + chala kataklarning yarmi ≈ yuz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Ko'lning yuzini paletka (katakli shaffof varaq) yordamida taxminan topamiz:</p>",
 btns:[phaser(P4)],
 after:"<p>Qoida: <b>to'liq kataklar</b> soni + <b>chala kataklar</b> sonining <b>yarmi</b>. Bu yerda 28 + 30 : 2 = <b>43 sm²</b> (aniq qiymat taxminan 43 ga teng). Kataklar qancha mayda bo'lsa, natija shuncha aniq.</p>",
 q:{t:"Paletkada shakl ichida 14 ta to'liq va 8 ta chala katak bor (1 katak = 1 sm²). Yuz taxminan qancha?",opts:["18 sm²","22 sm²","14 sm²","30 sm²"],ok:0,why:"14 + 8 : 2 = 18.",hint:"Chala kataklar soni ikkiga bo'linadi.",full:"14 + 8 : 2 = 14 + 4 = 18 sm². 22 — chala kataklarni to'liq hisoblash, 14 — chalalarni tashlab yuborish, 30 — chalalarni ikki marta hisoblash."},
 tn:"Shaffof faylga katak chizib paletka yasang. Bolalar kaftini qog'ozga chizib, yuzini paletka bilan topsin."},
{h:"Kublardan shakl hajmi",sum:"Hajmni qatlamlab sanaymiz; ko'rinmaydigan kublarni unutmang.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Shakl 1 sm³ li kubchalardan yasalgan. Nechta kubcha bor? Faqat ko'ringanlarini sanash — xato!</p>",
 btns:[phaser(P5)],
 after:"<p>Hajmni <b>qatlam-qatlam</b> sanaymiz: pastki 6 + ustki 4 = <b>10 sm³</b>. Pastki qatlamda bitta kub ustidagi kub ortida yashiringan — u ham hisobga olinadi (aks holda ustki kub havoda osilib qolardi!).</p>",
 q:{t:"Pastki qatlamda 3 × 3 = 9 kub, ustida yana 2 ta shunday qatlam bor, lekin eng ustki qatlamda 2 ta kub yo'q. Jami nechta kub?",opts:["25","27","23","21"],ok:0,why:"9 · 3 − 2 = 25.",hint:"Avval to'liq kubni hisoblang, keyin yo'qlarini ayiring.",full:"To'liq bo'lsa: 9 + 9 + 9 = 27. 2 ta yo'q: 27 − 2 = 25. 23 — 4 tasini ayirish, 21 — 9 + 9 + 3."},
 tn:"Konstruktor yoki gugurt qutilaridan shakl yig'ib, bolalar qatlam-qatlam sanasin. So'ng shaklni buzib, sanalganini tekshiring."},
{h:"Bo'yalgan kub",sum:"3 × 3 × 3 kubda: 8 ta kubchaning 3 tomoni, 12 tasining 2 tomoni, 6 tasining 1 tomoni bo'yalgan, 1 tasi bo'yalmagan.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Katta kubning sirti bo'yaldi va u 27 ta kubchaga kesildi. Nechta kubchaning nechta tomoni bo'yalgan?</p>",
 btns:[phaser(P6)],
 after:"<p>Kubning <b>uchlari</b> 8 ta → 3 tomoni bo'yalgan kubchalar 8 ta. <b>Qirralari</b> 12 ta → 2 tomoni bo'yalgan 12 ta. <b>Yoqlari</b> 6 ta → 1 tomoni bo'yalgan 6 ta. Ichkarida <b>1</b> ta bo'yalmagan. Tekshiramiz: 8 + 12 + 6 + 1 = 27 ✓.</p>",
 q:{t:"2 × 2 × 2 kubning sirti bo'yalib, 8 ta kubchaga kesildi. Nechta kubcha umuman bo'yalmagan?",opts:["0","1","8","4"],ok:0,why:"Har bir kubcha katta kubning uchida turadi.",hint:"2 × 2 × 2 kubda «ichki» kubcha bormi?",full:"2 × 2 × 2 kubda 8 ta kubchaning hammasi uchlarda — har birining 3 tomoni bo'yalgan. Ichkarida kubcha yo'q, javob 0. «1» — 3 × 3 × 3 kub bilan adashtirish."},
 tn:"Rubik kubi yoki 27 ta kubchadan yig'ilgan kubni ko'rsating; burchak, qirra, markaz kubchalarini rangli stikerlar bilan belgilang."},
{h:"Kub yoyilmasi: qarama-qarshi yoqlar",sum:"Yoyilmada qarama-qarshi yoqlar hech qachon yonma-yon turmaydi.",a:"m07",
 start:function(){S.mk7='1,1';S.f7={};S.n7=0;y4net();y4msg('Kub yig‘ilganda ★ ning qarshisida qaysi yoq turadi? Bosing')},fin:function(){S.mk7='1,0';S.f7={'1,2':1};y4net();y4msg('Qarama-qarshi yoqlar yonma-yon turmaydi')},
 act:function(c,done){S.d7=done},
 html:"<p>Kubning yoyilmasi. Uni xayolan yig'ing va <b>★ yoqning qarshisidagi</b> yoqni bosing. Keyin yana bitta topshiriq bo'ladi.</p>",
 after:"<p>Yoyilmaning uzun qatorida <b>bitta oraliq qoldirib</b> turgan yoqlar qarama-qarshi bo'ladi. ★ ga tutashgan yoqlar — <b>qo'shni</b>. Har bir yoqning 4 ta qo'shnisi va 1 ta qarshisi bor. O'yin zarida qarama-qarshi yoqlar yig'indisi doim <b>7</b>.</p>",
 q:{t:"O'yin zarida qarama-qarshi yoqlardagi sonlar yig'indisi 7 ga teng. 2 ning qarshisida qaysi son?",opts:["5","3","4","6"],ok:0,why:"2 + 5 = 7.",hint:"2 ga qaysi sonni qo'shsak 7 bo'ladi?",full:"Qarama-qarshi yoqlar: 1 va 6, 2 va 5, 3 va 4. Demak, 2 ning qarshisida 5."},
 tn:"Yoyilmani qog'ozdan kesib, kub yig'dirib ko'ring. Qarama-qarshi yoqlarni bir xil rangga bo'yating."},
{h:"Quti sirti: yoyilma yuzi",sum:"Parallelepiped sirti = 2 · (birinchi + ikkinchi + uchinchi yoq yuzi).",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>3 dm × 2 dm × 1 dm li qutini qog'oz bilan o'ramoqchimiz. Eng kami necha dm² qog'oz kerak?</p>",
 btns:[phaser(P8)],
 after:"<p>Qutining 6 ta yog'i <b>juft-juft teng</b>: 3 · 2 = 6 (ikkita), 3 · 1 = 3 (ikkita), 2 · 1 = 2 (ikkita). Sirt: <b>2 · (6 + 3 + 2) = 22 dm²</b>. Hajm esa boshqa: 3 · 2 · 1 = 6 dm³ — sirt bilan adashtirmang!</p>",
 q:{t:"3 dm × 2 dm × 1 dm li qutining sirtini o'rash uchun nima uchun 11 dm² yetmaydi?",opts:["Har bir yoq ikkitadan bor: 2 · 11 = 22","11 dm² — hajm","Qutining 3 ta yog'i bor","Qog'oz yetarli, 11 to'g'ri"],ok:0,why:"6 + 3 + 2 = 11 — faqat uchta yoq.",hint:"Qutining nechta yog'i bor?",full:"6 + 3 + 2 = 11 dm² — bu faqat 3 ta yoq. Qutida 6 ta yoq bor, har biri juft: 2 · 11 = 22 dm². Hajm esa 6 dm³."},
 tn:"Bo'sh qutini (masalan, choy qutisini) yelim joylaridan ochib, yoyilmasini doskaga yopishtiring."},
{h:"Bilasizmi?",sum:"Kubning 11 xil yoyilmasi bor; Rubik kubi 1974-yilda ixtiro qilingan.",a:"m09",
 start:function(){y4paint(0)},fin:function(){y4paint(0)},
 html:"<p>🧊 Kubni <b>11 xil</b> yoyilma ko'rinishida ochish mumkin — boshqa barcha 6 kvadratli shakllardan kub yig'ib bo'lmaydi.</p><p>🎲 Mashhur <b>Rubik kubini</b> 1974-yilda vengriyalik me'mor va o'qituvchi <b>Erno Rubik</b> ixtiro qilgan. U 3 × 3 × 3 kubdan iborat — xuddi biz bo'yagan kub kabi.</p><p>💧 1 dm³ hajmli idishga roppa-rosa <b>1 litr</b> suv sig'adi.</p>",
 tn:"Bolalar 6 kvadratdan iborat turli shakllar chizsin va qaysilaridan kub yig'ilishini qaychi bilan tekshirsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){y4paint(0)},fin:function(){y4paint(0)},
 html:"<div class='memo'><ul><li>Murakkab shakl: <b>bo'laklarga ajrating</b> yoki <b>to'ldirib ayiring</b>.</li><li>Yuz (sm²) va perimetr (sm) — har xil: yuz bir xil bo'lsa ham perimetr har xil bo'lishi mumkin.</li><li>Kesib ko'chirsak yuz o'zgarmaydi.</li><li>Paletka: to'liq kataklar + chala kataklar : 2.</li><li>Hajm: qatlamlab sanang, yashirin kublarni unutmang.</li><li>3 × 3 × 3 bo'yalgan kub: 8 | 12 | 6 | 1.</li><li>Yoyilmada qarama-qarshi yoqlar yonma-yon turmaydi.</li><li>Quti sirti = 2 · (yoqlar yuzlari yig'indisi).</li></ul></div>",
 tn:"Uyga vazifa: uydagi qutining o'lchamlarini o'lchab, sirt va hajmini hisoblash."}
];
var PROBS=[
{t:"Kubning nechta qirrasi bor?",o:["12","6","8","24"],k:0,s:"Kubda 6 yoq, 8 uch, 12 qirra."},
{t:"1 dm² necha sm² ga teng?",o:["100 sm²","10 sm²","1000 sm²","40 sm²"],k:0,s:"10 sm × 10 sm = 100 sm²."},
{t:"Perimetri 16 sm bo'lgan kvadratning yuzi qancha?",o:["16 sm²","64 sm²","8 sm²","4 sm²"],k:0,s:"Tomoni 16 : 4 = 4 sm, yuzi 4 · 4 = 16 sm²."},
{t:"Yuzi 36 sm² bo'lgan kvadratning perimetri qancha?",o:["24 sm","36 sm","18 sm","9 sm"],k:0,s:"Tomoni 6 sm, perimetr 4 · 6 = 24 sm."},
{t:"6 sm × 4 sm li to'g'ri to'rtburchakdan 2 sm × 2 sm li kvadrat kesib olindi. Qolgan shakl yuzi?",o:["20 sm²","24 sm²","16 sm²","22 sm²"],k:0,s:"24 − 4 = 20 sm²."},
{t:"Tomoni 3 sm bo'lgan ikki kvadrat yonma-yon qo'yilib, to'g'ri to'rtburchak hosil qilindi. Uning perimetri?",o:["18 sm","24 sm","12 sm","36 sm"],k:0,s:"6 sm × 3 sm: 2 · (6 + 3) = 18 sm."},
{t:"12 ta 1 sm² li kvadratchadan to'g'ri to'rtburchak yasaldi. Uning perimetri eng ko'pi bilan qancha bo'lishi mumkin?",o:["26 sm","14 sm","16 sm","24 sm"],k:0,s:"1 × 12: 2 · (1 + 12) = 26 sm."},
{t:"12 ta 1 sm² li kvadratchadan to'g'ri to'rtburchak yasaldi. Uning perimetri eng kami bilan qancha bo'lishi mumkin?",o:["14 sm","16 sm","26 sm","12 sm"],k:0,s:"3 × 4: 2 · (3 + 4) = 14 sm."},
{t:"Xona poli 5 m × 4 m. 1 m² ga 4 ta plitka ketadi. Jami nechta plitka kerak?",o:["80","20","40","18"],k:0,s:"5 · 4 = 20 m², 20 · 4 = 80."},
{t:"Qirrasi 3 sm bo'lgan kubning hajmi?",o:["27 sm³","9 sm³","18 sm³","12 sm³"],k:0,s:"3 · 3 · 3 = 27 sm³."},
{t:"4 sm × 3 sm × 2 sm li parallelepiped nechta 1 sm³ li kubchadan iborat?",o:["24","9","12","52"],k:0,s:"4 · 3 · 2 = 24."},
{t:"Qirrasi 2 sm bo'lgan kubning sirti (barcha yoqlari yuzlari yig'indisi)?",o:["24 sm²","8 sm²","16 sm²","12 sm²"],k:0,s:"Bir yoq 4 sm², 6 ta yoq: 24 sm²."},
{t:"Zarda qarama-qarshi yoqlar yig'indisi 7. 1 ning qarshisida qaysi son?",o:["6","2","5","3"],k:0,s:"1 + 6 = 7."},
{t:"3 × 3 × 3 kubning sirti bo'yalib, 27 kubchaga kesildi. 3 tomoni bo'yalgan kubchalar nechta?",o:["8","12","6","27"],k:0,s:"Uchlardagilar — 8 ta."},
{t:"3 × 3 × 3 kubning sirti bo'yalib, 27 kubchaga kesildi. 2 tomoni bo'yalgan kubchalar nechta?",o:["12","8","6","24"],k:0,s:"Har qirraning o'rtasida 1 ta: 12 ta."},
{t:"3 × 3 × 3 kubning sirti bo'yalib, 27 kubchaga kesildi. Bo'yalmagan kubchalar nechta?",o:["1","0","6","9"],k:0,s:"Faqat markazdagi bitta."},
{t:"Kubning barcha qirralari uzunliklari yig'indisi 48 sm. Kubning hajmi?",o:["64 sm³","48 sm³","16 sm³","96 sm³"],k:0,s:"Qirra 48 : 12 = 4 sm, hajm 4 · 4 · 4 = 64 sm³."},
{t:"To'g'ri to'rtburchakning bo'yi ham, eni ham 2 marta oshirildi. Yuzi necha marta oshadi?",o:["4 marta","2 marta","8 marta","6 marta"],k:0,s:"2 · 2 = 4 marta."},
{t:"Kubning qirrasi 2 marta oshirildi. Hajmi necha marta oshadi?",o:["8 marta","2 marta","4 marta","6 marta"],k:0,s:"2 · 2 · 2 = 8 marta."},
{t:"Akvarium o'lchamlari 2 dm × 3 dm × 4 dm. Unga necha litr suv sig'adi? (1 dm³ = 1 litr)",o:["24 litr","9 litr","12 litr","48 litr"],k:0,s:"2 · 3 · 4 = 24 dm³ = 24 litr."}
];
function PRACT_STAGE(){y4paint(0)}
var PREP_DATA={teach:["Murakkab shakl yuzi: ajratish va to'ldirib ayirish.","Yuz va perimetr farqi: yuz bir xil — perimetr har xil.","Paletka bilan egri shakl yuzini taxminlash.","Kublardan shakl hajmi, bo'yalgan kub masalasi.","Kub yoyilmasi, qarama-qarshi yoqlar; quti sirti."],
 mist:["Yuz va perimetrni adashtiradi (26 sm ni yuz deb yozadi).","Ko'rinmaydigan (orqadagi) kublarni sanamaydi.","Quti sirtida faqat 3 ta yoqni hisoblaydi.","Paletkada chala kataklarni to'liq sanaydi.","Yoyilmada qo'shni yoqni qarama-qarshi deb o'ylaydi."],
 need:["Katakli qog'oz, qaychi, shaffof paletka.","Konstruktor kublari yoki gugurt qutilari.","Bo'sh karton quti (yoyilma uchun)."],
 board:["L shakl: 16 + 4 = 20; 24 − 4 = 20.","12 kvadrat: 4×3 → P 14; 6×2 → 16; 12×1 → 26.","Paletka: 28 + 30 : 2 = 43.","Kublar: 6 + 4 = 10.","3×3×3: 8 | 12 | 6 | 1.","Quti: 2 · (6 + 3 + 2) = 22 dm²."]};
