var CODE='4B4',TITLE='4-sinf · Natijani chamalash va tekshirish';
function a44c(lines,col){clear();var g=S.g;lines.forEach(function(l,i){var y=34+i*34,last=i===lines.length-1;T(g,180,y,l,{'font-size':Math.min(last?20:17,Math.floor(600/Math.max(1,l.length))),'font-weight':800,fill:last?(col||C.blue):'#4a5a6a','font-family':'ui-monospace,Menlo,monospace'})})}
var STEPS=[
{h:"Chamalash — javobni oldindan bilish",sum:"4 873 + 3 196 ≈ 4 900 + 3 200 = 8 100; aniq javob 8 069 — yaqin.",a:"m01",
 start:function(){a44c(['4 873 + 3 196 = ?','≈ 4 900 + 3 200','≈ ?']);msg('Yuzliklargacha yaxlitlab, og‘zaki chamalaymiz')},fin:function(){a44c(['4 873 + 3 196 = 8 069','≈ 4 900 + 3 200','≈ 8 100'],C.ok);msg('Chama 8 100, aniq 8 069 — juda yaqin ✓')},
 html:"<p>Hisoblashdan oldin <b>chamalang</b>: 4 873 + 3 196 taxminan qancha? Keyin quyidagi javoblardan qaysi biri to'g'ri bo'lishi mumkinligini tanlang:</p>",
 btns:a4ch(["7 069","8 069","80 069","9 069"],1,function(){a44c(['4 873 + 3 196 = 8 069','≈ 4 900 + 3 200','≈ 8 100'],C.ok);msg('Faqat <b>8 069</b> chama (≈ 8 100) ga yaqin')},function(i){msg(i===2?'80 069 — chamadan 10 marta katta! Xona xatosi':'Chama ≈ 8 100. Bu javob 1 000 ga farq qiladi')}),g2:1,
 after:"<p>Chama aniq javobni bermaydi, lekin <b>«yaqinida bo'lishi kerak»</b> degan chegarani beradi. Javob chamadan juda uzoq bo'lsa — qayta hisoblang. Odatda eng katta xonalargacha yaxlitlash yetarli.</p>",
 q:{t:"58 412 − 19 875 ≈ ?",opts:["≈ 38 000","≈ 78 000","≈ 3 800","≈ 48 000"],ok:0,why:"58 000 − 20 000 = 38 000.",hint:"Minglargacha yaxlitlang.",full:"≈ 58 000 − 20 000 = 38 000 (aniq: 38 537). «78 000» — qo'shib yuborish; «3 800» — xona xatosi."},
 tn:"Har bir misol oldidan «chama» ustuni — bolalar avval chamalab yozadi (Singapur «estimate first»)."},
{h:"Xatoni chamalash ushlaydi",sum:"6 012 − 2 987 = 4 025? Chama ≈ 3 000 → xato! Aniq: 3 025.",a:"m02",
 start:function(){a44c(['Vali: 6 012 − 2 987 = 4 025','chama: 6 000 − 3 000 = ?','?']);msg('Valining javobini tekshiramiz')},fin:function(){a44c(['6 012 − 2 987 ≠ 4 025','chama: ≈ 3 000','to‘g‘ri: 3 025'],C.bad);msg('Vali qarz olingan mingni unutgan')},
 html:"<p>Vali 6 012 − 2 987 = 4 025 deb topdi. Chamalab ayting — javob to'g'rimi?</p>",
 btns:a4ch(["to'g'ri","xato: chama ≈ 3 000"],1,function(){a44c(['6 012 − 2 987 ≠ 4 025','chama: ≈ 3 000','to‘g‘ri: 3 025'],C.bad);msg('Chama 3 000, javob 4 025 — 1 000 farq. Aniq javob <b>3 025</b>')},function(){msg('6 000 − 3 000 = 3 000. 4 025 bunga yaqinmi?')}),g2:1,
 after:"<p>Chama ayniqsa <b>qarz/o'tkazish</b> xatolarini ushlaydi: unutilgan qarz javobni roppa-rosa 10, 100 yoki 1 000 ga o'zgartiradi.</p>",
 q:{t:"Qaysi javob chamaga ko'ra albatta xato?",opts:["9 012 − 4 987 = 5 025","2 975 + 4 018 = 6 993","3 004 + 2 996 = 6 000","8 001 − 999 = 7 002"],ok:0,why:"≈ 9 000 − 5 000 = 4 000, 5 025 juda uzoq.",hint:"Har birini minglargacha chamalang.",full:"9 012 − 4 987 ≈ 4 000, javob 5 025 — 1 000 ga farq: xato (aniq 4 025). Qolganlari chamaga mos va to'g'ri: 6 993 ≈ 7 000; 6 000; 7 002 ≈ 7 000."},
 tn:"Bolalar bir-birining daftaridagi javoblarni faqat chama bilan «tekshiruvchi» bo'lib tekshirsin."},
{h:"Oxirgi raqam bilan tekshirish",sum:"348 · 7: oxirgi raqam 8 · 7 = 56 → 6. Demak javob …6 bilan tugaydi: 2 436.",a:"m03",
 start:function(){a44c(['348 · 7 = ?','oxirgi raqam: 8 · 7 = 56','… 6']);msg('Ko‘paytmaning oxirgi raqami — oxirgi raqamlar ko‘paytmasidan')},fin:function(){a44c(['348 · 7 = 2 436','8 · 7 = 56 → 6 ✓','chama: 350 · 7 ≈ 2 450 ✓'],C.ok);msg('Ikki tekshiruv ham o‘tdi')},
 html:"<p>348 · 7 ning javobi qaysi biri bo'lishi mumkin? Oxirgi raqamga va chamaga qarang:</p>",
 btns:a4ch(["2 438","2 436","24 36","3 436"],1,function(){a44c(['348 · 7 = 2 436','8 · 7 = 56 → 6 ✓','chama: 350 · 7 ≈ 2 450 ✓'],C.ok);msg('Oxiri 6 va chamaga yaqin — <b>2 436</b>')},function(i){msg(i===0?'Oxirgi raqam 8 · 7 = 56 → 6 bo‘lishi kerak, 8 emas':i===3?'Chama ≈ 2 450 — 3 436 juda katta':'Bunday yozuv son emas')}),g2:1,
 after:"<p>Qo'shishda ham: oxirgi raqam = oxirgi raqamlar yig'indisining oxirgisi (7 + 6 = 13 → 3). Bu tekshiruv bir soniya oladi, lekin «birliklar» xatosini albatta ushlaydi.</p>",
 q:{t:"4 527 + 3 868 ning javobi qaysi raqam bilan tugaydi?",opts:["5","15","3","1"],ok:0,why:"7 + 8 = 15 → 5.",hint:"Faqat birliklarni qo'shing.",full:"7 + 8 = 15, oxirgi raqam 5 (aniq: 8 395). «15» — raqam emas, ikki xonali son."},
 tn:"«Oxirgi raqam detektivi» o'yini: o'qituvchi javoblarni aytadi, bolalar faqat oxirgi raqamga qarab xatoni topadi."},
{h:"Juft-toqlik bilan tekshirish",sum:"3 457 + 2 819 = 6 275? Toq + toq = juft → xato. Aniq: 6 276.",a:"m04",
 start:function(){a44c(['3 457 + 2 819 = 6 275 ?','toq + toq = ?','?']);msg('Hisoblamasdan tekshiring')},fin:function(){a44c(['3 457 + 2 819 ≠ 6 275','toq + toq = juft','to‘g‘ri: 6 276'],C.bad);msg('6 275 toq — bo‘lishi mumkin emas')},
 html:"<p>Kimdir 3 457 + 2 819 = 6 275 deb yozdi. Hisoblamasdan ayting — bo'lishi mumkinmi?</p>",
 btns:a4ch(["mumkin","mumkin emas: toq + toq = juft"],1,function(){a44c(['3 457 + 2 819 ≠ 6 275','toq + toq = juft','to‘g‘ri: 6 276'],C.bad);msg('Ikki toq son yig‘indisi juft bo‘ladi, 6 275 esa toq ✗')},function(){msg('3 457 — toq, 2 819 — toq. Ularning yig‘indisi qanday?')}),g2:1,
 after:"<p>Juft-toqlik tekshiruvi: J ± J = J, T ± T = J, J ± T = T; ko'paytmada bitta juft ko'paytuvchi bo'lsa — juft. Masalan 125 · 36 toq chiqsa — albatta xato.</p>",
 q:{t:"Qaysi tenglik albatta xato?",opts:["125 · 36 = 4 505","1 357 + 2 469 = 3 826","5 000 − 1 234 = 3 766","15 · 15 = 225"],ok:0,why:"36 juft → ko'paytma juft bo'lishi kerak, 4 505 toq.",hint:"Ko'paytmada juft ko'paytuvchi bormi?",full:"125 · 36 da 36 juft → ko'paytma juft; 4 505 toq — xato (aniq 4 500). Qolganlari to'g'ri."},
 tn:"Juft-toqlik jadvali doskada doim tursin."},
{h:"Teskari amal bilan tekshirish",sum:"7 248 : 6 = 1 208 → tekshirish: 1 208 · 6 = 7 248 ✓.",a:"m05",
 start:function(){a44c(['7 248 : 6 = 1 208','tekshirish: ? · ? = 7 248','?']);msg('Bo‘lishni qaysi amal bilan tekshiramiz?')},fin:function(){a44c(['7 248 : 6 = 1 208','1 208 · 6 = 7 248','✓ to‘g‘ri'],C.ok);msg('Bo‘linma · bo‘luvchi = bo‘linuvchi')},
 html:"<p>7 248 : 6 = 1 208. Buni qanday tekshiramiz?</p>",
 btns:a4ch(["1 208 · 6","1 208 : 6","7 248 · 6","7 248 − 1 208"],0,function(){a44c(['7 248 : 6 = 1 208','1 208 · 6 = 7 248','✓ to‘g‘ri'],C.ok);msg('1 208 · 6 = 7 248 — bo‘linuvchi chiqdi ✓')},function(i){msg(i===1?'Yana bo‘lish — tekshiruv emas':i===2?'Bu juda katta son beradi':'Ayirish — qo‘shishning teskarisi, bo‘lishniki emas')}),g2:1,
 after:"<p>Har bir amalning teskarisi bor: + ↔ −, · ↔ :. Teskari amal bilan tekshirish — eng ishonchli usul, chunki u javobni <b>to'liq</b> tekshiradi (chama va oxirgi raqam esa qisman).</p>",
 q:{t:"Ayirishni (8 000 − 3 456 = 4 544) qanday tekshiramiz?",opts:["4 544 + 3 456 = 8 000","8 000 + 3 456","4 544 − 3 456","8 000 − 4 544 − 3 456"],ok:0,why:"Ayirma + ayriluvchi = kamayuvchi.",hint:"Ayirishning teskarisi — qo'shish.",full:"4 544 + 3 456 = 8 000 ✓. Boshqa variantlar kamayuvchini qaytarib bermaydi."},
 tn:"Daftarda ikki ustun: «hisob» va «tekshiruv»."},
{h:"Chegaralar bilan chamalash",sum:"386 · 4: 300 · 4 = 1 200 < javob < 400 · 4 = 1 600. Aniq: 1 544.",a:"m06",
 start:function(){bqLine(1000,1800,[],[[1200,C.blue],[1600,C.blue]],{step:200});T(S.g,180,26,'300 · 4 < 386 · 4 < 400 · 4',{'font-size':13,'font-weight':800,fill:C.blue});msg('Javob shu oraliqda bo‘lishi shart')},
 fin:function(){bqLine(1000,1800,[],[[1200,C.blue],[1544,C.ok],[1600,C.blue]],{step:200});T(S.g,180,26,'386 · 4 = 1 544 — oraliq ichida ✓',{'font-size':13,'font-weight':800,fill:C.ok});msg('<b>1 544</b>')},
 html:"<p>386 · 4 ning javobi qaysi biri? Avval «pastki» va «yuqori» chegarani toping:</p>",
 btns:a4ch(["1 244","1 544","1 644","15 44"],1,function(){STEPS[5].fin()},function(i){msg(i===0?'1 244 — 1 200 ga juda yaqin; 386 esa 400 ga yaqin. Oxirgi raqamni ham tekshiring: 6 · 4 = 24 → 4':i===2?'1 644 > 1 600 — yuqori chegaradan oshdi!':'Bunday son yo‘q')}),g2:1,
 after:"<p>Pastki chegara — kami bilan yaxlitlab, yuqori — ortig'i bilan. Javob ular orasida bo'lishi <b>shart</b>. Bir nechta tekshiruvni birga ishlating: chegara + oxirgi raqam.</p>",
 q:{t:"612 · 5 qaysi oraliqda?",opts:["3 000 va 3 500 orasida","2 500 va 3 000 orasida","30 000 dan katta","600 va 700 orasida"],ok:0,why:"600 · 5 = 3 000, 700 · 5 = 3 500; aniq 3 060.",hint:"600 · 5 va 700 · 5.",full:"600 · 5 = 3 000 < 612 · 5 < 700 · 5 = 3 500. Aniq: 3 060."},
 tn:"Son o'qida chegaralarni belgilab, javobni «ichiga» joylash."},
{h:"Hayotda: pul yetadimi?",sum:"2 980 + 4 950 + 1 990 ≈ 3 000 + 5 000 + 2 000 = 10 000 — lekin aniq 9 920, yetadi!",a:"m07",
 start:function(){bqBar('10 000',[{v:'2 980',w:2980,col:'#bfe6d4'},{v:'4 950',w:4950,col:C.a},{v:'1 990',w:1990,col:'#cfe2f7'},{v:'?',q:1,w:80}],{title:'Hamyonda 10 000 so‘m'});msg('Har bir narx yuqoriga yaxlitlansa — haqiqiy jami kamroq')},
 fin:function(){bqBar('10 000',[{v:'2 980',w:2980,col:'#bfe6d4'},{v:'4 950',w:4950,col:C.a},{v:'1 990',w:1990,col:'#cfe2f7'},{v:'80',w:200,col:'#fff3c4'}],{title:'9 920 so‘m — yetadi, qaytim 80'});msg('Aniq jami <b>9 920</b>, qaytim 80 so‘m')},
 html:"<p>Hamyonda 10 000 so'm. Narxlar: 2 980, 4 950 va 1 990 so'm. Uchalasini olishga pul yetadimi?</p>",
 btns:a4ch(["yetmaydi","roppa-rosa 10 000","yetadi, 80 so'm qoladi"],2,function(){STEPS[6].fin()},function(i){msg(i===0?'Chama 10 000 chiqdi — lekin har bir narx ORTIG‘I bilan yaxlitlangan, demak aslida kamroq':'Chama — taxminiy. Aniq hisoblang: 2 980 + 4 950 + 1 990')}),g3:1,
 after:"<p>Chamani to'g'ri tushunish: hamma son <b>yuqoriga</b> yaxlitlansa — chama aniqdan katta; <b>pastga</b> yaxlitlansa — kichik. Chama chegaraga juda yaqin bo'lsa (10 000 = 10 000), <b>aniq hisoblash</b> shart.</p>",
 q:{t:"3 ta kitob: 12 400, 18 700, 9 300 so'm. 40 000 so'm yetadimi?",opts:["Yo'q, 400 so'm yetmaydi","Ha, 400 so'm qoladi","Ha, roppa-rosa","Yo'q, 4 000 yetmaydi"],ok:0,why:"12 400 + 18 700 + 9 300 = 40 400.",hint:"Chama ≈ 12 000 + 19 000 + 9 000 = 40 000 — juda yaqin, aniq hisoblang.",full:"12 400 + 18 700 = 31 100; + 9 300 = 40 400 > 40 000. 400 so'm yetmaydi."},
 tn:"Do'kon o'yini: narx yorliqlari bilan «savdo» — avval chama, keyin kalkulyatorsiz aniq hisob."},
{h:"Javob necha xonali bo'ladi?",sum:"312 · 48 ≈ 300 · 50 = 15 000 → besh xonali. Aniq: 14 976.",a:"m08",
 start:function(){a44c(['312 · 48 = ?','≈ 300 · 50','≈ ?']);msg('Xonalar sonini oldindan bilish — katta xatoni ushlaydi')},fin:function(){a44c(['312 · 48 = 14 976','≈ 300 · 50','≈ 15 000 → 5 xonali'],C.ok);msg('Besh xonali javob ✓')},
 html:"<p>312 · 48 hisoblanganda javob necha xonali son bo'ladi?</p>",
 btns:a4ch(["4 xonali","5 xonali","6 xonali"],1,function(){a44c(['312 · 48 = 14 976','≈ 300 · 50','≈ 15 000 → 5 xonali'],C.ok);msg('≈ 15 000 — besh xonali. Aniq: <b>14 976</b>')},function(i){msg(i===0?'300 · 50 = 15 000 — besh xonali':'6 xonali — 100 000 dan katta. Chama 15 000')}),g3:1,
 after:"<p>Ko'paytirishdagi eng ko'p xato — ikkinchi qatorni surmaslik; u javobni 10 marta kichraytiradi (masalan 3 744 o'rniga). Xonalar soni tekshiruvi buni darhol ushlaydi.</p>",
 q:{t:"Sardor 312 · 48 = 3 744 deb topdi. Xatosi:",opts:["javob 10 marta kichik — 2-qatorni surmagan","oxirgi raqam xato","qarzni unutgan","xato yo'q"],ok:0,why:"312 · 8 = 2 496, 312 · 4 = 1 248; surmasa 2 496 + 1 248 = 3 744.",hint:"Chamani eslang: ≈ 15 000.",full:"312 · 8 = 2 496; 312 · 40 = 12 480. Jami 14 976. Sardor 1 248 ni surmagan: 2 496 + 1 248 = 3 744 — chamadan 4 marta kichik."},
 tn:"3C13 bilan bog'lang: ustun usulida ikkinchi qatorni surish."},
{h:"Bilasizmi?",sum:"«9 bilan tekshirish» — hisobchilarning qadimiy siri.",a:"m09",
 start:function(){a44c(['3 457 → 3+4+5+7 = 19 → 1+9 = 10 → 1','raqamlar yig‘indisi «izi»','9 bilan tekshirish']);msg('Qadimiy usul')},fin:function(){a44c(['3 457 → 3+4+5+7 = 19 → 1+9 = 10 → 1','raqamlar yig‘indisi «izi»','9 bilan tekshirish']);msg('Qadimiy usul')},
 html:"<p>🔍 O'rta asrlarda Sharq va Yevropa hisobchilari katta hisob-kitoblarni <b>«9 bilan tekshirish»</b> usuli bilan nazorat qilishgan: har bir sonning raqamlarini qo'shib, bitta raqamgacha qisqartirishadi. Qo'shiluvchilar «izlari»ning yig'indisi javob «izi»ga mos kelmasa — hisobda xato bor. Bu usulni 5-sinfda batafsil o'rganasiz.</p>",
 tn:"Kuchli o'quvchilar uchun: 3 457 + 2 819 = 6 276 ni 9 bilan tekshirish (1 + 2 = 3; 6+2+7+6 = 21 → 3 ✓)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a44c(['4 873 + 3 196 = 8 069','≈ 4 900 + 3 200','≈ 8 100'],C.ok)},fin:function(){a44c(['4 873 + 3 196 = 8 069','≈ 4 900 + 3 200','≈ 8 100'],C.ok)},
 html:"<div class='memo'><ul><li>Avval chamalang: eng katta xonagacha yaxlitlab.</li><li>Oxirgi raqam: oxirgi raqamlardan hisoblanadi.</li><li>Juft-toqlik: T + T = J; juft ko'paytuvchi → juft ko'paytma.</li><li>Teskari amal: ayirma + ayriluvchi; bo'linma · bo'luvchi.</li><li>Chegaralar: 300 · 4 < 386 · 4 < 400 · 4.</li><li>Chama chegaraga yaqin bo'lsa — aniq hisoblang.</li></ul></div>",
 tn:"Keyingi bo'lim — ko'paytirish va bo'lish."}
];
var PROBS=[
{t:"4 873 + 3 196 ning to'g'ri javobi qaysi bo'lishi mumkin?",o:["8 069","7 069","80 069","9 069"],k:0,s:"Chama ≈ 8 100."},
{t:"58 412 − 19 875 ≈ ?",o:["38 000","78 000","3 800","48 000"],k:0,s:"58 000 − 20 000."},
{t:"Vali: 6 012 − 2 987 = 4 025. To'g'ri javob:",o:["3 025","4 025","3 125","2 025"],k:0,s:"Chama ≈ 3 000."},
{t:"348 · 7 = ?",o:["2 436","2 438","3 436","2 426"],k:0,s:"Oxiri 6, chama ≈ 2 450."},
{t:"4 527 + 3 868 qaysi raqam bilan tugaydi?",o:["5","3","1","15"],k:0,s:"7 + 8 = 15."},
{t:"3 457 + 2 819 = ?",o:["6 276","6 275","6 266","5 276"],k:0,s:"T + T = J."},
{t:"Qaysi tenglik albatta xato?",o:["125 · 36 = 4 505","1 357 + 2 469 = 3 826","5 000 − 1 234 = 3 766","15 · 15 = 225"],k:0,s:"36 juft → ko'paytma juft."},
{t:"7 248 : 6 = 1 208 ni qanday tekshiramiz?",o:["1 208 · 6","1 208 : 6","7 248 · 6","7 248 − 1 208"],k:0,s:"Bo'linma · bo'luvchi."},
{t:"8 000 − 3 456 = 4 544 ni tekshirish:",o:["4 544 + 3 456 = 8 000","8 000 + 3 456","4 544 − 3 456","4 544 · 2"],k:0,s:"Ayirma + ayriluvchi."},
{t:"386 · 4 = ?",o:["1 544","1 244","1 644","1 534"],k:0,s:"1 200 < x < 1 600, oxiri 4."},
{t:"612 · 5 qaysi oraliqda?",o:["3 000 va 3 500","2 500 va 3 000","30 000 dan katta","600 va 700"],k:0,s:"3 060."},
{t:"10 000 so'mga 2 980, 4 950, 1 990 so'mlik narsalar olinsa, qaytim:",o:["80 so'm","0","20 so'm","yetmaydi"],k:0,s:"9 920."},
{t:"12 400 + 18 700 + 9 300. 40 000 so'm yetadimi?",o:["Yo'q, 400 so'm yetmaydi","Ha, 400 qoladi","Ha, roppa-rosa","Yo'q, 4 000 yetmaydi"],k:0,s:"40 400."},
{t:"312 · 48 javobi necha xonali?",o:["5 xonali","4 xonali","6 xonali","3 xonali"],k:0,s:"≈ 15 000."},
{t:"Sardor 312 · 48 = 3 744 deb topdi. To'g'ri javob:",o:["14 976","3 744","37 440","14 966"],k:0,s:"2 496 + 12 480."},
{t:"49 · 51 ning javobi qaysi bo'lishi mumkin?",o:["2 499","24 999","249","3 499"],k:0,s:"≈ 50 · 50 = 2 500; oxirgi raqam 9 · 1 = 9."},
{t:"789 + 805 + 798 + 812 ≈ ?",o:["3 200","2 400","4 000","32 000"],k:0,s:"≈ 800 · 4 = 3 200 (aniq 3 204)."},
{t:"Qaysi ko'paytma 10 000 dan katta?",o:["267 · 41","198 · 49","99 · 99","312 · 32"],k:0,s:"≈ 270 · 40 = 10 800 (aniq 10 947); 198 · 49 = 9 702; 9 801; 9 984."},
{t:"Ali: 4 005 − 1 997 = 2 008. Tekshiring:",o:["to'g'ri","xato, 2 018","xato, 3 008","xato, 2 108"],k:0,s:"4 008 − 2 000 = 2 008 ✓."},
{t:"A = 5 678 + 4 321, B = 10 000. Qaysi to'g'ri?",o:["A < B","A > B","A = B","A = B + 1"],k:0,s:"5 678 + 4 321 = 9 999."}
];
function PRACT_STAGE(){a44c(['4 873 + 3 196 = 8 069','≈ 4 900 + 3 200','≈ 8 100'],C.ok)}
var PREP_DATA={teach:["Chamalash (yaxlitlab), chama bilan xatoni topish.","Oxirgi raqam, juft-toqlik, teskari amal bilan tekshirish.","Chegaralar, xonalar soni, hayotiy chamalash (pul)."],mist:["Chamani aniq javob deb yozadi.","Chama chegaraga yaqin bo'lsa ham aniq hisoblamaydi.","Tekshirishda noto'g'ri teskari amal tanlaydi.","Ko'paytirishda 2-qatorni surmaydi va sezmaydi."],need:["Narx yorliqlari, son o'qi, kartochkalar."],board:["<span class='w2'>4 873 + 3 196 ≈ 8 100</span>.","<span class='w2'>8 · 7 = 56 → …6</span>.","<span class='w2'>T + T = J</span>.","<span class='w2'>1 200 < 386 · 4 < 1 600</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
