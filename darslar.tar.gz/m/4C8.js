var CODE='4C8',TITLE='4-sinf · Ko‘paytirish va bo‘lishni tekshirish, chamalash';
var P1=[function(){W3eq(['326 · 24 = 7 824']);W3msg('Javob to‘g‘rimi? Teskari amal bilan tekshiramiz')},
 function(){W3eq(['326 · 24 = 7 824','7 824 : 24 = ?']);W3msg('Ko‘paytmani bir ko‘paytuvchiga bo‘lsak — ikkinchisi chiqishi kerak')},
 function(){w4Tail(7824,24);W3msg('7 824 : 24 = <b>326</b> ✓ — ko‘paytirish to‘g‘ri')}];
var P3=[function(){W3eq(['487 · 32 ≈ ?']);W3msg('Har bir sonni eng katta xonasigacha yaxlitlaymiz')},
 function(){W3eq(['487 ≈ 500','32 ≈ 30']);W3msg('487 — 500 ga yaqin, 32 — 30 ga')},
 function(){W3eq(['500 · 30 = 15 000','487 · 32 = [15 584]']);W3msg('Chama 15 000, aniq javob 15 584 — yaqin ✓','Chama aniq javob emas, lekin xona xatosini darhol ko‘rsatadi')}];
function w4Tail(D,d){w3Long(D,d,99)}
var STEPS=[
{h:"Ko'paytirishni bo'lish bilan",sum:"326 · 24 = 7 824 → tekshiruv: 7 824 : 24 = 326.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har bir amalning <b>teskari amali</b> bor. U bilan javobni tekshiramiz.</p>",btns:[phaser(P1)],
 after:"<p>Ko'paytirishni tekshirish: <b>ko'paytma : bir ko'paytuvchi = ikkinchi ko'paytuvchi</b>. Chiqmasa — qayerdadir xato bor.</p>",
 q:{t:"Bola 208 · 35 = 7 280 deb topdi. Qaysi amal bilan tekshiriladi?",opts:["7 280 : 35 = 208","7 280 · 35","7 280 − 35","208 : 35"],ok:0,why:"Ko'paytmani ko'paytuvchiga bo'lamiz.",hint:"Ko'paytirishning teskarisi.",full:"Ko'paytirishning teskarisi — bo'lish: 7 280 : 35 = 208 chiqsa, javob to'g'ri. Boshqa ifodalar tekshiruv emas."},
 tn:"Juftlikda: biri hisoblaydi, ikkinchisi teskari amal bilan tekshiradi. Keyin rollar almashadi."},
{h:"Bo'lishni ko'paytirish bilan",sum:"Bola 4 572 : 12 = 371 deb yozdi; 371 · 12 = 4 452 ≠ 4 572 — xato. To'g'risi 381.",a:"m02",start:function(){W3eq(['4 572 : 12 = 371 ?']);W3msg('Bolaning javobini tekshiring')},fin:function(){W3eq(['371 · 12 = 4 452 ≠ 4 572','4 572 : 12 = [381]'])},
 html:"<p>Bola yozdi: <b>4 572 : 12 = 371</b>. Ko'paytirib tekshiring va baho bering:</p>",
 btns:[["Tekshirish: 371 · 12",function(c,done,b){b.disabled=true;W3eq(['371 · 12 = 4 452','4 452 ≠ 4 572']);W3msg('Bo‘linuvchi chiqmadi — 120 ga kam. Demak bo‘linmada bitta o‘nlik yetmayapti')}],["Javob to‘g‘ri",function(){W3eq(['371 · 12 = ?']);W3msg('Avval tekshiring!','Ko‘paytirib ko‘ring')}],["Xato, to‘g‘risi 381",function(c,done){W3eq(['381 · 12 = 4 572 ✓','4 572 : 12 = [381]']);W3msg('120 : 12 = 10 — bo‘linmaga yana 10 qo‘shamiz: <b>381</b>');done()}]],
 after:"<p>Bo'lishni tekshirish: <b>bo'linma · bo'luvchi = bo'linuvchi</b> (qoldiq bo'lsa, qoldiqni qo'shamiz). Farq qancha chiqsa — xato o'shancha xonada.</p>",
 q:{t:"5 115 : 15 = 341 (qoldiq 0). Tekshiruv qaysi?",opts:["341 · 15 = 5 115","341 + 15 = 5 115","5 115 · 15","341 : 15"],ok:0,why:"Bo'linma · bo'luvchi.",hint:"Bo'lishning teskarisi — ko'paytirish.",full:"341 · 15 = 3 410 + 1 705 = 5 115 ✓. Qo'shish va boshqa amallar tekshiruv bermaydi."},
 tn:"Xato topilganda «farq»ni tahlil qilish (120 = 12 · 10) — chuqur tushunishga olib boradi."},
{h:"Chamalash: yaxlitlab",sum:"487 · 32 ≈ 500 · 30 = 15 000; aniq 15 584.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Chamalash — hisoblashdan <b>oldin</b> javobni taxmin qilish.</p>",btns:[phaser(P3)],
 after:"<p>Sonni <b>eng katta xonasigacha</b> yaxlitlaymiz: 487 → 500, 32 → 30, 6 812 → 7 000. Yaxlit sonlar bilan og'zaki hisoblaymiz.</p>",
 q:{t:"612 · 49 ning chamasi?",opts:["30 000","3 000","300 000","24 000"],ok:0,why:"600 · 50.",hint:"612 ≈ 600, 49 ≈ 50.",full:"600 · 50 = 30 000. Aniq javob 29 988 — juda yaqin. «3 000» va «300 000» — xona xatosi."},
 tn:"Har misol oldidan «Chamam: …» qatorini yozish odatini shakllantiring."},
{h:"Chegaralar: kamida va ko'pi bilan",sum:"400 · 30 = 12 000 < 487 · 32 < 500 · 40 = 20 000.",a:"m04",start:function(){W3eq(['400 · 30 < 487 · 32 < 500 · 40']);W3msg('Pastga va yuqoriga yaxlitlab — chegaralar')},fin:function(){W3eq(['12 000 < [15 584] < 20 000'])},
 html:"<p><b>487 · 32</b> ning javobi qaysi biri bo'lishi mumkin?</p>",
 btns:[["15 584",function(c,done){W3eq(['12 000 < [15 584] < 20 000']);W3msg('Chegaralar ichida ✓');done()}],["1 558",function(){W3eq(['1 558 < 12 000']);W3msg('Pastki chegaradan ham kichik','Qayta tanlang')}],["25 584",function(){W3eq(['25 584 > 20 000']);W3msg('Yuqori chegaradan katta','Qayta tanlang')}]],g3:1,
 after:"<p>Ikkala ko'paytuvchini <b>pastga</b> yaxlitlasak — kamida qancha, <b>yuqoriga</b> — ko'pi bilan qancha. Javob shu oraliqda bo'lishi shart.</p>",
 q:{t:"198 · 41 qaysi oraliqda?",opts:["4 000 va 10 000 orasida","400 va 1 000 orasida","10 000 va 20 000 orasida","40 000 dan katta"],ok:0,why:"100 · 40 = 4 000, 200 · 50 = 10 000.",hint:"198 — 100 va 200 orasida, 41 — 40 va 50 orasida.",full:"Kamida 100 · 40 = 4 000, ko'pi bilan 200 · 50 = 10 000. Aniq: 198 · 41 = 8 118 ✓."},
 tn:"Son o'qida oraliqni bo'yab ko'rsating — chegaralar ko'rinadi."},
{h:"Oxirgi raqam bilan tekshirish",sum:"347 · 26: oxirgi raqam 7 · 6 = 42 → 2. Javob 2 bilan tugashi shart: 9 022.",a:"m05",start:function(){W3eq(['347 · 26 = ?']);W3msg('Uchta javob — chamasi bir xil. Qaysi biri?')},fin:function(){W3eq(['7 · 6 = 4[2]','347 · 26 = 9 02[2]'])},
 html:"<p><b>347 · 26</b>: javoblar 9 022, 9 024, 9 027. Chamalash yordam bermaydi — hammasi 9 000 atrofida. Qaysi biri?</p>",
 btns:[["9 022",function(c,done){W3eq(['7 · 6 = 4[2]','347 · 26 = 9 02[2]']);W3msg('Birliklar: 7 · 6 = 42 → oxirgi raqam <b>2</b> ✓');done()}],["9 024",function(){W3eq(['7 · 6 = 42 → 2','9 024 → 4 ✗']);W3msg('Oxirgi raqam mos emas','Qayta tanlang')}],["9 027",function(){W3eq(['7 · 6 = 42 → 2','9 027 → 7 ✗']);W3msg('Oxirgi raqam mos emas','Qayta tanlang')}]],g3:1,
 after:"<p>Ko'paytmaning oxirgi raqami faqat ko'paytuvchilarning <b>oxirgi raqamlariga</b> bog'liq. Chamalash «kattaligini», oxirgi raqam «aniqligini» tekshiradi.</p>",
 q:{t:"Qaysi javob 253 · 47 ga to'g'ri kelishi mumkin?",opts:["11 891","11 893","11 896","1 891"],ok:0,why:"3 · 7 = 21 → 1, chama 250 · 50 = 12 500.",hint:"Oxirgi raqam va chama.",full:"3 · 7 = 21 → oxirgi raqam 1. Chama ≈ 12 000. «1 891» — oxiri 1, lekin chamaga to'g'ri kelmaydi. Javob 11 891."},
 tn:"Ikki tekshiruvni birga: «katta-kichikligi» (chama) va «oxiri» (oxirgi raqam)."},
{h:"Juft-toq tekshiruv",sum:"Toq · toq = toq: 135 · 27 juft son bo'lolmaydi. Javob 3 645.",a:"m06",start:function(){W3eq(['135 · 27 = 3 644 ?']);W3msg('Bola shunday yozdi. Hisoblamasdan tekshiring!')},fin:function(){W3eq(['toq · toq = toq','135 · 27 = [3 645]'])},
 html:"<p>Bola: <b>135 · 27 = 3 644</b>. Hisoblamasdan ayting — to'g'rimi?</p>",
 btns:[["Xato: juft chiqmaydi",function(c,done){W3eq(['toq · toq = toq','135 · 27 = [3 645]']);W3msg('Ikki toq sonning ko‘paytmasi doim <b>toq</b>. 3 644 juft — xato');done()}],["To‘g‘ri bo‘lishi mumkin",function(){W3eq(['5 · 7 = 35 → toq']);W3msg('Oxirgi raqamlarga qarang: 5 · 7 = 35 — toq','Qayta o‘ylang')}]],
 after:"<p>Juft · istalgan son = <b>juft</b>; toq · toq = <b>toq</b>. 5 ga tugaydigan son · toq son — 5 bilan tugaydi. Bu tekshiruvlar bir soniyada bajariladi.</p>",
 q:{t:"Qaysi javob aniq XATO (hisoblamasdan)?",opts:["25 · 39 = 974","25 · 39 = 975","48 · 13 = 624","16 · 25 = 400"],ok:0,why:"Toq · toq juft bo'lolmaydi.",hint:"25 va 39 — toq.",full:"25 va 39 — toq, ko'paytma toq bo'lishi kerak. 974 juft — xato (to'g'risi 975)."},
 tn:"«Detektiv» o'yini: 10 ta yozuvdan hisoblamasdan xatolarini toping."},
{h:"Bo'linmani chamalash",sum:"7 344 : 36 ≈ 7 200 : 36 = 200; javob 204.",a:"m07",start:function(){W3eq(['7 344 : 36 ≈ ?']);W3msg('36 ga oson bo‘linadigan yaqin son: 7 200')},fin:function(){W3eq(['7 200 : 36 = 200','7 344 : 36 = [204]'])},
 html:"<p><b>7 344 : 36</b>. Qaysi javob to'g'ri kelishi mumkin?</p>",
 btns:[["204",function(c,done){W3eq(['7 200 : 36 = 200','7 344 : 36 = [204]']);W3msg('200 dan sal ko‘p ✓ Tekshiruv: 204 · 36 = 7 344');done()}],["24",function(){W3eq(['≈ 200','24 — 10 marta kam']);W3msg('Bo‘linmadagi 0 yo‘qolgan','Qayta tanlang')}],["2 004",function(){W3eq(['≈ 200','2 004 — 10 marta ko‘p']);W3msg('Ortiqcha nol','Qayta tanlang')}]],g3:1,
 after:"<p>Bo'lishda chamalash uchun bo'linuvchini <b>bo'luvchiga oson bo'linadigan</b> songa yaxlitlaymiz: 7 344 → 7 200 (36 · 200).</p>",
 q:{t:"2 940 : 35 ning chamasi qaysi?",opts:["≈ 80–90","≈ 8–9","≈ 800–900","≈ 30"],ok:0,why:"2 800 : 35 = 80.",hint:"35 · 80 = 2 800.",full:"35 · 80 = 2 800, 35 · 90 = 3 150 — javob 80 va 90 orasida. Aniq: 84."},
 tn:"Chamalashda aniq son emas, «oraliq» aytish ham to'g'ri — buni rag'batlantiring."},
{h:"Mantiq bilan tekshirish",sum:"8 avtobusda 45 o'rindan — 3 600 emas, 360 o'rin. Javob hayotga mos bo'lishi kerak.",a:"m08",start:function(){W3eq(['45 · 8 = 3 600 ?']);W3msg('Bola masalaga shunday javob berdi: «8 avtobusda 3 600 o‘rin»')},fin:function(){W3eq(['45 · 8 = [360]'])},
 html:"<p>Masala: avtobusda 45 o'rin. 8 ta avtobusda nechta o'rin? Bola javobi: <b>3 600</b>. Baho bering:</p>",
 btns:[["Mantiqsiz — 10 marta ko‘p",function(c,done){W3eq(['50 · 8 = 400 dan ko‘p emas','45 · 8 = [360]']);W3msg('8 avtobus — katta maktab hovlisi. 3 600 kishi — stadion! To‘g‘risi <b>360</b>');done()}],["To‘g‘ri",function(){W3eq(['1 avtobus ≈ 50 kishi','8 avtobus ≈ ?']);W3msg('Chamalang: 50 · 8 = 400','Qayta o‘ylang')}]],
 after:"<p>Masalada javob <b>hayotga mos</b> kelishini tekshiring: odamning bo'yi 15 m bo'lmaydi, bir sinfda 300 o'quvchi bo'lmaydi.</p>",
 q:{t:"Qaysi javob mantiqan XATO?",opts:["Bir o'quvchi kuniga 1 440 bet o'qiydi","Sinfda 32 o'quvchi","Avtobus soatiga 60 km yuradi","Bir non 4 000 so'm"],ok:0,why:"Kuniga 1 440 bet — imkonsiz.",hint:"Qaysi biri hayotda bo'lmaydi?",full:"Sutkada 1 440 daqiqa bor — har daqiqada bir bet o'qib, uxlamasdan o'qish kerak bo'lardi. Qolganlari odatiy."},
 tn:"Masala yechgandan keyin «Javob haqiqatga o'xshaydimi?» savolini majburiy qiling."},
{h:"Bilasizmi? To'qqiz bilan tekshirish",sum:"Raqamlar yig'indisi orqali tekshirish: 347 → 14 → 5; 26 → 8; 5 · 8 = 40 → 4; 9 022 → 13 → 4 ✓.",a:"m09",start:function(){W3eq(['347 → 3+4+7 = 14 → 5','26 → 2+6 = 8','5 · 8 = 40 → 4','9 022 → 13 → 4 ✓'],{fs:17});W3msg('Raqamlar yig‘indisi bilan tekshiruv')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Qadimgi hisobchilar <b>«to'qqiz bilan tekshirish»</b> usulidan foydalanishgan: har sonning raqamlarini bitta raqam qolguncha qo'shib boriladi. Ko'paytuvchilarning «raqamlari» ko'paytmasi natijaning «raqami»ga teng chiqishi kerak.</p><p>⭐ 347 → 14 → 5, 26 → 8, 5 · 8 = 40 → 4. Javob 9 022 → 13 → 4 ✓. Agar mos kelmasa — javob aniq xato.</p>",
 tn:"Bu usul 9 ga bo'linish alomatiga bog'liq — keyingi darsga ko'prik bo'ladi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3eq(['487 · 32 ≈ 500 · 30','= 15 000'])},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Ko'paytirishni bo'lish bilan: 7 824 : 24 = 326.</li><li>Bo'lishni ko'paytirish bilan: 381 · 12 = 4 572.</li><li>Chama: eng katta xonagacha yaxlitlang: 487 · 32 ≈ 15 000.</li><li>Chegaralar: 12 000 &lt; 487 · 32 &lt; 20 000.</li><li>Oxirgi raqam: 7 · 6 = 42 → javob 2 bilan tugaydi.</li><li>Toq · toq = toq.</li><li>Javob hayotga mosmi?</li></ul></div>",
 tn:"Keyingi mavzu: bo'linish alomatlari — tekshiruvning yana bir quroli."}
];
var PROBS=[
{t:"413 · 27 ning chamasi?",o:["12 000","1 200","120 000","8 000"],k:0,s:"400 · 30."},
{t:"6 812 : 34 ning chamasi?",o:["200","20","2 000","300"],k:0,s:"6 800 : 34 = 200."},
{t:"Qaysi javob 389 · 52 ga to'g'ri kelishi mumkin?",o:["20 228","2 028","202 280","20 225"],k:0,s:"≈ 20 000; 9 · 2 = 18 → 8."},
{t:"Qaysi javob 5 712 : 24 ga to'g'ri kelishi mumkin?",o:["238","38","2 380","138"],k:0,s:"4 800 : 24 = 200, 7 200 : 24 = 300."},
{t:"Bola 263 · 18 = 4 736 deb yozdi. Oxirgi raqam bo'yicha nima deysiz?",o:["Xato: 3 · 8 = 24, javob 4 bilan tugashi kerak","To'g'ri","Xato: javob 8 bilan tugashi kerak","Xato: javob 2 bilan tugashi kerak"],k:0,s:"3 · 8 = 24 → 4; aniq 263 · 18 = 4 734."},
{t:"Qaysi yozuv aniq XATO (hisoblamasdan)?",o:["37 · 53 = 1 960","37 · 53 = 1 961","24 · 15 = 360","45 · 22 = 990"],k:0,s:"Toq · toq juft bo'lolmaydi."},
{t:"Qaysi yozuv aniq XATO?",o:["125 · 7 = 873","125 · 7 = 875","64 · 5 = 320","18 · 5 = 90"],k:0,s:"5 bilan tugaydigan son · toq = 5 bilan tugaydi."},
{t:"Bola 2 856 : 14 = 24 deb yozdi. Tekshiruv natijasi?",o:["24 · 14 = 336 — xato, to'g'risi 204","To'g'ri","24 · 14 = 2 856","Xato, to'g'risi 2 004"],k:0,s:"204 · 14 = 2 856."},
{t:"Bola 3 001 : 7 = 428 (qoldiq 5) deb yozdi. Tekshiring.",o:["428 · 7 + 5 = 3 001 — to'g'ri","Xato, qoldiq 7 dan katta","Xato, 429 bo'lishi kerak","Xato, qoldiq bo'lmaydi"],k:0,s:"2 996 + 5 = 3 001."},
{t:"256 · 39 qaysi oraliqda?",o:["6 000 va 12 000 orasida","600 va 1 200 orasida","12 000 va 20 000 orasida","60 000 dan katta"],k:0,s:"200 · 30 va 300 · 40; aniq 9 984."},
{t:"Hisoblamasdan: 48 · 25 ko'paytmaning oxirgi raqami?",o:["0","5","8","2"],k:0,s:"8 · 5 = 40."},
{t:"a · 13 = 2 457. Tekshiruv uchun qaysi amal?",o:["2 457 : 13 = a","2 457 · 13","2 457 − 13","13 : 2 457"],k:0,s:"Noma'lum ko'paytuvchi."},
{t:"Qaysi masala javobi mantiqsiz?",o:["Bir mushukning vazni 450 kg","Bir sinfda 28 o'quvchi","Bir kitob 280 bet","Bir piyoda soatiga 5 km yuradi"],k:0,s:"Mushuk 4–5 kg."},
{t:"Chamalang: 4 kg olma 11 900 so'm. 1 kg taxminan necha so'm?",o:["3 000 so'm atrofida","300 so'm atrofida","30 000 so'm atrofida","12 000 so'm atrofida"],k:0,s:"12 000 : 4 = 3 000; aniq 2 975."},
{t:"Maktabda 1 248 o'quvchi, har biri 12 ta daftar oldi. Qaysi javob bo'lishi mumkin?",o:["14 976","1 497","104 976","1 260"],k:0,s:"≈ 1 250 · 12 = 15 000; 8 · 2 = 16 → 6."},
{t:"Qaysi javob 999 · 99 ga teng?",o:["98 901","99 999","98 999","9 891"],k:0,s:"99 900 − 999."},
{t:"Bola 507 · 6 = 3 042 deb yozdi. To'qqiz bilan tekshiruv: 507 → 3, 6 → 6, 3 · 6 = 18 → 9; 3 042 → 9. Natija?",o:["Mos keldi — javob to'g'ri","Mos kelmadi — xato","Tekshirib bo'lmaydi","Javob 3 024"],k:0,s:"507 · 6 = 3 042 ✓."},
{t:"Qaysi ko'paytmaning chamasi 20 000 ga eng yaqin?",o:["198 · 102","49 · 41","802 · 19","4 980 · 2"],k:0,s:"≈ 20 000; 2 000; 16 000; 10 000."},
{t:"Bo'lishda bo'linma 302, bo'luvchi 25, qoldiq 9. Bo'linuvchi?",o:["7 559","7 550","7 541","336"],k:0,s:"302 · 25 + 9 = 7 559."},
{t:"Qaysi tekshiruv 7 344 : 36 = 204 ning to'g'riligini ko'rsatadi?",o:["204 · 36 = 7 344","204 + 36 = 7 344","7 344 − 204 = 36","36 : 204"],k:0,s:"Bo'linma · bo'luvchi."}
];
function PRACT_STAGE(){W3eq(['Chama → hisob → tekshiruv'],{fs:20})}
var PREP_DATA={teach:["Teskari amal bilan tekshirish (ko'paytirish ↔ bo'lish).","Chamalash: yaxlitlab, oraliq bilan.","Oxirgi raqam va juft-toq tekshiruvi.","Bo'linmani chamalash.","Javobning mantiqiyligi; to'qqiz bilan tekshirish."],
 mist:["Tekshiruvni bajarmaydi yoki noto'g'ri amal tanlaydi (371 + 12).","Chamani aniq javob deb yozadi.","Bo'linmadagi nolni yo'qotadi va chama bilan sezmaydi.","Mantiqsiz javobni qabul qiladi (3 600 o'rin)."],
 need:["Kartochkalar: 'Chama', 'Hisob', 'Tekshiruv'."],
 board:["<span class='w2'>7 824 : 24 = 326 ✓</span>","<span class='w2'>487 · 32 ≈ 500 · 30</span>","<span class='w2'>7 · 6 = 42 → …2</span>","<span class='w2'>toq · toq = toq</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
