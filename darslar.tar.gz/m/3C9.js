var CODE='3C9',TITLE='3-sinf · Ko‘paytirish xossalari';
var P1=[function(){W3arr(3,5,{lbl:'3 qator × 5 ta = 15'});W3msg('3 · 5 = 15')},
 function(){W3arr(5,3,{cols:function(){return C.a},lbl:'Burdik: 5 qator × 3 ta = 15'});W3msg('Massivni 90° burdik — nuqtalar soni <b>o‘zgarmadi</b>')},
 function(){W3arr(5,3,{cols:function(){return C.a},lbl:'3 · 5 = 5 · 3 = 15'});W3msg('<b>O‘rin almashtirish:</b> a · b = b · a')}];
var P3=[function(){W3area([12],7,{lbl:'7 · 12 = ?'});W3msg('Bu to‘rtburchakda nechta katak? Bo‘lib ko‘ramiz')},
 function(){W3area([10,2],7,{show:1,lbl:'12 = 10 + 2'});W3msg('12 ni <b>10 va 2</b> ga ajratdik')},
 function(){W3area([10,2],7,{show:2,lbl:'70 + 14 = 84'});W3msg('7 · 12 = 7 · 10 + 7 · 2 = 70 + 14 = <b>84</b>')}];
var P4=[function(){W3eq(['9 · 19 = ?'])},
 function(){W3eq(['9 · 19 = 9 · 20 − 9 · 1']);W3msg('19 = 20 − 1: «yaxlit»dan bittani olamiz')},
 function(){W3eq(['9 · 19 = 9 · 20 − 9 · 1','= 180 − 9 = [171]']);W3msg('Ayirishga nisbatan taqsimot: a · (b − c) = a · b − a · c')}];
var P8=[function(){W3eq(['(3 + 4) · 5 = ?'])},
 function(){W3eq(['(3 + 4) · 5 = 3 · 5 + 4 · 5','= 15 + 20 = [35]']);W3msg('<b>Ikkala</b> qo‘shiluvchi ham 5 ga ko‘paytiriladi')},
 function(){W3eq(['(3 + 4) · 5 = [35]','3 + 4 · 5 = 3 + 20 = 23']);W3msg('Qavssiz: avval ko‘paytirish — 23. Qavs natijani o‘zgartiradi!')}];
var STEPS=[
{h:"O'rin almashtirish xossasi",sum:"3 · 5 = 5 · 3: massivni burganda nuqtalar soni o'zgarmaydi.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>3 qator 5 tadan nuqta. Massivni burib qaraymiz.</p>",btns:[phaser(P1,'▶ Burish')],
 after:"<p><b>Ko'paytuvchilarning o'rni almashganda ko'paytma o'zgarmaydi:</b> a · b = b · a. Bu jadvalni yarmiga qisqartiradi: 8 · 3 ni bilsangiz, 3 · 8 ni ham bilasiz.</p>",
 q:{t:"9 · 7 = 63. 7 · 9 = ?",opts:["63","16","79","72"],ok:0,why:"O'rin almashtirish: 63.",hint:"Ko'paytuvchilar o'rnini almashtirsa nima bo'ladi?",full:"7 · 9 = 9 · 7 = 63. Ko'paytma o'zgarmaydi."},
 tn:"Qog'ozga chizilgan massivni bolalar o'zi aylantirsin — Yaponiyada shunday ko'rsatiladi."},
{h:"Guruhlash xossasi",sum:"2 · 5 · 7: (2 · 5) · 7 = 10 · 7 = 70 — qulay juftni avval ko'paytiramiz.",a:"m02",start:function(){W3eq(['2 · 5 · 7 = ?']);W3msg('Qaysi juftni avval ko‘paytirish qulay?')},fin:function(){W3eq(['(2 · 5) · 7 = 10 · 7 = [70]'])},
 html:"<p>Uchta sonni ko'paytiramiz. Qaysi ikkitasini avval ko'paytirasiz?</p>",
 btns:[["2 · 5",function(c,done){W3eq(['(2 · 5) · 7','= 10 · 7 = [70]']);W3msg('Juda qulay: 10 ga ko‘paytirish oson!');done()}],["5 · 7",function(){W3eq(['2 · (5 · 7)','= 2 · 35 = 70']);W3msg('Javob ham 70, lekin 2 · 35 qiyinroq. Qulayrog‘ini toping','Yana tanlang')}],["2 · 7",function(){W3eq(['(2 · 7) · 5','= 14 · 5 = 70']);W3msg('Javob ham 70! Lekin 14 · 5 og‘zaki qiyinroq','Yana tanlang')}]],g3:1,
 after:"<p><b>Ko'paytuvchilarni istalgan tartibda guruhlash mumkin:</b> (a · b) · c = a · (b · c). Javob doim bir xil — biz faqat <b>qulay</b> yo'lni tanlaymiz.</p>",
 q:{t:"Qaysi guruhlash eng qulay: 5 · 9 · 2?",opts:["(5 · 2) · 9","(5 · 9) · 2","(9 · 2) · 5","Qulay usul yo'q"],ok:0,why:"5 · 2 = 10, 10 · 9 = 90.",hint:"Qaysi ikkitasi 10 ni beradi?",full:"5 · 2 = 10, keyin 10 · 9 = 90 — og'zaki bir zumda. Boshqa yo'llar ham 90 beradi, lekin qiyinroq."},
 tn:"Bolalar «do'st juftlar»ni yod olsin: 2 · 5 = 10, 4 · 25 = 100, 2 · 50 = 100."},
{h:"Taqsimot xossasi",sum:"7 · 12 = 7 · 10 + 7 · 2 = 70 + 14 = 84 (maydon modeli).",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>7 · 12 ni jadvalda yo'q. Lekin 12 ni bo'laklarga ajratsak — oson!</p>",btns:[phaser(P3)],
 after:"<p><b>Yig'indini songa ko'paytirish:</b> (a + b) · c = a · c + b · c. Har bir bo'lakni ko'paytirib, natijalarni qo'shamiz.</p>",
 q:{t:"6 · 14 = 6 · 10 + 6 · 4 = ?",opts:["84","64","70","24"],ok:0,why:"60 + 24 = 84.",hint:"Ikkala bo'lakni ham ko'paytiring.",full:"6 · 10 = 60, 6 · 4 = 24, 60 + 24 = 84. «64» — 6 · 10 + 4: ikkinchi bo'lak ko'paytirilmagan."},
 tn:"Katakli daftarda 7 × 12 to'rtburchak chizib, uni 10 va 2 ga qaychi bilan kesing — bolalar maydonlarni sanasin."},
{h:"Ayirishga taqsimot",sum:"9 · 19 = 9 · 20 − 9 = 171: yaxlit sondan foydalanish.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>19 — 20 ga juda yaqin. Buni qanday ishlatamiz?</p>",btns:[phaser(P4)],
 after:"<p>(a − b) · c = a · c − b · c. Son yaxlitga yaqin bo'lsa (19, 29, 49, 99) — yaxlitga ko'paytirib, ortiqchasini ayiramiz.</p>",
 q:{t:"5 · 49 = ?",opts:["245","250","249","200"],ok:0,why:"5 · 50 − 5 = 245.",hint:"49 = 50 − 1.",full:"5 · 50 = 250, 250 − 5 = 245. «249» — faqat 1 ayirilgan, 5 · 1 = 5 ayirish kerak edi."},
 tn:"Hayotiy misol: 9 ta narsa 19 so'mdan — «20 so'mdan bo'lsa 180, har biridan 1 so'm qaytadi»."},
{h:"1 va 0 ning xossalari",sum:"a · 1 = a; a · 0 = 0; 0 : a = 0; 0 ga bo'lish mumkin emas.",a:"m05",start:function(){W3eq(['37 · 1 = ?','37 · 0 = ?','0 : 37 = ?'],{fs:22})},fin:function(){W3eq(['37 · 1 = [37]','37 · 0 = [0]','0 : 37 = [0]'],{fs:22})},
 html:"<p>Har birini bosib, javobni ko'ring:</p>",
 btns:[["· 1",function(c,done){W3eq(['37 · 1 = [37]'],{fs:22});W3msg('1 marta olsak — o‘zi qoladi');mvK(done,4)}],["· 0",function(c,done){W3eq(['37 · 0 = [0]'],{fs:22});W3msg('0 marta olsak — hech narsa: 0');mvK(done,4)}],["0 :",function(c,done){W3eq(['0 : 37 = [0]'],{fs:22});W3msg('0 ta olmani 37 kishiga — har biriga 0');mvK(done,4)}],[": 0",function(c,done){W3eq(['37 : 0 = ?'],{fs:22});W3msg('<b>0 ga bo‘lish mumkin emas!</b> □ · 0 = 37 bo‘ladigan son yo‘q');mvK(done,4)}]],g2:1,
 after:"<p><b>a · 1 = a</b>, <b>a · 0 = 0</b>, <b>0 : a = 0</b>, <b>a : a = 1</b>. <b>0 ga bo'lib bo'lmaydi</b>, chunki hech qaysi sonni 0 ga ko'paytirib 37 olib bo'lmaydi.</p>",
 q:{t:"(48 − 48) · 9 = ?",opts:["0","9","48","432"],ok:0,why:"48 − 48 = 0, 0 · 9 = 0.",hint:"Qavs ichini hisoblang.",full:"Qavs ichi 0, 0 · 9 = 0. «9» — 0 · 9 ni 9 deb olish odatiy xato."},
 tn:"«0 ga bo'lish mumkin emas»ni teskari amal bilan tushuntiring: □ · 0 = 37 ni hech kim to'ldira olmaydi."},
{h:"Tuzoq: qulay tartib",sum:"4 · 7 · 25 = (4 · 25) · 7 = 100 · 7 = 700.",a:"m06",start:function(){W3eq(['4 · 7 · 25 = ?']);W3msg('Og‘zaki hisoblang. Qaysi usul?')},fin:function(){W3eq(['(4 · 25) · 7','= 100 · 7 = [700]'])},
 html:"<p>Ko'pchilik chapdan o'ngga hisoblaydi: 28 · 25 — qiyin. Siz-chi?</p>",
 btns:[["4 · 25 avval",function(c,done){W3eq(['(4 · 25) · 7','= 100 · 7 = [700]']);W3msg('Zo‘r! 4 · 25 = 100 — «do‘st juft»');done()}],["4 · 7 avval",function(){W3eq(['(4 · 7) · 25','= 28 · 25 = ?']);W3msg('To‘g‘ri yo‘l, lekin 28 · 25 ni og‘zaki hisoblash qiyin','Qulayrog‘ini toping')}]],g2:1,
 after:"<p>O'rin almashtirish + guruhlash birga: avval <b>10, 100</b> beradigan juftlarni toping. 4 · 25 = 100, 2 · 50 = 100, 5 · 20 = 100.</p>",
 q:{t:"25 · 9 · 4 = ?",opts:["900","225","100","9254"],ok:0,why:"25 · 4 = 100, 100 · 9 = 900.",hint:"25 ning «do'sti» qaysi?",full:"(25 · 4) · 9 = 100 · 9 = 900. «225» — 25 · 9, 4 ga ko'paytirish unutilgan."},
 tn:"Doskada «do'st juftlar» ro'yxatini osib qo'ying: 2·5, 4·25, 2·50, 5·20, 8·125."},
{h:"Tuzoq: taqsimot teskari tomonga",sum:"6 · 8 + 6 · 2 = 6 · (8 + 2) = 60; 13 · 7 − 3 · 7 = 10 · 7 = 70.",a:"m07",start:function(){W3eq(['6 · 8 + 6 · 2 = ?']);W3msg('Umumiy ko‘paytuvchini ko‘ryapsizmi?')},fin:function(){W3eq(['6 · 8 + 6 · 2','= 6 · (8 + 2) = 6 · 10 = [60]'])},
 html:"<p>Ikkala ko'paytmada ham <b>6</b> bor. Qanday qisqartirasiz?</p>",
 btns:[["6 · (8 + 2)",function(c,done){W3eq(['6 · 8 + 6 · 2','= 6 · (8 + 2) = 6 · 10 = [60]']);W3msg('6 ni qavsdan tashqariga chiqardik');done()}],["6 · 8 · 2",function(){W3eq(['6 · 8 · 2 = 96']);W3msg('Yo‘q: 48 + 12 = 60, 96 emas','Qayta tanlang')}],["12 · 10",function(){W3eq(['12 · 10 = 120']);W3msg('Yo‘q: 6 ni ikki marta olib bo‘lmaydi. 48 + 12 = 60','Qayta tanlang')}]],g3:1,
 after:"<p>Taqsimot ikki yo'nalishda ishlaydi: a · b + a · c = <b>a · (b + c)</b>. Umumiy ko'paytuvchini <b>bir marta</b> yozamiz.</p>",
 q:{t:"13 · 7 − 3 · 7 = ?",opts:["70","91","21","112"],ok:0,why:"(13 − 3) · 7 = 70.",hint:"7 — umumiy ko'paytuvchi.",full:"(13 − 3) · 7 = 10 · 7 = 70. «91» — faqat 13 · 7 hisoblangan, «112» — ayirish o'rniga qo'shilgan."},
 tn:"Maydon modelida ikki to'rtburchak bir xil balandlikda — ularni yonma-yon qo'yib bitta katta to'rtburchak qiling."},
{h:"Tuzoq: qavs muhim",sum:"(3 + 4) · 5 = 35, 3 + 4 · 5 = 23: qavs bilan har ikki qo'shiluvchi ko'paytiriladi.",a:"m08",start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Bolalar ko'pincha (3 + 4) · 5 = 3 + 20 deb yozib qo'yishadi. Kuzating:</p>",btns:[phaser(P8)],
 after:"<p>Qavsli yig'indini ko'paytirganda <b>har bir</b> qo'shiluvchi ko'paytiriladi. Qavs bo'lmasa — avval ko'paytirish, keyin qo'shish.</p>",
 q:{t:"(10 + 6) · 3 = ?",opts:["48","28","19","36"],ok:0,why:"30 + 18 = 48.",hint:"Ikkala sonni ham 3 ga ko'paytiring.",full:"10 · 3 + 6 · 3 = 30 + 18 = 48. «28» — 10 + 6 · 3 deb hisoblangan (qavs e'tiborsiz)."},
 tn:"Ikki rangli qalam bilan: qavs ichidagi har songa strelka chizdiring — ikkala strelka ham ko'paytuvchiga borsin."},
{h:"Bilasizmi? Neper tayoqchalari",sum:"1617-yilda Jon Neper ko'paytirishni osonlashtiradigan tayoqchalarni tasvirlagan.",a:"m09",start:function(){clear('#f6ead0');var g=S.g;for(var i=0;i<4;i++){var x=70+i*60;E('rect',{x:x,y:14,width:44,height:150,rx:4,fill:'#f2d79b',stroke:'#6b3d12'},g);T(g,x+22,32,String([3,4,7,9][i]),{'font-size':15,'font-weight':800,fill:'#6b3d12'});for(var j=1;j<=4;j++){var v=[3,4,7,9][i]*(j+1);E('line',{x1:x,y1:14+j*30,x2:x+44,y2:14+j*30,stroke:'#6b3d12'},g);T(g,x+22,36+j*30,String(v),{'font-size':12,'font-weight':700,fill:'#33475b'})}}W3msg('Har tayoqchada bitta sonning karrali sonlari')},fin:function(){STEPS[8].start()},
 html:"<p>🪵 Shotlandiyalik olim <b>Jon Neper</b> 1617-yilda ko'paytirishni osonlashtiradigan tayoqchalarni tasvirlab berdi. Har bir tayoqchada bitta sonning ko'paytmalari yozilgan. Tayoqchalarni yonma-yon qo'yib, katta sonlarni ko'paytirish mumkin bo'lgan — aynan <b>taqsimot xossasi</b> asosida!</p>",
 tn:"Karton tayoqchalarda 1–9 karralilarini yozdirib, sinfda «Neper tayoqchalari» yasang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3area([10,2],7,{show:2,lbl:'7 · 12 = 70 + 14 = 84'})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>O'rin almashtirish:</b> a · b = b · a.</li><li><b>Guruhlash:</b> (a · b) · c = a · (b · c) — qulay juftni avval: 4 · 7 · 25 = 100 · 7.</li><li><b>Taqsimot:</b> (a + b) · c = a · c + b · c: 7 · 12 = 70 + 14.</li><li>a · (b − c) = a · b − a · c: 9 · 19 = 180 − 9.</li><li>Teskari: 6 · 8 + 6 · 2 = 6 · 10.</li><li>a · 1 = a, a · 0 = 0, 0 : a = 0, <b>0 ga bo'lish mumkin emas</b>.</li></ul></div>",
 tn:"Keyingi mavzu: shu xossalar asosida og'zaki hisoblash usullari."}
];
var PROBS=[
{t:"8 · 6 = 48. 6 · 8 = ?",o:["48","14","68","86"],k:0,s:"O'rin almashtirish: 48."},
{t:"(2 · 9) · 5 = 2 · (9 · □). □ = ?",o:["5","2","9","10"],k:0,s:"Guruhlash: ko'paytuvchilar o'zgarmaydi."},
{t:"53 · 1 = ?",o:["53","1","54","0"],k:0,s:"a · 1 = a."},
{t:"0 · 86 = ?",o:["0","86","1","860"],k:0,s:"0 ga ko'paytma 0."},
{t:"Qaysi ifodaning qiymati yo'q?",o:["9 : 0","0 : 9","9 · 0","0 · 9"],k:0,s:"0 ga bo'lish mumkin emas."},
{t:"5 · 13 · 2 = ?",o:["130","65","26","1310"],k:0,s:"(5 · 2) · 13 = 130."},
{t:"4 · 9 · 25 = ?",o:["900","225","36","100"],k:0,s:"100 · 9 = 900."},
{t:"8 · 13 = 8 · 10 + 8 · □. □ = ?",o:["3","13","10","8"],k:0,s:"13 = 10 + 3."},
{t:"6 · 17 = ?",o:["102","67","96","112"],k:0,s:"60 + 42 = 102."},
{t:"7 · 29 = ?",o:["203","210","209","196"],k:0,s:"7 · 30 − 7 = 203."},
{t:"9 · 6 + 9 · 4 = ?",o:["90","54","36","94"],k:0,s:"9 · (6 + 4) = 90."},
{t:"15 · 8 − 5 · 8 = ?",o:["80","120","40","160"],k:0,s:"(15 − 5) · 8 = 80."},
{t:"(20 + 3) · 4 = ?",o:["92","32","83","27"],k:0,s:"80 + 12 = 92."},
{t:"Qaysi tenglik noto'g'ri?",o:["(5 + 2) · 3 = 5 + 6","3 · 7 = 7 · 3","4 · 25 = 100","8 · 0 = 0"],k:0,s:"(5 + 2) · 3 = 21, 5 + 6 = 11."},
{t:"(67 − 67) · 45 + 45 = ?",o:["45","0","90","3015"],k:0,s:"0 · 45 + 45 = 45."},
{t:"2 · 7 · 50 = ?",o:["700","140","350","1400"],k:0,s:"(2 · 50) · 7 = 700."},
{t:"12 · 5 = 6 · □. □ = ?",o:["10","5","12","60"],k:0,s:"12 · 5 = 6 · 2 · 5 = 6 · 10."},
{t:"Bir qatorda 9 ta, 11 ta qator. Jami nechta stul?",o:["99","90","20","109"],k:0,s:"9 · 11 = 90 + 9 = 99."},
{t:"3 ta qutida 8 tadan qizil va 2 tadan ko'k shar. Jami nechta shar?",o:["30","26","13","48"],k:0,s:"3 · (8 + 2) = 30."},
{t:"a · 7 = 56 bo'lsa, a · 7 · 0 · 5 = ?",o:["0","56","280","35"],k:0,s:"0 ga ko'paytma — 0."}
];
function PRACT_STAGE(){W3area([10,2],7,{show:1,lbl:'(a + b) · c = a · c + b · c'})}
var PREP_DATA={teach:["O'rin almashtirish (massivni burish).","Guruhlash va «do'st juftlar» (2·5, 4·25).","Taqsimot xossasi: qo'shish va ayirishga nisbatan (maydon modeli).","1 va 0 xossalari, 0 ga bo'lish mumkin emasligi."],
 mist:["(3 + 4) · 5 = 3 + 20 (faqat bitta qo'shiluvchini ko'paytiradi).","5 · 49 = 250 − 1.","0 · 9 = 9.","6 · 8 + 6 · 2 = 12 · 10."],
 need:["Katakli daftar, qaychi (maydon modeli).","Nuqtali massiv kartochkasi, «do'st juftlar» plakati."],
 board:["<span class='w2'>3 · 5 = 5 · 3</span>","<span class='w2'>(2 · 5) · 7 = 70</span>","<span class='w2'>7 · 12 = 70 + 14 = 84</span>","<span class='w2'>9 · 19 = 180 − 9 = 171</span>","<span class='w2'>a · 0 = 0, a : 0 — mumkin emas</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
