var CODE='2H16',TITLE='2-sinf · Tanga va pul jumboqlari';
// ---------- sahna: tangalar ----------
var H16C={100:'#d9dde2',200:'#e9c46a',500:'#c9a227',1000:'#9ad0a4',2000:'#a9c7ee',5000:'#f2a7a7'};
function h16Coin(g,x,y,v,o){o=o||{};var bill=v>=1000;if(bill){E('rect',{x:x-24,y:y-14,width:48,height:28,rx:4,fill:H16C[v],stroke:'#5b6b7b','stroke-width':1.2},g);T(g,x,y+4,String(v),{'font-size':11,'font-weight':800,fill:'#1d2b3a'})}
 else{var r=v===100?12:(v===200?14:16);E('circle',{cx:x,cy:y,r:r,fill:H16C[v],stroke:o.hl?C.ok:'#8a6a2a','stroke-width':o.hl?3:1.4},g);T(g,x,y+4,String(v),{'font-size':v===100?9:10,'font-weight':800,fill:'#3a2a0a'})}}
function h16Row(list,title,o){o=o||{};clear();var g=S.g;if(title)T(g,180,20,title,{'font-size':12,'font-weight':800,fill:C.blue});
 var x=30,y=56;list.forEach(function(v,i){var w=v>=1000?54:36;if(x+w>350){x=30;y+=40}h16Coin(g,x+w/2-4,y,v,{hl:o.hl&&o.hl.indexOf(i)>=0});x+=w});
 var s=list.reduce(function(a,b){return a+b},0);if(!o.nosum)T(g,180,160,'Jami: '+s+' so‘m',{'font-size':15,'font-weight':800,fill:o.target&&s===o.target?C.ok:'#1d2b3a'});S.sum=s}
function h16Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function h16Ways(rows,hl){clear();var g=S.g;T(g,180,18,'1 500 so‘m: faqat 500 va 200 so‘mlik tangalar',{'font-size':11,'font-weight':800,fill:C.blue});
 rows.forEach(function(r,i){var y=40+i*32,ok=r[2];E('rect',{x:14,y:y-14,width:332,height:28,rx:8,fill:ok?'#e6f6ee':(ok===false?'#fdeaea':'#fff'),stroke:ok?C.ok:(ok===false?C.bad:'#dde5ee')},g);T(g,22,y+4,r[0],{'font-size':12,'font-weight':700,'text-anchor':'start',fill:'#1d2b3a'});T(g,338,y+4,r[1],{'font-size':12,'font-weight':800,'text-anchor':'end',fill:ok?C.ok:(ok===false?C.bad:'#5b6b7b')})})}
// ---------- bosqichlar ----------
var P2=[function(){h16Row([1000,500],'Muzqaymoq 1 500 so‘m. Eng kam pul bilan to‘lang');h16Msg('Avval <b>eng kattasini</b> olamiz: 1 000 so‘mlik')},
 function(){h16Row([1000,500],'1 000 + 500 = 1 500',{hl:[0,1]});h16Msg('Qolgan 500 — bitta 500 so‘mlik. Jami <b>2 ta</b> pul')},
 function(){h16Row([500,500,500],'Boshqa yo‘l: 3 ta 500 so‘mlik');h16Msg('Bu ham 1 500, lekin <b>3 ta</b> — ko‘proq. Eng kami — <b>2 ta</b>')}];
var P3=[function(){h16Ways([['500 so‘mlik — 3 ta','?'],['500 so‘mlik — 2 ta','?'],['500 so‘mlik — 1 ta','?'],['500 so‘mlik — 0 ta','?']]);h16Msg('Tartib bilan sinaymiz: 500 so‘mliklar sonini 3, 2, 1, 0 qilib')},
 function(){h16Ways([['3 · 500 = 1 500','✓ bo‘ladi',true],['2 · 500 = 1 000, qoldi 500','?'],['500 so‘mlik — 1 ta','?'],['500 so‘mlik — 0 ta','?']]);h16Msg('3 ta 500 so‘mlik — bo‘ladi')},
 function(){h16Ways([['3 · 500 = 1 500','✓ bo‘ladi',true],['2 · 500, qoldi 500 — 200 bilan yig‘ilmaydi','✗',false],['1 · 500, qoldi 1 000 = 5 · 200','✓ bo‘ladi',true],['0 · 500, qoldi 1 500 — 200 bilan yig‘ilmaydi','✗',false]]);h16Msg('Javob: <b>2 xil</b> usul. Tartib bilan sinasak, birorta usul tushib qolmaydi')}];
var P4=[function(){h16Row([],'3 ta tanga, jami 1 200 so‘m (500 va 200)',{nosum:1});h16Msg('500 so‘mliklar nechta bo‘lishi mumkin? Sinaymiz')},
 function(){h16Row([500,500,500],'3 ta 500 = 1 500 — ko‘p');h16Msg('3 ta 500 so‘mlik — 1 500, ko‘p ✗')},
 function(){h16Row([500,500,200],'2 ta 500 + 1 ta 200',{target:1200,hl:[0,1,2]});h16Msg('2 · 500 + 200 = <b>1 200</b> ✓. Demak 500 so‘mliklar — <b>2 ta</b>')}];
var P5=[function(){h16Row([100,200,500],'Lolada 100, 200, 500 dan bittadan',{nosum:1});h16Msg('Bitta, ikkita yoki uchalasini berib, nechta xil summa?')},
 function(){h16Row([100,200,500],'bittadan: 100, 200, 500',{nosum:1});h16Msg('Bittadan: <b>100, 200, 500</b> — 3 ta')},
 function(){h16Row([100,200,500],'ikkitadan: 300, 600, 700',{nosum:1});h16Msg('Ikkitadan: 100+200 = <b>300</b>, 100+500 = <b>600</b>, 200+500 = <b>700</b> — 3 ta')},
 function(){h16Row([100,200,500],'uchalasi: 800',{nosum:1});h16Msg('Uchalasi: <b>800</b>. Jami: 3 + 3 + 1 = <b>7 xil</b> summa')}];
var STEPS=[
{h:"Pulni roppa-rosa yig'amiz",sum:"Tangalarni qo'shib kerakli summani yig'amiz: 1 200 = 500 + 500 + 200.",a:"m01",
 start:function(){S.l=[];h16Row([],'Non va sut: 1 200 so‘m',{target:1200});h16Msg('Tangalarni bosib, <b>roppa-rosa 1 200</b> so‘m yig‘ing')},fin:function(){h16Row([500,500,200],'1 200 so‘m',{target:1200});h16Msg('500 + 500 + 200 = 1 200 ✓')},
 html:"<p>Do'konda non va sut <b>1 200 so'm</b>. Tangalarni bosing va roppa-rosa shu summani yig'ing. Oshib ketsa — «Tozalash».</p>",
 btns:[["100",function(c,done){h16Add(100,done)}],["200",function(c,done){h16Add(200,done)}],["500",function(c,done){h16Add(500,done)},'u'],["Tozalash",function(){S.l=[];h16Row([],'Non va sut: 1 200 so‘m',{target:1200});h16Msg('Qaytadan')}]],g2:1,
 after:"<p>1 200 ni turlicha yig'ish mumkin: 500 + 500 + 200, yoki 6 ta 200, yoki 12 ta 100… Masalalarda odatda «<b>eng kam</b> tanga» yoki «<b>necha xil</b> usul» so'raladi.</p>",
 q:{t:"Alida faqat 200 so'mlik tangalar bor. 1 000 so'mlik non uchun u nechta tanga beradi?",opts:["4","10","5","2"],ok:2,why:"200 + 200 + 200 + 200 + 200 = 1 000 — 5 ta.",hint:"200 dan sanab boring: 200, 400, 600…",full:"200, 400, 600, 800, 1 000 — 5 ta tanga. «10» — 100 so'mlik tangalar uchun javob bo'lardi."},
 tn:"Sinfda o'yinchoq pullar bilan «do'kon» o'ynang. Uzbekistonda hozir 100, 200, 500 so'mlik tangalar va 1 000 so'mdan boshlab qog'oz pullar ishlatiladi."},
{h:"Eng kam pul bilan",sum:"Eng kam pul bilan to'lash uchun avval eng katta pulni olamiz: 1 500 = 1 000 + 500 (2 ta).",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Muzqaymoq <b>1 500 so'm</b>. Alida 1 000 so'mlik va 500 so'mlik pullar bor. U <b>eng kami bilan</b> nechta pul beradi?</p>",
 btns:[phaser(P2)],
 after:"<p>Qoida: <b>eng kam</b> pul bilan to'lash uchun avval <b>eng kattasini</b> imkon qadar ko'p olamiz, keyin qolganini kichiklari bilan to'ldiramiz.</p>",
 q:{t:"5 tangalik va 2 tangalik jetonlar bor. Roppa-rosa 11 tanga to'lash uchun eng kami bilan nechta jeton kerak?",opts:["3","5","4","6"],ok:2,why:"5 + 2 + 2 + 2 = 11 — 4 ta jeton.",hint:"5 lik jetondan 2 tasini olsangiz, qolgan 1 ni 2 lik bilan yig'ib bo'ladimi?",full:"5 + 5 = 10, qolgan 1 ni 2 lik bilan yig'ib bo'lmaydi. Demak 5 likdan bitta: 5, qolgan 6 = 2 + 2 + 2. Jami 4 ta jeton. Bu yerda «eng kattasidan ko'p» qoidasi har doim ishlamaydi — tekshirish kerak!"},
 tn:"Savolda tuzoq bor: «eng kattasini ko'p olish» har doim ham ishlamaydi. Bolalar qoldiqni tekshirishga o'rgansin."},
{h:"Necha xil usulda?",sum:"Tartib bilan sinaymiz: 500 so'mliklar 3, 2, 1, 0 ta. 1 500 ni 500 va 200 bilan 2 xil usulda.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Faqat <b>200 va 500 so'mlik</b> tangalar bilan roppa-rosa <b>1 500 so'm</b>ni necha xil usulda to'lash mumkin? Hech qaysi usul tushib qolmasligi uchun <b>tartib bilan</b> sinaymiz.</p>",
 btns:[phaser(P3)],
 after:"<p>Usul: bitta tanga sonini <b>kattadan kichikka</b> o'zgartirib boramiz va har safar qolganini tekshiramiz. Bunday ro'yxat hech narsani unutmaydi.</p>",
 q:{t:"Faqat 100 va 500 so'mlik tangalar bilan 1 000 so'mni necha xil usulda to'lash mumkin?",opts:["2","3","1","10"],ok:1,why:"2 · 500; 1 · 500 + 5 · 100; 10 · 100 — 3 xil.",hint:"500 so'mliklar sonini 2, 1, 0 qilib sinang.",full:"500 so'mlik 2 ta — 1 000 ✓. 1 ta — qolgan 500 = 5 · 100 ✓. 0 ta — 10 · 100 ✓. Jami 3 xil usul."},
 tn:"Doskada jadval chizing: «500 lik | 200 lik | jami». Bolalar qatorlarni to'ldirib borsin."},
{h:"Tangalar soni va summa",sum:"3 ta tanga = 1 200 (500 va 200): 3 ta 500 — ko'p; 2 ta 500 + 200 = 1 200 ✓.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«Valining cho'ntagida <b>3 ta</b> tanga, jami <b>1 200 so'm</b>. Tangalar faqat 200 va 500 so'mlik. 500 so'mliklar nechta?»</p>",
 btns:[phaser(P4,'▶ Sinab ko‘rish')],
 after:"<p>Ikki shart birga bajarilishi kerak: <b>tangalar soni</b> ham, <b>summa</b> ham. Sinab ko'ramiz: 3 ta 500 — 1 500 (ko'p), 2 ta 500 va 1 ta 200 — 1 200 ✓.</p>",
 q:{t:"Lolada 4 ta tanga bor, jami 1 100 so'm. Tangalar 500 va 200 so'mlik. 200 so'mliklar nechta?",opts:["1","3","2","4"],ok:1,why:"1 · 500 + 3 · 200 = 1 100, jami 4 ta tanga.",hint:"500 so'mlikni 2 ta deb sinang: qolgan 2 ta tanga 100 ni beradimi?",full:"2 ta 500 = 1 000, qolgan 2 tanga 100 ni berishi kerak — 200 lik bilan bo'lmaydi. 1 ta 500, qolgan 3 ta 200 = 600, jami 1 100 ✓. Demak 200 so'mliklar 3 ta."},
 tn:"Bunday masalalar keyinchalik «ikki noma'lumli» masalalarga o'tadi. Hozir — sinab ko'rish usuli."},
{h:"Tuzoq: nechta xil summa?",sum:"100, 200, 500 dan bittadan: 100, 200, 500, 300, 600, 700, 800 — 7 xil summa.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>«Lolada 100, 200 va 500 so'mlik tangalardan <b>bittadan</b> bor. Bittasini, ikkitasini yoki uchalasini berib, <b>necha xil</b> summani to'lash mumkin?» Ko'pchilik «3» deydi…</p>",
 btns:[phaser(P5,'▶ Keyingi guruh')],
 after:"<p>Usul: summalarni <b>guruhlab</b> sanaymiz — bittadan, ikkitadan, uchtadan. Hech biri takrorlanmasligini tekshiramiz: 100, 200, 300, 500, 600, 700, 800 — <b>7 ta</b>.</p>",
 q:{t:"Alida 100 va 200 so'mlik tangalardan bittadan bor. Necha xil summani to'lay oladi?",opts:["2","4","3","1"],ok:2,why:"100, 200, 300 — 3 xil.",hint:"Bittadan bersa nechta summa? Ikkalasini birga bersa-chi?",full:"Bittadan: 100 va 200. Ikkalasi: 300. Jami 3 xil summa."},
 tn:"Kombinatorikaning ilk qadami. Bolalar ro'yxatni o'zi tuzsin, keyin tekshirsin."},
{h:"Qaytim",sum:"Qaytim = berilgan pul − narx: 1 000 − 700 = 300 so'm.",a:"m06",
 start:function(){S.k6=0;h16Row([1000],'Daftar 700 so‘m. Ali 1 000 so‘m berdi');h16Msg('Sotuvchi qancha qaytim beradi?')},fin:function(){h16Row([200,100],'Qaytim: 300 so‘m');h16Msg('1 000 − 700 = <b>300</b> so‘m')},
 html:"<p>Daftar <b>700 so'm</b>. Ali <b>1 000 so'm</b> berdi. Qaytimni sanang: sotuvchi 700 dan boshlab 1 000 gacha «sanab» beradi.</p>",
 btns:[["▶ Sanab berish",function(c,done,b){S.k6++;if(S.k6===1){h16Row([200],'700 + 200 = 900');h16Msg('700 + 200 = 900')}else{h16Row([200,100],'900 + 100 = 1 000',{target:300});h16Msg('Qaytim: 200 + 100 = <b>300</b> so‘m');b.disabled=true;done()}}]],
 after:"<p>Qaytimni ikki yo'l bilan topish mumkin: <b>ayirib</b> (1 000 − 700 = 300) yoki sotuvchidek <b>narxdan berilgan pulgacha sanab</b> (700 → 900 → 1 000).</p>",
 q:{t:"Kitob 1 300 so'm. Lola 2 000 so'm berdi. Qancha qaytim oladi?",opts:["700 so'm","1 300 so'm","3 300 so'm","800 so'm"],ok:0,why:"2 000 − 1 300 = 700.",hint:"1 300 dan 2 000 gacha sanang: 1 300 → 1 500 → 2 000.",full:"2 000 − 1 300 = 700 so'm. Sanab: 1 300 + 200 = 1 500, + 500 = 2 000 — qaytim 200 + 500 = 700."},
 tn:"Hayotiy ko'nikma: bolalar uyga borib, do'kondagi qaytimni o'zi tekshirsin."},
{h:"Bilasizmi? Pulning tarixi",sum:"O'zbekiston so'mi 1994-yildan beri muomalada. Qadimda ayirboshlash, keyin tangalar paydo bo'lgan.",a:"m07",
 start:function(){h16Row([100,200,500,1000,2000,5000],'Bizning pullar',{nosum:1});h16Msg('100 so‘mdan boshlab')},fin:function(){h16Row([100,200,500,1000,2000,5000],'Bizning pullar',{nosum:1});h16Msg('100 so‘mdan boshlab')},
 html:"<p>🐑 Juda qadimda odamlar pul ishlatmagan — narsani narsaga <b>ayirboshlagan</b>: bitta qo'yni bir qop bug'doyga. Bu juda noqulay edi.</p><p>🪙 Keyin metall <b>tangalar</b> paydo bo'ldi, ularning qiymati yozib qo'yilgan. Buyuk Ipak yo'lidagi shaharlarimizda — Samarqand, Buxoro, Xorazmda — o'z tangalari zarb qilingan.</p><p>🇺🇿 O'zbekistonning milliy puli — <b>so'm</b> — 1994-yildan beri muomalada.</p>",
 tn:"Muzeyga sayohat yoki eski tanga ko'rsatish — eng yaxshi dars."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h16Row([500,500,200],'1 200 so‘m',{target:1200});h16Msg('500 + 500 + 200')},fin:function(){h16Row([500,500,200],'1 200 so‘m',{target:1200});h16Msg('500 + 500 + 200')},
 html:"<div class='memo'><ul><li><b>Eng kam</b> pul: avval eng kattasini oling, lekin qolganini <b>tekshiring</b> (11 = 5 + 2 + 2 + 2).</li><li><b>Necha xil usul</b>: bitta tanga sonini kattadan kichikka o'zgartirib, tartib bilan sinang.</li><li><b>Soni va summasi</b> berilsa — ikkala shartni birga tekshiring.</li><li><b>Necha xil summa</b>: bittadan, ikkitadan, uchtadan guruhlab sanang.</li><li><b>Qaytim</b> = berilgan pul − narx.</li></ul></div>",
 tn:"Keyingi darsni «Faqat 200 va 500 so'mlik tangalar bilan 900 so'mni yig'ib bo'ladimi?» (ha: 500 + 200 + 200) savoli bilan boshlang."}
];
function h16Add(v,done){S.l=S.l||[];if(S.l.length>=10){h16Msg('Joy qolmadi — «Tozalash»ni bosing');return}S.l.push(v);h16Row(S.l,'Non va sut: 1 200 so‘m',{target:1200});var s=S.sum;
 if(s===1200){h16Msg('Roppa-rosa <b>1 200</b> ✓');done()}else h16Msg(s<1200?'Yana '+(1200-s)+' so‘m kerak':'Ko‘p bo‘ldi ('+s+') — «Tozalash»')}
var PROBS=[
{t:"Alida faqat 200 so'mlik tangalar bor. 1 000 so'mlik non uchun nechta tanga beradi?",o:["5","4","10","2"],k:0,s:"200 · 5 = 1 000."},
{t:"Muzqaymoq 1 500 so'm. 1 000 so'mlik va 500 so'mlik pullar bilan eng kami nechta pul beriladi?",o:["2","3","1","4"],k:0,s:"1 000 + 500 — 2 ta."},
{t:"Faqat 200 va 500 so'mlik tangalar bilan 1 500 so'mni necha xil usulda to'lash mumkin?",o:["2","3","1","4"],k:0,s:"3 · 500 va 1 · 500 + 5 · 200 — 2 xil."},
{t:"5 tangalik va 2 tangalik jetonlar bor. 11 tanga uchun eng kami nechta jeton?",o:["4","3","5","6"],k:0,s:"5 + 2 + 2 + 2 = 11 — 4 ta."},
{t:"Lolada 100, 200, 500 so'mlik tangalardan bittadan. Necha xil summa to'lay oladi?",o:["7","3","6","8"],k:0,s:"100, 200, 500, 300, 600, 700, 800 — 7 xil."},
{t:"Valida 3 ta tanga, jami 1 200 so'm (200 va 500 so'mlik). 500 so'mliklar nechta?",o:["2","1","3","0"],k:0,s:"2 · 500 + 200 = 1 200."},
{t:"Lolada 200 so'mlik 3 ta tanga, 100 so'mliklari esa 2 ta ko'p. Jami qancha pul bor?",o:["1 100 so'm","800 so'm","1 000 so'm","1 300 so'm"],k:0,s:"3 · 200 = 600, 5 · 100 = 500, jami 1 100."},
{t:"Daftar 700 so'm. Ali 1 000 so'm berdi. Qaytim qancha?",o:["300 so'm","1 700 so'm","700 so'm","200 so'm"],k:0,s:"1 000 − 700 = 300."},
{t:"Kitob 1 300 so'm. Lola 2 000 so'm berdi. Qaytim qancha?",o:["700 so'm","800 so'm","1 300 so'm","3 300 so'm"],k:0,s:"2 000 − 1 300 = 700."},
{t:"Faqat 100 va 500 so'mlik tangalar bilan 1 000 so'mni necha xil usulda to'lash mumkin?",o:["3","2","1","10"],k:0,s:"2 · 500; 500 + 5 · 100; 10 · 100 — 3 xil."},
{t:"Alida 4 ta tanga, jami 1 100 so'm (500 va 200 so'mlik). 200 so'mliklar nechta?",o:["3","1","2","4"],k:0,s:"500 + 3 · 200 = 1 100."},
{t:"Ruchka 600 so'm. 200 so'mlik tangalar bilan nechta tanga beriladi?",o:["3","6","2","4"],k:0,s:"600 : 200 = 3."},
{t:"Eng kam tanga bilan 800 so'm to'lang (100, 200, 500 so'mliklar bor). Nechta tanga?",o:["3","4","2","8"],k:0,s:"500 + 200 + 100 — 3 ta."},
{t:"Eng kam tanga bilan 900 so'm to'lang (100, 200, 500 so'mliklar bor). Nechta tanga?",o:["3","4","2","9"],k:0,s:"500 + 200 + 200 — 3 ta."},
{t:"Alida 2 000 so'm bor edi. U 500 so'mlik 3 ta qalam oldi. Qancha puli qoldi?",o:["500 so'm","1 500 so'm","1 000 so'm","0 so'm"],k:0,s:"3 · 500 = 1 500, 2 000 − 1 500 = 500."},
{t:"Alida 100 va 200 so'mlik tangalardan bittadan. Necha xil summa to'lay oladi?",o:["3","2","4","1"],k:0,s:"100, 200, 300."},
{t:"Valida 500 so'mlik 2 ta va 200 so'mlik 3 ta tanga bor. U 1 500 so'mlik o'yinchoqni roppa-rosa to'lay oladimi?",o:["Yo'q, roppa-rosa 1 500 yig'ilmaydi","Ha, 500 + 500 + 200 + 200 + 200","Ha, 500 + 500 + 500","Yo'q, puli 1 400"],k:0,s:"Mumkin summalar: 500·a + 200·b. 1 500 uchun 1 000 + 500 kerak, lekin 500 ni 200 lar bilan yig'ib bo'lmaydi; 3 · 500 esa yo'q. To'lay olmaydi (jami puli 1 600)."},
{t:"Pirojnoe 800 so'm. Lola 1 000 so'm berdi, sotuvchida faqat 100 so'mlik tangalar bor. Qaytimga nechta tanga beradi?",o:["2","20","8","1"],k:0,s:"Qaytim 200 = 2 · 100."},
{t:"Alida 500 so'mlik va 200 so'mlik tangadan bittadan bor. Ularni 100 so'mlik tangalarga almashtirsa, nechta tanga oladi?",o:["7","2","5","70"],k:0,s:"500 + 200 = 700 = 7 · 100."},
{t:"Ali 1 200 so'mni 200 so'mlik tangalarda, Vali 1 500 so'mni 500 so'mlik tangalarda to'ladi. Kim ko'p tanga berdi va qanchaga?",o:["Ali, 3 taga","Vali, 3 taga","Teng","Ali, 6 taga"],k:0,s:"Ali 6 ta, Vali 3 ta — Ali 3 ta ko'p."}
];
function PRACT_STAGE(){h16Row([500,500,200],'1 200 so‘m',{target:1200});h16Msg('Tartib bilan sinang')}
var PREP_DATA={teach:["Tangalar bilan summani yig'ish.","Eng kam pul bilan to'lash (va qoldiqni tekshirish).","Necha xil usul — tartibli ro'yxat.","Tangalar soni va summasi; necha xil summa; qaytim."],
 mist:["«Eng kattasini ko'p olish» qoidasini tekshirmasdan qo'llaydi (11 = 5 + 5 + ?).","Usullarni tartibsiz sanab, birini unutadi.","«Necha xil summa» da faqat tangalar sonini aytadi.","Qaytimda qo'shib yuboradi."],
 need:["O'yinchoq pullar yoki karton tangalar (100, 200, 500)."],
 board:["<span class='w2'>1 200 = 500 + 500 + 200</span>.","Eng kam: <span class='w2'>1 500 = 1 000 + 500</span>.","Jadval: <span class='w2'>500 lik | 200 lik | jami</span>.","Summalar: <span class='w2'>100, 200, 500 | 300, 600, 700 | 800</span>.","Qaytim: <span class='w2'>1 000 − 700 = 300</span>."]};
