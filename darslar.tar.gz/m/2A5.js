var CODE='2A5',TITLE='2-sinf · Sonning tarkibi, xona birliklari';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// o'nliklar va birliklar sahnasi (birliklar 30 tagacha)
function tu(t,u,o){o=o||{};clear();var g=S.g;S.t=t;S.u=u;
 E('rect',{x:4,y:4,width:200,height:166,rx:10,fill:'#fdf3e3',stroke:'#efd9b5'},g);E('rect',{x:208,y:4,width:148,height:166,rx:10,fill:'#e3f5f3',stroke:'#bfe6e1'},g);
 T(g,104,20,'O‘nliklar: '+t,{'font-size':12,'font-weight':800,fill:C.t1});T(g,282,20,'Birliklar: '+u,{'font-size':12,'font-weight':800,fill:C.u});
 for(var i=0;i<t;i++)rod(g,22+i*20,32,110);
 for(var k=0;k<u;k++)unit(g,222+(k%6)*22,38+Math.floor(k/6)*24,o.hiU&&k>=u-10?C.hi:null);
 var n=t*10+u;if(!o.nostrip)msg(t+' o‘nlik + '+u+' birlik = '+(t*10)+' + '+u+' = <b>'+n+'</b>')}
var P2=[function(){tu(6,4);msg('64 = <b>6 o‘nlik 4 birlik</b>')},
 function(){tu(5,14,{hiU:1});msg('Bitta o‘nlikni «yechdik» — 10 ta birlik bo‘ldi: <b>5 o‘nlik 14 birlik</b> = 50 + 14 = 64')},
 function(){tu(4,24);msg('Yana bittasini: <b>4 o‘nlik 24 birlik</b> = 40 + 24 = 64. Son o‘zgarmadi!')}];
var P4=[function(){tu(5,3);msg('Son 53. O‘nlar raqami 3 ga kamayadi, birlar raqami 2 ga ortadi')},
 function(){tu(2,3);msg('3 ta o‘nlik olindi: −30. Son: 23')},
 function(){tu(2,5);msg('2 ta birlik qo‘shildi: +2. Son: 25. Jami: 53 → 25, ya‘ni <b>28 ga kamaydi</b> (30 − 2)')}];
var P5=[function(){nl5(40,55,47,null);msg('47 ning o‘nlar raqami (4) 1 taga oshishi uchun eng kamida nechani qo‘shamiz?')},
 function(){nl5(40,55,47,50);msg('O‘nlar raqami 5 bo‘lishi uchun eng yaqin son — <b>50</b>. 47 dan 50 gacha: <b>3</b> qadam')}];
var P6=[function(){dsum(0);msg('Raqamlari yig‘indisi 7 bo‘lgan ikki xonali sonlar. O‘nlar raqamini 1 dan boshlab sinaymiz')},
 function(){dsum(4);msg('O‘nlar 1 → birlar 6: 16; 2 → 5: 25; 3 → 4: 34; 4 → 3: 43…')},
 function(){dsum(7);msg('… 52, 61, 70. O‘nlar 8 bo‘lsa — birlar −1, bo‘lmaydi. Jami <b>7 ta</b>')}];
var STEPS=[
{h:"Son nimalardan tuzilgan?",sum:"Ikki xonali son = o'nliklar + birliklar: 47 = 40 + 7 (xona qo'shiluvchilari).",a:"m01",
 start:function(){tu(4,7)},fin:function(){tu(4,7)},
 html:"<p>Har bir ikki xonali son <b>o'nliklar</b> va <b>birliklardan</b> tuziladi. Tugmalar bilan sonni o'zgartiring va pastdagi yozuvni kuzating.</p>",
 btns:[["+ o'nlik",function(c,done){if(S.t<9){tu(S.t+1,Math.min(S.u,9));mvK(done)}}],["− o'nlik",function(c,done){if(S.t>1){tu(S.t-1,Math.min(S.u,9));mvK(done)}}],["+ birlik",function(c,done){if(S.u<9){tu(S.t,S.u+1);mvK(done)}},'u'],["− birlik",function(c,done){if(S.u>0){tu(S.t,S.u-1);mvK(done)}},'u']],g2:1,
 after:"<p>47 = <b>4 o'nlik 7 birlik</b> = <b>40 + 7</b>. 40 va 7 — <b>xona qo'shiluvchilari</b>: birinchisi o'nliklar xonasidan, ikkinchisi birliklar xonasidan.</p>",
 q:{t:"60 + □ = 6 o'nlik 9 birlik. □ o'rniga qaysi son yoziladi?",opts:["90","9","69","3"],ok:1,why:"6 o'nlik = 60, 9 birlik = 9: 60 + 9.",hint:"6 o'nlik nechaga teng? Qolgan qismi qancha?",full:"6 o'nlik 9 birlik = 69 = 60 + 9. Demak □ = 9. «69» — butun son, «90» — 9 o'nlik bo'lib qoladi."},
 tn:"Doskada: «47 = 40 + 7». Bolalar navbat bilan son aytadi, sinf uni xona qo'shiluvchilariga ajratadi."},
{h:"Bitta son — bir necha yozuv",sum:"64 = 6 o'nlik 4 birlik = 5 o'nlik 14 birlik = 4 o'nlik 24 birlik. O'nlikni «yechsak», son o'zgarmaydi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Bir o'nlikni «yechib», 10 ta birlikka aylantirsak nima bo'ladi? Son o'zgaradimi?</p>",
 btns:[phaser(P2,'🔓 O‘nlikni yechish')],
 after:"<p>Narsalar soni o'zgarmadi — faqat <b>joylashuvi</b> o'zgardi. 64 ni <b>5 o'nlik 14 birlik</b> deb ham yozish mumkin. Bu «almashtirish» keyinchalik ayirishda juda kerak bo'ladi (64 − 28 da).</p>",
 q:{t:"64 ga qaysi yozuv teng?",opts:["6 o'nlik 14 birlik","4 o'nlik 6 birlik","5 o'nlik 14 birlik","5 o'nlik 4 birlik"],ok:2,why:"5 o'nlik 14 birlik = 50 + 14 = 64.",hint:"Har bir yozuvni hisoblang: o'nliklar · 10 + birliklar.",full:"6 o'nlik 14 birlik = 74. 4 o'nlik 6 birlik = 46. 5 o'nlik 4 birlik = 54. 5 o'nlik 14 birlik = 50 + 14 = 64 ✓."},
 tn:"Singapur darsliklarida bu «renaming» (qayta nomlash) deyiladi. Cho'p bog'lamini yechib ko'rsating — bolalar son o'zgarmaganini o'zi sanaydi."},
{h:"Xona raqami o'zgarsa, son qancha o'zgaradi?",sum:"O'nlar raqami 1 ga ortsa — son 10 ga ortadi; birlar raqami 1 ga ortsa — 1 ga ortadi.",a:"m03",
 start:function(){tu(3,5);S.base=35},fin:function(){tu(5,5);msg('35 → 55: o‘nlar raqami 2 ga ortdi, son <b>20 ga</b> ortdi')},
 html:"<p>Son 35. O'nlar raqamini yoki birlar raqamini oshirib, son <b>qanchaga</b> o'zgarishini kuzating:</p>",
 btns:[["o'nlar +1",function(c,done){if(S.t<9){tu(S.t+1,S.u,{nostrip:1});dif();mvK(done)}}],["birlar +1",function(c,done){if(S.u<9){tu(S.t,S.u+1,{nostrip:1});dif();mvK(done)}},'u']],g2:1,
 after:"<p>O'nlar raqami <b>1 ga</b> ortsa — son <b>10 ga</b> ortadi (bitta tayoqcha = 10). O'nlar raqami 2 ga ortsa — 20 ga. Birlar raqami 1 ga ortsa — atigi 1 ga.</p>",
 q:{t:"Ikki xonali sonning o'nlar xonasidagi raqami 2 ga ortsa, son qanday o'zgaradi?",opts:["2 ga ortadi","12 ga ortadi","20 ga ortadi","22 ga ortadi"],ok:2,why:"Har bir o'nlik — 10 ta: 2 · 10 = 20.",hint:"O'nlar raqami 1 ga ortsa, son nechaga ortadi?",full:"O'nlar xonasidagi 1 — bu 10. Raqam 2 ga ortsa, 2 ta o'nlik qo'shiladi: 20. Masalan, 35 → 55."},
 tn:"Bu — o'rin qiymatining eng chuqur sinovi. Sonlarni kalkulyatorda o'zgartirish o'yini: «faqat o'nlar raqami o'zgarsin»."},
{h:"Tuzoq: ikkala xona birdan o'zgarsa",sum:"O'nlar raqami 3 ga kamaydi (−30), birlar 2 ga ortdi (+2): son 28 ga kamaydi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«O'nlar xonasidagi raqam 3 ga kamaydi, birlar xonasidagi raqam esa 2 ga ortdi. Son qanday o'zgardi?» Ko'p bola «1 ga kamaydi» deydi. Tekshiramiz!</p>",
 btns:[phaser(P4)],
 after:"<p>O'nlar raqami 3 ga kamaydi — bu <b>30</b> ta kamaydi. Birlar 2 ga ortdi — <b>2</b> ta qo'shildi. Jami: −30 + 2 = <b>28 ga kamaydi</b>. Raqamlarni emas, ularning <b>qiymatini</b> hisoblang!</p>",
 q:{t:"O'nlar raqami 2 ga ortdi, birlar raqami 5 ga kamaydi. Son qanday o'zgardi?",opts:["3 ga ortdi","15 ga ortdi","25 ga ortdi","7 ga kamaydi"],ok:1,why:"+20 − 5 = +15.",hint:"O'nlar raqami 2 ga ortsa, son nechaga ortadi? Birlar 5 ga kamaysa-chi?",full:"O'nlar: +2 o'nlik = +20. Birlar: −5. Jami: 20 − 5 = 15 ga ortdi. Masalan: 37 → 52 (52 − 37 = 15). «3 ga ortdi» — raqamlarni ayirib yuborish xatosi."},
 tn:"Avval aniq son bilan tekshirtiring (53 → 25), keyin umumiy qoidaga o'ting."},
{h:"O'nlikkacha nechta yetmaydi?",sum:"47 ning o'nlar raqami oshishi uchun keyingi o'nlikkacha (50) qo'shish kerak: 3.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>«47 sonining o'nlar raqami 1 taga oshishi uchun bu songa eng kamida nechani qo'shish kerak?» 10 ni qo'shsak ham oshadi — lekin <b>eng kamida</b> deyilgan!</p>",
 btns:[phaser(P5)],
 after:"<p>O'nlar raqami o'zgarishi uchun keyingi <b>o'nlikka</b> (50) yetish kifoya: 47 + 3 = 50. Shuning uchun eng kami — <b>3</b>. Bu «10 gacha to'ldirish» usuli, u og'zaki hisobda juda kerak.</p>",
 q:{t:"97 sonida nechta o'nlik bor va 100 bo'lishi uchun yana nechta birlik kerak?",opts:["9 o'nlik, 7 birlik","7 o'nlik, 3 birlik","9 o'nlik, 3 birlik","97 o'nlik, 3 birlik"],ok:2,why:"97 = 9 o'nlik 7 birlik; 97 + 3 = 100.",hint:"97 da o'nliklar xonasida qaysi raqam? 100 gacha nechta qadam?",full:"97 = 9 o'nlik va 7 birlik. 97 dan 100 gacha: 98, 99, 100 — 3 qadam. Javob: 9 o'nlik, 3 birlik."},
 tn:"Yaponiya darsliklarida «10 gacha to'ldirish» (10 no hosū) — asosiy mahorat. Barmoqlar bilan mashq qiling: 7 → 3, 4 → 6."},
{h:"Raqamlar yig'indisi bo'yicha sonlar",sum:"Raqamlari yig'indisi 7 bo'lgan ikki xonali sonlar: 16, 25, 34, 43, 52, 61, 70 — 7 ta. Tartib bilan sanaymiz.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>«Raqamlarining yig'indisi 7 ga teng bo'lgan ikki xonali sonlar nechta?» Tasodifiy topsak, birortasini unutamiz. <b>Tartib bilan</b> sanaymiz.</p>",
 btns:[phaser(P6)],
 after:"<p>Usul: o'nlar raqamini <b>1, 2, 3, …</b> deb oshirib boramiz, birlar raqami o'zi chiqadi (7 − o'nlar). 70 ni unutmang — 0 ham raqam! Jami <b>7 ta</b>.</p>",
 q:{t:"Raqamlarining yig'indisi 5 ga teng ikki xonali sonlar nechta?",opts:["4","5","6","3"],ok:1,why:"14, 23, 32, 41, 50 — 5 ta.",hint:"O'nlar raqamini 1 dan boshlab sinang. 50 ni unutmang.",full:"O'nlar 1 → 14, 2 → 23, 3 → 32, 4 → 41, 5 → 50. Jami 5 ta. «4» — 50 unutilgan."},
 tn:"Tartibli sanash (jadval usuli) — kombinatorikaning boshlanishi. Doskada ikki ustun: «o'nlar | birlar»."},
{h:"Oxiriga 0 yozilsa",sum:"6 ning o'ng tomoniga 0 yozilsa 60 bo'ladi: son 10 marta kattalashadi, 54 ga ortadi.",a:"m07",
 start:function(){zr(false)},fin:function(){zr(true)},
 html:"<p>6 sonining <b>o'ng tomoniga 0</b> raqamini yozib qo'ysak, qanday son chiqadi? Tugmani bosing.</p>",
 btns:[["➕ 0 ni yozish",function(c,done,b){b.disabled=true;zr(true);done()}]],
 after:"<p>6 → <b>60</b>: 6 ta birlik 6 ta <b>o'nlikka</b> aylandi! Son 10 marta kattalashdi. Farqi: 60 − 6 = <b>54</b>.</p>",
 q:{t:"6 sonining o'ng tomoniga 0 yozildi. Hosil bo'lgan son 6 dan qanchaga katta?",opts:["6","54","60","66"],ok:1,why:"60 − 6 = 54.",hint:"Avval yangi sonni toping, keyin farqini hisoblang.",full:"6 ning o'ng tomoniga 0 yozilsa — 60. Qanchaga katta: 60 − 6 = 54. «60» — yangi sonning o'zi, savol farqni so'rayapti."},
 tn:"«Qanchaga katta» va «nechta marta katta» savollarini farqlashni o'rgating: 60 — 6 dan 54 ta ko'p, 10 marta katta."},
{h:"Bilasizmi?",sum:"2000 yil oldin Xitoyda hisob cho'plari bilan sonlar xonalar bo'yicha terilgan, bo'sh joy — nol o'rnida.",a:"m08",
 start:function(){rods8()},fin:function(){rods8()},
 html:"<p>🇨🇳 Bundan 2000 yildan ko'proq oldin Xitoyda sonlar stol ustiga <b>hisob cho'plari</b> bilan terilgan: o'ng ustunda birliklar, chapida o'nliklar, keyin yuzliklar. Xona bo'sh bo'lsa, ustun <b>bo'sh</b> qoldirilgan — bu nolning o'rnini bosgan.</p><p>Bu ham xuddi bizdagi qoida: har bir raqamning qiymati uning <b>turgan joyiga</b> bog'liq.</p>",
 tn:"Bolalar cho'plardan o'z sonlarini «xitoycha» terib ko'rsin: ustunlar daftarda chizilgan bo'lsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){tu(4,7)},fin:function(){tu(4,7)},
 html:"<div class='memo'><ul><li>Son = o'nliklar + birliklar: <b>47 = 40 + 7</b>.</li><li>Bitta son — bir necha yozuv: 64 = 6 o'nlik 4 birlik = <b>5 o'nlik 14 birlik</b>.</li><li>O'nlar raqami 1 ga o'zgarsa — son <b>10 ga</b> o'zgaradi.</li><li>Ikkala xona o'zgarsa — qiymatlarni hisoblang: −30 + 2 = <b>−28</b>.</li><li>O'nlar raqami oshishi uchun — keyingi o'nlikkacha to'ldiring: 47 + <b>3</b> = 50.</li><li>Raqamlar yig'indisi masalasida — <b>tartib bilan</b> sanang, 0 ni unutmang.</li><li>Oxiriga 0 yozilsa — son 10 marta kattalashadi: 6 → 60.</li></ul></div>",
 tn:"Keyingi darsni «5 o'nlik 17 birlik — qaysi son?» (67) savoli bilan boshlang."}
];
function dif(){var n=S.t*10+S.u,d=n-35;msg('35 → <b>'+n+'</b>: son <b>'+d+' ga</b> ortdi'+(S.t>3?' ('+(S.t-3)+' o‘nlik = '+(S.t-3)*10+')':''))}
function nl5(from,to,a,b){clear();var x0=20,x1=340,y=96,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=from;v<=to;v++){E('line',{x1:X(v),y1:y-(v%10?6:11),x2:X(v),y2:y+(v%10?6:11),stroke:'#33475b','stroke-width':v%10?1.3:2.6},S.g);T(S.g,X(v),y+26,String(v),{'font-size':9,'font-weight':v%10?500:800,fill:'#5b6b7b'})}
 E('circle',{cx:X(a),cy:y,r:8,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);T(S.g,X(a),y-16,String(a),{'font-size':14,'font-weight':800,fill:C.blue});
 if(b!=null){for(var s=a;s<b;s++)E('path',{d:'M'+X(s)+' '+(y-8)+' Q'+(X(s)+X(s+1))/2+' '+(y-32)+' '+X(s+1)+' '+(y-8),fill:'none',stroke:C.ok,'stroke-width':2},S.g);E('circle',{cx:X(b),cy:y,r:8,fill:C.ok,stroke:'#fff','stroke-width':2},S.g);T(S.g,X(b),y-36,String(b),{'font-size':15,'font-weight':800,fill:C.ok});T(S.g,(X(a)+X(b))/2,y-50,'+3',{'font-size':14,'font-weight':800,fill:C.ok})}}
function dsum(k){clear();var g=S.g;T(g,90,24,'o‘nlar',{'font-size':12,'font-weight':800,fill:C.t1});T(g,150,24,'birlar',{'font-size':12,'font-weight':800,fill:C.u});T(g,230,24,'son',{'font-size':12,'font-weight':800,fill:C.blue});
 for(var i=1;i<=Math.min(k,7);i++){var y=24+i*19;T(g,90,y,String(i),{'font-size':13,'font-weight':700});T(g,150,y,String(7-i),{'font-size':13,'font-weight':700});T(g,230,y,String(i*10+7-i),{'font-size':14,'font-weight':800,fill:C.ok})}
 if(k>=7)T(g,300,100,'7 ta',{'font-size':22,'font-weight':800,fill:C.blue})}
function zr(on){clear();var g=S.g;T(g,120,95,'6',{'font-size':54,'font-weight':800,fill:'#1d2b3a'});if(on){T(g,152,95,'0',{'font-size':54,'font-weight':800,fill:C.bad});T(g,250,80,'60 − 6 = 54',{'font-size':18,'font-weight':800,fill:C.ok});T(g,250,108,'10 marta katta',{'font-size':13,'font-weight':700,fill:C.blue});msg('6 birlik → <b>6 o‘nlik</b>: 60')}else msg('6 ning o‘ng tomoniga 0 yozamiz')}
function rods8(){clear('#f6ead0');var g=S.g;[['yuzlar',1],['o‘nlar',0],['birlar',5]].forEach(function(c,i){var x=70+i*110;E('rect',{x:x-40,y:30,width:80,height:110,rx:8,fill:'#fff8e8',stroke:'#c9a764'},g);T(g,x,48,c[0],{'font-size':11,fill:'#6b3d12'});for(var k=0;k<c[1];k++)E('rect',{x:x-24+k*12,y:62,width:6,height:56,rx:2,fill:'#6b3d12'},g);if(!c[1])T(g,x,98,'bo‘sh',{'font-size':12,fill:'#9a7a50'})});msg('105: yuzlar — 1 cho‘p, o‘nlar — bo‘sh, birlar — 5 cho‘p')}
var PROBS=[
{t:"5 o'nlik va 17 birlikdan iborat sonni toping.",o:["67","75","57","517"],k:0,s:"50 + 17 = 67."},
{t:"Qaysi yozuv 53 ga teng emas?",o:["4 o'nlik 3 birlik","3 o'nlik 23 birlik","5 o'nlik 3 birlik","4 o'nlik 13 birlik"],k:0,s:"4 o'nlik 3 birlik = 43. Qolganlari 53."},
{t:"Sonda 8 ta birlik bor, o'nliklari birliklaridan 2 ta kam. Bu qaysi son?",o:["68","86","88","610"],k:0,s:"O'nliklar 8 − 2 = 6: 68."},
{t:"47 sonining o'nlar raqami 1 taga oshishi uchun eng kamida nechani qo'shish kerak?",o:["3","1","10","7"],k:0,s:"47 + 3 = 50."},
{t:"Ikki xonali sonning o'nlar raqami 2 ga ortsa, son qanday o'zgaradi?",o:["20 ga ortadi","2 ga ortadi","12 ga ortadi","22 ga ortadi"],k:0,s:"2 o'nlik = 20."},
{t:"O'nlar raqami 3 ga kamaydi, birlar raqami 2 ga ortdi. Son qanday o'zgardi?",o:["28 ga kamaydi","1 ga kamaydi","32 ga kamaydi","5 ga kamaydi"],k:0,s:"−30 + 2 = −28."},
{t:"Raqamlarining yig'indisi 7 ga teng ikki xonali sonlar nechta?",o:["7 ta","5 ta","6 ta","8 ta"],k:0,s:"16, 25, 34, 43, 52, 61, 70."},
{t:"6 sonining o'ng tomoniga 0 yozildi. Hosil bo'lgan son 6 dan qanchaga katta?",o:["54","6","60","66"],k:0,s:"60 − 6 = 54."},
{t:"60 + □ = 6 o'nlik 9 birlik. □ = ?",o:["9","90","69","3"],k:0,s:"69 = 60 + 9."},
{t:"72 = 6 o'nlik va □ birlik. □ = ?",o:["12","2","7","62"],k:0,s:"72 − 60 = 12."},
{t:"80 sonida nechta o'nlik bor?",o:["8","80","0","10"],k:0,s:"80 = 8 o'nlik 0 birlik."},
{t:"35 ni xona qo'shiluvchilariga ajrating.",o:["30 + 5","3 + 5","20 + 15","35 + 0"],k:0,s:"3 o'nlik = 30, 5 birlik = 5. (20 + 15 ham 35 ga teng, lekin u xona qo'shiluvchilari emas.)"},
{t:"Birlar raqami o'nlar raqamidan 3 ta katta, o'nlar raqami 4. Son qaysi?",o:["47","74","43","41"],k:0,s:"O'nlar 4, birlar 4 + 3 = 7: 47."},
{t:"Ikki xonali sonda birlar raqami 1 ga ortdi, o'nlar raqami 1 ga kamaydi. Son qanday o'zgardi?",o:["9 ga kamaydi","o'zgarmadi","11 ga kamaydi","9 ga ortdi"],k:0,s:"−10 + 1 = −9."},
{t:"58 ga eng kamida nechani qo'shsak, o'nlar raqami 1 ga oshadi?",o:["2","10","8","1"],k:0,s:"58 + 2 = 60."},
{t:"Raqamlari yig'indisi 10 ga teng eng kichik ikki xonali son?",o:["19","28","91","55"],k:0,s:"O'nlar eng kichik bo'lsin: 1 → birlar 9: 19."},
{t:"Qaysi son 4 o'nlik 25 birlikka teng?",o:["65","425","45","29"],k:0,s:"40 + 25 = 65."},
{t:"O'nlar va birlar raqamlari bir xil bo'lgan ikki xonali sonlar nechta?",o:["9","10","11","8"],k:0,s:"11, 22, … 99 — 9 ta."},
{t:"Sonning o'nlar raqami 5, birlar raqami esa o'nlar raqamidan 5 ta kam. Son qaysi?",o:["50","55","5","45"],k:0,s:"Birlar 5 − 5 = 0: 50."},
{t:"Ali 2 ta o'nlik va 30 ta birlik oldi. Unda jami nechta?",o:["50","230","32","23"],k:0,s:"20 + 30 = 50."}
];
function PRACT_STAGE(){tu(4,7)}
var PREP_DATA={teach:["Sonning tarkibi: o'nliklar va birliklar, xona qo'shiluvchilari (47 = 40 + 7).","Bitta sonning turli yozuvlari: 64 = 5 o'nlik 14 birlik.","Xona raqami o'zgarganda son qanchaga o'zgaradi.","Raqamlar yig'indisi bo'yicha sonlarni tartib bilan topish; oxiriga 0 yozish."],
 mist:["«O'nlar raqami 2 ga ortsa — son 2 ga ortadi» deydi.","Ikkala xona o'zgarganda raqamlarning o'zini ayiradi (3 − 2 = 1).","«5 o'nlik 17 birlik» ni 517 deb yozadi.","Raqamlar yig'indisi masalasida 70, 50 kabi 0 li sonlarni unutadi."],
 need:["Cho'p bog'lamlari (o'nliklar) va dona cho'plar.","«O'nlar | Birlar» jadvali doskada."],
 board:["<span class='w2'>47 = 4 o'nlik 7 birlik = 40 + 7</span>.","<span class='w2'>64 = 6o 4b = 5o 14b = 4o 24b</span>.","O'nlar +1 → son +10; birlar +1 → son +1.","<span class='w2'>53 → 25: −30 + 2 = −28</span>.","Raqamlar yig'indisi 7: 16, 25, 34, 43, 52, 61, 70."]};
