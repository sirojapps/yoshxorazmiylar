var CODE='2A7',TITLE='2-sinf · Eng katta va eng kichik son, raqamlardan son tuzish';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// kartochkalar va bo'sh kataklar
function deck(digs,slots,fill,o){o=o||{};clear();var g=S.g,n=slots;
 var sx=180-(n*56-6)/2;for(var i=0;i<n;i++){var f=fill&&fill[i]!=null;E('rect',{x:sx+i*56,y:28,width:50,height:58,rx:10,fill:f?'#fff7ea':'#f4f7fa',stroke:f?C.line:'#9aa8b6','stroke-width':2,'stroke-dasharray':f?'':'5 4'},g);
  T(g,sx+i*56+25,104,['yuzlar','o‘nlar','birlar'].slice(3-n)[i],{'font-size':10,fill:'#5b6b7b'});if(f)T(g,sx+i*56+25,70,String(fill[i]),{'font-size':30,'font-weight':800,fill:'#1d2b3a'})}
 var used=o.used||[],cx=180-(digs.length*44-6)/2;digs.forEach(function(d,i){var u=used.indexOf(i)>=0;E('rect',{x:cx+i*44,y:122,width:38,height:42,rx:8,fill:u?'#e9eef3':'#ffe8c7',stroke:u?'#c9d3dd':C.a,'stroke-width':1.5},g);T(g,cx+i*44+19,150,String(d),{'font-size':22,'font-weight':800,fill:u?'#9aa8b6':'#a8601f'})})}
var P2=[function(){deck([5,2,4,7],2,[null,null]);msg('5, 2, 4, 7 raqamlaridan eng katta ikki xonali son (raqamlar takrorlanmasin)')},
 function(){deck([5,2,4,7],2,[7,null],{used:[3]});msg('O‘nlar xonasi eng «qimmat» — unga <b>eng katta</b> raqam: 7')},
 function(){deck([5,2,4,7],2,[7,5],{used:[3,0]});msg('Birlarga qolganlarning eng kattasi: 5. Eng katta son — <b>75</b>')},
 function(){deck([5,2,4,7],2,[2,4],{used:[1,2]});msg('Eng kichik: o‘nlarga eng kichik raqam (2), birlarga keyingisi (4) — <b>24</b>')}];
var P3=[function(){deck([7,0,4],2,[null,null]);msg('7, 0, 4 dan eng katta va eng kichik ikki xonali son')},
 function(){deck([7,0,4],2,[7,4],{used:[0,2]});msg('Eng katta: <b>74</b>')},
 function(){deck([7,0,4],2,[0,4],{used:[1,2]});E('line',{x1:122,y1:24,x2:178,y2:92,stroke:C.bad,'stroke-width':4},S.g);msg('Eng kichik — «04»? <b style="color:#d94b4b">Yo‘q!</b> 04 — bu ikki xonali son emas, shunchaki 4')},
 function(){deck([7,0,4],2,[4,0],{used:[1,2]});msg('0 boshda tura olmaydi. Eng kichik: <b>40</b>. Ayirma: 74 − 40 = <b>34</b>')}];
var P4=[function(){tree(0);msg('3, 0, 6 dan nechta har xil ikki xonali son tuzish mumkin? Tartib bilan sanaymiz')},function(){tree(1);msg('O‘nlar xonasiga 0 qo‘yib bo‘lmaydi — faqat 3 yoki 6')},function(){tree(2);msg('3 bilan: 30, 36. 6 bilan: 60, 63. Jami <b>4 ta</b>')}];
var P5=[function(){cands([],'5, 8, 0, 3 dan eng katta <b>juft</b> ikki xonali son (takrorlanmasin)')},
 function(){cands([85,83,80],'O‘nlarga eng katta raqam — 8. Birlarga: 5, 3 yoki 0')},
 function(){cands([85,83,80],'85 — toq ✗, 83 — toq ✗, <b>80</b> — juft ✓. Javob: <b>80</b>',[0,0,1])}];
var P7=[function(){d12(0);msg('Raqamlari yig‘indisi 12 ga teng <b>eng kichik</b> ikki xonali son')},
 function(){d12(1);msg('Son kichik bo‘lishi uchun o‘nlar raqami iloji boricha kichik bo‘lsin. Birlar esa ko‘pi bilan 9')},
 function(){d12(2);msg('O‘nlar 12 − 9 = 3: <b>39</b>. Tekshiramiz: 3 + 9 = 12 ✓')}];
var P8=[function(){deck([4,0,7],3,[null,null,null]);msg('4, 0, 7 dan uch xonali sonlar. Eng katta va eng kichik orasidagi farq?')},
 function(){deck([4,0,7],3,[7,4,0],{used:[0,1,2]});msg('Eng katta: <b>740</b>')},
 function(){deck([4,0,7],3,[4,0,7],{used:[0,1,2]});msg('Eng kichik: yuzlarga eng kichik <b>noldan farqli</b> raqam (4), keyin 0, keyin 7: <b>407</b>. Farq: 740 − 407 = <b>333</b>')}];
var STEPS=[
{h:"Kartochkalardan son tuzamiz",sum:"Ikkita raqamdan ikki xil son: 52 va 25. Katta raqam o'nliklarda tursa, son katta.",a:"m01",
 start:function(){S.f=[null,null];S.u=[];deck([5,2],2,S.f);msg('Kartochkani bosing — u bo‘sh katakka tushadi')},fin:function(){deck([5,2],2,[5,2],{used:[0,1]});msg('52 > 25')},
 html:"<p>Sizda <b>5</b> va <b>2</b> raqamli kartochkalar bor. Ularni kataklarga qo'yib son tuzing. Keyin teskarisini sinab ko'ring.</p>",
 btns:[["5",function(c,done){put(0,5,done)}],["2",function(c,done){put(1,2,done)}],["↺ Qaytadan",function(){S.f=[null,null];S.u=[];deck([5,2],2,S.f);msg('Kartochkani bosing')},'u']],g3:1,
 after:"<p>5 va 2 dan ikkita son chiqadi: <b>52</b> va <b>25</b>. 52 katta — chunki unda 5 ta o'nlik bor. Katta raqam <b>o'nliklar</b> xonasida tursa, son katta bo'ladi.</p>",
 q:{t:"3 va 8 raqamlaridan tuzilgan ikki xonali sonlarning kattasi qaysi?",opts:["38","83","11","88"],ok:1,why:"8 o'nliklarda: 83.",hint:"Qaysi raqamni o'nliklarga qo'ysak, son katta bo'ladi?",full:"3 va 8 dan: 38 va 83. 83 da 8 ta o'nlik — katta. 88 — raqam takrorlangan, 11 — yig'indi."},
 tn:"Raqam kartochkalari (0–9) — Yaponiya va Singapur darslarining asosiy vositasi. Har bir bolaga to'plam bering."},
{h:"Eng katta va eng kichik son",sum:"Eng katta son: raqamlar kamayish tartibida (75). Eng kichik: o'sish tartibida (24).",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Ali doskaga <b>5, 2, 4, 7</b> raqamlarini yozdi. Ulardan (takrorlanmasdan) eng katta va eng kichik ikki xonali sonni tuzamiz.</p>",
 btns:[phaser(P2)],
 after:"<p><b>Eng katta</b> son uchun: eng «qimmat» xonaga (o'nliklarga) — eng katta raqam, keyin keyingisi: <b>75</b>. <b>Eng kichik</b> uchun — teskarisi: <b>24</b>. Ularning yig'indisi: 75 + 24 = 99.</p>",
 q:{t:"6, 1, 9, 3 raqamlaridan (takrorlanmasin) tuzilgan eng kichik ikki xonali son qaysi?",opts:["19","13","31","36"],ok:1,why:"O'nlarga eng kichik raqam 1, birlarga keyingisi 3.",hint:"Eng kichik raqamni qayerga qo'yish kerak? Keyin qaysi raqam?",full:"Eng kichik raqam — 1 (o'nliklarga). Birlarga qolganlarning eng kichigi — 3. Son: 13. «19» — birlarga eng kattasini qo'yish xatosi."},
 tn:"Bolalar raqamlarni avval tartiblasin (kamayish yoki o'sish), keyin son tuzsin — bu usul har qanday masalada ishlaydi."},
{h:"Tuzoq: 0 boshda tura olmaydi",sum:"7, 0, 4: eng katta 74, eng kichik 40 (04 — ikki xonali emas). Ayirma 34.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Raqamlar orasida <b>0</b> bo'lsa, ehtiyot bo'ling! 7, 0, 4 dan eng katta va eng kichik ikki xonali son qaysi?</p>",
 btns:[phaser(P3)],
 after:"<p>Ikki xonali son <b>0 bilan boshlanmaydi</b>: «04» — bu 4, bir xonali. Shuning uchun eng kichik sonda 0 <b>ikkinchi</b> o'ringa o'tadi: <b>40</b>. Eng katta — 74. Farqi: <b>34</b>.</p>",
 q:{t:"5, 0, 9 raqamlaridan (takrorlanmasin) tuzilgan eng kichik ikki xonali son qaysi?",opts:["05","50","59","90"],ok:1,why:"0 boshda bo'lmaydi: o'nlarga 5, birlarga 0.",hint:"Eng kichik raqam 0 — lekin u o'nlar xonasida tura oladimi?",full:"0 o'nlar xonasida tura olmaydi («05» = 5). Shuning uchun o'nlarga noldan keyingi eng kichik raqam — 5, birlarga 0: 50."},
 tn:"Bu tuzoq olimpiada va saralash testlarida juda ko'p. Doskada «04» ni ustidan chizib, «bu 4» deb yozib qo'ying."},
{h:"Nechta son tuzish mumkin?",sum:"3, 0, 6 dan ikki xonali sonlar: 30, 36, 60, 63 — 4 ta. O'nlar raqamidan boshlab tartib bilan sanaymiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«Kartochkalarda 3, 0 va 6 yozilgan. Ikkitasini yonma-yon qo'yib, nechta har xil ikki xonali son hosil qilish mumkin?» Tasodifiy tersak, birortasini unutamiz — <b>daraxt</b> chizib sanaymiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Daraxt usuli: avval <b>o'nlar</b> raqamini tanlaymiz (0 mumkin emas — 3 yoki 6), har biridan <b>birlar</b> uchun qolgan ikkita raqam. Jami <b>4 ta</b>: 30, 36, 60, 63.</p>",
 q:{t:"1, 2, 3 raqamlaridan (takrorlanmasin) nechta ikki xonali son tuzish mumkin?",opts:["3","6","9","4"],ok:1,why:"12, 13, 21, 23, 31, 32 — 6 ta.",hint:"O'nlar raqamini 3 xil tanlash mumkin. Har biri uchun birlarga nechta raqam qoladi?",full:"O'nlar 1: 12, 13. O'nlar 2: 21, 23. O'nlar 3: 31, 32. Jami 3 · 2 = 6 ta. «9» — takrorlanishga ruxsat berilgandagi javob (11, 22, 33 ham)."},
 tn:"«Daraxt» (variantlar daraxti) — kombinatorikaning birinchi vositasi. Doskada shoxlab chizing."},
{h:"Shart bilan: eng katta juft son",sum:"5, 8, 0, 3 dan eng katta juft: o'nlarga 8, birlarga juft raqam — 80.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Endi shart qo'shamiz: 5, 8, 0, 3 raqamlaridan (takrorlanmasin) eng katta <b>juft</b> ikki xonali son. «85» deb shoshilmang!</p>",
 btns:[phaser(P5)],
 after:"<p>Usul: avval odatdagidek eng katta sonni tuzamiz, keyin shartni tekshiramiz. Juft bo'lishi uchun <b>birlar</b> raqami juft bo'lishi kerak: 0 yoki 8. 8 o'nliklarda band — demak birlarga 0: <b>80</b>.</p>",
 q:{t:"Raqamlari har xil bo'lgan eng katta ikki xonali toq son qaysi?",opts:["99","98","97","89"],ok:2,why:"99 — raqamlar bir xil, 98 — juft; 97 — toq va raqamlari har xil.",hint:"Eng katta sondan boshlab pastga tekshiring: raqamlari har xilmi? Toqmi?",full:"99 — raqamlari bir xil ✗. 98 — juft ✗. 97 — toq, raqamlari har xil ✓. 89 ham mos, lekin 97 dan kichik."},
 tn:"Shartli masalalarda «avval eng yaxshisi, keyin tekshir» strategiyasi samarali. Bolalar nomzodlarni yozib, birma-bir o'chirsin."},
{h:"Raqamlar yig'indisi bilan: eng kichik son",sum:"Raqamlari yig'indisi 12, eng kichik: birlarga 9 (eng ko'pi), o'nlarga 3 — 39.",a:"m06",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>«Raqamlarining yig'indisi 12 ga teng bo'lgan <b>eng kichik</b> ikki xonali sonni toping.» 12 ni ikki raqamga bo'lish kerak.</p>",
 btns:[phaser(P7)],
 after:"<p>Son kichik bo'lishi uchun <b>o'nlar</b> raqami kichik bo'lsin. Lekin birlar raqami <b>9 dan oshmaydi</b>. Shuning uchun birlarga 9, o'nlarga 12 − 9 = 3: <b>39</b>.</p>",
 q:{t:"Raqamlarining ko'paytmasi 12 ga teng bo'lgan eng kichik ikki xonali son qaysi?",opts:["34","26","43","62"],ok:1,why:"12 = 2 · 6 = 3 · 4. Eng kichik o'nlar raqami — 2: 26.",hint:"12 ni qaysi ikki raqamning ko'paytmasi qilib yozish mumkin? O'nlar raqami eng kichigi qaysi?",full:"12 = 2 · 6 = 3 · 4 (1 · 12 — 12 raqam emas). Sonlar: 26, 62, 34, 43. Eng kichigi — 26."},
 tn:"«Eng kichik» uchun o'nliklarni kichik, «eng katta» uchun katta qilish — umumiy qoida. Teskari savolni ham bering: eng kattasi (93)."},
{h:"Uch xonali sonlar ham xuddi shunday",sum:"4, 0, 7: eng katta 740, eng kichik 407 (0 boshda emas). Farq: 333.",a:"m07",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Yangi darslikda 2-sinfda uch xonali sonlar ham o'tiladi. Qoida o'zgarmaydi! 4, 0, 7 raqamlaridan (har biri bir marta) eng katta va eng kichik uch xonali son:</p>",
 btns:[phaser(P8)],
 after:"<p>Eng katta: raqamlar kamayish tartibida — <b>740</b>. Eng kichik: yuzlarga <b>noldan farqli</b> eng kichik raqam (4), keyin 0, keyin 7 — <b>407</b>. Farq: 740 − 407 = <b>333</b>.</p>",
 q:{t:"2, 9, 0 raqamlaridan (har biri bir marta) tuzilgan eng kichik uch xonali son qaysi?",opts:["029","209","290","902"],ok:1,why:"Yuzlarga 2 (0 mumkin emas), keyin 0, keyin 9.",hint:"Yuzlar xonasiga 0 qo'yish mumkinmi? Unda qaysi raqam?",full:"«029» — bu 29, ikki xonali. Yuzlarga noldan farqli eng kichik raqam — 2. Keyin qolganlarning eng kichigi — 0, keyin 9: 209."},
 tn:"Ikki xonali va uch xonali misollarni yonma-yon bering — bolalar qoida umumiy ekanini ko'rsin."},
{h:"Bilasizmi?",sum:"4 raqamli PIN-kodda 10 000 xil variant bor (0000 dan 9999 gacha) — shuning uchun uni topish qiyin.",a:"m08",
 start:function(){pin()},fin:function(){pin()},
 html:"<p>🔒 Telefon yoki karta PIN-kodi 4 ta raqamdan iborat. Unda raqamlar takrorlanishi va 0 boshda turishi mumkin: 0000, 0001, … 9999. Jami <b>10 000</b> xil kod! Shuning uchun begona odam uni tasodifan topa olmaydi.</p><p>💡 Siz bugun o'rgangan «nechta son tuzish mumkin?» savoli — kodlar va parollar xavfsizligining asosi.</p>",
 tn:"Bolalar bilan 2 raqamli «qulf» o'yini: raqamlar 1, 2, 3 bo'lsa, nechta kod bor? (takrorlanish bilan 9, takrorsiz 6)."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){deck([5,2,4,7],2,[7,5],{used:[3,0]})},fin:function(){deck([5,2,4,7],2,[7,5],{used:[3,0]})},
 html:"<div class='memo'><ul><li><b>Eng katta</b> son: raqamlar kamayish tartibida (5, 2, 4, 7 → <b>75</b>).</li><li><b>Eng kichik</b> son: o'sish tartibida (→ <b>24</b>).</li><li><b>0 boshda turmaydi</b>: 7, 0, 4 → eng kichik <b>40</b>; 4, 0, 7 → <b>407</b>.</li><li>Nechta son? — <b>daraxt</b> bilan tartib bilan sanang (3, 0, 6 → 4 ta).</li><li>Shart bo'lsa (juft, toq): avval eng yaxshisini tuzing, keyin tekshiring.</li><li>Raqamlar yig'indisi berilsa, eng kichik son uchun birlarga <b>9</b> qo'ying (12 → 39).</li></ul></div>",
 tn:"Keyingi darsni «Eng katta ikki xonali son bilan eng kichik ikki xonali sonning ayirmasi?» (89) savoli bilan boshlang."}
];
function put(i,d,done){if(S.u.indexOf(i)>=0)return;var k=S.f.indexOf(null);if(k<0)return;S.f[k]=d;S.u.push(i);deck([5,2],2,S.f,{used:S.u});
 if(S.f.indexOf(null)<0){var n=S.f[0]*10+S.f[1];S.made=S.made||{};S.made[n]=1;msg('Siz <b>'+n+'</b> sonini tuzdingiz'+(Object.keys(S.made).length<2?'. Endi «Qaytadan» bosib, teskarisini tuzing':'. Ikkala son: 52 va 25 — 52 katta!'));if(Object.keys(S.made).length>=2)done()}}
function tree(k){clear();var g=S.g;T(g,40,90,'o‘nlar',{'font-size':11,fill:'#5b6b7b'});T(g,320,22,'birlar',{'font-size':11,fill:'#5b6b7b'});
 var heads=[[3,50],[0,90],[6,130]];heads.forEach(function(h){var bad=h[0]===0,x=110;E('circle',{cx:x,cy:h[1],r:15,fill:bad&&k>=1?'#fdeaea':'#fff7ea',stroke:bad&&k>=1?C.bad:C.line,'stroke-width':2},g);T(g,x,h[1]+6,String(h[0]),{'font-size':16,'font-weight':800,fill:bad&&k>=1?C.bad:'#1d2b3a'});if(bad&&k>=1)T(g,x+40,h[1]+5,'✗ boshda bo‘lmaydi',{'font-size':11,fill:C.bad,'text-anchor':'start'});
  if(!bad&&k>=2){[3,0,6].filter(function(d){return d!==h[0]}).forEach(function(d,j){var y=h[1]-12+j*24;E('line',{x1:x+15,y1:h[1],x2:220,y2:y,stroke:'#9aa8b6','stroke-width':1.5},g);T(g,232,y+5,String(d),{'font-size':14,'font-weight':800});T(g,290,y+5,String(h[0]*10+d),{'font-size':16,'font-weight':800,fill:C.ok})})}})}
function cands(list,txt,ok){clear();var g=S.g;T(g,180,30,'5, 8, 0, 3',{'font-size':18,'font-weight':800,fill:'#a8601f'});list.forEach(function(n,i){var x=90+i*90,good=ok&&ok[i];E('rect',{x:x-32,y:60,width:64,height:48,rx:10,fill:ok?(good?'#e6f6ee':'#fdeaea'):'#fff',stroke:ok?(good?C.ok:C.bad):'#c9d3dd','stroke-width':2},g);T(g,x,92,String(n),{'font-size':24,'font-weight':800,fill:ok?(good?C.ok:C.bad):'#1d2b3a'});if(ok)T(g,x,130,good?'juft ✓':'toq ✗',{'font-size':12,'font-weight':800,fill:good?C.ok:C.bad})});msg(txt)}
function d12(k){clear();var g=S.g;T(g,180,34,'□ + □ = 12',{'font-size':24,'font-weight':800,fill:'#1d2b3a'});if(k>=1){T(g,110,80,'o‘nlar: kichik',{'font-size':13,fill:C.blue,'font-weight':700});T(g,250,80,'birlar: ≤ 9',{'font-size':13,fill:C.blue,'font-weight':700})}
 if(k>=2){T(g,110,128,'3',{'font-size':40,'font-weight':800,fill:C.ok});T(g,250,128,'9',{'font-size':40,'font-weight':800,fill:C.ok});T(g,180,160,'39',{'font-size':18,'font-weight':800,fill:C.ok})}}
function pin(){clear();var g=S.g;for(var i=0;i<4;i++){E('rect',{x:84+i*50,y:40,width:42,height:52,rx:10,fill:'#fff',stroke:C.blue,'stroke-width':2},g);T(g,105+i*50,76,'*',{'font-size':28,'font-weight':800,fill:C.blue})}T(g,180,130,'10 · 10 · 10 · 10 = 10 000 variant',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});msg('Har bir katakka 10 xil raqam')}
var PROBS=[
{t:"5, 2, 4, 7 raqamlaridan (takrorlanmasin) eng katta va eng kichik ikki xonali sonlarning yig'indisi?",o:["99","72","117","81"],k:0,s:"Eng katta 75, eng kichik 24: 75 + 24 = 99."},
{t:"Eng katta ikki xonali son bilan eng kichik ikki xonali sonning ayirmasi?",o:["89","99","90","88"],k:0,s:"99 − 10 = 89."},
{t:"7, 0, 4 raqamlaridan (takrorlanmasin) eng katta va eng kichik ikki xonali sonlar ayirmasi?",o:["34","30","47","70"],k:0,s:"74 − 40 = 34."},
{t:"5, 8, 0, 3 raqamlaridan (takrorlanmasin) eng katta juft ikki xonali son?",o:["80","38","85","58"],k:0,s:"O'nlarga 8, birlarga juft raqam 0: 80."},
{t:"Raqamlari har xil bo'lgan eng katta ikki xonali toq son?",o:["97","99","98","89"],k:0,s:"99 — raqamlar bir xil, 98 — juft. 97."},
{t:"Raqamlarining yig'indisi 12 ga teng eng kichik ikki xonali son?",o:["39","48","57","93"],k:0,s:"Birlarga 9, o'nlarga 3: 39."},
{t:"3, 0, 6 kartochkalaridan ikkitasini qo'yib nechta har xil ikki xonali son hosil qilish mumkin?",o:["4","6","3","9"],k:0,s:"30, 36, 60, 63."},
{t:"Raqamlari bir xil bo'lgan eng katta ikki xonali son bilan eng kichigining ayirmasi?",o:["88","89","90","98"],k:0,s:"99 − 11 = 88."},
{t:"Birlar raqami 0 bo'lgan nechta ikki xonali son bor?",o:["9","8","10","90"],k:0,s:"10, 20, … 90 — 9 ta."},
{t:"Faqat 4 va 9 raqamlaridan (takrorlanishi mumkin) eng katta va eng kichik ikki xonali sonlar tuzildi. Ularning ayirmasi?",o:["55","54","45","50"],k:0,s:"99 − 44 = 55."},
{t:"Raqamlarining ko'paytmasi 12 ga teng eng kichik ikki xonali son?",o:["26","34","43","62"],k:0,s:"12 = 2 · 6 = 3 · 4: 26, 34, 43, 62. Eng kichigi 26."},
{t:"4, 0, 7 raqamlarining har birini bir martadan ishlatib uch xonali sonlar tuzildi. Eng katta son eng kichik sondan qanchaga katta?",o:["333","293","363","703"],k:0,s:"740 − 407 = 333."},
{t:"Raqamlarining yig'indisi 5 ga teng nechta ikki xonali son bor?",o:["5","4","6","3"],k:0,s:"14, 23, 32, 41, 50."},
{t:"1, 2, 3 raqamlaridan (takrorlanmasin) nechta ikki xonali son tuzish mumkin?",o:["6","3","9","4"],k:0,s:"12, 13, 21, 23, 31, 32."},
{t:"Raqamlari har xil bo'lgan eng kichik ikki xonali son?",o:["10","11","12","01"],k:0,s:"10: raqamlari 1 va 0 — har xil."},
{t:"6, 1, 9, 3 raqamlaridan (takrorlanmasin) eng kichik ikki xonali son?",o:["13","19","31","16"],k:0,s:"O'nlarga 1, birlarga 3."},
{t:"Raqamlari har xil bo'lgan eng katta uch xonali son?",o:["987","999","998","978"],k:0,s:"Kamayish tartibida: 9, 8, 7."},
{t:"2, 9, 0 raqamlaridan (har biri bir marta) eng kichik uch xonali son?",o:["209","029","290","902"],k:0,s:"Yuzlarga 2, keyin 0, keyin 9."},
{t:"Raqamlarining yig'indisi 15 ga teng eng katta ikki xonali son?",o:["96","69","87","78"],k:0,s:"O'nlarga eng katta raqam 9, birlarga 15 − 9 = 6: 96."},
{t:"5 va 0 raqamlaridan (takrorlanishi mumkin) nechta ikki xonali son tuzish mumkin?",o:["2","4","3","1"],k:0,s:"50 va 55 (00 va 05 — ikki xonali emas)."}
];
function PRACT_STAGE(){deck([5,2,4,7],2,[7,5],{used:[3,0]});msg('Eng katta — kamayish, eng kichik — o‘sish tartibida; 0 boshda emas')}
var PREP_DATA={teach:["Raqam kartochkalaridan son tuzish; raqam o'rni sonni o'zgartiradi.","Eng katta (kamayish tartibi) va eng kichik (o'sish tartibi) son.","0 boshda turmaydi; nechta son tuzish mumkin (daraxt).","Shartli masalalar: juft/toq, raqamlar yig'indisi; uch xonali sonlar."],
 mist:["Eng kichik songa 0 ni boshga qo'yadi (04, 029).","Nechta son tuzishda birortasini unutadi yoki 0 li sonlarni sanaydi.","Shartni (juft) tekshirmay, eng katta sonni yozadi (85).","Raqamlar yig'indisi masalasida birlarga 9 qo'yishni o'ylamaydi."],
 need:["0–9 raqam kartochkalari (har bolaga).","Doskada «o'nlar | birlar» kataklari."],
 board:["5, 2 → 52 va 25.","5, 2, 4, 7 → eng katta <span class='w2'>75</span>, eng kichik <span class='w2'>24</span>.","7, 0, 4 → <span class='w2'>74</span> va <span class='w2'>40</span> (04 ✗).","Daraxt: 3 → 30, 36; 6 → 60, 63.","Yig'indi 12, eng kichik: <span class='w2'>39</span>."]};
