// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F3',TITLE='4-sinf · Maxrajlari bir xil kasrlarni qo‘shish va ayirish';
function f3pieC(cx,cy,r,cols){var g=E('g',{},S.g),n=cols.length,d=2*Math.PI/n,a=-Math.PI/2;cols.forEach(function(cl,i){f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,cl||C.off)});return g}
function f3cols(n,a,b){var r=[];for(var i=0;i<n;i++)r.push(i<a?C.a:(i<a+b?C.b:null));return r}
var F3P1=[function(){clear();f3pieC(90,88,62,f3cols(8,3,0));f4t(90,166,'Ali: 3/8',13,C.a2);f4t(270,60,'3/8 + 2/8 = ?',18);f4c(['Pitsa 8 ta teng bo‘lak. Ali 3 tasini yedi'])},
 function(){clear();f3pieC(90,88,62,f3cols(8,3,2));f4t(90,166,'Ali 3/8 + Vali 2/8',12,'#33475b');f4t(270,60,'3/8 + 2/8 = ?',18);f4c(['Vali yana 2 ta bo‘lak yedi. Bo‘laklar <b>bir xil</b> — sakkizdan bir'])},
 function(){clear();f3pieC(90,88,62,f3cols(8,3,2));f4t(90,166,'5 ta bo‘lak — 5/8',13,C.ok);f4t(270,60,'3/8 + 2/8 = 5/8',18,C.ok);f4t(270,110,'3 + 2 = 5 bo‘lak',13,'#5b6b7b');f4t(270,134,'bo‘lak nomi: sakkizdan',12,'#5b6b7b');f4c(['3 ta + 2 ta = <b>5 ta</b> sakkizdan bir: <b>5/8</b>','Maxraj — bo‘lakning «nomi», u o‘zgarmaydi'])}];
function f3wrong(){clear();f3pieC(70,70,48,f3cols(8,3,0));f4t(70,136,'3/8',14,C.a2);f4t(140,74,'+',22);f3pieC(210,70,48,f3cols(8,0,2));f4t(210,136,'2/8',14,C.blue);f4t(290,74,'= ?',20);f4msg('Javob qaysi? Pitsa 16 bo‘lakka bo‘lindimi?')}
var F3P4=[function(){clear();f4bar(30,60,300,40,7,7,C.b);f4t(180,40,'1 butun = 7/7',14,C.blue);f4c(['1 dan 3/7 ni ayirish kerak. 1 ni kasr ko‘rinishida yozamiz'])},
 function(){clear();var B=f4bar(30,60,300,40,7,7,C.b);for(var i=4;i<7;i++){B.cells[i].setAttribute('fill','#ffd0d0');var x=30+i*300/7;E('line',{x1:x+6,y1:66,x2:x+300/7-6,y2:94,stroke:C.bad,'stroke-width':3},S.g)}f4t(180,40,'7/7 − 3/7',14,C.blue);f4c(['3 ta bo‘lakni olib tashlaymiz'])},
 function(){clear();var B=f4bar(30,60,300,40,7,4,C.b);f4t(180,40,'7/7 − 3/7 = 4/7',16,C.ok);f4Br(30,30+300*4/7,104,'4/7 qoldi',false,C.ok);f4c(['1 − 3/7 = 7/7 − 3/7 = <b>4/7</b>','Xato: 1 − 3/7 = 2/7 (1 ni «1/7» deb olish)'])}];
function f3nl(st){clear();var X=f4line(110,0,1,6,40,280,function(q,big){return big?String(q/6):(q+'/6')});var ball=st>=2?5:(st>=1?2:0);
 if(st>=1)f4arc(X(0),X(2/6),110,30,'+2/6',C.a2);if(st>=2)f4arc(X(2/6),X(5/6),110,46,'+3/6',C.blue);E('circle',{cx:X(ball/6),cy:92,r:8,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);
 f4t(180,22,st>=2?'2/6 + 3/6 = 5/6':'2/6 + 3/6 = ?',15,st>=2?C.ok:'#1d2b3a')}
var F3P5=[function(){f3nl(0);f4c(['Son o‘qida 0 dan 1 gacha — 6 ta teng qadam (har biri 1/6)'])},function(){f3nl(1);f4c(['Avval 2 qadam: 2/6'])},function(){f3nl(2);f4c(['Yana 3 qadam: 2/6 + 3/6 = <b>5/6</b>','Qo‘shish — o‘ngga, ayirish — chapga sakrash'])}];
function f3three(st){clear();var cols=[],i;for(i=0;i<10;i++)cols.push(null);var a=2,b=5,c=4;
 if(st>=1)for(i=0;i<a;i++)cols[i]=C.a;if(st>=2)for(i=a;i<a+b;i++)cols[i]=C.b;if(st>=3){for(i=a+b-c;i<a+b;i++)cols[i]='#ffd0d0'}
 f4barC(20,60,320,40,cols);if(st>=3)for(i=a+b-c;i<a+b;i++){var x=20+i*32;E('line',{x1:x+5,y1:66,x2:x+27,y2:94,stroke:C.bad,'stroke-width':3},S.g)}
 f4t(180,36,'2/10 + 5/10 − 4/10',16);if(st>=3)f4t(180,136,'= 3/10',18,C.ok)}
var F3P6=[function(){f3three(0);f4c(['Uch kasr. Chapdan o‘ngga tartib bilan bajaramiz'])},function(){f3three(1);f4c(['2/10 — 2 ta bo‘lak'])},function(){f3three(2);f4c(['+ 5/10: 2 + 5 = 7 ta bo‘lak — 7/10'])},function(){f3three(3);f4c(['− 4/10: 7 − 4 = 3 → <b>3/10</b>','Faqat suratlar bilan amal bajariladi: 2 + 5 − 4 = 3'])}];
function f3road(st){clear();var cols=[],i;for(i=0;i<9;i++)cols.push(i<2?C.a:(i<6&&st>=1?C.b:null));var lab=['','','','','','','','',''];
 f4barC(20,64,320,38,cols);f4Br(20,20+320*2/9,60,'1-kun 2/9',true,C.a2);if(st>=1)f4Br(20+320*2/9,20+320*6/9,60,'2-kun 4/9',true,C.blue);
 if(st>=2)f4Br(20+320*6/9,340,106,'qoldi 3/9',false,C.ok);f4t(180,150,st>=2?'9/9 − 2/9 − 4/9 = 3/9':'Butun yo‘l = 9/9',14,st>=2?C.ok:'#33475b')}
var F3P8=[function(){f3road(0);f4c(['Butun yo‘l — 9/9. 1-kuni 2/9 qismi o‘tildi'])},function(){f3road(1);f4c(['2-kuni 4/9 qismi. Ikki kunda: 2/9 + 4/9 = 6/9'])},function(){f3road(2);f4c(['Qoldi: 9/9 − 6/9 = <b>3/9</b>'])}];
function PRACT_STAGE(){clear();f3pieC(90,88,62,f3cols(8,3,2));f4t(260,70,'3/8 + 2/8 = 5/8',16,C.ok);f4t(260,110,'1 − 3/7 = 4/7',16,C.blue);f4c(['Suratlarni qo‘shamiz (ayiramiz), maxraj o‘zgarmaydi'])}
var STEPS=[
{h:"Bir xil bo'laklarni qo'shamiz",sum:"3/8 + 2/8 = 5/8: sakkizdan bir bo'laklar soni qo'shiladi, bo'lak nomi (maxraj) o'zgarmaydi.",a:"m01",
 start:function(){startPh(F3P1)},fin:function(){S.ph=2;F3P1[2]()},
 html:"<p>Pitsa 8 ta teng bo'lakka bo'lingan. Ali 3/8 qismini, Vali 2/8 qismini yedi. Birgalikda qancha yeyishdi? Bosing:</p>",btns:[phaser(F3P1)],
 after:"<p>Maxraj 8 — bu bo'lakning <b>nomi</b>: «sakkizdan bir». 3 ta olma + 2 ta olma = 5 ta olma bo'lgani kabi, <b>3 ta sakkizdan bir + 2 ta sakkizdan bir = 5 ta sakkizdan bir</b>.</p><p><b>Qoida:</b> maxrajlari bir xil kasrlarni qo'shishda <b>suratlar qo'shiladi</b>, maxraj <b>o'sha-o'sha</b> qoladi.</p>",
 q:{t:"2/7 + 4/7 = ?",opts:["6/14","6/7","8/7","2/7"],ok:1,why:"2 + 4 = 6 ta yettidan bir: 6/7.",hint:"Bo'lak nomi (maxraj) o'zgaradimi? Faqat nechta bo'lak bo'lganini sanang.",full:"Suratlar: 2 + 4 = 6, maxraj 7 qoladi — 6/7. «6/14» — maxrajlarni ham qo'shish: bunda bo'laklar kichrayib qoladi, bu noto'g'ri. «8/7» — surat va maxrajni aralashtirish."},
 tn:"Ingliz va yapon darsliklari maxrajni «bo'lak nomi» (unit) deb o'rgatadi: «3 ta sakkizdan bir + 2 ta sakkizdan bir». Shu tilda gapirtirsangiz, maxrajni qo'shish xatosi kamayadi."},
{h:"Tuzoq: maxrajlarni ham qo'shish",sum:"3/8 + 2/8 ≠ 5/16! Pitsa 16 bo'lakka bo'linmagan — bo'laklar o'sha sakkizdan bir.",a:"m02",
 start:function(){f3wrong()},fin:function(){clear();f3pieC(90,80,58,f3cols(8,3,2));f4t(90,156,'5/8',16,C.ok);f4t(260,80,'5/16 bo‘lsa —',12,C.bad);f4t(260,104,'yarimdan ham kam!',12,C.bad);f4msg('3/8 + 2/8 = <b>5/8</b>')},
 html:"<p>Ko'p bolalar shunday yozadi: <b>3/8 + 2/8 = 5/16</b>. To'g'ri javobni tanlang:</p>",
 btns:f4pick(1,[["5/16","Pitsa 16 bo'lakka bo'linmadi! 5/16 — yarimdan ham kam, lekin ular yarimdan ko'p yedi (5 ta bo'lak 8 tadan)."],["5/8","To'g'ri! Bo'laklar o'sha — sakkizdan bir, faqat soni 5 ta bo'ldi."],["6/8","Sanab ko'ring: 3 ta + 2 ta = nechta bo'lak?"]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Tekshirish usuli: 3/8 — deyarli yarim, 2/8 — chorak. Yig'indi yarimdan <b>ko'p</b> bo'lishi kerak. 5/16 esa yarimdan <b>kam</b> — demak xato. Har doim javobni mantiq bilan tekshiring!</p>",
 q:{t:"Ali shokoladning 2/9 qismini, Vali 5/9 qismini yedi. Ikkalasi birgalikda qancha yedi?",opts:["7/18","7/9","10/9","3/9"],ok:1,why:"2 + 5 = 7 ta to'qqizdan bir.",hint:"Shokolad 18 ta bo'lakka bo'lindimi? Bo'lak nomi qanday?",full:"Shokolad 9 ta bo'lak, ular 2 + 5 = 7 ta bo'lak yedi: 7/9. «7/18» — maxrajlarni qo'shish xatosi, «3/9» — ayirish, «10/9» — ko'paytirish (2 · 5)."},
 tn:"Bu xato butun dunyoda eng ko'p uchraydi. «Yig'indi har bir qo'shiluvchidan katta bo'lishi kerak: 5/16 &lt; 3/8 — demak xato» degan tekshiruvni o'rgating."},
{h:"Ayirish: bo'laklarni olib tashlaymiz",sum:"7/9 − 4/9 = 3/9: 7 ta bo'lakdan 4 tasi olindi, 3 tasi qoldi.",a:"m03",
 start:function(){clear();S.left=7;var B=f4bar(20,60,320,42,9,7,C.a);f4t(180,38,'7/9 − 4/9: 4 ta bo‘lakni bosib oling',13);B.cells.forEach(function(c,i){if(i>=7)return;c.style.cursor='pointer';c.addEventListener('click',function(){if(c._x||S.left<=3)return;c._x=1;c.setAttribute('fill','#ffd0d0');S.left--;var x=+c.getAttribute('x');E('line',{x1:x+6,y1:66,x2:x+320/9-6,y2:96,stroke:C.bad,'stroke-width':3,'pointer-events':'none'},S.g);f4c(['Olindi: '+(7-S.left)+' ta. Qoldi: '+S.left+'/9']);if(S.left===3&&S.cb)S.cb()})});f4c(['Bo‘yalgan bo‘laklardan 4 tasini bosing'])},
 fin:function(){clear();f4bar(20,60,320,42,9,3,C.a);f4t(180,38,'7/9 − 4/9 = 3/9',16,C.ok);f4Br(20,20+320*3/9,106,'3/9',false,C.ok);f4c(['7 − 4 = 3 → <b>3/9</b>. Maxraj o‘zgarmaydi'])},
 html:"<p>Shokoladdan 7/9 qismi bor edi. Ukangizga 4/9 qismini bering — rasmda 4 ta bo'lakni bosing:</p>",
 act:function(c,done){S.cb=function(){S.cb=null;f4c(['7/9 − 4/9 = <b>3/9</b>','7 − 4 = 3, maxraj 9 qoladi']);done()}},
 after:"<p>Ayirish ham xuddi qo'shishdek: <b>suratdan surat ayiriladi</b>, maxraj o'zgarmaydi. 7 ta to'qqizdan bir − 4 ta to'qqizdan bir = 3 ta to'qqizdan bir.</p>",
 q:{t:"8/11 − 5/11 = ?",opts:["3/11","13/11","3/22","5/11"],ok:0,why:"8 − 5 = 3, maxraj 11.",hint:"Faqat suratlar bilan amal bajaring.",full:"8 − 5 = 3 ta o'n birdan bir: 3/11. «3/22» — maxrajlarni qo'shish, «13/11» — ayirish o'rniga qo'shish."},
 tn:"Bolalarga qog'oz tasmani 9 ga buklatib, 7 tasini bo'yatib, 4 tasini qaychi bilan kesib olishni bajartiring — ayirishning ma'nosi qo'lda seziladi."},
{h:"Birdan ayirish",sum:"1 − 3/7 = 7/7 − 3/7 = 4/7. Avval 1 ni maxraji kerakli kasr ko'rinishida yozamiz.",a:"m04",
 start:function(){startPh(F3P4)},fin:function(){S.ph=2;F3P4[2]()},
 html:"<p>Butun shokoladdan 3/7 qismi yeyildi. Qancha qoldi? 1 da surat ham, maxraj ham yo'q — nima qilamiz? Bosing:</p>",btns:[phaser(F3P4)],
 after:"<p>Kalit fikr: <b>1 = 7/7</b> (butun — 7 ta yettidan bir). Shunda 1 − 3/7 = 7/7 − 3/7 = <b>4/7</b>.</p><p>1 ni istalgan maxraj bilan yozish mumkin: 1 = 2/2 = 5/5 = 10/10 = 100/100.</p>",
 q:{t:"1 − 5/12 = ?",opts:["4/12","7/12","1/7","6/12"],ok:1,why:"12/12 − 5/12 = 7/12.",hint:"1 ni o'n ikkidan bir bo'laklar bilan yozing: 1 = ?/12.",full:"1 = 12/12. 12/12 − 5/12 = 7/12. «4/12» — 1 ni «1» deb surat bilan ayirish (5 − 1), «1/7» — mantiqsiz."},
 tn:"«Butunni maydalash» — yapon darsliklarida alohida mashq: bolalar 1 = 4/4 = 8/8 … ni tasmada ko'rsatsin."},
{h:"Son o'qida qo'shish",sum:"2/6 + 3/6: son o'qida 0 dan 2 qadam, keyin yana 3 qadam — 5/6.",a:"m05",
 start:function(){startPh(F3P5)},fin:function(){S.ph=2;F3P5[2]()},
 html:"<p>Kasr — son, demak son o'qida qo'shish ham mumkin. 2/6 + 3/6 ni sakrab toping:</p>",btns:[phaser(F3P5,'🦘 Sakra')],
 after:"<p>Son o'qida 0 dan 1 gacha 6 ta teng qadam — har biri 1/6. 2 qadam + 3 qadam = 5 qadam: <b>5/6</b>. Qadam uzunligi (maxraj) o'zgarmadi — faqat qadamlar soni qo'shildi.</p>",
 q:{t:"Chumoli son o'qida 3/8 nuqtadan o'ngga 4/8 ga yurdi. U qaysi nuqtaga keldi?",opts:["7/16","7/8","1/8","12/8"],ok:1,why:"3/8 + 4/8 = 7/8.",hint:"O'ngga yurish — qo'shish. Har bir qadam 1/8.",full:"3 qadam + 4 qadam = 7 qadam, har biri 1/8: 7/8. «1/8» — chapga yurish (ayirish), «7/16» — maxrajlarni qo'shish."},
 tn:"Polga lenta bilan son o'qi chizing (0 va 1 orasi 6 qadam). Bolalar o'zi sakrab, «2/6 + 3/6» ni oyog'i bilan topsin."},
{h:"Uchta kasr bilan amal",sum:"2/10 + 5/10 − 4/10 = 3/10: chapdan o'ngga, faqat suratlar bilan: 2 + 5 − 4 = 3.",a:"m06",
 start:function(){startPh(F3P6)},fin:function(){S.ph=3;F3P6[3]()},
 html:"<p>Ifodada qo'shish ham, ayirish ham bor. Qavs yo'q — chapdan o'ngga bajaramiz:</p>",btns:[phaser(F3P6)],
 after:"<p>Maxraj hamma kasrda bir xil bo'lsa, butun ifodani <b>suratlar ustida</b> hisoblash mumkin: 2 + 5 − 4 = 3, maxraj 10 — javob <b>3/10</b>.</p>",
 q:{t:"9/10 − 3/10 + 2/10 = ?",opts:["4/10","8/10","14/10","8/30"],ok:1,why:"9 − 3 + 2 = 8.",hint:"Chapdan o'ngga: avval 9 − 3, keyin natijaga 2 ni qo'shing.",full:"9 − 3 = 6, 6 + 2 = 8: 8/10. «4/10» — ikkalasini ham ayirish (9 − 3 − 2): bu amallar tartibi xatosi. «8/30» — maxrajlarni qo'shish."},
 tn:"Butun sonlardagi amallar tartibi kasrlarda ham o'sha. Doskada avval 9 − 3 + 2 ni, keyin 9/10 − 3/10 + 2/10 ni yozib solishtiring."},
{h:"Noma'lum kasrni topish",sum:"□ + 3/11 = 9/11 → □ = 9/11 − 3/11 = 6/11. Noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi.",a:"m07",
 start:function(){clear();f4t(180,40,'□ + 3/11 = 9/11',22);f4barC(30,74,300,34,[null,null,null,null,null,null,C.b,C.b,C.b,null,null]);f4Br(30,30+300*6/11,112,'□ = ?',false,C.a2);f4Br(30+300*6/11,30+300*9/11,112,'3/11',false,C.blue);f4msg('Kvadrat o‘rnida qaysi kasr?')},
 fin:function(){clear();f4t(180,40,'6/11 + 3/11 = 9/11',22,C.ok);f4barC(30,74,300,34,[C.a,C.a,C.a,C.a,C.a,C.a,C.b,C.b,C.b,null,null]);f4Br(30,30+300*6/11,112,'6/11',false,C.a2);f4Br(30+300*6/11,30+300*9/11,112,'3/11',false,C.blue);f4msg('□ = 9/11 − 3/11 = <b>6/11</b>')},
 html:"<p>Kvadrat o'rniga qaysi kasr qo'yilsa, tenglik to'g'ri bo'ladi? Tanlang:</p>",
 btns:f4pick(0,[["6/11","To'g'ri: 9/11 − 3/11 = 6/11. Tekshirish: 6/11 + 3/11 = 9/11 ✓"],["12/11","Siz qo'shdingiz. Lekin 9/11 — yig'indi, undan qo'shiluvchini ayirish kerak."],["6/22","Maxrajlar ayirilmaydi ham, qo'shilmaydi ham — 11 qoladi."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Butun sonlardagi qoida o'zgarmaydi: <b>noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi</b>; <b>noma'lum kamayuvchi = ayirma + ayriluvchi</b>. Javobni doim o'rniga qo'yib tekshiring.</p>",
 q:{t:"□ − 2/9 = 5/9. Kvadrat o'rnida qaysi kasr?",opts:["3/9","7/9","7/18","10/9"],ok:1,why:"Kamayuvchi = 5/9 + 2/9 = 7/9.",hint:"Noma'lum — kamayuvchi. U ayirma bilan ayriluvchining yig'indisiga teng.",full:"□ = 5/9 + 2/9 = 7/9. Tekshirish: 7/9 − 2/9 = 5/9 ✓. «3/9» — ayirib yuborish (5 − 2), «7/18» — maxrajlarni qo'shish."},
 tn:"Tenglamani chizma bilan yeching: tasmada ma'lum va noma'lum qismni belgilang. Al-Xorazmiyning «al-jabr» usuli — noma'lumni bir tomonga to'plash."},
{h:"Matnli masala: qolgan qism",sum:"Yo'lning 2/9 + 4/9 = 6/9 qismi o'tildi; qoldi 9/9 − 6/9 = 3/9.",a:"m08",
 start:function(){startPh(F3P8)},fin:function(){S.ph=2;F3P8[2]()},
 html:"<p>Sayyohlar 1-kuni yo'lning 2/9 qismini, 2-kuni 4/9 qismini bosib o'tdi. Yo'lning qancha qismi qoldi?</p>",btns:[phaser(F3P8)],
 after:"<p>Butun yo'l — <b>9/9</b> (ya'ni 1). Avval o'tilganini qo'shamiz: 2/9 + 4/9 = 6/9. Keyin butundan ayiramiz: 9/9 − 6/9 = <b>3/9</b>.</p><p>Tuzoq: savolda «qoldi» so'zi bor — faqat qo'shib to'xtab qolmang!</p>",
 q:{t:"Bo'yoqchi devorning 3/10 qismini ertalab, 4/10 qismini kunduzi bo'yadi. Devorning qancha qismi bo'yalmay qoldi?",opts:["7/10","3/10","1/10","7/20"],ok:1,why:"Bo'yaldi 7/10, qoldi 10/10 − 7/10 = 3/10.",hint:"Avval qancha bo'yalganini toping. Butun devor — 10/10.",full:"3/10 + 4/10 = 7/10 bo'yaldi. 10/10 − 7/10 = 3/10 qoldi. «7/10» — bo'yalgan qism (savolga javob emas), «1/10» — 4/10 − 3/10."},
 tn:"Masalani chizma bilan yechishni talab qiling: butun tasma, ustida 1-kun va 2-kun, qolgani «?». Javob savolga mos ekanini tekshirtiring."},
{h:"Bilasizmi? 3500 yillik kasrlar",sum:"Misrning Rind papirusida (taxminan miloddan avvalgi 1550-yil) 2/5 = 1/3 + 1/15 kabi kasr jadvallari bor.",a:"m09",
 start:function(){clear('#f6ead0');f4t(180,30,'Rind papirusi (Misr)',15,'#7a4a12');f4t(180,56,'taxminan 3500 yil oldin',12,'#7a4a12');f4msg('Misrliklar kasrlarni qanday qo‘shgan?')},
 fin:function(){clear('#f6ead0');f4t(180,26,'Rind papirusi: 2/5 = 1/3 + 1/15',14,'#7a4a12');f4bar(30,46,300,30,5,2,C.a);f4barC(30,96,300,30,[C.a2,C.a2,C.a2,C.a2,C.a2,'#f3c06a',null,null,null,null,null,null,null,null,null]);f4t(80,150,'1/3',14,C.a2);f4t(140,150,'1/15',14,'#a8601f');f4msg('Ikkala tasma ham bir xil uzunlikda bo‘yalgan: 2/5 = 5/15 + 1/15 = 6/15')},
 html:"<p>📜 Britaniya muzeyida <b>Rind papirusi</b> saqlanadi. Uni miloddan avvalgi taxminan <b>1550-yilda</b> kotib <b>Axmes</b> ko'chirib yozgan. Tugmani bosing:</p>",
 btns:[["📜 Papirusni ochish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>Papirusda <b>84 ta masala</b> va 2/n ko'rinishidagi kasrlar jadvali bor. Misrliklar 2/5 ni surati 1 bo'lgan kasrlar yig'indisi qilib yozgan: <b>2/5 = 1/3 + 1/15</b>. Bu masala ham — kasrlarni qo'shish!</p><p>Bugun biz bir xil maxrajli kasrlarni bir qadamda qo'shamiz — chunki maxrajni «bo'lak nomi» deb tushunamiz.</p>",
 tn:"Kuchli o'quvchilarga topshiriq: 2/5 = 1/3 + 1/15 ekanini 15 ta katakli tasmada tekshirsin (6 katak = 5 + 1)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>Maxrajlar bir xil: <b>suratlar qo'shiladi (ayiriladi), maxraj o'zgarmaydi</b>. 3/8 + 2/8 = 5/8.</li><li>Maxrajlarni qo'shish — XATO: 3/8 + 2/8 ≠ 5/16.</li><li>Tekshirish: yig'indi har bir qo'shiluvchidan katta bo'ladi.</li><li>1 dan ayirish: <b>1 = 7/7</b>, 1 − 3/7 = 4/7.</li><li>Bir nechta amal — chapdan o'ngga: 2/10 + 5/10 − 4/10 = 3/10.</li><li>Noma'lum qo'shiluvchi = yig'indi − ma'lum qo'shiluvchi.</li><li>«Qoldi» — butundan (9/9 dan) ayiring.</li></ul></div>",
 tn:"Keyingi dars uchun savol: «7/7 — bu qanday kasr? 9/7 chi?» — to'g'ri va noto'g'ri kasrlarga ko'prik."}
];
var PROBS=[
{t:"3/10 + 4/10 = ?",o:["7/10","7/20","12/10","1/10"],k:0,s:"3 + 4 = 7; maxraj 10."},
{t:"11/15 − 6/15 = ?",o:["5/15","17/15","5/30","6/15"],k:0,s:"11 − 6 = 5; maxraj 15."},
{t:"1 − 4/9 = ?",o:["5/9","3/9","4/9","5/18"],k:0,s:"9/9 − 4/9 = 5/9."},
{t:"2/13 + 5/13 + 4/13 = ?",o:["11/13","11/39","10/13","11/26"],k:0,s:"2 + 5 + 4 = 11."},
{t:"17/20 − 9/20 − 3/20 = ?",o:["5/20","11/20","5/60","29/20"],k:0,s:"17 − 9 = 8; 8 − 3 = 5."},
{t:"Bola kitobning 1-kuni 3/11 qismini, 2-kuni 5/11 qismini o'qidi. Ikki kunda kitobning qancha qismini o'qidi?",o:["8/11","8/22","2/11","15/11"],k:0,s:"3/11 + 5/11 = 8/11."},
{t:"Bola kitobning 1-kuni 3/11 qismini, 2-kuni 5/11 qismini o'qidi. Kitobning qancha qismi o'qilmay qoldi?",o:["3/11","8/11","2/11","3/22"],k:0,s:"O'qildi 8/11; qoldi 11/11 − 8/11 = 3/11."},
{t:"□ + 5/12 = 11/12. Kvadrat o'rnida qaysi kasr?",o:["6/12","16/12","6/24","5/12"],k:0,s:"11/12 − 5/12 = 6/12."},
{t:"7/8 − □ = 2/8. Kvadrat o'rnida qaysi kasr?",o:["5/8","9/8","5/16","3/8"],k:0,s:"Ayriluvchi = 7/8 − 2/8 = 5/8."},
{t:"Qaysi tenglik to'g'ri?",o:["4/7 + 2/7 = 6/7","4/7 + 2/7 = 6/14","4/7 + 2/7 = 8/7","4/7 − 2/7 = 6/7"],k:0,s:"Suratlar qo'shiladi, maxraj o'zgarmaydi."},
{t:"5/9 + □ = 1. Kvadrat o'rnida qaysi kasr?",o:["4/9","5/9","6/9","1/9"],k:0,s:"1 = 9/9; 9/9 − 5/9 = 4/9."},
{t:"Idishda 7/10 litr sut bor edi. 2/10 litri ichildi, keyin 4/10 litr quyildi. Idishda endi qancha sut bor?",o:["9/10 l","1/10 l","13/10 l","5/10 l"],k:0,s:"7 − 2 + 4 = 9: 9/10 l."},
{t:"Sayyohlar 1-soatda yo'lning 2/9 qismini, 2-soatda esa 1-soatdagidan 1/9 ko'p qismini o'tdi. Yo'lning qancha qismi qoldi?",o:["4/9","5/9","6/9","3/9"],k:0,s:"2-soat: 3/9. O'tildi 5/9, qoldi 4/9."},
{t:"a/12 + 5/12 = 11/12 bo'lsa, a nechaga teng?",o:["6","16","11","5"],k:0,s:"a + 5 = 11, a = 6."},
{t:"3/11 + 4/11 va 9/11 − 3/11 ni taqqoslang.",o:["Birinchisi 1/11 ga katta","Ikkinchisi 1/11 ga katta","Teng","Birinchisi 2/11 ga katta"],k:0,s:"7/11 va 6/11: farq 1/11."},
{t:"Qaysi ifodaning qiymati 1 ga teng?",o:["3/8 + 5/8","4/9 + 4/9","7/10 − 3/10","2/5 + 2/5"],k:0,s:"3/8 + 5/8 = 8/8 = 1."},
{t:"1 dan 3/8 ni ayirdik, natijaga 1/8 ni qo'shdik. Nima hosil bo'ldi?",o:["6/8","4/8","2/8","5/8"],k:0,s:"8/8 − 3/8 = 5/8; 5/8 + 1/8 = 6/8."},
{t:"Hovuzning 1-soatda 3/12 qismi, 2-soatda 4/12 qismi, 3-soatda yana 4/12 qismi to'ldi. Hovuzning qancha qismi bo'sh qoldi?",o:["1/12","11/12","5/12","1/36"],k:0,s:"3 + 4 + 4 = 11: to'ldi 11/12, bo'sh 1/12."},
{t:"2/7 + 2/7 + 2/7 + 2/7 = ?",o:["8/7","8/28","2/28","6/7"],k:0,s:"2 · 4 = 8 ta yettidan bir: 8/7."},
{t:"Ikki kasrning yig'indisi 5/6, ayirmasi 1/6. Bu qaysi kasrlar?",o:["3/6 va 2/6","4/6 va 1/6","4/6 va 3/6","2/6 va 1/6"],k:0,s:"3/6 + 2/6 = 5/6; 3/6 − 2/6 = 1/6."}
];
var PREP_DATA={teach:["Maxraj — bo'lak nomi: 3 ta sakkizdan bir + 2 ta sakkizdan bir.","Qo'shish va ayirishda suratlar bilan amal, maxraj o'zgarmaydi.","1 dan ayirish: 1 = n/n.","Son o'qida qo'shish; uch kasrli ifoda.","Noma'lum komponentni topish; «qoldi» masalalari."],
 mist:["Maxrajlarni ham qo'shadi: 3/8 + 2/8 = 5/16.","1 − 3/7 da 1 ni kasrga aylantirmaydi (2/7 deb yozadi).","Uch amalli ifodada ikkala sonni ham ayiradi.","«Qoldi» masalasida faqat qo'shib to'xtaydi.","Noma'lum kamayuvchini ayirib topadi."],
 need:["Qog'oz doiralar (pitsa), tasmalar.","Polda lenta bilan son o'qi."],
 board:["<span class='w2'>3/8 + 2/8 = 5/8</span> (≠ 5/16!).","<span class='w2'>7/9 − 4/9 = 3/9</span>.","<span class='w2'>1 − 3/7 = 7/7 − 3/7 = 4/7</span>.","<span class='w2'>2/10 + 5/10 − 4/10 = 3/10</span>.","□ + 3/11 = 9/11 → □ = 6/11."]};
