var CODE='4D4',TITLE='4-sinf · Tengsizliklar';
var P3=[function(){w3Expr(['x + 12 < 20']);w3Msg('Avval «chegara»ni topamiz: qachon tenglik bo‘ladi?')},
 function(){w3Expr(['x + 12 = 20','x = {8}']);w3Msg('x = 8 da chap tomon 20 ga teng — bu chegara')},
 function(){w3Ray(1,10,1,[[8,'8',C.bad]],{all:1});w3Msg('8 da 20 ga teng. 8 dan katta bo‘lsa — 20 dan oshib ketadi')},
 function(){w3Ray(1,10,1,[[1,'',C.ok],[2,'',C.ok],[3,'',C.ok],[4,'',C.ok],[5,'',C.ok],[6,'',C.ok],[7,'7',C.ok],[8,'8',C.bad]],{all:1});w3Msg('Yechimlar: 1, 2, …, 7. Eng kattasi — <b>7</b> (7 + 12 = 19 &lt; 20 ✓)')}];
var P8=[function(){w3Bar([{lab:'lift',segs:[{w:600,t:'ko‘pi bilan 600 kg'}],tot:600}],{top:60});w3Msg('Lift ko‘pi bilan 600 kg ko‘taradi. Har odam 75 kg')},
 function(){w3Bar([{lab:'lift',segs:[{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'}],tot:600,br:'8 · 75 = 600',brw:1}],{top:60});w3Msg('75 · x ≤ 600 → 8 kishi (aynan 600 — ruxsat)')},
 function(){w3Bar([{lab:'lift',segs:[{w:70,t:'yuk',c:C.a},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:75,t:'75'},{w:5,t:'',c:'#fff'}],tot:600,br:'70 + 7 · 75 = 595',brw:595/600}],{top:60});w3Msg('70 kg yuk bilan: 75 · x ≤ 530 → <b>7</b> kishi (8 kishi bo‘lsa 670 kg!)')}];
var STEPS=[
{h:"Tengsizlik nima?",sum:"«>» — katta, «<» — kichik. 305 > 299 — to'g'ri tengsizlik; 305 < 299 — noto'g'ri.",a:"m01",
 start:function(){w3Expr(['305 ? 299']);w3Msg('Qaysi yozuv to‘g‘ri?')},fin:function(){w3Expr(['305 {>} 299']);w3Msg('Belgining «og‘zi» katta songa ochiladi')},
 html:"<p>Ikki son yoki ifoda «katta-kichik» belgisi bilan bog'lansa — <b>tengsizlik</b>. Qaysi biri <b>to'g'ri</b>?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['305 > 299','305 < 299','305 = 299'],'305 > 299',function(){w3Expr(['305 {>} 299']);w3Msg('To‘g‘ri: 3 yuz 2 yuzdan katta');done()},{'305 < 299':'Yuzlarni solishtiring: 3 yuz > 2 yuz','305 = 299':'Bu sonlar teng emas'})},
 after:"<p>Tengsizlik to'g'ri yoki noto'g'ri bo'lishi mumkin. Agar unda <b>x</b> bo'lsa (x < 5), x ning tengsizlikni to'g'ri qiladigan har bir qiymati — <b>yechim</b>. Tenglamadan farqi: yechim odatda bitta emas, <b>ko'p</b>!</p>",
 q:{t:"Qaysi tengsizlik noto'g'ri?",opts:["4 · 25 > 101","99 < 100","1000 > 999","7 · 8 > 55"],ok:0,why:"4 · 25 = 100, 100 > 101 — noto'g'ri.",hint:"Har birini hisoblang.",full:"4 · 25 = 100, 100 < 101, demak «4 · 25 > 101» noto'g'ri. 7 · 8 = 56 > 55 — to'g'ri."},
 tn:"Belgini «ochiq og'iz» deb tushuntiring: og'iz doim katta tomonga qaraydi."},
{h:"x < 5: yechimlarni toping",sum:"1 dan 9 gacha sonlardan x < 5 ning yechimlari: 1, 2, 3, 4. 5 yechim emas (5 < 5 — noto'g'ri).",a:"m02",
 start:function(){S.w4=[];var dr=function(){w3Ray(1,9,1,S.w4.map(function(v){return[v,String(v),C.ok]}),{all:1,tap:function(v){if(v<5){if(S.w4.indexOf(v)<0)S.w4.push(v);dr();w3Msg('✓ '+v+' &lt; 5. Topildi: '+S.w4.length+' / 4');if(S.w4.length===4&&S.w4done)S.w4done()}else{w3Msg(v===5?'5 &lt; 5 — noto‘g‘ri! 5 o‘ziga teng, kichik emas':v+' &lt; 5 — noto‘g‘ri, '+v+' katta')}}})};S.w4dr=dr;dr();w3Msg('Son nurida x &lt; 5 bo‘ladigan sonlarni bosing')},
 fin:function(){w3Ray(1,9,1,[[1,'1',C.ok],[2,'2',C.ok],[3,'3',C.ok],[4,'4',C.ok],[5,'5',C.bad]],{all:1});w3Msg('Yechimlar: 1, 2, 3, 4. 5 — chegara, yechim emas')},
 html:"<p>Son nurida <b>x &lt; 5</b> tengsizlikning yechimi bo'lgan barcha sonlarni bosing (1 dan 9 gacha):</p>",
 act:function(c,done){S.w4done=done;if(S.w4.length===4)done()},
 after:"<p>Yechimlar: <b>1, 2, 3, 4</b> — 4 ta. Diqqat: <b>5 yechim emas</b>, chunki 5 &lt; 5 noto'g'ri (5 = 5). Son nurida yechimlar — chegaradan chapdagi hamma nuqtalar.</p>",
 q:{t:"Qaysi son x < 5 tengsizlikning yechimi EMAS?",opts:["5","4","3","1"],ok:0,why:"5 < 5 — noto'g'ri.",hint:"Chegaraning o'zini tekshiring.",full:"5 < 5 noto'g'ri, chunki 5 = 5. 4, 3, 1 — hammasi 5 dan kichik, demak yechim."},
 tn:"Polga lenta bilan son nuri chizing. «x < 5» ni aytsangiz, mos sonlardagi bolalar o'rnidan turadi."},
{h:"Ifodali tengsizlik: chegaradan boshlang",sum:"x + 12 < 20: chegara x + 12 = 20 → x = 8. Yechimlar 8 dan kichik: eng kattasi 7.",a:"m03",
 start:w4St(P3),fin:w4Fin(P3),
 html:"<p><b>x + 12 &lt; 20</b> ning eng katta natural yechimini topamiz. Usul: avval <b>tenglama</b> yechib chegarani topamiz.</p>",btns:[phaser(P3)],
 after:"<p>Usul: 1) «&lt;» ni «=» ga almashtirib, chegarani toping (x = 8); 2) chegaraning o'zini va yonidagi sonni tekshiring: 8 + 12 = 20 (teng — yechim emas), 7 + 12 = 19 &lt; 20 ✓.</p>",
 q:{t:"100 − x > 93. x ning eng katta natural qiymati?",opts:["6","7","8","93"],ok:0,why:"100 − 7 = 93 (teng emas, katta kerak), 100 − 6 = 94 > 93 ✓.",hint:"Chegara: 100 − x = 93, x = 7.",full:"Chegara x = 7: 100 − 7 = 93 — «katta» emas. x kamaysa, ayirma oshadi: x = 6 da 94 > 93 ✓. Javob 6. «7» — chegarani yechim deb olish."},
 tn:"Chegarani doskada qizil nuqta bilan belgilang. Bola chegaradan qaysi tomonga yurish kerakligini tekshirib aytsin."},
{h:"Tuzoq: «eng kichik» yechim",sum:"3 · x > 20: 3 · 6 = 18 (kichik), 3 · 7 = 21 > 20 ✓. Eng kichik natural yechim — 7.",a:"m04",
 start:function(){w3Expr(['3 · x > 20','x = ?  (eng kichik natural)']);w3Msg('20 : 3 butun chiqmaydi — ehtiyot bo‘ling')},fin:function(){w3Expr(['3 · 6 = 18 [<] 20 ✗','3 · 7 = 21 {>} 20 ✓']);w3Msg('Eng kichik yechim — 7')},
 html:"<p><b>3 · x &gt; 20</b> ning <b>eng kichik</b> natural yechimini tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['6','7','21'],'7',function(){w3Expr(['3 · 6 = 18 [<] 20 ✗','3 · 7 = 21 {>} 20 ✓']);w3Msg('To‘g‘ri: 7');done()},{'6':'3 · 6 = 18 — bu 20 dan kichik, «katta» shart bajarilmadi','21':'21 — bu 3 · x ning qiymati, x emas. x = 7'})},
 after:"<p>20 : 3 = 6 (qoldiq 2). 6 «yetmaydi» (18 &lt; 20), shuning uchun keyingi son — <b>7</b>. Qoldiqli bo'lishda javobni har doim tekshiring: yaxlitlab yuborish yoki tashlab yuborish — masala shartiga qarab!</p>",
 q:{t:"1200 < 4 · x. x ning eng kichik natural qiymati?",opts:["301","300","299","4800"],ok:0,why:"4 · 300 = 1200 (teng), 4 · 301 = 1204 > 1200 ✓.",hint:"Chegara: 4 · x = 1200, x = 300.",full:"x = 300 da 4 · 300 = 1200 — «kichik» emas, teng. Demak eng kichik yechim 301. «300» — chegarani yechim deb olish; «4800» — ko'paytirish."},
 tn:"Bolalar chegaraning ikki yonidagi sonlarni (6 va 7) jadvalga yozib tekshirsin — «chegara tekshiruvi» odatini shakllantiring."},
{h:"Qo'sh tengsizlik",sum:"45 < x < 50: x = 46, 47, 48, 49 — 4 ta son (45 va 50 kirmaydi).",a:"m05",
 start:function(){w3Ray(44,51,1,[[45,'45',C.bad],[50,'50',C.bad]],{all:1});w3Msg('45 &lt; x &lt; 50 — x ikki son orasida')},fin:function(){w3Ray(44,51,1,[[45,'45',C.bad],[46,'',C.ok],[47,'',C.ok],[48,'',C.ok],[49,'',C.ok],[50,'50',C.bad]],{all:1});w3Msg('46, 47, 48, 49 — 4 ta son')},
 html:"<p><b>45 &lt; x &lt; 50</b> — «x 45 dan katta va 50 dan kichik». Nechta natural son bu shartni qanoatlantiradi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['4','5','6'],'4',function(){w3Ray(44,51,1,[[45,'45',C.bad],[46,'',C.ok],[47,'',C.ok],[48,'',C.ok],[49,'',C.ok],[50,'50',C.bad]],{all:1});w3Msg('To‘g‘ri: 46, 47, 48, 49');done()},{'5':'50 − 45 = 5 — lekin chegaralar kirmaydi. Sanab ko‘ring!','6':'45 va 50 ham kiritildi — ular yechim emas'})},
 after:"<p>Tuzoq: 50 − 45 = 5 deb javob berish. Ikkala chegara ham kirmasa, sonlar soni <b>bittaga kam</b>: 50 − 45 − 1 = 4. Shubha bo'lsa — sanab chiqing!</p>",
 q:{t:"a < 8 va a > 5. a ning nechta natural qiymati bor?",opts:["2","3","4","1"],ok:0,why:"6 va 7.",hint:"5 < a < 8.",full:"5 < a < 8 → a = 6 yoki 7 — 2 ta. «3» — 8 − 5 = 3 deb, chegaralarni hisobga olmaslik."},
 tn:"Ikki bola chegara sonlarini ushlab turadi, orasidagilar sanaladi — chegara bolalari «sanalmaydi»."},
{h:"Ikki shart birga",sum:"x juft va 30 < 2 · x < 40: 2 · x = 32, 34, 36, 38 → x = 16, 17, 18, 19; juftlari 16 va 18 — 2 ta.",a:"m06",
 start:function(){w3Expr(['30 < 2 · x < 40','x — juft son']);w3Msg('Ikkala shart birga bajarilishi kerak')},fin:function(){w3Expr(['2 · x: 32, 34, 36, 38','x: {16}, 17, {18}, 19','juftlari: 16 va 18']);w3Msg('Javob: 2 ta')},
 html:"<p><b>x</b> — juft son va <b>30 &lt; 2 · x &lt; 40</b>. Nechta shunday x bor?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['2','4','5'],'2',function(){w3Expr(['2 · x: 32, 34, 36, 38','x: {16}, 17, {18}, 19','juftlari: 16 va 18']);w3Msg('To‘g‘ri!');done()},{'4':'4 ta x topildi (16–19), lekin «juft» shartini unutmang','5':'31 dan 39 gacha 2 · x juft bo‘lishi kerak — 5 ta emas'})},
 after:"<p>Murakkab masalalarda shartlarni <b>bittalab</b> qo'llang: avval 2 · x ning qiymatlari (32, 34, 36, 38), keyin x (16, 17, 18, 19), oxirida «juft» filtri (16, 18). Har bosqichni yozib boring!</p>",
 q:{t:"x · 5 < 43. Nechta natural yechim bor?",opts:["8","9","43","7"],ok:0,why:"x = 1, …, 8 (8 · 5 = 40 < 43; 9 · 5 = 45).",hint:"Chegara: 43 : 5 = 8 (qoldiq 3).",full:"8 · 5 = 40 < 43 ✓, 9 · 5 = 45 > 43 ✗. Yechimlar 1…8 — 8 ta."},
 tn:"Elak (filtr) metaforasi: har shart — bitta elak. Kartochkalarni bosqichma-bosqich elakdan o'tkazing."},
{h:"Hisoblamasdan taqqoslash",sum:"600 : 4 > 600 : 5 — bo'luvchi katta bo'lsa, bo'linma kichik. 345 + 278 < 345 + 287.",a:"m07",
 start:function(){w3Expr(['600 : 4  ?  600 : 5']);w3Msg('Hisoblamasdan belgini qo‘ying')},fin:function(){w3Expr(['600 : 4 {>} 600 : 5','150 > 120']);w3Msg('Kamroq odamga bo‘linsa — har biriga ko‘proq tegadi')},
 html:"<p>Hisoblamasdan belgini tanlang: <b>600 : 4 ? 600 : 5</b></p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['>','<','='],'>',function(){w3Expr(['600 : 4 {>} 600 : 5','150 > 120']);w3Msg('To‘g‘ri: 600 ni 4 kishiga bo‘lsak, har biriga ko‘proq tegadi');done()},{'<':'5 katta, lekin 600 ni ko‘proq kishiga bo‘lsak — har biriga kamroq tegadi','=':'Bo‘luvchilar har xil — bo‘linmalar ham har xil'})},
 after:"<p>Mantiq bilan taqqoslash qoidalari: yig'indida bir qo'shiluvchi bir xil bo'lsa — ikkinchisi hal qiladi (345 + 278 &lt; 345 + 287). Ayirmada ayriluvchi katta bo'lsa — ayirma kichik. Bo'lishda bo'luvchi katta bo'lsa — bo'linma kichik.</p>",
 q:{t:"Qaysi yozuv to'g'ri? (hisoblamasdan o'ylang)",opts:["900 − 348 > 900 − 384","900 − 348 < 900 − 384","900 − 348 = 900 − 384","900 − 384 > 900 − 348"],ok:0,why:"348 < 384 → kamroq ayirilsa, ko'proq qoladi.",hint:"Qaysi holda ko'proq ayiriladi?",full:"900 dan 348 ni ayirsak — 384 ni ayirgandan ko'ra kamroq olinadi, demak ko'proq qoladi: 552 > 516."},
 tn:"Pizza misoli: 1 ta pizzani 4 kishiga yoki 5 kishiga bo'lish — qaysi bo'lak katta?"},
{h:"Hayotiy tengsizlik: lift",sum:"Lift ko'pi bilan 600 kg: 75 kg dan 8 kishi. 70 kg yuk bilan: 75 · x ≤ 530 → 7 kishi.",a:"m08",
 start:w4St(P8),fin:w4Fin(P8),
 html:"<p>«<b>Ko'pi bilan</b>» — «shundan oshmasin» (≤), «<b>kamida</b>» — «shundan kam bo'lmasin» (≥). Lift masalasini kuzating:</p>",btns:[phaser(P8)],
 after:"<p>Yuk bilan: 600 − 70 = 530 kg odamlarga qoladi. 530 : 75 = 7 (qoldiq 5). 8 kishi bo'lsa 70 + 600 = 670 kg — liftning chegarasidan oshadi! Hayotda tengsizliklar xavfsizlik uchun kerak.</p>",
 q:{t:"25 000 so'm bor. 4000 so'mlik ruchka va 2500 so'mlik daftarlar olinmoqchi. Ko'pi bilan nechta daftar olish mumkin?",opts:["8","9","10","7"],ok:0,why:"25 000 − 4000 = 21 000; 21 000 : 2500 = 8 (qoldiq 1000).",hint:"Avval ruchka pulini ayiring.",full:"Daftarga 21 000 so'm qoladi. 8 · 2500 = 20 000 ≤ 21 000 ✓, 9 · 2500 = 22 500 > 21 000 ✗. Javob 8. «10» — ruchka hisobga olinmagan."},
 tn:"Lift yoki ko'prik yonidagi «max 600 kg» belgisi rasmini ko'rsating."},
{h:"Bilasizmi? «<» va «>» belgilari",sum:"«<» va «>» belgilarini ingliz olimi Tomas Harriot kiritgan; ular 1631-yilda nashr etilgan kitobida chiqqan.",a:"m09",
 start:function(){w3Expr(['3 < 5','5 > 3']);w3Msg('Atigi 400 yoshga yaqin belgilar')},fin:function(){w3Expr(['3 < 5','5 > 3']);w3Msg('Atigi 400 yoshga yaqin belgilar')},
 html:"<p>📜 «Kichik» va «katta» belgilarini ingliz matematigi va astronomi <b>Tomas Harriot</b> o'ylab topgan. Ular uning vafotidan keyin, <b>1631-yilda</b> nashr etilgan kitobida chiqqan.</p><p>⭐ Undan oldin matematiklar «kichik», «katta» so'zlarini to'liq yozishgan. Qiziq: o'sha yili «×» belgisi ham bosmada paydo bo'lgan!</p>",
 tn:"Belgilar tarixini 4D1 dagi «×» tarixi bilan bog'lang — ikkalasi ham 1631-yil."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['1) chegara: < → =','2) chegarani tekshir','3) yechimlarni sana']);w3Msg('Tengsizlik yechish rejasi')},fin:function(){w3Expr(['1) chegara: < → =','2) chegarani tekshir','3) yechimlarni sana']);w3Msg('Tengsizlik yechish rejasi')},
 html:"<div class='memo'><ul><li>Belgining «og'zi» katta tomonga qaraydi: 5 &gt; 3, 3 &lt; 5.</li><li>Tengsizlikda yechim ko'p bo'ladi; chegara soni (x &lt; 5 da 5) yechim emas.</li><li>Usul: «&lt;» ni «=» ga almashtirib chegarani toping, so'ng chegara va qo'shni sonni tekshiring.</li><li>45 &lt; x &lt; 50 — 4 ta son (5 ta emas!).</li><li>«Ko'pi bilan» — oshmasin, «kamida» — kam bo'lmasin.</li><li>Bo'luvchi katta → bo'linma kichik; ayriluvchi katta → ayirma kichik.</li></ul></div>",
 tn:"Kartochkani 4E (masalalar) mavzulariga bog'lang: «ko'pi bilan», «kamida» so'zlari matnli masalalarda ko'p uchraydi."}
];
var PROBS=[
{t:"Qaysi son x < 5 tengsizlikning yechimi EMAS?",o:["5","4","3","1"],k:0,s:"5 < 5 — noto'g'ri."},
{t:"x + 12 < 20. x ning eng katta natural qiymati?",o:["7","8","32","6"],k:0,s:"Chegara x = 8; 7 + 12 = 19 < 20."},
{t:"3 · x > 20. x ning eng kichik natural qiymati?",o:["7","6","21","60"],k:0,s:"3 · 6 = 18, 3 · 7 = 21 > 20."},
{t:"45 < x < 50. Nechta natural son bu shartni qanoatlantiradi?",o:["4","5","6","3"],k:0,s:"46, 47, 48, 49."},
{t:"Qaysi yozuv to'g'ri?",o:["600 : 4 > 600 : 5","600 : 4 < 600 : 5","600 : 4 = 600 : 5","600 : 4 > 600 : 3"],k:0,s:"150 > 120; 600 : 3 = 200 > 150."},
{t:"Qaysi yozuv to'g'ri?",o:["345 + 278 < 345 + 287","345 + 278 > 345 + 287","345 + 278 = 345 + 287","345 + 278 > 344 + 279"],k:0,s:"278 < 287. 344 + 279 = 623 = 345 + 278."},
{t:"Lift ko'pi bilan 600 kg ko'taradi. Har bir odam 75 kg. Ko'pi bilan nechta odam chiqishi mumkin?",o:["8","9","7","80"],k:0,s:"8 · 75 = 600."},
{t:"Lift ko'pi bilan 600 kg ko'taradi. Unda 70 kg yuk bor. 75 kg dan ko'pi bilan nechta odam chiqishi mumkin?",o:["7","8","6","9"],k:0,s:"530 : 75 = 7 (qoldiq 5)."},
{t:"x — juft son va 30 < 2 · x < 40. Nechta shunday x bor?",o:["2","4","5","3"],k:0,s:"x = 16, 17, 18, 19; juftlari 16, 18."},
{t:"x · 5 < 43. Nechta natural yechim bor?",o:["8","9","43","7"],k:0,s:"1 dan 8 gacha."},
{t:"100 − x > 93. x ning eng katta natural qiymati?",o:["6","7","8","93"],k:0,s:"100 − 6 = 94 > 93; 100 − 7 = 93."},
{t:"Qaysi son 2 · x + 5 < 25 tengsizlikning yechimi?",o:["9","10","12","15"],k:0,s:"2 · 9 + 5 = 23 < 25; 2 · 10 + 5 = 25."},
{t:"1200 < 4 · x. x ning eng kichik natural qiymati?",o:["301","300","299","4800"],k:0,s:"4 · 300 = 1200, 4 · 301 = 1204."},
{t:"a < b va b < c bo'lsa, qaysi biri to'g'ri?",o:["a < c","a > c","a = c","c < b"],k:0,s:"a < b < c."},
{t:"a < 8 va a > 5. a ning nechta natural qiymati bor?",o:["2","3","4","1"],k:0,s:"6 va 7."},
{t:"Qaysi yozuv to'g'ri?",o:["7 · 8 > 9 · 6","7 · 8 < 9 · 6","7 · 8 = 9 · 6","7 · 8 < 6 · 9"],k:0,s:"56 > 54."},
{t:"15 000 so'mga 2500 so'mlik daftardan ko'pi bilan nechta olish mumkin?",o:["6","5","7","4"],k:0,s:"6 · 2500 = 15 000."},
{t:"25 000 so'm bor. 4000 so'mlik ruchka va 2500 so'mlik daftarlar olinmoqchi. Ko'pi bilan nechta daftar olish mumkin?",o:["8","9","10","7"],k:0,s:"21 000 : 2500 = 8 (qoldiq 1000)."},
{t:"350 < x < 400 va x — 25 ga bo'linadi. x = ?",o:["375","350","400","380"],k:0,s:"350 va 400 kirmaydi; 375 = 25 · 15."},
{t:"Qayiqqa ko'pi bilan 8 kishi sig'adi. 50 kishini kamida necha qatnovda o'tkazish mumkin?",o:["7","6","8","5"],k:0,s:"6 · 8 = 48 < 50, demak 7 qatnov kerak."}
];
function PRACT_STAGE(){w3Ray(1,9,1,[[5,'5',C.bad]],{all:1});w3Msg('Chegarani toping va tekshiring')}
var PREP_DATA={teach:["Tengsizlik, uning yechimi; son nurida tasvirlash.","Ifodali tengsizliklar: chegara orqali yechish.","Qo'sh tengsizlik va ikki shartli masalalar.","Hisoblamasdan taqqoslash; «ko'pi bilan», «kamida» masalalari."],
 mist:["Chegara sonni yechim deb oladi (x < 5 da 5).","45 < x < 50 da 5 ta son deb sanaydi.","Qoldiqli bo'lishda noto'g'ri yaxlitlaydi (3 · x > 20 da 6).","Bo'luvchi kattalashsa bo'linma ham kattalashadi deb o'ylaydi."],
 need:["Polga chizilgan son nuri (lenta).","Son kartochkalari."],
 board:["<span class='w2'>x < 5: 1, 2, 3, 4</span>.","<span class='w2'>x + 12 < 20 → eng katta x = 7</span>.","<span class='w2'>3 · x > 20 → eng kichik x = 7</span>.","<span class='w2'>45 < x < 50: 4 ta son</span>.","<span class='w2'>600 : 4 > 600 : 5</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
