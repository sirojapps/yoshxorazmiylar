var CODE='3J20',TITLE='3-sinf · Shakl = son jumboqlari';
var J20G={T:['▲','#e8862a'],S:['■','#3d7fd0'],C:['●','#2f9e5f']};
// tokenli qator: 'T','S','C' — shakllar, boshqalar — matn; 'B3' — 3 bananli dasta
function j20Row(g,y,toks,fs,col){fs=fs||24;var ws=toks.map(function(t){if(J20G[t])return fs*1.05;if(/^B\d$/.test(t))return +t[1]*fs*0.62+12;return String(t).length*fs*0.56+6}),W=ws.reduce(function(a,b){return a+b},0),x=180-W/2;
 toks.forEach(function(t,i){var cx=x+ws[i]/2;if(J20G[t])T(g,cx,y,J20G[t][0],{'font-size':fs,'font-weight':800,fill:J20G[t][1]});
  else if(/^B\d$/.test(t)){E('rect',{x:x+2,y:y-fs*0.85,width:ws[i]-4,height:fs*1.1,rx:8,fill:'#fff6c9',stroke:'#d9b84a'},g);T(g,cx,y-2,new Array(+t[1]+1).join('🍌'),{'font-size':fs*0.6})}
  else T(g,cx,y,t,{'font-size':fs*0.85,'font-weight':800,fill:col||'#1d2b3a'});x+=ws[i]})}
function j20Eqs(rows,o){o=o||{};clear(o.bg);var g=S.g,n=rows.length,dy=o.dy||Math.min(40,140/n),y0=o.y0||(92-(n-1)*dy/2+8);rows.forEach(function(r,i){j20Row(g,y0+i*dy,r.t||r,r.fs||o.fs,r.c)})}
function j20Scale(L,R,tilt){clear();var g=S.g,a=tilt||0;E('polygon',{points:'180,150 166,166 194,166',fill:'#8a5a24'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#8a5a24','stroke-width':4},g);
 var w=E('g',{transform:'rotate('+a+' 180 70)'},g);E('line',{x1:60,y1:70,x2:300,y2:70,stroke:'#8a5a24','stroke-width':4},w);[[90,L],[270,R]].forEach(function(s){E('line',{x1:s[0]-40,y1:70,x2:s[0]-40,y2:110,stroke:'#b89a6a'},w);E('line',{x1:s[0]+40,y1:70,x2:s[0]+40,y2:110,stroke:'#b89a6a'},w);E('path',{d:'M'+(s[0]-50)+' 110 Q'+s[0]+' 130 '+(s[0]+50)+' 110 Z',fill:'#f0dcb4',stroke:'#b89a6a'},w);
  var k=0;s[1].forEach(function(t){if(J20G[t]){T(w,s[0]-((s[1].length-1)*13)+k*26,104,J20G[t][0],{'font-size':24,'font-weight':800,fill:J20G[t][1]});k++}else{T(w,s[0]-((s[1].length-1)*13)+k*26,104,t,{'font-size':16,'font-weight':800});k++}})});}
var P2=[function(){j20Eqs([['T','+','S','=','10'],['T','+','T','+','S','=','14']]);j2Msg('Ikki tenglik. Ikkinchisida birinchisidan nima <b>ortiq</b>?')},
 function(){j20Eqs([{t:['T','+','S','=','10']},{t:['T','+','T','+','S','=','14']},{t:['ortiqcha: ','T','= 14 − 10'],fs:20,c:C.bad}]);j2Msg('Ikkinchi qatorda bitta ▲ ortiq, yig‘indi esa 4 ga ortiq → ▲ = <b>4</b>')},
 function(){j20Eqs([{t:['T','=','4']},{t:['4','+','S','=','10']},{t:['S','=','6'],c:C.ok}]);j2Msg('Birinchi tenglikka qo‘yamiz: 4 + ■ = 10 → ■ = <b>6</b>. Tekshirish: 4 + 4 + 6 = 14 ✓')}];
function j20Grid(sh,vals){clear();var g=S.g,rows=[['C','C','C'],['C','T','T'],['T','S','C']],sums=[12,20,17];
 rows.forEach(function(r,i){E('rect',{x:70,y:16+i*46,width:170,height:40,rx:8,fill:'#fff7ea',stroke:'#d9b98a'},g);r.forEach(function(t,j){var v=vals&&vals[t]!=null&&sh>i;T(g,100+j*55,16+i*46+29,v?vals[t]:J20G[t][0],{'font-size':v?20:26,'font-weight':800,fill:J20G[t][1]})});
  E('rect',{x:256,y:22+i*46,width:46,height:28,rx:6,fill:'#e8f0fb',stroke:'#4b8fd9'},g);T(g,279,42+i*46,sums[i],{'font-size':16,'font-weight':800,fill:'#2a64a8'})});T(g,290,160,'yig‘indilar',{'font-size':10,fill:'#5b6b7b'})}
var P3=[function(){j20Grid(0);j2Msg('Har tokchadagi shakllar yig‘indisi o‘ngda. Qaysi tokchadan boshlash kerak?')},
 function(){j20Grid(1,{C:4});j2Msg('1-tokcha: ●●● = 12 → ● = 12 : 3 = <b>4</b>. Faqat bitta xil shakl bor qatordan boshlaymiz!')},
 function(){j20Grid(2,{C:4,T:8});j2Msg('2-tokcha: 4 + ▲ + ▲ = 20 → ▲ + ▲ = 16 → ▲ = <b>8</b>')},
 function(){j20Grid(3,{C:4,T:8,S:5});j2Msg('3-tokcha: 8 + ■ + 4 = 17 → ■ = <b>5</b>')}];
var P5=[function(){j20Eqs([['S','+','S','+','T','=','T','T','T','T','T','T','T']],{fs:24});j2Msg('Tenglik: ■ + ■ + ▲ = 7 ta ▲. ■ va ▲ qanday bog‘langan?')},
 function(){j20Eqs([{t:['S','+','S','+','T','=','T','T','T','T','T','T','T']},{t:['har ikki tomondan bitta ▲ olib tashlaymiz'],fs:15,c:C.bad}]);j2Msg('Tarozidek: ikkala pallaga bir xil narsani olsak — muvozanat saqlanadi')},
 function(){j20Eqs([{t:['S','+','S','=','T','T','T','T','T','T']},{t:['S','=','T','T','T'],c:C.ok}]);j2Msg('2 ta ■ = 6 ta ▲ → 1 ta ■ = <b>3 ta ▲</b>, ya’ni ▲ + ▲ + ▲ = ■')}];
var P7=[function(){j20Eqs([['🍎','+','🍎','+','🍎','=','30'],['🍎','+','B4','+','B4','=','18'],['B3','+','🍎','=','?']],{fs:22});j2Msg('Mashhur internet jumbog‘i. Diqqat bilan qarang!')},
 function(){j20Eqs([{t:['🍎','=','10'],c:C.ok},{t:['10','+','B4','+','B4','=','18']},{t:['B4','=','4']}],{fs:22});j2Msg('🍎 = 10. Ikki dasta = 8 → bitta dasta = 4. Dastada nechta banan bor?')},
 function(){j20Eqs([{t:['B4','= 4 → 1 banan = 1']},{t:['B3','=','3'],c:C.bad},{t:['3 + 10 = 13'],c:C.ok}],{fs:22});j2Msg('Tuzoq: oxirgi qatorda dastada <b>3 ta</b> banan! 3 + 10 = <b>13</b> (14 emas)')}];
var STEPS=[
{h:"Bir xil shakl — bir xil son",sum:"▲ + ▲ + ▲ = 18 → ▲ = 18 : 3 = 6.",a:"m01",
 start:function(){j20Eqs([['T','+','T','+','T','=','18']],{fs:30});j2Msg('Bir xil shakllar — bir xil son. ▲ nechaga teng?')},fin:function(){j20Eqs([['6','+','6','+','6','=','18']],{fs:30});j2Msg('✓ ▲ = 6')},
 html:"<p>Shakl — bu yashirin son. Uch ta bir xil son qo'shilib 18 bo'ldi. Bitta ▲ ni toping:</p>",
 g2:1,btns:j2Pick(["6","15","9","3"],0,function(){STEPS[0].fin()},function(i){j2Msg(['','15 = 18 − 3: ayirmaymiz, 3 ga <b>bo‘lamiz</b>','9 + 9 + 9 = 27 — ko‘p','3 + 3 + 3 = 9 — kam'][i])}),
 after:"<p>Bir xil qo'shiluvchilar yig'indisi — <b>ko'paytirish</b>: ▲ · 3 = 18. Demak ▲ = 18 : 3 = 6. Doim <b>tekshiring</b>: 6 + 6 + 6 = 18 ✓.</p>",
 q:{t:"● + ● + ● + ● + ● = 45. ● nechaga teng?",opts:["9","40","5","8"],ok:0,why:"45 : 5 = 9.",hint:"Nechta ● bor? Yig'indini shunga bo'ling.",full:"5 ta bir xil son → ● · 5 = 45 → ● = 9. «40» — 45 − 5, «5» — shakllar soni."},
 tn:"Bolalarga kartondan ▲ ■ ● qirqib bering — orqasiga son yozib, «yashirin son» o'yinini o'ynating."},
{h:"Ikki tenglikni solishtiramiz",sum:"▲ + ■ = 10 va ▲ + ▲ + ■ = 14: farq bitta ▲ = 4, keyin ■ = 6.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ikki noma'lum, ikki tenglik. Ayyor usul — tengliklarni <b>solishtirish</b>: biri ikkinchisidan nimasi bilan farq qiladi?</p>",
 btns:[phaser(P2,'▶ Keyingi')],
 after:"<p>Ikkinchi tenglikda xuddi birinchisi + yana bitta ▲. Shuning uchun yig'indilar farqi — aynan ▲. Bu usul tarozidagi kabi: bir xil narsalarni olib tashlaymiz.</p>",
 q:{t:"● + ▲ = 15, ● + ● + ▲ = 22. ▲ nechaga teng?",opts:["8","7","15","22"],ok:0,why:"Farq: ● = 22 − 15 = 7. ▲ = 15 − 7 = 8.",hint:"Avval ● ni toping: ikkinchi tenglikda nima ortiq?",full:"Ikkinchi tenglikda bitta ● ortiq, yig'indi 7 ga ortiq → ● = 7. Keyin 7 + ▲ = 15 → ▲ = 8. «7» — bu ●, ▲ emas."},
 tn:"Ikki tenglikni ustma-ust yozib, bir xil qismlarni qalam bilan o'chiring — qolgani farqni ko'rsatadi."},
{h:"Tokchalar jumbog'i",sum:"●●● = 12 → ● = 4; ●▲▲ = 20 → ▲ = 8; ▲■● = 17 → ■ = 5. Bitta xil shaklli qatordan boshlang.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Har tokchadagi shakllar yig'indisi berilgan. Hamma shaklni toping. Qaysi tokchadan boshlash kerakligini o'ylang:</p>",
 btns:[phaser(P3,'▶ Keyingi tokcha')],
 after:"<p>Strategiya: avval <b>faqat bitta xil</b> shakl bor qatorni toping, keyin topilganlarni qo'yib, har safar faqat bitta yangi noma'lum qoladigan qatorga o'ting.</p>",
 q:{t:"Shu jumboqda (● = 4, ▲ = 8, ■ = 5) 2-ustun (●, ▲, ■) yig'indisi nechaga teng?",opts:["17","16","15","20"],ok:0,why:"4 + 8 + 5 = 17.",hint:"2-ustunda yuqoridan pastga: ●, ▲, ■.",full:"2-ustun: ● (4) + ▲ (8) + ■ (5) = 17. «16» — 1- yoki 3-ustun (●, ●, ▲ yoki ●, ▲, ●)."},
 tn:"Doskada 3×3 jadval chizib, ustunlar yig'indisini ham yozing — bolalar tekshirish uchun foydalansin."},
{h:"Tarozida almashtirish",sum:"▲ + ▲ = ■ va ■ + ▲ = 12 → ■ o'rniga ▲▲: 3 ta ▲ = 12 → ▲ = 4, ■ = 8.",a:"m04",
 start:function(){j20Scale(['S','T'],['12']);j2Msg('■ = ▲ + ▲ ekani ma’lum. Tarozi muvozanatda: ■ + ▲ = 12. ▲ = ?')},
 fin:function(){j20Scale(['T','T','T'],['12']);j2Msg('✓ ▲▲▲ = 12 → ▲ = 4, ■ = 8')},
 html:"<p>Agar ■ ikki ▲ ga teng bo'lsa, tarozida ■ ni <b>ikkita ▲ bilan almashtirish</b> mumkin — muvozanat buzilmaydi. ▲ ni toping:</p>",
 g2:1,btns:j2Pick(["4","6","8","3"],0,function(){STEPS[3].fin()},function(i){j20Scale(['S','T'],['12']);j2Msg(['','▲ = 6 bo‘lsa ■ = 12, unda ■ + ▲ = 18 ≠ 12 ✗','8 — bu ■ ning qiymati, ▲ emas','3: ■ = 6, ■ + ▲ = 9 ≠ 12 ✗'][i])}),
 after:"<p>■ ni ▲▲ ga almashtirdik → pallada <b>3 ta ▲</b> = 12 → ▲ = 4, ■ = 8. Tekshirish: 8 + 4 = 12 ✓, 4 + 4 = 8 ✓. Almashtirish — eng kuchli usul.</p>",
 q:{t:"● = ▲ + ▲ + ▲ va ● + ▲ = 20. ● nechaga teng?",opts:["15","5","10","20"],ok:0,why:"● o'rniga ▲▲▲: 4 ta ▲ = 20 → ▲ = 5, ● = 15.",hint:"● ni uchta ▲ bilan almashtiring. Nechta ▲ bo'ldi?",full:"▲ + ▲ + ▲ + ▲ = 20 → ▲ = 5. ● = 3 · 5 = 15. Tekshirish: 15 + 5 = 20 ✓. «5» — bu ▲."},
 tn:"Haqiqiy tarozi (yoki chizg'ich va qalam) bilan: bitta katta kubik = 2 ta kichik kubik. Bolalar almashtirib ko'rsin."},
{h:"Tuzoq: bir xil shakllarni olib tashlash",sum:"■ + ■ + ▲ = 7 ta ▲ → ikkala tomondan ▲ olinsa: 2 ta ■ = 6 ta ▲ → ■ = ▲ + ▲ + ▲.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bu safar son yo'q — faqat shakllar orasidagi <b>bog'lanishni</b> topish kerak. Kuzating:</p>",
 btns:[phaser(P5,'▶ Keyingi')],
 after:"<p>Tenglikning ikki tomonidan bir xil narsani olsak yoki ikki tomonni bir xil songa bo'lsak — tenglik saqlanadi. Shu bilan murakkab ko'ringan rasm oddiy javobga keladi.</p>",
 q:{t:"■ + ▲ + ▲ = ▲ + ▲ + ▲ + ▲ + ▲. Qaysi tenglik to'g'ri?",opts:["■ = ▲ + ▲ + ▲","■ = ▲ + ▲","■ = ▲ + ▲ + ▲ + ▲ + ▲","■ = ▲"],ok:0,why:"Ikki tomondan ▲ + ▲ ni olsak: ■ = ▲ + ▲ + ▲.",hint:"Chap tomonda nechta ▲ bor? Ularni o'ng tomondan ham olib tashlang.",full:"Chapda ■ va 2 ta ▲, o'ngda 5 ta ▲. Ikkala tomondan 2 ta ▲ olib tashlasak: ■ = 3 ta ▲. «5 ta ▲» — chapdagi ▲ larni unutish."},
 tn:"Doskada shakllarni magnit/kartochka bilan qo'ying va ikki tomondan bir xillarini haqiqatan olib tashlang."},
{h:"Ko'paytma bilan jumboq",sum:"● × ● = 49 → ● = 7; ● + ▲ = 12 → ▲ = 5; ▲ × ■ = 30 → ■ = 6.",a:"m06",
 start:function(){j20Eqs([['C','×','C','=','49'],['C','+','T','=','12'],['T','×','S','=','30']]);j2Msg('Zanjir: har tenglik keyingisiga kalit beradi. ■ = ?')},
 fin:function(){j20Eqs([{t:['C','= 7'],c:C.ok},{t:['T','= 5'],c:C.ok},{t:['S','= 6'],c:C.ok}]);j2Msg('✓ ● = 7, ▲ = 5, ■ = 6')},
 html:"<p>Ko'paytirish jadvalini eslang: qaysi son o'ziga ko'paytirilsa 49 bo'ladi? So'ng zanjir bo'ylab boring. ■ ni tanlang:</p>",
 g2:1,btns:j2Pick(["6","5","7","25"],0,function(){STEPS[5].fin()},function(i){j2Msg(['','5 — bu ▲ (12 − 7). Endi ▲ × ■ = 30 dan ■ ni toping','7 — bu ●. Zanjir oxirigacha boring','25 — 30 − 5: ko‘paytmadan <b>bo‘lish</b> bilan topamiz'][i])}),
 after:"<p>● · ● = 49 → ● = 7 (7 · 7). 7 + ▲ = 12 → ▲ = 5. 5 · ■ = 30 → ■ = 30 : 5 = 6. Teskari amallar: yig'indidan — ayirish, ko'paytmadan — bo'lish.</p>",
 q:{t:"■ × ■ = 36, ■ + ● = 10, ● × ▲ = 12. ▲ nechaga teng?",opts:["3","4","6","8"],ok:0,why:"■ = 6, ● = 4, ▲ = 12 : 4 = 3.",hint:"Qaysi son o'ziga ko'paytirilsa 36?",full:"■ = 6 (6 · 6 = 36). ● = 10 − 6 = 4. ▲ = 12 : 4 = 3. «4» — bu ●, «8» — 12 − 4."},
 tn:"Ko'paytirish jadvali kvadratlari (4, 9, 16, 25, 36, 49, 64, 81) ni doskaga yozib qo'ying."},
{h:"Tuzoq: rasmga diqqat!",sum:"🍎·3 = 30, 🍎 + 2 dasta (4 tadan) = 18 → banan = 1; oxirgi dastada 3 ta banan → 3 + 10 = 13.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Internetda millionlab odam xato qilgan jumboq. Rasmdagi <b>har bir tafsilotga</b> e'tibor bering!</p>",
 btns:[phaser(P7,'▶ Keyingi')],
 after:"<p>Shakl-son jumboqlarida rasm o'zgarishi mumkin: dastadagi banan soni, shakl ichidagi nuqta, rang. Har qatorda shakllarni <b>yangidan sanang</b>.</p>",
 q:{t:"🍎 + 🍎 = 12. 🍎 + (3 banan dastasi) = 9. 🍎 + (2 banan dastasi) = ?",opts:["8","9","7","6"],ok:0,why:"🍎 = 6; 3 banan = 3 → 1 banan = 1; 6 + 2 = 8.",hint:"Avval bitta banan nechaga tengligini toping.",full:"🍎 = 6. 6 + dasta = 9 → 3 bananli dasta = 3 → 1 banan = 1. 2 bananli dasta = 2 → 6 + 2 = 8. «9» — dastani o'sha 3 deb olish."},
 tn:"Bolalarga o'zlari «tuzoqli» rasm-jumboq tuzishni topshiring: sinfdoshlari yechsin."},
{h:"Bilasizmi? Noma'lum — harf bilan",sum:"Noma'lumni harf bilan belgilashni XVI asrda Fransua Viet tizimli qo'llagan; x, y, z ni 1637-yilda Rene Dekart ishlatgan.",a:"m08",
 start:function(){j20Eqs([{t:['T','+','T','=','14']},{t:['x + x = 14'],c:C.blue},{t:['x = 7'],c:C.ok}])},fin:function(){STEPS[7].start()},
 html:"<p>✍️ Bugun biz shakl ishlatyapmiz, katta sinflarda esa <b>harf</b> ishlatamiz: ▲ + ▲ = 14 → x + x = 14. Noma'lum sonlarni harflar bilan belgilashni XVI asrda fransuz matematigi <b>Fransua Viet</b> tizimli qo'llay boshlagan, noma'lumlar uchun <b>x, y, z</b> harflarini esa 1637-yilda <b>Rene Dekart</b> ishlatgan.</p>",
 btns:[["Tushundim",function(c,done){j2Msg('▲ ■ ● — bu sizning birinchi tenglamalaringiz!');done()}]],
 after:"<p>Shakl jumbog'ini yechish — haqiqiy <b>tenglama yechish</b>: siz allaqachon algebrani boshladingiz.</p>",
 tn:"Bir xil masalani ham shakl, ham harf bilan yozib ko'rsating — bolalar farq yo'qligini ko'rsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){j20Eqs([['T','+','S','=','10'],['T','+','T','+','S','=','14']])},fin:function(){j20Eqs([['T','+','S','=','10'],['T','+','T','+','S','=','14']])},
 html:"<div class='memo'><ul><li>Bir xil shakl — <b>bir xil</b> son.</li><li>▲ + ▲ + ▲ = 18 → ▲ = 18 : 3.</li><li><b>Bitta xil</b> shaklli qatordan boshlang.</li><li>Ikki tenglikni solishtiring: farq — ortiqcha shakl.</li><li><b>Almashtiring</b>: ■ = ▲▲ bo'lsa, ■ o'rniga ▲▲ qo'ying.</li><li>Ikki tomondan bir xilini olib tashlash mumkin.</li><li>Rasmni har qatorda qayta sanang — tuzoq bo'lishi mumkin!</li><li>Oxirida barcha tengliklarga qo'yib <b>tekshiring</b>.</li></ul></div>",
 tn:"Keyingi dars: «● + ● + ▲ = 20, ● + ▲ + ▲ = 16» — ikkalasini qo'shish usulini ko'rsating (● = 8, ▲ = 4)."}
];
var PROBS=[
{t:"▲ + ▲ + ▲ = 18. ▲ nechaga teng?",o:["6","15","9","3"],k:0,s:"18 : 3 = 6."},
{t:"■ + ■ + ■ + ■ = 36. ■ nechaga teng?",o:["9","32","12","8"],k:0,s:"36 : 4 = 9."},
{t:"▲ + ■ = 10, ▲ + ▲ + ■ = 14. ▲ nechaga teng?",o:["4","6","10","2"],k:0,s:"Farq: ▲ = 14 − 10 = 4."},
{t:"▲ + ■ = 10, ▲ + ▲ + ■ = 14. ■ nechaga teng?",o:["6","4","5","10"],k:0,s:"▲ = 4, ■ = 10 − 4 = 6."},
{t:"● + ● + ● = 12, ● + ▲ + ▲ = 20. ▲ nechaga teng?",o:["8","10","4","16"],k:0,s:"● = 4; ▲ + ▲ = 16 → ▲ = 8."},
{t:"● + ● + ● = 12, ● + ▲ + ▲ = 20, ▲ + ■ + ● = 17. ■ nechaga teng?",o:["5","8","9","4"],k:0,s:"● = 4, ▲ = 8, ■ = 17 − 12 = 5."},
{t:"▲ + ▲ = ■, ■ + ▲ = 12. ▲ nechaga teng?",o:["4","6","8","3"],k:0,s:"■ o'rniga ▲▲: 3 ta ▲ = 12."},
{t:"▲ + ▲ = ■, ■ + ▲ = 12. ■ nechaga teng?",o:["8","4","6","12"],k:0,s:"▲ = 4, ■ = 8."},
{t:"■ + ■ + ▲ = ▲ + ▲ + ▲ + ▲ + ▲ + ▲ + ▲. Qaysi tenglik to'g'ri?",o:["▲ + ▲ + ▲ = ■","▲ + ▲ = ■","▲ + ▲ + ▲ + ▲ + ▲ + ▲ = ■","■ + ■ + ■ = ▲"],k:0,s:"Ikki tomondan ▲ olsak: 2 ta ■ = 6 ta ▲ → ■ = 3 ta ▲."},
{t:"● × ● = 49, ● + ▲ = 12. ▲ nechaga teng?",o:["5","7","6","12"],k:0,s:"● = 7, ▲ = 5."},
{t:"● × ● = 49, ● + ▲ = 12, ▲ × ■ = 30. ■ nechaga teng?",o:["6","5","7","25"],k:0,s:"● = 7, ▲ = 5, ■ = 30 : 5 = 6."},
{t:"▲ + ▲ = 14, ▲ − ■ = 3. ■ nechaga teng?",o:["4","10","11","7"],k:0,s:"▲ = 7, ■ = 7 − 3 = 4."},
{t:"■ : ▲ = 3, ■ + ▲ = 24. ▲ nechaga teng?",o:["6","8","18","3"],k:0,s:"■ = 3 ta ▲ → 4 ta ▲ = 24 → ▲ = 6."},
{t:"■ : ▲ = 3, ■ + ▲ = 24. ■ nechaga teng?",o:["18","6","21","8"],k:0,s:"▲ = 6, ■ = 18."},
{t:"■ + ■ + ■ = ▲ + ▲ va ▲ = 12. ■ nechaga teng?",o:["8","12","6","4"],k:0,s:"3 ta ■ = 24 → ■ = 8."},
{t:"🍎 + 🍎 + 🍎 = 30. 🍎 + (4 banan dastasi) + (4 banan dastasi) = 18. 🍎 + (3 banan dastasi) = ?",o:["13","14","11","12"],k:0,s:"🍎 = 10, 1 banan = 1, 3 banan = 3: 10 + 3 = 13."},
{t:"● + ● + ▲ = 20, ● + ▲ + ▲ = 16. ● nechaga teng?",o:["8","4","12","6"],k:0,s:"Qo'shsak: 3 ta ● + 3 ta ▲ = 36 → ● + ▲ = 12; ● = 20 − 12 = 8."},
{t:"▲ + ■ + ● = 20, ▲ + ■ = 13, ■ + ● = 15. ■ nechaga teng?",o:["8","7","5","13"],k:0,s:"● = 20 − 13 = 7, ▲ = 20 − 15 = 5, ■ = 13 − 5 = 8."},
{t:"Tarozida 3 ta olma 2 ta nok bilan muvozanatda. 1 ta nok 150 g. 1 ta olma necha gramm?",o:["100 g","150 g","75 g","225 g"],k:0,s:"2 · 150 = 300 g, 300 : 3 = 100 g."},
{t:"2 ta ● = 3 ta ▲, ▲ + ● = 25. ● nechaga teng?",o:["15","10","25","5"],k:0,s:"▲ = 10, ● = 15: 2 · 15 = 3 · 10 = 30, 10 + 15 = 25."}
];
function PRACT_STAGE(){j20Eqs([['T','+','S','=','10'],['T','+','T','+','S','=','14']])}
var PREP_DATA={teach:["Bir xil shakl — bir xil son; ▲·3 = 18.","Ikki tenglikni solishtirish (farq usuli).","Tokcha/jadval jumboqlari: bitta noma'lumli qatordan boshlash.","Almashtirish usuli (tarozi).","Ikki tomondan bir xilini olib tashlash.","Rasmdagi tuzoqlar."],
 mist:["▲+▲+▲ = 18 da 18 − 3 deb ayiradi.","Ikki noma'lumdan birini topib, ikkinchisi deb javob beradi.","Qatorni tasodifiy tanlab boshlaydi.","Rasmda shakl/miqdor o'zgarganini sezmaydi.","Tekshirmaydi."],
 need:["Kartondan ▲ ■ ● shakllar.","Tarozi yoki uning rasmi.","Doskada 3×3 jadval."],
 board:["<span class='w2'>▲+▲+▲ = 18 → ▲ = 6</span>.","<span class='w2'>▲+■ = 10, ▲+▲+■ = 14 → ▲ = 4, ■ = 6</span>.","<span class='w2'>●●● = 12 → ● = 4</span>.","<span class='w2'>■ = ▲▲, ■+▲ = 12 → ▲ = 4</span>.","<span class='w2'>■■▲ = 7▲ → ■ = 3▲</span>.","<span class='w2'>🍌🍌🍌 = 3!</span>"]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
