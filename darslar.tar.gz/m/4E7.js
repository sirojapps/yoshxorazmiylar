var CODE='4E7',TITLE='4-sinf · Yig‘indi va ayirmasiga ko‘ra ikki sonni topish';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
var STEPS=[
e4st({h:"Chizma: farqni olib tashlaymiz",sum:"32 kg un ikki qopda, 1-sida 6 kg ko‘p: 32 − 6 = 26, 26 : 2 = 13 (2-si), 13 + 6 = 19 (1-si).",a:"m01",
 frames:[{t:'32 kg unni ikki qopga solishdi. 1-qopda 2-sidan 6 kg ko‘p. Har qopda necha kg?',bars:[{lab:'1-qop',y:48,segs:[{w:13,txt:'?',c:'a'},{w:6,txt:'6',c:'c'}]},{lab:'2-qop',y:96,segs:[{w:13,txt:'?',c:'a'}]}],max:19,note:'Ikkala qop birga — 32 kg'},
  {t:'Ortiqcha 6 kg ni vaqtincha olib qo‘yamiz',bars:[{lab:'1-qop',y:48,segs:[{w:13,txt:'?',c:'a'},{w:6,txt:'6',c:'q'}]},{lab:'2-qop',y:96,segs:[{w:13,txt:'?',c:'a'}]}],max:19,calc:['32 − 6 = 26 — endi qoplar teng']},
  {t:'Ikkita teng bo‘lak — 26 kg',bars:[{lab:'1-qop',y:48,segs:[{w:13,txt:'13',c:'g'},{w:6,txt:'6',c:'c'}]},{lab:'2-qop',y:96,segs:[{w:13,txt:'13',c:'g'}]}],max:19,br:[{b:0,lab:'19 kg',up:true,col:C.ok}],calc:['1) 32 − 6 = 26','2) 26 : 2 = 13 kg (2-qop)','3) 13 + 6 = <b>19</b> kg (1-qop)']}],
 html:"<p>Ikki son: <b>yig'indisi</b> ham, <b>ayirmasi</b> ham ma'lum. Singapur chizma modeli bilan yechamiz. Tugmani bosing.</p>",
 after:"<p>G'oya: ortiqcha qismni olib tashlasak, ikkala son <b>tenglashadi</b>. Tekshiruv: 19 + 13 = 32 ✓, 19 − 13 = 6 ✓.</p>",
 q:{t:"Ikki savatda jami 50 ta olma. Birinchisida 8 ta ko'p. Kichik savatda nechta?",opts:["21","29","25","42"],ok:0,why:"(50 − 8) : 2 = 21.",hint:"Avval farqni olib tashlang.",full:"50 − 8 = 42; 42 : 2 = 21 (kichigi); 21 + 8 = 29 (kattasi). «25» — 50 : 2, farq hisobga olinmagan; «42» — bo'lish unutilgan."},
 tn:"Singapur bar modeli. Ikki qog'oz tasmani (biri uzunroq) doskaga yopishtiring; ortiqchasini qaychi bilan kesib ko'rsating."}),
e4st({h:"Ikki yo‘l: kichigidan yoki kattasidan",sum:"Yig‘indi 96, ayirma 28: kichigi (96 − 28) : 2 = 34; kattasi (96 + 28) : 2 = 62.",a:"m02",
 frames:[{t:'Ikki sonning yig‘indisi 96, ayirmasi 28.',bars:[{lab:'katta',y:48,segs:[{w:34,txt:'?',c:'a'},{w:28,txt:'28',c:'c'}]},{lab:'kichik',y:96,segs:[{w:34,txt:'?',c:'a'}]}],max:62,note:'1-usul: ortiqchani olib tashlash'},
  {t:'1-usul: kichigini topamiz',bars:[{lab:'katta',y:48,segs:[{w:34,txt:'34',c:'g'},{w:28,txt:'28',c:'c'}]},{lab:'kichik',y:96,segs:[{w:34,txt:'34',c:'g'}]}],max:62,calc:['Kichik = (96 − 28) : 2 = 68 : 2 = <b>34</b>','Katta = 34 + 28 = 62']},
  {t:'2-usul: yetishmaganini qo‘shamiz',bars:[{lab:'katta',y:48,segs:[{w:62,txt:'62',c:'g'}]},{lab:'kichik',y:96,segs:[{w:34,txt:'34',c:'a'},{w:28,txt:'+28',c:'q'}]}],max:62,calc:['Katta = (96 + 28) : 2 = 124 : 2 = <b>62</b>','Ikkala usul bir xil javob beradi']}],
 html:"<p>Kichik sonni ham, katta sonni ham <b>birinchi</b> topish mumkin. Ikkala yo'lni ko'ring.</p>",
 after:"<p>Qoida: <b>kichik = (yig'indi − ayirma) : 2</b>, <b>katta = (yig'indi + ayirma) : 2</b>. Ikkinchisini topgach, albatta tekshiring: 62 − 34 = 28 ✓.</p>",
 q:{t:"Ikki sonning yig'indisi 120, ayirmasi 40. Kattasi?",opts:["80","40","60","160"],ok:0,why:"(120 + 40) : 2 = 80.",hint:"Katta = (yig'indi + ayirma) : 2.",full:"(120 + 40) : 2 = 80; kichigi 40. Tekshiruv: 80 + 40 = 120, 80 − 40 = 40 ✓. «60» — 120 : 2; «160» — bo'linmagan."},
 tn:"Bank: 1796-id. Doskada ikkita formula; bolalar qaysi birini qachon ishlatish qulayligini aytsin."}),
e4st({h:"Tuzoq: «yarmiga qo‘shib qo‘ydim»",sum:"395 kg, 2-urinishda 9 kg ortiq: 1-si (395 − 9) : 2 = 193 kg.",a:"m03",
 frames:[{t:'Sportchi ikki urinishda jami 395 kg ko‘tardi. 2-urinishda 1-sidan 9 kg ortiq. 1-urinishda necha kg?',bars:[{lab:'1-urinish',y:48,segs:[{w:193,txt:'?',c:'a'}]},{lab:'2-urinish',y:96,segs:[{w:193,txt:'?',c:'a'},{w:9,txt:'9',c:'c'}]}],max:202,note:'Tanlang:'}],
 html:"<p>Qaysi javob to'g'ri? Chizmaga qarang.</p>",
 btns:e4pk(["202 kg","193 kg","197 kg"],1,{t:'1-urinish: (395 − 9) : 2',bars:[{lab:'1-urinish',y:48,segs:[{w:193,txt:'193',c:'g'}]},{lab:'2-urinish',y:96,segs:[{w:193,txt:'193',c:'g'},{w:9,txt:'9',c:'c'}]}],max:202,calc:['(395 − 9) : 2 = 386 : 2 = <b>193</b> kg','2-urinish: 193 + 9 = 202 kg']},["202 kg — bu 2-urinish (kattasi). Savol 1-urinishni so‘rayapti.","","197 ≈ 395 : 2 — farq hisobga olinmagan, keyin yaxlitlangan."]),
 after:"<p>Ikki xatoni eslab qoling: <b>savol qaysi sonni so'rayapti</b> — kichiginimi, kattasinimi? Va farqni <b>avval</b> olib tashlang, keyin bo'ling.</p>",
 q:{t:"Ikki sinfda jami 57 o'quvchi. 4-A da 4-B dan 5 ta kam. 4-A da nechta?",opts:["26","31","28","52"],ok:0,why:"(57 − 5) : 2 = 26.",hint:"Kim kam? 4-A — kichigi.",full:"4-A kichigi: (57 − 5) : 2 = 26; 4-B: 31. «31» — kattasi, «28» — 57 : 2 ni yaxlitlash."},
 tn:"Bank: 1795-id. Bolalarga savolni ikki marta o'qish va so'ralgan sonni chizmada doiraga olish odatini singdiring."}),
e4st({h:"Geometriyada ham: burchaklar va kesmalar",sum:"Yoyiq burchak 180°, AOC BOC dan 36° katta: BOC = (180 − 36) : 2 = 72°, AOC = 108°.",a:"m04",
 frames:[{t:'OC nur 180° li yoyiq burchakni bo‘ldi. ∠AOC ∠BOC dan 36° katta.',bars:[{lab:'AOC',y:48,segs:[{w:72,txt:'?',c:'b'},{w:36,txt:'36°',c:'c'}]},{lab:'BOC',y:96,segs:[{w:72,txt:'?',c:'b'}]}],max:108,note:'Yig‘indi 180°, ayirma 36°'},
  {t:'OC nur 180° li yoyiq burchakni bo‘ldi. ∠AOC ∠BOC dan 36° katta.',bars:[{lab:'AOC',y:48,segs:[{w:72,txt:'72°',c:'g'},{w:36,txt:'36°',c:'c'}]},{lab:'BOC',y:96,segs:[{w:72,txt:'72°',c:'g'}]}],max:108,calc:['BOC = (180 − 36) : 2 = <b>72°</b>','AOC = 72 + 36 = <b>108°</b>']}],
 html:"<p>Usul faqat sonlar uchun emas: burchaklar, kesmalar, pul, yosh — hammasida ishlaydi.</p>",
 after:"<p>Tekshiruv: 108° + 72° = 180° ✓. Kesmalarda ham xuddi shunday: AB = 72 sm, AC CB dan 14 sm uzun → CB = (72 − 14) : 2 = 29, AC = 43.</p>",
 q:{t:"72 sm kesma ikki bo'lakka bo'lindi; AC bo'lak CB dan 14 sm uzun. AC necha sm?",opts:["43 sm","29 sm","36 sm","58 sm"],ok:0,why:"(72 + 14) : 2 = 43.",hint:"AC — kattasi.",full:"AC = (72 + 14) : 2 = 43 sm, CB = 29 sm. «29» — kichigi, «36» — 72 : 2, «58» — 72 − 14."},
 tn:"Bank: 1797, 1798-idlar. Transportir bilan yoyiq burchakni chizib, nurni bolalar o'zi o'tkazsin."}),
e4st({h:"Tuzoq: «bersa teng bo‘ladi»",sum:"Ali Valiga 4 ta bersa teng: farq 8 (4 emas!). 46 ta: Vali (46 − 8) : 2 = 19, Ali 27.",a:"m05",
 frames:[{t:'Ali va Valida jami 46 ta yong‘oq. Ali Valiga 4 ta bersa, ikkalasida teng bo‘ladi. Alida nechta?',bars:[{lab:'Ali',y:48,segs:[{w:19,txt:'?',c:'a'},{w:4,txt:'4',c:'c'},{w:4,txt:'4',c:'c'}]},{lab:'Vali',y:96,segs:[{w:19,txt:'?',c:'a'}]}],max:27,note:'Farq qancha? Tanlang:'}],
 html:"<p>Bu yerda ayirma <b>yashiringan</b>. Ehtiyot bo'ling:</p>",
 btns:e4pk(["Ali 25, Vali 21","Ali 27, Vali 19","Ali 23, Vali 23"],1,{t:'Ali 4 tani bersa: Alida 4 ta kamayadi, Valida 4 ta ko‘payadi',bars:[{lab:'Ali',y:48,segs:[{w:19,txt:'19',c:'g'},{w:4,txt:'4',c:'c'},{w:4,txt:'→ Vali',c:'q',fs:10}]},{lab:'Vali',y:96,segs:[{w:19,txt:'19',c:'g'},{w:4,txt:'+4',c:'y'}]}],max:27,calc:['Farq: 4 + 4 = 8','Vali: (46 − 8) : 2 = 19,  Ali: 19 + 8 = <b>27</b>','Tekshiruv: 27 − 4 = 23, 19 + 4 = 23 ✓']},["25 va 21 ning farqi 4. Ali 4 ta bersa: 21 va 25 — teng emas!","","23 va 23 — bu berib bo‘lgandan KEYINGI holat."]),
 after:"<p>Qoida: «a ta bersa teng bo'ladi» → farq <b>2 · a</b>. Chunki biridan kamayadi, ikkinchisiga qo'shiladi.</p>",
 q:{t:"Ikki javonda 70 ta kitob. 1-javondan 2-siga 5 ta qo'yilsa, kitoblar teng bo'ladi. 1-javonda nechta kitob bor?",opts:["40","35","30","37"],ok:0,why:"Farq 10; (70 + 10) : 2 = 40.",hint:"Farq 5 emas.",full:"Farq: 5 · 2 = 10. Katta: (70 + 10) : 2 = 40, kichik: 30. Tekshiruv: 40 − 5 = 35, 30 + 5 = 35 ✓. «37» — farqni 5 deb olib, 37,5 ni yaxlitlash; «35» — ko'chirishdan keyingi holat."},
 tn:"Kubiklar bilan sahnalashtiring: ikki bola, birida 8 ta ortiq. 4 tasini bersa — teng. Bolalar o'zi ko'rsin."}),
e4st({h:"Uch kishi: juft yig‘indilar",sum:"J+K = 52, K+L = 45, L+J = 37. Hammasi ikki marta: 134, bitta marta 67. L = 67 − 52 = 15.",a:"m06",
 frames:[{t:'Jamshid + Kamol = 52 kg, Kamol + Laziz = 45 kg, Laziz + Jamshid = 37 kg.',bars:[{lab:'J + K',y:36,segs:[{w:22,txt:'J',c:'a'},{w:30,txt:'K',c:'b'}]},{lab:'K + L',y:76,segs:[{w:30,txt:'K',c:'b'},{w:15,txt:'L',c:'g'}]},{lab:'L + J',y:116,segs:[{w:15,txt:'L',c:'g'},{w:22,txt:'J',c:'a'}]}],max:60,gap:40,note:'Har kim chizmada necha marta bor?'},
  {t:'Uchala qatorni qo‘shamiz',bars:[{lab:'J + K',y:36,segs:[{w:22,txt:'J',c:'a'},{w:30,txt:'K',c:'b'}]},{lab:'K + L',y:76,segs:[{w:30,txt:'K',c:'b'},{w:15,txt:'L',c:'g'}]},{lab:'L + J',y:116,segs:[{w:15,txt:'L',c:'g'},{w:22,txt:'J',c:'a'}]}],max:60,gap:40,calc:['52 + 45 + 37 = 134 — har kim 2 marta','J + K + L = 134 : 2 = 67']},
  {t:'Endi har birini topamiz',bars:[{lab:'J + K',y:36,segs:[{w:22,txt:'22',c:'a'},{w:30,txt:'30',c:'b'}]},{lab:'K + L',y:76,segs:[{w:30,txt:'30',c:'b'},{w:15,txt:'15',c:'g'}]},{lab:'L + J',y:116,segs:[{w:15,txt:'15',c:'g'},{w:22,txt:'22',c:'a'}]}],max:60,gap:40,calc:['L = 67 − 52 = <b>15</b>,  J = 67 − 45 = <b>22</b>,  K = 67 − 37 = <b>30</b>']}],
 html:"<p>Olimpiada masalasi: uch kishining <b>juft-juft</b> yig'indilari ma'lum. Tugmani bosing.</p>",
 after:"<p>Hiyla: hammasini qo'shsak, har kim <b>ikki marta</b> sanaladi. Uchchalasining yig'indisini topib, har bir juftni undan ayiramiz. Tekshiruv: 22 + 30 = 52 ✓.</p>",
 q:{t:"A + B = 30, B + C = 40, A + C = 50. B nechaga teng?",opts:["10","20","30","60"],ok:0,why:"Jami (30 + 40 + 50) : 2 = 60; B = 60 − 50 = 10.",hint:"Uchchalasining yig'indisini toping.",full:"30 + 40 + 50 = 120; A + B + C = 60. B = 60 − (A + C) = 60 − 50 = 10. A = 20, C = 30. «60» — uchchalasining yig'indisi."},
 tn:"Bank: 1799-id. Uch rangli tasmalar bilan chizmani sinfda yig'ing."}),
e4st({h:"Uch son va ikki farq",sum:"99 ta olma 3 qutida: 2-si 1-sidan 8 ta, 3-si 2-sidan 5 ta ko‘p. Ortiqcha: 8 + 13 = 21; (99 − 21) : 3 = 26.",a:"m07",
 frames:[{t:'3 qutida 99 ta olma. 2-qutida 1-sidan 8 ta, 3-qutida 2-sidan 5 ta ko‘p.',bars:[{lab:'1-quti',y:36,segs:[{w:26,txt:'?',c:'a'}]},{lab:'2-quti',y:76,segs:[{w:26,txt:'?',c:'a'},{w:8,txt:'8',c:'c'}]},{lab:'3-quti',y:116,segs:[{w:26,txt:'?',c:'a'},{w:8,txt:'8',c:'c'},{w:5,txt:'5',c:'b'}]}],max:39,gap:40,note:'Barcha ortiqchani olib tashlaymiz'},
  {t:'Ortiqchalar: 8 + 8 + 5 = 21',bars:[{lab:'1-quti',y:36,segs:[{w:26,txt:'26',c:'g'}]},{lab:'2-quti',y:76,segs:[{w:26,txt:'26',c:'g'},{w:8,txt:'8',c:'c'}]},{lab:'3-quti',y:116,segs:[{w:26,txt:'26',c:'g'},{w:8,txt:'8',c:'c'},{w:5,txt:'5',c:'b'}]}],max:39,gap:40,calc:['1) 8 + (8 + 5) = 21','2) (99 − 21) : 3 = <b>26</b>;  34;  39']}],
 html:"<p>Uchta son bo'lsa ham usul o'sha: <b>kichik</b> songa teng bo'lmagan barcha bo'laklarni olib tashlaymiz.</p>",
 after:"<p>Diqqat: 3-quti 1-sidan 8 + 5 = <b>13</b> ta ko'p (5 emas). Tekshiruv: 26 + 34 + 39 = 99 ✓.</p>",
 q:{t:"Uch sonning yig'indisi 75. Ikkinchisi birinchisidan 6 ga, uchinchisi ikkinchisidan 6 ga katta. Eng kattasi?",opts:["31","25","19","37"],ok:0,why:"Ortiqcha 6 + 12 = 18; (75 − 18) : 3 = 19; 25; 31.",hint:"3-son 1-sidan 12 ga katta.",full:"Ortiqchalar: 6 va 12, jami 18. 1-son: (75 − 18) : 3 = 19, 2-si 25, 3-si 31. «25» — o'rtadagi, «19» — eng kichigi."},
 tn:"Chizmada farqlarni har xil rangda bo'yang — bolalar 13 ni 5 deb olmasligi uchun."}),
e4st({h:"Bilasizmi? Al-Xorazmiyning masalalari",sum:"Al-Xorazmiy (IX asr) «al-jabr» kitobidagi ko‘p masalalarni «O‘nni ikki qismga bo‘ldim…» deb boshlagan.",a:"m08",
 frames:[{t:'«O‘nni ikki qismga bo‘ldim…»',bars:[{lab:'10',y:80,segs:[{w:6,txt:'1-qism',c:'a'},{w:4,txt:'2-qism',c:'b'}]}],max:10,note:'Yig‘indisi ma’lum — 10'}],
 html:"<p>📜 Buyuk vatandoshimiz <b>Muhammad al-Xorazmiy</b> (IX asr) o'zining mashhur «al-jabr va al-muqobala» kitobida ko'plab masalalarni «<b>O'nni ikki qismga bo'ldim…</b>» deb boshlagan. Ya'ni ikki sonning <b>yig'indisi</b> ma'lum, boshqa shart bo'yicha har birini topish kerak. «Algebra» so'zi shu kitob nomidan kelib chiqqan.</p>",
 after:"<p>Siz bugun yechgan masalalar — algebraning eng birinchi qadamlari. Platformamiz nomi ham — «Yosh Xorazmiylar»!</p>",
 tn:"Sinfga topishmoq: «O'nni ikki qismga bo'ldim, biri ikkinchisidan 4 ga katta» — javob 7 va 3."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Yig‘indi va ayirma',bars:[{lab:'katta',y:48,segs:[{w:20,txt:'kichik',c:'a'},{w:10,txt:'ayirma',c:'c'}]},{lab:'kichik',y:96,segs:[{w:20,txt:'kichik',c:'a'}]}],max:30})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Kichik = (yig'indi − ayirma) : 2.</b></li><li><b>Katta = (yig'indi + ayirma) : 2.</b></li><li>Avval <b>chizma</b> chizing: ortiqcha qismni belgilang.</li><li>Savol <b>qaysi</b> sonni so'rayapti — tekshiring.</li><li>«a ta bersa teng bo'ladi» → ayirma <b>2 · a</b>.</li><li>Juft yig'indilar: hammasini qo'shib, 2 ga bo'ling.</li><li>Doim tekshiring: yig'indi ham, ayirma ham to'g'ri chiqsin.</li></ul></div>",
 tn:"Keyingi dars — «yig'indi va karrali nisbat»: chizmada bo'laklar teng bo'ladi."}
];
var PROBS=[
{t:"32 kg un ikki qopda; 1-qopda 6 kg ko'p. 1-qopda necha kg?",o:["19 kg","13 kg","16 kg","26 kg"],k:0,s:"(32 + 6) : 2 = 19."},
{t:"Ikki savatda 50 ta olma; birinchisida 8 ta ko'p. Kichik savatda nechta?",o:["21","29","25","42"],k:0,s:"(50 − 8) : 2 = 21."},
{t:"Ikki sonning yig'indisi 96, ayirmasi 28. Kattasi?",o:["62","34","68","48"],k:0,s:"(96 + 28) : 2 = 62."},
{t:"Ikki sonning yig'indisi 120, ayirmasi 40. Kichigi?",o:["40","80","60","20"],k:0,s:"(120 − 40) : 2 = 40."},
{t:"Sportchi 2 urinishda 395 kg ko'tardi, 2-sida 9 kg ortiq. 1-urinishda necha kg?",o:["193","202","197","186"],k:0,s:"(395 − 9) : 2 = 193."},
{t:"Ikki sinfda 57 o'quvchi; 4-A da 4-B dan 5 ta kam. 4-A da nechta?",o:["26","31","28","52"],k:0,s:"(57 − 5) : 2 = 26."},
{t:"180° li burchak ikki burchakka bo'lindi; biri ikkinchisidan 36° katta. Kattasi?",o:["108°","72°","144°","90°"],k:0,s:"(180 + 36) : 2 = 108."},
{t:"72 sm kesma ikki bo'lakka bo'lindi, AC CB dan 14 sm uzun. AC?",o:["43 sm","29 sm","36 sm","58 sm"],k:0,s:"(72 + 14) : 2 = 43."},
{t:"Ota va o'g'il yoshlari yig'indisi 48, ota o'g'ildan 26 yosh katta. O'g'il necha yoshda?",o:["11","37","22","24"],k:0,s:"(48 − 26) : 2 = 11."},
{t:"To'g'ri to'rtburchakning perimetri 60 sm, bo'yi enidan 8 sm uzun. Eni?",o:["11 sm","26 sm","19 sm","15 sm"],k:0,s:"Yarim perimetr 30; (30 − 8) : 2 = 11."},
{t:"Ali va Valida 46 ta yong'oq. Ali Valiga 4 ta bersa, teng bo'ladi. Alida nechta?",o:["27","25","23","19"],k:0,s:"Farq 8; (46 + 8) : 2 = 27."},
{t:"Ikki javonda 70 ta kitob. 1-dan 2-siga 5 ta qo'yilsa teng bo'ladi. 1-javonda nechta?",o:["40","35","30","37"],k:0,s:"Farq 10; (70 + 10) : 2 = 40."},
{t:"J + K = 52, K + L = 45, L + J = 37. L = ?",o:["15","7","22","30"],k:0,s:"Jami 67; 67 − 52 = 15."},
{t:"A + B = 30, B + C = 40, A + C = 50. B = ?",o:["10","20","30","60"],k:0,s:"Jami 60; 60 − 50 = 10."},
{t:"3 qutida 99 ta olma; 2-sida 1-sidan 8 ta, 3-sida 2-sidan 5 ta ko'p. 3-qutida nechta?",o:["39","34","26","31"],k:0,s:"(99 − 21) : 3 = 26; 26 + 13 = 39."},
{t:"Uch sonning yig'indisi 75; har biri oldingisidan 6 ga katta. Eng kattasi?",o:["31","25","19","37"],k:0,s:"(75 − 18) : 3 = 19; 31."},
{t:"Ikki sonning yig'indisi 594. Kattasi kichigidan 486 ga katta. Kichigi?",o:["54","540","108","243"],k:0,s:"(594 − 486) : 2 = 54."},
{t:"Ikki qizning puli jami 25 000 so'm. Biri 3 000 so'm sarflasa, ikkalasida teng bo'ladi. Ko'prog'ida qancha bor?",o:["14 000","11 000","12 500","15 500"],k:0,s:"Farq 3 000; (25 000 + 3 000) : 2 = 14 000."},
{t:"Ikki son yig'indisi 100. Biridan 10 ni olib, ikkinchisiga qo'shsak, ular teng bo'ladi. Kattasi?",o:["60","55","50","40"],k:0,s:"Farq 20; (100 + 20) : 2 = 60."},
{t:"Akam va mening yoshim jami 30. 4 yildan keyin akam mendan 6 yosh katta bo'ladi. Men hozir necha yoshdaman?",o:["12","18","14","16"],k:0,s:"Yoshlar farqi doim 6; (30 − 6) : 2 = 12."}
];
function PRACT_STAGE(){bmDraw({t:'Chizma chizing: katta, kichik, ayirma',bars:[{lab:'katta',y:48,segs:[{w:20,txt:'?',c:'a'},{w:10,txt:'ayirma',c:'c'}]},{lab:'kichik',y:96,segs:[{w:20,txt:'?',c:'a'}]}],max:30})}
var PREP_DATA={teach:["Yig'indi va ayirmasiga ko'ra ikki sonni chizma model bilan topish.","Ikki formula: kichik = (S − A) : 2, katta = (S + A) : 2.","Yashirin ayirma («a ta bersa teng bo'ladi» → 2a), geometrik va yosh masalalari.","Uch son: juft yig'indilar va ikki farq."],
 mist:["Yig'indini 2 ga bo'lib, ayirmani qo'shadi (S : 2 + A).","Savol kattasini so'rasa kichigini javob qiladi.","«4 ta bersa teng» da farqni 4 deb oladi.","Uch sonda 3-sonning 1-sidan farqini noto'g'ri oladi."],
 need:["Rangli qog'oz tasmalar va qaychi.","Kubiklar (yong'oq/olma o'rniga).","Transportir (burchak masalasi uchun)."],
 board:["<span class='w2'>(32 − 6) : 2 = 13</span>; <span class='w2'>13 + 6 = 19</span>.","<span class='w2'>(96 + 28) : 2 = 62</span>.","«4 ta bersa teng» → <span class='w2'>ayirma 8</span>.","<span class='w2'>(52 + 45 + 37) : 2 = 67</span>.","<span class='w2'>(99 − 8 − 13) : 3 = 26</span>."]};
