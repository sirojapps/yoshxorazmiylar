var CODE='2F7',TITLE='2-sinf · Katakli qog‘ozda shakllar';
// ---------- katakli qog'oz ----------
var KQ={x0:20,y0:12,cs:16,cols:20,rows:9};
function kqPaper(o){o=o||{};clear('#ffffff');var g=S.g,K=KQ;S.kq={};
 for(var c=0;c<=K.cols;c++)E('line',{x1:K.x0+c*K.cs,y1:K.y0,x2:K.x0+c*K.cs,y2:K.y0+K.rows*K.cs,stroke:'#cfe0f2','stroke-width':1},g);
 for(var r=0;r<=K.rows;r++)E('line',{x1:K.x0,y1:K.y0+r*K.cs,x2:K.x0+K.cols*K.cs,y2:K.y0+r*K.cs,stroke:'#cfe0f2','stroke-width':1},g);
 if(o.tap){for(var r2=0;r2<K.rows;r2++)for(var c2=0;c2<K.cols;c2++)(function(r,c){var e=E('rect',{x:K.x0+c*K.cs,y:K.y0+r*K.cs,width:K.cs,height:K.cs,fill:'transparent',style:'cursor:pointer'},g);e.addEventListener('click',function(){o.tap(r,c,e)})})(r2,c2)}}
function kqCell(r,c,col,num){var K=KQ;var e=E('rect',{x:K.x0+c*K.cs+1,y:K.y0+r*K.cs+1,width:K.cs-2,height:K.cs-2,rx:2,fill:col||C.a,'pointer-events':'none'},S.g);S.kq[r+','+c]=e;
 if(num!=null)T(S.g,K.x0+c*K.cs+K.cs/2,K.y0+r*K.cs+12,String(num),{'font-size':10,'font-weight':800,fill:'#fff','pointer-events':'none'});return e}
function kqCells(list,col,nums){list.forEach(function(p,i){kqCell(p[0],p[1],col,nums?i+1:null)})}
function kqLine(pts,col,w){var K=KQ,d='';pts.forEach(function(p,i){d+=(i?'L':'M')+(K.x0+p[1]*K.cs)+' '+(K.y0+p[0]*K.cs)});E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':w||3,'stroke-linejoin':'round','stroke-linecap':'round'},S.g)}
function kqDot(r,c,col){var K=KQ;E('circle',{cx:K.x0+c*K.cs,cy:K.y0+r*K.cs,r:5,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
function kqMsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function kqRect(r0,c0,h,w){var l=[];for(var r=0;r<h;r++)for(var c=0;c<w;c++)l.push([r0+r,c0+c]);return l}
// L-shakl va boshqa namunalar
var KQ_L=[[2,3],[3,3],[4,3],[5,3],[5,4],[5,5],[4,5],[2,4]];
// robot yo'li: 3 o'ngga, 2 pastga, 3 chapga, 2 yuqoriga
var P2=[function(){kqPaper();kqDot(2,4);kqMsg('Robot qizil nuqtada. Buyruqlar: <b>3 o‘ngga → 2 pastga → 3 chapga → 2 yuqoriga</b>')},
 function(){kqPaper();kqLine([[2,4],[2,7]]);kqDot(2,4);kqMsg('1) <b>3 katak o‘ngga</b>')},
 function(){kqPaper();kqLine([[2,4],[2,7],[4,7]]);kqDot(2,4);kqMsg('2) <b>2 katak pastga</b>')},
 function(){kqPaper();kqLine([[2,4],[2,7],[4,7],[4,4]]);kqDot(2,4);kqMsg('3) <b>3 katak chapga</b>')},
 function(){kqPaper();kqCells(kqRect(2,4,2,3),'#bfe0ff');kqLine([[2,4],[2,7],[4,7],[4,4],[2,4]]);kqDot(2,4);kqMsg('4) <b>2 katak yuqoriga</b> — boshlangan joyga qaytdi. To‘g‘ri to‘rtburchak: ichida <b>3 · 2 = 6</b> katak')}];
var P3=[function(){kqPaper();kqCells(KQ_L,C.a);kqMsg('Shaklda nechta katak bor? Bittalab sanaymiz')},
 function(){kqPaper();kqCells(KQ_L,C.a,true);kqMsg('Har katakka raqam qo‘yib chiqdik: <b>8 ta</b> katak. Hech biri ikki marta sanalmadi')}];
var P4=[function(){kqPaper();kqCells([[2,8],[3,8],[3,9],[4,9],[4,10]],C.a);E('rect',{x:KQ.x0+8*KQ.cs,y:KQ.y0+2*KQ.cs,width:3*KQ.cs,height:3*KQ.cs,fill:'none',stroke:C.blue,'stroke-width':2,'stroke-dasharray':'5 4'},S.g);kqMsg('Shakl 5 katak. 3 × 3 kvadrat bo‘lishi uchun nechta katak qo‘shish kerak?')},
 function(){kqPaper();kqCells([[2,8],[3,8],[3,9],[4,9],[4,10]],C.a);kqCells([[2,9],[2,10],[3,10],[4,8]],'#9fd9a8');E('rect',{x:KQ.x0+8*KQ.cs,y:KQ.y0+2*KQ.cs,width:3*KQ.cs,height:3*KQ.cs,fill:'none',stroke:C.blue,'stroke-width':2},S.g);kqMsg('Butun kvadrat: 3 · 3 = <b>9</b> katak. Bor: 5 ta. Kerak: 9 − 5 = <b>4</b> ta (yashil)')}];
var P6=[function(){kqPaper();kqCells(kqRect(3,6,1,4),C.a);kqMsg('Tasma: bo‘yi 4 katak, eni 1 katak. Har katak tomoni 1 sm. Perimetri?')},
 function(){kqPaper();kqCells(kqRect(3,6,1,4),C.a);kqLine([[3,6],[3,10]],C.bad,3);kqLine([[4,6],[4,10]],C.bad,3);kqMsg('Tepa va past: 4 + 4 = 8 sm')},
 function(){kqPaper();kqCells(kqRect(3,6,1,4),C.a);kqLine([[3,6],[3,10],[4,10],[4,6],[3,6]],C.bad,3);kqMsg('Yon tomonlar: 1 + 1 = 2 sm. Perimetr: 8 + 2 = <b>10 sm</b> (kataklar soni 4 emas!)')}];
var P7=[function(){kqPaper();var b=kqRect(2,6,3,4);b.forEach(function(p,i){kqCell(p[0],p[1],[0,1,2,4,5,8,9].indexOf(i)>=0?C.a:'#d5e2ef')});E('rect',{x:KQ.x0+6*KQ.cs,y:KQ.y0+2*KQ.cs,width:4*KQ.cs,height:3*KQ.cs,fill:'none',stroke:C.blue,'stroke-width':2},S.g);kqMsg('3 × 4 to‘rtburchakda bo‘yalgan kataklar bo‘yalmaganlardan nechta ko‘p?')},
 function(){kqPaper();var b=kqRect(2,6,3,4),n1=0,n2=0;b.forEach(function(p,i){var on=[0,1,2,4,5,8,9].indexOf(i)>=0;kqCell(p[0],p[1],on?C.a:'#d5e2ef',on?++n1:null)});kqMsg('Bo‘yalgan: <b>7</b>. Hammasi: 3 · 4 = 12. Bo‘yalmagan: 12 − 7 = <b>5</b>')},
 function(){kqPaper();var b=kqRect(2,6,3,4);b.forEach(function(p,i){kqCell(p[0],p[1],[0,1,2,4,5,8,9].indexOf(i)>=0?C.a:'#d5e2ef')});kqMsg('Farq: 7 − 5 = <b>2</b>. Diqqat: savol «nechta ko‘p?» — javob 7 ham, 5 ham emas')}];
var STEPS=[
{h:"Katakli qog'oz",sum:"Katakli qog'ozda har bir katak — bir xil kichik kvadrat. Shakllarni kataklar bo'yicha chizamiz va sanaymiz.",a:"m01",
 start:function(){S.n7=0;kqPaper({tap:function(r,c){if(S.kq[r+','+c])return;kqCell(r,c,C.a,++S.n7);kqMsg('Bo‘yaldi: <b>'+S.n7+'</b> ta katak'+(S.n7>=6?' — yaxshi!':''));if(S.n7===6&&S.d7)S.d7()}});kqMsg('Istalgan 6 ta katakni bosib bo‘yang')},
 fin:function(){kqPaper();kqCells(kqRect(3,8,2,3),C.a,true);kqMsg('6 ta katak')},
 html:"<p>Daftaringizdagi katakli qog'ozga qarang: u bir xil <b>kichik kvadratlar</b> — kataklardan iborat. Matematika daftarida har bir katakning tomoni <b>5 mm</b>, bizning rasmda esa uni <b>1 sm</b> deb olamiz. Tepadagi qog'ozda <b>6 ta katakni</b> bosib bo'yang.</p>",
 act:function(c,done){S.d7=function(){S.d7=null;done()};c.querySelector('.hint').textContent='Rasmdagi kataklarni bosing.'},
 after:"<p>Katakli qog'ozda shakl chizish oson: chiziqlar kataklar chegarasi bo'ylab yuradi, kataklarni esa <b>sanash</b> mumkin. Shuning uchun bu yerda shaklning qanchalik kattaligini aniq aytsa bo'ladi.</p>",
 q:{t:"Katakli qog'ozda bo'yi 3 katak, eni 2 katak bo'lgan to'g'ri to'rtburchak chizildi. Uning ichida nechta katak bor?",opts:["5","10","6","12"],ok:2,why:"2 qator, har birida 3 tadan: 6 ta.",hint:"Qatorlarni sanang: nechta qator, har qatorda nechta katak?",full:"Bo'yi 3, eni 2: 2 ta qator, har qatorda 3 ta katak — 3 + 3 = 6. «5» — tomonlarni qo'shib yuborish (3 + 2), «10» — perimetr."},
 tn:"Bolalarga katakli varaq bering. «Menga 6 katakli shakl chizing» deng — har xil shakllar chiqadi, hammasini doskada solishtiring."},
{h:"Ko'rsatma bo'yicha chizamiz",sum:"Buyruqlar: «3 o'ngga, 2 pastga, 3 chapga, 2 yuqoriga» — to'g'ri to'rtburchak, ichida 6 katak.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=4;P2[4]()},
 html:"<p>Robot katakli qog'ozda chiziq tortib yuradi. Unga buyruq beramiz va har qadamni kuzatamiz.</p>",
 btns:[phaser(P2,'▶ Keyingi buyruq')],
 after:"<p>Robot boshlagan nuqtasiga qaytdi — shakl <b>yopildi</b>. O'ngga 3 va chapga 3, pastga 2 va yuqoriga 2 — teng bo'lgani uchun qaytib keldi.</p>",
 q:{t:"Robot 3 katak o'ngga, 3 pastga, 3 chapga va 3 yuqoriga yurdi. Chizilgan shakl ichida nechta katak bor?",opts:["12","9","6","16"],ok:1,why:"Tomoni 3 katakli kvadrat: 3 · 3 = 9.",hint:"Qanday shakl chiqdi? Tomonlari teng-mi? Ichini qatorlab sanang.",full:"Hamma tomon 3 katak — bu kvadrat. 3 qator × 3 katak = 9. «12» — robot yurgan yo'l uzunligi (3 + 3 + 3 + 3), ya'ni perimetr, ichidagi kataklar emas."},
 tn:"«Grafik diktant»: o'qituvchi buyruq aytadi (2 o'ngga, 1 pastga…), bolalar daftarga chizadi. Oxirida hammaning shakli bir xil chiqishi kerak."},
{h:"Kataklarni xatosiz sanash",sum:"Har katakka raqam qo'yib sanaymiz — hech biri tushib qolmaydi, ikki marta ham sanalmaydi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Shakl murakkab bo'lsa, kataklarni sanashda adashish oson. Usul: <b>har katakka raqam qo'yib</b> chiqamiz.</p>",
 btns:[phaser(P3,'▶ Raqam qo‘yib sanash')],
 after:"<p>Qator-qator yoki ustun-ustun sanang va har katakni belgilang. Shunda birorta katak ham tushib qolmaydi va ikki marta sanalmaydi.</p>",
 q:{t:"Shakl 2 ta qatordan iborat: tepada 5 ta katak, pastda 3 ta katak. Hammasi nechta?",opts:["8","15","7","10"],ok:0,why:"5 + 3 = 8 katak.",hint:"Har qatordagi kataklarni qo'shing.",full:"Tepada 5 ta, pastda 3 ta: 5 + 3 = 8. «15» — 5 · 3 ko'paytirish, lekin qatorlar teng emas, ko'paytirib bo'lmaydi."},
 tn:"Bolalar sanagan kataklarini qalam bilan nuqta qo'yib belgilashsin — bu ko'p xatoning oldini oladi."},
{h:"Shaklni to'ldiramiz",sum:"3 × 3 kvadrat uchun 9 katak kerak. Bor 5 ta bo'lsa, yana 9 − 5 = 4 ta qo'shamiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Shaklni kattaroq shaklgacha to'ldirish kerak bo'lsa, avval <b>butun shakl</b>da nechta katak borligini topamiz, keyin borini ayiramiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Usul: <b>kerak − bor = qo'shiladi</b>. 3 × 3 kvadratda 9 katak, bizda 5 ta, demak 4 ta qo'shamiz. Bo'sh kataklarni bittalab sanab ham tekshirsa bo'ladi.</p>",
 q:{t:"Shaklda 7 ta katak bor. Uni 3 × 4 to'g'ri to'rtburchakka aylantirish uchun yana nechta katak kerak?",opts:["12","7","5","4"],ok:2,why:"3 · 4 = 12 katak kerak, 7 ta bor: 12 − 7 = 5.",hint:"Avval 3 × 4 to'rtburchakda nechta katak borligini toping.",full:"To'liq to'rtburchak: 3 · 4 = 12 katak. Bor: 7. Kerak: 12 − 7 = 5. «12» — bu butun to'rtburchak, «7» — bor kataklar."},
 tn:"Bolalarga chala shakl chizib bering va «to'ldiring» deng. Avval taxmin qilib, keyin sanab tekshirishsin."},
{h:"Shaklni nusxalaymiz",sum:"Nusxa ko'chirishda har bir katakning qaysi qator va ustunda turganiga qaraymiz.",a:"m05",
 start:function(){kq5()},fin:function(){kq5(true)},
 html:"<p>Chapda namuna shakl. Uni o'ng tomonga <b>xuddi shunday</b> ko'chiring: o'ngdagi kataklarni bosing. Namunaning har bir katagi qayerda turganiga qarang.</p>",
 act:function(c,done){S.d5=function(){S.d5=null;done()};c.querySelector('.hint').textContent='O‘ng tomondagi kataklarni bosib, namunani takrorlang.'},
 after:"<p>Nusxa ko'chirishda <b>bir burchakdan</b> boshlab, «nechta o'ngga, nechta pastga» deb sanash qulay. Bu — keyinchalik koordinatalar bilan ishlashning asosi.</p>",
 q:{t:"Namunada kataklar shunday joylashgan: tepada 2 ta yonma-yon, ostida faqat chapdagisi ostida 1 ta. Nusxada nechta katak bo'ladi?",opts:["2","3","4","6"],ok:1,why:"Nusxa namunadagidek: 2 + 1 = 3 katak.",hint:"Nusxa — xuddi o'sha shakl. Namunada nechta katak bor?",full:"Tepada 2 ta, pastda 1 ta — jami 3 ta katak. Nusxa ham 3 ta katakdan iborat bo'ladi, faqat boshqa joyda turadi."},
 tn:"Bu — darslikdagi «Katak qog'ozga shakl yasash» darsi. Naqshlarni (kashta) nusxalash vazifasini bering."},
{h:"Tuzoq: kataklar soni va perimetr",sum:"Tasma 4 × 1: kataklar 4 ta, lekin perimetr 4 + 4 + 1 + 1 = 10 sm.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Ko'pchilik shaklning <b>ichidagi kataklarni</b> va <b>chegara uzunligini</b> (perimetrni) aralashtirib yuboradi. Tasma misolida ko'raylik.</p>",
 btns:[phaser(P6)],
 after:"<p><b>Kataklar soni</b> — shakl ichi (yuz). <b>Perimetr</b> — chegara chizig'i uzunligi: shakl atrofida yuradigan chumoli bosib o'tgan yo'l. Ular har xil narsa!</p>",
 q:{t:"Bo'yi 3 katak, eni 1 katak bo'lgan tasmaning perimetri qancha (katak tomoni 1 sm)?",opts:["3 sm","8 sm","4 sm","6 sm"],ok:1,why:"3 + 3 + 1 + 1 = 8 sm.",hint:"Shakl atrofida yuring: tepada qancha, pastda qancha, yonlarda qancha?",full:"Tepa 3 sm, past 3 sm, ikki yon 1 sm dan: 3 + 3 + 1 + 1 = 8 sm. «3» — kataklar soni, bu perimetr emas."},
 tn:"Bolalar barmog'i bilan shakl chegarasi bo'ylab yurib, har bir katak tomonini sanashsin."},
{h:"Tuzoq: «nechta ko'p?»",sum:"Bo'yalgan 7, bo'yalmagan 12 − 7 = 5. Farq: 7 − 5 = 2.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Testda shunday savol keladi: «Bo'yalgan kataklar bo'yalmaganlardan nechta ko'p?» Bu yerda uch qadam bor.</p>",
 btns:[phaser(P7)],
 after:"<p>Uch qadam: <b>1)</b> bo'yalganlarni sanash, <b>2)</b> bo'yalmaganlarni topish (hammasidan ayirib), <b>3)</b> farqini hisoblash. Ko'pchilik 2- yoki 3-qadamni unutadi.</p>",
 q:{t:"4 × 4 kvadratda 10 ta katak bo'yalgan. Bo'yalgan kataklar bo'yalmaganlardan nechta ko'p?",opts:["6","10","4","16"],ok:2,why:"Hammasi 16, bo'yalmagan 16 − 10 = 6, farq 10 − 6 = 4.",hint:"Avval nechta katak bo'yalmaganini toping.",full:"4 · 4 = 16 katak. Bo'yalmagan: 16 − 10 = 6. Farq: 10 − 6 = 4. «6» — bu bo'yalmaganlar soni, farq emas."},
 tn:"Savolda «nechta ko'p?» so'zining tagiga chizdiring — bu farqni so'raydi."},
{h:"Bilasizmi? Ekran ham katakli",sum:"Telefon va televizor ekrani juda mayda kataklardan — piksellardan iborat.",a:"m08",
 start:function(){kqPix()},fin:function(){kqPix()},
 html:"<p>📱 Telefoningiz ekraniga juda yaqindan, lupa bilan qarasangiz, u ham <b>mayda kataklardan</b> iborat ekanini ko'rasiz. Ular <b>piksel</b> deyiladi. Har bir piksel bir rangga bo'yaladi — xuddi biz katakli qog'ozda qilganimizdek. Bitta telefon ekranida <b>million</b>dan ortiq piksel bor!</p><p>🧵 Buvilarimiz kashtani ham katakli mato ustida, kataklarni sanab tikishgan.</p>",
 tn:"Bolalar katakli qog'ozda o'z «piksel rasmi»ni (yurak, uy, yulduz) chizsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){kqPaper();kqCells(kqRect(3,8,2,3),C.a,true);kqMsg('2 qator × 3 katak = 6')},fin:function(){kqPaper();kqCells(kqRect(3,8,2,3),C.a,true);kqMsg('2 qator × 3 katak = 6')},
 html:"<div class='memo'><ul><li>Katakli qog'oz — bir xil kichik kvadratlar (kataklar).</li><li>To'g'ri to'rtburchak ichidagi kataklar: <b>qatorlar × har qatordagi kataklar</b> (2 × 3 = 6).</li><li>Murakkab shakl — har katakka raqam qo'yib sanang.</li><li>To'ldirish: <b>kerak − bor</b> (9 − 5 = 4).</li><li>Robot yo'li: o'ngga = chapga va pastga = yuqoriga bo'lsa — shakl yopiladi.</li><li><b>Kataklar soni</b> (ichi) va <b>perimetr</b> (chegara) — har xil narsa: 4 × 1 tasmada 4 katak, perimetr 10.</li><li>«Nechta ko'p?» — farqni toping.</li></ul></div>",
 tn:"Keyingi dars (yuz tushunchasi) shu yerdan davom etadi: «kataklar soni — shaklning yuzi»."}
];
function kq5(full){var pat=[[2,2],[2,3],[3,2],[4,2],[4,3]],tgt=pat.map(function(p){return [p[0],p[1]+9]});S.c5={};
 kqPaper({tap:function(r,c){if(full||S.c5[r+','+c]||c<8)return;S.c5[r+','+c]=1;var ok=tgt.some(function(p){return p[0]===r&&p[1]===c});kqCell(r,c,ok?C.ok:C.bad);
  var good=tgt.filter(function(p){return S.c5[p[0]+','+p[1]]}).length;kqMsg(ok?('To‘g‘ri: '+good+' / '+tgt.length):'Bu katak namunada yo‘q — namunaga qayta qarang');if(good===tgt.length&&S.d5)S.d5()}});
 E('line',{x1:KQ.x0+8*KQ.cs-8,y1:KQ.y0,x2:KQ.x0+8*KQ.cs-8,y2:KQ.y0+KQ.rows*KQ.cs,stroke:C.grey,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);
 T(S.g,KQ.x0+3*KQ.cs,KQ.y0+8*KQ.cs+10,'namuna',{'font-size':11,fill:C.blue});T(S.g,KQ.x0+13*KQ.cs,KQ.y0+8*KQ.cs+10,'nusxa',{'font-size':11,fill:C.blue});
 S.g.setAttribute('transform','translate(-44,-21.8) scale(1.6)'); kqCells(pat,C.a);if(full)kqCells(tgt,C.ok);kqMsg(full?'Nusxa namunaga mos: 5 ta katak':'Namunani o‘ng tomonga ko‘chiring')}
function kqPix(){clear('#ffffff');var g=S.g,H=[[0,1,1,0,1,1,0],[1,1,1,1,1,1,1],[1,1,1,1,1,1,1],[0,1,1,1,1,1,0],[0,0,1,1,1,0,0],[0,0,0,1,0,0,0]],cs=18,x0=117,y0=24;
 H.forEach(function(row,r){row.forEach(function(v,c){E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs-1,height:cs-1,fill:v?'#e0475b':'#eef3f8'},g)})});var n=0;H.forEach(function(r){r.forEach(function(v){n+=v})});kqMsg('42 ta «piksel»dan '+n+' tasi bo\u2018yalgan — yurak tasviri')}
var PROBS=[
{t:"Bo'yi 4 katak, eni 2 katak bo'lgan to'g'ri to'rtburchak ichida nechta katak bor?",o:["8","6","12","16"],k:0,s:"2 qator × 4 katak = 8."},
{t:"Kvadrat ichida 16 ta katak bor. Uning tomoni necha katak?",o:["4","8","16","2"],k:0,s:"4 · 4 = 16, tomoni 4 katak."},
{t:"Kvadrat ichida 9 ta katak bor. Uning tomoni necha katak?",o:["3","9","4","2"],k:0,s:"3 · 3 = 9."},
{t:"Shaklda 5 ta katak bor. 3 × 3 kvadrat hosil qilish uchun yana nechta katak kerak?",o:["4","5","3","9"],k:0,s:"9 − 5 = 4."},
{t:"Shaklda 6 ta katak bor. 3 × 4 to'g'ri to'rtburchak hosil qilish uchun yana nechta katak kerak?",o:["6","7","12","5"],k:0,s:"3 · 4 = 12, 12 − 6 = 6."},
{t:"Robot 2 katak o'ngga, 2 pastga, 2 chapga va 2 yuqoriga yurdi. Chizilgan shakl ichida nechta katak?",o:["4","8","2","6"],k:0,s:"Tomoni 2 katakli kvadrat: 2 · 2 = 4."},
{t:"Robot 3 katak o'ngga, 3 pastga, 3 chapga va 3 yuqoriga yurdi. U jami necha katak tomoni yo'l bosdi?",o:["12","9","6","3"],k:0,s:"3 + 3 + 3 + 3 = 12."},
{t:"Robot 4 katak o'ngga, 1 pastga, 4 chapga yurdi. Boshlagan joyiga qaytishi uchun yana nima qilishi kerak?",o:["1 katak yuqoriga","4 katak o'ngga","1 katak pastga","4 katak yuqoriga"],k:0,s:"O'ngga 4 va chapga 4 — tenglashdi; pastga 1 yurgan, demak 1 yuqoriga."},
{t:"Bo'yi 5 katak, eni 1 katak bo'lgan tasmaning perimetri (katak tomoni 1 sm)?",o:["12 sm","5 sm","10 sm","6 sm"],k:0,s:"5 + 5 + 1 + 1 = 12 sm."},
{t:"3 × 3 kvadratning perimetri (katak tomoni 1 sm)?",o:["12 sm","9 sm","6 sm","16 sm"],k:0,s:"4 ta tomon, har biri 3 sm: 3 · 4 = 12 sm."},
{t:"4 × 3 to'g'ri to'rtburchakda 8 ta katak bo'yalgan. Bo'yalmagan kataklar nechta?",o:["4","8","12","5"],k:0,s:"12 − 8 = 4."},
{t:"4 × 3 to'g'ri to'rtburchakda 7 ta katak bo'yalgan. Bo'yalgan kataklar bo'yalmaganlardan nechta ko'p?",o:["2","5","7","12"],k:0,s:"Bo'yalmagan 12 − 7 = 5, farq 7 − 5 = 2."},
{t:"5 × 2 to'g'ri to'rtburchakning yarmi bo'yalgan. Nechta katak bo'yalgan?",o:["5","10","7","2"],k:0,s:"Hammasi 10, yarmi 5."},
{t:"Ikki qatorli shakl: tepada 6 ta, pastda 4 ta katak. Hammasi nechta katak?",o:["10","24","12","8"],k:0,s:"6 + 4 = 10. Qatorlar teng emas — ko'paytirib bo'lmaydi."},
{t:"Qaysi to'g'ri to'rtburchakda kataklar eng ko'p?",o:["4 × 4","5 × 3","6 × 2","7 × 1"],k:0,s:"16, 15, 12, 7 — eng ko'pi 4 × 4 = 16."},
{t:"12 ta katakdan nechta har xil to'g'ri to'rtburchak yasash mumkin (aylantirilgani bir xil hisoblanadi)?",o:["3","2","4","6"],k:0,s:"1 × 12, 2 × 6, 3 × 4 — 3 ta."},
{t:"Kvadrat shaklidagi 2 × 2 plitkalardan 4 × 4 maydoncha terildi. Nechta plitka kerak bo'ldi?",o:["4","8","16","2"],k:0,s:"Har plitka 4 katak, maydon 16 katak: 16 : 4 = 4 (yoki 2 qator × 2)."},
{t:"Shaklda 3 qator bor, har qatorda 5 tadan katak. Agar har qatordan 1 tadan katak o'chirilsa, nechta qoladi?",o:["12","14","15","10"],k:0,s:"3 · 5 = 15, o'chirildi 3 ta: 15 − 3 = 12."},
{t:"Robot har safar 2 katak o'ngga va 1 katak pastga yuradi. Shu ishni 3 marta qilsa, jami necha katak o'ngga siljiydi?",o:["6","3","9","2"],k:0,s:"2 · 3 = 6 katak o'ngga."},
{t:"Bo'yi 4 katak, eni 2 katak bo'lgan to'g'ri to'rtburchak bitta to'g'ri kesish bilan ikkita bir xil kvadratga bo'lindi. Har bir kvadratda nechta katak bor?",o:["4","8","2","6"],k:0,s:"Har kvadrat 2 × 2: 4 ta katak (8 : 2 = 4)."}
];
function PRACT_STAGE(){kqPaper();kqCells(kqRect(3,8,2,3),C.a,true);kqMsg('Kerak bo‘lsa, kataklarni sanab tekshiring')}
var PREP_DATA={teach:["Katakli qog'oz, katak; kataklar bo'yicha shakl chizish.","Ko'rsatma (grafik diktant) bo'yicha chizish.","Kataklarni xatosiz sanash; shaklni to'ldirish (kerak − bor).","Shaklni nusxalash; kataklar soni va perimetr farqi."],
 mist:["Murakkab shakl kataklarini ikki marta sanaydi yoki tashlab ketadi.","Kataklar soni bilan perimetrni aralashtiradi (4 × 1 tasmada perimetr «4»).","«Nechta ko'p?» savoliga bo'yalganlar sonini aytadi.","Teng bo'lmagan qatorlarni ham ko'paytiradi."],
 need:["Katakli varaqlar, rangli qalamlar.","Doskada katakli to'r (yoki magnit kvadratchalar)."],
 board:["Katakli to'r: 3 × 2 to'rtburchak — 6 katak.","Grafik diktant: <span class='w2'>3 → 2 ↓ 3 ← 2 ↑</span>.","Raqam qo'yib sanash: L-shakl — 8 katak.","To'ldirish: <span class='w2'>9 − 5 = 4</span>.","Tasma 4 × 1: kataklar 4, perimetr <span class='w2'>4 + 4 + 1 + 1 = 10</span>.","Farq: <span class='w2'>7 − (12 − 7) = 2</span>."]};
