
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G1',TITLE='3-sinf · Uzunlik: mm, sm, dm, m, km';
function g1seg(x0,x1,y,lab,col,o){o=o||{};var g=S.g;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:col||C.blue,'stroke-width':o.w||4,'stroke-linecap':'round'},g);[x0,x1].forEach(function(x){E('line',{x1:x,y1:y-6,x2:x,y2:y+6,stroke:col||C.blue,'stroke-width':2},g)});if(lab)T(g,(x0+x1)/2,y+(o.below?20:-10),lab,{'font-size':12,'font-weight':800,fill:col||C.blue})}
function g1pt(x,y,n,col){E('circle',{cx:x,cy:y,r:4.5,fill:col||'#1d2b3a'},S.g);T(S.g,x,y-12,n,{'font-size':13,'font-weight':800,fill:col||'#1d2b3a'})}
function g1mm(v){var s=Math.floor(v/10),m=v%10;return (s?s+' sm ':'')+(m||!s?m+' mm':'')}
function g1rul(){var L=S.g1L;clear();T(S.g,14,18,'Kesmani 4 sm 3 mm qiling',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});var x=f3ruler(30,104,300,0,10);
 E('line',{x1:x(4.3),y1:40,x2:x(4.3),y2:104,stroke:C.ok,'stroke-width':1.2,'stroke-dasharray':'4 3'},S.g);if(L>0)g1seg(x(0),x(L/10),86,g1mm(L),L===43?C.ok:L>43?C.bad:C.blue);
 f3calc([L===43?'✓ <b>4 sm 3 mm = 43 mm</b> — 4 ta katta oraliq va 3 ta kichik':L>43?'Uzun bo‘lib ketdi: '+g1mm(L)+'. Keyingi bosishda 0 dan boshlaymiz':'Hozir: <b>'+g1mm(L)+'</b> = '+L+' mm'])}
function g1step(L,done){if(S.g1L>43)L=L-S.g1L;S.g1L=Math.max(0,Math.min(100,L));g1rul();if(S.g1L===43)done()}
var G1U=[['km','1 km = 1000 m'],['m','1 m = 10 dm = 100 sm = 1000 mm'],['dm','1 dm = 10 sm = 100 mm'],['sm','1 sm = 10 mm'],['mm','1 mm — eng kichik bo‘lak chizg‘ichda']];
function g1lad(sel){clear();var g=S.g,xs=[38,110,182,254,326];T(g,180,22,'kattadan kichikka →',{'font-size':11,fill:'#3a4a5a'});
 G1U.forEach(function(u,i){var on=i===sel;E('rect',{x:xs[i]-26,y:56+i*14-28,width:52,height:36,rx:8,fill:on?C.a:'#fff',stroke:on?C.a:C.line,'stroke-width':2},g);T(g,xs[i],56+i*14-4,u[0],{'font-size':16,'font-weight':800,fill:on?'#fff':'#1d2b3a'});
  if(i<4){T(g,xs[i]+44,82+i*14,i?'×10':'×1000',{'font-size':12,'text-anchor':'end','font-weight':800,fill:C.blue})}});
 f3calc([sel==null?'Birlikni tanlang':'<b>'+G1U[sel][1]+'</b>','Kichikroq birlikka o‘tsak — son KATTA bo‘ladi'])}
function g1tab(st){clear();var g=S.g,cols=['m','dm','sm','mm'],xs=[60,150,230,310],v=[['','','',''],['77','','9','4'],['77','0','9','4']][st];
 T(g,14,18,'77 m 9 sm 4 mm = ? mm',{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 cols.forEach(function(c,i){var w=i?70:100;E('rect',{x:xs[i]-w/2,y:40,width:w,height:28,fill:'#eef4fb',stroke:C.line},g);T(g,xs[i],59,c,{'font-size':13,'font-weight':800,fill:C.blue});
  var miss=st===1&&i===1;E('rect',{x:xs[i]-w/2,y:68,width:w,height:46,fill:miss?'#ffe3e0':'#fff',stroke:C.line},g);T(g,xs[i],100,miss?'?':v[i],{'font-size':22,'font-weight':800,fill:miss?C.bad:(st===2&&i===1?C.ok:'#1d2b3a')})});
 if(st===2)T(g,180,146,'77 0 9 4  →  77 094 mm',{'font-size':15,'font-weight':800,fill:C.ok})}
var G1P3=[function(){g1tab(0);f3calc(['Har bir birlik — bitta xona (o‘nlik sistema!)'])},function(){g1tab(1);f3calc(['Metr, santimetr, millimetrni joyiga yozamiz','Detsimetr xonasi bo‘sh — nima yozamiz?'])},function(){g1tab(2);f3calc(['Bo‘sh xonaga <b>0</b>! 77 m 9 sm 4 mm = <b>77 094 mm</b>','0 ni unutsangiz: 7794 mm — 10 marta kam!'])}];
var G1C=[['3 dm 4 mm',304],['2 dm 98 mm',298],['30 sm 3 mm',303],['29 sm 15 mm',305]];
function g1cards(show,okI){clear();var g=S.g;T(g,14,18,'Qaysi uzunlik eng uzun?',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 G1C.forEach(function(c,i){var x=12+i*86,on=show&&i===3;E('rect',{x:x,y:40,width:80,height:90,rx:8,fill:on?'#e3f6e8':'#fff',stroke:on?C.ok:C.line,'stroke-width':2},g);T(g,x+40,72,c[0].split(' ').slice(0,2).join(' '),{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,x+40,90,c[0].split(' ').slice(2).join(' '),{'font-size':13,'font-weight':800,fill:'#1d2b3a'});
  if(show)T(g,x+40,118,c[1]+' mm',{'font-size':13,'font-weight':800,fill:on?C.ok:C.blue})})}
var G1P5=[function(){g1map(0);f3calc(['Uydan bozorgacha 1 km 300 m, maktabgacha 860 m. Farqi?'])},function(){g1map(1);f3calc(['Bir xil birlikka: 1 km 300 m = 1000 + 300 = <b>1300 m</b>'])},function(){g1map(2);f3calc(['1300 − 860 = <b>440 m</b> — maktab shuncha yaqin'])}];
function g1map(st){clear();var k=0.22,x0=30,g=S.g;E('line',{x1:x0,y1:100,x2:x0+1300*k,y2:100,stroke:'#9fb3c8','stroke-width':6,'stroke-linecap':'round'},g);
 g1pt(x0,100,'🏠');g1pt(x0+860*k,100,'🏫');g1pt(x0+1300*k,100,'🛒');Br(x0,x0+1300*k,64,st?'1300 m':'1 km 300 m',true);Br(x0,x0+860*k,118,'860 m',false,C.b);if(st===2)Br(x0+860*k,x0+1300*k,118,'440 m',false,C.ok)}
function g1abd(c){clear();var k=12,A=110,g=S.g;E('line',{x1:20,y1:100,x2:340,y2:100,stroke:'#9fb3c8','stroke-width':2},g);var D=A+12*k,B=c===1?A+4*k:A-4*k;
 g1pt(A,100,'A');g1pt(D,100,'D');g1pt(B,100,'B',C.bad);Br(A,D,70,'AD = 12',true);Br(Math.min(A,B),Math.max(A,B),120,'AB = 4',false,C.b);Br(B,D,146,'BD = '+(c===1?8:16),false,C.ok);S.g1c[c]=1;
 var n=S.g1c.filter(Boolean).length;f3calc([c===1?'B — A va D orasida: BD = 12 − 4 = <b>8</b> sm':'B — A dan chapda: BD = 12 + 4 = <b>16</b> sm',n<2?'Boshqa joyini ham tekshiring!':'Ikkala holat ham mumkin: <b>8 yoki 16</b>'])}
var G1P7=[function(){g1ab(0);f3calc(['AB = 1 m 2 dm, AC = 38 sm. CB = ?'])},function(){g1ab(1);f3calc(['Bir xil birlik: 1 m 2 dm = 100 + 20 = <b>120 sm</b>'])},function(){g1ab(2);f3calc(['CB = 120 − 38 = <b>82 sm</b>','«1 m 2 dm − 38 sm» ni birlikka keltirmay ayirib bo‘lmaydi'])}];
function g1ab(st){clear();var k=2.4,x0=30;g1seg(x0,x0+120*k,96,'',C.line,{w:5});g1pt(x0,96,'A');g1pt(x0+38*k,96,'C',C.bad);g1pt(x0+120*k,96,'B');Br(x0,x0+120*k,62,st?'120 sm':'1 m 2 dm',true);Br(x0,x0+38*k,116,'38 sm',false,C.b);if(st===2)Br(x0+38*k,x0+120*k,116,'82 sm',false,C.ok)}
var G1P8=[function(){g1tri(0);f3calc(['AB = 52 mm, BC = 6 sm, AC = 47 mm. Perimetr (mm)?'])},function(){g1tri(1);f3calc(['6 sm = <b>60 mm</b> — avval bir xil birlikka!'])},function(){g1tri(1);f3calc(['P = 52 + 60 + 47 = <b>159 mm</b>','Xato: 52 + 6 + 47 = 105 — birlik aralashdi'])}];
function g1tri(st){clear();var g=S.g;E('path',{d:'M70 145 L180 30 L300 145 Z',fill:'#eef4fb',stroke:C.blue,'stroke-width':3},g);T(g,62,160,'A',{'font-size':13,'font-weight':800});T(g,180,22,'B',{'font-size':13,'font-weight':800});T(g,308,160,'C',{'font-size':13,'font-weight':800});
 T(g,104,84,'52 mm',{'font-size':12,'font-weight':800,fill:C.blue});T(g,268,84,st?'60 mm':'6 sm',{'font-size':12,'font-weight':800,fill:st?C.ok:C.bad});T(g,185,162,'47 mm',{'font-size':12,'font-weight':800,fill:C.blue})}
function g1hist(){clear('#f6ead0');var g=S.g;E('path',{d:'M180 20 A70 70 0 0 1 250 90',fill:'none',stroke:'#8a5a24','stroke-width':3},g);E('circle',{cx:180,cy:90,r:70,fill:'none',stroke:'#c9a764','stroke-dasharray':'4 4'},g);
 T(g,180,14,'qutb',{'font-size':11,fill:'#6b3d12'});T(g,290,94,'ekvator',{'font-size':11,fill:'#6b3d12'});T(g,232,40,'¼',{'font-size':14,'font-weight':800,fill:'#6b3d12'});f3msg('Metr — qutbdan ekvatorgacha masofaning 10 milliondan biri sifatida o‘ylab topilgan')}
var STEPS=[
{h:"Chizg'ich: sm va mm",sum:"Chizg'ichdagi katta oraliq — 1 sm, kichik oraliq — 1 mm. 1 sm = 10 mm. 4 sm 3 mm = 43 mm.",a:"m01",
 start:function(){S.g1L=0;g1rul()},fin:function(){S.g1L=43;g1rul()},
 html:"<p>Chizg'ichda raqamlar orasi — <b>1 santimetr</b>, uning ichidagi 10 ta mayda oraliq — <b>millimetr</b>. Tugmalar bilan kesmani 0 dan aniq <b>4 sm 3 mm</b> qiling:</p>",
 btns:[["+1 sm",function(c,done){g1step(S.g1L+10,done)}],["+1 mm",function(c,done){g1step(S.g1L+1,done)}]],g2:1,
 after:"<p>4 ta santimetr (40 mm) va yana 3 mm — jami <b>43 mm</b>. Bitta millimetr — tanga qirrasidek qalinlik.</p>",
 q:{t:"6 sm 5 mm necha millimetr?",opts:["65 mm","11 mm","605 mm","56 mm"],ok:0,why:"6 · 10 + 5 = 65.",hint:"1 sm da nechta millimetr bor?",full:"6 sm = 60 mm, yana 5 mm — 65 mm. «11» — 6 + 5 ni qo'shib yuborish, «605» — noto'g'ri nol."},
 tn:"Har bola o'z chizg'ichida qalam, o'chirg'ich uzunligini sm va mm da o'lchasin (Gollandiya RME: haqiqiy o'lchash)."},
{h:"Birliklar zinapoyasi",sum:"1 km = 1000 m; 1 m = 10 dm; 1 dm = 10 sm; 1 sm = 10 mm.",a:"m02",
 start:function(){g1lad(null)},fin:function(){g1lad(1)},
 html:"<p>Har bir birlikni bosing va u qancha kichik birlikka tengligini ko'ring (kamida 3 tasini):</p>",
 btns:G1U.map(function(u,i){return [u[0],function(c,done){g1lad(i);mvK(done,3)}]}),g3:1,
 after:"<p>mm → sm → dm → m — har qadam <b>10 marta</b>. m → km — <b>1000 marta</b>. Katta birlikdan kichigiga o'tsak — <b>ko'paytiramiz</b>, kichigidan kattasiga — <b>bo'lamiz</b>.</p>",
 q:{t:"4 m necha santimetr?",opts:["40 sm","400 sm","4000 sm","14 sm"],ok:1,why:"1 m = 100 sm, 4 · 100 = 400.",hint:"1 m da nechta santimetr bor? Detsimetr emas!",full:"1 m = 10 dm = 100 sm. 4 m = 400 sm. «40» — metrni detsimetrga aylantirish, «4000» — millimetrga."},
 tn:"Doskaga zinapoyani chizing. Bir metrli tasma ustida 10 ta detsimetrni belgilang."},
{h:"Bitta birlikka: nolni unutmang",sum:"77 m 9 sm 4 mm = 77 094 mm: detsimetr xonasiga 0 yoziladi.",a:"m03",
 start:function(){startPh(G1P3)},fin:function(){S.ph=2;G1P3[2]()},
 html:"<p>Uzunlik birliklari o'nlik sistemaga o'xshaydi: m, dm, sm, mm — bu <b>xonalar</b>. Jadvalni to'ldiring:</p>",btns:[phaser(G1P3)],
 after:"<p>Bo'sh birlik xonasiga <b>0</b> yozamiz. Xuddi sonlardagi kabi: 3 yuz va 5 birlik = 305.</p>",
 q:{t:"5 m 7 mm necha millimetr?",opts:["57 mm","507 mm","5007 mm","5070 mm"],ok:2,why:"5 m = 5000 mm, + 7 = 5007.",hint:"Metrdan millimetrgacha uchta xona: dm, sm, mm.",full:"m | dm | sm | mm → 5 | 0 | 0 | 7 = 5007 mm. «507» — bitta nol tushib qoldi, «57» — ikkalasi."},
 tn:"Jadvalni doskaga chizing: m | dm | sm | mm. Bolalar sonlarni magnit kartochkalar bilan joylashtirsin."},
{h:"Uzunliklarni taqqoslash",sum:"Taqqoslashdan oldin hamma uzunlikni bir birlikka (mm) keltiramiz: 29 sm 15 mm = 305 mm — eng uzun.",a:"m04",
 start:function(){g1cards(0);f3calc(['Har bir kartochka — boshqa birliklarda. Taxmin qiling'])},fin:function(){g1cards(1);f3msg('<b>29 sm 15 mm = 305 mm</b> — eng uzun')},
 html:"<p>Qaysi uzunlik eng uzun? Kattaroq son yoki birlikka aldanmang!</p>",
 btns:G1C.map(function(c,i){return [c[0],function(cc,done){g1cards(1);if(i===3){f3msg('✓ <b>29 sm 15 mm = 305 mm</b> — eng uzun');done()}else f3msg('<span style="color:#c0392b">✗</span> '+c[0]+' = '+c[1]+' mm. Hammasini mm da solishtiring')}]}),g2:1,
 after:"<p>Hammasi mm da: 304, 298, 303, <b>305</b>. «29 sm» kichik ko'rinadi, lekin 15 mm = 1 sm 5 mm — demak 30 sm 5 mm!</p>",
 q:{t:"Qaysi biri uzunroq: 4 dm 6 sm yoki 45 sm 12 mm?",opts:["4 dm 6 sm","45 sm 12 mm","Teng","Taqqoslab bo'lmaydi"],ok:1,why:"460 mm < 462 mm.",hint:"Ikkalasini millimetrga aylantiring.",full:"4 dm 6 sm = 46 sm = 460 mm. 45 sm 12 mm = 450 + 12 = 462 mm. 462 > 460 — ikkinchisi uzun."},
 tn:"Ko'p xatoni «tez taqqoslash» beradi. Har doim bir birlikka yozdirish odatini shakllantiring."},
{h:"Kilometr va metr",sum:"1 km 300 m = 1300 m; 1300 − 860 = 440 m.",a:"m05",
 start:function(){startPh(G1P5)},fin:function(){S.ph=2;G1P5[2]()},
 html:"<p><i>«Uydan bozorgacha 1 km 300 m, maktabgacha 860 m. Maktabgacha masofa necha metr qisqa?»</i></p>",btns:[phaser(G1P5)],
 after:"<p>1 km = <b>1000 m</b>. Avval hammasini metrga, keyin ayirish. Xato: 1300 dan emas, 300 dan ayirmoqchi bo'lish.</p>",
 q:{t:"Poyga yo'li 2 km. Velosipedchi yo'lning yarmini, keyin yana 350 m yurdi. Marragacha necha metr qoldi?",opts:["650 m","1350 m","1650 m","750 m"],ok:0,why:"2000 : 2 = 1000; 1000 + 350 = 1350; 2000 − 1350 = 650.",hint:"2 km = ? m. Yarmi qancha?",full:"2 km = 2000 m. Yarmi 1000 m, yana 350 — jami 1350 m yurildi. Qoldi: 2000 − 1350 = 650 m. «1350» — bu yurilgani."},
 tn:"Maktab atrofidagi masofani bolalar qadam bilan o'lchasin: 1 km taxminan 1500–2000 bola qadami."},
{h:"Tuzoq: nuqta qayerda?",sum:"AD = 12 sm, AB = 4 sm: B A va D orasida bo'lsa BD = 8, A dan chapda bo'lsa BD = 16.",a:"m06",
 start:function(){S.g1c=[];clear();E('line',{x1:20,y1:100,x2:340,y2:100,stroke:'#9fb3c8','stroke-width':2},S.g);g1pt(110,100,'A');g1pt(254,100,'D');f3calc(['AD = 12 sm, AB = 4 sm. BD necha sm? B ni qayerga qo‘yamiz?'])},
 fin:function(){S.g1c=[,1];g1abd(2)},
 html:"<p><i>«To'g'ri chiziqda A, B, D nuqtalar. AD = 12 sm, AB = 4 sm. BD necha santimetr bo'lishi mumkin?»</i> Shartda B ning joyi aytilmagan! Ikkala joyni tekshiring:</p>",
 btns:[["B — A va D orasida",function(c,done){g1abd(1);if(S.g1c[1]&&S.g1c[2])done()}],["B — A dan chapda",function(c,done){g1abd(2);if(S.g1c[1]&&S.g1c[2])done()}]],g2:1,
 after:"<p>Chizmasiz masalada nuqta <b>ikki tomonda</b> bo'lishi mumkin. Javob: <b>8 yoki 16 sm</b>. «Bo'lishi mumkin» so'zi — ishora!</p>",
 q:{t:"To'g'ri chiziqda K, L, M nuqtalar. KM = 10 sm, KL = 3 sm. LM necha sm bo'lishi mumkin?",opts:["faqat 7","faqat 13","7 yoki 13","3 yoki 10"],ok:2,why:"L orada: 10 − 3 = 7; L chetda: 10 + 3 = 13.",hint:"L nuqtani K va M orasiga, keyin K ning narigi tomoniga qo'yib ko'ring.",full:"L K va M orasida bo'lsa LM = 10 − 3 = 7 sm. L K dan tashqarida (M ning teskari tomonida) bo'lsa LM = 10 + 3 = 13 sm."},
 tn:"Bolalar ip va uchta tugmacha bilan ikkala holatni partada yasasin."},
{h:"Tuzoq: aralash birliklarni ayirish",sum:"AB = 1 m 2 dm = 120 sm, AC = 38 sm, CB = 120 − 38 = 82 sm.",a:"m07",
 start:function(){startPh(G1P7)},fin:function(){S.ph=2;G1P7[2]()},
 html:"<p><i>«C nuqta AB kesmada yotadi. AB = 1 m 2 dm, AC = 38 sm. CB ni toping.»</i></p>",btns:[phaser(G1P7)],
 after:"<p>Uchta xato yo'l bor: 2 − 38 qilib bo'lmaydi; 12 − 38 ham; 1 m 2 dm ni «12 sm» deb o'qish. To'g'risi: 1 m 2 dm = <b>120 sm</b>.</p>",
 q:{t:"Butun yo'l 2 dm 4 sm. Xonqizi 9 sm yurdi. Yana qancha yurishi kerak?",opts:["15 sm","33 sm","15 dm","5 sm"],ok:0,why:"2 dm 4 sm = 24 sm, 24 − 9 = 15 sm.",hint:"2 dm 4 sm necha santimetr?",full:"2 dm 4 sm = 20 + 4 = 24 sm. 24 − 9 = 15 sm (= 150 mm). «33» — qo'shib yuborish, «15 dm» — birlik xatosi."},
 tn:"Doskaga kesma chizib, har bir bo'lagini bir xil birlikda yozdiring."},
{h:"Tuzoq: perimetr va birliklar",sum:"AB = 52 mm, BC = 6 sm = 60 mm, AC = 47 mm; P = 159 mm.",a:"m08",
 start:function(){startPh(G1P8)},fin:function(){S.ph=2;G1P8[2]()},
 html:"<p><i>«Uchburchak tomonlari: AB = 52 mm, BC = 6 sm, AC = 47 mm. Perimetrni millimetrlarda toping.»</i> Bitta tomon boshqa birlikda!</p>",btns:[phaser(G1P8)],
 after:"<p>Qo'shishdan oldin <b>hamma uzunlikni bir birlikka</b> keltiramiz. 52 + 6 + 47 = 105 — noto'g'ri, chunki 6 — santimetr.</p>",
 q:{t:"Siniq chiziq: 4 sm, 7 sm, 5 sm. Uzunligini 2 marta orttiring va millimetrda yozing.",opts:["32 mm","160 mm","320 mm","3200 mm"],ok:2,why:"(4 + 7 + 5) · 2 = 32 sm = 320 mm.",hint:"Avval sm da hisoblang, keyin mm ga o'tkazing.",full:"4 + 7 + 5 = 16 sm. 16 · 2 = 32 sm = 320 mm. «32» — birlik o'zgartirilmagan, «160» — 2 ga ko'paytirilmagan."},
 tn:"Uchburchakning tomonlarini bolalar o'zi o'lchasin va har xil birlikda yozsin."},
{h:"Bilasizmi? Metr qanday tug'ilgan",sum:"Metr XVIII asr oxirida Fransiyada Yer o'lchamiga asoslanib kiritilgan; qadimda qarich, quloch, gaz ishlatilgan.",a:"m09",
 start:function(){g1hist()},fin:function(){g1hist()},
 html:"<p>🌍 <b>Metr</b> XVIII asr oxirida Fransiyada kiritilgan. U Shimoliy qutbdan ekvatorgacha bo'lgan masofaning <b>10 million</b>dan bir qismi deb belgilangan. Shuning uchun Yer aylanasi taxminan 40 000 km.</p><p>📏 Qadimda xalqimiz <b>qarich</b> (kerilgan bosh barmoq va jimjiloq orasi), <b>quloch</b> (kerilgan ikki qo'l orasi), <b>gaz</b> bilan o'lchagan. Ammo odamlarning qo'li har xil — o'lchov ham har xil chiqardi. Shuning uchun hamma uchun bir xil metr kerak bo'lgan.</p>",
 tn:"Bolalar o'z qarichini sm da o'lchasin va solishtirsin: nega bir xil emas?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g1lad(1)},fin:function(){g1lad(1)},
 html:"<div class='memo'><ul><li><b>1 sm = 10 mm</b>, <b>1 dm = 10 sm</b>, <b>1 m = 10 dm = 100 sm</b>, <b>1 km = 1000 m</b>.</li><li>Katta birlikdan kichigiga — <b>ko'paytiramiz</b>; kichigidan kattasiga — <b>bo'lamiz</b>.</li><li>Bir birlikka keltirishda bo'sh xonaga <b>0</b>: 77 m 9 sm 4 mm = 77 094 mm.</li><li>Taqqoslash, qo'shish, ayirishdan oldin — <b>bir xil birlik</b>.</li><li>Chizmasiz nuqta masalasida — <b>ikki holat</b> bo'lishi mumkin.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring; sinfda 1 m li tasma osib qo'ying."}
];
var PROBS=[
{t:"7 sm 2 mm necha millimetr?",o:["72 mm","9 mm","702 mm","27 mm"],k:0,s:"70 + 2 = 72."},
{t:"3 m necha detsimetr?",o:["30 dm","300 dm","3 dm","13 dm"],k:0,s:"1 m = 10 dm."},
{t:"5 km necha metr?",o:["5000 m","500 m","50 m","50 000 m"],k:0,s:"1 km = 1000 m."},
{t:"480 sm necha detsimetr?",o:["48 dm","4 dm 8 sm","480 dm","4800 dm"],k:0,s:"480 : 10 = 48 dm."},
{t:"Qaysi tenglik to'g'ri?",o:["1 m = 1000 mm","1 m = 100 mm","1 dm = 100 sm","1 km = 100 m"],k:0,s:"1 m = 100 sm = 1000 mm."},
{t:"77 m 9 sm 4 mm necha mm?",o:["77 094","7794","77 904","77 940"],k:0,s:"m|dm|sm|mm: 77|0|9|4."},
{t:"3 dm 458 mm = ☐ sm 8 mm. Katakdagi son?",o:["75","48","76","750"],k:0,s:"300 + 458 = 758 mm = 75 sm 8 mm."},
{t:"86 dm 5 sm = 8 m ☐ sm. Katakdagi son?",o:["65","6","605","165"],k:0,s:"865 sm = 8 m 65 sm."},
{t:"Qaysi uzunlik eng uzun?",o:["29 sm 15 mm","3 dm 4 mm","2 dm 98 mm","30 sm 3 mm"],k:0,s:"305 > 304 > 303 > 298 mm."},
{t:"46 sm + 38 sm + 54 sm + 62 sm + 70 sm = ? dm",o:["27","26","270","28"],k:0,s:"Jami 270 sm = 27 dm."},
{t:"Uydan bozorgacha 1 km 300 m, maktabgacha 860 m. Maktabgacha masofa necha metr qisqa?",o:["440 m","540 m","560 m","1160 m"],k:0,s:"1300 − 860 = 440."},
{t:"Ali uydan maktabgacha 1 km 250 m, keyin kutubxonagacha 850 m yurdi. Jami?",o:["2 km 100 m","1 km 950 m","2 km 10 m","2 km 1 m"],k:0,s:"1250 + 850 = 2100 m."},
{t:"AB = 1 m 2 dm, C nuqta AB da, AC = 38 sm. CB = ?",o:["82 sm","64 sm","158 sm","72 sm"],k:0,s:"120 − 38 = 82 sm."},
{t:"Uchburchak tomonlari: 52 mm, 6 sm, 47 mm. Perimetr (mm)?",o:["159","105","164","99"],k:0,s:"52 + 60 + 47 = 159."},
{t:"AD = 12 sm, AB = 4 sm (A, B, D bir to'g'ri chiziqda). BD bo'lishi mumkin:",o:["8 yoki 16 sm","4 yoki 16 sm","faqat 8 sm","faqat 16 sm"],k:0,s:"B orada — 8, chetda — 16."},
{t:"AB = 64 sm. C va D nuqtalar AB da: AC = 18 sm, DB = 27 sm (C — A ga yaqin). CD = ?",o:["19 sm","45 sm","46 sm","37 sm"],k:0,s:"64 − 18 − 27 = 19."},
{t:"Poyga yo'li 2 km. Yarmini va yana 350 m yurdi. Marragacha qoldi?",o:["650 m","1350 m","1650 m","750 m"],k:0,s:"2000 − 1350 = 650."},
{t:"Siniq chiziq: 4 sm, 7 sm, 5 sm. Uni 2 marta orttirib, mm da yozing.",o:["320 mm","32 mm","160 mm","3200 mm"],k:0,s:"16 · 2 = 32 sm = 320 mm."},
{t:"Arqonga tomoni 3 dm bo'lgan 20 ta kvadrat bayroqcha bir-biriga tegib, bo'sh joy qoldirmay osildi. Arqonning bayroqchali qismi necha metr?",o:["6 m","60 m","600 m","23 m"],k:0,s:"3 · 20 = 60 dm = 6 m."},
{t:"Ip 1 m edi. Undan 2 marta 35 sm dan kesildi. Necha sm qoldi?",o:["30 sm","65 sm","70 sm","63 sm"],k:0,s:"100 − 70 = 30 sm."}
];
function PRACT_STAGE(){g1lad(null)}
var PREP_DATA={teach:["mm, sm, dm, m, km va ular orasidagi bog'lanish; chizg'ichda o'lchash.","Ismli sonni bitta birlikka keltirish (bo'sh xonaga 0).","Uzunliklarni taqqoslash, qo'shish, ayirish — bir xil birlikda.","Tuzoqlar: nuqtaning ikki holati, aralash birliklar, perimetr."],
 mist:["1 m = 10 sm yoki 1 km = 100 m deb o'ylaydi.","77 m 9 sm 4 mm ni 7794 mm deb yozadi (0 tushib qoladi).","Har xil birlikdagi sonlarni to'g'ridan-to'g'ri qo'shadi: 52 mm + 6 sm = 58.","Chizmasiz masalada nuqtaning faqat bitta joyini ko'radi."],
 need:["Chizg'ichlar, 1 metrli tasma yoki ruletka.","Ip, tugmachalar."],
 board:["<span class='w2'>1 km = 1000 m; 1 m = 10 dm = 100 sm = 1000 mm</span>.","Jadval: <span class='w2'>m | dm | sm | mm</span>.","<span class='w2'>77 m 9 sm 4 mm = 77 094 mm</span>.","<span class='w2'>1 km 300 m − 860 m = 440 m</span>.","<span class='w2'>BD = 8 yoki 16</span>."]};
