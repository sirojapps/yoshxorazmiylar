var CODE='2A6',TITLE='2-sinf · Sonlarni o‘nlikkacha yaxlitlash';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// son o'qi: a dan b gacha, belgilangan son va masofalar
function rl(a,b,n,o){o=o||{};clear();var x0=26,x1=334,y=100,k=(x1-x0)/(b-a),X=function(v){return x0+(v-a)*k};S.X=X;
 if(o.band){E('rect',{x:X(o.band[0])-k/2,y:y-14,width:(o.band[1]-o.band[0]+1)*k,height:28,rx:8,fill:'#e6f6ee',stroke:C.ok},S.g)}
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);
 for(var v=a;v<=b;v++){var t=v%10===0;E('line',{x1:X(v),y1:y-(t?12:6),x2:X(v),y2:y+(t?12:6),stroke:'#33475b','stroke-width':t?2.8:1.3},S.g);if(t||b-a<=12||(v%10!==1&&v%10!==9))T(S.g,X(v),y+(t?30:24),String(v),{'font-size':t?14:9,'font-weight':t?800:500,fill:t?'#1d2b3a':'#5b6b7b'})}
 if(n!=null){var lo=Math.floor(n/10)*10,hi=lo+10;E('circle',{cx:X(n),cy:y,r:8,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);T(S.g,X(n),y-18,String(n),{'font-size':15,'font-weight':800,fill:C.blue});
  if(o.dist&&n%10){var dl=n-lo,dh=hi-n;E('path',{d:'M'+X(lo)+' '+(y+44)+' L'+X(n)+' '+(y+44),stroke:dl<dh?C.ok:C.bad,'stroke-width':3},S.g);T(S.g,(X(lo)+X(n))/2,y+60,dl+' qadam',{'font-size':11,'font-weight':800,fill:dl<dh?C.ok:C.bad});
   E('path',{d:'M'+X(n)+' '+(y+44)+' L'+X(hi)+' '+(y+44),stroke:dh<=dl?C.ok:C.bad,'stroke-width':3},S.g);T(S.g,(X(n)+X(hi))/2,y+60,dh+' qadam',{'font-size':11,'font-weight':800,fill:dh<=dl?C.ok:C.bad})}}}
function hill(n,roll){clear();var g=S.g,x0=40,x1=320,yb=150,top=40,X=function(v){return x0+(v-40)*(x1-x0)/10},Y=function(v){var d=Math.abs(v-45);return top+(d/5)*(yb-top-20)};
 var d='';for(var v=40;v<=50;v+=.25)d+=(v===40?'M':'L')+X(v)+' '+Y(v);E('path',{d:d,fill:'none',stroke:'#a0703c','stroke-width':4},g);
 for(var u=40;u<=50;u++){E('circle',{cx:X(u),cy:Y(u),r:2.5,fill:'#a0703c'},g);T(g,X(u),Y(u)+(u===45?-12:16),String(u),{'font-size':u%10===0?14:10,'font-weight':u%10===0?800:600,fill:u%10===0?'#1d2b3a':'#6b7b8b'})}
 T(g,X(40),yb+16,'40 ga',{'font-size':11,fill:C.ok,'font-weight':800});T(g,X(50),yb+16,'50 ga',{'font-size':11,fill:C.ok,'font-weight':800});
 var ball=E('circle',{cx:X(n),cy:Y(n)-10,r:9,fill:C.blue,stroke:'#fff','stroke-width':2},g);
 if(roll){var tgt=n>=45?50:40,tok=S.tok;tween(900,function(t){var v=n+(tgt-n)*t;ball.setAttribute('cx',X(v));ball.setAttribute('cy',Y(v)-10)}).then(function(){if(tok!==S.tok)return;msg(n+' → <b>'+tgt+'</b>'+(n===45?' — 45 aynan tepada: kelishuv bo‘yicha <b>yuqoriga</b> (50 ga) yaxlitlanadi':''))})}}
var P2=[function(){hill(43,false);msg('43 tepalikning chap yonbag‘rida turibdi. Qayoqqa dumalaydi?')},function(){hill(43,true)},function(){hill(47,true)},function(){hill(45,true)}];
var P4=[function(){rl(40,60,null);msg('O‘nlikkacha yaxlitlanganda <b>50</b> bo‘ladigan sonlar qaysilar?')},
 function(){rl(40,60,null,{band:[45,54]});msg('45, 46, 47, 48, 49 — yuqoriga 50 ga; 51, 52, 53, 54 — pastga 50 ga; 50 ning o‘zi ham')},
 function(){rl(40,60,null,{band:[45,54]});E('circle',{cx:S.X(54),cy:100,r:9,fill:C.ok,stroke:'#fff','stroke-width':2},S.g);T(S.g,S.X(54),80,'54',{'font-size':15,'font-weight':800,fill:C.ok});E('circle',{cx:S.X(45),cy:100,r:9,fill:C.a,stroke:'#fff','stroke-width':2},S.g);T(S.g,S.X(45),80,'45',{'font-size':15,'font-weight':800,fill:C.a});msg('Eng kattasi — <b>54</b> (55 → 60 bo‘lib ketadi), eng kichigi — <b>45</b>. Jami 45 dan 54 gacha: <b>10 ta</b> son')}];
var STEPS=[
{h:"Qaysi o'nlikka yaqin?",sum:"Son ikkita o'nlik orasida turadi; qaysi biriga kamroq qadam bo'lsa — o'shanga yaxlitlanadi: 47 → 50.",a:"m01",
 start:function(){rl(40,50,47);msg('Sonni tanlang')},fin:function(){rl(40,50,47,{dist:1});msg('47: 40 gacha 7 qadam, 50 gacha 3 qadam → <b>50</b>')},
 html:"<p>47 ta olma bor. Taxminan qancha deyish uchun eng yaqin «yumaloq» songa — <b>o'nlikka</b> yaxlitlaymiz. 47 qaysi o'nlikka yaqin: 40 gami yoki 50 gami? Sonlarni bosing:</p>",
 btns:[["47",function(c,done){sh1(47);mvK(done,3)}],["43",function(c,done){sh1(43);mvK(done,3)}],["48",function(c,done){sh1(48);mvK(done,3)}],["41",function(c,done){sh1(41);mvK(done,3)}]],g2:1,
 after:"<p>Son ikkita o'nlik <b>orasida</b> turadi. Qaysi biriga <b>kamroq qadam</b> bo'lsa, o'shanga yaxlitlanadi: 47 → <b>50</b> (3 qadam), 43 → <b>40</b> (3 qadam).</p>",
 q:{t:"38 ni o'nlikkacha yaxlitlang.",opts:["30","35","40","38"],ok:2,why:"38 dan 40 gacha 2 qadam, 30 gacha 8 qadam.",hint:"38 qaysi ikki o'nlik orasida? Qaysi biriga yaqinroq?",full:"38 — 30 va 40 orasida. 40 gacha: 39, 40 — 2 qadam. 30 gacha 8 qadam. Yaqini 40. «35» — o'nlik emas."},
 tn:"Son o'qi — yaxlitlashning eng tushunarli vositasi (AQSh IES va Gollandiya RME tavsiyasi). Qoidani yodlatishdan oldin «qaysi biriga yaqin?» deb so'rang."},
{h:"Tepalik: qaysi tomonga dumalaydi?",sum:"40–50 oralig'ini tepalik deb tasavvur qilamiz: 41–44 pastga (40 ga), 46–49 yuqoriga (50 ga), 45 — tepada, kelishuv bo'yicha 50 ga.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>40 dan 50 gacha bo'lgan yo'lni <b>tepalik</b> deb tasavvur qiling: 40 va 50 — pastda, 45 — eng tepada. To'p qo'yilgan joydan qaysi tomonga dumalaydi?</p>",
 btns:[phaser(P2,'▶ To‘pni qo‘yib yuborish')],
 after:"<p>43 — chap yonbag'irda, <b>40 ga</b> dumaladi. 47 — o'ng yonbag'irda, <b>50 ga</b>. 45 — aynan o'rtada: matematiklar kelishib olgan — <b>yuqoriga</b>, 50 ga yaxlitlanadi.</p>",
 q:{t:"45 ni o'nlikkacha yaxlitlang.",opts:["40","45","50","Ikkalasi ham bo'ladi"],ok:2,why:"Birlar 5 bo'lsa — yuqoriga yaxlitlanadi.",hint:"45 ikkala o'nlikka teng uzoqlikda. Kelishuv bo'yicha qaysi tomonga?",full:"45 dan 40 gacha ham, 50 gacha ham 5 qadam. Bunday holatda doim yuqoriga yaxlitlanadi: 45 → 50. Bu butun dunyodagi kelishuv."},
 tn:"«Yaxlitlash tepaligi» — AQSh va Buyuk Britaniya maktablarida mashhur tasvir. Doskaga yarim aylana chizib, sonlarni yozing."},
{h:"Qoida: oxirgi raqamga qarang",sum:"Birlar 0–4 bo'lsa — pastga (birlarni 0 ga), 5–9 bo'lsa — yuqoriga (keyingi o'nlikka).",a:"m03",
 start:function(){rule3(null)},fin:function(){rule3(46)},
 html:"<p>Har safar son o'qini chizish shart emas. Qoida oddiy — faqat <b>birlar raqamiga</b> qarang. Sonlarni bosib, qoidani tekshiring:</p>",
 btns:[["46",function(c,done){rule3(46);mvK(done,3)}],["72",function(c,done){rule3(72);mvK(done,3)}],["85",function(c,done){rule3(85);mvK(done,3)}],["19",function(c,done){rule3(19);mvK(done,3)}]],g2:1,
 after:"<p><b>0, 1, 2, 3, 4</b> — pastga: o'nliklar o'zgarmaydi, birlar 0 bo'ladi (72 → 70). <b>5, 6, 7, 8, 9</b> — yuqoriga: o'nliklar 1 ga ortadi (46 → 50, 19 → 20).</p>",
 q:{t:"Ali 46 ni o'nlikkacha yaxlitlab, 40 deb yozdi. U to'g'ri yaxlitladimi?",opts:["Ha, to'g'ri","Yo'q, 50 bo'ladi","Yo'q, 47 bo'ladi","Yo'q, 45 bo'ladi"],ok:1,why:"Birlar 6 — yuqoriga: 46 → 50.",hint:"46 ning birlar raqami nechta? 5 dan kichikmi yoki katta?",full:"46 da birlar 6 — bu 5 dan katta, yuqoriga yaxlitlanadi: 50. Ali birlarni shunchaki tashlab yuborgan — bu ko'p uchraydigan xato. 45 va 47 — o'nlik emas."},
 tn:"Eng ko'p xato — birlarni shunchaki «kesib tashlash» (46 → 40). Har safar «qaysi biriga yaqin?» deb tekshirtiring."},
{h:"Tuzoq: qaysi sonlar 50 bo'ladi?",sum:"50 ga yaxlitlanadigan sonlar: 45 dan 54 gacha — 10 ta. Eng kattasi 54, eng kichigi 45.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Teskari savol: «O'nlikkacha yaxlitlanganda <b>50</b> bo'ladigan sonlardan eng kattasi qaysi?» Kuzating.</p>",
 btns:[phaser(P4)],
 after:"<p>50 ga ikki tomondan keladi: pastdan <b>45–49</b> (yuqoriga dumalab), yuqoridan <b>51–54</b> (pastga) va 50 ning o'zi. Eng kattasi — <b>54</b>, eng kichigi — <b>45</b>, jami <b>10 ta</b>.</p>",
 q:{t:"O'nlikkacha yaxlitlanganda 30 bo'ladigan eng kichik son qaysi?",opts:["25","26","30","21"],ok:0,why:"25 → 30 (birlar 5 — yuqoriga). 24 → 20.",hint:"30 dan pastdagi qaysi sonlar 30 ga dumalaydi?",full:"30 ga 25, 26, 27, 28, 29 yuqoriga dumalab keladi. 24 esa 20 ga ketadi. Eng kichigi — 25."},
 tn:"Bu savol turi testlarda ko'p. Son o'qida «yaxlitlash zonasini» yashil bilan bo'yatib, chegaralarni topishni mashq qiling."},
{h:"Nechta son 70 ga yaxlitlanadi?",sum:"70 ga yaxlitlanadigan sonlar: 65, 66, … 74 — 10 ta. Har bir o'nlikning «zonasi» — 10 ta son.",a:"m05",
 start:function(){rl(60,80,null);msg('Tugmani bosing')},fin:function(){rl(60,80,null,{band:[65,74]});msg('65 dan 74 gacha — <b>10 ta</b> son 70 ga yaxlitlanadi')},
 html:"<p>«O'nlikkacha yaxlitlanganda <b>70</b> bo'ladigan nechta son bor?» Zonani bo'yaymiz:</p>",
 btns:[["🎨 70 zonasini bo'yash",function(c,done,b){b.disabled=true;rl(60,80,null,{band:[65,74]});var X=S.X;for(var v=65;v<=74;v++)T(S.g,X(v),60,String(v-64),{'font-size':10,'font-weight':800,fill:C.ok});msg('65 dan 74 gacha — <b>10 ta</b> son 70 ga yaxlitlanadi');done()}]],
 after:"<p>Har bir o'nlikning o'z «zonasi» bor: undan 5 ta pastdan (65) 4 ta yuqorigacha (74). Jami doim <b>10 ta</b> son. 75 esa — 80 ga.</p>",
 q:{t:"Qaysi son o'nlikkacha yaxlitlanganda 60 bo'lmaydi?",opts:["58","64","65","55"],ok:2,why:"65 → 70 (birlar 5 — yuqoriga).",hint:"60 zonasi qaysi sondan qaysi songacha?",full:"60 zonasi: 55, 56, … 64. 58 → 60, 64 → 60, 55 → 60. 65 esa yuqoriga — 70 ga yaxlitlanadi."},
 tn:"Zonani lenta bilan polga belgilash mumkin: bola zonaning ichida tursa — «60», tashqarida — boshqa o'nlik."},
{h:"Taxminiy hisob (chamalash)",sum:"38 + 43 ≈ 40 + 40 = 80. Aniq javob 81 — chamalash xatoni tez topishga yordam beradi.",a:"m06",
 start:function(){est(false)},fin:function(){est(true)},
 html:"<p>Bog'dan birinchi kuni 38 ta, ikkinchi kuni 43 ta olma terildi. Taxminan qancha? Yaxlitlab hisoblaymiz:</p>",
 btns:[["≈ Yaxlitlab hisoblash",function(c,done,b){b.disabled=true;est(true);done()}]],
 after:"<p>38 ≈ 40, 43 ≈ 40, demak taxminan <b>80 ta</b>. Aniq hisob: 38 + 43 = 81 — chamalashga juda yaqin. Agar kimdir 38 + 43 = 61 deb yozsa, chamalash darhol «xato!» deydi.</p>",
 q:{t:"Do'konda 52 ta va 29 ta daftar bor. Taxminan nechta daftar bor?",opts:["taxminan 70 ta","taxminan 80 ta","taxminan 90 ta","taxminan 81 ta"],ok:1,why:"52 ≈ 50, 29 ≈ 30: 50 + 30 = 80.",hint:"Har bir sonni o'nlikkacha yaxlitlang, keyin qo'shing.",full:"52 → 50, 29 → 30. 50 + 30 = 80. «81» — aniq javob, savol taxminiyni so'rayapti."},
 tn:"Xalqaro dasturlarda chamalash (estimation) alohida mahorat sifatida o'rgatiladi. Har bir hisobdan oldin «taxminan qancha chiqadi?» deb so'rang."},
{h:"Bilasizmi?",sum:"Hayotda yaxlitlash har joyda: narx, masofa, yosh. Do'konlar narxni 9 bilan tugatib, arzonroq ko'rsatadi.",a:"m07",
 start:function(){shop()},fin:function(){shop()},
 html:"<p>🛒 Do'konda narx ko'pincha <b>9 990 so'm</b> yoki <b>19 990 so'm</b> deb yoziladi. Nega 10 000 emas? Chunki odam birinchi raqamga qarab «9 ming» deb o'ylaydi — aslida bu deyarli <b>10 000</b>! Yaxlitlashni biladigan xaridor aldanmaydi.</p><p>📏 «Maktabgacha 1 km», «bu yerda 100 ga yaqin odam» — bular ham yaxlitlangan sonlar.</p>",
 tn:"Bolalardan uydagi narxlarni yozib kelib, ularni yaxlitlashni so'rang."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){rl(40,50,47,{dist:1})},fin:function(){rl(40,50,47,{dist:1})},
 html:"<div class='memo'><ul><li>Yaxlitlash — eng <b>yaqin o'nlikni</b> topish: 47 → 50, 43 → 40.</li><li>Birlar <b>0–4</b> → pastga (72 → 70). Birlar <b>5–9</b> → yuqoriga (46 → 50).</li><li>Birlar 5 bo'lsa — doim <b>yuqoriga</b>: 45 → 50.</li><li>Birlarni shunchaki tashlab yubormang: 46 → <b>50</b>, 40 emas!</li><li>50 ga yaxlitlanadigan sonlar: <b>45 … 54</b> — 10 ta.</li><li>Chamalash: 38 + 43 ≈ 40 + 40 = <b>80</b>.</li></ul></div>",
 tn:"Keyingi darsni «Yaxlitlanganda 90 bo'ladigan eng katta son?» (94) savoli bilan boshlang."}
];
function sh1(n){rl(Math.floor(n/10)*10,Math.floor(n/10)*10+10,n,{dist:1});var lo=Math.floor(n/10)*10,hi=lo+10,r=n-lo<5?lo:hi;msg(n+': '+lo+' gacha '+(n-lo)+' qadam, '+hi+' gacha '+(hi-n)+' qadam → <b>'+r+'</b>')}
function rule3(n){clear();var g=S.g;for(var d=0;d<=9;d++){var x=24+d*35,up=d>=5;E('rect',{x:x-14,y:30,width:28,height:34,rx:8,fill:up?'#fff1e0':'#e6f6ee',stroke:up?C.a:C.ok},g);T(g,x,53,String(d),{'font-size':17,'font-weight':800,fill:up?'#b0601f':C.ok})}
 T(g,95,84,'← pastga',{'font-size':13,'font-weight':800,fill:C.ok});T(g,265,84,'yuqoriga →',{'font-size':13,'font-weight':800,fill:'#b0601f'});
 if(n==null){msg('Sonni tanlang');return}var u=n%10,r=u<5?n-u:n-u+10;E('rect',{x:24+u*35-17,y:27,width:34,height:40,rx:9,fill:'none',stroke:C.blue,'stroke-width':3},g);
 T(g,180,130,n+'  →  '+r,{'font-size':30,'font-weight':800,fill:C.blue});msg('Birlar <b>'+u+'</b> — '+(u<5?'pastga: '+r:'yuqoriga: '+r))}
function est(on){clear();var g=S.g;T(g,180,50,'38 + 43',{'font-size':28,'font-weight':800,fill:'#1d2b3a'});if(!on){msg('Taxminan qancha?');return}
 T(g,180,90,'≈ 40 + 40 = 80',{'font-size':24,'font-weight':800,fill:C.blue});T(g,180,132,'aniq: 81',{'font-size':18,'font-weight':700,fill:C.ok});msg('Chamalash: <b>80</b>, aniq javob: 81')}
function shop(){clear();var g=S.g;E('rect',{x:110,y:30,width:140,height:90,rx:12,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},g);T(g,180,62,'Narx:',{'font-size':13,fill:'#5b6b7b'});T(g,180,96,'9 990 so‘m',{'font-size':24,'font-weight':800,fill:C.bad});T(g,180,150,'≈ 10 000 so‘m',{'font-size':18,'font-weight':800,fill:C.ok});msg('9 990 — deyarli 10 000!')}
var PROBS=[
{t:"47 ni o'nlikkacha yaxlitlang.",o:["50","40","45","47"],k:0,s:"Birlar 7 — yuqoriga: 50."},
{t:"62 ni o'nlikkacha yaxlitlang.",o:["60","70","65","62"],k:0,s:"Birlar 2 — pastga: 60."},
{t:"85 ni o'nlikkacha yaxlitlang.",o:["90","80","85","100"],k:0,s:"Birlar 5 — yuqoriga: 90."},
{t:"O'nlikkacha yaxlitlanganda 50 bo'ladigan sonlardan eng kattasi qaysi?",o:["54","49","55","59"],k:0,s:"55 → 60 bo'ladi. Eng kattasi 54."},
{t:"O'nlikkacha yaxlitlanganda 70 bo'ladigan nechta son bor?",o:["10","5","9","11"],k:0,s:"65 dan 74 gacha — 10 ta."},
{t:"O'nlikkacha yaxlitlanganda 30 bo'ladigan eng kichik son qaysi?",o:["25","26","30","21"],k:0,s:"25 → 30, 24 → 20."},
{t:"Bog'dan 38 ta va 43 ta olma terildi. Yaxlitlab hisoblasak, taxminan nechta?",o:["taxminan 80 ta","taxminan 70 ta","taxminan 90 ta","taxminan 81 ta"],k:0,s:"40 + 40 = 80."},
{t:"Qaysi son o'nlikkacha yaxlitlanganda 60 bo'lmaydi?",o:["65","58","64","55"],k:0,s:"65 → 70."},
{t:"Ali 46 ni o'nlikkacha yaxlitlab 40 deb yozdi. To'g'rimi?",o:["Yo'q, 50 bo'ladi","Ha, to'g'ri","Yo'q, 47 bo'ladi","Yo'q, 45 bo'ladi"],k:0,s:"Birlar 6 — yuqoriga: 50."},
{t:"Qaysi ikki son o'nlikkacha yaxlitlanganda bir xil son bo'ladi?",o:["36 va 44","34 va 36","25 va 24","56 va 45"],k:0,s:"36 → 40, 44 → 40. 34 → 30, 36 → 40; 25 → 30, 24 → 20; 56 → 60, 45 → 50."},
{t:"O'nlikkacha yaxlitlanganda 90 bo'ladigan eng katta son qaysi?",o:["94","95","99","89"],k:0,s:"95 → 100. Eng kattasi 94."},
{t:"9 ni o'nlikkacha yaxlitlang.",o:["10","0","9","5"],k:0,s:"9 — 0 va 10 orasida, 10 ga yaqin."},
{t:"96 ni o'nlikkacha yaxlitlang.",o:["100","90","95","96"],k:0,s:"Birlar 6 — yuqoriga: 100."},
{t:"Sardor 3 ta 19 so'mlik qalam oldi. Yaxlitlab hisoblasak, taxminan qancha to'ladi?",o:["taxminan 60 so'm","taxminan 30 so'm","taxminan 57 so'm","taxminan 50 so'm"],k:0,s:"19 ≈ 20, 20 + 20 + 20 = 60."},
{t:"Son o'nlikkacha yaxlitlanganda 40 bo'ldi. U qaysi son bo'lishi mumkin emas?",o:["46","38","44","35"],k:0,s:"40 zonasi: 35…44. 46 → 50."},
{t:"Birlar raqami nechta bo'lsa, son pastga yaxlitlanadi?",o:["0, 1, 2, 3, 4","5, 6, 7, 8, 9","faqat 0","faqat 4"],k:0,s:"0–4 — pastga, 5–9 — yuqoriga."},
{t:"Ikki xonali son o'nlikkacha yaxlitlanganda 20 bo'ldi. Raqamlari yig'indisi 7. Bu qaysi son?",o:["16","25","34","61"],k:0,s:"20 zonasi: 15…24. Raqamlar yig'indisi 7: 16 (1 + 6). 25 → 30, 34 → 30."},
{t:"72 + 19 ni chamalang (o'nlikkacha yaxlitlab).",o:["90","80","91","100"],k:0,s:"72 ≈ 70, 19 ≈ 20: 90. (Aniq: 91.)"},
{t:"O'nlikkacha yaxlitlanganda 60 bo'ladigan juft sonlar nechta?",o:["5","10","4","6"],k:0,s:"60 zonasi 55…64: juftlar 56, 58, 60, 62, 64 — 5 ta."},
{t:"Qaysi son 50 ga eng yaqin?",o:["48","44","55","57"],k:0,s:"48 dan 50 gacha 2 qadam — eng kam."}
];
function PRACT_STAGE(){rl(40,50,47,{dist:1})}
var PREP_DATA={teach:["Yaxlitlash — eng yaqin o'nlikni topish (son o'qida).","«Tepalik» tasviri va qoida: 0–4 pastga, 5–9 yuqoriga.","Teskari savollar: qaysi sonlar 50 ga yaxlitlanadi, nechta son.","Chamalash: 38 + 43 ≈ 80."],
 mist:["Birlarni shunchaki tashlab yuboradi (46 → 40).","45 ni 40 ga yaxlitlaydi.","«50 bo'ladigan eng katta son» ga 55 yoki 59 deydi.","Taxminiy va aniq javobni chalkashtiradi."],
 need:["Doskada son o'qi 40–60.","Yarim aylana «tepalik» rasmi."],
 board:["Son o'qi: <span class='w2'>40 · · · 47 · · 50</span> — 7 va 3 qadam.","Tepalik: 41–44 ← 45 → 46–49.","<span class='w2'>0 1 2 3 4 | 5 6 7 8 9</span> — pastga | yuqoriga.","50 zonasi: <span class='w2'>45 … 54</span>.","<span class='w2'>38 + 43 ≈ 40 + 40 = 80</span>."]};
