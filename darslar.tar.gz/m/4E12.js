var CODE='4E12',TITLE='4-sinf · Ekologik va amaliy masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// ---------- 4E: yo'l (harakat) chizmasi ----------
// f: {t, L (yo'l uzunligi), y, marks:[[pos,label]], obj:[{p,ic,lab,col}], seg:[{a,b,lab,col,up}], calc, note}
function e4road(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,x0=24,x1=336,y=f.y||104,L=f.L||100,k=(x1-x0)/L;function X(p){return x0+p*k}
 E('rect',{x:x0-6,y:y-7,width:x1-x0+12,height:14,rx:7,fill:f.water?'#cfe7fb':'#e7e2d8',stroke:f.water?'#6aa9de':'#b9b0a0'},g);
 if(f.water){for(var i=0;i<5;i++){var xx=x0+30+i*62;E('path',{d:'M'+xx+' '+y+' l14 0 m-5 -4 l5 4 l-5 4',stroke:'#3b82c4','stroke-width':1.6,fill:'none'},g)}}
 (f.marks||[]).forEach(function(m){E('line',{x1:X(m[0]),y1:y-9,x2:X(m[0]),y2:y+9,stroke:'#556',"stroke-width":1.5},g);T(g,X(m[0]),y+24,m[1],{'font-size':11,'font-weight':700,fill:'#33475b'})});
 (f.seg||[]).forEach(function(s){var a=X(s.a),b=X(s.b),yy=s.up?y-22-(s.lv||0)*18:y+36+(s.lv||0)*18;E('line',{x1:a,y1:yy,x2:b,y2:yy,stroke:s.col||C.blue,'stroke-width':3},g);
  E('path',{d:'M'+b+' '+yy+' l'+(b>a?-7:7)+' -5 l0 10 z',fill:s.col||C.blue},g);if(s.lab)T(g,(a+b)/2,yy+(s.up?-5:15),s.lab,{'font-size':11,'font-weight':800,fill:s.col||C.blue})});
 (f.obj||[]).forEach(function(o){var x=X(o.p);T(g,x,y-12,o.ic||'🚗',{'font-size':20,'nofr':1});if(o.lab)T(g,x,y-34,o.lab,{'font-size':11,'font-weight':800,fill:o.col||'#1d2b3a'})})}
// ko'p kadrli qadam (bar yoki yo'l chizmasi)
function e4fr(f){(f.head?e4tab:f.road?e4road:bmDraw)(f)}
function e4st(o){var F=o.frames,P=F.map(function(f){return function(){e4fr(f)}});o.start=function(){if(P.length>1)startPh(P);else P[0]()};o.fin=function(){S.ph=P.length-1;P[P.length-1]()};
 if(!o.btns&&!o.act){if(P.length>1)o.btns=[phaser(P)];else o.act=function(c,done){done()}}delete o.frames;return o}
function e4pk(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)e4fr(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
// jadval (masalan unum · vaqt = ish): f.head, f.rows, f.hl {r:c}
function e4tab(f){bmDraw({t:f.t,calc:f.calc,note:f.note});var g=S.g,H=f.head,R=f.rows,n=H.length,w=Math.min(96,330/n),x0=180-w*n/2,y0=f.y||(f.t?40:24),rh=Math.min(26,(150-y0)/(R.length+1));
 H.forEach(function(h,j){E('rect',{x:x0+j*w,y:y0,width:w,height:rh,fill:'#2f6fb0'},g);T(g,x0+j*w+w/2,y0+rh/2+4,h,{'font-size':11,'font-weight':800,fill:'#fff','nofr':1})});
 R.forEach(function(r,i){r.forEach(function(v,j){var hl=f.hl&&f.hl[i]===j,q=String(v)==='?';E('rect',{x:x0+j*w,y:y0+(i+1)*rh,width:w,height:rh,fill:hl?'#e6f6ee':q?'#fff4d6':'#fff',stroke:'#9fb3c8'},g);
  T(g,x0+j*w+w/2,y0+(i+1)*rh+rh/2+4,String(v),{'font-size':12,'font-weight':hl||q?800:600,fill:hl?C.ok:q?'#c98a00':'#1d2b3a'})})})}
var STEPS=[
e4st({h:"Tomchilab oqqan jo‘mrak",sum:"Kuniga 20 l. Haftada 140 l, oyda (30 kun) 600 l, yilda 20 · 365 = 7300 l.",a:"m01",
 frames:[{head:['vaqt','suv'],rows:[['1 kun','20 l'],['1 hafta','?'],['1 oy (30 kun)','?'],['1 yil (365 kun)','?']],t:'Buzuq jo‘mrak kuniga 20 l suv oqizadi. Haftada, oyda, yilda qancha?',note:'Kichik sarf — katta yo‘qotish'},
  {head:['vaqt','suv'],rows:[['1 kun','20 l'],['1 hafta','140 l'],['1 oy (30 kun)','600 l'],['1 yil (365 kun)','?']],hl:{2:1},t:'Buzuq jo‘mrak kuniga 20 l suv oqizadi. Haftada, oyda, yilda qancha?',calc:['Hafta: 20 · 7 = 140 l','Oy: 20 · 30 = 600 l']},
  {head:['vaqt','suv'],rows:[['1 kun','20 l'],['1 hafta','140 l'],['1 oy (30 kun)','600 l'],['1 yil (365 kun)','7300 l']],hl:{3:1},t:'Buzuq jo‘mrak kuniga 20 l suv oqizadi. Haftada, oyda, yilda qancha?',calc:['Yil: 20 · 365 = <b>7300</b> l','Bu 36 ta to‘la vanna (200 l dan)!']}],
 html:"<p>Tomchi — arzimas narsa. Lekin matematika boshqa gapni aytadi. Tugmani bosib, vaqtni uzaytiring.</p>",
 after:"<p>Ekologik masalalar — bu <b>sarf · vaqt</b> masalalari, faqat javob bizni o'ylantiradi. 7300 l — bir odamning 2 oylik ichimlik va yuvinish suvi. Jo'mrakni tuzatish 10 daqiqa.</p>",
 q:{t:"Tish yuvganda jo'mrak ochiq qolsa, 1 daqiqada 6 l suv oqadi. Kuniga 2 marta 3 daqiqadan. Haftada qancha suv behuda ketadi?",opts:["252 l","36 l","126 l","42 l"],ok:0,why:"6 · 3 · 2 = 36 l kuniga; 36 · 7 = 252.",hint:"Avval 1 kunlik sarf.",full:"1 marta: 6 · 3 = 18 l. Kuniga: 18 · 2 = 36 l. Haftada: 36 · 7 = 252 l. «36» — faqat 1 kun, «126» — kuniga 1 marta deb olingan."},
 tn:"Gollandiya RME: haqiqiy jo'mrak va 1 litrli idish bilan tomchini 1 daqiqa yig'ing — bolalar o'zi o'lchab, yillik hisobni chiqarsin."}),
e4st({h:"Dushmi, vannami?",sum:"Dush: 1 daqiqada 10 l, 5 daqiqa → 50 l. Vanna 150 l. Vanna 3 marta ko‘p.",a:"m02",
 frames:[{t:'Dush 1 daqiqada 10 l suv sarflaydi. 5 daqiqalik dush va 150 l li vanna — farqi?',bars:[{lab:'dush',y:46,segs:[{w:50,txt:'?',c:'q'}]},{lab:'vanna',y:98,segs:[{w:150,txt:'150 l',c:'b'}]}],max:150,note:'Tanlang:'}],
 html:"<p>Qaysi biri suvni ko'proq sarflaydi va necha marta? Tanlang:</p>",
 btns:e4pk(["Vanna, 3 marta","Vanna, 100 marta","Dush, 2 marta"],0,{t:'Dush: 10 · 5 = 50 l',bars:[{lab:'dush',y:46,segs:[{w:50,txt:'50 l',c:'g'}]},{lab:'vanna',y:98,segs:[{w:50,txt:'50',c:'b'},{w:50,txt:'50',c:'b'},{w:50,txt:'50',c:'b'}]}],max:150,calc:['Dush: 10 · 5 = 50 l','150 : 50 = <b>3</b> marta']},["","«Necha marta» — bo‘lish bilan topiladi, ayirish bilan emas: 150 − 50 = 100 l farq, lekin 3 marta.","Dush 10 l — bu 1 daqiqada. 5 daqiqa — 50 l."]),
 after:"<p>«Necha marta» — <b>bo'lish</b>, «nechaga» — <b>ayirish</b>. Vanna 100 l ko'p va 3 marta ko'p — ikkalasi ham to'g'ri, lekin har xil savolga javob. Tuzoq: 15 daqiqalik dush esa vannaga teng!</p>",
 q:{t:"Dush 1 daqiqada 10 l sarflaydi. Necha daqiqalik dush 150 l li vannaga teng bo'ladi?",opts:["15 daqiqa","10 daqiqa","5 daqiqa","1500 daqiqa"],ok:0,why:"150 : 10 = 15.",hint:"150 l ni 1 daqiqalik sarfga bo'ling.",full:"150 : 10 = 15 daqiqa. Demak uzoq dush vannadan tejamli emas. «1500» — ko'paytirilgan."},
 tn:"Oilada bir kunlik suv sarfini (dush, idish, kir) taxminan hisoblab kelish — uy vazifasi. Keyingi darsda sinf bo'yicha jadval."}),
e4st({h:"Chiqindi va kasr",sum:"Oila kuniga 2 kg chiqindi, 1/4 qismi plastik. Haftada: 2 · 7 = 14 kg; plastik 14 : 4 = 3 kg 500 g.",a:"m03",
 frames:[{t:'Oila kuniga 2 kg chiqindi chiqaradi, uning 1/4 qismi plastik. Haftada qancha plastik?',bars:[{lab:'1 kun',y:52,segs:[{w:1,txt:'plastik',c:'c'},{w:3,txt:'boshqa chiqindi',c:'x'}]}],max:4,br:[{b:0,lab:'2 kg',up:true,col:C.blue}],note:'1/4 qismi — 4 teng bo‘lakning bittasi'},
  {t:'Oila kuniga 2 kg chiqindi chiqaradi, uning 1/4 qismi plastik. Haftada qancha plastik?',bars:[{lab:'1 kun',y:40,segs:[{w:1,txt:'',c:'c'},{w:3,txt:'',c:'x'}]},{lab:'7 kun',y:92,segs:[{w:7,txt:'3,5 kg',c:'c'},{w:21,txt:'10,5 kg boshqa',c:'x'}]}],max:28,br:[{b:1,lab:'14 kg',up:false,col:C.blue}],calc:['Haftada: 2 · 7 = 14 kg','Plastik: 14 : 4 = 3 kg 500 g (yoki 500 · 7)']}],
 html:"<p>«1/4 qismi» — chiqindini 4 teng bo'lakka bo'lsak, bittasi plastik. Tugmani bosing.</p>",
 after:"<p>Ikki yo'l: avval haftalik (14 kg), keyin 1/4 (3,5 kg); yoki avval kunlik plastik (500 g), keyin · 7. Natija bir xil. Plastik tabiatda yuzlab yil chirimaydi — saralab topshirilsa, qayta ishlanadi.</p>",
 q:{t:"Maktabda kuniga 60 kg chiqindi yig'iladi, 1/3 qismi qog'oz. 5 o'quv kunida qancha qog'oz yig'iladi?",opts:["100 kg","300 kg","20 kg","180 kg"],ok:0,why:"60 : 3 = 20; 20 · 5 = 100.",hint:"Avval 1 kunlik qog'oz.",full:"Kuniga qog'oz: 60 : 3 = 20 kg. 5 kunda: 20 · 5 = 100 kg. «300» — butun chiqindi, «20» — faqat 1 kun."},
 tn:"Sinfda 1 kunlik chiqindini 3 qutiga saralang (qog'oz, plastik, boshqa) va tortib ko'ring — haqiqiy ma'lumot bilan masala tuzing."}),
e4st({h:"Qog‘oz va daraxt",sum:"1 tonna qog‘oz uchun taxminan 17 ta daraxt. Maktab yiliga 3 t qog‘oz ishlatsa — 51 ta daraxt. Yarmi qayta ishlansa — 25 ta daraxt saqlanadi.",a:"m04",
 frames:[{t:'1 tonna qog‘oz ≈ 17 ta daraxt. Maktab yiliga 3 t qog‘oz ishlatadi. Nechta daraxt?',bars:[{lab:'1 t',y:46,segs:[{w:17,txt:'17 🌳',c:'g'}]},{lab:'3 t',y:98,segs:[{w:17,txt:'17',c:'g'},{w:17,txt:'17',c:'g'},{w:17,txt:'17',c:'g'}]}],max:51,br:[{b:1,lab:'51 ta daraxt',col:C.ok}],calc:['17 · 3 = <b>51</b> ta daraxt']},
  {t:'Agar qog‘ozning yarmi qayta ishlangan bo‘lsa?',bars:[{lab:'3 t',y:60,segs:[{w:25,txt:'25 saqlandi',c:'g'},{w:26,txt:'26 kesildi',c:'x'}]}],max:51,calc:['Yarmi: 51 : 2 = 25 (qoldiq 1)','Taxminan <b>25</b> ta daraxt saqlanadi']}],
 html:"<p>Bitta daftar — arzimas. Lekin maktab bir yilda tonnalab qog'oz ishlatadi. Tugmani bosing.</p>",
 after:"<p>«Taxminan 17 daraxt» — o'rtacha baho (daraxt turi va qog'oz sifatiga bog'liq). Shuning uchun javob ham taxminiy: ≈ 51. Ekologik hisoblar ko'pincha <b>chamalash</b> — aniq son emas, lekin xulosa aniq: qayta ishlash daraxtni saqlaydi.</p>",
 q:{t:"1 t qog'oz ≈ 17 daraxt. Shahar maktablari yiliga 20 t qog'oz ishlatadi. Agar 3/4 qismi qayta ishlangan qog'ozdan bo'lsa, taxminan nechta daraxt saqlanadi?",opts:["255 ta","340 ta","85 ta","15 ta"],ok:0,why:"20 · 17 = 340; 3/4 qismi: 340 : 4 · 3 = 255.",hint:"Avval 20 t uchun daraxtlar soni.",full:"20 t → 17 · 20 = 340 daraxt. 3/4 qismi qayta ishlangan: 340 : 4 · 3 = 255 ta saqlanadi. «340» — hammasi, «85» — 1/4 qismi (kesilgani)."},
 tn:"Ikki tomonlama chop etish, qoralama uchun eski varaq — sinfda qoida qiling va yil oxirida tejalgan qog'ozni hisoblang."}),
e4st({h:"Lampochka: Vt va kVt·soat",sum:"Eski 60 Vt, yangi (LED) 10 Vt — farq 50 Vt. Kuniga 5 soat: 250 Vt·soat. 4 kunda 1000 Vt·soat = 1 kVt·soat tejaladi.",a:"m05",
 frames:[{head:['lampa','quvvat','5 soatda'],rows:[['eski','60 Vt','?'],['LED','10 Vt','?']],t:'Eski lampa 60 Vt, LED 10 Vt. Kuniga 5 soat yonadi. Kuniga qancha tejaladi?',note:'Vt·soat = quvvat · soat'},
  {head:['lampa','quvvat','5 soatda'],rows:[['eski','60 Vt','300 Vt·soat'],['LED','10 Vt','50 Vt·soat']],hl:{1:2},t:'Eski lampa 60 Vt, LED 10 Vt. Kuniga 5 soat yonadi. Kuniga qancha tejaladi?',calc:['Eski: 60 · 5 = 300, LED: 10 · 5 = 50','Tejaldi: 300 − 50 = <b>250</b> Vt·soat kuniga']},
  {head:['kun','tejaldi'],rows:[['1 kun','250 Vt·soat'],['4 kun','1 kVt·soat'],['30 kun','7,5 kVt·soat']],hl:{1:1},t:'1 kVt·soat = 1000 Vt·soat',calc:['4 kunda 250 · 4 = 1000 Vt·soat = <b>1 kVt·soat</b>','Oyda: 250 · 30 = 7500 Vt·soat = 7,5 kVt·soat — bitta lampadan!']}],
 html:"<p>Elektr hisobida «kVt·soat» (kilovatt-soat) yoziladi. 1 kVt·soat = 1000 Vt·soat. Tugmani bosing.</p>",
 after:"<p>Uyda 10 ta lampa bo'lsa — oyiga 75 kVt·soat tejaladi. Hisob: quvvat (Vt) · soat = Vt·soat; 1000 Vt·soat = 1 kVt·soat. Tuzoq: Vt·soatni kVt·soat deb yozish (1000 marta xato).</p>",
 q:{t:"Televizor 100 Vt, kuniga 4 soat yonadi. 10 kunda necha kVt·soat sarflaydi?",opts:["4 kVt·soat","400 kVt·soat","40 kVt·soat","1 kVt·soat"],ok:0,why:"100 · 4 · 10 = 4000 Vt·soat = 4 kVt·soat.",hint:"Avval Vt·soat, keyin 1000 ga bo'ling.",full:"100 · 4 = 400 Vt·soat kuniga. 10 kunda: 4000 Vt·soat = 4 kVt·soat. «400» — kVt·soatga o'tkazilmagan, «40» — 100 ga bo'lingan."},
 tn:"Uy hisoblagichini (schyotchik) rasmda ko'rsating: u kVt·soatni sanaydi. Bolalar uyidagi lampalar sonini sanab kelsin."}),
e4st({h:"Avtobus yoki 30 ta mashina?",sum:"120 kishi: avtobusda 40 tadan → 3 ta avtobus; mashinada 4 tadan → 30 ta mashina. Yo‘lda 27 ta transport kam.",a:"m06",
 frames:[{t:'120 o‘quvchi sayohatga boradi. Avtobus 40 kishi, mashina 4 kishi oladi.',bars:[{lab:'avtobus',y:46,segs:[{w:40,txt:'40',c:'g'},{w:40,txt:'40',c:'g'},{w:40,txt:'40',c:'g'}]},{lab:'mashina',y:98,segs:(function(){var s=[];for(var i=0;i<30;i++)s.push({w:4,txt:'',c:'c'});return s})()}],max:120,note:'Tanlang: nechta transport kam bo‘ladi?'}],
 html:"<p>Hamma mashinada borsa yo'l tirband bo'ladi va havo ifloslanadi. Nechta transport kam? Tanlang:</p>",
 btns:e4pk(["27 ta","10 ta","36 ta"],0,{t:'3 ta avtobus yoki 30 ta mashina',bars:[{lab:'avtobus',y:46,segs:[{w:40,txt:'1',c:'g'},{w:40,txt:'2',c:'g'},{w:40,txt:'3',c:'g'}]},{lab:'mashina',y:98,segs:(function(){var s=[];for(var i=0;i<30;i++)s.push({w:4,txt:'',c:'c'});return s})()}],max:120,br:[{b:1,lab:'30 ta mashina',col:C.bad}],calc:['Avtobus: 120 : 40 = 3 ta','Mashina: 120 : 4 = 30 ta','Farq: 30 − 3 = <b>27</b> ta kam']},["","10 — bu 40 : 4 (bitta avtobus nechta mashina o‘rnini bosadi). Jami farq so‘ralgan.","36 — bu 120 : 40 + ... tekshiring: 30 − 3."]),
 after:"<p>Bitta avtobus 10 ta mashinaning o'rnini bosadi. Jamoat transporti, velosiped, piyoda — havoni toza saqlashning matematik yo'li.</p>",
 q:{t:"Poyezd vagoniga 54 kishi sig'adi. 7 vagonli poyezddagi odamlar hammasi 6 kishilik mikroavtobuslarda borsa, nechta mikroavtobus kerak?",opts:["63 ta","9 ta","378 ta","42 ta"],ok:0,why:"54 · 7 = 378; 378 : 6 = 63.",hint:"Avval poyezddagi odamlar soni.",full:"Poyezd: 54 · 7 = 378 kishi. Mikroavtobus: 378 : 6 = 63 ta. «9» — bitta vagon uchun (54 : 6), «378» — odamlar soni."},
 tn:"Maktab oldidagi mashinalarni ertalab sanab, nechta bola piyoda yoki avtobusda kelganini so'rang — sinf diagrammasi."}),
e4st({h:"Oila byudjeti: kasr bilan",sum:"2 400 000 so‘m: oziq-ovqat 1/3 = 800 000, kommunal 1/4 = 600 000, qolgan 1 000 000.",a:"m07",
 frames:[{t:'Oila daromadi 2 400 000 so‘m. 1/3 qismi oziq-ovqatga, 1/4 qismi kommunalga. Qancha qoladi?',bars:[{lab:'daromad',y:60,segs:[{w:4,txt:'1/3',c:'a'},{w:3,txt:'1/4',c:'b'},{w:5,txt:'?',c:'q'}]}],max:12,br:[{b:0,lab:'2 400 000 so‘m',up:true,col:C.blue}],note:'1/3 va 1/4 ni alohida hisoblaymiz'},
  {t:'Oila daromadi 2 400 000 so‘m. 1/3 qismi oziq-ovqatga, 1/4 qismi kommunalga. Qancha qoladi?',bars:[{lab:'daromad',y:60,segs:[{w:4,txt:'800 000',c:'a'},{w:3,txt:'600 000',c:'b'},{w:5,txt:'1 000 000',c:'g'}]}],max:12,calc:['Oziq-ovqat: 2 400 000 : 3 = 800 000','Kommunal: 2 400 000 : 4 = 600 000','Qoldi: 2 400 000 − 1 400 000 = <b>1 000 000</b>']}],
 html:"<p>Pulni rejalashtirish — ham amaliy, ham matematik ish. Tugmani bosing.</p>",
 after:"<p>Tuzoq: 1/3 + 1/4 ni «2/7» deb qo'shish. Kasrlarni butundan alohida hisoblang: 800 000 + 600 000 = 1 400 000. Qolgan 1 000 000 — bu butunning 5/12 qismi.</p>",
 q:{t:"Sinf 360 000 so'm yig'di. 1/2 qismi sayohat chiptasiga, 1/5 qismi tushlikka. Qancha qoldi?",opts:["108 000 so'm","180 000 so'm","72 000 so'm","252 000 so'm"],ok:0,why:"180 000 + 72 000 = 252 000; 360 000 − 252 000 = 108 000.",hint:"Har kasrni alohida hisoblang.",full:"Chipta: 360 000 : 2 = 180 000. Tushlik: 360 000 : 5 = 72 000. Qoldi: 360 000 − 252 000 = 108 000 so'm. «252 000» — sarflangan pul."},
 tn:"Moliyaviy savodxonlik: bolalar 1 haftalik cho'ntak pulini qanday bo'lishini kasrlar bilan rejalashtirsin."}),
e4st({h:"Daraxt ekish: qator va nihol",sum:"28 o‘quvchi 3 tupdan: 84 tup. Qatorda 12 tup: 84 : 12 = 7 qator. Qatorlar orasi 4 m: 6 ta oraliq → 24 m.",a:"m08",
 frames:[{t:'28 o‘quvchi 3 tupdan nihol ekdi, qatorda 12 tup. Necha qator?',bars:[{lab:'nihollar',y:60,segs:(function(){var s=[];for(var i=0;i<7;i++)s.push({w:12,txt:'12',c:'g'});return s})()}],max:84,br:[{b:0,lab:'28 · 3 = 84 tup',up:true,col:C.blue}],calc:['84 : 12 = <b>7</b> qator']},
  {road:1,L:24,t:'7 qator, qatorlar orasi 4 m. Birinchidan oxirgi qatorgacha necha metr?',marks:[[0,'1'],[4,'2'],[8,'3'],[12,'4'],[16,'5'],[20,'6'],[24,'7']],obj:[{p:0,ic:'🌱'},{p:4,ic:'🌱'},{p:8,ic:'🌱'},{p:12,ic:'🌱'},{p:16,ic:'🌱'},{p:20,ic:'🌱'},{p:24,ic:'🌱'}],seg:[{a:0,b:24,lab:'6 oraliq · 4 m = 24 m',col:C.ok}],calc:['7 qator orasida <b>6</b> ta oraliq (7 emas!)','6 · 4 = <b>24</b> m']}],
 html:"<p>Ko'kalamzorlashtirish ham hisob talab qiladi. Tugmani bosing.</p>",
 after:"<p>Klassik tuzoq: 7 qator — <b>6</b> ta oraliq. Ustunlar, daraxtlar, qadamlar — har doim oraliq bittaga kam (agar doira bo'lmasa).</p>",
 q:{t:"Yo'l bo'yiga 5 m oraliqda 21 ta daraxt ekildi (ikki chetida ham bor). Yo'l uzunligi?",opts:["100 m","105 m","110 m","95 m"],ok:0,why:"20 oraliq · 5 = 100.",hint:"21 ta daraxt — nechta oraliq?",full:"21 daraxt orasida 20 ta oraliq. 20 · 5 = 100 m. «105» — 21 · 5 (oraliq daraxt soniga teng deb olingan)."},
 tn:"Hovlida bolalarni qatorga turg'izing: 5 bola — 4 oraliq. Tanasi bilan his qilgan narsa esda qoladi."}),
e4st({h:"Bilasizmi? Alyuminiy banka",sum:"Alyuminiyni cheksiz qayta ishlash mumkin. Qayta ishlangan alyuminiy yangisini rudadan olishdan ~95% kam energiya talab qiladi.",a:"m09",
 frames:[{t:'Bitta banka qayta ishlash — energiya tejash',bars:[{lab:'yangi',y:46,segs:[{w:100,txt:'100 birlik energiya',c:'x'}]},{lab:'qayta',y:98,segs:[{w:5,txt:'',c:'g'}]}],max:100,txt:[[106,116,'5 birlik',{'text-anchor':'start',fill:C.ok}]],note:'Tejaldi: 100 − 5 = 95 birlik (taxminan 95%)'}],
 html:"<p>♻️ <b>Alyuminiy</b> — sifatini yo'qotmasdan <b>cheksiz</b> marta qayta ishlanadigan material. Bankani eritib yangi banka yasash, rudadan yangi alyuminiy olishga qaraganda taxminan <b>95% kam</b> energiya talab qiladi: 20 ta qayta ishlangan banka energiyasi — 1 ta yangi banka energiyasi. Shuning uchun dunyoda alyuminiy bankalar eng ko'p yig'iladigan chiqindi turi.</p>",
 after:"<p>Hisoblab ko'ring: sinf oyiga 100 ta banka topshirsa, u 95 ta yangi banka energiyasini tejaydi. Yilda — 1140 ta!</p>",
 tn:"Sinfda alyuminiy va plastik uchun alohida quti qo'ying. Oy oxirida sanab, diagramma chizing (4-sinf «Ma'lumotlar» mavzusi bilan bog'lanish)."}),
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){e4tab({head:['sarf','vaqt','jami'],rows:[['20 l/kun','365 kun','7300 l'],['250 Vt·soat','4 kun','1 kVt·soat']],t:'Kichik sarf · uzoq vaqt = katta son',note:'Necha marta — bo‘lish; nechaga — ayirish; 1/n qismi — n ga bo‘lish'})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Ekologik masala = <b>sarf · vaqt</b>: kichik sarf uzoq vaqtda katta songa aylanadi.</li><li>«Necha marta» — <b>bo'lish</b>; «nechaga ko'p» — <b>ayirish</b>.</li><li>«1/n qismi» — butunni n ga bo'ling; bir nechta kasr bo'lsa, har birini <b>alohida</b> hisoblang.</li><li>Elektr: Vt · soat = Vt·soat; <b>1000 Vt·soat = 1 kVt·soat</b>.</li><li>Qatorlar va daraxtlar: oraliq soni = soni − 1.</li><li>«Taxminan» bo'lsa — javob ham taxminiy, xulosa esa aniq.</li></ul></div>",
 tn:"Loyiha: «Bizning sinf 1 oyda qancha suv, qog'oz va elektr tejashi mumkin?» — bolalar o'zi o'lchab, hisoblab, plakat qilsin."}
];
var PROBS=[
{t:"Buzuq jo'mrak kuniga 20 l suv oqizadi. Bir oyda (30 kun) qancha?",o:["600 l","50 l","140 l","7300 l"],k:0,s:"20 · 30 = 600."},
{t:"Buzuq jo'mrak kuniga 20 l oqizadi. Yilda (365 kun) qancha?",o:["7300 l","385 l","6000 l","730 l"],k:0,s:"20 · 365 = 7300."},
{t:"Dush 1 daqiqada 10 l sarflaydi. 5 daqiqalik dush va 150 l li vanna: vanna necha marta ko'p?",o:["3 marta","100 marta","15 marta","2 marta"],k:0,s:"150 : 50 = 3."},
{t:"Oila kuniga 2 kg chiqindi chiqaradi, 1/4 qismi plastik. Haftada qancha plastik?",o:["3 kg 500 g","14 kg","500 g","7 kg"],k:0,s:"14 : 4 = 3,5 kg."},
{t:"1 t qog'oz ≈ 17 daraxt. Maktab yiliga 3 t qog'oz ishlatadi. Taxminan nechta daraxt?",o:["51 ta","20 ta","34 ta","170 ta"],k:0,s:"17 · 3 = 51."},
{t:"Eski lampa 60 Vt, LED 10 Vt, kuniga 5 soat. Kuniga qancha tejaladi?",o:["250 Vt·soat","50 Vt·soat","300 Vt·soat","350 Vt·soat"],k:0,s:"(60 − 10) · 5 = 250."},
{t:"Televizor 100 Vt, kuniga 4 soat. 10 kunda necha kVt·soat?",o:["4 kVt·soat","400 kVt·soat","40 kVt·soat","1 kVt·soat"],k:0,s:"4000 Vt·soat = 4 kVt·soat."},
{t:"120 o'quvchi: avtobus 40 kishi, mashina 4 kishi oladi. Avtobusda borsa nechta transport kam bo'ladi?",o:["27 ta","10 ta","30 ta","3 ta"],k:0,s:"30 − 3 = 27."},
{t:"Oila daromadi 2 400 000 so'm. 1/3 qismi oziq-ovqat, 1/4 qismi kommunal. Qancha qoladi?",o:["1 000 000 so'm","1 400 000 so'm","800 000 so'm","600 000 so'm"],k:0,s:"2 400 000 − 800 000 − 600 000 = 1 000 000."},
{t:"28 o'quvchi 3 tupdan nihol ekdi, qatorda 12 tup. Necha qator?",o:["7 qator","84 qator","9 qator","6 qator"],k:0,s:"84 : 12 = 7."},
{t:"Yo'l bo'yiga 5 m oraliqda 21 ta daraxt ekildi (ikki chetida ham bor). Yo'l uzunligi?",o:["100 m","105 m","110 m","95 m"],k:0,s:"20 · 5 = 100."},
{t:"Tish yuvganda jo'mrak 3 daqiqa ochiq qoladi (daqiqasiga 6 l), kuniga 2 marta. Haftada qancha behuda ketadi?",o:["252 l","36 l","126 l","42 l"],k:0,s:"6 · 3 · 2 · 7 = 252."},
{t:"Maktabda kuniga 60 kg chiqindi, 1/3 qismi qog'oz. 5 kunda qancha qog'oz?",o:["100 kg","300 kg","20 kg","180 kg"],k:0,s:"20 · 5 = 100."},
{t:"Sinf 360 000 so'm yig'di. 1/2 qismi chipta, 1/5 qismi tushlik. Qoldi?",o:["108 000 so'm","180 000 so'm","72 000 so'm","252 000 so'm"],k:0,s:"360 000 − 180 000 − 72 000 = 108 000."},
{t:"Poyezd vagonida 54 kishi, 7 vagon. Hammasi 6 kishilik mikroavtobusda borsa, nechta kerak?",o:["63 ta","9 ta","378 ta","42 ta"],k:0,s:"378 : 6 = 63."},
{t:"Bir odam kuniga 2 l suv ichadi. 4 kishilik oila yilda (365 kun) necha litr ichadi?",o:["2920 l","730 l","1460 l","2900 l"],k:0,s:"2 · 4 · 365 = 2920."},
{t:"Kir yuvish mashinasi 1 yuvishda 50 l suv sarflaydi. Oila haftada 3 marta yuvadi. Yilda (52 hafta) qancha suv?",o:["7800 l","150 l","2600 l","5200 l"],k:0,s:"50 · 3 · 52 = 7800."},
{t:"Alyuminiy bankani qayta ishlash yangisidan 95% kam energiya oladi (yangi = 100 birlik). 400 ta banka qayta ishlansa, qancha energiya tejaladi?",o:["38 000 birlik","2 000 birlik","40 000 birlik","380 birlik"],k:0,s:"95 · 400 = 38 000."},
{t:"Maktab 10 ta eski lampani (60 Vt) LED (10 Vt) ga almashtirdi. Har biri kuniga 6 soat yonadi. 30 kunda necha kVt·soat tejaladi?",o:["90 kVt·soat","9 kVt·soat","900 kVt·soat","108 kVt·soat"],k:0,s:"50 · 6 · 10 · 30 = 90 000 Vt·soat = 90."},
{t:"Shahar kuniga 300 t chiqindi chiqaradi. 2/5 qismi qayta ishlanadi, qolgani poligonga ketadi. Haftada poligonga necha tonna?",o:["1260 t","840 t","180 t","2100 t"],k:0,s:"Qayta: 300 : 5 · 2 = 120; poligon 180 t kuniga; 180 · 7 = 1260."}
];
function PRACT_STAGE(){e4tab({head:['sarf','· vaqt','= jami'],rows:[['?','?','?']],t:'Kichik sarf · uzoq vaqt = katta son',note:'Necha marta — bo‘lish; 1/n qismi — n ga bo‘lish; 1 kVt·soat = 1000 Vt·soat'})}
var PREP_DATA={teach:["Sarf · vaqt — kundan haftaga, oyga, yilga.","Necha marta (bo'lish) va nechaga (ayirish) farqi.","Kasr qismi: 1/3, 1/4 — alohida hisoblash.","Elektr: Vt, Vt·soat, kVt·soat.","Oraliqlar soni = soni − 1; taxminiy ma'lumot bilan ishlash."],
 mist:["«Necha marta» ni ayirish bilan topadi.","1/3 + 1/4 ni 2/7 deb qo'shadi.","Vt·soatni kVt·soat deb yozadi.","21 daraxt — 21 oraliq deb oladi.","Faqat 1 kunlik sarfni javob qiladi."],
 need:["1 litrli idish va soat (jo'mrak tajribasi).","3 ta quti: qog'oz, plastik, boshqa.","Elektr hisoblagich rasmi (kVt·soat)."],
 board:["<span class='w2'>20 · 365 = 7300</span> l.","<span class='w2'>150 : 50 = 3</span> marta, <span class='w2'>150 − 50 = 100</span> l.","<span class='w2'>(60 − 10) · 5 = 250</span>; <span class='w2'>250 · 4 = 1000 = 1 kVt·soat</span>.","<span class='w2'>21 daraxt → 20 oraliq · 5 = 100</span> m."]};
