var CODE='2B10',TITLE='2-sinf · Ustun ko‘rinishida qo‘shish va ayirish';
function b10Ph(a,b,op,msgs){var n=Math.max(String(a).length,String(b).length,String(op==='+'?a+b:a-b).length),P=[function(){bqCol(a,b,op,0,{hl:0});bqMsg(msgs[0])}];for(var k=1;k<=n;k++)(function(k){P.push(function(){bqCol(a,b,op,k,{hl:k<n?k:null});bqMsg(msgs[k]||'')})})(k);return P}
var P2=b10Ph(34,25,'+',['Birliklardan boshlaymiz (o‘ngdan)','Birliklar: 4 + 5 = <b>9</b>','O‘nliklar: 3 + 2 = <b>5</b>. Javob: <b>59</b>']);
var P3=b10Ph(47,38,'+',['47 + 38. Birliklardan boshlaymiz','Birliklar: 7 + 8 = 15. <b>5</b> yozamiz, <b>1 o‘nlik</b>ni o‘nliklar ustiga eslab qo‘yamiz','O‘nliklar: 4 + 3 + <b>1</b> = 8. Javob: <b>85</b>']);
var P4=b10Ph(68,25,'−',['68 − 25. Birliklardan','Birliklar: 8 − 5 = <b>3</b>','O‘nliklar: 6 − 2 = <b>4</b>. Javob: <b>43</b>']);
var P5=b10Ph(63,28,'−',['63 − 28. Birliklar: 3 dan 8 ni ayirib bo‘lmaydi!','O‘nliklardan <b>1 o‘nlik</b> olamiz: 13 − 8 = <b>5</b>. O‘nliklarda endi 5 ta qoldi (nuqta)','O‘nliklar: 5 − 2 = <b>3</b>. Javob: <b>35</b>']);
var P6=b10Ph(70,26,'−',['70 − 26. Birliklarda 0 — undan 6 ni ayirib bo‘lmaydi','1 o‘nlikni olamiz: 10 − 6 = <b>4</b>. O‘nliklarda 6 ta qoldi','O‘nliklar: 6 − 2 = <b>4</b>. Javob: <b>44</b>']);
var P1=[function(){b10Bad();bqMsg('Raqamlar xonasi bo‘yicha ostma-ost yozilmasa…')},function(){bqCol(34,25,'+',null);bqMsg('To‘g‘ri: birlik ostida birlik, o‘nlik ostida o‘nlik')}];
function b10Bad(){clear();var g=S.g;T(g,120,40,'Noto‘g‘ri',{'font-size':12,'font-weight':800,fill:C.bad});T(g,140,76,'34',{'font-size':24,'font-weight':800,'font-family':'ui-monospace,monospace'});T(g,112,108,'+ 5',{'font-size':24,'font-weight':800,'font-family':'ui-monospace,monospace'});E('line',{x1:90,y1:116,x2:160,y2:116,stroke:'#33475b','stroke-width':2.5},g);T(g,140,146,'84 ✗',{'font-size':24,'font-weight':800,fill:C.bad,'font-family':'ui-monospace,monospace'});
 T(g,260,40,'To‘g‘ri',{'font-size':12,'font-weight':800,fill:C.ok});T(g,260,76,'34',{'font-size':24,'font-weight':800,'font-family':'ui-monospace,monospace'});T(g,262,108,'+  5',{'font-size':24,'font-weight':800,'font-family':'ui-monospace,monospace'});E('line',{x1:220,y1:116,x2:290,y2:116,stroke:'#33475b','stroke-width':2.5},g);T(g,260,146,'39 ✓',{'font-size':24,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,monospace'})}
var P7=[function(){b10Miss(0);bqMsg('3□ + □5 = 82. Ikkita raqam o‘chib ketgan')},
 function(){b10Miss(1);bqMsg('Birliklar: □ + 5 ning oxiri 2 bo‘lishi kerak → □ + 5 = 12 → □ = <b>7</b> (1 o‘nlik eslab)')},
 function(){b10Miss(2);bqMsg('O‘nliklar: 3 + □ + 1 = 8 → □ = <b>4</b>. Tekshiramiz: 37 + 45 = 82 ✓')}];
function b10Miss(k){clear();var g=S.g,x=210,mono={'font-size':26,'font-weight':800,'font-family':'ui-monospace,monospace'};
 T(g,x-20,60,'3',mono);T(g,x+20,60,k>=1?'7':'□',Object.assign({},mono,{fill:k>=1?C.ok:C.bad}));T(g,x-20,96,k>=2?'4':'□',Object.assign({},mono,{fill:k>=2?C.ok:C.bad}));T(g,x+20,96,'5',mono);T(g,x-56,96,'+',Object.assign({},mono,{fill:C.blue}));
 E('line',{x1:x-70,y1:106,x2:x+40,y2:106,stroke:'#33475b','stroke-width':2.5},g);T(g,x-20,138,'8',Object.assign({},mono,{fill:C.ok}));T(g,x+20,138,'2',Object.assign({},mono,{fill:C.ok}));if(k>=1)T(g,x-20,30,'1',{'font-size':13,'font-weight':800,fill:C.bad})}
var STEPS=[
{h:"Ostma-ost — xona ostida xona",sum:"Ustunda birlik birlik ostiga, o'nlik o'nlik ostiga yoziladi: 34 + 5 = 39, 84 emas.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>Katta sonlarni qo'shish-ayirishda ularni <b>ustun</b> qilib yozamiz. Lekin qanday? Ikki yozuvni solishtiring:</p>",
 btns:[phaser(P1)],
 after:"<p>Eng muhim qoida: <b>birliklar — birliklar ostida, o'nliklar — o'nliklar ostida</b>. 5 — bu 5 ta birlik, uni o'nliklar ostiga yozsak 50 bo'lib qoladi!</p>",
 q:{t:"52 + 7 ni ustunda yozganda 7 qayerga yoziladi?",opts:["5 ning ostiga","2 ning ostiga","ikkalasining o'rtasiga","52 ning chap tomoniga"],ok:1,why:"7 — birlik, u birliklar (2) ostida turadi.",hint:"7 qaysi xonada — birliklarmi yoki o'nliklarmi?",full:"7 bir xonali son, ya'ni 7 ta birlik. U 52 ning birliklari (2) ostiga yoziladi: 52 + 7 = 59. 5 ostiga yozilsa 52 + 70 bo'lib qoladi."},
 tn:"Katakli daftarda har raqam alohida katakka yoziladi. Ustunlarni rangli qalam bilan ajratib qo'ying: birliklar — yashil, o'nliklar — sariq."},
{h:"O'nlikdan o'tmay qo'shish",sum:"34 + 25: birliklar 4 + 5 = 9, o'nliklar 3 + 2 = 5 → 59.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=P2.length-1;P2[P2.length-1]()},
 html:"<p>Ustunda <b>o'ngdan chapga</b> — birliklardan boshlab hisoblaymiz. Tugmani bosib, har xonani kuzating:</p>",
 btns:[phaser(P2,'▶ Keyingi xona')],
 after:"<p>Nega birliklardan boshlaymiz? Chunki birliklar 10 dan oshsa, o'nlikka «ko'chadi» — buni keyingi qadamda ko'rasiz.</p>",
 q:{t:"52 + 36 = ? (ustunda)",opts:["88","98","78","816"],ok:0,why:"2 + 6 = 8, 5 + 3 = 8.",hint:"Birliklar: 2 + 6. O'nliklar: 5 + 3.",full:"Birliklar: 2 + 6 = 8. O'nliklar: 5 + 3 = 8. Javob: 88. «816» — xonalarni alohida yozib yuborish xatosi."},
 tn:"Bolalar har xona hisobini ovoz chiqarib aytsin: «birliklar: ikki qo'shuv olti — sakkiz»."},
{h:"O'nlikdan o'tib qo'shish",sum:"47 + 38: 7 + 8 = 15 — 5 yoziladi, 1 eslab qolinadi; 4 + 3 + 1 = 8 → 85.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=P3.length-1;P3[P3.length-1]()},
 html:"<p>47 + 38. Birliklar qo'shilganda 10 dan oshib ketadi. Nima qilamiz?</p>",
 btns:[phaser(P3,'▶ Keyingi xona')],
 after:"<p>15 ta birlik — bu 1 o'nlik va 5 birlik. <b>5</b> birliklar ostiga yoziladi, <b>1 o'nlik</b> o'nliklar ustiga kichik qilib yoziladi va o'nliklarni qo'shganda qo'shiladi. Bu <b>1</b> ni unutish — eng ko'p xato!</p>",
 q:{t:"56 + 35 = ? (ustunda)",opts:["81","91","811","92"],ok:1,why:"6 + 5 = 11: 1 yozamiz, 1 eslab; 5 + 3 + 1 = 9.",hint:"Birliklar 11 bo'ldi. Bir o'nlikni qayerga qo'yasiz?",full:"Birliklar: 6 + 5 = 11 — 1 yoziladi, 1 o'nlik eslab qolinadi. O'nliklar: 5 + 3 + 1 = 9. Javob: 91. «81» — eslab qolgan 1 unutilgan."},
 tn:"Eslab qolinadigan 1 ni har doim o'nliklar ustiga qizil rangda yozdiring — ko'z unutmaydi."},
{h:"O'nlikdan o'tmay ayirish",sum:"68 − 25: 8 − 5 = 3, 6 − 2 = 4 → 43.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=P4.length-1;P4[P4.length-1]()},
 html:"<p>Ayirishda ham xuddi shunday — birliklardan boshlaymiz:</p>",
 btns:[phaser(P4,'▶ Keyingi xona')],
 after:"<p>Har xonada <b>yuqoridagidan pastdagini</b> ayiramiz. Kamayuvchi doim tepada yoziladi.</p>",
 q:{t:"79 − 46 = ? (ustunda)",opts:["33","43","32","125"],ok:0,why:"9 − 6 = 3, 7 − 4 = 3.",hint:"Birliklar: 9 − 6. O'nliklar: 7 − 4.",full:"9 − 6 = 3, 7 − 4 = 3 → 33. «125» — qo'shib yuborilgan."},
 tn:"Ayirishda kamayuvchi doim tepada — bolalarga «katta son — tomda» deb eslating."},
{h:"O'nlikdan o'tib ayirish",sum:"63 − 28: 3 dan 8 ayirilmaydi → 1 o'nlik «qarz»: 13 − 8 = 5; 5 − 2 = 3 → 35.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=P5.length-1;P5[P5.length-1]()},
 html:"<p>63 − 28. Birliklarda 3 dan 8 ni ayirib bo'lmaydi. Qo'shni xonadan yordam so'raymiz:</p>",
 btns:[phaser(P5,'▶ Keyingi xona')],
 after:"<p>O'nliklardan <b>1 o'nlik</b> olib, uni 10 ta birlikka aylantiramiz: 3 + 10 = 13. 13 − 8 = 5. O'nliklarda endi <b>bitta kam</b> — 5 ta (ustiga nuqta qo'yamiz). 5 − 2 = 3. Javob: <b>35</b>.</p>",
 q:{t:"72 − 29 = ? (ustunda)",opts:["57","43","53","47"],ok:1,why:"12 − 9 = 3, 6 − 2 = 4 → 43.",hint:"Birliklarda 2 dan 9 ayirilmaydi. O'nlikdan qarz oling.",full:"12 − 9 = 3 (1 o'nlik olindi), o'nliklar: 6 − 2 = 4. Javob: 43. «57» — kichik raqamdan kattasini teskari ayirish xatosi (9 − 2 = 7)."},
 tn:"Eng ko'p xato: «3 dan 8 ayirilmaydi — 8 dan 3 ni ayiraman» (javob 45). O'nlik bloklar bilan qarz olishni qo'lda ko'rsating."},
{h:"Tuzoq: nol bilan tugagan son",sum:"70 − 26: 0 dan 6 ayirilmaydi → 10 − 6 = 4; 6 − 2 = 4 → 44.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=P6.length-1;P6[P6.length-1]()},
 html:"<p>70 − 26. Birliklarda <b>0</b>. Ko'pchilik «0 − 6 = 6» deb yozadi. Kuzating:</p>",
 btns:[phaser(P6,'▶ Keyingi xona')],
 after:"<p>0 dan hech narsa ayirib bo'lmaydi — o'nlikdan qarz olamiz: 10 − 6 = 4. O'nliklarda 6 qoladi: 6 − 2 = 4. Javob: <b>44</b>, «56» emas.</p>",
 q:{t:"80 − 37 = ? (ustunda)",opts:["57","43","53","47"],ok:1,why:"10 − 7 = 3, 7 − 3 = 4 → 43.",hint:"Birliklarda 0. O'nlikdan qarz oling.",full:"0 dan 7 ayirilmaydi → 10 − 7 = 3, o'nliklarda 7 qoldi: 7 − 3 = 4. Javob: 43. «57» — 7 − 0 = 7 deb teskari ayirish."},
 tn:"Qarz olishni «qo'shnidan bitta o'nlik so'radik» o'yini bilan ko'rsating."},
{h:"Tuzoq: o'chgan raqamlar",sum:"3□ + □5 = 82: birliklar □ + 5 = 12 → 7; o'nliklar 3 + □ + 1 = 8 → 4. 37 + 45 = 82.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Olimpiada savoli: ustunda ikkita raqam o'chib ketgan. Ularni topamiz — xona-xona:</p>",
 btns:[phaser(P7,'▶ Keyingi xona')],
 after:"<p>Kalit: birliklardan boshlab, <b>eslab qolingan 1</b> ni ham hisobga olish. Oxirida albatta tekshiring.</p>",
 q:{t:"4□ + 3□ = 84, ikkala □ da bir xil raqam. Qaysi raqam?",opts:["2","7","4","8"],ok:1,why:"47 + 37 = 84.",hint:"□ + □ ning oxiri 4 bo'lishi kerak: □ = 2 yoki 7. Ikkalasini sinab ko'ring.",full:"□ = 2: 42 + 32 = 74 ✗. □ = 7: birliklar 7 + 7 = 14 (4 yoziladi, 1 eslab), o'nliklar 4 + 3 + 1 = 8 → 84 ✓. «2» — eslab qolinadigan 1 ni hisobga olmaslik xatosi."},
 tn:"Bunday jumboqlarni bolalar o'zi tuzib, bir-biriga bersin."},
{h:"Bilasizmi? Ustun usulining tarixi",sum:"Ustunda yozma hisoblash hind raqamlari bilan birga al-Xorazmiyning arifmetika kitobi orqali Yevropaga tarqalgan.",a:"m08",
 start:function(){bqCol(47,38,'+',null)},fin:function(){bqCol(47,38,'+',null)},
 html:"<p>📜 Ilgari odamlar cho't yoki chiziqli taxtada hisoblashgan. Raqam o'rniga qarab yoziladigan sonlar va ularni <b>ustunda</b> qo'shish-ayirish Hindistonda paydo bo'lgan. IX asrda vatandoshimiz <b>al-Xorazmiy</b> bu hisob haqida kitob yozdi, u lotin tiliga tarjima qilinib, Yevropaga tarqaldi.</p>",
 btns:[["📜 Ko'rdim",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Bu kitobning lotincha tarjimasi «Dixit Algorizmi» — «Al-Xorazmiy aytdi» so'zlari bilan boshlanadi. Shundan «algoritm» so'zi paydo bo'lgan. Ustunda qo'shish ham — algoritm: har doim bir xil qadamlar ketma-ketligi!</p>",
 tn:"«Algoritm» so'zining kelib chiqishini bolalar albatta eslab qoladi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqCol(63,28,'−',null)},fin:function(){bqCol(63,28,'−',null)},
 html:"<div class='memo'><ul><li><b>Xona ostida xona</b>: birlik ostida birlik, o'nlik ostida o'nlik.</li><li>Hisob <b>o'ngdan chapga</b> — birliklardan boshlanadi.</li><li>Qo'shishda 10 dan oshsa: birlikni yozing, <b>1 o'nlikni eslab qoling</b> (o'nliklar ustiga).</li><li>Ayirishda kichikdan katta ayirilmasa: <b>1 o'nlik qarz</b> oling (10 qo'shing), o'nliklardan 1 kamaytiring.</li><li>0 dan ayirishda ham qarz olinadi: 70 − 26 = 44.</li><li>Oxirida <b>tekshiring</b>: 63 − 28 = 35 → 35 + 28 = 63 ✓</li></ul></div>",
 tn:"Ustun usulini katakli daftarda mashq qildiring: har raqam — alohida katakda."}
];
var PROBS=[
{t:"34 + 25 = ?",o:["59","58","69","49"],k:0,s:"4 + 5 = 9, 3 + 2 = 5."},
{t:"47 + 38 = ?",o:["85","75","715","86"],k:0,s:"7 + 8 = 15 (1 eslab), 4 + 3 + 1 = 8."},
{t:"56 + 35 = ?",o:["91","81","811","92"],k:0,s:"6 + 5 = 11, 5 + 3 + 1 = 9."},
{t:"68 − 25 = ?",o:["43","33","93","42"],k:0,s:"8 − 5 = 3, 6 − 2 = 4."},
{t:"63 − 28 = ?",o:["35","45","25","91"],k:0,s:"13 − 8 = 5, 5 − 2 = 3."},
{t:"70 − 26 = ?",o:["44","56","54","46"],k:0,s:"10 − 6 = 4, 6 − 2 = 4."},
{t:"80 − 37 = ?",o:["43","57","53","47"],k:0,s:"10 − 7 = 3, 7 − 3 = 4."},
{t:"29 + 29 = ?",o:["58","48","418","59"],k:0,s:"9 + 9 = 18 (1 eslab), 2 + 2 + 1 = 5."},
{t:"91 − 47 = ?",o:["44","56","54","46"],k:0,s:"11 − 7 = 4, 8 − 4 = 4."},
{t:"3□ + □5 = 82. O'chgan raqamlarni toping.",o:["7 va 4","5 va 3","2 va 5","7 va 5"],k:0,s:"37 + 45 = 82."},
{t:"□6 − 2□ = 38. O'chgan raqamlarni toping (□6 da o'nliklar, 2□ da birliklar).",o:["6 va 8","5 va 8","6 va 2","7 va 8"],k:0,s:"Birliklar: 16 − □ = 8 → □ = 8 (qarz). O'nliklar: □ − 1 − 2 = 3 → □ = 6. 66 − 28 = 38."},
{t:"45 + 27 + 18 = ?",o:["90","80","81","100"],k:0,s:"Birliklar: 5 + 7 + 8 = 20 (2 eslab), o'nliklar: 4 + 2 + 1 + 2 = 9."},
{t:"Ustunda 52 + 7 da 7 qaysi raqam ostiga yoziladi?",o:["2 ning","5 ning","o'rtasiga","chapga"],k:0,s:"7 — birlik."},
{t:"Ali 63 − 28 ni hisoblab 45 deb yozdi. U qanday xato qildi?",o:["8 dan 3 ni ayirdi","1 ni eslab qoldi","qo'shib yubordi","xato qilmadi"],k:0,s:"Birliklarda 3 − 8 o'rniga 8 − 3 = 5; o'nliklarda qarzni unutdi."},
{t:"Qaysi misolda o'nlikdan o'tish bor?",o:["37 + 46","32 + 45","51 + 28","63 + 24"],k:0,s:"7 + 6 = 13 > 9."},
{t:"Qaysi ayirishda qarz olish kerak?",o:["52 − 17","58 − 17","59 − 34","86 − 44"],k:0,s:"2 dan 7 ayirilmaydi."},
{t:"100 − 45 = ?",o:["55","65","45","155"],k:0,s:"100 − 40 = 60, 60 − 5 = 55."},
{t:"Ikki sonning yig'indisi 93, biri 58. Ikkinchisi?",o:["35","45","151","25"],k:0,s:"93 − 58 = 35 (13 − 8 = 5, 8 − 5 = 3)."},
{t:"Eng kichik ikki xonali son va eng katta ikki xonali son yig'indisi?",o:["109","99","110","100"],k:0,s:"10 + 99 = 109."},
{t:"76 − □ = 49. □ ni toping.",o:["27","33","125","37"],k:0,s:"76 − 49 = 27 (16 − 9 = 7, 6 − 4 = 2)."}
];
function PRACT_STAGE(){bqCol(47,38,'+',null);bqMsg('Birliklardan boshlang, eslab qolgan 1 ni unutmang')}
var PREP_DATA={teach:["Ustunda xonalarni to'g'ri joylash.","O'nlikdan o'tmay va o'tib qo'shish (eslab qolish).","O'nlikdan o'tmay va o'tib ayirish (qarz olish), nol bilan tugagan son.","Murakkab tur: o'chgan raqamlar; tekshirish."],
 mist:["Bir xonali sonni o'nliklar ostiga yozadi.","Eslab qolingan 1 ni unutadi (56 + 35 = 81).","Kichikdan kattani ayirolmay, teskari ayiradi (63 − 28 = 45).","70 − 26 da 0 − 6 = 6 deb yozadi."],
 need:["Katakli daftar.","O'nlik bloklar yoki cho'p bog'lamlari (qarzni ko'rsatish uchun)."],
 board:["<span class='w2'>34 + 25</span> — xonalar ostma-ost.","<span class='w2'>47 + 38: 7 + 8 = 15 → 5, ¹ → 85</span>.","<span class='w2'>63 − 28: 13 − 8 = 5, 5 − 2 = 3</span>.","<span class='w2'>70 − 26 = 44</span>.","<span class='w2'>3□ + □5 = 82 → 37 + 45</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
