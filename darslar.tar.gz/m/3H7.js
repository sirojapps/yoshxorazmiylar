var CODE='3H7',TITLE='3-sinf · Kesmani teng bo‘laklarga bo‘lish. Paletka bilan yuz';
function h7Ruler(x0,y0,n,px){var g=S.g;E('rect',{x:x0-6,y:y0,width:n*px+12,height:22,rx:3,fill:'#fdf1c7',stroke:'#c9a94a','stroke-width':1.2},g);
 for(var i=0;i<=n;i++){g3Line([x0+i*px,y0],[x0+i*px,y0+9],{w:1.3,c:'#6b5a2a'});T(g,x0+i*px,y0+19,String(i),{'font-size':9,fill:'#6b5a2a'})}}
function h7Seg(k){clear('#ffffff');var g=S.g,x0=60,y=70,px=20;h7Ruler(x0,y+10,12,px);g3Line([x0,y],[x0+240,y],{w:4});g3Dot([x0,y],'#33475b');g3Dot([x0+240,y],'#33475b');T(g,x0,y-10,'A',{'font-size':13,'font-weight':800});T(g,x0+240,y-10,'B',{'font-size':13,'font-weight':800});
 if(k>=2){g3Dot([x0+80,y],C.bad,5);g3Dot([x0+160,y],C.bad,5)}
 if(k>=3){[0,1,2].forEach(function(i){g3Line([x0+i*80,y],[x0+i*80+80,y],{w:5,c:['#e0713b','#2f8f5b','#1f6fb2'][i]});T(g,x0+i*80+40,y-10,'4 sm',{'font-size':12,'font-weight':800,fill:['#e0713b','#2f8f5b','#1f6fb2'][i]})})}
 g3Msg(['AB kesmani 3 ta teng bo‘lakka bo‘lamiz','O‘lchaymiz: AB = <b>12 sm</b>. Bitta bo‘lak: 12 : 3 = <b>4 sm</b>','4 sm va 8 sm da nuqta qo‘yamiz','3 ta teng bo‘lak: 4 + 4 + 4 = 12 ✓'][k])}
var P1=[function(){h7Seg(0)},function(){h7Seg(1)},function(){h7Seg(2)},function(){h7Seg(3)}];
function h7Arc(c,r,f,t,col){var pts=[];for(var d=f;d<=t+0.01;d+=3){var a=d*Math.PI/180;pts.push((c[0]+r*Math.cos(a))+','+(c[1]-r*Math.sin(a)))}E('polyline',{points:pts.join(' '),fill:'none',stroke:col,'stroke-width':2.5},S.g)}
function h7Mid(k){clear('#ffffff');var g=S.g,A=[100,110],B=[260,110],r=95;g3Line(A,B,{w:4});g3Dot(A,'#33475b');g3Dot(B,'#33475b');T(g,A[0]-10,A[1]+5,'A',{'font-size':13,'font-weight':800,'text-anchor':'end'});T(g,B[0]+10,B[1]+5,'B',{'font-size':13,'font-weight':800,'text-anchor':'start'});
 if(k>=1){h7Arc(A,r,15,50,C.blue);h7Arc(A,r,-50,-15,C.blue)}
 if(k>=2){h7Arc(B,r,130,165,C.ok);h7Arc(B,r,195,230,C.ok)}
 if(k>=3){g3Dot([180,59],C.bad,4);g3Dot([180,161],C.bad,4);g3Line([180,59],[180,161],{w:2.5,c:C.bad,d:'6 4'});g3Dot([180,110],C.bad,6);T(g,188,126,'M',{'font-size':14,'font-weight':800,fill:C.bad,'text-anchor':'start'})}
 g3Msg(['AB kesmani sirkul bilan teng ikkiga bo‘lamiz','Sirkulni AB ning yarmidan <b>kattaroq</b> ochib, A dan ikki yoy chizamiz','Shu ochilish bilan B dan ham yoylar chizamiz','Yoylar kesishgan nuqtalarni tutashtiramiz: <b>M</b> — o‘rtasi, AM = MB'][k])}
var P2=[function(){h7Mid(0)},function(){h7Mid(1)},function(){h7Mid(2)},function(){h7Mid(3)}];
function h7Parts(n){clear('#ffffff');var g=S.g,x0=50,L=260,y=80;g3Line([x0,y],[x0+L,y],{w:4});g3Dot([x0,y],'#33475b',5);g3Dot([x0+L,y],'#33475b',5);
 for(var i=1;i<n;i++){g3Dot([x0+L*i/n,y],C.bad,5);T(g,x0+L*i/n,y-12,'✂',{'font-size':12,fill:C.bad})}
 for(var j=0;j<n;j++)T(g,x0+L*(j+.5)/n,y+22,String(j+1),{'font-size':12,'font-weight':800,fill:C.blue});
 g3Msg('<b>'+n+'</b> bo‘lak → ichki nuqtalar (kesishlar): <b>'+(n-1)+'</b>, uchlari bilan nuqtalar: <b>'+(n+1)+'</b>')}
function h7Whole(k){clear('#ffffff');var g=S.g,x0=60,y=80,w=60;for(var i=0;i<4;i++){E('rect',{x:x0+i*w,y:y-14,width:w,height:28,fill:i===0||k>=2?['#f2b766','#f6c98a','#f2b766','#f6c98a'][i]:'#fff',stroke:C.line,'stroke-width':2},g);if(i===0||k>=2)T(g,x0+i*w+w/2,y+5,'6 sm',{'font-size':12,'font-weight':800})}
 if(k>=1)T(g,x0+2*w,y-24,'4 ta teng bo‘lak',{'font-size':12,'font-weight':800,fill:C.blue});if(k>=3)T(g,x0+2*w,y+40,'6 · 4 = 24 sm',{'font-size':15,'font-weight':800,fill:C.ok});
 g3Msg(['Tasmaning 4 ta teng bo‘lagidan biri 6 sm. Butun tasma qancha?','Butun = 4 ta shunday bo‘lak','Har bo‘lak 6 sm','Butun: 6 · 4 = <b>24 sm</b>'][k])}
var P4=[function(){h7Whole(0)},function(){h7Whole(1)},function(){h7Whole(2)},function(){h7Whole(3)}];
// paletka: sh — ellipslar [cx,cy,rx,ry]
function h7In(sh,x,y){for(var i=0;i<sh.length;i++){var e=sh[i],u=(x-e[0])/e[2],v=(y-e[1])/e[3];if(u*u+v*v<=1)return true}return false}
function h7Shape(sh,col){sh.forEach(function(e){E('ellipse',{cx:e[0],cy:e[1],rx:e[2],ry:e[3],fill:'none',stroke:'#2f6b3a','stroke-width':3},S.g)});sh.forEach(function(e){E('ellipse',{cx:e[0],cy:e[1],rx:e[2],ry:e[3],fill:col||'#9fd38a'},S.g)})}
function h7Pal(sh,x0,y0,cs,cols,rows,mode){var g=S.g,full=0,part=0;
 for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var n=0;for(var a=0;a<4;a++)for(var b=0;b<4;b++)if(h7In(sh,x0+c*cs+(a+.5)*cs/4,y0+r*cs+(b+.5)*cs/4))n++;
  var t=n===16?2:n>0?1:0;if(t===2)full++;else if(t===1)part++;
  if(mode>=1&&t===2)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs,height:cs,fill:'rgba(31,111,178,.45)'},g);
  if(mode>=2&&t===1)E('rect',{x:x0+c*cs,y:y0+r*cs,width:cs,height:cs,fill:'rgba(240,160,64,.55)'},g)}
 for(var i=0;i<=cols;i++)g3Line([x0+i*cs,y0],[x0+i*cs,y0+rows*cs],{w:1,c:'rgba(31,111,178,.6)'});for(var j=0;j<=rows;j++)g3Line([x0,y0+j*cs],[x0+cols*cs,y0+j*cs],{w:1,c:'rgba(31,111,178,.6)'});
 E('rect',{x:x0,y:y0,width:cols*cs,height:rows*cs,fill:'rgba(200,225,250,.12)',stroke:C.blue,'stroke-width':1.5},g);return [full,part]}
var H7B=[[180,88,90,54],[140,70,40,40]];
function h7Est(f,p){return f+Math.round(p/2)}
function h7Leaf(m){clear('#ffffff');var g=S.g;h7Shape(H7B);if(m===0){g3Msg('Bu shaklni katakchalar bilan qoplab bo‘lmaydi — u egri!');return}
 var r=h7Pal(H7B,70,20,20,11,7,m-1);
 if(m===1)g3Msg('Paletka — shaffof katakli plastinka. 1 katak = 1 sm². Shakl ustiga qo‘ydik');
 if(m===2)g3Msg('<b>To‘liq</b> kataklar (ko‘k): <b>'+r[0]+'</b> ta');
 if(m===3)g3Msg('<b>Chala</b> kataklar (sariq): <b>'+r[1]+'</b> ta → ikki chala ≈ bitta butun');
 if(m===4)g3Msg('S ≈ '+r[0]+' + '+r[1]+' : 2 = <b>'+h7Est(r[0],r[1])+' sm²</b>')}
var P6=[function(){h7Leaf(1)},function(){h7Leaf(2)},function(){h7Leaf(3)},function(){h7Leaf(3);var r=h7Pal(H7B,70,20,20,11,7,-1);clear('#ffffff');h7Shape(H7B);h7Pal(H7B,70,20,20,11,7,2);g3Msg('S ≈ '+r[0]+' + '+r[1]+' : 2 = <b>'+h7Est(r[0],r[1])+' sm²</b>')}];
function h7Fine(m){clear('#ffffff');var sh=[[180,88,70,58]];h7Shape(sh);var r;
 if(m===1){r=h7Pal(sh,80,8,40,5,4,2);g3Msg('Katta katak (1 katak = 4 sm²): '+r[0]+' to‘liq, '+r[1]+' chala → ≈ '+h7Est(r[0],r[1])+' · 4 = <b>'+h7Est(r[0],r[1])*4+' sm²</b>')}
 else if(m===2){r=h7Pal(sh,100,24,20,8,7,2);g3Msg('Kichik katak (1 sm²): '+r[0]+' to‘liq, '+r[1]+' chala → ≈ <b>'+h7Est(r[0],r[1])+' sm²</b> — aniqroq')}
 else g3Msg('Qaysi paletka aniqroq natija beradi?')}
var H7L=[[120,80,70,40],[230,92,72,48],[290,60,30,26]];
function h7Lake(on){clear('#e8f1e4');var g=S.g;h7Shape(H7L,'#7fc3ea');var r=h7Pal(H7L,40,20,20,15,7,on?2:0);
 g3Msg(on?'1 katak = 1 km²: '+r[0]+' + '+r[1]+' : 2 ≈ <b>'+h7Est(r[0],r[1])+' km²</b>':'Xaritadagi ko‘l. Paletka katagi = 1 km²')}
var STEPS=[
{h:"Kesmani teng bo'laklarga bo'lish",sum:"Kesmani n teng bo'lakka bo'lish: uzunligini o'lchab, n ga bo'lamiz va nuqtalar qo'yamiz.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>12 sm li AB kesmani <b>3 ta teng</b> bo'lakka bo'lamiz. Chizg'ich yordamida:</p>",
 btns:[phaser(P1)],
 after:"<p>1) Kesmani o'lchaymiz. 2) Uzunlikni bo'laklar soniga <b>bo'lamiz</b>: 12 : 3 = 4. 3) Har 4 sm da nuqta qo'yamiz. Tekshirish: 4 · 3 = 12.</p>",
 q:{t:"20 sm li kesma 4 ta teng bo'lakka bo'lindi. Har bo'lak?",opts:["16 sm","5 sm","80 sm","4 sm"],ok:1,why:"20 : 4 = 5.",hint:"Uzunlikni bo'laklar soniga bo'ling.",full:"20 : 4 = 5 sm. «16» — ayirilgan, «80» — ko'paytirilgan."},
 tn:"Har bolaga qog'oz tasma bering: chizg'ich bilan o'lchab, teng bo'laklarga bo'lib, qaychi bilan kessin."},
{h:"Sirkul bilan teng ikkiga",sum:"A va B dan bir xil radiusli yoylar chizib, kesishish nuqtalarini tutashtirsak — kesma o'rtasi M topiladi.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Kesmani <b>o'lchamasdan</b>, faqat sirkul va chizg'ich bilan teng ikkiga bo'lish mumkin! Qadamlarni bajaring:</p>",
 btns:[phaser(P2,'✏️ Chizish')],
 after:"<p>Sirkul ochilmasi kesma yarmidan <b>katta</b> bo'lishi shart, aks holda yoylar kesishmaydi. Hosil bo'lgan M nuqta — kesmaning <b>o'rtasi</b>: AM = MB.</p>",
 q:{t:"Kesma 14 sm. O'rtasi M topildi. AM qancha?",opts:["14 sm","7 sm","28 sm","2 sm"],ok:1,why:"14 : 2 = 7.",hint:"O'rta nuqta kesmani nechta teng bo'lakka bo'ladi?",full:"M — o'rtasi, AM = MB = 14 : 2 = 7 sm."},
 tn:"Doskada katta sirkul (yoki ip va bo'r) bilan yasang; bolalar daftarda takrorlasin."},
{h:"Tuzoq: bo'laklar va nuqtalar",sum:"n bo'lak uchun n − 1 ta kesish (ichki nuqta); uchlari bilan n + 1 ta nuqta.",a:"m03",
 start:function(){S.pn=1;h7Parts(1)},fin:function(){h7Parts(4)},
 html:"<p>Kesmani bo'laklarga bo'lsak, nechta nuqta (kesish) kerak? Bo'laklarni ko'paytiring:</p>",
 btns:[["＋ Bo'lak",function(c,done){S.pn=S.pn>=6?2:S.pn+1;h7Parts(S.pn);mvK(done,3)}]],
 after:"<p><b>Bo'laklar = kesishlar + 1</b>. Ustun masalasi: 12 m yo'lda har 3 m da ustun (boshida ham, oxirida ham): 12 : 3 = 4 oraliq, ustunlar <b>4 + 1 = 5</b>.</p>",
 q:{t:"Yog'och 6 bo'lakka arralandi. Necha marta arralangan?",opts:["6","5","7","3"],ok:1,why:"Bo'laklar − 1 = 5.",hint:"Bitta arralash nechta bo'lak beradi?",full:"1 arralash — 2 bo'lak, 2 — 3 bo'lak… 6 bo'lak uchun 5 marta. «6» — eng ko'p xato, «7» — uchlari bilan nuqtalar soni."},
 tn:"Bolalar qog'oz tasmani kesib, «kesishlar» va «bo'laklar»ni sanasin; ustunlar masalasini chizmada ko'rsating."},
{h:"Bo'lakdan butunga",sum:"4 ta teng bo'lakdan biri 6 sm bo'lsa, butun 6 · 4 = 24 sm.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>Teskari masala: <i>«Tasmaning 4 ta teng bo'lagidan biri 6 sm. Butun tasma uzunligi?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Bir bo'lak ma'lum bo'lsa, butun = <b>bo'lak · bo'laklar soni</b>: 6 · 4 = 24 sm. Bir nechta bo'lak: 3 bo'lagi = 6 · 3 = 18 sm.</p>",
 q:{t:"18 sm kesma 3 ta teng bo'lakka bo'lindi. Ikki bo'lagi uzunligi?",opts:["6 sm","12 sm","9 sm","15 sm"],ok:1,why:"Bir bo'lak 6, ikkitasi 12.",hint:"Avval bitta bo'lakni toping.",full:"18 : 3 = 6 sm — bitta bo'lak, ikkitasi 6 · 2 = 12 sm. «9» — 18 : 2, «6» — bitta bo'lak."},
 tn:"Singapur chizma modeli: tasmani bo'laklarga bo'lib chizing — noma'lum butun yoki bo'lak ko'rinib turadi."},
{h:"Paletka nima?",sum:"Paletka — shaffof katakli plastinka. Egri shakl yuzini kataklar bilan taxminan o'lchaydi.",a:"m05",
 start:function(){h7Leaf(0)},fin:function(){h7Leaf(1)},
 html:"<p>Bargning yuzini qanday topamiz? U to'g'ri to'rtburchak emas — formula yo'q! Yordamga <b>paletka</b> keladi:</p>",
 btns:[["🔲 Paletkani qo'yish",function(c,done){h7Leaf(1);done()}]],
 after:"<p><b>Paletka</b> — shaffof plyonka yoki qog'ozga chizilgan kataklar (odatda 1 sm²). Uni shakl ustiga qo'yib, kataklarni sanaymiz. Paletkani o'zingiz ham yasashingiz mumkin: shaffof faylga katak chizing.</p>",
 q:{t:"Paletka bilan nimani o'lchaymiz?",opts:["Kesma uzunligini","Shakl yuzini","Burchakni","Hajmni"],ok:1,why:"Kataklar soni — yuz.",hint:"Katak (kvadrat birlik) nimaning birligi?",full:"Paletka kataklari kvadrat birliklar (sm²) — u yuzni o'lchaydi, ayniqsa egri shakllarnikini."},
 tn:"Shaffof fayl yoki kalka qog'oziga 1 sm li kataklar chizib, har bolaga paletka yasang."},
{h:"Paletka bilan sanash qoidasi",sum:"S ≈ to'liq kataklar + chala kataklar : 2.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Shakl ustidagi kataklar ikki xil: <b>to'liq</b> (butunlay ichida) va <b>chala</b> (bir qismi ichida). Sanaymiz:</p>",
 btns:[phaser(P6,'🔍 Sanash')],
 after:"<p>Qoida: <b>S ≈ to'liq + chala : 2</b>. Chala kataklarning ba'zisi kattaroq, ba'zisi kichikroq qismini egallaydi — o'rtacha har ikki chala ≈ bitta butun. Natija <b>taxminiy</b>.</p>",
 q:{t:"Paletkada 20 ta to'liq va 8 ta chala katak. Yuz taxminan?",opts:["28 sm²","24 sm²","20 sm²","36 sm²"],ok:1,why:"20 + 8 : 2 = 24.",hint:"Chala kataklarni 2 ga bo'lishni unutmang.",full:"20 + 8 : 2 = 20 + 4 = 24 sm². «28» — chalalar butun deb olingan, «20» — chalalar tashlab yuborilgan."},
 tn:"Bolalar o'z kaftini daftarga chizib, paletka bilan yuzini topsin — kimniki katta?"},
{h:"Tuzoq: katta va kichik katak",sum:"Paletka katagi qancha kichik bo'lsa, natija shuncha aniq. Katak 4 sm² bo'lsa, javobni 4 ga ko'paytirish kerak.",a:"m07",
 start:function(){h7Fine(0)},fin:function(){h7Fine(2)},
 html:"<p>Bir xil shaklni ikki paletka bilan o'lchaymiz: kataklari 2 × 2 sm va 1 × 1 sm.</p>",
 btns:[["⬛ Katta katak",function(c,done){h7Fine(1);mvK(done,2)}],["▪️ Kichik katak",function(c,done){h7Fine(2);mvK(done,2)}]],g2:1,
 after:"<p>Kichik kataklarda chala kataklar ulushi kamroq — natija <b>aniqroq</b>. Diqqat: katak 2 × 2 sm bo'lsa, bitta katak = <b>4 sm²</b>, sanalgan kataklarni 4 ga ko'paytiramiz!</p>",
 q:{t:"Paletka katagi tomoni 2 sm. Shaklda 9 ta to'liq va 6 ta chala katak. Yuz taxminan?",opts:["12 sm²","48 sm²","15 sm²","60 sm²"],ok:1,why:"(9 + 3) · 4 = 48.",hint:"Bitta katakning yuzi necha sm²?",full:"Kataklar: 9 + 6 : 2 = 12. Bir katak 2 · 2 = 4 sm², S ≈ 12 · 4 = 48 sm². «12» — katak yuzi hisobga olinmagan, «60» — chalalar butun olingan."},
 tn:"Ikki xil paletka bilan bir shaklni o'lchab, natijalarni doskada solishtiring."},
{h:"Tuzoq: chala kataklar",sum:"Barg: 18 to'liq + 10 chala → 18 + 5 = 23 sm² (28 ham, 18 ham emas).",a:"m08",
 start:function(){clear('#ffffff');h7Shape([[180,88,110,50]]);T(S.g,180,92,'18 to‘liq · 10 chala',{'font-size':15,'font-weight':800,fill:'#1d3b22'});g3Msg('Barg yuzi taxminan qancha?')},fin:function(){clear('#ffffff');h7Shape([[180,88,110,50]]);T(S.g,180,92,'18 + 10 : 2 = 23 sm²',{'font-size':16,'font-weight':800,fill:'#1d3b22'});g3Msg('To‘g‘ri: <b>23 sm²</b>')},
 html:"<p>Bargni paletka bilan o'lchadik: <b>18</b> ta to'liq, <b>10</b> ta chala katak. Yuzi qancha? Sinab ko'ring:</p>",
 btns:[["28",function(){clear('#ffffff');h7Shape([[180,88,110,50]]);T(S.g,180,92,'18 + 10 = 28 ?',{'font-size':16,'font-weight':800,fill:C.bad});g3Msg('Chala kataklar butun deb olindi ✗')}],["23",function(c,done){clear('#ffffff');h7Shape([[180,88,110,50]]);T(S.g,180,92,'18 + 10 : 2 = 23 sm²',{'font-size':16,'font-weight':800,fill:'#1d3b22'});g3Msg('To‘g‘ri!');done()},'u'],["18",function(){clear('#ffffff');h7Shape([[180,88,110,50]]);T(S.g,180,92,'faqat 18 ?',{'font-size':16,'font-weight':800,fill:C.bad});g3Msg('Chala kataklar unutildi ✗')}]],g3:1,
 after:"<p>Chala kataklarni tashlab ham, butun deb ham olmaymiz — <b>yarmini</b> qo'shamiz: 18 + 10 : 2 = <b>23 sm²</b>.</p>",
 q:{t:"Paletkada 15 ta to'liq va 6 ta chala katak. Yuz taxminan?",opts:["21 sm²","18 sm²","15 sm²","27 sm²"],ok:1,why:"15 + 3 = 18.",hint:"Chala kataklarning yarmini qo'shing.",full:"15 + 6 : 2 = 18 sm². «21» — chalalar butun, «15» — chalalar tashlangan."},
 tn:"Javobni «taxminan» so'zi bilan aytishga o'rgating: S ≈ 23 sm²."},
{h:"Bilasizmi? Xaritada ko'l",sum:"Paletka bilan xaritadagi ko'l, o'rmon, dala yuzini ham taxminan topish mumkin.",a:"m09",
 start:function(){h7Lake(0)},fin:function(){h7Lake(1)},
 html:"<p>🗺️ Paletka usuli xaritalarda ham qo'llanadi: ko'l, o'rmon yoki dala yuzini taxminan topish uchun. Xaritadagi ko'lni o'lchang:</p>",
 btns:[["🔲 O'lchash",function(c,done){h7Lake(1);done()}]],
 after:"<p>Xaritada katak 1 km² ga teng bo'lsa, javob km² da chiqadi. Yuzalarni o'lchashning bu usuli «kataklar usuli» deb ham ataladi.</p>",
 tn:"Viloyatingiz xaritasi nusxasiga paletka qo'yib, biror ko'l yoki tuman yuzini taxmin qiling."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h7Seg(3)},fin:function(){h7Seg(3)},
 html:"<div class='memo'><ul><li>Kesmani n teng bo'lakka: <b>uzunlik : n</b>.</li><li>Sirkul bilan teng ikkiga: A va B dan bir xil yoylar → M.</li><li>n bo'lak — <b>n − 1</b> kesish; uchlari bilan <b>n + 1</b> nuqta.</li><li>Bo'lakdan butun: <b>bo'lak · n</b>.</li><li>Paletka: <b>S ≈ to'liq + chala : 2</b>.</li><li>Katak 4 sm² bo'lsa — natijani 4 ga ko'paytiring.</li><li>Kichik katak — aniqroq natija.</li></ul></div>",
 tn:"Uyga: o'z kaftingiz yuzini paletka bilan toping."}
];
var PROBS=[
{t:"12 sm kesma 3 ta teng bo'lakka bo'lindi. Har bo'lak?",o:["4 sm","9 sm","36 sm","3 sm"],k:0,s:"12 : 3 = 4."},
{t:"20 sm kesma 4 ta teng bo'lakka bo'lindi. Har bo'lak?",o:["5 sm","16 sm","80 sm","4 sm"],k:0,s:"20 : 4 = 5."},
{t:"Kesmani 5 teng bo'lakka bo'lish uchun uchlaridan tashqari nechta nuqta qo'yiladi?",o:["4","5","6","3"],k:0,s:"5 − 1 = 4."},
{t:"1 dm kesma 5 ta teng bo'lakka bo'lindi. Har bo'lak necha mm?",o:["20 mm","2 mm","50 mm","5 mm"],k:0,s:"100 : 5 = 20."},
{t:"Kesma 14 sm. O'rtasidan uchigacha masofa?",o:["7 sm","14 sm","28 sm","2 sm"],k:0,s:"14 : 2 = 7."},
{t:"Tasmaning 4 ta teng bo'lagidan biri 6 sm. Butun tasma?",o:["24 sm","10 sm","2 sm","18 sm"],k:0,s:"6 · 4 = 24."},
{t:"Yo'l 12 m. Har 3 m da ustun qo'yildi (boshida va oxirida ham). Nechta ustun?",o:["5","4","6","3"],k:0,s:"12 : 3 = 4 oraliq, 5 ustun."},
{t:"Yog'och 6 bo'lakka arralandi. Necha marta arralangan?",o:["5","6","7","3"],k:0,s:"6 − 1 = 5."},
{t:"Arqon 4 marta kesildi. Nechta bo'lak bo'ldi?",o:["5","4","3","8"],k:0,s:"4 + 1 = 5."},
{t:"18 sm kesma 3 ta teng bo'lakka bo'lindi. Ikki bo'lagi uzunligi?",o:["12 sm","6 sm","9 sm","15 sm"],k:0,s:"6 · 2 = 12."},
{t:"Kesma 3 sm 6 mm. 4 ta teng bo'lakka bo'lindi. Har bo'lak?",o:["9 mm","9 sm","4 mm","36 mm"],k:0,s:"36 : 4 = 9 mm."},
{t:"40 sm tasma 5 ta teng bo'lakka bo'lindi, 3 bo'lagi kesib olindi. Qolgani?",o:["16 sm","24 sm","8 sm","35 sm"],k:0,s:"Bo'lak 8, qoldi 2 · 8 = 16."},
{t:"Paletka bilan nimani o'lchaymiz?",o:["Shakl yuzini","Kesma uzunligini","Burchakni","Hajmni"],k:0,s:"Kataklar — yuz birligi."},
{t:"Paletkada 20 ta to'liq va 8 ta chala katak (1 katak = 1 sm²). Yuz?",o:["≈ 24 sm²","≈ 28 sm²","≈ 20 sm²","≈ 36 sm²"],k:0,s:"20 + 8 : 2 = 24."},
{t:"Paletkada 15 ta to'liq va 6 ta chala katak. Yuz?",o:["≈ 18 sm²","≈ 21 sm²","≈ 15 sm²","≈ 27 sm²"],k:0,s:"15 + 3 = 18."},
{t:"Barg: 18 ta to'liq va 10 ta chala katak. Yuz?",o:["≈ 23 sm²","≈ 28 sm²","≈ 18 sm²","≈ 38 sm²"],k:0,s:"18 + 5 = 23."},
{t:"Qaysi paletka aniqroq natija beradi?",o:["Kataklari kichigi","Kataklari kattasi","Ikkalasi bir xil","Katakisiz"],k:0,s:"Kichik katakda xato kamroq."},
{t:"4 × 3 sm to'g'ri to'rtburchakka 1 sm li paletka qo'yildi. Chala katak yo'q. Yuz?",o:["12 sm²","7 sm²","14 sm²","6 sm²"],k:0,s:"12 ta to'liq katak."},
{t:"Xaritada ko'l: 30 to'liq, 14 chala katak, 1 katak = 1 km². Ko'l yuzi?",o:["≈ 37 km²","≈ 44 km²","≈ 30 km²","≈ 51 km²"],k:0,s:"30 + 7 = 37."},
{t:"Paletka katagi tomoni 2 sm. 9 ta to'liq, 6 ta chala katak. Yuz?",o:["≈ 48 sm²","≈ 12 sm²","≈ 15 sm²","≈ 60 sm²"],k:0,s:"(9 + 3) · 4 = 48."}
];
function PRACT_STAGE(){h7Seg(3)}
var PREP_DATA={teach:["Kesmani chizg'ich bilan teng bo'laklarga bo'lish (uzunlik : n).","Sirkul bilan kesmani teng ikkiga bo'lish.","Bo'laklar va kesishlar (ustunlar, arralash) masalalari; bo'lakdan butunni topish.","Paletka: to'liq va chala kataklar, S ≈ to'liq + chala : 2; katak o'lchamining ta'siri."],
 mist:["n bo'lak uchun n marta kesish kerak deydi.","Ustunlar masalasida oraliqlar sonini javob qiladi.","Paletkada chala kataklarni butun deb yoki umuman sanamaydi.","Katak 4 sm² bo'lsa ham kataklar sonini javob deb yozadi."],
 need:["Chizg'ich, sirkul, qog'oz tasmalar, qaychi.","Shaffof fayl/kalka (paletka uchun), barglar, xarita nusxasi."],
 board:["<span class='w2'>12 : 3 = 4</span> sm.","n bo'lak → <span class='w2'>n − 1</span> kesish.","<span class='w2'>S ≈ to'liq + chala : 2</span>.","Katak 2 × 2: <span class='w2'>(9 + 6 : 2) · 4 = 48</span>."]};

// ===== w_3g umumiy chizma yordamchilari (3G7, 3G8, 3H1–3H7) =====
function g3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// katakli qog'oz: cs — katak o'lchami
function g3Paper(cs,x0,y0,cols,rows,col){var g=S.g;for(var c=0;c<=cols;c++)E('line',{x1:x0+c*cs,y1:y0,x2:x0+c*cs,y2:y0+rows*cs,stroke:col||'#dbe7f3','stroke-width':1},g);for(var r=0;r<=rows;r++)E('line',{x1:x0,y1:y0+r*cs,x2:x0+cols*cs,y2:y0+r*cs,stroke:col||'#dbe7f3','stroke-width':1},g)}
// to'rtburchak (katak birligida), ixtiyoriy to'ldirish, yozuvlar
function g3Rect(x,y,w,h,o){o=o||{};var g=S.g;E('rect',{x:x,y:y,width:w,height:h,fill:o.fill||'rgba(240,160,64,.35)',stroke:o.stroke||C.line,'stroke-width':o.sw||2.2,rx:o.rx||0},g);
 if(o.top)T(g,x+w/2,y-5,o.top,{'font-size':11,'font-weight':800,fill:o.tc||C.blue});if(o.left)T(g,x-5,y+h/2+4,o.left,{'font-size':11,'font-weight':800,fill:o.tc||C.blue,'text-anchor':'end'});
 if(o.mid)T(g,x+w/2,y+h/2+5,o.mid,{'font-size':o.mfs||14,'font-weight':800,fill:o.mc||'#1d2b3a'})}
// ko'pburchak (nuqtalar massivi)
function g3Poly(pts,o){o=o||{};return E('polygon',{points:pts.map(function(p){return p[0]+','+p[1]}).join(' '),fill:o.fill||'rgba(90,169,230,.25)',stroke:o.stroke||C.blue,'stroke-width':o.sw||2.2,'stroke-linejoin':'round'},S.g)}
function g3Line(a,b,o){o=o||{};return E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:o.c||'#33475b','stroke-width':o.w||2,'stroke-dasharray':o.d||'','stroke-linecap':'round'},S.g)}
function g3Dot(p,col,r){return E('circle',{cx:p[0],cy:p[1],r:r||4,fill:col||C.bad,stroke:'#fff','stroke-width':1.5},S.g)}
// muntazam ko'pburchak nuqtalari
function g3Reg(n,cx,cy,R,rot){var a=[];rot=rot==null?-Math.PI/2:rot;for(var i=0;i<n;i++)a.push([cx+R*Math.cos(rot+i*2*Math.PI/n),cy+R*Math.sin(rot+i*2*Math.PI/n)]);return a}
// kub (izometrik): x,y — old pastki chap burchak, s — tomon
function g3Cube(x,y,s,o){o=o||{};var g=S.g,d=s*0.45,dy=s*0.3;
 E('path',{d:'M'+x+' '+(y-s)+' l'+d+' '+(-dy)+' h'+s+' l'+(-d)+' '+dy+' Z',fill:o.top||'#f6c98a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('path',{d:'M'+(x+s)+' '+y+' v'+(-s)+' l'+d+' '+(-dy)+' v'+s+' Z',fill:o.side||'#d9954a',stroke:o.st||C.line,'stroke-width':1.4},g);
 E('rect',{x:x,y:y-s,width:s,height:s,fill:o.front||'#f2b766',stroke:o.st||C.line,'stroke-width':1.4},g)}
// parallelepiped: a (bo'yi), b (eni, chuqurlik), c (balandligi) piksellarda
function g3Box(x,y,a,b,c,o){o=o||{};var g=S.g,d=b*0.5,dy=b*0.35;
 E('path',{d:'M'+x+' '+(y-c)+' l'+d+' '+(-dy)+' h'+a+' l'+(-d)+' '+dy+' Z',fill:o.top||'#cfe6f8',stroke:C.blue,'stroke-width':1.6},g);
 E('path',{d:'M'+(x+a)+' '+y+' v'+(-c)+' l'+d+' '+(-dy)+' v'+c+' Z',fill:o.side||'#9cc8ec',stroke:C.blue,'stroke-width':1.6},g);
 E('rect',{x:x,y:y-c,width:a,height:c,fill:o.front||'#e3f0fb',stroke:C.blue,'stroke-width':1.6},g);
 if(o.dash){E('path',{d:'M'+x+' '+y+' l'+d+' '+(-dy)+' h'+a+' M'+(x+d)+' '+(y-dy)+' v'+(-c),fill:'none',stroke:C.blue,'stroke-width':1.2,'stroke-dasharray':'4 3'},g)}
 if(o.la)T(g,x+a/2,y+16,o.la,{'font-size':11,'font-weight':800,fill:C.bad});if(o.lb)T(g,x+a+d/2+16,y-dy/2+6,o.lb,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'start'});if(o.lc)T(g,x-6,y-c/2+4,o.lc,{'font-size':11,'font-weight':800,fill:C.bad,'text-anchor':'end'})}
// fazoviy jismlar
function g3Solid(kind,cx,cy,s,o){o=o||{};var g=S.g,fill=o.fill||'#f2b766',st=C.line;
 if(kind==='cube'){g3Cube(cx-s/2,cy+s/2,s);return}
 if(kind==='sphere'){E('circle',{cx:cx,cy:cy,r:s/2,fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy,rx:s/2,ry:s/7,fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);E('ellipse',{cx:cx-s/6,cy:cy-s/6,rx:s/9,ry:s/14,fill:'#fff',opacity:.6},g);return}
 if(kind==='cyl'){var rx=s/2,ry=s/7,h=s;E('path',{d:'M'+(cx-rx)+' '+(cy-h/2)+' v'+h+' a'+rx+' '+ry+' 0 0 0 '+(2*rx)+' 0 v'+(-h)+' Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('ellipse',{cx:cx,cy:cy-h/2,rx:rx,ry:ry,fill:'#f6d9a8',stroke:st,'stroke-width':1.6},g);return}
 if(kind==='cone'){var rx2=s/2,ry2=s/7;E('path',{d:'M'+cx+' '+(cy-s/2)+' L'+(cx+rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 1 '+(-2*rx2)+' 0 Z',fill:fill,stroke:st,'stroke-width':1.6},g);E('path',{d:'M'+(cx-rx2)+' '+(cy+s/2)+' a'+rx2+' '+ry2+' 0 0 0 '+(2*rx2)+' 0',fill:'none',stroke:st,'stroke-width':1,'stroke-dasharray':'3 3'},g);return}
 if(kind==='box'){g3Box(cx-s*0.55,cy+s*0.4,s*0.9,s*0.6,s*0.6);return}
 if(kind==='pyr'){var b1=[cx-s/2,cy+s/2],b2=[cx+s/3,cy+s/2],b3=[cx+s/2,cy+s/3],ap=[cx,cy-s/2];g3Poly([b1,b2,ap],{fill:'#f2b766',stroke:st});g3Poly([b2,b3,ap],{fill:'#d9954a',stroke:st});return}}
// burchak chizish: uch nuqtasi v, ikki nur yo'nalishi (gradus), uzunlik L
function g3Angle(v,a1,a2,L,o){o=o||{};var g=S.g,r=Math.PI/180,p1=[v[0]+L*Math.cos(a1*r),v[1]-L*Math.sin(a1*r)],p2=[v[0]+L*Math.cos(a2*r),v[1]-L*Math.sin(a2*r)];
 g3Line(v,p1,{w:2.5,c:o.c||'#33475b'});g3Line(v,p2,{w:2.5,c:o.c||'#33475b'});var d=Math.abs(a2-a1);
 if(Math.abs(d-90)<.5&&!o.arc){var q=14,u1=[Math.cos(a1*r),-Math.sin(a1*r)],u2=[Math.cos(a2*r),-Math.sin(a2*r)];E('path',{d:'M'+(v[0]+u1[0]*q)+' '+(v[1]+u1[1]*q)+' L'+(v[0]+u1[0]*q+u2[0]*q)+' '+(v[1]+u1[1]*q+u2[1]*q)+' L'+(v[0]+u2[0]*q)+' '+(v[1]+u2[1]*q),fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 else{var rr=18,s1=[v[0]+rr*Math.cos(a1*r),v[1]-rr*Math.sin(a1*r)],s2=[v[0]+rr*Math.cos(a2*r),v[1]-rr*Math.sin(a2*r)];E('path',{d:'M'+s1[0]+' '+s1[1]+' A'+rr+' '+rr+' 0 '+(d>180?1:0)+' 0 '+s2[0]+' '+s2[1],fill:'none',stroke:o.ac||C.bad,'stroke-width':2},g)}
 g3Dot(v,'#33475b',3)}
// kvadrat qog'oz burchagi (to'g'ri burchak o'lchagich)
function g3Corner(x,y,s,rot){var g=E('g',{transform:'translate('+x+','+y+') rotate('+(rot||0)+')'},S.g);E('path',{d:'M0 0 h'+s+' v'+(s*0.35)+' h'+(-s*0.65)+' v'+(s*0.65)+' h'+(-s*0.35)+' Z',fill:'rgba(31,111,178,.25)',stroke:C.blue,'stroke-width':1.5},g);return g}
