var CODE='4J08',TITLE="4-sinf · Kesish, ustun va oraliqlar";
function u8L(a,b,c,d,col,w){E('line',{x1:a,y1:b,x2:c,y2:d,stroke:col||'#2a4a6a','stroke-width':w||2,'stroke-linecap':'round'},S.g)}
function u8Tree(x,y){E('circle',{cx:x,cy:y-7,r:6,fill:'#5fb36a',stroke:'#2e7d3a'},S.g);u8L(x,y-2,x,y+4,'#8a5a24',2.5)}
function u8Road(both){clear();var x0=30,x1=330;E('rect',{x:x0,y:70,width:x1-x0,height:34,fill:'#d9dde2'},S.g);u8L(x0,87,x1,87,'#fff',2);for(var i=0;i<=10;i++){var x=x0+i*(x1-x0)/10;u8Tree(x,64);if(both)u8Tree(x,122)}T(S.g,180,150,'100 m, har 10 m da',{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
function u8Sq(){clear();var x0=120,y0=30,L=120;E('rect',{x:x0,y:y0,width:L,height:L,fill:'#eaf5e3',stroke:'#2a4a6a','stroke-width':2},S.g);for(var i=0;i<20;i++){var t=i*24/L,s=Math.floor(i/5),k=(i%5)*24,x,y;if(s===0){x=x0+k;y=y0}else if(s===1){x=x0+L;y=y0+k}else if(s===2){x=x0+L-k;y=y0+L}else{x=x0;y=y0+L-k}E('circle',{cx:x,cy:y,r:4.5,fill:C.bad},S.g)}T(S.g,300,95,'P = 40 m',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});T(S.g,300,115,'har 2 m',{'font-size':12,'font-weight':700,fill:'#3a4a5a'})}
function u8Log(n,cuts){clear();var x0=40,x1=320;E('rect',{x:x0,y:66,width:x1-x0,height:32,rx:10,fill:'#d9a35a',stroke:'#8a5a24','stroke-width':1.5},S.g);for(var i=1;i<n;i++){var x=x0+i*(x1-x0)/n;u8L(x,56,x,108,C.bad,2.5)}T(S.g,180,138,cuts,{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
function u8Stairs(){clear();var x=40,y=150;for(var f=1;f<=6;f++){var yy=y-(f-1)*24;u8L(x,yy,330,yy,'#c9d3dd',1);T(S.g,24,yy+4,f+'',{'font-size':12,'font-weight':800,fill:f<=3?C.blue:'#7a8899'})}u8L(60,150,180,102,C.blue,4);u8L(180,102,320,30,'#b9c3cd',4);T(S.g,110,112,'36 zina',{'font-size':13,'font-weight':800,fill:C.blue});T(S.g,270,86,'?',{'font-size':18,'font-weight':800,fill:C.bad})}
function u8Bells(n){clear();for(var i=0;i<n;i++){var x=40+i*(280/(n-1));E('circle',{cx:x,cy:80,r:9,fill:C.a,stroke:'#8a5a24'},S.g);if(i<n-1){var m=x+140/(n-1);T(S.g,m,64,'?',{'font-size':12,'font-weight':800,fill:C.blue})}}T(S.g,180,120,'6 ta zarb — 5 ta oraliq — 5 soniya',{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
function u8Cake(k){clear();E('circle',{cx:180,cy:86,r:70,fill:'#fde2c8',stroke:'#8a5a24','stroke-width':2},S.g);var L=[[115,60,250,110],[115,115,250,55],[138,24,160,150]];for(var i=0;i<k;i++)u8L(L[i][0],L[i][1],L[i][2],L[i][3],C.bad,2.5)}
var STEPS=[
J4({h:"Ikki tomonga ustunlar",sum:"100 m da har 10 m — 10 ta oraliq, 11 ta daraxt (boshi va oxiri bilan). Ikki tomonda 22.",a:"m01",
 s:function(){u8Road(0)},m:"Oraliqlar 10 ta, daraxtlar-chi?",f:function(){u8Road(1);j3Msg('Bir tomonda 10 + 1 = 11, ikki tomonda <b>22</b>')},
 html:"<p>100 m uzunlikdagi yo'lning <b>ikkala</b> tomoniga har 10 m da daraxt ekildi (boshida ham, oxirida ham). Jami nechta daraxt?</p>",
 ch:["22","20","11","21"],ok:0,bad:["","100 : 10 · 2 = 20 — bu oraliqlar, daraxtlar har tomonda bittaga ko‘p","11 — faqat bir tomon","21 — 11 + 10? Ikki tomon bir xil"],
 after:"<p>Ochiq chiziqda: <b>ustunlar = oraliqlar + 1</b>. 100 : 10 = 10 oraliq → 11 daraxt. Ikki tomonda: 11 · 2 = 22. Eng ko'p xato — oraliqlar sonini daraxtlar soni deb olish yoki ikkinchi tomonni unutish.</p>",
 q:{t:"60 m yo'lning bir tomoniga har 5 m da ustun qo'yildi (boshi va oxirida ham). Nechta ustun?",opts:["13","12","14","26"],ok:0,why:"60 : 5 = 12 oraliq, ustunlar 13.",hint:"Avval oraliqlarni sanang.",full:"12 oraliq + 1 = 13. «12» — oraliqlar, «26» — ikki tomon deb olish."},
 tn:"Barmoqlar bilan: 4 ta oraliq — 5 ta barmoq. Bolalar o'z qo'lida tekshirsin."}),
J4({h:"Yopiq chiziq: ustunlar = oraliqlar",sum:"Kvadrat maydon perimetri 40 m, har 2 m da ustun: 20 ta oraliq, yopiq chiziqda ustunlar ham 20 ta.",a:"m02",
 s:u8Sq,m:"Yopiq chiziqda boshi va oxiri bir nuqta",f:function(){u8Sq();j3Msg('40 : 2 = 20 oraliq = <b>20</b> ustun')},
 html:"<p>Kvadrat shaklidagi maydon atrofi (perimetri) 40 m. Atrofiga har 2 m da ustun qo'yildi, burchaklarda ham. Nechta ustun?</p>",
 ch:["20","21","24","16"],ok:0,bad:["","Yopiq chiziqda boshi va oxiri bitta ustun — +1 kerak emas","Burchaklarni ikki marta sanadingiz","Har tomonda 5 tadan emas: 10 m : 2 = 5 oraliq"],
 after:"<p>Yopiq chiziqda (aylana, kvadrat, uchburchak atrofi) oxirgi oraliq birinchi ustunga qaytib keladi: <b>ustunlar = oraliqlar</b>. 40 : 2 = 20. Tekshirish: har tomonda 5 oraliq, 4 tomon — 20 ✓.</p>",
 q:{t:"Doira shaklidagi hovuz atrofi 36 m. Atrofiga har 4 m da daraxt ekildi. Nechta daraxt?",opts:["9","10","8","36"],ok:0,why:"Yopiq chiziq: 36 : 4 = 9.",hint:"Chiziq ochiqmi yoki yopiqmi?",full:"Yopiq chiziqda ustunlar = oraliqlar = 36 : 4 = 9. «10» — ochiq chiziq qoidasi."},
 tn:"Ip bilan halqa yasang, unga qisqichlar teng oraliqda taqing — oraliqlar va qisqichlarni sanang."}),
J4({h:"Vaqt kesishga sarflanadi",sum:"4 bo'lak — 3 kesish — 12 daqiqa → 1 kesish 4 daqiqa. 8 bo'lak — 7 kesish — 28 daqiqa.",a:"m03",
 s:function(){u8Log(4,'4 bo‘lak — 12 daqiqa')},m:"Necha marta kesildi?",f:function(){u8Log(8,'7 kesish · 4 daqiqa = 28 daqiqa');j3Msg('1 kesish = 12 : 3 = 4 daqiqa')},
 html:"<p>Brusni 4 bo'lakka arralash uchun 12 daqiqa ketdi. Xuddi shunday brusni <b>8 bo'lakka</b> arralash uchun necha daqiqa kerak?</p>",
 ch:["28","24","32","21"],ok:0,bad:["","12 · 2 = 24 — bo‘laklar 2 marta, kesishlar 2 marta emas","8 · 4 = 32 — 8 ta kesish emas, 7 ta","7 kesish to‘g‘ri, lekin 1 kesish 3 daqiqa emas: 12 : 3 = 4"],
 after:"<p>Vaqt <b>kesishlarga</b> ketadi. 4 bo'lak — 3 kesish → 1 kesish 4 daqiqa. 8 bo'lak — 7 kesish → 7 · 4 = <b>28</b> daqiqa. Kesishlar = bo'laklar − 1.</p>",
 q:{t:"Yog'ochni 5 bo'lakka arralash 20 daqiqa oldi. 3 bo'lakka arralash necha daqiqa?",opts:["10","12","15","8"],ok:0,why:"4 kesish — 20 daqiqa → 5 daqiqa; 2 kesish — 10.",hint:"5 bo'lak uchun nechta kesish?",full:"5 bo'lak — 4 kesish → 1 kesish 5 daqiqa. 3 bo'lak — 2 kesish → 10 daqiqa. «12» — 20 : 5 · 3."},
 tn:"Qog'oz lentani bolalar o'zi qaychi bilan kessin: 3 kesish — 4 bo'lak."}),
J4({h:"Zinapoya va qavatlar",sum:"1-qavatdan 3-qavatga 2 ta qavat oralig'i: 36 : 2 = 18. 1-dan 6-qavatga 5 oraliq: 90.",a:"m04",
 s:u8Stairs,m:"Necha qavat ko‘tarildingiz — 3 tami yoki 2 tami?",f:function(){u8Stairs();j3Msg('36 : 2 = 18 zina; 5 oraliq · 18 = <b>90</b>')},
 html:"<p>1-qavatdan 3-qavatga 36 ta zina bor (har qavat orasidagi zinalar teng). 1-qavatdan <b>6-qavatga</b> nechta zina?</p>",
 ch:["90","108","72","120"],ok:0,bad:["","36 : 3 = 12 deb olib, 9 marta? 1-dan 3-ga 2 ta oraliq bor","36 · 2 = 72 — 6-qavat 3-ning ikki barobari emas","Oraliq 24 emas: 36 : 2 = 18"],
 after:"<p>1-qavatdan 3-qavatga chiqqanda <b>2 ta</b> oraliq o'tiladi (1→2, 2→3). 36 : 2 = 18 zina. 1→6: 5 oraliq · 18 = <b>90</b>. Qavatlar bilan ham xuddi ustunlar kabi: oraliqlar = qavatlar farqi.</p>",
 q:{t:"1-qavatdan 4-qavatga 60 ta zina. 2-qavatdan 7-qavatga nechta zina?",opts:["100","120","80","140"],ok:0,why:"3 oraliq — 60 → 20; 5 oraliq — 100.",hint:"1→4 da nechta oraliq? 2→7 da-chi?",full:"1→4: 3 oraliq, 60 : 3 = 20. 2→7: 5 oraliq · 20 = 100."},
 tn:"Maktab binosidagi haqiqiy zinalarni sanab, keyingi darsda masala qiling."}),
J4({h:"Soat zarblari",sum:"6 marta zarb — 5 ta oraliq — 5 soniya → 1 oraliq 1 soniya. 12 marta — 11 oraliq — 11 soniya.",a:"m05",
 s:function(){u8Bells(6)},m:"Vaqt zarblar orasidagi oraliqlarga ketadi",f:function(){u8Bells(6);j3Msg('12 zarb — 11 oraliq — <b>11</b> soniya')},
 html:"<p>Soat 6 da soat 6 marta zarb uradi va bunga 5 soniya ketadi (birinchi zarbdan oxirgisigacha). Soat 12 da 12 marta zarb uradi. Bunga necha soniya ketadi?</p>",
 ch:["11","10","12","6"],ok:0,bad:["","10 = 5 · 2 — zarblar 2 marta, oraliqlar 2 marta emas","12 — oraliqlar zarblardan bittaga kam","6 — bu zarblar soni"],
 after:"<p>6 zarb orasida 5 ta oraliq → 1 oraliq 1 soniya. 12 zarb orasida <b>11</b> oraliq → 11 soniya. Bu yana «ustunlar va oraliqlar» masalasi, faqat vaqtda.</p>",
 q:{t:"Qo'ng'iroq 4 marta chalinishi uchun 6 soniya ketadi. 7 marta chalinishi uchun-chi?",opts:["12","10","14","9"],ok:0,why:"3 oraliq — 6 s → 2 s; 6 oraliq — 12 s.",hint:"4 zarb orasida nechta oraliq?",full:"4 zarb — 3 oraliq: 6 : 3 = 2 soniya. 7 zarb — 6 oraliq: 12 soniya. «10» — 6 : 4 · 7 ga yaqin xato."},
 tn:"Stol ustiga bolalar barmoq bilan urib, sekundomer bilan o'lchasin."}),
J4({h:"Tuzoq: eng ko'p bo'lak",sum:"Tortni 3 ta to'g'ri kesish bilan eng ko'pi 7 bo'lakka bo'lish mumkin: har yangi chiziq oldingilarning hammasini kesib o'tsin.",a:"m06",
 s:function(){u8Cake(2)},m:"2 ta kesish — 4 bo‘lak. Uchinchi chiziqni qanday o‘tkazsak, eng ko‘p bo‘lak chiqadi?",f:function(){u8Cake(3);j3Msg('3-chiziq ikkala chiziqni kesadi → 3 ta yangi bo‘lak: 4 + 3 = <b>7</b>')},
 html:"<p>Dumaloq tortni yuqoridan 3 ta to'g'ri chiziq bo'ylab kesish mumkin (bo'laklarni ustma-ust qo'ymasdan). <b>Eng ko'pi</b> bilan nechta bo'lak hosil bo'ladi?</p>",
 ch:["7","6","8","9"],ok:0,bad:["","6 — uchala chiziq bir nuqtadan o‘tsa. Ularni har xil joyda kesishtiring","8 — bu kubni 3 marta kesganda (fazoda). Tekislikda 7","9 — 3 · 3? Har chiziq faqat o‘zi kesgan bo‘laklarni ikkiga bo‘ladi"],
 after:"<p>1-kesish: 2 bo'lak. 2-kesish birinchini kesib o'tsa: +2 = 4. 3-kesish ikkala chiziqni (har xil nuqtada) kesib o'tsa, 3 ta bo'lakdan o'tadi: +3 = <b>7</b>. Qoida: n-kesish eng ko'pi n ta yangi bo'lak qo'shadi: 2, 4, 7, 11, 16 …</p>",
 q:{t:"Kub shaklidagi pishloqni 3 ta tekis kesish bilan (bo'laklarni siljitmasdan) eng ko'pi nechta bo'lakka bo'lish mumkin?",opts:["8","6","7","9"],ok:0,why:"Uch yo'nalishda kesish: 2 · 2 · 2 = 8.",hint:"Tik, ko'ndalang va yotiq kesishlarni tasavvur qiling.",full:"Har kesish barcha bo'laklarni ikkiga bo'ladi: 2 → 4 → 8. «7» — tekislikdagi tort javobi."},
 tn:"Doskada aylana chizing, bolalar 3 ta chiziqni turlicha o'tkazib, bo'laklarni sanasin: 4, 5, 6, 7."}),
J4info({h:"Bilasizmi? Marafon masofasi",a:"m07",s:['42 km 195 m','km belgilari: 0, 1, 2, …, 42 → 43 ta'],so:{fs:17,lh:42},m:"Har kilometr belgisi — ustun",
 html:"<p>🏃 Marafon masofasi — <b>42 km 195 m</b>. Bu masofa 1908-yil London Olimpiadasida yugurilgan va keyinchalik (1921-yilda) rasmiy masofa sifatida qabul qilingan. Yo'l bo'yidagi kilometr belgilari ham «ustunlar» masalasi: 0 dan 42 gacha butun kilometrlarga belgi qo'yilsa, ular 43 ta bo'ladi.</p>",
 tn:"Sinf xonasi uzunligini qadamlarda o'lchab, «qadamlar va izlar» (izlar = qadamlar + 1) masalasini tuzing."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){u8Log(4,'3 kesish — 4 bo‘lak')},m:"Oraliqlar va nuqtalarni ajrating",
 html:"<div class='memo'><ul><li>Ochiq chiziq: ustunlar = oraliqlar <b>+ 1</b>.</li><li>Yopiq chiziq: ustunlar = oraliqlar.</li><li>Kesishlar = bo'laklar <b>− 1</b>; vaqt kesishlarga sarflanadi.</li><li>Qavatlar: oraliqlar = yuqori qavat − pastki qavat.</li><li>Zarblar: oraliqlar = zarblar − 1.</li><li>Ikki tomon — ikki barobar; burchaklarni ikki marta sanamang.</li></ul></div>",
 tn:"Uyga: uydagi panjara yoki deraza romidan «ustunlar» masalasi tuzib kelish."})
];
var PROBS=[
{t:"Arqonni 6 bo'lakka bo'lish uchun nechta kesish kerak?",o:["5","6","7","12"],k:0,s:"Kesishlar = bo'laklar − 1 = 5."},
{t:"Lentani 3 marta kesishdi. Nechta bo'lak hosil bo'ldi?",o:["4","3","6","2"],k:0,s:"3 + 1 = 4."},
{t:"50 m yo'lning bir tomoniga har 5 m da ustun qo'yildi (boshi va oxirida ham). Nechta ustun?",o:["11","10","12","9"],k:0,s:"10 oraliq + 1 = 11."},
{t:"Qo'shni ustunlar orasi 9 m. 1-ustundan 8-ustungacha necha metr?",o:["63","72","54","81"],k:0,s:"7 oraliq · 9 = 63."},
{t:"Aylana yo'lakka teng oraliqda 12 ta chiroq o'rnatildi. Chiroqlar orasidagi oraliqlar nechta?",o:["12","11","13","24"],k:0,s:"Yopiq chiziq: oraliqlar = chiroqlar."},
{t:"Uchburchak maydonning har tomoni 30 m. Atrofiga har 5 m da ustun qo'yildi, burchaklarda ham. Nechta ustun?",o:["18","21","19","15"],k:0,s:"Perimetr 90 : 5 = 18."},
{t:"Taxtani 6 bo'lakka arralash uchun 25 daqiqa ketdi. 10 bo'lakka arralash uchun-chi?",o:["45","50","40","41"],k:0,s:"5 kesish — 25 → 5 daqiqa; 9 kesish — 45."},
{t:"1-qavatdan 5-qavatgacha 64 ta zina. 1-qavatdan 9-qavatgacha nechta zina?",o:["128","144","115","112"],k:0,s:"4 oraliq — 64 → 16; 8 oraliq — 128."},
{t:"Lift 1-qavatdan 3-qavatga 6 soniyada chiqadi. 1-qavatdan 9-qavatga necha soniyada chiqadi (to'xtamasdan)?",o:["24","18","27","30"],k:0,s:"2 oraliq — 6 s → 3 s; 8 oraliq — 24 s."},
{t:"Soat 5 da 5 marta zarb uradi va bunga 8 soniya ketadi. Soat 10 dagi 10 zarb uchun necha soniya?",o:["18","16","20","9"],k:0,s:"4 oraliq — 8 s → 2 s; 9 oraliq — 18 s."},
{t:"Qatorda 10 bola turibdi, qo'shnilar orasi 1 m. Birinchi boladan oxirgisigacha necha metr?",o:["9","10","11","8"],k:0,s:"9 oraliq."},
{t:"Kitob betlari 1 dan 120 gacha raqamlangan. Jami nechta raqam yozilgan?",o:["252","240","360","249"],k:0,s:"1–9: 9, 10–99: 90 · 2 = 180, 100–120: 21 · 3 = 63. Jami 252."},
{t:"Kitobning 15-betidan 40-betigacha (ikkalasi ham kiradi) nechta bet bor?",o:["26","25","27","40"],k:0,s:"40 − 15 + 1 = 26."},
{t:"Yo'lning ikki tomoniga jami 42 ta daraxt teng oraliqda (boshi va oxirida ham) ekildi. Oraliq 6 m. Yo'l uzunligi?",o:["120","126","240","114"],k:0,s:"Bir tomonda 21 ta → 20 oraliq · 6 = 120 m."},
{t:"To'g'ri panjarada 8 ta ustun bor, ular orasi 2 m. Panjara uzunligi?",o:["14","16","18","12"],k:0,s:"7 oraliq · 2 = 14 m."},
{t:"Tortni yuqoridan 4 ta to'g'ri kesish bilan eng ko'pi nechta bo'lakka bo'lish mumkin?",o:["11","8","10","16"],k:0,s:"2, 4, 7, 11."},
{t:"Bitta kesishga 3 daqiqa ketadi, har kesishdan keyin 1 daqiqa dam olinadi (oxirgisidan keyin emas). Yog'ochni 5 bo'lakka necha daqiqada arralash mumkin?",o:["15","16","20","19"],k:0,s:"4 kesish · 3 = 12, 3 ta dam = 3: jami 15."},
{t:"Avtobus 1-bekatdan 7-bekatgacha 24 daqiqa yuradi (bekatlar orasi bir xil). 3-bekatdan 10-bekatgacha necha daqiqa?",o:["28","32","24","35"],k:0,s:"6 oraliq — 24 → 4; 7 oraliq — 28."},
{t:"Kvadrat hovuz atrofiga har tomonga 6 tadan daraxt ekildi, burchaklarda ham. Jami nechta daraxt?",o:["20","24","22","18"],k:0,s:"Burchaklar ikki marta sanalgan: 24 − 4 = 20."},
{t:"1 m tayoqni 20 sm li bo'laklarga kesish uchun nechta kesish kerak?",o:["4","5","20","6"],k:0,s:"100 : 20 = 5 bo'lak → 4 kesish."}
];
function PRACT_STAGE(){u8Road(1)}
var PREP_DATA={teach:["Ochiq chiziq: ustunlar = oraliqlar + 1.","Yopiq chiziq: ustunlar = oraliqlar.","Kesish vaqti, qavatlar, soat zarblari — oraliqlar.","Eng ko'p bo'lak: tekislikda va fazoda."],
 mist:["Oraliqlarni ustunlar deb hisoblaydi (yoki aksincha).","3-qavatga chiqishni 3 ta oraliq deb oladi.","Yopiq chiziqda ham +1 qiladi."],
 need:["Qog'oz lenta, qaychi.","Ip va qisqichlar (yopiq chiziq).","Sekundomer."],
 board:["ochiq: n oraliq → n + 1 ustun","yopiq: n oraliq → n ustun","kesish = bo'lak − 1","qavat: 1 → k: k − 1 oraliq"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
