var CODE='3B5',TITLE='3-sinf · Qulay usulda hisoblash';
var P1=[function(){bqLine(390,650,[],[[398,C.blue]],{step:50});bqMsg('398 + 246 — ustunda yozmasdan hisoblaymiz')},
 function(){bqLine(390,650,[[398,400,'+2',C.ok]],[[398,C.blue],[400,C.ok]],{step:50});bqMsg('398 ga 2 qo‘shsak — yaxlit 400')},
 function(){bqLine(390,650,[[398,400,'+2',C.ok],[400,646,'+246',C.blue]],[[400,C.ok],[646,C.blue]],{step:50});bqMsg('400 + 246 = 646')},
 function(){bqLine(390,650,[[398,400,'+2',C.ok],[400,646,'+246',C.blue],[646,644,'−2',C.bad]],[[644,C.bad]],{step:50});bqMsg('Ortiqcha qo‘shgan 2 ni qaytaramiz: 646 − 2 = <b>644</b>')}];
var P3=[function(){bqExpr(['723 − 298']);bqMsg('298 — 300 ga juda yaqin')},function(){bqExpr(['723 − 300 = 423']);bqMsg('300 ni ayiramiz — 2 ta ortiqcha ayirdik')},function(){bqExpr(['723 − 300 = 423','423 [+ 2] = [425]']);bqMsg('Ortiqcha ayirilgan 2 ni qaytaramiz (qo‘shamiz!): 425')}];
var P5=[function(){bqExpr(['900 − (500 + 175)']);bqMsg('Sondan yig‘indini ayirish')},function(){bqExpr(['900 − 500 − 175']);bqMsg('Qavsni ochamiz: avval 500 ni, keyin 175 ni ayiramiz')},function(){bqExpr(['900 − 500 = 400','400 − 175 = [225]']);bqMsg('Yaxlit sondan boshlash oson: 225')}];
var P6=[function(){bqExpr(['(463 + 285) − 263']);bqMsg('Yig‘indidan sonni ayirish: qaysi qo‘shiluvchidan ayirish qulay?')},function(){bqExpr(['(463 − 263) + 285']);bqMsg('463 dan 263 ni ayirish oson — 200!')},function(){bqExpr(['200 + 285 = [485]']);bqMsg('Javob: 485. Ustunda yozish shart bo‘lmadi')}];
var P7=[function(){bqExpr(['1000 − 637']);bqMsg('Qarz kerak bo‘ladigan ayirish')},function(){bqExpr(['(1000 − 1) − (637 − 1)','= 999 − 636']);bqMsg('Ikkalasidan 1 ni ayiramiz — ayirma o‘zgarmaydi')},function(){bqExpr(['999 − 636 = [363]']);bqMsg('999 dan ayirishda hech qachon qarz kerak emas!')}];
var STEPS=[
{h:"Yaxlitlab olish va to'g'rilash",sum:"398 + 246: 398 → 400 (+2), 400 + 246 = 646, 646 − 2 = 644.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Ustunda yozmasdan ham hisoblash mumkin. 398 — 400 ga juda yaqin. Shu yaqinlikdan foydalanamiz. Son o'qida kuzating.</p>",btns:[phaser(P1)],
 after:"<p>Usul: <b>yaxlitlang</b> → hisoblang → <b>to'g'rilang</b>. Qo'shishda ko'p qo'shgan bo'lsangiz — ayiring. Bu usul Gollandiya va Singapur darsliklarida «kompensatsiya» deb ataladi.</p>",
 q:{t:"597 + 285 = ?",opts:["882","887","872","782"],ok:0,why:"600 + 285 = 885, 885 − 3 = 882.",hint:"597 ni 600 ga yaxlitlang. Nechta ortiqcha qo'shdingiz?",full:"597 + 3 = 600. 600 + 285 = 885. 3 ortiqcha qo'shildi — ayiramiz: 885 − 3 = 882. «887» — to'g'rilashda ayirish o'rniga qo'shilgan."},
 tn:"Bolalar har kuni 2–3 daqiqa og'zaki hisoblasin: «499 + 237», «198 + 456». Ular tez orada o'zlari yaxlitlashni boshlaydi."},
{h:"Juftlab yaxlit qilish",sum:"125 + 347 + 75 = (125 + 75) + 347 = 200 + 347 = 547. Juftlari yaxlit son beradigan sonlarni topamiz.",a:"m02",start:function(){S._p=[];bqExpr(['125   360   75   640   250   750']);bqMsg('Yig‘indisi yaxlit yuzlik bo‘ladigan juftlarni toping')},fin:function(){bqExpr(['125 + 75 = 200','360 + 640 = 1000','250 + 750 = 1000']);bqMsg('Uchta «do‘st juft»')},
 html:"<p>Qaysi juftlarning yig'indisi yaxlit yuzlik? Uchta «do'st juft»ni toping:</p>",g3:1,
 btns:[["125 + 75",function(c,d,b){w3b5p(b,d,1)}],["360 + 75",function(c,d,b){w3b5p(b,d,0)}],["360 + 640",function(c,d,b){w3b5p(b,d,1)}],["250 + 640",function(c,d,b){w3b5p(b,d,0)}],["250 + 750",function(c,d,b){w3b5p(b,d,1)}],["125 + 640",function(c,d,b){w3b5p(b,d,0)}]],
 after:"<p>Qo'shishda o'rin almashtirish va guruhlash mumkin. Shuning uchun avval <b>«do'st juftlar»</b>ni qidiring: 125 + 75, 360 + 640, 250 + 750. Ular yaxlit son beradi.</p>",
 q:{t:"236 + 158 + 64 + 42 = ?",opts:["500","490","400","510"],ok:0,why:"(236 + 64) + (158 + 42) = 300 + 200 = 500.",hint:"Birliklari qo'shilganda 10 bo'ladigan juftlarni toping: 6 va 4, 8 va 2.",full:"236 + 64 = 300, 158 + 42 = 200. Jami 500. Ketma-ket qo'shsak ham 500 chiqadi, lekin ancha uzoq."},
 tn:"«Do'st sonlar» o'yini: biri son aytadi (365), ikkinchisi uni 1000 gacha to'ldiradi (635)."},
{h:"Ayirishda yaxlitlash",sum:"723 − 298: 300 ni ayiramiz (423), ortiqcha ayirilgan 2 ni qaytaramiz: 425.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ayirishda ham yaxlitlash mumkin, lekin <b>ehtiyot bo'ling</b>: to'g'rilash yo'nalishi boshqacha.</p>",btns:[phaser(P3)],
 after:"<p>Ko'p <b>ayirgan</b> bo'lsangiz — farqni <b>qo'shib</b> qaytaring. Bu eng ko'p adashiladigan joy: 723 − 300 = 423, keyin <b>+2</b> (−2 emas!).</p>",
 q:{t:"815 − 397 = ?",opts:["418","412","428","518"],ok:0,why:"815 − 400 = 415, 415 + 3 = 418.",hint:"397 ni 400 ga yaxlitlang. Ko'p ayirdingizmi yoki kam?",full:"815 − 400 = 415. 3 ta ortiqcha ayirildi — qaytaramiz: 415 + 3 = 418. «412» — to'g'rilash teskari qilingan."},
 tn:"Pul bilan tushuntiring: 723 so'mdan 298 so'm to'lash uchun 300 so'm berdik — 2 so'm qaytim olamiz."},
{h:"Xona bo'yicha ajratib hisoblash",sum:"456 + 327 = (400 + 300) + (50 + 20) + (6 + 7) = 700 + 70 + 13 = 783.",a:"m04",start:function(){S._x=[];bqExpr(['456 + 327']);bqMsg('Har xonani alohida qo‘shamiz')},fin:function(){S._x=[0,1,2];bqExpr(['400 + 300 = 700','50 + 20 = 70','6 + 7 = 13','700 + 70 + 13 = [783]']);bqMsg('Javob: 783')},
 html:"<p>Boshqa usul: sonlarni xonalarga ajratib, har xonani alohida qo'shamiz. Tugmalarni ketma-ket bosing:</p>",
 btns:[["yuzliklar",function(c,done,b){b.disabled=true;w3b5x(0,done)}],["o'nliklar",function(c,done,b){b.disabled=true;w3b5x(1,done)}],["birliklar",function(c,done,b){b.disabled=true;w3b5x(2,done)}]],
 after:"<p>Bu usul — og'zaki hisobning «suyagi». U chapdan (yuzliklardan) boshlanadi, shuning uchun javobning taxminiy kattaligi darhol ko'rinadi: 456 + 327 — «700 dan ko'p».</p>",
 q:{t:"538 + 246 ni xonalar bo'yicha hisoblang.",opts:["784","774","7714","684"],ok:0,why:"700 + 70 + 14 = 784.",hint:"500 + 200, 30 + 40, 8 + 6 — keyin hammasini qo'shing.",full:"Yuzliklar: 700, o'nliklar: 70, birliklar: 14. 700 + 70 + 14 = 784. «7714» — natijalar yonma-yon yozilgan, qo'shilmagan."},
 tn:"Bolalar natijalarni ustma-ust yozib qo'shsin: 700 / 70 / 14 — so'ng 784."},
{h:"Sondan yig'indini ayirish",sum:"900 − (500 + 175) = 900 − 500 − 175 = 225.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Sondan yig'indini ayirishda qavsni ochib, <b>har qo'shiluvchini ketma-ket</b> ayirish mumkin.</p>",btns:[phaser(P5)],
 after:"<p><b>a − (b + c) = a − b − c</b>. Qavsni ochganda qavs ichidagi «+» ayirishga aylanadi — chunki ikkala qism ham ketadi.</p>",
 q:{t:"800 − (350 + 150) = ?",opts:["300","600","500","200"],ok:0,why:"350 + 150 = 500, 800 − 500 = 300.",hint:"Qavs ichini avval hisoblash qulay: 350 + 150.",full:"350 + 150 = 500 (do'st juft!). 800 − 500 = 300. «600» — 800 − 350 + 150 qilingan: qavs ochilganda ishora o'zgarmagan."},
 tn:"Qavs ichida do'st juft bo'lsa — avval qavsni hisoblash qulay; bo'lmasa — ketma-ket ayirish qulay. Bolalar o'zi tanlashni o'rgansin."},
{h:"Yig'indidan sonni ayirish",sum:"(463 + 285) − 263 = (463 − 263) + 285 = 485.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Yig'indidan sonni ayirganda, uni <b>qulay qo'shiluvchidan</b> ayirish mumkin.</p>",btns:[phaser(P6)],
 after:"<p><b>(a + b) − c = (a − c) + b</b>. Qaysi qo'shiluvchidan ayirish oson bo'lsa — o'shandan ayiramiz. Bu yerda 463 − 263 = 200.</p>",
 q:{t:"(375 + 518) − 318 = ?",opts:["575","893","475","675"],ok:0,why:"518 − 318 = 200, 375 + 200 = 575.",hint:"Qaysi qo'shiluvchidan 318 ni ayirish oson?",full:"518 − 318 = 200 — oson. 375 + 200 = 575. Ketma-ket qilsak: 893 − 318 = 575 — ham to'g'ri, lekin qiyinroq."},
 tn:"Olimpiada testlarida bunday «yashirin qulaylik» doim bor. Bolalar hisoblashdan oldin 5 soniya sonlarga «qarab tursin»."},
{h:"Tuzoq: 1000 dan ayirish qarzsiz",sum:"1000 − 637 = 999 − 636 = 363: ikkalasidan 1 ayirsak, qarz kerak bo'lmaydi.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Kamayuvchi va ayriluvchidan <b>bir xil son</b> ayirsak (yoki qo'shsak), ayirma o'zgarmaydi. Bundan foydalanamiz.</p>",btns:[phaser(P7)],
 after:"<p>Ayirmaning xossasi: <b>(a − 1) − (b − 1) = a − b</b>. 999 ning hamma raqami 9 — undan istalgan raqamni qarzsiz ayirish mumkin.</p>",
 q:{t:"5000 − 2648 = ?",opts:["2352","3462","2452","3352"],ok:0,why:"4999 − 2647 = 2352.",hint:"Ikkalasidan 1 ni ayiring: 4999 − 2647.",full:"5000 − 2648 = 4999 − 2647. 4 − 2 = 2, 9 − 6 = 3, 9 − 4 = 5, 9 − 7 = 2: 2352. Tekshirish: 2352 + 2648 = 5000 ✓."},
 tn:"Bu usul ko'p xonali sonlar bilan ham ishlaydi (3B7). Kuchli o'quvchilarga «70 000 − 23 456» ni berib ko'ring."},
{h:"Umumiy ko'paytuvchini chiqarish",sum:"8 · 5 + 8 · 9 − 8 · 7 − 8 · 6 = 8 · (5 + 9 − 7 − 6) = 8 · 1 = 8. 4 · 37 · 25 = (4 · 25) · 37 = 3700.",a:"m08",start:function(){bqExpr(['8 · 5 + 8 · 9 − 8 · 7 − 8 · 6']);bqMsg('Har qo‘shiluvchida 8 bor — bu nimani beradi?')},fin:function(){bqExpr(['8 · 5 + 8 · 9 − 8 · 7 − 8 · 6','= 8 · (5 + 9 − 7 − 6)','= 8 · 1 = [8]']);bqMsg('Umumiy ko‘paytuvchini qavsdan tashqariga chiqardik')},
 html:"<p>Har bir hadda <b>8</b> bor: 8 ta beshlik, 8 ta to'qqizlik… Ularni «sakkizliklar» sifatida sanaymiz. Qiymati nechaga teng?</p>",g3:1,
 btns:[["8",function(c,d,b){bqExpr(['8 · 5 + 8 · 9 − 8 · 7 − 8 · 6','= 8 · (5 + 9 − 7 − 6)','= 8 · 1 = [8]']);w3b5c(b,d,1,'5 + 9 − 7 − 6 = 1 ta sakkizlik qoldi: 8','')}],["0",function(c,d,b){w3b5c(b,d,0,'','Qavs ichini hisoblang: 5 + 9 − 7 − 6 = ?')}],["16",function(c,d,b){w3b5c(b,d,0,'','5 + 9 = 14, 14 − 7 − 6 = 1 — 2 emas')}]],
 after:"<p><b>a · b + a · c = a · (b + c)</b> va <b>a · b − a · c = a · (b − c)</b>. «8 ta beshlik va 8 ta to'qqizlik» = «8 ta o'n to'rtlik». Ko'paytirishda esa do'st juftlar: <b>4 · 25 = 100</b>, shuning uchun 4 · 37 · 25 = 100 · 37 = 3700.</p>",
 q:{t:"6 · 17 + 6 · 13 = ?",opts:["180","102","216","36"],ok:0,why:"6 · (17 + 13) = 6 · 30 = 180.",hint:"Ikkala hadda ham 6 bor. 17 + 13 = ?",full:"6 · 17 + 6 · 13 = 6 · (17 + 13) = 6 · 30 = 180. «102» — faqat 6 · 17; «216» — 6 · 36 (qavs noto'g'ri qo'shilgan)."},
 tn:"Bolalarga «6 ta qutida 17 tadan va yana 6 ta qutida 13 tadan» deb tasavvur qildiring: 6 ta qutini birlashtirsak — 6 ta 30 lik."},
{h:"Bilasizmi? Gaussning hiylasi",sum:"1 + 2 + … + 100 = 50 · 101 = 5050: juftlab qo'shish.",a:"m09",start:function(){bqExpr(['1 + 2 + 3 + … + 99 + 100 = ?']);bqMsg('Kichkina Gauss buni bir zumda topgan')},fin:function(){bqExpr(['1 + 100 = 101','2 + 99 = 101','… 50 ta juft','50 · 101 = [5050]']);bqMsg('Juftlab qo‘shish — eng qulay usul')},
 html:"<p>🎓 Rivoyat qilinishicha, nemis matematigi <b>Karl Gauss</b> boshlang'ich sinfda o'qiganida o'qituvchi 1 dan 100 gacha barcha sonlarni qo'shishni buyurgan. Gauss bir necha daqiqada <b>5050</b> deb javob bergan!</p>",
 btns:[["💡 Gauss qanday hisoblagan?",function(c,done){bqExpr(['1 + 100 = 101','2 + 99 = 101','… 50 ta juft','50 · 101 = [5050]']);bqMsg('Chetlardan juftlab: har juft 101');done()}]],
 after:"<p>U sonlarni chetlardan juftlagan: 1 + 100, 2 + 99, 3 + 98… Har biri 101, juftlar 50 ta. 50 · 101 = 5050. Bu — bugungi darsdagi «do'st juftlar»ning eng mashhur namunasi.</p>",
 tn:"Bolalar 1 + 2 + … + 10 ni Gauss usulida yechib ko'rsin: 5 · 11 = 55."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){bqExpr(['398 + 246 = 400 + 246 − 2 = 644']);bqMsg('Yaxlitla → hisobla → to‘g‘rila')},fin:function(){bqExpr(['398 + 246 = 400 + 246 − 2 = 644']);bqMsg('Yaxlitla → hisobla → to‘g‘rila')},
 html:"<div class='memo'><ul><li><b>Yaxlitla → hisobla → to'g'rila</b>: 398 + 246 = 400 + 246 − 2 = 644.</li><li>Ayirishda: 723 − 298 = 723 − 300 <b>+ 2</b> = 425 (ko'p ayirdik — qaytaramiz).</li><li><b>Do'st juftlar</b>: 125 + 75, 360 + 640 — avval ularni qo'shing.</li><li>Xonalar bo'yicha: 456 + 327 = 700 + 70 + 13.</li><li><b>a − (b + c) = a − b − c</b>; <b>(a + b) − c = (a − c) + b</b>.</li><li>1000 − 637 = 999 − 636 — qarzsiz.</li><li><b>a · b + a · c = a · (b + c)</b>; 4 · 25 = 100.</li></ul></div>",
 tn:"Keyingi darsni «Bitta misolni ikki xil qulay usulda yeching» topshirig'i bilan boshlang."}
];
function w3b5c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
function w3b5p(b,done,ok){var t=b.textContent;if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(t+' = '+eval(t)+' — yaxlit emas');setTimeout(function(){b.style.background=bg},2000);return}b.disabled=true;b.style.background='#e6f6ee';S._p=S._p||[];S._p.push(t+' = '+eval(t));bqExpr(['125   360   75   640   250   750'].concat(S._p));if(S._p.length===3){bqMsg('Uchta do‘st juft topildi!');done()}else bqMsg('Yana '+(3-S._p.length)+' ta')}
function w3b5x(k,done){S._x=S._x||[];if(S._x.indexOf(k)<0)S._x.push(k);var L=[['400 + 300 = 700'],['50 + 20 = 70'],['6 + 7 = 13']],sh=[];S._x.slice().sort().forEach(function(i){sh.push(L[i][0])});if(S._x.length===3)sh.push('700 + 70 + 13 = [783]');bqExpr(S._x.length===3?sh:['456 + 327'].concat(sh));bqMsg(S._x.length===3?'Javob: 783':'Davom eting');if(S._x.length===3)done()}
var PROBS=[
{t:"499 + 376 = ?",o:["875","876","865","975"],k:0,s:"500 + 376 = 876, 876 − 1 = 875."},
{t:"298 + 445 = ?",o:["743","747","733","643"],k:0,s:"300 + 445 = 745, 745 − 2 = 743."},
{t:"634 − 199 = ?",o:["435","433","445","535"],k:0,s:"634 − 200 = 434, 434 + 1 = 435."},
{t:"852 − 396 = ?",o:["456","448","466","556"],k:0,s:"852 − 400 = 452, 452 + 4 = 456."},
{t:"175 + 389 + 25 = ?",o:["589","579","599","489"],k:0,s:"175 + 25 = 200, 200 + 389 = 589."},
{t:"345 + 278 + 655 + 22 = ?",o:["1300","1200","1290","1310"],k:0,s:"(345 + 655) + (278 + 22) = 1000 + 300 = 1300."},
{t:"900 − (400 + 235) = ?",o:["265","735","365","165"],k:0,s:"900 − 400 = 500, 500 − 235 = 265."},
{t:"(548 + 375) − 348 = ?",o:["575","923","475","675"],k:0,s:"548 − 348 = 200, 200 + 375 = 575."},
{t:"1000 − 485 = ?",o:["515","625","525","615"],k:0,s:"999 − 484 = 515."},
{t:"Qaysi ifoda 723 − 298 ga teng?",o:["723 − 300 + 2","723 − 300 − 2","723 + 300 − 2","720 − 298 − 3"],k:0,s:"300 ni ayirib, ortiqcha 2 ni qaytaramiz: 723 − 300 + 2."},
{t:"Qaysi ifoda 398 + 246 ga teng?",o:["400 + 246 − 2","400 + 246 + 2","400 + 244 + 2","398 + 250 + 4"],k:0,s:"398 = 400 − 2: 400 + 246 − 2."},
{t:"736 + 199 + 64 = ?",o:["999","1000","899","1099"],k:0,s:"736 + 64 = 800, 800 + 199 = 999."},
{t:"1 + 2 + 3 + … + 20 = ?",o:["210","200","220","190"],k:0,s:"10 ta juft, har biri 21: 10 · 21 = 210."},
{t:"Qaysi juft «do'st» (yig'indisi yaxlit yuzlik)?",o:["365 va 235","365 va 245","365 va 135","365 va 645"],k:0,s:"365 + 235 = 600. Qolganlari 610, 500?.. 365 + 135 = 500 ham yaxlit — lekin 135 + 365 = 500 ✓? Tekshirish: 365 + 135 = 500."},
{t:"6000 − 2875 = ?",o:["3125","4235","3235","4125"],k:0,s:"5999 − 2874 = 3125."},
{t:"7 · 8 + 7 · 9 − 7 · 7 = ?",o:["70","77","63","56"],k:0,s:"7 · (8 + 9 − 7) = 7 · 10 = 70."},
{t:"4 · 39 · 25 = ?",o:["3900","975","1560","390"],k:0,s:"(4 · 25) · 39 = 100 · 39 = 3900."},
{t:"Qaysi ifodani hisoblash eng oson?",o:["(681 + 249) − 181","681 + 249 − 248","681 + (249 − 1)","681 − 249"],k:0,s:"(681 − 181) + 249 = 500 + 249 = 749 — eng qulay."},
{t:"Ali 398 + 265 ni 400 + 265 + 2 = 667 deb hisobladi. To'g'ri javob?",o:["663","667","665","673"],k:0,s:"400 + 265 = 665, ortiqcha 2 ni ayiramiz: 663."},
{t:"99 + 999 + 9999 = ?",o:["11097","11197","10997","11107"],k:0,s:"(100 − 1) + (1000 − 1) + (10000 − 1) = 11100 − 3 = 11097."}
];
PROBS[13]={t:"Qaysi juftning yig'indisi yaxlit yuzlik bo'lmaydi?",o:["365 va 245","365 va 235","365 va 135","365 va 635"],k:0,s:"365 + 245 = 610 — yaxlit yuzlik emas. 365 + 235 = 600, 365 + 135 = 500, 365 + 635 = 1000."};
function PRACT_STAGE(){bqExpr(['Yaxlitla → hisobla → to‘g‘rila']);bqMsg('Avval sonlarga qarang: qaysi usul qulay?')}
var PREP_DATA={teach:["Kompensatsiya: yaxlitlab olib, natijani to'g'rilash (qo'shish va ayirishda).","Do'st juftlar: o'rin almashtirish va guruhlash.","Xonalar bo'yicha og'zaki qo'shish.","a − (b + c) va (a + b) − c xossalari; 1000 dan qarzsiz ayirish."],
 mist:["Ayirishda to'g'rilash yo'nalishini adashtiradi (723 − 300 − 2).","Qavsni ochganda ishorani o'zgartirmaydi.","Xonalar natijasini yonma-yon yozadi (7714).","Do'st juftlarni qidirmasdan ketma-ket qo'shadi."],
 need:["Son o'qi (0–1000) doskada.","Kartochkalar: do'st juftlar o'yini uchun."],
 board:["<span class='w2'>398 + 246 = 400 + 246 − 2</span>","<span class='w2'>723 − 298 = 723 − 300 + 2</span>","<span class='w2'>125 + 347 + 75 = 200 + 347</span>","<span class='w2'>900 − (500 + 175) = 400 − 175</span>","<span class='w2'>(463 + 285) − 263 = 200 + 285</span>","<span class='w2'>1000 − 637 = 999 − 636</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
