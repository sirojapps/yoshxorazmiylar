
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3F3',TITLE='3-sinf · Ulushlarni taqqoslash';
// qatorlar: [n,k,yozuv,rang,ichki yozuvlar]
function f33rows(rows,o){o=o||{};clear();var h=o.h||26,gap=o.gap||10,y=o.y||(87-(rows.length*(h+gap)-gap)/2);if(o.title)T(S.g,14,16,o.title,{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 rows.forEach(function(r,i){var yy=y+i*(h+gap);T(S.g,48,yy+h/2+5,r[2],{'font-size':13,'font-weight':800,'text-anchor':'end',fill:r[3]||C.a});f3bar(56,yy,280,h,r[0],r[1],r[3],r[4])});
 if(o.half){var Y0=y-6,Y1=y+rows.length*(h+gap)-gap+6;E('line',{x1:196,y1:Y0,x2:196,y2:Y1,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 4'},S.g);T(S.g,196,Y1+11,'yarmi',{'font-size':10,fill:C.bad,'font-weight':700})}}
function f33lab(n,k){var a=[];for(var i=0;i<n;i++)a.push(n<=8?'1/'+n:'');return a}
function f33pick(okIdx,msgs){return function(i){return function(c,done,b){if(i===okIdx){f3msg('✓ '+msgs[i]);done()}else f3msg('<span style="color:#c0392b">✗</span> '+msgs[i])}}}
function f33cakes(st){clear();var d=[[4,'Lola','1/4',C.a],[3,'Ali','1/3',C.b],[6,'Vali','1/6',C.c]];d.forEach(function(q,i){var cx=70+i*110;f3circle(cx,80,46,q[0],st>=1?1:0,null,q[3]);T(S.g,cx,148,q[1]+' — '+q[2],{'font-size':12,'font-weight':800,fill:'#33475b'})});
 if(st>=2){T(S.g,180,166,'Ali > Lola > Vali',{'font-size':12,'font-weight':800,fill:C.ok})}}
var F3P3=[function(){f33rows([[4,0,'?',C.a,f33lab(4)],[5,0,'?',C.b,f33lab(5)]],{title:'3/4 va 3/5 — suratlar bir xil'});f3calc(['Ikkalasida 3 tadan bo‘lak. Qaysi bo‘laklar katta?'])},
 function(){f33rows([[4,3,'3/4',C.a,f33lab(4)],[5,3,'3/5',C.b,f33lab(5)]],{title:'3/4 va 3/5 — suratlar bir xil'});f3calc(['1/4 > 1/5 — choraklar kattaroq','3 ta katta bo‘lak > 3 ta kichik bo‘lak: <b>3/4 > 3/5</b>'])}];
var F3P5=[function(){f33rows([[2,1,'1/2',C.a,['1/2','1/2']]],{title:'Teng ulushlar'});f3calc(['Yarim tasma bo‘yaldi'])},
 function(){f33rows([[2,1,'1/2',C.a,['1/2','1/2']],[4,2,'2/4',C.b,f33lab(4)]],{title:'Teng ulushlar'});f3calc(['Choraklarga bo‘lsak — 2 ta chorak. <b>1/2 = 2/4</b>'])},
 function(){f33rows([[2,1,'1/2',C.a,['1/2','1/2']],[4,2,'2/4',C.b,f33lab(4)],[8,4,'4/8',C.c,f33lab(8)]],{title:'Teng ulushlar',half:1});f3calc(['Sakkizdan birlarga — 4 ta. <b>1/2 = 2/4 = 4/8</b>','Bo‘yalgan joy bir xil — ulushlar teng'])}];
var F3P6=[function(){f33cakes(0);f3calc(['Bir xil 3 ta tort. Lola 1/4, Ali 1/3, Vali 1/6 qismini yedi'])},function(){f33cakes(1);f3calc(['Bo‘laklarni bo‘yaymiz — qaysi bo‘lak katta?'])},function(){f33cakes(2);f3calc(['3 ga bo‘lingan tortning bo‘lagi eng katta: <b>Ali</b> eng ko‘p yedi','6 katta son, lekin 1/6 — eng kichik bo‘lak'])}];
var F3P8=[function(){f33rows([[3,2,'Ali',C.a,['','','']],[4,3,'Vali',C.b,['','','','']]],{title:'Bir xil yo‘l: Ali 2/3, Vali 3/4 qismini bosdi'});f3calc(['Kim manzilga yaqinroq? Bosilganni emas — QOLGANNI qaraymiz'])},
 function(){f33rows([[3,2,'Ali',C.a,['','','1/3']],[4,3,'Vali',C.b,['','','','1/4']]],{title:'Bir xil yo‘l: Ali 2/3, Vali 3/4 qismini bosdi'});f3calc(['Alida 1/3, Valida 1/4 qism qoldi','1/4 < 1/3 — Valida kamroq qoldi: <b>Vali yaqinroq</b>'])}];
var STEPS=[
{h:"Maxrajlari bir xil",sum:"3/8 va 5/8: bo'laklar bir xil kattalikda, 5 ta bo'lak 3 tadan ko'p — 5/8 > 3/8.",a:"m01",
 start:function(){f33rows([[8,3,'3/8',C.a,f33lab(8)],[8,5,'5/8',C.b,f33lab(8)]],{title:'Bir xil pirog, 8 bo‘lak'});f3calc(['Qaysi biri katta? Tugmani tanlang'])},
 fin:function(){f33rows([[8,3,'3/8',C.a,f33lab(8)],[8,5,'5/8',C.b,f33lab(8)]],{title:'Bir xil pirog, 8 bo‘lak'});f3msg('<b>5/8 > 3/8</b> — bo‘laklar bir xil, 5 ta ko‘p')},
 html:"<p>Ikkala tasma 8 ta <b>bir xil</b> bo'lakka bo'lingan. Qaysi biri ko'p bo'yalgan?</p>",
 btns:(function(){var m=['3/8 da kamroq bo‘lak bo‘yalgan — u kichik.','<b>5/8 > 3/8</b> — bo‘laklar bir xil, 5 ta bo‘lak 3 tadan ko‘p.','Teng emas — bo‘yalgan qism uzunligini solishtiring.'],p=f33pick(1,m);return [["3/8 katta",p(0)],["5/8 katta",p(1)],["Teng",p(2)]]})(),g3:1,
 after:"<p><b>Qoida 1:</b> maxrajlar bir xil bo'lsa — bo'laklar bir xil kattalikda. Qaysi ulushda <b>surat katta</b>, o'sha ulush katta: 5/8 > 3/8.</p>",
 q:{t:"Qaysi tengsizlik to'g'ri?",opts:["2/7 > 5/7","5/7 > 2/7","2/7 = 5/7","5/7 > 1"],ok:1,why:"Maxraj bir xil, 5 > 2.",hint:"Ikkalasida bo'laklar bir xil — nechtadan olingan?",full:"Ikkala ulushda bo'lak 1/7. 5 ta bo'lak 2 tadan ko'p: 5/7 > 2/7. 5/7 — butundan kichik, chunki 7 ta bo'lakdan faqat 5 tasi."},
 tn:"Singapur usuli: bir xil uzunlikdagi qog'oz tasmalarni buklab, bo'yating va ustma-ust qo'yib solishtiring."},
{h:"Bo'laklar devori",sum:"Butun qancha ko'p bo'lakka bo'linsa, har bir bo'lak shuncha kichik: 1/2 > 1/3 > 1/4 > 1/6 > 1/8.",a:"m02",
 start:function(){S.f3w=[];f33wall()},fin:function(){S.f3w=[2,3,4,6,8];f33wall()},
 html:"<p>«Ulushlar devori»ni quramiz. Tugmalarni bosib, tasmalarni qo'shing va bitta bo'laklarni solishtiring (kamida 3 ta):</p>",
 btns:[[2,3,4,6,8].map(function(n){return ["1/"+n,function(c,done){if(S.f3w.indexOf(n)<0)S.f3w.push(n);S.f3w.sort(function(a,b){return a-b});f33wall();mvK(done,3)}]})][0],g3:1,
 after:"<p><b>Qoida 2:</b> suratlari 1 bo'lgan ulushlarda <b>maxraj katta bo'lsa — ulush kichik</b>: 1/8 < 1/6 < 1/4 < 1/3 < 1/2. Pizzani qancha ko'p odamga bo'lsangiz, har biriga shuncha kichik bo'lak tegadi.</p>",
 q:{t:"Qaysi ulush eng kichik?",opts:["1/3","1/5","1/10","1/7"],ok:2,why:"Maxraj eng katta — 10, bo'lak eng kichik.",hint:"Butunni 10 ta yoki 3 ta bo'lakka bo'lsangiz, qaysi bo'lak kichik?",full:"Butun 10 ta bo'lakka bo'linganda bo'laklar eng mayda bo'ladi: 1/10 eng kichik. 1/3 — eng katta."},
 tn:"Ulushlar devori (fraction wall) — Buyuk Britaniya va Singapurda keng qo'llanadi. Doskaga chizing yoki tasmalardan yasang."},
{h:"Suratlari bir xil",sum:"3/4 va 3/5: ikkalasida 3 ta bo'lak, lekin choraklar katta — 3/4 > 3/5.",a:"m03",
 start:function(){startPh(F3P3)},fin:function(){S.ph=1;F3P3[1]()},
 html:"<p>Endi bo'laklar soni bir xil (3 tadan), lekin bo'laklarning <b>o'zi</b> har xil. Kuzating:</p>",btns:[phaser(F3P3)],
 after:"<p><b>Qoida 3:</b> suratlar bir xil bo'lsa — maxraji <b>kichik</b> ulush katta: 3/4 > 3/5, chunki chorak beshdan birdan katta.</p>",
 q:{t:"Qaysi ulush katta: 2/3 yoki 2/9?",opts:["2/9","2/3","Teng","Taqqoslab bo'lmaydi, suratlar bir xil"],ok:1,why:"Ikkalasida 2 ta bo'lak, uchdan bir bo'lak katta.",hint:"1/3 va 1/9 — qaysi bo'lak katta?",full:"1/3 > 1/9, demak 2 ta uchdan bir 2 ta to'qqizdan birdan katta: 2/3 > 2/9. «2/9» — «9 katta son» degan xato."},
 tn:"Bolalar o'zi tushuntirsin (Yaponiya usuli): «Nega 3/4 katta?» — «Chunki bo'laklari katta»."},
{h:"Yarim bilan solishtiramiz",sum:"Ulush yarmidan kichikmi yoki katta: 3/8 < 1/2 < 5/8; 4/8 = 1/2.",a:"m04",
 start:function(){S.f3h=[8,3];f33half()},fin:function(){S.f3h=[6,4];f33half()},
 html:"<p>Ulushning <b>yarim</b> chizig'idan qayerda ekanini ko'ring (kamida 3 tasini tanlang):</p>",
 btns:[[8,3],[8,5],[8,4],[6,2],[6,4],[10,5]].map(function(p){return [p[1]+"/"+p[0],function(c,done){S.f3h=p;f33half();mvK(done,3)}]}),g3:1,
 after:"<p>Yarim — qulay «o'lchov chizig'i». Surat maxrajning yarmidan kichik bo'lsa — ulush 1/2 dan kichik (3/8: 3 < 4). Teng bo'lsa — ulush yarimga teng (5/10 = 1/2).</p>",
 q:{t:"Qaysi ulush yarimdan katta?",opts:["2/6","4/10","5/8","3/6"],ok:2,why:"8 ning yarmi 4, 5 > 4.",hint:"Maxrajning yarmini toping va surat bilan solishtiring.",full:"5/8: 8 ning yarmi 4, surat 5 — yarimdan katta. 2/6 va 4/10 — yarimdan kichik, 3/6 — aynan yarim."},
 tn:"Gollandiya RME: ulushlarni son nurida 0, 1/2 va 1 bilan joylashtirish — «o'lchov nuqtalari» usuli."},
{h:"Teng ulushlar",sum:"1/2 = 2/4 = 4/8 — tasmalarda bo'yalgan joy bir xil.",a:"m05",
 start:function(){startPh(F3P5)},fin:function(){S.ph=2;F3P5[2]()},
 html:"<p>Har xil yozilgan ulushlar teng bo'lishi mumkin. Tasmalarni qo'shib boring:</p>",btns:[phaser(F3P5)],
 after:"<p>Bo'laklar 2 marta mayda bo'lsa, ularning soni 2 marta ko'p bo'ladi: 1/2 = 2/4 = 4/8. Shuning uchun «yarim soat» = «ikki chorak soat» = 30 minut.</p>",
 q:{t:"Qaysi ulush 1/2 ga teng?",opts:["2/3","3/6","1/4","2/8"],ok:1,why:"6 ning yarmi 3.",hint:"Surat maxrajning aynan yarmi bo'lishi kerak.",full:"3/6: 6 ta bo'lakdan 3 tasi — aynan yarmi. 2/8 = 1/4, 2/3 — yarimdan katta."},
 tn:"Bir xil tasmalarni 2, 4, 8 ga buklab, ustma-ust qo'ying — bolalar tenglikni o'z ko'zi bilan ko'radi."},
{h:"Tuzoq: «katta maxraj — katta ulush»?",sum:"Lola 1/4, Ali 1/3, Vali 1/6 qism tort yedi: eng ko'p — Ali (1/3), eng kam — Vali (1/6).",a:"m06",
 start:function(){startPh(F3P6)},fin:function(){S.ph=2;F3P6[2]()},
 html:"<p><i>«Bir xil tortdan Lola 1/4 qismini, Ali 1/3 qismini, Vali 1/6 qismini yedi. Kim eng ko'p yedi?»</i> Ko'pchilik «Vali — 6 katta» deydi.</p>",btns:[phaser(F3P6)],
 after:"<p>Maxraj — <b>bo'laklar soni</b>, bo'lak hajmi emas. Bo'laklar ko'p bo'lsa — har biri kichik. Shuning uchun 1/6 < 1/4 < 1/3.</p>",
 q:{t:"Bir xil shokoladdan Ali 1/5, Vali 1/2, Sardor 1/8 qismini yedi. Kim eng kam yedi?",opts:["Vali","Ali","Sardor","Hammasi teng"],ok:2,why:"1/8 — eng kichik bo'lak.",hint:"Qaysi shokolad eng ko'p bo'lakka bo'lingan?",full:"Sardorning bo'lagi — shokolad 8 ga bo'linganda bitta bo'lak, eng kichigi. Vali eng ko'p yedi (yarmi)."},
 tn:"Haqiqiy olma yoki nonni 2 va 6 bo'lakka kesib, bolalarga ko'rsating."},
{h:"Tuzoq: har xil sonlarning ulushi",sum:"18 ning 1/3 qismi = 6, 24 ning 1/4 qismi = 6 — teng! Butunlar har xil bo'lsa, hisoblab solishtiramiz.",a:"m07",
 start:function(){f33num(0)},fin:function(){f33num(1)},
 html:"<p>Qaysi biri ko'p: <b>18 ning 1/3 qismi</b> yoki <b>24 ning 1/4 qismi</b>? «1/3 > 1/4, demak birinchisi» — shoshilmang!</p>",
 btns:(function(){var m=['1/3 > 1/4, lekin butunlar har xil — hisoblang: 18 : 3 va 24 : 4.','24 katta, lekin 1/4 kichikroq — hisoblang: 18 : 3 va 24 : 4.','<b>Teng!</b> 18 : 3 = 6 va 24 : 4 = 6.'],p=f33pick(2,m);return [["18 ning 1/3",function(c,done,b){p(0)(c,done,b)}],["24 ning 1/4",function(c,done,b){p(1)(c,done,b)}],["Teng",function(c,done,b){f33num(1);p(2)(c,done,b)}]]})(),g3:1,
 after:"<p>Ulushlarni faqat <b>bir xil butunda</b> qoida bo'yicha solishtiramiz. Butunlar har xil bo'lsa — har birini <b>hisoblab</b>, natijalarni solishtiramiz.</p>",
 q:{t:"Qaysi ko'p: 20 ning 1/2 qismi yoki 60 ning 1/5 qismi?",opts:["20 ning 1/2 qismi","60 ning 1/5 qismi","Teng","1/2 har doim katta"],ok:1,why:"20 : 2 = 10, 60 : 5 = 12. 12 > 10.",hint:"Ikkalasini hisoblang.",full:"20 ning yarmi 10, 60 ning 1/5 qismi 12. 12 > 10 — ikkinchisi ko'p. 1/2 > 1/5 faqat bir xil butun uchun to'g'ri."},
 tn:"Bu bankdagi tuzoq turlariga mos. Bolalar avval taxmin qilsin, keyin hisoblasin."},
{h:"Tuzoq: kim manzilga yaqin?",sum:"Ali yo'lning 2/3, Vali 3/4 qismini bosdi: Alida 1/3, Valida 1/4 qoldi; 1/4 < 1/3 — Vali yaqinroq.",a:"m08",
 start:function(){startPh(F3P8)},fin:function(){S.ph=1;F3P8[1]()},
 html:"<p><i>«Ali bir xil yo'lning 2/3 qismini, Vali 3/4 qismini bosib o'tdi. Kim manzilga yaqinroq?»</i> 2/3 va 3/4 ni to'g'ridan-to'g'ri solishtirish qiyin. Qolgan qismga qaraymiz!</p>",btns:[phaser(F3P8)],
 after:"<p>Ayyorlik: 2/3 da butungacha <b>1/3</b>, 3/4 da <b>1/4</b> yetmaydi. Kimga kamroq yetmasa — o'sha butunga yaqin: <b>3/4 > 2/3</b>.</p>",
 q:{t:"Qaysi ulush katta: 4/5 yoki 5/6?",opts:["4/5","5/6","Teng","Taqqoslab bo'lmaydi"],ok:1,why:"4/5 ga 1/5, 5/6 ga 1/6 yetmaydi; 1/6 < 1/5.",hint:"Har biriga butungacha qancha yetmaydi?",full:"4/5 + 1/5 = 1, 5/6 + 1/6 = 1. 1/6 kichikroq bo'lak — demak 5/6 butunga yaqinroq va katta: 5/6 > 4/5."},
 tn:"Bu — kuchli o'quvchilar uchun. Bir xil uzunlikdagi ikki tasmada «qolgan» qismlarni qizil bilan bo'yatish yordam beradi."},
{h:"Bilasizmi? Notalar ham ulush",sum:"«Kasr» so'zi arabchada «sindirish» degani; musiqada butun, yarim, chorak, sakkizdan bir notalar bor.",a:"m09",
 start:function(){f33notes()},fin:function(){f33notes()},
 html:"<p>🎵 Musiqada notalar davomiyligi ulushlar bilan ataladi: <b>butun nota</b>, <b>yarim nota</b>, <b>chorak nota</b>, <b>sakkizdan bir nota</b>. Bitta butun nota vaqtida 2 ta yarim yoki 4 ta chorak nota chalinadi.</p><p>📖 Ulushlarni yozish uchun ishlatiladigan <b>«kasr»</b> so'zi arab tilidan olingan va <b>«sindirish»</b> degan ma'noni bildiradi — butunni «sindirib» bo'laklarga ajratamiz.</p>",
 tn:"Musiqa o'qituvchisi bilan birga: qarsak bilan butun, yarim, chorak notalarni chalib ko'ring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.f3w=[2,3,4,6,8];f33wall()},fin:function(){S.f3w=[2,3,4,6,8];f33wall()},
 html:"<div class='memo'><ul><li><b>Maxrajlar bir xil</b> — surati katta ulush katta: 5/8 > 3/8.</li><li><b>Suratlar bir xil</b> — maxraji kichik ulush katta: 3/4 > 3/5, 1/3 > 1/6.</li><li><b>Yarim bilan</b>: surat maxrajning yarmidan katta bo'lsa — ulush 1/2 dan katta.</li><li><b>Teng ulushlar</b>: 1/2 = 2/4 = 4/8.</li><li><b>Butungacha</b> qancha yetmasligini solishtirish: 3/4 > 2/3.</li><li>Butunlar har xil bo'lsa — <b>hisoblab</b> solishtiring.</li></ul></div>",
 tn:"Kartochka va ulushlar devorini daftarga chizdiring."}
];
function f33wall(){var r=S.f3w.map(function(n,i){return [n,1,'1/'+n,[C.a,C.b,C.c,C.blue,C.a2][i%5],f33lab(n)]});if(!r.length){clear();f3msg('Tugmani bosib tasma qo‘shing');return}
 f33rows([[1,1,'1','#9fb3c8',['butun']]].concat(r),{h:18,gap:6,y:14});var w=r.map(function(q){return q[2]});f3calc([w.length>1?w.join(' > '):w[0]+' — yana tasma qo‘shing','Maxraj katta — bo‘lak kichik'])}
function f33half(){var n=S.f3h[0],k=S.f3h[1],s=k*2<n?'<':k*2>n?'>':'=';f33rows([[n,k,k+'/'+n,C.b,f33lab(n)]],{half:1,h:34,title:k+'/'+n+' va 1/2'});f3calc([n+' ning yarmi '+n/2+', surat '+k+' → <b>'+k+'/'+n+' '+s+' 1/2</b>'])}
function f33num(st){clear();T(S.g,14,16,'Butunlar har xil!',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});f3bar(30,46,180,32,3,st?1:0,C.a,st?['6','6','6']:['','','']);Br(30,210,42,'18',true);f3bar(30,112,240,32,4,st?1:0,C.b,st?['6','6','6','6']:['','','','']);Br(30,270,108,'24',true);
 T(S.g,300,68,'1/3 ?',{'font-size':13,'font-weight':800,fill:C.a});T(S.g,310,134,'1/4 ?',{'font-size':13,'font-weight':800,fill:C.b});if(st)f3calc(['18 : 3 = <b>6</b>','24 : 4 = <b>6</b> — teng!']);else f3calc(['Bitta tasma 18 ga, ikkinchisi 24 ga teng'])}
function f33notes(){clear('#f5f0ff');var g=S.g;for(var l=0;l<5;l++)E('line',{x1:20,y1:50+l*10,x2:340,y2:50+l*10,stroke:'#8a7fb0'},g);
 [[50,'butun',1,0],[130,'yarim',1,1],[210,'chorak',0,1],[290,'1/8',0,2]].forEach(function(n){E('ellipse',{cx:n[0],cy:85,rx:9,ry:6.5,fill:n[2]?'#fff':'#3d2f6b',stroke:'#3d2f6b','stroke-width':2.5,transform:'rotate(-20 '+n[0]+' 85)'},g);if(n[3]){E('line',{x1:n[0]+8,y1:83,x2:n[0]+8,y2:40,stroke:'#3d2f6b','stroke-width':2},g);if(n[3]>1)E('path',{d:'M'+(n[0]+8)+' 40 q10 8 6 20',fill:'none',stroke:'#3d2f6b','stroke-width':2.5},g)}T(g,n[0],125,n[1],{'font-size':12,'font-weight':800,fill:'#3d2f6b'})});
 f3msg('1 butun = 2 yarim = 4 chorak = 8 ta sakkizdan bir')}
var PROBS=[
{t:"Qaysi tengsizlik to'g'ri?",o:["4/9 < 7/9","4/9 > 7/9","4/9 = 7/9","7/9 > 1"],k:0,s:"Maxraj bir xil, 4 < 7."},
{t:"Qaysi ulush eng katta?",o:["1/2","1/3","1/5","1/9"],k:0,s:"Maxraj eng kichik — bo'lak eng katta."},
{t:"Qaysi ulush eng kichik?",o:["1/12","1/4","1/6","1/10"],k:0,s:"12 ta bo'lak — eng mayda."},
{t:"Qaysi tengsizlik to'g'ri?",o:["3/5 > 3/8","3/5 < 3/8","3/5 = 3/8","3/8 > 3/5"],k:0,s:"Surat bir xil, 1/5 > 1/8."},
{t:"Bo'sh katakka qaysi belgi qo'yiladi: 1/7 ☐ 1/4",o:["<",">","=","+"],k:0,s:"1/7 kichik bo'lak."},
{t:"Qaysi ulush 1/2 ga teng?",o:["4/8","3/8","2/6","4/6"],k:0,s:"8 ning yarmi 4."},
{t:"Qaysi ulush yarimdan kichik?",o:["3/8","5/8","4/6","5/10"],k:0,s:"8 ning yarmi 4, 3 < 4."},
{t:"Ulushlarni kichigidan kattasiga tartiblang: 1/3, 1/8, 1/5",o:["1/8, 1/5, 1/3","1/3, 1/5, 1/8","1/5, 1/8, 1/3","1/8, 1/3, 1/5"],k:0,s:"Maxraj katta — ulush kichik."},
{t:"Bir xil tortdan Lola 1/4, Ali 1/3, Vali 1/6 qismini yedi. Kim eng ko'p yedi?",o:["Ali","Lola","Vali","Lola va Ali teng"],k:0,s:"1/3 — eng katta bo'lak."},
{t:"Bir xil shokoladdan Ali 2/6, Vali 5/6 qismini yedi. Kim ko'p yedi?",o:["Vali","Ali","Teng","Aniq emas"],k:0,s:"Maxraj bir xil, 5 > 2."},
{t:"Bir xil lentadan Zarina 3/4 qismini, Malika 3/10 qismini oldi. Kimda lenta ko'p?",o:["Zarinada","Malikada","Teng","10 katta, shuning uchun Malikada"],k:0,s:"Surat bir xil, chorak > o'ndan bir."},
{t:"Bir soatning qaysi qismi ko'proq: 1/4 soat yoki 1/3 soat?",o:["1/3 soat","1/4 soat","Teng","Soatni bo'lib bo'lmaydi"],k:0,s:"1/3 soat = 20 min, 1/4 soat = 15 min."},
{t:"Qaysi ko'p: 18 ning 1/3 qismi yoki 24 ning 1/4 qismi?",o:["Teng","18 ning 1/3 qismi","24 ning 1/4 qismi","Taqqoslab bo'lmaydi"],k:0,s:"6 = 6."},
{t:"Qaysi ko'p: 20 ning 1/2 qismi yoki 60 ning 1/5 qismi?",o:["60 ning 1/5 qismi","20 ning 1/2 qismi","Teng","1/2 har doim katta"],k:0,s:"10 < 12."},
{t:"Qaysi ko'p: 1 metrning 1/4 qismi yoki 1 metrning 1/5 qismi? Farqi necha sm?",o:["1/4 qismi, 5 sm","1/5 qismi, 5 sm","1/4 qismi, 1 sm","Teng"],k:0,s:"25 sm − 20 sm = 5 sm."},
{t:"Qaysi ulush katta: 2/3 yoki 3/4?",o:["3/4","2/3","Teng","Taqqoslab bo'lmaydi"],k:0,s:"2/3 ga 1/3, 3/4 ga 1/4 yetmaydi; 1/4 < 1/3."},
{t:"Qaysi ulush katta: 4/5 yoki 5/6?",o:["5/6","4/5","Teng","Taqqoslab bo'lmaydi"],k:0,s:"Butungacha 1/5 va 1/6 yetmaydi; 1/6 kichik."},
{t:"Ali bir xil kitoblarning 5/8 qismini, Vali 3/8 qismini o'qidi. Kimga o'qish ko'proq qoldi?",o:["Valiga","Aliga","Teng","Aniq emas"],k:0,s:"Valiga 5/8, Aliga 3/8 qoldi."},
{t:"Qaysi uchta ulush teng?",o:["1/2, 2/4, 4/8","1/2, 1/4, 1/8","1/3, 2/4, 3/5","2/4, 2/6, 2/8"],k:0,s:"Hammasi yarim."},
{t:"1/☐ ulush 1/6 dan katta bo'lishi uchun katakka yoziladigan eng katta son qaysi?",o:["5","7","6","1"],k:0,s:"1/☐ > 1/6 bo'lishi uchun ☐ < 6; eng kattasi 5."}
];
function PRACT_STAGE(){S.f3w=[2,3,4,6,8];f33wall()}
var PREP_DATA={teach:["Maxrajlari bir xil ulushlarni taqqoslash.","Suratlari bir xil (shu jumladan 1/n) ulushlarni taqqoslash; ulushlar devori.","Yarim bilan solishtirish; teng ulushlar (1/2 = 2/4 = 4/8).","Tuzoqlar: «katta maxraj — katta ulush» xatosi; har xil butunlar; butungacha yetmagan qism."],
 mist:["1/6 > 1/3 deb o'ylaydi, chunki 6 > 3.","Har xil butunlarning ulushlarini qoida bilan solishtiradi (hisoblamaydi).","3/4 va 3/5 da faqat suratga qarab «teng» deydi.","Teng ulushlarni (2/4 va 1/2) har xil deb hisoblaydi."],
 need:["Bir xil uzunlikdagi qog'oz tasmalar (har bolaga 5 ta), rangli qalamlar.","Ulushlar devori plakati."],
 board:["<span class='w2'>3/8 < 5/8</span> — maxraj bir xil.","<span class='w2'>1/8 < 1/6 < 1/4 < 1/3 < 1/2</span>.","<span class='w2'>3/5 < 3/4</span> — surat bir xil.","<span class='w2'>1/2 = 2/4 = 4/8</span>.","<span class='w2'>2/3 < 3/4</span>: yetmaydi 1/3 va 1/4."]};
