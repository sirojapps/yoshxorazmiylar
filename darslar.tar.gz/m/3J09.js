var CODE='3J09',TITLE="3-sinf · Hafta kunlari va kalendar jumboqlari";
var J9D=['Du','Se','Ch','Pa','Ju','Sh','Ya'],J9N=['Dushanba','Seshanba','Chorshanba','Payshanba','Juma','Shanba','Yakshanba'];
function j9Wheel(from,to,lab){clear();var g=S.g,cx=180,cy=84,r=62;E('circle',{cx:cx,cy:cy,r:r,fill:'none',stroke:'#c9d3dd','stroke-width':2,'stroke-dasharray':'4 4'},g);
 for(var i=0;i<7;i++){var a=-Math.PI/2+i*2*Math.PI/7,x=cx+r*Math.cos(a),y=cy+r*Math.sin(a);var f=i===from?'#ffe08a':(i===to?'#bfe8cf':'#fff');E('circle',{cx:x,cy:y,r:17,fill:f,stroke:C.line,'stroke-width':1.6},g);T(g,x,y+5,J9D[i],{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
 T(g,cx,cy+5,lab||'7 kun',{'font-size':14,'font-weight':800,fill:C.blue})}
function j9Cal(first,days,hl){var rows=[J9D.slice()],r=[],i;for(i=0;i<first;i++)r.push('');for(var d=1;d<=days;d++){r.push(d);if(r.length===7){rows.push(r);r=[]}}if(r.length){while(r.length<7)r.push('');rows.push(r)}
 var f={},col={};rows.forEach(function(row,ri){row.forEach(function(v,ci){if(ri&&hl&&hl.indexOf(v)>=0)f[ri+','+ci]='#ffe08a';if(ci===6)col[ri+','+ci]=C.bad})});j3Tab(rows,{hr:1,cw:44,ch:Math.min(24,168/rows.length),fs:12,fill:f,col:col,y0:4})}
function j9Fist(){clear();var g=S.g,M=['Yan','Fev','Mar','Apr','May','Iyn','Iyl'],M2=['Avg','Sen','Okt','Noy','Dek'];
 function row(arr,x0,y){arr.forEach(function(m,i){var top=i%2===0,x=x0+i*42;E(top?'circle':'path',top?{cx:x,cy:y,r:15,fill:'#ffe0bd',stroke:C.line,'stroke-width':1.4}:{d:'M'+(x-12)+','+(y+4)+' Q'+x+','+(y+20)+' '+(x+12)+','+(y+4),fill:'none',stroke:C.line,'stroke-width':1.6},g);T(g,x,top?y+4:y+34,m,{'font-size':11,'font-weight':800,fill:top?'#1e8e5a':C.bad})})}
 row(M,54,48);row(M2,96,112);T(g,180,170,'do‘mboq — 31 · chuqurcha — 30 (fevral 28/29)',{'font-size':11,'font-weight':800,fill:'#1d2b3a'})}
var STEPS=[
{h:"Hafta — 7 kunlik aylana",sum:"Har 7 kunda hafta kuni takrorlanadi: 10 = 7 + 3, chorshanba + 3 = shanba.",a:"m01",
 start:function(){j9Wheel(2,-1,'+10 kun');j3Msg('Bugun chorshanba. 10 kundan keyin qaysi kun?')},fin:function(){j9Wheel(2,5,'10 = 7 + 3');j3Msg('7 kun — to‘liq aylana, yana 3 qadam: shanba')},
 html:"<p>Hafta kunlari aylanada yuradi: yakshanbadan keyin yana dushanba. Bugun <b>chorshanba</b>. <b>10 kundan keyin</b> qaysi kun bo'ladi?</p>",
 btns:j3Ch(["Juma","Shanba","Yakshanba","Chorshanba"],1,function(){j9Wheel(2,5,'10 = 7 + 3');j3Msg('To‘g‘ri! 7 kundan keyin yana chorshanba, +3 → shanba')},function(i){return ['Juma — bu 9 kundan keyin. Aylanada sanang','','Yakshanba — 11 kundan keyin','Chorshanba — 7 kundan keyin bo‘lardi. 10 − 7 = ?'][i]}),g2:1,
 after:"<p>7 kun o'tsa — yana o'sha kun. Shuning uchun kunlardan <b>7 larni tashlab yuboramiz</b>: 10 = 7 + 3 → faqat 3 qadam yuramiz.</p>",
 q:{t:"Bugun dushanba. 15 kundan keyin qaysi kun?",opts:["Dushanba","Seshanba","Chorshanba","Yakshanba"],ok:1,why:"15 = 14 + 1, dushanba + 1 = seshanba.",hint:"15 dan nechta to'liq hafta chiqadi?",full:"15 = 2 · 7 + 1. Ikki to'liq hafta — yana dushanba, yana 1 kun — seshanba."},
 tn:"Polga 7 ta kartochkani aylana qilib qo'ying; bola ustidan yurib sanasin, keyin «7 ni tashlash» qoidasini kashf etsin."},
{h:"Katta sonlar: qoldiq bilan",sum:"100 : 7 = 14 (qoldiq 2). Dushanbadan 100 kun → chorshanba.",a:"m02",
 start:function(){j9Wheel(0,-1,'+100 kun');j3Msg('Bugun dushanba. 100 kundan keyin qaysi kun?')},fin:function(){j9Wheel(0,2,'100 = 98 + 2');j3Msg('100 : 7 = 14 (qoldiq 2) → dushanba + 2 = chorshanba')},
 html:"<p>100 marta sanash uzoq. Qoldiqli bo'lishdan foydalaning! Bugun <b>dushanba</b>. <b>100 kundan</b> keyin qaysi kun?</p>",
 btns:j3Ch(["Dushanba","Seshanba","Chorshanba","Payshanba"],2,function(){j9Wheel(0,2,'100 = 98 + 2');j3Msg('To‘g‘ri! 100 = 14 · 7 + 2 → 2 qadam: chorshanba')},function(i){return ['Dushanba — agar 100 kun 7 ga qoldiqsiz bo‘linsa. 14 · 7 = 98, qoldiq bor','Seshanba — qoldiq 1 bo‘lsa. 100 − 98 = ?','','Payshanba — qoldiq 3 bo‘lsa'][i]}),g2:1,
 after:"<p>Usul: kunlar sonini 7 ga bo'lamiz, <b>faqat qoldiq</b> muhim. 100 : 7 = 14 (qoldiq <b>2</b>) → 2 kun oldinga. O'tmishga sanasak — orqaga yuramiz.</p>",
 q:{t:"Bugun payshanba. 10 kun oldin qaysi kun edi?",opts:["Yakshanba","Dushanba","Seshanba","Shanba"],ok:1,why:"10 = 7 + 3; payshanbadan 3 kun orqaga — dushanba.",hint:"O'tmish — aylanada orqaga yuring.",full:"10 kun = 1 hafta + 3 kun. Payshanbadan 3 kun orqaga: chorshanba, seshanba, dushanba. «Yakshanba» — oldinga sanash xatosi."},
 tn:"Bu yerda 3-sinfda o'tiladigan qoldiqli bo'lish hayotiy ma'no oladi — bolalarga aytib o'ting."},
{h:"Oylar: musht qoidasi",sum:"Mushtning do'mboqlari — 31 kunlik oylar, chuqurchalari — 30 kunlik (fevral 28 yoki 29). Iyul va avgust — ikkalasi ham 31.",a:"m03",
 start:function(){j9Fist()},fin:function(){j9Fist()},
 html:"<p>Mushtingizni tugib, bo'g'imlarga qarang. Do'mboq — 31 kun, chuqurcha — 30 kun. Yanvardan boshlab sanang; iyuldan keyin yana boshidan. Qaysi <b>ikki qo'shni oy</b> ikkalasi ham 31 kunlik?</p>",
 btns:j3Ch(["Iyun–iyul","Iyul–avgust","Avgust–sentyabr","Aprel–may"],1,function(){j3Msg('To‘g‘ri! Iyul — oxirgi do‘mboq, avgust — yana birinchi do‘mboq')},function(i){return ['Iyun — chuqurcha (30 kun)','','Sentyabr — chuqurcha (30 kun)','Aprel — chuqurcha (30 kun)'][i]}),g2:1,
 after:"<p>31 kunlik oylar: yanvar, mart, may, iyul, avgust, oktyabr, dekabr (7 ta). 30 kunlik: aprel, iyun, sentyabr, noyabr. Fevral — 28 kun, kabisa yilida 29. Yilda 365 kun (kabisada 366).</p>",
 q:{t:"Kabisa bo'lmagan yilda yanvar va fevral birgalikda necha kun?",opts:["60","59","62","61"],ok:1,why:"31 + 28 = 59.",hint:"Fevral oddiy yilda necha kun?",full:"Yanvar 31, fevral 28: 59. «60» — fevralni 29 deb olish (bu faqat kabisada), «62» — ikkalasini 31 deb olish."},
 tn:"Bolalar musht qoidasini bir-biriga tushuntirib bersin — yapon usuli: «tushuntirgan — o'rgangan»."},
{h:"Kalendar varag'i",sum:"Bir xil hafta kunidagi sanalar 7 ga farq qiladi: 1, 8, 15, 22, 29. 1-mart yakshanba → 31-mart seshanba.",a:"m04",
 start:function(){j9Cal(6,31,[1]);j3Msg('1-mart — yakshanba. 31-mart qaysi kun?')},fin:function(){j9Cal(6,31,[1,8,15,22,29,31]);j3Msg('29-mart — yakshanba, 31-mart — seshanba')},
 html:"<p>Bu — 2026-yil mart oyi. 1-mart <b>yakshanba</b>. Jadvalga qaramasdan hisoblang: <b>31-mart</b> qaysi kun? (So'ng jadvalda tekshiring.)</p>",
 btns:j3Ch(["Dushanba","Seshanba","Yakshanba","Chorshanba"],1,function(){j9Cal(6,31,[1,8,15,22,29,31]);j3Msg('To‘g‘ri! 1, 8, 15, 22, 29 — yakshanba; 30 — dushanba; 31 — seshanba')},function(i){return ['31 − 1 = 30 kun o‘tdi. 30 = 28 + 2 → 2 qadam','','29-mart yakshanba. 31 — undan 2 kun keyin','Chorshanba — 3 qadam bo‘lardi'][i]}),g2:1,
 after:"<p>Kalendarda bir ustundagi sanalar <b>7 ga</b> farq qiladi. 1-sana yakshanba → 8, 15, 22, 29 ham yakshanba. 31 = 29 + 2 → seshanba. Diqqat: 1-dan 31-gacha <b>30</b> kun o'tadi, 31 emas!</p>",
 q:{t:"1-may dushanba. 1-iyun qaysi kun? (May 31 kun.)",opts:["Dushanba","Payshanba","Chorshanba","Juma"],ok:1,why:"31 kun = 4 hafta + 3 kun: dushanba + 3 = payshanba.",hint:"1-maydan 1-iyungacha necha kun o'tadi?",full:"May 31 kun → 31 kun o'tadi. 31 = 28 + 3 → dushanbadan 3 kun: payshanba. «Chorshanba» — 30 kunlik oy deb olish."},
 tn:"Haqiqiy devoriy kalendardan foydalaning; bolalar ustunlardagi sanalar farqini topsin."},
{h:"Tuzoq: «kecha», «ertaga»",sum:"Ertadan keyingi kun juma → bugun chorshanba → kechadan oldingi kun dushanba.",a:"m05",
 start:function(){j9Wheel(4,-1,'?');j3Msg('Ertadan keyingi kun — juma. Kechadan oldingi kun qaysi?')},fin:function(){j9Wheel(2,0,'bugun Ch');j3Msg('Bugun chorshanba (sariq) → kechadan oldingi kun dushanba (yashil)')},
 html:"<p>Diqqat bilan o'qing: <b>ertadan keyingi kun</b> — juma. <b>Kechadan oldingi kun</b> qaysi kun edi? Avval «bugun»ni toping!</p>",
 btns:j3Ch(["Dushanba","Seshanba","Chorshanba","Yakshanba"],0,function(){j9Wheel(2,0,'bugun Ch');j3Msg('To‘g‘ri! Juma − 2 = chorshanba (bugun), − 2 = dushanba')},function(i){return ['','Seshanba — bu kecha. Kechadan oldingi kun-chi?','Chorshanba — bu bugun','Yakshanba — jumadan 2 kun keyin. Biz orqaga yurishimiz kerak'][i]}),g2:1,
 after:"<p>Usul: har doim avval <b>bugun</b>ni toping. «Ertadan keyingi» = bugun + 2, «kechadan oldingi» = bugun − 2. Bugun = juma − 2 = chorshanba, javob = chorshanba − 2 = dushanba.</p>",
 q:{t:"Ertaga yakshanba. Kecha qaysi kun edi?",opts:["Shanba","Juma","Payshanba","Dushanba"],ok:1,why:"Bugun shanba, kecha juma.",hint:"Avval bugun qaysi kun ekanini toping.",full:"Ertaga yakshanba → bugun shanba → kecha juma. «Shanba» — bugunni javob deb olish."},
 tn:"Doskaga son o'qi kabi chiziq chizing: «kecha — bugun — ertaga» — bolalar har so'zni chiziqqa joylasin."},
{h:"Tuzoq: qaysi kunlar 5 marta?",sum:"31 kun = 4 hafta + 3 kun. 1-sana payshanba → payshanba, juma, shanba 5 martadan.",a:"m06",
 start:function(){j9Cal(3,31,[]);j3Msg('Oy 31 kun, 1-sana payshanba. Qaysi kunlar 5 martadan uchraydi?')},fin:function(){j9Cal(3,31,[29,30,31]);j3Msg('29, 30, 31 — Pa, Ju, Sh: shu kunlar 5 martadan')},
 html:"<p>Oy 31 kun, 1-sanasi <b>payshanba</b>. Haftaning qaysi kunlari bu oyda <b>5 martadan</b> uchraydi?</p>",
 btns:j3Ch(["Pa, Ju, Sh","Faqat Pa","Du, Se, Ch","Ju, Sh, Ya"],0,function(){j9Cal(3,31,[29,30,31]);j3Msg('To‘g‘ri! 28 kun — har kun 4 tadan; ortiqcha 29, 30, 31 — Pa, Ju, Sh')},function(i){return ['','31 = 28 + 3: ortiqcha kunlar 3 ta, bitta emas','Du, Se, Ch — agar 1-sana dushanba bo‘lsa','Ju, Sh, Ya — 1-sanadan emas, 2-sanadan boshladingiz'][i]}),g2:1,
 after:"<p>28 kun = aniq 4 hafta — har bir kun 4 martadan. Ortiqcha 3 kun (29, 30, 31) — 1, 2, 3-sanalar bilan bir xil kunlar: payshanba, juma, shanba. Ular 5 martadan.</p>",
 q:{t:"31 kunlik oyda 5 ta dushanba, 5 ta seshanba va 5 ta chorshanba bor. Oyning 1-sanasi qaysi kun?",opts:["Seshanba","Dushanba","Yakshanba","Chorshanba"],ok:1,why:"Ortiqcha 3 kun 1, 2, 3-sanalar bilan bir xil: Du, Se, Ch → 1-sana dushanba.",hint:"5 marta uchraydigan kunlar oyning boshida keladi.",full:"31 = 28 + 3. 5 marta uchraydigan uch kun — 1, 2, 3-sanalar kunlari. Ular Du, Se, Ch, demak 1-sana dushanba."},
 tn:"Bu — olimpiadaning klassik masalasi. Bolalar avval 28 kunni «tashlab» olishni o'rgansin."},
{h:"Bilasizmi? Kabisa yili va kun nomlari",sum:"Yer Quyosh atrofini taxminan 365 kun 6 soatda aylanadi → har 4 yilda bir kun qo'shiladi (29-fevral). «Dushanba» — forscha «ikkinchi kun» (shanbadan keyin).",a:"m07",
 start:function(){j9Cal(1,29,[29]);j3Msg('2028-yil fevrali: 29 kun')},fin:function(){j9Cal(1,29,[29]);j3Msg('2028-yil fevrali: 29 kun')},
 html:"<p>🌍 Yer Quyosh atrofini taxminan <b>365 kun 6 soatda</b> bir marta aylanadi. Har yili 6 soat «ortib qoladi», 4 yilda — 24 soat, ya'ni bir kun. Shuning uchun har 4 yilda bir marta fevral <b>29</b> kun bo'ladi — bu <b>kabisa yili</b> (masalan, 2024, 2028).</p><p>📛 Hafta kunlari nomlari fors tilidan: «shanba» — dam kuni, «yakshanba» — undan keyingi 1-kun, «dushanba» — 2-kun, «seshanba» — 3-kun, «chorshanba» — 4-kun, «payshanba» — 5-kun.</p>",
 tn:"Bolalar o'z tug'ilgan kunlari bu yil qaysi kunga tushishini hisoblasin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j9Wheel(0,-1)},fin:function(){j9Wheel(0,-1)},
 html:"<div class='memo'><ul><li>Har <b>7 kunda</b> hafta kuni takrorlanadi.</li><li>n kundan keyin: n : 7 — <b>qoldiq</b> qadam oldinga.</li><li>O'tmish — orqaga sanang.</li><li>31 kun = 4 hafta + 3 kun; 30 kun = 4 hafta + 2 kun.</li><li>Musht: do'mboq — 31, chuqurcha — 30; fevral 28/29.</li><li>Kecha/ertaga: avval <b>bugun</b>ni toping.</li><li>Kalendar ustunida sanalar 7 ga farq qiladi.</li></ul></div>",
 tn:"Sinf kalendarini osib qo'ying va har dushanba «hafta jumbog'i» bering."}
];
var PROBS=[
{t:"Bugun seshanba. 3 kundan keyin qaysi kun?",o:["Juma","Payshanba","Shanba","Chorshanba"],k:0,s:"Seshanba + 3 = juma."},
{t:"Bugun juma. 7 kundan keyin qaysi kun?",o:["Juma","Shanba","Payshanba","Yakshanba"],k:0,s:"7 kun — to'liq hafta."},
{t:"Bugun dushanba. 15 kundan keyin qaysi kun?",o:["Seshanba","Dushanba","Chorshanba","Yakshanba"],k:0,s:"15 = 14 + 1."},
{t:"Bugun shanba. 30 kundan keyin qaysi kun?",o:["Dushanba","Yakshanba","Seshanba","Shanba"],k:0,s:"30 = 28 + 2: shanba + 2 = dushanba."},
{t:"Bugun chorshanba. 100 kundan keyin qaysi kun?",o:["Juma","Payshanba","Shanba","Chorshanba"],k:0,s:"100 = 98 + 2: chorshanba + 2 = juma."},
{t:"Bugun payshanba. 10 kun oldin qaysi kun edi?",o:["Dushanba","Yakshanba","Seshanba","Shanba"],k:0,s:"10 = 7 + 3, 3 kun orqaga."},
{t:"Ertaga yakshanba. Kecha qaysi kun edi?",o:["Juma","Shanba","Payshanba","Dushanba"],k:0,s:"Bugun shanba, kecha juma."},
{t:"Ertadan keyingi kun juma. Kechadan oldingi kun qaysi kun edi?",o:["Dushanba","Seshanba","Chorshanba","Yakshanba"],k:0,s:"Bugun chorshanba, 2 kun oldin dushanba."},
{t:"Qaysi oyda 30 kun bor?",o:["Aprel","Mart","Iyul","Avgust"],k:0,s:"30 kunlik: aprel, iyun, sentyabr, noyabr."},
{t:"Kabisa bo'lmagan yilda yanvar va fevral birgalikda necha kun?",o:["59","60","62","61"],k:0,s:"31 + 28 = 59."},
{t:"Kabisa yilida necha kun bor?",o:["366","365","364","367"],k:0,s:"Fevral 29 kun: 366."},
{t:"Quyidagi yillardan qaysi biri kabisa yili?",o:["2028","2026","2027","2030"],k:0,s:"2028 soni 4 ga bo'linadi."},
{t:"1-may dushanba. 1-iyun qaysi kun? (May 31 kun.)",o:["Payshanba","Dushanba","Chorshanba","Juma"],k:0,s:"31 = 28 + 3."},
{t:"1-aprel juma. 1-may qaysi kun? (Aprel 30 kun.)",o:["Yakshanba","Shanba","Juma","Dushanba"],k:0,s:"30 = 28 + 2: juma + 2 = yakshanba."},
{t:"Oyning 3-sanasi seshanba. Shu oyning 24-sanasi qaysi kun?",o:["Seshanba","Chorshanba","Dushanba","Shanba"],k:0,s:"24 − 3 = 21 = 3 hafta."},
{t:"Oyning 1-kuni payshanba, oy 30 kun. Bu oyda nechta payshanba bor?",o:["5","4","6","3"],k:0,s:"1, 8, 15, 22, 29."},
{t:"Fevral 28 kun, 1-fevral yakshanba. Fevralda nechta yakshanba bor?",o:["4","5","3","6"],k:0,s:"28 kun = 4 hafta: 1, 8, 15, 22."},
{t:"31 kunlik oyda 5 ta dushanba, 5 ta seshanba, 5 ta chorshanba bor. Oyning 1-sanasi qaysi kun?",o:["Dushanba","Seshanba","Yakshanba","Chorshanba"],k:0,s:"Ortiqcha 3 kun — 1, 2, 3-sanalar kunlari."},
{t:"Bir oyda uchta yakshanba juft sanaga to'g'ri keldi. Shu oyning 15-sanasi qaysi kun?",o:["Shanba","Yakshanba","Juma","Dushanba"],k:0,s:"Yakshanbalar 2, 16, 30 bo'lishi kerak — 15-sana shanba."},
{t:"Kabisa bo'lmagan yil dushanba kuni boshlandi. Uning oxirgi kuni (31-dekabr) qaysi kun?",o:["Dushanba","Yakshanba","Seshanba","Shanba"],k:0,s:"365 = 52 · 7 + 1: 365-kun 1-kun bilan bir xil."}
];
function PRACT_STAGE(){j9Wheel(0,-1)}
var PREP_DATA={teach:["Hafta — 7 kunlik aylana; 7 larni tashlab yuborish.","Qoldiqli bo'lish bilan katta sonlar.","Oylar kunlari (musht qoidasi), kabisa yili.","Kecha/ertaga jumboqlari, 5 marta uchraydigan kunlar."],
 mist:["1-dan 31-gacha 31 kun o'tdi deb hisoblaydi (30 emas).","O'tmishni oldinga sanaydi.","«Ertadan keyingi»ni «ertaga» bilan adashtiradi."],
 need:["Devoriy kalendar.","Hafta kunlari kartochkalari (7 ta)."],
 board:["<span class='w2'>n : 7 → qoldiq</span>","31 = 28 + <span class='w2'>3</span>, 30 = 28 + <span class='w2'>2</span>","Bugun = ertadan keyingi − 2","Kabisa: <span class='w2'>366 kun</span>"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
