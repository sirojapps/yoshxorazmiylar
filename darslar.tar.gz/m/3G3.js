
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G3',TITLE='3-sinf · Vaqt: sutka, soat, minut, sekund';
function g3t(m){m=((m%1440)+1440)%1440;return f3hm(Math.floor(m/60),m%60)}
function g3d(m){var h=Math.floor(m/60),r=m%60;return (h?h+' soat':'')+(h&&r?' ':'')+(r||!h?r+' min':'')}
// bo'sh vaqt nuri: a..b (minut), jumps: [[t1,t2]] — sakrashlar, marks — qo'shimcha vaqtlar
function g3line(a,b,jumps,o){o=o||{};clear();var g=S.g,x0=24,x1=336,X=function(t){return x0+(t-a)/(b-a)*(x1-x0)};if(o.title)T(g,14,16,o.title,{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 E('line',{x1:x0-6,y1:120,x2:x1+8,y2:120,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+8)+' 115 l8 5 l-8 5 Z',fill:'#33475b'},g);
 var pts=[a,b];jumps.forEach(function(j){pts.push(j[0],j[1])});var lx=-99,alt=0;pts.filter(function(v,i,s){return s.indexOf(v)===i}).sort(function(p,q){return p-q}).forEach(function(t){E('line',{x1:X(t),y1:113,x2:X(t),y2:127,stroke:'#33475b','stroke-width':2},g);alt=(X(t)-lx<34)?1-alt:0;lx=X(t);T(g,X(t),142+alt*13,g3t(t),{'font-size':10.5,'font-weight':800,fill:t===b||t===a?'#1d2b3a':'#5b6b7b'})});
 jumps.forEach(function(j,i){var xa=X(j[0]),xb=X(j[1]),xm=(xa+xb)/2,hgt=Math.min(48,16+(xb-xa)/4);E('path',{d:'M'+xa+' 112 Q'+xm+' '+(112-hgt*2)+' '+xb+' 112',fill:'none',stroke:[C.a,C.b,C.ok,C.blue][i%4],'stroke-width':2.5},g);T(g,xm,112-hgt-6,g3d(j[1]-j[0]),{'font-size':10.5,'font-weight':800,fill:[C.a,C.b,C.ok,C.blue][i%4]})});
 if(o.mid!=null){E('line',{x1:X(o.mid),y1:108,x2:X(o.mid),y2:158,stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'4 3'},g);T(g,X(o.mid),169,'yarim tun',{'font-size':10,fill:C.bad,'font-weight':700})}}
var G3U=[['sutka','1 sutka = 24 soat'],['soat','1 soat = 60 minut'],['minut','1 minut = 60 sekund'],['sekund','1 sekund — «bir, ikki» deb sanagandek']];
function g3lad(sel){clear();var g=S.g,xs=[45,135,225,315];T(g,180,20,'kattadan kichikka →',{'font-size':11,fill:'#3a4a5a'});
 G3U.forEach(function(u,i){var on=i===sel,y=46+i*26;E('rect',{x:xs[i]-36,y:y,width:72,height:36,rx:8,fill:on?C.a:'#fff',stroke:on?C.a:C.line,'stroke-width':2},g);T(g,xs[i],y+23,u[0],{'font-size':14,'font-weight':800,fill:on?'#fff':'#1d2b3a'});
  if(i<3)T(g,xs[i]+8,y+54,['×24','×60','×60'][i],{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue})});
 f3calc([sel==null?'Birlikni tanlang':'<b>'+G3U[sel][1]+'</b>','1 sutka = 24 · 60 = 1440 minut'])}
function g3set(){var h=S.g3h,m=S.g3m;clear();T(S.g,14,18,'Soatni 3:15 ga qo‘ying',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});f3clock(180,92,72,h,m,{shade:[0,m]});
 var ok=h===3&&m===15;f3calc([ok?'✓ <b>3:15</b> — uchdan chorak (15 minut) o‘tdi':'Hozir: <b>'+h+':'+(m<10?'0':'')+m+'</b>'+(h>3||m>15?' — o‘tib ketdi, keyingi bosishda 12:00 dan':'')])}
function g3mv(dh,dm,done){if(S.g3h>3||S.g3m>15){S.g3h=12;S.g3m=0}if(S.g3h===12)S.g3h=0;S.g3h+=dh;S.g3m+=dm;if(S.g3h===0)S.g3h=12;g3set();if(S.g3h===3&&S.g3m===15)done()}
var G3P3=[function(){clear();f3clock(180,90,72,4,0);f3calc(['«To‘rtga chorak kam» — to‘rt bo‘lishiga hali 15 minut bor'])},
 function(){clear();f3clock(180,90,72,3,45,{shade:[45,60],shadeCol:'#ffd6d0'});f3calc(['Soat 4 dan 15 minut orqaga: <b>3:45</b>','Xato: 4:15 (bu «to‘rtdan chorak o‘tdi») yoki 4:45'])}];
var G3P4=[function(){g3line(570,730,[],{title:'Sayohat: 9:30 → 12:10. Necha minut?'});f3calc(['Bo‘sh vaqt nuri: boshi va oxiri'])},
 function(){g3line(570,730,[[570,600]],{title:'Sayohat: 9:30 → 12:10. Necha minut?'});f3calc(['Avval butun soatgacha: 9:30 → 10:00 = 30 min'])},
 function(){g3line(570,730,[[570,600],[600,720]],{title:'Sayohat: 9:30 → 12:10. Necha minut?'});f3calc(['10:00 → 12:00 = 2 soat'])},
 function(){g3line(570,730,[[570,600],[600,720],[720,730]],{title:'Sayohat: 9:30 → 12:10. Necha minut?'});f3calc(['12:00 → 12:10 = 10 min','30 + 120 + 10 = <b>160 minut</b> (2 soat 40 min)'])}];
var G3P5=[function(){g3line(1370,1645,[],{title:'Poyezd: 22:50 → ertasi 03:25',mid:1440});f3calc(['Yarim tundan o‘tadi! 3:25 − 22:50 qilib bo‘lmaydi'])},
 function(){g3line(1370,1645,[[1370,1380],[1380,1440]],{title:'Poyezd: 22:50 → ertasi 03:25',mid:1440});f3calc(['22:50 → 23:00 = 10 min; 23:00 → 00:00 = 1 soat'])},
 function(){g3line(1370,1645,[[1370,1380],[1380,1440],[1440,1620],[1620,1645]],{title:'Poyezd: 22:50 → ertasi 03:25',mid:1440});f3calc(['00:00 → 03:00 = 3 soat; 03:00 → 03:25 = 25 min','Jami: <b>4 soat 35 minut</b>'])}];
var G3P6=[function(){g3line(1120,1235,[],{title:'Kino 18:40 da boshlandi, 1 soat 55 min davom etdi'});f3calc(['Tugash vaqtini topamiz: boshidan oldinga sakraymiz'])},
 function(){g3line(1120,1235,[[1120,1180]],{title:'Kino 18:40 da boshlandi, 1 soat 55 min davom etdi'});f3calc(['18:40 + 1 soat = 19:40'])},
 function(){g3line(1120,1235,[[1120,1180],[1180,1200],[1200,1235]],{title:'Kino 18:40 da boshlandi, 1 soat 55 min davom etdi'});f3calc(['19:40 + 20 min = 20:00 (butun soat)','20:00 + 35 min = <b>20:35</b> (20 + 35 = 55 ✓)'])}];
function g3sched(st){clear();var g=S.g,x0=14,k=330/225;T(g,14,18,'Darslar 8:30 da. Dars 45 min, tanaffus 10 min. 4-dars tugashi?',{'font-size':10.5,'text-anchor':'start',fill:'#3a4a5a'});var t=0;
 for(var i=0;i<4;i++){E('rect',{x:x0+t*k,y:50,width:45*k,height:36,rx:4,fill:C.blue,opacity:.85},g);T(g,x0+(t+22.5)*k,73,(i+1)+'-dars',{'font-size':11,'font-weight':800,fill:'#fff'});t+=45;
  if(i<3){E('rect',{x:x0+t*k,y:50,width:10*k,height:36,fill:st>=1?C.a:'#eee'},g);t+=10}}
 T(g,x0,104,'8:30',{'font-size':11,'font-weight':800});if(st>=2){T(g,x0+t*k-6,104,'12:00',{'font-size':11,'font-weight':800,fill:C.ok})}
 if(st>=1)T(g,180,134,'tanaffus 3 ta (4 ta emas!)',{'font-size':12,fill:C.a,'font-weight':800})}
var G3P7=[function(){g3sched(0);f3calc(['4 ta dars: 45 · 4 = 180 min = 3 soat'])},function(){g3sched(1);f3calc(['Tanaffuslar: darslar <b>orasida</b> — 3 ta: 10 · 3 = 30 min'])},function(){g3sched(2);f3calc(['8:30 + 3 soat 30 min = <b>12:00</b>','Xato: 4 ta tanaffus → 12:10'])}];
function g3days(st){clear();var g=S.g;for(var i=0;i<5;i++){var x=18+i*66;E('rect',{x:x,y:40,width:60,height:46,rx:6,fill:st>=2&&i<2?'#ffd6d0':'#eef4fb',stroke:C.line},g);T(g,x+30,60,(i+1)+'-sutka',{'font-size':11,'font-weight':700});T(g,x+30,78,'24 soat',{'font-size':11,'font-weight':800,fill:C.blue})}
 if(st>=2){E('rect',{x:18+132+2,y:36,width:2,height:54,fill:C.bad},g);T(g,85,108,'49 soat = 2 sutka 1 soat',{'font-size':11,'font-weight':800,fill:C.bad})}}
var G3P8=[function(){g3days(0);f3calc(['5 sutka − 49 soat = ? soat'])},function(){g3days(1);f3calc(['5 sutka = 5 · 24 = <b>120 soat</b>'])},function(){g3days(2);f3calc(['120 − 49 = <b>71 soat</b>','Xato: 5 − 49 yoki 1 sutka = 100 soat deb hisoblash'])}];
function g3hist(){clear('#e9eef8');var g=S.g;E('path',{d:'M60 150 L60 70 A120 120 0 0 1 180 40',fill:'none',stroke:'#6b5b9a','stroke-width':10},g);E('rect',{x:40,y:150,width:280,height:8,fill:'#9a8a6a'},g);T(g,220,80,'Ulug‘bek',{'font-size':14,'font-weight':800,fill:'#3d2f6b'});T(g,220,100,'rasadxonasi',{'font-size':12,fill:'#3d2f6b'});
 f3msg('Yil uzunligi: 365 kun 6 soat 10 minut 8 sekund')}
var STEPS=[
{h:"Vaqt birliklari",sum:"1 sutka = 24 soat, 1 soat = 60 minut, 1 minut = 60 sekund.",a:"m01",
 start:function(){g3lad(null)},fin:function(){g3lad(1)},
 html:"<p>Vaqt birliklarini bosing (kamida 3 tasini). Diqqat: bu yerda zinapoya <b>10 lik emas</b>!</p>",
 btns:G3U.map(function(u,i){return [u[0],function(c,done){g3lad(i);mvK(done,3)}]}),g2:1,
 after:"<p>Uzunlik va massada qadamlar 10, 100, 1000. Vaqtda esa <b>24 va 60</b>. Shuning uchun 1 soat 30 minut — 130 minut emas, <b>90 minut</b>.</p>",
 q:{t:"2 sutka necha minut?",opts:["2880","2400","480","1440"],ok:0,why:"2 · 24 = 48 soat, 48 · 60 = 2880.",hint:"Avval soatga, keyin minutga.",full:"2 sutka = 48 soat = 48 · 60 = 2880 minut. «2400» — 1 soat = 50 min deb olish, «1440» — faqat 1 sutka, «480» — soatni 10 ga ko'paytirish."},
 tn:"Bolalar 1 minut davomida ko'zini yumib o'tirsin va «hozir 1 minut bo'ldi» deganda qo'l ko'tarsin — vaqt sezgisi."},
{h:"Soatni o'rnatamiz",sum:"Kichik mil — soat, katta mil — minut. 3:15 — katta mil 3 raqamida (15 minut).",a:"m02",
 start:function(){S.g3h=12;S.g3m=0;g3set()},fin:function(){S.g3h=3;S.g3m=15;g3set()},
 html:"<p>Soat millarini <b>3:15</b> ga to'g'rilang. Katta (qizil) mil — minutlar, kichik mil — soatlar:</p>",
 btns:[["+1 soat",function(c,done){g3mv(1,0,done)}],["+5 minut",function(c,done){g3mv(0,5,done)}]],g2:1,
 after:"<p>Katta mil 3 raqamini ko'rsatsa — 15 minut, ya'ni soatning <b>choragi</b>. Kichik mil 3 dan biroz o'tgan, chunki soat ham sekin yurib turadi.</p>",
 q:{t:"Katta mil 9 da, kichik mil 7 va 8 orasida. Soat necha?",opts:["9:07","7:45","8:45","7:09"],ok:1,why:"9 raqami — 45 minut, soat 7 dan o'tgan.",hint:"Katta milning har bir raqami — 5 minut.",full:"Katta mil 9 da: 9 · 5 = 45 minut. Kichik mil 7 dan o'tgan, 8 ga yetmagan — soat 7. Javob 7:45. «8:45» — kichik mil yaqin turgan raqamni olish xatosi."},
 tn:"Kartondan soat yasab, millarini bolalar o'zi aylantirsin. Har raqam — 5 minut (5 lik sanoq)."},
{h:"«...ga chorak kam» qanday o'qiladi",sum:"«To'rtga chorak kam» = 3:45. «To'rtdan chorak o'tdi» = 4:15.",a:"m03",
 start:function(){startPh(G3P3)},fin:function(){S.ph=1;G3P3[1]()},
 html:"<p>Kundalik nutqda soatni ikki xil aytamiz: «to'rtdan chorak o'tdi» va «to'rtga chorak kam». Ikkinchisini ko'raylik:</p>",btns:[phaser(G3P3)],
 after:"<p>«...ga <b>kam</b>» — hali o'sha soat bo'lmagan: orqaga sanaymiz. To'rtga 15 minut kam = 3:45. To'rtga 10 minut kam = 3:50.</p>",
 q:{t:"«Oltiga yigirma minut kam» — raqamlarda?",opts:["06:20","05:40","06:40","05:20"],ok:1,why:"6:00 dan 20 minut oldin — 5:40.",hint:"Hali soat 6 bo'lmagan. 6:00 dan orqaga 20 minut.",full:"60 − 20 = 40 minut, soat hali 5: 05:40. «06:20» — «oltidan yigirma o'tdi», «06:40» — soatni o'zgartirmaslik xatosi."},
 tn:"Bank testida (#174) shu tur bor. Doskada ikki ustun: «...dan o'tdi» va «...ga kam»."},
{h:"Vaqt oralig'i: sakrab sanaymiz",sum:"9:30 → 12:10: 30 min + 2 soat + 10 min = 160 minut.",a:"m04",
 start:function(){startPh(G3P4)},fin:function(){S.ph=3;G3P4[3]()},
 html:"<p><i>«Sayohatga 9:30 da ketib, 12:10 da qaytildi. Sayohat necha minut davom etgan?»</i> Vaqtni ayirish noqulay — vaqt nurida <b>sakraymiz</b>:</p>",btns:[phaser(G3P4)],
 after:"<p>Usul: avval <b>butun soatgacha</b>, keyin butun soatlar, keyin qolgan minutlar. 12:10 − 9:30 ni oddiy sonlardek ayirsak (1210 − 930 = 280) — <b>noto'g'ri</b>, chunki soatda 100 emas, 60 minut!</p>",
 q:{t:"Dars 13:45 da boshlanib, 15:20 da tugadi. Necha minut davom etdi?",opts:["95 minut","175 minut","85 minut","1 soat 25 minut"],ok:0,why:"15 + 60 + 20 = 95.",hint:"13:45 dan 14:00 gacha qancha?",full:"13:45 → 14:00 = 15 min, 14:00 → 15:00 = 60 min, 15:00 → 15:20 = 20 min. Jami 95 min (1 soat 35 min). «175» — 1520 − 1345 ni oddiy sonlardek ayirish xatosi."},
 tn:"Gollandiya RME «bo'sh son o'qi» usuli. Doskada nur chizib, sakrashlarni yoy bilan ko'rsating."},
{h:"Tuzoq: yarim tundan o'tish",sum:"22:50 → 03:25: 10 min + 1 soat + 3 soat + 25 min = 4 soat 35 minut.",a:"m05",
 start:function(){startPh(G3P5)},fin:function(){S.ph=2;G3P5[2]()},
 html:"<p><i>«Poyezd 22:50 da jo'nab, ertasi kuni 03:25 da yetib keldi. Yo'lda qancha yurdi?»</i></p>",btns:[phaser(G3P5)],
 after:"<p>Yarim tunda (00:00) soat yana noldan boshlanadi. Shuning uchun <b>yarim tungacha</b> va <b>yarim tundan keyin</b> alohida sanaymiz: 1 soat 10 min + 3 soat 25 min = 4 soat 35 min.</p>",
 q:{t:"Bola 21:30 da uxladi va 06:45 da uyg'ondi. Necha vaqt uxladi?",opts:["9 soat 15 minut","15 soat 15 minut","8 soat 45 minut","9 soat 45 minut"],ok:0,why:"21:30 → 00:00 = 2 soat 30 min; 00:00 → 06:45 = 6 soat 45 min; jami 9 soat 15 min.",hint:"Yarim tungacha qancha? Keyin yarim tundan 06:45 gacha.",full:"2 soat 30 min + 6 soat 45 min = 8 soat 75 min = 9 soat 15 min. «15 soat 15 min» — 21:30 − 06:45 ni teskari ayirish."},
 tn:"Bolalarning o'z kun tartibi: necha soat uxlaydi? Bu ham yarim tundan o'tadi."},
{h:"Tugash vaqtini topish",sum:"18:40 + 1 soat 55 min: 19:40 → 20:00 → 20:35.",a:"m06",
 start:function(){startPh(G3P6)},fin:function(){S.ph=2;G3P6[2]()},
 html:"<p><i>«Kino 18:40 da boshlanib, 1 soat 55 minut davom etdi. Soat nechada tugadi?»</i></p>",btns:[phaser(G3P6)],
 after:"<p>40 + 55 = 95 minut — bu 1 soat 35 minut! Shuning uchun 18:95 emas, <b>20:35</b>. Minutlar 60 dan oshsa — 1 soat qo'shamiz.</p>",
 q:{t:"Soat 16:45. 50 minutdan keyin soat necha bo'ladi?",opts:["17:35","16:95","17:45","17:25"],ok:0,why:"16:45 + 15 = 17:00, + 35 = 17:35.",hint:"Avval 17:00 gacha nechta minut?",full:"16:45 → 17:00 = 15 min. Qolgan 50 − 15 = 35 min: 17:35. «16:95» — minutlarni 60 ga aylantirmaslik."},
 tn:"Televizor dasturidan haqiqiy ko'rsatuv vaqtlarini olib, tugash vaqtini topdiring."},
{h:"Tuzoq: tanaffuslar soni",sum:"4 dars × 45 min + 3 tanaffus × 10 min = 3 soat 30 min; 8:30 → 12:00.",a:"m07",
 start:function(){startPh(G3P7)},fin:function(){S.ph=2;G3P7[2]()},
 html:"<p><i>«Darslar 8:30 da boshlanadi. Har dars 45 minut, darslar orasida 10 minutdan tanaffus. 4-dars soat nechada tugaydi?»</i></p>",btns:[phaser(G3P7)],
 after:"<p>4 ta dars <b>orasida</b> 3 ta tanaffus bor (4 ta daraxt orasida 3 ta oraliq kabi). Chizma bu tuzoqni ko'rsatadi.</p>",
 q:{t:"Bog'bon har 35 minutda bitta daraxt sug'oradi. 1-daraxtni 9:40 da sug'ordi. 5-daraxtni soat nechada sug'oradi?",opts:["12:00","12:35","11:25","11:40"],ok:0,why:"1-dan 5-gacha 4 ta oraliq: 35 · 4 = 140 min; 9:40 + 2 soat 20 min = 12:00.",hint:"1-daraxtdan 5-daraxtgacha nechta oraliq?",full:"Oraliqlar 4 ta: 4 · 35 = 140 min = 2 soat 20 min. 9:40 + 2:20 = 12:00. «12:35» — 5 ta oraliq olish xatosi."},
 tn:"«Oraliqlar» masalasi: 5 ta bola qatorda turgan bo'lsa, ular orasida nechta bo'sh joy?"},
{h:"Tuzoq: aralash birliklar",sum:"5 sutka − 49 soat = 120 − 49 = 71 soat.",a:"m08",
 start:function(){startPh(G3P8)},fin:function(){S.ph=2;G3P8[2]()},
 html:"<p><i>«Hisoblang: 5 sutka − 49 soat. Javobni soatda yozing.»</i></p>",btns:[phaser(G3P8)],
 after:"<p>Birinchi qadam doim bir xil — <b>bir xil birlikka</b> keltirish. 1 sutka = 24 soat (100 emas!).</p>",
 q:{t:"Sekundomer boshida 7 min 48 s, oxirida 9 min 15 s ni ko'rsatdi. Necha sekund o'tdi?",opts:["87 s","167 s","127 s","153 s"],ok:0,why:"9 min 15 s = 555 s, 7 min 48 s = 468 s, 555 − 468 = 87.",hint:"7 min 48 s dan 8 min gacha qancha? Keyin 9 min 15 s gacha.",full:"7:48 → 8:00 = 12 s; 8:00 → 9:00 = 60 s; 9:00 → 9:15 = 15 s. Jami 87 s. «167» — 915 − 748 kabi oddiy ayirish xatosi."},
 tn:"Haqiqiy sekundomer (telefon) bilan: bolalar 10 marta o'tirib-turishini o'lchasin."},
{h:"Bilasizmi? Ulug'bek va yil uzunligi",sum:"Mirzo Ulug'bek rasadxonasida yil uzunligi 365 kun 6 soat 10 minut 8 sekund deb hisoblangan.",a:"m09",
 start:function(){g3hist()},fin:function(){g3hist()},
 html:"<p>🔭 XV asrda Samarqandda <b>Mirzo Ulug'bek</b> rasadxonasida olimlar yil uzunligini hisoblashgan: <b>365 kun 6 soat 10 minut 8 sekund</b>. Bu bugungi aniq o'lchovdan atigi bir minutga yaqin farq qiladi!</p><p>⏱ Soatni 60 minutga, minutni 60 sekundga bo'lish odati juda qadimiy — <b>Qadimgi Bobil</b>da 60 lik sanoq ishlatilgan.</p>",
 tn:"Samarqanddagi Ulug'bek rasadxonasi rasmini ko'rsating; sekstantning yer ostidagi qismi saqlanib qolgan."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){g3lad(1)},fin:function(){g3lad(1)},
 html:"<div class='memo'><ul><li><b>1 sutka = 24 soat</b>, <b>1 soat = 60 min</b>, <b>1 min = 60 s</b>.</li><li>Katta mil — minut (har raqam 5 minut), kichik mil — soat.</li><li>«To'rtga chorak kam» = 3:45; «to'rtdan chorak o'tdi» = 4:15.</li><li>Vaqt oralig'i: vaqt nurida <b>butun soatgacha</b> sakraymiz.</li><li>Yarim tun (00:00) — alohida sanaymiz.</li><li>Minutlar 60 dan oshsa — 1 soat qo'shamiz: 18:95 emas, 19:35.</li><li>4 ta dars orasida <b>3</b> ta tanaffus.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring."}
];
var PROBS=[
{t:"3 soat necha minut?",o:["180","300","30","63"],k:0,s:"3 · 60."},
{t:"2 sutka necha soat?",o:["48","24","200","26"],k:0,s:"2 · 24."},
{t:"5 minut necha sekund?",o:["300","500","50","65"],k:0,s:"5 · 60."},
{t:"1 soat 20 minut necha minut?",o:["80","120","21","100"],k:0,s:"60 + 20."},
{t:"«To'rtga o'n besh minut kam» — raqamlarda?",o:["03:45","04:15","04:45","03:55"],k:0,s:"4:00 dan 15 min oldin."},
{t:"Katta mil 6 da, kichik mil 2 va 3 orasida. Soat necha?",o:["2:30","6:02","3:30","2:06"],k:0,s:"6 raqami — 30 min, soat 2."},
{t:"Sayohat 9:30 da boshlanib, 12:10 da tugadi. Necha minut?",o:["160","140","220","280"],k:0,s:"30 + 120 + 10."},
{t:"Poyezd 22:50 da jo'nab, ertasi 03:25 da keldi. Yo'lda qancha?",o:["4 soat 35 min","5 soat 35 min","4 soat 25 min","19 soat 25 min"],k:0,s:"1 s 10 min + 3 s 25 min."},
{t:"Kino 18:40 da boshlanib, 1 soat 55 minut davom etdi. Tugadi:",o:["20:35","19:35","20:45","21:35"],k:0,s:"19:40 + 55 min."},
{t:"Soat 16:45. 50 minutdan keyin soat necha?",o:["17:35","17:25","17:45","18:35"],k:0,s:"17:00 + 35."},
{t:"Toqqa chiqish 2 soat 35 min, tushish 1 soat 50 min. Jami?",o:["4 soat 25 min","4 soat 35 min","3 soat 25 min","4 soat 15 min"],k:0,s:"3 soat 85 min = 4 soat 25 min."},
{t:"5 sutka − 49 soat = ? soat",o:["71","81","51","69"],k:0,s:"120 − 49."},
{t:"1 sutka va 5 soat necha minut?",o:["1740","1445","1500","1800"],k:0,s:"29 · 60."},
{t:"Darslar 8:30 da. Dars 45 min, orasida 10 min tanaffus. 4-dars tugashi?",o:["12:00","12:10","11:50","11:30"],k:0,s:"180 + 30 = 210 min."},
{t:"Bog'bon har 35 minutda bitta daraxt sug'oradi. 1-daraxt 9:40 da. 5-daraxt?",o:["12:00","12:35","11:25","11:40"],k:0,s:"4 oraliq · 35 = 140 min."},
{t:"Sekundomer 7 min 48 s dan 9 min 15 s gacha. Necha sekund?",o:["87","167","127","153"],k:0,s:"12 + 60 + 15."},
{t:"Zafar 1 soatda 4 ta daraxtni oqlaydi. 6 tasini necha minutda?",o:["90","100","75","120"],k:0,s:"1 daraxt 15 min, 6 · 15."},
{t:"Sayyoh 1 km ni 15 minutda yuradi. 12 km ni necha soatda?",o:["3","2","4","1"],k:0,s:"180 min = 3 soat."},
{t:"Dilnoza maktabga piyoda, uyga avtobusda — 1 soat 10 min. Ikkala tomonga avtobusda — 20 min. Ikkala tomonga piyoda?",o:["2 soat","1 soat 20 min","2 soat 20 min","1 soat 50 min"],k:0,s:"Avtobus bir tomon 10 min, piyoda 60 min, ikki tomon 120 min."},
{t:"Raqamli soat 20:19 ni ko'rsatyapti. Keyingi safar aynan shu 4 ta raqam (2, 0, 1, 9) bilan qaysi vaqt chiqadi?",o:["21:09","09:12","09:21","02:19"],k:0,s:"20:19 dan keyin: 20:91 bo'lmaydi; 21:09."}
];
function PRACT_STAGE(){S.ph=3;G3P4[3]()}
var PREP_DATA={teach:["Sutka, soat, minut, sekund va ular orasidagi bog'lanish (24 va 60).","Soatni o'qish: «...dan o'tdi», «...ga kam».","Vaqt oralig'i va tugash vaqti — bo'sh vaqt nurida sakrash.","Tuzoqlar: yarim tundan o'tish, tanaffuslar soni, aralash birliklar."],
 mist:["1 soat = 100 minut deb oddiy sonlardek ayiradi: 12:10 − 9:30 = 2:80.","«To'rtga chorak kam» ni 4:15 yoki 4:45 deb yozadi.","Minutlar 60 dan oshganini sezmaydi: 18:95.","Darslar sonicha tanaffus oladi."],
 need:["Kartondan yasalgan soat (har bolaga), devor soati.","Telefondagi sekundomer."],
 board:["<span class='w2'>1 sutka = 24 soat; 1 soat = 60 min; 1 min = 60 s</span>.","Vaqt nuri: <span class='w2'>9:30 →(30)→ 10:00 →(2 s)→ 12:00 →(10)→ 12:10</span>.","<span class='w2'>22:50 → 00:00 → 03:25</span>.","<span class='w2'>To'rtga chorak kam = 3:45</span>."]};
