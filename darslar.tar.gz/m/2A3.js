var CODE='2A3',TITLE='2-sinf · Sonlar ketma-ketligi: oldingi va keyingi son';
// ---------- sahna vositalari ----------
function nl(from,to,o){o=o||{};clear();var x0=22,x1=338,y=o.y||100,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},S.g);E('path',{d:'M'+(x1+8)+' '+(y-6)+' L'+(x1+16)+' '+y+' L'+(x1+8)+' '+(y+6)+' Z',fill:'#33475b'},S.g);
 for(var v=from;v<=to;v++){var col=(o.col&&o.col[v])||null;E('line',{x1:X(v),y1:y-7,x2:X(v),y2:y+7,stroke:'#33475b','stroke-width':v%10===0?2.6:1.4},S.g);
  if(col)E('circle',{cx:X(v),cy:y,r:o.r||9,fill:col,stroke:'#fff','stroke-width':2},S.g);
  if(o.all||v%5===0||col)T(S.g,X(v),y+(o.lab||26),String(v),{'font-size':o.fs||12,'font-weight':col?800:500,fill:col||'#5b6b7b'})}
 return X}
function arc(a,b,lab,col,y){y=y||100;var X=S.X;E('path',{d:'M'+X(a)+' '+(y-10)+' Q'+(X(a)+X(b))/2+' '+(y-46)+' '+X(b)+' '+(y-10),fill:'none',stroke:col||C.blue,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-5)+' '+(y-18)+' L'+X(b)+' '+(y-10)+' L'+(X(b)+(X(b)>X(a)?-8:8))+' '+(y-12),fill:'none',stroke:col||C.blue,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-40,lab,{'font-size':12,'font-weight':800,fill:col||C.blue})}
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// 100 jadvali
function grid(sel){clear();var x0=40,y0=8,c=28,h=16;S.cells={};
 for(var n=1;n<=100;n++){var r=Math.floor((n-1)/10),q=(n-1)%10,x=x0+q*c,y=y0+r*h,f='#fff';
  if(sel){if(n===sel)f=C.hi;else if(n===sel-1||n===sel+1)f='#bfe9e3';else if(n===sel-10||n===sel+10)f='#ffd9b8'}
  var e=E('rect',{x:x,y:y,width:c-1,height:h-1,rx:2,fill:f,stroke:'#dde5ee'},S.g);e._n=n;S.cells[n]=e;T(S.g,x+c/2,y+12,String(n),{'font-size':9,'font-weight':n===sel?800:500,fill:'#33475b','pointer-events':'none'})}
 [].forEach.call(S.g.querySelectorAll('rect'),function(e){if(e._n){e.style.cursor='pointer';e.addEventListener('click',function(){if(S.onCell)S.onCell(e._n)})}})}
// minoralar (ketma-ket sonlar yig'indisi)
function towers(vals,lab,opt){opt=opt||{};clear();var n=vals.length,w=60,gap=30,x0=180-(n*w+(n-1)*gap)/2,base=150,u=7;
 vals.forEach(function(v,i){var x=x0+i*(w+gap),h=v*u;E('rect',{x:x,y:base-h,width:w,height:h,rx:4,fill:(opt.cols&&opt.cols[i])||C.b,stroke:C.line,'stroke-width':1.5},S.g);
  if(opt.extra&&opt.extra[i]){var eh=opt.extra[i]*u;E('rect',{x:x,y:base-h-eh,width:w,height:eh,rx:3,fill:C.c,stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'4 3'},S.g)}
  T(S.g,x+w/2,base-h-(opt.extra&&opt.extra[i]?opt.extra[i]*u:0)-8,String(v+(opt.extra&&opt.extra[i]?'+'+opt.extra[i]:'')),{'font-size':15,'font-weight':800,fill:'#1d2b3a'})});
 E('line',{x1:20,y1:base,x2:340,y2:base,stroke:'#33475b','stroke-width':2},S.g);if(lab)T(S.g,180,168,lab,{'font-size':12,'font-weight':700,fill:C.blue})}
// ---------- bosqichlar ----------
var P3=[function(){nl(35,45,{col:{39:C.blue},all:1});msg('39 dan keyingi son qaysi?')},
 function(){nl(35,45,{col:{39:C.blue,40:C.ok},all:1});arc(39,40,'+1',C.ok);msg('39 + 1 = <b>40</b> — 9 ta birlikka 1 qo‘shildi, yangi o‘nlik bo‘ldi!')},
 function(){nl(65,75,{col:{70:C.blue,69:C.bad},all:1});arc(70,69,'−1',C.bad);msg('70 dan oldingi son — <b>69</b> (68 emas, 71 emas)')}];
var P4=[function(){nl(44,60,{col:{46:C.bad,58:C.bad},all:1,fs:10});msg('46 va 58 <b>orasida</b> nechta son bor? Chetlari kirmaydi')},
 function(){var col={46:C.bad,58:C.bad};for(var v=47;v<=57;v++)col[v]=C.ok;nl(44,60,{col:col,all:1,fs:10,r:7});msg('47, 48, … 57 — sanaymiz: <b>11 ta</b>')},
 function(){var col={46:C.bad,58:C.bad};for(var v=47;v<=57;v++)col[v]=C.ok;nl(44,60,{col:col,all:1,fs:10,r:7});Br(S.X(46),S.X(58),70,'58 − 46 = 12 qadam',true);msg('Qadamlar 12 ta, sonlar esa <b>12 − 1 = 11</b> ta: chetlarini olib tashladik')}];
var P5=[function(){var col={};for(var v=36;v<=52;v++)col[v]=C.ok;nl(34,54,{col:col,fs:9,r:6});msg('36 <b>dan</b> 52 <b>gacha</b> — ikkala chet ham <b>kiradi</b>')},
 function(){var col={};for(var v=36;v<=52;v++)col[v]=C.ok;nl(34,54,{col:col,fs:9,r:6});Br(S.X(36),S.X(52),70,'52 − 36 = 16 qadam',true);msg('Qadamlar 16 ta, sonlar <b>16 + 1 = 17</b> ta (chetlar ham sanaladi)')}];
var P6=[function(){nl(36,44,{col:{39:C.blue},all:1});msg('«Men o‘ylagan sondan <b>oldingi</b> son <b>39 dan keyingi</b> songa teng»')},
 function(){nl(36,44,{col:{39:C.blue,40:C.a},all:1});arc(39,40,'keyingi',C.a);msg('39 dan keyingi son — <b>40</b>. Demak o‘ylagan sondan oldingi son 40')},
 function(){nl(36,44,{col:{39:C.blue,40:C.a,41:C.ok},all:1});arc(39,40,'',C.a);arc(40,41,'',C.ok);msg('40 — oldingi bo‘lsa, o‘ylagan son <b>41</b>')},
 function(){nl(36,44,{col:{39:C.blue,40:C.a,41:C.ok,42:C.bad},all:1});arc(39,40,'',C.a);arc(40,41,'',C.ok);arc(41,42,'keyingi',C.bad);msg('Savol: o‘ylagan sondan keyingi son — <b>42</b>')}];
var P7=[function(){towers([11,12,13],'Uchta ketma-ket son: yig‘indisi 36');msg('Ketma-ket sonlar zinapoyaga o‘xshaydi: har biri oldingisidan 1 ta ko‘p')},
 function(){towers([12,12,12],'Kattasidan 1 ni olib, kichigiga beramiz',{cols:[C.ok,C.b,C.ok]});msg('Hammasi tenglashdi: 36 : 3 = <b>12</b> — bu <b>o‘rtadagi</b> son')},
 function(){towers([11,12,13],'11 + 12 + 13 = 36',{cols:[C.b,C.ok,C.a]});msg('O‘rtadagi 12, oldingisi 11, keyingisi <b>13</b> — eng kattasi')}];
var P8=[function(){towers([28,29].map(function(v){return v/2}),'');clear();towers([14,14],'',{extra:[0,.5]});S.g.querySelectorAll('text')[0].textContent='kichigi';S.g.querySelectorAll('text')[1].textContent='kichigi+1';msg('Ikki ketma-ket son: kattasi kichigidan <b>1</b> ta ko‘p. Yig‘indisi 57')},
 function(){clear();towers([14,14],'',{extra:[0,.5],cols:[C.b,C.b]});S.g.querySelectorAll('text')[0].textContent='?';S.g.querySelectorAll('text')[1].textContent='?+1';msg('Ortiqcha 1 ni olib tashlaymiz: 57 − 1 = <b>56</b> — endi ikkalasi teng')},
 function(){clear();towers([14,14],'',{cols:[C.ok,C.a],extra:[0,.5]});S.g.querySelectorAll('text')[0].textContent='28';S.g.querySelectorAll('text')[1].textContent='29';msg('56 : 2 = <b>28</b> — kichigi. Kattasi 29. Tekshiramiz: 28 + 29 = 57 ✓')}];
var STEPS=[
{h:"Keyingi va oldingi son",sum:"Keyingi son — 1 ta ko'p (o'ngdagi qo'shni), oldingi son — 1 ta kam (chapdagi qo'shni).",a:"m01",
 start:function(){S.v=47;S.used={};nl(40,55,{col:{47:C.blue},all:1,fs:11});msg('Son o‘qida <b>47</b>. Tugmalarni bosing')},fin:function(){nl(40,55,{col:{46:C.bad,47:C.blue,48:C.ok},all:1,fs:11});msg('46 ← <b>47</b> → 48')},
 html:"<p>Son o'qida chumoli <b>47</b> da turibdi. Bir qadam o'ngga yursa — <b>keyingi</b> son, bir qadam chapga — <b>oldingi</b> son. Sinab ko'ring:</p>",
 btns:[["← oldingi (−1)",function(c,done){S.used.l=1;if(S.v>41)S.v--;show1();if(S.used.l&&S.used.r)done()}],["keyingi (+1) →",function(c,done){S.used.r=1;if(S.v<54)S.v++;show1();if(S.used.l&&S.used.r)done()},'u']],g2:1,
 after:"<p><b>Keyingi son</b> = son + 1 (o'ngdagi qo'shni). <b>Oldingi son</b> = son − 1 (chapdagi qo'shni). 47 ning qo'shnilari: <b>46</b> va <b>48</b>.</p>",
 q:{t:"64 dan oldingi son qaysi?",opts:["65","63","54","74"],ok:1,why:"64 − 1 = 63.",hint:"Oldingi — chapdagi qo'shni, 1 ta kam.",full:"Oldingi son 1 ta kam: 64 − 1 = 63. 65 — keyingi son. 54 va 74 — 10 ta kam/ko'p."},
 tn:"Polda lenta bilan son o'qi yasang: bola «son» bo'lib turadi, «oldingi» desangiz bir qadam chapga, «keyingi» desangiz o'ngga yuradi."},
{h:"100 jadvali: qo'shnilar",sum:"100 jadvalida: chap/o'ng qo'shni ±1, ust/ost qo'shni ±10.",a:"m02",
 start:function(){S.taps=0;grid(null);msg('Jadvaldagi istalgan sonni bosing');S.onCell=function(n){S.taps++;grid(n);msg('<b>'+n+'</b>: oldingi '+(n-1)+', keyingi '+(n+1)+(n>10?' · ustidagi '+(n-10):'')+(n<=90?' · ostidagi '+(n+10):''));if(S.taps>=2&&S.d2)S.d2()}},
 fin:function(){grid(47);msg('<b>47</b>: oldingi 46, keyingi 48 · ustidagi 37 · ostidagi 57')},
 html:"<p>Bu — <b>100 jadvali</b>. Sonlar qator-qator tartib bilan yozilgan. Istalgan sonni bosing va uning qo'shnilariga qarang (kamida 2 ta son).</p>",
 act:function(c,done){S.d2=function(){S.d2=null;done()};c.querySelector('.hint').textContent='Jadvaldagi sonlarni bosing.'},
 after:"<p>Yashil — <b>oldingi va keyingi</b> (±1). To'q sariq — <b>ustidagi va ostidagi</b> (±10). Ostidagi son har doim 10 ta ko'p: 47 ostida 57.</p>",
 q:{t:"100 jadvalida 35 ning ostidagi son qaysi?",opts:["36","34","45","25"],ok:2,why:"Ostidagi son 10 ta ko'p: 35 + 10 = 45.",hint:"Ostidagi qatorga o'tganda son nechtaga ortadi?",full:"Har bir qatorda 10 ta son. Pastga tushsak, 10 ta ko'p: 35 + 10 = 45. 25 — ustidagi, 34 va 36 — yon qo'shnilar."},
 tn:"100 jadvali — dunyo bo'yicha boshlang'ich sinflarning asosiy vositasi. Sinf devoriga osib qo'ying va har kuni 1–2 daqiqa «qo'shnisini top» o'yinini o'ynang."},
{h:"O'nlikdan o'tishda ehtiyot bo'ling",sum:"39 dan keyin 40 keladi (9 + 1 = yangi o'nlik); 70 dan oldin 69.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Eng ko'p xato shu yerda: 39 dan keyin nima? 70 dan oldin nima? Kuzating.</p>",
 btns:[phaser(P3)],
 after:"<p>39 + 1 = <b>40</b>: to'qqizta birlikka bitta qo'shilsa — o'nta, ya'ni yangi o'nlik. 70 − 1 = <b>69</b>: o'nlikdan bitta olinadi, 9 ta birlik qoladi.</p>",
 q:{t:"70 dan keyingi son 70 dan oldingi sondan qanchaga katta?",opts:["1","10","2","0"],ok:2,why:"Keyingi 71, oldingi 69: 71 − 69 = 2.",hint:"Avval ikkalasini toping: 70 dan keyingi va 70 dan oldingi.",full:"70 dan keyingi — 71, oldingi — 69. Farqi: 71 − 69 = 2. Son o'qida ular orasida 2 qadam bor."},
 tn:"«80 dan oldingi», «59 dan keyingi» kabi savollarni og'zaki tez-tez bering — o'nlik chegarasi avtomatik bo'lishi kerak."},
{h:"Tuzoq: «orasida» nechta son?",sum:"46 va 58 orasida: 58 − 46 − 1 = 11 ta son (chetlari kirmaydi).",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>«46 va 58 sonlari <b>orasida</b> nechta son bor?» Ko'pchilik tezda 58 − 46 = 12 deydi. Tekshiramiz!</p>",
 btns:[phaser(P4)],
 after:"<p>58 − 46 = 12 — bu <b>qadamlar</b> soni. Lekin «orasida» deganda 46 va 58 ning <b>o'zi kirmaydi</b>, shuning uchun 1 ta kam: <b>11</b>.</p><p>Qoida: <b>orasidagi sonlar = katta − kichik − 1</b>.</p>",
 q:{t:"87 va 93 sonlari orasida nechta son bor?",opts:["6","5","4","7"],ok:1,why:"93 − 87 − 1 = 5: 88, 89, 90, 91, 92.",hint:"Qadamlar: 93 − 87. Orasidagilar bundan 1 ta kam.",full:"Sanaymiz: 88, 89, 90, 91, 92 — 5 ta. Formula: 93 − 87 = 6 qadam, orasidagi sonlar 6 − 1 = 5."},
 tn:"Bu — mashhur «ustunlar xatosi». Barmoqlar bilan ko'rsating: 5 ta barmoq orasida 4 ta oraliq bor."},
{h:"Tuzoq: «dan … gacha» nechta son?",sum:"36 dan 52 gacha (ikkalasi ham kiradi): 52 − 36 + 1 = 17 ta son.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Endi teskarisi: «36 <b>dan</b> 52 <b>gacha</b> (ikkalasi ham kiradi) nechta son bor?»</p>",
 btns:[phaser(P5)],
 after:"<p>Qadamlar 52 − 36 = 16 ta, lekin sonlar <b>1 ta ko'p</b> — chunki birinchi son (36) ham sanaladi: <b>17</b>.</p><div class='life'><div>🚧<span>«orasida» — chetlari <b>kirmaydi</b>: katta − kichik <b>− 1</b></span></div><div>📏<span>«dan … gacha» — chetlari <b>kiradi</b>: katta − kichik <b>+ 1</b></span></div></div>",
 q:{t:"Kitobning 15-betidan 24-betigacha (ikkalasi ham) o'qildi. Necha bet o'qildi?",opts:["9","10","8","11"],ok:1,why:"24 − 15 + 1 = 10 bet.",hint:"15-bet ham, 24-bet ham o'qildi. Chetlari kiradimi?",full:"Chetlari kiradi: 24 − 15 = 9, yana 1 qo'shamiz — 10 bet. Sanab ko'ring: 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 — 10 ta."},
 tn:"Hayotiy misol: «Dushanbadan payshanbagacha necha kun?» — 4 kun (ikkalasi kiradi), «dushanba va payshanba orasida» — 2 kun."},
{h:"Topishmoq: zanjirni yechamiz",sum:"Oldingisi 39 dan keyingi songa teng → oldingi 40 → son 41 → keyingi 42.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>«Men o'ylagan sondan <b>oldingi</b> son <b>39 dan keyingi</b> songa teng. Men o'ylagan sondan <b>keyingi</b> son nechchi?» — so'zlar ko'p, lekin har birini bittadan yechamiz.</p>",
 btns:[phaser(P6,'▶ Keyingi bo‘g‘in')],
 after:"<p>Usul: so'zlarni <b>bittalab</b> son o'qida bajaramiz. Har bir «oldingi» — bir qadam chapga, har bir «keyingi» — bir qadam o'ngga. Shoshilsak, bir qadamni unutib qo'yamiz.</p>",
 q:{t:"Men o'ylagan sondan keyingi son 60 ga teng. Men o'ylagan sondan oldingi sondan oldingi son qaysi?",opts:["61","57","58","59"],ok:1,why:"O'ylagan son 59, oldingisi 58, uning oldingisi 57.",hint:"Avval o'ylagan sonni toping: undan keyingisi 60.",full:"Keyingisi 60 bo'lsa, o'ylagan son 59. Oldingisi — 58, undan oldingisi — 57. Son o'qida chapga 2 qadam."},
 tn:"Bolalar topishmoqlarni o'zi tuzsin va bir-biriga bersin — bu eng yaxshi mustahkamlash."},
{h:"Ketma-ket sonlar yig'indisi",sum:"Uchta ketma-ket son yig'indisi 36: o'rtadagisi 36 : 3 = 12 → 11, 12, 13.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>«Ketma-ket kelgan uchta sonning yig'indisi 36. Ularning eng kattasi qaysi?» Sonlarni minora qilib ko'ramiz.</p>",
 btns:[phaser(P7)],
 after:"<p>Kattasidan 1 ni olib kichigiga bersak, uchalasi <b>tenglashadi</b>. Demak 36 ni 3 ga bo'lsak — <b>o'rtadagi son</b> chiqadi: 12. Qo'shnilari: 11 va 13.</p>",
 q:{t:"Ketma-ket kelgan uchta sonning yig'indisi 45. Eng kichigi qaysi?",opts:["15","14","16","13"],ok:1,why:"45 : 3 = 15 — o'rtadagi; eng kichigi 14.",hint:"Avval o'rtadagi sonni toping: yig'indini 3 ga bo'ling.",full:"O'rtadagi: 45 : 3 = 15. Sonlar: 14, 15, 16. Eng kichigi — 14. Tekshiramiz: 14 + 15 + 16 = 45 ✓."},
 tn:"«Tenglashtirish» g'oyasi — Yaponiya va Singapur darsliklarida o'rtacha qiymatning asosi. Kubiklardan minora qurib ko'rsating."},
{h:"Ikki ketma-ket son",sum:"Yig'indisi 57: ortiqcha 1 ni olamiz → 56 : 2 = 28 (kichigi), kattasi 29.",a:"m08",
 start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>«Ikkita ketma-ket sonning yig'indisi 57. Kichigini toping.» 57 ni 2 ga bo'lib bo'lmaydi-ku? Kuzating.</p>",
 btns:[phaser(P8)],
 after:"<p>Kattasi kichigidan <b>1</b> ta ko'p. Shu ortiqcha 1 ni olib tashlasak: 57 − 1 = 56, ikkalasi teng — 56 : 2 = <b>28</b>. Kattasi 29.</p>",
 q:{t:"Ikkita ketma-ket sonning yig'indisi 75. Kattasi qaysi?",opts:["37","38","36","39"],ok:1,why:"75 − 1 = 74, 74 : 2 = 37 — kichigi, kattasi 38.",hint:"Ortiqcha 1 ni olib tashlang va ikkiga bo'ling — bu kichigi.",full:"75 − 1 = 74, 74 : 2 = 37 — kichigi. Kattasi 38. Tekshiramiz: 37 + 38 = 75 ✓."},
 tn:"Bu — 5–6-sinf tenglamasining (x + x + 1 = 57) rasmdagi ko'rinishi. Kuchli bolalarga shuni aytib qo'ying."},
{h:"Bilasizmi? Ustunlar xatosi",sum:"10 m panjarada har 1 m da ustun bo'lsa — 11 ta ustun kerak. Bu xatoni hatto dasturchilar ham qiladi.",a:"m09",
 start:function(){fence(false)},fin:function(){fence(true)},
 html:"<p>🚧 10 metrli panjaraga har 1 metrda ustun qo'yiladi. Nechta ustun kerak? Ko'pchilik «10» deydi…</p>",
 btns:[["🚧 Ustunlarni qo'yish",function(c,done){fence(true);done()}]],
 after:"<p>Kerak <b>11 ta</b> ustun: oraliqlar 10 ta, ustunlar bitta ko'p. Bu xato shunchalik mashhurki, uning nomi bor — <b>«ustunlar xatosi»</b>. Uni qadimgi quruvchilar ham, bugungi kompyuter dasturchilari ham qiladi. Siz endi qilmaysiz!</p>",
 tn:"Bolalardan so'rang: «5 qavatli uyda 1-qavatdan 5-qavatga necha zinapoya marshi bor?» (4 ta)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){nl(40,55,{col:{46:C.bad,47:C.blue,48:C.ok},all:1,fs:11});msg('46 ← <b>47</b> → 48')},fin:function(){nl(40,55,{col:{46:C.bad,47:C.blue,48:C.ok},all:1,fs:11});msg('46 ← <b>47</b> → 48')},
 html:"<div class='memo'><ul><li><b>Keyingi</b> = son + 1, <b>oldingi</b> = son − 1.</li><li>O'nlik chegarasi: 39 → <b>40</b>, 70 ← <b>69</b>.</li><li>100 jadvalida: yon qo'shnilar ±1, ust/ost ±10.</li><li><b>Orasida</b> (chetlari kirmaydi): katta − kichik <b>− 1</b>. 46 va 58 orasida 11 ta.</li><li><b>Dan … gacha</b> (chetlari kiradi): katta − kichik <b>+ 1</b>. 36 dan 52 gacha 17 ta.</li><li>Uchta ketma-ket son: yig'indi : 3 = <b>o'rtadagi</b>.</li><li>Ikkita ketma-ket son: (yig'indi − 1) : 2 = <b>kichigi</b>.</li><li>Topishmoqlarni son o'qida <b>bittalab</b> yeching.</li></ul></div>",
 tn:"Keyingi darsni «20 va 30 orasida nechta son bor?» (9 ta) savoli bilan boshlang."}
];
function show1(){var col={};col[S.v]=C.blue;if(S.v!==47)col[47]='#9aa8b6';nl(40,55,{col:col,all:1,fs:11});if(S.v!==47)arc(47,S.v,S.v>47?'keyingi':'oldingi',S.v>47?C.ok:C.bad);msg(S.v===47?'<b>47</b>':(S.v>47?'47 dan keyingi: <b>'+S.v+'</b>':'47 dan oldingi: <b>'+S.v+'</b>')+(Math.abs(S.v-47)>1?' (bu endi qo‘shni emas — '+Math.abs(S.v-47)+' qadam)':''))}
function fence(on){clear();var x0=30,x1=330,y=110;E('line',{x1:x0,y1:y-20,x2:x1,y2:y-20,stroke:'#a0703c','stroke-width':5},S.g);E('line',{x1:x0,y1:y-40,x2:x1,y2:y-40,stroke:'#a0703c','stroke-width':5},S.g);
 for(var i=0;i<10;i++)T(S.g,x0+(i+.5)*30,y+22,'1 m',{'font-size':9,fill:'#5b6b7b'});
 if(on){for(var j=0;j<=10;j++){E('rect',{x:x0+j*30-4,y:y-56,width:8,height:56,rx:2,fill:'#6b3d12'},S.g);T(S.g,x0+j*30,y+40,String(j+1),{'font-size':11,'font-weight':800,fill:C.ok})}msg('Oraliqlar <b>10</b> ta, ustunlar <b>11</b> ta')}
 else msg('10 metr, har 1 metrda ustun. Nechta ustun?')}
var PROBS=[
{t:"58 dan keyingi son qaysi?",o:["59","57","60","68"],k:0,s:"Keyingi son 1 ta ko'p: 58 + 1 = 59."},
{t:"80 dan oldingi son qaysi?",o:["79","81","70","89"],k:0,s:"80 − 1 = 79."},
{t:"49 dan keyingi son qaysi?",o:["50","48","410","59"],k:0,s:"49 + 1 = 50 — yangi o'nlik."},
{t:"Beshta ketma-ket son: □, □, 45, □, 47. Birinchi son qaysi?",o:["43","44","42","41"],k:0,s:"45 dan oldin 44, undan oldin 43."},
{t:"46 va 58 sonlari orasida nechta son bor?",o:["11","12","13","10"],k:0,s:"58 − 46 − 1 = 11."},
{t:"36 dan 52 gacha (ikkalasi ham) nechta son bor?",o:["17","16","18","15"],k:0,s:"52 − 36 + 1 = 17."},
{t:"Ketma-ket kelgan uchta sonning yig'indisi 36. Eng kattasi qaysi?",o:["13","12","11","14"],k:0,s:"36 : 3 = 12 — o'rtadagi. Eng kattasi 13."},
{t:"Ikkita ketma-ket sonning yig'indisi 57. Kichigini toping.",o:["28","29","27","30"],k:0,s:"(57 − 1) : 2 = 28."},
{t:"Men o'ylagan sondan oldingi son 39 dan keyingi songa teng. Men o'ylagan sondan keyingi son nechchi?",o:["42","41","40","43"],k:0,s:"39 dan keyingi 40 — oldingi son. O'ylagan 41, keyingisi 42."},
{t:"100 jadvalida 64 ning ustidagi son qaysi?",o:["54","74","63","65"],k:0,s:"Ustidagi son 10 ta kam: 64 − 10 = 54."},
{t:"20 va 30 sonlari orasida nechta son bor?",o:["9","10","11","8"],k:0,s:"30 − 20 − 1 = 9: 21, 22, … 29."},
{t:"Qaysi son 69 va 71 orasida turadi?",o:["70","68","72","60"],k:0,s:"69 dan keyin 70, keyin 71."},
{t:"Ketma-ket kelgan uchta sonning yig'indisi 60. O'rtadagisi qaysi?",o:["20","19","21","30"],k:0,s:"60 : 3 = 20."},
{t:"Ikkita ketma-ket sonning yig'indisi 41. Kattasi qaysi?",o:["21","20","22","19"],k:0,s:"(41 − 1) : 2 = 20 — kichigi, kattasi 21."},
{t:"Ali 12-uydan 20-uygacha (ikkalasi ham) gazeta tarqatdi. Nechta uyga?",o:["9","8","10","7"],k:0,s:"20 − 12 + 1 = 9 ta uy."},
{t:"12 metrli yo'lakka har 2 metrda daraxt ekildi (boshi va oxirida ham). Nechta daraxt?",o:["7","6","12","5"],k:0,s:"Oraliqlar 12 : 2 = 6 ta, daraxtlar bitta ko'p — 7 ta."},
{t:"Eng kichik ikki xonali sondan oldingi son qaysi?",o:["9","11","10","99"],k:0,s:"Eng kichik ikki xonali — 10, oldingisi 9."},
{t:"Eng katta ikki xonali sondan keyingi son qaysi?",o:["100","98","999","90"],k:0,s:"99 + 1 = 100."},
{t:"Sanoq 0 dan boshlanib, har safar 5 ga ortadi: 0, 5, 10, … 7-o'rindagi son qaysi? (0 — 1-o'rinda)",o:["30","35","25","40"],k:0,s:"1) 0, 2) 5, 3) 10, 4) 15, 5) 20, 6) 25, 7) 30."},
{t:"Men o'ylagan sondan keyingi sondan keyingi son 50 ga teng. Men o'ylagan son qaysi?",o:["48","49","52","51"],k:0,s:"50 dan orqaga 2 qadam: 49, 48."}
];
function PRACT_STAGE(){grid(null);S.onCell=function(n){grid(n);msg('<b>'+n+'</b>: oldingi '+(n-1)+', keyingi '+(n+1))};msg('Kerak bo‘lsa, jadvaldan foydalaning')}
var PREP_DATA={teach:["Oldingi va keyingi son (±1), o'nlik chegarasidan o'tish (39 → 40).","100 jadvali: qo'shnilar ±1 va ±10.","«Orasida» va «dan … gacha»: chetlari kiradimi-yo'qmi.","Topishmoqlar zanjiri; ketma-ket sonlar yig'indisi."],
 mist:["39 dan keyingini «310» yoki «49» deydi.","«46 va 58 orasida» — 12 deydi (chetlarni sanaydi).","«36 dan 52 gacha» — 16 deydi (birinchisini unutadi).","Topishmoqda bir qadamni tashlab ketadi."],
 need:["Devoriy 100 jadvali.","Polda lenta bilan son o'qi.","Kubiklar (minoralar uchun)."],
 board:["<span class='w2'>46 ← 47 → 48</span>.","<span class='w2'>39 + 1 = 40</span>, <span class='w2'>70 − 1 = 69</span>.","Orasida: <span class='w2'>58 − 46 − 1 = 11</span>.","Dan … gacha: <span class='w2'>52 − 36 + 1 = 17</span>.","Uchta ketma-ket: <span class='w2'>36 : 3 = 12 → 11, 12, 13</span>.","Ikkita ketma-ket: <span class='w2'>(57 − 1) : 2 = 28</span>.","Panjara: 10 oraliq — 11 ustun."]};
