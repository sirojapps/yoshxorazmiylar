var CODE='4I2',TITLE='4-sinf · Grafik va ma’lumotlarni tahlil qilish';
function qdmsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// o: xl [x yorliqlari], mn, mx, st, ser [[qiymatlar, rang, upto]], hi [[i,qiymat,lab,col]], seg [[i1,i2,col]], tap, xu, yu
function qdgr(o){clear();var g=S.g,n=o.xl.length,x0=44,W=296,y0=146,H=124,i,v;S.qd=o;
 var X=function(i){return x0+W*i/(n-1)},Y=function(v){return y0-(v-o.mn)/(o.mx-o.mn)*H};
 for(v=o.mn;v<=o.mx;v+=o.st){E('line',{x1:x0,y1:Y(v),x2:x0+W,y2:Y(v),stroke:'#e6ebf0'},g);T(g,x0-7,Y(v)+4,''+v,{'font-size':10,'font-weight':700,fill:'#5a6b7d','text-anchor':'end'})}
 for(i=0;i<n;i++){E('line',{x1:X(i),y1:y0,x2:X(i),y2:y0-H,stroke:'#f0f3f6'},g);T(g,X(i),y0+15,''+o.xl[i],{'font-size':10,'font-weight':700,fill:'#33475b'})}
 E('line',{x1:x0,y1:y0,x2:x0+W+8,y2:y0,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0,y1:y0,x2:x0,y2:y0-H-8,stroke:'#33475b','stroke-width':2},g);
 if(o.yu)T(g,x0+4,14,o.yu,{'font-size':10,'font-weight':700,fill:'#5a6b7d','text-anchor':'start'});if(o.xu)T(g,x0+W,y0+27,o.xu,{'font-size':10,'font-weight':700,fill:'#5a6b7d','text-anchor':'end'});
 (o.seg||[]).forEach(function(s){var a=o.ser[0][0];E('line',{x1:X(s[0]),y1:Y(a[s[0]]),x2:X(s[1]),y2:Y(a[s[1]]),stroke:s[2]||C.bad,'stroke-width':8,'stroke-linecap':'round',opacity:.45},g)});
 (o.ser||[]).forEach(function(s){var a=s[0],up=s[2]==null?a.length-1:s[2],d='';for(i=0;i<=up;i++){if(a[i]==null)continue;d+=(d?' L':'M')+X(i)+' '+Y(a[i])}if(s[3]!==0&&up>0)E('path',{d:d,fill:'none',stroke:s[1]||C.blue,'stroke-width':3,'stroke-linejoin':'round'},g);for(i=0;i<=up;i++)if(a[i]!=null)E('circle',{cx:X(i),cy:Y(a[i]),r:4,fill:s[1]||C.blue},g)});
 (o.hi||[]).forEach(function(h){E('line',{x1:X(h[0]),y1:Y(h[1]),x2:X(h[0]),y2:y0,stroke:h[3]||C.a2,'stroke-dasharray':'4 3','stroke-width':1.5},g);E('line',{x1:x0,y1:Y(h[1]),x2:X(h[0]),y2:Y(h[1]),stroke:h[3]||C.a2,'stroke-dasharray':'4 3','stroke-width':1.5},g);E('circle',{cx:X(h[0]),cy:Y(h[1]),r:6,fill:h[3]||C.a2,stroke:'#fff','stroke-width':1.5},g);if(h[2])T(g,X(h[0]),Y(h[1])-10,h[2],{'font-size':12,'font-weight':800,fill:h[3]||C.a2})});
 if(o.tap){var r=E('rect',{x:x0-6,y:y0-H-8,width:W+12,height:H+16,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var i=Math.max(0,Math.min(n-1,Math.round((p.x-x0)/W*(n-1)))),hs=o.st/2,vv=Math.round((o.mn+(y0-p.y)/H*(o.mx-o.mn))/hs)*hs;o.tap(i,Math.max(o.mn,Math.min(o.mx,vv)))})}}
var QDX=['8','10','12','14','16','18'],QDV=[6,10,16,20,null,14];
var QDT=[6,10,16,20,18,14];
function qdT(o){o=o||{};return {xl:QDX,mn:0,mx:24,st:4,yu:'°C',xu:'soat',ser:[[o.v||QDT,C.blue,o.up]],hi:o.hi,seg:o.seg,tap:o.tap}}
var QDP1=[function(){qdgr(qdT({up:0}));qdmsg('Soat 8 da harorat 6°. Nuqta qo‘yamiz')},
 function(){qdgr(qdT({up:3}));qdmsg('Har 2 soatda o‘lchab, nuqtalarni ketma-ket tutashtiramiz')},
 function(){qdgr(qdT({}));qdmsg('Mana — <b>chiziqli grafik</b>: harorat kun bo‘yi qanday o‘zgargani bir qarashda ko‘rinadi')}];
var QDM=[0,40,80,80,140,200];
function qdM(o){o=o||{};return {xl:['0','1','2','3','4','5'],mn:0,mx:200,st:40,yu:'km',xu:'soat',ser:[[QDM,C.ok,o.up]],hi:o.hi,seg:o.seg}}
var QDP6=[function(){qdgr(qdM({up:2}));qdmsg('Avtobus 2 soatda 80 km yurdi')},
 function(){qdgr(qdM({up:3,seg:[[2,3,C.bad]]}));qdmsg('2-soatdan 3-soatgacha chiziq <b>yotiq</b>: masofa o‘zgarmadi — avtobus <b>to‘xtagan</b>')},
 function(){qdgr(qdM({seg:[[3,5,C.a2]]}));qdmsg('Keyin qiyaroq chiziq: 3–5 soatda 120 km — avvalgidan <b>tezroq</b>')}];
var QDA=[0,60,120,180],QDB=[180,135,90,45];
var QDP8=[function(){qdgr({xl:['0','1','2','3'],mn:0,mx:180,st:30,yu:'km (A shahardan)',xu:'soat',ser:[[QDA,C.blue]]});qdmsg('Ko‘k: 1-mashina A shahardan B ga, soatiga 60 km')},
 function(){qdgr({xl:['0','1','2','3'],mn:0,mx:180,st:30,yu:'km (A shahardan)',xu:'soat',ser:[[QDA,C.blue],[QDB,C.bad]]});qdmsg('Qizil: 2-mashina B dan A ga, soatiga 45 km')},
 function(){qdgr({xl:['0','1','2','3'],mn:0,mx:180,st:30,yu:'km (A shahardan)',xu:'soat',ser:[[QDA,C.blue],[QDB,C.bad]]});var X=44+296*(180/105)/3,Y=146-(60*180/105)/180*124;E('circle',{cx:X,cy:Y,r:8,fill:'none',stroke:C.ok,'stroke-width':3},S.g);T(S.g,X+44,Y+24,'uchrashuv',{'font-size':12,'font-weight':800,fill:C.ok});qdmsg('Chiziqlar <b>kesishgan</b> joy — mashinalar uchrashgan vaqt va joy')}];
var STEPS=[
{h:"Chiziqli grafik",sum:"Chiziqli grafik kattalikning vaqt bo'yicha o'zgarishini ko'rsatadi: nuqtalar ketma-ket tutashtiriladi.",a:"m01",
 start:function(){startPh(QDP1)},fin:function(){S.ph=2;QDP1[2]()},
 html:"<p>Ob-havo stansiyasida harorat har 2 soatda o'lchandi. Natijani qanday ko'rsatamiz?</p>",
 btns:[phaser(QDP1)],
 after:"<p>Gorizontal o'qda — <b>vaqt</b>, vertikal o'qda — <b>harorat</b>. Har bir o'lchov — nuqta, nuqtalar ketma-ket tutashtiriladi. Ustunli diagramma alohida narsalarni solishtirishga, <b>chiziqli grafik</b> esa <b>o'zgarishni</b> kuzatishga qulay.</p>",
 q:{t:"Nimani ko'rsatish uchun chiziqli grafik qulayroq?",opts:["Bolaning bo'yi yillar davomida qanday o'sgani","Sinflardagi o'quvchilar soni","Sevimli mevalar","Uch do'kondagi narxlar"],ok:0,why:"Vaqt bo'yicha o'zgarish — chiziqli grafik.",hint:"Qaysi biri vaqt o'tishi bilan o'zgaradi?",full:"Bo'yning yillar bo'yicha o'zgarishi — vaqt bo'yicha o'zgarish, chiziqli grafik qulay. Qolganlari alohida guruhlarni solishtirish — ustunli diagramma."},
 tn:"Darsdan oldin bir hafta davomida har kuni ertalab haroratni yozib boring va shu ma'lumot bilan grafik chizing."},
{h:"Grafikdan qiymatni o'qish",sum:"Kerakli vaqtdan tik yuqoriga, grafikka yetgach chapga — o'qdagi sonni o'qiymiz.",a:"m02",
 start:function(){qdgr(qdT({}));qdmsg('Soat 14 da harorat necha gradus edi?')},fin:function(){qdgr(qdT({hi:[[3,20,'20°']]}));qdmsg('✓ 14 dan yuqoriga, keyin chapga: <b>20°</b>')},
 btns:[["16°",function(c,done){qdmsg('16° — soat 12 dagi harorat. 14 ga qarang')}],["20°",function(c,done){STEPS[1].fin();done()}],["14°",function(c,done){qdmsg('14 — bu vaqt (soat), harorat emas')}],["18°",function(c,done){qdmsg('18° — soat 16 dagi harorat')}]],g2:1,
 html:"<p>Grafikdan o'qing: <b>soat 14</b> da harorat necha gradus edi?</p>",
 after:"<p>Gorizontal o'qda <b>14</b> ni topib, tik yuqoriga grafikka yetamiz, keyin chapga — vertikal o'qda <b>20°</b>. Chalkashmaslik uchun: vaqt — pastda, qiymat — chapda.</p>",
 q:{t:"Grafikka ko'ra harorat qachon 10° edi?",opts:["Soat 10 da","Soat 18 da","Soat 12 da","Soat 8 da"],ok:0,why:"10° ga mos nuqta soat 10 da.",hint:"Endi teskarisi: chapda 10 ni topib, o'ngga yuring.",full:"Vertikal o'qda 10° dan o'ngga yursak, grafik soat 10 dagi nuqtada uchraydi. Soat 8 da 6°, 18 da 14°."},
 tn:"Chizg'ichni ikki marta qo'yish usulini o'rgating: tik — vaqtdan, yotiq — nuqtadan o'qqa."},
{h:"Eng yuqori va eng past",sum:"Grafikning eng baland nuqtasi — eng katta qiymat (maksimum), eng past nuqtasi — eng kichik (minimum).",a:"m03",
 start:function(){qdgr(qdT({}));qdmsg('Kunning eng issiq vaqti qachon bo‘lgan?')},fin:function(){qdgr(qdT({hi:[[3,20,'eng issiq',C.bad],[0,6,'eng sovuq',C.blue]]}));qdmsg('✓ Eng issiq — soat <b>14</b> (20°), eng sovuq — soat 8 (6°)')},
 btns:[["Soat 12",function(c,done){qdmsg('Soat 12 da 16°. Grafik undan keyin yana ko‘tarilgan')}],["Soat 14",function(c,done){STEPS[2].fin();done()}],["Soat 18",function(c,done){qdmsg('Soat 18 — oxirgi o‘lchov, eng issiq emas: 14°')}]],g3:1,
 html:"<p>Grafik bo'yicha kunning <b>eng issiq</b> vaqti qachon bo'lgan?</p>",
 after:"<p>Grafikning <b>eng baland</b> nuqtasi — soat 14 (20°). <b>Eng past</b> nuqtasi — soat 8 (6°). Kun davomidagi o'zgarish: 20 − 6 = <b>14°</b>. Grafikning yaxshi tomoni: eng katta va eng kichikni sonlarni solishtirmasdan, ko'z bilan bir zumda topamiz.</p>",
 q:{t:"Kun davomida eng katta va eng kichik harorat farqi?",opts:["14°","26°","20°","6°"],ok:0,why:"20 − 6 = 14.",hint:"Eng yuqori va eng past qiymatni toping.",full:"Eng yuqori 20°, eng past 6°: 20 − 6 = 14°. 26° — qo'shib yuborish."},
 tn:"«Tog' cho'qqisi» va «vodiy» so'zlarini ishlating: bolalar grafikdagi cho'qqi va vodiyni barmoq bilan ko'rsatsin."},
{h:"O'sish va kamayish",sum:"Grafik chapdan o'ngga ko'tarilsa — kattalik o'sadi, tushsa — kamayadi; qiyalik qancha keskin bo'lsa, o'zgarish shuncha tez.",a:"m04",
 start:function(){qdgr(qdT({}));qdmsg('Harorat qaysi 2 soatda <b>eng tez</b> ko‘tarilgan?')},fin:function(){qdgr(qdT({seg:[[1,2,C.bad]]}));qdmsg('✓ 10 dan 12 gacha: 10° → 16°, <b>+6°</b> — eng keskin qism')},
 btns:[["8–10",function(c,done){qdgr(qdT({seg:[[0,1,C.blue]]}));qdmsg('8–10: 6° → 10°, +4°')}],["10–12",function(c,done){STEPS[3].fin();done()}],["12–14",function(c,done){qdgr(qdT({seg:[[2,3,C.blue]]}));qdmsg('12–14: 16° → 20°, +4°')}],["16–18",function(c,done){qdgr(qdT({seg:[[4,5,C.blue]]}));qdmsg('16–18: harorat <b>kamaygan</b>: 18° → 14°')}]],g2:1,
 html:"<p>Grafik qaysi oraliqda eng <b>keskin</b> ko'tarilgan? Oraliqni tanlang.</p>",
 after:"<p>10 dan 12 gacha harorat <b>6°</b> ga oshgan — boshqa oraliqlarda 4°. Grafikda bu qism <b>eng tik</b>. 14 dan keyin grafik pastga tushadi — harorat <b>kamaygan</b>. Qoida: tik chiziq — tez o'zgarish, yotiqroq — sekin, yotiq — o'zgarish yo'q.</p>",
 q:{t:"Soat 14 dan 18 gacha harorat qanchaga o'zgargan?",opts:["6° ga kamaygan","6° ga oshgan","4° ga kamaygan","34° ga o'zgargan"],ok:0,why:"20° dan 14° ga: 6° kamaygan.",hint:"14 da va 18 da qiymatlarni o'qing.",full:"14 da 20°, 18 da 14°: 20 − 14 = 6° ga kamaygan. Oshgan emas — grafik pastga tushadi."},
 tn:"Bolalar qo'li bilan grafik shaklini havoda chizsin: ko'tarilish — qo'l yuqoriga, tushish — pastga. Tez o'zgarish — tik harakat."},
{h:"Grafikni to'ldiring",sum:"Jadvaldagi qiymatni grafikda mos vaqt va qiymat kesishgan joyga nuqta qilib qo'yamiz.",a:"m05",
 start:function(){qdgr(Object.assign(qdT({v:QDV}),{tap:qdt5}));qdmsg('Soat 16 da 18° edi. Nuqtani qo‘ying')},fin:function(){qdgr(qdT({hi:[[4,18,'18°',C.ok]]}));qdmsg('✓ Soat 16 va 18° kesishmasi')},
 act:function(c,done){S.d5=done},
 html:"<p>Soat 16 dagi o'lchov tushib qolgan. Jadvalda: <b>16:00 — 18°</b>. Grafikda mos joyni bosing (18 — 16 va 20 ning o'rtasi).</p>",
 after:"<p>Pastda <b>16</b> ni, chapda <b>18</b> ni topamiz — ular kesishgan joyga nuqta. Shkala 4 dan, shuning uchun 18 chiziqlar orasida (16 va 20 ning o'rtasida) bo'ladi.</p>",
 q:{t:"Shkala 4 dan: 0, 4, 8, 12... 14° qayerda bo'ladi?",opts:["12 va 16 ning o'rtasida","14-chiziqda","12 da","16 da"],ok:0,why:"14 = (12 + 16) : 2.",hint:"14 qaysi ikki chiziq orasida?",full:"Chiziqlar 12 va 16 da, 14 — ularning o'rtasi. 14-chiziq yo'q, chunki shkala 4 dan."},
 tn:"Grafikni qog'ozda ham chizdiring: o'qlarni chizish, shkala tanlash, nuqtalarni qo'yish — hammasini bola o'zi qilsin."},
{h:"Harakat grafigi",sum:"Masofa–vaqt grafigida yotiq qism — to'xtash, tikroq qism — tezroq harakat.",a:"m06",
 start:function(){startPh(QDP6)},fin:function(){S.ph=2;QDP6[2]()},
 html:"<p>Avtobus Qorako'ldan Buxoroga yo'l oldi. Grafikda bosib o'tilgan masofa ko'rsatilgan.</p>",
 btns:[phaser(QDP6)],
 after:"<p>0–2 soat: 80 km (soatiga 40 km). 2–3 soat: chiziq <b>yotiq</b> — masofa o'zgarmagan, avtobus <b>to'xtagan</b> (masalan, tushlik). 3–5 soat: 120 km, soatiga <b>60 km</b> — tezroq, shuning uchun chiziq tikroq. Jami 200 km.</p>",
 q:{t:"Grafikda avtobus jami qancha vaqt harakatda bo'lgan (to'xtashsiz)?",opts:["4 soat","5 soat","3 soat","1 soat"],ok:0,why:"5 soatdan 1 soat to'xtash: 4 soat.",hint:"Grafikning qaysi qismi to'xtash?",full:"Butun yo'l 5 soat, shundan 1 soat (2–3) to'xtash. Harakatda: 5 − 1 = 4 soat. 5 soat — to'xtashni ham qo'shib hisoblash."},
 tn:"Bolalarga o'z «maktabga yo'li» grafigini chizdiring: do'kon oldida to'xtash — yotiq chiziq."},
{h:"Grafikdan tezlik",sum:"Tezlik = masofa : vaqt. Grafikdan ikkala sonni o'qib, bo'lamiz.",a:"m07",
 start:function(){qdgr(qdM({hi:[[5,200,'200 km',C.a2]]}));qdmsg('3-soatdan 5-soatgacha tezlik qancha?')},fin:function(){qdgr(qdM({seg:[[3,5,C.a2]],hi:[[3,80,'80',C.blue],[5,200,'200',C.a2]]}));qdmsg('✓ (200 − 80) : (5 − 3) = 120 : 2 = <b>60 km/soat</b>')},
 btns:[["40 km/soat",function(c,done){qdmsg('40 km/soat — bu birinchi 2 soatdagi tezlik')}],["60 km/soat",function(c,done){STEPS[6].fin();done()}],["100 km/soat",function(c,done){qdmsg('200 : 2 = 100 — lekin 3-soatgacha 80 km yurilgan edi. Faqat shu qismni oling')}],["120 km/soat",function(c,done){qdmsg('120 km — 2 soatda yurilgan. Bir soatda-chi?')}]],g2:1,
 html:"<p>3-soatdan 5-soatgacha avtobus qanday tezlikda yurgan?</p>",
 after:"<p>3-soatda 80 km, 5-soatda 200 km: bu qismda <b>120 km</b> yurilgan, vaqt <b>2 soat</b>. Tezlik 120 : 2 = <b>60 km/soat</b>. Tuzoq: 200 ni butun (200 : 2 = 100) olish — boshidagi 80 km ni ayirmaslik.</p>",
 q:{t:"Butun yo'l (5 soat, 200 km) bo'yicha o'rtacha tezlik?",opts:["40 km/soat","60 km/soat","50 km/soat","1000 km/soat"],ok:0,why:"200 : 5 = 40 (to'xtash ham vaqtga kiradi).",hint:"Jami masofani jami vaqtga bo'ling.",full:"O'rtacha tezlik = jami masofa : jami vaqt = 200 : 5 = 40 km/soat. 50 — to'xtashni chiqarib (200 : 4), lekin o'rtacha tezlikka to'xtash vaqti ham kiradi."},
 tn:"Ikkita tuzoqni doskada yonma-yon yozing: «qism tezligi» va «o'rtacha tezlik». Ular har xil savol."},
{h:"Ikki grafik: uchrashuv",sum:"Bir chizmadagi ikki grafikning kesishgan nuqtasi — ikki kattalik teng bo'lgan payt (uchrashuv).",a:"m08",
 start:function(){startPh(QDP8)},fin:function(){S.ph=2;QDP8[2]()},
 html:"<p>A va B shaharlar orasi 180 km. Ikki mashina bir vaqtda bir-biriga qarab yo'lga chiqdi. Grafikda — har birining A shahardan uzoqligi.</p>",
 btns:[phaser(QDP8)],
 after:"<p>Ko'k chiziq ko'tariladi (A dan uzoqlashadi), qizil tushadi (A ga yaqinlashadi). Ular <b>kesishgan</b> joyda ikkala mashina A dan bir xil uzoqlikda — <b>uchrashgan</b>. Hisob: 180 : (60 + 45) = 180 : 105 ≈ 1,7 soat — grafikda ham 1 va 2 soat orasida.</p>",
 q:{t:"Grafikka ko'ra 1 soatdan keyin mashinalar orasidagi masofa?",opts:["75 km","60 km","135 km","105 km"],ok:0,why:"1 soatda ko'k 60, qizil 135: 135 − 60 = 75.",hint:"1-soatda ikkala grafikdan qiymatni o'qing.",full:"1 soatda ko'k mashina A dan 60 km, qizil 135 km uzoqda. Oralig'i 135 − 60 = 75 km. Hisob bilan ham: 180 − (60 + 45) = 75."},
 tn:"Ikkita bola sinfning ikki chetidan bir-biriga qarab yursin, boshqalar har 3 soniyada ularning joyini doskadagi grafikka belgilasin."},
{h:"Bilasizmi? Grafiklar hayotda",sum:"Shifokorlar yurak ishini, sinoptiklar ob-havoni, iqtisodchilar narxlarni grafikda kuzatadi.",a:"m09",
 start:function(){qdgr(qdT({}));qdmsg('Grafik — o‘zgarishni bir qarashda ko‘rsatadi')},fin:function(){qdgr(qdT({}));qdmsg('Grafik — o‘zgarishni bir qarashda ko‘rsatadi')},
 html:"<p>❤ <b>Elektrokardiogramma</b> (EKG) — yurak ishining grafigi. Shifokor uning shaklidan yurak sog'lig'ini biladi.</p><p>🌡 Ob-havo saytlaridagi «kun bo'yi harorat» egri chizig'i ham chiziqli grafik.</p><p>📈 Vaqt bo'yicha o'zgarish grafigini (masalan, eksport va import) 1786-yilda <b>Uilyam Pleyfer</b> kitobida keng qo'llagan.</p>",
 tn:"Telefondagi ob-havo ilovasidagi haroratning soatlik grafigini ko'rsating va undan ma'lumot o'qitib ko'ring."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){qdgr(qdM({}));qdmsg('Yotiq — to‘xtash, tik — tez')},fin:function(){qdgr(qdM({}));qdmsg('Yotiq — to‘xtash, tik — tez')},
 html:"<div class='memo'><ul><li>Chiziqli grafik — vaqt bo'yicha <b>o'zgarish</b>ni ko'rsatadi.</li><li>O'qish: vaqtdan tik yuqoriga → grafik → chapga o'qqa.</li><li>Eng baland nuqta — maksimum, eng past — minimum.</li><li>Ko'tarilish — o'sish, tushish — kamayish; tikroq — tezroq.</li><li>Harakat grafigida yotiq qism — to'xtash.</li><li>Tezlik = masofa farqi : vaqt farqi.</li><li>O'rtacha tezlik = jami masofa : jami vaqt (to'xtash ham kiradi).</li><li>Ikki grafik kesishgan joy — teng bo'lish (uchrashuv).</li></ul></div>",
 tn:"Uyga: bir kun davomida 4 marta uydagi haroratni (yoki tashqaridagi) yozib, grafik chizish."}
];
function qdt5(i,v){if(i===4&&v===18){STEPS[4].fin();if(S.d5){var d=S.d5;S.d5=null;d()}}else if(S.d5){var a=QDV.slice();a[4]=null;var o=Object.assign(qdT({v:a}),{tap:qdt5});o.hi=[[i,v,v+'°',C.grey]];qdgr(o);qdmsg(i!==4?'Bu soat '+QDX[i]+'. Kerak: soat <b>16</b>':'Bu '+v+'°. Kerak: <b>18°</b> — 16 va 20 ning o‘rtasi')}}
var PROBS=[
{t:"Grafikda soat 8 da 6°, soat 10 da 10°. Harorat qanchaga oshgan?",o:["4°","16°","2°","10°"],k:0,s:"10 − 6 = 4°."},
{t:"Grafikning qaysi qismi «kattalik o'zgarmadi» degani?",o:["Yotiq qism","Tik ko'tarilish","Pastga tushish","Eng baland nuqta"],k:0,s:"Yotiq — o'zgarish yo'q."},
{t:"Grafik chapdan o'ngga pastga tushyapti. Kattalik nima bo'lyapti?",o:["Kamayyapti","O'syapti","O'zgarmayapti","Ikki marta oshyapti"],k:0,s:"Tushish — kamayish."},
{t:"Harorat: 8 da 4°, 12 da 14°, 16 da 10°. Eng katta o'zgarish qaysi oraliqda?",o:["8–12 (10° ga)","12–16 (4° ga)","Teng","8–16 (6° ga)"],k:0,s:"14 − 4 = 10 > 14 − 10 = 4."},
{t:"Masofa–vaqt grafigi: 0 soat — 0 km, 3 soat — 150 km. Tezlik?",o:["50 km/soat","150 km/soat","450 km/soat","153 km/soat"],k:0,s:"150 : 3 = 50."},
{t:"Grafik: 1 soat — 60 km, 4 soat — 240 km. 1 va 4 soat orasidagi tezlik?",o:["60 km/soat","80 km/soat","240 km/soat","180 km/soat"],k:0,s:"(240 − 60) : 3 = 60."},
{t:"Velosipedchi grafigida 2–3 soat oralig'i yotiq. Bu nima?",o:["1 soat dam olgan","1 soat juda tez yurgan","Orqaga qaytgan","Grafik xato"],k:0,s:"Masofa o'zgarmagan — to'xtagan."},
{t:"Piyoda 4 soatda 12 km yurdi, shundan 1 soat dam oldi. Harakatdagi tezligi?",o:["4 km/soat","3 km/soat","12 km/soat","16 km/soat"],k:0,s:"12 : (4 − 1) = 4."},
{t:"Shu piyodaning o'rtacha tezligi (dam olish bilan)?",o:["3 km/soat","4 km/soat","2 km/soat","12 km/soat"],k:0,s:"12 : 4 = 3."},
{t:"Ikki o'quvchining bo'yi grafigi 10 yoshda kesishgan. Bu nimani bildiradi?",o:["10 yoshda bo'ylari teng bo'lgan","10 yoshda o'sish to'xtagan","Ikkalasi 10 sm o'sgan","Grafik xato"],k:0,s:"Kesishish — qiymatlar teng."},
{t:"Bakda 40 l suv bor, har kuni 5 l sarflanadi. Grafik har kuni 5 ga tushadi. 4 kundan keyin bakda qancha qoladi?",o:["20 l","35 l","25 l","15 l"],k:0,s:"40 − 4 · 5 = 20 l."},
{t:"Grafik nuqtalari: (0; 10), (1; 15), (2; 20), (3; 25). Qonuniyat bo'yicha 5 soatda?",o:["35","30","40","50"],k:0,s:"Har soat +5: 25 + 10 = 35."},
{t:"Haroratlar: 6°, 10°, 16°, 20°, 18°, 14°. O'rtacha harorat?",o:["14°","84°","16°","13°"],k:0,s:"84 : 6 = 14°."},
{t:"Mashina A dan B ga (180 km) 60 km/soat, ikkinchisi B dan A ga 30 km/soat bir vaqtda chiqdi. Grafiklar qachon kesishadi?",o:["2 soatda","3 soatda","6 soatda","1 soatda"],k:0,s:"180 : (60 + 30) = 2."},
{t:"Shu masalada uchrashuv A dan qancha uzoqda?",o:["120 km","60 km","90 km","180 km"],k:0,s:"2 · 60 = 120 km."},
{t:"Grafikda o'q 5 dan: 0, 5, 10, 15. Nuqta 10 va 15 ning o'rtasida. Qiymati?",o:["12,5","12","11","13"],k:0,s:"(10 + 15) : 2 = 12,5."},
{t:"Bola 0–1 soat: 4 km, 1–2 soat: 4 km, 2–3 soat: 0 km. 3 soatlik grafikning oxirgi qismi qanday?",o:["Yotiq","Tik yuqoriga","Pastga","Ko'rinmaydi"],k:0,s:"Masofa o'zgarmagan — yotiq."},
{t:"Qaysi grafik eng tez harakatni ko'rsatadi: 1 soatda 30 km, 2 soatda 50 km, 3 soatda 100 km?",o:["3 soatda 100 km (≈33 km/soat)","1 soatda 30 km","2 soatda 50 km","Hammasi teng"],k:0,s:"30, 25, ≈33 km/soat — eng tezi uchinchisi."},
{t:"Do'konning oylik savdosi grafigi: yan 20, fev 25, mar 25, apr 35. Qaysi oyda savdo o'zgarmadi?",o:["Martda (fevralga nisbatan)","Fevralda","Aprelda","Yanvarda"],k:0,s:"Fevral 25, mart 25 — yotiq qism."},
{t:"Shu grafikda qaysi oyda o'sish eng katta?",o:["Aprel (+10)","Fevral (+5)","Mart (0)","Teng"],k:0,s:"35 − 25 = 10 eng katta."}
];
function PRACT_STAGE(){qdgr(qdT({}))}
var PREP_DATA={teach:["Chiziqli grafik: o'qlar, nuqtalar, tutashtirish.","Grafikdan qiymat o'qish va teskarisi; maksimum, minimum.","O'sish, kamayish, o'zgarish tezligi; grafikni to'ldirish.","Harakat grafigi: to'xtash, tezlik, o'rtacha tezlik; ikki grafikning kesishishi."],
 mist:["Vaqt va qiymat o'qlarini adashtiradi.","Shkala qadamini hisobga olmaydi (14 ni chiziqda qidiradi).","Yotiq qismni «tez harakat» deb o'ylaydi.","Qism tezligida boshlang'ich masofani ayirmaydi.","O'rtacha tezlikda to'xtash vaqtini tashlab yuboradi."],
 need:["Katakli daftar, chizg'ich, rangli qalam.","Bir haftalik harorat yozuvi.","Ob-havo ilovasidagi grafik (telefon)."],
 board:["Vaqt → , qiymat ↑.","Maksimum — cho'qqi, minimum — vodiy.","Tik — tez, yotiq — o'zgarmas.","Tezlik = Δmasofa : Δvaqt.","O'rtacha = jami : jami.","Kesishish — uchrashuv."]};
