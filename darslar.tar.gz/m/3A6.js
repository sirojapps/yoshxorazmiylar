var CODE='3A6',TITLE='3-sinf · Ko‘p xonali sonlar';
var P1=[function(){w3table(999,{min:4,top:'999'});msg('999 — eng katta uch xonali son. Unga 1 qo‘shamiz')},
 function(){w3table(999,{min:4,hl:[0],top:'999 + 1'});msg('Birliklar: 9 + 1 = 10 → 0, bitta o‘nlik oldinga')},
 function(){w3table(1000,{hl:[3],top:'1 000 — ming'});msg('Hamma xonalar «to‘ldi»: yangi xona — <b>ming</b> ochildi')}];
var P7=[function(){w3table(999999,{min:7,top:'999 999'});msg('Eng katta olti xonali son')},function(){w3table(1000000,{hl:[6],top:'1 000 000 — million'});msg('999 999 + 1 = <b>1 000 000</b> — bir million = 1000 ta ming')}];
var STEPS=[
{h:"Ming — yangi xona",sum:"999 + 1 = 1 000: to'rtinchi xona — minglar.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Uch xonali sonlar 999 da tugaydi. Unga 1 qo'shsak nima bo'ladi? Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>10 birlik = 1 o'nlik, 10 o'nlik = 1 yuzlik, <b>10 yuzlik = 1 ming</b>. Har safar 10 ta to'planganda — chapda yangi xona ochiladi. Shu qoida bilan son cheksiz davom etadi.</p>",
 q:{t:"1 000 da nechta yuzlik bor?",opts:["10","100","1","1 000"],ok:0,why:"1 000 = 10 · 100.",hint:"Nechta 100 qo'shsak 1 000 bo'ladi?",full:"100 · 10 = 1 000, demak 10 ta yuzlik. 100 — o'nliklar soni, 1 000 — birliklar soni."},
 tn:"10 ta yuzlik kvadratni ustma-ust qo'yib «ming kubi»ni yasash (Yapon bloklari)."},
{h:"Sinflar: uchtadan ajratib o'qiymiz",sum:"45 308: minglar sinfi — 45, birlar sinfi — 308: «qirq besh ming uch yuz sakkiz».",a:"m02",
 start:function(){S.rk=0;S.rb=0;w3table(45308,{min:6,top:'45 308'});msg('Son o‘ngdan chapga uchtadan sinflarga ajratiladi')},fin:function(){w3table(45308,{min:6,top:'45 308'});msg('<b>'+wbig(45308)+'</b>')},
 html:"<p>Katta sonlarni o'ngdan chapga <b>uchtadan</b> ajratamiz — bular <b>sinflar</b>. Har sinf uch xonali son kabi o'qiladi, keyin sinf nomi qo'shiladi. Ikkala sinfni o'qing:</p>",
 btns:[["Minglar sinfi",function(c,done){S.rk=1;w3table(45308,{min:6,hl:[3,4,5],top:'45 308'});msg('<b>qirq besh</b> ming…');if(S.rb)a6r(done)}],["Birlar sinfi",function(c,done){S.rb=1;w3table(45308,{min:6,hl:[0,1,2],top:'45 308'});msg('… <b>uch yuz sakkiz</b>');if(S.rk)a6r(done)},'u']],g2:1,
 after:"<p>Yozganda sinflar orasida <b>kichik bo'sh joy</b> qoldiramiz: 45 308, 1 250 000. Bu o'qishni osonlashtiradi. Birlar sinfi nomi aytilmaydi: «qirq besh ming uch yuz sakkiz».</p>",
 q:{t:"«Yuz ikki ming o'ttiz» qaysi son?",opts:["102 030","102 300","120 030","1 230"],ok:0,why:"Minglar: 102, birlar: 030.",hint:"Birlar sinfi «o'ttiz» — uch xonada qanday yoziladi?",full:"Minglar sinfi — 102. Birlar sinfi — o'ttiz = 030 (yuzliklar 0). Natija 102 030. «102 300» — 30 ni 300 deb yozish; «1 230» — nollarni tushirish."},
 tn:"Doskada sonni yozib, sinflarni yoy bilan ajratish. Bola avval qismlarga ajratadi, keyin o'qiydi."},
{h:"Nollar bilan yozish",sum:"«Yigirma ming besh» = 20 005: bo'sh xonalarga nol.",a:"m03",
 start:function(){w3table(0,{min:5,top:'yigirma ming besh = ?'});msg('Har bir sinf — uch xona')},fin:function(){w3table(20005,{top:'20 005'});msg('yigirma ming besh = <b>20 005</b>')},
 html:"<p>«<b>Yigirma ming besh</b>» sonini yozing. Tuzoq — nollarni yetarli yozmaslik:</p>",
 btns:w3choose(["2 005","20 005","20 500"],1,function(){w3table(20005,{top:'20 005'});msg('Minglar: 20, birlar: 005 — uch xona!')},function(i){msg(i===0?'2 005 — «ikki ming besh». Minglar sinfi 20 bo‘lishi kerak':'20 500 — «yigirma ming besh yuz»')}),g3:1,
 after:"<p>Qoida: birlar sinfi doim <b>uch xona</b>. «Besh» — 005, «qirq» — 040, «yuz» — 100. Shuning uchun 20 005 da birlar sinfida ikkita nol bor.</p>",
 q:{t:"«Uch yuz ming yetti» qaysi son?",opts:["300 007","3 007","300 700","30 007"],ok:0,why:"Minglar: 300, birlar: 007.",hint:"Birlar sinfiga 3 ta xona: 0, 0, 7.",full:"300 007. «3 007» — uch ming yetti; «300 700» — 7 ni yuzlik deb olish; «30 007» — minglarni noto'g'ri yozish."},
 tn:"Bo'sh jadval chizib, bolalar xonalarga raqamni yozsin — avval sinf, keyin raqam."},
{h:"Ko'p xonali sonlarni taqqoslash",sum:"Avval xonalar sonini solishtiramiz; teng bo'lsa — chapdan xonama-xona.",a:"m04",
 start:function(){w3table(45380,{top:'45 308  ?  45 380'});msg('Xonalar soni teng (5 ta). Chapdan solishtiramiz')},fin:function(){w3table(45380,{hl:[1],top:'45 308 < 45 380'});msg('O‘nliklar: 0 < 8')},
 html:"<p>45 308 va 45 380 ni taqqoslang. Minglar teng, yuzliklar teng… keyin? Belgini tanlang:</p>",
 btns:w3choose(["45 308 > 45 380","45 308 < 45 380","45 308 = 45 380"],1,function(){w3table(45380,{hl:[1],top:'45 308 < 45 380'});msg('O‘nliklar: <b>0 < 8</b> — birinchi farq shu yerda')},function(i){msg(i===0?'Oxirgi raqam 8 > 0 — lekin avval o‘nliklarni solishtirish kerak!':'Raqamlar bir xil, lekin tartibi boshqa')}),g3:1,
 after:"<p>Tartib: 1) <b>xonalar soni</b> — ko'p xonali son katta (9 999 &lt; 10 000); 2) teng bo'lsa — <b>chapdan</b> birinchi farq qilgan xona. Oxirgi raqamga qarash — xato.</p>",
 q:{t:"Qaysi son eng katta?",opts:["99 999","100 001","98 765","100 000"],ok:1,why:"100 001 — olti xonali va 100 000 dan 1 ta katta.",hint:"Avval xonalar sonini sanang.",full:"99 999 va 98 765 — besh xonali. 100 000 va 100 001 — olti xonali; ularning oxirgi xonasi farq qiladi: 100 001 katta."},
 tn:"Bank 4A1-turidagi savol. Ikki sonni jadvalda ustma-ust yozdirib, farq qilgan xonani doiraga oling."},
{h:"Ko'p xonali sonning xona qo'shiluvchilari",sum:"306 040 = 300 000 + 6 000 + 40.",a:"m05",
 start:function(){w3table(306040,{top:'306 040'});msg('Nol bo‘lmagan har bir raqam — bitta qo‘shiluvchi')},fin:function(){w3table(306040,{hl:[5,3,1],top:'300 000 + 6 000 + 40'});msg('306 040 = 300 000 + 6 000 + 40')},
 html:"<p>306 040 ni xona qo'shiluvchilariga ajrating. Nol turgan xonalar qo'shiluvchi bermaydi:</p>",
 btns:w3choose(["300 000 + 6 000 + 40","300 + 60 + 40","30 000 + 6 000 + 40"],0,function(){w3table(306040,{hl:[5,3,1],top:'300 000 + 6 000 + 40'});msg('3 — yuz minglar, 6 — minglar, 4 — o‘nliklar')},function(i){msg(i===1?'Bu raqamlar sinfini e‘tiborsiz qoldirish: 3 — yuz minglar xonasida!':'3 qaysi xonada? Jadvalga qarang')}),
 after:"<p>Har bir raqamni o'z xonasi qiymatiga aylantiramiz: 3 yuz ming = 300 000, 6 ming = 6 000, 4 o'nlik = 40. Teskarisi: 500 000 + 70 + 2 = <b>500 072</b>.</p>",
 q:{t:"80 000 + 300 + 5 = ?",opts:["80 305","8 305","80 350","83 005"],ok:0,why:"8 o'n ming, 3 yuzlik, 5 birlik: 80 305.",hint:"Minglar sinfi va birlar sinfini alohida yozing.",full:"Minglar sinfi: 80. Birlar sinfi: 300 + 5 = 305. Natija: 80 305. «8 305» — o'n mingni ming deb yozish; «83 005» — 300 ni 3 000 deb olish."},
 tn:"Raqam kartochkalarini ustma-ust qo'yish (Montessori) 6 xonagacha."},
{h:"Tuzoq: xonadagi raqam va jami minglar",sum:"45 308 da minglar raqami — 5, jami minglar — 45.",a:"m06",
 start:function(){w3table(45308,{top:'45 308'});msg('Bu sonda nechta ming bor?')},fin:function(){w3table(45308,{hl:[3,4],top:'jami 45 ta ming'});msg('Minglar xonasida 5, lekin jami <b>45</b> ta ming')},
 html:"<p>Ikki xil savol bor: «minglar xonasidagi raqam» va «sonda <b>jami nechta ming</b> bor». 45 308 da jami nechta to'liq ming bor?</p>",
 btns:w3choose(["5","45","453"],1,function(){w3table(45308,{hl:[3,4],top:'jami 45 ta ming'});msg('Minglar sinfi butunligicha: <b>45</b> ming')},function(i){msg(i===0?'5 — minglar xonasidagi raqam, o‘n minglar ham ming hisoblanadi!':'453 — bu jami yuzliklar soni')}),g3:1,
 after:"<p>Jami minglar — <b>minglar sinfidagi butun son</b>: 45. Jami yuzliklar — oxirgi ikki raqamni tashlab: <b>453</b>. Jami o'nliklar — oxirgi raqamni tashlab: <b>4 530</b>.</p>",
 q:{t:"72 615 da jami nechta yuzlik bor?",opts:["726","6","72","7 261"],ok:0,why:"Oxirgi ikki raqamni olib tashlaymiz: 726.",hint:"Yuzlikdan kichik xonalarni (o'nlik, birlik) tashlang.",full:"72 615 = 726 yuzlik va 15. Javob: 726. «6» — yuzliklar xonasidagi raqam; «72» — minglar soni; «7 261» — o'nliklar soni."},
 tn:"Bank 3A1/4A1-turi. 3A1 dagi «23 o'nlik» bilan bog'lang."},
{h:"Million",sum:"999 999 + 1 = 1 000 000: millionlar sinfi ochiladi.",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=1;P7[1]()},
 html:"<p>Minglar sinfi ham to'lsa — yangi, <b>millionlar sinfi</b> ochiladi. Kuzating:</p>",
 btns:[phaser(P7)],
 after:"<p>1 million = <b>1 000 ta ming</b> = 1 000 000 (6 ta nol). 2 500 000 — «ikki million besh yuz ming».</p>",
 q:{t:"1 000 000 da nechta ming bor?",opts:["1 000","100","10 000","10"],ok:0,why:"1 000 000 = 1 000 · 1 000.",hint:"Minglar sinfida qaysi son turibdi (nollar bilan)?",full:"1 000 000 : 1 000 = 1 000. 100 va 10 000 — nollarni noto'g'ri sanash."},
 tn:"Hayot: shahar aholisi, telefonlar soni — millionlar bilan o'lchanadi."},
{h:"Bilasizmi? Million qanchalik katta?",sum:"1 000 000 soniya — 11 kundan ko'proq.",a:"m08",
 start:function(){w3table(1000000,{top:'1 000 000 soniya'});msg('1 kunda 86 400 soniya')},fin:function(){w3table(1000000,{top:'1 000 000 soniya'});msg('1 000 000 soniya ≈ 11 kun 14 soat')},
 html:"<p>⏱ 1 kunda 24 · 60 · 60 = <b>86 400</b> soniya. Shuning uchun <b>1 million soniya</b> — taxminan <b>11,5 kun</b>! Agar «bir, ikki, uch…» deb millionga qadar to'xtovsiz sanasangiz, 11 kundan ko'proq kerak bo'ladi.</p><p>🔢 «Million» so'zi italyancha «katta ming» degan ma'noni bildiradi.</p>",
 tn:"Bolalar 1 000 ni kvadrat qog'ozda 10 × 100 katakcha qilib ko'rsin — millionga shunday 1 000 varaq kerak."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){w3table(45308,{top:'45 308'})},fin:function(){w3table(45308,{top:'45 308'})},
 html:"<div class='memo'><ul><li>10 yuzlik = 1 ming, 1 000 ming = 1 million.</li><li>O'ngdan uchtadan — <b>sinflar</b>: birlar, minglar, millionlar.</li><li>O'qish: 45 308 — «qirq besh ming uch yuz sakkiz».</li><li>Yozish: birlar sinfi doim uch xona — 20 005.</li><li>Taqqoslash: xonalar soni → chapdan birinchi farq.</li><li>Jami minglar — minglar sinfidagi son (45), xonadagi raqam emas (5).</li></ul></div>",
 tn:"Keyingi dars — pozitsion sanoq sistemasi."}
];
function a6r(done){w3table(45308,{min:6,top:'45 308'});msg('<b>'+wbig(45308)+'</b>');done()}
var PROBS=[
{t:"999 + 1 = ?",o:["1 000","9 991","100","10 000"],k:0,s:"Yangi xona — ming."},
{t:"45 308 qanday o'qiladi?",o:["qirq besh ming uch yuz sakkiz","to'rt yuz ellik uch ming sakkiz","qirq besh ming o'ttiz sakkiz","to'rt ming besh yuz o'ttiz sakkiz"],k:0,s:"Minglar 45, birlar 308."},
{t:"«Yigirma ming besh» qaysi son?",o:["20 005","2 005","20 500","20 050"],k:0,s:"Birlar sinfi 005."},
{t:"«Uch yuz ming yetti» qaysi son?",o:["300 007","3 007","300 700","30 007"],k:0,s:"Birlar sinfi 007."},
{t:"«Yuz ikki ming o'ttiz» qaysi son?",o:["102 030","102 300","120 030","1 230"],k:0,s:"Minglar 102, birlar 030."},
{t:"Qaysi yozuv to'g'ri?",o:["45 308 < 45 380","45 308 > 45 380","45 083 > 45 308","45 830 < 45 380"],k:0,s:"O'nliklar 0 < 8; qolganlari noto'g'ri."},
{t:"Qaysi son eng katta?",o:["100 001","99 999","100 000","98 765"],k:0,s:"Olti xonali va 100 000 dan katta."},
{t:"306 040 = ?",o:["300 000 + 6 000 + 40","300 + 60 + 40","30 000 + 6 000 + 40","300 000 + 600 + 40"],k:0,s:"3 yuz ming, 6 ming, 4 o'nlik."},
{t:"80 000 + 300 + 5 = ?",o:["80 305","8 305","80 350","83 005"],k:0,s:"Minglar 80, birlar 305."},
{t:"45 308 da jami nechta ming bor?",o:["45","5","453","4"],k:0,s:"Minglar sinfi — 45."},
{t:"72 615 da jami nechta yuzlik bor?",o:["726","6","72","7 261"],k:0,s:"Oxirgi 2 raqamni tashlaymiz."},
{t:"1 000 000 da nechta ming bor?",o:["1 000","100","10 000","10"],k:0,s:"1 000 · 1 000 = 1 000 000."},
{t:"Eng kichik besh xonali son:",o:["10 000","11 111","99 999","1 000"],k:0,s:"1 va to'rtta nol."},
{t:"Eng katta olti xonali son va eng kichik yetti xonali son ayirmasi:",o:["1","10","0","100"],k:0,s:"1 000 000 − 999 999 = 1."},
{t:"5 □ 47 > 5 847. □ o'rniga qaysi raqam qo'yilsa to'g'ri bo'ladi?",o:["9","8","7","0"],k:0,s:"8 bo'lsa 5 847 = 5 847 (katta emas); 9 bo'lsa 5 947 > 5 847."},
{t:"Qaysi sonda 6 raqami minglar xonasida turibdi?",o:["36 125","63 125","31 625","31 256"],k:0,s:"36 125: o'ngdan 4-xona — 6."},
{t:"2 500 000 qanday o'qiladi?",o:["ikki million besh yuz ming","ikki million ellik ming","yigirma besh million","ikki ming besh yuz"],k:0,s:"Millionlar 2, minglar 500."},
{t:"Qaysi yozuv to'g'ri?",o:["10 000 − 1 = 9 999","10 000 − 1 = 9 000","10 000 − 1 = 1 999","10 000 − 1 = 99 999"],k:0,s:"10 000 dan oldingi son 9 999."},
{t:"7, 0, 3, 9, 5 raqamlaridan (har biri bir marta) yasalgan eng kichik besh xonali son:",o:["30 579","03 579","35 079","30 975"],k:0,s:"Birinchi o'ringa 0 qo'yib bo'lmaydi: 3, keyin 0, 5, 7, 9."},
{t:"Sonda 4 ta ming, 2 ta yuzlik va 15 ta birlik bor. Bu qaysi son?",o:["4 215","42 150","4 205","42 015"],k:0,s:"4 000 + 200 + 15 = 4 215."}
];
function PRACT_STAGE(){w3table(45308,{top:'45 308'})}
var PREP_DATA={teach:["Ming va million — yangi xonalar va sinflar.","Ko'p xonali sonlarni sinflab o'qish va nollar bilan yozish.","Taqqoslash, xona qo'shiluvchilari, «jami minglar» va «minglar raqami» farqi."],mist:["«Yigirma ming besh» ni 2 005 deb yozadi.","Taqqoslashda oxirgi raqamga qaraydi.","306 040 ni 300 + 60 + 40 deb ajratadi.","Jami minglar o'rniga minglar xonasidagi raqamni aytadi."],need:["Xonalar jadvali (6–7 ustun), raqam kartochkalari."],board:["<span class='w2'>45 308 = 45 ming 308</span>.","<span class='w2'>20 005</span> — birlar sinfi uch xona.","<span class='w2'>45 308 < 45 380</span>.","<span class='w2'>306 040 = 300 000 + 6 000 + 40</span>.","<span class='w2'>1 000 000 = 1 000 ming</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
