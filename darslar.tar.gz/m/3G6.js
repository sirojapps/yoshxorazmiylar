
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G6',TITLE='3-sinf · Pul: narx, qaytim, tejash';
function g6f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var G6NC={'500':'#f3e1c4','1 000':'#e6d7f0','2 000':'#d6e9f7','5 000':'#f7d6d0','10 000':'#d8eecf','20 000':'#fde8b5','50 000':'#e8d9c6'};
function g6note(x,y,v){return f3note(x,y,g6f(v),G6NC[g6f(v)]||'#d8eecf')}
// daftar belgisi + narx yorlig'i
function g6item(x,y,lbl,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:30,height:38,rx:3,fill:col||'#9ec5ea',stroke:'#33475b','stroke-width':1.5},g);for(var i=0;i<4;i++)E('circle',{cx:x+4,cy:y+7+i*8,r:1.8,fill:'#33475b'},g);if(lbl)T(g,x+15,y+52,lbl,{'font-size':11,'font-weight':800,fill:'#1d2b3a'});return g}
// 1) narx · miqdor = qiymat
function g6p1(st){clear();var g=S.g;T(g,14,18,'3 ta daftar, har biri 2 500 so‘m',{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 for(var i=0;i<3;i++)g6item(40+i*44,34,'2 500');
 if(st>=1){var x0=190,w=150;for(var j=0;j<3;j++){E('rect',{x:x0+j*w/3,y:40,width:w/3,height:28,fill:'#ffe9c6',stroke:C.a,'stroke-width':1.5},g);T(g,x0+(j+.5)*w/3,59,'2 500',{'font-size':11,'font-weight':800,fill:'#7a4a12'})}
  Br(x0,x0+w,72,st>=2?'7 500':'?',false,C.ok)}
 if(st>=2){T(g,180,128,'narx · miqdor = qiymat',{'font-size':14,'font-weight':800,fill:C.blue});T(g,180,152,'2 500 · 3 = 7 500 so‘m',{'font-size':16,'font-weight':800,fill:C.ok})}}
var G6P1=[function(){g6p1(0);f3calc(['Bitta narsaning puli — <b>narx</b>, nechtaligi — <b>miqdor</b>'])},
 function(){g6p1(1);f3calc(['Chizma: 3 ta teng bo‘lak, har biri 2 500'])},
 function(){g6p1(2);f3calc(['Hammasining puli — <b>qiymat</b>: 2 500 · 3 = <b>7 500</b> so‘m','Teskari: qiymat : miqdor = narx; qiymat : narx = miqdor'])}];
// 2) to'lash va qaytim
var G6PRICE=13700,g6paid=[];
function g6pay(){clear();var g=S.g;T(g,14,18,'Xarid: 13 700 so‘m. Kupyura bering:',{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 var s=0;g6paid.forEach(function(v,i){g6note(16+(i%5)*68,34+Math.floor(i/5)*36,v);s+=v});
 T(g,180,128,'Berildi: '+g6f(s)+' so‘m',{'font-size':14,'font-weight':800,fill:s>=G6PRICE?C.ok:'#33475b'});
 if(s>=G6PRICE)T(g,180,156,'Qaytim: '+g6f(s)+' − 13 700 = '+g6f(s-G6PRICE)+' so‘m',{'font-size':13,'font-weight':800,fill:C.a});return s}
function g6btn(v){return [g6f(v),function(c,done){if(g6paid.length&&g6paid.reduce(function(a,b){return a+b},0)>=G6PRICE)return;g6paid.push(v);var s=g6pay();
 if(s>=G6PRICE){f3calc(['Yetarli! Qaytim = berilgan − narx','= '+g6f(s)+' − 13 700 = <b>'+g6f(s-G6PRICE)+'</b> so‘m']);done()}else f3calc(['Hali '+g6f(G6PRICE-s)+' so‘m yetmaydi'])}]}
// 3) qaytimni to'ldirib sanash
function g6line(st){clear();var g=S.g,X=function(v){return {13700:40,14000:105,15000:180,20000:330}[v]};E('line',{x1:20,y1:110,x2:340,y2:110,stroke:'#33475b','stroke-width':2.5},g);
 [[13700,'13 700'],[14000,'14 000'],[15000,'15 000'],[20000,'20 000']].forEach(function(p,i){if(i>st)return;E('line',{x1:X(p[0]),y1:104,x2:X(p[0]),y2:116,stroke:'#33475b','stroke-width':2},g);T(g,X(p[0]),132,p[1],{'font-size':11,'font-weight':800,fill:'#1d2b3a'})});
 var J=[[13700,14000,'+300'],[14000,15000,'+1 000'],[15000,20000,'+5 000']];J.forEach(function(j,i){if(i>=st)return;var a=X(j[0]),b=X(j[1]),h=i===2?56:34;E('path',{d:'M'+a+' 104 Q'+(a+b)/2+' '+(104-h)+' '+b+' 104',fill:'none',stroke:C.a,'stroke-width':2.2},g);T(g,(a+b)/2,104-h/2-6,j[2],{'font-size':12,'font-weight':800,fill:C.a})});
 T(g,14,18,'Sotuvchi usuli: narxdan berilgan pulgacha «to‘ldirib» sanaymiz',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 if(st>=3)T(g,180,162,'300 + 1 000 + 5 000 = 6 300 so‘m',{'font-size':15,'font-weight':800,fill:C.ok})}
var G6P3=[function(){g6line(0);f3calc(['Narx 13 700, berildi 20 000. Qaytim?'])},function(){g6line(1);f3calc(['13 700 → <b>14 000</b>: +300 (yaxlit mingga)'])},function(){g6line(2);f3calc(['14 000 → <b>15 000</b>: +1 000'])},function(){g6line(3);f3calc(['15 000 → 20 000: +5 000. Qaytim: <b>6 300</b> so‘m','Tekshirish: 13 700 + 6 300 = 20 000 ✓'])}];
// tanlov tugmalari
function g6pick(okI,msgs,fin){return msgs.map(function(m,i){return [m[0],function(c,done){if(i===okI){fin();f3msg('✓ '+m[1]);done()}else f3msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// 4) yetadimi?
function g6budget(st){clear();var g=S.g,k=0.011,x0=70;T(g,14,18,'Lolada 25 000 so‘m. 4 ta daftar (3 500 dan) va kitob (12 000)',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 T(g,62,52,'pul',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:C.ok});E('rect',{x:x0,y:38,width:25000*k,height:24,fill:'#cfeccf',stroke:C.ok,rx:3},g);T(g,x0+25000*k/2,55,'25 000',{'font-size':11,'font-weight':800,fill:'#2f5a22'});
 T(g,62,96,'xarid',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:C.a});for(var i=0;i<4;i++)E('rect',{x:x0+i*3500*k,y:82,width:3500*k,height:24,fill:'#ffe9c6',stroke:C.a},g);E('rect',{x:x0+14000*k,y:82,width:12000*k,height:24,fill:'#d6e9f7',stroke:C.blue},g);
 T(g,x0+7000*k,99,'14 000',{'font-size':10,'font-weight':800,fill:'#7a4a12'});T(g,x0+20000*k,99,'12 000',{'font-size':10,'font-weight':800,fill:'#1d4a7a'});
 if(st){E('line',{x1:x0+25000*k,y1:30,x2:x0+25000*k,y2:116,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);Br(x0+25000*k,x0+26000*k,112,'',false,C.bad);T(g,180,150,'26 000 > 25 000 — 1 000 so‘m yetmaydi',{'font-size':13,'font-weight':800,fill:C.bad})}}
// 5) tejash
function g6save(st){clear();var g=S.g,k=0.017,x0=26;T(g,14,18,'O‘yinchoq 18 000. Bor: 4 000. Har kuni +2 500',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 E('rect',{x:x0,y:50,width:18000*k,height:30,fill:'#fff',stroke:'#33475b','stroke-width':2},g);Br(x0,x0+18000*k,46,'18 000',true);
 E('rect',{x:x0,y:50,width:4000*k,height:30,fill:'#cfeccf',stroke:C.ok},g);T(g,x0+2000*k,69,'4 000',{'font-size':10,'font-weight':800,fill:'#2f5a22'});
 if(st>=1)Br(x0+4000*k,x0+18000*k,84,'kerak: 14 000',false,C.a);
 if(st>=2){var n=st>=3?6:5;for(var i=0;i<n;i++){var a=x0+(4000+i*2500)*k,w=Math.min(2500,18000+3000-4000-i*2500)*k;E('rect',{x:a,y:120,width:2500*k,height:22,fill:i<5?'#ffe9c6':'#ffd6a0',stroke:C.a},g);T(g,a+1250*k,135,(i+1)+'-k',{'font-size':10,'font-weight':800,fill:'#7a4a12'})}
  E('line',{x1:x0+18000*k,y1:44,x2:x0+18000*k,y2:148,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
  T(g,180,166,st>=3?'6 kunda: 4 000 + 15 000 = 19 000 ≥ 18 000 ✓':'5 kunda: 4 000 + 12 500 = 16 500 — hali kam',{'font-size':12,'font-weight':800,fill:st>=3?C.ok:C.bad})}}
var G6P5=[function(){g6save(0);f3calc(['Necha kunda yetadi? Bor pulni unutmang!'])},function(){g6save(1);f3calc(['Yetishmaydi: 18 000 − 4 000 = <b>14 000</b>'])},function(){g6save(2);f3calc(['14 000 : 2 500 = 5, qoldiq 1 500 — 5 kun yetmaydi'])},function(){g6save(3);f3calc(['Demak, <b>6 kun</b> kerak (qoldiq bo‘lsa — yana 1 kun)','Xato: 18 000 : 2 500 → «7 kun» (bor 4 000 unutilgan)'])}];
// 6) qaysi biri arzon?
function g6pack(st){clear();var g=S.g;T(g,14,18,'Qaysi qadoqda bitta tuxum arzon?',{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 function pack(x,n,price,lbl){E('rect',{x:x,y:34,width:150,height:70,rx:8,fill:'#fbf3e6',stroke:'#b08a5a','stroke-width':2},g);for(var i=0;i<n;i++)E('ellipse',{cx:x+16+(i%5)*29,cy:52+Math.floor(i/5)*28,rx:10,ry:12,fill:'#fff',stroke:'#b08a5a'},g);T(g,x+75,122,n+' ta — '+price,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});if(st)T(g,x+75,146,lbl,{'font-size':13,'font-weight':800,fill:C.a})}
 pack(16,6,'9 000',st?'9 000 : 6 = 1 500':'');pack(194,10,'14 000',st?'14 000 : 10 = 1 400':'');if(st)T(g,180,168,'Katta qadoqda bittasi 100 so‘m arzon',{'font-size':12,'font-weight':800,fill:C.ok})}
// 7) aksiya
function g6promo(st){clear();var g=S.g;T(g,14,18,'Aksiya: «3 ta olsangiz — 4-si tekin». 1 ta = 3 000. Kerak: 10 ta',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 for(var i=0;i<10;i++){var grp=Math.floor(i/4),x=20+i*32+grp*10,free=st>=1&&i%4===3;E('path',{d:'M'+(x+4)+' 60 L'+(x+24)+' 60 L'+(x+14)+' 92 Z',fill:'#e8c48a',stroke:'#8a6a3a'},g);E('circle',{cx:x+14,cy:52,r:11,fill:free?'#cfeccf':'#f7c6d9',stroke:free?C.ok:'#c0587e','stroke-width':free?2.5:1},g);if(free)T(g,x+14,112,'tekin',{'font-size':10,'font-weight':800,fill:C.ok})}
 if(st>=1){[0,1,2].forEach(function(j){var a=20+j*(4*32+10),b=a+(j<2?4:2)*32-6;E('rect',{x:a-3,y:36,width:b-a+6,height:62,rx:6,fill:'none',stroke:C.blue,'stroke-dasharray':'4 3'},g)})}
 if(st>=2)T(g,180,140,'Pulli: 3 + 3 + 2 = 8 ta',{'font-size':14,'font-weight':800,fill:C.a});if(st>=3)T(g,180,164,'8 · 3 000 = 24 000 so‘m',{'font-size':15,'font-weight':800,fill:C.ok})}
var G6P7=[function(){g6promo(0);f3calc(['10 tasiga 30 000 to‘laymizmi? Shoshmang!'])},function(){g6promo(1);f3calc(['4 tadan guruhlaymiz: har guruhda 1 tasi tekin'])},function(){g6promo(2);f3calc(['10 = 4 + 4 + 2. Oxirgi 2 tasi to‘liq guruh emas — tekini yo‘q'])},function(){g6promo(3);f3calc(['To‘lov: 8 · 3 000 = <b>24 000</b> so‘m','Xato: «10 tadan 3 tasi tekin» deb 21 000 yozish'])}];
// 8) teskari masala
function g6rev(st){clear();var g=S.g,k=0.0145,x0=36;T(g,14,18,'20 000 berdi, 3 ta bir xil kitob oldi, qaytim 4 400',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 E('rect',{x:x0,y:44,width:20000*k,height:28,fill:'#cfeccf',stroke:C.ok,rx:3},g);T(g,x0+10000*k,63,'20 000 (berildi)',{'font-size':11,'font-weight':800,fill:'#2f5a22'});
 for(var i=0;i<3;i++){E('rect',{x:x0+i*5200*k,y:90,width:5200*k,height:28,fill:'#d6e9f7',stroke:C.blue},g);T(g,x0+(i+.5)*5200*k,109,st>=2?'5 200':'?',{'font-size':11,'font-weight':800,fill:'#1d4a7a'})}
 E('rect',{x:x0+15600*k,y:90,width:4400*k,height:28,fill:'#ffe9c6',stroke:C.a},g);T(g,x0+17800*k,109,'4 400',{'font-size':11,'font-weight':800,fill:'#7a4a12'});
 if(st>=1)Br(x0,x0+15600*k,122,'kitoblar: 15 600',false,C.blue);if(st>=2)T(g,180,166,'15 600 : 3 = 5 200 so‘m',{'font-size':15,'font-weight':800,fill:C.ok})}
var G6P8=[function(){g6rev(0);f3calc(['Berilgan pul = kitoblar puli + qaytim'])},function(){g6rev(1);f3calc(['Kitoblar: 20 000 − 4 400 = <b>15 600</b>'])},function(){g6rev(2);f3calc(['Bittasi: 15 600 : 3 = <b>5 200</b> so‘m','Tekshirish: 5 200 · 3 + 4 400 = 20 000 ✓'])}];
// Bilasizmi
function g6hist(st){clear();var g=S.g;T(g,180,22,'Pul tarixi',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});
 var P=[[60,'tanga','~2 700 yil oldin','Lidiya'],[180,'qog‘oz pul','~1 000 yil oldin','Xitoy'],[300,'so‘m','1994-yil 1-iyul','O‘zbekiston']];
 E('line',{x1:30,y1:90,x2:330,y2:90,stroke:'#33475b','stroke-width':2.5},g);
 P.forEach(function(p,i){if(i>st)return;E('circle',{cx:p[0],cy:90,r:8,fill:[C.a,C.blue,C.ok][i]},g);T(g,p[0],62,p[1],{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,p[0],116,p[2],{'font-size':11,'font-weight':700,fill:'#3a4a5a'});T(g,p[0],134,p[3],{'font-size':11,fill:'#3a4a5a'})})}
var G6P9=[function(){g6hist(0);f3calc(['Eng qadimgi tangalar — Lidiyada (hozirgi Turkiya hududi)'])},function(){g6hist(1);f3calc(['Qog‘oz pul birinchi bo‘lib Xitoyda paydo bo‘lgan'])},function(){g6hist(2);f3calc(['O‘zbekiston so‘mi 1994-yil 1-iyuldan muomalada'])}];
function PRACT_STAGE(){clear();var g=S.g;[500,1000,2000,5000,10000].forEach(function(v,i){g6note(16+i*68,40,v)});T(g,180,120,'narx · miqdor = qiymat',{'font-size':14,'font-weight':800,fill:C.blue});T(g,180,146,'qaytim = berilgan − narx',{'font-size':14,'font-weight':800,fill:C.a})}
var STEPS=[
{h:"Narx, miqdor, qiymat",sum:"Narx — bittasining puli, miqdor — nechtaligi, qiymat — hammasining puli: 2 500 · 3 = 7 500.",a:"m01",
 start:function(){startPh(G6P1)},fin:function(){S.ph=2;G6P1[2]()},
 html:"<p>Do'konda uchta so'z ko'p ishlatiladi: <b>narx</b> (bittasi necha so'm), <b>miqdor</b> (nechta), <b>qiymat</b> (hammasi necha so'm). Bosib ko'ring:</p>",btns:[phaser(G6P1)],
 after:"<p><b>qiymat = narx · miqdor</b>. Undan ikki teskari qoida: <b>narx = qiymat : miqdor</b>, <b>miqdor = qiymat : narx</b>. Uchtasidan ikkitasi ma'lum bo'lsa — uchinchisini topamiz.</p>",
 q:{t:"4 ta bir xil ruchka 9 600 so'm. Bitta ruchka necha so'm?",opts:["2 400 so'm","38 400 so'm","2 600 so'm","5 600 so'm"],ok:0,why:"9 600 : 4 = 2 400.",hint:"Qiymat va miqdor ma'lum. Narx = qiymat : miqdor.",full:"9 600 : 4 = 2 400 so'm (tekshirish: 2 400 · 4 = 9 600). «38 400» — bo'lish o'rniga ko'paytirish, «5 600» — 4 000 ni ayirish (9 600 − 4 000)."},
 tn:"Singapur usuli: narx–miqdor–qiymat jadvalini doskaga chizing (3 ustun). Har masalada bola avval jadvalni to'ldiradi, keyin «?» ni topadi."},
{h:"To'lov va qaytim",sum:"Qaytim = berilgan pul − narx. Kupyuralar narxdan oshguncha beriladi.",a:"m02",
 start:function(){g6paid=[];g6pay();f3calc(['Kupyurani bosing — to‘lov narxdan kam bo‘lmasin'])},fin:function(){g6paid=[10000,5000];g6pay();f3msg('15 000 − 13 700 = <b>1 300</b> so‘m qaytim')},
 html:"<p>Siz kassadasiz: xarid <b>13 700 so'm</b>. Hamyondan kupyura bering (bir necha marta bosish mumkin). Pul yetganda qaytim hisoblanadi:</p>",
 btns:[g6btn(10000),g6btn(5000),g6btn(1000),g6btn(500)],g2:1,
 after:"<p><b>Qaytim = berilgan − narx</b>. Berilgan pul narxdan kam bo'lsa — xarid bo'lmaydi. Ko'p kupyura berish shart emas: 20 000 ham, 15 000 ham bo'ladi — faqat qaytim har xil.</p>",
 q:{t:"Non 4 500 so'm. 3 ta non olib, 20 000 so'm berdi. Qaytim?",opts:["6 500 so'm","15 500 so'm","7 500 so'm","33 500 so'm"],ok:0,why:"4 500 · 3 = 13 500; 20 000 − 13 500 = 6 500.",hint:"Avval 3 ta nonning qiymatini toping.",full:"Qiymat: 4 500 · 3 = 13 500. Qaytim: 20 000 − 13 500 = 6 500 so'm. «15 500» — faqat bitta nonni ayirish (20 000 − 4 500), «33 500» — ayirish o'rniga qo'shish."},
 tn:"Sinfda «do'kon» o'yini: qog'oz kupyuralar (500, 1 000, 5 000, 10 000) va narx yorliqlari. Bir bola sotuvchi, biri xaridor."},
{h:"Qaytimni to'ldirib sanash",sum:"13 700 → 14 000 → 15 000 → 20 000: 300 + 1 000 + 5 000 = 6 300.",a:"m03",
 start:function(){startPh(G6P3)},fin:function(){S.ph=3;G6P3[3]()},
 html:"<p>Sotuvchilar qaytimni ayirmasdan, <b>narxdan berilgan pulgacha to'ldirib</b> sanaydi. Son o'qida ko'ring:</p>",btns:[phaser(G6P3)],
 after:"<p>Bu — ayirishning qulay usuli (Gollandiya maktablarida «sakrash» deyiladi): avval yaxlit mingga, keyin yaxlit o'n mingga sakraymiz. Nollardan qarz olib ayirishdan ko'ra xato kam bo'ladi.</p>",
 q:{t:"Xarid 7 650 so'm, 10 000 so'm berildi. Qaytim?",opts:["2 350 so'm","3 350 so'm","2 450 so'm","3 450 so'm"],ok:0,why:"7 650 → 8 000 (+350) → 10 000 (+2 000): 2 350.",hint:"7 650 dan 8 000 gacha qancha? 8 000 dan 10 000 gacha-chi?",full:"7 650 + 350 = 8 000; 8 000 + 2 000 = 10 000. Qaytim: 350 + 2 000 = 2 350 so'm. «3 350» — 1 000 ni ortiqcha sanash (nollardan qarzda adashish), «2 450» — 350 o'rniga 450."},
 tn:"Doskada bo'sh son o'qini chizing; bolalar «sakrash»larni yoy bilan belgilaydi. Bir nechta narx bilan takrorlang."},
{h:"Pul yetadimi?",sum:"14 000 + 12 000 = 26 000 > 25 000 — 1 000 so'm yetmaydi.",a:"m04",
 start:function(){g6budget(0);f3calc(['Avval xaridning hammasini hisoblang, keyin taqqoslang'])},fin:function(){g6budget(1);f3msg('Yetmaydi: <b>1 000 so‘m</b> kam')},
 html:"<p><i>«Lolada 25 000 so'm bor. U 3 500 so'mdan 4 ta daftar va 12 000 so'mlik kitob olmoqchi. Puli yetadimi?»</i> Javobni tanlang:</p>",
 btns:g6pick(1,[["Yetadi, 9 500 qoladi","Bu — faqat 1 ta daftar hisoblangan: 25 000 − 3 500 − 12 000. Daftar 4 ta!"],["Yetmaydi, 1 000 kam","4 · 3 500 = 14 000; 14 000 + 12 000 = 26 000 > 25 000."],["Yetadi, 1 000 qoladi","Taqqoslashda adashdingiz: 26 000 — 25 000 dan katta."],["Yetmaydi, 11 000 kam","25 000 − 14 000 = 11 000 — bu daftardan keyin qolgan pul, kamomad emas."]],function(){g6budget(1)}),g2:1,
 after:"<p>Ikki qadam: 1) xaridning <b>umumiy qiymati</b>; 2) uni bor pul bilan <b>taqqoslash</b>. Kam bo'lsa — kamomad = qiymat − pul.</p>",
 q:{t:"Onada 100 000 so'm. 3 kg go'sht oldi, kilosi 32 000 so'm. Puli yetadimi?",opts:["Yetadi, 4 000 so'm qoladi","Yetmaydi, 4 000 so'm kam","Yetadi, 6 000 so'm qoladi","Yetadi, 68 000 so'm qoladi"],ok:0,why:"32 000 · 3 = 96 000 < 100 000; 100 000 − 96 000 = 4 000.",hint:"Avval 3 kg ning narxini toping.",full:"32 000 · 3 = 96 000 so'm. 96 000 < 100 000 — yetadi, 4 000 so'm qoladi. «68 000» — faqat 1 kg ni ayirish."},
 tn:"Bolalarga reklama varaqasidan «ro'yxat» bering: 20 000 so'mga nimalar sig'adi? Har bola o'z savatini tuzib, hisoblab beradi."},
{h:"Tejash: necha kunda yig'iladi?",sum:"18 000 − 4 000 = 14 000; 14 000 : 2 500 = 5 (qoldiq 1 500) → 6 kun.",a:"m05",
 start:function(){startPh(G6P5)},fin:function(){S.ph=3;G6P5[3]()},
 html:"<p><i>«O'yinchoq 18 000 so'm. Anvarda 4 000 so'm bor. U har kuni 2 500 so'mdan yig'adi. Kamida necha kunda o'yinchoqqa yetadi?»</i></p>",btns:[phaser(G6P5)],
 after:"<p>Ikki tuzoq: 1) bor pulni ayirishni unutish; 2) qoldiqli bo'lishda kunni yaxlitlamaslik. «5 kun-u yana ozgina» bo'lsa ham — <b>6-kun</b> kerak bo'ladi.</p>",
 q:{t:"Kitob 15 000 so'm. Lolada 4 000 so'm bor, har kuni 3 000 so'm yig'adi. Kamida necha kunda kitobga yetadi?",opts:["4 kun","3 kun","5 kun","2 kun"],ok:0,why:"11 000 : 3 000 = 3 (qoldiq 2 000) → 4 kun.",hint:"Avval qancha pul yetishmasligini toping.",full:"15 000 − 4 000 = 11 000. 3 kunda 9 000 — yetmaydi, 4 kunda 12 000 — yetadi. Javob 4 kun. «3 kun» — qoldiqni tashlab yuborish, «5 kun» — bor 4 000 ni unutish (15 000 : 3 000)."},
 tn:"Hayotiy bog'lanish: sinfda «tejash jadvali» — har kuni qancha yig'ildi, maqsadgacha qancha qoldi. Moliyaviy savodxonlikning birinchi qadami."},
{h:"Qaysi biri arzon?",sum:"9 000 : 6 = 1 500; 14 000 : 10 = 1 400 — katta qadoq arzon.",a:"m06",
 start:function(){g6pack(0);f3calc(['Qadoq narxi emas — <b>bittasining</b> narxi muhim'])},fin:function(){g6pack(1);f3msg('Katta qadoq: bittasi <b>1 400</b> so‘m')},
 html:"<p>Kichik qadoqda 6 ta tuxum — 9 000 so'm, katta qadoqda 10 ta — 14 000 so'm. Qaysi birida <b>bitta</b> tuxum arzon?</p>",
 btns:g6pick(2,[["Kichik: 9 000 < 14 000","Qadoqlarda tuxum soni har xil! Bittasining narxini taqqoslash kerak."],["Ikkalasi bir xil","9 000 : 6 = 1 500, 14 000 : 10 = 1 400 — bir xil emas."],["Katta: bittasi 1 400","9 000 : 6 = 1 500 > 14 000 : 10 = 1 400."],["Kichik: bittasi 1 400","Hisobni tekshiring: 9 000 : 6 = 1 500."]],function(){g6pack(1)}),g2:1,
 after:"<p>Taqqoslash uchun <b>bir xil miqdorga</b> keltiramiz (bitta, 1 kg, 1 l). Do'konlarda narx yorlig'ida ko'pincha «1 kg narxi» ham yoziladi — aynan shu sababli.</p>",
 q:{t:"Guruch: 3 kg lik qop 24 000 so'm, 5 kg lik qop 38 000 so'm. Qaysi qopda 1 kg arzon va qanchaga?",opts:["5 kg likda, 400 so'm arzon","3 kg likda, chunki 24 000 < 38 000","5 kg likda, 14 000 so'm arzon","3 kg likda, 400 so'm arzon"],ok:0,why:"24 000 : 3 = 8 000; 38 000 : 5 = 7 600; farq 400.",hint:"Har qopda 1 kg necha so'm?",full:"3 kg: 24 000 : 3 = 8 000; 5 kg: 38 000 : 5 = 7 600. 5 kg lik qopda 1 kg 400 so'm arzon. «14 000» — qoplar narxining farqi, u miqdorni hisobga olmaydi."},
 tn:"Haqiqiy chek yoki narx yorliqlarini olib keling. Bolalar «1 dona narxi»ni hisoblab, eng foydalisini tanlaydi."},
{h:"Tuzoq: aksiya",sum:"«3 ta olsangiz — 4-si tekin», 10 ta kerak: 4 + 4 + 2 → pulli 8 ta → 24 000.",a:"m07",
 start:function(){startPh(G6P7)},fin:function(){S.ph=3;G6P7[3]()},
 html:"<p><i>«Muzqaymoq 3 000 so'm. Aksiya: 3 ta olsangiz, 4-si tekin. 10 ta muzqaymoq necha so'm turadi?»</i></p>",btns:[phaser(G6P7)],
 after:"<p>Aksiyada narsalarni <b>guruhlaymiz</b>: guruhda nechta pulli, nechta tekin. To'liq bo'lmagan oxirgi guruhda tekin yo'q.</p>",
 q:{t:"Sharbat 5 000 so'm. Aksiya: 2 ta olsangiz, 3-si tekin. 7 ta sharbat necha so'm?",opts:["25 000 so'm","35 000 so'm","30 000 so'm","20 000 so'm"],ok:0,why:"7 = 3 + 3 + 1 → pulli 2 + 2 + 1 = 5; 5 · 5 000 = 25 000.",hint:"3 tadan guruhlang: har guruhda nechtasi pulli?",full:"Guruhlar: 3 + 3 + 1. Pulli: 2 + 2 + 1 = 5 ta. 5 · 5 000 = 25 000 so'm. «35 000» — aksiyani unutish, «30 000» — faqat 1 ta tekin deb olish, «20 000» — oxirgi 1 tasini ham tekin deb olish."},
 tn:"Bank misoli turi (#1418). Doskada narsalarni doiracha bilan chizib, guruhlarni o'rab chiqing."},
{h:"Tuzoq: qaytimdan narxni topish",sum:"20 000 − 4 400 = 15 600; 15 600 : 3 = 5 200.",a:"m08",
 start:function(){startPh(G6P8)},fin:function(){S.ph=2;G6P8[2]()},
 html:"<p><i>«Dilshod 20 000 so'm berib, 3 ta bir xil kitob oldi va 4 400 so'm qaytim oldi. Bitta kitob necha so'm?»</i> Teskari masala — chizma yordam beradi:</p>",btns:[phaser(G6P8)],
 after:"<p>Chizmada ko'rinadi: berilgan pul = kitoblar + qaytim. Avval qaytimni <b>ayiramiz</b>, keyin <b>bo'lamiz</b>. Ko'p bola 20 000 ni darhol 3 ga bo'lib yuboradi — chiqmaydi.</p>",
 q:{t:"Sardor 20 000 so'm berib, 2 ta bir xil to'p oldi. Qaytim 2 000 so'm. Bitta to'p necha so'm?",opts:["9 000 so'm","11 000 so'm","10 000 so'm","1 000 so'm"],ok:0,why:"(20 000 − 2 000) : 2 = 9 000.",hint:"Avval to'plarga qancha pul ketganini toping.",full:"To'plar: 20 000 − 2 000 = 18 000; bittasi 18 000 : 2 = 9 000 so'm. «11 000» — qaytimni qo'shib bo'lish, «10 000» — qaytimni unutish, «1 000» — qaytimni bo'lish."},
 tn:"Bar modelni (Singapur) bola o'zi chizsin: uzun tasma — berilgan pul, ichida teng bo'laklar va qaytim."},
{h:"Bilasizmi? Pul tarixi",sum:"Tangalar ~2 700 yil oldin Lidiyada, qog'oz pul ~1 000 yil oldin Xitoyda paydo bo'lgan; so'm — 1994-yildan.",a:"m09",
 start:function(){startPh(G6P9)},fin:function(){S.ph=2;G6P9[2]()},
 html:"<p>Pul bo'lmagan davrda odamlar narsani narsaga almashgan (barter). Bosib, pul tarixi bilan tanishing:</p>",btns:[phaser(G6P9)],
 after:"<p>🪙 Eng qadimgi tangalar taxminan <b>2 700 yil oldin</b> Lidiya podsholigida zarb qilingan. 💵 Qog'oz pul birinchi bo'lib <b>Xitoyda</b>, taxminan 1 000 yil oldin paydo bo'lgan. 🇺🇿 O'zbekistonning milliy puli — <b>so'm</b> — 1994-yil 1-iyuldan muomalada.</p>",
 tn:"Bolalardan so'rang: pul bo'lmasa, non sotib olish uchun nima qilardik? Barter o'yini: bir olma = necha qalam?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>qiymat = narx · miqdor</b>; narx = qiymat : miqdor; miqdor = qiymat : narx.</li><li><b>qaytim = berilgan − qiymat</b>. Qulay usul: narxdan yaxlit songa «to'ldirib» sanash.</li><li>Pul yetadimi: avval hammasini hisoblang, keyin taqqoslang.</li><li>Tejash: avval bor pulni ayiring; qoldiq bo'lsa — yana 1 kun.</li><li>Arzonini topish: <b>bittasining</b> (1 kg ning) narxini taqqoslang.</li><li>Aksiya: guruhlang — har guruhda nechtasi tekin.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring; uyga vazifa — oiladagi bir xarid chekini hisoblab kelish."}
];
var PROBS=[
{t:"Daftar 2 600 so'm. 4 ta daftar necha so'm?",o:["10 400 so'm","8 400 so'm","2 604 so'm","10 600 so'm"],k:0,s:"2 600 · 4 = 10 400."},
{t:"5 ta bir xil ruchka 7 500 so'm. Bitta ruchka necha so'm?",o:["1 500 so'm","37 500 so'm","2 500 so'm","1 250 so'm"],k:0,s:"7 500 : 5 = 1 500."},
{t:"Non 4 000 so'm. 3 ta non olib, 20 000 so'm berdi. Qaytim?",o:["8 000 so'm","16 000 so'm","12 000 so'm","7 000 so'm"],k:0,s:"20 000 − 12 000 = 8 000."},
{t:"Xarid 6 350 so'm, 10 000 so'm berildi. Qaytim?",o:["3 650 so'm","4 650 so'm","3 750 so'm","4 750 so'm"],k:0,s:"6 350 → 7 000 (+650) → 10 000 (+3 000)."},
{t:"Olmaning kilosi 12 000, nokning kilosi 15 000 so'm. 3 kg olma va 2 kg nok necha so'm?",o:["66 000 so'm","27 000 so'm","69 000 so'm","135 000 so'm"],k:0,s:"36 000 + 30 000 = 66 000."},
{t:"Xarid 13 700 so'm, 50 000 so'm berildi. Qaytim?",o:["36 300 so'm","37 300 so'm","36 400 so'm","47 300 so'm"],k:0,s:"50 000 − 13 700 = 36 300."},
{t:"Shakarning kilosi 14 000 so'm. 2 kg 500 g shakar necha so'm?",o:["35 000 so'm","28 500 so'm","28 000 so'm","42 000 so'm"],k:0,s:"28 000 + 7 000 (yarim kg) = 35 000."},
{t:"Lolada 25 000 so'm. 3 500 so'mdan 4 ta daftar va 12 000 so'mlik kitob olmoqchi. Puli yetadimi?",o:["Yetmaydi, 1 000 so'm kam","Yetadi, 1 000 so'm qoladi","Yetadi, 9 500 so'm qoladi","Yetmaydi, 11 000 so'm kam"],k:0,s:"14 000 + 12 000 = 26 000 > 25 000."},
{t:"Muzqaymoq 2 300 so'm. Javohirda 15 000 so'm. Eng ko'pi bilan nechta oladi va qancha qoladi?",o:["6 ta, 1 200 so'm qoladi","7 ta, 900 so'm qoladi","6 ta, 2 300 so'm qoladi","5 ta, 3 500 so'm qoladi"],k:0,s:"2 300 · 6 = 13 800; 7 tasi 16 100 — yetmaydi."},
{t:"6 ta tuxum 9 600 so'm, 10 ta tuxum 15 000 so'm. Qaysi qadoqda bitta tuxum arzon va qanchaga?",o:["10 talikda, 100 so'm arzon","6 talikda, 5 400 so'm arzon","10 talikda, 5 400 so'm arzon","6 talikda, 100 so'm arzon"],k:0,s:"1 600 va 1 500."},
{t:"O'yinchoq 24 000 so'm. Anvarda 6 000 so'm bor, har kuni 4 000 so'm yig'adi. Kamida necha kunda yetadi?",o:["5 kun","4 kun","6 kun","7 kun"],k:0,s:"18 000 : 4 000 = 4 (qoldiq 2 000) → 5 kun."},
{t:"10 000 so'm berib, 4 ta bir xil daftar oldi. Qaytim 1 600 so'm. Bitta daftar necha so'm?",o:["2 100 so'm","2 900 so'm","2 500 so'm","400 so'm"],k:0,s:"8 400 : 4 = 2 100."},
{t:"50 000 so'm berib, 4 ta bir xil kitob oldi. Qaytim 2 000 so'm. Bitta kitob necha so'm?",o:["12 000 so'm","12 500 so'm","13 000 so'm","500 so'm"],k:0,s:"48 000 : 4 = 12 000."},
{t:"Bulochka 2 500 so'm. Aksiya: 3 ta olsangiz, 4-si tekin. 8 ta bulochka necha so'm?",o:["15 000 so'm","20 000 so'm","17 500 so'm","10 000 so'm"],k:0,s:"2 guruh: pulli 3 + 3 = 6; 6 · 2 500."},
{t:"Sharbat 5 000 so'm. Aksiya: 2 ta olsangiz, 3-si tekin. 7 ta sharbat necha so'm?",o:["25 000 so'm","35 000 so'm","30 000 so'm","20 000 so'm"],k:0,s:"3 + 3 + 1 → pulli 5 ta."},
{t:"Ali kuniga 3 000, Vali kuniga 5 000 so'm yig'adi. Ikkalasi birga necha kunda 40 000 so'm yig'adi?",o:["5 kun","8 kun","13 kun","4 kun"],k:0,s:"Kuniga 8 000; 40 000 : 8 000 = 5."},
{t:"Daftar 2 400 so'm edi, 600 so'mga qimmatladi. Endi 20 000 so'mga avvalgidan nechta kam daftar olinadi?",o:["2 ta kam","1 ta kam","3 ta kam","4 ta kam"],k:0,s:"Avval 8 ta (19 200), endi 3 000 dan 6 ta."},
{t:"Faqat 10 000, 5 000, 1 000 va 500 so'mlik kupyuralar bor. 37 500 so'mni eng kam nechta kupyura bilan to'lash mumkin?",o:["7 ta","6 ta","8 ta","5 ta"],k:0,s:"3 · 10 000 + 5 000 + 2 · 1 000 + 500."},
{t:"Anvarda 7 000 so'm bor. U har kuni 3 000 so'm oladi va 1 000 so'm sarflaydi. Necha kundan keyin unda 19 000 so'm bo'ladi?",o:["6 kun","4 kun","3 kun","10 kun"],k:0,s:"Kuniga +2 000; 12 000 : 2 000 = 6."},
{t:"Kitob va daftar birga 15 000 so'm. Kitob daftardan 9 000 so'm qimmat. Daftar necha so'm?",o:["3 000 so'm","6 000 so'm","12 000 so'm","4 500 so'm"],k:0,s:"(15 000 − 9 000) : 2 = 3 000; kitob 12 000."}
];
var PREP_DATA={teach:["Narx, miqdor, qiymat va ular orasidagi bog'lanish (·, :).","Qaytim: ayirish va «to'ldirib sanash» usuli.","Pul yetadimi — umumiy qiymatni hisoblab taqqoslash.","Tejash: bor pulni hisobga olish, qoldiqda yana 1 kun.","Bittasining narxi bo'yicha arzonini topish; aksiya; teskari masala."],
 mist:["Bitta narsa narxini ayirib, miqdorni unutadi.","Nollardan qarzda adashadi: 10 000 − 7 650 = 3 350.","Tejashda bor pulni ayirmaydi yoki qoldiqni tashlab yuboradi.","Qadoq narxini taqqoslaydi (miqdorni hisobga olmaydi).","Teskari masalada qaytimni ayirmasdan bo'ladi."],
 need:["Qog'oz kupyuralar (500 – 10 000), narx yorliqlari.","Reklama varaqasi yoki do'kon cheklari."],
 board:["<span class='w2'>qiymat = narx · miqdor</span>.","<span class='w2'>qaytim = berilgan − qiymat</span>.","13 700 → 14 000 → 15 000 → 20 000: <span class='w2'>6 300</span>.","<span class='w2'>(20 000 − 4 400) : 3 = 5 200</span>."]};
