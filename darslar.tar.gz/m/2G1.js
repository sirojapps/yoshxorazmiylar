var CODE='2G1',TITLE='2-sinf · Jadval va oddiy diagramma o‘qish';
function g1Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ustunli diagramma: data=[[nom,qiymat]], step — shkala qadami, mx — shkala maksimum
function g1Chart(data,o){o=o||{};clear();var g=S.g,x0=44,y0=150,H=120,mx=o.mx||10,st=o.step||1,n=data.length,bw=Math.min(44,250/n-14),gap=(300-n*bw)/(n+1);
 for(var v=0;v<=mx;v+=st){var y=y0-v/mx*H;E('line',{x1:x0,y1:y,x2:348,y2:y,stroke:v?'#e6ebf1':'#33475b','stroke-width':v?1:2},g);T(g,x0-6,y+4,String(v),{'font-size':9,'text-anchor':'end',fill:'#5b6b7b'})}
 E('line',{x1:x0,y1:y0,x2:x0,y2:y0-H-6,stroke:'#33475b','stroke-width':2},g);S.g1b=[];
 data.forEach(function(d,i){var x=x0+gap+i*(bw+gap),h=(o.grow!=null?Math.min(d[1],o.grow[i]):d[1])/mx*H,on=o.hl&&o.hl.indexOf(i)>=0;var r=E('rect',{x:x,y:y0-h,width:bw,height:h,rx:3,fill:on?C.a2:(o.cols?o.cols[i]:'#5aa9e6'),stroke:'#2b6ca3','stroke-width':1,style:'cursor:pointer'},g);r._i=i;S.g1b.push(r);
  T(g,x+bw/2,y0+13,d[0],{'font-size':10,'font-weight':700,fill:'#1d2b3a'});if(o.vals||on)T(g,x+bw/2,y0-h-5,String(o.grow?Math.min(d[1],o.grow[i]):d[1]),{'font-size':11,'font-weight':800,fill:on?C.a2:C.blue});
  r.addEventListener('click',function(){if(S.g1tap)S.g1tap(i)})});
 if(o.title)T(g,200,14,o.title,{'font-size':11,'font-weight':800,fill:C.blue})}
// jadval
function g1Table(rows,cols,cells,o){o=o||{};clear();var g=S.g,x0=10,y0=12,cw=(340-80)/cols.length,ch=28;
 E('rect',{x:x0,y:y0,width:80,height:ch,fill:'#eef3f8',stroke:'#c9d3dd'},g);cols.forEach(function(c,j){E('rect',{x:x0+80+j*cw,y:y0,width:cw,height:ch,fill:'#eef3f8',stroke:'#c9d3dd'},g);T(g,x0+80+j*cw+cw/2,y0+18,c,{'font-size':11,'font-weight':800})});
 rows.forEach(function(r,i){var y=y0+ch*(i+1);E('rect',{x:x0,y:y,width:80,height:ch,fill:'#f7f9fb',stroke:'#c9d3dd'},g);T(g,x0+40,y+18,r,{'font-size':11,'font-weight':800});
  cols.forEach(function(c,j){var on=o.hl&&o.hl[0]===i&&o.hl[1]===j,cr=o.hr===i||o.hc===j;var e=E('rect',{x:x0+80+j*cw,y:y,width:cw,height:ch,fill:on?C.hi:(cr?'#fff4d6':'#fff'),stroke:'#c9d3dd',style:'cursor:pointer'},g);T(g,x0+80+j*cw+cw/2,y+18,String(cells[i][j]),{'font-size':12,'font-weight':on?800:500,'pointer-events':'none'});e.addEventListener('click',function(){if(S.g1cell)S.g1cell(i,j)})})})}
var TR=['2-A','2-B','2-V'],TC=['Futbol','Shaxmat','Suzish'],TV=[[8,5,6],[7,9,4],[10,3,8]];
var D1=[['Ali',6],['Lola',9],['Vali',4],['Zarina',7]];
var D2=[['Qish',6],['Bahor',10],['Yoz',14],['Kuz',8]];
var P3=[function(){g1Chart(D2,{mx:16,step:2,title:'Sevimli fasl (o‘quvchilar soni)'});g1Msg('Bu diagrammada shkala <b>2 lab</b>: 0, 2, 4, 6 …')},
 function(){g1Chart(D2,{mx:16,step:2,hl:[0,2],title:'Sevimli fasl (o‘quvchilar soni)'});g1Msg('Qish ustuni 6 chizig‘ida, yoz — 14 da. Chiziqlar orasidagi ustun — toq son (masalan 7)')},
 function(){g1Chart(D2,{mx:16,step:2,vals:1,hl:[2,0],title:'Sevimli fasl (o‘quvchilar soni)'});g1Msg('Eng ko‘p — yoz (14), eng kam — qish (6). Farq: 14 − 6 = <b>8</b>')}];
var P6=[function(){g1Chart([['Kamola',7],['Sardor',5],['Javohir',6],['Dilnoza',3]],{mx:10,vals:1,title:'Bir oyda o‘qilgan kitoblar'});g1Msg('Kamola va Sardor birga Javohir va Dilnozadan nechta ko‘p?')},
 function(){g1Chart([['Kamola',7],['Sardor',5],['Javohir',6],['Dilnoza',3]],{mx:10,vals:1,hl:[0,1],title:'Bir oyda o‘qilgan kitoblar'});g1Msg('Kamola + Sardor = 7 + 5 = <b>12</b>')},
 function(){g1Chart([['Kamola',7],['Sardor',5],['Javohir',6],['Dilnoza',3]],{mx:10,vals:1,hl:[2,3],title:'Bir oyda o‘qilgan kitoblar'});g1Msg('Javohir + Dilnoza = 6 + 3 = <b>9</b>. Farq: 12 − 9 = <b>3</b>')}];
var STEPS=[
{h:"Jadvalni o'qish",sum:"Jadvalda qator va ustun kesishgan katakda javob turadi.",a:"m01",
 start:function(){g1Table(TR,TC,TV,{});g1Msg('Sinflar qaysi to‘garakka qatnashadi. Istalgan katakni bosing');S.g1cell=function(i,j){g1Table(TR,TC,TV,{hl:[i,j],hr:i,hc:j});g1Msg('<b>'+TR[i]+'</b> sinfda <b>'+TC[j]+'</b>ga — <b>'+TV[i][j]+'</b> o‘quvchi');S.g1t=(S.g1t||0)+1;if(S.g1t>=2&&S.g1d)S.g1d()}},
 fin:function(){g1Table(TR,TC,TV,{hl:[1,1],hr:1,hc:1});g1Msg('<b>2-B</b> sinfda <b>Shaxmat</b>ga — <b>9</b> o‘quvchi')},
 html:"<p>Jadval — ma'lumotlarni <b>qator</b> va <b>ustun</b>larga terib yozish. Kerakli javob qator va ustun <b>kesishgan</b> katakda turadi. Kamida 2 ta katakni bosib, o'qing:</p>",
 act:function(c,done){S.g1t=0;S.g1d=function(){S.g1d=null;done()};c.querySelector('.hint').textContent='Jadval kataklarini bosing.'},
 after:"<p>Masalan, «2-B sinfda nechta bola shaxmatga qatnashadi?»: <b>2-B</b> qatorini va <b>Shaxmat</b> ustunini topamiz, kesishgan katakda — <b>9</b>.</p>",
 q:{t:"Jadvalga ko'ra 2-V sinfda nechta bola suzishga qatnashadi?",opts:["4","8","10","6"],ok:1,why:"2-V qatori va Suzish ustuni kesishgan katakda 8.",hint:"Avval 2-V qatorini, keyin Suzish ustunini toping.",full:"2-V qatori: 10, 3, 8. Suzish — uchinchi ustun: 8. «4» — 2-B sinfniki, «6» — 2-A niki."},
 tn:"Doskaga jadval chizib, bolalar barmog'i bilan qator va ustunni «yurib» kesishgan katakni topsin."},
{h:"Ustunli diagramma",sum:"Ustun qancha baland bo'lsa, son shuncha katta. Ustun uchini chap shkalada o'qiymiz.",a:"m02",
 start:function(){g1Chart(D1,{mx:10,title:'Kim nechta olma terdi'});g1Msg('Ustunni bosing — necha olma ekanini ko‘ring');S.g1tap=function(i){g1Chart(D1,{mx:10,hl:[i],title:'Kim nechta olma terdi'});g1Msg('<b>'+D1[i][0]+'</b>: '+D1[i][1]+' ta olma');S.g1c=(S.g1c||0)+1;if(S.g1c>=3&&S.g1d2)S.g1d2()}},
 fin:function(){g1Chart(D1,{mx:10,vals:1,title:'Kim nechta olma terdi'});g1Msg('Ustunlar balandligi — olmalar soni')},
 html:"<p>Diagramma — ma'lumotning <b>rasmi</b>. Har bir ustun bitta bola. Ustun uchidan chapga qarab, shkaladagi sonni o'qiymiz. Kamida 3 ta ustunni bosing:</p>",
 act:function(c,done){S.g1c=0;S.g1d2=function(){S.g1d2=null;done()};c.querySelector('.hint').textContent='Ustunlarni bosing.'},
 after:"<p>Eng baland ustun — <b>Lola</b> (9 ta), eng past — <b>Vali</b> (4 ta). Diagramma kim ko'p, kim kam ekanini <b>bir qarashda</b> ko'rsatadi — jadvaldan farqi shu.</p>",
 q:{t:"Diagrammaga ko'ra Zarina Validan nechta ko'p olma tergan?",opts:["7","3","11","4"],ok:1,why:"7 − 4 = 3.",hint:"Zarina va Vali ustunlarini o'qing, keyin ayiring.",full:"Zarina — 7, Vali — 4. 7 − 4 = 3. «11» — qo'shib yuborgan."},
 tn:"Sinfda «sevimli meva» bo'yicha so'rov o'tkazing va doskada birga ustunli diagramma chizing."},
{h:"Shkala 2 lab bo'lsa",sum:"Shkala 2, 4, 6… bo'lsa, ikki chiziq orasidagi ustun — toq son. Farq: 14 − 6 = 8.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ba'zi diagrammalarda shkala 1 lab emas, <b>2 lab</b> yoki <b>5 lab</b> bo'ladi. Diqqat bilan o'qiymiz:</p>",
 btns:[phaser(P3)],
 after:"<p>Diagrammani o'qishdan oldin <b>shkalaga qarang</b>: u qanday qadam bilan ortadi? Ustun chiziqlar orasida bo'lsa — o'rtadagi son: 6 va 8 orasi — 7.</p>",
 q:{t:"Shkala 0, 5, 10, 15, 20. Ustun 10 va 15 ning roppa-rosa o'rtasida. Bu qaysi son?",opts:["11","12","13","14"],ok:2,why:"10 va 15 ning o'rtasi — 12 va 13 ham emas… aniq o'rtasi 12,5 bo'lmaydi; shkala 5 lab, o'rtasida 12 yoki 13? Butun son uchun teng bo'lingan kataklar kerak.",hint:"10 dan 15 gacha 5 birlik. O'rtasi qaysi?",full:""},
 tn:"Bolalar shkalasiz diagramma chizib, keyin shkala qo'shib ko'rsin — shkala nima uchun kerakligini tushunadi."},
{h:"Eng ko'p, eng kam va farq",sum:"Eng baland va eng past ustunni topib, ayiramiz.",a:"m04",
 start:function(){g1Chart([['A',30],['B',50],['V',40],['G',20]],{mx:60,step:10,title:'Binolar balandligi (m)'});g1Msg('Eng baland bino eng pastidan necha metr baland?')},fin:function(){g1Chart([['A',30],['B',50],['V',40],['G',20]],{mx:60,step:10,vals:1,hl:[1,3],title:'Binolar balandligi (m)'});g1Msg('50 − 20 = <b>30 m</b>')},
 html:"<p>Diagrammada to'rtta binoning balandligi. Eng baland va eng pastini toping:</p>",
 btns:[["🔍 Eng baland",function(c,done){g1Chart([['A',30],['B',50],['V',40],['G',20]],{mx:60,step:10,hl:[1],title:'Binolar balandligi (m)'});g1Msg('Eng baland — B: <b>50 m</b>');S.g1x=(S.g1x||0)|1;if(S.g1x===3)done()}],["🔍 Eng past",function(c,done){g1Chart([['A',30],['B',50],['V',40],['G',20]],{mx:60,step:10,hl:[3],title:'Binolar balandligi (m)'});g1Msg('Eng past — G: <b>20 m</b>');S.g1x=(S.g1x||0)|2;if(S.g1x===3)done()},'u']],g2:1,
 after:"<p>Eng baland — 50 m, eng past — 20 m. Farq: <b>50 − 20 = 30 m</b>. Diagramma savollarida ko'pincha ikki qadam bor: <b>o'qish</b>, keyin <b>hisoblash</b>.</p>",
 q:{t:"Diagrammada A — 30, B — 50, V — 40, G — 20. Hamma binolar balandligi yig'indisi?",opts:["120 m","140 m","50 m","130 m"],ok:1,why:"30 + 50 + 40 + 20 = 140.",hint:"Hamma ustunlardagi sonlarni qo'shing.",full:"30 + 50 = 80, + 40 = 120, + 20 = 140 m. «120» — oxirgisini qo'shmagan."},
 tn:"Bank: «Eng baland bino eng pastidan necha metr baland?» — shu ikki qadamli usul."},
{h:"Jadvaldan diagramma quramiz",sum:"Jadvaldagi har son — bitta ustunning balandligi.",a:"m05",
 start:function(){S.g1g=[0,0,0];g1Build()},fin:function(){S.g1g=[5,8,3];g1Build()},
 html:"<p>Jadval: <b>olma — 5</b>, <b>nok — 8</b>, <b>uzum — 3</b>. Tugmalar bilan ustunlarni kerakli balandlikka ko'taring:</p>",
 btns:[["🍎 +1",function(c,done){g1Grow(0,done)}],["🍐 +1",function(c,done){g1Grow(1,done)}],["🍇 +1",function(c,done){g1Grow(2,done)},'u']],g3:1,
 after:"<p>Jadval va diagramma — <b>bir xil ma'lumot</b>ning ikki ko'rinishi. Jadvalda aniq son yozilgan, diagrammada esa taqqoslash oson: nok eng ko'p, uzum eng kam.</p>",
 q:{t:"Olma 5, nok 8, uzum 3. Diagrammada qaysi ustun eng baland bo'ladi?",opts:["olma","nok","uzum","hammasi teng"],ok:1,why:"8 — eng katta son.",hint:"Qaysi meva soni eng katta?",full:"Ustun balandligi sonni ko'rsatadi: 8 > 5 > 3. Eng baland ustun — nok."},
 tn:"Darslikdagi jadvallarni bolalar katakli daftarga diagramma qilib chizsin."},
{h:"Tuzoq: birgalikda taqqoslash",sum:"(Kamola + Sardor) − (Javohir + Dilnoza) = 12 − 9 = 3.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Masala: <i>«Kamola va Sardor birgalikda Javohir va Dilnozadan nechta ko'p kitob o'qigan?»</i> Ikki juftni solishtiramiz:</p>",
 btns:[phaser(P6)],
 after:"<p>Uch qadam: 1) birinchi juft yig'indisi — 12; 2) ikkinchi juft — 9; 3) farq — <b>3</b>. Ko'pchilik faqat ikkita ustunni solishtirib xato qiladi.</p>",
 q:{t:"Futbolni 8, voleybolni 5, shaxmatni 11 bola yoqtiradi. Futbol va voleybolni birga yoqtiruvchilar shaxmatchilardan nechta ko'p?",opts:["3","2","13","24"],ok:1,why:"8 + 5 = 13, 13 − 11 = 2.",hint:"Avval futbol va voleybolni qo'shing.",full:"8 + 5 = 13. 13 − 11 = 2. «3» — faqat 8 − 5 ni hisoblagan, «13» — ayirishni unutgan."},
 tn:"Savolni bo'laklarga ajratib, har bo'lak ostiga chiziq tortishni o'rgating."},
{h:"Bilasizmi? Birinchi diagramma",sum:"Ustunli diagrammani 1786-yilda shotlandiyalik Uilyam Pleyfer o'ylab topgan.",a:"m07",
 start:function(){g1Chart(D2,{mx:16,step:2,vals:1,title:'Sevimli fasl'});g1Msg('Diagramma — ma‘lumotning rasmi')},fin:function(){g1Chart(D2,{mx:16,step:2,vals:1,title:'Sevimli fasl'});g1Msg('Diagramma — ma‘lumotning rasmi')},
 html:"<p>📊 Ustunli diagrammani <b>1786</b>-yilda shotlandiyalik olim <b>Uilyam Pleyfer</b> o'ylab topgan. U mamlakatlar savdosini sonlar bilan emas, ustunlar bilan ko'rsatgan — hamma birdan tushungan!</p><p>📰 Bugun diagrammalarni gazetalarda, televizorda, ob-havo xabarida, telefon ilovalarida ko'rasiz.</p>",
 tn:"Bolalar uydan gazeta yoki jurnaldagi diagrammani olib kelib, sinfga «o'qib» bersin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){g1Chart(D1,{mx:10,vals:1,title:'Kim nechta olma terdi'});g1Msg('Avval shkala, keyin ustun')},fin:function(){g1Chart(D1,{mx:10,vals:1,title:'Kim nechta olma terdi'});g1Msg('Avval shkala, keyin ustun')},
 html:"<div class='memo'><ul><li><b>Jadval</b>: qator va ustun kesishgan katakda javob.</li><li><b>Ustunli diagramma</b>: ustun balandligi — son.</li><li>Avval <b>shkalaga</b> qarang: 1 lab, 2 lab, 5 lab, 10 lab?</li><li>Eng ko'p — eng baland ustun, eng kam — eng past.</li><li>Ko'p qadamli savol: o'qing → yozing → hisoblang.</li><li>Birgalikda taqqoslash: (A + B) − (V + G).</li></ul></div>",
 tn:"Keyingi darsni sinf o'quvchilarining tug'ilgan oylari bo'yicha diagramma chizish bilan boshlang."}
];
// 3-qadam savolini to'g'irlaymiz (shkala 5 lab: o'rtasi aniq son bo'lishi uchun 10 va 20 ishlatamiz)
STEPS[2].q={t:"Shkala 0, 10, 20, 30, 40. Ustun 20 va 30 ning roppa-rosa o'rtasida. Bu qaysi son?",opts:["21","25","30","20"],ok:1,why:"20 va 30 ning o'rtasi — 25.",hint:"20 dan 30 gacha 10 birlik. Uning yarmi qancha?",full:"20 dan 30 gacha 10 birlik, yarmi 5. 20 + 5 = 25. «21» — chiziqlar orasini 1 deb o'ylagan."};
function g1Build(){g1Chart([['olma',5],['nok',8],['uzum',3]],{mx:10,grow:S.g1g,vals:1,cols:['#f08a8a','#a6d98a','#b89ae6'],title:'Jadval: olma 5, nok 8, uzum 3'});var ok=S.g1g[0]===5&&S.g1g[1]===8&&S.g1g[2]===3;g1Msg(ok?'Diagramma jadvalga to‘liq mos!':'Olma '+S.g1g[0]+'/5 · nok '+S.g1g[1]+'/8 · uzum '+S.g1g[2]+'/3');return ok}
function g1Grow(i,done){var need=[5,8,3];if(S.g1g[i]<need[i])S.g1g[i]++;if(g1Build())done()}
var PROBS=[
{t:"Jadvalda: 2-A sinfda futbolga 8, 2-B da 7, 2-V da 10 bola. Eng ko'p bola qaysi sinfda?",o:["2-V","2-A","2-B","teng"],k:0,s:"10 > 8 > 7."},
{t:"Diagrammada Ali — 6, Lola — 9 olma. Lola Alidan nechta ko'p?",o:["3","15","9","6"],k:0,s:"9 − 6 = 3."},
{t:"Ustunlar: qish 6, bahor 10, yoz 14, kuz 8. Eng ko'p va eng kam farqi?",o:["8","4","20","6"],k:0,s:"14 − 6 = 8."},
{t:"Binolar: 30 m, 50 m, 40 m, 20 m. Eng baland eng pastidan necha metr baland?",o:["30 m","20 m","10 m","70 m"],k:0,s:"50 − 20 = 30."},
{t:"Uch sinfda a'lochilar: 12, 11, 12. Jami nechta?",o:["35","34","36","24"],k:0,s:"12 + 11 + 12 = 35."},
{t:"Kamola 7, Sardor 5, Javohir 6, Dilnoza 3 kitob. Kamola va Sardor birga Javohir va Dilnozadan nechta ko'p?",o:["3","2","10","7"],k:0,s:"12 − 9 = 3."},
{t:"Futbol 8, voleybol 5, shaxmat 11. Futbol va voleybol birga shaxmatdan nechta ko'p?",o:["2","3","13","24"],k:0,s:"13 − 11 = 2."},
{t:"Shkala 0, 2, 4, 6, 8. Ustun 4 va 6 ning o'rtasida. Bu qaysi son?",o:["5","4","6","3"],k:0,s:"4 va 6 orasi — 5."},
{t:"Shkala 0, 10, 20, 30. Ustun 20 va 30 ning o'rtasida. Qaysi son?",o:["25","21","22","30"],k:0,s:"20 + 5 = 25."},
{t:"Sport tanlovi: futbol 9, kurash 7, suzish 6, tennis 3. Hammasi nechta bola?",o:["25","24","22","21"],k:0,s:"9 + 7 + 6 + 3 = 25."},
{t:"Eng ko'p tanlangan sport eng kamidan nechta ko'p? (9, 7, 6, 3)",o:["6","3","4","2"],k:0,s:"9 − 3 = 6."},
{t:"Jadval: dushanba 4, seshanba 6, chorshanba 5 ta muzqaymoq. Qaysi kuni eng ko'p sotilgan?",o:["seshanba","dushanba","chorshanba","teng"],k:0,s:"6 eng katta."},
{t:"Gullar: Ali 12, Vali 5, Sardor 9. Eng ko'p ekkan eng kamidan nechta ko'p?",o:["7","3","17","4"],k:0,s:"12 − 5 = 7."},
{t:"Diagrammada qaysi ustun eng past bo'ladi: 5, 8, 3, 6?",o:["3","5","6","8"],k:0,s:"Eng kichik son — eng past ustun."},
{t:"Oktabrda 4, noyabrda 6, dekabrda 10 kitob o'qildi. Qaysi oyda sentabr (4) va noyabr birga o'qilgancha o'qildi?",o:["dekabr","oktabr","noyabr","hech qaysi"],k:0,s:"4 + 6 = 10 — dekabr."},
{t:"Jadvalda 2-B qatori: futbol 7, shaxmat 9, suzish 4. 2-B da shu uch to'garakka jami nechta bola?",o:["20","16","13","9"],k:0,s:"7 + 9 + 4 = 20."},
{t:"Diagrammada shkala 5 lab: 0, 5, 10, 15. Ustun 15 da. Bu nechani bildiradi?",o:["15","3","5","10"],k:0,s:"Ustun uchi 15 chizig'ida."},
{t:"Olma 5, nok 8, uzum 3. Nok olma va uzumdan birga qancha ko'p yoki kam?",o:["teng","1 ta ko'p","1 ta kam","3 ta ko'p"],k:0,s:"5 + 3 = 8 = nok."},
{t:"Qaysi ma'lumotni diagrammada ko'rsatish qulay?",o:["Sinfdagi sevimli mevalar soni","Do'stingizning ismi","Bugungi sana","Uy manzili"],k:0,s:"Diagramma — sonlarni taqqoslash uchun."},
{t:"Qishda 6, yozda 14 bola tug'ilgan kunini nishonlaydi. Yozda qishdagidan necha marta… emas, nechta ko'p?",o:["8","20","2","6"],k:0,s:"14 − 6 = 8."}
];
PROBS[19]={t:"Qishda 6 bola, yozda 14 bola tug'ilgan. Yozda nechta ko'p?",o:["8","20","2","6"],k:0,s:"14 − 6 = 8."};
function PRACT_STAGE(){g1Chart(D1,{mx:10,vals:1,title:'Kim nechta olma terdi'});g1Msg('Avval shkala, keyin ustun')}
var PREP_DATA={teach:["Jadvalni o'qish: qator va ustun kesishmasi.","Ustunli diagramma: ustun balandligi va shkala.","Shkala 2, 5, 10 lab bo'lganda o'qish.","Eng ko'p/kam, farq, jami; birgalikda taqqoslash; jadvaldan diagramma qurish."],
 mist:["Shkalaga qaramay, kataklar sonini sanaydi.","Qator va ustunni adashtiradi.","«Birgalikda» savolida faqat ikkita ustunni solishtiradi.","Ustun chiziqlar orasida bo'lsa, eng yaqin chiziqni o'qiydi."],
 need:["Katakli daftar, rangli qalamlar."],
 board:["Jadval: <span class='w2'>sinf × to'garak</span>.","Diagramma: o'q, shkala, ustunlar.","<span class='w2'>14 − 6 = 8</span>.","<span class='w2'>(7 + 5) − (6 + 3) = 3</span>."]};
