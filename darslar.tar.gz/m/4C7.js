var CODE='4C7',TITLE='4-sinf · Ko‘paytirish va bo‘lish xossalari';
var P1=[function(){W3arr(4,7,{lbl:'4 qator, 7 tadan: 4 · 7 = 28'});W3msg('Nuqtalar massivi')},
 function(){W3arr(7,4,{lbl:'7 qator, 4 tadan: 7 · 4 = 28'});W3msg('Massivni 90° burdik — nuqtalar soni o‘zgarmadi')},
 function(){W3eq(['4 · 7 = 7 · 4','a · b = b · a']);W3msg('<b>O‘rin almashtirish xossasi</b>: ko‘paytuvchilar o‘rnini almashtirsak, ko‘paytma o‘zgarmaydi')}];
var P3=[function(){W3eq(['48 · 7 + 52 · 7 = ?']);W3msg('Ikkala ko‘paytmada ham 7 bor')},
 function(){W3area([48,52],7,{show:1,lbl:'Ikki to‘rtburchak, balandligi bir xil — 7'})},
 function(){W3area([100],7,{show:1,lbl:'Birlashtirsak: (48 + 52) · 7'})},
 function(){W3eq(['(48 + 52) · 7','= 100 · 7 = [700]']);W3msg('<b>Taqsimot xossasi</b>: a · c + b · c = (a + b) · c')}];
var P4=[function(){W3eq(['86 · 15 − 86 · 5 = ?'])},
 function(){W3eq(['86 · (15 − 5)']);W3msg('Umumiy ko‘paytuvchi 86 ni qavsdan tashqariga chiqaramiz')},
 function(){W3eq(['86 · 10 = [860]']);W3msg('a · b − a · c = a · (b − c)','Shu xossa bilan: 37 · 99 = 37 · 100 − 37 = 3 663')}];
var P5=[function(){W3eq(['408 : 12 = ?']);W3msg('408 ni 12 ga qulay bo‘linadigan qismlarga ajratamiz')},
 function(){W3eq(['408 = 360 + 48']);W3msg('360 ham, 48 ham 12 ga bo‘linadi')},
 function(){W3eq(['(360 + 48) : 12','= 360 : 12 + 48 : 12','= 30 + 4 = [34]']);W3msg('<b>Yig‘indini songa bo‘lish</b>: har qo‘shiluvchini bo‘lib, natijalarni qo‘shamiz')}];
var STEPS=[
{h:"O'rin almashtirish",sum:"a · b = b · a: massivni bursak, nuqtalar soni o'zgarmaydi.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Xossalar — tez hisoblashning kalitlari. Birinchisi — eng sodda.</p>",btns:[phaser(P1)],
 after:"<p>O'rin almashtirish xossasi ko'paytirishda bor, <b>bo'lishda yo'q</b>: 20 : 4 = 5, lekin 4 : 20 — butunlay boshqa.</p>",
 q:{t:"Qaysi tenglik NOTO'G'RI?",opts:["36 : 6 = 6 : 36","36 · 6 = 6 · 36","9 · 4 = 4 · 9","125 · 8 = 8 · 125"],ok:0,why:"Bo'lishda o'rin almashtirib bo'lmaydi.",hint:"Qaysi amal bor?",full:"36 : 6 = 6, lekin 6 : 36 — 1 dan kichik (6 ni 36 bo'lakka bo'lish). O'rin almashtirish faqat qo'shish va ko'paytirishda."},
 tn:"Qog'ozga 4 × 7 nuqta chizib, uni burib ko'rsating — Yaponiya darsliklarida shunday."},
{h:"Guruhlash: do'st juftlar",sum:"25 · 37 · 4 = (25 · 4) · 37 = 100 · 37 = 3 700.",a:"m02",start:function(){W3eq(['25 · 37 · 4 = ?']);W3msg('Qaysi juftni avval ko‘paytirgan qulay?')},fin:function(){W3eq(['(25 · 4) · 37','= 100 · 37 = [3 700]'])},
 html:"<p><b>25 · 37 · 4</b>. Qaysi tartibda hisoblash qulay?</p>",
 btns:[["(25 · 4) · 37",function(c,done){W3eq(['(25 · 4) · 37','= 100 · 37 = [3 700]']);W3msg('25 · 4 = 100 — «do‘st juft»! Keyin 37 · 100 og‘zaki');done()}],["(25 · 37) · 4",function(){W3eq(['25 · 37 = 925','925 · 4 = 3 700']);W3msg('Javob to‘g‘ri, lekin 25 · 37 ni hisoblash qiyin. Qulayrog‘ini toping!','Qayta tanlang')}]],
 after:"<p><b>Guruhlash xossasi</b>: (a · b) · c = a · (b · c). Ko'paytuvchilarni istalgan tartibda guruhlash mumkin. Do'st juftlar: <b>2 · 5 = 10, 4 · 25 = 100, 8 · 125 = 1 000</b>.</p>",
 q:{t:"8 · 43 · 125 = ?",opts:["43 000","4 300","430 000","5 375"],ok:0,why:"8 · 125 = 1 000.",hint:"Do'st juftni toping.",full:"(8 · 125) · 43 = 1 000 · 43 = 43 000. «5 375» — 43 · 125, 8 unutilgan."},
 tn:"«Do'st juftlar» kartochkalarini doskada osib qo'ying va o'yin qiling: kim tezroq juftini topadi."},
{h:"Taqsimot xossasi",sum:"48 · 7 + 52 · 7 = (48 + 52) · 7 = 700.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Ikki ko'paytmada bir xil ko'paytuvchi bo'lsa — ularni birlashtirsa bo'ladi. Kuzating.</p>",btns:[phaser(P3)],
 after:"<p>Maydon modeli xossani ko'rsatadi: bir xil balandlikdagi ikki to'rtburchak birlashsa — eni qo'shiladi. Teskari yo'nalishda ham ishlaydi: 23 · 14 = 23 · 10 + 23 · 4 (ustun usulining siri).</p>",
 q:{t:"17 · 6 + 17 · 4 = ?",opts:["170","102","68","1 020"],ok:0,why:"17 · (6 + 4) = 17 · 10.",hint:"Umumiy ko'paytuvchi — 17.",full:"17 · 6 + 17 · 4 = 17 · (6 + 4) = 17 · 10 = 170. «102» — faqat 17 · 6."},
 tn:"Katakli qog'ozda ikki to'rtburchakni qirqib, yopishtirib birlashtiring — CPA (aniq → rasm → belgi)."},
{h:"Ayirishga nisbatan",sum:"86 · 15 − 86 · 5 = 86 · 10 = 860; 37 · 99 = 37 · 100 − 37.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Taqsimot xossasi ayirishda ham ishlaydi.</p>",btns:[phaser(P4)],
 after:"<p>a · b − a · c = a · (b − c). Shu sababli 99, 98, 999 ga ko'paytirish oson: <b>a · 99 = a · 100 − a</b>.</p>",
 q:{t:"64 · 101 − 64 = ?",opts:["6 400","6 464","6 336","64"],ok:0,why:"64 · (101 − 1) = 64 · 100.",hint:"64 = 64 · 1.",full:"64 · 101 − 64 · 1 = 64 · (101 − 1) = 64 · 100 = 6 400. «6 464» — 64 · 101."},
 tn:"«64 — bu 64 · 1» degan fikrni alohida ta'kidlang — ko'p bolalar buni ko'rmaydi."},
{h:"Yig'indini songa bo'lish",sum:"408 : 12 = (360 + 48) : 12 = 30 + 4 = 34.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Katta sonni qulay qismlarga ajratib bo'lish mumkin.</p>",btns:[phaser(P5)],
 after:"<p>(a + b) : c = a : c + b : c — <b>ikkala qo'shiluvchi c ga bo'linsa</b>. Bu og'zaki bo'lishning asosiy usuli: 936 : 9 = 900 : 9 + 36 : 9 = 104.</p>",
 q:{t:"(560 + 35) : 7 = ?",opts:["85","80","8 + 5","13"],ok:0,why:"80 + 5.",hint:"560 : 7 va 35 : 7.",full:"560 : 7 = 80, 35 : 7 = 5, jami 85. «13» — 8 + 5: nol yo'qolgan."},
 tn:"Pul bilan: 408 so'mni 12 kishiga — avval 360 so'mni, keyin 48 so'mni ulashamiz."},
{h:"Tuzoq: songa yig'indini bo'lish",sum:"120 : (4 + 6) = 120 : 10 = 12, lekin 120 : 4 + 120 : 6 = 50 — bunday xossa YO'Q.",a:"m06",start:function(){W3eq(['120 : (4 + 6) = ?']);W3msg('Bola: «120 : 4 + 120 : 6 = 30 + 20 = 50». To‘g‘rimi?')},fin:function(){W3eq(['4 + 6 = 10','120 : 10 = [12]'])},
 html:"<p><b>120 : (4 + 6)</b>. Qaysi javob to'g'ri?</p>",
 btns:[["12",function(c,done){W3eq(['4 + 6 = 10','120 : 10 = [12]']);W3msg('Avval qavs: 4 + 6 = 10. 120 : 10 = <b>12</b>');done()}],["50",function(){W3eq(['120 : 4 + 120 : 6 = 50','≠ 120 : 10']);W3msg('Songa yig‘indini bunday bo‘lib bo‘lmaydi! Tekshiring: 50 · 10 = 500 ≠ 120','Qayta tanlang')}],["36",function(){W3eq(['120 : 4 + 6 = 36']);W3msg('Qavsni e‘tiborsiz qoldirdingiz','Qayta tanlang')}]],g3:1,
 after:"<p><b>Yig'indini</b> songa bo'lish mumkin: (a + b) : c. <b>Songa yig'indini</b> bo'lishning bunday qoidasi yo'q: a : (b + c) ≠ a : b + a : c. Har doim avval qavs ichini hisoblang.</p>",
 q:{t:"240 : (8 + 4) = ?",opts:["20","90","34","60"],ok:0,why:"240 : 12.",hint:"Avval qavs.",full:"8 + 4 = 12, 240 : 12 = 20. «90» — 30 + 60 (noto'g'ri xossa), «34» — 30 + 4 (qavs e'tiborsiz)."},
 tn:"Ikkala ifodani yonma-yon yozib, bolalar chizma (lenta) bilan farqini ko'rsatsin."},
{h:"Ko'paytmani songa bo'lish",sum:"(36 · 25) : 9 = (36 : 9) · 25 = 4 · 25 = 100.",a:"m07",start:function(){W3eq(['(36 · 25) : 9 = ?']);W3msg('Qaysi ko‘paytuvchini 9 ga bo‘lgan qulay?')},fin:function(){W3eq(['(36 : 9) · 25','= 4 · 25 = [100]'])},
 html:"<p><b>(36 · 25) : 9</b>. Qanday hisoblaysiz?</p>",
 btns:[["(36 : 9) · 25",function(c,done){W3eq(['(36 : 9) · 25','= 4 · 25 = [100]']);W3msg('Ko‘paytmani bo‘lish uchun <b>bitta</b> ko‘paytuvchini bo‘lish yetarli');done()}],["(36 : 9) · (25 : 9)",function(){W3eq(['25 : 9 — butun emas','ikkalasini bo‘lish shart emas']);W3msg('Ikkala ko‘paytuvchini bo‘lsak, natija 9 marta kichrayib ketadi','Qayta tanlang')}],["900 : 9",function(){W3eq(['36 · 25 = 900','900 : 9 = 100']);W3msg('To‘g‘ri, lekin uzoqroq yo‘l. Qisqasini toping!','Qayta tanlang')}]],g3:1,
 after:"<p>(a · b) : c = (a : c) · b — ko'paytuvchilardan biri c ga bo'linsa. <b>Ikkalasini</b> bo'lish xato: (36 : 9) · (25 : 9) emas.</p>",
 q:{t:"(125 · 48) : 8 = ?",opts:["750","6 000","93","75"],ok:0,why:"125 · (48 : 8) = 125 · 6.",hint:"48 : 8 = 6.",full:"48 : 8 = 6, 125 · 6 = 750. «6 000» — 125 · 48, 8 ga bo'lish unutilgan."},
 tn:"«Bitta yetarli» qoidasini to'rtburchak bilan ko'rsating: tomonlardan birini 9 marta kichraytirsak, yuz 9 marta kichrayadi."},
{h:"0 va 1",sum:"a · 1 = a, a : 1 = a, a · 0 = 0, 0 : a = 0, a : 0 — ma'nosiz.",a:"m08",start:function(){W3eq(['17 · 0','0 : 17','17 : 0']);W3msg('Qaysi ifodaning ma‘nosi yo‘q?')},fin:function(){W3eq(['17 · 0 = 0','0 : 17 = 0','17 : 0 — [ma‘nosiz]'])},
 html:"<p>Uchta ifoda. Qaysi birining <b>qiymati yo'q</b> (hisoblab bo'lmaydi)?</p>",
 btns:[["17 : 0",function(c,done){W3eq(['17 · 0 = 0','0 : 17 = 0','17 : 0 — [ma‘nosiz]']);W3msg('□ · 0 = 17 bo‘ladigan son yo‘q — <b>nolga bo‘lish mumkin emas</b>');done()}],["0 : 17",function(){W3eq(['0 : 17 = 0','0 · 17 = 0 ✓']);W3msg('Hech narsani 17 kishiga ulashsak — har biriga 0','Qayta tanlang')}],["17 · 0",function(){W3eq(['17 · 0 = 0']);W3msg('17 marta nol — 0','Qayta tanlang')}]],g3:1,
 after:"<p>Nima uchun 17 : 0 yo'q? Bo'lish — ko'paytirishning teskarisi: 17 : 0 = □ bo'lsa, □ · 0 = 17 bo'lishi kerak. Lekin har qanday son · 0 = 0. Bunday son yo'q.</p>",
 q:{t:"(254 − 254) · 39 + 39 : 39 = ?",opts:["1","0","39","40"],ok:0,why:"0 · 39 + 1.",hint:"Avval qavs, keyin ko'paytirish va bo'lish.",full:"254 − 254 = 0, 0 · 39 = 0, 39 : 39 = 1, jami 1. «0» — 39 : 39 ni 0 deb olgan."},
 tn:"«Nolga bo'lish»ni tarqatish bilan tushuntiring: 17 ta konfetni 0 ta bolaga — nechtadan? Savolning o'zi ma'nosiz."},
{h:"Bilasizmi? Belgilar tarixi",sum:"Ko'paytirish belgisi × ni 1631-yilda ingliz matematigi Uilyam Outred qo'llagan; nuqta · ni Leybnits taklif etgan.",a:"m09",start:function(){W3eq(['×  — Outred, 1631','·  — Leybnits'],{fs:22});W3msg('Belgilar ham ixtiro qilingan')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Ko'paytirish belgisi <b>×</b> ni 1631-yilda ingliz matematigi <b>Uilyam Outred</b> o'z kitobida qo'llagan. Keyinroq nemis olimi <b>Leybnits</b> × ni «x» harfi bilan adashtirmaslik uchun <b>nuqta ·</b> ni taklif qilgan — biz hozir shuni ishlatamiz.</p><p>⭐ Xossalar esa belgilardan ancha qadimiy: taqsimot xossasini qadimgi yunon matematigi Evklid ham chizmalar orqali isbotlagan.</p>",
 tn:"Bolalarga: «Nega maktabda × emas, · yozamiz?» — algebraga tayyorgarlik (x harfi)."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3area([48,52],7,{show:1,lbl:'(48 + 52) · 7 = 700'})},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>O'rin almashtirish: a · b = b · a (bo'lishda yo'q!).</li><li>Guruhlash: (25 · 4) · 37 = 3 700; do'st juftlar 2·5, 4·25, 8·125.</li><li>Taqsimot: a · c + b · c = (a + b) · c; a · 99 = a · 100 − a.</li><li>Yig'indini bo'lish: (360 + 48) : 12 = 30 + 4. <b>Songa yig'indini</b> bunday bo'lib bo'lmaydi!</li><li>Ko'paytmani bo'lish: (36 · 25) : 9 = 4 · 25 — bitta ko'paytuvchini bo'lamiz.</li><li>a · 0 = 0, 0 : a = 0, a : 0 — ma'nosiz.</li></ul></div>",
 tn:"Keyingi mavzu: ko'paytirish va bo'lishni tekshirish, chamalash."}
];
var PROBS=[
{t:"4 · 37 · 25 = ?",o:["3 700","370","37 000","1 625"],k:0,s:"(4 · 25) · 37."},
{t:"125 · 7 · 8 = ?",o:["7 000","700","70 000","1 000"],k:0,s:"(125 · 8) · 7."},
{t:"2 · 5 · 2 · 5 · 2 · 5 = ?",o:["1 000","100","30","10 000"],k:0,s:"10 · 10 · 10."},
{t:"39 · 8 + 61 · 8 = ?",o:["800","312","488","8 000"],k:0,s:"(39 + 61) · 8."},
{t:"73 · 26 − 73 · 16 = ?",o:["730","1 168","10","7 300"],k:0,s:"73 · 10."},
{t:"45 · 99 = ?",o:["4 455","4 500","4 545","4 405"],k:0,s:"4 500 − 45."},
{t:"28 · 11 = ?",o:["308","280","318","288"],k:0,s:"280 + 28."},
{t:"(720 + 64) : 8 = ?",o:["98","90","908","17"],k:0,s:"90 + 8."},
{t:"(1 200 − 48) : 6 = ?",o:["192","208","200","1 192"],k:0,s:"200 − 8."},
{t:"360 : (6 + 3) = ?",o:["40","180","63","120"],k:0,s:"360 : 9."},
{t:"(48 · 35) : 12 = ?",o:["140","1 680","35","420"],k:0,s:"(48 : 12) · 35 = 4 · 35."},
{t:"(81 · 16) : 9 : 8 = ?",o:["18","1 296","162","9"],k:0,s:"(81 : 9) · (16 : 8) = 9 · 2."},
{t:"Qaysi tenglik to'g'ri?",o:["(30 + 6) : 3 = 30 : 3 + 6 : 3","30 : (3 + 6) = 30 : 3 + 30 : 6","(30 · 6) : 3 = (30 : 3) · (6 : 3)","30 : 6 = 6 : 30"],k:0,s:"Yig'indini bo'lish xossasi."},
{t:"(567 − 567) · 89 + 0 : 89 = ?",o:["0","89","1","90"],k:0,s:"0 + 0."},
{t:"a · 17 + a · 3 = 1 000. a = ?",o:["50","20","100","5"],k:0,s:"a · 20 = 1 000."},
{t:"Bir qutida 25 ta qalam, bir yashikda 8 ta quti. 4 ta yashikda nechta qalam?",o:["800","200","100","37"],k:0,s:"25 · 8 · 4 = 25 · 4 · 8."},
{t:"Ali 34 ta daftarni 2 500 so'mdan, Vali 66 ta daftarni 2 500 so'mdan oldi. Ikkalasi jami necha so'm to'ladi?",o:["250 000","85 000","165 000","25 000"],k:0,s:"(34 + 66) · 2 500."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["99 · 101","100 · 100 − 2","98 · 102","9 999 − 99"],k:0,s:"9 999; 9 998; 9 996; 9 900."},
{t:"Bo'sh joyga qaysi son mos? 56 · 13 + 56 · □ = 5 600",o:["87","100","43","7"],k:0,s:"13 + □ = 100."},
{t:"(□ + 49) : 7 = 23. □ = ?",o:["112","161","16","7"],k:0,s:"□ + 49 = 161."}
];
function PRACT_STAGE(){W3eq(['(25 · 4) · 37','(48 + 52) · 7'])}
var PREP_DATA={teach:["O'rin almashtirish (bo'lishda yo'qligi).","Guruhlash va do'st juftlar.","Taqsimot xossasi (qo'shish va ayirishga nisbatan).","Yig'indini songa bo'lish; songa yig'indini bo'lish xatosi.","Ko'paytmani songa bo'lish; 0 va 1."],
 mist:["120 : (4 + 6) = 120 : 4 + 120 : 6.","(36 · 25) : 9 da ikkala ko'paytuvchini bo'ladi.","64 · 101 − 64 da 64 ni «64 · 1» deb ko'rmaydi.","17 : 0 = 0 yoki 17 deb yozadi."],
 need:["Nuqtali massiv kartochkasi.","Katakli qog'oz, qaychi (maydon modeli)."],
 board:["<span class='w2'>a · b = b · a</span>","<span class='w2'>(a · b) · c = a · (b · c)</span>","<span class='w2'>a · c + b · c = (a + b) · c</span>","<span class='w2'>(a + b) : c = a : c + b : c</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
