var CODE='4J15',TITLE="4-sinf · Raqamlar yig'indisi, raqamli jumboqlar";
function q15Cells(digs,hl,cap){clear();var g=S.g,n=digs.length,w=44,x0=180-n*(w+6)/2;digs.forEach(function(d,i){var x=x0+i*(w+6),on=hl&&hl.indexOf(i)>=0;E('rect',{x:x,y:44,width:w,height:56,rx:8,fill:on?'#e6f6ee':'#fff',stroke:on?C.ok:'#c9d3dd','stroke-width':2},g);T(g,x+w/2,82,d,{'font-size':26,'font-weight':900,fill:on?C.ok:'#1d2b3a'})});if(cap)T(g,180,132,cap,{'font-size':14,'font-weight':800,fill:C.blue})}
var P1=[function(){q15Cells(["?","?","?"],null,"raqamlar yig'indisi = 25");j2Msg("Raqamlari yig'indisi 25 bo'lgan <b>eng kichik</b> sonni topamiz.")},
 function(){q15Cells(["?","9","9"],[1,2],"oxiriga 9 lar: 9 + 9 = 18");j2Msg("Son kichik bo'lishi uchun raqamlar <b>kam</b> bo'lsin → har biri iloji boricha katta (9). Ikki xona: 9 + 9 = 18 < 25 — yetmaydi, demak 3 xona.")},
 function(){q15Cells(["7","9","9"],[0],"25 − 18 = 7  →  799");j2Msg("Birinchi raqam — qolgani: 25 − 18 = 7. Eng kichik son: <b>799</b>.")}];
var P2=[function(){j2Lines([["raqamlari har xil, yig'indisi 15",C.blue,18],["eng katta son?",null,18]]);j2Msg("Eng katta son — <b>xonalari eng ko'p</b> son. Buning uchun eng kichik raqamlarni olamiz!")},
 function(){j2Lines([["0 + 1 + 2 + 3 + 4 + 5 = 15",C.blue,20],["6 ta raqam!",null,17]]);j2Msg("0, 1, 2, 3, 4, 5 — yig'indisi aynan 15, 6 xona.")},
 function(){q15Cells(["5","4","3","2","1","0"],[0],"543 210");j2Msg("Kattadan kichikka joylaymiz: <b>543 210</b>. 96 yoki 9 510 — xonasi kam, kichik.")}];
var P3=[function(){j2Lines([["1, 2, 3, … , 99",C.blue,24]]);j2Msg("1 dan 99 gacha <b>barcha raqamlar</b> yig'indisi qancha?")},
 function(){j2Lines([["birliklar: har raqam 0–9 — 10 martadan",null,15],["(0+1+…+9) · 10 = 45 · 10 = 450",C.blue,17]]);j2Msg("Birliklar xonasida har raqam 10 marta uchraydi.")},
 function(){j2Lines([["o'nliklar: 1–9 — 10 martadan",null,15],["45 · 10 = 450",C.blue,17],["450 + 450 = 900",C.ok,22]]);j2Msg("O'nliklarda ham 1 dan 9 gacha har biri 10 martadan: 450. Jami <b>900</b>.")}];
var P4=[function(){q15Cells(["A","B"],null,"AB + BA = 121");j2Msg("AB — ikki xonali son (A — o'nliklar, B — birliklar). AB + BA = 121.")},
 function(){j2Lines([["AB = 10A + B,  BA = 10B + A",null,16],["AB + BA = 11A + 11B = 11 · (A + B)",C.blue,16]]);j2Msg("Ikkalasini qo'shsak, har raqam 11 marta: 11 · (A + B).")},
 function(){j2Lines([["11 · (A + B) = 121",null,18],["A + B = 11",C.ok,24],["29, 38, 47, 56, 65, 74, 83, 92",null,14]]);j2Msg("A + B = 11 → 8 ta son: 29, 38, …, 92.")}];
var P5=[function(){q15Cells(["7","5","2"],null,"752 − 257 = ?");j2Msg("Uch xonali sondan uning teskarisini ayiramiz: 752 − 257.")},
 function(){j2Lines([["752 − 257 = 495",C.blue,24],["495 = 99 · 5",null,18],["7 − 2 = 5 !",C.ok,20]]);j2Msg("Natija har doim <b>99 ga</b> karrali: ABC − CBA = 99 · (A − C). O'rtadagi raqam yo'qoladi!")}];
var P6=[function(){j2Lines([["1 dan 100 gacha: 9 raqami",C.blue,20]]);j2Msg("1 dan 100 gacha sonlarni yozganda 9 raqami necha marta yoziladi?")},
 function(){j2Lines([["birliklarda: 9, 19, 29, …, 99 → 10",null,16]]);j2Msg("Birliklar xonasida — 10 marta.")},
 function(){j2Lines([["o'nliklarda: 90, 91, …, 99 → 10",null,16],["99 da ikkala 9 ham sanaladi!",C.bad,15],["10 + 10 = 20",C.ok,22]]);j2Msg("O'nliklar xonasida yana 10. 99 dagi ikki 9 ikkala hisobda bor. Jami <b>20</b> (19 emas!).")}];
var STEPS=[
{h:"Raqamlar yig'indisi berilgan — eng kichik son",sum:"Eng kichik son: xonalar kam (9 larni oxiriga), birinchi raqam — qolgani: 25 → 799.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Raqamlari yig'indisi 25 bo'lgan eng kichik natural son qaysi? Kuzating, qanday fikrlaymiz.</p>",
 btns:[phaser(P1)],
 after:"<p>Qoida: avval <b>xonalar soni</b> eng kam bo'lsin (oxiriga 9 lar), keyin birinchi raqam eng kichik bo'lsin. 889 ham yig'indisi 25, lekin 799 dan katta.</p>",
 q:{t:"Raqamlari yig'indisi 30 bo'lgan eng kichik son qaysi?",opts:["9 993","3 999","6 888","39 999"],ok:1,why:"999 → 27 < 30, demak 4 xona; birinchi raqam 30 − 27 = 3.",hint:"Uch xonali son ko'pi bilan necha raqam yig'indisiga ega? Yetadimi?",full:"Uch xonali eng katta yig'indi 9 + 9 + 9 = 27 < 30. Demak 4 xona kerak: oxiri 999, birinchi raqam 30 − 27 = 3 → 3 999. 6 888 va 9 993 ham to'g'ri yig'indili, lekin kattaroq."},
 tn:"«Eng kichik son» — avval xona soni, keyin chapdan raqamlar. Doskada 799, 889, 979, 997 ni solishtiring."},
{h:"Raqamlari har xil — eng katta son",sum:"Eng katta son — xonasi eng ko'p: 0+1+2+3+4+5 = 15 → 543 210.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Endi teskarisi: raqamlari <b>har xil</b>, yig'indisi 15 bo'lgan <b>eng katta</b> son.</p>",
 btns:[phaser(P2)],
 after:"<p>Tuzoq: ko'pchilik 9 dan boshlaydi (96, 9 510). Lekin xonasi ko'p son har doim katta. Eng ko'p xona — eng kichik raqamlar bilan.</p>",
 q:{t:"Raqamlari har xil, yig'indisi 10 bo'lgan eng katta son?",opts:["910","4 321","43 210","64"],ok:2,why:"0 + 1 + 2 + 3 + 4 = 10 → 5 xona: 43 210.",hint:"Eng ko'p nechta har xil raqam yig'indisi 10 beradi?",full:"0 + 1 + 2 + 3 + 4 = 10 — 5 ta har xil raqam. Kattadan kichikka: 43 210. 4 321 — 0 ni unutgan, 910 va 64 — xonasi kam."},
 tn:"Bolalar juftlikda «kim kattaroq son tuzadi» musobaqasi o'tkazsin."},
{h:"1 dan 99 gacha raqamlar yig'indisi",sum:"Birliklarda 450, o'nliklarda 450 → 900.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Hamma sonlarni yozib qo'shish uzoq. Xonalar bo'yicha sanaymiz.</p>",
 btns:[phaser(P3)],
 after:"<p>Usul: har xonada har raqam <b>necha marta</b> uchrashini sanaymiz. Bu «1 dan 99 gacha sonlar yig'indisi» (4 950) bilan bir xil emas!</p>",
 q:{t:"1 dan 20 gacha barcha sonlarning raqamlari yig'indisi?",opts:["210","102","100","45"],ok:1,why:"1–9: 45; 10–19: 10 + 45 = 55; 20: 2. Jami 102.",hint:"1–9, 10–19 va 20 ni alohida hisoblang.",full:"1–9: 45. 10–19: o'nliklarda 10 ta «1» = 10, birliklarda 0–9 = 45 → 55. 20: 2 + 0 = 2. Jami 45 + 55 + 2 = 102. «210» — sonlarning o'zi yig'indisi."},
 tn:"Jadval tuzdiring: xona | raqam | necha marta. Bu kombinatorikaga ham tayyorlaydi."},
{h:"Jumboq: AB + BA",sum:"AB + BA = 11 · (A + B). 121 → A + B = 11.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Harflar — raqamlar. Raqamlarni almashtirsak, son qanday o'zgaradi?</p>",
 btns:[phaser(P4)],
 after:"<p>Kalit: ikki xonali sonni <b>10A + B</b> deb yozish. Shundan keyin jumboq oddiy tenglamaga aylanadi.</p>",
 q:{t:"AB + BA = 132. AB ning eng katta qiymati?",opts:["84","93","66","39"],ok:1,why:"11 · (A + B) = 132 → A + B = 12 → eng kattasi 93.",hint:"132 : 11 = ? Shu yig'indili eng katta ikki xonali son?",full:"132 : 11 = 12, demak A + B = 12. Juftlar: 39, 48, 57, 66, 75, 84, 93. Eng kattasi 93. 84 ham mos, lekin kichik."},
 tn:"Bolalar o'z ikki xonali sonini teskarisiga qo'shib, natija 11 ga bo'linishini tekshirsin."},
{h:"ABC − CBA: 99 ning siri",sum:"ABC − CBA = 99 · (A − C): 752 − 257 = 495 = 99 · 5.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Uch xonali sondan uning teskarisini ayirsak, natijada sehrli narsa bor.</p>",
 btns:[phaser(P5)],
 after:"<p>100A + 10B + C − (100C + 10B + A) = 99A − 99C = 99 · (A − C). O'rtadagi raqam umuman ta'sir qilmaydi!</p>",
 q:{t:"ABC − CBA = 396. A − C nechaga teng?",opts:["3","4","6","2"],ok:1,why:"396 : 99 = 4.",hint:"Ayirma 99 · (A − C). 396 ni 99 ga bo'ling.",full:"99 · (A − C) = 396 → A − C = 396 : 99 = 4. Masalan, 501 − 105 = 396 yoki 862 − 268 = 594 — bu esa 6."},
 tn:"Sinf bo'yicha har kim o'z sonini olib ABC − CBA ni hisoblasin — hamma natijalar 99 ga bo'linadi."},
{h:"Tuzoq: 9 raqami necha marta?",sum:"1–100 da 9: birliklarda 10, o'nliklarda 10 → 20 (99 ikki marta).",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>«Necha <b>son</b>da 9 bor?» va «9 <b>raqami</b> necha marta yozilgan?» — har xil savollar!</p>",
 btns:[phaser(P6)],
 after:"<p>9 qatnashgan <b>sonlar</b> 19 ta (99 bitta son). Lekin 9 <b>raqami</b> 20 marta yozilgan. Savolni diqqat bilan o'qing.</p>",
 q:{t:"1 dan 100 gacha sonlarni yozganda 0 raqami necha marta yoziladi?",opts:["10","9","11","20"],ok:2,why:"10, 20, …, 90 — 9 ta, 100 da — 2 ta: 11.",hint:"0 birliklarda qaysi sonlarda? 100 ni unutmang.",full:"Birliklar xonasida 0: 10, 20, 30, …, 90 — 9 ta. 100 da ikkita 0. Jami 9 + 2 = 11. 0 o'nliklarda (01, 02…) yozilmaydi."},
 tn:"Bolalar 1 dan 100 gacha sonlar jadvalidan 9 larni qizil bilan belgilab sanasin."},
{h:"Bilasizmi? Kaprekar sehri — 6174",sum:"Har qanday 4 xonali sonda (raqamlari hammasi bir xil emas) «kattadan kichikni ayirish» 6174 ga olib keladi.",a:"m07",
 start:function(){j2Lines([["3524 → 5432 − 2345 = 3087",null,15],["→ 8730 − 0378 = 8352",null,15],["→ 8532 − 2358 = 6174",C.ok,17]]);j2Msg("Hind matematigi Kaprekar (1949)")},fin:function(){j2Lines([["3524 → 5432 − 2345 = 3087",null,15],["→ 8730 − 0378 = 8352",null,15],["→ 8532 − 2358 = 6174",C.ok,17]]);j2Msg("Hind matematigi Kaprekar (1949)")},
 html:"<p>🔢 Hind matematigi <b>D. R. Kaprekar</b> 1949-yilda kashf qilgan: istalgan 4 xonali sonni oling (raqamlari hammasi bir xil bo'lmasin). Raqamlarini kamayish tartibida yozib, o'sish tartibidagisini ayiring. Natija bilan yana shunday qiling. Ko'pi bilan 7 qadamda doim <b>6174</b> chiqadi, keyin u o'zgarmaydi: 7641 − 1467 = 6174.</p>",
 btns:[["🔢 Sinab ko'raman",function(c,done){done()}]],
 tn:"Har bola o'z sonini olib sinab ko'rsin — eng ko'p qadam kimda bo'ldi?"},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["AB = 10A + B",C.blue,26]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["AB = 10A + B",C.blue,26]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li>Yig'indi berilgan <b>eng kichik</b> son: xonalar kam, oxiriga 9 lar (25 → 799).</li><li>Raqamlari har xil <b>eng katta</b> son: xonalar ko'p, kichik raqamlar (15 → 543 210).</li><li>Raqamlar yig'indisini xonalar bo'yicha sanang (1–99 → 900).</li><li>AB + BA = 11 · (A + B); ABC − CBA = 99 · (A − C).</li><li>«Raqam necha marta» ≠ «necha sonda»: 99 da ikkita 9.</li></ul></div>",
 tn:"Uyga: «Raqamlari yig'indisi 20 bo'lgan eng kichik va eng katta uch xonali sonlar»."}
];
var PROBS=[
{t:"Raqamlari yig'indisi 25 bo'lgan eng kichik son?",o:["799","997","889","1 699"],k:0,s:"Oxiriga 99, birinchi raqam 25 − 18 = 7."},
{t:"Raqamlari yig'indisi 30 bo'lgan eng kichik son?",o:["3 999","9 993","6 888","39 999"],k:0,s:"4 xona: 30 − 27 = 3."},
{t:"Raqamlari yig'indisi 20 bo'lgan eng katta uch xonali son?",o:["992","983","299","999"],k:0,s:"9 + 9 + 2 = 20."},
{t:"Raqamlari har xil, yig'indisi 10 bo'lgan eng katta son?",o:["43 210","910","4 321","64"],k:0,s:"0 + 1 + 2 + 3 + 4 = 10."},
{t:"Raqamlari har xil, yig'indisi 15 bo'lgan eng katta son?",o:["543 210","9 510","54 321","960"],k:0,s:"0 + 1 + 2 + 3 + 4 + 5 = 15 → 6 xona."},
{t:"1 dan 20 gacha barcha sonlarning raqamlari yig'indisi?",o:["102","210","100","45"],k:0,s:"45 + 55 + 2 = 102."},
{t:"1 dan 99 gacha barcha sonlarning raqamlari yig'indisi?",o:["900","4 950","450","990"],k:0,s:"Birliklarda 450, o'nliklarda 450."},
{t:"1 dan 100 gacha yozganda 9 raqami necha marta yoziladi?",o:["20","10","19","11"],k:0,s:"Birliklarda 10, o'nliklarda 10."},
{t:"1 dan 100 gacha yozganda 0 raqami necha marta yoziladi?",o:["11","10","9","20"],k:0,s:"10, 20, …, 90 — 9 ta, 100 da 2 ta."},
{t:"AB + BA = 121. A + B nechaga teng?",o:["11","12","10","13"],k:0,s:"11 · (A + B) = 121."},
{t:"AB + BA = 132. AB ning eng katta qiymati?",o:["93","66","39","84"],k:0,s:"A + B = 12 → 93."},
{t:"752 − 257 = ?",o:["495","505","595","485"],k:0,s:"99 · (7 − 2) = 495."},
{t:"ABC − CBA = 396. A − C = ?",o:["4","3","6","2"],k:0,s:"396 : 99 = 4."},
{t:"ABC − CBA = 297 (A va C nol emas). ABC ning eng kichik qiymati?",o:["401","300","411","104"],k:0,s:"A − C = 3: eng kichigi A = 4, B = 0, C = 1."},
{t:"Ikki xonali son raqamlarini almashtirsak, son 27 ga ortadi. Raqamlar ayirmasi?",o:["3","27","9","2"],k:0,s:"9 · (B − A) = 27 → 3."},
{t:"5432 − 2345 = ?",o:["3 087","3 187","2 087","3 097"],k:0,s:"5432 − 2345 = 3087."},
{t:"Raqamlari yig'indisi 4 bo'lgan uch xonali sonlar nechta?",o:["10","4","6","15"],k:0,s:"400, 310, 301, 220, 211, 202, 130, 121, 112, 103."},
{t:"Raqamlari ko'paytmasi 12 bo'lgan eng kichik ikki xonali son?",o:["26","34","43","62"],k:0,s:"2 · 6 = 12; 26 < 34."},
{t:"Raqamlari ko'paytmasi 0 bo'lgan ikki xonali sonlar nechta?",o:["9","10","18","1"],k:0,s:"10, 20, …, 90."},
{t:"8 532 − 2 358 = ?",o:["6 174","6 274","6 184","5 174"],k:0,s:"Kaprekar soni: 6174."}
];
function PRACT_STAGE(){q15Cells(["A","B","C"],null,"raqamlar jumboqlari")}
var PREP_DATA={teach:["Raqamlar yig'indisi berilganda eng kichik/eng katta son.","Xonalar bo'yicha sanash.","AB = 10A + B: jumboqlarni tenglamaga aylantirish.","«Raqam necha marta» savoli."],
 mist:["Eng katta sonni 9 dan boshlaydi (xonalar sonini unutadi).","Raqamlar yig'indisini sonlar yig'indisi bilan chalkashtiradi.","99 dagi ikki 9 dan birini sanamaydi.","100 dagi nollarni unutadi."],
 need:["0–9 raqamli kartochkalar (har bolaga).","1–100 sonlar jadvali."],
 board:["<span class='w2'>25 → 799</span>.","<span class='w2'>15 → 543 210</span>.","<span class='w2'>AB + BA = 11 · (A + B)</span>.","<span class='w2'>ABC − CBA = 99 · (A − C)</span>.","<span class='w2'>9 raqami: 10 + 10 = 20</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
