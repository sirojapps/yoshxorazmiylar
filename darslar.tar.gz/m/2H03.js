var CODE='2H03',TITLE='2-sinf olimpiada · Shakllarni sanash (rasmda nechta?)';
// ---------- uchburchak + uchidan kesmalar ----------
var H3A=[180,22],H3Y=150,H3X0=50,H3X1=310;
function h3bx(i,n){return H3X0+(H3X1-H3X0)*i/n}
function h3tri(n,hl,lab){clear();var g=S.g;
 if(hl){var a=h3bx(hl[0],n),b=h3bx(hl[1],n);E('path',{d:'M'+H3A[0]+' '+H3A[1]+' L'+a+' '+H3Y+' L'+b+' '+H3Y+' Z',fill:C.hi,opacity:.85},g)}
 E('path',{d:'M'+H3A[0]+' '+H3A[1]+' L'+H3X0+' '+H3Y+' L'+H3X1+' '+H3Y+' Z',fill:'none',stroke:'#33475b','stroke-width':2.5},g);
 for(var i=1;i<n;i++)E('line',{x1:H3A[0],y1:H3A[1],x2:h3bx(i,n),y2:H3Y,stroke:'#33475b','stroke-width':2},g);
 for(var j=0;j<=n;j++){E('circle',{cx:h3bx(j,n),cy:H3Y,r:3.5,fill:'#33475b'},g);T(g,h3bx(j,n),H3Y+16,String.fromCharCode(65+j),{'font-size':11,'font-weight':800})}
 if(lab)T(g,330,40,lab,{'font-size':20,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
// barcha (i,j) juftlar — o'lcham bo'yicha
function h3pairs(n){var a=[];for(var s=1;s<=n;s++)for(var i=0;i+s<=n;i++)a.push([i,i+s]);return a}
function h3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// kvadrat to'r
function h3grid(n,hl,lab,extra){clear();var g=S.g,s=Math.min(36,120/n),x0=180-n*s/2,y0=24;
 if(hl)E('rect',{x:x0+hl[0]*s,y:y0+hl[1]*s,width:hl[2]*s,height:hl[2]*s,fill:C.hi,opacity:.85},g);
 for(var i=0;i<=n;i++){E('line',{x1:x0,y1:y0+i*s,x2:x0+n*s,y2:y0+i*s,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0+n*s,stroke:'#33475b','stroke-width':2},g)}
 if(extra)extra(g,x0,y0,s);if(lab)T(g,330,40,lab,{'font-size':20,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
var P1=[];(function(){var L=h3pairs(2),names=['ABD... ','',''];L.forEach(function(p,k){P1.push(function(){h3tri(2,p,String(k+1));var nm=String.fromCharCode(65+p[0])+String.fromCharCode(65+p[1]);h3msg((k+1)+'-uchburchak: uchi va <b>'+nm+'</b> asos'+(k===2?' — <b>katta</b> uchburchak ham sanaladi! Jami <b>3</b>':''))})})})();
P1.unshift(function(){h3tri(2,null,'?');h3msg('Rasmda nechta uchburchak? Ko‘pchilik «2» deydi…')});
var P2=[function(){h3tri(4,null,'?');h3msg('Uchidan 3 ta kesma. Asos 4 bo‘lakka bo‘lingan')},
 function(){h3tri(4,[0,1],'4');h3msg('1 bo‘lakli uchburchaklar: <b>4</b> ta')},
 function(){h3tri(4,[0,2],'3');h3msg('2 bo‘lakli: AC, BD, CE — <b>3</b> ta')},
 function(){h3tri(4,[0,3],'2');h3msg('3 bo‘lakli: AD, BE — <b>2</b> ta')},
 function(){h3tri(4,[0,4],'1');h3msg('4 bo‘lakli (butun): <b>1</b> ta. Jami 4 + 3 + 2 + 1 = <b>10</b>')}];
var P4=[function(){h3grid(3,null,'?');h3msg('3 × 3 to‘rda nechta kvadrat? «9» — hammasi emas!')},
 function(){h3grid(3,[0,0,1],'9');h3msg('1 × 1 kvadratlar: <b>9</b> ta')},
 function(){h3grid(3,[0,0,2],'4');h3msg('2 × 2 kvadratlar: <b>4</b> ta (chap-tepa, o‘ng-tepa, chap-past, o‘ng-past)')},
 function(){h3grid(3,[0,0,3],'1');h3msg('3 × 3 (butun): <b>1</b> ta. Jami 9 + 4 + 1 = <b>14</b>')}];
function h3diag(k){clear();var g=S.g,x0=120,y0=22,s=120,c=[x0+s/2,y0+s/2];var P=[[x0,y0],[x0+s,y0],[x0+s,y0+s],[x0,y0+s]];
 var hl=[];if(k===1)hl=[[P[0],P[1],c]];if(k===2)hl=[[P[0],P[1],P[2]]];
 hl.forEach(function(t){E('path',{d:'M'+t.map(function(p){return p.join(' ')}).join(' L')+' Z',fill:C.hi,opacity:.85},g)});
 E('rect',{x:x0,y:y0,width:s,height:s,fill:'none',stroke:'#33475b','stroke-width':2.5},g);E('line',{x1:x0,y1:y0,x2:x0+s,y2:y0+s,stroke:'#33475b','stroke-width':2},g);E('line',{x1:x0+s,y1:y0,x2:x0,y2:y0+s,stroke:'#33475b','stroke-width':2},g);
 ['A','B','C','D'].forEach(function(n,i){T(g,P[i][0]+(i===1||i===2?10:-10),P[i][1]+(i<2?-4:12),n,{'font-size':11,'font-weight':800})});
 h3msg(['Kvadrat va 2 diagonal. Nechta uchburchak?','Kichik uchburchaklar (markazga tegadi): <b>4</b> ta','Katta (yarim kvadrat): ABC, BCD, CDA, DAB — <b>4</b> ta. Jami <b>8</b>'][k])}
var STEPS=[
{h:"Katta shaklni unutmang",sum:"Uchidan 1 kesma o'tkazilgan uchburchakda 3 ta uchburchak: 2 kichik + 1 katta.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Uchburchakning uchidan asosiga bitta kesma o'tkazildi. Rasmda nechta uchburchak bor? Har birini bittalab ko'ring.</p>",
 btns:[phaser(P1,'▶ Keyingi uchburchak')],
 after:"<p>Ikkita kichik uchburchak ko'rinib turibdi, lekin ular birga <b>katta uchburchakni</b> ham hosil qiladi. Jami 3 ta. Eng ko'p uchraydigan xato — butun shaklni sanashni unutish.</p>",
 q:{t:"Uchidan 2 ta kesma o'tkazilgan uchburchakda nechta uchburchak bor?",opts:["6","3","4","5"],ok:0,why:"1 bo'lakli 3 ta, 2 bo'lakli 2 ta, butun 1 ta: 3 + 2 + 1 = 6.",hint:"Asos 3 bo'lakka bo'lingan. 1 bo'lakli, 2 bo'lakli va butun uchburchaklarni alohida sanang.",full:"Asosda 3 bo'lak: kichiklari 3 ta, ikkitalik — 2 ta, uchtalik (butun) — 1 ta. Jami 6. «3» — faqat kichiklar."},
 tn:"Bolalar har topgan uchburchagini rangli qalam bilan chizib, belgilab borsin."},
{h:"Tartib bilan sanash",sum:"Asos 4 bo'lak: 4 + 3 + 2 + 1 = 10 uchburchak. O'lcham bo'yicha guruhlab sanaymiz.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=4;P2[4]()},
 html:"<p>Endi uchidan <b>3 ta</b> kesma. Tartibsiz sanasak, adashamiz. Shuning uchun <b>o'lchami bo'yicha</b> sanaymiz: avval eng kichiklar, keyin kattaroqlar.</p>",
 btns:[phaser(P2,'▶ Keyingi o‘lcham')],
 after:"<p>Asos 4 bo'lak bo'lsa: 4 + 3 + 2 + 1 = <b>10</b>. Qonuniyat: asos nechta bo'lakka bo'lingan bo'lsa, 1 dan shu songacha qo'shamiz. Bu usul — tartibli sanash — olimpiadaning asosiy quroli.</p>",
 q:{t:"Uchidan 4 ta kesma o'tkazilgan uchburchakda nechta uchburchak?",opts:["15","10","5","20"],ok:0,why:"Asos 5 bo'lak: 5 + 4 + 3 + 2 + 1 = 15.",hint:"4 ta kesma asosni nechta bo'lakka bo'ladi?",full:"4 ta kesma — 5 ta bo'lak. 5 + 4 + 3 + 2 + 1 = 15. «10» — asos 4 bo'lak deb olingan."},
 tn:"Jadval tuzdiring: «o'lcham | nechta». Bu kombinatorikaning birinchi qadami."},
{h:"Kesmalarni sanash",sum:"To'g'ri chiziqda 4 nuqta: 3 + 2 + 1 = 6 kesma.",a:"m03",
 start:function(){h3seg(-1)},fin:function(){h3seg(5)},
 html:"<p>To'g'ri chiziqda 4 ta nuqta: A, B, C, D. Nechta kesma bor? Har bir kesmani ko'rish uchun tugmani bosing.</p>",
 btns:[["▶ Keyingi kesma",function(c,done,b){S.h3s=(S.h3s==null?-1:S.h3s)+1;h3seg(S.h3s);if(S.h3s>=5){b.disabled=true;done()}}]],
 after:"<p>A dan boshlanadigan kesmalar: AB, AC, AD (3 ta); B dan: BC, BD (2 ta); C dan: CD (1 ta). Jami 3 + 2 + 1 = <b>6</b>. Bu uchburchaklar sanog'i bilan bir xil qonuniyat!</p>",
 q:{t:"To'g'ri chiziqda 5 ta nuqta. Nechta kesma bor?",opts:["10","5","4","15"],ok:0,why:"4 + 3 + 2 + 1 = 10.",hint:"Birinchi nuqtadan nechta kesma chiqadi? Ikkinchisidan-chi (takrorlamasdan)?",full:"1-nuqtadan 4 ta, 2-dan 3 ta, 3-dan 2 ta, 4-dan 1 ta: 10. «4» — faqat qo'shni nuqtalar orasidagi kesmalar."},
 tn:"Bolalar qo'l berib ko'rishish masalasini sahnalashtirsin: 4 bola nechta qo'l berishadi? (6)"},
{h:"Kvadratlarni sanash",sum:"3 × 3 to'rda: 9 (1×1) + 4 (2×2) + 1 (3×3) = 14 kvadrat.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=3;P4[3]()},
 html:"<p>3 × 3 katakli kvadratda nechta kvadrat bor? Kataklar 9 ta — lekin kvadratlar ko'proq!</p>",
 btns:[phaser(P4,'▶ Keyingi o‘lcham')],
 after:"<p>Yana o'lcham bo'yicha sanaymiz: 1 × 1 — 9 ta, 2 × 2 — 4 ta, 3 × 3 — 1 ta. Jami <b>14</b>. Qiziq: 9, 4, 1 — bular 3·3, 2·2, 1·1!</p>",
 q:{t:"2 × 2 katakli kvadratda nechta kvadrat bor?",opts:["5","4","3","6"],ok:0,why:"4 ta kichik + 1 ta katta = 5.",hint:"Kichik kvadratlarni sanang. Butun shakl ham kvadratmi?",full:"1 × 1 — 4 ta, 2 × 2 (butun) — 1 ta. Jami 5. «4» — katta kvadrat unutilgan."},
 tn:"Shaxmat taxtasida nechta kvadrat bor? (204) — kuchli bolalarga uyga savol."},
{h:"Tuzoq: kvadrat ichida kvadrat",sum:"Kvadrat 4 ga, biri yana 4 ga bo'lingan: 1 + 4 + 4 = 9 kvadrat.",a:"m05",
 start:function(){h3nest(0)},fin:function(){h3nest(3)},
 html:"<p>Kvadrat 4 ta teng kvadratchaga bo'lindi, so'ng ulardan biri yana 4 ta kichik kvadratchaga bo'lindi. Rasmda jami nechta kvadrat? (Bank testidagi savol.)</p>",
 btns:[["▶ Keyingi qadam",function(c,done,b){S.h3n=(S.h3n||0)+1;h3nest(S.h3n);if(S.h3n>=3){b.disabled=true;done()}}]],
 after:"<p>Uch o'lchamdagi kvadratlar: eng kichik — 4 ta, o'rtacha — 4 ta (bittasi bo'lingan bo'lsa ham, u ham kvadrat!), katta — 1 ta. Jami <b>9</b>.</p>",
 q:{t:"Kvadrat 4 ga bo'lindi, so'ng ikkita kichik kvadratning har biri yana 4 ga bo'lindi. Nechta kvadrat?",opts:["13","12","9","17"],ok:0,why:"1 + 4 + 4 + 4 = 13.",hint:"Eng kichiklari nechta? O'rtachalari-chi? Butuni?",full:"Eng kichik: 4 + 4 = 8, o'rtacha: 4, katta: 1. Jami 13. «12» — butun kvadrat unutilgan."},
 tn:"Qog'oz kvadratni buklab-kesib, bolalar o'zi yasasin va sanasin."},
{h:"Tuzoq: diagonallar",sum:"Kvadrat va 2 diagonal: 4 kichik + 4 katta = 8 uchburchak.",a:"m06",
 start:function(){S.h3d=0;h3diag(0)},fin:function(){h3diag(2)},
 html:"<p>ABCD kvadratda ikkita diagonal chizildi. Rasmda nechta uchburchak bor? Ko'pchilik «4» deb qo'yadi…</p>",
 btns:[["▶ Keyingi turi",function(c,done,b){S.h3d=(S.h3d||0)+1;h3diag(S.h3d);if(S.h3d>=2){b.disabled=true;done()}}]],
 after:"<p>4 ta kichik uchburchak markazda uchrashadi. Lekin har bir diagonal kvadratni <b>ikkita katta</b> uchburchakka ham bo'ladi: 2 diagonal × 2 = 4. Jami <b>8</b>.</p>",
 q:{t:"To'g'ri to'rtburchak 1 × 3 katakdan iborat (3 ta kvadrat qatorda). Unda nechta to'g'ri to'rtburchak bor (kvadratlar ham)?",opts:["6","3","4","5"],ok:0,why:"1 katakli 3, 2 katakli 2, 3 katakli 1: 6.",hint:"Kesmalarni sanash usulini qo'llang: 1, 2 va 3 katakli to'rtburchaklar.",full:"1 katakli — 3 ta, 2 katakli — 2 ta, butun — 1 ta: 3 + 2 + 1 = 6. «3» — faqat kataklar."},
 tn:"Shaffof plyonkaga uchburchaklarni chizib, rasm ustiga qo'yib tekshirish mumkin."},
{h:"Bilasizmi? Tartib — sanash siri",sum:"«Barcha variantlarni tartib bilan ko'rib chiqish» — kombinatorika fanining asosi.",a:"m07",
 start:function(){h3tri(4,[1,3],'');h3msg('Tartib bilan sanash')},fin:function(){h3tri(4,[1,3],'');h3msg('Tartib bilan sanash')},
 html:"<p>🧠 Matematiklar shakllarni, yo'llarni, variantlarni sanashni <b>kombinatorika</b> deb atashadi. Uning asosiy qoidasi — <b>hech narsani tashlab ketmaslik va ikki marta sanamaslik</b>.</p><p>⭐ Biz ishlatgan usul — avval eng kichiklarini, keyin kattaroqlarini sanash — dunyo bo'yicha olimpiadachilarning eng sevimli usullaridan biri. 4 + 3 + 2 + 1 kabi yig'indilar esa matematikada juda ko'p uchraydi.</p>",
 tn:"Bolalarga 1 + 2 + … + 10 ni tez hisoblashni (juftlab: 1 + 10, 2 + 9 …) ko'rsating — 55."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){h3tri(3,null,'');h3msg('Tartib bilan sanang!')},fin:function(){h3tri(3,null,'');h3msg('Tartib bilan sanang!')},
 html:"<div class='memo'><ul><li><b>O'lcham bo'yicha</b> sanang: avval kichiklar, keyin kattalar.</li><li><b>Butun shaklni</b> unutmang!</li><li>Uchidan kesmalar: asos n bo'lak → 1 + 2 + … + n uchburchak (4 bo'lak → 10).</li><li>Chiziqda n nuqta: kesmalar (n − 1) + … + 1 (4 nuqta → 6).</li><li>3 × 3 to'r: 9 + 4 + 1 = 14 kvadrat.</li><li>Bo'lingan kvadrat ham kvadrat sifatida sanaladi.</li><li>Kvadrat + 2 diagonal = 8 uchburchak.</li></ul></div>",
 tn:"Keyingi darsni «4 × 4 to'rda nechta kvadrat?» (16 + 9 + 4 + 1 = 30) savoli bilan boshlang."}
];
function h3seg(k){clear();var g=S.g,xs=[50,140,220,310],y=90,L=['AB','AC','AD','BC','BD','CD'],P=[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]];
 E('line',{x1:30,y1:y,x2:330,y2:y,stroke:'#9aa8b6','stroke-width':2},g);
 for(var i=0;i<=Math.min(k,5);i++){var p=P[i];E('line',{x1:xs[p[0]],y1:y-14-i*7,x2:xs[p[1]],y2:y-14-i*7,stroke:i===k?C.bad:'rgba(31,111,178,.35)','stroke-width':i===k?5:3},g)}
 xs.forEach(function(x,i){E('circle',{cx:x,cy:y,r:5,fill:'#33475b'},g);T(g,x,y+20,'ABCD'[i],{'font-size':13,'font-weight':800})});
 h3msg(k<0?'Nechta kesma? Tugmani bosing':(k<5?(k+1)+'-kesma: <b>'+L[k]+'</b>':'6-kesma: <b>CD</b>. Jami: 3 + 2 + 1 = <b>6</b>'))}
function h3nest(k){var s=60;h3grid(2,null,k>=3?'9':'',function(g,x0,y0,s2){var a=x0,b=y0;E('line',{x1:a+s2/2,y1:b,x2:a+s2/2,y2:b+s2,stroke:'#33475b','stroke-width':1.5},g);E('line',{x1:a,y1:b+s2/2,x2:a+s2,y2:b+s2/2,stroke:'#33475b','stroke-width':1.5},g);
  if(k===1)for(var i=0;i<2;i++)for(var j=0;j<2;j++)E('rect',{x:a+i*s2/2+2,y:b+j*s2/2+2,width:s2/2-4,height:s2/2-4,fill:'none',stroke:C.bad,'stroke-width':2.5},g);
  if(k===2)for(var i2=0;i2<2;i2++)for(var j2=0;j2<2;j2++)E('rect',{x:x0+i2*s2+3,y:y0+j2*s2+3,width:s2-6,height:s2-6,fill:'none',stroke:C.ok,'stroke-width':3},g);
  if(k===3)E('rect',{x:x0+2,y:y0+2,width:2*s2-4,height:2*s2-4,fill:'none',stroke:C.blue,'stroke-width':4},g)});
 h3msg(['Nechta kvadrat?','Eng kichiklari: <b>4</b> ta','O‘rtachalari: <b>4</b> ta (bo‘lingani ham!)','Katta: <b>1</b> ta. Jami 4 + 4 + 1 = <b>9</b>'][k])}
var PROBS=[
{t:"Uchidan 1 ta kesma o'tkazilgan uchburchakda nechta uchburchak?",o:["3","2","1","4"],k:0,s:"2 kichik + 1 katta = 3."},
{t:"Uchidan 3 ta kesma o'tkazilgan uchburchakda nechta uchburchak?",o:["10","4","7","8"],k:0,s:"Asos 4 bo'lak: 4 + 3 + 2 + 1 = 10."},
{t:"Chiziqda 4 ta nuqta. Nechta kesma?",o:["6","4","3","8"],k:0,s:"3 + 2 + 1 = 6."},
{t:"Chiziqda 6 ta nuqta. Nechta kesma?",o:["15","6","5","21"],k:0,s:"5 + 4 + 3 + 2 + 1 = 15."},
{t:"2 × 2 to'rda nechta kvadrat?",o:["5","4","6","8"],k:0,s:"4 + 1 = 5."},
{t:"3 × 3 to'rda nechta kvadrat?",o:["14","9","10","13"],k:0,s:"9 + 4 + 1 = 14."},
{t:"Kvadrat 4 ga bo'lindi, biri yana 4 ga bo'lindi. Nechta kvadrat?",o:["9","8","12","7"],k:0,s:"4 + 4 + 1 = 9."},
{t:"Kvadratda 2 diagonal chizildi. Nechta uchburchak?",o:["8","4","6","7"],k:0,s:"4 kichik + 4 katta = 8."},
{t:"1 × 4 katakli tasmada nechta to'g'ri to'rtburchak (kvadratlar ham)?",o:["10","4","8","6"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"Kvadratda bitta diagonal chizildi. Nechta uchburchak hosil bo'ldi?",o:["2","1","4","3"],k:0,s:"Bitta diagonal kvadratni 2 ta uchburchakka bo'ladi."},
{t:"4 bola bir-biri bilan qo'l berib ko'rishdi (har juft bir marta). Nechta qo'l berish?",o:["6","4","8","12"],k:0,s:"3 + 2 + 1 = 6."},
{t:"5 ta jamoa bir-biri bilan bir martadan o'ynadi. Nechta o'yin?",o:["10","5","20","15"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"Doira ichida 2 ta diametr (xoch shaklida). Nechta bo'lak?",o:["4","2","3","6"],k:0,s:"2 diametr doirani 4 bo'lakka bo'ladi."},
{t:"Uchburchakning har bir tomonining o'rtasini tutashtirsak, nechta uchburchak hosil bo'ladi (kattasi bilan)?",o:["5","4","3","6"],k:0,s:"4 kichik + 1 katta = 5."},
{t:"2 × 3 katakli to'g'ri to'rtburchakda nechta kvadrat?",o:["8","6","7","9"],k:0,s:"1×1 — 6 ta, 2×2 — 2 ta: 8."},
{t:"Ichma-ich 3 ta doira chizildi. Nechta doira?",o:["3","1","2","6"],k:0,s:"Har biri alohida doira — 3 ta."},
{t:"Uchidan 5 ta kesma o'tkazilgan uchburchakda nechta uchburchak?",o:["21","15","6","25"],k:0,s:"Asos 6 bo'lak: 6 + 5 + 4 + 3 + 2 + 1 = 21."},
{t:"4 × 4 to'rda nechta 2 × 2 kvadrat bor?",o:["9","4","8","16"],k:0,s:"Har yo'nalishda 3 ta joy: 3 · 3 = 9."},
{t:"Kvadrat 9 ta katakka bo'lingan (3 × 3). Markazdagi katakni o'z ichiga olgan nechta kvadrat bor?",o:["6","5","4","9"],k:0,s:"1×1 — 1, 2×2 — 4, 3×3 — 1: 6."},
{t:"Chiziqda A, B, C nuqtalar. Nechta kesma?",o:["3","2","1","6"],k:0,s:"AB, AC, BC — 3 ta."}
];
function PRACT_STAGE(){h3tri(3,null,'');h3msg('O‘lcham bo‘yicha sanang')}
var PREP_DATA={teach:["Shakllarni o'lcham bo'yicha tartibli sanash.","Uchidan kesmalar — 1 + 2 + … + n qonuniyati; kesmalar va qo'l berishlar.","To'rdagi kvadratlar; ichma-ich bo'lingan kvadratlar.","Diagonallar bilan uchburchaklar."],
 mist:["Butun shaklni sanashni unutadi.","Tartibsiz sanaydi — takrorlaydi yoki tashlab ketadi.","To'rda faqat kataklarni sanaydi.","Diagonallarda katta uchburchaklarni ko'rmaydi."],
 need:["Shaffof plyonka, flomaster.","Chop etilgan shakllar."],
 board:["Uchidan 1 kesma: <span class='w2'>2 + 1 = 3</span>.","Asos 4 bo'lak: <span class='w2'>4 + 3 + 2 + 1 = 10</span>.","4 nuqta: <span class='w2'>3 + 2 + 1 = 6</span> kesma.","3 × 3: <span class='w2'>9 + 4 + 1 = 14</span>.","Ichma-ich: <span class='w2'>4 + 4 + 1 = 9</span>.","Diagonallar: <span class='w2'>4 + 4 = 8</span>."]};
