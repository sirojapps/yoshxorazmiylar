var CODE='3H10',TITLE='3-sinf · Koordinata burchagi, nuqtalar yasash';
function h10msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function h10X(i){return 30+28*i}function h10Y(j){return 150-24*j}
// o: pts [[x,y,lab,col]], segs [[x1,y1,x2,y2,col,dash]], tap fn(x,y)
function h10grid(o){o=o||{};clear();var g=S.g,i,j;
 for(i=0;i<=9;i++)E('line',{x1:h10X(i),y1:h10Y(0),x2:h10X(i),y2:h10Y(5),stroke:'#e3e8ee','stroke-width':1},g);
 for(j=0;j<=5;j++)E('line',{x1:h10X(0),y1:h10Y(j),x2:h10X(9),y2:h10Y(j),stroke:'#e3e8ee','stroke-width':1},g);
 if(!o.noAx){E('line',{x1:h10X(0),y1:h10Y(0),x2:h10X(9)+18,y2:h10Y(0),stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(h10X(9)+18)+' 150 l-8 -4 v8 z',fill:'#33475b'},g);
  E('line',{x1:h10X(0),y1:h10Y(0),x2:h10X(0),y2:h10Y(5)-16,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M30 '+(h10Y(5)-16)+' l-4 8 h8 z',fill:'#33475b'},g);
  T(g,h10X(9)+20,166,'x',{'font-size':13,'font-weight':800,fill:C.blue});T(g,18,16,'y',{'font-size':13,'font-weight':800,fill:C.bad});
  for(i=1;i<=9;i++)T(g,h10X(i),166,''+i,{'font-size':11,fill:C.blue});for(j=1;j<=5;j++)T(g,19,h10Y(j)+4,''+j,{'font-size':11,fill:C.bad});T(g,19,166,'O',{'font-size':11,'font-weight':800})}
 (o.segs||[]).forEach(function(q){E('line',{x1:h10X(q[0]),y1:h10Y(q[1]),x2:h10X(q[2]),y2:h10Y(q[3]),stroke:q[4]||C.a2,'stroke-width':q[5]?2:3.5,'stroke-dasharray':q[5]?'5 4':'none','stroke-linecap':'round'},g)});
 (o.pts||[]).forEach(function(p){E('circle',{cx:h10X(p[0]),cy:h10Y(p[1]),r:6,fill:p[3]||C.bad,stroke:'#fff','stroke-width':1.5},g);if(p[2])T(g,h10X(p[0])+(p[0]>=8?-10:12),h10Y(p[1])-9,p[2],{'font-size':12,'font-weight':800,fill:p[3]||C.bad,'text-anchor':p[0]>=8?'end':'start'})});
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var x=Math.max(0,Math.min(9,Math.round((p.x-30)/28))),y=Math.max(0,Math.min(5,Math.round((150-p.y)/24)));o.tap(x,y)})}}
function h10walk(x,y,lab,k){var s=[],q=[];if(k>=1)s.push([0,0,x,0,C.blue]);if(k>=2)s.push([x,0,x,y,C.bad]);if(k>=3){q.push([x,y,lab+'('+x+'; '+y+')'])}h10grid({segs:s,pts:q})}
var P1=[function(){h10grid({noAx:1});h10msg('Katakli qog‘oz. Nuqtaning o‘rnini qanday aytamiz?')},
 function(){clear();h10grid();h10msg('Ikki nur: yotiq <b style="color:#2f6fb5">x o‘qi</b> (o‘ngga) va tik <b style="color:#d9534f">y o‘qi</b> (yuqoriga). Ular O nuqtada boshlanadi')},
 function(){h10grid({pts:[[0,0,'O(0; 0)',C.ok]]});h10msg('O — <b>koordinatalar boshi</b>, (0; 0). Bu shakl — <b>koordinata burchagi</b>')}];
var P2=[function(){h10walk(3,2,'A',0);h10msg('A nuqtaga O dan boramiz')},function(){h10walk(3,2,'A',1);h10msg('Avval x o‘qi bo‘ylab <b>o‘ngga 3</b> qadam')},function(){h10walk(3,2,'A',2);h10msg('Keyin <b>yuqoriga 2</b> qadam')},function(){h10walk(3,2,'A',3);h10msg('<b>A(3; 2)</b>: birinchi son — o‘ngga, ikkinchi son — yuqoriga')}];
var P6=[[1,1,'A'],[6,1,'B'],[6,4,'C'],[1,4,'D']];
var P6P=[function(){h10grid({pts:P6.map(function(p){return [p[0],p[1],p[2]+'('+p[0]+'; '+p[1]+')']})});h10msg('A(1; 1), B(6; 1), C(6; 4), D(1; 4) — 4 ta nuqta')},
 function(){h10grid({segs:[[1,1,6,1],[6,1,6,4]],pts:P6.map(function(p){return [p[0],p[1],p[2]]})});h10msg('A→B: y bir xil (1) — yotiq kesma. B→C: x bir xil (6) — tik kesma')},
 function(){h10grid({segs:[[1,1,6,1],[6,1,6,4],[6,4,1,4],[1,4,1,1]],pts:P6.map(function(p){return [p[0],p[1],p[2]]})});h10msg('ABCD — <b>to‘g‘ri to‘rtburchak</b>: AB = 6 − 1 = 5, BC = 4 − 1 = 3 katak')}];
function h10mv(){h10grid({pts:[[4,3,'K(4; 3)',C.ok],[S.px,S.py,'P('+S.px+'; '+S.py+')',C.bad]]})}
var STEPS=[
{h:"Koordinata burchagi",sum:"Ikki perpendikular nur — x o'qi va y o'qi — koordinata burchagini hosil qiladi; ularning boshi O(0; 0).",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Xaritada, shaxmatda, kinoteatrda joyni ikki son bilan aytamiz. Matematikada buning uchun <b>koordinata burchagi</b> chiziladi.</p>",
 btns:[phaser(P1)],
 after:"<p><b>x o'qi</b> — o'ngga, <b>y o'qi</b> — yuqoriga yo'nalgan. Ular perpendikular va <b>O</b> nuqtada (koordinatalar boshi) boshlanadi. O'qlarda bir xil qadam bilan sonlar yoziladi.</p>",
 q:{t:"Koordinatalar boshi O ning koordinatalari qanday?",opts:["(1; 1)","(0; 0)","(0; 1)","(1; 0)"],ok:1,why:"O dan hech qayerga yurmaymiz: o'ngga 0, yuqoriga 0.",hint:"O nuqtadan O ga borish uchun necha qadam yurish kerak?",full:"O — boshlanish nuqtasi: o'ngga 0 qadam, yuqoriga 0 qadam, demak O(0; 0). (1; 1) — bu bir qadam o'ngda va bir qadam yuqorida turgan nuqta."},
 tn:"Doskada katakli to'r chizib, ikki o'qni turli rangda (x — ko'k, y — qizil) belgilang. Rang bolalarga tartibni eslab qolishga yordam beradi."},
{h:"Nuqtaning koordinatalari",sum:"A(3; 2): avval o'ngga 3 (x), keyin yuqoriga 2 (y). Birinchi son — x, ikkinchisi — y.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>A nuqtaga O dan qanday boramiz? Qadamma-qadam ko'ring.</p>",
 btns:[phaser(P2)],
 after:"<p>Nuqtaning o'rni <b>ikki son</b> bilan yoziladi: <b>A(3; 2)</b>. Birinchi son (x) — o'ngga necha qadam, ikkinchi son (y) — yuqoriga necha qadam. Sonlar orasiga nuqtali vergul qo'yiladi.</p>",
 q:{t:"B nuqtaga borish uchun O dan o'ngga 4, yuqoriga 1 qadam yurdik. B ning koordinatalari?",opts:["B(1; 4)","B(4; 1)","B(5; 0)","B(4; 4)"],ok:1,why:"Avval o'ngga (x = 4), keyin yuqoriga (y = 1).",hint:"Qavs ichida birinchi qaysi yo'nalish yoziladi?",full:"Birinchi son — o'ngga yurish (x = 4), ikkinchi son — yuqoriga (y = 1): B(4; 1). B(1; 4) — bu o'ngga 1, yuqoriga 4, boshqa nuqta."},
 tn:"«Avval yo'lak bo'ylab, keyin zinadan yuqoriga» — bu ibora tartibni eslab qolishga yordam beradi."},
{h:"Nuqtani o'zingiz yasang",sum:"M(5; 4) ni yasash: O dan o'ngga 5, keyin yuqoriga 4.",a:"m03",
 start:function(){h10grid({tap:h10t3});h10msg('M(5; 4) nuqtani to‘rda bosing')},fin:function(){h10grid({segs:[[0,0,5,0,C.blue,1],[5,0,5,4,C.bad,1]],pts:[[5,4,'M(5; 4)',C.ok]]});h10msg('✓ M(5; 4)')},
 act:function(c,done){S.d3=done},
 html:"<p><b>M(5; 4)</b> nuqtani yasang: to'rdagi kerakli tugunni bosing.</p>",
 after:"<p>To'g'ri! O dan <b>o'ngga 5</b> (x = 5), keyin <b>yuqoriga 4</b> (y = 4). Tekshirish: nuqtadan pastga tushsak x o'qida 5, chapga yursak y o'qida 4 bo'ladi.</p>",
 q:{t:"N nuqtadan pastga tushsak x o'qida 7, chapga yursak y o'qida 3 chiqadi. N ning koordinatalari?",opts:["N(3; 7)","N(7; 3)","N(10; 0)","N(7; 7)"],ok:1,why:"Pastdagi son (x o'qidagi) birinchi yoziladi.",hint:"x o'qidagi son qavsda nechanchi o'rinda yoziladi?",full:"x o'qidagi son (7) birinchi, y o'qidagi son (3) ikkinchi yoziladi: N(7; 3). N(3; 7) — sonlar o'rni almashib qolgan, bu boshqa nuqta."},
 tn:"Bola nuqtani qo'ygach, teskari tekshirsin: nuqtadan o'qlarga kesik chiziq (proyeksiya) tushirib, sonlarni o'qisin."},
{h:"Tuzoq: (2; 5) va (5; 2)",sum:"Sonlar o'rnini almashtirsak, boshqa nuqta chiqadi: (2; 5) ≠ (5; 2).",a:"m04",
 start:function(){h10grid({tap:h10t4});h10msg('B(2; 5) nuqtani bosing')},fin:function(){h10grid({pts:[[2,5,'B(2; 5)',C.ok],[5,2,'(5; 2)',C.grey]],segs:[[0,0,2,0,C.blue,1],[2,0,2,5,C.bad,1]]});h10msg('B(2; 5) va (5; 2) — <b>har xil</b> nuqtalar')},
 act:function(c,done){S.d4=done},
 html:"<p>Ehtiyot bo'ling! <b>B(2; 5)</b> nuqtani bosing.</p>",
 after:"<p>B(2; 5) — o'ngga 2, yuqoriga 5. (5; 2) esa — o'ngga 5, yuqoriga 2: bu <b>boshqa nuqta</b>. Koordinatalarda <b>tartib muhim</b>: birinchi — x, ikkinchi — y.</p>",
 q:{t:"Qaysi ikki yozuv bitta nuqtani bildiradi?",opts:["(3; 1) va (1; 3)","(4; 2) va (4; 2)","(2; 4) va (4; 2)","(0; 5) va (5; 0)"],ok:1,why:"Faqat tartibi ham bir xil bo'lsa, nuqta bir xil.",hint:"Sonlar o'rnini almashtirsak, nuqta o'zgaradimi?",full:"Bir nuqtani faqat bir xil juftlik bildiradi: (4; 2) va (4; 2). Qolgan juftliklarda sonlar o'rni almashgan — ular har xil nuqtalar."},
 tn:"Ikki bolani doskaga chiqaring: biri (2; 5), ikkinchisi (5; 2) ni yassin — ikki nuqta turli joyda chiqishi tuzoqni yaxshi ko'rsatadi."},
{h:"O'qlardagi nuqtalar",sum:"x o'qidagi nuqtada y = 0, y o'qidagi nuqtada x = 0.",a:"m05",
 start:function(){h10grid();h10msg('Tugmalarni bosib, o‘qlardagi nuqtalarni ko‘ring')},fin:function(){h10grid({pts:[[4,0,'K(4; 0)',C.blue],[0,3,'L(0; 3)',C.bad],[0,0,'O(0; 0)',C.ok]]});h10msg('K(4; 0) — x o‘qida, L(0; 3) — y o‘qida')},
 btns:[["K(4; 0)",function(c,done){h10grid({pts:[[4,0,'K(4; 0)',C.blue]]});h10msg('Yuqoriga 0 qadam — nuqta <b>x o‘qida</b> qoladi');mvK(done,3)}],["L(0; 3)",function(c,done){h10grid({pts:[[0,3,'L(0; 3)',C.bad]]});h10msg('O‘ngga 0 qadam — nuqta <b>y o‘qida</b>');mvK(done,3)}],["O(0; 0)",function(c,done){h10grid({pts:[[0,0,'O(0; 0)',C.ok]]});h10msg('Ikkalasi 0 — koordinatalar boshi');mvK(done,3)}]],g3:1,
 html:"<p>Ba'zi nuqtalar o'qning o'zida yotadi. Uchala tugmani bosing:</p>",
 after:"<p>Agar <b>y = 0</b> bo'lsa, nuqta <b>x o'qida</b> yotadi: (4; 0). Agar <b>x = 0</b> bo'lsa — <b>y o'qida</b>: (0; 3). Ikkalasi 0 — bu O.</p>",
 q:{t:"P(0; 5) nuqta qayerda yotadi?",opts:["x o'qida","y o'qida","O nuqtada","O'qlarda emas"],ok:1,why:"x = 0 — o'ngga yurmaymiz, faqat yuqoriga 5.",hint:"O'ngga necha qadam yuramiz?",full:"x = 0 — o'ngga yurilmaydi, faqat yuqoriga 5 qadam: nuqta y o'qida. x o'qidagi nuqtalarda ikkinchi son (y) 0 bo'ladi, masalan (5; 0)."},
 tn:"Ko'p bolalar (0; 3) ni x o'qiga 3 ga qo'yadi. Har doim «o'ngga 0» ni ovoz chiqarib aytdiring."},
{h:"Nuqtalarni tutashtirib shakl yasaymiz",sum:"Bir xil y li nuqtalar yotiq, bir xil x li nuqtalar tik kesma bilan tutashadi.",a:"m06",
 start:function(){startPh(P6P)},fin:function(){S.ph=2;P6P[2]()},
 html:"<p>4 ta nuqtani belgilab, ketma-ket tutashtiramiz. Qanday shakl chiqadi?</p>",
 btns:[phaser(P6P)],
 after:"<p>A(1; 1) va B(6; 1) da <b>y bir xil</b> — AB yotiq, uzunligi <b>6 − 1 = 5</b> katak. B(6; 1) va C(6; 4) da <b>x bir xil</b> — BC tik, uzunligi <b>4 − 1 = 3</b> katak. Shakl — to'g'ri to'rtburchak, perimetri 5 + 3 + 5 + 3 = 16 katak.</p>",
 q:{t:"E(2; 3) va F(8; 3) nuqtalar orasidagi kesma necha katak?",opts:["6","10","5","3"],ok:0,why:"y bir xil, kesma yotiq: 8 − 2 = 6.",hint:"Qaysi koordinata bir xil? Qolgan ikki sonni qanday solishtiramiz?",full:"y = 3 ikkalasida bir xil — kesma yotiq, uzunligi x lar ayirmasi: 8 − 2 = 6 katak. 10 — x larni qo'shib yuborish (2 + 8), 5 — nuqtalarni sanab, kataklarni emas."},
 tn:"Bolalar daftarda o'z harfining (masalan, «L», «П») uchlarini koordinatalar bilan yozib, qo'shnisiga yasatishi mumkin."},
{h:"Kvadratni to'ldiring",sum:"Kvadratning to'rtinchi uchi: qolgan uchlardan x ni bittasidan, y ni boshqasidan olamiz.",a:"m07",
 start:function(){h10grid({tap:h10t7,segs:[[2,1,5,1],[5,1,5,4]],pts:[[2,1,'A'],[5,1,'B'],[5,4,'C']]});h10msg('A(2; 1), B(5; 1), C(5; 4). D ni bosing')},fin:function(){h10grid({segs:[[2,1,5,1],[5,1,5,4],[5,4,2,4],[2,4,2,1]],pts:[[2,1,'A'],[5,1,'B'],[5,4,'C'],[2,4,'D(2; 4)',C.ok]]});h10msg('✓ D(2; 4) — ABCD kvadrat (tomoni 3 katak)')},
 act:function(c,done){S.d7=done},
 html:"<p>ABCD kvadratning uchta uchi berilgan: <b>A(2; 1), B(5; 1), C(5; 4)</b>. To'rtinchi uchi <b>D</b> ni to'rdan toping va bosing.</p>",
 after:"<p>D nuqta A ning ustida (x = 2, A dagidek) va C ning chapida (y = 4, C dagidek): <b>D(2; 4)</b>. Tomonlari: 5 − 2 = 3 va 4 − 1 = 3 — teng, demak kvadrat.</p>",
 q:{t:"To'g'ri to'rtburchakning uchlari: (1; 2), (7; 2), (7; 5). To'rtinchi uchi qayerda?",opts:["(1; 5)","(5; 1)","(7; 1)","(2; 5)"],ok:0,why:"x ni (1; 2) dan, y ni (7; 5) dan olamiz.",hint:"To'rtinchi uch qaysi nuqtaning ustida, qaysi nuqtaning yonida bo'ladi?",full:"To'rtinchi uch (1; 2) ning ustida (x = 1) va (7; 5) ning yonida (y = 5): (1; 5). (5; 1) — sonlar o'rni almashgan."},
 tn:"Avval bolalarga uchta uchni daftarga yasating, keyin to'rtinchisini topishni so'rang — chizma o'zi javobni ko'rsatadi."},
{h:"Nuqtani siljitamiz",sum:"O'ngga siljisa x ortadi, yuqoriga siljisa y ortadi.",a:"m08",
 start:function(){S.px=1;S.py=1;h10mv();h10msg('P(1; 1) ni K(4; 3) ga olib boring')},fin:function(){S.px=4;S.py=3;h10grid({pts:[[4,3,'P = K(4; 3)',C.ok]],segs:[[1,1,4,1,C.blue,1],[4,1,4,3,C.bad,1]]});h10msg('O‘ngga 3: x 1 → 4. Yuqoriga 2: y 1 → 3')},
 btns:[["→ o'ngga 1",function(c,done){S.px++;h10s8(done)}],["↑ yuqoriga 1",function(c,done){S.py++;h10s8(done)},'u']],g2:1,
 html:"<p>Qizil nuqta <b>P(1; 1)</b> ni tugmalar bilan yashil nuqta <b>K(4; 3)</b> ga olib boring. Koordinatalar qanday o'zgarishini kuzating.</p>",
 after:"<p>O'ngga 1 qadam — <b>x</b> 1 ga ortadi, yuqoriga 1 qadam — <b>y</b> 1 ga ortadi. P(1; 1) → K(4; 3): o'ngga 4 − 1 = 3, yuqoriga 3 − 1 = 2 qadam.</p>",
 q:{t:"R(2; 3) nuqtani o'ngga 3, yuqoriga 1 qadam siljitdik. Yangi nuqta?",opts:["(5; 4)","(3; 6)","(5; 3)","(6; 3)"],ok:0,why:"x: 2 + 3 = 5, y: 3 + 1 = 4.",hint:"O'ngga siljish qaysi songa qo'shiladi?",full:"O'ngga 3 — x ga qo'shiladi: 2 + 3 = 5. Yuqoriga 1 — y ga: 3 + 1 = 4. Javob (5; 4). (3; 6) — siljishlarni noto'g'ri songa qo'shish."},
 tn:"Sinf polida (yoki doskada) katak chizib, bitta bolani «nuqta» qiling — sinf buyruq beradi: «o'ngga 2, yuqoriga 1»."},
{h:"Bilasizmi? Dekart va shaxmat taxtasi",sum:"Koordinatalar g'oyasini 1637-yilda fransuz olimi Rene Dekart kitobida bayon qilgan.",a:"m09",
 start:function(){h10grid({pts:[[3,2,'A(3; 2)']]});h10msg('A(3; 2): avval o‘ngga <b>3</b>, keyin yuqoriga <b>2</b>')},fin:function(){h10grid({pts:[[3,2,'A(3; 2)']]});h10msg('A(3; 2): avval o‘ngga <b>3</b>, keyin yuqoriga <b>2</b>')},
 html:"<p>📘 Fransuz olimi <b>Rene Dekart</b> 1637-yilda chop etilgan kitobida nuqtalarni sonlar yordamida yozish usulini bayon qilgan. Shuning uchun bunday koordinatalar <b>«Dekart koordinatalari»</b> deb ataladi.</p><p>♟ Shaxmat taxtasida ham koordinatalar bor: ustunlar <b>a–h</b> harflari, qatorlar <b>1–8</b> raqamlari bilan belgilanadi. «e4» — e ustun, 4-qator.</p><p>🎬 Kinoteatr chiptasida «7-qator, 12-o'rin» deb yoziladi — bu ham ikki son bilan joyni aytish.</p>",
 tn:"Sinfdagi partalarni «qator; o'rin» bo'yicha raqamlab, har bola o'z joyining koordinatasini aytsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){h10grid({pts:[[3,2,'A(3; 2)']]});h10msg('A(3; 2): avval o‘ngga <b>3</b>, keyin yuqoriga <b>2</b>')},fin:function(){h10grid({pts:[[3,2,'A(3; 2)']]});h10msg('A(3; 2): avval o‘ngga <b>3</b>, keyin yuqoriga <b>2</b>')},
 html:"<div class='memo'><ul><li><b>Koordinata burchagi</b>: x o'qi (o'ngga) va y o'qi (yuqoriga), boshi <b>O(0; 0)</b>.</li><li><b>A(3; 2)</b>: avval o'ngga 3 (x), keyin yuqoriga 2 (y).</li><li>Tartib muhim: (2; 5) ≠ (5; 2).</li><li>y = 0 — nuqta x o'qida; x = 0 — nuqta y o'qida.</li><li>y bir xil — kesma yotiq, uzunligi x lar ayirmasi.</li><li>x bir xil — kesma tik, uzunligi y lar ayirmasi.</li><li>O'ngga siljish x ni, yuqoriga siljish y ni oshiradi.</li></ul></div>",
 tn:"Keyingi darsni «Men o'ylagan nuqta» o'yini bilan boshlang: o'qituvchi koordinata aytadi, bolalar daftarda belgilaydi."}
];
function h10t3(x,y){if(x===5&&y===4){h10grid({segs:[[0,0,5,0,C.blue,1],[5,0,5,4,C.bad,1]],pts:[[5,4,'M(5; 4)',C.ok]]});h10msg('✓ M(5; 4)');if(S.d3){var d=S.d3;S.d3=null;d()}}else if(S.d3){h10grid({tap:h10t3,pts:[[x,y,'('+x+'; '+y+')',C.grey]]});h10msg(x===4&&y===5?'Bu (4; 5) — sonlar o‘rni almashgan. Avval o‘ngga <b>5</b>':'Bu ('+x+'; '+y+'). Kerak: o‘ngga <b>5</b>, yuqoriga <b>4</b>')}}
function h10t4(x,y){if(x===2&&y===5){STEPS[3].fin();if(S.d4){var d=S.d4;S.d4=null;d()}}else if(S.d4){h10grid({tap:h10t4,pts:[[x,y,'('+x+'; '+y+')',C.grey]]});h10msg(x===5&&y===2?'Tuzoq! Bu <b>(5; 2)</b>: o‘ngga 5, yuqoriga 2. B(2; 5) da avval o‘ngga <b>2</b>':'Bu ('+x+'; '+y+'). B(2; 5): o‘ngga 2, yuqoriga 5')}}
function h10t7(x,y){if(x===2&&y===4){STEPS[6].fin();if(S.d7){var d=S.d7;S.d7=null;d()}}else if(S.d7){h10grid({tap:h10t7,segs:[[2,1,5,1],[5,1,5,4]],pts:[[2,1,'A'],[5,1,'B'],[5,4,'C'],[x,y,'('+x+'; '+y+')',C.grey]]});h10msg(x===4&&y===2?'(4; 2) — sonlar o‘rni almashgan':'('+x+'; '+y+') — kvadrat chiqmaydi. D A ning ustida, C ning chapida')}}
function h10s8(done){if(S.px===4&&S.py===3){h10mv();h10msg('✓ Yetib keldik! P(4; 3) = K');done();return}if(S.px>4||S.py>3){h10msg('O‘tib ketdingiz ('+S.px+'; '+S.py+'). Qaytadan P(1; 1) dan');S.px=1;S.py=1;setTimeout(h10mv,10);return}h10mv();h10msg('P('+S.px+'; '+S.py+') → K(4; 3)')}
var PROBS=[
{t:"A(4; 1) nuqtaga borish uchun O dan avval qayerga yuramiz?",o:["O'ngga 4","Yuqoriga 4","O'ngga 1","Yuqoriga 1"],k:0,s:"Birinchi son — o'ngga: 4."},
{t:"O'ngga 2, yuqoriga 6 qadam. Nuqta koordinatalari?",o:["(2; 6)","(6; 2)","(8; 0)","(2; 2)"],k:0,s:"Avval x = 2, keyin y = 6."},
{t:"Koordinatalar boshi qanday belgilanadi?",o:["O(0; 0)","O(1; 1)","O(1; 0)","O(0; 1)"],k:0,s:"O — (0; 0)."},
{t:"(6; 0) nuqta qayerda yotadi?",o:["x o'qida","y o'qida","O nuqtada","O'qlarda emas"],k:0,s:"y = 0 — x o'qida."},
{t:"(0; 4) nuqta qayerda yotadi?",o:["y o'qida","x o'qida","O nuqtada","O'qlarda emas"],k:0,s:"x = 0 — y o'qida."},
{t:"Qaysi nuqta x o'qida yotadi?",o:["(3; 0)","(0; 3)","(3; 3)","(1; 3)"],k:0,s:"x o'qida y = 0."},
{t:"M(7; 2) nuqtadan x o'qiga tushsak, qaysi songa tushamiz?",o:["7","2","9","5"],k:0,s:"x o'qidagi son — birinchi koordinata 7."},
{t:"(3; 5) va (5; 3) — bitta nuqtami?",o:["Yo'q, ular har xil","Ha, bitta nuqta","Ha, chunki sonlar bir xil","Faqat O da bir xil"],k:0,s:"Tartib muhim: o'ngga 3 yoki o'ngga 5 — har xil joy."},
{t:"A(2; 4) va B(9; 4) orasidagi kesma necha katak?",o:["7","11","6","8"],k:0,s:"y bir xil, 9 − 2 = 7."},
{t:"C(5; 1) va D(5; 6) orasidagi kesma necha katak?",o:["5","7","6","1"],k:0,s:"x bir xil, 6 − 1 = 5."},
{t:"P(3; 2) ni o'ngga 4 qadam siljitdik. Yangi nuqta?",o:["(7; 2)","(3; 6)","(7; 6)","(4; 2)"],k:0,s:"x: 3 + 4 = 7, y o'zgarmaydi."},
{t:"Q(6; 5) ni chapga 2, pastga 3 qadam siljitdik. Yangi nuqta?",o:["(4; 2)","(8; 8)","(3; 3)","(2; 4)"],k:0,s:"x: 6 − 2 = 4, y: 5 − 3 = 2."},
{t:"Qaysi ikki nuqta bitta tik chiziqda yotadi?",o:["(4; 1) va (4; 5)","(1; 4) va (5; 4)","(4; 1) va (1; 4)","(2; 3) va (3; 2)"],k:0,s:"Tik chiziqda x bir xil: 4 va 4."},
{t:"To'g'ri to'rtburchak uchlari: (1; 1), (5; 1), (5; 3). To'rtinchi uch?",o:["(1; 3)","(3; 1)","(3; 5)","(5; 5)"],k:0,s:"x ni (1; 1) dan, y ni (5; 3) dan: (1; 3)."},
{t:"Kvadrat uchlari: (2; 2), (6; 2), (6; 6). To'rtinchi uch?",o:["(2; 6)","(6; 2)","(4; 4)","(2; 4)"],k:0,s:"x ni (2; 2) dan, y ni (6; 6) dan: (2; 6)."},
{t:"(1; 1), (6; 1), (6; 4), (1; 4) uchli to'g'ri to'rtburchakning perimetri necha katak?",o:["16","15","8","10"],k:0,s:"Tomonlar 5 va 3: 5 + 3 + 5 + 3 = 16."},
{t:"(0; 0), (4; 0), (4; 3), (0; 3) uchli to'g'ri to'rtburchak ichida nechta katak bor?",o:["12","14","7","16"],k:0,s:"4 × 3 = 12 katak."},
{t:"Ali (3; 2) da, Vali undan 2 qadam o'ngda va 3 qadam yuqorida. Vali qayerda?",o:["(5; 5)","(6; 4)","(5; 2)","(3; 5)"],k:0,s:"x: 3 + 2 = 5, y: 2 + 3 = 5."},
{t:"Nuqtaning ikkala koordinatasi teng va yig'indisi 8. Bu qaysi nuqta?",o:["(4; 4)","(8; 8)","(2; 6)","(8; 0)"],k:0,s:"Teng sonlar, yig'indisi 8: 4 + 4."},
{t:"Shaxmatda «c3» katagi: c — 3-ustun. Koordinatalarda u qanday yoziladi?",o:["(3; 3)","(3; 1)","(1; 3)","(c; 3)"],k:0,s:"c — 3-ustun (a, b, c), 3 — 3-qator: (3; 3)."}
];
function PRACT_STAGE(){h10grid({pts:[[3,2,'A(3; 2)']]})}
var PREP_DATA={teach:["Koordinata burchagi: x va y o'qlari, O(0; 0).","Nuqtaning koordinatalari: (x; y) — avval o'ngga, keyin yuqoriga.","Nuqta yasash, o'qlardagi nuqtalar, nuqtani siljitish.","Nuqtalarni tutashtirib shakl yasash, to'rtinchi uchni topish."],
 mist:["Koordinatalar o'rnini almashtiradi: (2; 5) o'rniga (5; 2).","(0; 3) ni x o'qiga qo'yadi.","Kesma uzunligini sonlarni qo'shib topadi.","Tugun o'rniga katak ichiga nuqta qo'yadi."],
 need:["Katakli daftar, rangli qalam.","Doskada katakli to'r (yoki plakat).","Shaxmat taxtasi rasmi (ixtiyoriy)."],
 board:["Koordinata burchagi: <span class='w2'>x</span> → , <span class='w2'>y</span> ↑ , O(0; 0).","A(3; 2): o'ngga 3, yuqoriga 2.","Tuzoq: (2; 5) ≠ (5; 2).","(4; 0) — x o'qida, (0; 3) — y o'qida.","AB: y bir xil → 6 − 1 = 5 katak.","Kvadratning 4-uchi.","Siljitish: x + o'ngga, y + yuqoriga."]};
