// --- k2c13_ yordamchilari ---
function k2c13_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c13_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c13_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c13_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C13',TITLE='2-sinf · 10 va 100 ga ko‘paytirish va bo‘lish';
// xonalar jadvali: raqamlar xonalar bo'ylab suriladi
function k2c13_pv(digits,shift,note){clear();var g=S.g,names=['Minglar','Yuzlar','O‘nlar','Birlar'],x0=30,w=75;
 for(var i=0;i<4;i++){E('rect',{x:x0+i*w,y:24,width:w-4,height:96,rx:10,fill:['#f3e8ff','#fde6c8','#fdf0e1','#e1f4f2'][i],stroke:'#dde5ee'},g);T(g,x0+i*w+w/2-2,40,names[i],{'font-size':11,'font-weight':800,fill:'#5b6b7b'})}
 var s=String(digits),n=s.length;for(var k=0;k<n;k++){var col=4-n+k-shift;if(col<0)continue;T(g,x0+col*w+w/2-2,96,s[k],{'font-size':38,'font-weight':800,fill:'#1d2b3a'})}
 for(var z=0;z<shift;z++){var c2=3-z;T(g,x0+c2*w+w/2-2,96,'0',{'font-size':38,'font-weight':800,fill:C.ok})}
 if(note)T(g,180,148,note,{'font-size':13,'font-weight':800,fill:C.blue})}
function k2c13_pvDiv(digits,shift,note){clear();var g=S.g,names=['Minglar','Yuzlar','O‘nlar','Birlar'],x0=30,w=75;
 for(var i=0;i<4;i++){E('rect',{x:x0+i*w,y:24,width:w-4,height:96,rx:10,fill:['#f3e8ff','#fde6c8','#fdf0e1','#e1f4f2'][i],stroke:'#dde5ee'},g);T(g,x0+i*w+w/2-2,40,names[i],{'font-size':11,'font-weight':800,fill:'#5b6b7b'})}
 var s=String(digits),n=s.length;for(var k=0;k<n-shift;k++){var col=4-(n-shift)+k;T(g,x0+col*w+w/2-2,96,s[k],{'font-size':38,'font-weight':800,fill:'#1d2b3a'})}
 if(note)T(g,180,148,note,{'font-size':13,'font-weight':800,fill:C.blue})}
var P1=[function(){k2c13_pv(7,0,'7 ta birlik');k2c13_big('7 · 10 = ?')},function(){k2c13_pv(7,1,'7 bir xona chapga — o\u2018nlarga o\u2018tdi');k2c13_big('7 · 10 = <b>70</b>','10 marta ko‘p: har bir birlik o‘nlikka aylandi')}];
var P2=[function(){k2c13_pv(7,0,'7 ta birlik');k2c13_big('7 · 100 = ?')},function(){k2c13_pv(7,1,'');k2c13_big('7 · 10 = 70','100 = 10 · 10 — ikki marta 10 ga')},function(){k2c13_pv(7,2,'7 yuzlarga o‘tdi, ikki 0 paydo bo‘ldi');k2c13_big('7 · 100 = <b>700</b>')}];
var P3=[function(){k2c13_pv(8,1,'80 = 8 ta o‘nlik');k2c13_big('80 : 10 = ?')},function(){k2c13_pvDiv('80',1,'Raqamlar o‘ngga suriladi, oxirgi 0 tushib qoladi');k2c13_big('80 : 10 = <b>8</b>','10 marta kam')}];
var P4=[function(){k2c13_pv(34,0,'34');k2c13_big('34 · 10 = ?')},function(){k2c13_pv(34,1,'3 → yuzlar, 4 → o‘nlar');k2c13_big('34 · 10 = <b>340</b>','Har bir raqam bitta xona chapga')},function(){k2c13_pvDiv('340',1,'Teskarisi');k2c13_big('340 : 10 = <b>34</b>')}];
var P6=[function(){k2c13_big('x · 10 = 900. &nbsp; x · 100 = ?','Shoshilmang: x ni topish shart emas!');k2c13_pv(900,0,'x · 10 = 900')},
 function(){k2c13_pv(9000,0,'x · 100 = (x · 10) · 10 = 900 · 10');k2c13_big('x · 100 = (x · 10) · 10','100 = 10 · 10')},
 function(){k2c13_pv(9000,0,'= 9000');k2c13_big('x · 100 = 900 · 10 = <b>9000</b> &nbsp; (x = 90)')}];
var STEPS=[
{h:"10 ga ko'paytirish",sum:"7 · 10 = 70: raqam bir xona chapga suriladi, birlar xonasiga 0 yoziladi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>10 ga ko'paytirish — har bir birlikni o'nlikka aylantirish. Xonalar jadvalida kuzating:</p>",btns:[phaser(P1)],
 after:"<p>10 ga ko'paytirganda raqam <b>bir xona chapga</b> suriladi, bo'sh qolgan birlar xonasiga <b>0</b> yoziladi: 7 · 10 = 70, 25 · 10 = 250. «Oxiriga 0 qo'shiladi» — bu shu siljishning qisqa aytilishi.</p>",
 q:{t:"9 · 10 nechaga teng?",opts:["90","19","900","910"],ok:0,why:"9 bir xona chapga: 90.",hint:"10 ga ko'paytirsak, oxiriga nechta 0 qo'shiladi?",full:"9 · 10 = 90. «19» — qo'shilgan, «900» — 100 ga ko'paytirilgan."},
 tn:"Raqam kartochkasini xonalar jadvalida qo'l bilan chapga suring — «0 qo'shish» sehr emas, siljish ekanini ko'rsating."},
{h:"100 ga ko'paytirish",sum:"7 · 100 = 700: ikki xona chapga, ikkita 0. 100 = 10 · 10.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>100 = 10 · 10. Demak 100 ga ko'paytirish — <b>ikki marta</b> 10 ga ko'paytirish.</p>",btns:[phaser(P2)],
 after:"<p>100 ga ko'paytirganda raqam <b>ikki xona chapga</b> suriladi, ikkita 0 paydo bo'ladi: 7 · 100 = 700, 6 · 100 = 600.</p>",
 q:{t:"5 · 100 nechaga teng?",opts:["50","500","5000","105"],ok:1,why:"Ikki xona chapga: 500.",hint:"100 da nechta 0 bor?",full:"5 · 100 = 500 (ikkita 0). «50» — 10 ga ko'paytirilgan, «5000» — uchta 0 qo'yilgan."},
 tn:"Pul bilan: 100 so'mlik tangadan 5 tasi — 500 so'm."},
{h:"10 ga bo'lish",sum:"80 : 10 = 8: raqamlar bir xona o'ngga suriladi, oxirgi 0 tushib qoladi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Bo'lish — ko'paytirishning teskarisi. 10 ga bo'lsak, raqamlar qaysi tomonga suriladi?</p>",btns:[phaser(P3)],
 after:"<p>10 ga bo'lganda raqamlar <b>bir xona o'ngga</b> suriladi: 80 : 10 = 8, 340 : 10 = 34. 100 ga bo'lganda — ikki xona: 600 : 100 = 6.</p>",
 q:{t:"600 : 100 nechaga teng?",opts:["60","6","6000","500"],ok:1,why:"Ikki xona o'ngga: 6.",hint:"100 ga bo'lsak, nechta 0 tushib qoladi?",full:"600 : 100 = 6 (ikkita 0 tushdi). «60» — 10 ga bo'lingan."},
 tn:"Bu yerda faqat 0 bilan tugaydigan sonlarni bo'lamiz (2-sinf darajasi)."},
{h:"Ikki xonali sonni 10 ga",sum:"34 · 10 = 340; 340 : 10 = 34. Har bir raqam bir xona suriladi.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>34 da ikkita raqam bor. 10 ga ko'paytirsak, ikkalasi ham bir xona chapga suriladi.</p>",btns:[phaser(P4)],
 after:"<p>34 · 10 = <b>340</b>: 3 o'nlik → 3 yuzlik, 4 birlik → 4 o'nlik. Ya'ni 34 ta o'nlik = 340.</p>",
 q:{t:"56 · 10 nechaga teng?",opts:["560","5610","506","66"],ok:0,why:"Har raqam bir xona chapga: 560.",hint:"Oxiriga bitta 0.",full:"56 · 10 = 560. «506» — 0 noto'g'ri joyga, «66» — 10 qo'shilgan."},
 tn:"Bolalar «56 ta o'nlik nechaga teng?» degan savolga javob bersin — bu xona tushunchasini mustahkamlaydi."},
{h:"Qaysi tomonga? Mashq",sum:"Ko'paytirish — chapga (kattalashadi), bo'lish — o'ngga (kichrayadi).",a:"m05",
 start:function(){k2c13_pv(45,0,'45');k2c13_big('Amalni tanlang')},fin:function(){k2c13_pv(45,2,'45 · 100 = 4500');k2c13_big('45 · 100 = 4500')},
 html:"<p>Amalni tanlang va raqamlar qayerga ketishini kuzating:</p>",
 btns:[["45 · 10",function(c,d){k2c13_pv(45,1,'45 · 10 = 450');k2c13_big('45 · 10 = <b>450</b>');mvK(d,3)}],["45 · 100",function(c,d){k2c13_pv(45,2,'45 · 100 = 4500');k2c13_big('45 · 100 = <b>4500</b>');mvK(d,3)}],["450 : 10",function(c,d){k2c13_pvDiv('450',1,'450 : 10 = 45');k2c13_big('450 : 10 = <b>45</b>');mvK(d,3)}],["900 : 100",function(c,d){k2c13_pvDiv('900',2,'900 : 100 = 9');k2c13_big('900 : 100 = <b>9</b>');mvK(d,3)}]],g2:1,
 after:"<p>Eslab qoling: <b>· 10, · 100 — chapga</b> (son kattalashadi), <b>: 10, : 100 — o'ngga</b> (son kichrayadi). Javobni chamalang: 45 · 100 «45 dan ancha katta» bo'lishi kerak.</p>",
 q:{t:"Qaysi tenglik NOTO'G'RI?",opts:["30 · 10 = 300","700 : 10 = 70","8 · 100 = 80","500 : 100 = 5"],ok:2,why:"8 · 100 = 800, 80 emas.",hint:"100 ga ko'paytirsak nechta 0 qo'shiladi?",full:"8 · 100 = 800. 80 bo'lsa — 10 ga ko'paytirilgan. Qolgan uchtasi to'g'ri."},
 tn:"«Chapga — ko'paytirish» qoidasini ikki qo'l bilan ko'rsating."},
{h:"Tuzoq: x ni topmasdan",sum:"x · 10 = 900 bo'lsa, x · 100 = 900 · 10 = 9000.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Bank savoli: «<b>x · 10 = 900</b> bo'lsa, <b>x · 100</b> ning qiymatini toping.» Ayyor yo'l bor!</p>",btns:[phaser(P6)],
 after:"<p>x · 100 — bu x · 10 ning yana 10 barobari. Shuning uchun <b>900 · 10 = 9000</b>. Tekshiruv: x = 90, 90 · 100 = 9000 ✓</p>",
 q:{t:"a · 100 = 600 bo'lsa, a · 10 nechaga teng?",opts:["60","6000","6","600"],ok:0,why:"a · 10 — a · 100 dan 10 marta kam: 600 : 10 = 60.",hint:"a · 10 kattami yoki a · 100?",full:"a · 10 = (a · 100) : 10 = 600 : 10 = 60. Tekshiruv: a = 6, 6 · 10 = 60 ✓."},
 tn:"Bu fikrlash «nisbat» tushunchasining boshlanishi. Bolalarni javobni ikkala yo'l bilan tekshirishga undang."},
{h:"Tuzoq: aralash amallar",sum:"800 : 10 · 6: chapdan o'ngga — 80 · 6 = 480.",a:"m07",
 start:function(){k2c13_big('800 : 10 · 6 = ?','Tartib: chapdan o‘ngga!');k2c13_pv(800,0,'800')},fin:function(){k2c13_pv(480,0,'480');k2c13_big('800 : 10 = 80, 80 · 6 = <b>480</b>')},
 html:"<p>Bank savoli: <b>800 : 10 · 6</b>. Ko'paytirish va bo'lish aralash kelsa — <b>chapdan o'ngga</b>.</p>",
 btns:[["▶ 1-amal",function(c,d){k2c13_pvDiv('800',1,'800 : 10 = 80');k2c13_big('800 : 10 = <b>80</b>');mvK(d,2)}],["▶ 2-amal",function(c,d){k2c13_pv(480,0,'80 · 6 = 480');k2c13_big('80 · 6 = <b>480</b>');mvK(d,2)}]],g2:1,
 after:"<p>Xato yo'l: avval 10 · 6 = 60, keyin 800 : 60 — bu noto'g'ri, tartib buziladi. To'g'ri: chapdan o'ngga — <b>480</b>.</p>",
 q:{t:"7000 : 100 − 600 : 10 nechaga teng?",opts:["10","64","640","1"],ok:0,why:"70 − 60 = 10.",hint:"Avval ikkala bo'lishni bajaring, keyin ayiring.",full:"7000 : 100 = 70, 600 : 10 = 60, 70 − 60 = 10. Bo'lish ayirishdan oldin bajariladi."},
 tn:"Amallar tartibi 2B7 da o'tilgan — bu yerda takrorlanadi."},
{h:"Bilasizmi? O'nli sanoq",sum:"Biz o'nli sanoq tizimida yozamiz — shuning uchun 10 ga ko'paytirish shunchaki siljish. Rim raqamlarida bunday emas.",a:"m08",
 start:function(){k2c13_pv(7,0,'');k2c13_big('VII · 10 = Lk2c13_')},fin:function(){k2c13_pv(7,1,'');k2c13_big('VII · 10 = Lk2c13_')},
 html:"<p>🔟 Biz sonlarni <b>o'nli</b> tizimda yozamiz: har bir xona o'ngdagisidan 10 marta katta. Shuning uchun 10 ga ko'paytirish — shunchaki raqamlarni bir xona surish!</p><p>🏛 Rim raqamlarida esa bunday qulaylik yo'q: VII · 10 = Lk2c13_ — butunlay boshqa belgilar. Shuning uchun rimliklar hisob-kitobni toshchalar (abak) bilan qilgan.</p><p>⭐ O'nli joylashuvli yozuvni dunyoga yoyishda vatandoshimiz <b>al-Xorazmiy</b>ning hisob kitobi katta rol o'ynagan.</p>",
 tn:"Bolalarga «10 ga ko'paytirishni rim raqamlarida qilib ko'ring» deb qiziqarli topshiriq bering."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){k2c13_pv(34,1,'34 · 10 = 340');k2c13_big('34 · 10 = 340')},fin:function(){k2c13_pv(34,1,'34 · 10 = 340');k2c13_big('34 · 10 = 340')},
 html:"<div class='memo'><ul><li><b>· 10</b> — raqamlar bir xona chapga, oxiriga 0: 7 · 10 = 70, 34 · 10 = 340.</li><li><b>· 100</b> — ikki xona chapga, ikkita 0: 7 · 100 = 700.</li><li><b>: 10</b> — bir xona o'ngga, oxirgi 0 tushadi: 80 : 10 = 8.</li><li><b>: 100</b> — ikki xona o'ngga: 600 : 100 = 6.</li><li>x · 10 = 900 → x · 100 = 9000 (yana 10 barobar).</li><li>Aralash amallar — chapdan o'ngga.</li></ul></div>",
 tn:"Keyingi darsni «37 · 100 − 37 · 10» bilan boshlang (3700 − 370 = 3330)."}
];
var PROBS=[
{t:"6 · 10 nechaga teng?",o:["60","16","600","610"],k:0,s:"Oxiriga bitta 0: 60."},
{t:"4 · 100 nechaga teng?",o:["400","40","4000","104"],k:0,s:"Ikkita 0: 400."},
{t:"90 : 10 nechaga teng?",o:["9","90","900","80"],k:0,s:"Bir xona o'ngga: 9."},
{t:"300 : 100 nechaga teng?",o:["3","30","300","200"],k:0,s:"Ikki xona o'ngga: 3."},
{t:"27 · 10 nechaga teng?",o:["270","2710","207","37"],k:0,s:"27 · 10 = 270."},
{t:"560 : 10 nechaga teng?",o:["56","5600","560","506"],k:0,s:"560 : 10 = 56."},
{t:"Qaysi tenglik to'g'ri?",o:["40 · 10 = 400","40 · 10 = 4000","40 · 10 = 50","40 · 10 = 140"],k:0,s:"40 · 10 = 400."},
{t:"x · 10 = 900 bo'lsa, x · 100 ning qiymatini toping.",o:["9000","90","900","90000"],k:0,s:"x · 100 = 900 · 10 = 9000."},
{t:"Hisoblang: 800 : 10 · 6",o:["480","86","48","4800"],k:0,s:"800 : 10 = 80, 80 · 6 = 480."},
{t:"Hisoblang: 270 : 10 · 3",o:["81","9","810","71"],k:0,s:"270 : 10 = 27, 27 · 3 = 81."},
{t:"Hisoblang: 700 : 100 · 10",o:["70","7","700","7000"],k:0,s:"700 : 100 = 7, 7 · 10 = 70."},
{t:"Hisoblang: 7000 : 100 − 600 : 10",o:["10","64","1","640"],k:0,s:"70 − 60 = 10."},
{t:"Hisoblang: 200 · 3 + 30 · 10",o:["900","600","630","6300"],k:0,s:"600 + 300 = 900."},
{t:"Bir pachkada 10 ta daftar. 45 ta pachkada nechta daftar?",o:["450","55","4500","405"],k:0,s:"45 · 10 = 450."},
{t:"300 · 3 · 10 = 30 · □. □ nechaga teng?",o:["300","90","30","3000"],k:0,s:"300 · 3 · 10 = 9000, 9000 : 30 = 300."},
{t:"Hisoblang: (800 · 10 − 4000) : 100",o:["40","4","400","4000"],k:0,s:"8000 − 4000 = 4000, 4000 : 100 = 40."},
{t:"Qaysi son 100 ga bo'linganda 8 chiqadi?",o:["800","80","8000","108"],k:0,s:"8 · 100 = 800."},
{t:"Hisoblang: 3000 : 100 : 10 · 100",o:["300","3000","30","3"],k:0,s:"30 : 10 = 3, 3 · 100 = 300."},
{t:"Hisoblang: 37 · 100 − 37 · 10",o:["3330","370","3700","3663"],k:0,s:"3700 − 370 = 3330."},
{t:"a · 100 = 600 bo'lsa, a · 10 nechaga teng?",o:["60","6000","6","600"],k:0,s:"600 : 10 = 60."}
];
function PRACT_STAGE(){k2c13_pv(34,1,'· 10 — chapga, : 10 — o‘ngga');k2c13_msg('Chapga — ko‘paytirish, o‘ngga — bo‘lish')}
var PREP_DATA={teach:["10 va 100 ga ko'paytirish — raqamlarni xonalar bo'ylab chapga surish.","10 va 100 ga bo'lish (0 bilan tugaydigan sonlar) — o'ngga surish.","Ikki xonali sonni 10 ga ko'paytirish va teskarisi.","Tuzoqlar: x · 10 = 900 → x · 100; aralash amallar tartibi."],
 mist:["0 larni noto'g'ri sanaydi (8 · 100 = 80).","Bo'lishda 0 ni olib tashlash o'rniga qo'shadi.","Aralash amallarda tartibni buzadi.","«Oxiriga 0» ni bo'lishda ham qo'llaydi."],
 need:["Xonalar jadvali (4 ustun) va raqam kartochkalari.","10 va 100 so'mlik o'yin pullari."],
 board:["Jadval: <span class='w2'>Minglar | Yuzlar | O'nlar | Birlar</span>.","<span class='w2'>7 · 10 = 70</span>, <span class='w2'>7 · 100 = 700</span>.","<span class='w2'>80 : 10 = 8</span>, <span class='w2'>600 : 100 = 6</span>.","<span class='w2'>34 · 10 = 340</span>.","<span class='w2'>x · 10 = 900 → x · 100 = 9000</span>."]};
