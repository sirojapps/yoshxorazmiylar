var CODE='3J04',TITLE="3-sinf · Gugurt cho'plari bilan masalalar";
function j4Row(n){clear();j3Mt(j3SqRow(n,20,46,Math.min(40,310/n)));j3Msg(n+' ta kvadrat — <b>'+(3*n+1)+'</b> ta cho‘p'+(n>1?' = 4 + 3 · '+(n-1):''))}
function j4Tri(n){clear();var L=Math.min(46,300/((n+1)/2)),x0=22,y=110,s=[];for(var i=0;i<n;i++){var up=i%2===0,k=Math.floor(i/2);if(up){var a=[x0+k*L,y],b=[x0+k*L+L/2,y-L*0.87],c=[x0+(k+1)*L,y];s.push([a[0],a[1],b[0],b[1]]);s.push([b[0],b[1],c[0],c[1]]);s.push([a[0],a[1],c[0],c[1]])}else{s.push([x0+k*L+L/2,y-L*0.87,x0+(k+1)*L+L/2,y-L*0.87])}}j3Mt(s);j3Msg(n+' ta uchburchak — <b>'+(2*n+1)+'</b> ta cho‘p')}
var P3=[function(){clear();j3Mt(j3SqGrid(2,2,40,30,52));j3Msg('2 × 2 to‘r: gorizontal 3 qator × 2 = 6, vertikal 3 ustun × 2 = 6 → <b>12</b>')},
 function(){clear();j3Mt(j3SqGrid(3,3,130,22,40));j3Msg('3 × 3 to‘r: gorizontal 4 qator × 3 = 12, vertikal 4 ustun × 3 = 12')},
 function(){clear();j3Mt(j3SqGrid(3,3,130,22,40));T(S.g,70,90,'12 + 12',{'font-size':20,'font-weight':800,fill:C.blue});T(S.g,70,118,'= 24',{'font-size':22,'font-weight':800,fill:C.ok});j3Msg('Jami <b>24</b> ta cho‘p. «9 · 4 = 36» — xato: ichki cho‘plar ikki marta sanaladi')}];
function j4Diag(show){clear();var L=52,x0=40,y0=30,all=j3SqGrid(2,2,x0,y0,L),keep=[];
 // diagonal kvadratlar: chap-yuqori va o'ng-past
 all.forEach(function(s){var mx=(s[0]+s[2])/2,my=(s[1]+s[3])/2,inA=(mx>=x0&&mx<=x0+L&&my>=y0&&my<=y0+L),inB=(mx>=x0+L&&mx<=x0+2*L&&my>=y0+L&&my<=y0+2*L);if(show&&!(inA||inB))s[4]='#e9e2d6',s[5]='#e9e2d6';keep.push(s)});j3Mt(keep);
 if(show)T(S.g,270,96,'4 ta olindi',{'font-size':14,'font-weight':800,fill:C.bad})}
var P5=[function(){j3Lines(['IX − I = X','9 − 1 = 10 ?  [Noto‘g‘ri!]'],{fs:24,lh:40});j3Msg('Bitta cho‘pni ko‘chirib, tenglikni to‘g‘ri qiling')},
 function(){j3Lines(['[I]X − I = X  →  X − I = [I]X'],{fs:20});j3Msg('Chapdagi IX dan I ni olib, o‘ngdagi X ning chap tomoniga qo‘yamiz')},
 function(){j3Lines(['X − I = IX','10 − 1 = 9 ✓'],{fs:26,lh:40});j3Msg('Bitta cho‘p ko‘chdi — tenglik to‘g‘ri bo‘ldi')}];
var STEPS=[
{h:"Kvadratlar qatori: qonuniyat",sum:"n ta kvadrat qatori: 4 + 3·(n−1) = 3n + 1 cho'p. 10 ta kvadrat — 31.",a:"m01",
 start:function(){S.n=1;j4Row(1)},fin:function(){j4Row(4)},
 html:"<p>Gugurt cho'plaridan kvadratlarni yonma-yon terib boramiz. Har yangi kvadratga nechta cho'p kerak? Tugmani bosib kuzating (kamida 3 marta).</p>",
 btns:[["+ 1 kvadrat",function(c,done){if(S.n<7){S.n++;j4Row(S.n)}mvK(done,3)}]],
 after:"<p>Birinchi kvadratga <b>4</b> ta, keyingi har biriga faqat <b>3</b> ta cho'p kerak — chunki bitta tomoni oldingisi bilan umumiy. Qoida: <b>4 + 3 · (n − 1)</b>, ya'ni <b>3 · n + 1</b>.</p>",
 q:{t:"10 ta kvadrat qatoriga nechta cho'p kerak?",opts:["40","31","30","33"],ok:1,why:"3 · 10 + 1 = 31.",hint:"Birinchi kvadratga 4 ta, qolgan 9 tasining har biriga 3 tadan.",full:"4 + 3 · 9 = 4 + 27 = 31. «40» — har kvadratni alohida (4 tadan) sanagan, umumiy tomonlar ikki marta hisoblangan."},
 tn:"Bolalar jadval tuzsin: 1 → 4, 2 → 7, 3 → 10, 4 → 13. Farq doim 3 — bu qonuniyatni o'zlari ko'rsin."},
{h:"Uchburchaklar qatori",sum:"n ta uchburchak (navbatma-navbat) qatori: 2n + 1 cho'p.",a:"m02",
 start:function(){S.n=1;j4Tri(1)},fin:function(){j4Tri(5)},
 html:"<p>Endi uchburchaklar: biri tik, biri teskari — navbatma-navbat. Har yangi uchburchakka nechta cho'p qo'shiladi?</p>",
 btns:[["+ 1 uchburchak",function(c,done){if(S.n<9){S.n++;j4Tri(S.n)}mvK(done,3)}]],
 after:"<p>Birinchisiga <b>3</b> ta, keyingi har biriga <b>2</b> ta cho'p: qoida <b>3 + 2 · (n − 1) = 2n + 1</b>.</p>",
 q:{t:"7 ta uchburchak qatoriga nechta cho'p kerak?",opts:["21","14","15","16"],ok:2,why:"2 · 7 + 1 = 15.",hint:"Birinchisiga 3 ta, qolgan 6 tasiga 2 tadan.",full:"3 + 2 · 6 = 15. «21» — har uchburchakni alohida 3 tadan sanash xatosi."},
 tn:"Bu — algebraik fikrlashning boshlanishi: «n-chi» qadam uchun qoida topish."},
{h:"Kvadrat to'r: ichki cho'plar",sum:"3×3 to'r: gorizontal 4×3 + vertikal 4×3 = 24 cho'p (36 emas).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Kvadratlardan to'r yasaymiz. 2 × 2 va 3 × 3 to'rga nechta cho'p kerak? Qatorlab sanaymiz.</p>",
 btns:[phaser(P3)],
 after:"<p>Usul: <b>gorizontal</b> chiziqlar va <b>vertikal</b> chiziqlarni alohida sanaymiz. 3 × 3 to'rda 4 ta gorizontal qator, har birida 3 ta cho'p — 12; vertikallar ham 12. Jami <b>24</b>.</p>",
 q:{t:"2 × 4 to'g'ri to'rtburchak to'r (2 qator, har birida 4 kvadrat) uchun nechta cho'p kerak?",opts:["32","22","24","26"],ok:1,why:"Gorizontal: 3 qator × 4 = 12, vertikal: 5 ustun × 2 = 10. Jami 22.",hint:"Gorizontal chiziqlar nechta qator, har birida nechta cho'p? Vertikallar-chi?",full:"Gorizontal: 3 qator (yuqori, o'rta, past), har birida 4 ta — 12. Vertikal: 5 ustun, har birida 2 ta — 10. 12 + 10 = 22. «32» — 8 ta kvadratni 4 tadan sanash xatosi."},
 tn:"Doskada to'r chizib, gorizontallarni bir rangda, vertikallarni boshqa rangda bo'yatish ichki cho'plar ikki marta sanalmasligini ko'rsatadi."},
{h:"Cho'p olib tashlash",sum:"2×2 to'rdan (12 cho'p) 4 tasini olib, 2 ta kvadrat qoldirish: diagonal kvadratlar.",a:"m04",
 start:function(){j4Diag(false);j3Msg('12 ta cho‘pdan 4 tasini olib, 2 ta kvadrat qoldiring. Qaysi ikkitasi?')},fin:function(){j4Diag(true);j3Msg('Qolgan 8 ta cho‘p — ikkita alohida kvadrat (4 + 4)')},
 html:"<p>2 × 2 to'rda 4 ta kichik kvadrat bor. <b>4 ta</b> cho'pni olib tashlab, <b>2 ta</b> kvadrat qoldirish kerak. Qaysi kvadratlar qolsin?</p>",
 btns:j3Ch(["Yonma-yon ikkitasi","Diagonal ikkitasi","Ustma-ust ikkitasi"],1,function(){j4Diag(true);j3Msg('To‘g‘ri! Diagonal kvadratlarda umumiy tomon yo‘q: 4 + 4 = 8 cho‘p qoladi')},function(i){return 'Yonma-yon kvadratlarning umumiy tomoni bor: ular 7 ta cho‘p oladi, 12 − 4 = 8 ta qolishi kerak'}),
 after:"<p>Hisob bilan tekshiramiz: 12 − 4 = <b>8</b> ta cho'p qolishi kerak. 2 ta kvadrat 8 ta cho'p olishi uchun ularning <b>umumiy tomoni bo'lmasligi</b> kerak — demak, faqat diagonal juftlik.</p>",
 q:{t:"Qatorda 3 ta kvadrat (10 cho'p). Nechta cho'pni olib tashlasak, 2 ta alohida (umumiy tomonsiz) kvadrat qoladi?",opts:["4","2","3","1"],ok:1,why:"Chetdagi 2 ta kvadrat 8 ta cho'p oladi: 10 − 8 = 2 (o'rtadagi kvadratning tepa va pastki cho'pi).",hint:"Ikkita alohida kvadratga nechta cho'p kerak? 10 dan nechta ortiqcha?",full:"Chetdagi ikki kvadrat alohida qoladi: 4 + 4 = 8 cho'p. 10 − 8 = 2 ta cho'p — o'rtadagi kvadratning tepa va pastki tomoni — olib tashlanadi."},
 tn:"Avval «nechta qolishi kerak?» deb hisoblash, keyin shaklni qidirish — bu masalaning kaliti."},
{h:"Bitta cho'pni ko'chirish (Rim raqamlari)",sum:"IX − I = X (noto'g'ri) → X − I = IX (to'g'ri): chapdagi I o'ngga ko'chdi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Gugurt cho'plaridan Rim raqamlari bilan tenglik yozilgan: <b>IX − I = X</b>. Bu noto'g'ri (9 − 1 ≠ 10). Faqat <b>bitta</b> cho'pni ko'chirib, to'g'ri qiling.</p>",
 btns:[phaser(P5)],
 after:"<p>Rim raqamlarida I ning o'rni muhim: <b>IX</b> = 10 − 1 = 9, <b>XI</b> = 10 + 1 = 11. Chapdagi IX dan I ni olsak X (10) qoladi, o'ngdagi X oldiga qo'ysak IX (9) bo'ladi: <b>10 − 1 = 9</b> ✓.</p>",
 q:{t:"X + I = IX noto'g'ri (10 + 1 ≠ 9). Bitta cho'pni ko'chirib qaysi to'g'ri tenglik hosil bo'ladi?",opts:["X − I = IX","X + I = XI","XI + I = X","X + II = IX"],ok:1,why:"O'ngdagi IX ning I sini X ning o'ng tomoniga ko'chiramiz: XI. 10 + 1 = 11 ✓.",hint:"O'ng tomondagi IX ni o'zgartirib ko'ring: I chapda turibdi, o'ngga o'tsa nima bo'ladi?",full:"IX dagi I ni X ning o'ng tomoniga ko'chirsak XI (11) bo'ladi: X + I = XI, 10 + 1 = 11 ✓. «X − I = IX» ham to'g'ri tenglik, lekin «+» ni «−» ga aylantirish uchun cho'pni olib tashlash kerak — uni hech qayerga qo'ymaymiz, bu «ko'chirish» emas."},
 tn:"Gugurt bilan Rim raqamlari — klassik olimpiada turi. Haqiqiy cho'plar bilan bolalarga qilib ko'rsating."},
{h:"Raqamli cho'plar (kalkulyator raqamlari)",sum:"Raqamlar: 1 — 2 cho'p, 7 — 3, 4 — 4, 2/3/5 — 5, 0/6/9 — 6, 8 — 7. 6 cho'pdan eng katta son: 111.",a:"m06",
 start:function(){clear();j3Num('2026',60,50,{w:26,h:52,gap:18});j3Msg('Kalkulyatordagi raqamlar cho‘plardan tuzilgan. 2026 uchun nechta cho‘p?')},fin:function(){clear();j3Num('111',90,50,{w:26,h:52,gap:30,col:C.ok});j3Msg('6 ta cho‘pdan eng katta son — <b>111</b>')},
 html:"<p>Elektron soat va kalkulyator raqamlari 7 ta bo'lakdan iborat. Har bo'lak — bitta cho'p. 6 ta cho'pdan qaysi eng katta sonni yasash mumkin?</p>",
 btns:j3Ch(["77","111","9","60"],1,function(){clear();j3Num('111',90,50,{w:26,h:52,gap:30,col:C.ok});j3Msg('111 — uch xonali! 1 raqami eng kam (2 ta) cho‘p oladi, shuning uchun eng ko‘p xona chiqadi')},function(i){return ['77 ham 6 cho‘p, lekin ikki xonali. Uch xonali son yasab bo‘lmasmikan?','','9 — 6 cho‘p, lekin bir xonali son','60 uchun 6 + 6 = 12 cho‘p kerak'][i]}),
 after:"<p>Eng katta son — <b>eng ko'p xonali</b> son. Xona ko'p bo'lishi uchun har raqamga eng kam cho'p sarflaymiz: «1» — atigi 2 ta cho'p. 6 : 2 = 3 xona → <b>111</b>.</p>",
 q:{t:"2026 sonini yozish uchun nechta cho'p kerak?",opts:["20","22","24","18"],ok:1,why:"2 (5) + 0 (6) + 2 (5) + 6 (6) = 22.",hint:"Har raqamning cho'plarini sanang: 2 — 5 ta, 0 — 6 ta, 6 — 6 ta.",full:"2 → 5, 0 → 6, 2 → 5, 6 → 6. Jami: 5 + 6 + 5 + 6 = 22."},
 tn:"Daftarga 0–9 raqamlarini «soat raqami» qilib chizdirib, har biriga nechta chiziq kerakligini yozdiring — jadval keyingi masalalarda kerak bo'ladi."},
{h:"Bilasizmi? Etti bo'lakli raqamlar",sum:"Kalkulyator va soat raqamlari 7 bo'lakdan tuziladi; har raqam ba'zi bo'laklarni yoqadi.",a:"m07",
 start:function(){clear();j3Num('8',160,40,{w:36,h:76,col:'#f0a040'});j3Msg('8 — barcha 7 bo‘lak yoniq')},fin:function(){clear();j3Num('8',160,40,{w:36,h:76,col:'#f0a040'});j3Msg('8 — barcha 7 bo‘lak yoniq')},
 html:"<p>💡 Elektron soat, kalkulyator va lift tablosidagi raqamlar <b>7 ta bo'lakdan</b> tuziladi. «8» da hammasi yonadi, «1» da faqat 2 tasi. Shuning uchun gugurt cho'plari bilan raqam jumboqlari aynan shu shaklda tuziladi.</p><p>🔢 Bo'laklari soni bo'yicha: 1 — 2 ta, 7 — 3 ta, 4 — 4 ta, 2, 3, 5 — 5 tadan, 0, 6, 9 — 6 tadan, 8 — 7 ta.</p>",
 tn:"Bolalar o'z ismlarini yoki tug'ilgan yilini shu raqamlarda yozib, cho'plarni sanashsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j4Row(3)},fin:function(){j4Row(3)},
 html:"<div class='memo'><ul><li>Kvadratlar qatori: <b>3n + 1</b> (4, 7, 10, 13…).</li><li>Uchburchaklar qatori: <b>2n + 1</b>.</li><li>To'r: gorizontal va vertikal cho'plarni <b>alohida</b> sanang. 3 × 3 — 24 ta.</li><li>Cho'p olish: avval «nechta qolishi kerak?» ni hisoblang.</li><li>Rim raqamlari: IX = 9, XI = 11 — I ning o'rni muhim.</li><li>Raqamlar: 1 — 2, 7 — 3, 4 — 4, 2/3/5 — 5, 0/6/9 — 6, 8 — 7 cho'p.</li><li>Eng katta son — eng ko'p xonali: ko'proq «1» ishlating.</li></ul></div>",
 tn:"Keyingi darsni «4 × 4 to'rga nechta cho'p?» (40) savoli bilan boshlang."}
];
var PROBS=[
{t:"Qatordagi 6 ta kvadratga nechta cho'p kerak?",o:["19","24","18","21"],k:0,s:"3 · 6 + 1 = 19."},
{t:"Qatordagi 15 ta kvadratga nechta cho'p kerak?",o:["46","60","45","48"],k:0,s:"3 · 15 + 1 = 46."},
{t:"Qatordagi kvadratlarga 25 ta cho'p sarflandi. Nechta kvadrat?",o:["8","6","9","7"],k:0,s:"3n + 1 = 25 → 3n = 24 → n = 8."},
{t:"9 ta uchburchak qatoriga (navbatma-navbat) nechta cho'p kerak?",o:["19","27","18","20"],k:0,s:"2 · 9 + 1 = 19."},
{t:"Uchburchaklar qatoriga 21 ta cho'p ketdi. Nechta uchburchak?",o:["10","7","11","9"],k:0,s:"2n + 1 = 21 → n = 10."},
{t:"2 × 2 kvadrat to'rga nechta cho'p kerak?",o:["12","16","10","14"],k:0,s:"Gorizontal 3 × 2 = 6, vertikal 3 × 2 = 6. Jami 12."},
{t:"3 × 3 kvadrat to'rga nechta cho'p kerak?",o:["24","36","27","21"],k:0,s:"Gorizontal 4 × 3 = 12, vertikal 12. Jami 24."},
{t:"4 × 4 kvadrat to'rga nechta cho'p kerak?",o:["40","64","32","36"],k:0,s:"Gorizontal 5 × 4 = 20, vertikal 20. Jami 40."},
{t:"2 × 3 to'r (2 qator, har birida 3 kvadrat) uchun nechta cho'p?",o:["17","24","18","16"],k:0,s:"Gorizontal 3 × 3 = 9, vertikal 4 × 2 = 8. Jami 17."},
{t:"8 raqamini yasash uchun nechta cho'p kerak?",o:["7","8","6","5"],k:0,s:"8 — barcha 7 bo'lak."},
{t:"Eng kam cho'p bilan yoziladigan raqam qaysi?",o:["1","7","0","4"],k:0,s:"1 — atigi 2 ta cho'p."},
{t:"10 ta cho'pdan (raqamlar bilan) eng katta sonni yasang.",o:["11111","88","7777","1111"],k:0,s:"Har «1» — 2 cho'p: 10 : 2 = 5 xona → 11111."},
{t:"7 ta cho'pdan eng katta son qaysi?",o:["711","1111","8","77"],k:0,s:"Toq son cho'p: bitta «7» (3) + ikkita «1» (4) = 7 → uch xonali 711. «1111» uchun 8 cho'p kerak."},
{t:"2027 ni yozish uchun nechta cho'p kerak?",o:["19","22","20","21"],k:0,s:"2 (5) + 0 (6) + 2 (5) + 7 (3) = 19."},
{t:"2 × 2 to'rdan (12 cho'p) bitta tashqi cho'p olindi. Nechta kichik kvadrat qoldi?",o:["3","4","2","1"],k:0,s:"Tashqi cho'p faqat bitta kvadratga tegishli — u buziladi, 3 tasi qoladi."},
{t:"IV − I = V noto'g'ri. Bitta cho'pni ko'chirib to'g'ri qiling.",o:["V − I = IV","IV − I = IV","IV − II = V","VI − II = V"],k:0,s:"Chapdagi IV ning I sini o'ngdagi V ning oldiga ko'chiramiz: V − I = IV, 5 − 1 = 4 ✓."},
{t:"Qatorda nechta kvadrat bo'lsa, unga 34 ta cho'p kerak?",o:["11","8","12","10"],k:0,s:"3n + 1 = 34 → n = 11."},
{t:"Qatordagi 5 ta kvadratdan 2 ta cho'p olib tashlandi, kvadratlar 3 ta qoldi. Necha cho'p qoldi?",o:["14","16","13","12"],k:0,s:"5 ta kvadrat — 16 cho'p. 16 − 2 = 14."},
{t:"1 dan 9 gacha raqamlar orasida nechtasi aynan 5 ta cho'p bilan yoziladi?",o:["3","4","2","5"],k:0,s:"2, 3, 5 — 3 ta."},
{t:"Qaysi son yozilishiga eng ko'p cho'p ketadi?",o:["1888","999","808","2001"],k:0,s:"1888: 2 + 7 + 7 + 7 = 23; 999: 18; 808: 20; 2001: 19."}
];
function PRACT_STAGE(){j4Row(3)}
var PREP_DATA={teach:["Cho'plar qonuniyatini topish: 3n + 1, 2n + 1.","To'rlarda ichki cho'plarni ikki marta sanamaslik.","Cho'p olib tashlash va ko'chirish masalalari.","Etti bo'lakli raqamlar va eng katta son."],
 mist:["Har kvadratni alohida 4 tadan sanaydi (umumiy tomonlarni unutadi).","3 × 3 to'rni 9 · 4 = 36 deydi.","Eng katta son deb eng katta raqamni (9) tanlaydi, xonalar sonini o'ylamaydi."],
 need:["Haqiqiy gugurt cho'plari yoki qog'oz tasmalar.","Doskada katakli to'r."],
 board:["<span class='w2'>1 → 4, 2 → 7, 3 → 10 … 3n + 1</span>.","To'r: <span class='w2'>gorizontal + vertikal</span>.","<span class='w2'>IX − I = X → X − I = IX</span>.","Raqamlar jadvali: 1–2, 7–3, 4–4, 2/3/5–5, 0/6/9–6, 8–7."]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
