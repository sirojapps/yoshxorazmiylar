var CODE='3J07',TITLE="3-sinf · Yosh masalalari";
var J7R=[['Hozir',30,6,24],['+1 yil',31,7,24],['+10 yil',40,16,24],['−5 yil',25,1,24]];
function j7T(n,hl){var r=[['','Ota','O‘g‘il','Farq']].concat(J7R.slice(0,n));var f={};for(var i=1;i<=n;i++)f[i+',3']='#e6f6ee';if(hl)f[n+',1']=f[n+',2']='#ffe9a8';j3Tab(r,{hr:1,hc:1,cw:80,ch:30,fs:15,fill:f,y0:12})}
var P1=[function(){j7T(1);j3Msg('Ota 30 yoshda, o‘g‘li 6 yoshda. Farq: 30 − 6 = 24')},
 function(){j7T(2,1);j3Msg('1 yil o‘tdi: ikkalasi ham +1. Farq yana 24')},
 function(){j7T(3,1);j3Msg('10 yildan keyin: 40 va 16. Farq yana 24')},
 function(){j7T(4,1);j3Msg('5 yil oldin: 25 va 1. Farq doim <b>24</b>!')}];
var J7Y='#7fb3e6',J7O='#f2a65a';
function j7Ma(){j3Bars([{lab:'Qizi',parts:[[8,J7Y,4]],right:'8'},{lab:'Ona',parts:[[8,J7Y,4],[8,J7O,4],[8,J7O,4],[8,J7O,4]],right:'32'}],{u:8,y0:40,h:30,gap:22});j3Msg('Ona 32, qizi 8: ona 4 marta katta. Farq: 3 qism = 24')}
var STEPS=[
{h:"Yosh farqi o'zgarmaydi",sum:"Har yili hamma bir yoshga ulg'ayadi, shuning uchun yosh farqi doim bir xil.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>Ota va o'g'il yillar o'tishi bilan qanday o'zgaradi? Tugmani bosib, vaqtni oldinga va orqaga suring. <b>Farq</b> ustunini kuzating.</p>",
 btns:[phaser(P1)],
 after:"<p>Eng muhim qoida: <b>yosh farqi hech qachon o'zgarmaydi</b>. 1 yil o'tsa — ikkalasi +1, 10 yil o'tsa — ikkalasi +10. Ota doim o'g'lidan 24 yosh katta.</p>",
 q:{t:"Opa singlisidan 4 yosh katta. 10 yildan keyin opa singlisidan necha yosh katta bo'ladi?",opts:["14","4","10","6"],ok:1,why:"Farq o'zgarmaydi: 4.",hint:"10 yilda ikkalasiga nechadan qo'shiladi?",full:"10 yilda opaga ham, singilga ham 10 yil qo'shiladi. Farq yana 4. «14» — 10 ni faqat bittasiga qo'shish xatosi."},
 tn:"Doskaga ota va o'g'il jadvalini chizing; bolalar yangi qator qo'shib, farqni hisoblasin. Sinf a'zolarining o'z oila a'zolaridan misollar keltirsin."},
{h:"Yoshlar yig'indisi o'zgaradi",sum:"Har yili yig'indi odamlar soniga qarab oshadi: 2 kishi bo'lsa +2, 3 kishi bo'lsa +3.",a:"m02",
 start:function(){j3Lines(['Ali + Vali = 15 yosh','3 yildan keyin = ?'],{fs:20,lh:40});j3Msg('Ikki bolaning yoshlari yig‘indisi 15. 3 yildan keyin yig‘indi qancha?')},fin:function(){j3Lines(['Ali + Vali = 15 yosh','3 yildan keyin: 15 + 3 + 3 = 21'],{fs:19,lh:40});j3Msg('Har bolaga +3: yig‘indi +6')},
 html:"<p>Farq o'zgarmaydi. Yig'indi-chi? Ikki bolaning yoshlari yig'indisi 15. <b>3 yildan keyin</b> yig'indi qancha bo'ladi?</p>",
 btns:j3Ch(["15","18","21","24"],2,function(){j3Lines(['Ali + Vali = 15 yosh','3 yildan keyin: 15 + 3 + 3 = 21'],{fs:19,lh:40});j3Msg('To‘g‘ri! Har bolaga 3 yildan: 15 + 6 = 21')},function(i){return ['Yig‘indi o‘zgarmasligi faqat farqqa tegishli','3 yil faqat bitta bolaga qo‘shildi. Ikkinchisi-chi?','','Bolalar 2 ta, uchta emas'][i]}),g2:1,
 after:"<p>Yig'indi har yili <b>odamlar soniga</b> teng oshadi. 2 kishi, 3 yil: 15 + 2 · 3 = 21. Farq esa — o'zgarmaydi. Bu ikki qoidani adashtirmang!</p>",
 q:{t:"Uch opa-singil yoshlari yig'indisi 20. 4 yildan keyin yig'indi qancha?",opts:["24","28","32","36"],ok:2,why:"3 kishi, har biriga 4: 20 + 12 = 32.",hint:"Nechta odam bor? Har biriga necha yil qo'shiladi?",full:"Uch kishining har biriga 4 yil qo'shiladi: 3 · 4 = 12. 20 + 12 = 32. «24» — faqat bitta odamga qo'shish xatosi."},
 tn:"Jadvalga yig'indi ustunini ham qo'shing — bolalar u har yili 2 ga o'sishini o'zi ko'rsin."},
{h:"Yig'indi va farq: chizma bilan",sum:"Aka + uka = 20, aka 4 yosh katta → (20 − 4) : 2 = 8 (uka), aka 12.",a:"m03",
 start:function(){j3Bars([{lab:'Uka',parts:[['?',J7Y,12]]},{lab:'Aka',parts:[['?',J7Y,12],[4,J7O,4]],right:'jami 20'}],{u:10,y0:40,h:30,gap:22});j3Msg('Aka + uka = 20. Aka 4 yosh katta. Uka necha yoshda?')},fin:function(){j3Bars([{lab:'Uka',parts:[[8,J7Y,12]]},{lab:'Aka',parts:[[8,J7Y,12],[4,J7O,4]],right:'= 12'}],{u:10,y0:40,h:30,gap:22});j3Msg('(20 − 4) : 2 = 8 — uka; 8 + 4 = 12 — aka')},
 html:"<p>Aka va ukaning yoshlari yig'indisi 20, aka 4 yosh katta. Chizmaga qarang: akaning chizig'i ukanikidan 4 ga uzun. Uka necha yoshda?</p>",
 btns:j3Ch(["8","10","12","16"],0,function(){j3Bars([{lab:'Uka',parts:[[8,J7Y,12]]},{lab:'Aka',parts:[[8,J7Y,12],[4,J7O,4]],right:'= 12'}],{u:10,y0:40,h:30,gap:22});j3Msg('To‘g‘ri! 20 − 4 = 16, 16 : 2 = 8. Aka 12')},function(i){return ['','20 : 2 = 10 — bu teng bo‘lsalar. Lekin aka 4 ga katta!','12 — akaning yoshi. Savol uka haqida','20 − 4 = 16 — bu ikki ukaning yig‘indisi. Yana 2 ga bo‘ling'][i]}),g2:1,
 after:"<p>Singapur usuli: ortiqcha qismni (4) olib tashlasak, ikki teng chiziq qoladi: 20 − 4 = 16, har biri 16 : 2 = 8. Kichigi 8, kattasi 8 + 4 = 12. Tekshiruv: 8 + 12 = 20 ✓.</p>",
 q:{t:"Ona va qizining yoshlari yig'indisi 40, ona 26 yosh katta. Qizi necha yoshda?",opts:["7","14","13","33"],ok:0,why:"(40 − 26) : 2 = 7.",hint:"Avval katta qismni olib tashlang, qolganini teng bo'ling.",full:"40 − 26 = 14 — bu ikki teng qism. 14 : 2 = 7 — qizi, ona 7 + 26 = 33. «14» — bo'lishni unutish, «13» — 26 : 2."},
 tn:"Chizma modelini qog'oz lentalar bilan ko'rsating: ikki lentadan birini 4 katakka uzunroq kesing."},
{h:"«Necha marta katta» qachon bo'ladi?",sum:"Ona 32, qizi 8 (farq 24). Ona 3 marta katta bo'lganda farq = 2 qism → qizi 12 → 4 yildan keyin.",a:"m04",
 start:function(){j7Ma()},fin:function(){j3Bars([{lab:'Qizi',parts:[[12,J7Y,6]],right:'12'},{lab:'Ona',parts:[[12,J7Y,6],[12,J7O,6],[12,J7O,6]],right:'36'}],{u:8,y0:40,h:30,gap:22});j3Msg('Farq 24 = 2 qism → 1 qism 12. Qizi 12 yoshda — 4 yildan keyin')},
 html:"<p>Ona 32 yoshda, qizi 8 da — ona 4 marta katta. <b>Necha yildan keyin</b> ona qizidan <b>3 marta</b> katta bo'ladi? Yordam: farq doim 24.</p>",
 btns:j3Ch(["2 yildan","4 yildan","8 yildan","12 yildan"],1,function(){j3Bars([{lab:'Qizi',parts:[[12,J7Y,6]],right:'12'},{lab:'Ona',parts:[[12,J7Y,6],[12,J7O,6],[12,J7O,6]],right:'36'}],{u:8,y0:40,h:30,gap:22});j3Msg('To‘g‘ri! Qizi 12, ona 36: 36 = 3 · 12 ✓')},function(i){return ['2 yildan keyin: 34 va 10 — 34 : 10 butun emas','','8 yildan keyin: 40 va 16 — 3 marta emas','12 — qizining yoshi bo‘ladi, yillar soni emas: 12 − 8 = ?'][i]}),g2:1,
 after:"<p>Usul: «3 marta katta» → ona = 3 qism, qizi = 1 qism, <b>farq = 2 qism</b>. Farq doim 24, demak 1 qism = 12. Qizi 12 yoshda bo'ladi, ya'ni 12 − 8 = <b>4 yildan</b> keyin.</p>",
 q:{t:"Ota o'g'lidan 3 marta katta, farq 24 yosh. O'g'il necha yoshda?",opts:["8","12","36","6"],ok:1,why:"3 marta → farq 2 qism: 24 : 2 = 12.",hint:"Ota 3 qism, o'g'il 1 qism. Farq necha qism?",full:"Ota — 3 qism, o'g'il — 1 qism, farq — 2 qism = 24, 1 qism = 12. O'g'il 12, ota 36. «8» — 24 ni 3 ga bo'lish xatosi."},
 tn:"Bu qadam — olimpiadaning eng ko'p uchraydigan turi. Bolalar har doim «farq necha qism?» deb so'rasin."},
{h:"Tuzoq: o'tmishga qarab",sum:"Ona 32, qizi 8. Ona 5 marta katta bo'lgan payt: farq 24 = 4 qism → qizi 6 → 2 yil oldin.",a:"m05",
 start:function(){j7Ma()},fin:function(){j3Bars([{lab:'Qizi',parts:[[6,J7Y,3]],right:'6'},{lab:'Ona',parts:[[6,J7Y,3],[6,J7O,3],[6,J7O,3],[6,J7O,3],[6,J7O,3]],right:'30'}],{u:8,y0:40,h:30,gap:22});j3Msg('Farq 24 = 4 qism → 1 qism 6 → 8 − 6 = 2 yil oldin')},
 html:"<p>Xuddi shu oila. <b>Necha yil oldin</b> ona qizidan <b>5 marta</b> katta edi?</p>",
 btns:j3Ch(["2 yil oldin","4 yil oldin","6 yil oldin","3 yil oldin"],0,function(){j3Bars([{lab:'Qizi',parts:[[6,J7Y,3]],right:'6'},{lab:'Ona',parts:[[6,J7Y,3],[6,J7O,3],[6,J7O,3],[6,J7O,3],[6,J7O,3]],right:'30'}],{u:8,y0:40,h:30,gap:22});j3Msg('To‘g‘ri! 2 yil oldin: 30 va 6, 30 = 5 · 6 ✓')},function(i){return ['','4 yil oldin: 28 va 4 — 7 marta','6 — qizining o‘sha paytdagi yoshi. Hozir u 8 da','3 yil oldin: 29 va 5 — butun marta emas'][i]}),g2:1,
 after:"<p>5 marta → farq <b>4 qism</b> = 24 → 1 qism = 6. Qizi 6 yoshda bo'lgan — hozir 8 da, demak 2 yil oldin. Tekshirish har doim shart: 30 : 6 = 5 ✓.</p>",
 q:{t:"Bobo 64, nevara 8 yoshda. Necha yildan keyin bobo nevarasidan 5 marta katta bo'ladi?",opts:["6","14","3","8"],ok:0,why:"Farq 56 = 4 qism, 1 qism 14 → 14 − 8 = 6 yil.",hint:"Farq necha? 5 martada farq necha qism?",full:"Farq 64 − 8 = 56. 5 marta → farq 4 qism → 1 qism = 14. Nevara 14 yoshda bo'ladi: 14 − 8 = 6 yildan keyin. Bobo 70: 70 = 5 · 14 ✓. «14» — yillar emas, yosh."},
 tn:"Har yechimni jadvalda tekshiring: «Hozir / x yildan keyin» — ikki qator."},
{h:"«Tug'ilganda» degan so'z",sum:"«Ona qizi tug'ilganda 25 yoshda edi» = farq 25. Ona 2 marta katta bo'lishi uchun qizi 25 yoshda bo'lishi kerak.",a:"m06",
 start:function(){j3Lines(['Ona qizi tug‘ilganda 25 yoshda edi','Qizi necha yoshda bo‘lganda','ona undan 2 marta katta bo‘ladi?'],{fs:17,lh:32});j3Msg('Tug‘ilganda qizi 0 yoshda — demak farq = 25')},fin:function(){j3Lines(['Farq = 25 = 1 qism','Qizi 25, ona 50'],{fs:19,lh:38});j3Msg('2 marta katta → farq = 1 qism = qizining yoshi')},
 html:"<p>Ona qizi tug'ilganda 25 yoshda edi. Qizi <b>necha yoshda</b> bo'lganda ona undan 2 marta katta bo'ladi?</p>",
 btns:j3Ch(["12","25","50","13"],1,function(){j3Lines(['Farq = 25 = 1 qism','Qizi 25, ona 50'],{fs:19,lh:38});j3Msg('To‘g‘ri! 50 = 2 · 25 ✓')},function(i){return ['25 ni 2 ga bo‘ldingizmi? 2 martada farq necha qism?','','50 — onaning yoshi bo‘ladi','13 bo‘lsa, ona 38: 2 marta emas'][i]}),g2:1,
 after:"<p>«Tug'ilganda» — yashirin ma'lumot: o'sha paytda bola 0 yoshda, demak onaning yoshi = <b>farq</b>. 2 marta katta → farq 1 qism → qizi 25, ona 50.</p>",
 q:{t:"Ota o'g'li tug'ilganda 28 yoshda edi. Hozir o'g'il 10 yoshda. Ularning yoshlari yig'indisi?",opts:["38","48","28","20"],ok:1,why:"Ota 38, o'g'il 10: jami 48.",hint:"Hozir ota necha yoshda?",full:"Farq 28: ota 10 + 28 = 38. Yig'indi 38 + 10 = 48. «38» — faqat ota yoshi."},
 tn:"Bolalar o'z ota-onasining ular tug'ilgandagi yoshini so'rab kelsin — farqni o'zi hisoblasin."},
{h:"Bilasizmi? Diofantning yoshi",sum:"Qadimgi yunon jumbog'i: Diofant umrining 1/6 qismi bolalik, 1/12 yoshlik, 1/7 qismi bo'ydoqlik... Javob — 84 yil.",a:"m07",
 start:function(){j3Lines(['Diofant: 84 yil','bolalik — 14 yil (84 : 6)','yoshlik — 7 yil (84 : 12)'],{fs:17,lh:32});j3Msg('Qadimgi yosh jumbog‘i')},fin:function(){j3Lines(['Diofant: 84 yil','bolalik — 14 yil (84 : 6)','yoshlik — 7 yil (84 : 12)'],{fs:17,lh:32});j3Msg('Qadimgi yosh jumbog‘i')},
 html:"<p>📜 Qadimgi yunon matematigi <b>Diofant</b> haqida mashhur jumboq bor (u «Yunon antologiyasi» to'plamida saqlangan): uning umrining oltidan biri — bolalik, o'n ikkidan biri — yoshlik, yettidan biri — uylanmasdan o'tgan yillar, keyin 5 yildan so'ng o'g'li tug'ilgan, o'g'li otasining yarim umricha yashagan, otasi esa o'g'lidan keyin 4 yil yashagan.</p><p>Bu jumboq yechimi — <b>84 yil</b>. 84 soni 6 ga, 12 ga va 7 ga bo'linishini tekshiring!</p>",
 tn:"Kuchli o'quvchilar uchun: 84 : 6 + 84 : 12 + 84 : 7 + 5 + 84 : 2 + 4 = 84 ekanini tekshirish."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j7T(4)},fin:function(){j7T(4)},
 html:"<div class='memo'><ul><li>Yosh <b>farqi o'zgarmaydi</b>.</li><li>Yig'indi har yili <b>odamlar soniga</b> teng oshadi.</li><li>Yig'indi va farq: (yig'indi − farq) : 2 = kichigi.</li><li>«n marta katta» → farq = <b>n − 1 qism</b>.</li><li>Javob — yoshmi yoki yillar sonimi? Savolni qayta o'qing.</li><li>«Tug'ilganda» → o'sha paytdagi yosh = farq.</li><li>Har doim tekshiring: hozir va x yildan keyin.</li></ul></div>",
 tn:"Uyga vazifa: oila a'zolarining yoshlari bilan 2 ta masala tuzib kelish."}
];
var PROBS=[
{t:"Ali 9 yoshda, Vali 5 yoshda. 6 yildan keyin ularning yosh farqi qancha bo'ladi?",o:["4","10","6","15"],k:0,s:"Farq o'zgarmaydi: 9 − 5 = 4."},
{t:"Aka 12, uka 7 yoshda. 5 yil oldin aka necha yoshda edi?",o:["7","2","17","5"],k:0,s:"12 − 5 = 7."},
{t:"Opa 11, singil 6 yoshda. Singil 11 yoshga kirganda opa necha yoshda bo'ladi?",o:["16","11","17","22"],k:0,s:"Farq 5: 11 + 5 = 16."},
{t:"Men 2 yil oldin 8 yoshda edim. 3 yildan keyin necha yoshda bo'laman?",o:["13","11","10","5"],k:0,s:"Hozir 10, 3 yildan keyin 13."},
{t:"Uch bolaning yoshlari yig'indisi 20. 4 yildan keyin yig'indi qancha?",o:["32","24","28","36"],k:0,s:"20 + 3 · 4 = 32."},
{t:"Ota va o'g'il yoshlari yig'indisi 40. 5 yil oldin yig'indi qancha edi?",o:["30","35","45","20"],k:0,s:"40 − 2 · 5 = 30."},
{t:"Aka va uka yoshlari yig'indisi 18, farqi 4. Aka necha yoshda?",o:["11","7","14","9"],k:0,s:"(18 − 4) : 2 = 7 — uka, aka 11."},
{t:"Ona qizidan 26 yosh katta, yoshlari yig'indisi 40. Qizi necha yoshda?",o:["7","14","33","13"],k:0,s:"(40 − 26) : 2 = 7."},
{t:"Ota 36, o'g'il 9 yoshda. Ota o'g'lidan necha marta katta?",o:["4","27","3","5"],k:0,s:"36 : 9 = 4."},
{t:"Uka 7 yoshda, aka undan 3 marta katta. Aka 30 yoshga kirganda uka necha yoshda bo'ladi?",o:["16","10","21","14"],k:0,s:"Aka 21, farq 14: 30 − 14 = 16."},
{t:"Ota o'g'li tug'ilganda 28 yoshda edi. Hozir o'g'il 10 yoshda. Yoshlari yig'indisi?",o:["48","38","28","20"],k:0,s:"Ota 38, jami 48."},
{t:"Malika 2025-yilda 9 yoshda edi. U qaysi yili 15 yoshga to'ladi?",o:["2031","2030","2034","2024"],k:0,s:"2025 + 6 = 2031."},
{t:"Ota o'g'lidan 3 marta katta, farq 24 yosh. O'g'il necha yoshda?",o:["12","8","36","6"],k:0,s:"Farq 2 qism: 24 : 2 = 12."},
{t:"Ota 35, o'g'il 7 yoshda. Necha yildan keyin ota o'g'lidan 3 marta katta bo'ladi?",o:["7","14","2","21"],k:0,s:"Farq 28 = 2 qism → o'g'il 14 → 7 yildan keyin."},
{t:"Ona 32, qizi 8 yoshda. Necha yil oldin ona qizidan 5 marta katta edi?",o:["2","4","6","3"],k:0,s:"Farq 24 = 4 qism → qizi 6 → 2 yil oldin."},
{t:"Bobo 64, nevara 8 yoshda. Necha yildan keyin bobo nevarasidan 5 marta katta bo'ladi?",o:["6","14","3","8"],k:0,s:"Farq 56 = 4 qism → 14 → 6 yildan keyin."},
{t:"Ona qizi tug'ilganda 25 yoshda edi. Qizi necha yoshda bo'lganda ona undan 2 marta katta bo'ladi?",o:["25","50","12","30"],k:0,s:"Farq 25 = 1 qism → qizi 25."},
{t:"Egizaklar va ularning akasi yoshlari yig'indisi 30. Aka egizaklardan 3 yosh katta. Aka necha yoshda?",o:["12","9","10","11"],k:0,s:"x + x + x + 3 = 30 → x = 9, aka 12."},
{t:"Ota 40, o'g'illari 10 va 6 yoshda. Necha yildan keyin ota yoshi o'g'illari yoshlari yig'indisiga teng bo'ladi?",o:["24","12","16","8"],k:0,s:"Har yili yig'indi 2 ga, ota 1 ga oshadi: farq 24 har yili 1 ga kamayadi → 24 yil."},
{t:"3 yil oldin aka ukadan 2 marta katta edi, uka o'shanda 5 yoshda edi. Aka hozir necha yoshda?",o:["13","10","16","8"],k:0,s:"3 yil oldin aka 10, hozir 13."}
];
function PRACT_STAGE(){j7T(4)}
var PREP_DATA={teach:["Yosh farqi o'zgarmasligi.","Yig'indining odamlar soniga qarab o'zgarishi.","Yig'indi va farq bo'yicha chizma (Singapur modeli).","«n marta katta» masalalari: farq = n − 1 qism."],
 mist:["Yillarni faqat bitta odamga qo'shadi.","«3 marta katta»da farqni 3 ga bo'ladi (2 ga emas).","Javobda yosh o'rniga yillar sonini (yoki aksincha) yozadi."],
 need:["Qog'oz lentalar (chizma model uchun).","Oila jadvali uchun katakli varaq."],
 board:["Farq = <span class='w2'>doim bir xil</span>","Yig'indi: <span class='w2'>+ odamlar soni × yil</span>","3 marta: <span class='w2'>farq = 2 qism</span>","(yig'indi − farq) : 2 = kichigi"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}
