var CODE='3C7',TITLE='3-sinf · 10 va 100 ga ko‘paytirish va bo‘lish';
function c7(rows,arrow,msg,note){W3pv(rows,{cols:5,arrow:arrow});W3msg(msg,note)}
var P1=[function(){c7([{v:23}],null,'23 = 2 o‘nlik 3 birlik')},
 function(){c7([{v:23},{v:230,lab:'·10',zero:1}],'·10','Har bir raqam <b>bir xona chapga</b> surildi: 2 o‘nlik → 2 yuzlik, 3 birlik → 3 o‘nlik. Bo‘sh birliklar xonasiga — <b>0</b>')}];
var P2=[function(){c7([{v:23}],null,'23 ni 100 ga ko‘paytiramiz')},
 function(){c7([{v:23},{v:2300,lab:'·100',zero:2}],'·100','100 = 10 · 10: raqamlar <b>ikki xona</b> chapga, oxiriga <b>ikkita 0</b>')}];
var P3=[function(){c7([{v:450}],null,'450 ni 10 ga bo‘lamiz')},
 function(){c7([{v:450},{v:45,lab:':10'}],':10','Raqamlar <b>bir xona o‘ngga</b>: 4 yuzlik → 4 o‘nlik, 5 o‘nlik → 5 birlik. Oxirgi 0 «chiqib ketdi»')}];
var P4=[function(){c7([{v:3700}],null,'3700 : 100')},
 function(){c7([{v:3700},{v:37,lab:':100'}],':100','Ikki xona o‘ngga — oxiridagi <b>ikkita 0</b> olib tashlanadi: <b>37</b>')}];
var P6=[function(){c7([{v:5000}],null,'5000 : 100 = ?','Ko‘pchilik «5» deydi…')},
 function(){c7([{v:5000},{v:50,lab:':100'}],':100','100 da <b>ikkita</b> 0 — faqat ikkita 0 olinadi: <b>50</b>. 5 desak — uchta nol olingan bo‘ladi')}];
var STEPS=[
{h:"10 ga ko'paytirish: bir xona chapga",sum:"23 · 10 = 230: har raqam bir xona chapga suriladi, birliklar xonasiga 0.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=1;P1[1]()},
 html:"<p>10 ga ko'paytirsak, har bir birlik — o'nlikka, har bir o'nlik — yuzlikka aylanadi. Xonalar jadvalida kuzating.</p>",btns:[phaser(P1,'▶ ·10')],
 after:"<p>Shuning uchun «oxiriga 0 yoziladi» deyiladi. Lekin aslida <b>raqamlar suriladi</b>, 0 esa bo'sh qolgan joyni egallaydi.</p>",
 q:{t:"47 · 10 = ?",opts:["470","4710","407","4700"],ok:0,why:"Bir xona chapga: 470.",hint:"10 da nechta nol bor?",full:"10 ga ko'paytirsak — bir xona chapga, oxiriga bitta 0: 470. «4700» — 100 ga ko'paytirilgan."},
 tn:"Xonalar jadvalini doskada chizing, raqamlarni magnit yoki qog'oz kartochkada siljiting — «0 qo'shish» qoidasidan oldin g'oyani ko'rsin."},
{h:"100 ga ko'paytirish: ikki xona chapga",sum:"23 · 100 = 2300: 100 = 10 · 10, ikki xona chapga.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=1;P2[1]()},
 html:"<p>100 ga ko'paytirish — bu ikki marta 10 ga ko'paytirish.</p>",btns:[phaser(P2,'▶ ·100')],
 after:"<p>23 · 100 = 23 · 10 · 10 = 230 · 10 = <b>2300</b>.</p>",
 q:{t:"68 · 100 = ?",opts:["680","6800","68 000","6080"],ok:1,why:"Ikki xona chapga: 6800.",hint:"100 da ikkita nol.",full:"68 · 100 = 6800 — oxiriga ikkita 0. «680» — 10 ga ko'paytirilgan."},
 tn:"Bolalarga 5 ta sonni 10 ga, keyin 100 ga ko'paytirtiring — qonuniyatni o'zi aytsin."},
{h:"10 ga bo'lish: bir xona o'ngga",sum:"450 : 10 = 45: raqamlar bir xona o'ngga, oxirgi 0 olib tashlanadi.",a:"m03",start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Bo'lish — teskari amal: raqamlar <b>o'ngga</b> suriladi.</p>",btns:[phaser(P3,'▶ :10')],
 after:"<p>Faqat oxiri 0 bilan tugagan sonlar 10 ga qoldiqsiz bo'linadi. 450 : 10 = 45, tekshiruv: 45 · 10 = 450 ✓.</p>",
 q:{t:"820 : 10 = ?",opts:["8200","82","802","8"],ok:1,why:"Bir xona o'ngga: 82.",hint:"Bo'lishda raqamlar qaysi tomonga suriladi?",full:"820 : 10 = 82 — oxirgi 0 olinadi. Tekshiruv: 82 · 10 = 820 ✓."},
 tn:"«Ko'paytirish — chapga, bo'lish — o'ngga» degan qisqa qo'shiqcha bilan mustahkamlang."},
{h:"100 ga bo'lish",sum:"3700 : 100 = 37: ikki xona o'ngga, ikkita 0 olinadi.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>3700 : 100 — ikki xona o'ngga.</p>",btns:[phaser(P4,'▶ :100')],
 after:"<p>100 ga qoldiqsiz bo'linadigan son oxirida kamida <b>ikkita 0</b> bo'lishi kerak.</p>",
 q:{t:"Qaysi son 100 ga qoldiqsiz bo'linadi?",opts:["750","1050","2300","1005"],ok:2,why:"2300 oxirida ikkita 0: 2300 : 100 = 23.",hint:"Oxirida nechta 0 bor?",full:"Faqat 2300 da oxirida ikkita 0 bor. 750 va 1050 — bitta 0, 1005 — oxirida 0 yo'q."},
 tn:"Bolalarga pul misolida: 3700 so'm nechta 100 so'mlik? — 37 ta."},
{h:"Tuzoq: o'rtadagi va oxiridagi nollar",sum:"306 · 10 = 3060 (o'rtadagi 0 joyida qoladi); 40 · 10 = 400.",a:"m05",start:function(){c7([{v:306}],null,'306 · 10 = ? Variantni tanlang')},fin:function(){c7([{v:306},{v:3060,lab:'·10',zero:1}],'·10','306 · 10 = 3060')},
 html:"<p>306 ni 10 ga ko'paytiring. To'g'ri javobni tanlang:</p>",
 btns:[["3060",function(c,done){c7([{v:306},{v:3060,lab:'·10',zero:1}],'·10','To‘g‘ri! O‘rtadagi 0 ham chapga suriladi, yo‘qolmaydi');done()}],["3600",function(){c7([{v:306}],null,'Yo‘q: o‘rtadagi 0 ni tashlab yubordingiz','Qayta tanlang')}],["30 600",function(){c7([{v:306}],null,'Yo‘q: bu 100 ga ko‘paytirish','Qayta tanlang')}]],g3:1,
 after:"<p>Hamma raqamlar — <b>nollar ham</b> — birga suriladi. 306 · 10 = <b>3060</b>.</p>",
 q:{t:"704 · 100 = ?",opts:["70 400","7400","74 000","7040"],ok:0,why:"Ikki xona chapga, o'rtadagi 0 qoladi: 70 400.",hint:"O'rtadagi 0 ni ham suring.",full:"704 · 100 = 70 400. «7400» — o'rtadagi 0 tashlab yuborilgan, «7040» — faqat 10 ga ko'paytirilgan."},
 tn:"Xatoni bolaning o'zi topsin: «3600 : 10 = 360, 306 emas» — tekshirish bilan."},
{h:"Tuzoq: nechta nol olinadi?",sum:"5000 : 100 = 50 — faqat 100 dagi nollar soncha (2 ta) olinadi.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=1;P6[1]()},
 html:"<p>Bo'lishda ehtiyot bo'ling: hamma nollarni emas, faqat bo'luvchidagi nollar sonini olamiz.</p>",btns:[phaser(P6)],
 after:"<p>Qoida: <b>:10</b> — bitta 0, <b>:100</b> — ikkita 0. Tekshiruv: 50 · 100 = 5000 ✓.</p>",
 q:{t:"(6000 : 100) : 10 = ?",opts:["6","60","600","0"],ok:0,why:"6000 : 100 = 60, 60 : 10 = 6.",hint:"Qavs ichini avval hisoblang.",full:"6000 : 100 = 60 (ikkita 0 olindi), 60 : 10 = 6. Jami uchta 0 olindi — bu 1000 ga bo'lish bilan bir xil."},
 tn:"Zanjirli misollar (·10 ·10, :100 :10) keyingi darsdagi 1000 ga ko'prik bo'ladi."},
{h:"Kattaliklarni almashtirish",sum:"1 m = 100 sm: 7 m = 700 sm; 1 sm = 10 mm: 80 mm = 8 sm; 600 sm = 6 m.",a:"m07",start:function(){W3eq(['7 m = ? sm'])},fin:function(){W3eq(['7 m = 7 · 100 = [700] sm','80 mm = 80 : 10 = [8] sm'])},
 html:"<p>10 va 100 ga ko'paytirish kattaliklarni almashtirishda kerak. Tanlang:</p>",
 btns:[["7 m → sm",function(c,done){W3eq(['1 m = 100 sm','7 m = 7 · 100 = [700] sm']);W3msg('Katta birlikdan kichigiga — <b>ko‘paytiramiz</b>');mvK(done,2)}],["80 mm → sm",function(c,done){W3eq(['1 sm = 10 mm','80 mm = 80 : 10 = [8] sm']);W3msg('Kichik birlikdan kattasiga — <b>bo‘lamiz</b>');mvK(done,2)}],["600 sm → m",function(c,done){W3eq(['1 m = 100 sm','600 sm = 600 : 100 = [6] m']);W3msg('sm dan m ga — 100 ga bo‘lamiz');mvK(done,2)}]],g3:1,
 after:"<p>Yodda tuting: <b>katta birlik → kichik birlik: ko'paytirish</b> (son kattalashadi), <b>kichik → katta: bo'lish</b>.</p>",
 q:{t:"4 m 5 sm = ? sm",opts:["45","405","450","4005"],ok:1,why:"4 m = 400 sm, + 5 = 405 sm.",hint:"Avval metrlarni sm ga aylantiring.",full:"4 m = 4 · 100 = 400 sm, 400 + 5 = 405 sm. «450» — 5 sm ni 50 sm deb olgan xato."},
 tn:"Chizg'ich va metr lentasini ko'rsating: 1 m da 100 ta santimetr chiziqchasi bor."},
{h:"Teskari savol",sum:"□ · 10 = 360 → □ = 36; □ · 100 = 3600.",a:"m08",start:function(){W3eq(['□ · 10 = 360','□ · 100 = ?'])},fin:function(){W3eq(['□ = 360 : 10 = [36]','36 · 100 = [3600]'])},
 html:"<p>Olimpiada savoli: <b>□ · 10 = 360</b> bo'lsa, <b>□ · 100</b> nechaga teng?</p>",btns:[["▶ Yechish",function(c,done){W3eq(['□ = 360 : 10 = [36]','36 · 100 = [3600]']);W3msg('Yoki qisqa: 100 — bu 10 dan 10 marta ko‘p, demak natija ham 10 marta ko‘p: 360 · 10 = 3600');done()}]],
 after:"<p>Ikki yo'l: avval □ ni topish (360 : 10 = 36) yoki darhol <b>10 marta oshirish</b>: 3600.</p>",
 q:{t:"□ · 100 = 5200. □ · 10 = ?",opts:["520","52","52 000","5200"],ok:0,why:"□ = 52, 52 · 10 = 520.",hint:"□ ni toping: 5200 : 100.",full:"□ = 5200 : 100 = 52. 52 · 10 = 520. Yoki: 10 — 100 dan 10 marta kam, demak 5200 : 10 = 520."},
 tn:"Bunday savollar «ko'paytuvchi o'zgarsa, ko'paytma qanday o'zgaradi?» g'oyasini o'rgatadi."},
{h:"Bilasizmi? Metrik tizim",sum:"Metr, santimetr, millimetr — hammasi 10 ga bog'langan. Bu tizimni 1795-yilda Fransiya qabul qilgan.",a:"m09",start:function(){clear('#f6ead0');var g=S.g;E('rect',{x:30,y:70,width:300,height:30,fill:'#f2d79b',stroke:'#6b3d12'},g);for(var i=0;i<=10;i++)E('line',{x1:30+i*30,y1:70,x2:30+i*30,y2:i%5?84:100,stroke:'#6b3d12','stroke-width':i%5?1:2},g);T(g,180,60,'1 dm = 10 sm = 100 mm',{'font-size':14,'font-weight':800,fill:'#6b3d12'});W3msg('Metrik tizimda hamma birliklar 10 ga bog‘langan')},fin:function(){STEPS[8].start()},
 html:"<p>📏 Ilgari har mamlakatda o'z o'lchovi bo'lgan: tirsak, qarich, quloch… Fransiya <b>1795-yilda</b> metrik tizimni qabul qildi: hamma birliklar <b>10 ga</b> bog'langan. Shuning uchun almashtirish shunchaki raqamlarni surishdan iborat!</p><p>⭐ Bizning sanoq ham o'nli — chunki qo'llarimizda 10 ta barmoq bor.</p>",
 tn:"Bolalardan eski o'lchovlar (qarich, quloch) bilan sinf uzunligini o'lchatib, natijalar har xil chiqishini ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){c7([{v:23},{v:230,lab:'·10'},{v:2300,lab:'·100'}],null,'Ko‘paytirish — chapga, bo‘lish — o‘ngga')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li><b>·10</b> — raqamlar bir xona chapga, oxiriga bitta 0: 23 · 10 = 230.</li><li><b>·100</b> — ikki xona chapga: 23 · 100 = 2300.</li><li><b>:10</b> — bir xona o'ngga: 450 : 10 = 45. <b>:100</b> — ikki xona: 3700 : 100 = 37.</li><li>O'rtadagi 0 yo'qolmaydi: 306 · 10 = 3060.</li><li>Bo'lishda faqat bo'luvchidagi nollar soncha 0 olinadi: 5000 : 100 = 50.</li><li>Katta birlik → kichik: ko'paytirish (7 m = 700 sm); kichik → katta: bo'lish (80 mm = 8 sm).</li></ul></div>",
 tn:"Keyingi mavzu: 1000 ga ko'paytirish va yaxlit sonlar bilan amallar."}
];
var PROBS=[
{t:"56 · 10 = ?",o:["560","5610","506","5600"],k:0,s:"Bir xona chapga: 560."},
{t:"39 · 100 = ?",o:["3900","390","39 000","3090"],k:0,s:"Ikki xona chapga: 3900."},
{t:"720 : 10 = ?",o:["72","7200","702","7"],k:0,s:"Bir xona o'ngga: 72."},
{t:"8600 : 100 = ?",o:["86","860","8","806"],k:0,s:"Ikki xona o'ngga: 86."},
{t:"405 · 10 = ?",o:["4050","4500","40 500","450"],k:0,s:"O'rtadagi 0 qoladi: 4050."},
{t:"9000 : 100 = ?",o:["90","9","900","9000"],k:0,s:"Ikkita 0 olinadi: 90."},
{t:"Qaysi son 10 ga qoldiqsiz bo'linadi?",o:["370","307","375","3007"],k:0,s:"Oxiri 0 bilan tugagan: 370."},
{t:"6 m = ? sm",o:["600","60","6000","106"],k:0,s:"1 m = 100 sm: 6 · 100 = 600."},
{t:"90 mm = ? sm",o:["9","900","90","19"],k:0,s:"1 sm = 10 mm: 90 : 10 = 9."},
{t:"3 m 8 sm = ? sm",o:["308","38","380","3008"],k:0,s:"300 + 8 = 308 sm."},
{t:"500 sm = ? m",o:["5","50","500","5000"],k:0,s:"500 : 100 = 5 m."},
{t:"□ · 10 = 640. □ · 100 = ?",o:["6400","640","64","64 000"],k:0,s:"□ = 64, 64 · 100 = 6400."},
{t:"□ : 10 = 38. □ = ?",o:["380","3,8","3800","48"],k:0,s:"□ = 38 · 10 = 380."},
{t:"(25 · 10) · 10 = ?",o:["2500","250","25 000","2510"],k:0,s:"25 · 100 = 2500."},
{t:"7000 : 10 : 10 = ?",o:["70","700","7","7000"],k:0,s:"7000 : 10 = 700, 700 : 10 = 70."},
{t:"Bitta daftar 100 so'm. 47 ta daftar necha so'm?",o:["4700","470","47 000","147"],k:0,s:"47 · 100 = 4700 so'm."},
{t:"2400 so'mga 100 so'mlik nechta tanga to'g'ri keladi?",o:["24","240","2400","204"],k:0,s:"2400 : 100 = 24."},
{t:"Qaysi tenglik noto'g'ri?",o:["306 · 10 = 3600","80 · 10 = 800","4500 : 10 = 450","700 : 100 = 7"],k:0,s:"306 · 10 = 3060, 3600 emas."},
{t:"Ip 3 m edi. Undan 10 sm lik bo'laklar kesilsa, nechta bo'lak chiqadi?",o:["30","3","300","13"],k:0,s:"3 m = 300 sm, 300 : 10 = 30."},
{t:"Sonni 10 ga ko'paytirib, 100 ga bo'ldik va 8 chiqdi. Son qaysi?",o:["80","8","800","18"],k:0,s:"Oxiridan: 8 · 100 = 800, 800 : 10 = 80. Tekshiruv: 80 · 10 = 800, 800 : 100 = 8."}
];
function PRACT_STAGE(){c7([{v:23},{v:230,lab:'·10'}],null,'·10 — chapga, :10 — o‘ngga')}
var PREP_DATA={teach:["10 va 100 ga ko'paytirish — raqamlarni chapga surish, bo'lish — o'ngga.","O'rtadagi va oxiridagi nollar.","Bo'lishda olinadigan nollar soni.","Kattaliklarni almashtirish (m, sm, mm) va teskari savollar."],
 mist:["306 · 10 = 3600 (o'rtadagi nolni tashlaydi).","5000 : 100 = 5 (ortiqcha nol oladi).","4 m 5 sm = 45 sm.","Katta → kichik birlikda bo'lib yuboradi."],
 need:["Xonalar jadvali (doskada yoki qog'ozda), raqam kartochkalari.","Metr lentasi, chizg'ich."],
 board:["<span class='w2'>23 · 10 = 230</span>, <span class='w2'>23 · 100 = 2300</span>","<span class='w2'>450 : 10 = 45</span>, <span class='w2'>3700 : 100 = 37</span>","<span class='w2'>306 · 10 = 3060</span>","<span class='w2'>5000 : 100 = 50</span>","<span class='w2'>7 m = 700 sm</span>, <span class='w2'>80 mm = 8 sm</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
