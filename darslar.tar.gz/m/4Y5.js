// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4Y5',TITLE='4-sinf · Fazoviy shakllar, yoyilmalar va burchaklar bo‘yicha qiyin masalalar';
function y5poly(pts,o){return E('polygon',Object.assign({points:pts.map(function(p){return p.join(',')}).join(' '),fill:'#fff3dc',stroke:C.line,'stroke-width':1.6,'stroke-linejoin':'round'},o||{}),S.g)}
function y5cube(x,y,s){var d=s*.45;y5poly([[x,y],[x+s,y],[x+s,y+s],[x,y+s]]);y5poly([[x,y],[x+d,y-d],[x+s+d,y-d],[x+s,y]],{fill:'#ffe7bf'});y5poly([[x+s,y],[x+s+d,y-d],[x+s+d,y+s-d],[x+s,y+s]],{fill:'#f7d39a'})}
function y5prism(x,y,s){var d=s*.6;y5poly([[x,y+s],[x+s,y+s],[x+s/2,y]]);y5poly([[x+s/2,y],[x+s/2+d,y-d*.4],[x+s+d,y+s-d*.4],[x+s,y+s]],{fill:'#f7d39a'})}
function y5pyr(x,y,s){var top=[x+s*.6,y-s*.7];y5poly([[x,y+s*.4],[x+s,y+s*.4],[x+s*1.3,y],[x+s*.3,y]],{fill:'#ffe7bf'});y5poly([[x,y+s*.4],[x+s,y+s*.4],top]);y5poly([[x+s,y+s*.4],[x+s*1.3,y],top],{fill:'#f7d39a'})}
function y5table(st){clear();y4title('Uchlar (U), qirralar (Q), yoqlar (Y)');var g=S.g;
 var R=[['kub',8,12,6],['uchburchakli prizma',6,9,5],['to‘rtburchakli piramida',5,8,5]];
 y5cube(26,72,34);y5prism(140,48,34);y5pyr(244,66,40);
 y4T(g,48,126,'kub',{'font-size':11,'font-weight':800});y4T(g,170,126,'prizma',{'font-size':11,'font-weight':800});y4T(g,280,126,'piramida',{'font-size':11,'font-weight':800});
 R.forEach(function(r,i){var x=[48,170,280][i];if(st>=1)y4T(g,x,146,'U '+r[1]+' · Q '+r[2]+' · Y '+r[3],{'font-size':11,'font-weight':800,fill:C.blue});if(st>=2)y4T(g,x,164,r[1]+' − '+r[2]+' + '+r[3]+' = 2',{'font-size':11,'font-weight':800,fill:C.ok})})}
var Y5P1=[function(){y5table(0);calc(['Uch — burchak nuqtasi, qirra — chiziq, yoq — tekis yuz'])},function(){y5table(1);calc(['Sanaymiz: kub 8–12–6, prizma 6–9–5, piramida 5–8–5'])},function(){y5table(2);calc(['Hammasida <b>U − Q + Y = 2</b> — Eyler formulasi!','Sanashda adashsangiz, formula tekshirib beradi'])}];
var Y5N=[[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]],[[0,0],[1,0],[2,0],[0,1],[1,1],[2,1]],[[0,0],[1,0],[1,1],[2,1],[2,2],[3,2]],[[0,0],[0,1],[1,1],[2,1],[3,1],[3,2]]];
function y5nets(sh){clear();y4title('Qaysi yoyilmadan kub yasab BO‘LMAYDI?');var g=S.g,s=15;
 Y5N.forEach(function(n,i){var x=[18,104,190,276][i],y=40;y4net(x,y,s,n.map(function(c){return [c[0],c[1]]}),sh&&i===1?'#ffd9d9':'#fff3dc');y4T(g,x+30,y+70,(i+1)+'-yoyilma',{'font-size':11,'font-weight':800,fill:sh&&i===1?C.bad:'#1d2b3a'})});
 if(sh)y4T(g,180,150,'2×3 to‘rtburchakda yoqlar ustma-ust tushadi',{'font-size':12,'font-weight':800,fill:C.bad})}
function y5opp(sh){clear();y4title('Kub yoyilmasi. Qaysi yoqlar qarama-qarshi?');var g=S.g;y4net(90,30,34,[[1,0,1],[0,1,2],[1,1,3],[2,1,4],[3,1,5],[2,2,6]],'#fff3dc',15);
 if(sh){[['1 ↔ 6',C.ok],['2 ↔ 4',C.blue],['3 ↔ 5',C.a2]].forEach(function(p,i){y4T(g,300,60+i*28,p[0],{'font-size':14,'font-weight':800,fill:p[1]})})}}
function y5paint(st){clear();y4title('4×4×4 kub tashqaridan bo‘yaldi va 64 kubchaga kesildi');var g=S.g,s=22,x0=30,y0=34;
 for(var r=0;r<4;r++)for(var c=0;c<4;c++){var corner=(r===0||r===3)&&(c===0||c===3),edge=!corner&&(r===0||r===3||c===0||c===3);var col='#fff';if(st>=1&&corner)col='#f08aa8';if(st>=2&&edge)col='#f0a040';if(st>=3&&!corner&&!edge)col='#5aa9e6';E('rect',{x:x0+c*s,y:y0+r*s,width:s,height:s,fill:col,stroke:'#8a5a24'},g)}
 var L=[['3 yog‘i: uchlarda — 8',C.c],['2 yog‘i: qirralarda 12 · 2 = 24',C.a],['1 yog‘i: yoqlarda 6 · 4 = 24',C.b],['0: ichida 2 · 2 · 2 = 8',C.grey]];
 L.forEach(function(l,i){if(i+1>st)return;E('rect',{x:140,y:38+i*26,width:12,height:12,fill:l[1]},g);y4T(g,158,48+i*26,l[0],{'font-size':11,'font-weight':800,'text-anchor':'start'})});
 if(st>=4)y4T(g,250,154,'8 + 24 + 24 + 8 = 64 ✓',{'font-size':12,'font-weight':800,fill:C.ok})}
var Y5P4=[function(){y5paint(0);calc(['Old yoq ko‘rinishi. Har kubchaning nechta yog‘i bo‘yalgan?'])},function(){y5paint(1);calc(['Kubning <b>uchlari</b>da: 3 yoq bo‘yalgan. Uchlar 8 ta → 8 kubcha'])},function(){y5paint(2);calc(['Har <b>qirra</b>da uchlardan tashqari 4 − 2 = 2 tadan. 12 qirra → 24'])},function(){y5paint(3);calc(['Har <b>yoq</b> o‘rtasida (4 − 2)·(4 − 2) = 4 tadan. 6 yoq → 24'])},function(){y5paint(4);calc(['Ichida: (4 − 2)³ = 2 · 2 · 2 = 8 — umuman bo‘yalmagan','Tekshirish: 8 + 24 + 24 + 8 = 64 ✓'])}];
function y5cone(sh){clear();y4title('Bu qaysi jismning yoyilmasi?');var g=S.g,cx=150,cy=30,r=84,a0=Math.PI*0.28,a1=Math.PI*0.72;
 E('path',{d:'M'+cx+' '+cy+' L'+(cx+r*Math.cos(a0))+' '+(cy+r*Math.sin(a0))+' A'+r+' '+r+' 0 0 1 '+(cx+r*Math.cos(a1))+' '+(cy+r*Math.sin(a1))+' Z',fill:'#fff3dc',stroke:C.line,'stroke-width':1.6},g);
 E('circle',{cx:cx,cy:cy+r+22,r:22,fill:'#fff3dc',stroke:C.line,'stroke-width':1.6},g);
 if(sh){E('path',{d:'M270 140 L300 50 L330 140',fill:'none',stroke:C.line,'stroke-width':1.6},g);E('ellipse',{cx:300,cy:140,rx:30,ry:9,fill:'#ffe7bf',stroke:C.line,'stroke-width':1.6},g);y4T(g,300,164,'konus',{'font-size':12,'font-weight':800,fill:C.ok})}}
function y5clock(st){clear();var T3=[[3,0,'90°'],[4,0,'120°'],[3,30,'75°']][st];y4title('Soat '+T3[0]+':'+(T3[1]?'30':'00')+' — millar orasidagi burchak');y4clock(110,96,62,T3[0],T3[1],true);
 var L=['Har soat belgisi orasi: 360° : 12 = 30°','4 oraliq · 30° = 120°','Soat mili ham yarim yo‘lda: 2,5 · 30° = 75°'][st];y4T(S.g,268,90,T3[2],{'font-size':22,'font-weight':800,fill:C.a2});y4T(S.g,268,124,st===2?'90° emas!':'',{'font-size':12,'font-weight':800,fill:C.bad})}
var Y5P6=[function(){y5clock(0);calc(['Har soat belgisi orasi: 360° : 12 = <b>30°</b>. 3 oraliq → 90°'])},function(){y5clock(1);calc(['4:00 da 4 oraliq: 4 · 30° = <b>120°</b>'])},function(){y5clock(2);calc(['3:30 da minut mili 6 da, soat mili esa 3 bilan 4 ning <b>o‘rtasida</b>!','2,5 oraliq: 2,5 · 30° = <b>75°</b>'])}];
function y5prot(sh){clear();y4title('Burchakni transportir bilan o‘lchash');var g=S.g,cx=180,cy=150,r=110;E('path',{d:'M'+(cx-r)+' '+cy+' A'+r+' '+r+' 0 0 1 '+(cx+r)+' '+cy+' Z',fill:'rgba(207,230,250,.5)',stroke:'#1f6fb2','stroke-width':1.5},g);
 for(var a=0;a<=180;a+=10){var t=a*Math.PI/180,x1=cx+r*Math.cos(Math.PI-t),y1=cy-r*Math.sin(Math.PI-t),x2=cx+(r-8)*Math.cos(Math.PI-t),y2=cy-(r-8)*Math.sin(Math.PI-t);E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:'#1f6fb2'},g);
  if(a%20===0&&a>0&&a<180){y4T(g,cx+(r-18)*Math.cos(Math.PI-t),cy-(r-18)*Math.sin(Math.PI-t)+3,String(a),{'font-size':9,fill:'#1f6fb2'});y4T(g,cx+(r-34)*Math.cos(Math.PI-t),cy-(r-34)*Math.sin(Math.PI-t)+3,String(180-a),{'font-size':9,fill:C.a2})}}
 E('line',{x1:cx,y1:cy,x2:cx+r+10,y2:cy,stroke:'#1d2b3a','stroke-width':3},g);var t2=40*Math.PI/180;E('line',{x1:cx,y1:cy,x2:cx+(r+10)*Math.cos(t2),y2:cy-(r+10)*Math.sin(t2),stroke:'#1d2b3a','stroke-width':3},g);
 E('path',{d:'M'+(cx+26)+' '+cy+' A26 26 0 0 0 '+(cx+26*Math.cos(t2))+' '+(cy-26*Math.sin(t2)),fill:'none',stroke:C.bad,'stroke-width':2.5},g);
 if(sh)y4T(g,cx+46,cy-8,'40°',{'font-size':13,'font-weight':800,fill:C.ok})}
function y5line(sh){clear();y4title('Yoyiq burchak 180° uch qismga bo‘lingan');var g=S.g,cx=180,cy=140;E('line',{x1:30,y1:cy,x2:330,y2:cy,stroke:'#1d2b3a','stroke-width':3},g);
 [70,135].forEach(function(a){var t=a*Math.PI/180;E('line',{x1:cx,y1:cy,x2:cx+110*Math.cos(t),y2:cy-110*Math.sin(t),stroke:'#1d2b3a','stroke-width':3},g)});
 y4T(g,cx+60,cy-16,'70°',{'font-size':13,'font-weight':800,fill:C.blue});y4T(g,cx+4,cy-56,sh?'65°':'x',{'font-size':15,'font-weight':800,fill:sh?C.ok:C.bad});y4T(g,cx-62,cy-14,'45°',{'font-size':13,'font-weight':800,fill:C.blue});
 if(sh)y4T(g,180,166,'180° − 70° − 45° = 65°',{'font-size':12,'font-weight':800,fill:C.ok})}
function y5plato(st){clear();y4title('Platon jismlari — muntazam ko‘pyoqlar');var g=S.g,R=[['tetraedr',4,'uchburchak'],['kub',6,'kvadrat'],['oktaedr',8,'uchburchak'],['dodekaedr',12,'beshburchak'],['ikosaedr',20,'uchburchak']];
 R.forEach(function(r,i){if(i>st*2+1&&st<2)return;var y=44+i*24;y4T(g,40,y,r[0],{'font-size':13,'font-weight':800,'text-anchor':'start'});y4T(g,170,y,r[1]+' yoq',{'font-size':12,'font-weight':800,fill:C.a2,'text-anchor':'start'});y4T(g,240,y,r[2],{'font-size':11,fill:'#3a4a5a','text-anchor':'start'})})}
var Y5P9=[function(){y5plato(0);calc(['Muntazam ko‘pyoqning hamma yoqlari bir xil muntazam ko‘pburchak'])},function(){y5plato(1);calc(['Ular bor-yo‘g‘i <b>5 ta</b> — oltinchisi yo‘q! Buni qadimgi yunonlar isbotlagan'])},function(){y5plato(2);calc(['O‘yin soqqalari ko‘pincha shu shakllarda yasaladi: 4, 6, 8, 12, 20 yoqli'])}];
function PRACT_STAGE(){clear();y4title('Avval chizib oling — keyin sanang');y5cube(40,80,50);y4net(170,40,22,[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]]);calc(['U − Q + Y = 2; soat: 1 belgi = 30°; yoyiq = 180°'])}
var STEPS=[
{h:"Uchlar, qirralar, yoqlar va Eyler formulasi",sum:"Kub 8–12–6, prizma 6–9–5, piramida 5–8–5. Hammasida U − Q + Y = 2.",a:"m01",
 start:function(){startPh(Y5P1)},fin:function(){S.ph=2;Y5P1[2]()},
 html:"<p>Ko'pyoqni uch xil narsa bilan tasvirlaymiz: <b>uch</b> (U), <b>qirra</b> (Q), <b>yoq</b> (Y). Sanab ko'ramiz:</p>",btns:[phaser(Y5P1)],
 after:"<p>Prizmada: asos n burchakli bo'lsa — U = 2n, Q = 3n, Y = n + 2. Piramidada: U = n + 1, Q = 2n, Y = n + 1. Va har doim <b>U − Q + Y = 2</b>.</p>",
 q:{t:"Ko'pyoqda 6 ta uch va 5 ta yoq bor. Uning nechta qirrasi bor?",opts:["9","11","13","1"],ok:0,why:"6 − Q + 5 = 2 → Q = 9.",hint:"Eyler formulasiga qo'ying: U − Q + Y = 2.",full:"6 − Q + 5 = 2 → 11 − Q = 2 → Q = 9. Bu — uchburchakli prizma. «11» — 6 + 5, «13» — 6 + 5 + 2."},
 tn:"Plastilin va cho'plardan kub, prizma, piramida yasating — bolalar uch, qirra, yoqlarni sanab jadvalga yozadi."},
{h:"Kub yoyilmasi: qaysi biri emas?",sum:"2×3 to'rtburchak — kub yoyilmasi emas: yoqlar ustma-ust tushadi.",a:"m02",
 start:function(){y5nets(0);calc(['Har yoyilmani xayolan buklang'])},fin:function(){y5nets(1);y4msg('<b>2-yoyilma</b> — kub bo‘lmaydi')},
 html:"<p>Har bir rasmda 6 ta kvadrat. Qaysi biridan kub yasab <b>bo'lmaydi</b>?</p>",
 btns:y4pick(1,[["1-yoyilma","Bu — «xoch»: 4 tasi halqa, ustida va ostida qopqoqlar. Kub bo'ladi."],["2-yoyilma","2×3 to'rtburchakni buklasak, 3 ta kvadrat bir chiziqda halqa bo'lolmaydi — yoqlar ustma-ust tushadi, ikki yoq ochiq qoladi."],["3-yoyilma","«Zinapoya» (2–2–2) — kub yoyilmasi, buklasa yopiladi."],["4-yoyilma","1–4–1 turidagi yoyilma: qopqoqlar turli tomonda — baribir kub bo'ladi."]],function(){y5nets(1)}),g2:1,
 after:"<p>Kubning <b>11 xil</b> yoyilmasi bor. Tekshirish qoidasi: bir qatorda 4 tadan ortiq kvadrat bo'lmasin; 2×2 kvadrat blok bo'lmasin (2×3 da ikkita shunday blok bor).</p>",
 q:{t:"Yoyilmada 2×2 kvadrat bloki (4 ta kvadrat kvadrat shaklida) bor. Undan kub yasash mumkinmi?",opts:["Yo'q, hech qachon","Ha, har doim","Faqat yana 2 ta kvadrat yonida bo'lsa","Faqat qog'oz qalin bo'lsa"],ok:0,why:"2×2 blokdagi 4 kvadrat bir uchda to'planadi — kub uchida faqat 3 yoq uchrashadi.",hint:"Kubning bitta uchida nechta yoq uchrashadi?",full:"Kubning har uchida 3 ta yoq uchrashadi. 2×2 blokda markazda 4 ta kvadrat uchrashadi — buklab bo'lmaydi. Shuning uchun bunday yoyilma kub bermaydi."},
 tn:"Katakli qog'ozdan yoyilmalarni kesib, buklab ko'rish — eng yaxshi isbot."},
{h:"Qarama-qarshi yoqlar",sum:"Xoch yoyilmada: qatorda bittadan keyingisi qarama-qarshi (2↔4, 3↔5), ustki va ostki (1↔6).",a:"m03",
 start:function(){y5opp(0);calc(['1 raqamli yoqqa qarama-qarshi yoq qaysi?'])},fin:function(){y5opp(1);y4msg('1 ↔ <b>6</b>, 2 ↔ 4, 3 ↔ 5')},
 html:"<p>Yoyilmani buklasak, qaysi yoq 1 raqamli yoqning <b>qarama-qarshisida</b> bo'ladi?</p>",
 btns:y4pick(0,[["6","Qatordan tashqaridagi ikki kvadrat (ustki va ostki) buklanganda qopqoq va tub bo'ladi — qarama-qarshi."],["3","3 — 1 ning ostida yonma-yon: ular qo'shni yoqlar (umumiy qirra bor)."],["4","4 — yon tomonda, 1 ga qo'shni."],["5","5 — ham qo'shni yoq."]],function(){y5opp(1)}),g2:1,
 after:"<p>Qoida: yoyilmada bir qatordagi kvadratlardan <b>bittasi oralab</b> turganlari qarama-qarshi bo'ladi (2 va 4). Yonma-yon turganlari doim qo'shni. O'yin soqqasida qarama-qarshi yoqlar yig'indisi 7: 1–6, 2–5, 3–4.</p>",
 q:{t:"Shu yoyilmada 3 raqamli yoqning qarama-qarshisida qaysi yoq?",opts:["5","4","1","2"],ok:0,why:"Qatorda 3 va 5 orasida bitta kvadrat (4).",hint:"Qatorda 3 dan bittasini oralab qaysi kvadrat turadi?",full:"Qator: 2, 3, 4, 5. 3 dan bitta oralab — 5. Shuning uchun 3 ↔ 5. 4 va 2 — 3 ga qo'shni, 1 esa 3 ning ustida — qo'shni."},
 tn:"Haqiqiy kub (karton quti) yoqlariga raqam yozib, yoyib ko'rsating."},
{h:"Bo'yalgan kub: 4×4×4",sum:"3 yoqli — 8, 2 yoqli — 24, 1 yoqli — 24, bo'yalmagan — 8; jami 64.",a:"m04",
 start:function(){startPh(Y5P4)},fin:function(){S.ph=4;Y5P4[4]()},
 html:"<p>4×4×4 kub tashqaridan bo'yalib, 64 ta kichik kubchaga kesildi. Nechta kubchaning nechta yog'i bo'yalgan? Bosing:</p>",btns:[phaser(Y5P4)],
 after:"<p>Umumiy qoida (n×n×n): 3 yoqli — doim <b>8</b> (uchlar); 2 yoqli — <b>12 · (n − 2)</b>; 1 yoqli — <b>6 · (n − 2)²</b>; bo'yalmagan — <b>(n − 2)³</b>. Har doim tekshiring: yig'indi n³.</p>",
 q:{t:"3×3×3 kub bo'yalib, 27 ta kubchaga kesildi. Nechta kubchaning hech bir yog'i bo'yalmagan?",opts:["1","0","8","6"],ok:0,why:"(3 − 2)³ = 1 — markazdagi kubcha.",hint:"Ichki kub qanday o'lchamda?",full:"Ichki kub: (3 − 2) × (3 − 2) × (3 − 2) = 1. Tekshirish: 8 + 12 + 6 + 1 = 27 ✓. «6» — 1 yoqli kubchalar, «8» — uchlardagi."},
 tn:"Konstruktor kubiklaridan 3×3×3 yasab, ustini qog'oz bilan o'rab chiqing — bolalar o'zi sanaydi."},
{h:"Silindr va konus yoyilmasi",sum:"Konus: doira + doira sektori. Silindr: 2 doira + to'g'ri to'rtburchak.",a:"m05",
 start:function(){y5cone(0);calc(['Sektor va doira — qaysi jism?'])},fin:function(){y5cone(1);y4msg('<b>Konus</b>: yon sirti — sektor, asosi — doira')},
 html:"<p>Rasmda — qog'ozdan kesilgan yoyilma. Buklasak, qaysi jism hosil bo'ladi?</p>",
 btns:y4pick(0,[["Konus","Sektor buklanib «qalpoq» bo'ladi, doira — uning tagi."],["Silindr","Silindr yoyilmasida to'g'ri to'rtburchak va ikkita doira bo'ladi."],["Piramida","Piramida yoqlari tekis ko'pburchaklar, egri chiziq yo'q."],["Shar","Sharni tekis qog'ozga yoyib bo'lmaydi."]],function(){y5cone(1)}),g2:1,
 after:"<p><b>Silindr</b>: ikki doira (asoslar) + to'g'ri to'rtburchak (yon sirt); to'rtburchakning bir tomoni — balandlik, ikkinchisi — asos aylanasining uzunligi. <b>Konus</b>: doira + sektor. <b>Shar</b> yoyilmaydi.</p>",
 q:{t:"Silindr yoyilmasidagi to'g'ri to'rtburchakning bir tomoni — balandlik. Ikkinchi tomoni nimaga teng?",opts:["Asos aylanasining uzunligiga","Asos radiusiga","Asos diametriga","Balandlikning yarmiga"],ok:0,why:"Yon sirt asosni bir marta aylanib o'raydi.",hint:"Yorliqni bankadan ajratsangiz, uning uzunligi nimaga teng?",full:"Yon sirt asosning atrofini o'raydi, shuning uchun uning uzunligi — aylana uzunligi. Radius va diametr undan ancha qisqa."},
 tn:"Konserva bankasining yorlig'ini ehtiyotkor ajratib, to'g'ri to'rtburchak ekanini ko'rsating."},
{h:"Soat millari orasidagi burchak",sum:"1 belgi = 30°. 3:00 → 90°, 4:00 → 120°, 3:30 → 75° (soat mili ham suriladi!).",a:"m06",
 start:function(){startPh(Y5P6)},fin:function(){S.ph=2;Y5P6[2]()},
 html:"<p>Soat millari burchak hosil qiladi. Ularni hisoblash usuli. Bosing:</p>",btns:[phaser(Y5P6)],
 after:"<p>Soat siferblati — 360°, 12 belgi: har oraliq <b>30°</b>. Tuzoq: yarim soatda soat mili ham yarim oraliq suriladi (15°). Shuning uchun 3:30 da 90° emas, 75°.</p>",
 q:{t:"Soat 9:30 da millar orasidagi burchak (kichigi)?",opts:["105°","90°","120°","75°"],ok:0,why:"Minut mili 6 da, soat mili 9 bilan 10 ning o'rtasida: 3,5 · 30° = 105°.",hint:"Soat mili 9:30 da qayerda turadi?",full:"Minut mili — 6 da. Soat mili — 9 dan yarim oraliq o'tgan. 6 dan 9,5 gacha 3,5 oraliq: 3,5 · 30° = 105°. «90°» — soat milini 9 da turibdi deb olish."},
 tn:"Karton soat bilan ishlang: minut milini aylantirganda soat mili ham qanday surilishini ko'rsating."},
{h:"Tuzoq: transportirning ikki shkalasi",sum:"Tomon ichki shkalaning 0 idan boshlansa, o'sha shkaladan o'qiymiz: 40°, 140° emas.",a:"m07",
 start:function(){y5prot(0);calc(['Burchak necha gradus? Ikki shkala bor — qaysi biri?'])},fin:function(){y5prot(1);y4msg('<b>40°</b> — o‘tkir burchak')},
 html:"<p>Transportirda ikki qator son bor (ko'k va to'q sariq). Rasmdagi burchak necha gradus?</p>",
 btns:y4pick(0,[["40°","Pastki tomon o'ngdagi 0 dan (ichki, to'q sariq shkala) boshlanadi — shu shkaladan o'qiymiz. Burchak o'tkir — 40° mantiqan to'g'ri."],["140°","Bu boshqa shkala. Burchak o'tkir (90° dan kichik) — 140° bo'lishi mumkin emas."],["50°","90° − 40° — bu qo'shni burchak emas."],["130°","Bunday belgi yo'q: ehtimol shkalalarni adashtirdingiz."]],function(){y5prot(1)}),g2:1,
 after:"<p>Ikki qadam: 1) burchakning qaysi tomoni <b>0 dan</b> boshlanayotganini toping — o'sha shkaladan o'qing; 2) natijani ko'z bilan tekshiring: o'tkir (&lt; 90°) yoki o'tmas (&gt; 90°)?</p>",
 q:{t:"Transportirda burchak tomoni ichki shkalada 70 ni, tashqi shkalada 110 ni ko'rsatmoqda. Burchak o'tmas. U necha gradus?",opts:["110°","70°","180°","40°"],ok:0,why:"O'tmas burchak 90° dan katta: 110°.",hint:"O'tmas burchak 90° dan kattami, kichikmi?",full:"Ikki o'qish: 70° yoki 110°. Burchak o'tmas — 90° dan katta, demak 110°. «180°» — 70 + 110, «40°» — 110 − 70."},
 tn:"Har bolaga transportir: bitta burchakni ikki xil joylashtirib o'lchash mashqi."},
{h:"Burchaklarning yig'indisi",sum:"Yoyiq burchak 180°: x = 180° − 70° − 45° = 65°.",a:"m08",
 start:function(){y5line(0);calc(['Yoyiq burchak = 180°. x ni toping'])},fin:function(){y5line(1);y4msg('x = <b>65°</b>')},
 html:"<p>To'g'ri chiziqdan bir nuqtadan ikki nur chiqqan va yoyiq burchakni uch qismga bo'lgan. x necha gradus?</p>",
 btns:y4pick(1,[["115°","180 − 70 + … — faqat bitta burchakni ayirdingiz. 45° ni ham ayiring."],["65°","70 + x + 45 = 180 → x = 180 − 115 = 65."],["25°","90° dan ayirdingiz — bu yerda burchak yoyiq (180°), to'g'ri emas."],["135°","180 − 45 — 70° ni ham ayirish kerak."]],function(){y5line(1)}),g2:1,
 after:"<p>Yoyiq burchak — <b>180°</b>, to'g'ri burchak — <b>90°</b>, to'liq aylanish — <b>360°</b>. Noma'lum qism = butun − ma'lum qismlar.</p>",
 q:{t:"To'g'ri burchak ikki burchakka bo'lindi, biri ikkinchisidan 30° katta. Kattasi necha gradus?",opts:["60°","45°","30°","75°"],ok:0,why:"(90 + 30) : 2 = 60; kichigi 30.",hint:"Yig'indi 90°, farq 30°.",full:"Kattasi + kichigi = 90, kattasi − kichigi = 30. Kattasi = (90 + 30) : 2 = 60°, kichigi 30°. «45°» — farqni unutish, «75°» — 45 + 30."},
 tn:"Qog'oz doirani buklab 180° va 90° ni ko'rsating; bo'laklarni qaychi bilan kesib qo'shib ko'ring."},
{h:"Bilasizmi? Platon jismlari",sum:"Muntazam ko'pyoqlar faqat 5 ta: tetraedr, kub, oktaedr, dodekaedr, ikosaedr.",a:"m09",
 start:function(){startPh(Y5P9)},fin:function(){S.ph=2;Y5P9[2]()},
 html:"<p>Hamma yoqlari bir xil muntazam ko'pburchak bo'lgan ko'pyoqlar nechta? Bosing:</p>",btns:[phaser(Y5P9)],
 after:"<p>🏛 Bu besh jism qadimgi yunon faylasufi Platon nomi bilan ataladi. Evklid «Negizlar» kitobida boshqa muntazam ko'pyoq yo'qligini isbotlagan. Eyler formulasi esa (U − Q + Y = 2) XVIII asrda topilgan — tekshirib ko'ring: ikosaedr 12 − 30 + 20 = 2.</p>",
 tn:"Ikosaedr yoki dodekaedr yoyilmasini chiqarib, bolalar bilan yelimlab yasang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li>U − Q + Y = 2. Prizma (n): 2n, 3n, n + 2. Piramida (n): n + 1, 2n, n + 1.</li><li>Kub yoyilmasida: qatorda ≤ 4 kvadrat, 2×2 blok bo'lmaydi. 11 xil yoyilma.</li><li>Qarama-qarshi yoqlar — qatorda bittasini oralab.</li><li>n×n×n bo'yalgan kub: 8; 12(n − 2); 6(n − 2)²; (n − 2)³.</li><li>Soat: 1 oraliq = 30°; yarim soatda soat mili 15° suriladi.</li><li>Transportir: 0 dan boshlangan shkala; o'tkir/o'tmasni tekshiring. Yoyiq 180°, to'g'ri 90°.</li></ul></div>",
 tn:"Uyga: uydagi buyumlardan 3 ta ko'pyoq topib, U, Q, Y sanash."}
];
var PROBS=[
{t:"Kubning nechta qirrasi bor?",o:["12","6","8","24"],k:0,s:"4 · 3 = 12."},
{t:"Uchburchakli prizmaning nechta uchi bor?",o:["6","5","9","3"],k:0,s:"2 · 3 = 6."},
{t:"To'rtburchakli piramidaning nechta yog'i bor?",o:["5","4","8","6"],k:0,s:"Asos + 4 yon yoq."},
{t:"Ko'pyoqda 8 ta uch va 12 ta qirra bor. Nechta yog'i bor?",o:["6","4","20","2"],k:0,s:"8 − 12 + Y = 2 → Y = 6."},
{t:"Oltiburchakli prizmaning nechta qirrasi bor?",o:["18","12","6","24"],k:0,s:"3 · 6 = 18."},
{t:"6 ta kvadrat 2 qator, 3 tadan to'g'ri to'rtburchak shaklida joylashgan. Undan kub yasash mumkinmi?",o:["Yo'q, mumkin emas","Ha, mumkin","Ha, ikki xil usulda","Faqat bitta yoqni olib tashlasa"],k:0,s:"2×2 bloklar bor — buklab bo'lmaydi."},
{t:"Kub yoyilmasi: qatorda 2, 3, 4, 5; 1 — 3 ning ustida, 6 — 4 ning ostida. 2 ga qarama-qarshi yoq?",o:["4","1","3","6"],k:0,s:"Qatorda bittasini oralab."},
{t:"4×4×4 kub bo'yalib, 64 ta kubchaga bo'lindi. Nechtasining aynan 2 yog'i bo'yalgan?",o:["24","8","12","48"],k:0,s:"12 · (4 − 2) = 24."},
{t:"3×3×3 bo'yalgan kubda nechta kubchaning hech bir yog'i bo'yalmagan?",o:["1","0","8","6"],k:0,s:"(3 − 2)³ = 1."},
{t:"4×4×4 bo'yalgan kubda nechta kubchaning hech bir yog'i bo'yalmagan?",o:["8","4","16","0"],k:0,s:"(4 − 2)³ = 8."},
{t:"Soat 3:00 da millar orasidagi burchak?",o:["90°","3°","45°","180°"],k:0,s:"3 · 30°."},
{t:"Soat 5:00 da millar orasidagi burchak?",o:["150°","50°","120°","180°"],k:0,s:"5 · 30°."},
{t:"Soat 9:30 da millar orasidagi burchak (kichigi)?",o:["105°","90°","120°","75°"],k:0,s:"3,5 · 30°."},
{t:"Yoyiq burchak uch qismga bo'lindi: 70°, x va 45°. x = ?",o:["65°","115°","25°","75°"],k:0,s:"180 − 115 = 65."},
{t:"To'g'ri burchak ikki burchakka bo'lindi, biri ikkinchisidan 30° katta. Kattasi?",o:["60°","45°","30°","75°"],k:0,s:"(90 + 30) : 2."},
{t:"Konus yoyilmasi qaysi shakllardan iborat?",o:["Doira va doira sektori","Ikki doira va to'g'ri to'rtburchak","Faqat uchburchaklar","Faqat doira"],k:0,s:"Yon sirt — sektor, asos — doira."},
{t:"Silindr yoyilmasidagi to'g'ri to'rtburchakning bir tomoni — balandlik. Ikkinchisi?",o:["Asos aylanasining uzunligi","Asos radiusi","Asos diametri","Balandlikning yarmi"],k:0,s:"Yon sirt asosni o'raydi."},
{t:"Kubning barcha qirralari yig'indisi 48 sm. Bitta yog'ining yuzi?",o:["16 sm²","4 sm²","64 sm²","96 sm²"],k:0,s:"Qirra 48 : 12 = 4; 4 · 4 = 16."},
{t:"Ko'pyoqda 6 ta uch va 5 ta yoq bor. Nechta qirrasi bor?",o:["9","11","13","1"],k:0,s:"6 − Q + 5 = 2."},
{t:"Transportirda tomon ichki shkalada 40 ni, tashqi shkalada 140 ni ko'rsatadi. Burchak o'tkir. Necha gradus?",o:["40°","140°","100°","180°"],k:0,s:"O'tkir < 90°."}
];
var PREP_DATA={teach:["Uch, qirra, yoq; prizma va piramida uchun formulalar; Eyler formulasi.","Kub yoyilmalari: to'g'ri va noto'g'ri; qarama-qarshi yoqlar.","Bo'yalgan n×n×n kub.","Silindr, konus yoyilmasi; shar yoyilmaydi.","Soat millari burchagi, transportir tuzog'i, yoyiq va to'g'ri burchak qismlari."],
 mist:["Qirralarni ikki marta yoki kam sanaydi.","2×3 to'rtburchakni kub yoyilmasi deb o'ylaydi.","Qo'shni yoqlarni qarama-qarshi deb oladi.","3:30 da soat milini 3 da deb hisoblaydi.","Transportirda noto'g'ri shkaladan o'qiydi."],
 need:["Karton kub, konserva bankasi, plastilin va cho'plar.","Katakli qog'oz (yoyilma), transportir, karton soat."],
 board:["<span class='w2'>U − Q + Y = 2</span>.","Kub: 8 · 12 · 6. n×n×n: 8; 12(n − 2); 6(n − 2)²; (n − 2)³.","Soat: <span class='w2'>1 oraliq = 30°</span>, 3:30 → 75°.","Yoyiq = 180°, to'g'ri = 90°."]};
