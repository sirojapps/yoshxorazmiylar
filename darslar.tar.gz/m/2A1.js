var CODE='2A1',TITLE='2-sinf · Ikki xonali sonlar: o\u2018nlik va birlik';

function pad(n){return n<10?'0'+n:''+n}
// ===================== SAHNA =====================
var NS='http://www.w3.org/2000/svg',sv=document.getElementById('sv'),strip=document.getElementById('strip');
function E(t,a,p){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
function tween(ms,f){return new Promise(function(res){var t0=performance.now();function s(n){var t=Math.min(1,(n-t0)/ms);f(t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2);if(t<1)requestAnimationFrame(s);else res()}requestAnimationFrame(s)})}
function wait(ms){return new Promise(function(r){setTimeout(r,ms)})}
function rnd(s){return function(){s=(s*16807)%2147483647;return (s-1)/2147483646}}
var COL={t1:'#a8601f',t2:'#e8a55d',u:'#12a39f',hi:'#ffd24d'};
var TENS=['','o‘n','yigirma','o‘ttiz','qirq','ellik','oltmish','yetmish','sakson','to‘qson'],ONES=['','bir','ikki','uch','to‘rt','besh','olti','yetti','sakkiz','to‘qqiz'];
function word(n){if(n===0)return 'nol';return (TENS[Math.floor(n/10)]+' '+ONES[n%10]).trim()}
var S={frames:[],loose:[],mode:'pv',tok:0};
function fPos(i){return [14+(i%3)*76,34+Math.floor(i/3)*42]}
function dPos(i,j){var p=fPos(i);return [p[0]+8+(j%5)*13.5,p[1]+8+Math.floor(j/5)*14]}
function lPos(k){return [266+(k%5)*18,52+Math.floor(k/5)*22]}
function bg(){sv.innerHTML='';E('rect',{x:4,y:4,width:236,height:166,rx:12,fill:'#fdf3e3',stroke:'#efd9b5'},sv);E('rect',{x:246,y:4,width:110,height:166,rx:12,fill:'#e3f5f3',stroke:'#bfe6e1'},sv);
 var a=E('text',{x:122,y:24,'text-anchor':'middle','font-size':13,'font-weight':700,fill:COL.t1},sv);a.textContent='O‘nliklar (to‘la qutilar)';
 var b=E('text',{x:301,y:24,'text-anchor':'middle','font-size':13,'font-weight':700,fill:COL.u},sv);b.textContent='Birliklar';
 S.gF=E('g',{},sv);S.gD=E('g',{},sv);S.gX=E('g',{},sv)}
function frameBox(i){var p=fPos(i);var g=E('g',{},S.gF);E('rect',{x:p[0],y:p[1],width:72,height:30,rx:6,fill:'#fff',stroke:'#d9b98a','stroke-width':1.5},g);for(var j=0;j<10;j++){var d=dPos(i,j);E('circle',{cx:d[0],cy:d[1],r:5.6,fill:'none',stroke:'#ecdcc3'},g)}g._i=i;return g}
function dot(x,y,c){var e=E('circle',{cx:x,cy:y,r:5.6,fill:c,stroke:'rgba(0,0,0,.18)'},S.gD);e._x=x;e._y=y;return e}
function mvd(e,x,y){e.setAttribute('cx',x);e.setAttribute('cy',y)}
function setPV(t,u){S.tok++;S.mode='pv';bg();S.frames=[];S.loose=[];S.fb=[];
 for(var i=0;i<t;i++){S.fb.push(frameBox(i));var f=[];for(var j=0;j<10;j++){var d=dPos(i,j);f.push(dot(d[0],d[1],j<5?COL.t1:COL.t2))}S.frames.push(f)}
 for(var k=0;k<u;k++){var q=lPos(k);S.loose.push(dot(q[0],q[1],COL.u))}
 S.fb.forEach(bindOpen);showStrip(true)}
function setScatter(n,seed){S.tok++;S.mode='sc';sv.innerHTML='';E('rect',{x:2,y:2,width:356,height:170,rx:14,fill:'#f7ead2',stroke:'#e6d0a8'},sv);S.gF=E('g',{},sv);S.gD=E('g',{},sv);S.gX=E('g',{},sv);
 var R=rnd(seed||5);S.frames=[];S.loose=[];S.fb=[];for(var i=0;i<n;i++){var x=18+R()*324,y=16+R()*142;S.loose.push(dot(x,y,'#d08a3a'))}showStrip(false)}
function showStrip(on,t,u){if(!on){strip.innerHTML='<span class="w" style="margin:0 auto">Nechta? Hali bilmaymiz…</span>';return}
 t=t==null?S.frames.length:t;u=u==null?S.loose.length:u;var ok=u<10;
 strip.innerHTML='<div class="c ct"><small>O‘nliklar</small><b class="tcol">'+t+'</b></div><div class="c cu"><small>Birliklar</small><b class="ucol">'+u+'</b></div>'+(ok?'<span class="n"><span class="tcol">'+(t||'')+'</span><span class="ucol">'+u+'</span></span><span class="w">'+(t*10)+' + '+u+'<br>'+word(t*10+u)+'</span>':'<span class="n" style="color:var(--bad)">?</span><span class="w">birliklar 10 tadan<br>ko‘p — sig‘maydi</span>')}
function big(txt,col){S.gX.innerHTML='';if(txt==null)return;var b=E('text',{x:180,y:164,'text-anchor':'middle','font-size':22,'font-weight':800,fill:col||'#1f6fb2',stroke:'#fff','stroke-width':5,'paint-order':'stroke'},S.gX);b.textContent=txt}
// to'la qutini ochib ko'rish: ichidagi 10 ta donani raqamlaydi
var openCb=null;
function bindOpen(g){g.style.cursor='pointer';g.addEventListener('click',function(){openFrame(g._i)})}
function openFrame(i){var old=sv.querySelector('.lbl'+i);if(old){[].slice.call(sv.querySelectorAll('.lbl'+i)).forEach(function(e){e.remove()});return}
 for(var j=0;j<10;j++){var d=dPos(i,j);var t=E('text',{x:d[0],y:d[1]+3.5,'text-anchor':'middle','font-size':8,'font-weight':800,fill:'#fff',class:'lbl'+i,'pointer-events':'none'},S.gX);t.textContent=j+1}
 if(openCb)openCb()}
// sochilgan donalarni qutilarga joylash
async function pack(){var tok=S.tok,ds=S.loose.slice();S.loose=[];var nf=Math.floor(ds.length/10);bg2();
 for(var i=0;i<nf;i++){S.fb.push(frameBox(i));var f=[];var grp=ds.slice(i*10,i*10+10);
  await tween(650,function(k){grp.forEach(function(e,j){var d=dPos(i,j);mvd(e,e._x+(d[0]-e._x)*k,e._y+(d[1]-e._y)*k)})});if(tok!==S.tok)return;
  grp.forEach(function(e,j){var d=dPos(i,j);e._x=d[0];e._y=d[1];e.setAttribute('fill',j<5?COL.t1:COL.t2);f.push(e)});S.frames.push(f);showStrip(true,S.frames.length,0)}
 var rest=ds.slice(nf*10);await tween(500,function(k){rest.forEach(function(e,j){var q=lPos(j);mvd(e,e._x+(q[0]-e._x)*k,e._y+(q[1]-e._y)*k)})});if(tok!==S.tok)return;
 rest.forEach(function(e,j){var q=lPos(j);e._x=q[0];e._y=q[1];e.setAttribute('fill',COL.u)});S.loose=rest;S.fb.forEach(bindOpen);showStrip(true)}
function bg2(){var keep=[].slice.call(S.gD.childNodes);S.mode='pv';bg();keep.forEach(function(e){S.gD.appendChild(e)})}
// birliklardan 10 tasini yangi qutiga
async function regroup(){var tok=S.tok,i=S.frames.length,grp=S.loose.slice(0,10);var g=frameBox(i);S.fb.push(g);
 await tween(800,function(k){grp.forEach(function(e,j){var d=dPos(i,j);mvd(e,e._x+(d[0]-e._x)*k,e._y+(d[1]-e._y)*k)})});if(tok!==S.tok)return;
 grp.forEach(function(e,j){var d=dPos(i,j);e._x=d[0];e._y=d[1];e.setAttribute('fill',j<5?COL.t1:COL.t2)});S.frames.push(grp);S.loose=S.loose.slice(10);
 await tween(400,function(k){S.loose.forEach(function(e,j){var q=lPos(j);mvd(e,e._x+(q[0]-e._x)*k,e._y+(q[1]-e._y)*k)})});S.loose.forEach(function(e,j){var q=lPos(j);e._x=q[0];e._y=q[1]});bindOpen(g);showStrip(true)}
function glowF(i,on){S.frames[i].forEach(function(e,j){e.setAttribute('fill',on?COL.hi:(j<5?COL.t1:COL.t2))})}
function glowU(k,on){S.loose[k].setAttribute('fill',on?COL.hi:COL.u)}
async function countAll(){var tok=S.tok,n=0;for(var i=0;i<S.frames.length;i++){n+=10;glowF(i,1);big(word(n)+' — '+n,COL.t1);await wait(900);if(tok!==S.tok)return}
 for(var k=0;k<S.loose.length;k++){n++;glowU(k,1);big(word(n)+' — '+n,COL.u);await wait(700);if(tok!==S.tok)return}
 big('Hammasi: '+n);await wait(600);S.frames.forEach(function(f,i){glowF(i,0)});S.loose.forEach(function(e,k){glowU(k,0)})}
function egypt(t,u){var g=S.gX;g.innerHTML='';E('rect',{x:20,y:100,width:320,height:66,rx:10,fill:'#f3e2b8',stroke:'#c9a764'},g);
 var x=40;for(var i=0;i<t;i++){E('path',{d:'M'+x+' 156 L'+x+' 130 Q'+(x+11)+' 112 '+(x+22)+' 130 L'+(x+22)+' 156',fill:'none',stroke:'#6b3d12','stroke-width':4,'stroke-linecap':'round'},g);x+=30}
 x+=8;for(var k=0;k<u;k++){E('line',{x1:x,y1:124,x2:x,y2:158,stroke:'#6b3d12','stroke-width':4,'stroke-linecap':'round'},g);x+=13}
 var tt=E('text',{x:330,y:116,'text-anchor':'end','font-size':11,fill:'#6b3d12'},g);tt.textContent='Qadimgi Misr: ∩ = 10, | = 1'}
// ===================== QADAMLAR =====================
var PRAISE=[["ok1","Barakalla!"],["ok2","Ha, aynan shunday!"],["ok3","Zo'r, topdingiz!"],["ok4","Juda yaxshi!"]];
var STEPS=[
{h:"Sanab ko'ring-chi",sum:"34 ta dona aralash yotsa, bittalab sanash qiyin — adashib ketamiz.",a:"m01",
 start:function(){setScatter(34,5)},fin:function(){setScatter(34,5)},
 html:"<p>Tepadagi rasmga qarang: <b>donalar</b> sochilib yotibdi. Nechta ekan? Har bir donani <b>bosib</b>, bittalab sanang.</p>",
 act:function(c,done){var n=0,info=c.querySelector('.hint');info.textContent='Rasmdagi donalarni bosing.';S.loose.forEach(function(e){e.style.cursor='pointer';e.addEventListener('click',function(){if(e._c)return;e._c=1;n++;e.setAttribute('fill','#7fb3e0');var t=E('text',{x:e._x,y:e._y+4,'text-anchor':'middle','font-size':10,'font-weight':800,fill:'#0d3d66',stroke:'#fff','stroke-width':2.5,'paint-order':'stroke','pointer-events':'none'},S.gX);t.textContent=n;info.innerHTML='Sanadingiz: <b>'+n+'</b>';if(n===8)done()})})},
 after:"<p>Qiyin bo'ldi-a? Donalar aralash. Qaysi birini sanadingiz, qaysi birini yo'q — eslab qolish qiyin. Bittasini o'tkazib yuborsak, hammasini boshidan sanaymiz.</p>",
 q:{t:"Aralash yotgan narsalarni bittalab sanaganda nima qiyin?",opts:["Adashib ketish oson","Donalar juda kichik","Hech narsa qiyin emas","Sanab bo'lmaydi"],ok:0,why:"Ko'p narsani bittalab sanaganda adashib ketish oson.",hint:"Sanayotganingizda nima bo'ldi? Qaysi birini sanaganingiz esingizdami?",full:"Narsa ko'p va aralash bo'lsa, qaysi birini sanaganimizni unutamiz. Shuning uchun adashish oson. Buning oson yo'li bor — keyingi qadamda."},
 tn:"Har bir bolaga 30–40 ta tugma, loviya yoki cho'p bering, sanatib ko'ring. Javoblar har xil chiqadi — bolalar «muammo»ni o'zi his qilsin."},
{h:"O'ntalik qutilarga joylaymiz",sum:"Har qutiga 10 ta: 5 ta to'q + 5 ta och. To'la quti bir qarashda ko'rinadi — sanash shart emas.",a:"m02",
 start:function(){setScatter(34,5)},fin:function(){setPV(3,4)},
 html:"<p>Har bir qutida <b>10 ta</b> joy bor: tepada 5 ta, pastda 5 ta. Donalarni qutilarga joylaymiz. Tugmani bosing.</p>",
 btns:[["📦 Qutilarga joylash",function(c,done,b){b.disabled=true;pack().then(function(){b.textContent='4 ta dona qutini to‘ldirmadi';done()})}]],
 after:"<p>Qarang: <b>to'la qutini sanash shart emas</b> — 5 ta to'q va 5 ta och, demak <b>10</b>. Tuxum qutisi ham xuddi shunday: ikki qator, har birida beshtadan.</p><div class='life'><div>🥚<span>tuxum qutisi — <b>10 ta</b></span></div><div>🖐🖐<span>ikki qo'l — 5 + 5 = <b>10 ta</b> barmoq</span></div></div>",
 q:{t:"Nechta to'la quti va nechta dona qoldi?",opts:["3 quti, 4 dona","4 quti, 3 dona","34 quti","3 quti, 0 dona"],ok:0,why:"3 ta to'la quti va 4 ta dona.",hint:"Rasmga qarang: chapda nechta to'la quti? O'ngda nechta dona?",full:"Chapda 3 ta to'la quti turibdi. O'ngda 4 ta dona qoldi — ular 10 taga yetmagani uchun qutini to'ldirmadi."},
 tn:"Tuxum qutisi yoki 2×5 katakli kartochka (doskaga chizilgan) ishlating. Yaponiya va Singapur darsliklari ham shunday qiladi: «to'la 10» bir qarashda ko'rinadi, bola sanamaydi."},
{h:"Endi sanash oson",sum:"Qutilarni o'ntadan: 10, 20, 30. Keyin donalarni bittadan: 31, 32, 33, 34.",a:"m03",
 start:function(){setPV(3,4)},fin:function(){setPV(3,4)},
 html:"<p>Qutilarni <b>o'ntadan</b> sanaymiz: o'n, yigirma, o'ttiz. Keyin donalarni <b>bittadan</b> qo'shamiz. Kuzating.</p>",
 btns:[["▶ Sanaymiz",function(c,done,b){b.disabled=true;countAll().then(function(){b.disabled=false;b.textContent='↻ Yana sanash';done()})}]],
 after:"<p>Hammasi <b>34 ta</b>. Bittalab sanashdan ancha tez va adashmaymiz!</p>",
 q:{t:"5 ta to'la quti va 2 ta dona. Hammasi nechta?",opts:["7","52","25","502"],ok:1,why:"O'n, yigirma, o'ttiz, qirq, ellik — va yana ikkita: ellik ikki.",hint:"Qutilarni o'ntadan sanang: o'n, yigirma… Keyin donalarni qo'shing.",full:"Har qutida 10 ta. Besh quti: o'n, yigirma, o'ttiz, qirq, ellik. Yana 2 dona: ellik bir, ellik ikki. Javob: 52. «7» deganlar qutini bitta dona deb sanagan."},
 tn:"Bolalar xor bilan sanasin: «o'n, yigirma, o'ttiz» deganda qo'l bilan butun qutini ko'rsatsin, «o'ttiz bir…» deganda bitta barmoq."},
{h:"O'nlik va birlik",sum:"To'la quti = 1 o'nlik = 10 ta birlik. Bitta dona = 1 birlik.",a:"m04",
 start:function(){setPV(3,4)},fin:function(){setPV(3,4);openFrame(0)},
 html:"<p>Matematikada to'la quti <b class='tcol'>o'nlik</b> deyiladi. Bitta dona — <b class='ucol'>birlik</b>.</p><p>Tekshirib ko'raylik: rasmdagi <b>istalgan to'la qutini bosing</b> — ichida rostdan 10 ta dona bormi?</p>",
 act:function(c,done){c.querySelector('.hint').textContent='Rasmdagi to‘la qutilardan birini bosing.';openCb=function(){openCb=null;done()}},
 after:"<p>Ha, ichida <b>10 ta</b> dona. Demak, <b>1 ta o'nlik — bu 10 ta birlik</b>, faqat bir joyga yig'ilgan. O'nlik «katta bitta» emas, u o'nta birlik!</p>",
 q:{t:"1 ta o'nlikda nechta birlik bor?",opts:["1","10","100","5"],ok:1,why:"To'la quti — 10 ta dona.",hint:"Qutini ochganingizda ichida nechta dona ko'rdingiz?",full:"O'nlik — bu 10 ta birlik bir joyga yig'ilgani. Qutini ochsak, 10 ta dona chiqadi."},
 tn:"Ko'p bola o'nlikni «bitta katta narsa» deb o'ylaydi va 1 deb sanaydi. Qutini ochib, donalarni sanab ko'rsatish shu xatoni yo'qotadi."},
{h:"Sonni qanday yozamiz",sum:"Chapda — o'nliklar soni, o'ngda — birliklar soni. 34 = 3 o'nlik + 4 birlik = 30 + 4.",a:"m05",
 start:function(){setPV(3,4)},fin:function(){setPV(3,4)},
 html:"<p>Rasm ostidagi qatorga qarang. Ikki xonali sonda <b>chapdagi raqam</b> — o'nliklar (to'la qutilar) soni, <b>o'ngdagi raqam</b> — birliklar soni.</p><p>Tugmalar bilan o'zingiz son yasang: rasm, jadval, son va uning nomi birga o'zgaradi.</p>",
 btns:[["+ o'nlik",function(c,done){if(S.frames.length<9){setPV(S.frames.length+1,S.loose.length);mv5(done)}}],["− o'nlik",function(c,done){if(S.frames.length){setPV(S.frames.length-1,S.loose.length);mv5(done)}}],["+ birlik",function(c,done){if(S.loose.length<9){setPV(S.frames.length,S.loose.length+1);mv5(done)}},'u'],["− birlik",function(c,done){if(S.loose.length){setPV(S.frames.length,S.loose.length-1);mv5(done)}},'u']],g2:1,
 after:"<p>Masalan, <b><span class='tcol'>5</span><span class='ucol'>7</span></b> — <span class='tcol'>5 ta o'nlik</span> va <span class='ucol'>7 ta birlik</span>: 50 + 7, «ellik yetti».</p>",
 q:{t:"57 sonida nechta o'nlik bor?",opts:["7","57","5","12"],ok:2,why:"Chapdagi raqam — 5. Demak, 5 ta o'nlik.",hint:"O'nliklar soni qaysi tomonda yoziladi — chapdami yoki o'ngdami?",full:"57 da chapda 5, o'ngda 7. Chapdagi — o'nliklar: 5 ta (50). O'ngdagi — birliklar: 7 ta. 57 = 50 + 7."},
 tn:"Doskaga «O'nliklar | Birliklar» jadvalini chizing. Son aytilganda bolalar avval jadvalga, keyin oddiy ko'rinishda yozsin. Nomini ham ayting: «o'ttiz — bu uchta o'n»."},
{h:"Raqamning o'rni muhim",sum:"34 va 43 — raqamlar bir xil, sonlar boshqa. Chapdagi raqam o'nliklarni bildiradi.",a:"m06",
 start:function(){setPV(3,4)},fin:function(){setPV(4,3)},
 html:"<p>34 va 43 — ikkalasida ham 3 va 4 bor. Bir xil sonmi? Tugmani bosib, raqamlar o'rnini almashtiring va qutilarni solishtiring.</p>",
 btns:[["⇄ O'rnini almashtir",function(c,done){var t=S.frames.length,u=S.loose.length;setPV(u,t);done()}]],
 after:"<p>43 da <b>4 ta</b> to'la quti, 34 da esa <b>3 ta</b>. Raqam qayerda tursa, shuni bildiradi: chapdagi 4 — bu 4 emas, <b>40</b>.</p>",
 q:{t:"Qaysi son katta: 43 yoki 34?",opts:["34","43","Ikkalasi teng","7 ga teng"],ok:1,why:"43 da o'nliklar ko'p: 4 ta, 34 da 3 ta.",hint:"Qaysi sonda to'la qutilar (o'nliklar) ko'proq?",full:"Avval o'nliklarni solishtiramiz: 43 da 4 ta, 34 da 3 ta. Demak, 43 katta. Raqamlari bir xil bo'lsa ham, o'rni boshqa — son boshqa."},
 tn:"Ikki bolaga 3 va 4 kartochkasini bering, o'rin almashsin. Sinf qaysi son chiqqanini va qaysi katta ekanini aytsin."},
{h:"Nol nimani bildiradi?",sum:"40 = 4 o'nlik, birlik yo'q — o'ngga 0 yoziladi. 0 bo'lmasa, 40 ni 4 deb o'ylab qolamiz.",a:"m07",
 start:function(){setPV(3,4)},fin:function(){setPV(4,0)},
 html:"<p>Agar donalar umuman bo'lmasa-chi? Tugmalarni bosib ko'ring.</p>",
 btns:[["4 ta quti, dona yo'q",function(c,done){setPV(4,0);done()}],["Quti yo'q, 7 ta dona",function(c,done){setPV(0,7);done()},'u']],
 after:"<p><b>40</b> — 4 ta o'nlik, birlik yo'q. «Yo'q» joyiga <b>0</b> yozamiz. 0 ni tashlab yuborsak, 4 bo'lib qoladi — o'n barobar kam!</p><p><b>7</b> — o'nlik yo'q, faqat 7 ta birlik. Bu bir xonali son, «07» deb yozilmaydi.</p>",
 q:{t:"6 ta o'nlik va 0 ta birlik — qaysi son?",opts:["6","60","06","600"],ok:1,why:"6 ta o'nlik — oltmish, birlik yo'q: 60.",hint:"Birlik yo'q bo'lsa, o'ng tomonga nima yoziladi?",full:"6 ta o'nlik — 60 ta dona. Birlik yo'q, shuning uchun o'ngga 0: 60. «6» desak, oltita dona bo'lib qoladi."},
 tn:"40 va 4 ni qutilarda yonma-yon ko'rsating: farq o'n barobar. Bolalar 0 ni «keraksiz» deb tashlab yuboradi."},
{h:"Tuzoq: birliklar 10 taga yetsa",sum:"2 o'nlik + 13 birlik ≠ 213. 10 ta birlikni qutiga joylaymiz: 3 o'nlik + 3 birlik = 33.",a:"m08",
 start:function(){setPV(2,13)},fin:function(){setPV(3,3)},
 html:"<p>Bu yerda <b>2 ta</b> to'la quti va <b>13 ta</b> dona. «2 13» — 213 deb yozsa bo'ladimi? <b>Yo'q!</b> Birliklar joyiga faqat <b>bitta raqam</b> (0 dan 9 gacha) sig'adi. Nima qilamiz?</p>",
 btns:[["📦 10 ta donani qutiga",function(c,done,b){b.disabled=true;regroup().then(function(){big('20 + 13 = 33');b.textContent='Tayyor';done()})}]],
 after:"<p>13 ta donadan 10 tasi yangi qutini to'ldirdi — bitta yangi o'nlik! Endi <b>3 ta o'nlik va 3 ta birlik: 33</b>.</p><p><b>Qoida:</b> birliklar 10 taga yetsa, ularni qutiga joylab o'nlikka aylantiramiz.</p>",
 q:{t:"4 ta o'nlik va 12 ta birlik — qaysi son?",opts:["412","16","52","42"],ok:2,why:"12 ta donadan 10 tasi — yana bitta o'nlik. 5 ta o'nlik va 2 ta birlik: 52.",hint:"12 ta birlikdan 10 tasini qutiga joylasak, nechta o'nlik bo'ladi?",full:"12 ta donadan 10 tasi yangi quti bo'ladi. Endi 4 + 1 = 5 ta o'nlik va 2 ta birlik: 52. «412» — birliklar joyiga 12 ni yozib qo'yilgan, bu xato."},
 tn:"Testlarda eng ko'p uchraydigan tuzoq: «7 ta o'nlik va 14 ta birlik» — javob 84, «714» emas. Qutida albatta qilib ko'rsating."},
{h:"Bilasizmi? 5000 yil oldin ham shunday",sum:"Qadimgi Misrda ∩ = 10, | = 1. Al-Xorazmiy raqam o'rni va nol bilan yozishni dunyoga tanitgan.",a:"m09",
 start:function(){setPV(3,4)},fin:function(){setPV(3,4);egypt(3,4)},
 html:"<p>🏺 Qadimgi Misrda, bundan <b>5000 yil oldin</b>, o'nlikni <b>∩</b> belgisi bilan, birlikni <b>|</b> chiziqcha bilan yozishgan. Ular ham o'ntadan guruhlagan! Tugmani bosing.</p>",
 btns:[["🏺 Misrcha yozish",function(c,done){egypt(S.frames.length,S.loose.length);done()}]],
 after:"<p>34 — misrcha <b>∩∩∩||||</b>. Lekin 98 ni yozish uchun 17 ta belgi kerak bo'lardi!</p><p>⭐ Hindistonda raqamning <b>o'rniga qarab</b> va <b>nol</b> bilan yozish o'ylab topilgan. Uni butun dunyoga tanitgan olim — vatandoshimiz <b>Muhammad al-Xorazmiy</b>. Shuning uchun biz bugun 98 ni atigi 2 ta raqam bilan yozamiz.</p>",
 tn:"Bolalardan misrcha 23 ni yozishni so'rang (∩∩|||). Keyin «98 ni misrcha yozing» — ular tezda bizning usul qanchalik qulayligini tushunadi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,
 start:function(){setPV(3,4)},fin:function(){setPV(3,4)},
 html:"<div class='memo'><ul><li><b>10 ta birlik = 1 o'nlik</b> (10 ta dona = 1 to'la quti).</li><li>Ikki xonali son: <b class='tcol'>chapda o'nliklar</b>, <b class='ucol'>o'ngda birliklar</b>. 34 = 30 + 4.</li><li>Sanash: avval o'ntadan (10, 20, 30), keyin bittadan (31, 32…).</li><li><b>43 ≠ 34</b>: o'nliklari ko'p son katta.</li><li>Birlik yo'q — <b>0</b> yoziladi: 4 o'nlik = 40.</li><li>Birliklar 10 taga yetsa — qutiga joylaymiz: 2 o'nlik + 13 birlik = <b>33</b>.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring. Keyingi darsni «7 ta o'nlik va 14 ta birlik — qaysi son?» savoli bilan boshlang."}
];
function mv5(done){var c=STEPS[cur];c._m=(c._m||0)+1;if(c._m>=3)done()}
var PROBS=[
{t:"6 ta o'nlik va 3 ta birlik — qaysi son?",o:["63","36","9","603"],k:0,s:"Chapga o'nliklar — 6, o'ngga birliklar — 3: 63 = 60 + 3."},
{t:"85 sonida nechta o'nlik bor?",o:["8","5","85","13"],k:0,s:"Chapdagi raqam — o'nliklar: 8 ta (80)."},
{t:"47 sonida nechta birlik bor?",o:["7","4","47","11"],k:0,s:"O'ngdagi raqam — birliklar: 7 ta. 47 = 40 + 7."},
{t:"9 ta o'nlik va 0 ta birlik — qaysi son?",o:["90","9","900","19"],k:0,s:"9 ta o'nlik — 90. Birlik yo'q, o'ngga 0."},
{t:"3 ta o'nlik va 15 ta birlik — qaysi son?",o:["45","315","18","35"],k:0,s:"15 ta birlikdan 10 tasi — yana 1 o'nlik. 4 o'nlik va 5 birlik: 45."},
{t:"Qaysi son eng katta?",o:["85","58","80","55"],k:0,s:"O'nliklar: 85 va 80 da 8 ta. Birliklar: 85 da 5 ta, 80 da 0. Eng kattasi 85."},
{t:"70 sonida nechta o'nlik bor?",o:["7","70","0","10"],k:0,s:"70 = 7 ta o'nlik va 0 ta birlik."},
{t:"Ali 5 ta to'la quti (har birida 10 ta) va 2 dona yong'oq oldi. Hammasi nechta?",o:["52","25","7","502"],k:0,s:"Qutilar: 10, 20, 30, 40, 50. Yana 2 dona: 52."},
{t:"1 ta o'nlik va 10 ta birlik — qaysi son?",o:["20","110","11","10"],k:0,s:"10 ta birlik — yana 1 o'nlik. 2 o'nlik, 0 birlik: 20."},
{t:"2 quti tuxum (har birida 10 ta) va 8 dona tuxum. Hammasi nechta?",o:["28","10","82","20"],k:0,s:"Qutilar: 10, 20. Yana 8 dona: 28."},
{t:"64 sonini o'nlik va birliklarga ajrating.",o:["60 + 4","6 + 4","40 + 6","64 + 0"],k:0,s:"6 ta o'nlik — 60, 4 ta birlik — 4. 64 = 60 + 4."},
{t:"Sonda 7 ta birlik bor, o'nliklari esa birliklardan 2 ta kam. Qaysi son?",o:["57","75","97","27"],k:0,s:"O'nliklar: 7 − 2 = 5. Son: 5 o'nlik va 7 birlik — 57."},
{t:"30 ta tuxumdan nechta to'la quti (10 talik) chiqadi?",o:["3","30","10","13"],k:0,s:"10, 20, 30 — 3 ta quti."},
{t:"46 ta donani 10 talik qutilarga joylasak, nechta dona ortib qoladi?",o:["6","4","46","10"],k:0,s:"46 = 4 o'nlik va 6 birlik: 4 ta quti to'ladi, 6 ta dona qoladi."},
{t:"Qaysi sonda o'nliklar soni birliklar sonidan ko'p?",o:["52","25","39","47"],k:0,s:"52: 5 ta o'nlik, 2 ta birlik — 5 ko'p. Qolganlarida birliklar ko'p."},
{t:"8 ta o'nlikka 1 ta birlik qo'shilsa, qaysi son chiqadi?",o:["81","90","9","801"],k:0,s:"8 ta o'nlik — 80. Yana 1 birlik: 81."},
{t:"59 ga 1 qo'shsak, nechta o'nlik bo'ladi?",o:["6","5","10","60"],k:0,s:"59 + 1 = 60: 9 ta birlikka 1 qo'shilib 10 bo'ldi — yangi o'nlik. 60 da 6 ta o'nlik."},
{t:"Misrliklar ∩∩|||| deb yozgan son qaysi?",o:["24","42","6","204"],k:0,s:"∩ — o'nlik, | — birlik. 2 ta ∩ va 4 ta |: 24."},
{t:"7 ta o'nlik va 14 ta birlik — qaysi son?",o:["84","714","74","21"],k:0,s:"14 ta birlikdan 10 tasi — yangi o'nlik. 8 o'nlik va 4 birlik: 84."},
{t:"4 ta o'nlik va 6 ta birlikka yana 2 ta o'nlik va 3 ta birlik qo'shildi. Qaysi son chiqadi?",o:["69","96","15","49"],k:0,s:"O'nliklar: 4 + 2 = 6. Birliklar: 6 + 3 = 9. Son: 69."}
];
(function(){var R=rnd(11);PROBS.forEach(function(p,i){p.a='p'+pad(i+1);var idx=[0,1,2,3];for(var j=3;j>0;j--){var r=Math.floor(R()*(j+1));var t=idx[j];idx[j]=idx[r];idx[r]=t}var o=idx.map(function(x){return p.o[x]});p.k=idx.indexOf(p.k);p.o=o;p._sh=1})})();
var LOCK_SEC=20;

function PRACT_STAGE(){setPV(3,4);big(null)}
var PREP='<div class="st prep"><div class="bd" style="padding-top:12px"><h3 style="margin-top:0">Darsga tayyorlanish</h3><ul><li>Ko\'p narsani o\'ntadan guruhlab sanash.</li><li><b>O\'nlik</b> va <b>birlik</b>: 10 ta birlik = 1 o\'nlik.</li><li>Ikki xonali sonni yozish: chapda o\'nliklar, o\'ngda birliklar.</li><li>Raqam o\'rni (34 va 43), nol (40), birliklarni o\'nlikka aylantirish.</li></ul><h3>Bolalar odatda qayerda adashadi</h3><ul><li>«7 o\'nlik va 14 birlik»ni 714 deb yozadi.</li><li>O\'nlikni «bitta narsa» deb 1 deb sanaydi (5 quti + 2 dona = 7).</li><li>34 va 43 ni bir xil deb o\'ylaydi.</li><li>40 ni yozganda 0 ni tashlab yuboradi.</li></ul><h3>Kerakli narsalar</h3><ul><li>Tuxum qutisi yoki doskaga chizilgan 2×5 katakli «o\'ntalik quti».</li><li>40 ta tugma, loviya yoki cho\'p.</li></ul><h3>Doskaga nima yoziladi</h3><ol><li>Sochilgan nuqtalar — «Nechta?»</li><li>2×5 katakli qutilar: <span class="w2">●●●●●/●●●●●</span> = <span class="w2">10</span>.</li><li>Sanash: <span class="w2">10, 20, 30, 31, 32, 33, 34</span>.</li><li>Jadval: <span class="w2">O\'nliklar | Birliklar</span> → <span class="w2">3 | 4</span> → <span class="w2">34 = 30 + 4</span>.</li><li><span class="w2">34 ≠ 43</span>, <span class="w2">40</span>.</li><li>Tuzoq: <span class="w2">2 o\'nlik + 13 birlik = 33</span> (213 emas).</li><li>Misr: <span class="w2">∩∩∩||||</span> = 34.</li></ol><button class="printbtn" onclick="window.print()">🖨 Chop etish</button><h3>Mashq varaqasi (javoblari bilan)</h3><ol class="plist">'+PROBS.map(function(p){return '<li>'+p.t+'<br><span class="pnum">'+p.o.map(function(o,j){return String.fromCharCode(65+j)+') '+o}).join(' &nbsp; ')+' — <b>'+String.fromCharCode(65+p.k)+'</b></span></li>'}).join('')+'</ol></div></div>';
