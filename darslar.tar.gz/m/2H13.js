var CODE='2H13',TITLE="2-sinf · Nechta usul bilan?";
function hDMsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function hDBox(x,y,t,o){o=o||{};var g=S.g;E('rect',{x:x-(o.w||40)/2,y:y-14,width:o.w||40,height:28,rx:8,fill:o.f||'#fff',stroke:o.s||C.line,'stroke-width':1.5},g);T(g,x,y+5,t,{'font-size':o.fs||13,'font-weight':800})}
// daraxt: sho'rva x salat
var SH=['🍲','🥣','🍜'],SL=['🥗','🥒'];
function hDTree(k){clear();var g=S.g,n=0;T(g,20,90,'●',{'font-size':12,fill:C.blue});
 SH.forEach(function(a,i){var y=30+i*58;if(k>=1){E('line',{x1:26,y1:88,x2:110,y2:y,stroke:C.b,'stroke-width':2.5},g);T(g,124,y+6,a,{'font-size':18})}
  if(k>=2)SL.forEach(function(b,j){var y2=y-14+j*28;E('line',{x1:138,y1:y,x2:220,y2:y2,stroke:C.c,'stroke-width':2},g);T(g,232,y2+6,b,{'font-size':16});n++;T(g,300,y2+5,a+' '+b,{'font-size':13})})});
 hDMsg(k===0?'Avval sho‘rva, keyin salat tanlaymiz':(k===1?'Sho‘rva: <b>3</b> xil':'Har sho‘rvaga 2 xil salat: 3 · 2 = <b>6</b> xil tushlik'))}
// ikki xonali sonlar
function hDNums(rep){clear();var g=S.g,L=[];[1,2,3].forEach(function(a){[1,2,3].forEach(function(b){if(rep||a!==b)L.push(''+a+b)})});
 L.forEach(function(t,i){var cols=rep?3:2,r=Math.floor(i/cols),q=i%cols;hDBox(90+q*80+(rep?0:40),32+r*(rep?50:50)-(rep?0:0),t,{w:52,f:rep&&t[0]===t[1]?'#fde6c8':'#fff',fs:16})});
 hDMsg(rep?'Takrorlash mumkin: 3 · 3 = <b>9</b> ta son':'Takrorlamasdan: 3 · 2 = <b>6</b> ta son')}
// qatorga terish
var P3=[function(){hDRow(0)},function(){hDRow(1)},function(){hDRow(2)}];
function hDRow(k){clear();var g=S.g,ps=[['🐰','🐻','🐱'],['🐰','🐱','🐻'],['🐻','🐰','🐱'],['🐻','🐱','🐰'],['🐱','🐰','🐻'],['🐱','🐻','🐰']];
 var show=k===0?2:6;for(var i=0;i<show;i++){var r=i%3,q=Math.floor(i/3);E('rect',{x:30+q*170,y:10+r*52,width:130,height:44,rx:10,fill:'#fff',stroke:C.line},g);ps[i].forEach(function(a,j){T(g,62+q*170+j*34,40+r*52,a,{'font-size':22})})}
 hDMsg(k===0?'1-o‘ringa 🐰 qo‘ysak — qolgan ikkitasini 2 xil teramiz':(k===1?'1-o‘ringa 3 xil, 2-o‘ringa 2 xil, 3-o‘ringa 1 ta':'3 · 2 · 1 = <b>6</b> xil tartib'))}
// qo'l berishish
function hDShake(n,card){clear();var g=S.g,cx=180,cy=86,R=62,pts=[];for(var i=0;i<n;i++){var a=-Math.PI/2+i*2*Math.PI/n;pts.push([cx+R*Math.cos(a),cy+R*Math.sin(a)])}
 var cnt=0;for(var i=0;i<n;i++)for(var j=i+1;j<n;j++){E('line',{x1:pts[i][0],y1:pts[i][1],x2:pts[j][0],y2:pts[j][1],stroke:card?C.c:C.ok,'stroke-width':card?4:2.5,'stroke-dasharray':card?'':''},g);cnt++}
 pts.forEach(function(p,i){E('circle',{cx:p[0],cy:p[1],r:15,fill:'#fff',stroke:C.line,'stroke-width':1.5},g);T(g,p[0],p[1]+6,['🧒','👧','👦','🧑'][i],{'font-size':16})});
 hDMsg(card?'Har chiziq bo‘ylab 2 ta otkritka (borib-kelib): '+cnt+' · 2 = <b>'+cnt*2+'</b>':'Har chiziq — bitta qo‘l berishish: <b>'+cnt+'</b> ta')}
function hDCoin(k){clear();var g=S.g,L=[['🦅','🦅'],['🦅','1'],['1','🦅'],['1','1']];
 L.slice(0,k?4:1).forEach(function(p,i){var x=50+i*80;p.forEach(function(s,j){E('circle',{cx:x+j*30,cy:80,r:13,fill:'#f6d36b',stroke:'#b08a1e','stroke-width':1.5},g);T(g,x+j*30,85,s,{'font-size':s==='1'?13:13,'font-weight':800})})});
 T(g,180,140,'🦅 — gerb,  1 — son',{'font-size':11,fill:'#5b6b7b'});hDMsg(k?'1-tanga 2 xil · 2-tanga 2 xil = <b>4</b> xil':'Ikki tanga tashlaymiz')}
var PT=[function(){hDTree(0)},function(){hDTree(1)},function(){hDTree(2)}];
var STEPS=[
{h:"Tushlik tanlash: daraxt chizamiz",sum:"3 xil sho'rva va 2 xil salat — har sho'rvaga 2 ta salat: 3 · 2 = 6.",a:"m01",
 start:function(){startPh(PT)},fin:function(){S.ph=2;PT[2]()},
 html:"<p><i>«Oshxonada 3 xil sho'rva va 2 xil salat bor. Bitta sho'rva va bitta salatdan iborat tushlikni necha xil tanlash mumkin?»</i> Hamma variantni yo'qotmaslik uchun <b>daraxt</b> chizamiz:</p>",
 btns:[phaser(PT,'▶ Keyingi')],
 after:"<p>Daraxtda har sho'rvadan 2 ta shox chiqdi: 2 + 2 + 2 = 3 · 2 = <b>6</b>. «5» degan javob — qo'shib yuborish xatosi (3 + 2). Ketma-ket tanlovlarda <b>ko'paytiramiz</b>.</p>",
 q:{t:"Lolada 4 ta ko'ylak va 2 ta yubka bor. Bitta ko'ylak va bitta yubkani necha xil kiyishi mumkin?",opts:["6","8","4","2"],ok:1,why:"4 · 2 = 8.",hint:"Har ko'ylakka nechta yubka mos keladi?",full:"Har ko'ylak bilan 2 xil yubka: 2 + 2 + 2 + 2 = 4 · 2 = 8 xil."},
 tn:"Qog'oz ko'ylak va yubkalar bilan kiyintirish o'yini — daraxtni bolalar o'zi chizsin."},
{h:"Raqamlardan sonlar",sum:"1, 2, 3 raqamlaridan ikki xonali sonlar: takrorlamasdan 6 ta, takrorlab 9 ta.",a:"m02",
 start:function(){S.nm={};hDNums(false)},fin:function(){hDNums(true)},
 html:"<p>1, 2 va 3 raqamlaridan ikki xonali sonlar tuzamiz. Ikkala holatni ko'ring:</p>",
 btns:[["Takrorlamasdan",function(c,done){hDNums(false);S.nm.a=1;if(S.nm.b)done()}],["Takrorlash mumkin",function(c,done){hDNums(true);S.nm.b=1;if(S.nm.a)done()},'u']],g2:1,
 after:"<p>O'nliklar xonasiga 3 xil raqam. Birliklarga: takrorlamasak — qolgan <b>2</b> ta (3 · 2 = 6), takrorlasak — yana <b>3</b> ta (3 · 3 = 9). Shart diqqat bilan o'qiladi: «raqamlar takrorlanmaydi» degan so'z bormi?</p>",
 q:{t:"1, 2, 3, 4 raqamlaridan raqamlari takrorlanmaydigan nechta ikki xonali son tuzish mumkin?",opts:["16","12","8","6"],ok:1,why:"O'nliklarga 4 xil, birliklarga qolgan 3 xil: 4 · 3 = 12.",hint:"Birinchi raqamni tanlagach, nechta raqam qoladi?",full:"O'nliklar xonasiga 4 ta raqamdan biri, birliklarga qolgan 3 tadan biri: 4 · 3 = 12. Masalan, 1 bilan: 12, 13, 14."},
 tn:"Raqamli kartochkalarni bolalar qo'lda terib, sonlarni yozib chiqsin, keyin sanasin."},
{h:"Qatorga terish",sum:"3 o'yinchoqni qatorga 3 · 2 · 1 = 6 xil terish mumkin.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p><i>«Javonga quyon, ayiq va mushuk o'yinchoqlarini qatorga qo'yamiz. Necha xil tartibda qo'yish mumkin?»</i></p>",
 btns:[phaser(P3,'▶ Keyingi')],
 after:"<p>1-o'ringa 3 xil, 2-o'ringa qolgan 2 xil, 3-o'ringa oxirgi 1 ta: 3 · 2 · 1 = <b>6</b>. 4 ta o'yinchoq bo'lsa: 4 · 3 · 2 · 1 = <b>24</b> xil!</p>",
 q:{t:"Ali, Vali va Soli navbatga turmoqchi. Ali doim birinchi tursa, ular necha xil tartibda turishi mumkin?",opts:["6","3","2","1"],ok:2,why:"Ali joyida; qolgan ikkitasi 2 xil turadi.",hint:"Birinchi o'rin band — qolgan 2 o'rinni necha xil to'ldirish mumkin?",full:"Ali birinchi. Qolgan ikki o'ringa Vali va Soli: Vali–Soli yoki Soli–Vali — 2 xil."},
 tn:"Uch bolani doska oldida turg'izib, har xil tartibda almashtiring — sinf sanasin."},
{h:"Tuzoq: qo'l berishish va otkritka",sum:"4 do'st qo'l berishsa — 6 marta; otkritka yuborishsa — 12 ta (har juft ikki tomonlama).",a:"m04",
 start:function(){S.sk={};hDShake(4,false)},fin:function(){hDShake(4,true)},
 html:"<p><i>«4 do'st uchrashib, har biri boshqalar bilan bir martadan qo'l berishdi. Necha marta qo'l berishildi?»</i> Va: <i>«Har biri qolganlariga bittadan otkritka yubordi. Jami nechta otkritka?»</i></p>",
 btns:[["🤝 Qo'l berishish",function(c,done){hDShake(4,false);S.sk.a=1;if(S.sk.b)done()}],["💌 Otkritka",function(c,done){hDShake(4,true);S.sk.b=1;if(S.sk.a)done()},'u']],g2:1,
 after:"<p>Har bola 3 kishi bilan qo'l beradi: 4 · 3 = 12 — lekin har qo'l berishish <b>ikki marta</b> sanaldi (Ali–Vali va Vali–Ali bitta), shuning uchun 12 : 2 = <b>6</b>. Otkritkada esa Ali Valiga va Vali Aliga — <b>ikki xil</b> otkritka: <b>12</b>. Tuzoq: ikkala masala o'xshash, javob har xil!</p>",
 q:{t:"3 do'st har biri qolganlariga bittadan SMS yubordi. Jami nechta SMS?",opts:["3","6","9","5"],ok:1,why:"Har biri 2 tadan: 3 · 2 = 6.",hint:"SMS bir tomonlama — Ali Valiga va Vali Aliga ikki xil SMS.",full:"Har do'st qolgan 2 kishiga yozadi: 3 · 2 = 6 SMS. (Qo'l berishish bo'lganda 3 ta bo'lardi.)"},
 tn:"Sinfda 4 bola haqiqatan qo'l berishib, bir bola sanasin — keyin qog'oz «otkritka» almashsin."},
{h:"Juftlik tanlash",sum:"4 bola ichidan 2 kishilik juftlik 6 xil tanlanadi — tartib muhim emas.",a:"m05",
 start:function(){hDPairs(false)},fin:function(){hDPairs(true)},
 html:"<p><i>«Ali, Vali, Soli va Gulidan navbatchilikka 2 kishi tanlash kerak. Necha xil juftlik bor?»</i> Tartib bilan yozamiz: avval Ali bilan juftlar, keyin Vali bilan (Ali bilan bo'lganini qaytarmaymiz)…</p>",
 btns:[["📋 Hammasini yozish",function(c,done,b){b.disabled=true;hDPairs(true);done()}]],
 after:"<p>Ali bilan 3 ta, Vali bilan yangi 2 ta, Soli bilan yangi 1 ta: 3 + 2 + 1 = <b>6</b>. Bu xuddi qo'l berishish masalasi — juftlikda tartib muhim emas (Ali–Vali = Vali–Ali).</p>",
 q:{t:"5 ta mevadan 2 tasini tanlash kerak. Necha xil tanlash mumkin?",opts:["10","20","5","8"],ok:0,why:"4 + 3 + 2 + 1 = 10.",hint:"Birinchi meva bilan nechta juft? Keyingisi bilan yangi nechta?",full:"1-meva bilan 4 juft, 2-si bilan yangi 3, 3-si bilan 2, 4-si bilan 1: 4 + 3 + 2 + 1 = 10."},
 tn:"Juftlarni tartibli yozish — xatosiz sanashning eng yaxshi usuli. Bolalarga «alifbo tartibida yoz» deb o'rgating."},
{h:"Tanga tashlash",sum:"Ikki tanga: gerb-gerb, gerb-son, son-gerb, son-son — 4 xil.",a:"m06",
 start:function(){hDCoin(0)},fin:function(){hDCoin(1)},
 html:"<p><i>«Bir tangani, keyin ikkinchi tangani tashlaymiz. Necha xil natija chiqishi mumkin?»</i></p>",
 btns:[["🪙 Hamma natijalar",function(c,done,b){b.disabled=true;hDCoin(1);done()}]],
 after:"<p>Ko'pchilik «3 xil» deydi (2 gerb, 2 son, aralash). Lekin «gerb-son» va «son-gerb» — <b>har xil</b> natija (1-tanga va 2-tanga farq qiladi): 2 · 2 = <b>4</b>.</p>",
 q:{t:"Uchta tanga ketma-ket tashlansa, necha xil natija bo'ladi?",opts:["6","8","4","3"],ok:1,why:"2 · 2 · 2 = 8.",hint:"Har tanga 2 xil tushadi.",full:"1-tanga 2 xil, 2-si 2 xil, 3-si 2 xil: 2 · 2 · 2 = 8."},
 tn:"Ikki xil rangli tanga bilan tashlab, natijalarni doskaga yozing — «gerb-son» va «son-gerb» farqini ko'rsatadi."},
{h:"Bilasizmi?",sum:"Shaxmat taxtasida dastlabki 2 yurishdan keyin 400 xil holat bo'lishi mumkin.",a:"m07",
 start:function(){hDTree(2)},fin:function(){hDTree(2)},
 html:"<p>♟ Shaxmatda oq birinchi yurishni <b>20</b> xil, qora ham javobni <b>20</b> xil qilishi mumkin. Demak, bir juft yurishdan keyin 20 · 20 = <b>400</b> xil holat! Shuning uchun shaxmat o'yinlari deyarli hech qachon takrorlanmaydi.</p><p>🔒 4 raqamli kodli qulfda 10 · 10 · 10 · 10 = <b>10 000</b> xil kod bor.</p>",
 tn:"Bolalarga 3 raqamli qulf kodi necha xil bo'lishini so'rang (1000)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){hDTree(2)},fin:function(){hDTree(2)},
 html:"<div class='memo'><ul><li>Hamma variantni yo'qotmaslik uchun — <b>daraxt</b> yoki tartibli ro'yxat.</li><li>Ketma-ket tanlovlar <b>ko'paytiriladi</b>: 3 sho'rva · 2 salat = 6.</li><li>«Takrorlanmaydi» bo'lsa, keyingi o'ringa bittasi kam: 3 · 2.</li><li>Qatorga terish: 3 · 2 · 1 = 6; 4 · 3 · 2 · 1 = 24.</li><li>Juftlik (tartib muhim emas): 3 + 2 + 1 = 6.</li><li>Otkritka (ikki tomonlama): 4 · 3 = 12.</li></ul></div>",
 tn:"Keyingi darsni «Sinfimizda necha xil navbatchi juftligi bor?» savoli bilan boshlang."}
];
function hDPairs(all){clear();var N=['Ali','Vali','Soli','Guli'],L=[];for(var i=0;i<4;i++)for(var j=i+1;j<4;j++)L.push(N[i]+' – '+N[j]);
 (all?L:L.slice(0,3)).forEach(function(t,k){var q=k<3?0:(k<5?1:2),r=k<3?k:(k<5?k-3:0);hDBox(70+q*110,30+r*48,t,{w:100,f:['#e6f0fb','#fde6c8','#e1f4f2'][q]})});
 hDMsg(all?'3 + 2 + 1 = <b>6</b> juftlik':'Ali bilan: 3 ta juft')}
var PROBS=[
{t:"3 xil sho'rva va 2 xil salat. Bitta sho'rva va bitta salat necha xil tanlanadi?",o:["6","5","3","9"],k:0,s:"3 · 2 = 6."},
{t:"4 ta ko'ylak va 2 ta yubka. Necha xil kiyinish mumkin?",o:["8","6","4","2"],k:0,s:"4 · 2 = 8."},
{t:"1, 2, 3 raqamlaridan raqamlari takrorlanmaydigan nechta ikki xonali son bor?",o:["6","9","3","4"],k:0,s:"3 · 2 = 6."},
{t:"1, 2, 3 raqamlaridan (takrorlash mumkin) nechta ikki xonali son bor?",o:["9","6","3","12"],k:0,s:"3 · 3 = 9."},
{t:"1, 2, 3, 4 raqamlaridan raqamlari takrorlanmaydigan nechta ikki xonali son bor?",o:["12","16","8","6"],k:0,s:"4 · 3 = 12."},
{t:"3 ta o'yinchoqni qatorga necha xil terish mumkin?",o:["6","3","9","5"],k:0,s:"3 · 2 · 1 = 6."},
{t:"4 ta qo'g'irchoqni qatorga necha xil terish mumkin?",o:["24","12","16","8"],k:0,s:"4 · 3 · 2 · 1 = 24."},
{t:"3 do'st bir-biri bilan bir martadan qo'l berishdi. Necha marta?",o:["3","6","9","2"],k:0,s:"Juftlar: 3 ta."},
{t:"4 do'st bir-biri bilan bir martadan qo'l berishdi. Necha marta?",o:["6","12","8","4"],k:0,s:"3 + 2 + 1 = 6."},
{t:"4 do'st har biri qolganlariga bittadan otkritka yubordi. Jami nechta?",o:["12","6","8","16"],k:0,s:"4 · 3 = 12."},
{t:"3 do'st har biri qolganlariga bittadan SMS yubordi. Jami nechta?",o:["6","3","9","5"],k:0,s:"3 · 2 = 6."},
{t:"4 boladan 2 kishilik navbatchi juftlik necha xil tanlanadi?",o:["6","8","12","4"],k:0,s:"3 + 2 + 1 = 6."},
{t:"5 ta mevadan 2 tasini necha xil tanlash mumkin?",o:["10","20","5","8"],k:0,s:"4 + 3 + 2 + 1 = 10."},
{t:"Ikki tanga tashlansa, necha xil natija bo'ladi?",o:["4","3","2","6"],k:0,s:"2 · 2 = 4."},
{t:"Uch tanga tashlansa, necha xil natija bo'ladi?",o:["8","6","4","9"],k:0,s:"2 · 2 · 2 = 8."},
{t:"Ali, Vali, Soli navbatga turadi, Ali doim birinchi. Necha xil tartib?",o:["2","6","3","1"],k:0,s:"Qolgan ikkitasi 2 xil."},
{t:"Ikki sonning yig'indisi 15, ikkalasi ham 1 dan 14 gacha natural son, juftlarda tartib muhim emas (7 + 8 = 8 + 7). Nechta juft bor?",o:["7","14","15","8"],k:0,s:"1+14, 2+13, …, 7+8 — 7 ta."},
{t:"Uydan maktabga 3 yo'l, maktabdan bog'ga 2 yo'l. Uydan maktab orqali bog'ga necha xil yo'l?",o:["6","5","3","2"],k:0,s:"3 · 2 = 6."},
{t:"Qizil, ko'k, sariq bayroqlardan 2 tasini ustma-ust osamiz (tartib muhim). Necha xil signal?",o:["6","3","9","4"],k:0,s:"3 · 2 = 6."},
{t:"2 xil non va 3 xil choy. Bitta non va bitta choyni necha xil tanlash mumkin?",o:["6","5","8","3"],k:0,s:"2 · 3 = 6."}
];
function PRACT_STAGE(){hDTree(2)}
var PREP_DATA={teach:["Variantlarni daraxt yoki tartibli ro'yxat bilan yozish.","Ketma-ket tanlovlar — ko'paytirish (3 · 2).","Takrorlanmaydigan raqamlar; qatorga terish (3 · 2 · 1).","Juftlik (tartib muhim emas) va otkritka (tartib muhim) farqi."],
 mist:["Ketma-ket tanlovlarni qo'shadi (3 + 2 = 5).","«Takrorlanmaydi» shartini e'tiborsiz qoldiradi.","Qo'l berishishlarni ikki marta sanaydi (12 o'rniga 6).","«Gerb-son» va «son-gerb»ni bitta deb hisoblaydi."],
 need:["Raqamli kartochkalar (1, 2, 3, 4).","2 ta tanga, 3–4 ta o'yinchoq."],
 board:["Daraxt: 🍲→🥗🥒, 🥣→🥗🥒, 🍜→🥗🥒 = 6.","12 13 21 23 31 32 — 6 ta.","Juftlar: 3 + 2 + 1 = 6; otkritka: 4 · 3 = 12.","Tanga: 2 · 2 = 4."]};
