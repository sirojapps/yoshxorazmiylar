var CODE='3E1',TITLE='3-sinf · Ikki va uch amalli masalalar';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w1u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Reja: avval nima, keyin nima?",sum:"380 kg − 235 kg = 145 kg qoldi; 145 : 5 = 29 yashik. Har amal — bitta savolga javob.",a:"m01",
 frames:[{t:'380 kg bodringdan 235 kg tuzlandi. Qolgani 5 kg dan yashiklarga. Nechta yashik?',bars:[{lab:'hammasi',y:70,segs:[{w:235,txt:'235 tuzlandi',c:'x'},{w:145,txt:'?',c:'q'}]}],br:[{b:0,lab:'380 kg',up:true}],note:'Savolga darhol javob yo‘q: avval «qolgani»ni topish kerak'},
  {t:'380 kg bodringdan 235 kg tuzlandi. Qolgani 5 kg dan yashiklarga. Nechta yashik?',bars:[{lab:'hammasi',y:70,segs:[{w:235,txt:'235 tuzlandi',c:'x'},{w:145,txt:'145',c:'g'}]}],br:[{b:0,lab:'380 kg',up:true}],calc:['1-savol: qancha qoldi?','380 − 235 = <b>145</b> kg']},
  {t:'380 kg bodringdan 235 kg tuzlandi. Qolgani 5 kg dan yashiklarga. Nechta yashik?',bars:[{lab:'qolgani',y:70,segs:w1u(6,'5 kg','g',24).concat([{w:24,txt:'…',c:'g'},{w:24,txt:'5 kg',c:'g'}])}],br:[{b:0,lab:'145 kg',up:true},{b:0,lab:'? yashik',up:false,col:C.ok}],calc:['1) 380 − 235 = 145 kg','2) 145 : 5 = <b>29</b> yashik']}],
 html:"<p>Ikki amalli masalada savolga <b>birdaniga</b> javob berib bo'lmaydi. Avval «yashirin savol»ga javob topamiz. Kuzating.</p>",
 after:"<p>Reja: <b>1-savol</b> — qancha qoldi? (ayirish). <b>2-savol</b> — nechta yashik? (bo'lish). Har amalning o'z savoli bor — ularni yozib qo'ying.</p>",
 q:{t:"Maktabga 560 ta kitob keltirildi, 280 tasi tarqatildi. Qolgani 7 ta sinfga teng bo'lindi. Har sinfga nechtadan?",opts:["80","40","120","273"],ok:1,why:"560 − 280 = 280; 280 : 7 = 40.",hint:"Avval qancha kitob qolganini toping.",full:"1) Qoldi: 560 − 280 = 280 ta. 2) 280 : 7 = 40 tadan. «80» — 560 ni 7 ga bo'lib yuborish xatosi (tarqatilganlar ayirilmagan)."},
 tn:"Bolalarga har bir amal oldidan savol yozishni o'rgating: «1) Qancha qoldi? 2) Nechta yashik?». Bu — Polyaning «reja tuz» qadami."}),
bmStep({h:"Uch amal: ko'paytir, qo'sh, ayir",sum:"7 paket · 45 = 315 xat; 315 − 277 = 38 qoldi.",a:"m02",
 frames:[{t:'Pochtachi 45 tadan xat bo‘lgan 7 ta paket olib keldi va 277 tasini tarqatdi. Nechta qoldi?',bars:[{lab:'paketlar',y:70,segs:w1u(7,'45','b',45)}],br:[{b:0,lab:'? xat',up:true}],calc:['1) Hammasi: 45 · 7 = <b>315</b> ta']},
  {t:'Pochtachi 45 tadan xat bo‘lgan 7 ta paket olib keldi va 277 tasini tarqatdi. Nechta qoldi?',bars:[{lab:'hammasi',y:70,segs:[{w:277,txt:'277 tarqatildi',c:'x'},{w:38,txt:'?',c:'q'}]}],br:[{b:0,lab:'315',up:true}],calc:['1) 45 · 7 = 315','2) 315 − 277 = <b>38</b> ta qoldi']}],
 html:"<p>Shartda «45 <b>tadan</b> 7 ta paket» — bu ko'paytirish signali. Chizmani kuzating.</p>",
 after:"<p>Teng guruhlar → <b>ko'paytirish</b>; qismni olib tashlash → <b>ayirish</b>. Chizma qaysi amal kerakligini ko'rsatib turadi.</p>",
 q:{t:"6 qutida 25 tadan olma bor. 38 tasi sotildi, qolgani 4 savatga teng bo'lindi. Har savatda nechta?",opts:["28","112","150","37"],ok:0,why:"25 · 6 = 150; 150 − 38 = 112; 112 : 4 = 28.",hint:"Uch qadam: hammasi → qoldi → har savatga.",full:"1) 25 · 6 = 150 ta. 2) 150 − 38 = 112 ta qoldi. 3) 112 : 4 = 28 tadan. «112» — oxirgi qadam unutilgan."},
 tn:"Uch amalli masalada savollar zanjirini doskaga strelkalar bilan chizing: hammasi → qoldi → har biriga."}),
bmStep({h:"Har kuni bir xil: takror ayirish",sum:"580 kg, har kuni 135 kg, 3 kun: 135 · 3 = 405; 580 − 405 = 175 kg.",a:"m03",
 frames:[{t:'Oshxonaga 580 kg kartoshka keldi. Har kuni 135 kg ishlatiladi. 3 kundan keyin qancha qoladi?',bars:[{lab:'kartoshka',y:70,segs:[{w:135,txt:'1-kun',c:'x'},{w:135,txt:'2-kun',c:'x'},{w:135,txt:'3-kun',c:'x'},{w:175,txt:'?',c:'q'}]}],br:[{b:0,lab:'580 kg',up:true}],note:'Qaysi javob to‘g‘ri? Tanlang:'}],
 html:"<p>Chizmaga qarab, 3 kundan keyin qancha qolishini tanlang:</p>",
 btns:bmPick(["445 kg","175 kg","745 kg"],1,{t:'3 kunda: 135 · 3 = 405 kg ishlatildi',bars:[{lab:'kartoshka',y:70,segs:[{w:405,txt:'405 ishlatildi',c:'x'},{w:175,txt:'175',c:'g'}]}],br:[{b:0,lab:'580 kg',up:true}],calc:['1) 135 · 3 = 405 kg','2) 580 − 405 = <b>175</b> kg']},["445 — bu faqat 1 kundan keyin qolgani. 3 kun-chi?","","745 — qo‘shib yuborildi; kartoshka ishlatiladi, ko‘paymaydi."]),
 after:"<p>«Har kuni bir xil» — bu <b>bir xil bo'laklar</b>: avval 3 kunlik sarfni ko'paytirib topamiz, keyin ayiramiz. Yoki 3 marta ketma-ket ayiramiz — javob bir xil.</p>",
 q:{t:"Bakda 900 l suv bor edi. Har kuni 120 l ishlatildi. 5 kundan keyin qancha qoldi?",opts:["780 l","300 l","600 l","1500 l"],ok:1,why:"120 · 5 = 600; 900 − 600 = 300.",hint:"5 kunda jami qancha ishlatildi?",full:"1) 5 kunda: 120 · 5 = 600 l. 2) Qoldi: 900 − 600 = 300 l. «780» — faqat 1 kun hisoblangan."},
 tn:"Bank misoli (56-id). Tuzoq javob 445 — bolalar faqat bitta kunni ayiradi."}),
bmStep({h:"Ikki guruh, bir hafta",sum:"(3 · 5 + 8 · 3) · 7 = (15 + 24) · 7 = 39 · 7 = 273 kg.",a:"m04",
 frames:[{t:'3 sher kuniga 5 kg dan, 8 yo‘lbars 3 kg dan go‘sht yeydi. Bir haftada necha kg?',bars:[{lab:'sherlar',y:40,segs:w1u(3,'5','a',5)},{lab:'yo‘lbarslar',y:86,segs:w1u(8,'3','b',3)}],calc:['1) Sherlar: 5 · 3 = 15 kg kuniga','2) Yo‘lbarslar: 3 · 8 = 24 kg kuniga']},
  {t:'3 sher kuniga 5 kg dan, 8 yo‘lbars 3 kg dan go‘sht yeydi. Bir haftada necha kg?',bars:[{lab:'1 kun',y:40,segs:[{w:15,txt:'15',c:'a'},{w:24,txt:'24',c:'b'}]}],br:[{b:0,lab:'39 kg',up:false}],calc:['1) 15 kg  2) 24 kg','3) Bir kunda: 15 + 24 = <b>39</b> kg']},
  {t:'3 sher kuniga 5 kg dan, 8 yo‘lbars 3 kg dan go‘sht yeydi. Bir haftada necha kg?',bars:[{lab:'hafta',y:70,segs:w1u(7,'39','g',39)}],br:[{b:0,lab:'? kg',up:true,col:C.ok}],calc:['3) 1 kunda 39 kg','4) Hafta = 7 kun: 39 · 7 = <b>273</b> kg']}],
 html:"<p>Bu yerda yashirin ma'lumot bor: «<b>bir hafta</b>» — necha kun? Bosqichma-bosqich kuzating.</p>",
 after:"<p>Yashirin ma'lumotlar: <b>hafta = 7 kun</b>, sutka = 24 soat, yil = 12 oy. Ularni shartda yozishmaydi — o'zingiz bilishingiz kerak!</p>",
 q:{t:"4 ot kuniga 6 kg dan, 3 sigir 9 kg dan pichan yeydi. 5 kunda necha kg pichan kerak?",opts:["255 kg","51 kg","165 kg","22 kg"],ok:0,why:"24 + 27 = 51 kg kuniga; 51 · 5 = 255.",hint:"Avval bir kunda jami qancha kerakligini toping.",full:"Otlar: 6 · 4 = 24 kg, sigirlar: 9 · 3 = 27 kg. Bir kunda 51 kg. 5 kunda: 51 · 5 = 255 kg. «51» — faqat bitta kun."},
 tn:"Bank misoli (50-id), 3-daraja. Javob variantidagi 270 — «5 · 3 · 7 + …» kabi chalkash hisob natijasi; bolalardan har guruhni alohida hisoblashni talab qiling."}),
bmStep({h:"Tuzoq: «va 1 ta zaxira»",sum:"Har mashinaga 4 + 1 = 5 g'ildirak; 400 : 5 = 80 mashina (100 emas!).",a:"m05",
 frames:[{t:'400 g‘ildirak. Har mashinaga 4 ta g‘ildirak va 1 ta zaxira. Nechta mashinaga yetadi?',bars:[{lab:'1 mashina',y:70,segs:w1u(4,'g','b',1).concat([{w:1,txt:'z',c:'c'}])}],br:[{b:0,lab:'? ta',up:false}],note:'Bitta mashinaga nechta g‘ildirak ketadi? Javobni tanlang:'}],
 html:"<p>Bankdagi qiyin masala. Diqqat bilan o'qing va nechta mashinaga yetishini tanlang:</p>",
 btns:bmPick(["100","80","96"],1,{t:'Bitta mashinaga: 4 + 1 = 5 ta g‘ildirak',bars:[{lab:'1 mashina',y:70,segs:w1u(5,'','b',1)}],br:[{b:0,lab:'5 ta',up:false,col:C.ok}],calc:['1) 4 + 1 = 5 ta — bir mashinaga','2) 400 : 5 = <b>80</b> mashina']},["100 — zaxira g‘ildirak unutildi (400 : 4).","","96 — 400 dan 4 ni ayirish noto‘g‘ri; zaxira har mashinaga bor."]),
 after:"<p>Har bir so'zni o'qing! «<b>va 1 ta zaxira</b>» — har mashina uchun 5 ta g'ildirak. Bitta guruh nimadan iborat ekanini topib, keyin bo'lamiz.</p>",
 q:{t:"Har sumkaga 3 ta daftar va 1 ta qalam solinadi. 120 ta buyumdan nechta sumka yig'iladi?",opts:["40","30","117","123"],ok:1,why:"Bir sumkada 3 + 1 = 4 buyum; 120 : 4 = 30.",hint:"Bitta sumkada nechta buyum bor?",full:"Bitta sumka: 3 daftar + 1 qalam = 4 buyum. 120 : 4 = 30 sumka. «40» — qalam unutilgan (120 : 3)."},
 tn:"Bank misoli (52-id). «Guruh tarkibi»ni avval aniqlash — barcha teng guruhli masalalarning kaliti."}),
bmStep({h:"Tuzoq: qoldiq bo'lsa nima qilamiz?",sum:"23 kg olma, 5 kg dan yashik: 23 : 5 = 4 (qoldiq 3) → yana bitta yashik kerak: 5 yashik.",a:"m06",
 frames:[{t:'23 kg olmani 5 kg sig‘adigan yashiklarga solish kerak. Kamida nechta yashik kerak?',bars:[{lab:'yashiklar',y:70,segs:w1u(4,'5 kg','g',5).concat([{w:3,txt:'3',c:'c'}])}],br:[{b:0,lab:'23 kg',up:true}],note:'4 ta yashik to‘ldi, 3 kg ortdi. Javob?'}],
 html:"<p>Qoldiqli bo'lishda javob <b>savolga qarab</b> o'zgaradi. Tanlang:</p>",
 btns:bmPick(["4 yashik","5 yashik","3 yashik"],1,{t:'Ortgan 3 kg ham yashikka solinishi kerak!',bars:[{lab:'yashiklar',y:70,segs:w1u(4,'5 kg','g',5).concat([{w:5,txt:'3 kg',c:'y'}])}],br:[{b:0,lab:'5 ta yashik',up:false,col:C.ok}],calc:['23 : 5 = 4 (qoldiq 3)','Ortgan 3 kg uchun yana 1 yashik: 4 + 1 = <b>5</b>']},["4 ta bo‘lsa, 3 kg olma yerda qoladi!","","3 — qoldiq, yashiklar soni emas."]),
 after:"<p>«<b>Kamida nechta kerak</b>» — qoldiq bo'lsa, <b>yana bitta</b> qo'shamiz (avtobus, yashik, qayiq). «<b>Nechta to'ldi</b>» deyilsa — qoldiq hisobga olinmaydi.</p>",
 q:{t:"47 o'quvchini 10 o'rinli mikroavtobuslarga joylashtirish kerak. Kamida nechta mikroavtobus kerak?",opts:["4","5","7","47"],ok:1,why:"47 : 10 = 4 (qoldiq 7) → 4 + 1 = 5.",hint:"4 ta avtobus to'lsa, nechta o'quvchi qoladi?",full:"4 ta avtobusga 40 kishi sig'adi, 7 kishi qoladi. Ular uchun yana 1 ta: jami 5. «4» — 7 o'quvchi joysiz qoladi."},
 tn:"Bank misoli (23-id) aynan shu tuzoq bilan: 145 : 5 = 29 aniq bo'linadi, lekin raqamlarni o'zgartirsangiz qoldiq chiqadi — bolalarga ikkala holatni ham bering."}),
bmStep({h:"Masaladan ifoda tuzamiz",sum:"3 quti 24 tadan, 18 tasi singan: 3 · 24 − 18 = 54.",a:"m07",
 frames:[{t:'3 qutida 24 tadan tuxum bor edi. 18 tasi singan. Butun tuxumlar nechta?',bars:[{lab:'qutilar',y:70,segs:w1u(3,'24','b',24)}],br:[{b:0,lab:'− 18 singan',up:false,col:C.bad}],note:'Qaysi ifoda masalaga mos? Tanlang:'}],
 html:"<p>Masalani bitta <b>ifoda</b> bilan yozish mumkin. Qaysi biri to'g'ri?</p>",
 btns:bmPick(["3 + 24 − 18","3 · 24 − 18","(24 − 18) · 3"],1,{t:'Hammasi 3 · 24, singanlar ayiriladi',bars:[{lab:'tuxumlar',y:70,segs:[{w:18,txt:'18',c:'x'},{w:54,txt:'54',c:'g'}]}],br:[{b:0,lab:'3 · 24 = 72',up:true}],calc:['3 · 24 − 18 = 72 − 18 = <b>54</b> ta']},["Qo‘shish emas: 3 ta quti — bu 24 ning 3 ta nusxasi.","","Bu holda har qutida 18 tadan singan bo‘lardi — shartda unday deyilmagan."]),
 after:"<p>Ifoda — masalaning «qisqa yozuvi». Amallar tartibi: avval ko'paytirish, keyin ayirish. Qavs kerak bo'lsa — faqat masala shuni talab qilganda.</p>",
 q:{t:"Do'konda 5 ta qopda 40 kg dan un bor edi, 75 kg sotildi. Qaysi ifoda qolgan unni topadi?",opts:["5 · 40 − 75","5 + 40 − 75","(40 − 75) · 5","5 · (40 + 75)"],ok:0,why:"Hammasi 5 · 40 = 200, sotilgani 75 ayiriladi: 125 kg.",hint:"Avval hammasini toping, keyin sotilganini olib tashlang.",full:"5 · 40 = 200 kg un bor edi, 75 kg sotildi: 5 · 40 − 75 = 125 kg. «(40 − 75) · 5» — har qopdan 75 kg sotilgan bo'lardi, bu mumkin emas."},
 tn:"Bolalar ifodani yozgach, har bir son nimani bildirishini so'zlab bersin: «3 · 24 — hamma tuxum»."}),
bmStep({h:"Bilasizmi? Masala yechishning 4 qadami",sum:"Polya: 1) tushun, 2) reja tuz, 3) bajar, 4) tekshir.",a:"m08",
 frames:[{t:'Vengriyalik matematik Dyord Polya (1945): masala yechishning 4 qadami',lines:['1) Tushun: nima berilgan, nima so‘ralgan?','2) Reja tuz: qaysi savollar, qaysi amallar?','3) Bajar: hisobla, har qadamni yoz','4) Tekshir: javobni shartga qo‘yib ko‘r'],hl:{3:'ok'},note:'Eng ko‘p unutiladigan qadam — 4-qadam!'}],
 html:"<p>📘 Vengriyalik matematik <b>Dyord Polya</b> 1945-yilda «Qanday yechish kerak» kitobini yozgan. U butun dunyoda o'qituvchilar uchun asosiy qo'llanma bo'lib qolgan. Unda masala yechishning <b>4 qadami</b> bor.</p>",
 after:"<p>Tekshiring: bodring masalasida 29 · 5 = 145, 145 + 235 = 380 ✓. Tekshirish 30 soniya oladi, lekin xatoni darhol ushlaydi!</p>",
 tn:"4 qadamni plakat qilib sinf devoriga osing. Har masaladan keyin «4-qadamni qildingmi?» deb so'rang."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Reja: savollar zanjiri',lines:['1) Nima berilgan? Nima so‘ralgan?','2) Yashirin savol: avval nimani topish kerak?','3) Har amal oldidan — o‘z savoli','4) Javobni shartga qo‘yib tekshir']})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>Ikki/uch amalli masalada avval <b>yashirin savol</b>ni toping (qancha qoldi? hammasi qancha?).</li><li>Har amal oldidan <b>savol</b> yozing: «1) Qancha qoldi?»</li><li>«… tadan … ta» → <b>ko'paytirish</b>; «teng bo'lindi» → <b>bo'lish</b>.</li><li>«Har kuni bir xil» → avval jami sarf: 135 · 3.</li><li>Guruh tarkibini o'qing: «4 g'ildirak <b>va 1 zaxira</b>» = 5.</li><li>«Kamida nechta kerak» + qoldiq → <b>yana bitta</b> qo'shing.</li><li>Yashirin ma'lumot: hafta = 7 kun, sutka = 24 soat.</li><li>Oxirida <b>tekshiring</b>!</li></ul></div>",
 tn:"Keyingi darsni «580 − 135 · 3» ifodasiga masala tuzishdan boshlang: bolalar o'zi shart o'ylab topsin."}
];
var PROBS=[
{t:"380 kg bodringdan 235 kg tuzlandi. Qolganini 5 kg dan yashiklarga solish uchun nechta yashik kerak?",o:["29","27","28","26"],k:0,s:"380 − 235 = 145; 145 : 5 = 29."},
{t:"Maktabga 560 ta kitob keltirildi, 280 tasi tarqatildi, qolgani 7 sinfga teng bo'lindi. Har sinfga nechtadan?",o:["40","80","30","50"],k:0,s:"560 − 280 = 280; 280 : 7 = 40."},
{t:"Pochtachi 45 tadan xat bo'lgan 7 ta paket olib keldi va 277 tasini tarqatdi. Nechta xat qoldi?",o:["38","28","48","31"],k:0,s:"45 · 7 = 315; 315 − 277 = 38."},
{t:"Oshxonaga 580 kg kartoshka keldi. Har kuni 135 kg ishlatilsa, 3 kundan keyin qancha qoladi?",o:["175 kg","445 kg","405 kg","745 kg"],k:0,s:"135 · 3 = 405; 580 − 405 = 175."},
{t:"3 sher kuniga 5 kg dan, 8 yo'lbars 3 kg dan go'sht yeydi. Bir haftada necha kg go'sht kerak?",o:["273 kg","39 kg","168 kg","270 kg"],k:0,s:"(15 + 24) · 7 = 39 · 7 = 273."},
{t:"400 ta g'ildirak bor. Har mashinaga 4 ta g'ildirak va 1 ta zaxira qo'yiladi. Nechta mashinaga yetadi?",o:["80","100","96","200"],k:0,s:"Bir mashinaga 5 ta; 400 : 5 = 80."},
{t:"47 o'quvchini 10 o'rinli mikroavtobuslarga joylash uchun kamida nechta mikroavtobus kerak?",o:["5","4","7","6"],k:0,s:"47 : 10 = 4 (qoldiq 7); 4 + 1 = 5."},
{t:"6 qutida 25 tadan olma bor. 38 tasi sotildi, qolgani 4 savatga teng bo'lindi. Har savatda nechta?",o:["28","112","150","37"],k:0,s:"150 − 38 = 112; 112 : 4 = 28."},
{t:"Bakda 900 l suv bor edi. Har kuni 120 l ishlatildi. 5 kundan keyin qancha qoldi?",o:["300 l","780 l","600 l","180 l"],k:0,s:"120 · 5 = 600; 900 − 600 = 300."},
{t:"4 ot kuniga 6 kg dan, 3 sigir 9 kg dan pichan yeydi. 5 kunda necha kg pichan kerak?",o:["255 kg","51 kg","165 kg","120 kg"],k:0,s:"24 + 27 = 51; 51 · 5 = 255."},
{t:"Har sumkaga 3 ta daftar va 1 ta qalam solinadi. 120 ta buyumdan nechta sumka yig'iladi?",o:["30","40","117","120"],k:0,s:"Bir sumka — 4 buyum; 120 : 4 = 30."},
{t:"Qaysi ifoda masalaga mos: «5 qopda 40 kg dan un bor edi, 75 kg sotildi. Qancha qoldi?»",o:["5 · 40 − 75","5 + 40 − 75","(40 − 75) · 5","5 · 75 − 40"],k:0,s:"Hammasi 5 · 40, sotilgani ayiriladi: 125 kg."},
{t:"Bog'da 8 qatorda 12 tadan olma daraxti va 35 ta nok daraxti bor. Jami nechta daraxt?",o:["131","55","96","420"],k:0,s:"12 · 8 = 96; 96 + 35 = 131."},
{t:"Kitob 240 bet. Ali kuniga 15 betdan 6 kun o'qidi. Yana necha bet qoldi?",o:["150","90","225","21"],k:0,s:"15 · 6 = 90; 240 − 90 = 150."},
{t:"Do'konga 6 yashik banan keltirildi, har birida 18 kg. 3 kunda 25 kg dan sotildi. Qancha qoldi?",o:["33 kg","83 kg","108 kg","75 kg"],k:0,s:"18 · 6 = 108; 25 · 3 = 75; 108 − 75 = 33."},
{t:"Sinfda 28 o'quvchi. Har biriga 3 tadan daftar kerak. Qutida 50 ta daftar bor. Yana nechta daftar kerak?",o:["34","84","22","31"],k:0,s:"28 · 3 = 84; 84 − 50 = 34."},
{t:"65 kg olmani 8 kg sig'adigan yashiklarga solish uchun kamida nechta yashik kerak?",o:["9","8","1","73"],k:0,s:"65 : 8 = 8 (qoldiq 1) → 8 + 1 = 9."},
{t:"Ota 3 ta ko'ylak 85 000 so'mdan va 2 ta shim oldi. Jami 395 000 so'm to'ladi. Bitta shim necha so'm?",o:["70 000","140 000","155 000","255 000"],k:0,s:"85 000 · 3 = 255 000; 395 000 − 255 000 = 140 000; 140 000 : 2 = 70 000."},
{t:"Har kuni 4 soatdan, 6 kun davomida soatiga 9 ta detal yasaldi. Jami nechta detal?",o:["216","54","36","19"],k:0,s:"4 · 6 = 24 soat; 24 · 9 = 216."},
{t:"Avtobusda 52 yo'lovchi bor edi. Bekatda 17 kishi tushdi, 9 kishi chiqdi. Keyingi bekatda 12 kishi tushdi. Avtobusda nechta yo'lovchi qoldi?",o:["32","56","14","38"],k:0,s:"52 − 17 + 9 − 12 = 32."}
];
function PRACT_STAGE(){bmDraw({t:'Har masalada: avval reja!',lines:['1) Nima berilgan? Nima so‘ralgan?','2) Avval nimani topish kerak?','3) Har amal — o‘z savoli','4) Tekshir']})}
var PREP_DATA={teach:["Ikki va uch amalli masalalarda «yashirin savol»ni topish.","Har amal oldidan savol yozib, reja tuzish.","Teng guruh tarkibini aniqlash («va 1 ta zaxira»).","Qoldiqli bo'lishda «kamida nechta kerak» savoli.","Masaladan ifoda tuzish; Polyaning 4 qadami."],
 mist:["Birinchi amalni bajarib, savolga javob berildi deb to'xtaydi.","Guruh tarkibidagi qo'shimcha narsani unutadi (400 : 4 = 100).","Qoldiq bo'lsa yana bitta yashik qo'shmaydi.","Yashirin ma'lumotni (hafta = 7 kun) e'tiborsiz qoldiradi."],
 need:["Rangli qog'oz tasmalar (chizma model uchun).","Polyaning 4 qadami yozilgan plakat."],
 board:["Chizma: <span class='w2'>[235 | ?] = 380</span>.","Reja: <span class='w2'>1) Qancha qoldi? 2) Nechta yashik?</span>","<span class='w2'>380 − 235 = 145; 145 : 5 = 29</span>.","Tuzoq: <span class='w2'>4 + 1 = 5; 400 : 5 = 80</span>.","Qoldiq: <span class='w2'>47 : 10 = 4 (qold. 7) → 5 ta</span>.","Ifoda: <span class='w2'>3 · 24 − 18</span>."]};
