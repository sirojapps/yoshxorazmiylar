// ===== w_4iy umumiy sahna vositalari (4I3–4I5, 4Y2–4Y6) =====
// matn ichidagi kasrlarni (a/b) ustma-ust chizish
function y4T(p,x,y,txt,a){a=a||{};txt=String(txt);var RE=/(\d{1,3})\/(\d{1,3})(?![\d\/])/g;if(a.nofr||/^\d{1,3}\/\d{1,3}$/.test(txt)||!RE.test(txt))return T(p,x,y,txt,a);RE.lastIndex=0;
 var fs=+(a['font-size']||12),g=E('g',{},p),cx=0,last=0,m,base=Object.assign({'font-size':12,fill:'#3a4a5a','font-weight':600},a);delete base['text-anchor'];delete base.nofr;
 function piece(t){if(!t)return;var e=E('text',Object.assign({},base,{x:cx,y:y,'text-anchor':'start'}),g);e.textContent=t;e.setAttribute('xml:space','preserve');e.style.whiteSpace='pre';var w=0;try{w=e.getComputedTextLength()}catch(_){w=t.length*fs*.55}cx+=w}
 while((m=RE.exec(txt))){piece(txt.slice(last,m.index));var f2=fs*.8,w2=Math.max(m[1].length,m[2].length)*f2*.62+4,c=cx+w2/2+1;
  var n=E('text',Object.assign({},base,{x:c,y:y-f2*.45,'text-anchor':'middle','font-size':f2}),g);n.textContent=m[1];var d=E('text',Object.assign({},base,{x:c,y:y+f2*.75,'text-anchor':'middle','font-size':f2}),g);d.textContent=m[2];
  E('line',{x1:c-w2/2,y1:y-f2*.18,x2:c+w2/2,y2:y-f2*.18,stroke:base.fill,'stroke-width':Math.max(1.2,f2/9)},g);cx+=w2+2;last=m.index+m[0].length}
 piece(txt.slice(last));var an=a['text-anchor']||'middle',sh=an==='start'?x:an==='end'?x-cx:x-cx/2;g.setAttribute('transform','translate('+sh+',0)');return g}
function y4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function y4pick(okI,arr,fin){return arr.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();y4msg('✓ '+m[1]);done()}else y4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function y4t(x,y,t,o){return y4T(S.g,x,y,t,Object.assign({'font-size':12,'font-weight':700,fill:'#1d2b3a'},o||{}))}
function y4title(t){return y4t(14,17,t,{'text-anchor':'start','font-size':11,'font-weight':700,fill:'#3a4a5a'})}
function y4sector(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:'#fff','stroke-width':2},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:'#fff','stroke-width':2},p)}
// doiraviy diagramma: parts=[[gradus,rang,yozuv]]
function y4pie(cx,cy,r,parts,fs){var a=-Math.PI/2;parts.forEach(function(q){var a1=a+q[0]*Math.PI/180;y4sector(S.g,cx,cy,r,a,a1,q[1]);if(q[2]){var m=(a+a1)/2,k=q[0]<50?.72:.58;y4t(cx+r*k*Math.cos(m),cy+r*k*Math.sin(m)+4,q[2],{'font-size':fs||11,'font-weight':800})}a=a1})}
// o'qlar: o={x0,x1,yb,yt,min,max,step,n,labels,unit}
function y4axes(o){var g=S.g,X=function(i){return o.x0+(i+.5)*(o.x1-o.x0)/o.n},Y=function(v){return o.yb-(v-(o.min||0))/(o.max-(o.min||0))*(o.yb-o.yt)};
 for(var v=(o.min||0);v<=o.max+1e-9;v+=o.step){E('line',{x1:o.x0,y1:Y(v),x2:o.x1,y2:Y(v),stroke:v===(o.min||0)?'#33475b':'#e3e8ee','stroke-width':v===(o.min||0)?1.6:1},g);T(g,o.x0-5,Y(v)+4,String(v),{'font-size':10,'text-anchor':'end',fill:'#3a4a5a'})}
 E('line',{x1:o.x0,y1:o.yt-6,x2:o.x0,y2:o.yb,stroke:'#33475b','stroke-width':1.6},g);
 (o.labels||[]).forEach(function(l,i){T(g,X(i),o.yb+14,l,{'font-size':10,'font-weight':700,fill:'#33475b'})});
 if(o.unit)T(g,o.x0+4,o.yt-10,o.unit,{'font-size':10,'text-anchor':'start',fill:'#3a4a5a'});return {X:X,Y:Y}}
function y4bars(o,vals,cols,showV){var A=y4axes(o),bw=(o.x1-o.x0)/o.n*.56;vals.forEach(function(v,i){if(v==null)return;var y=A.Y(v);E('rect',{x:A.X(i)-bw/2,y:y,width:bw,height:o.yb-y,fill:(cols&&cols[i])||C.b,rx:2},S.g);if(showV)T(S.g,A.X(i),y-4,String(v),{'font-size':10,'font-weight':800,fill:'#1d2b3a'})});return A}
function y4lineg(o,vals,col,k,showV){var A=y4axes(o);k=k==null?vals.length:k;var d='';for(var i=0;i<k;i++)d+=(i?' L':'M')+A.X(i)+' '+A.Y(vals[i]);if(k>1)E('path',{d:d,fill:'none',stroke:col||C.blue,'stroke-width':2.5},S.g);
 for(var j=0;j<k;j++){E('circle',{cx:A.X(j),cy:A.Y(vals[j]),r:4,fill:col||C.blue},S.g);if(showV)T(S.g,A.X(j),A.Y(vals[j])-8,String(vals[j]),{'font-size':10,'font-weight':800,fill:col||C.blue})}return A}
function y4addLine(A,vals,col,showV){var d='';vals.forEach(function(v,i){d+=(i?' L':'M')+A.X(i)+' '+A.Y(v)});E('path',{d:d,fill:'none',stroke:col,'stroke-width':2.5,'stroke-dasharray':'6 3'},S.g);vals.forEach(function(v,i){E('rect',{x:A.X(i)-3.5,y:A.Y(v)-3.5,width:7,height:7,fill:col},S.g);if(showV)T(S.g,A.X(i),A.Y(v)+15,String(v),{'font-size':10,'font-weight':800,fill:col})})}
// Venn: ikki to'plam
function y4venn2(la,lb,n,hl){var g=S.g;E('rect',{x:14,y:26,width:332,height:142,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:142,cy:106,r:56,fill:hl&&hl.a?'#ffe1b0':'rgba(240,160,64,.18)',stroke:C.a,'stroke-width':2.2},g);E('circle',{cx:218,cy:106,r:56,fill:hl&&hl.b?'#cfe6fa':'rgba(90,169,230,.18)',stroke:C.b,'stroke-width':2.2},g);
 if(hl&&hl.ab){E('path',{d:'M180 65 A56 56 0 0 1 180 147 A56 56 0 0 1 180 65 Z',fill:'#c8efd8',stroke:'none'},g)}
 T(g,104,42,la,{'font-size':11,'font-weight':800,fill:C.a2});T(g,256,42,lb,{'font-size':11,'font-weight':800,fill:C.blue});
 if(n){[['a',112,111],['ab',180,111],['b',248,111],['o',322,158]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':16,'font-weight':800,fill:'#1d2b3a'})})}}
// Venn: uch to'plam
function y4venn3(la,lb,lc,n){var g=S.g;E('rect',{x:14,y:24,width:332,height:146,rx:8,fill:'#fff',stroke:'#c9d3dd'},g);
 E('circle',{cx:152,cy:74,r:44,fill:'rgba(240,160,64,.16)',stroke:C.a,'stroke-width':2},g);E('circle',{cx:208,cy:74,r:44,fill:'rgba(90,169,230,.16)',stroke:C.b,'stroke-width':2},g);E('circle',{cx:180,cy:120,r:44,fill:'rgba(30,142,90,.13)',stroke:C.ok,'stroke-width':2},g);
 T(g,96,40,la,{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});T(g,264,40,lb,{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'start'});T(g,232,160,lc,{'font-size':11,'font-weight':800,fill:C.ok,'text-anchor':'start'});
 if(n){[['a',130,66],['b',230,66],['c',180,150],['ab',180,58],['ac',154,110],['bc',206,110],['abc',180,92],['o',330,40]].forEach(function(p){if(n[p[0]]!=null)T(g,p[1],p[2],String(n[p[0]]),{'font-size':13,'font-weight':800,fill:'#1d2b3a'})})}}
// 10×10 to'r (foiz)
function y4grid(x,y,s,k,col){var g=S.g;for(var i=0;i<100;i++){var r=Math.floor(i/10),c=i%10;E('rect',{x:x+c*s,y:y+r*s,width:s,height:s,fill:i<k?(col||C.a):'#fff',stroke:'#c9a764','stroke-width':.8},g)}E('rect',{x:x,y:y,width:10*s,height:10*s,fill:'none',stroke:C.line,'stroke-width':1.8},g)}
// yo'l (harakat): uzunlik L km, x0..x1
function y4road(y,L,x0,x1,ticks){var g=S.g,k=(x1-x0)/L;E('line',{x1:x0,y1:y,x2:x1,y2:y,stroke:'#33475b','stroke-width':3},g);(ticks||[]).forEach(function(t){var X=x0+t*k;E('line',{x1:X,y1:y-5,x2:X,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);T(g,X,y+18,String(t),{'font-size':10,fill:'#3a4a5a'})});return function(v){return x0+v*k}}
function y4dot(x,y,lbl,col){E('circle',{cx:x,cy:y,r:9,fill:col,stroke:'#fff','stroke-width':2},S.g);T(S.g,x,y+4,lbl,{'font-size':10,'font-weight':800,fill:'#fff'})}
function y4arrow(x1,x2,y,txt,col){var g=S.g;E('line',{x1:x1,y1:y,x2:x2,y2:y,stroke:col,'stroke-width':2.2},g);var d=x2>x1?-1:1;E('path',{d:'M'+x2+' '+y+' l'+(d*7)+' -5 l0 10 Z',fill:col},g);if(txt)T(g,(x1+x2)/2,y-6,txt,{'font-size':11,'font-weight':800,fill:col})}
// kub yoyilmasi: cells=[[ustun,qator,yozuv]]
function y4net(x,y,s,cells,col,fs){cells.forEach(function(c){E('rect',{x:x+c[0]*s,y:y+c[1]*s,width:s,height:s,fill:col||'#fff3dc',stroke:C.line,'stroke-width':1.5},S.g);if(c[2]!=null)T(S.g,x+(c[0]+.5)*s,y+(c[1]+.5)*s+5,String(c[2]),{'font-size':fs||13,'font-weight':800,fill:'#1d2b3a'})})}
// soat
function y4clock(cx,cy,r,hh,mm,shade){var g=S.g;E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 if(shade){var a0=Math.min(ah,am),a1=Math.max(ah,am);y4sector(g,cx,cy,r-4,a0,a1,'#ffe2b8')}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;E('line',{x1:cx+(r-7)*Math.cos(a2),y1:cy+(r-7)*Math.sin(a2),x2:cx+(r-2)*Math.cos(a2),y2:cy+(r-2)*Math.sin(a2),stroke:'#33475b','stroke-width':2},g);T(g,cx+(r-17)*Math.cos(a2),cy+(r-17)*Math.sin(a2)+4,String(h),{'font-size':10,'font-weight':700,fill:'#1d2b3a'})}
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g)}
function y4f(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
var CODE='4I3',TITLE='4-sinf · Chiziqli va doiraviy diagrammalar';
var I3T=[12,15,11,17,20,18,14],I3D=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function i3temp(k,hl){clear();y4title('Bir haftalik havo harorati, °C');var A=y4lineg({x0:40,x1:345,yb:146,yt:34,min:0,max:25,step:5,n:7,labels:I3D},I3T,C.a2,k,true);
 if(hl){E('line',{x1:A.X(2),y1:A.Y(11),x2:A.X(3),y2:A.Y(17),stroke:C.ok,'stroke-width':6,opacity:.55},S.g);y4t(186,104,'+6°',{'font-size':13,'font-weight':800,fill:C.ok})}}
var I3P1=[function(){i3temp(3);calc(['Har kun — bitta nuqta. Balandligi = harorat'])},function(){i3temp(7);calc(['Nuqtalarni chiziq bilan tutashtiramiz — o‘zgarish ko‘rinadi'])},function(){i3temp(7,1);calc(['Chiziq qanchalik <b>tik</b> ko‘tarilsa, o‘zgarish shuncha katta','Ch → Pa: 11° → 17°, <b>+6°</b> (eng katta ko‘tarilish)'])}];
var I3S=[20,40,50,70];
function i3save(sh){clear();y4title('Lolaning tejagan puli (ming so‘m)');var A=y4lineg({x0:46,x1:340,yb:146,yt:34,min:0,max:80,step:20,n:4,labels:['Sen','Okt','Noy','Dek']},I3S,C.blue,4,false);
 if(sh){E('line',{x1:46,y1:A.Y(50),x2:A.X(2),y2:A.Y(50),stroke:C.ok,'stroke-width':1.5,'stroke-dasharray':'4 3'},S.g);y4t(A.X(2)+22,A.Y(50)+4,'50',{'font-size':13,'font-weight':800,fill:C.ok})}}
var I3A=[10,20,30,40,50],I3V=[25,30,35,40,45];
function i3two(st){clear();y4title('O‘qilgan betlar soni (jami)');var o={x0:40,x1:345,yb:146,yt:34,min:0,max:50,step:10,n:5,labels:['1-kun','2-kun','3-kun','4-kun','5-kun']};
 var A=y4lineg(o,I3A,C.a2,st>=0?5:0,false);if(st>=1)y4addLine(A,I3V,C.blue,false);
 y4t(70,30,'— Ali',{'font-size':11,'font-weight':800,fill:C.a2});y4t(130,30,'- - Vali',{'font-size':11,'font-weight':800,fill:C.blue});
 if(st>=2){E('circle',{cx:A.X(3),cy:A.Y(40),r:11,fill:'none',stroke:C.ok,'stroke-width':2.5},S.g);y4t(A.X(3),A.Y(40)-16,'teng: 40',{'font-size':11,'font-weight':800,fill:C.ok})}}
var I3P3=[function(){i3two(0);calc(['Ali har kuni 10 betdan o‘qiydi'])},function(){i3two(1);calc(['Vali 20 bet o‘qib qo‘ygan edi, har kuni 5 betdan qo‘shadi'])},function(){i3two(2);calc(['Chiziqlar <b>kesishgan</b> joyda betlar teng: 4-kun, 40 tadan','Kesishgandan keyin Alining chizig‘i tepada'])}];
var I3K=['#f0a040','#5aa9e6','#7cc68f','#f08aa8','#c9a0e6'];
function i3pie1(st){clear();y4title('Sinfdagi 40 bola qaysi sportni yoqtiradi?');
 if(st===0){y4pie(110,96,62,[[360,'#e9e2d6','']]);y4t(110,100,'40 bola',{'font-size':14,'font-weight':800})}
 if(st===1){y4pie(110,96,62,[[180,I3K[0],'1/2'],[180,'#e9e2d6','']])}
 if(st>=2)y4pie(110,96,62,[[180,I3K[0],'1/2'],[90,I3K[1],'1/4'],[90,I3K[2],'1/4']],13);
 var L=[['futbol',I3K[0],'1/2 · 40 = 20'],['basketbol',I3K[1],'1/4 · 40 = 10'],['shaxmat',I3K[2],'1/4 · 40 = 10']];
 L.forEach(function(l,i){if(st<1||(st<2&&i>0))return;E('rect',{x:196,y:52+i*34,width:14,height:14,fill:l[1]},S.g);y4t(216,63+i*34,l[0],{'text-anchor':'start','font-size':12});if(st>=3)y4t(216,77+i*34,l[2],{'text-anchor':'start','font-size':11,fill:C.ok})})}
var I3P4=[function(){i3pie1(0);calc(['Butun doira = <b>hamma</b> bolalar (40 ta)'])},function(){i3pie1(1);calc(['Yarim doira — yarmi: futbol'])},function(){i3pie1(2);calc(['Qolgan yarmi teng ikkiga: chorak va chorak'])},function(){i3pie1(3);calc(['Har qism soni = <b>qism · jami</b>','20 + 10 + 10 = 40 ✓ (qismlar yig‘indisi — butun)'])}];
function i3deg(sh){clear();y4title('24 bola: sevimli meva (doira = 360°)');y4pie(105,98,64,[[120,I3K[0],'120°'],[90,I3K[1],'90°'],[150,I3K[2],'150°']],12);
 [['olma',I3K[0],'120° = 1/3 → 8'],['nok',I3K[1],'90° = 1/4 → 6'],['uzum',I3K[2],'150° → 10']].forEach(function(l,i){E('rect',{x:196,y:50+i*34,width:14,height:14,fill:l[1]},S.g);y4t(216,61+i*34,l[0],{'text-anchor':'start'});if(sh&&(i===0||sh>1))y4t(216,75+i*34,l[2],{'text-anchor':'start','font-size':11,fill:C.ok})})}
function i3twopie(sh){clear();y4title('Matematikani sevimli fan deb tanlaganlar');y4pie(90,92,52,[[180,I3K[0],'1/2'],[180,'#e9e2d6','']],13);y4pie(270,92,52,[[90,I3K[1],'1/4'],[270,'#e9e2d6','']],13);
 y4t(90,162,'A sinf: 20 bola',{'font-size':12});y4t(270,162,'B sinf: 40 bola',{'font-size':12});if(sh){y4t(90,32,'20 : 2 = 10',{'font-size':12,'font-weight':800,fill:C.ok});y4t(270,32,'40 : 4 = 10',{'font-size':12,'font-weight':800,fill:C.ok})}}
function i3budget(st){clear();y4title('Oila daromadi 1 200 000 so‘m');var P=[[180,I3K[0],'1/2'],[90,I3K[1],'1/4'],[60,I3K[2],'1/6'],[30,I3K[3],'']];y4pie(95,96,62,P.slice(0,Math.min(st+1,4)).concat(st<3?[[360-[180,270,330][st],'#e9e2d6','']]:[]),12);
 var L=[['ovqat','1/2 → 600 000'],['kommunal','1/4 → 300 000'],['kiyim','1/6 → 200 000'],['tejash','qolgani → 100 000']];
 L.forEach(function(l,i){if(i>st)return;E('rect',{x:184,y:40+i*30,width:13,height:13,fill:I3K[i]},S.g);y4t(203,50+i*30,l[0]+': '+l[1],{'text-anchor':'start','font-size':11})})}
var I3P7=[function(){i3budget(0);calc(['Ovqat: 1 200 000 : 2 = 600 000'])},function(){i3budget(1);calc(['Kommunal: 1 200 000 : 4 = 300 000'])},function(){i3budget(2);calc(['Kiyim: 1 200 000 : 6 = 200 000'])},function(){i3budget(3);calc(['Qolgani: 1 200 000 − 600 000 − 300 000 − 200 000 = <b>100 000</b>','Doirada bu 30° — eng kichik bo‘lak'])}];
function i3kinds(){clear();y4title('Uch xil diagramma — uch xil vazifa');var g=S.g;
 E('path',{d:'M24 120 L50 96 L76 104 L102 66',fill:'none',stroke:C.a2,'stroke-width':3},g);[[24,120],[50,96],[76,104],[102,66]].forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:4,fill:C.a2},g)});E('line',{x1:20,y1:132,x2:110,y2:132,stroke:'#33475b'},g);
 y4t(65,152,'chiziqli',{'font-size':12,'font-weight':800});y4t(65,166,'vaqt bo‘yicha o‘zgarish',{'font-size':10,fill:'#3a4a5a'});
 y4pie(180,96,36,[[200,I3K[0],''],[100,I3K[1],''],[60,I3K[2],'']]);y4t(180,152,'doiraviy',{'font-size':12,'font-weight':800});y4t(180,166,'butunning qismlari',{'font-size':10,fill:'#3a4a5a'});
 [40,64,30,52].forEach(function(h,i){E('rect',{x:250+i*22,y:132-h,width:15,height:h,fill:C.b},g)});E('line',{x1:244,y1:132,x2:342,y2:132,stroke:'#33475b'},g);y4t(295,152,'ustunli',{'font-size':12,'font-weight':800});y4t(295,166,'taqqoslash',{'font-size':10,fill:'#3a4a5a'})}
function i3hist(st){clear();y4title('Diagrammalar qachon paydo bo‘lgan?');var g=S.g;E('line',{x1:30,y1:100,x2:330,y2:100,stroke:'#33475b','stroke-width':3},g);
 var Y=[[1786,60,'chiziqli va ustunli','U. Pleyfer'],[1801,170,'doiraviy','U. Pleyfer'],[1858,280,'«atirgul» diagramma','F. Naytingeyl']];
 Y.forEach(function(y,i){if(i>st)return;E('circle',{cx:y[1],cy:100,r:7,fill:C.a},g);y4t(y[1],86,String(y[0]),{'font-size':14,'font-weight':800,fill:C.a2});y4t(y[1],124,y[2],{'font-size':11,'font-weight':800});y4t(y[1],140,y[3],{'font-size':10,fill:'#3a4a5a'})})}
var I3P9=[function(){i3hist(0);calc(['1786: Shotlandiyalik Uilyam Pleyfer chiziqli va ustunli diagrammani o‘ylab topdi'])},function(){i3hist(1);calc(['1801: o‘sha Pleyfer — birinchi doiraviy diagramma'])},function(){i3hist(2);calc(['1858: Florens Naytingeyl diagramma bilan kasalxonalarni isloh qildirdi'])}];
function PRACT_STAGE(){clear();y4title('Diagrammani o‘qishdan oldin: nomi, o‘qlar, butun nechaga teng?');y4pie(90,100,52,[[180,I3K[0],'1/2'],[120,I3K[1],'1/3'],[60,I3K[2],'1/6']],12);
 var A=y4lineg({x0:190,x1:345,yb:150,yt:44,min:0,max:30,step:10,n:4,labels:['1','2','3','4']},[10,15,25,20],C.a2,4,false);calc(['Doiraviy: qismlar → sonlar. Chiziqli: qadam → qiymat'])}
var STEPS=[
{h:"Chiziqli diagramma: o'zgarishni ko'rish",sum:"Har kun — nuqta, nuqtalar chiziq bilan tutashadi. Chiziq qancha tik bo'lsa, o'zgarish shuncha katta.",a:"m01",
 start:function(){startPh(I3P1)},fin:function(){S.ph=2;I3P1[2]()},
 html:"<p>Bir hafta davomida har kuni tushda havo harorati o'lchandi. Bu sonlarni <b>chiziqli diagramma</b>ga aylantiramiz. Bosib boring:</p>",btns:[phaser(I3P1)],
 after:"<p>Chiziqli diagramma <b>vaqt o'tishi bilan o'zgarish</b>ni ko'rsatadi. Chiziq yuqoriga ketsa — ortgan, pastga — kamaygan, qanchalik tik bo'lsa — o'zgarish shuncha katta.</p>",
 q:{t:"Diagramma bo'yicha: qaysi kuni eng issiq bo'lgan va u dushanbadan necha gradus issiq?",opts:["Juma, 8° ga","Juma, 20° ga","Payshanba, 5° ga","Shanba, 6° ga"],ok:0,why:"Eng baland nuqta — Juma, 20°; 20 − 12 = 8.",hint:"Eng baland nuqtani toping, keyin dushanbaning qiymatini ayiring.",full:"Eng baland nuqta — Juma (20°). Dushanba 12°. 20 − 12 = 8° ga issiq. «20° ga» — farq emas, Jumaning o'z qiymati."},
 tn:"Doskada o'qlarni chizing, bolalar navbat bilan nuqta qo'ysin. So'ng «eng tik bo'lak»ni barmoq bilan ko'rsatish o'yini."},
{h:"Shkalani to'g'ri o'qish",sum:"O'qdagi sonlar har 20 da. Nuqta 40 va 60 ning o'rtasida → 50.",a:"m02",
 start:function(){i3save(0);calc(['Noyabrda Lola necha ming so‘m tejagan? Variantni tanlang'])},fin:function(){i3save(1);y4msg('Noyabr: <b>50</b> ming so‘m')},
 html:"<p>Diagrammada nuqta to'r chizig'iga to'g'ri kelmasa nima qilamiz? Avval o'qdagi <b>qadam</b>ni aniqlang: 0, 20, 40… Noyabr nuqtasi qanchani bildiradi?</p>",
 btns:y4pick(0,[["50","40 va 60 ning roppa-rosa o'rtasi: 40 + 10 = 50."],["41","Kataklarni birlab sanadingiz. Bu o'qda bir chiziqdan keyingisiga 20 qadam."],["45","Ko'z bilan chamaladingiz. O'rtasi aniq: 40 bilan 60 ning yarmi — 50."],["60","Bu — keyingi chiziq. Nuqta undan pastda."]],function(){i3save(1)}),g2:1,
 after:"<p>Diagrammani o'qishdan oldin: 1) o'q nimani ko'rsatadi (birligi); 2) <b>qadam</b> nechaga teng; 3) nuqta qaysi ikki chiziq orasida. O'rtada bo'lsa — qadamning yarmini qo'shamiz.</p>",
 q:{t:"Vertikal o'qda 0, 50, 100, 150 yozilgan. Nuqta 100 bilan 150 ning roppa-rosa o'rtasida. Qiymat nechaga teng?",opts:["125","101","110","150"],ok:0,why:"Qadam 50, yarmi 25: 100 + 25 = 125.",hint:"Qadam nechaga teng? Uning yarmi-chi?",full:"Qadam 50 ga teng, o'rtasi — qadamning yarmi, 25. 100 + 25 = 125. «101» — birlab sanash, «110» — ko'z bilan chamalash, «150» — keyingi chiziq."},
 tn:"Bitta grafikni har xil shkalada (5, 10, 20, 50) chizib, bolalardan bir xil nuqtani o'qishni so'rang."},
{h:"Ikki chiziq bitta diagrammada",sum:"Kesishish nuqtasida qiymatlar teng; undan keyin tepadagi chiziq ko'p.",a:"m03",
 start:function(){startPh(I3P3)},fin:function(){S.ph=2;I3P3[2]()},
 html:"<p>Ikki bola kitob o'qiyapti. Har birining jami o'qigan betlari — alohida chiziq. Bosing:</p>",btns:[phaser(I3P3)],
 after:"<p>Ikki chiziq <b>kesishgan</b> joyda qiymatlar teng. Kesishishdan oldin bir chiziq tepada, keyin boshqasi. Tikroq chiziq — tezroq o'sadi.</p>",
 q:{t:"Diagramma bo'yicha: qaysi kuni Ali Validan BIRINCHI marta ko'p o'qigan bo'ladi?",opts:["5-kun","4-kun","1-kun","3-kun"],ok:0,why:"4-kun teng (40 = 40), 5-kun Ali 50, Vali 45.",hint:"Kesishish nuqtasidan keyingi kunni qarang.",full:"1–3-kunlarda Vali oldinda (25>10, 30>20, 35>30), 4-kun teng — 40 tadan, 5-kun Ali 50 > 45. Javob: 5-kun. «4-kun» — teng bo'lgan kun, ko'p emas."},
 tn:"Ikki rangli bo'r bilan chizing. «Kim oldinda?» savolini har kun uchun bering — bolalar qo'l ko'tarib javob beradi."},
{h:"Doiraviy diagramma: butun va qismlar",sum:"Butun doira — hammasi. Qism soni = qism · jami: 1/2 · 40 = 20, 1/4 · 40 = 10.",a:"m04",
 start:function(){startPh(I3P4)},fin:function(){S.ph=3;I3P4[3]()},
 html:"<p><b>Doiraviy diagramma</b>da butun doira — hamma narsa (bu yerda 40 bola). Har bo'lak — butunning bir qismi. Bosing:</p>",btns:[phaser(I3P4)],
 after:"<p>Qismdagi son = jami ÷ maxraj (yoki qism · jami). Teskari: qism soni ma'lum bo'lsa, jami = qism soni · maxraj. Barcha bo'laklar yig'indisi — har doim butun.</p>",
 q:{t:"Doiraviy diagrammada chorak (1/4) qism 12 bolaga to'g'ri keladi. Jami nechta bola so'ralgan?",opts:["48","3","16","36"],ok:0,why:"Butun = 4 ta chorak: 12 · 4 = 48.",hint:"Butun doirada nechta chorak bor?",full:"Butun doirada 4 ta chorak, har biri 12 bola: 12 · 4 = 48. «3» — 12 : 4 (teskari amal), «16» — 12 + 4, «36» — 3 ta chorak."},
 tn:"Qog'oz doirani buklab yarim va chorak qiling. Bolalar o'z sinfidagi so'rov natijasini shunday doiraga bo'yaydi."},
{h:"Gradus orqali qismni topish",sum:"Doira = 360°. 120° = 1/3, 90° = 1/4. 24 bolaning 1/3 qismi = 8.",a:"m05",
 start:function(){i3deg(0);calc(['«Olma» bo‘lagi 120°. Nechta bola olmani tanlagan?'])},fin:function(){i3deg(2);y4msg('olma 8, nok 6, uzum 10 — jami 24 ✓')},
 html:"<p>Ba'zan bo'lakning <b>gradus</b>i yoziladi. Butun doira — <b>360°</b>. 24 bola so'ralgan. Olmani nechta bola tanlagan?</p>",
 btns:y4pick(0,[["8","120° — 360° ning 1/3 qismi (360 : 120 = 3). 24 : 3 = 8."],["12","120 ni 10 ga bo'ldingiz — gradus bola soni emas. Avval 120° butunning qanday qismi ekanini toping."],["120","120 — gradus, bolalar soni emas. Jami atigi 24 bola!"],["6","Bu 90° li bo'lak (nok): 360 : 90 = 4, 24 : 4 = 6."]],function(){i3deg(1)}),g2:1,
 after:"<p>Qadamlar: 1) bo'lak butunning qanday qismi: <b>360 : gradus</b> (120° → 3 ga bo'linadi → 1/3); 2) jamini shunga bo'lamiz. Muhim belgilar: 180° = 1/2, 120° = 1/3, 90° = 1/4, 60° = 1/6.</p>",
 q:{t:"Doiraviy diagrammada 60° li bo'lak bor. Jami 42 ta kitob. Bu bo'lakda nechta kitob?",opts:["7","6","60","14"],ok:0,why:"360 : 60 = 6 → 1/6; 42 : 6 = 7.",hint:"60° butunning qanday qismi?",full:"360 : 60 = 6, demak bo'lak — 1/6 qism. 42 : 6 = 7 ta kitob. «6» — faqat maxraj, «60» — gradusning o'zi, «14» — 1/3 deb olish."},
 tn:"Transportir bilan haqiqiy diagrammadagi bo'laklarni o'lchatib, gradusdan qismga o'tkazing."},
{h:"Tuzoq: katta bo'lak — ko'p son emas",sum:"A sinf: 20 ning 1/2 = 10; B sinf: 40 ning 1/4 = 10. Teng!",a:"m06",
 start:function(){i3twopie(0);calc(['Qaysi sinfda matematikani tanlaganlar KO‘P?'])},fin:function(){i3twopie(1);y4msg('Teng: <b>10 tadan</b>')},
 html:"<p>Ikki sinfda so'rov o'tkazildi. A sinfda bo'lak katta ko'rinadi. Demak u yerda ko'pmi? Tanlang:</p>",
 btns:y4pick(2,[["A sinfda — bo'lagi katta","Bo'lak — qism, son emas. A sinfda jami 20 bola: 20 : 2 = 10."],["B sinfda — 2 marta ko'p","B sinfda bola ko'p, lekin qism kichik: 40 : 4 = 10."],["Teng: 10 tadan","20 : 2 = 10 va 40 : 4 = 10."],["A sinfda 2 marta ko'p","1/2 chorakdan 2 marta katta, lekin sinflar har xil kattalikda."]],function(){i3twopie(1)}),g2:1,
 after:"<p>Doiraviy diagramma faqat <b>ulush</b>ni ko'rsatadi. Ikki diagrammani taqqoslashdan oldin har birining <b>jami</b>sini bilish shart. Jami har xil bo'lsa — sonlarni hisoblab, keyin taqqoslaymiz.</p>",
 q:{t:"A maktabda 600 o'quvchining 1/3 qismi, B maktabda 900 o'quvchining 1/4 qismi to'garakka qatnaydi. Qayerda to'garakchilar ko'p?",opts:["B maktabda: 225 > 200","A maktabda: 1/3 > 1/4","Teng: 200 tadan","A maktabda: 600 < 900"],ok:0,why:"600 : 3 = 200, 900 : 4 = 225.",hint:"Har maktab uchun sonni alohida hisoblang.",full:"A: 600 : 3 = 200; B: 900 : 4 = 225. B maktabda 25 taga ko'p. «1/3 > 1/4» — ulushlarni taqqoslash, lekin butunlar har xil."},
 tn:"Bu xato gazeta va reklamalarda ham uchraydi. Bolalar o'zlari «aldaydigan» diagramma chizib, sinfdoshini sinab ko'rsin."},
{h:"Byudjet diagrammasi: qolgan qismni topish",sum:"1 200 000: ovqat 1/2, kommunal 1/4, kiyim 1/6, qolgani 100 000 (30°).",a:"m07",
 start:function(){startPh(I3P7)},fin:function(){S.ph=3;I3P7[3]()},
 html:"<p>Oilaning oylik daromadi doiraviy diagrammada. Har bo'lakni so'mga aylantiramiz. Bosing:</p>",btns:[phaser(I3P7)],
 after:"<p>Murakkab masalada har bir qismni <b>alohida</b> hisoblab, keyin butundan ayiramiz. Tekshirish: barcha bo'laklarning yig'indisi butunga teng bo'lishi kerak.</p>",
 q:{t:"Oila daromadi 900 000 so'm: 1/3 qismi ovqatga, 1/4 qismi ijaraga, qolgani tejashga. Tejashga qancha?",opts:["375 000 so'm","300 000 so'm","225 000 so'm","525 000 so'm"],ok:0,why:"900 000 : 3 = 300 000; 900 000 : 4 = 225 000; 900 000 − 525 000 = 375 000.",hint:"Avval ovqat va ijarani alohida toping.",full:"Ovqat: 900 000 : 3 = 300 000. Ijara: 900 000 : 4 = 225 000. Ikkalasi: 525 000. Tejash: 900 000 − 525 000 = 375 000 so'm. «525 000» — sarflangan pul, tejash emas."},
 tn:"Bolalar o'z oilaviy «xayoliy byudjet»ini tuzib, doiraviy diagrammaga chizsin (aniq summalar shart emas)."},
{h:"Qaysi diagramma qachon kerak?",sum:"Vaqt bo'yicha o'zgarish — chiziqli; butunning qismlari — doiraviy; taqqoslash — ustunli.",a:"m08",
 start:function(){i3kinds();calc(['Bir yil davomida har oy bolaning bo‘yi o‘lchandi. Qaysi diagramma mos?'])},fin:function(){i3kinds();y4msg('Bo‘yning o‘zgarishi — <b>chiziqli</b> diagramma')},
 html:"<p>Har diagrammaning o'z vazifasi bor. <i>«Bir yil davomida har oy bolaning bo'yi o'lchandi.»</i> Qaysi biri eng mos?</p>",
 btns:y4pick(0,[["Chiziqli","Bo'y vaqt o'tishi bilan o'zgaradi — chiziq o'sishni yaxshi ko'rsatadi."],["Doiraviy","Doira butunning qismlari uchun. Oylardagi bo'y — bir butunning qismlari emas."],["Ustunli","Mumkin, lekin o'zgarishni (o'sish tezligini) chiziq yaxshiroq ko'rsatadi."]]),
 after:"<p><b>Chiziqli</b> — vaqt bo'yicha o'zgarish (harorat, bo'y, tejash). <b>Doiraviy</b> — butun qanday qismlarga bo'lingani (byudjet, so'rov). <b>Ustunli</b> — bir necha narsani taqqoslash (sinflardagi bolalar soni).</p>",
 q:{t:"Sinf o'quvchilarining qancha qismi piyoda, qancha qismi avtobusda, qancha qismi velosipedda kelishini ko'rsatish kerak. Qaysi diagramma eng mos?",opts:["Doiraviy","Chiziqli","Hech qaysi — faqat jadval","Ikkita chiziqli"],ok:0,why:"Butun (sinf) qismlarga bo'linadi — doiraviy.",hint:"Gap butunning qismlari haqidami yoki vaqt bo'yicha o'zgarishmi?",full:"Barcha o'quvchilar — butun, ular uchta qismga bo'linadi. Bu doiraviy diagrammaning vazifasi. Chiziqli diagramma vaqt bo'yicha o'zgarish uchun."},
 tn:"Gazeta yoki darslikdan diagrammalar kesib olib keling — bolalar ularni uch guruhga ajratadi."},
{h:"Bilasizmi? Diagrammalar tarixi",sum:"Pleyfer: 1786 — chiziqli va ustunli, 1801 — doiraviy diagramma. 1858 — Naytingeyl.",a:"m09",
 start:function(){startPh(I3P9)},fin:function(){S.ph=2;I3P9[2]()},
 html:"<p>Diagrammalar har doim bo'lmagan — ularni kimdir o'ylab topgan. Bosib ko'ring:</p>",btns:[phaser(I3P9)],
 after:"<p>🇬🇧 Florens Naytingeyl — hamshira va statistik. U urushda askarlarning ko'pi jarohatdan emas, <b>kasalxonadagi kasalliklardan</b> o'layotganini doiraviy diagrammaga o'xshash chizma bilan ko'rsatdi va kasalxonalarda tozalikka erishdi. Diagramma odamlar hayotini saqlab qolgan!</p>",
 tn:"Bolalarga savol: nega jadvalga qaraganda diagrammani tez tushunamiz? (Ko'z shaklni sondan tez taqqoslaydi.)"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>Chiziqli</b> diagramma — vaqt bo'yicha o'zgarish. Tik chiziq — katta o'zgarish; kesishish — tenglik.</li><li>O'qishdan oldin: birlik va o'qdagi <b>qadam</b>; chiziqlar orasidagi nuqta — qadamning bir qismi.</li><li><b>Doiraviy</b> diagramma — butunning qismlari. Doira = 360°: 180° = 1/2, 120° = 1/3, 90° = 1/4, 60° = 1/6.</li><li>Qism soni = jami : maxraj; jami = qism soni · maxraj.</li><li>Ikki doiraviy diagrammani taqqoslashdan oldin <b>jamilarini</b> bilib oling.</li><li>Qolgan qism = butun − topilgan qismlar.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring. Uyga: oila a'zolaridan sevimli rangini so'rab, doiraviy diagramma chizish."}
];
var PROBS=[
{t:"Doiraviy diagrammada yarim doira «futbol». Sinfda 30 bola. Futbolni nechta bola tanlagan?",o:["15","30","2","60"],k:0,s:"30 : 2 = 15."},
{t:"Doiraviy diagrammada chorak (1/4) qism 9 bolaga teng. Jami nechta bola?",o:["36","13","27","18"],k:0,s:"9 · 4 = 36."},
{t:"Doiraviy diagrammada 90° li bo'lak butunning qanday qismi?",o:["1/4","1/9","1/3","1/2"],k:0,s:"360 : 90 = 4."},
{t:"Doiraviy diagrammada 60° li bo'lak. Jami 48 ta kitob. Bu bo'lakda nechta kitob?",o:["8","6","12","60"],k:0,s:"360 : 60 = 6; 48 : 6 = 8."},
{t:"Harorat: Du 8°, Se 12°, Ch 9°, Pa 15°. Qaysi ketma-ket ikki kun orasida harorat eng ko'p ko'tarilgan?",o:["Ch – Pa","Du – Se","Se – Ch","Du – Se va Ch – Pa teng"],k:0,s:"Du→Se +4, Ch→Pa +6."},
{t:"Vertikal o'qda 0, 10, 20, 30 yozilgan. Nuqta 20 bilan 30 ning roppa-rosa o'rtasida. Qiymat?",o:["25","21","20","30"],k:0,s:"Qadam 10, yarmi 5: 20 + 5."},
{t:"Chiziqli diagramma: dushanba 30, seshanba 45, chorshanba 40 ta kitob sotilgan. Seshanbadan chorshanbaga qanday o'zgargan?",o:["5 taga kamaygan","5 taga ko'paygan","15 taga ko'paygan","40 taga kamaygan"],k:0,s:"45 → 40: −5."},
{t:"36 boladan 1/2 qismi olma, 1/3 qismi nok, qolgani uzum yoqtiradi. Uzumni nechta bola yoqtiradi?",o:["6","12","18","30"],k:0,s:"18 + 12 = 30; 36 − 30 = 6."},
{t:"Doiraviy diagrammada: olma 150°, nok 90°, uzum — qolgan qism. Uzum necha gradus?",o:["120°","60°","240°","210°"],k:0,s:"360 − 150 − 90 = 120."},
{t:"Doiraviy diagrammada uch bo'lak: 180°, 120° va qolgani. Qolgan bo'lak butunning qanday qismi?",o:["1/6","1/5","1/3","1/60"],k:0,s:"360 − 300 = 60°; 360 : 60 = 6."},
{t:"A sinfda 24 bola, yarmi shaxmat o'ynaydi. B sinfda 36 bola, uchdan biri shaxmat o'ynaydi. Qaysi sinfda shaxmatchilar ko'p?",o:["Teng: 12 tadan","A sinfda, chunki 1/2 > 1/3","B sinfda, chunki 36 > 24","A sinfda 2 marta ko'p"],k:0,s:"24 : 2 = 12; 36 : 3 = 12."},
{t:"Chiziqli diagramma: har oy oldingisidan 15 taga ko'p sotilgan, yanvarda 40 ta. Aprelda nechta sotilgan?",o:["85","100","55","60"],k:0,s:"40, 55, 70, 85."},
{t:"80 bola: 1/2 qismi avtobusda, 1/4 qismi piyoda, 1/5 qismi velosipedda, qolgani mashinada keladi. Mashinada nechta?",o:["4","16","20","5"],k:0,s:"40 + 20 + 16 = 76; 80 − 76 = 4."},
{t:"Doiraviy diagramma ikki bo'lakdan iborat, biri ikkinchisidan 2 marta katta. Kattasi necha gradus?",o:["240°","180°","120°","270°"],k:0,s:"3 ta teng qism: 360 : 3 = 120; katta = 240."},
{t:"Daromad diagrammasida ovqat bo'lagi 120°. Ovqatga 400 000 so'm ketgan bo'lsa, butun daromad qancha?",o:["1 200 000 so'm","1 600 000 so'm","800 000 so'm","4 800 000 so'm"],k:0,s:"120° = 1/3; 400 000 · 3."},
{t:"Ali 10 000 so'mdan boshlab har hafta 5 000 so'm, Vali 20 000 so'mdan boshlab har hafta 3 000 so'm tejaydi. Necha haftadan keyin ularning puli teng bo'ladi?",o:["5 haftadan keyin","2 haftadan keyin","10 haftadan keyin","Hech qachon"],k:0,s:"Farq 10 000, har hafta 2 000 ga qisqaradi: 10 000 : 2 000 = 5."},
{t:"Doiraviy diagrammada qizil bo'lak 72°. Bu butunning qanday qismi?",o:["1/5","1/72","1/4","1/6"],k:0,s:"360 : 72 = 5."},
{t:"Sinfda 24 bola. 6 bola tanlagan javob doiraviy diagrammada necha gradusli bo'lak bo'ladi?",o:["90°","60°","6°","144°"],k:0,s:"6 = 24 ning 1/4 qismi; 360 : 4 = 90."},
{t:"Harorat: soat 6 da 4°, soat 9 da 10°, soat 12 da 16°, soat 15 da 13°. Soat 9 dan 15 gacha harorat qanday o'zgargan?",o:["3° ga ko'tarilgan","6° ga ko'tarilgan","3° ga tushgan","9° ga ko'tarilgan"],k:0,s:"10° → 13°: +3 (oraliqda 16° ga chiqib, keyin tushgan)."},
{t:"120 boladan 1/3 qismi raqsga, 1/4 qismi rasmga, 1/6 qismi shaxmatga, qolganlari sportga qatnaydi. Sportga nechta bola qatnaydi?",o:["30","50","90","20"],k:0,s:"40 + 30 + 20 = 90; 120 − 90 = 30."}
];
var PREP_DATA={teach:["Chiziqli diagramma: nuqtalar, chiziq, o'sish va kamayish, eng tik bo'lak.","Shkala qadami va chiziqlar orasidagi qiymatni o'qish.","Ikki chiziq: kesishish — tenglik.","Doiraviy diagramma: butun = 360°, qism soni = jami : maxraj.","Ikki doiraviy diagrammani taqqoslash tuzog'i; qolgan qismni topish."],
 mist:["Kataklarni birlab sanaydi, shkala qadamini e'tiborsiz qoldiradi.","Gradusni bolalar soni deb oladi (120° → 120 bola).","Katta bo'lakni katta son deb o'ylaydi (jamini e'tiborga olmaydi).","Qolgan qism o'rniga sarflangan qismni javob qiladi.","Diagramma turini vazifaga mos tanlamaydi."],
 need:["Katakli doska yoki qog'oz, rangli bo'r.","Qog'oz doiralar (buklash uchun), transportir."],
 board:["Doira = <span class='w2'>360°</span>: 180° = 1/2, 120° = 1/3, 90° = 1/4, 60° = 1/6.","<span class='w2'>qism soni = jami : maxraj</span>.","Ikki chiziq kesishgan joy — <span class='w2'>teng</span>.","1 200 000 − 600 000 − 300 000 − 200 000 = <span class='w2'>100 000</span>."]};
