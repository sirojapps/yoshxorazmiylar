var CODE='2B4',TITLE='2-sinf · Qo‘shish va ayirish komponentlari';
function msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// bar model: a + b = s; hide: 'a'|'b'|'s'
function bar(a,b,o){o=o||{};clear();var g=S.g,s=a+b,f=300/s,x=30,y=56;
 E('rect',{x:x,y:y,width:a*f,height:36,fill:o.hide==='a'?'#fff7ea':C.b,stroke:C.line,'stroke-width':1.5,'stroke-dasharray':o.hide==='a'?'4 3':''},g);
 E('rect',{x:x+a*f,y:y,width:b*f,height:36,fill:o.hide==='b'?'#fff7ea':C.c,stroke:C.line,'stroke-width':1.5,'stroke-dasharray':o.hide==='b'?'4 3':''},g);
 T(g,x+a*f/2,y+24,o.hide==='a'?'?':String(a),{'font-size':15,'font-weight':800,fill:o.hide==='a'?C.bad:'#fff'});T(g,x+a*f+b*f/2,y+24,o.hide==='b'?'?':String(b),{'font-size':15,'font-weight':800,fill:o.hide==='b'?C.bad:'#fff'});
 E('path',{d:'M'+x+' '+(y-8)+' L'+x+' '+(y-16)+' L'+(x+300)+' '+(y-16)+' L'+(x+300)+' '+(y-8),fill:'none',stroke:'#5b6b7b','stroke-width':1.5},g);T(g,180,y-22,o.hide==='s'?'?':String(s),{'font-size':15,'font-weight':800,fill:o.hide==='s'?C.bad:'#1d2b3a'});
 if(o.la){T(g,x+a*f/2,y+56,o.la[0],{'font-size':12,'font-weight':800,fill:C.blue});T(g,x+a*f+b*f/2,y+56,o.la[1],{'font-size':12,'font-weight':800,fill:'#c0507a'})}
 if(o.note)T(g,180,160,o.note,{'font-size':14,'font-weight':800,fill:o.nc||C.ok})}
function names(k){clear();var g=S.g;function row(y,parts,labs,cols){var xs=[70,125,180,235,290];parts.forEach(function(p,i){T(g,xs[i],y,p,{'font-size':26,'font-weight':800,fill:i%2?'#5b6b7b':'#1d2b3a'})});labs.forEach(function(l,i){if(l)T(g,xs[i*2],y+24,l,{'font-size':11,'font-weight':800,fill:cols[i]})})}
 if(k===0||k===2)row(k===2?42:70,['35','+','24','=','59'],['qo‘shiluvchi','qo‘shiluvchi','yig‘indi'],[C.blue,'#c0507a',C.ok]);
 if(k>=1)row(k===2?118:70,['59','−','24','=','35'],['kamayuvchi','ayriluvchi','ayirma'],[C.blue,'#c0507a',C.ok])}
var P1=[function(){names(0);msg('35 + 24 = 59. Har bir sonning <b>nomi</b> bor')},function(){names(1);msg('59 − 24 = 35: kamayuvchi, ayriluvchi, ayirma')},function(){names(2);msg('Ikkala tenglikda ham <b>o‘sha uchta son</b>: 35, 24, 59')}];
var P3=[function(){bar(28,17,{hide:'a',la:['?','17'],note:''});msg('□ + 17 = 45. Noma‘lum qo‘shiluvchi qanday topiladi?')},function(){bar(28,17,{hide:'a',la:['45 − 17','17'],note:'butun − ma‘lum qism'});msg('Butundan ma‘lum qismni ayiramiz: 45 − 17')},function(){bar(28,17,{la:['28','17'],note:'□ = 28.  Tekshirish: 28 + 17 = 45 ✓'});msg('□ = <b>28</b>')}];
var P4=[function(){bar(26,38,{hide:'s',la:['ayirma 26','ayriluvchi 38']});msg('□ − 38 = 26. Kamayuvchi — bu <b>butun</b>')},function(){bar(26,38,{la:['26','38'],note:'□ = 26 + 38 = 64'});msg('Kamayuvchi = ayirma + ayriluvchi = <b>64</b>')}];
var P5=[function(){bar(45,27,{hide:'b',la:['ayirma 45','?']});msg('72 − □ = 45. Ayriluvchi — kesib olingan bo‘lak')},function(){bar(45,27,{la:['45','27'],note:'□ = 72 − 45 = 27'});msg('Ayriluvchi = kamayuvchi − ayirma = <b>27</b>')}];
var STEPS=[
{h:"Sonlarning nomlari",sum:"35 + 24 = 59: qo'shiluvchilar va yig'indi. 59 − 24 = 35: kamayuvchi, ayriluvchi, ayirma.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Har bir amalda sonlarning o'z <b>nomi</b> bor — xuddi oilada ota, ona, bola kabi. Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p><b>Qo'shiluvchi + qo'shiluvchi = yig'indi.</b><br><b>Kamayuvchi − ayriluvchi = ayirma.</b><br>Qo'shish va ayirish — «bir oila»: 35, 24, 59 sonlaridan ikkala tenglikni ham tuzish mumkin.</p>",
 q:{t:"72 − 45 = 27 tenglikda 45 nima deb ataladi?",opts:["kamayuvchi","ayirma","ayriluvchi","yig'indi"],ok:2,why:"Ayiriladigan son — ayriluvchi.",hint:"Qaysi son kamaytiryapti — undan ayirilyaptimi yoki u ayirilyaptimi?",full:"72 — kamayuvchi (undan ayiramiz, u kamayadi), 45 — ayriluvchi (uni ayiramiz), 27 — ayirma (natija)."},
 tn:"Nomlarni karta qilib, doskadagi tenglik ustiga bolalar o'zi yopishtirsin. «Kamayuvchi — kamayadigan son» deb mantiqini ayting."},
{h:"Bir oila — to'rtta tenglik",sum:"28, 17, 45 → 28 + 17 = 45, 17 + 28 = 45, 45 − 17 = 28, 45 − 28 = 17.",a:"m02",
 start:function(){fam(0)},fin:function(){STEPS[1]._f={1:1,2:1,3:1,4:1};fam(5)},
 html:"<p>28, 17 va 45 sonlari — bitta «oila». Ulardan nechta to'g'ri tenglik tuzish mumkin? Tugmalarni bosing:</p>",
 btns:[["28 + 17",function(c,done){fam(1);mvK(done,4)}],["17 + 28",function(c,done){fam(2);mvK(done,4)},'u'],["45 − 17",function(c,done){fam(3);mvK(done,4)}],["45 − 28",function(c,done){fam(4);mvK(done,4)},'u']],g2:1,
 after:"<p>To'rtta tenglik! <b>Yig'indi — eng katta son</b> (butun), qo'shiluvchilar — uning bo'laklari. Butundan bir bo'lakni ayirsak — ikkinchi bo'lak qoladi.</p>",
 q:{t:"Qaysi tenglik 36, 19, 55 oilasiga kirmaydi?",opts:["36 + 19 = 55","55 − 36 = 19","19 − 36 = 55","55 − 19 = 36"],ok:2,why:"19 dan 36 ni (kichikdan kattani) ayirib bo'lmaydi; butun — 55.",hint:"Qaysi son butun? Ayirishda doim butundan boshlanadi.",full:"Butun — 55. Qolgan uchtasi to'g'ri. «19 − 36 = 55» — noto'g'ri: kichik sondan katta sonni ayirib bo'lmaydi."},
 tn:"«Uchburchak kartochka» (fact family triangle): uchida butun, burchaklarida bo'laklar. Bitta burchakni yopib, so'rang."},
{h:"Noma'lum qo'shiluvchi",sum:"□ + 17 = 45 → □ = 45 − 17 = 28. Yig'indidan ma'lum qo'shiluvchini ayiramiz.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Qutida bir nechta qalam bor edi. 17 ta qo'shilgach, 45 ta bo'ldi: <b>□ + 17 = 45</b>. Avval qutida nechta edi?</p>",
 btns:[phaser(P3)],
 after:"<p>Qoida: <b>noma'lum qo'shiluvchini topish uchun yig'indidan ma'lum qo'shiluvchini ayiramiz.</b> 45 − 17 = 28. Tekshirish: 28 + 17 = 45 ✓.</p>",
 q:{t:"□ + 26 = 63. □ = ?",opts:["37","89","47","43"],ok:0,why:"63 − 26 = 37. Tekshirish: 37 + 26 = 63.",hint:"Yig'indi 63, ma'lum qo'shiluvchi 26.",full:"□ = 63 − 26 = 37 (13 − 6 = 7, 5 − 2 = 3). «89» — qo'shib yuborilgan: noma'lumni topishda yig'indidan ayiriladi."},
 tn:"Bolalarning eng ko'p xatosi — tenglikdagi «+» ni ko'rib, sonlarni qo'shib yuborish. Chiziqli modelni chizdiring."},
{h:"Noma'lum kamayuvchi",sum:"□ − 38 = 26 → □ = 26 + 38 = 64. Ayirmaga ayriluvchini qo'shamiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=1;P4[1]()},
 html:"<p>Novvoy bir nechta non yopdi. 38 tasi sotilgach, 26 ta qoldi: <b>□ − 38 = 26</b>. Hammasi nechta edi?</p>",
 btns:[phaser(P4)],
 after:"<p>Kamayuvchi — <b>butun</b>: sotilgani va qolgani birga. Qoida: <b>noma'lum kamayuvchini topish uchun ayirmaga ayriluvchini qo'shamiz.</b> 26 + 38 = 64. Tekshirish: 64 − 38 = 26 ✓.</p>",
 q:{t:"□ − 29 = 45. □ = ?",opts:["16","74","64","84"],ok:1,why:"45 + 29 = 74. Tekshirish: 74 − 29 = 45.",hint:"Kamayuvchi butun — ayirma va ayriluvchini birlashtiring.",full:"□ = 45 + 29 = 74. «16» — ayirib yuborilgan (45 − 29), lekin kamayuvchi doim ayirmadan katta bo'ladi."},
 tn:"Tekshirish savoli: «Kamayuvchi ayirmadan katta bo'lishi kerakmi?» — ha. Bu javobni tez tekshirish yo'li."},
{h:"Noma'lum ayriluvchi",sum:"72 − □ = 45 → □ = 72 − 45 = 27. Kamayuvchidan ayirmani ayiramiz.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Savatda 72 ta olma bor edi. Bir nechtasi olingach, 45 ta qoldi: <b>72 − □ = 45</b>. Nechta olma olindi?</p>",
 btns:[phaser(P5)],
 after:"<p>Qoida: <b>noma'lum ayriluvchini topish uchun kamayuvchidan ayirmani ayiramiz.</b> 72 − 45 = 27. Tekshirish: 72 − 27 = 45 ✓.</p>",
 q:{t:"Qaysi qoida to'g'ri?",opts:["Noma'lum ayriluvchi = kamayuvchi + ayirma","Noma'lum kamayuvchi = ayirma − ayriluvchi","Noma'lum qo'shiluvchi = yig'indi + qo'shiluvchi","Noma'lum ayriluvchi = kamayuvchi − ayirma"],ok:3,why:"72 − 45 = 27: kamayuvchidan ayirma ayiriladi.",hint:"Hozirgi misolda nima qildik: 72 va 45 bilan?",full:"Uchta qoida: qo'shiluvchi = yig'indi − qo'shiluvchi; kamayuvchi = ayirma + ayriluvchi; ayriluvchi = kamayuvchi − ayirma."},
 tn:"Uchala qoidani bitta chiziqli model bilan tushuntiring: butun noma'lum bo'lsa — qo'shamiz, bo'lak noma'lum bo'lsa — ayiramiz."},
{h:"Komponent o'zgarsa, natija qanday o'zgaradi?",sum:"Qo'shiluvchi +10 → yig'indi +10. Kamayuvchi +10 → ayirma +10. Ayriluvchi +6 → ayirma −6.",a:"m06",
 start:function(){chg(0)},fin:function(){chg(3)},
 html:"<p>Asos: <b>45 − 20 = 25</b> va <b>30 + 15 = 45</b>. Bitta sonni o'zgartirsak, natija nima bo'ladi? Bosing:</p>",
 btns:[["qo'shiluvchi +10",function(c,done){chg(1);mvK(done,3)}],["kamayuvchi +10",function(c,done){chg(2);mvK(done,3)},'u'],["ayriluvchi +6",function(c,done){chg(3);mvK(done,3)}]],g3:1,
 after:"<p>Qo'shiluvchi yoki kamayuvchi <b>oshsa</b> — natija ham shunchaga <b>oshadi</b>. Lekin ayriluvchi oshsa — ayirma <b>kamayadi</b>: ko'proq olib qo'ysak, kamroq qoladi!</p>",
 q:{t:"Ayriluvchini 6 ga oshirsak, ayirma qanday o'zgaradi?",opts:["6 ga kamayadi","6 ga oshadi","o'zgarmaydi","12 ga kamayadi"],ok:0,why:"45 − 26 = 19, 45 − 20 = 25: 6 ga kam.",hint:"Savatdan ko'proq olma olsangiz, qolgani ko'payadimi yoki kamayadimi?",full:"45 − 20 = 25, 45 − 26 = 19. 25 − 19 = 6. Ayriluvchi 6 ga oshdi — ayirma 6 ga kamaydi."},
 tn:"Bu — algebraik fikrlashning boshlanishi. «Hisoblamasdan ayting» deb so'rang: 52 − 18 = 34 bo'lsa, 52 − 28 = ?"},
{h:"Olimpiada masalasi",sum:"Kamayuvchi 80, ayirma ayriluvchidan 12 ga katta: ayriluvchi + ayirma = 80 → ayriluvchi 34, ayirma 46.",a:"m07",
 start:function(){ol(0)},fin:function(){ol(2)},
 html:"<p><i>«Kamayuvchi 80 ga teng. Ayirma ayriluvchidan 12 ta katta. Ayriluvchini toping.»</i> Kalit: ayriluvchi + ayirma = kamayuvchi!</p>",
 btns:[["1) Model",function(c,done){ol(1);mvK(done,2)}],["2) Yechim",function(c,done){ol(2);mvK(done,2)},'u']],
 after:"<p>Ayriluvchi + ayirma = 80. Ayirma 12 ga ko'p: 80 − 12 = 68 — bu ikkita teng bo'lak, 68 = 34 + 34. Ayriluvchi = <b>34</b>, ayirma = 46. Tekshirish: 80 − 34 = 46, 46 − 34 = 12 ✓.</p>",
 q:{t:"Yig'indi 50. Bir qo'shiluvchi ikkinchisidan 10 ta katta. Kichik qo'shiluvchi nechaga teng?",opts:["25","40","20","30"],ok:2,why:"50 − 10 = 40, 40 = 20 + 20. Sonlar 20 va 30.",hint:"Ortiqcha 10 ni olib tashlang — qolgani ikkita teng bo'lak.",full:"50 − 10 = 40. Ikkita teng bo'lak: 20 va 20. Kichigi 20, kattasi 20 + 10 = 30. Tekshirish: 20 + 30 = 50 ✓."},
 tn:"Singapur «bar model» — bunday masalalarning standart vositasi. Bolalar chiziqlarni o'zi chizsin."},
{h:"Harfli ifodalar",sum:"a + b = c bo'lsa: c − a = b, c − b = a. Harflar ham sonlar kabi ishlaydi.",a:"m08",
 start:function(){lt(0)},fin:function(){lt(1)},
 html:"<p>Matematiklar sonlar o'rniga ba'zan <b>harflar</b> yozadi. Agar <b>a + b = c</b> bo'lsa, a ni qanday topamiz?</p>",
 btns:[["Ko'rsat",function(c,done){lt(1);done()}]],
 after:"<p>Xuddi sonlardagidek: <b>a = c − b</b>, <b>b = c − a</b>. Masalan, Alida m ta konfet bor, u n tasini Valiga, k tasini Soliga berdi. Unda <b>m − (n + k)</b> ta qoldi.</p>",
 q:{t:"Savatda a ta olma bor edi. Undan b ta olindi. Qancha qoldi?",opts:["b − a","a − b","a + b","b"],ok:1,why:"Butun — a, olingani — b: a − b.",hint:"Qaysi son butun (kamayuvchi)?",full:"Kamayuvchi a (bor edi), ayriluvchi b (olindi). Qoldi: a − b. «b − a» — tartib almashgan."},
 tn:"Harfli ifoda — 2-sinf darsligidagi mavzu. Harf o'rniga turli sonlar qo'yib, tekshirib ko'rishsin."},
{h:"Bilasizmi?",sum:"Al-Xorazmiy «al-jabr» — tenglikdan noma'lumni topish san'ati.",a:"m09",
 start:function(){clear();T(S.g,180,70,'□ + 17 = 45',{'font-size':28,'font-weight':800,fill:C.blue});T(S.g,180,120,'al-jabr ⟶ algebra',{'font-size':18,'font-weight':800,fill:C.ok});msg('Muhammad al-Xorazmiy, IX asr')},fin:function(){STEPS[8].start()},
 html:"<p>📜 Bugun biz noma'lum sonni tenglikdan topdik. Buni IX asrda yashagan vatandoshimiz <b>Muhammad al-Xorazmiy</b> ilm sifatida yozib qoldirgan. Uning kitobidagi «<b>al-jabr</b>» so'zidan butun dunyoda ishlatiladigan «<b>algebra</b>» so'zi kelib chiqqan.</p><p>Demak, siz bugun kichkina algebra yechdingiz! 🎉</p>",
 tn:"Xiva (Xorazm) — al-Xorazmiy vatani; Xivada uning haykali bor. Bolalarga xaritada ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.ph=2;P1[2]()},fin:function(){S.ph=2;P1[2]()},
 html:"<div class='memo'><ul><li><b>qo'shiluvchi + qo'shiluvchi = yig'indi</b></li><li><b>kamayuvchi − ayriluvchi = ayirma</b></li><li>Noma'lum qo'shiluvchi = yig'indi − qo'shiluvchi.</li><li>Noma'lum kamayuvchi = ayirma <b>+</b> ayriluvchi.</li><li>Noma'lum ayriluvchi = kamayuvchi − ayirma.</li><li>Ayriluvchi oshsa — ayirma <b>kamayadi</b>.</li><li>Doim tekshiring: noma'lum o'rniga javobni qo'yib.</li></ul></div>",
 tn:"Uyga vazifa: oiladagi biror voqeadan «noma'lumli» masala tuzib kelish."}
];
function fam(k){clear();var g=S.g;E('path',{d:'M180 14 L120 100 L240 100 Z',fill:'#fff7ea',stroke:C.line,'stroke-width':2},g);T(g,180,46,'45',{'font-size':18,'font-weight':800,fill:C.ok});T(g,146,92,'28',{'font-size':16,'font-weight':800,fill:C.blue});T(g,214,92,'17',{'font-size':16,'font-weight':800,fill:'#c0507a'});
 var c=STEPS[1];if(k===0)c._f={};else if(k<5)(c._f=c._f||{})[k]=1;var L=['28 + 17 = 45','17 + 28 = 45','45 − 17 = 28','45 − 28 = 17'],F=c._f||{};
 for(var i=0;i<4;i++)if(F[i+1])T(g,i<2?80:280,128+(i%2)*24,L[i],{'font-size':14,'font-weight':800,fill:i<2?C.blue:C.bad});msg('Tuzilgan tengliklar: '+Object.keys(F).length+' / 4')}
function chg(k){clear();var g=S.g,rows=[['30 + 15 = 45','40 + 15 = 55','+10 → +10',C.ok],['45 − 20 = 25','55 − 20 = 35','+10 → +10',C.ok],['45 − 20 = 25','45 − 26 = 19','+6 → −6',C.bad]];
 if(!k){T(g,180,70,'45 − 20 = 25',{'font-size':24,'font-weight':800});T(g,180,110,'30 + 15 = 45',{'font-size':24,'font-weight':800});msg('Tugmani bosing');return}
 var r=rows[k-1];T(g,180,44,r[0],{'font-size':22,'font-weight':800,fill:'#5b6b7b'});T(g,180,96,r[1],{'font-size':26,'font-weight':800,fill:r[3]});T(g,180,142,r[2],{'font-size':18,'font-weight':800,fill:r[3]});msg(['','Qo‘shiluvchi 10 ga oshdi — yig‘indi ham 10 ga oshdi','Kamayuvchi 10 ga oshdi — ayirma ham 10 ga oshdi','Ayriluvchi 6 ga oshdi — ayirma <b>6 ga kamaydi</b>'][k])}
function ol(k){clear();var g=S.g,f=3.4,x=40;T(g,x+30,34,'ayriluvchi',{'font-size':11,'text-anchor':'start',fill:C.blue});
 E('rect',{x:x+30,y:40,width:34*f,height:28,fill:C.b,stroke:C.line,'stroke-width':1.5},g);T(g,x+30+17*f,59,k>=2?'34':'?',{'font-size':13,'font-weight':800,fill:'#fff'});
 E('rect',{x:x+30,y:80,width:34*f,height:28,fill:C.c,stroke:C.line,'stroke-width':1.5},g);E('rect',{x:x+30+34*f,y:80,width:12*f,height:28,fill:k>=1?C.hi:C.c,stroke:C.line,'stroke-width':1.5},g);T(g,x+30+40*f,99,'12',{'font-size':12,'font-weight':800});T(g,x+30+17*f,99,k>=2?'34':'?',{'font-size':13,'font-weight':800,fill:'#fff'});
 T(g,x+30,128,'ayirma',{'font-size':11,'text-anchor':'start',fill:'#c0507a'});T(g,300,82,'} 80',{'font-size':30,fill:'#1d2b3a'});
 if(k>=1)T(g,180,152,k>=2?'80 − 12 = 68, 68 = 34 + 34 → ayriluvchi 34':'ayriluvchi + ayirma = 80',{'font-size':13,'font-weight':800,fill:C.ok});msg(k>=2?'Ayriluvchi = <b>34</b>, ayirma = 46':'Ikkala chiziq birga — kamayuvchi 80')}
function lt(k){clear();var g=S.g;T(g,180,50,'a + b = c',{'font-size':30,'font-weight':800,fill:C.blue});if(k){T(g,180,100,'a = c − b',{'font-size':24,'font-weight':800,fill:C.ok});T(g,180,140,'b = c − a',{'font-size':24,'font-weight':800,fill:C.ok})}msg(k?'Masalan: 28 + 17 = 45 → 28 = 45 − 17':'a ni qanday topamiz?')}
var PROBS=[
{t:"72 − 45 = 27 tenglikda 72 nima deb ataladi?",o:["kamayuvchi","ayriluvchi","ayirma","yig'indi"],k:0,s:"Undan ayiriladigan son — kamayuvchi."},
{t:"35 + 24 = 59 tenglikda 59 nima?",o:["yig'indi","qo'shiluvchi","ayirma","kamayuvchi"],k:0,s:"Qo'shish natijasi — yig'indi."},
{t:"□ + 26 = 63. □ = ?",o:["37","89","47","43"],k:0,s:"63 − 26 = 37."},
{t:"□ − 29 = 45. □ = ?",o:["74","16","64","84"],k:0,s:"45 + 29 = 74."},
{t:"72 − □ = 45. □ = ?",o:["27","117","37","33"],k:0,s:"72 − 45 = 27."},
{t:"Kamayuvchi 80. Ayirma ayriluvchidan 12 ta katta. Ayriluvchini toping.",o:["34","46","68","40"],k:0,s:"80 − 12 = 68, 68 = 34 + 34."},
{t:"Ayriluvchini 6 ga oshirsak, ayirma qanday o'zgaradi?",o:["6 ga kamayadi","6 ga oshadi","o'zgarmaydi","12 ga oshadi"],k:0,s:"Ko'proq ayirsak, kamroq qoladi."},
{t:"Bir qo'shiluvchini 10 ga oshirsak, yig'indi qanday o'zgaradi?",o:["10 ga oshadi","10 ga kamayadi","o'zgarmaydi","20 ga oshadi"],k:0,s:"30 + 15 = 45, 40 + 15 = 55."},
{t:"52 − 18 = 34 bo'lsa, 52 − 28 = ?",o:["24","44","34","14"],k:0,s:"Ayriluvchi 10 ga oshdi — ayirma 10 ga kamaydi."},
{t:"Savatda a ta olma bor edi, b tasi olindi. Qancha qoldi?",o:["a − b","b − a","a + b","b"],k:0,s:"Butun a, olingani b."},
{t:"Alida m ta konfet bor edi. U n tasini Valiga, k tasini Soliga berdi. Alida nechta qoldi?",o:["m − (n + k)","m + n − k","(n + k) − m","m − n + k"],k:0,s:"Bergan jami n + k, uni m dan ayiramiz."},
{t:"Yig'indi 50. Bir qo'shiluvchi ikkinchisidan 10 ta katta. Katta qo'shiluvchi?",o:["30","20","40","25"],k:0,s:"50 − 10 = 40, 20 + 20; kattasi 30."},
{t:"Qaysi tenglik 36, 19, 55 oilasiga kirmaydi?",o:["19 − 36 = 55","36 + 19 = 55","55 − 36 = 19","55 − 19 = 36"],k:0,s:"Kichikdan katta ayirilmaydi."},
{t:"Ayirma 25, ayriluvchi 38. Kamayuvchi nechaga teng?",o:["63","13","53","73"],k:0,s:"25 + 38 = 63."},
{t:"Novvoy non yopdi. 38 tasi sotildi, 26 tasi qoldi. Nechta non yopilgan edi?",o:["64","12","54","74"],k:0,s:"26 + 38 = 64."},
{t:"Kamayuvchi va ayriluvchi teng bo'lsa, ayirma nechaga teng?",o:["0","1","kamayuvchiga","ikki baravariga"],k:0,s:"Masalan 47 − 47 = 0."},
{t:"Kamayuvchi, ayriluvchi va ayirma yig'indisi 90. Kamayuvchi nechaga teng?",o:["45","30","90","60"],k:0,s:"Ayriluvchi + ayirma = kamayuvchi, demak 90 = 2 ta kamayuvchi: 45."},
{t:"Bir son 47. U boshqa sondan 19 ta kichik. Boshqa son nechaga teng?",o:["66","28","56","38"],k:0,s:"47 + 19 = 66."},
{t:"Kamayuvchini 10 ga, ayriluvchini ham 10 ga oshirsak, ayirma qanday o'zgaradi?",o:["o'zgarmaydi","10 ga oshadi","20 ga oshadi","10 ga kamayadi"],k:0,s:"55 − 30 = 45 − 20 = 25."},
{t:"Qaysi qoida to'g'ri?",o:["Noma'lum ayriluvchi = kamayuvchi − ayirma","Noma'lum kamayuvchi = ayirma − ayriluvchi","Noma'lum qo'shiluvchi = yig'indi + qo'shiluvchi","Noma'lum ayriluvchi = kamayuvchi + ayirma"],k:0,s:"72 − 45 = 27."}
];
function PRACT_STAGE(){S.ph=2;P1[2]()}
var PREP_DATA={teach:["Komponentlar nomlari: qo'shiluvchi, yig'indi; kamayuvchi, ayriluvchi, ayirma.","Bir oila — to'rtta tenglik (28 + 17 = 45 …).","Noma'lum qo'shiluvchi, kamayuvchi, ayriluvchini topish qoidalari.","Komponent o'zgarsa natija o'zgarishi; harfli ifodalar."],
 mist:["Ayriluvchi va kamayuvchi nomlarini aralashtiradi.","□ + 26 = 63 da sonlarni qo'shib yuboradi (89).","Noma'lum kamayuvchini topishda ayiradi (45 − 29 = 16).","Ayriluvchi oshsa ayirma ham oshadi deb o'ylaydi."],
 need:["Nomlar yozilgan kartalar (yopishqoq).","Uchburchak «oila» kartochkalari.","Doskada chiziqli model (bar model)."],
 board:["<span class='w2'>qo'shiluvchi + qo'shiluvchi = yig'indi</span>","<span class='w2'>kamayuvchi − ayriluvchi = ayirma</span>","□ + 17 = 45 → □ = 45 − 17 = 28.","□ − 38 = 26 → □ = 26 + 38 = 64.","72 − □ = 45 → □ = 72 − 45 = 27."]};
