// ===== w_4f umumiy sahna vositalari (4-sinf kasrlar) =====
function f4big(s){return typeof s==='string'?s.replace(/(^|[^\d\/\w>])(\d{1,4})\/(\d{4})(?![\d\/])/g,'$1<span class="frc"><span>$2</span><span>$3</span></span>'):s}
function f4fix(){function fx(o){for(var k in o){if(typeof o[k]==='string')o[k]=f4big(o[k]);else if(o[k]&&typeof o[k]==='object'&&k!=='btns')fx(o[k])}}STEPS.forEach(fx);PROBS.forEach(fx);if(typeof PREP_DATA!=='undefined')fx(PREP_DATA)}
function f4msg(h){h=f4big(h);strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f4c(lines,note){calc(lines.map(f4big),note)}
// tasma: n bo'lak, k bo'yalgan (son yoki massiv), col — rang, lab — har katak yozuvi
function f4bar(x,y,w,h,n,k,col,lab,p){var g=E('g',{},p||S.g),cells=[];
 for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;var c=E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g);c._on=on;c._i=i;cells.push(c);
  if(lab&&lab[i]!=null&&lab[i]!=='')T(g,x+(i+.5)*w/n,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);g.cells=cells;return g}
// bir nechta rang bilan bo'yash: cols — har katak rangi (null — oq)
function f4barC(x,y,w,h,cols,lab){var g=E('g',{},S.g);cols.forEach(function(cl,i){E('rect',{x:x+i*w/cols.length,y:y,width:w/cols.length,height:h,fill:cl||C.off,stroke:C.line,'stroke-width':1.4},g);if(lab&&lab[i])T(g,x+(i+.5)*w/cols.length,y+h/2+5,lab[i],{'font-size':Math.min(13,h*.45),'font-weight':800,fill:'#1d2b3a'})});E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.4,rx:2},g);return g}
// bosib bo'yaladigan tasma: faqat qo'shadi; onCh(k) har bosishda
function f4tapBar(x,y,w,h,n,onCh,col){var B=f4bar(x,y,w,h,n,0,col);S.tk=0;B.cells.forEach(function(c){c.style.cursor='pointer';c.addEventListener('click',function(){if(c._on)return;c._on=true;c.setAttribute('fill',col||C.a);S.tk++;onCh(S.tk,c)})});return B}
// doira (pitsa) n bo'lak, k bo'yalgan
function f4sec(p,cx,cy,r,a0,a1,fill){if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
function f4pie(cx,cy,r,n,k,col){var g=E('g',{},S.g),d=2*Math.PI/n,a=-Math.PI/2;for(var i=0;i<n;i++)f4sec(g,cx,cy,r,a+i*d,a+(i+1)*d,i<k?(col||C.a):C.off);return g}
// aralash son SVG da: butun katta, kasr ustma-ust
function f4mix(p,x,y,w,n,d,a){a=a||{};var fs=a.fs||18,col=a.fill||'#1d2b3a',g=E('g',{},p);
 if(n===0||n==null){T(g,x,y,String(w),{'font-size':fs,'font-weight':800,fill:col});return g}
 var ww=String(w).length*fs*.6;if(w)T(g,x-ww/2-2,y,String(w),{'font-size':fs*1.1,'font-weight':800,fill:col});T(g,w?x+8:x,y,n+'/'+d,{'font-size':fs,'font-weight':800,fill:col});return g}
// tanlov tugmalari: items [[yorliq, izoh]], okI — to'g'risi; fin() — to'g'ri tanlanganda sahna
function f4pick(okI,items,fin){return items.map(function(m,i){return [m[0],function(c,done){if(i===okI){if(fin)fin();f4msg('✓ '+m[1]);done()}else f4msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
// son o'qi: from..to, bo'linish d (har butunda), ox — chap, len — uzunlik
function f4line(y,from,to,d,ox,len,labF){var g=S.g,u=len/(to-from);E('line',{x1:ox-6,y1:y,x2:ox+len+8,y2:y,stroke:'#33475b','stroke-width':2.4},g);
 for(var q=from*d;q<=to*d;q++){var X=ox+(q/d-from)*u,big=q%d===0;E('line',{x1:X,y1:y-(big?11:7),x2:X,y2:y+(big?11:7),stroke:'#33475b','stroke-width':big?2.4:1.3},g);
  var L=labF?labF(q,big):(big?String(q/d):'');if(L)T(g,X,y+(big?28:24),L,{'font-size':big?14:10,'font-weight':big?800:600,fill:big?'#1d2b3a':'#6b7b8b'})}
 return function(v){return ox+(v-from)*u}}
function f4arc(X1,X2,y,h,lab,col){E('path',{d:'M'+X1+' '+(y-4)+' Q'+(X1+X2)/2+' '+(y-4-h)+' '+X2+' '+(y-4),fill:'none',stroke:col||C.blue,'stroke-width':2,'stroke-dasharray':'4 3'},S.g);if(lab)T(S.g,(X1+X2)/2,y-4-h/2-4,lab,{'font-size':11,'font-weight':800,fill:col||C.blue})}
// matn ichidagi a/b kasrlarni ustma-ust chizadi (aralash matn ham)
function f4t(x,y,s,fs,col,anc){s=String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>');fs=fs||13;col=col||'#1d2b3a';anc=anc||'middle';
 var re=/(\d{1,4})\/(\d{1,4})/g,parts=[],last=0,m;while((m=re.exec(s))){if(m.index>last)parts.push({t:s.slice(last,m.index)});parts.push({n:m[1],d:m[2]});last=re.lastIndex}if(last<s.length)parts.push({t:s.slice(last)});
 if(parts.length===1&&parts[0].t!=null)return T(S.g,x,y,s,{'font-size':fs,'font-weight':800,fill:col,'text-anchor':anc});
 var ff=fs*.8;function tw(t){var w=0;for(var i=0;i<t.length;i++){var ch=t[i];w+=ch===' '?.27:(/[0-9]/.test(ch)?.6:(/[=+−·:<>→×]/.test(ch)?.62:(/[ilj‘’'.,!|]/.test(ch)?.3:(/[mwMW]/.test(ch)?.85:.56))))}return w*fs}
 parts.forEach(function(p){p.w=p.t!=null?tw(p.t):Math.max(p.n.length,p.d.length)*ff*.62+9});
 var tot=parts.reduce(function(a,p){return a+p.w},0),cx=anc==='start'?x:(anc==='end'?x-tot:x-tot/2),g=E('g',{},S.g);
 parts.forEach(function(p){if(p.t!=null){var e=E('text',{x:cx,y:y,'font-size':fs,'font-weight':800,fill:col,style:'white-space:pre'},g);e.textContent=p.t}else T(g,cx+p.w/2,y,p.n+'/'+p.d,{'font-size':fs,'font-weight':800,fill:col});cx+=p.w});return g}
function f4Br(x1,x2,y,lab,up,col){Br(x1,x2,y,'',up,col);if(lab)f4t((x1+x2)/2,up?y-16:y+26,lab,13,col||C.blue)}
var CODE='4F6',TITLE='4-sinf · Aralash kasrlar';
// choraklar: n ta chorak bo'lakni pitsalarga yig'ish
function f6pies(n,st){clear();var full=Math.floor(n/4),rest=n%4;
 if(st===0){for(var i=0;i<n;i++){var x=30+i*44;f4sec(E('g',{},S.g),x,90,26,-Math.PI/2,0,C.a)}f4t(180,30,n+' ta chorak bo‘lak: '+n+'/4',14);return}
 for(var j=0;j<full;j++)f4pie(70+j*110,84,44,4,4,C.a);if(rest)f4pie(70+full*110,84,44,4,rest,C.a);
 f4t(70,150,'1 butun',13,C.ok);if(rest)f4t(70+full*110,150,rest+'/4',14,C.a2);if(st>=2)f4t(290,90,n+'/4 = '+full+' '+rest+'/4',16,C.blue)}
var F6P1=[function(){f6pies(7,0);f4c(['Har bo‘lak — pitsaning 1/4 qismi. 7 ta bo‘lak — 7/4'])},function(){f6pies(7,1);f4c(['4 ta chorak — 1 butun pitsa. Yana 3 ta chorak qoldi'])},function(){f6pies(7,2);f4c(['7/4 = <b>1 3/4</b> — «bir butun to‘rtdan uch»','Bunday son <b>aralash son</b> deyiladi: butun qism + to‘g‘ri kasr'])}];
function f6bars(n,d,st){clear();var w=Math.floor(n/d),r=n%d,bw=Math.min(90,320/(w+1)-8);for(var j=0;j<=w;j++){if(j===w&&!r)break;f4bar(20+j*(bw+8),40,bw,34,d,j<w?d:r,j<w?C.b:C.a)}
 f4t(180,22,n+'/'+d+(st>=1?' = '+n+' : '+d:''),15);if(st>=1)f4t(180,110,n+' : '+d+' = '+w+' (qoldiq '+r+')',14,'#33475b');if(st>=2)f4t(180,144,n+'/'+d+' = '+w+' '+r+'/'+d,18,C.ok)}
var F6P2=[function(){f6bars(17,5,0);f4c(['17/5 — 17 ta beshdan bir. Nechta butun yig‘iladi?'])},function(){f6bars(17,5,1);f4c(['Har 5 bo‘lak — 1 butun. 17 : 5 = <b>3</b>, qoldiq <b>2</b>'])},function(){f6bars(17,5,2);f4c(['Bo‘linma — butun qism (3), qoldiq — surat (2), maxraj o‘sha (5)','17/5 = <b>3 2/5</b>'])}];
function f6back(st){clear();f4bar(20,40,96,34,5,5,C.b);f4bar(126,40,96,34,5,5,C.b);f4bar(232,40,96,34,5,3,C.a);f4t(180,22,'2 3/5 = ?',15);
 if(st>=1){f4t(68,96,'5/5',13,C.blue);f4t(174,96,'5/5',13,C.blue);f4t(280,96,'3/5',13,C.a2);f4t(180,124,'2 · 5 = 10 beshdan bir',13,'#33475b')}
 if(st>=2)f4t(180,154,'10 + 3 = 13 → 2 3/5 = 13/5',16,C.ok)}
var F6P4=[function(){f6back(0);f4c(['2 3/5 ni noto‘g‘ri kasr qilib yozamiz'])},function(){f6back(1);f4c(['Har butunda 5 ta beshdan bir: 2 · 5 = <b>10</b>'])},function(){f6back(2);f4c(['Yana 3 tasi: 10 + 3 = 13 → <b>13/5</b>','Qoida: yangi surat = butun · maxraj + surat; maxraj o‘zgarmaydi'])}];
function f6nl(st){clear();var X=f4line(104,0,3,4,30,300);if(st>=1)f4arc(X(0),X(2),104,40,'2 butun',C.blue);if(st>=2)f4arc(X(2),X(2.25),104,22,'',C.a2);var v=st>=2?2.25:(st>=1?2:0);E('circle',{cx:X(v),cy:88,r:7,fill:C.a2,stroke:'#fff','stroke-width':2},S.g);
 f4t(180,24,st>=2?'2 1/4 — 2 dan keyin yana 1/4':'2 1/4 qayerda?',14,st>=2?C.ok:'#1d2b3a')}
var F6P6=[function(){f6nl(0);f4c(['Son o‘qi 0 dan 3 gacha, har butun 4 ga bo‘lingan'])},function(){f6nl(1);f4c(['Avval butun qism: 2'])},function(){f6nl(2);f4c(['Keyin kasr qism: yana 1/4 qadam → <b>2 1/4</b>','2 1/4 son o‘qida 2 va 3 orasida'])}];
function f6share(st){clear();var g=S.g;for(var i=0;i<10;i++){var cx=26+i*34,cy=50;var c=st>=1?(i<8?['#cfe3f5','#ffe2b0','#d8eecf','#f7d6d0'][Math.floor(i/2)]:'#eee'):'#f3d29b';E('circle',{cx:cx,cy:cy,r:14,fill:c,stroke:'#8a5a24','stroke-width':1.5},g);if(st>=2&&i>=8){E('line',{x1:cx-14,y1:cy,x2:cx+14,y2:cy,stroke:C.bad,'stroke-width':2},g)}}
 f4t(180,20,'10 ta non — 4 kishiga teng',13);if(st>=1)f4t(180,98,'Har biriga 2 tadan butun (8 ta non)',12,'#33475b');if(st>=2)f4t(180,124,'Qolgan 2 ta non 2 bo‘lakdan: 4 ta yarim',12,'#33475b');if(st>=3)f4t(180,156,'10/4 = 2 2/4 = 2 1/2 non',16,C.ok)}
var F6P8=[function(){f6share(0);f4c(['10 ta nonni 4 kishiga teng bo‘lamiz: 10 : 4 = 10/4'])},function(){f6share(1);f4c(['Har biriga 2 ta butun non'])},function(){f6share(2);f4c(['Qolgan 2 ta nonni yarimga bo‘lamiz — har biriga 1 ta yarim'])},function(){f6share(3);f4c(['Har biriga: <b>2 1/2</b> non (2 2/4 = 2 1/2)'])}];
function PRACT_STAGE(){f6pies(7,2);f4c(['Noto‘g‘ri → aralash: <b>17/5 = 3 2/5</b> (17 : 5 = 3, qoldiq 2)','Aralash → noto‘g‘ri: <b>2 3/5 = 13/5</b> (2 · 5 + 3)'])}
var STEPS=[
{h:"Butun va bo'lak birga",sum:"7/4 = 1 3/4: 4 ta chorak — 1 butun, yana 3 ta chorak. Butun son + to'g'ri kasr — aralash son.",a:"m01",
 start:function(){startPh(F6P1)},fin:function(){S.ph=2;F6P1[2]()},
 html:"<p>Stolda 7 ta chorak pitsa bo'lagi bor — <b>7/4</b>. Ularni butun pitsalarga yig'amiz. Bosing:</p>",btns:[phaser(F6P1)],
 after:"<p>4 ta chorakdan <b>1 butun</b> pitsa yig'ildi, yana <b>3/4</b> qoldi. Buni qisqa yozamiz: <b>1 3/4</b> — «bir butun to'rtdan uch».</p><p><b>Aralash son</b> = butun qism + to'g'ri kasr. U har doim 1 dan katta va noto'g'ri kasrning boshqacha yozilishi.</p>",
 q:{t:"9/4 qanday aralash son?",opts:["2 1/4","2 1/9","4 1/2","9 1/4"],ok:0,why:"8 ta chorak — 2 butun, yana 1 chorak.",hint:"Nechta to'liq «4 ta chorak» bor? Nechtasi ortib qoladi?",full:"9 ta chorakdan 2 ta butun (8 ta chorak) yig'iladi, 1 ta chorak qoladi: 2 1/4. «9 1/4» — butun qismni noto'g'ri topish, «2 1/9» — maxrajni almashtirish."},
 tn:"Haqiqiy qog'oz «pitsa» choraklarini bolalarga bering — ular o'zi butun doiralar yig'ib, qolganini sanasin (Montessori kasr doiralari)."},
{h:"Butun qismni ajratish",sum:"17/5 = 3 2/5: 17 : 5 = 3 (qoldiq 2). Bo'linma — butun qism, qoldiq — yangi surat, maxraj o'zgarmaydi.",a:"m02",
 start:function(){startPh(F6P2)},fin:function(){S.ph=2;F6P2[2]()},
 html:"<p>Bo'laklar ko'p bo'lsa, sanash uzoq. Tez yo'l — <b>qoldiqli bo'lish</b>. 17/5 ni ko'ring:</p>",btns:[phaser(F6P2)],
 after:"<p>Kasr chizig'i — bo'lish. 17 : 5 = 3, qoldiq 2. Demak:</p><p>• <b>bo'linma</b> (3) — butun qism;<br>• <b>qoldiq</b> (2) — surat;<br>• <b>maxraj</b> (5) — o'zgarmaydi.</p><p>17/5 = <b>3 2/5</b>. Tekshirish: 3 · 5 + 2 = 17 ✓.</p>",
 q:{t:"23/6 kasrdan butun qismni ajrating.",opts:["3 5/6","3 1/6","5 3/6","6 3/5"],ok:0,why:"23 : 6 = 3, qoldiq 5.",hint:"23 ni 6 ga qoldiqli bo'ling.",full:"23 : 6 = 3 (6 · 3 = 18), qoldiq 23 − 18 = 5. Javob: 3 5/6. «5 3/6» — bo'linma va qoldiqni almashtirish."},
 tn:"Butun qismni ajratish — qoldiqli bo'lishning amaliy qo'llanishi. Doskada ustunda bo'lish yozuvi bilan yonma-yon ko'rsating."},
{h:"To'g'ri aralash sonni tanlang",sum:"11/3: 11 : 3 = 3, qoldiq 2 → 3 2/3.",a:"m03",
 start:function(){clear();f4t(180,60,'11/3 = ?',30);f4msg('Qaysi aralash son 11/3 ga teng?')},fin:function(){f6bars(11,3,2);f4msg('11 : 3 = 3, qoldiq 2 → <b>3 2/3</b>')},
 html:"<p>11/3 qaysi aralash songa teng? Avval hisoblang, keyin tanlang:</p>",
 btns:f4pick(1,[["3 1/3","Tekshiring: 3 · 3 + 1 = 10, 11 emas."],["3 2/3","To'g'ri! 3 · 3 + 2 = 11."],["2 2/3","Tekshiring: 2 · 3 + 2 = 8, 11 emas."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Javobni doim tekshiring: <b>butun · maxraj + surat</b> boshlang'ich suratga teng chiqishi kerak. 3 · 3 + 2 = 11 ✓.</p><p>Diqqat: aralash sonning kasr qismi doim <b>to'g'ri kasr</b> bo'ladi. «2 5/3» deb yozilmaydi — 5/3 dan yana bitta butun ajraladi.</p>",
 q:{t:"Qaysi kasr 4 1/2 ga teng?",opts:["9/2","41/2","6/2","5/2"],ok:0,why:"4 · 2 + 1 = 9.",hint:"4 ta butunda nechta yarim bor? Yana bitta yarim qo'shing.",full:"4 butunda 4 · 2 = 8 ta yarim, yana 1 ta: 9/2. «41/2» — raqamlarni yonma-yon yozish, «5/2» — 4 + 1."},
 tn:"Xato javoblarni tekshiruv formulasi bilan rad etish — o'quvchida o'z-o'zini nazorat qilish odatini shakllantiradi."},
{h:"Aralash sondan noto'g'ri kasrga",sum:"2 3/5 = 13/5, chunki 2 · 5 + 3 = 13: har butunda 5 ta beshdan bir.",a:"m04",
 start:function(){startPh(F6P4)},fin:function(){S.ph=2;F6P4[2]()},
 html:"<p>Endi teskari yo'l: 2 3/5 ni noto'g'ri kasr ko'rinishida yozamiz. Bosing:</p>",btns:[phaser(F6P4)],
 after:"<p>Har butunda maxrajcha (5 ta) bo'lak bor. 2 butunda — 2 · 5 = 10 ta, yana 3 tasi: 13 ta. Demak <b>2 3/5 = 13/5</b>.</p><p><b>Qoida:</b> butunni maxrajga ko'paytirib, suratni qo'shamiz; maxraj o'zgarmaydi.</p>",
 q:{t:"3 2/7 ni noto'g'ri kasrga aylantiring.",opts:["23/7","32/7","6/7","21/7"],ok:0,why:"3 · 7 + 2 = 23.",hint:"3 butunda nechta yettidan bir bor?",full:"3 · 7 = 21 ta yettidan bir, yana 2 ta: 23/7. «21/7» — surat 2 ni qo'shishni unutish, «32/7» — raqamlarni yonma-yon yozish, «6/7» — 3 · 2."},
 tn:"Kalit so'zlar: «ko'paytir — qo'sh — maxraj qoladi». Bolalar qo'l bilan doira chizib (butun · maxraj + surat) yod olsin."},
{h:"Tuzoq: raqamlarni yonma-yon yozish",sum:"2 3/5 ≠ 23/5! 23/5 = 4 3/5. To'g'risi: 2 3/5 = 13/5.",a:"m05",
 start:function(){clear();f4t(180,50,'2 3/5 = 23/5 ?',26,C.bad);f4msg('Bola raqamlarni ketma-ket yozib qo‘ydi. To‘g‘rimi?')},
 fin:function(){clear();f4t(100,50,'23/5 = 4 3/5',18,C.bad);f4t(260,50,'2 3/5 = 13/5',18,C.ok);f4t(180,110,'2 · 5 + 3 = 13',16,'#33475b');f4msg('23/5 da 4 ta butun bor — bu boshqa son!')},
 html:"<p>Ali 2 3/5 ni noto'g'ri kasrga aylantirib, <b>23/5</b> deb yozdi. To'g'ri javobni tanlang:</p>",
 btns:f4pick(1,[["23/5","23 : 5 = 4, qoldiq 3. 23/5 = 4 3/5 — 2 3/5 emas!"],["13/5","To'g'ri! 2 · 5 + 3 = 13."],["6/5","Bu 2 · 3 — butunni suratga ko'paytirish. Butunni maxrajga ko'paytiring."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Aralash son yozuvida butun qism va kasr <b>yonma-yon</b> turadi, lekin bu <b>qo'shish</b>: 2 3/5 = 2 + 3/5. Raqamlarni «yopishtirish» katta xato.</p><p>Tekshiring: 13/5 → 13 : 5 = 2, qoldiq 3 → 2 3/5 ✓.</p>",
 q:{t:"5 1/3 nechaga teng?",opts:["51/3","16/3","8/3","15/3"],ok:1,why:"5 · 3 + 1 = 16.",hint:"Butunni maxrajga ko'paytiring, suratni qo'shing.",full:"5 · 3 + 1 = 16: 16/3. «51/3» — raqamlarni yopishtirish, «15/3» — suratni unutish (bu 5 ga teng), «8/3» — 5 + 3."},
 tn:"Ikki yo'nalishda tekshirish (aylantirib, qaytarib aylantirish) — xalqaro dasturlarda ko'p tavsiya etiladi."},
{h:"Aralash son son o'qida",sum:"2 1/4: avval 2 butun, keyin yana 1/4 — 2 va 3 orasida.",a:"m06",
 start:function(){startPh(F6P6)},fin:function(){S.ph=2;F6P6[2]()},
 html:"<p>Aralash son ham son — son o'qida uning joyi bor. 2 1/4 ni toping:</p>",btns:[phaser(F6P6,'🦘 Sakra')],
 after:"<p>Butun qism — qaysi ikki butun son <b>orasida</b> ekanini aytadi: 2 1/4 — 2 va 3 orasida. Kasr qism — 2 dan <b>qancha</b> o'ngda ekanini.</p>",
 q:{t:"Son o'qida 1 3/5 qayerda joylashgan?",opts:["1 va 2 orasida","3 va 4 orasida","0 va 1 orasida","Aynan 3 da"],ok:0,why:"Butun qism 1.",hint:"Butun qismga qarang.",full:"1 3/5 = 1 + 3/5: 1 dan o'ngda, lekin 2 ga yetmaydi (3/5 &lt; 1). «3 va 4 orasida» — surat 3 ga qarash xatosi."},
 tn:"Polga 0–3 son o'qini chizing. Bolalar «2 1/4» kartochkasini olib, o'z joyiga turib ko'rsatsin."},
{h:"Aralash sonlarni taqqoslash",sum:"Avval butun qismlar, ular teng bo'lsa — kasr qismlar. 13/4 = 3 1/4; 3 1/10 &gt; 2 4/5.",a:"m07",
 start:function(){clear();f4t(100,60,'13/4',26);f4t(180,62,'?',24);f4t(260,60,'3 1/4',26);f4msg('Belgini tanlang')},
 fin:function(){clear();f4t(100,50,'13/4',22);f4t(180,52,'=',22,C.ok);f4t(260,50,'3 1/4',22);f4t(180,110,'13 : 4 = 3, qoldiq 1',14,'#33475b');f4t(180,146,'3 1/10 > 2 4/5 — butun qism hal qiladi',13,C.blue);f4msg('13/4 = 3 1/4')},
 html:"<p>13/4 va 3 1/4 ni taqqoslang. Avval bir xil ko'rinishga keltiring:</p>",
 btns:f4pick(2,[["&gt;","13/4 ni aralash songa aylantiring: 13 : 4 = ?"],["&lt;","13 katta son, lekin u surat — 4 ga bo'linadi."],["=","To'g'ri! 13/4 = 3 1/4 — bir son, ikki xil yozuv."]],function(){STEPS[cur].fin()}),g3:1,
 after:"<p>Taqqoslashdan oldin ikkala sonni <b>bir ko'rinishga</b> keltiring. Aralash sonlarda: avval <b>butun qismlar</b> solishtiriladi. 3 1/10 va 2 4/5 — 3 &gt; 2, demak 3 1/10 katta, garchi 4/5 &gt; 1/10 bo'lsa ham.</p>",
 q:{t:"Qaysi biri katta: 17/5 yoki 3 1/5?",opts:["17/5","3 1/5","Teng","3 1/5, chunki butun qismi bor"],ok:0,why:"17/5 = 3 2/5 &gt; 3 1/5.",hint:"17/5 ni aralash songa aylantiring.",full:"17 : 5 = 3, qoldiq 2: 17/5 = 3 2/5. Butun qismlar teng (3), kasrlar: 2/5 &gt; 1/5. Demak 17/5 katta."},
 tn:"Testlarda aralash va noto'g'ri kasrni taqqoslash ko'p keladi. Avval «bir xil ko'rinish» qoidasini doskaga yozing."},
{h:"Hayotda: nonni bo'lishish",sum:"10 ta nonni 4 kishiga: 10/4 = 2 2/4 = 2 1/2 — har biriga ikki yarim non.",a:"m08",
 start:function(){startPh(F6P8)},fin:function(){S.ph=3;F6P8[3]()},
 html:"<p>To'yda 10 ta non 4 ta dasturxonga teng tarqatilishi kerak. Har biriga qancha non tegadi?</p>",btns:[phaser(F6P8)],
 after:"<p><b>Bo'lish natijasi kasr bo'lishi mumkin</b>: 10 : 4 = 10/4 = <b>2 2/4</b>. 2/4 — bu yarim, shuning uchun har biriga 2 1/2 non tegadi.</p><p>Bu IES tavsiyasidagi «teng bo'lishish» usuli: hayotiy taqsimlash orqali kasr butun songa bo'lish natijasi ekanini ko'rish.</p>",
 q:{t:"7 ta tarvuzni 2 kishi teng bo'lishdi. Har biriga qancha tarvuz tegdi?",opts:["3 1/2","2 1/7","3 2/7","5"],ok:0,why:"7 : 2 = 3, qoldiq 1 → 3 1/2.",hint:"7 ni 2 ga qoldiqli bo'ling. Qoldiq tarvuzni nima qilamiz?",full:"7 : 2 = 3 (qoldiq 1). Qolgan 1 tarvuz ikkiga bo'linadi — har biriga 1/2. Javob: 3 1/2. «2 1/7» — surat va maxrajni almashtirish."},
 tn:"Sinfda 5 ta qog'oz «non»ni 2 bolaga bo'ldiring. Bola qaychi bilan kesib, o'zi «2 1/2» degan javobga kelsin."},
{h:"Bilasizmi? Hindcha yozuv",sum:"Qadimgi Hindistonda aralash sonni ustma-ust uch qatorda yozishgan: butun, surat, maxraj — chiziqsiz.",a:"m09",
 start:function(){clear('#f6ead0');f4t(180,50,'Qadimgi hind yozuvi',16,'#7a4a12');f4msg('1 3/4 ni hindlar qanday yozgan?')},
 fin:function(){clear('#f6ead0');var g=S.g;f4t(90,22,'Hindcha',13,'#7a4a12');['1','3','4'].forEach(function(t,i){T(g,90,56+i*34,t,{'font-size':24,'font-weight':800,fill:'#7a4a12'})});E('rect',{x:66,y:30,width:48,height:110,rx:6,fill:'none',stroke:'#c9a56b','stroke-width':1.5},g);f4t(260,22,'Bugun',13,'#7a4a12');f4t(260,96,'1 3/4',28,'#7a4a12');f4msg('Keyinchalik arab olimlari surat va maxraj orasiga chiziq qo‘shgan')},
 html:"<p>📜 Hind matematiklari (masalan, VII asrdagi <b>Brahmagupta</b>) kasrlar bilan erkin hisoblashgan. Aralash sonni ular qanday yozgan ekan?</p>",
 btns:[["📜 Ko'rsatish",function(c,done,b){b.disabled=true;STEPS[cur].fin();done()}]],
 after:"<p>Hindlar aralash sonni <b>ustun shaklida</b> yozgan: tepada butun qism, uning ostida surat, eng pastda maxraj — chiziqsiz. Arab olimlari surat va maxraj orasiga <b>chiziq</b> qo'shishdi. Bugungi yozuvimiz — shu ikki an'ananing birlashmasi.</p>",
 tn:"Bolalar daftarida 2–3 ta aralash sonni «hindcha» ustun qilib yozib, keyin bugungi usulda yozsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){PRACT_STAGE()},fin:function(){PRACT_STAGE()},
 html:"<div class='memo'><ul><li><b>Aralash son</b> = butun qism + to'g'ri kasr: 1 3/4 = 1 + 3/4.</li><li>Noto'g'ri → aralash: <b>surat : maxraj</b>. Bo'linma — butun, qoldiq — surat: 17/5 = 3 2/5.</li><li>Aralash → noto'g'ri: <b>butun · maxraj + surat</b>: 2 3/5 = 13/5.</li><li>2 3/5 ≠ 23/5 — raqamlarni yopishtirmang!</li><li>Kasr qismi doim to'g'ri kasr.</li><li>Taqqoslash: avval butun qismlar, keyin kasr qismlar.</li><li>Bo'lish natijasi kasr bo'lishi mumkin: 10 : 4 = 2 2/4.</li></ul></div>",
 tn:"Keyingi dars — aralash sonlarni qo'shish va ayirish. «1 3/4 + 1 2/4» ni pitsalar bilan qilib ko'rishni topshiring."}
];
var PROBS=[
{t:"13/4 ni aralash son ko'rinishida yozing.",o:["3 1/4","4 1/3","3 3/4","1 3/4"],k:0,s:"13 : 4 = 3, qoldiq 1."},
{t:"2 5/6 ni noto'g'ri kasr ko'rinishida yozing.",o:["17/6","25/6","10/6","12/6"],k:0,s:"2 · 6 + 5 = 17."},
{t:"29/8 ni aralash son ko'rinishida yozing.",o:["3 5/8","3 3/8","5 3/8","8 5/3"],k:0,s:"29 : 8 = 3, qoldiq 5."},
{t:"4 1/3 ni noto'g'ri kasr ko'rinishida yozing.",o:["13/3","41/3","5/3","12/3"],k:0,s:"4 · 3 + 1 = 13."},
{t:"Qaysi kasr 1 3/7 ga teng?",o:["10/7","13/7","4/7","8/7"],k:0,s:"1 · 7 + 3 = 10."},
{t:"18/5 kasrning butun qismi nechaga teng?",o:["3","5","4","13"],k:0,s:"18 : 5 = 3, qoldiq 3."},
{t:"6 2/3 aralash sonning kasr qismi qaysi?",o:["2/3","6","20/3","6/3"],k:0,s:"Butun qism 6, kasr qism 2/3."},
{t:"Qaysi son eng katta?",o:["3 1/8","2 7/8","3","23/8"],k:0,s:"23/8 = 2 7/8; eng kattasi 3 1/8."},
{t:"Qaysi son 4 ga teng?",o:["12/3","4/3","3/4","1 3/4"],k:0,s:"12 : 3 = 4."},
{t:"Qaysi tenglik to'g'ri?",o:["9/2 = 4 1/2","9/2 = 2 1/9","9/2 = 4 1/9","9/2 = 9 1/2"],k:0,s:"9 : 2 = 4, qoldiq 1."},
{t:"5 a/7 = 39/7 bo'lsa, a nechaga teng?",o:["4","3","2","39"],k:0,s:"5 · 7 + a = 39, a = 4."},
{t:"□/6 = 3 1/6. Kvadrat o'rnida qaysi son?",o:["19","18","31","4"],k:0,s:"3 · 6 + 1 = 19."},
{t:"14 ta pirogni 4 bola teng bo'lishdi. Har bir bolaga qancha pirog tegdi?",o:["3 2/4","4 2/3","3 1/4","2 3/4"],k:0,s:"14 : 4 = 3, qoldiq 2 → 3 2/4."},
{t:"Sonlarni o'sish tartibida joylang: 11/4, 2 1/4, 3.",o:["2 1/4, 11/4, 3","11/4, 2 1/4, 3","3, 11/4, 2 1/4","2 1/4, 3, 11/4"],k:0,s:"11/4 = 2 3/4; 2 1/4 < 2 3/4 < 3."},
{t:"Butun qismi 2, kasr qismining maxraji 5 bo'lgan nechta aralash son bor?",o:["4","5","3","10"],k:0,s:"2 1/5, 2 2/5, 2 3/5, 2 4/5."},
{t:"Qaysi noto'g'ri kasr 3 dan katta va 4 dan kichik?",o:["15/4","12/4","16/4","11/4"],k:0,s:"15/4 = 3 3/4."},
{t:"3 1/2 soat — bu necha yarim soat?",o:["7","6","3","5"],k:0,s:"3 1/2 = 7/2: 7 ta yarim soat."},
{t:"9 m ipni 4 ta teng bo'lakka bo'lishdi. Har bir bo'lak necha metr?",o:["2 1/4 m","2 1/9 m","4 1/2 m","1 3/4 m"],k:0,s:"9 : 4 = 2, qoldiq 1 → 2 1/4."},
{t:"Butun qismi 3, kasr qismining maxraji 8 bo'lgan eng katta aralash son qaysi noto'g'ri kasrga teng?",o:["31/8","32/8","38/8","11/8"],k:0,s:"3 7/8 = (3 · 8 + 7)/8 = 31/8."},
{t:"1 soat 15 minut — bu necha soat?",o:["1 1/4 soat","1 15/100 soat","1 1/15 soat","1 1/2 soat"],k:0,s:"15 minut = 1/4 soat."}
];
var PREP_DATA={teach:["Aralash son: butun qism + to'g'ri kasr (pitsa choraklari).","Noto'g'ri kasrdan butun qismni ajratish — qoldiqli bo'lish.","Aralash sonni noto'g'ri kasrga aylantirish: butun · maxraj + surat.","Son o'qida aralash son; taqqoslash.","Teng bo'lishish: 10 : 4 = 2 2/4."],
 mist:["Raqamlarni yopishtiradi: 2 3/5 = 23/5.","Bo'linma va qoldiqni almashtiradi.","Butunni suratga ko'paytiradi: 2 3/5 = 6/5.","Kasr qismini noto'g'ri kasr qoldiradi: 2 5/3.","Taqqoslashda kasr qismiga qarab, butun qismni unutadi."],
 need:["Qog'oz doiralar (choraklar), tasmalar.","Polda 0–3 son o'qi."],
 board:["<span class='w2'>7/4 = 1 3/4</span>.","<span class='w2'>17/5: 17 : 5 = 3 (qoldiq 2) → 3 2/5</span>.","<span class='w2'>2 3/5 = 13/5</span>: 2 · 5 + 3 = 13 (≠ 23/5).","3 1/10 &gt; 2 4/5 — butun qism hal qiladi."]};
