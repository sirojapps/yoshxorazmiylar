var CODE='3A7',TITLE='3-sinf · Pozitsion sanoq sistemasi';
function a7big(t,sub,col){clear();T(S.g,180,74,t,{'font-size':34,'font-weight':800,fill:col||'#1d2b3a'});if(sub)T(S.g,180,116,sub,{'font-size':15,'font-weight':700,fill:'#5b6b7b'})}
var P1=[function(){clear();var g=S.g;T(g,90,30,'Rimcha',{'font-size':13,'font-weight':800,fill:'#6b3d12'});T(g,270,30,'Bizning yozuv',{'font-size':13,'font-weight':800,fill:C.blue});E('line',{x1:180,y1:14,x2:180,y2:166,stroke:'#e6d6bd','stroke-width':2},g);T(g,90,90,'XXX',{'font-size':40,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'});T(g,270,90,'333',{'font-size':40,'font-weight':800,fill:C.blue});msg('Ikkala yozuvda ham bir xil belgi uch marta takrorlangan')},
 function(){clear();var g=S.g;E('line',{x1:180,y1:14,x2:180,y2:166,stroke:'#e6d6bd','stroke-width':2},g);T(g,90,90,'XXX',{'font-size':40,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'});T(g,90,130,'10 + 10 + 10 = 30',{'font-size':13,'font-weight':700,fill:'#6b3d12'});T(g,270,90,'333',{'font-size':40,'font-weight':800,fill:C.blue});msg('Rimchada har bir X — doim 10, qayerda tursa ham')},
 function(){clear();var g=S.g;E('line',{x1:180,y1:14,x2:180,y2:166,stroke:'#e6d6bd','stroke-width':2},g);T(g,90,90,'XXX',{'font-size':40,'font-weight':800,fill:'#6b3d12','font-family':'Georgia,serif'});T(g,90,130,'10 + 10 + 10 = 30',{'font-size':13,'font-weight':700,fill:'#6b3d12'});[['3',C.t1],['3','#b07a33'],['3',C.u]].forEach(function(r,i){T(g,240+i*30,90,r[0],{'font-size':40,'font-weight':800,fill:r[1]})});T(g,270,130,'300 + 30 + 3 = 333',{'font-size':13,'font-weight':700,fill:C.blue});msg('Bizda 3 ning qiymati <b>pozitsiyasiga</b> (joyiga) bog‘liq — bu pozitsion yozuv')}];
var STEPS=[
{h:"Pozitsion yozuv nima?",sum:"Raqamning qiymati uning joyiga (pozitsiyasiga) bog'liq bo'lsa — yozuv pozitsion.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Rimcha <b>XXX</b> va bizning <b>333</b>. Ikkalasida ham bitta belgi 3 marta takrorlangan. Farqini kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>«Pozitsiya» — joy, o'rin. Bizning yozuvda atigi <b>10 ta raqam</b> (0–9) bilan har qanday sonni yozish mumkin — chunki raqam joyini o'zgartirib, qiymatini o'zgartiradi. Shuning uchun u <b>o'nlik pozitsion sanoq sistemasi</b> deyiladi.</p>",
 q:{t:"Qaysi yozuvda raqam qiymati joyiga bog'liq?",opts:["555 (arab raqamlari)","XXX (rim raqamlari)","||| (cho'plar)","●●● (nuqtalar)"],ok:0,why:"555 = 500 + 50 + 5 — bir xil raqam, turli qiymat.",hint:"Qayerda bir xil belgi turli qiymat oladi?",full:"555 da beshlar 500, 50 va 5 ni bildiradi — pozitsion. XXX da har X = 10; cho'p va nuqtalarda har biri 1 — joyi ahamiyatsiz."},
 tn:"Doskada ikki ustun: «rimcha» va «bizniki». Bolalar bir xil sonni ikki usulda yozsin (masalan 38: XXXVIII va 38)."},
{h:"Har bir xona qo'shnisidan 10 marta katta",sum:"1 → 10 → 100 → 1 000: chapga bir xona — 10 marta katta.",a:"m02",
 start:function(){S.x10=1;w3table(1,{min:4,top:'1'});msg('×10 tugmasini bosing')},fin:function(){S.x10=1000;w3table(1000,{min:4,top:'1 000'});msg('1 · 10 · 10 · 10 = 1 000')},
 html:"<p>Raqam bir xona <b>chapga</b> surilsa, qiymati <b>10 marta</b> ortadi. 1 ni uch marta 10 ga ko'paytiring:</p>",
 btns:[["× 10",function(c,done,b){if(S.x10<1000){S.x10*=10;w3table(S.x10,{min:4,top:fmt(S.x10),hl:[String(S.x10).length-1]});msg('Raqam bir xona chapga surildi: <b>'+fmt(S.x10)+'</b>')}if(S.x10>=1000){b.disabled=true;done()}}]],
 after:"<p>Shuning uchun <b>10 birlik = 1 o'nlik</b>, 10 o'nlik = 1 yuzlik, 10 yuzlik = 1 ming. Bu sistemaning asosi — <b>10</b>. Har bir xonada eng ko'pi 9 bo'ladi — 10 bo'lsa, keyingi xonaga o'tadi.</p>",
 q:{t:"Minglar xonasining bir birligi o'nliklar xonasining bir birligidan necha marta katta?",opts:["100 marta","10 marta","1000 marta","2 marta"],ok:0,why:"1 000 : 10 = 100.",hint:"O'nlikdan minggacha nechta xona bor?",full:"O'nlik → yuzlik (×10) → ming (×10): 10 · 10 = 100 marta. «10 marta» — faqat bitta qadam; «2 marta» — xonalar sonini sanash."},
 tn:"Bloklar: 10 ta tayoqcha = 1 kvadrat; 10 ta kvadrat = 1 kub. Bolalar ustma-ust qo'yib ko'rsin."},
{h:"Sonni xona birliklari orqali yoyish",sum:"4 735 = 4 · 1 000 + 7 · 100 + 3 · 10 + 5.",a:"m03",
 start:function(){w3table(4735,{top:'4 735 = ?'});msg('Har raqam × o‘z xonasining birligi')},fin:function(){w3table(4735,{top:'4·1000 + 7·100 + 3·10 + 5'});msg('4 735 = 4 · 1 000 + 7 · 100 + 3 · 10 + 5')},
 html:"<p>Pozitsion yozuvda har bir raqam — «nechta» degani: <b>4</b> ta ming, <b>7</b> ta yuz… 4 735 ning to'g'ri yoyilmasini tanlang:</p>",
 btns:w3choose(["4 + 7 + 3 + 5","4·1000 + 7·100 + 3·10 + 5","4·100 + 7·10 + 3 + 5"],1,function(){w3table(4735,{top:'4·1000 + 7·100 + 3·10 + 5'});msg('4 000 + 700 + 30 + 5 = 4 735 ✓')},function(i){msg(i===0?'Bu raqamlar yig‘indisi — 19':'Xonalar bir pog‘onaga siljigan: 4 — minglar xonasida!')}),
 after:"<p>Teskarisi: 6 · 1 000 + 2 · 10 = <b>6 020</b> (yuzliklar va birliklar — 0). Bu yozuv sonning «tarkibi»ni ochib beradi.</p>",
 q:{t:"5 · 1 000 + 8 · 10 + 3 = ?",opts:["5 083","583","5 803","5 830"],ok:0,why:"Ming 5, yuzlik 0, o'nlik 8, birlik 3.",hint:"Yuzliklar soni nechta?",full:"5 000 + 80 + 3 = 5 083. «583» — nolni tushirib qoldirish; «5 803» — 8 ni yuzlik deb olish; «5 830» — raqamlarni surib yuborish."},
 tn:"Kartochka o'yini: bir bola yoyilmani aytadi, boshqasi sonni yozadi."},
{h:"Tuzoq: o'ngdan nol yozilsa",sum:"37 ning o'ng tomoniga 0 yozilsa — 370: son 10 marta ortadi, ya'ni 333 ga ortadi.",a:"m04",
 start:function(){a7big('37  →  370','o‘ngdan 0 yozildi');msg('Son nima bo‘ldi?')},fin:function(){a7big('370 − 37 = 333','10 marta katta = 333 ga ko‘p',C.ok)},
 html:"<p>37 ning o'ng tomoniga 0 yozildi — 370 bo'ldi. «Son <b>qanchaga</b> ortdi?» Ehtiyot bo'ling: «necha marta» va «qanchaga» — turli savol!</p>",
 btns:w3choose(["10 ga","333 ga","0 ga"],1,function(){a7big('370 − 37 = 333','10 marta katta = 333 ga ko‘p',C.ok);msg('Hamma raqamlar bir xona chapga surildi → 10 <b>marta</b>, farq <b>333</b>')},function(i){msg(i===0?'«10» — bu «necha marta»ning javobi. «Qanchaga» — ayirma: 370 − 37':'Nol qo‘shilsa ham raqamlar joyi o‘zgardi!')}),g3:1,
 after:"<p>O'ngdan 0 yozish = 10 ga ko'paytirish (raqamlar bir xona chapga suriladi). Ortish: 37 · 10 − 37 = 37 · 9 = <b>333</b>. Ikkita 0 yozilsa — 100 marta.</p>",
 q:{t:"Bir songa o'ngdan 0 yozilgach, u 450 ga ortdi. Dastlabki son qaysi?",opts:["50","45","500","4 500"],ok:0,why:"500 − 50 = 450.",hint:"Yangi son eskisidan 10 marta katta, farqi esa 9 ta eski son.",full:"Yangi son = eski · 10, farq = eski · 9 = 450 → eski = 50. Tekshiruv: 500 − 50 = 450 ✓. «45» — 450 : 10, lekin 450 − 45 = 405 ≠ 450."},
 tn:"Kuchli o'quvchilar uchun. Avval 2–3 sonda tajriba qilib ko'rsating: 12 → 120 (108 ga), 20 → 200 (180 ga)."},
{h:"Tuzoq: chapdan raqam yozilsa",sum:"52 ning chap tomoniga 3 yozilsa — 352: son 300 ga ortadi.",a:"m05",
 start:function(){a7big('52  →  352','chapdan 3 yozildi');msg('Son qanchaga ortdi?')},fin:function(){a7big('352 − 52 = 300','3 yuzliklar xonasiga tushdi',C.ok)},
 html:"<p>Ikki xonali 52 ning <b>chap</b> tomoniga 3 yozildi. Bu safar boshqa raqamlar joyida qoladi! Son qanchaga ortdi?</p>",
 btns:w3choose(["3 ga","30 ga","300 ga"],2,function(){a7big('352 − 52 = 300','3 yuzliklar xonasiga tushdi',C.ok);msg('5 va 2 joyida qoldi, yangi 3 — yuzlik: <b>+300</b>')},function(i){msg(i===0?'3 yangi xonaga — yuzliklarga tushdi, uning qiymati 3 emas':'3 qaysi xonada turibdi? Uchinchi xona — yuzliklar')}),g3:1,
 after:"<p>Chapdan yozilgan raqam <b>yangi eng katta xonaga</b> tushadi. Ikki xonali songa chapdan 3 yozilsa — <b>+300</b>; uch xonali songa — <b>+3 000</b>.</p>",
 q:{t:"Uch xonali 418 ning chap tomoniga 6 yozildi. Son qanchaga ortdi?",opts:["6 000","600","6","6 418"],ok:0,why:"6 418 − 418 = 6 000.",hint:"6 nechanchi xonaga tushadi?",full:"418 — uch xonali, 6 to'rtinchi xonaga (minglar) tushadi: 6 418 − 418 = 6 000. «600» — 6 ni yuzlik deb olish; «6 418» — yangi son, ortish emas."},
 tn:"Raqam kartochkalarini stol ustida chapga/o'ngga qo'shib, son qanday o'zgarishini ko'rsating."},
{h:"Kartochkalardan son yasaymiz",sum:"3, 0, 7, 5: eng kattasi 7 530, eng kichigi 3 057 (0 boshida turolmaydi).",a:"m06",
 start:function(){a7cards('');msg('Kartochkalar: 3, 0, 7, 5')},fin:function(){a7cards('3 057');msg('Eng kichik to‘rt xonali son: <b>3 057</b>')},
 html:"<p>3, 0, 7, 5 kartochkalaridan (har biri bir marta) <b>eng kichik to'rt xonali</b> son yasang. Tuzoq — 0 ni boshiga qo'yish:</p>",
 btns:w3choose(["0 357","3 057","3 075"],1,function(){a7cards('3 057');msg('Boshiga eng kichik <b>noldan farqli</b> raqam — 3, keyin 0, 5, 7')},function(i){msg(i===0?'0 357 — bu to‘rt xonali emas, uch xonali 357!':'3 075 > 3 057 — 5 va 7 o‘rnini almashtiring')}),g3:1,
 after:"<p>Eng katta: raqamlar kamayish tartibida — <b>7 530</b>. Eng kichik: boshiga eng kichik noldan farqli raqam, qolganlari o'sish tartibida — <b>3 057</b>. Ularning ayirmasi: 7 530 − 3 057 = <b>4 473</b>.</p>",
 q:{t:"4, 0, 9, 1 raqamlaridan (har biri bir marta) yasalgan eng kichik to'rt xonali son?",opts:["1 049","0 149","1 094","1 409"],ok:0,why:"Boshiga 1, keyin 0, 4, 9.",hint:"Birinchi o'ringa noldan farqli eng kichik raqam.",full:"Birinchi o'rin — 1 (0 bo'lolmaydi). Qolganlari o'sish tartibida: 0, 4, 9. Javob 1 049. «0 149» — aslida uch xonali; «1 094» va «1 409» — kattaroq."},
 tn:"Har bir partaga 4 ta raqam kartochkasi. Kim tezroq eng katta va eng kichik sonni yasaydi?"},
{h:"Bilasizmi? Al-Xorazmiy va raqamlar",sum:"O'nlik pozitsion yozuv Hindistonda paydo bo'lgan, Al-Xorazmiy kitobi orqali Yevropaga tarqalgan.",a:"m07",
 start:function(){a7big('0 1 2 3 4 5 6 7 8 9','10 ta raqam — cheksiz sonlar',C.blue)},fin:function(){a7big('0 1 2 3 4 5 6 7 8 9','10 ta raqam — cheksiz sonlar',C.blue)},
 html:"<p>📜 Nol va o'nlik pozitsion yozuv <b>Hindistonda</b> paydo bo'lgan. IX asrda vatandoshimiz <b>Muhammad al-Xorazmiy</b> hind hisobi haqida kitob yozgan. U lotin tiliga tarjima qilinib, Yevropa shu yozuvni o'rgangan.</p><p>🔤 Lotincha tarjimada uning nomi «Algoritmi» deb yozilgan — bugungi <b>«algoritm»</b> so'zi shundan kelib chiqqan.</p><p>Shu sababli Yevropada bu raqamlar «arab raqamlari» deb ataladi.</p>",
 tn:"Loyiha nomi — «Yosh Xorazmiylar» — shu tarixga bog'liq ekanini aytib o'ting."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){w3table(4735,{top:'4·1000 + 7·100 + 3·10 + 5'})},fin:function(){w3table(4735,{top:'4·1000 + 7·100 + 3·10 + 5'})},
 html:"<div class='memo'><ul><li>Pozitsion yozuv: raqam qiymati <b>joyiga</b> bog'liq (333 = 300 + 30 + 3).</li><li>Asos — 10: har xona qo'shnisidan 10 marta katta.</li><li>4 735 = 4·1000 + 7·100 + 3·10 + 5.</li><li>O'ngdan 0 — 10 marta ortadi (37 → 370, +333).</li><li>Chapdan raqam — yangi katta xona (52 → 352, +300).</li><li>Eng kichik son: boshiga 0 qo'yilmaydi (3 057).</li></ul></div>",
 tn:"Keyingi bo'lim — og'zaki va yozma qo'shish-ayirish."}
];
function a7cards(res){clear();var g=S.g;['3','0','7','5'].forEach(function(d,i){var x=75+i*70;E('rect',{x:x-24,y:18,width:48,height:58,rx:8,fill:'#fff',stroke:C.blue,'stroke-width':2},g);T(g,x,58,d,{'font-size':30,'font-weight':800,fill:'#1d2b3a'})});if(res)T(g,180,130,res,{'font-size':36,'font-weight':800,fill:C.ok})}
var PROBS=[
{t:"555 sonidagi beshlarning qiymatlari:",o:["500, 50, 5","5, 5, 5","500, 500, 500","50, 5, 5"],k:0,s:"Har xonada boshqa qiymat."},
{t:"Bizning sanoq sistemasining asosi:",o:["10","2","100","9"],k:0,s:"10 birlik = 1 o'nlik."},
{t:"Minglar xonasining birligi o'nliklar xonasining birligidan necha marta katta?",o:["100","10","1 000","3"],k:0,s:"1 000 : 10 = 100."},
{t:"4 735 = ?",o:["4·1000 + 7·100 + 3·10 + 5","4 + 7 + 3 + 5","4·100 + 7·10 + 3 + 5","47·100 + 3·5"],k:0,s:"Har raqam × xona birligi."},
{t:"5 · 1 000 + 8 · 10 + 3 = ?",o:["5 083","583","5 803","5 830"],k:0,s:"Yuzliklar 0."},
{t:"6 · 1 000 + 2 · 10 = ?",o:["6 020","620","6 200","6 002"],k:0,s:"Yuzlik va birlik 0."},
{t:"37 ning o'ngidan 0 yozildi. Son qanchaga ortdi?",o:["333","10","370","300"],k:0,s:"370 − 37 = 333."},
{t:"Bir songa o'ngdan 0 yozilgach, u 450 ga ortdi. Dastlabki son:",o:["50","45","500","90"],k:0,s:"Farq = 9 · son = 450 → 50."},
{t:"52 ning chapidan 3 yozildi. Son qanchaga ortdi?",o:["300","30","3","352"],k:0,s:"352 − 52 = 300."},
{t:"418 ning chapidan 6 yozildi. Son qanchaga ortdi?",o:["6 000","600","6","6 418"],k:0,s:"6 418 − 418 = 6 000."},
{t:"3, 0, 7, 5 dan eng kichik to'rt xonali son:",o:["3 057","0 357","3 075","3 507"],k:0,s:"Boshiga 0 qo'yilmaydi."},
{t:"3, 0, 7, 5 dan yasalgan eng katta va eng kichik to'rt xonali sonlar ayirmasi:",o:["4 473","4 483","7 173","4 373"],k:0,s:"7 530 − 3 057 = 4 473."},
{t:"4, 0, 9, 1 dan eng kichik to'rt xonali son:",o:["1 049","0 149","1 094","1 409"],k:0,s:"1, 0, 4, 9."},
{t:"Qaysi yozuv pozitsion emas?",o:["XXX","333","4 735","1 000"],k:0,s:"Rimchada har X = 10, joyidan qat'i nazar."},
{t:"Sondagi 7 raqami o'nliklardan minglarga ko'chirildi (boshqa raqamlar 0). Qiymati necha marta ortdi?",o:["100","10","1 000","2"],k:0,s:"70 → 7 000: 100 marta."},
{t:"Ikki xonali sonning o'rtasiga 0 qo'yildi: 47 → 407. Son qanchaga ortdi?",o:["360","400","40","0"],k:0,s:"407 − 47 = 360."},
{t:"Qaysi sonda 5 raqami eng katta qiymatga ega?",o:["5 012","1 502","1 250","20 150"],k:0,s:"5 012 da 5 — minglar (5 000); 20 150 da — o'nlik."},
{t:"Bitta xonada eng ko'pi bilan qaysi raqam turishi mumkin?",o:["9","10","1","99"],k:0,s:"10 bo'lsa keyingi xonaga o'tadi."},
{t:"Uch xonali sonning o'ngidan ikkita 0 yozilsa, son necha marta ortadi?",o:["100","10","2","200"],k:0,s:"Raqamlar ikki xona chapga — ×100."},
{t:"23 o'nlik va 4 birlik pozitsion yozuvda:",o:["234","2 304","27","2 340"],k:0,s:"230 + 4 = 234."}
];
function PRACT_STAGE(){w3table(4735,{top:'4 735'})}
var PREP_DATA={teach:["Pozitsion va nopozitsion yozuv farqi; o'nlik sistema asosi — 10.","Sonni xona birliklari orqali yoyish.","Raqam qo'shilganda/surilganda son qanday o'zgarishi; kartochkalardan son yasash."],mist:["O'ngdan 0 yozilsa «10 ga ortdi» deydi (aslida 10 marta).","Chapdan raqam yozilganda uning qiymatini xato topadi.","Eng kichik sonni 0 bilan boshlaydi.","Yoyilmada xonalarni siljitadi."],need:["Raqam kartochkalari, o'nlik bloklar."],board:["<span class='w2'>XXX = 30, 333 = 300 + 30 + 3</span>.","<span class='w2'>1 → 10 → 100 → 1 000</span>.","<span class='w2'>4 735 = 4·1000 + 7·100 + 3·10 + 5</span>.","<span class='w2'>37 → 370 (+333), 52 → 352 (+300)</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
