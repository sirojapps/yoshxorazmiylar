var CODE='4J07',TITLE="4-sinf · Yosh masalalari";
var Y7='#7fb3e6',O7='#f2a65a',G7='#9ad0a0';
function y7TL(){clear();var g=S.g;k7L(30,100,330,100);[[60,'d yil oldin'],[220,'hozir']].forEach(function(p){k7L(p[0],92,p[0],108);T(g,p[0],124,p[1],{'font-size':12,'font-weight':800,fill:'#3a4a5a'})});
 T(g,60,60,'aka = ukaning hozirgi yoshi',{'font-size':11,'font-weight':700,fill:C.blue});T(g,60,78,'uka = 5',{'font-size':13,'font-weight':800,fill:C.bad});T(g,220,60,'aka = ?   uka = ?',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(g,220,78,'yig‘indi 34',{'font-size':12,'font-weight':700,fill:'#3a4a5a'})}
function k7L(a,b,c,d){E('line',{x1:a,y1:b,x2:c,y2:d,stroke:'#2a4a6a','stroke-width':2},S.g)}
var STEPS=[
J4({h:"«Men sening yoshingda bo'lganimda…»",sum:"Farq d. Aka ukaning hozirgi yoshida bo'lgan payt — d yil oldin; o'shanda uka 5. Uka = 5 + d, aka = 5 + 2d. 10 + 3d = 34 → d = 8 → aka 21.",a:"m01",
 s:y7TL,m:"«Sening yoshingda bo‘lganimda» — bu aynan farq qadar yil oldin",
 f:function(){j3Bars([{lab:'5 yoshda',parts:[[5,Y7,5]]},{lab:'Uka',parts:[[5,Y7,5],['d = 8',O7,8]],right:'13'},{lab:'Aka',parts:[[5,Y7,5],['d = 8',O7,8],['d = 8',O7,8]],right:'21'}],{u:9,y0:22,h:28,gap:14,x0:78})},fm:"5 + 5 + 3 · d = 34 → d = 8. Uka 13, aka 21",
 html:"<p>Aka ukasiga: «Men sening hozirgi yoshingda bo'lganimda, sen 5 yoshda eding». Ularning yoshlari yig'indisi 34. <b>Aka necha yoshda?</b></p>",
 ch:["21","13","17","26"],ok:0,bad:["","13 — ukaning yoshi","34 : 2 = 17 — teng bo‘lishsa shunday bo‘lardi","26 bo‘lsa uka 8, farq 18 — 18 yil oldin uka hali tug‘ilmagan"],
 after:"<p>Kalit: aka ukaning hozirgi yoshida bo'lgan payt — bundan <b>d yil oldin</b> (d — farq). O'shanda uka 5 yoshda. Demak uka = 5 + d, aka = 5 + 2d. Yig'indi: 10 + 3d = 34 → d = 8. Uka 13, aka <b>21</b>. Tekshirish: 8 yil oldin aka 13 (ukaning hozirgi yoshi), uka 5 ✓.</p>",
 q:{t:"Opa singlisiga: «Men sening yoshingda bo'lganimda, sen 2 yoshda eding». Opa 14 yoshda. Singil necha yoshda?",opts:["8","7","12","10"],ok:0,why:"Opa = 2 + 2d = 14 → d = 6, singil 2 + 6 = 8.",hint:"Opa = 2 + 2 · farq.",full:"Farq d: singil 2 + d, opa 2 + 2d = 14 → d = 6 → singil 8. 6 yil oldin: opa 8, singil 2 ✓. «7» — 14 : 2."},
 tn:"Doskada vaqt chizig'i: «d yil oldin — hozir». Uchta chiziq bilan Singapur modeli (5, d, d)."}),
J4({h:"Ko'paytma va farq",sum:"Aka-uka yoshlari ko'paytmasi 48, farqi 2: 48 = 6 · 8. Aka 8, uka 6.",a:"m02",
 s:['aka · uka = 48','aka − uka = 2'],so:{fs:20,lh:44},m:"48 ni ikki ko‘paytuvchiga ajratib ko‘ring",
 f:['48 = 1·48 = 2·24 = 3·16 = 4·12 = [6·8]','farqi 2: 8 − 6 = 2 ✓'],fso:{fs:15,lh:40},fm:"Juftlarni tartib bilan yozamiz — farqi 2 bo‘lganini tanlaymiz",
 html:"<p>Aka va ukaning yoshlari ko'paytmasi 48, aka ukadan 2 yosh katta. <b>Aka necha yoshda?</b></p>",
 ch:["8","6","12","24"],ok:0,bad:["","6 — ukaning yoshi","12 · 4 = 48, lekin farqi 8","24 · 2 = 48, farqi 22"],
 after:"<p>48 ni ko'paytuvchilarga ajratamiz: 1 · 48, 2 · 24, 3 · 16, 4 · 12, 6 · 8. Farqi 2 bo'lgani — 6 va 8. Aka <b>8</b>, uka 6. Tartibli ro'yxat hech bir juftni o'tkazib yubormaydi.</p>",
 q:{t:"Ikki opa-singil yoshlari ko'paytmasi 63, farqi 2. Kichigi necha yoshda?",opts:["7","9","3","21"],ok:0,why:"63 = 7 · 9.",hint:"63 ning ko'paytuvchilar juftlarini yozing.",full:"63 = 1·63 = 3·21 = 7·9. Farqi 2 — 7 va 9. Kichigi 7."},
 tn:"Ko'paytuvchilar juftini topishni ko'paytirish jadvali bilan bog'lang."}),
J4({h:"Bitta odam ikkitaga qarshi",sum:"Ona + qizlar = 50. 10 yilda ona +10, qizlar birga +20. Shunda teng bo'lsa: hozir ona qizlardan 10 ga katta → ona 30.",a:"m03",
 s:['ona + 2 qiz = 50','10 yildan keyin: ona = qizlar yig‘indisi'],so:{fs:17,lh:42},m:"10 yilda ona +10, ikki qiz birga +20",
 f:function(){j3Bars([{lab:'Qizlar',parts:[[20,Y7,10]],right:'+20'},{lab:'Ona',parts:[[20,Y7,10],[10,O7,5]],right:'+10'}],{u:9,y0:40,h:30,gap:22});j3Msg('Ona qizlardan 10 ga katta: (50 + 10) : 2 = <b>30</b>')},
 html:"<p>Ona va ikki qizining yoshlari yig'indisi 50. 10 yildan keyin onaning yoshi ikki qizining yoshlari yig'indisiga teng bo'ladi. <b>Ona hozir necha yoshda?</b></p>",
 ch:["30","25","40","20"],ok:0,bad:["","50 : 2 = 25 — hozir teng emas, 10 yildan keyin teng","40 bo‘lsa qizlar 10; 10 yilda 50 va 30","20 — qizlarning yig‘indisi"],
 after:"<p>10 yilda ona 10 ga, ikki qiz birgalikda 20 ga ulg'ayadi — farq 10 ga qisqaradi. Keyin teng bo'lsa, hozir ona qizlardan <b>10 ga</b> katta. Yig'indi 50, farq 10: ona (50 + 10) : 2 = 30, qizlar 20. Tekshirish: 40 = 20 + 20 ✓.</p>",
 q:{t:"Ota 40 yoshda, o'g'illari 12 va 8. Necha yildan keyin ota yoshi o'g'illari yoshlari yig'indisiga teng bo'ladi?",opts:["20","10","40","12"],ok:0,why:"Farq 40 − 20 = 20, har yili 1 ga qisqaradi.",hint:"Har yili ota +1, o'g'illar birga +2. Farq qanday o'zgaradi?",full:"Hozir farq 40 − 20 = 20. Har yili o'g'illar yig'indisi otadan 1 ta tezroq o'sadi → 20 yildan keyin: 60 = 32 + 28 ✓."},
 tn:"Jadval: yil | ona | qizlar yig'indisi | farq — farq har yili 1 ga qisqarishini bolalar o'zi ko'rsin."}),
J4({h:"Tug'ilgan yil bilan",sum:"Bobo 1950, nevara 2014 — farq 64. 5 marta katta → farq 4 qism → 1 qism 16 → nevara 16 yoshda: 2014 + 16 = 2030.",a:"m04",
 s:['bobo: 1950-yil','nevara: 2014-yil','qaysi yili bobo 5 marta katta?'],so:{fs:17,lh:36},m:"Avval farqni toping — u doim bir xil",
 f:function(){j3Bars([{lab:'Nevara',parts:[[16,Y7,4]],right:'16'},{lab:'Bobo',parts:[[16,Y7,4],[16,O7,4],[16,O7,4],[16,O7,4],[16,O7,4]],right:'80'}],{u:12,y0:40,h:30,gap:22});j3Msg('Farq 64 = 4 qism → 16. 2014 + 16 = <b>2030</b>')},
 html:"<p>Bobo 1950-yilda, nevarasi 2014-yilda tug'ilgan. <b>Qaysi yili</b> bobo nevarasidan 5 marta katta bo'ladi?</p>",
 ch:["2030","2026","2034","2016"],ok:0,bad:["","2026 da: 76 va 12 — 5 marta emas","2034 da: 84 va 20","16 — nevaraning yoshi, uni tug‘ilgan yilga qo‘shing"],
 after:"<p>Farq 2014 − 1950 = 64 yil. «5 marta katta» → farq 4 qism → 1 qism = 16. Nevara 16 yoshda bo'ladi: 2014 + 16 = <b>2030</b>. Tekshirish: bobo 80 = 5 · 16 ✓. Javob — yil, yosh emas: savolni oxirigacha o'qing!</p>",
 q:{t:"Ota 1990-yilda, o'g'li 2014-yilda tug'ilgan. Qaysi yili ota o'g'lidan 3 marta katta bo'ladi?",opts:["2026","2022","2030","2038"],ok:0,why:"Farq 24 = 2 qism → 12 → 2014 + 12 = 2026.",hint:"3 marta katta bo'lsa, farq necha qism?",full:"Farq 24. 3 marta → farq 2 qism → o'g'il 12 yoshda: 2026. Ota 36 = 3 · 12 ✓."},
 tn:"O'quvchilar o'z tug'ilgan yili va ota-onasiniki bilan shunday masala tuzsin."}),
J4({h:"Tuzoq: ikki xil vaqtdagi ikki shart",sum:"4 yil oldin opa 3 marta katta, 4 yildan keyin 2 marta. Farq o'zgarmaydi: 2 qism (o'tmish) = farq = 1 qism (kelajak). Singil 12, opa 28.",a:"m05",
 s:['4 yil oldin: opa = 3 · singil','4 yildan keyin: opa = 2 · singil'],so:{fs:17,lh:42},m:"Ikkala paytda ham farq bir xil!",
 f:function(){j3Bars([{lab:'4 yil oldin',parts:[[8,Y7,4],[16,O7,8]],right:'farq 16'},{lab:'4 yildan keyin',parts:[[16,Y7,8],[16,O7,8]],right:'farq 16'}],{u:9,y0:40,h:30,gap:22,x0:96});j3Msg('Singil 4 yil oldin 8, keyin 16: 8 + 4 = <b>12</b>')},
 html:"<p>4 yil oldin opa singlisidan 3 marta katta edi. 4 yildan keyin esa 2 marta katta bo'ladi. <b>Singil hozir</b> necha yoshda?</p>",
 ch:["12","8","16","28"],ok:0,bad:["","8 — 4 yil oldingi yoshi","16 — 4 yildan keyingi yoshi","28 — opaning hozirgi yoshi"],
 after:"<p>4 yil oldin: singil x, opa 3x, farq 2x. 4 yildan keyin: singil x + 8, opa 2 · (x + 8), farq x + 8. Farq o'zgarmaydi: 2x = x + 8 → x = 8. Singil hozir 8 + 4 = <b>12</b>, opa 24 + 4 = 28. Tekshirish: 32 = 2 · 16 ✓.</p>",
 q:{t:"3 yil oldin ota o'g'lidan 7 marta katta edi, hozir esa 4 marta katta. O'g'il hozir necha yoshda?",opts:["6","3","9","24"],ok:0,why:"o'g'il x, ota 4x: 4x − 3 = 7 · (x − 3) → x = 6.",hint:"Hozirgi yoshni x desak, ota 4x. 3 yil oldin-chi?",full:"4x − 3 = 7x − 21 → 3x = 18 → x = 6. Ota 24. 3 yil oldin 21 va 3: 7 marta ✓. «3» — o'shandagi yoshi."},
 tn:"Bu — eng qiyin turi. Ikki chiziqli chizmada farq bo'lagini bir xil uzunlikda chizish muhim."}),
J4({h:"Uch kishi, ikki farq",sum:"o'g'il x, ona x + 25, ota x + 29. 3x + 54 = 75 → x = 7. Ona 32, ota 36.",a:"m06",
 s:function(){j3Bars([{lab:'O‘g‘il',parts:[['?',Y7,4]]},{lab:'Ona',parts:[['?',Y7,4],[25,O7,10]]},{lab:'Ota',parts:[['?',Y7,4],[25,O7,10],[4,G7,2]],right:'jami 75'}],{u:9,y0:24,h:28,gap:14})},m:"Hammasini eng kichigi orqali ifodalaymiz",
 f:function(){j3Bars([{lab:'O‘g‘il',parts:[[7,Y7,4]]},{lab:'Ona',parts:[[7,Y7,4],[25,O7,10]],right:'32'},{lab:'Ota',parts:[[7,Y7,4],[25,O7,10],[4,G7,2]],right:'36'}],{u:9,y0:24,h:28,gap:14});j3Msg('75 − 25 − 25 − 4 = 21, 21 : 3 = <b>7</b>')},
 html:"<p>Ota, ona va o'g'ilning yoshlari yig'indisi 75. Ota onadan 4 yosh katta, ona o'g'lidan 25 yosh katta. <b>O'g'il</b> necha yoshda?</p>",
 ch:["7","9","12","25"],ok:0,bad:["","9 bo‘lsa: 9 + 34 + 38 = 81","75 : 3 = 25 dan boshlash xato — ular teng emas","25 — ona va o‘g‘il orasidagi farq"],
 after:"<p>Eng kichigini bitta bo'lak deb olamiz. Ona = bo'lak + 25, ota = bo'lak + 25 + 4. Ortiqchalarni ayiramiz: 75 − 25 − 29 = 21 — bu uchta teng bo'lak → 1 bo'lak = <b>7</b>. Ona 32, ota 36: 7 + 32 + 36 = 75 ✓.</p>",
 q:{t:"Uch aka-uka: har biri keyingisidan 3 yosh katta, yoshlari yig'indisi 30. Eng kattasi necha yoshda?",opts:["13","10","7","16"],ok:0,why:"O'rtanchasi 30 : 3 = 10, kattasi 13.",hint:"O'rtanchasi qancha bo'ladi?",full:"Kichigi x, o'rtanchasi x + 3, kattasi x + 6: 3x + 9 = 30 → x = 7. Kattasi 13. «10» — o'rtanchasi."},
 tn:"Chizmada bir xil «?» bo'laklarni bir rangda bo'yatib, ortiqchalarni boshqa rangda ko'rsating."}),
J4info({h:"Bilasizmi? Eng uzoq umr",a:"m07",s:['1875 → 1997','122 yil 164 kun'],so:{fs:20,lh:44},m:"Hujjatlar bilan tasdiqlangan eng uzoq umr",
 html:"<p>🎂 Hujjatlar bilan tasdiqlangan eng uzoq umr ko'rgan inson — fransuz ayoli <b>Janna Kalman</b>: u 1875-yil 21-fevralda tug'ilib, 1997-yil 4-avgustda vafot etgan, ya'ni 122 yil 164 kun yashagan. Yoshni aniq hisoblash uchun nafaqat yillar, balki oylar va kunlar ham kerak bo'ladi — tug'ilgan kun hali kelmagan bo'lsa, yosh bittaga kam bo'ladi.</p>",
 tn:"Bolalar o'z yoshini kunlarda hisoblasin (yillar · 365 + kabisa yillari + qolgan kunlar)."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:function(){j3Bars([{lab:'Singil',parts:[[8,Y7,4]]},{lab:'Opa',parts:[[8,Y7,4],[16,O7,8]],right:'farq'}],{u:10,y0:50,h:30,gap:22})},m:"Farq — doim bir xil",
 html:"<div class='memo'><ul><li>Farq o'zgarmaydi; yig'indi har yili odamlar soniga oshadi.</li><li>«Sening yoshingda bo'lganimda» → farq qadar yil oldin.</li><li>«n marta katta» → farq = n − 1 qism.</li><li>Ikki paytdagi ikki shart: farqni ikkala paytda tenglang.</li><li>Uch kishi: hammasini eng kichigi orqali yozing.</li><li>Javob — yoshmi, yilmi, necha yil keyinmi? Savolni qayta o'qing.</li></ul></div>",
 tn:"Uyga: oiladagi uch kishi yoshlari bilan «uch kishi, ikki farq» masalasini tuzib kelish."})
];
var PROBS=[
{t:"Aka 15, uka 9 yoshda. Aka 30 ga kirganda uka necha yoshda bo'ladi?",o:["24","18","30","15"],k:0,s:"Farq 6: 30 − 6 = 24."},
{t:"Ota va o'g'il yoshlari yig'indisi 50. 5 yildan keyin yig'indi qancha bo'ladi?",o:["60","55","50","65"],k:0,s:"Ikki kishi, har biriga 5: 50 + 10 = 60."},
{t:"Ona va qizi yoshlari yig'indisi 48, ona 24 yosh katta. Qizi necha yoshda?",o:["12","24","36","18"],k:0,s:"(48 − 24) : 2 = 12."},
{t:"Ota o'g'lidan 4 marta katta, farqi 30 yosh. O'g'il necha yoshda?",o:["10","40","30","15"],k:0,s:"4 marta → farq 3 qism: 30 : 3 = 10."},
{t:"Bobo 70, nevara 10 yoshda. Necha yil oldin bobo nevarasidan 13 marta katta edi?",o:["5","10","13","4"],k:0,s:"Farq 60 = 12 qism → 5. Nevara 5 yoshda edi: 5 yil oldin."},
{t:"Opa 14, singil 8 yoshda. Necha yildan keyin yoshlari yig'indisi 40 bo'ladi?",o:["9","18","4","26"],k:0,s:"Hozir 22, har yili +2: 18 : 2 = 9."},
{t:"Uch farzand yoshlari yig'indisi 21. 5 yil oldin hammasi tug'ilgan edi. O'shanda yig'indi qancha edi?",o:["6","16","11","15"],k:0,s:"21 − 3 · 5 = 6."},
{t:"Aka ukasiga: «Men sening yoshingda bo'lganimda sen 3 yoshda eding». Aka 15 yoshda. Uka necha yoshda?",o:["9","12","6","7"],k:0,s:"Aka = 3 + 2 · farq = 15 → farq 6, uka 9."},
{t:"Aka-uka yoshlari ko'paytmasi 72, aka 1 yosh katta. Aka necha yoshda?",o:["9","8","12","6"],k:0,s:"72 = 8 · 9."},
{t:"Ona 33 yoshda, qizlari 7 va 4 yoshda. Necha yildan keyin ona yoshi qizlari yoshlari yig'indisiga teng bo'ladi?",o:["22","11","33","18"],k:0,s:"Farq 33 − 11 = 22, har yili 1 ga qisqaradi: 22 yil."},
{t:"Ota 1985-yilda, o'g'li 2013-yilda tug'ilgan. Qaysi yili ota o'g'lidan 3 marta katta bo'ladi?",o:["2027","2022","2041","2020"],k:0,s:"Farq 28 = 2 qism → o'g'il 14: 2013 + 14 = 2027."},
{t:"4 yil oldin opa singlisidan 3 marta katta edi, 4 yildan keyin 2 marta katta bo'ladi. Opa hozir necha yoshda?",o:["28","12","24","32"],k:0,s:"2x = x + 8 → x = 8 (4 yil oldin singil). Opa o'shanda 24, hozir 28."},
{t:"3 yil oldin ota o'g'lidan 7 marta katta edi, hozir 4 marta katta. Ota hozir necha yoshda?",o:["24","21","28","6"],k:0,s:"4x − 3 = 7 · (x − 3) → x = 6, ota 24."},
{t:"Ota, ona, o'g'il yoshlari yig'indisi 75. Ota onadan 4 yosh katta, ona o'g'ildan 25 yosh katta. Ota necha yoshda?",o:["36","32","7","29"],k:0,s:"O'g'il 7, ona 32, ota 36."},
{t:"Egizaklar va ularning opasi yoshlari yig'indisi 34. Opa egizaklardan 4 yosh katta. Opa necha yoshda?",o:["14","10","12","15"],k:0,s:"3x + 4 = 34 → x = 10, opa 14."},
{t:"Ali 10, Vali 4 yoshda. Necha yildan keyin Ali Validan 2 marta katta bo'ladi?",o:["2","6","3","4"],k:0,s:"Farq 6 = 1 qism → Vali 6: 2 yildan keyin."},
{t:"Ota o'g'lidan 3 marta katta. 12 yildan keyin 2 marta katta bo'ladi. O'g'il hozir necha yoshda?",o:["12","24","36","6"],k:0,s:"Farq 2x = x + 12 → x = 12."},
{t:"«Men tug'ilganimda onam 26 yoshda edi. Hozir yoshlarimiz yig'indisi 40». Men necha yoshdaman?",o:["7","14","33","13"],k:0,s:"x + x + 26 = 40 → x = 7."},
{t:"«Bir yildan keyin men 2 yil oldingi yoshimdan 2 marta katta bo'laman». Men hozir necha yoshdaman?",o:["5","3","4","6"],k:0,s:"x + 1 = 2 · (x − 2) → x = 5: 6 = 2 · 3 ✓."},
{t:"Bobom 1951-yilda, men 2014-yilda tug'ilganman. Qaysi yili bobom mendan 8 marta katta bo'lgan?",o:["2023","2021","2022","2018"],k:0,s:"Farq 63 = 7 qism → 9 yosh: 2014 + 9 = 2023."}
];
function PRACT_STAGE(){j3Bars([{lab:'Uka',parts:[[13,Y7,13]]},{lab:'Aka',parts:[[13,Y7,13],[8,O7,8]]}],{u:8,y0:50,h:30,gap:22})}
var PREP_DATA={teach:["«Sening yoshingda bo'lganimda» masalasi.","Ko'paytma va farq bo'yicha juftlarni tanlash.","Bitta odam ikkitaga qarshi: farqning qisqarishi.","Tug'ilgan yil bilan masalalar.","Ikki paytdagi ikki shart."],
 mist:["Yil o'rniga yoshni (yoki aksincha) javob deb yozadi.","«n marta» da farqni n qismga bo'ladi.","Yig'indidagi o'zgarishni odamlar soniga ko'paytirmaydi."],
 need:["Qog'oz lentalar (chizma model).","Vaqt chizig'i uchun uzun qog'oz."],
 board:["sening yoshingda → d yil oldin","n marta → farq = n − 1 qism","1 kishi vs 2 kishi: farq har yili −1","farq(o'tmish) = farq(kelajak)"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
