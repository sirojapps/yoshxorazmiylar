var CODE='2H11',TITLE="2-sinf · Fazoviy tasavvur: kublar, yoyilmalar";
function hBMsg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// izometrik kublar: list [[x,y,z],...]
function hBCubes(list,o){o=o||{};clear();var g=S.g,s=o.s||22,ox=o.ox||180,oy=o.oy||120;
 function P(x,y,z){return [ox+(x-y)*s*.87,oy-z*s+(x+y)*s*.5]}
 var L=list.slice().sort(function(a,b){return (a[0]+a[1])-(b[0]+b[1])||a[2]-b[2]});
 L.forEach(function(c){var x=c[0],y=c[1],z=c[2],col=c[3];var a=P(x,y,z+1),b=P(x+1,y,z+1),cc=P(x+1,y+1,z+1),d=P(x,y+1,z+1),e=P(x+1,y,z),f=P(x+1,y+1,z),h=P(x,y+1,z);
  function poly(pts,fill){E('path',{d:'M'+pts.map(function(p){return p[0]+' '+p[1]}).join(' L')+' Z',fill:fill,stroke:'#6b3d12','stroke-width':1.1},g)}
  poly([a,b,cc,d],col?col[0]:'#f6c98a');poly([b,e,f,cc],col?col[1]:'#d9954a');poly([d,cc,f,h],col?col[2]:'#e8ad62')});
 return P}
var CUBE=[[0,0,0]];
function hBOne(mode){var P=hBCubes([[0,0,0]],{s:70,ox:180,oy:70});var g=S.g;
 var V=[[0,0,1],[1,0,1],[1,1,1],[0,1,1],[1,0,0],[1,1,0],[0,1,0]].map(function(v){return P(v[0],v[1],v[2])});
 if(mode==='uch')V.forEach(function(p){E('circle',{cx:p[0],cy:p[1],r:6,fill:C.bad,stroke:'#fff','stroke-width':2},g)});
 if(mode==='qirra'){var E2=[[0,1],[1,2],[2,3],[3,0],[1,4],[4,5],[5,2],[3,6],[6,5]];E2.forEach(function(e){E('line',{x1:V[e[0]][0],y1:V[e[0]][1],x2:V[e[1]][0],y2:V[e[1]][1],stroke:C.blue,'stroke-width':4},g)})}
 if(mode==='yog')T(g,180,40,'1',{'font-size':16,'font-weight':800,fill:'#fff'})}
var P4=[function(){hBCubes([[0,0,0],[0,0,1],[0,0,2]],{s:34,oy:132});hBMsg('3 ta kub ustma-ust. Har kubda 6 yog‘: 3 · 6 = 18')},
 function(){hBCubes([[0,0,0,['#f6c98a','#d9954a','#e8ad62']],[0,0,1],[0,0,2]],{s:34,oy:132});E('ellipse',{cx:180,cy:150,rx:70,ry:12,fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 3'},S.g);hBMsg('Pastki yog‘ stolga tegib turibdi — 1 ta yopiq')},
 function(){hBCubes([[0,0,0],[0,0,1],[0,0,2]],{s:34,oy:132});[98,64].forEach(function(y){E('line',{x1:150,y1:y,x2:210,y2:y,stroke:C.bad,'stroke-width':4},S.g)});hBMsg('Kublar orasida 2 ta tutashuv, har birida 2 ta yog‘ yopiq — 4 ta. Ochiq: 18 − 1 − 4 = <b>13</b>')}];
var NETS=[ // har biri: [ustun,qator] kataklar
 {c:[[1,0],[0,1],[1,1],[2,1],[1,2],[1,3]],ok:1},{c:[[0,0],[1,0],[2,0],[0,1],[1,1],[2,1]],ok:0},{c:[[0,0],[1,0],[2,0],[3,0],[4,0],[5,0]],ok:0},{c:[[0,0],[1,0],[1,1],[2,1],[2,2],[3,2]],ok:1}];
function hBNets(sel){clear();var g=S.g,s=12;NETS.forEach(function(n,i){var ox=14+i*88,oy=40;E('rect',{x:ox-6,y:14,width:82,height:128,rx:8,fill:sel===i?(n.ok?'#e6f6ee':'#fdeaea'):'#fff',stroke:'#c9d3dd'},g);
  n.c.forEach(function(p){E('rect',{x:ox+p[0]*s,y:oy+p[1]*s,width:s,height:s,fill:'#f6c98a',stroke:'#6b3d12','stroke-width':1},g)});T(g,ox+35,156,String.fromCharCode(65+i),{'font-size':14,'font-weight':800});
  var hit=E('rect',{x:ox-6,y:14,width:82,height:150,fill:'transparent',style:'cursor:pointer'},g);hit.addEventListener('click',function(){if(S.netTap)S.netTap(i)})})}
var P5=[function(){hBNet(0);hBMsg('Kubni qirralaridan qirqib, tekislikka yoyamiz — <b>yoyilma</b>')},function(){hBNet(1);hBMsg('Yoyilmada 6 ta kvadrat — kubning 6 ta yog‘i')},function(){hBNet(2);hBMsg('Bir qatorda uchta kvadratning chetkilari — <b>qarama-qarshi</b> yog‘lar: 1 va 3, 2 va 4… ')}];
function hBNet(k){clear();var g=S.g,s=30,ox=120,oy=20;var c=[[1,0,'5'],[0,1,'2'],[1,1,'1'],[2,1,'4'],[1,2,'6'],[1,3,'3']];
 c.forEach(function(p){var hl=k>=2&&(p[2]==='5'||p[2]==='6');E('rect',{x:ox+p[0]*s,y:oy+p[1]*s,width:s,height:s,fill:hl?'#ffd24d':(k>=1?'#f6c98a':'#f2d9b4'),stroke:'#6b3d12','stroke-width':1.4},g);if(k>=1)T(g,ox+p[0]*s+s/2,oy+p[1]*s+s/2+5,p[2],{'font-size':14,'font-weight':800})});
 if(k>=2){T(g,280,70,'5 va 6 — qarama-qarshi',{'font-size':11,'font-weight':800,fill:C.blue});T(g,280,88,'(orasida bitta kvadrat)',{'font-size':10,fill:C.blue})}}
var STEPS=[
{h:"Kubni tanishamiz: yog', qirra, uch",sum:"Kubda 6 ta yog', 12 ta qirra, 8 ta uch bor.",a:"m01",
 start:function(){hBOne('');hBMsg('Tugmalarni bosib, kubning qismlarini ko‘ring')},fin:function(){hBOne('uch');hBMsg('Kub: 6 yog‘, 12 qirra, 8 uch')},
 html:"<p>Kub — o'yin kubigi, muz bo'lagi kabi shakl. Uning qismlarini ko'raylik:</p>",
 btns:[["Yog'lar",function(c,done){hBOne('yog');hBMsg('<b>Yog‘</b> — kvadrat sirt. Kubda <b>6 ta</b>: 3 tasi ko‘rinadi, 3 tasi orqada');mvK(done,3)}],["Qirralar",function(c,done){hBOne('qirra');hBMsg('<b>Qirra</b> — ikki yog‘ tutashgan chiziq. Ko‘rinadi 9 ta, jami <b>12 ta</b>');mvK(done,3)}],["Uchlar",function(c,done){hBOne('uch');hBMsg('<b>Uch</b> — burchak nuqta. Ko‘rinadi 7 ta, jami <b>8 ta</b>');mvK(done,3)}]],g3:1,
 after:"<p>Rasmda kubning hammasi ko'rinmaydi — <b>orqa</b> tomoni yashirin. Shuning uchun haqiqiy kubni qo'lda aylantirib sanash eng yaxshi: 6 yog', 12 qirra, 8 uch.</p>",
 q:{t:"Kubning har bir yog'i boshqa rangga bo'yaldi. Nechta rang ishlatilgan?",opts:["4","6","8","12"],ok:1,why:"Kubda 6 ta yog'.",hint:"Kubda nechta yog' bor?",full:"Kubning 6 ta yog'i bor — 6 ta rang. 12 — qirralar, 8 — uchlar soni."},
 tn:"Har bolaga qog'oz kub yoki o'yin kubigi bering — yog', qirra, uchlarni barmoq bilan sanasin."},
{h:"Minora quramiz",sum:"Zinapoya 1 + 2 + 3 = 6 kub. Har ustunni alohida sanang.",a:"m02",
 start:function(){S.nb=0;hBStair(0)},fin:function(){hBStair(6)},
 html:"<p>Kubiklardan zinapoya quramiz: birinchi ustunda 1 ta, ikkinchisida 2 ta, uchinchisida 3 ta. Kub qo'shing:</p>",
 btns:[["+ kub",function(c,done){if(S.nb<6){S.nb++;hBStair(S.nb);if(S.nb===6)done()}},'u']],
 after:"<p>Rasmdagi kublarni sanashning ishonchli usuli — <b>ustunma-ustun</b>: 1 + 2 + 3 = <b>6</b>. Faqat ko'ringan yog'larni sanab qo'ymang!</p>",
 q:{t:"Minorada 4 ta ustun bor: 1, 2, 3 va 4 kubdan. Jami nechta kub?",opts:["4","10","8","12"],ok:1,why:"1 + 2 + 3 + 4 = 10.",hint:"Har ustundagi kublarni qo'shing.",full:"Ustunlar: 1 + 2 + 3 + 4 = 10 kub."},
 tn:"Bolalar o'zi kubikdan qurib, keyin rasm bo'yicha qurilganini taqqoslasin."},
{h:"Ko'rinmaydigan kublar",sum:"Piramida: pastda 3×3 = 9, o'rtada 2×2 = 4, tepada 1 — jami 14. Ichkaridagilarni ham sanang.",a:"m03",
 start:function(){hBPyr(1)},fin:function(){hBPyr(3)},
 html:"<p>Usta kublardan piramida yasadi: pastki qavat 3 qator 3 tadan, o'rta qavat 2 qator 2 tadan, tepada 1 ta. Qavatma-qavat quring:</p>",
 btns:[["+ qavat",function(c,done){S.pq=(S.pq||1)+1;if(S.pq>3)S.pq=3;hBPyr(S.pq);if(S.pq===3)done()},'u']],
 after:"<p>Rasmda ko'p kublar <b>yashirin</b> — ular ustidagi kublar ostida. Qavatlab sanaymiz: 9 + 4 + 1 = <b>14</b>. Rasmdagi ko'ringan yuzlarni sanash xato javob beradi.</p>",
 q:{t:"Kublardan to'g'ri to'rtburchakli quti yasaldi: pastki qavatda 5 × 3 kub, 4 ta qavat. Jami nechta kub?",opts:["12","20","15","60"],ok:3,why:"Bir qavat 5 · 3 = 15, 4 qavat: 15 · 4 = 60.",hint:"Avval bitta qavatdagi kublarni sanang.",full:"Bir qavat: 5 · 3 = 15 kub. 4 ta bunday qavat: 15 + 15 + 15 + 15 = 60."},
 tn:"Qand kublaridan qavatlab qurish — eng arzon va tushunarli material."},
{h:"Tuzoq: ochiq yog'lar",sum:"3 ta kub ustma-ust: 18 yog'dan pastki 1 va tutashgan 4 yopiq → 13 ochiq.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p><i>«Uchta bir xil kub stol ustida ustma-ust qo'yildi. Minoraning nechta yog'i ochiq — stolga ham, boshqa kubga ham tegmaydi?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Hamma yog'lar: 3 · 6 = 18. Yopiqlari: stoldagi 1 ta va har ikki kub tutashgan joyda <b>2 tadan</b> (pastdagining tepasi va ustidagining osti): 2 · 2 = 4. Ochiq: 18 − 5 = <b>13</b>.</p>",
 q:{t:"2 ta kub ustma-ust stolda turibdi. Nechta yog' ochiq?",opts:["12","10","9","11"],ok:2,why:"12 − 1 (stol) − 2 (tutashuv) = 9.",hint:"Jami yog'lar 12. Nechta yog' yashirin?",full:"2 kub — 12 yog'. Yopiq: stolga tekkan 1 ta va tutashgan 2 ta. Ochiq: 12 − 3 = 9."},
 tn:"Kubiklarni ustma-ust qo'yib, yopishgan yog'lariga stiker yopishtiring — yashirin yog'lar ko'rinadi."},
{h:"Kubning yoyilmasi",sum:"Kubni qirralaridan qirqib yoysak — 6 kvadratdan iborat yoyilma. Bir qatordagi uchtaning chetkilari qarama-qarshi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Karton qutini qirralari bo'ylab qirqib, stolga tekis yoyib qo'ysak nima bo'ladi? Kuzating:</p>",
 btns:[phaser(P5)],
 after:"<p>Yoyilmani qayta buklasak, kub hosil bo'ladi. Muhim sir: yoyilmada bir qatorda turgan uchta kvadratning <b>chetkilari</b> kubda <b>qarama-qarshi</b> yog'lar bo'ladi (o'yin kubigida ular yig'indisi 7: 1–6, 2–5, 3–4).</p>",
 q:{t:"Kub yoyilmasida bir qatorda 3 ta kvadrat: A, B, C (B — o'rtada). Kubda A ning qarshisida qaysi yog'?",opts:["B","C","yonidagi","hech biri"],ok:1,why:"Bir qatordagi uchtaning chetkilari qarama-qarshi.",hint:"O'rtadagi B kubning bir yog'i bo'ladi. A va C qayerga buklanadi?",full:"A va C B ning ikki tomoniga buklanib, bir-biriga qarama-qarshi bo'ladi. B esa A ga qo'shni."},
 tn:"Qog'ozdan xoch shaklidagi yoyilmani kesib, buklab kub yasang — yog'larni raqamlab, qarama-qarshilarini toping."},
{h:"Qaysi yoyilmadan kub chiqadi?",sum:"6 kvadrat ham har doim kub bermaydi: 2×3 to'rtburchak yoki 6 tasi bir qatorda — kub chiqmaydi.",a:"m06",
 start:function(){hBNets(-1);S.netTap=function(i){hBNets(i);var n=NETS[i];hBMsg(n.ok?'<b>'+String.fromCharCode(65+i)+'</b> — buklasa kub chiqadi ✓':'<b>'+String.fromCharCode(65+i)+'</b> — kub chiqmaydi: '+(i===1?'buklaganda yog‘lar ustma-ust tushadi':'bir qatorda 4 tadan ortiq kvadrat — aylanib o‘ziga tushadi'));S.nT=S.nT||{};S.nT[i]=1;if(Object.keys(S.nT).length>=3&&S.dN){var d=S.dN;S.dN=null;d()}};hBMsg('Yoyilmalarni bosib tekshiring')},fin:function(){hBNets(0);hBMsg('A va D — kub yoyilmasi')},
 html:"<p>To'rtta shaklda ham 6 tadan kvadrat bor. Qaysilaridan kub yasash mumkin? Har birini bosing (kamida 3 tasini):</p>",
 act:function(c,done){S.nT={};S.dN=done;c.querySelector('.hint').textContent='Rasmdagi yoyilmalarni bosing.'},
 after:"<p>Kub chiqishi uchun: bir qatorda <b>4 tadan ko'p</b> kvadrat bo'lmasligi va buklaganda ikki kvadrat <b>bir joyga</b> tushmasligi kerak. A (xoch) va D (zinapoya) — kub beradi; B (2×3) va C (6 tasi qatorda) — bermaydi.</p>",
 q:{t:"Quyidagilardan qaysi biri kub yoyilmasi BO'LA OLMAYDI?",opts:["xoch shaklidagi 6 kvadrat","6 kvadrat bir qatorda","T shaklidagi 4 + 1 + 1 (yuqori va pastda)","zinapoya shaklidagi 6 kvadrat"],ok:1,why:"6 tasi bir qatorda — buklaganda 5- va 6-kvadrat 1- va 2-ning ustiga tushadi.",hint:"Bir qatorda nechta kvadrat bo'lsa, ular kub atrofida aylanib o'ziga qaytadi?",full:"Kub atrofini 4 ta yog' o'raydi. 6 tasi bir qatorda bo'lsa, 5- va 6-kvadrat birinchilarining ustiga tushib qoladi — kub yopilmaydi."},
 tn:"Kub yoyilmasining jami 11 xil turi bor. Bolalar katakli qog'ozda o'zlari topib, kesib, buklab tekshirsin."},
{h:"Tuzoq: bo'yalgan katta kub",sum:"2×2×2 kub 8 ta kubchadan; sirti bo'yalsa, har kubchaning 3 ta yog'i bo'yalgan bo'ladi (hammasi burchakda).",a:"m07",
 start:function(){hBBig(false)},fin:function(){hBBig(true)},
 html:"<p>8 ta kubchadan 2×2×2 katta kub yasaldi va uning <b>tashqi</b> tomoni bo'yaldi. Keyin kubchalar ajratildi. Har bir kubchaning nechta yog'i bo'yalgan?</p>",
 btns:[["🔍 Ajratib ko'rish",function(c,done,b){b.disabled=true;hBBig(true);done()}]],
 after:"<p>2×2×2 kubda har bir kubcha <b>burchakda</b> turadi — burchakda 3 ta yog' tashqariga qaraydi. Demak, har birida <b>3 ta</b> bo'yalgan, <b>3 ta</b> bo'yalmagan yog' bor.</p>",
 q:{t:"Qand kubiklaridan 2 × 2 × 2 kub yasaldi (8 ta kubik). Ichkarida (ko'rinmaydigan) nechta kubik bor?",opts:["1","0","2","4"],ok:1,why:"2×2×2 da hamma kubik chetda — ichkarida hech biri yo'q.",hint:"Har bir kubik tashqi tomonga tegib turibdimi?",full:"2×2×2 kubda har bir kubik burchakda, hammasi tashqariga chiqib turadi. Ichki kubik yo'q — 0. (3×3×3 kubda esa ichkarida 1 ta bo'ladi.)"},
 tn:"Kuchli bolalar uchun: 3×3×3 kubda nechta kubchaning 3, 2, 1 va 0 yog'i bo'yalgan? (8, 12, 6, 1)."},
{h:"Bilasizmi? Rubik kubi",sum:"Rubik kubini 1974-yilda vengriyalik Erne Rubik ixtiro qilgan — dunyodagi eng mashhur jumboq.",a:"m08",
 start:function(){hBRubik()},fin:function(){hBRubik()},
 html:"<p>🧩 <b>Rubik kubi</b>ni 1974-yilda Vengriyalik arxitektor <b>Erne Rubik</b> o'quvchilariga fazoviy tasavvurni tushuntirish uchun ixtiro qilgan. U dunyodagi eng ko'p sotilgan jumboq o'yinchoqlardan biriga aylandi.</p><p>⏱ Eng tez yechuvchilar uni 5 soniyadan ham kam vaqtda yig'a oladi!</p>",
 tn:"Sinfda Rubik kubi bo'lsa, bolalarga faqat bitta tomonini yig'ishni o'rgatish — ajoyib fazoviy mashq."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){hBOne('uch');hBMsg('6 yog‘, 12 qirra, 8 uch')},fin:function(){hBOne('uch');hBMsg('6 yog‘, 12 qirra, 8 uch')},
 html:"<div class='memo'><ul><li>Kub: <b>6</b> yog', <b>12</b> qirra, <b>8</b> uch.</li><li>Rasmdagi kublarni <b>ustunma-ustun</b> yoki <b>qavatma-qavat</b> sanang — yashirinlarini unutmang.</li><li>Quti: bir qavat × qavatlar soni (5 · 3 · 4 = 60).</li><li>Ochiq yog'lar: jami − stoldagi − tutashganlar (har tutashuvda 2 ta).</li><li>Yoyilmada bir qatordagi 3 ta kvadratning chetkilari — qarama-qarshi.</li><li>6 kvadrat bir qatorda yoki 2×3 — kub yoyilmasi emas.</li><li>2×2×2 kubda har kubchaning 3 yog'i tashqarida.</li></ul></div>",
 tn:"Keyingi darsni «Gugurt qutisining nechta qirrasi bor?» savoli bilan boshlang (12)."}
];
function hBStair(n){var L=[],cols=[[0,1],[1,2],[2,3]],k=0;for(var i=0;i<3;i++)for(var z=0;z<cols[i][1];z++){if(k<n)L.push([i,0,z]);k++}hBCubes(L,{s:28,ox:150,oy:140});hBMsg('Kublar: <b>'+n+'</b>'+(n===6?' = 1 + 2 + 3':''))}
function hBPyr(q){var L=[];for(var x=0;x<3;x++)for(var y=0;y<3;y++)L.push([x,y,0]);if(q>=2)for(var x2=0;x2<2;x2++)for(var y2=0;y2<2;y2++)L.push([x2,y2,1]);if(q>=3)L.push([0,0,2]);S.pq=q;hBCubes(L,{s:24,ox:180,oy:100});hBMsg('Qavatlar: '+[9,4,1].slice(0,q).join(' + ')+' = <b>'+[9,13,14][q-1]+'</b> kub')}
function hBBig(split){var L=[];for(var x=0;x<2;x++)for(var y=0;y<2;y++)for(var z=0;z<2;z++)L.push([x*(split?1.5:1),y*(split?1.5:1),z*(split?1.5:1),['#e85a5a','#c94a4a','#d95454']]);hBCubes(L,{s:split?24:30,ox:180,oy:split?92:110});hBMsg(split?'Har kubchada 3 ta qizil (bo‘yalgan) yog‘ — hammasi burchakda':'2 × 2 × 2 = 8 ta kubcha, tashqarisi bo‘yalgan')}
function hBRubik(){var cols=[['#e85a5a','#5aa9e6','#ffd54d'],['#4caf72','#e85a5a','#ffffff'],['#ffd54d','#f0a040','#5aa9e6']],L=[];for(var x=0;x<3;x++)for(var y=0;y<3;y++)for(var z=0;z<3;z++)L.push([x,y,z,[cols[(x+z)%3][0],cols[(y+z)%3][1],cols[(x+y)%3][2]]]);hBCubes(L,{s:22,ox:180,oy:96});hBMsg('3 × 3 × 3 — 27 ta kubcha')}
var PROBS=[
{t:"Kubning nechta uchi bor?",o:["8","6","12","4"],k:0,s:"Kubda 8 ta uch."},
{t:"Kubning nechta qirrasi bor?",o:["12","8","6","10"],k:0,s:"12 ta qirra."},
{t:"Kubning har yog'i boshqa rangga bo'yaldi. Nechta rang?",o:["6","4","8","12"],k:0,s:"6 ta yog'."},
{t:"Zinapoya: ustunlarda 1, 2, 3, 4 kub. Jami?",o:["10","4","8","12"],k:0,s:"1 + 2 + 3 + 4 = 10."},
{t:"Piramida: pastda 3×3, o'rtada 2×2, tepada 1 kub. Jami?",o:["14","9","13","6"],k:0,s:"9 + 4 + 1 = 14."},
{t:"Quti 1 sm li kubiklar bilan to'la: pastki qatlamda 5 × 3, 4 ta qatlam. Nechta kubik?",o:["60","12","20","15"],k:0,s:"15 · 4 = 60."},
{t:"3 ta kub ustma-ust stolda. Nechta yog' ochiq?",o:["13","18","14","12"],k:0,s:"18 − 1 − 4 = 13."},
{t:"2 ta kub ustma-ust stolda. Nechta yog' ochiq?",o:["9","12","10","11"],k:0,s:"12 − 1 − 2 = 9."},
{t:"Kub yoyilmasida bir qatorda A, B, C (B o'rtada). A ning qarshisida qaysi yog'?",o:["C","B","yonidagi","yo'q"],k:0,s:"Chetkilari qarama-qarshi."},
{t:"Qaysi biri kub yoyilmasi BO'LA OLMAYDI?",o:["6 kvadrat bir qatorda","xoch shakli","zinapoya shakli","T shaklidagi 4 + 1 + 1"],k:0,s:"6 tasi qatorda — ustma-ust tushadi."},
{t:"O'yin kubigida qarama-qarshi yog'lar yig'indisi 7. 2 ning qarshisida qaysi son?",o:["5","4","6","3"],k:0,s:"7 − 2 = 5."},
{t:"2 × 2 × 2 kubda ichki (ko'rinmaydigan) kubchalar nechta?",o:["0","1","2","8"],k:0,s:"Hammasi chetda."},
{t:"3 × 3 × 3 kubda ichki (ko'rinmaydigan) kubcha nechta?",o:["1","0","9","27"],k:0,s:"Faqat markazdagi bitta."},
{t:"Kub stolda turibdi. Nechta yog'i ko'rinmaydi (stolga tegib turgani)?",o:["1","3","2","0"],k:0,s:"Faqat pastki yog'."},
{t:"Gugurt qutisining (to'g'ri burchakli parallelepiped) nechta yog'i bor?",o:["6","4","8","12"],k:0,s:"Kub kabi 6 ta yog'."},
{t:"Kubning nechta yog'i bir vaqtda ko'rinishi mumkin (bitta qarashda)?",o:["3","2","4","6"],k:0,s:"Ko'pi bilan 3 ta."},
{t:"Ikki ustunli minorada 5 va 2 kub. Ikkalasi teng bo'lishi uchun past ustunga nechta kub qo'shish kerak?",o:["3","2","7","5"],k:0,s:"5 − 2 = 3."},
{t:"Kubning bitta uchida nechta qirra tutashadi?",o:["3","2","4","6"],k:0,s:"Har uchda 3 ta qirra."},
{t:"4 ta kubdan qator yasaldi (yonma-yon, stolda). Nechta yog' ochiq?",o:["14","24","18","16"],k:0,s:"24 − 4 (stol) − 6 (3 tutashuv × 2) = 14."},
{t:"Kubning yoyilmasida nechta kvadrat bor?",o:["6","4","8","12"],k:0,s:"6 ta yog' — 6 ta kvadrat."}
];
function PRACT_STAGE(){hBOne('uch');hBMsg('6 yog‘ · 12 qirra · 8 uch')}
var PREP_DATA={teach:["Kub elementlari: 6 yog', 12 qirra, 8 uch.","Rasmdagi kublarni sanash: ustunlab, qavatlab, yashirinlarini ham.","Ochiq va yopiq yog'lar; tutashuvda 2 ta yog' yopiladi.","Kub yoyilmasi; qarama-qarshi yog'lar; kub chiqmaydigan yoyilmalar."],
 mist:["Rasmda faqat ko'ringan kublarni sanaydi.","Kubda «4 ta yog'» yoki «8 ta qirra» deydi.","Tutashgan joyda faqat 1 ta yog'ni yopiq deb hisoblaydi.","6 kvadrat bo'lsa, har qanday shakl kub beradi deb o'ylaydi."],
 need:["O'yin kubiklari, qand kublari.","Qog'oz, qaychi (yoyilma uchun), karton quti."],
 board:["Kub: 6 / 12 / 8.","Qavatlab: 9 + 4 + 1 = 14.","Ochiq yog'lar: 18 − 1 − 4 = 13.","Xoch yoyilma: chetkilari qarama-qarshi.","Kub emas: ▭▭▭▭▭▭ va 2×3."]};
