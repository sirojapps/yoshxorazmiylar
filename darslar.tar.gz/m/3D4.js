var CODE='3D4',TITLE='3-sinf · Tengsizliklar: qaysi sonlar mos keladi';
function d4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg(badMsg[v]||'Yana o‘ylab ko‘ring')}})}
function d4Pick(from,to,good,why,done,okMsg){S.w4=[];function draw(bad){var m=S.w4.map(function(v){return [v,String(v),C.ok]});if(bad!=null)m.push([bad,'✗',C.bad]);w3Ray(from,to,1,m,{all:1,tap:tap})}
 function tap(v){if(good.indexOf(v)>=0){if(S.w4.indexOf(v)<0)S.w4.push(v);draw();if(S.w4.length===good.length){w3Msg(okMsg);done()}else w3Msg('Topildi: '+S.w4.length+' / '+good.length)}else{draw(v);w3Msg(why(v));setTimeout(function(){draw()},1200)}}
 draw()}
function d4Show(from,to,good,lab){w3Ray(from,to,1,good.map(function(v){return [v,String(v),C.ok]}),{all:1});if(lab)T(S.g,180,160,lab,{'font-size':13,'font-weight':800,fill:'#1d2b3a'})}
var P4=[function(){w3Expr(['5 · x < 32','x — natural son']);w3Msg('x ning qaysi qiymatlari mos? Sinab ko‘ramiz')},
 function(){w3Expr(['x = 5:  5 · 5 = 25 < 32 ✓','x = 6:  5 · 6 = 30 < 32 ✓']);w3Msg('Kattaroq sonlarni sinaymiz')},
 function(){w3Expr(['x = 6:  30 < 32 {✓}','x = 7:  35 < 32 [✗]']);w3Msg('7 dan boshlab hammasi katta chiqadi')},
 function(){w3Expr(['x = 1, 2, 3, 4, 5, 6','{6 ta son}']);w3Msg('Javob: <b>6 ta</b> natural son')}];
var P6=[function(){w3Expr(['27 < x < 65','nechta natural son?']);w3Msg('Hammasini sanash uzoq. Qisqa yo‘l bormi?')},
 function(){w3Expr(['28, 29, 30, …, 64','27 ham, 65 ham kirmaydi']);w3Msg('Birinchisi 28, oxirgisi 64')},
 function(){w3Expr(['64 − 28 = 36','36 + [1] = {37}']);w3Msg('Oxirgi − birinchi + 1 (birinchi sonni ham sanaymiz)')},
 function(){w3Expr(['Javob: {37} ta','tuzoq: 65 − 27 = [38]']);w3Msg('65 − 27 ni olsak, chegaralardan biri ortiqcha sanaladi')}];
function d4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"x < 5: qaysi sonlar mos keladi?",sum:"x < 5 ni qanoatlantiruvchi natural sonlar: 1, 2, 3, 4. Ularni tengsizlikning yechimlari deyiladi.",a:"m01",
 start:function(){S.w4=[];w3Ray(0,10,1,[],{all:1});w3Msg('Son nurida x < 5 ga mos natural sonlarni bosing')},fin:function(){d4Show(0,10,[1,2,3,4]);w3Msg('Yechimlar: <b>1, 2, 3, 4</b>')},
 html:"<p><b>x < 5</b> — bu <b>tengsizlik</b>. x o'rniga qaysi <b>natural sonlarni</b> qo'ysak, to'g'ri bo'ladi? Son nurida hammasini bosing:</p>",
 act:function(c,done){d4Pick(0,10,[1,2,3,4],function(v){return v===0?'0 — natural son emas (natural sonlar 1 dan boshlanadi)':v===5?'5 < 5 — noto‘g‘ri: 5 o‘ziga teng, kichik emas!':v+' < 5 — noto‘g‘ri'},done,'Hammasi topildi: <b>1, 2, 3, 4</b>')},
 after:"<p>Tengsizlikni to'g'ri qiladigan sonlar — uning <b>yechimlari</b>. Diqqat: <b>5</b> kirmaydi (5 < 5 — yolg'on), <b>0</b> ham kirmaydi — u natural son emas.</p>",
 q:{t:"x < 4 ni qanoatlantiruvchi natural sonlar?",opts:["1, 2, 3","0, 1, 2, 3","1, 2, 3, 4","4, 5, 6"],ok:0,why:"Natural sonlar 1 dan; 4 kirmaydi.",hint:"4 < 4 to'g'rimi?",full:"1, 2, 3 — hammasi 4 dan kichik. 0 — natural emas, 4 — o'ziga teng, kichik emas."},
 tn:"Polga lenta bilan son nuri chizing. Bolalar «yechim» bo'lgan sonlarga borib tursin (Gollandiya RME, harakat orqali)."},
{h:"Yechimlar soni: chekli yoki cheksiz",sum:"x < 5 — 4 ta yechim. x > 7 — 8, 9, 10, … — cheksiz ko'p yechim.",a:"m02",
 start:function(){S.w2={};w3Ray(0,12,1,[],{all:1});w3Msg('Ikki tengsizlikni solishtiramiz')},fin:function(){w3Ray(0,12,1,[[8,'8',C.u],[9,'9',C.u],[10,'10',C.u],[11,'11',C.u],[12,'12…',C.u]],{all:1});w3Msg('x > 7: 8, 9, 10, … — <b>cheksiz</b>')},
 html:"<p>Ikki tengsizlikni bosing va yechimlarni son nurida ko'ring:</p>",
 btns:[["x < 5",function(c,done){S.w2.a=1;d4Show(0,12,[1,2,3,4]);w3Msg('x < 5: 1, 2, 3, 4 — <b>4 ta</b> yechim');if(S.w2.b)done()}],["x > 7",function(c,done){S.w2.b=1;w3Ray(0,12,1,[[8,'8',C.u],[9,'9',C.u],[10,'10',C.u],[11,'11',C.u],[12,'12…',C.u]],{all:1});w3Msg('x > 7: 8, 9, 10, 11, … — <b>cheksiz ko‘p</b> yechim');if(S.w2.a)done()},'u']],g2:1,
 after:"<p>«Kichik» tengsizlikda natural yechimlar <b>chekli</b> (1 dan chegaragacha). «Katta» tengsizlikda — <b>cheksiz</b>: qaysi katta sonni olsangiz ham, undan katta son bor.</p>",
 q:{t:"x < 9 ni qanoatlantiruvchi nechta natural son bor?",opts:["8","9","7","Cheksiz ko'p"],ok:0,why:"1, 2, …, 8 — 8 ta.",hint:"9 kirmaydi, 0 ham.",full:"1 dan 8 gacha — 8 ta son. «9» — 9 ning o'zini yoki 0 ni qo'shib sanash."},
 tn:"Sinfga savol: «Eng katta natural son bormi?» — cheksizlik haqidagi qiziqarli suhbat."},
{h:"Qo'sh tengsizlik: 27 < x < 34",sum:"27 < x < 34 dagi toq sonlar: 29, 31, 33 — 3 ta.",a:"m03",
 start:function(){w3Ray(26,35,1,[],{all:1});w3Msg('27 < x < 34 bo‘lgan TOQ sonlarni bosing')},fin:function(){d4Show(26,35,[29,31,33]);w3Msg('Toq sonlar: <b>29, 31, 33</b> — 3 ta')},
 html:"<p><b>27 < x < 34</b> — x 27 dan katta <b>va</b> 34 dan kichik. Bankdagi savol: bunday <b>toq</b> sonlar nechta? Hammasini bosing:</p>",
 act:function(c,done){d4Pick(26,35,[29,31,33],function(v){return v===27?'27 < 27 — yo‘q, chegara kirmaydi':v<27||v>=34?v+' — oraliqdan tashqarida':v+' — juft son'},done,'Toq sonlar: <b>29, 31, 33</b> — <b>3 ta</b>')},
 after:"<p>Qo'sh tengsizlik — ikki shart birga: chap chegaradan katta <b>va</b> o'ng chegaradan kichik. Chegaralar (27 va 34) kirmaydi. 27 — toq, lekin u yechim emas!</p>",
 q:{t:"27 < x < 34 dagi juft sonlar qaysilar?",opts:["28, 30, 32","28, 30, 32, 34","27, 29, 31, 33","30, 32"],ok:0,why:"28, 30, 32 — oraliqdagi juft sonlar; 34 kirmaydi.",hint:"34 < 34 to'g'rimi?",full:"28, 30, 32. «… 34» — chegara kirmaydi; «30, 32» — 28 unutilgan."},
 tn:"Ikki rangli lenta: chap chegara — qizil bayroq, o'ng — ko'k. Faqat bayroqlar orasidagi sonlar."},
{h:"Ko'paytmali tengsizlik: 5 · x < 32",sum:"x = 6: 30 < 32 ✓; x = 7: 35 > 32 ✗. Yechimlar 1–6, jami 6 ta.",a:"m04",
 start:function(){startPh(P4)},fin:d4Fin(P4),
 html:"<p>x ko'paytmada bo'lsa, qiymatlarni sinab ko'ramiz — qaysi sondan boshlab tengsizlik buziladi?</p>",btns:[phaser(P4)],
 after:"<p>Usul: «chegaraviy» sonni toping — 32 ga yaqin karrali: 5 · 6 = 30 < 32, 5 · 7 = 35 > 32. Demak x = 1, …, 6 — <b>6 ta</b>.</p>",
 q:{t:"x · 8 < 50 bo'ladigan eng katta natural x?",opts:["6","7","8","42"],ok:0,why:"8 · 6 = 48 < 50, 8 · 7 = 56 > 50.",hint:"8 ning 50 ga yaqin karralisini toping.",full:"48 < 50 ✓, 56 > 50 ✗. Eng katta x = 6. «42» — 50 − 8."},
 tn:"Karrali jadval qatori bilan ishlang: 5, 10, 15, … 30 | 35 — chiziq tortib «chegara»ni ko'rsating."},
{h:"Bank misoli: x · 10 < 70",sum:"x · 10 < 70 → x < 7 → x = 1, 2, 3, 4, 5, 6 → 6 ta.",a:"m05",
 start:function(){w3Expr(['x · 10 < 70','nechta natural son?']);w3Msg('Javobni tanlang')},fin:function(){w3Expr(['x · 10 < 70','x < 7','1, 2, 3, 4, 5, 6 → {6 ta}']);w3Msg('7 · 10 = 70 — 70 < 70 emas!')},
 html:"<p>Bankdagi misol: <b>x · 10 < 70</b> tengsizlikni nechta natural son qanoatlantiradi?</p><div class='digs w3c'></div>",
 act:function(c,done){d4Sel(c,'.w3c',['7','6','70'],'6',function(){w3Expr(['x · 10 < 70','x < 7','1, 2, 3, 4, 5, 6 → {6 ta}']);w3Msg('To‘g‘ri: <b>6 ta</b>');done()},{'7':'7 · 10 = 70, lekin 70 < 70 — noto‘g‘ri. 7 kirmaydi!','70':'70 — chegara, yechimlar soni emas'})},
 after:"<p>Eng ko'p xato — chegaraviy son (7) ni ham sanash. Tekshiruv: 7 · 10 = 70, 70 < 70 — yolg'on. Demak 6 ta.</p>",
 q:{t:"x + 12 < 20 ni nechta natural son qanoatlantiradi?",opts:["7","8","32","6"],ok:0,why:"x < 8 → 1, …, 7.",hint:"x + 12 = 20 bo'lganda x = 8 — u kiradimi?",full:"x < 8: 1, 2, …, 7 — 7 ta. «8» — chegaraviy son qo'shilgan; «32» — 20 + 12."},
 tn:"Avval tenglamani yeching (x · 10 = 70 → x = 7), keyin «7 kiradimi?» deb so'rang."},
{h:"Tuzoq: katta oraliqda sanash",sum:"27 < x < 65: 28 dan 64 gacha → 64 − 28 + 1 = 37 ta (38 emas).",a:"m06",
 start:function(){startPh(P6)},fin:d4Fin(P6),
 html:"<p>Oraliq katta bo'lsa, birma-bir sanamaymiz — formula bor. Bosib kuzating:</p>",btns:[phaser(P6)],
 after:"<p>Qoida: <b>oxirgi − birinchi + 1</b>. Tekshirish uchun kichik misol: 2 < x < 6 → 3, 4, 5 — 3 ta; formula: 5 − 3 + 1 = 3 ✓.</p>",
 q:{t:"99 < x < 1000 ni qanoatlantiruvchi natural sonlar nechta?",opts:["900","901","899","1000"],ok:0,why:"100 dan 999 gacha: 999 − 100 + 1 = 900.",hint:"Birinchisi 100, oxirgisi 999.",full:"999 − 100 + 1 = 900 — barcha uch xonali sonlar. «901» — 1000 − 99; «899» — 999 − 100 (+1 unutilgan)."},
 tn:"«Panjara ustunlari» masalasi bilan bog'lang: 10 m panjara, har 1 m da ustun — 11 ta ustun."},
{h:"Sonli tengsizliklar: hisoblamasdan",sum:"345 + 18 < 345 + 20: birinchi qo'shiluvchilar teng, ikkinchisi kichik. 72 − 15 > 72 − 20: kam ayirsak, ko'p qoladi.",a:"m07",
 start:function(){w3Expr(['345 + 18  ?  345 + 20','72 − 15  ?  72 − 20']);w3Msg('Hisoblamasdan belgi qo‘ying')},fin:function(){w3Expr(['345 + 18  {<}  345 + 20','72 − 15  {>}  72 − 20']);w3Msg('Farq qiladigan qismga qarang')},
 html:"<p>Qaysi tengsizlik <b>to'g'ri</b>? Hisoblamasdan, faqat solishtirib toping:</p><div class='digs w3c'></div>",
 act:function(c,done){d4Sel(c,'.w3c',['345 + 18 > 345 + 20','72 − 15 > 72 − 20','6 · 9 > 7 · 9'],'72 − 15 > 72 − 20',function(){w3Expr(['72 − 15  {>}  72 − 20','57 > 52 ✓']);w3Msg('Kamroq ayirsak — ko‘proq qoladi');done()},{'345 + 18 > 345 + 20':'345 bir xil, 18 < 20 — demak chap tomon kichik','6 · 9 > 7 · 9':'9 bir xil, 6 < 7 — chap tomon kichik'})},
 after:"<p>Ayirishda tuzoq: ayriluvchi <b>katta</b> bo'lsa, ayirma <b>kichik</b>. 72 − 15 > 72 − 20. Olimpiadada katta sonlar bilan bunday «hisoblamasdan» savollar ko'p.</p>",
 q:{t:"Qaysi tengsizlik to'g'ri?",opts:["600 − 199 > 600 − 201","600 − 199 < 600 − 201","48 · 7 > 48 · 8","1000 : 5 < 1000 : 10"],ok:0,why:"199 < 201, kam ayirildi — ko'p qoldi.",hint:"Ayriluvchilarni solishtiring.",full:"600 − 199 = 401 > 399. Bo'lishda: 1000 : 5 = 200 > 100 — kichik songa bo'lsak, katta chiqadi."},
 tn:"Hayotiy: «100 so'mdan 15 so'm sarfladim / 20 so'm sarfladim — qachon ko'p qoladi?»"},
{h:"Hayotiy masala: eng ko'pi bilan nechta?",sum:"Lift 400 kg dan ortiq ko'tarmaydi, quti 60 kg: 60 · 6 = 360 ✓, 60 · 7 = 420 ✗ → 6 ta.",a:"m08",
 start:function(){w3Expr(['60 · x ≤ 400 kg','x — qutilar soni']);w3Msg('Eng ko‘pi bilan nechta quti?')},fin:function(){w3Expr(['60 · 6 = 360 ≤ 400 {✓}','60 · 7 = 420 > 400 [✗]','Javob: {6 ta}']);w3Msg('Qoldiq 40 kg — 7-quti sig‘maydi')},
 html:"<p>Lift <b>400 kg</b> dan ortiq yuk ko'tara olmaydi. Har bir quti <b>60 kg</b>. Liftga eng ko'pi bilan nechta quti qo'yish mumkin?</p><div class='digs w3c'></div>",
 act:function(c,done){d4Sel(c,'.w3c',['7','6','340'],'6',function(){w3Expr(['60 · 6 = 360 ≤ 400 {✓}','60 · 7 = 420 > 400 [✗]','Javob: {6 ta}']);w3Msg('Eng ko‘pi bilan <b>6 ta</b>');done()},{'7':'60 · 7 = 420 kg — lift ko‘tarmaydi!','340':'400 − 60 = 340 — bu kilogramm, qutilar soni emas'})},
 after:"<p>«Eng ko'pi bilan» masalalari — tengsizlik: javob <b>pastga</b> yaxlitlanadi. «Kamida nechta avtobus kerak?» masalasida esa — <b>yuqoriga</b>.</p>",
 q:{t:"Daftar 150 so'm. 1000 so'mga eng ko'pi bilan nechta daftar olish mumkin?",opts:["6","7","66","5"],ok:0,why:"150 · 6 = 900 ≤ 1000, 150 · 7 = 1050 > 1000.",hint:"150 ning 1000 ga yaqin karralisini toping.",full:"900 so'mga 6 ta, 100 so'm qoladi — 7-chisiga yetmaydi. «7» — yuqoriga yaxlitlash xatosi."},
 tn:"Haqiqiy narx yorliqlari bilan «do'kon» o'yini — pul yetadimi?"},
{h:"Bilasizmi? < va > belgilari",sum:"«<» va «>» belgilarini ingliz olimi Tomas Xarriot kiritgan; uning kitobi 1631-yilda nashr etilgan.",a:"m09",
 start:function(){w3Expr(['3 < 5','8 > 2']);w3Msg('Ochiq tomoni — katta son tomonda')},fin:function(){w3Expr(['3 < 5','8 > 2']);w3Msg('Ochiq tomoni — katta son tomonda')},
 html:"<p>📜 «Kichik» va «katta» belgilarini ingliz matematigi va astronomi <b>Tomas Xarriot</b> ishlatgan. Uning algebra kitobi vafotidan keyin, <b>1631-yilda</b> nashr etilgan.</p><p>🐊 Yodlash usuli: belgi — och qolgan og'iz, u doim <b>kattaroq</b> songa qarab ochiladi.</p>",
 tn:"«Timsoh og'zi» usulini qo'l harakati bilan ko'rsating."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){d4Show(0,10,[1,2,3,4],'x < 5 → 1, 2, 3, 4');w3Msg('Chegara kirmaydi')},fin:function(){d4Show(0,10,[1,2,3,4],'x < 5 → 1, 2, 3, 4');w3Msg('Chegara kirmaydi')},
 html:"<div class='memo'><ul><li>Tengsizlik yechimi — uni to'g'ri qiladigan son.</li><li>Natural sonlar 1 dan boshlanadi; chegara soni (x < 5 da 5) kirmaydi.</li><li>x < a — chekli, x > a — cheksiz ko'p natural yechim.</li><li>a < x < b — ikki shart birga.</li><li>Sanash: oxirgi − birinchi + 1 (27 < x < 65 → 37 ta).</li><li>5 · x < 32: chegaraviy karralini toping (30 ✓, 35 ✗).</li></ul></div>",
 tn:"Kartochka bilan birga son nuri lentasini daftarga yopishtirish foydali."}
];
var PROBS=[
{t:"x < 4 ni qanoatlantiruvchi natural sonlar?",o:["1, 2, 3","0, 1, 2, 3","1, 2, 3, 4","4, 5, 6"],k:0,s:"Natural sonlar 1 dan; 4 kirmaydi."},
{t:"x < 9 ni nechta natural son qanoatlantiradi?",o:["8","9","7","10"],k:0,s:"1, …, 8 — 8 ta."},
{t:"Qaysi son x > 15 tengsizlikning yechimi?",o:["16","15","14","9"],k:0,s:"16 > 15 ✓; 15 > 15 — yo'q."},
{t:"27 < x < 34 dagi toq sonlar nechta?",o:["3","4","6","7"],k:0,s:"29, 31, 33."},
{t:"27 < x < 34 dagi juft sonlar qaysilar?",o:["28, 30, 32","28, 30, 32, 34","30, 32","27, 29, 31"],k:0,s:"34 kirmaydi."},
{t:"5 · x < 32 ni nechta natural son qanoatlantiradi?",o:["6","7","5","32"],k:0,s:"5 · 6 = 30 < 32, 5 · 7 = 35 > 32."},
{t:"x · 10 < 70 ni nechta natural son qanoatlantiradi?",o:["6","7","70","60"],k:0,s:"x < 7 → 1, …, 6."},
{t:"27 < x < 65 ni nechta natural son qanoatlantiradi?",o:["37","38","36","92"],k:0,s:"64 − 28 + 1 = 37."},
{t:"x · 8 < 50 bo'ladigan eng katta natural x?",o:["6","7","8","42"],k:0,s:"48 < 50, 56 > 50."},
{t:"x · 9 > 60 bo'ladigan eng kichik natural x?",o:["7","6","51","69"],k:0,s:"9 · 6 = 54 < 60, 9 · 7 = 63 > 60."},
{t:"Qaysi tengsizlik to'g'ri?",o:["345 + 18 < 345 + 20","345 + 18 > 345 + 20","72 − 15 < 72 − 20","6 · 9 > 7 · 9"],k:0,s:"345 bir xil, 18 < 20."},
{t:"100 − x > 95 ni nechta natural son qanoatlantiradi?",o:["4","5","95","96"],k:0,s:"x < 5 → 1, 2, 3, 4."},
{t:"x + 12 < 20 ni nechta natural son qanoatlantiradi?",o:["7","8","32","6"],k:0,s:"x < 8 → 1, …, 7."},
{t:"x < 15 bo'lgan ikki xonali sonlar nechta?",o:["5","15","4","6"],k:0,s:"10, 11, 12, 13, 14."},
{t:"Lift 400 kg dan ortiq ko'tarmaydi. 60 kg li qutilardan eng ko'pi bilan nechtasini qo'yish mumkin?",o:["6","7","340","5"],k:0,s:"360 ≤ 400, 420 > 400."},
{t:"Daftar 150 so'm. 1000 so'mga eng ko'pi bilan nechta daftar olish mumkin?",o:["6","7","66","5"],k:0,s:"900 ≤ 1000, 1050 > 1000."},
{t:"3 · x + 2 < 20 ni nechta natural son qanoatlantiradi?",o:["5","6","18","4"],k:0,s:"3 · x < 18 → x < 6 → 1, …, 5."},
{t:"x > 4 va x < 9 shartlarni birga qanoatlantiruvchi natural sonlar nechta?",o:["4","5","6","3"],k:0,s:"5, 6, 7, 8."},
{t:"3 < x < 7 bo'lgan eng katta natural son?",o:["6","7","3","4"],k:0,s:"7 kirmaydi — eng kattasi 6."},
{t:"99 < x < 1000 ni nechta natural son qanoatlantiradi?",o:["900","901","899","1000"],k:0,s:"999 − 100 + 1 = 900."}
];
function PRACT_STAGE(){d4Show(0,10,[1,2,3,4],'x < 5');w3Msg('Chegara kirmaydi')}
var PREP_DATA={teach:["Tengsizlik va uning yechimlari; son nurida ko'rsatish.","Chekli va cheksiz yechimlar.","Qo'sh tengsizlik; toq/juft yechimlar.","x ko'paytma/yig'indi ichida bo'lgan tengsizliklar; oraliqdagi sonlarni sanash; hayotiy «eng ko'pi bilan» masalalari."],
 mist:["Chegara sonini qo'shib yuboradi: x < 5 da 5 ni ham oladi.","0 ni natural son deb hisoblaydi.","Oraliqni ayirma bilan sanaydi: 65 − 27 = 38.","«Eng ko'pi bilan» masalasida yuqoriga yaxlitlaydi."],
 need:["Polda lenta bilan son nuri.","Qizil va ko'k bayroqchalar (chegaralar)."],
 board:["<span class='w2'>x < 5</span> → 1, 2, 3, 4.","<span class='w2'>27 < x < 34</span>, toq: 29, 31, 33.","<span class='w2'>5 · x < 32</span> → 6 ta.","<span class='w2'>27 < x < 65</span> → 64 − 28 + 1 = 37."]};

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
