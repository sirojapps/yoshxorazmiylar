var CODE='3C6',TITLE='3-sinf · Qoldiqli bo‘lish';
var DAYS=['dushanba','seshanba','chorshanba','payshanba','juma','shanba','yakshanba'];
function c6pile(n){clear();var g=S.g;for(var i=0;i<n;i++)E('circle',{cx:30+(i%12)*26,cy:40+Math.floor(i/12)*28,r:9,fill:C.a,stroke:'rgba(0,0,0,.2)'},g)}
function c6mod(d){W3grid(function(n){var r=n%d;return r===0?'#bfe9e3':['#fff','#fdf0e1','#e8f1fb','#fdeaea','#efe8fb','#fff4d6','#e6f6ee','#f3eefc','#fde6c8'][r]},{n:40});W3msg(d+' ga bo‘lganda qoldiqlar: '+Array.from({length:d},function(_,i){return i}).join(', ')+' — har biri o‘z rangida. Yashil — qoldiqsiz')}
var P2=[function(){W3groups(17,5,{lbl:'17 ta: 5 tadan 3 quti, 2 ortdi'});W3msg('17 : 5 = 3 (qoldiq 2)')},
 function(){W3groups(17,5,{q:2});W3msg('Ali yozdi: «17 : 5 = 2 (qoldiq 7)». To‘g‘rimi?')},
 function(){W3groups(17,5,{q:2,lbl:'7 ta ortsa — yana bitta 5 talik quti chiqadi!'});W3msg('Qoldiq <b>bo‘luvchidan kichik</b> bo‘lishi shart: 7 > 5 — demak bo‘lish tugamagan')}];
var P5=[function(){W3groups(26,4,{lbl:'26 bola, qayiqqa 4 tadan'});W3msg('26 : 4 = 6 (qoldiq 2). 6 ta qayiq yetadimi?')},
 function(){W3groups(26,4,{lbl:'2 bola qirg‘oqda qoldi! Ular uchun yana 1 qayiq'});W3msg('Qoldiq bor — demak <b>yana bitta</b> qayiq kerak: 6 + 1 = <b>7</b>')}];
var P6=[function(){W3eq(['□ : 6 = 7 (qoldiq 4)']);W3msg('Bo‘linuvchi noma’lum')},
 function(){W3eq(['□ : 6 = 7 (qoldiq 4)','□ = 6 · 7 + 4']);W3msg('Bo‘linuvchi = bo‘luvchi · bo‘linma + qoldiq')},
 function(){W3eq(['□ : 6 = 7 (qoldiq 4)','□ = 42 + 4 = [46]']);W3msg('Tekshiruv: 46 : 6 = 7, 6 · 7 = 42, 46 − 42 = 4 ✓')}];
var P8=[function(){W3eq(['125 : 4 = ?']);W3msg('125 ni qulay qismlarga ajratamiz')},
 function(){W3eq(['125 : 4 = ?','120 : 4 + 5 : 4']);W3msg('120 : 4 = 30, 5 : 4 = 1 (qoldiq 1)')},
 function(){W3eq(['125 : 4 = ?','30 + 1 = [31] (qoldiq [1])']);W3msg('Tekshiruv: 31 · 4 + 1 = 124 + 1 = 125 ✓')}];
var STEPS=[
{h:"Teng bo'linmasa — qoldiq",sum:"17 ta konfet 5 tadan qutiga: 3 quti, 2 ta ortadi. 17 : 5 = 3 (qoldiq 2).",a:"m01",start:function(){c6pile(17);W3msg('17 ta konfet. Har qutiga 5 tadan joylaymiz')},fin:function(){P2[0]()},
 html:"<p>17 ta konfetni qutilarga <b>5 tadan</b> joylaymiz. Hammasi joylashadimi? Tugmani bosing.</p>",
 btns:[["📦 5 tadan joylash",function(c,done,b){b.disabled=true;P2[0]();done()}]],
 after:"<p>3 ta quti to'ldi, <b>2 ta</b> konfet ortdi — ular yangi qutini to'ldirolmaydi. Bu — <b>qoldiq</b>. Yoziladi: <b>17 : 5 = 3 (qoldiq 2)</b>.</p>",
 q:{t:"23 ta qalam 4 tadan bog'landi. Nechta bog'lam chiqdi va nechta ortdi?",opts:["5 bog'lam, 3 ortdi","6 bog'lam, 1 ortdi","5 bog'lam, 2 ortdi","4 bog'lam, 7 ortdi"],ok:0,why:"4 · 5 = 20, 23 − 20 = 3.",hint:"4 ga ko'paytirib, 23 dan oshmaydigan eng katta sonni toping.",full:"4 · 5 = 20 ≤ 23, 4 · 6 = 24 > 23. Demak 5 bog'lam, 23 − 20 = 3 ortdi. «4 bog'lam, 7 ortdi» — 7 dan yana bitta bog'lam chiqadi."},
 tn:"Bolalar haqiqiy narsalar (tugma, cho'p) bilan guruhlarga ajratsin — qoldiq «qo'lda qolgan» narsa sifatida esda qoladi."},
{h:"Qoldiq bo'luvchidan kichik",sum:"Qoldiq har doim bo'luvchidan kichik: 5 ga bo'lishda qoldiq 0, 1, 2, 3 yoki 4.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ali «17 : 5 = 2 (qoldiq 7)» deb yozdi. Nima deysiz? Kuzating.</p>",btns:[phaser(P2)],
 after:"<p><b>Oltin qoida:</b> qoldiq bo'luvchidan <b>kichik</b>. Agar qoldiq bo'luvchiga teng yoki katta chiqsa — yana bitta guruh olish mumkin, javob xato.</p>",
 q:{t:"Qaysi yozuv to'g'ri?",opts:["29 : 6 = 3 (qoldiq 11)","29 : 6 = 4 (qoldiq 5)","29 : 6 = 5 (qoldiq 1)","29 : 6 = 4 (qoldiq 6)"],ok:1,why:"6 · 4 = 24, 29 − 24 = 5 < 6.",hint:"Qoldiq 6 dan kichik bo'lishi kerak. 6 · 5 = 30 — 29 dan katta.",full:"6 · 4 = 24, 29 − 24 = 5, 5 < 6 ✓. «qoldiq 11» va «qoldiq 6» — qoldiq 6 dan kichik emas. «5 (qoldiq 1)» — 6 · 5 = 30 > 29."},
 tn:"Har qoldiqli bo'lishdan keyin «qoldiq bo'luvchidan kichikmi?» deb so'rash odat bo'lsin."},
{h:"Tekshirish formulasi",sum:"Bo'linuvchi = bo'luvchi · bo'linma + qoldiq: 17 = 5 · 3 + 2.",a:"m03",start:function(){W3eq(['17 : 5 = 3 (qoldiq 2)','?'])},fin:function(){W3eq(['17 : 5 = 3 (qoldiq 2)','5 · 3 + 2 = [17] ✓'])},
 html:"<p>Qoldiqli bo'lishni qanday tekshiramiz? Tugmani bosing.</p>",
 btns:[["✓ Tekshirish",function(c,done){W3eq(['17 : 5 = 3 (qoldiq 2)','5 · 3 + 2 = [17] ✓']);W3msg('Bo‘luvchi · bo‘linma + qoldiq = bo‘linuvchi');done()}]],
 after:"<p>Formula: <b>bo'linuvchi = bo'luvchi · bo'linma + qoldiq</b>. Qoldiqni qo'shishni unutmang — 5 · 3 = 15 emas, 17!</p>",
 q:{t:"37 : 8 = 4 (qoldiq 5). Tekshiruv qaysi?",opts:["8 · 4 = 37","8 · 4 + 5 = 37","8 · 5 + 4 = 37","37 − 8 = 29"],ok:1,why:"32 + 5 = 37 ✓.",hint:"Formula: bo'luvchi · bo'linma + qoldiq.",full:"8 · 4 = 32, 32 + 5 = 37 — bo'linuvchi chiqdi ✓. «8 · 5 + 4» = 44 ≠ 37."},
 tn:"Formulani doskaga ramka ichida yozing va har darsda qaytaring."},
{h:"Qanday qoldiqlar bo'lishi mumkin?",sum:"4 ga bo'lishda qoldiqlar: 0, 1, 2, 3 — qaytarilib keladi. n ga bo'lishda eng katta qoldiq n − 1.",a:"m04",start:function(){c6mod(4)},fin:function(){c6mod(5)},
 html:"<p>Sonlar jadvalida qoldiqlarni ranglar bilan ko'raylik. Bo'luvchini tanlang:</p>",
 btns:[["3 ga",function(c,done){c6mod(3);mvK(done,2)}],["4 ga",function(c,done){c6mod(4);mvK(done,2)}],["5 ga",function(c,done){c6mod(5);mvK(done,2)}]],g3:1,
 after:"<p>Qoldiqlar <b>aylana bo'lib</b> qaytariladi: 4 ga bo'lishda 1, 2, 3, 0, 1, 2, 3, 0… Eng katta qoldiq — <b>bo'luvchidan 1 ta kam</b>.</p>",
 q:{t:"7 ga bo'lganda eng katta qoldiq qancha bo'lishi mumkin?",opts:["7","6","8","1"],ok:1,why:"Qoldiq 7 dan kichik: 0 … 6. Eng kattasi 6.",hint:"Qoldiq bo'luvchidan kichik bo'ladi.",full:"7 ga bo'lishda qoldiqlar: 0, 1, 2, 3, 4, 5, 6. Eng kattasi 6. 7 bo'lsa — yana bitta guruh chiqadi."},
 tn:"Bu soat va kalendar masalalarining asosi (9-qadam). Jadvalni rangli qalamlar bilan daftarda bo'yatish mumkin."},
{h:"Tuzoq: qayiq masalasi",sum:"26 bola, qayiqqa 4 tadan: 26 : 4 = 6 (qoldiq 2) → 7 ta qayiq kerak (qoldiq ham joy talab qiladi).",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>«26 bola qayiqda sayr qiladi. Bitta qayiqqa 4 kishi sig'adi. Nechta qayiq kerak?» Ko'pchilik «6» deydi…</p>",btns:[phaser(P5)],
 after:"<p>Qoldiq — bu <b>joy kerak bo'lgan bolalar</b>! Shuning uchun javob <b>7</b>. Masalaning ma'nosiga qarab qoldiq bilan nima qilish kerakligini o'ylang: «nechta to'la quti» — qoldiq tashlanadi, «nechta qayiq kerak» — bitta qo'shiladi.</p>",
 q:{t:"30 ta tuxum 12 talik qutilarga solinadi. Nechta TO'LA quti chiqadi?",opts:["3","2","2 (qoldiq 6)","18"],ok:1,why:"30 : 12 = 2 (qoldiq 6) — to'la quti 2 ta.",hint:"Savol «to'la» qutilar haqida. Ortgan 6 ta tuxum qutini to'ldiradimi?",full:"12 · 2 = 24, 30 − 24 = 6. 6 ta tuxum qutini to'ldirmaydi — to'la quti 2 ta. «3» — bu «nechta quti kerak» savolining javobi."},
 tn:"Ikki savolni yonma-yon bering: «nechta qayiq kerak?» va «nechta to'la quti?» — bolalar qoldiqning ma'nosini farqlashni o'rganadi."},
{h:"Bo'linuvchini topish",sum:"□ : 6 = 7 (qoldiq 4) → □ = 6 · 7 + 4 = 46.",a:"m06",start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Teskari savol: <b>□ : 6 = 7 (qoldiq 4)</b>. Bo'linuvchi qaysi?</p>",btns:[phaser(P6)],
 after:"<p>Tekshirish formulasining o'zi yechadi: <b>bo'linuvchi = bo'luvchi · bo'linma + qoldiq</b>.</p>",
 q:{t:"□ : 9 = 5 (qoldiq 3). □ = ?",opts:["45","48","42","27"],ok:1,why:"9 · 5 + 3 = 48.",hint:"Bo'luvchini bo'linmaga ko'paytiring va qoldiqni qo'shing.",full:"9 · 5 = 45, 45 + 3 = 48. Tekshiruv: 48 : 9 = 5 (qoldiq 3) ✓. «42» — qoldiq ayirib yuborilgan."},
 tn:"Bu teskari amal — tenglamalarga ko'prik."},
{h:"Tuzoq: eng katta bo'linuvchi",sum:"□ : 5 = 8 qoldiqli bo'lsa, eng katta □ = 5 · 8 + 4 = 44 (eng katta qoldiq 4).",a:"m07",start:function(){W3eq(['□ : 5 = 8 (qoldiqli)','□ = ?'])},fin:function(){W3eq(['□ : 5 = 8 (qoldiq 1…4)','eng katta: 5 · 8 + [4] = 44'])},
 html:"<p>Olimpiada savoli: «Son 5 ga bo'linganda bo'linma 8 chiqdi va qoldiq bor. Son eng ko'pi bilan nechaga teng?» Qoldiq qancha bo'lishi mumkinligini tanlab ko'ring:</p>",
 btns:[["qoldiq 1",function(c,done){W3eq(['5 · 8 + 1 = 41']);mvK(done,2)}],["qoldiq 4",function(c,done){W3eq(['5 · 8 + 4 = [44]']);W3msg('Eng katta qoldiq — 4');mvK(done,2)}],["qoldiq 5",function(c,done){W3eq(['5 · 8 + 5 = 45','45 : 5 = [9]!']);W3msg('Qoldiq 5 bo‘lmaydi — bo‘linma 9 ga aylanib qoladi');mvK(done,2)}]],g3:1,
 after:"<p>Eng katta son uchun <b>eng katta qoldiq</b> kerak: 5 ga bo'lishda bu 4. Javob: 5 · 8 + 4 = <b>44</b>. Eng kichigi esa 41 (qoldiq kamida 1).</p>",
 q:{t:"Son 6 ga bo'linganda bo'linma 7, qoldiq bor. Son eng kami bilan nechaga teng?",opts:["42","43","47","48"],ok:1,why:"Eng kichik qoldiq 1: 6 · 7 + 1 = 43.",hint:"«Qoldiq bor» — demak qoldiq 0 emas. Eng kichigi qancha?",full:"Qoldiq kamida 1: 6 · 7 + 1 = 43. 42 — qoldiqsiz bo'linadi. 47 — eng katta (qoldiq 5)."},
 tn:"Saralash testlarida tez-tez uchraydi. Bolalar qoldiqlar ro'yxatini (1…n−1) yozib, chetlarini tanlashga o'rgansin."},
{h:"Uch xonali sonni qoldiqli bo'lish",sum:"125 : 4 = 120 : 4 + 5 : 4 → 30 + 1 = 31 (qoldiq 1).",a:"m08",start:function(){startPh(P8)},fin:function(){S.ph=2;P8[2]()},
 html:"<p>Katta sonni ham qulay qismlarga ajratib bo'lamiz: bo'linadigan qism + kichik qism.</p>",btns:[phaser(P8)],
 after:"<p>Qism tanlashda: birinchisi bo'luvchiga <b>to'liq</b> bo'linsin (120), qolgani kichik bo'lsin — qoldiq o'shandan chiqadi.</p>",
 q:{t:"143 : 7 = ?",opts:["20 (qoldiq 3)","21 (qoldiq 6)","20 (qoldiq 13)","19 (qoldiq 10)"],ok:0,why:"140 : 7 = 20, 3 < 7 — qoldiq 3.",hint:"143 ni 140 + 3 qilib ajrating.",full:"143 = 140 + 3. 140 : 7 = 20, 3 ni 7 ga bo'lib bo'lmaydi — qoldiq 3. Tekshiruv: 7 · 20 + 3 = 143 ✓. «qoldiq 13» va «10» — qoldiq 7 dan katta."},
 tn:"Keyingi darsda bu usul burchakli bo'lishga aylanadi — bir xil g'oya, faqat yozuvi boshqa."},
{h:"Bilasizmi? Hafta kunlari va qoldiq",sum:"Hafta 7 kun: 10 kundan keyin = 10 : 7 qoldiq 3 → dushanbadan 3 kun keyin — payshanba.",a:"m09",start:function(){c6week(0,0)},fin:function(){c6week(10,1)},
 html:"<p>📅 Bugun <b>dushanba</b>. 10 kundan keyin qaysi kun bo'ladi? Hafta har 7 kunda takrorlanadi — demak faqat <b>qoldiq</b> muhim! Tugmani bosing.</p>",
 btns:[["📅 10 kundan keyin",function(c,done){c6week(10,1);done()}],["📅 100 kundan keyin",function(c,done){c6week(100,1);done()}]],g2:1,
 after:"<p>10 : 7 = 1 (qoldiq 3) → dushanbadan 3 kun keyin — <b>payshanba</b>. 100 : 7 = 14 (qoldiq 2) → <b>chorshanba</b>. Soat ham shunday: 12 soatda aylanadi. Matematiklar buni «modul arifmetikasi» deydi — kompyuterlar va shifrlar ham shunga tayanadi.</p>",
 tn:"Bolalardan tug'ilgan kunigacha nechta kun qolganini so'rab, qaysi hafta kuniga to'g'ri kelishini hisoblatsa bo'ladi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){W3eq(['17 : 5 = 3 (qoldiq 2)','5 · 3 + 2 = 17 ✓'])},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>Teng bo'linmasa — <b>qoldiq</b>: 17 : 5 = 3 (qoldiq 2).</li><li>Qoldiq <b>bo'luvchidan kichik</b>. 5 ga bo'lishda: 0…4.</li><li>Tekshiruv: <b>bo'luvchi · bo'linma + qoldiq = bo'linuvchi</b>.</li><li>«Nechta kerak?» — qoldiq bo'lsa, <b>1 ta qo'shiladi</b> (26 bola → 7 qayiq). «Nechta to'la?» — qoldiq tashlanadi.</li><li>□ : 6 = 7 (qoldiq 4) → □ = 46.</li><li>Eng katta son — eng katta qoldiq bilan: □ : 5 = 8 → 44.</li><li>Hafta kunlari: kunlar sonining 7 ga bo'lishdagi qoldig'i.</li></ul></div>",
 tn:"Keyingi darsni «45 ta o'quvchi 4 kishilik stollarga o'tiradi. Nechta stol kerak?» savoli bilan boshlang."}
];
function c6week(n,show){clear();var g=S.g,w=46;for(var i=0;i<7;i++){var x=18+i*w,hl=show&&(n%7)===i;E('rect',{x:x,y:56,width:w-4,height:48,rx:8,fill:hl?C.hi:(i===0?'#e8f1fb':'#fff'),stroke:hl?C.bad:'#c9d3dd','stroke-width':hl?2.5:1.5},g);T(g,x+w/2-2,84,DAYS[i].slice(0,3),{'font-size':12,'font-weight':800,fill:'#1d2b3a'})}
 T(g,18+w/2-2,48,'bugun',{'font-size':10,fill:C.blue});if(show)W3msg(n+' : 7 = '+Math.floor(n/7)+' (qoldiq '+(n%7)+') → <b>'+DAYS[n%7]+'</b>');else W3msg('Kunlar 7 kunda takrorlanadi')}
var PROBS=[
{t:"25 : 4 = ?",o:["6 (qoldiq 1)","5 (qoldiq 5)","6 (qoldiq 4)","7 (qoldiq 3)"],k:0,s:"4 · 6 = 24, 25 − 24 = 1."},
{t:"38 : 5 = ?",o:["7 (qoldiq 3)","6 (qoldiq 8)","8 (qoldiq 2)","7 (qoldiq 4)"],k:0,s:"5 · 7 = 35, 38 − 35 = 3."},
{t:"50 : 8 = ?",o:["6 (qoldiq 2)","5 (qoldiq 10)","7 (qoldiq 6)","6 (qoldiq 4)"],k:0,s:"8 · 6 = 48, 50 − 48 = 2."},
{t:"9 ga bo'lganda qaysi qoldiq bo'lishi MUMKIN EMAS?",o:["9","8","0","5"],k:0,s:"Qoldiq 9 dan kichik: 0…8."},
{t:"Qaysi yozuv xato?",o:["44 : 6 = 6 (qoldiq 8)","44 : 6 = 7 (qoldiq 2)","44 : 5 = 8 (qoldiq 4)","44 : 7 = 6 (qoldiq 2)"],k:0,s:"Qoldiq 8 > 6 — xato. To'g'risi 7 (qoldiq 2)."},
{t:"□ : 7 = 4 (qoldiq 5). □ = ?",o:["33","28","23","39"],k:0,s:"7 · 4 + 5 = 33."},
{t:"□ : 8 = 9 (qoldiq 3). □ = ?",o:["75","72","69","81"],k:0,s:"8 · 9 + 3 = 75."},
{t:"34 o'quvchi 4 kishilik stollarga o'tiradi. Nechta stol kerak?",o:["9","8","8 (qoldiq 2)","10"],k:0,s:"34 : 4 = 8 (qoldiq 2) — 2 kishiga yana stol: 9."},
{t:"50 ta olma 6 talik qutilarga solinadi. Nechta to'la quti chiqadi?",o:["8","9","7","8 (qoldiq 2)"],k:0,s:"6 · 8 = 48 ≤ 50 — 8 to'la quti, 2 ta ortadi."},
{t:"Son 4 ga bo'linganda bo'linma 9, qoldiq bor. Son eng ko'pi bilan nechaga teng?",o:["39","36","40","37"],k:0,s:"Eng katta qoldiq 3: 4 · 9 + 3 = 39."},
{t:"Son 5 ga bo'linganda bo'linma 6, qoldiq bor. Son eng kami bilan nechaga teng?",o:["31","30","34","29"],k:0,s:"Eng kichik qoldiq 1: 5 · 6 + 1 = 31."},
{t:"Bugun seshanba. 15 kundan keyin qaysi kun?",o:["chorshanba","seshanba","payshanba","dushanba"],k:0,s:"15 : 7 = 2 (qoldiq 1) — seshanbadan 1 kun keyin: chorshanba."},
{t:"Bugun juma. 30 kundan keyin qaysi kun?",o:["yakshanba","juma","shanba","dushanba"],k:0,s:"30 : 7 = 4 (qoldiq 2) — jumadan 2 kun keyin: yakshanba."},
{t:"87 : 4 = ?",o:["21 (qoldiq 3)","20 (qoldiq 7)","22 (qoldiq 1)","21 (qoldiq 4)"],k:0,s:"80 : 4 = 20, 7 : 4 = 1 (qoldiq 3) → 21 (qoldiq 3)."},
{t:"146 : 7 = ?",o:["20 (qoldiq 6)","21 (qoldiq 1)","20 (qoldiq 4)","19 (qoldiq 13)"],k:0,s:"140 : 7 = 20, 6 < 7 → qoldiq 6."},
{t:"Qaysi son 5 ga bo'linganda qoldiq 3 qoladi?",o:["28","25","30","27"],k:0,s:"28 = 5 · 5 + 3."},
{t:"Qaysi son 3 ga ham, 4 ga ham bo'linganda qoldiq 1 qoladi?",o:["13","10","9","11"],k:0,s:"13 = 3 · 4 + 1 = 4 · 3 + 1. 10: 4 ga qoldiq 2."},
{t:"Konfetlarni 6 tadan bo'lsa 2 ta ortadi, 5 tadan bo'lsa qoldiqsiz. Konfetlar 30 dan kam. Nechta?",o:["20","26","15","25"],k:0,s:"5 ga bo'linadigan: 5…25. 6 ga qoldiq 2: 20 (6·3+2) ✓."},
{t:"Ip 47 sm. Undan 9 sm lik bo'laklar kesildi. Necha sm ortdi?",o:["2","5","7","1"],k:0,s:"9 · 5 = 45, 47 − 45 = 2 sm."},
{t:"7 ga bo'lganda qoldiq 4, bo'linma 12. Bo'linuvchi?",o:["88","84","80","91"],k:0,s:"7 · 12 + 4 = 88."}
];
function PRACT_STAGE(){W3eq(['bo‘linuvchi =','bo‘luvchi · bo‘linma + qoldiq'],{fs:20});W3msg('Qoldiq bo‘luvchidan kichik!')}
var PREP_DATA={teach:["Qoldiqli bo'lishning ma'nosi (guruhlab, ortgani — qoldiq).","Qoldiq bo'luvchidan kichik; mumkin bo'lgan qoldiqlar.","Tekshiruv: bo'luvchi · bo'linma + qoldiq.","Hayotiy masalalarda qoldiqni talqin qilish (qayiq / to'la quti); teskari va «eng katta son» masalalari; hafta kunlari."],
 mist:["Qoldiqni bo'luvchidan katta qoldiradi (17 : 5 = 2 qoldiq 7).","Tekshirishda qoldiqni qo'shmaydi.","«Nechta qayiq kerak?» da qoldiqni tashlab yuboradi.","«Qoldiq bor» shartida 0 ni ham oladi."],
 need:["Tugmalar yoki cho'plar, qutichalar (guruhlash uchun).","Devoriy kalendar."],
 board:["<span class='w2'>17 : 5 = 3 (qoldiq 2)</span>","<span class='w2'>qoldiq < bo'luvchi</span>","<span class='w2'>5 · 3 + 2 = 17</span>","<span class='w2'>26 : 4 = 6 (q. 2) → 7 qayiq</span>","<span class='w2'>□ : 6 = 7 (q. 4) → 46</span>","<span class='w2'>10 : 7 = 1 (q. 3) → payshanba</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[';ts.textContent=hl?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}
