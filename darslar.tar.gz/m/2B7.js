var CODE='2B7',TITLE='2-sinf · Qavsli ifodalar va amallar tartibi';
// tanlash qadami: bola qaysi amal birinchi ekanini bosadi
function b7Pick(opts,ok,lines,okMsg,badMsg){return opts.map(function(o,i){return [o,function(c,done,b){if(i===ok){bqExpr(lines);bqMsg(okMsg);c.querySelectorAll('.ab').forEach(function(x){x.disabled=true});b.className='ab u';done()}else{flashBad(b);setTimeout(function(){b.className='ab'},2000);bqMsg(badMsg)}}]})}
var P1=[function(){bqExpr(['50 − 20 + 5']);bqMsg('Qavs yo‘q, faqat qo‘shish va ayirish')},
 function(){bqExpr(['[50 − 20] + 5','30 + 5 = 35']);bqMsg('To‘g‘ri: <b>chapdan o‘ngga</b> — avval 50 − 20 = 30, keyin 30 + 5 = <b>35</b>')},
 function(){bqExpr(['50 − [20 + 5]','50 − 25 = 25 ✗']);bqMsg('Agar oxiridan boshlasak — 25 chiqadi. Bu <b>xato</b>: qavs yo‘q bo‘lsa, tartib chapdan o‘ngga')}];
var P3=[function(){bqExpr(['86 − 53 − 29','33 − 29 = [4]']);bqMsg('Qavssiz: chapdan o‘ngga — <b>4</b>')},
 function(){bqExpr(['86 − (53 − 29)','86 − [24] = 62']);bqMsg('Qavs bilan: avval 53 − 29 = 24, keyin 86 − 24 = <b>62</b>')},
 function(){bqExpr(['86 − 53 − 29 = 4','86 − (53 − 29) = 62']);bqMsg('Sonlar bir xil, lekin qavs natijani <b>butunlay o‘zgartirdi</b>!')}];
var P5=[function(){bqExpr(['90 − 4 · (12 + 8)']);bqMsg('Uchta amal: ayirish, ko‘paytirish va qavs ichida qo‘shish')},
 function(){bqExpr(['90 − 4 · ([12 + 8])','90 − 4 · 20']);bqMsg('<b>1)</b> Qavs: 12 + 8 = 20')},
 function(){bqExpr(['90 − [4 · 20]','90 − 80']);bqMsg('<b>2)</b> Ko‘paytirish: 4 · 20 = 80')},
 function(){bqExpr(['90 − 80','[10]']);bqMsg('<b>3)</b> Ayirish: 90 − 80 = <b>10</b>')}];
var P6=[function(){bqExpr(['52 − (9 + 14) − (8 + 13 − 7)']);bqMsg('Ikkita qavs bor')},
 function(){bqExpr(['52 − ([9 + 14]) − ([8 + 13 − 7])','52 − 23 − 14']);bqMsg('Avval ikkala qavs: 9 + 14 = 23; 8 + 13 − 7 = 14')},
 function(){bqExpr(['52 − 23 − 14','29 − 14','[15]']);bqMsg('Keyin chapdan o‘ngga: 52 − 23 = 29, 29 − 14 = <b>15</b>')}];
var STEPS=[
{h:"Qavs yo'q bo'lsa — chapdan o'ngga",sum:"50 − 20 + 5 = 35: qo'shish va ayirish chapdan o'ngga tartib bilan bajariladi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ifodada bir nechta amal bo'lsa, <b>qaysi birini birinchi</b> bajarish muhim. Qavs yo'q bo'lsa nima qilamiz? Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p><b>Qoida 1:</b> qavs bo'lmasa va faqat qo'shish-ayirish bo'lsa — amallar <b>chapdan o'ngga</b> navbat bilan bajariladi, xuddi kitob o'qigandek.</p>",
 q:{t:"40 − 10 + 5 = ?",opts:["25","35","45","30"],ok:1,why:"40 − 10 = 30, 30 + 5 = 35.",hint:"Chapdan boshlang: avval birinchi amal.",full:"Chapdan o'ngga: 40 − 10 = 30, keyin 30 + 5 = 35. «25» — oxiridan boshlash xatosi (40 − 15)."},
 tn:"Bolalar ifoda ostiga amallar tartibini raqam bilan yozsin: ① ② ③. Bu odat keyingi sinflarda ham asqotadi."},
{h:"Qavs — birinchi",sum:"84 − (29 + 36): avval qavs 65, keyin 84 − 65 = 19.",a:"m02",
 start:function(){bqExpr(['84 − (29 + 36)']);bqMsg('Qaysi amalni <b>birinchi</b> bajaramiz? Pastdagi tugmalardan tanlang')},fin:function(){bqExpr(['84 − ([29 + 36])','84 − 65 = [19]'])},
 html:"<p>Qavs — «avval meni bajaring!» degan belgi. 84 − (29 + 36) da qaysi amal birinchi?</p>",
 btns:b7Pick(['84 − 29','29 + 36'],1,['84 − ([29 + 36])','84 − 65 = [19]'],'To‘g‘ri! Qavs ichi: 29 + 36 = 65, keyin 84 − 65 = <b>19</b>','Yo‘q — qavs ichidagi amal birinchi bajariladi'),g2:1,
 after:"<p><b>Qoida 2:</b> qavs bo'lsa — <b>avval qavs ichi</b> hisoblanadi, keyin qolgan amallar.</p>",
 q:{t:"46 − (17 + 19) = ?",opts:["48","12","10","20"],ok:2,why:"17 + 19 = 36, 46 − 36 = 10.",hint:"Avval qavs ichini hisoblang.",full:"Qavs: 17 + 19 = 36. Keyin 46 − 36 = 10. «48» — qavsni e'tiborsiz chapdan o'ngga hisoblash: 46 − 17 + 19."},
 tn:"Qavsni rangli qalam bilan o'rab, «quti» deb nomlang: «Avval qutini oching»."},
{h:"Qavs natijani o'zgartiradi",sum:"86 − 53 − 29 = 4, lekin 86 − (53 − 29) = 62. Qavs — muhim belgi!",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ikki ifodada sonlar bir xil, faqat bittasida qavs bor. Natijalar teng bo'ladimi?</p>",
 btns:[phaser(P3)],
 after:"<p>Qavs — bezak emas: u <b>hisob tartibini</b> o'zgartiradi, shuning uchun natija ham o'zgaradi. Qavsni ko'chirib yozishda tushirib qoldirmang!</p>",
 q:{t:"86 − (53 − 29) = ?",opts:["4","62","63","72"],ok:1,why:"53 − 29 = 24, 86 − 24 = 62.",hint:"Qavs ichi: 53 − 29. Keyin 86 dan ayiring.",full:"Qavs: 53 − 29 = 24. Keyin 86 − 24 = 62. «4» — qavssiz hisoblash natijasi."},
 tn:"Bir xil sonlar bilan qavsli va qavssiz ifodalar juftligini bering — bolalar farqni o'zi topsin."},
{h:"Ko'paytirish va bo'lish — qo'shishdan oldin",sum:"8 + 24 : 4: avval bo'lish 6, keyin 8 + 6 = 14.",a:"m04",
 start:function(){bqExpr(['8 + 24 : 4']);bqMsg('Qavs yo‘q. Qaysi amal birinchi?')},fin:function(){bqExpr(['8 + [24 : 4]','8 + 6 = [14]'])},
 html:"<p>Ifodada qo'shish ham, bo'lish ham bor: 8 + 24 : 4. Qaysi birini birinchi bajaramiz?</p>",
 btns:b7Pick(['8 + 24','24 : 4'],1,['8 + [24 : 4]','8 + 6 = [14]'],'To‘g‘ri! Bo‘lish birinchi: 24 : 4 = 6, keyin 8 + 6 = <b>14</b>','Yo‘q — ko‘paytirish va bo‘lish qo‘shish-ayirishdan oldin bajariladi'),g2:1,
 after:"<p><b>Qoida 3:</b> qavs yo'q bo'lsa, avval <b>ko'paytirish va bo'lish</b>, keyin <b>qo'shish va ayirish</b>. Ko'paytirish — «kuchliroq» amal.</p><p>To'liq tartib: <b>qavs → ko'paytirish/bo'lish → qo'shish/ayirish</b>.</p>",
 q:{t:"20 − 3 · 5 = ?",opts:["85","5","15","35"],ok:1,why:"3 · 5 = 15, 20 − 15 = 5.",hint:"Qaysi amal kuchliroq — ayirishmi yoki ko'paytirishmi?",full:"Avval ko'paytirish: 3 · 5 = 15. Keyin 20 − 15 = 5. «85» — chapdan o'ngga hisoblash xatosi: (20 − 3) · 5."},
 tn:"Darslikning 122–125-darslari. Tartibni zinapoya qilib chizing: 1-pog'ona — qavs, 2 — ko'paytirish/bo'lish, 3 — qo'shish/ayirish."},
{h:"Uch qavatli ifoda",sum:"90 − 4 · (12 + 8): qavs 20 → ko'paytirish 80 → ayirish 10.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p>Endi hamma qoidalar birga: <b>90 − 4 · (12 + 8)</b>. Qadam-baqadam yechamiz.</p>",
 btns:[phaser(P5,'▶ Keyingi amal')],
 after:"<p>Har qadamda ifodani <b>qayta yozib</b>, faqat bitta amalni bajaring. Shoshilganda eng ko'p xato shu yerda bo'ladi.</p>",
 q:{t:"93 − (35 + 27) + 5 · 3 = ?",opts:["46","36","16","100"],ok:0,why:"Qavs 62, ko'paytirish 15: 93 − 62 + 15 = 31 + 15 = 46.",hint:"Tartib: qavs, keyin ko'paytirish, keyin chapdan o'ngga.",full:"Qavs: 35 + 27 = 62. Ko'paytirish: 5 · 3 = 15. Endi chapdan o'ngga: 93 − 62 = 31, 31 + 15 = 46. «16» — 62 + 15 ni ayirib yuborish xatosi."},
 tn:"Har amal ustiga tartib raqamini yozdiring, keyin yeching. Bank testlarida shu tur ko'p."},
{h:"Tuzoq: ikkita qavs",sum:"52 − (9 + 14) − (8 + 13 − 7): qavslar 23 va 14 → 52 − 23 − 14 = 15.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Ikki qavs bo'lsa — ikkalasini ham avval hisoblaymiz, keyin qolganini chapdan o'ngga.</p>",
 btns:[phaser(P6)],
 after:"<p>Qavs ichida ham bir nechta amal bo'lishi mumkin (8 + 13 − 7) — uning ichida ham <b>chapdan o'ngga</b>.</p>",
 q:{t:"48 − (7 + 15 − 6) + (14 − 8) = ?",opts:["40","38","30","26"],ok:1,why:"Qavslar: 16 va 6. 48 − 16 + 6 = 38.",hint:"Avval ikkala qavsni alohida hisoblang.",full:"1-qavs: 7 + 15 − 6 = 16. 2-qavs: 14 − 8 = 6. Endi 48 − 16 + 6 = 32 + 6 = 38. «26» — oxirgi qavsni ayirib yuborish xatosi."},
 tn:"Har qavsni alohida rang bilan o'rang: ko'k va yashil qutilar."},
{h:"Tuzoq: qavsni o'zingiz qo'ying",sum:"20 − 8 − 2 = 14 bo'lishi uchun qavs: 20 − (8 − 2) = 14.",a:"m07",
 start:function(){bqExpr(['20 − 8 − 2 = 14 ?']);bqMsg('Qavssiz natija 10 chiqadi. Qavsni qayerga qo‘ysak, 14 bo‘ladi?')},fin:function(){bqExpr(['20 − (8 − 2) = 14','20 − 6 = [14] ✓'])},
 html:"<p>Olimpiada savoli: <b>20 − 8 − 2 = 14</b> to'g'ri bo'lishi uchun qavsni qayerga qo'yish kerak? Variantni tanlang:</p>",
 btns:b7Pick(['(20 − 8) − 2','20 − (8 − 2)'],1,['20 − (8 − 2)','20 − 6 = [14] ✓'],'To‘g‘ri! 8 − 2 = 6, 20 − 6 = <b>14</b>','Bu qavs natijani o‘zgartirmaydi: (20 − 8) − 2 = 10'),g2:1,
 after:"<p>Qavsni oldingi amalning ustiga qo'yish natijani o'zgartirmaydi — chunki tartib baribir chapdan o'ngga. Natijani o'zgartirish uchun qavs <b>keyingi</b> amalni oldinga chiqarishi kerak.</p>",
 q:{t:"Qaysi ifodaning qiymati 30 ga teng?",opts:["(4 + 2) · 5","4 + 2 · 5","4 · 5 + 2","4 + 5 · 2"],ok:0,why:"(4 + 2) · 5 = 6 · 5 = 30.",hint:"Har birini tartib bilan hisoblang: avval qavs, keyin ko'paytirish.",full:"(4 + 2) · 5 = 30. 4 + 2 · 5 = 4 + 10 = 14. 4 · 5 + 2 = 22. 4 + 5 · 2 = 14. Faqat birinchisi 30."},
 tn:"Bolalarga 1, 2, 3, 4 sonlari va amallar bilan «qavs qo'yib maqsadli sonni hosil qil» o'yinini o'ynating."},
{h:"Bilasizmi? Kalkulyator ham tartibni biladi",sum:"Oddiy kalkulyator har tugmani darhol hisoblaydi va xato beradi; ilmiy kalkulyator amallar tartibiga amal qiladi.",a:"m08",
 start:function(){calcB(false)},fin:function(){calcB(true)},
 html:"<p>📱 Oddiy kalkulyatorda <b>2 + 3 × 4</b> ni tersangiz, u <b>20</b> ko'rsatadi: u har tugmani darhol bajaradi (2 + 3 = 5, 5 × 4 = 20). Ilmiy kalkulyator va telefon kalkulyatori esa <b>14</b> ko'rsatadi. Qaysi biri to'g'ri? Tekshiring:</p>",
 btns:[["🔍 Tekshirish",function(c,done){calcB(true);done()}]],
 after:"<p>To'g'risi — <b>14</b>: avval 3 × 4 = 12, keyin 2 + 12. Amallar tartibi — butun dunyo matematiklari kelishgan qoida. Shuning uchun Toshkentda ham, Tokioda ham 2 + 3 · 4 = 14.</p>",
 tn:"Agar oddiy kalkulyator bo'lsa, sinfda sinab ko'ring — bolalar uchun juda qiziqarli tajriba."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bqExpr(['90 − 4 · (12 + 8)','① qavs  ② ·  ③ −','[10]'])},fin:function(){bqExpr(['90 − 4 · (12 + 8)','① qavs  ② ·  ③ −','[10]'])},
 html:"<div class='memo'><ul><li><b>1) Qavs</b> ichidagi amal birinchi.</li><li><b>2) Ko'paytirish va bo'lish</b>.</li><li><b>3) Qo'shish va ayirish</b>.</li><li>Bir xil darajadagi amallar — <b>chapdan o'ngga</b>: 50 − 20 + 5 = 35.</li><li>Qavs natijani o'zgartiradi: 86 − 53 − 29 = 4, 86 − (53 − 29) = 62.</li><li>Har qadamda ifodani qayta yozing, bitta amal bajaring.</li></ul></div>",
 tn:"Kartochkani daftar muqovasiga yopishtirtiring."}
];
function calcB(on){clear();var g=S.g;[[60,'Oddiy',on?'20':'?',C.bad],[240,'Ilmiy',on?'14':'?',C.ok]].forEach(function(k){E('rect',{x:k[0],y:20,width:90,height:130,rx:12,fill:'#33475b'},g);E('rect',{x:k[0]+8,y:30,width:74,height:30,rx:4,fill:'#d8f0d0'},g);T(g,k[0]+76,52,k[2],{'font-size':20,'font-weight':800,fill:'#1d2b3a','text-anchor':'end'});
 for(var r=0;r<3;r++)for(var c=0;c<3;c++)E('rect',{x:k[0]+10+c*24,y:70+r*24,width:20,height:18,rx:3,fill:'#6b7b8b'},g);T(g,k[0]+45,166,k[1],{'font-size':12,'font-weight':800,fill:k[3]})});
 T(g,180,92,'2 + 3 × 4',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});bqMsg(on?'2 + 3 × 4 = 2 + 12 = <b>14</b> — ilmiy kalkulyator to‘g‘ri':'Qaysi kalkulyator to‘g‘ri?')}
var PROBS=[
{t:"84 − (29 + 36) = ?",o:["19","21","29","91"],k:0,s:"Qavs 65, 84 − 65 = 19."},
{t:"46 − (17 + 19) = ?",o:["10","48","12","20"],k:0,s:"Qavs 36, 46 − 36 = 10."},
{t:"86 − (53 − 29) = ?",o:["62","4","63","72"],k:0,s:"Qavs 24, 86 − 24 = 62."},
{t:"8 + 24 : 4 = ?",o:["14","8","6","32"],k:0,s:"24 : 4 = 6, 8 + 6 = 14."},
{t:"90 − 4 · (12 + 8) = ?",o:["10","34","50","70"],k:0,s:"Qavs 20, 4 · 20 = 80, 90 − 80 = 10."},
{t:"52 − (9 + 14) − (8 + 13 − 7) = ?",o:["15","1","29","25"],k:0,s:"Qavslar 23 va 14: 52 − 23 − 14 = 15."},
{t:"48 − (7 + 15 − 6) + (14 − 8) = ?",o:["38","40","30","26"],k:0,s:"48 − 16 + 6 = 38."},
{t:"93 − (35 + 27) + 5 · 3 = ?",o:["46","36","16","100"],k:0,s:"93 − 62 + 15 = 46."},
{t:"50 − 20 + 5 = ?",o:["35","25","75","45"],k:0,s:"Chapdan o'ngga: 30 + 5 = 35."},
{t:"20 − 3 · 5 = ?",o:["5","85","15","35"],k:0,s:"3 · 5 = 15, 20 − 15 = 5."},
{t:"(20 − 3) · 2 = ?",o:["34","14","40","26"],k:0,s:"Qavs 17, 17 · 2 = 34."},
{t:"6 + 4 · 2 = ?",o:["14","20","12","16"],k:0,s:"4 · 2 = 8, 6 + 8 = 14."},
{t:"(6 + 4) · 2 = ?",o:["20","14","12","16"],k:0,s:"Qavs 10, 10 · 2 = 20."},
{t:"Qaysi ifodaning qiymati 30 ga teng?",o:["(4 + 2) · 5","4 + 2 · 5","4 · 5 + 2","4 + 5 · 2"],k:0,s:"(4 + 2) · 5 = 30; qolganlari 14, 22, 14."},
{t:"20 − 8 − 2 = 14 bo'lishi uchun qavs qayerga qo'yiladi?",o:["20 − (8 − 2)","(20 − 8) − 2","(20 − 8 − 2)","qavs kerak emas"],k:0,s:"20 − (8 − 2) = 20 − 6 = 14."},
{t:"81 − (27 + x) = 38. x nechaga teng?",o:["16","43","6","54"],k:0,s:"27 + x = 81 − 38 = 43, x = 16."},
{t:"40 : 4 + 6 = ?",o:["16","4","10","46"],k:0,s:"40 : 4 = 10, 10 + 6 = 16."},
{t:"40 : (4 + 6) = ?",o:["4","16","10","46"],k:0,s:"Qavs 10, 40 : 10 = 4."},
{t:"70 − (25 − 5) − 10 = ?",o:["40","60","50","30"],k:0,s:"Qavs 20: 70 − 20 − 10 = 40."},
{t:"3 · 4 + 2 · 5 = ?",o:["22","70","50","34"],k:0,s:"12 + 10 = 22."}
];
function PRACT_STAGE(){bqExpr(['① qavs','② ko‘paytirish, bo‘lish','③ qo‘shish, ayirish']);bqMsg('Bir xil darajada — chapdan o‘ngga')}
var PREP_DATA={teach:["Qavssiz ifodada qo'shish-ayirish chapdan o'ngga.","Qavs birinchi; qavs natijani o'zgartiradi.","Ko'paytirish va bo'lish qo'shish-ayirishdan oldin.","Murakkab tur: ikki qavs, qavsni o'zi qo'yish."],
 mist:["Qavssiz ifodani oxiridan hisoblaydi (50 − 20 + 5 = 25).","Ko'paytirishni oxirida bajaradi (20 − 3 · 5 = 85).","Ko'chirishda qavsni tushirib qoldiradi.","Qavs ichidagi bir nechta amalni noto'g'ri tartibda bajaradi."],
 need:["Rangli qalamlar (qavslarni o'rash uchun).","Imkon bo'lsa, oddiy kalkulyator."],
 board:["Zinapoya: <span class='w2'>① () ② · : ③ + −</span>.","<span class='w2'>50 − 20 + 5 = 35</span>.","<span class='w2'>84 − (29 + 36) = 19</span>.","<span class='w2'>86 − 53 − 29 = 4</span> va <span class='w2'>86 − (53 − 29) = 62</span>.","<span class='w2'>8 + 24 : 4 = 14</span>.","<span class='w2'>90 − 4 · (12 + 8) = 10</span>."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
