var CODE='3C2',TITLE='3-sinf · Jadval bo‘yicha bo‘lish';
function w3c2c(b,done,ok,mOk,mBad){if(!ok){var bg=b.style.background;b.style.background='#f8d7d7';bqMsg(mBad);setTimeout(function(){b.style.background=bg},2000);return}b.style.background='#e6f6ee';bqMsg(mOk);done()}
var P1=[function(){w3Arr(1,24,{lab:'24 ta yong‘oq'});bqMsg('24 ta yong‘oqni 4 bolaga teng bo‘lamiz')},function(){w3Arr(4,6,{lab:'har bolaga bittadan… qator-qator'});bqMsg('Har bolaga navbat bilan bittadan beramiz — 4 qator hosil bo‘ladi')},function(){w3Arr(4,6,{lab:'24 : 4 = 6'});bqMsg('Har bolaga 6 tadan: <b>24 : 4 = 6</b>')}];
var STEPS=[
{h:"Teng bo'lish",sum:"24 : 4 = 6: 24 ta narsani 4 ta teng guruhga bo'lsak, har birida 6 ta.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Bo'lish — <b>teng</b> bo'lish. 24 ta yong'oqni 4 bolaga hech kim xafa bo'lmaydigan qilib bo'lamiz:</p>",btns:[phaser(P1)],
 after:"<p><b>24 : 4 = 6</b>. 24 — <b>bo'linuvchi</b>, 4 — <b>bo'luvchi</b>, 6 — <b>bo'linma</b>. Tekshirish: 4 · 6 = 24 — bo'lish ko'paytirishning teskari amali.</p>",
 q:{t:"35 ta qalamni 5 ta qutiga teng joyladik. Har qutida nechta?",opts:["7","30","40","5"],ok:0,why:"35 : 5 = 7, chunki 5 · 7 = 35.",hint:"5 ni nechaga ko'paytirsak 35 bo'ladi?",full:"35 : 5 = 7 (tekshiruv 5 · 7 = 35). «30» — ayirilgan, «40» — qo'shilgan."},
 tn:"Haqiqiy narsalar bilan: 24 ta cho'pni 4 bolaga «sizga bitta, sizga bitta» usulida tarqatish."},
{h:"Sig'dirish: nechta guruh?",sum:"24 : 6 = 4: 24 ta narsani 6 tadan joylasak, 4 ta guruh chiqadi.",a:"m02",start:function(){w3Arr(4,6,{lab:'24 ta tuxum, qutiga 6 tadan'});bqMsg('Nechta quti kerak?')},fin:function(){w3Arr(4,6,{lab:'24 : 6 = 4 quti'});bqMsg('Har qator — bitta quti: 4 ta')},
 html:"<p>24 ta tuxum bor. Har qutiga <b>6 tadan</b> sig'adi. Nechta quti kerak?</p>",g3:1,
 btns:[["4 ta",function(c,d,b){w3Arr(4,6,{lab:'24 : 6 = 4 quti'});w3c2c(b,d,1,'24 : 6 = 4, tekshiruv: 4 · 6 = 24','')}],["6 ta",function(c,d,b){w3c2c(b,d,0,'','6 — bu bitta qutidagi tuxumlar soni, qutilar soni emas')}],["18 ta",function(c,d,b){w3c2c(b,d,0,'','24 − 6 = 18 — bu ayirish. Necha marta 6 tadan olish mumkin?')}]],
 after:"<p>Bo'lishning <b>ikki ma'nosi</b> bor: «nechtadan?» (24 ni 4 ga teng bo'lish) va «necha marta sig'adi?» (24 da 6 necha marta bor). Ikkalasi ham bitta amal: <b>bo'lish</b>.</p>",
 q:{t:"Qaysi masala 42 : 7 bilan yechilmaydi?",opts:["7 ta savatda 42 tadan olma bor. Jami nechta?","42 ta olma 7 ta savatga teng solindi. Har birida nechta?","42 ta olma 7 tadan solindi. Nechta savat?","42 metr arqonni 7 metrdan kesildi. Nechta bo'lak?"],ok:0,why:"Birinchisi — ko'paytirish: 7 · 42.",hint:"Qaysi masalada «jami» so'raladi?",full:"«7 ta savatda 42 tadan» — jami 7 · 42 = 294, bu ko'paytirish. Qolganlari 42 : 7 = 6."},
 tn:"Ikki ma'noni ikki xil predmet bilan: tarqatish (bolalarga) va qadoqlash (qutilarga)."},
{h:"Ko'paytirish-bo'lish oilasi",sum:"6 · 8 = 48 dan: 8 · 6 = 48, 48 : 6 = 8, 48 : 8 = 6 — to'rtta misol bitta faktdan.",a:"m03",start:function(){bqExpr(['6 · 8 = 48','48 : 6 = ?','48 : 8 = ?']);bqMsg('Bitta ko‘paytmadan ikkita bo‘lish')},fin:function(){bqExpr(['6 · 8 = 48','8 · 6 = 48','48 : 6 = 8','48 : 8 = [6]']);bqMsg('Uchburchak oilasi: 6, 8, 48')},
 html:"<p>6 · 8 = 48 ekanini bilamiz. Unda <b>48 : 8</b> = ?</p>",g3:1,
 btns:[["6",function(c,d,b){bqExpr(['6 · 8 = 48','8 · 6 = 48','48 : 6 = 8','48 : 8 = [6]']);w3c2c(b,d,1,'8 · 6 = 48, demak 48 : 8 = 6','')}],["8",function(c,d,b){w3c2c(b,d,0,'','48 : 6 = 8. Bizga 48 : 8 kerak — boshqa ko‘paytuvchi')}],["40",function(c,d,b){w3c2c(b,d,0,'','48 − 8 = 40 — bu ayirish')}]],
 after:"<p>Uchta son — 6, 8, 48 — bitta <b>«oila»</b>. Bo'lishni yodlash shart emas: <b>ko'paytirish jadvalini bilsangiz, bo'lishni ham bilasiz</b>. «48 : 8 = ?» o'rniga o'zingizdan so'rang: «8 ni nechaga ko'paytirsam 48 bo'ladi?»</p>",
 q:{t:"7 · 9 = 63. Qaysi tenglik NOTO'G'RI?",opts:["63 : 7 = 7","63 : 9 = 7","63 : 7 = 9","9 · 7 = 63"],ok:0,why:"63 : 7 = 9, 7 emas.",hint:"7 ni nechaga ko'paytirsak 63 bo'ladi?",full:"63 : 7 = 9 va 63 : 9 = 7. «63 : 7 = 7» noto'g'ri: 7 · 7 = 49."},
 tn:"Uchburchak kartochkalar: tepada ko'paytma (48), pastda 6 va 8. Bitta burchakni yopib, «yopilgan sonni toping»."},
{h:"Jadvaldan bo'lishni topish",sum:"56 : 7: jadvalning 7-qatoridan 56 ni topamiz — u 8-ustunda. 56 : 7 = 8.",a:"m04",start:function(){w3Tab([],null,{row:7});bqMsg('56 : 7 — 7-qatorda 56 ni qidiring')},fin:function(){w3Tab([[7,8]],null,{row:7});bqMsg('56 — 8-ustunda: 56 : 7 = 8')},
 html:"<p>7-qatorda (yashil) <b>56</b> ni toping. U qaysi ustunda?</p>",g3:1,
 btns:[["7-ustun",function(c,d,b){w3Tab([[7,7]],null,{row:7});w3c2c(b,d,0,'','7-ustunda 49 turibdi. Bir katak o‘ngga qarang')}],["8-ustun",function(c,d,b){w3Tab([[7,8]],null,{row:7});w3c2c(b,d,1,'56 : 7 = 8','')}],["9-ustun",function(c,d,b){w3Tab([[7,9]],null,{row:7});w3c2c(b,d,0,'','9-ustunda 63 turibdi. Chaproqqa qarang')}]],
 after:"<p>Jadval «teskari» o'qiladi: <b>bo'luvchi qatorida bo'linuvchini topamiz, ustun raqami — bo'linma</b>. Bu yerda 7-qator, 56 soni, 8-ustun.</p>",
 q:{t:"Jadvalning 9-qatorida 54 soni nechanchi ustunda?",opts:["6","9","5","7"],ok:0,why:"9 · 6 = 54, demak 54 : 9 = 6.",hint:"9 ni nechaga ko'paytirsak 54 bo'ladi?",full:"9 · 6 = 54 → 6-ustun, 54 : 9 = 6. «5» — 45, «7» — 63."},
 tn:"Proyektorsiz: bo'sh jadval varag'ida bolalar barmoqni qator bo'ylab yurgizsin."},
{h:"Nol va bir bilan bo'lish",sum:"a : 1 = a, a : a = 1, 0 : a = 0. Nolga bo'lish MUMKIN EMAS.",a:"m05",start:function(){bqExpr(['8 : 1 = 8','8 : 8 = 1','0 : 8 = 0','8 : 0 = ?']);bqMsg('Oxirgisi-chi?')},fin:function(){bqExpr(['8 : 1 = 8','8 : 8 = 1','0 : 8 = 0','8 : 0 — [mumkin emas]']);bqMsg('0 ni nechaga ko‘paytirsak ham 8 chiqmaydi')},
 html:"<p>8 ta konfetni 0 ta bolaga bo'lish mumkinmi? <b>8 : 0</b> = ?</p>",g3:1,
 btns:[["0",function(c,d,b){w3c2c(b,d,0,'','Tekshiring: 0 · 0 = 0, 8 emas')}],["8",function(c,d,b){w3c2c(b,d,0,'','Tekshiring: 0 · 8 = 0, 8 emas')}],["mumkin emas",function(c,d,b){bqExpr(['8 : 1 = 8','8 : 8 = 1','0 : 8 = 0','8 : 0 — [mumkin emas]']);w3c2c(b,d,1,'0 ni hech qanday songa ko‘paytirib 8 olib bo‘lmaydi','')}]],
 after:"<p>Tekshiruv orqali: 8 : 0 = □ bo'lsa, □ · 0 = 8 bo'lishi kerak. Lekin istalgan son · 0 = 0. Shuning uchun <b>nolga bo'lish mumkin emas</b>. Nolni esa bo'lish mumkin: <b>0 : 8 = 0</b> (hech narsani 8 kishiga bo'lsak, hech kimga hech narsa tegmaydi).</p>",
 q:{t:"Qaysi ifodaning qiymati 1 ga teng?",opts:["9 : 9","9 : 1","0 : 9","9 · 0"],ok:0,why:"Sonni o'ziga bo'lsak — 1.",hint:"a : a = ?",full:"9 : 9 = 1. 9 : 1 = 9, 0 : 9 = 0, 9 · 0 = 0."},
 tn:"«Nolga bo'lish» haqida bolalar munozara qilsin: tekshiruv (ko'paytirish) orqali o'zlari xulosa chiqarsin."},
{h:"Noma'lum komponentni topish",sum:"x · 7 = 63 → x = 63 : 7 = 9. 72 : x = 8 → x = 72 : 8 = 9. x : 6 = 9 → x = 9 · 6 = 54.",a:"m06",start:function(){bqExpr(['x : 6 = 9','x = ?']);bqMsg('Bo‘linuvchi noma’lum')},fin:function(){bqExpr(['x : 6 = 9','x = 9 · 6','x = [54]']);bqMsg('Bo‘linuvchi = bo‘linma · bo‘luvchi')},
 html:"<p><b>x : 6 = 9</b>. Noma'lum bo'linuvchini qanday topamiz?</p>",g3:1,
 btns:[["x = 9 : 6",function(c,d,b){w3c2c(b,d,0,'','9 ni 6 ga bo‘lib bo‘lmaydi (jadvalda). Bo‘linuvchi bo‘linmadan katta bo‘ladi')}],["x = 9 · 6",function(c,d,b){bqExpr(['x : 6 = 9','x = 9 · 6','x = [54]']);w3c2c(b,d,1,'x = 54. Tekshiruv: 54 : 6 = 9 ✓','')}],["x = 9 + 6",function(c,d,b){w3c2c(b,d,0,'','Tekshiring: 15 : 6 — jadvalda yo‘q')}]],
 after:"<p>Uchta qoida:<br>• noma'lum <b>ko'paytuvchi</b> = ko'paytma : ma'lum ko'paytuvchi;<br>• noma'lum <b>bo'linuvchi</b> = bo'linma · bo'luvchi;<br>• noma'lum <b>bo'luvchi</b> = bo'linuvchi : bo'linma.</p>",
 q:{t:"72 : x = 8. x = ?",opts:["9","576","64","80"],ok:0,why:"x = 72 : 8 = 9. Tekshiruv: 72 : 9 = 8 ✓.",hint:"Bo'luvchi noma'lum: bo'linuvchini bo'linmaga bo'ling.",full:"x = 72 : 8 = 9. «576» — 72 · 8 qilingan (bo'linuvchi qoidasi bilan adashtirilgan); «64» — 72 − 8."},
 tn:"Har tenglamani tekshiruv bilan tugatish shart."},
{h:"Tuzoq: amallar tartibi",sum:"48 : 6 · 2 = 8 · 2 = 16: ko'paytirish va bo'lish chapdan o'ngga, navbat bilan.",a:"m07",start:function(){bqExpr(['48 : 6 · 2 = ?']);bqMsg('Avval qaysi amal?')},fin:function(){bqExpr(['48 : 6 · 2','= 8 · 2','= [16]']);bqMsg('Chapdan o‘ngga!')},
 html:"<p>Ko'paytirish va bo'lish yonma-yon kelsa — <b>chapdan o'ngga</b>. <b>48 : 6 · 2</b> = ?</p>",g3:1,
 btns:[["4",function(c,d,b){w3c2c(b,d,0,'','Bu 48 : 12 — avval ko‘paytirildi. Lekin tartib chapdan o‘ngga!')}],["16",function(c,d,b){bqExpr(['48 : 6 · 2','= 8 · 2','= [16]']);w3c2c(b,d,1,'48 : 6 = 8, 8 · 2 = 16','')}],["12",function(c,d,b){w3c2c(b,d,0,'','6 · 2 = 12 — bu oraliq natija, javob emas')}]],
 after:"<p>Ko'paytirish bo'lishdan «kuchli» emas — ular <b>teng huquqli</b>, chapdan o'ngga bajariladi. Agar avval ko'paytirish kerak bo'lsa, qavs qo'yiladi: <b>48 : (6 · 2) = 4</b>. Qo'shish/ayirish esa ulardan keyin.</p>",
 q:{t:"36 − 24 : 6 · 2 = ?",opts:["28","4","32","1"],ok:0,why:"24 : 6 = 4, 4 · 2 = 8, 36 − 8 = 28.",hint:"Avval bo'lish va ko'paytirish (chapdan o'ngga), keyin ayirish.",full:"24 : 6 = 4, 4 · 2 = 8, 36 − 8 = 28. «4» — chapdan o'ngga hamma amal ketma-ket qilingan (36 − 24 = 12, 12 : 6 = 2, 2 · 2 = 4)."},
 tn:"Amallar tartibini doskada raqamlar bilan belgilash: har amal ustiga 1, 2, 3."},
{h:"«Necha marta» masalalari",sum:"56 soni 7 dan necha marta katta? 56 : 7 = 8 marta. 6 marta kichik: 48 : 6 = 8.",a:"m08",start:function(){bqBar(null,[{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a}],{title:'56 ni 7 lik bo‘laklarga ajratamiz'});bqMsg('56 da nechta 7 bor?')},fin:function(){bqBar(56,[{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a}],{title:'56 : 7 = 8 marta'});bqMsg('56 soni 7 dan 8 marta katta')},
 html:"<p>Akaning 56 ta markasi, ukaning 7 ta. Akaning markasi ukanikidan <b>necha marta ko'p</b>?</p>",g3:1,
 btns:[["49 marta",function(c,d,b){w3c2c(b,d,0,'','56 − 7 = 49 — bu «nechta ko‘p». «Necha marta» — bo‘lish!')}],["8 marta",function(c,d,b){bqBar(56,[{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a},{v:'7',w:1,col:C.a}],{title:'56 : 7 = 8 marta'});w3c2c(b,d,1,'56 : 7 = 8 marta','')}],["63 marta",function(c,d,b){w3c2c(b,d,0,'','56 + 7 — bu qo‘shish, bu yerda ma’nosi yo‘q')}]],
 after:"<p>Farqlang: <b>«nechta ko'p»</b> — ayirish (56 − 7 = 49 ta ko'p); <b>«necha marta ko'p»</b> — bo'lish (56 : 7 = 8 marta). «6 marta kam» degani — 6 ga bo'lish: 48 dan 6 marta kam son — 8.</p>",
 q:{t:"Lola 72 ta rasm chizdi, Nodira esa undan 9 marta kam. Nodira nechta rasm chizdi?",opts:["8","63","81","648"],ok:0,why:"9 marta kam — 9 ga bo'lamiz: 72 : 9 = 8.",hint:"«Marta kam» — qaysi amal?",full:"72 : 9 = 8. «63» — 9 ta kam (72 − 9) deb tushunilgan; «648» — 9 marta ko'p deb tushunilgan."},
 tn:"Ikki ustun: «… ta ko'p/kam» (+/−) va «… marta ko'p/kam» (·/:). Bolalar masala kartochkalarini ustunlarga ajratsin."},
{h:"Bilasizmi? Bo'lish belgilari",sum:"«:» belgisini nemis olimi Leybnits (1684), «÷» belgisini shveytsariyalik Iogann Ran (1659) qo'llagan.",a:"m09",start:function(){bqExpr(['48 : 6','48 ÷ 6','48 / 6']);bqMsg('Uchta yozuv — bitta amal')},fin:function(){bqExpr(['48 : 6 = 8','48 ÷ 6 = 8','48 / 6 = 8']);bqMsg('Har yerda javob bir xil')},
 html:"<p>🎓 Bizda bo'lish <b>«:»</b> bilan yoziladi — bu belgini nemis matematigi <b>Gotfrid Leybnits</b> 1684-yilda qo'llagan. Ingliz tilidagi darsliklarda esa <b>«÷»</b> ishlatiladi — uni shveytsariyalik <b>Iogann Ran</b> 1659-yilda kitobida qo'llagan. Kalkulyator va kompyuterda <b>«/»</b>.</p>",
 btns:[["💡 Hammasi bir xilmi?",function(c,done){bqExpr(['48 : 6 = 8','48 ÷ 6 = 8','48 / 6 = 8']);bqMsg('Ha — faqat yozuv turlicha');done()}]],
 after:"<p>Belgi turlicha, amal bitta. Kalkulyatorda «÷» tugmasi bor — bu bizning «:».</p>",
 tn:"Kalkulyatordagi ÷ tugmasini ko'rsatib, 3 ta belgini taqqoslash."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){bqExpr(['6 · 8 = 48','48 : 6 = 8','48 : 8 = 6']);bqMsg('Bo‘lish — ko‘paytirishning teskarisi')},fin:function(){bqExpr(['6 · 8 = 48','48 : 6 = 8','48 : 8 = 6']);bqMsg('Bo‘lish — ko‘paytirishning teskarisi')},
 html:"<div class='memo'><ul><li>Bo'linuvchi : bo'luvchi = bo'linma; tekshiruv — <b>bo'linma · bo'luvchi</b>.</li><li>Ikki ma'no: «nechtadan?» va «necha marta sig'adi?».</li><li>Bitta oila: 6 · 8 = 48 → 48 : 6 = 8, 48 : 8 = 6.</li><li>a : 1 = a, a : a = 1, 0 : a = 0, <b>nolga bo'lish mumkin emas</b>.</li><li>· va : — <b>chapdan o'ngga</b>.</li><li>«Necha marta» — bo'lish; «nechta» — ayirish.</li></ul></div>",
 tn:"Uyga: 5 ta «uchburchak oila» kartochkasi yasash."}
];
var PROBS=[
{t:"42 : 6 = ?",o:["7","6","8","36"],k:0,s:"6 · 7 = 42."},
{t:"63 : 9 = ?",o:["7","9","6","54"],k:0,s:"9 · 7 = 63."},
{t:"56 : 8 = ?",o:["7","8","6","48"],k:0,s:"8 · 7 = 56."},
{t:"81 : 9 = ?",o:["9","8","72","1"],k:0,s:"9 · 9 = 81."},
{t:"0 : 7 = ?",o:["0","7","1","mumkin emas"],k:0,s:"0 ni bo'lsak — 0."},
{t:"x · 8 = 64. x = ?",o:["8","56","72","9"],k:0,s:"64 : 8 = 8."},
{t:"x : 7 = 6. x = ?",o:["42","1","13","49"],k:0,s:"6 · 7 = 42."},
{t:"54 : x = 9. x = ?",o:["6","45","63","486"],k:0,s:"54 : 9 = 6."},
{t:"32 ta talabani 4 kishilik guruhlarga bo'ldik. Nechta guruh?",o:["8","28","36","4"],k:0,s:"32 : 4 = 8."},
{t:"45 soni 5 dan necha marta katta?",o:["9","40","50","8"],k:0,s:"45 : 5 = 9."},
{t:"Qaysi ifodaning qiymati eng katta?",o:["72 : 8","48 : 8","35 : 7","42 : 7"],k:0,s:"9, 6, 5, 6."},
{t:"24 : 4 · 2 = ?",o:["12","3","8","6"],k:0,s:"24 : 4 = 6, 6 · 2 = 12."},
{t:"24 : (4 · 2) = ?",o:["3","12","8","48"],k:0,s:"4 · 2 = 8, 24 : 8 = 3."},
{t:"50 − 36 : 4 = ?",o:["41","14","3","9"],k:0,s:"36 : 4 = 9, 50 − 9 = 41."},
{t:"Qaysi tenglik to'g'ri?",o:["0 : 6 = 0","6 : 0 = 0","6 : 6 = 0","0 : 6 = 6"],k:0,s:"0 : 6 = 0; nolga bo'lib bo'lmaydi; 6 : 6 = 1."},
{t:"Do'konda 48 ta bo'r bor edi. Ularni 6 tadan qutiga joyladi va 3 qutini sotdi. Nechta quti qoldi?",o:["5","8","2","30"],k:0,s:"48 : 6 = 8 quti, 8 − 3 = 5."},
{t:"Bir son 9 ga bo'linganda 8 chiqdi. Shu sonni 6 ga bo'lsak?",o:["12","72","9","48"],k:0,s:"Son 9 · 8 = 72, 72 : 6 = 12."},
{t:"Akada 64 so'm, ukada undan 8 marta kam. Ukada necha so'm?",o:["8","56","72","512"],k:0,s:"64 : 8 = 8."},
{t:"Qaysi sonni 6 ga ham, 8 ga ham qoldiqsiz bo'lish mumkin?",o:["48","36","32","42"],k:0,s:"48 : 6 = 8, 48 : 8 = 6. 36 : 8, 32 : 6, 42 : 8 — qoldiqli."},
{t:"Ikki son ko'paytmasi 56, bo'linmasi (kattasini kichigiga) 14. Bu sonlar?",o:["28 va 2","8 va 7","14 va 4","56 va 1"],k:0,s:"28 · 2 = 56, 28 : 2 = 14."}
];
function PRACT_STAGE(){bqExpr(['48 : 6 = ?','6 · ? = 48']);bqMsg('Bo‘lishni ko‘paytirish orqali toping')}
var PREP_DATA={teach:["Bo'lishning ikki ma'nosi: teng bo'lish va sig'dirish.","Ko'paytirish-bo'lish oilasi; jadvaldan bo'lishni o'qish.","0 va 1 bilan bo'lish, nolga bo'lish mumkin emasligi.","Noma'lum komponentlar; amallar tartibi; «necha marta» masalalari."],
 mist:["Bo'linma o'rniga bo'luvchini yozadi.","Nolga bo'lishni 0 yoki shu son deb oladi.","48 : 6 · 2 da avval ko'paytiradi.","«Necha marta» o'rniga ayiradi."],
 need:["Cho'plar/yong'oqlar tarqatish uchun.","Uchburchak oila kartochkalari.","Bo'sh 9×9 jadval."],
 board:["<span class='w2'>24 : 4 = 6, chunki 4 · 6 = 24</span>","<span class='w2'>6 · 8 = 48 → 48 : 6 = 8, 48 : 8 = 6</span>","<span class='w2'>8 : 0 — mumkin emas</span>","<span class='w2'>48 : 6 · 2 = 16</span>"]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>4?8:9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<n)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=Math.max(W*p/tot,34);E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,p+' · '+b+' = '+(p*b),{'font-size':w<70?10:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
