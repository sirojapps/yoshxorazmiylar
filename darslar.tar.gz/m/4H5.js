var CODE='4H5',TITLE='4-sinf · Katakli tekislik va koordinatalar';
function q5msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function q5X(i){return 28+27*i}function q5Y(j){return 152-23*j}
// o: pts [[x,y,lab,col]], segs [[x1,y1,x2,y2,col,dash]], polys [[pts,fill]], tap fn(x,y)
function q5grid(o){o=o||{};clear();var g=S.g,i,j;
 for(i=0;i<=10;i++)E('line',{x1:q5X(i),y1:q5Y(0),x2:q5X(i),y2:q5Y(6),stroke:'#e3e8ee','stroke-width':1},g);
 for(j=0;j<=6;j++)E('line',{x1:q5X(0),y1:q5Y(j),x2:q5X(10),y2:q5Y(j),stroke:'#e3e8ee','stroke-width':1},g);
 E('line',{x1:q5X(0),y1:q5Y(0),x2:q5X(10)+16,y2:q5Y(0),stroke:'#33475b','stroke-width':2.2},g);E('path',{d:'M'+(q5X(10)+16)+' 152 l-8 -4 v8 z',fill:'#33475b'},g);
 E('line',{x1:q5X(0),y1:q5Y(0),x2:q5X(0),y2:q5Y(6)-8,stroke:'#33475b','stroke-width':2.2},g);E('path',{d:'M28 '+(q5Y(6)-10)+' l-4 8 h8 z',fill:'#33475b'},g);
 T(g,q5X(10)+18,167,'x',{'font-size':12,'font-weight':800,fill:C.blue});T(g,40,12,'y',{'font-size':12,'font-weight':800,fill:C.bad});
 for(i=1;i<=10;i++)T(g,q5X(i),167,''+i,{'font-size':10,fill:C.blue});for(j=1;j<=6;j++)T(g,17,q5Y(j)+4,''+j,{'font-size':10,fill:C.bad});T(g,17,167,'O',{'font-size':10,'font-weight':800});
 (o.polys||[]).forEach(function(q){E('polygon',{points:q[0].map(function(p){return q5X(p[0])+','+q5Y(p[1])}).join(' '),fill:q[1]||'rgba(240,160,64,.35)',stroke:q[2]||C.a2,'stroke-width':2.5,'stroke-linejoin':'round'},g)});
 (o.segs||[]).forEach(function(q){E('line',{x1:q5X(q[0]),y1:q5Y(q[1]),x2:q5X(q[2]),y2:q5Y(q[3]),stroke:q[4]||C.a2,'stroke-width':q[5]?2:3.5,'stroke-dasharray':q[5]?'5 4':'none','stroke-linecap':'round'},g)});
 (o.pts||[]).forEach(function(p){E('circle',{cx:q5X(p[0]),cy:q5Y(p[1]),r:5.5,fill:p[3]||C.bad,stroke:'#fff','stroke-width':1.5},g);if(p[2]){var rt=p[0]>=7;T(g,q5X(p[0])+(rt?-9:9),q5Y(p[1])+(p[4]==='b'||p[1]>=6?15:-8),p[2],{'font-size':11,'font-weight':800,fill:p[3]||C.bad,'text-anchor':rt?'end':'start'})}});
 if(o.tap){var r=E('rect',{x:2,y:2,width:356,height:170,fill:'transparent',style:'cursor:crosshair'},sv);r.addEventListener('click',function(ev){var pt=sv.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;var p=pt.matrixTransform(sv.getScreenCTM().inverse());var x=Math.max(0,Math.min(10,Math.round((p.x-28)/27))),y=Math.max(0,Math.min(6,Math.round((152-p.y)/23)));o.tap(x,y)})}}
function q5lab(a){return a.map(function(p){return [p[0],p[1],p[2]]})}
var Q5R=[[1,1,'A'],[7,1,'B'],[7,4,'C'],[1,4,'D']];
var Q5P4=[function(){q5grid({pts:q5lab(Q5R)});q5msg('A(1; 1), B(7; 1), C(7; 4), D(1; 4) — to‘rtburchak uchlari')},
 function(){q5grid({polys:[[Q5R]],pts:q5lab(Q5R)});q5msg('AB: y bir xil → 7 − 1 = <b>6</b>. BC: x bir xil → 4 − 1 = <b>3</b>')},
 function(){q5grid({polys:[[Q5R]],pts:q5lab(Q5R)});q5msg('Yuzi: 6 · 3 = <b>18</b> katak. Perimetri: (6 + 3) · 2 = <b>18</b> birlik')}];
var Q5T=[[1,1,'A'],[7,1,'B'],[1,5,'C']];
var Q5P5=[function(){q5grid({polys:[[Q5T]],pts:q5lab(Q5T)});q5msg('Uchburchak ABC: A(1; 1), B(7; 1), C(1; 5). Kataklari chala — sanash qiyin')},
 function(){q5grid({polys:[[[[1,1],[7,1],[7,5],[1,5]],'rgba(31,111,178,.10)',C.blue],[Q5T]],pts:q5lab(Q5T).concat([[7,5,'',C.blue]])});q5msg('Uni to‘g‘ri to‘rtburchak ichiga joylaymiz: 6 · 4 = <b>24</b> katak')},
 function(){q5grid({polys:[[[[1,1],[7,1],[7,5],[1,5]],'rgba(31,111,178,.10)',C.blue],[Q5T]],segs:[[7,1,1,5,C.bad]],pts:q5lab(Q5T)});q5msg('Diagonal to‘rtburchakni <b>ikki teng</b> uchburchakka bo‘ladi: 24 : 2 = <b>12</b> katak')}];
var Q5W=[function(){q5grid({pts:[[1,1,'A(1; 1)',C.ok],[6,4,'B(6; 4)',C.blue]]});q5msg('Chumoli faqat katak chiziqlari bo‘ylab yuradi. A dan B ga eng qisqa yo‘l?')},
 function(){q5grid({segs:[[1,1,6,1,C.a2],[6,1,6,4,C.a2]],pts:[[1,1,'A',C.ok],[6,4,'B',C.blue]]});q5msg('1-yo‘l: o‘ngga 6 − 1 = 5, yuqoriga 4 − 1 = 3. Jami <b>8</b>')},
 function(){q5grid({segs:[[1,1,1,4,C.u],[1,4,6,4,C.u],[1,1,3,1,C.bad,1],[3,1,3,3,C.bad,1],[3,3,6,3,C.bad,1],[6,3,6,4,C.bad,1]],pts:[[1,1,'A',C.ok],[6,4,'B',C.blue]]});q5msg('Boshqa yo‘llar ham <b>8</b>: o‘ngga jami 5 va yuqoriga jami 3 baribir yuriladi')}];
function q5tri(dx,dy){return [[1+dx,1+dy],[4+dx,1+dy],[1+dx,3+dy]]}
function q5mv(){var t=q5tri(S.dx,S.dy);q5grid({polys:[[q5tri(5,2),'rgba(30,142,90,.12)',C.ok],[t]],pts:[[t[0][0],t[0][1],'A('+t[0][0]+'; '+t[0][1]+')']]})}
var STEPS=[
{h:"Nuqtani yasang",sum:"M(x; y): avval x o'qi bo'ylab o'ngga x, keyin yuqoriga y.",a:"m01",
 start:function(){q5grid({tap:q5t1});q5msg('M(8; 3) nuqtani to‘rda bosing')},fin:function(){q5grid({segs:[[0,0,8,0,C.blue,1],[8,0,8,3,C.bad,1]],pts:[[8,3,'M(8; 3)',C.ok]]});q5msg('✓ M(8; 3): o‘ngga 8, yuqoriga 3')},
 act:function(c,done){S.d1=done},
 html:"<p>3-sinfdan eslaymiz: nuqtaning o'rni ikki son bilan aytiladi. <b>M(8; 3)</b> nuqtani to'rdagi tugunni bosib yasang.</p>",
 after:"<p>Birinchi son <b>x</b> (abssissa) — o'ngga, ikkinchi son <b>y</b> (ordinata) — yuqoriga. M(8; 3) da x = 8, y = 3. Bu ikki son <b>nuqtaning koordinatalari</b> deyiladi.</p>",
 q:{t:"T nuqtadan pastga tushsak x o'qida 2, chapga yursak y o'qida 6 chiqadi. T ning koordinatalari?",opts:["T(6; 2)","T(2; 6)","T(8; 0)","T(2; 2)"],ok:1,why:"x o'qidagi son birinchi yoziladi: (2; 6).",hint:"Qavsda birinchi o'rinda qaysi o'qdagi son turadi?",full:"x o'qidagi son (2) birinchi, y o'qidagi son (6) ikkinchi: T(2; 6). T(6; 2) — sonlar o'rni almashgan, u boshqa nuqta."},
 tn:"Darsni 2 daqiqalik «Men o'ylagan nuqta» o'yini bilan boshlang: siz koordinata aytasiz, bolalar daftarda belgilaydi, qo'shnisi tekshiradi."},
{h:"Koordinatalarni o'qing",sum:"Nuqtadan x o'qiga tik, y o'qiga yotiq chiziq tushirib o'qiymiz.",a:"m02",
 start:function(){q5grid({pts:[[6,2,'P',C.bad]]});q5msg('P nuqtaning koordinatalari qanday? Tugmani tanlang')},fin:function(){q5grid({segs:[[6,0,6,2,C.blue,1],[0,2,6,2,C.bad,1]],pts:[[6,2,'P(6; 2)',C.ok]]});q5msg('✓ P(6; 2): pastda 6, chapda 2')},
 btns:[["(2; 6)",function(c,done){q5grid({pts:[[6,2,'P',C.bad],[2,6,'(2; 6)',C.grey]]});q5msg('(2; 6) — bu boshqa nuqta (kulrang). Sonlar o‘rni almashdi')}],["(6; 2)",function(c,done){STEPS[1].fin();done()}],["(6; 0)",function(c,done){q5grid({pts:[[6,2,'P',C.bad],[6,0,'(6; 0)',C.grey]]});q5msg('(6; 0) — x o‘qidagi nuqta. P esa yuqoriroqda')}],["(8; 0)",function(c,done){q5msg('6 + 2 = 8 deb qo‘shib bo‘lmaydi: koordinatalar alohida yoziladi')}]],g2:1,
 html:"<p>Sahnadagi <b>P</b> nuqtaning koordinatalarini tanlang.</p>",
 after:"<p>Nuqtadan <b>pastga</b> tik chiziq tushirsak — x o'qida <b>6</b>, <b>chapga</b> yotiq chiziq tortsak — y o'qida <b>2</b>. Demak P(6; 2).</p>",
 q:{t:"Qaysi nuqta y o'qida yotadi?",opts:["(4; 0)","(0; 4)","(4; 4)","(1; 4)"],ok:1,why:"y o'qida x = 0.",hint:"y o'qidagi nuqtaga borish uchun o'ngga necha qadam yuriladi?",full:"y o'qidagi nuqtada o'ngga yurilmaydi, ya'ni x = 0: (0; 4). (4; 0) esa x o'qida yotadi, chunki unda y = 0."},
 tn:"Tik va yotiq chiziqlarni bo'r bilan kesik chiziq qilib torting — bola sonni qayerdan o'qishni ko'radi."},
{h:"Kesmaning o'rtasi",sum:"Yotiq kesma o'rtasining x i — uchlari x larining o'rtasi: (1 + 9) : 2 = 5.",a:"m03",
 start:function(){q5grid({tap:q5t3,segs:[[1,2,9,2]],pts:[[1,2,'A(1; 2)'],[9,2,'B(9; 2)']]});q5msg('AB kesmaning o‘rtasini bosing')},fin:function(){q5grid({segs:[[1,2,5,2,C.u],[5,2,9,2,C.a2]],pts:[[1,2,'A'],[9,2,'B'],[5,2,'K(5; 2)',C.ok]]});q5msg('✓ K(5; 2): AK = KB = 4 katak')},
 act:function(c,done){S.d3=done},
 html:"<p>A(1; 2) va B(9; 2) kesmaning <b>o'rtasi</b> K ni toping va bosing.</p>",
 after:"<p>AB uzunligi 9 − 1 = <b>8</b>, yarmi <b>4</b>. A dan 4 qadam o'ngga: 1 + 4 = <b>5</b>. y o'zgarmaydi: <b>K(5; 2)</b>. Qisqa yo'l: (1 + 9) : 2 = 5.</p>",
 q:{t:"C(2; 1) va D(2; 7) kesmaning o'rtasi qayerda?",opts:["(2; 4)","(2; 3)","(4; 4)","(1; 4)"],ok:0,why:"x bir xil, y lar o'rtasi: (1 + 7) : 2 = 4.",hint:"Kesma tik: qaysi koordinata o'zgaradi?",full:"x = 2 ikkalasida bir xil — kesma tik. Uzunligi 7 − 1 = 6, yarmi 3: 1 + 3 = 4. O'rtasi (2; 4). (2; 3) — uzunlikning yarmini (3) koordinata deb olish xatosi."},
 tn:"Ko'p bolalar o'rtani «uzunlikning yarmi» deb 4 ni yozadi. «Yarmini qayerdan o'lchaymiz? — A dan!» deb so'rang."},
{h:"To'rtburchak yuzi koordinatalardan",sum:"Uchlari koordinatalari bilan berilgan to'g'ri to'rtburchakda tomonlar — koordinatalar ayirmasi.",a:"m04",
 start:function(){startPh(Q5P4)},fin:function(){S.ph=2;Q5P4[2]()},
 html:"<p>To'rtburchakning uchlari koordinatalari bilan berilgan. Kataklarni sanamay, faqat sonlardan yuz va perimetrni topamiz.</p>",
 btns:[phaser(Q5P4)],
 after:"<p>Yotiq tomon: <b>x lar ayirmasi</b> 7 − 1 = 6. Tik tomon: <b>y lar ayirmasi</b> 4 − 1 = 3. Yuz S = 6 · 3 = <b>18</b> kv. birlik, perimetr P = (6 + 3) · 2 = <b>18</b> birlik. Son bir xil chiqdi, lekin yuz va perimetr — <b>har xil kattaliklar</b>.</p>",
 q:{t:"Uchlari (2; 1), (9; 1), (9; 5), (2; 5) bo'lgan to'g'ri to'rtburchakning yuzi?",opts:["28","22","24","20"],ok:0,why:"Tomonlar 9 − 2 = 7 va 5 − 1 = 4: 7 · 4 = 28.",hint:"Avval ikkala tomonni koordinatalar ayirmasidan toping.",full:"Yotiq tomon 9 − 2 = 7, tik tomon 5 − 1 = 4, yuz 7 · 4 = 28. 22 — perimetr ((7 + 4) · 2). 24 va 20 — tomonlardan birini 9 yoki 5 deb (ayirmasdan) olish xatosi."},
 tn:"Yuz va perimetr bir xil son chiqqan holat — ajoyib munozara: «Bular tengmi?» Javob: birliklari har xil (kv. birlik va birlik)."},
{h:"Uchburchak yuzi: to'rtburchakning yarmi",sum:"To'g'ri burchakli uchburchak — to'g'ri to'rtburchakning yarmi: (6 · 4) : 2 = 12.",a:"m05",
 start:function(){startPh(Q5P5)},fin:function(){S.ph=2;Q5P5[2]()},
 html:"<p>Uchburchakning kataklari chala. Ularni sanamasdan yuzini qanday topamiz?</p>",
 btns:[phaser(Q5P5)],
 after:"<p>Uchburchakni to'g'ri to'rtburchak ichiga joylaymiz: 6 · 4 = 24. <b>Diagonal</b> uni ikkita teng uchburchakka bo'ladi, demak uchburchak yuzi <b>24 : 2 = 12</b> kv. birlik. Bu usul katakli qog'ozdagi har qanday to'g'ri burchakli uchburchak uchun ishlaydi.</p>",
 q:{t:"Uchlari (0; 0), (8; 0), (0; 3) bo'lgan uchburchakning yuzi necha katak?",opts:["12","24","11","22"],ok:0,why:"(8 · 3) : 2 = 12.",hint:"Shu uchburchakni ichiga oladigan to'g'ri to'rtburchak yuzi qancha?",full:"To'rtburchak 8 · 3 = 24, uchburchak uning yarmi: 12. 24 — ikkiga bo'lishni unutish, 11 — (8 + 3) qo'shib yuborish, 22 — perimetr formulasi."},
 tn:"Qog'ozdan to'rtburchak qirqib, diagonal bo'yicha kesing — ikkala bo'lak ustma-ust tushadi. Bu yarmi ekanini qo'lda isbotlaydi."},
{h:"Shaklni siljitamiz (parallel ko'chirish)",sum:"Shakl o'ngga a, yuqoriga b siljisa, har bir uchiga (+a; +b) qo'shiladi.",a:"m06",
 start:function(){S.dx=0;S.dy=0;q5mv();q5msg('Uchburchakni yashil izga olib boring')},fin:function(){S.dx=5;S.dy=2;q5mv();q5msg('✓ A(1; 1) → A(6; 3): o‘ngga 5, yuqoriga 2. Shakl o‘zgarmadi')},
 btns:[["→ o'ngga 1",function(c,done){S.dx++;q5s6(done)}],["↑ yuqoriga 1",function(c,done){S.dy++;q5s6(done)}]],g2:1,
 html:"<p>To'q sariq uchburchakni tugmalar bilan yashil izga olib boring. A uchining koordinatalari qanday o'zgaradi?</p>",
 after:"<p>Shakl <b>o'ngga 5</b> va <b>yuqoriga 2</b> siljidi. Har bir uchda x ga 5, y ga 2 qo'shildi: A(1; 1) → A(6; 3). Shaklning o'lchami va ko'rinishi <b>o'zgarmaydi</b> — bu <b>parallel ko'chirish</b>.</p>",
 q:{t:"Kvadratning uchi K(3; 4). Kvadratni chapga 2, pastga 3 siljitdik. K qayerga tushdi?",opts:["(1; 1)","(5; 7)","(1; 7)","(6; 2)"],ok:0,why:"x: 3 − 2 = 1, y: 4 − 3 = 1.",hint:"Chapga siljish x ni oshiradimi yoki kamaytiradimi?",full:"Chapga 2: x = 3 − 2 = 1. Pastga 3: y = 4 − 3 = 1. Javob (1; 1). (5; 7) — hammasini qo'shib yuborish, (1; 7) — y ga qo'shib yuborish."},
 tn:"Shaffof qog'ozga (yoki kalka) uchburchak chizib, uni daftar bo'ylab siljitib ko'rsating — burilmaydi, faqat suriladi."},
{h:"Tuzoq: parallelogrammning to'rtinchi uchi",sum:"Parallelogrammda qarama-qarshi tomonlar bir xil siljish bilan beriladi: B dan C ga qanday borsak, A dan D ga ham shunday.",a:"m07",
 start:function(){q5grid({tap:q5t7,segs:[[1,1,5,1],[5,1,7,4]],pts:[[1,1,'A(1; 1)'],[5,1,'B(5; 1)',C.bad,'b'],[7,4,'C(7; 4)']]});q5msg('ABCD parallelogramm. D ni bosing')},fin:function(){q5grid({polys:[[[[1,1],[5,1],[7,4],[3,4]]]],pts:[[1,1,'A'],[5,1,'B'],[7,4,'C'],[3,4,'D(3; 4)',C.ok]]});q5msg('✓ D(3; 4): B→C kabi A→D: o‘ngga 2, yuqoriga 3')},
 act:function(c,done){S.d7=done},
 html:"<p>ABCD — <b>parallelogramm</b> (qarama-qarshi tomonlari parallel va teng). A(1; 1), B(5; 1), C(7; 4). <b>D</b> ni toping va bosing. Ehtiyot bo'ling: bu to'g'ri to'rtburchak emas!</p>",
 after:"<p>B(5; 1) dan C(7; 4) ga: o'ngga <b>2</b>, yuqoriga <b>3</b>. AD tomon BC ga parallel va teng, demak A dan ham shunday yuramiz: (1 + 2; 1 + 3) = <b>D(3; 4)</b>. Ko'pchilik (1; 4) ni bosadi — u holda to'g'ri to'rtburchak emas, trapetsiya chiqadi.</p>",
 q:{t:"Parallelogramm uchlari: A(0; 0), B(4; 0), C(6; 2). D qayerda?",opts:["(2; 2)","(0; 2)","(6; 0)","(10; 2)"],ok:0,why:"B→C: o'ngga 2, yuqoriga 2. A dan ham: (2; 2).",hint:"B dan C ga qanday siljiymiz? Shu siljishni A ga qo'llang.",full:"B(4; 0) → C(6; 2): o'ngga 2, yuqoriga 2. A(0; 0) ga ham shuni qo'shamiz: D(2; 2). (0; 2) — to'g'ri to'rtburchak deb o'ylash xatosi."},
 tn:"Bu — olimpiada turidagi tuzoq. Bolalar avval (1; 4) ni bosishiga yo'l qo'ying, keyin shakl tomonlarini o'lchab, parallel emasligini o'zlari ko'rsin."},
{h:"Katak chiziqlari bo'ylab eng qisqa yo'l",sum:"Faqat chiziqlar bo'ylab yurilsa, eng qisqa yo'l = x lar ayirmasi + y lar ayirmasi.",a:"m08",
 start:function(){startPh(Q5W)},fin:function(){S.ph=2;Q5W[2]()},
 html:"<p>Shahar ko'chalari katakli bo'lsa, ikki joy orasidagi yo'l to'g'ri chiziq bo'ylab emas, ko'chalar bo'ylab o'lchanadi.</p>",
 btns:[phaser(Q5W)],
 after:"<p>A(1; 1) dan B(6; 4) ga: o'ngga jami <b>6 − 1 = 5</b>, yuqoriga jami <b>4 − 1 = 3</b>. Qaysi tartibda yursak ham (orqaga qaytmasak) yo'l <b>5 + 3 = 8</b> qadam. Bunday masofa «taksi masofasi» deb ham ataladi.</p>",
 q:{t:"Robot (2; 5) dan (9; 1) ga faqat katak chiziqlari bo'ylab boradi. Eng qisqa yo'l necha qadam?",opts:["11","3","8","17"],ok:0,why:"9 − 2 = 7 va 5 − 1 = 4: 7 + 4 = 11.",hint:"x lar qanchaga farq qiladi? y lar-chi?",full:"O'ngga 9 − 2 = 7, pastga 5 − 1 = 4, jami 11. 3 — ikki ayirmani ayirish (7 − 4), 8 — y larni noto'g'ri ayirish, 17 — sonlarni shunchaki qo'shish."},
 tn:"Sinf partalari orasidagi yo'laklarni «ko'chalar» deb olib, bolalarni bir partadan boshqasiga eng qisqa yo'l bilan yurdiring."},
{h:"Bilasizmi? Yer shari koordinatalari",sum:"Yer yuzidagi har bir joy ham ikki son — kenglik va uzunlik bilan aytiladi.",a:"m09",
 start:function(){q5grid({pts:[[8,3,'M(8; 3)']]});q5msg('Tekislikda — (x; y). Yer sharida — (kenglik; uzunlik)')},fin:function(){q5grid({pts:[[8,3,'M(8; 3)']]});q5msg('Tekislikda — (x; y). Yer sharida — (kenglik; uzunlik)')},
 html:"<p>📘 Nuqtani ikki son bilan yozish usulini fransuz olimi <b>Rene Dekart</b> 1637-yilda chop etilgan kitobida bayon qilgan.</p><p>🌍 Yer sharidagi har bir joy ham ikki son bilan aytiladi: <b>kenglik</b> va <b>uzunlik</b>. Masalan, Toshkent taxminan <b>41° shimoliy kenglik</b> va <b>69° sharqiy uzunlik</b>da joylashgan. Telefondagi xarita (GPS) aynan shu ikki son bilan ishlaydi.</p><p>📐 Buyuk olim <b>Abu Rayhon Beruniy</b> X–XI asrlarda ko'plab shaharlarning kenglik va uzunligini hisoblab, jadval tuzgan.</p>",
 tn:"Telefondagi xaritada maktabingiz koordinatasini ko'rsating — ikki son chiqadi. Bu bolalar uchun juda ta'sirli."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){q5grid({pts:[[8,3,'M(8; 3)']]});q5msg('M(8; 3): x = 8 (o‘ngga), y = 3 (yuqoriga)')},fin:function(){q5grid({pts:[[8,3,'M(8; 3)']]});q5msg('M(8; 3): x = 8 (o‘ngga), y = 3 (yuqoriga)')},
 html:"<div class='memo'><ul><li><b>M(x; y)</b>: x — o'ngga, y — yuqoriga. Tartib muhim: (2; 6) ≠ (6; 2).</li><li>x o'qida y = 0, y o'qida x = 0.</li><li>Yotiq kesma uzunligi — x lar ayirmasi, tik kesma — y lar ayirmasi.</li><li>Kesma o'rtasi: uchlar koordinatalarining yarim yig'indisi, (1 + 9) : 2 = 5.</li><li>To'g'ri burchakli uchburchak yuzi — to'rtburchak yuzining yarmi.</li><li>Siljitish: o'ngga a, yuqoriga b → (x + a; y + b).</li><li>Parallelogrammning 4-uchi: B→C siljishini A ga qo'llang.</li><li>Chiziqlar bo'ylab eng qisqa yo'l = x ayirmasi + y ayirmasi.</li></ul></div>",
 tn:"Uyga: daftarda o'z ismingizning birinchi harfini koordinatalar bilan «shifrlab», qo'shningizga yasating."}
];
function q5t1(x,y){if(x===8&&y===3){STEPS[0].fin();if(S.d1){var d=S.d1;S.d1=null;d()}}else if(S.d1){q5grid({tap:q5t1,pts:[[x,y,'('+x+'; '+y+')',C.grey]]});q5msg(x===3&&y===8?'Bu (3; 8) emas — sonlar o‘rni almashdi':'Bu ('+x+'; '+y+'). Kerak: o‘ngga <b>8</b>, yuqoriga <b>3</b>')}}
function q5t3(x,y){if(x===5&&y===2){STEPS[2].fin();if(S.d3){var d=S.d3;S.d3=null;d()}}else if(S.d3){q5grid({tap:q5t3,segs:[[1,2,9,2]],pts:[[1,2,'A(1; 2)'],[9,2,'B(9; 2)'],[x,y,'('+x+'; '+y+')',C.grey]]});q5msg(x===4&&y===2?'(4; 2): 4 — bu yarim uzunlik. A dan 4 qadam yuring: 1 + 4 = ?':(y!==2?'O‘rta kesmaning ustida bo‘ladi (y = 2)':'('+x+'; 2) dan A gacha '+(x-1)+', B gacha '+(9-x)+' — teng emas'))}}
function q5t7(x,y){if(x===3&&y===4){STEPS[6].fin();if(S.d7){var d=S.d7;S.d7=null;d()}}else if(S.d7){q5grid({tap:q5t7,segs:[[1,1,5,1],[5,1,7,4],[7,4,x,y,C.grey,1],[x,y,1,1,C.grey,1]],pts:[[1,1,'A(1; 1)'],[5,1,'B(5; 1)',C.bad,'b'],[7,4,'C(7; 4)'],[x,y,'('+x+'; '+y+')',C.grey]]});q5msg(x===1&&y===4?'Tuzoq! (1; 4) da AD tik, BC esa qiya — parallel emas':'('+x+'; '+y+') — AD tomon BC ga parallel emas. B→C: o‘ngga 2, yuqoriga 3')}}
function q5s6(done){if(S.dx===5&&S.dy===2){STEPS[5].fin();done();return}if(S.dx>5){S.dx=5;q5mv();q5msg('O‘ngga yetarli (5). Endi faqat yuqoriga');return}if(S.dy>2){S.dy=2;q5mv();q5msg('Yuqoriga yetarli (2). Endi faqat o‘ngga');return}q5mv();q5msg('Siljish: o‘ngga '+S.dx+', yuqoriga '+S.dy)}
var PROBS=[
{t:"O'ngga 7, yuqoriga 2 qadam. Nuqta koordinatalari?",o:["(7; 2)","(2; 7)","(9; 0)","(7; 7)"],k:0,s:"Avval x = 7, keyin y = 2."},
{t:"Qaysi nuqta x o'qida yotadi?",o:["(5; 0)","(0; 5)","(5; 5)","(1; 5)"],k:0,s:"x o'qida y = 0."},
{t:"A(3; 6) va B(10; 6) orasidagi kesma uzunligi?",o:["7","13","6","3"],k:0,s:"y bir xil: 10 − 3 = 7."},
{t:"C(4; 1) va D(4; 7) kesmaning o'rtasi?",o:["(4; 4)","(4; 3)","(4; 6)","(2; 4)"],k:0,s:"(1 + 7) : 2 = 4. O'rtasi (4; 4)."},
{t:"E(2; 3) va F(10; 3) kesmaning o'rtasi?",o:["(6; 3)","(4; 3)","(8; 3)","(5; 3)"],k:0,s:"(2 + 10) : 2 = 6."},
{t:"Uchlari (1; 2), (6; 2), (6; 5), (1; 5) bo'lgan to'rtburchakning yuzi?",o:["15","16","8","30"],k:0,s:"5 · 3 = 15."},
{t:"Uchlari (0; 0), (9; 0), (9; 4), (0; 4) bo'lgan to'rtburchakning perimetri?",o:["26","36","13","22"],k:0,s:"(9 + 4) · 2 = 26."},
{t:"Uchlari (0; 0), (6; 0), (0; 5) bo'lgan uchburchakning yuzi?",o:["15","30","11","22"],k:0,s:"(6 · 5) : 2 = 15."},
{t:"Nuqta (4; 2) ni o'ngga 3, yuqoriga 4 siljitdik. Yangi nuqta?",o:["(7; 6)","(8; 5)","(7; 2)","(1; 6)"],k:0,s:"(4 + 3; 2 + 4) = (7; 6)."},
{t:"Nuqta (9; 5) ni chapga 4, pastga 5 siljitdik. Yangi nuqta?",o:["(5; 0)","(13; 10)","(4; 5)","(5; 5)"],k:0,s:"(9 − 4; 5 − 5) = (5; 0) — x o'qiga tushdi."},
{t:"Kvadrat uchlari (2; 1), (5; 1), (5; 4). To'rtinchi uch?",o:["(2; 4)","(4; 2)","(5; 5)","(1; 4)"],k:0,s:"x ni (2; 1) dan, y ni (5; 4) dan: (2; 4)."},
{t:"Parallelogramm A(1; 1), B(6; 1), C(8; 4). D qayerda?",o:["(3; 4)","(1; 4)","(8; 1)","(13; 4)"],k:0,s:"B→C: o'ngga 2, yuqoriga 3. A dan: (3; 4)."},
{t:"(1; 1) dan (7; 5) ga faqat katak chiziqlari bo'ylab eng qisqa yo'l necha birlik?",o:["10","6","4","14"],k:0,s:"6 + 4 = 10."},
{t:"Kvadratning bir tomoni (2; 2) dan (2; 7) gacha. Kvadrat yuzi?",o:["25","20","10","5"],k:0,s:"Tomon 7 − 2 = 5, yuz 5 · 5 = 25."},
{t:"A(0; 0), B(8; 0), C(8; 6) — to'g'ri to'rtburchakning uchta uchi. Uning yuzi ABC uchburchak yuzidan necha marta katta?",o:["2 marta","4 marta","3 marta","Teng"],k:0,s:"Diagonal to'rtburchakni ikki teng uchburchakka bo'ladi: 48 va 24."},
{t:"K nuqta x o'qida, O dan 6 birlik o'ngda. L nuqta y o'qida, O dan 4 birlik yuqorida. OKL uchburchak yuzi?",o:["12","24","10","20"],k:0,s:"K(6; 0), L(0; 4): (6 · 4) : 2 = 12."},
{t:"Ikki nuqta: (3; 4) va (x; 4). Ular orasidagi masofa 5. x ning eng katta qiymati?",o:["8","5","2","15"],k:0,s:"x − 3 = 5, demak x = 8."},
{t:"To'g'ri to'rtburchak uchlari (1; 1) va (7; 4) qarama-qarshi uchlar. Qolgan ikki uch?",o:["(7; 1) va (1; 4)","(4; 1) va (1; 7)","(1; 7) va (7; 1)","(4; 4) va (1; 1)"],k:0,s:"x larni va y larni almashtirib olamiz: (7; 1), (1; 4)."},
{t:"Uchburchak A(1; 1), B(5; 1), C(3; 4). Uni o'ngga 4 siljitsak, C qayerga tushadi?",o:["(7; 4)","(3; 8)","(7; 8)","(5; 4)"],k:0,s:"C ga x bo'yicha 4 qo'shamiz: (7; 4)."},
{t:"Shakl uchlari: (0; 0), (6; 0), (6; 2), (2; 2), (2; 5), (0; 5). Uning yuzi?",o:["18","30","22","24"],k:0,s:"Ikki to'rtburchak: 6 · 2 = 12 va 2 · 3 = 6. Jami 18."}
];
function PRACT_STAGE(){q5grid({pts:[[8,3,'M(8; 3)'],[2,5,'N(2; 5)',C.blue]]})}
var PREP_DATA={teach:["Nuqtaning koordinatalari (x; y), o'qlardagi nuqtalar — takrorlash.","Kesma uzunligi va o'rtasi koordinatalar orqali.","To'g'ri to'rtburchak va to'g'ri burchakli uchburchak yuzi katakli tekislikda.","Parallel ko'chirish; parallelogrammning to'rtinchi uchi; chiziqlar bo'ylab eng qisqa yo'l."],
 mist:["Koordinatalar o'rnini almashtiradi.","Kesma o'rtasi o'rniga uzunlikning yarmini yozadi.","Uchburchak yuzida ikkiga bo'lishni unutadi.","Parallelogrammni to'g'ri to'rtburchak deb hisoblaydi.","Chapga/pastga siljitganda qo'shib yuboradi."],
 need:["Katakli daftar, chizg'ich, rangli qalam.","Doskada koordinata to'ri.","Kalka yoki shaffof qog'oz (siljitish uchun).","Qog'oz to'rtburchak va qaychi (diagonal tajribasi)."],
 board:["M(x; y): x → , y ↑.","AB: (1; 2)–(9; 2), o'rtasi (5; 2).","S = 6 · 3 = 18, P = 18 (har xil birlik!).","Uchburchak = (6 · 4) : 2 = 12.","Siljitish: (x + a; y + b).","Parallelogramm: D = A + (B→C).","Eng qisqa yo'l: 5 + 3 = 8."]};
