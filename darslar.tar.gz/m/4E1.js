var CODE='4E1',TITLE='4-sinf · Ko‘p amalli masalalar';
var P1=[function(){w3Bar([{lab:'jami',segs:[{w:6000,t:'6000 kg urug‘'}],tot:6000}],{top:60});w3Msg('Fermerda 6000 kg urug‘ bor. 3 dalaga 1200 kg dan, 2 dalaga 950 kg dan sepdi')},
 function(){w3Bar([{lab:'jami',segs:[{w:3600,t:'3 · 1200 = 3600'},{w:2400,t:'',c:'#fff'}],tot:6000,br:'1-savol',brw:0.6}],{top:60});w3Msg('1) 3 ta dalaga: 1200 · 3 = <b>3600</b> kg')},
 function(){w3Bar([{lab:'jami',segs:[{w:3600,t:'3600'},{w:1900,t:'1900',c:C.a},{w:500,t:'',c:'#fff'}],tot:6000}],{top:60});w3Msg('2) 2 ta dalaga: 950 · 2 = <b>1900</b> kg')},
 function(){w3Bar([{lab:'jami',segs:[{w:5500,t:'sepildi: 5500',c:'#9cc8ee'},{w:500,t:'',c:'#fff'}],tot:6000}],{top:60});w3Msg('3) Hammasi sepildi: 3600 + 1900 = <b>5500</b> kg')},
 function(){w3Bar([{lab:'jami',segs:[{w:5500,t:'5500',c:'#9cc8ee'},{w:500,t:'',c:C.ok}],tot:6000,br:'6000',brw:1}],{top:60});T(S.g,300,112,'qoldi: 500',{'font-size':14,'font-weight':800,fill:C.ok});w3Msg('4) Qoldi: 6000 − 5500 = <b>500</b> kg')}];
var P4=[function(){w3Expr(['? → −12 +8 → −15 → 26']);w3Msg('Avval nechta yo‘lovchi bo‘lgan? Oxiridan boshlaymiz')},
 function(){w3Expr(['26 + 15 = {41}']);w3Msg('2-bekatda 15 kishi tushgan edi — qaytaramiz: +15')},
 function(){w3Expr(['41 − 8 = {33}']);w3Msg('1-bekatda 8 kishi chiqqan edi — qaytaramiz: −8')},
 function(){w3Expr(['33 + 12 = {45}']);w3Msg('1-bekatda 12 kishi tushgan edi — qaytaramiz: +12. Avval <b>45</b> kishi')},
 function(){w3Expr(['45 − 12 + 8 − 15 = {26} ✓']);w3Msg('Tekshiruv: to‘g‘ri yo‘nalishda o‘tib chiqamiz')}];
var P5=[function(){w3Bar([{lab:'Q',segs:[{w:1,t:'q'},{w:1,t:'q'},{w:1,t:'q'}],tot:7},{lab:'R',segs:[{w:1,t:'q',c:C.a},{w:1,t:'+1200',c:'#f6c9c9'},{w:1,t:'q',c:C.a},{w:1,t:'+1200',c:'#f6c9c9'}],tot:7}]);w3Msg('Q — qalam, R — ruchka. Ruchka = qalam + 1200. Jami 8400')},
 function(){w3Bar([{lab:'5 Q',segs:[{w:1,t:'q'},{w:1,t:'q'},{w:1,t:'q'},{w:1,t:'q',c:C.a},{w:1,t:'q',c:C.a}],tot:7},{lab:'+',segs:[{w:2,t:'2400',c:'#f6c9c9'}],tot:7}]);w3Msg('5 ta «qalam» + 2 · 1200 = 8400 → 5 ta qalam = 8400 − 2400 = 6000')},
 function(){w3Expr(['qalam = 6000 : 5 = {1200}','ruchka = 1200 + 1200 = {2400}','tekshiruv: 3600 + 4800 = 8400 ✓']);w3Msg('Qalam 1200, ruchka 2400 so‘m')}];
var STEPS=[
{h:"Reja: savollar zanjiri",sum:"6000 − (1200 · 3 + 950 · 2) = 6000 − 5500 = 500 kg. Har savol — bitta amal.",a:"m01",
 start:w4St(P1),fin:w4Fin(P1),
 html:"<p>«Fermerda 6000 kg urug' bor edi. 3 ta dalaga 1200 kg dan, 2 ta dalaga 950 kg dan sepdi. Qancha urug' qoldi?» Ko'p amalli masalani <b>savollar zanjiri</b>ga bo'lamiz:</p>",btns:[phaser(P1)],
 after:"<p>Reja: 1) 3 dalaga qancha? 2) 2 dalaga qancha? 3) jami qancha sepildi? 4) qancha qoldi? Bitta ifoda: <b>6000 − (1200 · 3 + 950 · 2) = 500</b>.</p>",
 q:{t:"Fermerda 6000 kg urug' bor edi. 3 ta dalaga 1200 kg dan, 2 ta dalaga 950 kg dan sepdi. Qancha qoldi?",opts:["500 kg","3850 kg","5500 kg","1100 kg"],ok:0,why:"6000 − 5500 = 500.",hint:"Avval jami sepilganini toping.",full:"3600 + 1900 = 5500, 6000 − 5500 = 500. «3850» — 1200 va 950 ni bir martadan ayirish (dalalar soni unutilgan); «5500» — sepilgani, qolgani emas."},
 tn:"Polya usuli: 1) tushun, 2) reja, 3) bajar, 4) tekshir. Rejani doskada raqamlangan savollar ko'rinishida yozing."},
{h:"Savoldan boshlab o'ylash",sum:"«5 qutida 24 tadan qalam, 8 bolaga teng bo'lindi»: avval jami qalam (120), keyin har biriga (15).",a:"m02",
 start:function(){w3Expr(['Har biriga = jami : 8','jami = ?']);w3Msg('Savoldan orqaga: nima yetishmayapti?')},fin:function(){w3Expr(['jami = 24 · 5 = {120}','har biriga = 120 : 8 = {15}']);w3Msg('Savol → yetishmagan ma’lumot → uni topish')},
 html:"<p>«5 ta qutida 24 tadan qalam bor. Ularni 8 bolaga teng bo'lishdi. Har biriga nechta tegdi?» Javobni topish uchun <b>avval</b> nimani bilishimiz kerak?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['Jami qalamlar soni','Bitta qutida nechta','Bolalar soni'],'Jami qalamlar soni',function(){w3Expr(['jami = 24 · 5 = {120}','har biriga = 120 : 8 = {15}']);w3Msg('To‘g‘ri! Jami 120 ta, har biriga 15 ta');done()},{'Bitta qutida nechta':'Bu shartda berilgan (24 ta)','Bolalar soni':'Bu ham berilgan (8 ta). Berilmagani — jami qalamlar'})},
 after:"<p><b>Tahlil usuli</b>: savoldan boshlab «buni bilish uchun menga nima kerak?» deb so'raymiz. Kerakli ma'lumot berilmagan bo'lsa — u yangi oraliq savol bo'ladi. Shunday qilib «savollar daraxti» hosil bo'ladi.</p>",
 q:{t:"5 ta qutida 24 tadan qalam bor. Ularni 8 bolaga teng bo'lishdi. Har biriga nechta tegdi?",opts:["15","37","3","120"],ok:0,why:"120 : 8 = 15.",hint:"Jami: 24 · 5.",full:"Jami 24 · 5 = 120, har biriga 120 : 8 = 15. «3» — 24 : 8 (faqat bitta quti); «120» — oraliq natija."},
 tn:"Doskada savollar daraxtini chizing: tepada asosiy savol, pastda unga kerakli ma'lumotlar."},
{h:"Ortiqcha ma'lumot tuzog'i",sum:"«Ali 7 yoshda, 3 ta 1500 so'mlik daftar oldi» — yosh kerak emas: 1500 · 3 = 4500.",a:"m03",
 start:function(){w3Expr(['7 yosh,  3 ta,  1500 so‘m']);w3Msg('Qaysi son masalaga kerak emas?')},fin:function(){w3Expr(['[7 yosh] — ortiqcha','1500 · 3 = {4500} so‘m']);w3Msg('Har bir sonni ishlatish shart emas!')},
 html:"<p>«Ali 7 yoshda. U do'kondan 3 ta daftar oldi, har biri 1500 so'm. Ali qancha to'ladi?» Qaysi ma'lumot <b>ortiqcha</b>?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['7 yosh','3 ta','1500 so‘m'],'7 yosh',function(){w3Expr(['[7 yosh] — ortiqcha','1500 · 3 = {4500} so‘m']);w3Msg('To‘g‘ri! Yosh narxga ta’sir qilmaydi');done()},{'3 ta':'Daftarlar soni kerak — usiz narxni topib bo‘lmaydi','1500 so‘m':'Bitta daftar narxi kerak'})},
 after:"<p>Olimpiada va test masalalarida ataylab <b>ortiqcha son</b> qo'yiladi. «Hamma sonni ishlatish kerak» degan fikr — tuzoq! Har bir son uchun so'rang: «Bu savolga javob berishga yordam beradimi?»</p>",
 q:{t:"Ali 7 yoshda. U 3 ta daftar oldi, har biri 1500 so'm. Ali qancha to'ladi?",opts:["4500 so'm","10 500 so'm","1503 so'm","3000 so'm"],ok:0,why:"1500 · 3 = 4500.",hint:"Yosh kerakmi?",full:"Narx · soni = 1500 · 3 = 4500. «10 500» — 7 · 1500 (yoshni ishlatish xatosi)."},
 tn:"Bolalarga bitta masalaga o'zlari ortiqcha ma'lumot qo'shishni topshiring — keyin qo'shnisi uni topsin."},
{h:"Oxiridan boshlab yechish",sum:"Bekatda 12 tushdi, 8 chiqdi, keyin 15 tushdi, 26 qoldi: 26 + 15 − 8 + 12 = 45.",a:"m04",
 start:w4St(P4),fin:w4Fin(P4),
 html:"<p>«Avtobusda yo'lovchilar bor edi. 1-bekatda 12 kishi tushdi va 8 kishi chiqdi. 2-bekatda 15 kishi tushdi. Avtobusda 26 kishi qoldi. Avval nechta yo'lovchi bo'lgan?»</p>",btns:[phaser(P4)],
 after:"<p>Boshlang'ich son noma'lum, oxirgisi ma'lum bo'lsa — <b>oxiridan</b> yuramiz va har amalni <b>teskarisiga</b> almashtiramiz: «tushdi» (−) → +, «chiqdi» (+) → −. Javob <b>45</b>.</p>",
 q:{t:"Ali pulining yarmini kitobga, keyin 3000 so'mni daftarga sarfladi. Unda 5000 so'm qoldi. Avval qancha puli bor edi?",opts:["16 000 so'm","13 000 so'm","8000 so'm","21 000 so'm"],ok:0,why:"5000 + 3000 = 8000 — yarmi; 8000 · 2 = 16 000.",hint:"Oxiridan: avval daftar pulini qaytaring.",full:"Daftardan oldin: 5000 + 3000 = 8000. Bu pulning yarmi, demak hammasi 16 000. «13 000» — 5000 · 2 + 3000 (tartib buzilgan); «8000» — oraliq natija."},
 tn:"«Vaqt mashinasi» o'yini: bolalar voqealarni teskari tartibda aytadi va har birini «bekor qiladi»."},
{h:"Bir noma'lumga keltirish",sum:"3 qalam + 2 ruchka = 8400, ruchka qalamdan 1200 qimmat: 5 qalam = 8400 − 2400 = 6000 → qalam 1200, ruchka 2400.",a:"m05",
 start:w4St(P5),fin:w4Fin(P5),
 html:"<p>«3 ta qalam va 2 ta ruchka 8400 so'm turadi. Ruchka qalamdan 1200 so'm qimmat. Ruchka necha so'm?» Chizma model bilan:</p>",btns:[phaser(P5)],
 after:"<p>Usul: qimmatini «arzon + farq» deb yozamiz. Shunda hamma narsa bitta noma'lum (qalam) orqali ifodalanadi: 5 ta qalam + 2400 = 8400. Tekshiruv: 3 · 1200 + 2 · 2400 = 8400 ✓.</p>",
 q:{t:"3 ta qalam va 2 ta ruchka 8400 so'm. Ruchka qalamdan 1200 so'm qimmat. Ruchka necha so'm?",opts:["2400 so'm","1200 so'm","1680 so'm","3600 so'm"],ok:0,why:"Qalam 1200, ruchka 2400.",hint:"Ruchkani «qalam + 1200» deb chizing.",full:"5 · qalam + 2400 = 8400 → qalam = 1200 → ruchka = 2400. «1680» — 8400 : 5 (farqni hisobga olmaslik); «1200» — qalam narxi."},
 tn:"Singapur maktablarida bu turdagi masalalar faqat chizma model bilan yechiladi. Bolalar avval chizsin!"},
{h:"Ikki xil yechim",sum:"2 qatorda va 3 qatorda 15 tadan stul: 15 · 2 + 15 · 3 = 75 yoki 15 · (2 + 3) = 75.",a:"m06",
 start:function(){S.w4={};w3Expr(['2 qator × 15,  3 qator × 15']);w3Msg('Ikki yo‘l bilan yeching')},fin:function(){w3Expr(['15 · 2 + 15 · 3 = 30 + 45 = {75}','15 · (2 + 3) = 15 · 5 = {75}']);w3Msg('Ikkinchi yo‘l qisqaroq!')},
 html:"<p>«Zalning chap qismida 2 qator, o'ng qismida 3 qator stul bor. Har qatorda 15 tadan. Jami nechta stul?» Ikkala usulni ham bosing:</p>",
 btns:[["1-usul",function(c,done){S.w4.a=1;w3Expr(['chap: 15 · 2 = 30','o‘ng: 15 · 3 = 45','jami: 30 + 45 = {75}']);w3Msg('Har qismni alohida sanadik');if(S.w4.b)done()}],["2-usul",function(c,done){S.w4.b=1;w3Expr(['qatorlar: 2 + 3 = 5','jami: 15 · 5 = {75}']);w3Msg('Avval qatorlarni birlashtirdik — 2 amal');if(S.w4.a)done()},'u']],g2:1,
 after:"<p>Ikkala yo'l bir xil javob beradi — bu taqsimot qonuni: <b>15 · 2 + 15 · 3 = 15 · (2 + 3)</b>. Masalani ikki yo'l bilan yechish — eng ishonchli tekshiruv!</p>",
 q:{t:"Bir qatorda 12 ta daraxt, 8 qator bor. 15 tasi qurib qoldi, o'rniga 9 ta yangi ekildi. Endi nechta daraxt bor?",opts:["90","72","102","81"],ok:0,why:"96 − 15 + 9 = 90.",hint:"Avval jami: 12 · 8.",full:"12 · 8 = 96, 96 − 15 = 81, 81 + 9 = 90. «81» — yangi ekilganlar unutilgan; «102» — qurigan daraxtlar qo'shilgan."},
 tn:"Sinfdagi partalar qatoridan foydalaning: ikki ustunni alohida va birga sanatib ko'ring."},
{h:"Qoldiq tuzog'i",sum:"250 o'quvchi, avtobusga 45 kishi: 250 : 45 = 5 (qoldiq 25) — demak 6 ta avtobus kerak.",a:"m07",
 start:function(){w3Expr(['250 : 45 = 5 (qoldiq 25)']);w3Msg('Javob 5 mi?')},fin:function(){w3Expr(['5 avtobus: 225 kishi','25 kishi qoldi → yana 1 avtobus','jami: {6} ta']);w3Msg('Qoldiq ham odam — uni tashlab ketib bo‘lmaydi!')},
 html:"<p>«250 o'quvchini sayohatga olib borish kerak. Bitta avtobusga 45 kishi sig'adi. Kamida nechta avtobus kerak?»</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['5','6','25'],'6',function(){w3Expr(['5 avtobus: 225 kishi','25 kishi qoldi → yana 1 avtobus','jami: {6} ta']);w3Msg('To‘g‘ri: 6 ta avtobus');done()},{'5':'5 ta avtobusga 225 kishi sig‘adi. Qolgan 25 o‘quvchi-chi?','25':'25 — qoldiq (o‘quvchilar), avtobuslar soni emas'})},
 after:"<p>Qoldiqli bo'lishda javob <b>masala ma'nosiga</b> qarab tanlanadi: «nechta avtobus kerak» — yuqoriga (6); «nechta to'liq quti chiqadi» — pastga (5). Doim so'rang: qoldiq bilan nima bo'ladi?</p>",
 q:{t:"Uyda 48 ta tuxum bor. Har kuni 5 tadan ishlatiladi. Necha kunga to'liq yetadi?",opts:["9","10","43","53"],ok:0,why:"48 : 5 = 9 (qoldiq 3) — 10-kunga yetmaydi.",hint:"«To'liq» kunlar soni.",full:"9 kunda 45 ta ishlatiladi, 3 ta qoladi — 10-kunga yetmaydi. Javob 9. Bu yerda yuqoriga yaxlitlash noto'g'ri!"},
 tn:"Ikki o'xshash masalani yonma-yon qo'ying: avtobus (yuqoriga) va tuxum (pastga). Farqni bolalar o'zi tushuntirsin."},
{h:"Chamalab tekshirish",sum:"Kino 2 soat 15 daqiqa, 18:40 da boshlandi → 20:55 da tugaydi. Javobni chamalash xatoni ushlaydi.",a:"m08",
 start:function(){w3Expr(['18:40 + 2 soat 15 daq = ?']);w3Msg('Taxminan: 19 + 2 = 21 dan biroz oldin')},fin:function(){w3Expr(['18:40 + 2 soat = 20:40','20:40 + 15 daq = {20:55}']);w3Msg('Chamamizga mos ✓')},
 html:"<p>«Kino 2 soat 15 daqiqa davom etadi. U 18:40 da boshlandi. Qachon tugaydi?» Avval chamalang, keyin aniq javobni tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['20:55','20:15','21:55','20:45'],'20:55',function(){w3Expr(['18:40 + 2 soat = 20:40','20:40 + 15 daq = {20:55}']);w3Msg('To‘g‘ri!');done()},{'20:15':'2 soat qo‘shildi, lekin daqiqalar 40 + 15, 15 emas','21:55':'Bu 3 soat 15 daqiqa qo‘shilgani','20:45':'40 + 15 = 55, 45 emas'})},
 after:"<p>Chamalash — javobning «oqilona» ekanini tekshirish: kino 2 soatdan sal ko'proq, demak tugashi 20:40 dan sal keyin. 21:55 yoki 20:15 bu chamaga mos kelmaydi.</p>",
 q:{t:"Dazmol 180 000 so'm. Choynak undan 3 marta arzon, piyola choynakdan 4 marta arzon. 6 ta piyola necha so'm?",opts:["90 000 so'm","60 000 so'm","15 000 so'm","135 000 so'm"],ok:0,why:"Choynak 60 000, piyola 15 000, 6 ta — 90 000.",hint:"Zanjir: dazmol → choynak → piyola.",full:"180 000 : 3 = 60 000 (choynak), 60 000 : 4 = 15 000 (piyola), 15 000 · 6 = 90 000. «15 000» — bitta piyola; «60 000» — choynak."},
 tn:"Har masaladan oldin bolalar javobni «taxminan» yozib qo'ysin, oxirida aniq javob bilan solishtirsin."},
{h:"Bilasizmi? Masala yechishning 4 qadami",sum:"Vengriyalik matematik Dyord Poya 1945-yilda «Masalani qanday yechish kerak» kitobida 4 qadamni taklif qilgan.",a:"m09",
 start:function(){w3Expr(['1) tushun  2) reja','3) bajar  4) tekshir']);w3Msg('Poyaning 4 qadami')},fin:function(){w3Expr(['1) tushun  2) reja','3) bajar  4) tekshir']);w3Msg('Poyaning 4 qadami')},
 html:"<p>📜 Vengriyalik matematik <b>Dyord Poya</b> 1945-yilda «Masalani qanday yechish kerak» (How to Solve It) kitobini yozgan. Bu kitob ko'plab tillarga tarjima qilingan va millionlab nusxada tarqalgan.</p><p>⭐ Poyaning 4 qadami: <b>1) masalani tushun; 2) reja tuz; 3) rejani bajar; 4) orqaga qarab tekshir</b>. Bu usul bugun butun dunyo maktablarida qo'llanadi.</p>",
 tn:"4 qadamni plakat qilib osing va har masalada bolalar qaysi qadamda turganini aytsin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['tushun → reja','bajar → tekshir']);w3Msg('Ko‘p amalli masala')},fin:function(){w3Expr(['tushun → reja','bajar → tekshir']);w3Msg('Ko‘p amalli masala')},
 html:"<div class='memo'><ul><li>Masalani savollar zanjiriga bo'ling: har savol — bitta amal.</li><li>Savoldan boshlang: «buni topish uchun nima kerak?»</li><li>Ortiqcha ma'lumotni toping — hamma son kerak emas.</li><li>Boshlang'ich son noma'lum bo'lsa — oxiridan, teskari amallar bilan.</li><li>Qoldiq bilan nima qilish masala ma'nosiga bog'liq (avtobus — yuqoriga, to'liq quti — pastga).</li><li>Javobni chamalab va ikkinchi yo'l bilan tekshiring.</li></ul></div>",
 tn:"4E mavzularining barchasida shu kartochkadan foydalaning."}
];
var PROBS=[
{t:"Fermerda 6000 kg urug' bor edi. 3 ta dalaga 1200 kg dan, 2 ta dalaga 950 kg dan sepdi. Qancha urug' qoldi?",o:["500 kg","3850 kg","5500 kg","1100 kg"],k:0,s:"6000 − (3600 + 1900) = 500."},
{t:"250 o'quvchini sayohatga olib borish kerak. Bitta avtobusga 45 kishi sig'adi. Kamida nechta avtobus kerak?",o:["6","5","7","25"],k:0,s:"250 : 45 = 5 (qoldiq 25) → 6."},
{t:"Avtobusda yo'lovchilar bor edi. 1-bekatda 12 kishi tushdi va 8 kishi chiqdi, 2-bekatda 15 kishi tushdi. 26 kishi qoldi. Avval nechta edi?",o:["45","15","61","37"],k:0,s:"26 + 15 − 8 + 12 = 45."},
{t:"3 ta qalam va 2 ta ruchka 8400 so'm. Ruchka qalamdan 1200 so'm qimmat. Ruchka necha so'm?",o:["2400 so'm","1200 so'm","1680 so'm","3600 so'm"],k:0,s:"5 qalam = 6000, qalam 1200, ruchka 2400."},
{t:"Zalning chap qismida 2 qator, o'ng qismida 3 qator stul bor, har qatorda 15 tadan. Jami nechta stul?",o:["75","30","45","225"],k:0,s:"15 · (2 + 3) = 75."},
{t:"Kutubxonada 3 javonda 85 tadan kitob bor edi. 76 tasi o'quvchilarga berildi, 120 ta yangi kitob keldi. Endi nechta?",o:["299","59","451","179"],k:0,s:"255 − 76 + 120 = 299."},
{t:"Bog'dan 18 kg dan 4 savat olma va 15 kg dan 3 savat nok terildi. Hammasini 9 kg li qutilarga solishdi. Nechta quti kerak bo'ldi?",o:["13","117","12","14"],k:0,s:"72 + 45 = 117, 117 : 9 = 13."},
{t:"Novvoyxona 4 kunda 1060 ta non yopdi. Dastlabki 3 kunda har kuni 240 tadan yopgan. 4-kuni nechta yopgan?",o:["340","820","265","100"],k:0,s:"1060 − 720 = 340."},
{t:"Ali 7 yoshda. U 3 ta daftar oldi, har biri 1500 so'm. Ali qancha to'ladi?",o:["4500 so'm","10 500 so'm","1503 so'm","3000 so'm"],k:0,s:"1500 · 3 = 4500 (yosh ortiqcha)."},
{t:"Kino 2 soat 15 daqiqa davom etadi. U 18:40 da boshlandi. Qachon tugaydi?",o:["20:55","20:15","21:55","20:45"],k:0,s:"18:40 + 2:15 = 20:55."},
{t:"Sut 9800 so'm, non 3500 so'm. 3 ta sut va 2 ta non olib, 50 000 so'm berildi. Qaytim?",o:["13 600 so'm","36 400 so'm","23 600 so'm","3600 so'm"],k:0,s:"29 400 + 7000 = 36 400; 50 000 − 36 400 = 13 600."},
{t:"Velosipedchi 3 soat 14 km/soat tezlikda, keyin 2 soat 12 km/soat tezlikda yurdi. Jami qancha yo'l bosdi?",o:["66 km","130 km","52 km","78 km"],k:0,s:"42 + 24 = 66."},
{t:"Uyda 48 ta tuxum bor. Har kuni 5 tadan ishlatiladi. Necha kunga to'liq yetadi?",o:["9","10","43","53"],k:0,s:"48 : 5 = 9 (qoldiq 3)."},
{t:"Teatrda kattalar chiptasi 25 000, bolalar chiptasi 15 000 so'm. 2 ta katta va 3 ta bola uchun qancha to'lanadi?",o:["95 000 so'm","80 000 so'm","200 000 so'm","65 000 so'm"],k:0,s:"50 000 + 45 000 = 95 000."},
{t:"Omborda 1200 kg kartoshka bor edi. 450 kg sotildi, qolgani 25 kg li qoplarga solindi. Nechta qop chiqdi?",o:["30","48","18","66"],k:0,s:"750 : 25 = 30."},
{t:"Ali pulining yarmini kitobga, keyin 3000 so'mni daftarga sarfladi. 5000 so'm qoldi. Avval qancha puli bor edi?",o:["16 000 so'm","13 000 so'm","8000 so'm","21 000 so'm"],k:0,s:"(5000 + 3000) · 2 = 16 000."},
{t:"Bir qatorda 12 ta daraxt, 8 qator bor. 15 tasi qurib qoldi, o'rniga 9 ta ekildi. Endi nechta daraxt bor?",o:["90","72","102","81"],k:0,s:"96 − 15 + 9 = 90."},
{t:"5 ta qutida 24 tadan qalam bor. Ularni 8 bolaga teng bo'lishdi. Har biriga nechta tegdi?",o:["15","37","3","120"],k:0,s:"120 : 8 = 15."},
{t:"Dazmol 180 000 so'm. Choynak undan 3 marta arzon, piyola choynakdan 4 marta arzon. 6 ta piyola necha so'm?",o:["90 000 so'm","60 000 so'm","15 000 so'm","135 000 so'm"],k:0,s:"60 000 : 4 = 15 000; 15 000 · 6 = 90 000."},
{t:"Ikki shahar oralig'i 420 km. Avtobus 3 soat 70 km/soat tezlikda yurdi. Qolgan yo'lni 2 soatda bosdi. Keyingi tezligi qancha?",o:["105 km/soat","70 km/soat","210 km/soat","84 km/soat"],k:0,s:"420 − 210 = 210; 210 : 2 = 105."}
];
function PRACT_STAGE(){w3Expr(['tushun → reja','bajar → tekshir']);w3Msg('Rejani savollar zanjiri qilib yozing')}
var PREP_DATA={teach:["3–4 amalli masalalarni savollar zanjiri bilan yechish.","Tahlil (savoldan) va sintez (berilganlardan) usullari.","Ortiqcha ma'lumot; oxiridan yechish; bir noma'lumga keltirish.","Qoldiqni masala ma'nosiga qarab talqin qilish; chamalab tekshirish."],
 mist:["Hamma sonni ishlatishga urinadi (ortiqcha ma'lumot).","Oraliq natijani javob deb beradi.","Oxiridan yechishda amallarni teskarisiga almashtirmaydi.","Qoldiqli bo'lishda noto'g'ri yaxlitlaydi."],
 need:["Poyaning 4 qadami plakati.","Rangli lentalar (chizma model)."],
 board:["<span class='w2'>6000 − (1200 · 3 + 950 · 2) = 500</span>.","<span class='w2'>26 + 15 − 8 + 12 = 45</span>.","<span class='w2'>5 qalam = 8400 − 2400</span>.","<span class='w2'>250 : 45 = 5 (q. 25) → 6 avtobus</span>.","<span class='w2'>15 · (2 + 3) = 75</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
