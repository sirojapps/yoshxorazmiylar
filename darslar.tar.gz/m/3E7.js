var CODE='3E7',TITLE='3-sinf · Ish unumi va mahsulot masalalari';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w7u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Ish unumi — 1 soatdagi ish",sum:"Usta soatiga 9 ta stul yasaydi; 72 ta stul uchun 72 : 9 = 8 soat.",a:"m01",
 frames:[{t:'Usta soatiga 9 ta stul yasaydi. 72 ta stulni necha soatda yasaydi?',bars:[{lab:'72 stul',y:76,segs:[{w:9,txt:'9',c:'a'},{w:63,txt:'?',c:'q'}]}],br:[{b:0,lab:'72 ta',up:true}],note:'Bitta bo‘lak — 1 soatlik ish'},
  {t:'Usta soatiga 9 ta stul yasaydi. 72 ta stulni necha soatda yasaydi?',bars:[{lab:'72 stul',y:76,segs:w7u(8,'9','g',9)}],br:[{b:0,lab:'72 ta',up:true},{b:0,lab:'8 soat',up:false,col:C.ok}],calc:['Vaqt = ish : unum','72 : 9 = <b>8</b> soat']}],
 html:"<p><b>Ish unumi</b> — 1 soatda (1 daqiqada, 1 kunda) bajariladigan ish. Tezlik kabi! Kuzating.</p>",
 after:"<p>Yana o'sha uchlik: <b>ish = unum · vaqt</b>, <b>unum = ish : vaqt</b>, <b>vaqt = ish : unum</b>. Narx–miqdor–qiymat, tezlik–vaqt–masofa bilan bir xil tuzilish.</p>",
 q:{t:"Tikuvchi soatiga 6 ta ko'ylak tikadi. 7 soatda nechta ko'ylak tikadi?",opts:["42","13","1","48"],ok:0,why:"6 · 7 = 42.",hint:"Ish = unum · vaqt.",full:"Ish = 6 · 7 = 42 ta. «13» — qo'shilgan, «48» — 6 · 8 (jadval xatosi)."},
 tn:"Bank misoli (3103-id). Doskada uch kattalik jadvali: «Unum | Vaqt | Ish»."}),
bmStep({h:"Avval unumni topamiz",sum:"Printer 3 minutda 54 bet → 1 minutda 18 bet → 90 bet uchun 90 : 18 = 5 minut.",a:"m02",
 frames:[{t:'Printer 3 minutda 54 bet chop etadi. 90 betni necha minutda chop etadi?',bars:[{lab:'3 min',y:66,segs:w7u(3,'?','a',18)},{lab:'90 bet',y:112,segs:[{w:90,txt:'?',c:'q'}]}],br:[{b:0,lab:'54 bet',up:true}],calc:['1) Unum: 54 : 3 = 18 bet/min']},
  {t:'Printer 3 minutda 54 bet chop etadi. 90 betni necha minutda chop etadi?',bars:[{lab:'3 min',y:66,segs:w7u(3,'18','a',18)},{lab:'90 bet',y:112,segs:w7u(5,'18','g',18)}],br:[{b:0,lab:'54 bet',up:true},{b:1,lab:'5 minut',up:false,col:C.ok}],calc:['1) 54 : 3 = 18','2) 90 : 18 = <b>5</b> minut']}],
 html:"<p>Unum berilmagan — avval uni topamiz. Kuzating.</p>",
 after:"<p>Ikki marta bo'lish: 1) <b>unum</b> = ish : vaqt; 2) <b>vaqt</b> = yangi ish : unum. Tekshiruv: 18 · 5 = 90 ✓.</p>",
 q:{t:"Nasos 4 minutda 120 l suv chiqaradi. 210 l suvni necha minutda chiqaradi?",opts:["7","30","90","6"],ok:0,why:"120 : 4 = 30; 210 : 30 = 7.",hint:"1 minutda necha litr?",full:"Unum: 120 : 4 = 30 l/min. Vaqt: 210 : 30 = 7 min. «30» — unumning o'zi, «90» — 210 − 120."},
 tn:"Bank misoli (1363-id)."}),
bmStep({h:"Birgalikda ishlash",sum:"Usta 12, shogird 8 ta/soat → birga 20 ta/soat; 200 : 20 = 10 soat.",a:"m03",
 frames:[{t:'Usta soatiga 12 ta, shogirdi 8 ta detal tayyorlaydi. Birga 200 tani necha soatda?',bars:[{lab:'1 soat',y:76,segs:[{w:12,txt:'12',c:'a'},{w:8,txt:'8',c:'b'}]}],br:[{b:0,lab:'20 ta',up:true}],note:'Birga ishlasa — unumlar qo‘shiladi',max:200},
  {t:'Usta soatiga 12 ta, shogirdi 8 ta detal tayyorlaydi. Birga 200 tani necha soatda?',bars:[{lab:'200 ta',y:76,segs:w7u(10,'20','g',20)}],br:[{b:0,lab:'200 ta',up:true},{b:0,lab:'10 soat',up:false,col:C.ok}],calc:['1) Birgalikdagi unum: 12 + 8 = 20 ta/soat','2) 200 : 20 = <b>10</b> soat']}],
 html:"<p>Ikki kishi <b>birga</b> ishlasa, 1 soatda qancha ish qilinadi? Kuzating.</p>",
 after:"<p>Birgalikdagi unum = unumlar <b>yig'indisi</b> (xuddi bir-biriga qarab harakatdagi tezliklar kabi). Keyin vaqt = ish : umumiy unum.</p>",
 q:{t:"Bir traktor soatiga 3 ga, ikkinchisi 5 ga yer haydaydi. Birga 40 ga ni necha soatda haydaydi?",opts:["5","8","13","20"],ok:0,why:"40 : (3 + 5) = 5.",hint:"Birga 1 soatda necha ga?",full:"Birga 3 + 5 = 8 ga/soat. 40 : 8 = 5 soat. «8» — umumiy unum, «20» — 40 : (5 − 3)."},
 tn:"Bank misoli (2254-id). Ikki o'quvchiga birga daftar varaqlarini taxlatib ko'ring."}),
bmStep({h:"Tuzoq: ikki printer",sum:"20 + 30 = 50 bet/min birga; 500 : 50 = 10 daqiqa (25 — faqat 1-printer, ≈17 — faqat 2-printer).",a:"m04",
 frames:[{t:'1-printer daqiqasiga 20 bet, 2-printer 30 bet chop etadi. Birga 500 betni necha daqiqada?',bars:[{lab:'500 bet',y:76,segs:[{w:500,txt:'?',c:'q'}]}],note:'Javobni tanlang:'}],
 html:"<p>Ko'p bolalar shu yerda adashadi. Qaysi javob to'g'ri?</p>",
 btns:bmPick(["25 daqiqa","10 daqiqa","50 daqiqa"],1,{t:'Birga: 20 + 30 = 50 bet/min',bars:[{lab:'500 bet',y:76,segs:w7u(10,'50','g',50)}],br:[{b:0,lab:'10 daqiqa',up:false,col:C.ok}],calc:['1) 20 + 30 = 50 bet/min','2) 500 : 50 = <b>10</b> daqiqa']},["25 = 500 : 20 — bu faqat 1-printer yolg‘iz ishlasa. Birga — tezroq!","","50 — bu birgalikdagi unum (bet/min), vaqt emas."]),
 after:"<p>Mantiqiy tekshiruv: birga ishlash har bir printerning yolg'iz vaqtidan (25 va ≈17 daqiqa) <b>kamroq</b> bo'lishi shart. 10 &lt; 17 ✓.</p>",
 q:{t:"Ona soatiga 6 ta, qizi 4 ta somsa tugadi. Birga 50 ta somsani necha soatda tugishadi?",opts:["5","10","25","13"],ok:0,why:"50 : (6 + 4) = 5.",hint:"Birgalikdagi unumni toping.",full:"Birga 10 ta/soat. 50 : 10 = 5 soat. «10» — umumiy unum, «13» — 50 : 4 taxminan (faqat qizi)."},
 tn:"Bank misoli (3104-id), 3-daraja. «Birga ishlash — har kimning yolg'iz vaqtidan kam» qoidasini bolalar o'zi aytsin."}),
bmStep({h:"Ikki usta, olti kun",sum:"1-usta 64, 2-usta 64 − 15 = 49 g'isht/kun; birga 113; 6 kunda 113 · 6 = 678.",a:"m05",
 frames:[{t:'1-usta kuniga 64 ta g‘isht teradi, 2-usta undan 15 ta kam. Ikkalasi birga 6 kunda nechta?',bars:[{lab:'1-usta',y:66,segs:[{w:64,txt:'64',c:'a'}]},{lab:'2-usta',y:112,segs:[{w:49,txt:'?',c:'q'},{w:15,txt:'15',c:'x'}]}],calc:['2-usta: 64 − 15 = 49']},
  {t:'1-usta kuniga 64 ta g‘isht teradi, 2-usta undan 15 ta kam. Ikkalasi birga 6 kunda nechta?',bars:[{lab:'1 kun',y:68,segs:[{w:64,txt:'64',c:'a'},{w:49,txt:'49',c:'b'}]},{lab:'6 kun',y:112,segs:w7u(6,'113','g',113)}],br:[{b:0,lab:'113',up:true},{b:1,lab:'678 ta',up:false,col:C.ok}],calc:['1) 64 − 15 = 49','2) 64 + 49 = 113 (bir kunda birga)','3) 113 · 6 = <b>678</b> ta']}],
 html:"<p>Uch qadamli masala: 2-usta unumi → birgalikdagi unum → 6 kunlik ish. Kuzating.</p>",
 after:"<p>Boshqa yo'l: 64 · 6 + 49 · 6 = 384 + 294 = 678 ✓. «294» — faqat 2-usta, «358» — 64 + 294: bitta qadam tushib qolgan.</p>",
 q:{t:"Bir ishchi kuniga 35 ta detal, ikkinchisi undan 8 ta ko'p tayyorlaydi. Ikkalasi 5 kunda nechta?",opts:["390","215","78","175"],ok:0,why:"35 + 43 = 78; 78 · 5 = 390.",hint:"Ikkinchisi kuniga nechta?",full:"Ikkinchisi 35 + 8 = 43. Birga kuniga 78. 5 kunda 78 · 5 = 390. «78» — faqat bir kun, «215» — 43 · 5 (faqat ikkinchisi)."},
 tn:"Bank misoli (1364-id)."}),
bmStep({h:"Uch kattalik: soat, kun, odam",sum:"Sevinch 4, Dilshoda 6 ta/soat → 10; kuniga 8 soat → 80; 4 kunda 320.",a:"m06",
 frames:[{t:'Sevinch soatiga 4 ta, Dilshoda 6 ta quticha yasaydi. Kuniga 8 soatdan, 4 kun ishlashdi.',bars:[{lab:'1 soat',y:62,segs:[{w:4,txt:'4',c:'a'},{w:6,txt:'6',c:'b'}]},{lab:'1 kun',y:110,segs:w7u(8,'10','y',10)}],br:[{b:0,lab:'10',up:true},{b:1,lab:'80 ta (8 soat)',up:false}],calc:['Birga 1 soatda: 4 + 6 = 10','1 kunda: 10 · 8 = 80'],max:80},
  {t:'Sevinch soatiga 4 ta, Dilshoda 6 ta quticha yasaydi. Kuniga 8 soatdan, 4 kun ishlashdi.',bars:[{lab:'4 kun',y:84,segs:w7u(4,'80','g',80)}],br:[{b:0,lab:'320 ta',up:false,col:C.ok}],calc:['1) 4 + 6 = 10;  2) 10 · 8 = 80','3) 80 · 4 = <b>320</b> ta']}],
 html:"<p>Soatlar, kunlar va ikki ishchi — hammasi bitta masalada. Qadamma-qadam boramiz.</p>",
 after:"<p>Tartib: <b>soatlik</b> unum → <b>kunlik</b> unum → hamma kunlar. «192» (6 · 8 · 4) — faqat Dilshoda, «80» — faqat bir kun.</p>",
 q:{t:"Fabrika bitta ko'ylakka 3 m mato sarflaydi va kuniga 8 ta ko'ylak tikadi. 5 kunda necha metr mato ketadi?",opts:["120","40","24","16"],ok:0,why:"3 · 8 · 5 = 120.",hint:"Avval 1 kunda necha metr?",full:"1 kunda 3 · 8 = 24 m. 5 kunda 24 · 5 = 120 m. «24» — faqat 1 kun, «40» — 8 · 5 (faqat ko'ylaklar soni)."},
 tn:"Bank misoli (180-id), 3-daraja. Doskada zinapoya: «soat → kun → 4 kun»."}),
bmStep({h:"Tuzoq: kranlar",sum:"3 kran 3 mashinani 3 daqiqada: har kran o'z mashinasini 3 daqiqada; 6 kran 6 mashinani ham 3 daqiqada.",a:"m07",
 frames:[{t:'3 ta kran 3 ta mashinani 3 daqiqada yuklaydi. 6 ta kran 6 ta mashinani necha daqiqada?',bars:[{lab:'3 kran',y:56,segs:w7u(3,'3 min','a',1)},{lab:'6 kran',y:110,segs:w7u(6,'?','q',1)}],note:'Har bir bo‘lak — bitta kran va uning mashinasi',max:6}],
 html:"<p>Olimpiada savoli. Shoshilmang — tasavvur qiling, kranlar <b>bir vaqtda</b> ishlaydi.</p>",
 btns:bmPick(["6 daqiqa","12 daqiqa","3 daqiqa"],2,{t:'Har bir kran o‘z mashinasini 3 daqiqada yuklaydi',bars:[{lab:'3 kran',y:56,segs:w7u(3,'3 min','a',1)},{lab:'6 kran',y:110,segs:w7u(6,'3 min','g',1)}],calc:['1 kran → 1 mashina → 3 daqiqa','6 kran bir vaqtda → 6 mashina → <b>3</b> daqiqa'],max:6},["Mashinalar 2 marta ko‘p, lekin kranlar ham 2 marta ko‘p — vaqt o‘zgarmaydi.","12 — ikkala sonni ham ko‘paytirdingiz. Kranlar bir vaqtda ishlaydi!",""]),
 after:"<p>Kalit — <b>bitta</b> kranning unumi: 1 mashina 3 daqiqada. Ishchilar ko'paysa, ish ham shuncha ko'paysa — vaqt o'zgarmaydi.</p>",
 q:{t:"5 ta mushuk 5 ta sichqonni 5 daqiqada tutadi. 100 ta mushuk 100 ta sichqonni necha daqiqada tutadi?",opts:["5","100","20","500"],ok:0,why:"Har mushuk 1 sichqonni 5 daqiqada.",hint:"Bitta mushuk bitta sichqonni qancha vaqtda tutadi?",full:"Bitta mushuk 1 sichqonni 5 daqiqada tutadi. 100 mushuk bir vaqtda 100 sichqonni — yana 5 daqiqada. «100» — «sonlar teng bo'lsa, javob ham shu son» degan noto'g'ri taxmin."},
 tn:"Mashhur «mushuk-sichqon» topishmog'i. Bolalar sahnalashtirsin: 3 bola 3 ta kitobni javonga qo'yadi."}),
bmStep({h:"Bilasizmi? Ford konveyeri",sum:"1913 yilda Ford zavodida harakatlanuvchi konveyer avtomobil yig'ish vaqtini taxminan 12 soatdan 1,5 soatga (90 min) qisqartirdi: 720 : 90 = 8 marta.",a:"m08",
 frames:[{t:'1913-yil, Ford zavodi: avtomobil yig‘ish vaqti',bars:[{lab:'oldin',y:56,segs:[{w:720,txt:'≈ 12 soat = 720 min',c:'a'}]},{lab:'keyin',y:110,segs:[{w:90,txt:'90',c:'g'}]}],note:'Unum necha marta oshdi?'}],
 html:"<p>🚗 1913-yilda Genri Ford zavodida <b>harakatlanuvchi konveyer</b> joriy qilindi: avtomobil ishchilar yoniga o'zi keladi, har kim faqat bitta ishni qiladi. Bitta mashinani yig'ish vaqti taxminan 12 soatdan 1,5 soatga tushdi.</p>",
 btns:bmPick(["630 marta","8 marta","80 marta"],1,{t:'720 : 90 = 8',bars:[{lab:'oldin',y:56,segs:w7u(8,'90','a',90)},{lab:'keyin',y:110,segs:[{w:90,txt:'90',c:'g'}]}],calc:['12 soat = 720 min','720 : 90 = <b>8</b> marta tez — unum 8 marta oshdi']},["630 = 720 − 90 — bu «qanchaga», «necha marta» emas.","","80 marta bo‘lsa, 90 · 80 = 7200 min bo‘lardi."]),
 after:"<p>Ish unumini oshirish — butun sanoatning maqsadi. Bugungi zavodlarda robotlar bu vaqtni yana ham qisqartirgan.</p>",
 tn:"Sinfda «konveyer» o'yini: 4 bola qatorda, har biri qog'oz qayiqning bitta bukilishini qiladi — yolg'iz yasash bilan solishtiring."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Ish = unum · vaqt',bars:[{lab:'vaqt = 4',y:76,segs:w7u(4,'unum','a',1)}],br:[{b:0,lab:'ish',up:true}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li><b>Unum</b> — 1 birlik vaqtdagi ish.</li><li><b>Ish = unum · vaqt</b>, <b>unum = ish : vaqt</b>, <b>vaqt = ish : unum</b>.</li><li>Birga ishlasa — <b>unumlar qo'shiladi</b>.</li><li>Birga ishlash vaqti har kimning yolg'iz vaqtidan <b>kam</b>.</li><li>Soat → kun → kunlar: qadamma-qadam ko'paytiring.</li><li>Ishchi va ish teng ko'paysa — <b>vaqt o'zgarmaydi</b>.</li></ul></div>",
 tn:"Uch uchlikni (narx, harakat, ish) yonma-yon yozib, umumiy tuzilishni bolalar o'zi topsin."}
];
var PROBS=[
{t:"Usta soatiga 9 ta stul yasaydi. 72 ta stulni necha soatda yasaydi?",o:["8","63","81","9"],k:0,s:"72 : 9 = 8."},
{t:"Tikuvchi soatiga 6 ta ko'ylak tikadi. 7 soatda nechta?",o:["42","13","48","36"],k:0,s:"6 · 7 = 42."},
{t:"Printer 3 minutda 54 bet chop etadi. 90 betni necha minutda?",o:["5","6","4","2"],k:0,s:"54 : 3 = 18; 90 : 18 = 5."},
{t:"Nasos 4 minutda 120 l chiqaradi. 210 l ni necha minutda?",o:["7","30","90","6"],k:0,s:"120 : 4 = 30; 210 : 30 = 7."},
{t:"Usta soatiga 12, shogird 8 ta detal. Birga 200 tani necha soatda?",o:["10","25","20","8"],k:0,s:"200 : 20 = 10."},
{t:"Traktorlar soatiga 3 va 5 ga haydaydi. Birga 40 ga ni necha soatda?",o:["5","8","20","13"],k:0,s:"40 : 8 = 5."},
{t:"Printerlar daqiqasiga 20 va 30 bet. Birga 500 betni necha daqiqada?",o:["10","25","17","50"],k:0,s:"500 : 50 = 10."},
{t:"Ona soatiga 6, qizi 4 ta somsa tugadi. Birga 50 tani necha soatda?",o:["5","10","25","13"],k:0,s:"50 : 10 = 5."},
{t:"1-usta kuniga 64 g'isht, 2-usta undan 15 ta kam teradi. Birga 6 kunda nechta?",o:["678","294","858","358"],k:0,s:"113 · 6 = 678."},
{t:"Ishchi kuniga 35, ikkinchisi undan 8 ta ko'p detal. Ikkalasi 5 kunda nechta?",o:["390","215","78","175"],k:0,s:"78 · 5 = 390."},
{t:"Sevinch soatiga 4, Dilshoda 6 quticha; kuniga 8 soat, 4 kun. Jami nechta?",o:["320","192","80","240"],k:0,s:"10 · 8 · 4 = 320."},
{t:"Ko'ylakka 3 m mato; kuniga 8 ko'ylak. 5 kunda necha m mato?",o:["120","40","24","16"],k:0,s:"3 · 8 · 5 = 120."},
{t:"3 ta kran 3 ta mashinani 3 daqiqada yuklaydi. 6 kran 6 mashinani necha daqiqada?",o:["3","6","12","9"],k:0,s:"Har kran o'z mashinasini 3 daqiqada."},
{t:"5 mushuk 5 sichqonni 5 daqiqada tutadi. 100 mushuk 100 sichqonni necha daqiqada?",o:["5","100","20","500"],k:0,s:"Vaqt o'zgarmaydi."},
{t:"2 ta bir xil nasos 6 soatda hovuzni to'ldiradi. 1 ta nasos necha soatda to'ldiradi?",o:["12","3","6","8"],k:0,s:"Nasos 2 marta kam → vaqt 2 marta ko'p."},
{t:"Usta 3 soatda 24 ta, shogird 4 soatda 20 ta detal yasaydi. Birga 1 soatda nechta?",o:["13","44","7","11"],k:0,s:"8 + 5 = 13."},
{t:"Birga 2 printer 1 daqiqada 45 bet chop etadi, biri 25 bet. Ikkinchisi 8 daqiqada necha bet?",o:["160","200","360","20"],k:0,s:"45 − 25 = 20; 20 · 8 = 160."},
{t:"Brigada 5 kunda 450 m yo'l yotqizdi. 720 m ni necha kunda yotqizadi?",o:["8","90","270","9"],k:0,s:"450 : 5 = 90; 720 : 90 = 8."},
{t:"Usta soatiga 7 ta detal yasaydi. 8 soatlik ish kunida 3 soat ishladi. Rejadagi kunlik ish bajarilishi uchun yana nechta detal kerak?",o:["35","21","56","5"],k:0,s:"7 · (8 − 3) = 35."},
{t:"Fabrika 1-kuni 120 ta, keyingi har kuni oldingisidan 10 ta ko'p ko'ylak tikdi. 4 kunda jami nechta?",o:["540","480","160","520"],k:0,s:"120 + 130 + 140 + 150 = 540."}
];
function PRACT_STAGE(){bmDraw({t:'Ish = unum · vaqt',bars:[{lab:'vaqt',y:76,segs:w7u(4,'unum','a',1)}],br:[{b:0,lab:'ish',up:true}]})}
var PREP_DATA={teach:["Ish unumi; ish = unum · vaqt va undan unum, vaqt.","Avval unumni topish (birga keltirish).","Birgalikda ishlash: unumlar qo'shiladi.","Ko'p qadamli: soat → kun → kunlar; «kranlar» tuzog'i."],
 mist:["Birga ishlaganda vaqtlarni qo'shadi yoki bitta ishchining vaqtini oladi.","Unumni javob deb beradi.","Kunlik soatlarni hisobga olmaydi.","«3 kran 3 mashina 3 daqiqa» da hamma sonlarni ko'paytiradi."],
 need:["«Unum | Vaqt | Ish» jadvali.","Qog'oz (konveyer o'yini uchun)."],
 board:["<span class='w2'>72 : 9 = 8</span> soat.","<span class='w2'>54 : 3 = 18; 90 : 18 = 5</span>.","<span class='w2'>200 : (12 + 8) = 10</span>.","<span class='w2'>(64 + 49) · 6 = 678</span>.","<span class='w2'>(4 + 6) · 8 · 4 = 320</span>."]};
