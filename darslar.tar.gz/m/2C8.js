var CODE='2C8',TITLE='2-sinf · Teng guruhlarga ajratish va ortib qolgan narsalar';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P4=[function(){cDeal(17,1,0,{});cMsg('17 nafar bola. Har mashinaga 4 kishi')},
 function(){cDeal(17,5,16,{per:4,who:'mashina'});cMsg('4 ta mashina to‘ldi (16 kishi), <b>1 bola</b> qoldi!')},
 function(){cDeal(17,5,17,{per:4,who:'mashina'});cMsg('Qolgan bolani tashlab ketmaymiz — yana 1 mashina: jami <b>5 ta</b>')}];
var P5=[function(){cDeal(23,6,20,{per:4,who:'savat'});cMsg('23 ta olma 4 tadan: 5 ta savat, 3 ta ortdi')},
 function(){cDeal(24,6,24,{per:4,who:'savat'});cMsg('6-savat to‘lishi uchun 4 − 3 = <b>1</b> ta olma qo‘shish kerak')}];
var STEPS=[
{h:"Hammasi teng bo'linmaydi",sum:"14 ta olmani 4 tadan solsak: 3 ta savat to'ladi, 2 ta ortib qoladi.",a:"m01",
 start:function(){cDeal(14,4,0,{per:4,who:'savat'});cMsg('14 ta olma, har savatga 4 tadan')},fin:function(){cDeal(14,4,12,{per:4,who:'savat'});cMsg('3 ta savat, <b>2 ta</b> ortib qoldi')},
 html:"<p>14 ta olmani savatlarga <b>4 tadan</b> solamiz. Tugmani bosing va oxirida nima bo'lishini ko'ring:</p>",
 btns:[["🍎 4 tadan solish",function(c,done,b){b.disabled=true;cDealAnim(14,4,{per:4,who:'savat'},function(){cMsg('3 ta savat to‘ldi, <b>2 ta</b> olma ortib qoldi');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>2 ta olma bilan to'liq savat bo'lmaydi — ular <b>ortib qoladi</b>. Yoziladi: <b>14 = 4 · 3 + 2</b>. Ortib qolgan son — <b>qoldiq</b> (3-sinfda batafsil o'rganasiz).</p>",
 q:{t:"26 ta tuxum 6 talik idishlarga solindi. Nechta idish to'ldi va nechta tuxum ortdi?",opts:["3 ta idish, 8 ta tuxum ortdi","5 ta idish, 1 ta tuxum ortdi","4 ta idish, 2 ta tuxum ortdi","4 ta idish, 4 ta tuxum ortdi"],ok:2,why:"6 · 4 = 24, 26 − 24 = 2.",hint:"6 tadan necha marta olish mumkin? 6, 12, 18, 24 …",full:"6 · 4 = 24, keyingisi 30 — ko'p. Demak 4 ta idish, 26 − 24 = 2 ta ortdi. «3 ta idish, 8 ortdi» — 8 ta bilan yana bitta idish to'ladi, bu xato."},
 tn:"Haqiqiy narsalar bilan: 14 ta qalamni 4 tadan bog'lang — ortgani ko'rinib turadi."},
{h:"Ortib qolgan — guruhdan kam",sum:"4 tadan solsak, ortib qolgan narsa 0, 1, 2 yoki 3 bo'ladi — hech qachon 4 yoki ko'p emas.",a:"m02",
 start:function(){S.t=12;c8Rem()},fin:function(){S.t=15;c8Rem()},
 html:"<p>Olmalar sonini o'zgartiring, savatga 4 tadan solinadi. Ortib qolganiga qarang:</p>",
 btns:[["+ olma",function(c,done){if(S.t<24){S.t++;c8Rem();mvK(done,4)}}],["− olma",function(c,done){if(S.t>4){S.t--;c8Rem();mvK(done,4)}}]],g2:1,
 after:"<p>Ortib qolgan narsa doim <b>guruhdan kam</b>: 4 tadan solsak — 0, 1, 2 yoki 3. Agar 4 ta ortsa — yana bitta savat to'ladi!</p>",
 q:{t:"Narsalarni 5 tadan guruhlaganda qancha ortib qolishi MUMKIN EMAS?",opts:["1","3","4","5"],ok:3,why:"5 ta ortsa, yana bitta guruh to'ladi.",hint:"Ortib qolgan narsa guruhdan kam bo'lishi kerakmi?",full:"5 tadan guruhlaganda 0, 1, 2, 3, 4 ortishi mumkin. 5 ta ortsa — bu yana bitta to'liq guruh. Demak 5 ortishi mumkin emas."},
 tn:"Bu qoida 3-sinfdagi qoldiqli bo'lishning asosi: qoldiq bo'luvchidan kichik."},
{h:"Teng bo'lishish — ortgani bilan",sum:"29 ta qalam 3 bolaga: har biriga 9 tadan, 2 ta ortdi (29 = 9 · 3 + 2).",a:"m03",
 start:function(){cDeal(29,3,0,{who:'bola'});cMsg('29 ta qalam, 3 ta bola')},fin:function(){cDeal(29,3,27,{who:'bola'});cMsg('Har biriga 9 tadan, <b>2 ta</b> ortdi')},
 html:"<p>29 ta qalamni 3 bolaga teng tarqatamiz — har biriga iloji boricha ko'p. Tugmani bosing:</p>",
 btns:[["✏ Tarqatish",function(c,done,b){b.disabled=true;cDealAnim(29,3,{who:'bola',fast:1},function(){cMsg('Har biriga <b>9</b> tadan, <b>2 ta</b> ortdi: 29 = 9 · 3 + 2');b.disabled=false;b.textContent='↻ Yana';done()})}]],
 after:"<p>2 ta qalamni 3 bolaga teng berib bo'lmaydi — ular ortib qoladi. Tekshirish: 9 · 3 + 2 = 27 + 2 = 29 ✓.</p>",
 q:{t:"17 ta konfet 5 bolaga teng bo'lindi (har biriga iloji boricha ko'p). Har biriga nechtadan tegdi va nechta ortdi?",opts:["3 tadan, 2 ta ortdi","4 tadan, 3 ta ortdi","2 tadan, 7 ta ortdi","3 tadan, 3 ta ortdi"],ok:0,why:"5 · 3 = 15, 17 − 15 = 2.",hint:"5 ning qaysi karralisi 17 dan oshmaydi?",full:"5 · 3 = 15, 5 · 4 = 20 — ko'p. Demak 3 tadan, 17 − 15 = 2 ortdi. «2 tadan, 7 ortdi» — 7 ta bilan yana bir marta tarqatsa bo'lardi."},
 tn:"Tekshirish formulasi: «guruhlar · har birida + ortgani = hammasi»."},
{h:"Tuzoq: «kamida nechta kerak?»",sum:"17 bola, mashinaga 4 kishi: 4 ta mashina to'ladi va 1 bola qoladi → kamida 5 ta mashina.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Masala: <i>«17 nafar bola sayohatga boradi. Har mashinaga 4 kishi sig'adi. Kamida nechta mashina kerak?»</i> 4 deb shoshilmang!</p>",
 btns:[phaser(P4)],
 after:"<p>Ortib qolgan bolani tashlab ketib bo'lmaydi — unga ham mashina kerak. Shuning uchun javob <b>bittaga ko'p</b>: 5 ta. «Nechta to'ldi?» va «nechta kerak?» — har xil savollar!</p>",
 q:{t:"Sinfdagi 23 o'quvchi 5 kishilik jamoalarga bo'lindi. Oxirgi, to'liq bo'lmagan jamoada nechta o'quvchi bor?",opts:["5","3","4","2"],ok:1,why:"5 · 4 = 20, 23 − 20 = 3.",hint:"Nechta to'liq jamoa bo'ladi? Qancha o'quvchi ortadi?",full:"5 · 4 = 20 — 4 ta to'liq jamoa. 23 − 20 = 3 o'quvchi oxirgi jamoada. «4» — to'liq jamoalar soni."},
 tn:"Hayotiy savol: «24 kishilik avtobus, 50 o'quvchi — nechta avtobus?» (3). Bolalar o'zi isbotlasin."},
{h:"Tuzoq: «yana nechta qo'shish kerak?»",sum:"23 ta olma 4 tadan: 3 ta ortdi. Yana bitta savat to'lishi uchun 4 − 3 = 1 ta yetishmaydi.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>Masala: <i>«23 ta olma savatlarga 4 tadan joylandi. Yana bitta savat to'lishi uchun kamida nechta olma qo'shish kerak?»</i></p>",
 btns:[phaser(P5)],
 after:"<p>Ortgan olmalar — 3 ta. Savatga 4 ta kerak, demak <b>4 − 3 = 1</b> ta yetishmaydi. Javob — ortgan son emas, <b>yetishmaydigan</b> son!</p>",
 q:{t:"17 ta gulni 3 ta guldonga teng qo'yish uchun eng kami bilan yana nechta gul kerak?",opts:["1","2","3","4"],ok:0,why:"17 dan keyingi 3 ga bo'linadigan son 18: 18 − 17 = 1.",hint:"17 ga eng yaqin, 3 guldonga teng bo'linadigan katta son qaysi?",full:"3 · 5 = 15 (2 ta ortadi), 3 · 6 = 18. 18 − 17 = 1 ta gul yetishmaydi. «2» — ortgan gullar soni, savol esa yetishmaydiganini so'rayapti."},
 tn:"«Ortdi» va «yetishmaydi» — ikkita alohida savol. Doskaga chizmada ko'rsating."},
{h:"Qaysi son? — teskari savol",sum:"4 ga bo'lganda 3 ortsa: 4 · □ + 3. Masalan 23 = 4 · 5 + 3.",a:"m06",
 start:function(){S.t=23;c8Rem()},fin:function(){S.t=23;c8Rem()},
 html:"<p>Teskari savol: <b>«Qaysi sonni 4 ga bo'lganda 3 ortib qoladi?»</b> Sonlarni sinab ko'ring:</p>",
 btns:[["20",function(c,done){S.t=20;c8Rem();mvK(done,3)}],["22",function(c,done){S.t=22;c8Rem();mvK(done,3)}],["23",function(c,done){S.t=23;c8Rem();mvK(done,3)}],["24",function(c,done){S.t=24;c8Rem();mvK(done,3)}]],g2:1,
 after:"<p>23 = 4 · 5 + <b>3</b>. Bunday sonlar ko'p: 3, 7, 11, 15, 19, 23, 27… — har biri 4 ning karralisidan 3 ta ko'p.</p>",
 q:{t:"Qaysi sonni 5 ga bo'lganda 4 ortib qoladi?",opts:["20","24","25","22"],ok:1,why:"24 = 5 · 4 + 4.",hint:"5 ning karralisidan 4 ta ko'p sonni toping.",full:"20 — 0 ortadi, 22 — 2 ortadi, 25 — 0 ortadi. 24 = 5 · 4 + 4 — 4 ortadi."},
 tn:"Bolalar o'zi shunday son o'ylab, sherigiga topishmoq bersin."},
{h:"Bilasizmi? Hafta va kunlar",sum:"30 kun = 4 hafta va 2 kun: 7 · 4 = 28, 30 − 28 = 2.",a:"m07",
 start:function(){clear('#f6ead0');for(var i=0;i<30;i++){var r=Math.floor(i/7),c=i%7;E('rect',{x:62+c*34,y:12+r*30,width:30,height:26,rx:4,fill:r<4?'#fff':'#ffd0d0',stroke:'#c9a764'},S.g);T(S.g,77+c*34,30+r*30,String(i+1),{'font-size':11,'font-weight':700,fill:'#6b3d12'})}cMsg('30 kun = 4 hafta va <b>2 kun</b>')},fin:function(){STEPS[6].start()},
 html:"<p>📅 Kalendar — teng guruhlarning eng mashhur misoli: <b>7 kun</b> — bir hafta. 30 kunlik oyda 4 ta to'liq hafta (28 kun) va yana <b>2 kun</b> bor.</p><p>Shuning uchun har oy boshqa hafta kunidan boshlanadi! Agar oy dushanbadan boshlansa, keyingi oy (30 kunlik bo'lsa) chorshanbadan boshlanadi.</p>",
 tn:"Joriy oy kalendarini ko'rsating: necha to'liq hafta va necha kun ortadi?"},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){cDeal(14,4,12,{per:4,who:'savat'});cMsg('14 = 4 · 3 + 2')},fin:function(){STEPS[7].start()},
 html:"<div class='memo'><ul><li>Hammasi teng bo'linmasa — <b>ortib qoladi</b>: 14 = 4 · 3 + 2.</li><li>Ortgan narsa doim <b>guruhdan kam</b> (4 tadan — 0, 1, 2, 3).</li><li>Tekshirish: guruhlar · har birida + ortgani = hammasi.</li><li>«Nechta <b>to'ldi</b>?» — to'liq guruhlar; «kamida nechta <b>kerak</b>?» — bittaga ko'p (17 bola → 5 mashina).</li><li>«Yana nechta qo'shish kerak?» — guruh − ortgan (4 − 3 = 1).</li><li>4 ga bo'lganda 3 ortadigan sonlar: 3, 7, 11, 15, 19, 23…</li></ul></div>",
 tn:"Keyingi darsni «50 o'quvchi, avtobusga 24 kishi — nechta avtobus?» savoli bilan boshlang."}
];
function c8Rem(){var t=S.t,g=Math.floor(t/4),r=t-4*g;cDeal(t,Math.max(1,g+(r?1:0)),4*g,{per:4,who:'savat'});cMsg(t+' = 4 · '+g+' + <b>'+r+'</b>'+(r?' — '+r+' ta ortdi':' — hech narsa ortmadi'))}
var PROBS=[
{t:"14 ta olma 4 tadan savatlarga solindi. Nechta savat to'ldi va nechta ortdi?",o:["3 savat, 2 ortdi","4 savat, 2 ortdi","3 savat, 4 ortdi","2 savat, 6 ortdi"],k:0,s:"4 · 3 = 12, 14 − 12 = 2."},
{t:"26 ta tuxum 6 talik idishlarga solindi. Nechta idish to'ldi va nechta ortdi?",o:["4 ta idish, 2 ta ortdi","3 ta idish, 8 ta ortdi","5 ta idish, 1 ta ortdi","4 ta idish, 4 ta ortdi"],k:0,s:"6 · 4 = 24, 26 − 24 = 2."},
{t:"29 ta qalam 3 bolaga teng bo'lindi (iloji boricha ko'p). Har biriga nechtadan va nechta ortdi?",o:["9 tadan, 2 ta ortdi","9 tadan, 3 ta ortdi","8 tadan, 5 ta ortdi","10 tadan, 1 ta ortdi"],k:0,s:"3 · 9 = 27, 29 − 27 = 2."},
{t:"17 nafar bola sayohatga boradi. Har mashinaga 4 kishi sig'adi. Kamida nechta mashina kerak?",o:["5","4","6","3"],k:0,s:"4 ta to'ladi (16), 1 bola qoladi — yana 1 mashina."},
{t:"23 o'quvchi 5 kishilik jamoalarga bo'lindi. Oxirgi, to'liq bo'lmagan jamoada nechta o'quvchi?",o:["3","5","4","2"],k:0,s:"5 · 4 = 20, 23 − 20 = 3."},
{t:"23 ta olma 4 tadan joylandi. Yana bitta savat to'lishi uchun kamida nechta olma qo'shish kerak?",o:["1","3","2","4"],k:0,s:"3 ta ortdi, 4 − 3 = 1."},
{t:"17 ta gulni 3 ta guldonga teng qo'yish uchun eng kami bilan yana nechta gul kerak?",o:["1","2","3","4"],k:0,s:"18 − 17 = 1."},
{t:"Qaysi sonni 4 ga bo'lganda 3 ortib qoladi?",o:["23","24","22","20"],k:0,s:"23 = 4 · 5 + 3."},
{t:"Narsalarni 5 tadan guruhlaganda qancha ortib qolishi MUMKIN EMAS?",o:["5","1","3","4"],k:0,s:"5 ta ortsa — yana bitta guruh."},
{t:"30 kun nechta to'liq hafta va necha kun?",o:["4 hafta va 2 kun","3 hafta va 9 kun","5 hafta","4 hafta va 3 kun"],k:0,s:"7 · 4 = 28, 30 − 28 = 2."},
{t:"Avtobusga 9 kishi sig'adi. 30 kishini olib ketish uchun kamida nechta avtobus kerak?",o:["4","3","5","27"],k:0,s:"9 · 3 = 27, 3 kishi qoladi — yana 1 avtobus: 4."},
{t:"20 ta konfet 6 bolaga teng bo'lindi. Har biriga nechtadan tegdi?",o:["3","4","2","14"],k:0,s:"6 · 3 = 18, 2 ta ortadi."},
{t:"Qutiga 8 ta qalam sig'adi. 35 ta qalam uchun nechta quti to'liq bo'ladi?",o:["4","5","3","27"],k:0,s:"8 · 4 = 32, 3 ta ortadi."},
{t:"Qutiga 8 ta qalam sig'adi. 35 ta qalamning hammasini joylash uchun kamida nechta quti kerak?",o:["5","4","3","6"],k:0,s:"4 ta to'ladi, 3 ta ortgani uchun yana 1 quti."},
{t:"Ali 22 ta yong'oqni 5 do'stiga teng bo'ldi, ortganini o'zi oldi. Alida nechta yong'oq qoldi?",o:["2","4","5","3"],k:0,s:"5 · 4 = 20, 22 − 20 = 2."},
{t:"Qaysi yozuv to'g'ri?",o:["19 = 4 · 4 + 3","19 = 4 · 3 + 7","19 = 4 · 5 − 1 + 1","19 = 4 · 4 + 4"],k:0,s:"16 + 3 = 19, ortgan 3 < 4."},
{t:"Bir son 3 ga bo'linganda 6 chiqdi va 2 ortdi. Bu qaysi son?",o:["20","18","16","11"],k:0,s:"3 · 6 + 2 = 20."},
{t:"50 o'quvchi, avtobusga 24 kishi sig'adi. Kamida nechta avtobus kerak?",o:["3","2","4","26"],k:0,s:"24 · 2 = 48, 2 kishi qoladi — 3 ta avtobus."},
{t:"Sinfda 25 o'quvchi. Har partada 2 kishi o'tiradi. Kamida nechta parta kerak?",o:["13","12","25","14"],k:0,s:"2 · 12 = 24, 1 kishi qoladi — 13 ta parta."},
{t:"Oy dushanbadan boshlanib, 30 kun davom etdi. Keyingi oyning 1-kuni haftaning qaysi kuni?",o:["Chorshanba","Dushanba","Seshanba","Payshanba"],k:0,s:"30 = 4 hafta + 2 kun. Dushanbadan 2 kun keyin — chorshanba."}
];
function PRACT_STAGE(){cDeal(14,4,12,{per:4,who:'savat'});cMsg('Hammasi = guruhlar · har birida + ortgani')}
var PREP_DATA={teach:["Teng guruhlarga ajratishda ortib qolgan narsa.","Ortgan narsa guruhdan kam bo'lishi.","Teng bo'lishish va tekshirish: 29 = 9 · 3 + 2.","Tuzoqlar: «kamida nechta kerak», «yana nechta qo'shish kerak», teskari savol."],
 mist:["«Kamida nechta mashina» da to'liq guruhlarni javob deb yozadi (4).","«Yana nechta qo'shish kerak» da ortgan sonni yozadi.","Ortgan narsa guruhdan ko'p bo'lib qoladi (3 savat, 8 ortdi).","Tekshirishda ortganini qo'shishni unutadi."],
 need:["Qalam/olma va savat/quti.","Joriy oy kalendari."],
 board:["<span class='w2'>14 = 4 · 3 + 2</span>.","Ortgan &lt; guruh.","<span class='w2'>17 bola, 4 tadan → 4 ta + 1 → 5 mashina</span>.","<span class='w2'>23 → 3 ortdi → 4 − 3 = 1 qo'shish</span>.","<span class='w2'>30 = 7 · 4 + 2</span>."]};
