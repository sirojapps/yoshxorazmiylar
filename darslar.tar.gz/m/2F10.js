var CODE='2F10',TITLE='2-sinf · To‘g‘ri to‘rtburchakning yuzi';
// ---------- sahna ----------
var TG={x0:20,y0:12,cs:16,cols:20,rows:9};
function t10Paper(){clear('#ffffff');var g=S.g,K=TG;for(var c=0;c<=K.cols;c++)E('line',{x1:K.x0+c*K.cs,y1:K.y0,x2:K.x0+c*K.cs,y2:K.y0+K.rows*K.cs,stroke:'#dbe7f3'},g);for(var r=0;r<=K.rows;r++)E('line',{x1:K.x0,y1:K.y0+r*K.cs,x2:K.x0+K.cols*K.cs,y2:K.y0+r*K.cs,stroke:'#dbe7f3'},g)}
function t10Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
// to'rtburchak: w (bo'yi, gorizontal), h (eni, vertikal), r0,c0 — chap yuqori katak
function t10Rect(w,h,o){o=o||{};t10Paper();var K=TG,r0=o.r0!=null?o.r0:1,c0=o.c0!=null?o.c0:2,g=S.g;
 for(var r=0;r<h;r++)for(var c=0;c<w;c++){var on=o.rows!=null?r<o.rows:true;E('rect',{x:K.x0+(c0+c)*K.cs+1,y:K.y0+(r0+r)*K.cs+1,width:K.cs-2,height:K.cs-2,rx:2,fill:on?(o.col||C.a):'#fbe6c6'},g);
  if(o.num&&on)T(g,K.x0+(c0+c)*K.cs+K.cs/2,K.y0+(r0+r)*K.cs+12,String(r*w+c+1),{'font-size':8,'font-weight':800,fill:'#fff'})}
 E('rect',{x:K.x0+c0*K.cs,y:K.y0+r0*K.cs,width:w*K.cs,height:h*K.cs,fill:'none',stroke:C.line,'stroke-width':2},g);
 if(!o.nolab){T(g,K.x0+(c0+w/2)*K.cs,K.y0+r0*K.cs-3,'bo‘yi '+w+' sm',{'font-size':10,'font-weight':700,fill:C.blue});E('text',{},g);var t=T(g,K.x0+c0*K.cs-6,K.y0+(r0+h/2)*K.cs+4,h+' sm',{'font-size':10,'font-weight':700,fill:C.blue,'text-anchor':'end'})}
 if(o.rows!=null&&o.rows>0)for(var k=0;k<o.rows;k++)T(g,K.x0+(c0+w)*K.cs+16,K.y0+(r0+k)*K.cs+12,String((k+1)*w),{'font-size':10,'font-weight':800,fill:C.t1})}
// qatorlab sanash
var P1=[function(){t10Rect(4,3,{rows:0});t10Msg('Bo‘yi 4 sm, eni 3 sm. Kataklarni qatorlab sanaymiz')},
 function(){t10Rect(4,3,{rows:1});t10Msg('1-qator: <b>4</b> ta katak')},
 function(){t10Rect(4,3,{rows:2});t10Msg('2 qator: 4 + 4 = <b>8</b>')},
 function(){t10Rect(4,3,{rows:3});t10Msg('3 qator: 4 + 4 + 4 = <b>4 · 3 = 12 sm²</b>')}];
var P4=[function(){t10Rect(7,6,{nolab:1,col:'#f6d9a8'});t10Msg('Hovlining yuzi 42 m², bo‘yi 7 m. Eni-chi?')},
 function(){t10Rect(7,6,{rows:1,nolab:1});t10Msg('Bitta qatorda 7 ta kvadrat metr')},
 function(){t10Rect(7,6,{rows:6,nolab:1});t10Msg('Nechta qator? 42 : 7 = <b>6</b>. Eni <b>6 m</b>. Tekshiramiz: 7 · 6 = 42 ✓')}];
var P5=[function(){t10Rect(6,4,{nolab:1,col:'#f6d9a8'});t10Msg('Yuzi 24 sm², bo‘yi 6 sm. Perimetri-chi?')},
 function(){t10Rect(6,4);t10Msg('1) Eni: 24 : 6 = <b>4 sm</b>')},
 function(){t10Rect(6,4);var K=TG;E('rect',{x:K.x0+2*K.cs,y:K.y0+1*K.cs,width:6*K.cs,height:4*K.cs,fill:'none',stroke:C.bad,'stroke-width':3.5},S.g);t10Msg('2) Perimetr: 6 + 4 + 6 + 4 = <b>20 sm</b>. Javob 24 ham, 10 ham emas!')}];
var P6=[function(){t10L(0);t10Msg('L-shakl. Uning yuzi qancha? Ikki usul bor')},
 function(){t10L(1);t10Msg('1-usul: ikkiga bo‘lamiz: 5 · 2 = 10 va 2 · 3 = 6. Jami <b>16 sm²</b>')},
 function(){t10L(2);t10Msg('2-usul: butun to‘rtburchak 5 · 5 = 25, qirqilgani 3 · 3 = 9. 25 − 9 = <b>16 sm²</b> ✓')}];
var P7=[function(){t10Sq(0);t10Msg('Kvadratning perimetri 36 sm. Yuzi qancha?')},
 function(){t10Sq(1);t10Msg('1) Tomoni: 36 : 4 = <b>9 sm</b> (kvadratning 4 tomoni teng)')},
 function(){t10Sq(2);t10Msg('2) Yuzi: 9 · 9 = <b>81 sm²</b>. «36» — bu perimetr, yuz emas!')}];
var STEPS=[
{h:"Bittalab emas — qatorlab",sum:"4 × 3 to'rtburchak: har qatorda 4 tadan, 3 qator — 4 · 3 = 12 katak.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=3;P1[3]()},
 html:"<p>To'g'ri to'rtburchakdagi kataklarni bittalab sanash uzoq. Kataklar <b>teng qatorlarda</b> joylashgan — demak qatorlab sanash mumkin. Kuzating.</p>",
 btns:[phaser(P1,'▶ Yana bir qator')],
 after:"<p>Har qatorda <b>4 ta</b>, qatorlar <b>3 ta</b>: 4 + 4 + 4 = <b>4 · 3 = 12</b>. Teng qo'shiluvchilarni qo'shish — bu ko'paytirish! To'g'ri to'rtburchakning yuzini ko'paytirish bilan topish mumkin.</p>",
 q:{t:"Har qatorda 5 tadan katak, 4 ta qator. Yuz necha katak?",opts:["9","20","18","54"],ok:1,why:"5 · 4 = 20.",hint:"Teng qatorlar — ko'paytirish. Har qatorda nechta, nechta qator?",full:"5 + 5 + 5 + 5 = 5 · 4 = 20 katak. «9» — 5 va 4 ni qo'shib yuborish, «18» — perimetr (5 + 4 + 5 + 4)."},
 tn:"Darslikda bu ko'paytirish tushunchasidan keyin keladi (86-dars). Bolalar to'rtburchakni qatorlarga ajratib, qo'shishni ko'paytirishga aylantirsin."},
{h:"Yuz = bo'yi × eni",sum:"To'g'ri to'rtburchakning yuzi = bo'yi · eni. 6 sm × 3 sm = 18 sm².",a:"m02",
 start:function(){S.w=4;S.h=3;t10Draw()},fin:function(){S.w=6;S.h=3;t10Draw()},
 html:"<p>Bo'yi va enini o'zgartiring — pastda yuz darhol hisoblanadi. Kataklarni sanab tekshiring.</p>",
 btns:[["bo'yi +1",function(c,done){if(S.w<14){S.w++;t10Draw();mvK(done)}}],["bo'yi −1",function(c,done){if(S.w>1){S.w--;t10Draw();mvK(done)}}],["eni +1",function(c,done){if(S.h<7){S.h++;t10Draw();mvK(done)}},'u'],["eni −1",function(c,done){if(S.h>1){S.h--;t10Draw();mvK(done)}},'u']],g2:1,
 after:"<p>Qoida: <b>to'g'ri to'rtburchakning yuzi = bo'yi · eni</b>. Bo'yi va eni bir xil birlikda bo'lishi shart (ikkalasi sm bo'lsa — javob sm², ikkalasi m bo'lsa — m²).</p>",
 q:{t:"Gilamchaning bo'yi 7 dm, eni 3 dm. Uning yuzi qancha?",opts:["10 dm²","20 dm","21 dm²","21 dm"],ok:2,why:"7 · 3 = 21 dm².",hint:"Yuz = bo'yi · eni. Birlik qanday bo'ladi?",full:"7 · 3 = 21, birligi dm² (kvadrat detsimetr). «21 dm» — birlik xato, «10» — qo'shib yuborish, «20 dm» — perimetr."},
 tn:"Formulani yod oldirishdan oldin bolalar 3–4 ta to'rtburchakning kataklarini sanab, keyin ko'paytirib tekshirsin — formula o'zi «kashf» qilinsin."},
{h:"Kvadratning yuzi",sum:"Kvadratda bo'yi = eni: yuz = tomoni · tomoni. Tomoni 3 sm → 9 sm².",a:"m03",
 start:function(){t10Rect(3,3);t10Msg('Kvadrat: tomoni 3 sm')},fin:function(){t10Rect(5,5,{c0:3,r0:2});t10Msg('Tomoni 5 sm: 5 · 5 = <b>25 sm²</b>')},
 html:"<p>Kvadrat — bo'yi ham, eni ham teng bo'lgan to'g'ri to'rtburchak. Tomonini tanlang:</p>",
 btns:[["tomoni 3",function(c,done){t10Rect(3,3);t10Msg('3 · 3 = <b>9 sm²</b>');mvK(done,2)}],["tomoni 4",function(c,done){t10Rect(4,4);t10Msg('4 · 4 = <b>16 sm²</b>');mvK(done,2)}],["tomoni 5",function(c,done){t10Rect(5,5,{c0:3,r0:2});t10Msg('5 · 5 = <b>25 sm²</b>');mvK(done,2)}]],g3:1,
 after:"<p>Kvadratning yuzi = <b>tomoni · tomoni</b>. Tomoni 2 marta oshsa (2 dan 4 ga), yuzi <b>4 marta</b> oshadi (4 dan 16 ga)!</p>",
 q:{t:"Tomoni 6 sm bo'lgan kvadratning yuzi qancha?",opts:["12 sm²","24 sm²","36 sm²","6 sm²"],ok:2,why:"6 · 6 = 36 sm².",hint:"Kvadratning bo'yi va eni teng. Ko'paytiring.",full:"6 · 6 = 36 sm². «24» — perimetr (6 · 4), «12» — 6 + 6."},
 tn:"Katakli qog'ozda 1 × 1, 2 × 2, 3 × 3, 4 × 4 kvadratlarni chizdiring: yuzlari 1, 4, 9, 16 — bolalar qonuniyatni o'zi ko'rsin."},
{h:"Teskari: yuz va bo'yi ma'lum",sum:"Yuz 42 m², bo'yi 7 m → eni = 42 : 7 = 6 m.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Masala: <i>«To'g'ri to'rtburchak shaklidagi hovlining yuzi 42 m², bo'yi 7 m. Hovlining eni necha metr?»</i></p>",
 btns:[phaser(P4)],
 after:"<p>Yuz = bo'yi · eni bo'lsa, <b>eni = yuz : bo'yi</b>. Har qatorda 7 ta kvadrat metr — nechta qator bo'lsa 42 chiqadi? 42 : 7 = 6.</p>",
 q:{t:"To'g'ri to'rtburchakning yuzi 32 sm², eni 4 sm. Bo'yi necha sm?",opts:["8 sm","28 sm","36 sm","128 sm"],ok:0,why:"32 : 4 = 8 sm.",hint:"Yuzni ma'lum tomonga bo'ling.",full:"Bo'yi = yuz : eni = 32 : 4 = 8 sm. Tekshiramiz: 8 · 4 = 32 ✓. «28» — ayirib yuborish, «128» — ko'paytirib yuborish."},
 tn:"Ko'paytirish va bo'lish bog'liqligini (2C7) shu yerda qo'llang: «qaysi son 7 ga ko'paytirilsa 42 bo'ladi?»"},
{h:"Tuzoq: yuzdan perimetrga",sum:"Yuz 24 sm², bo'yi 6 sm → eni 4 sm → perimetr 6 + 4 + 6 + 4 = 20 sm.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Testda shunday keladi: <i>«To'g'ri to'rtburchakning yuzi 24 sm², bo'yi 6 sm. Uning perimetri necha sm?»</i> Ikki qadamli masala!</p>",
 btns:[phaser(P5)],
 after:"<p>Avval yuzdan <b>enini</b> topamiz (24 : 6 = 4), keyin <b>perimetrni</b> (6 + 4 + 6 + 4 = 20). Ko'pchilik birinchi qadamda to'xtab qoladi yoki 24 ni javob deb yozadi.</p>",
 q:{t:"To'g'ri to'rtburchakning yuzi 56 sm², bo'yi 8 sm. Uning perimetri necha sm?",opts:["15 sm","22 sm","30 sm","64 sm"],ok:2,why:"Eni 56 : 8 = 7; perimetr 8 + 7 + 8 + 7 = 30.",hint:"Avval enini toping, keyin to'rtta tomonni qo'shing.",full:"Eni: 56 : 8 = 7 sm. Perimetr: 8 + 7 + 8 + 7 = 30 sm. «15» — faqat ikki tomon, «22» — 7 + 7 + 8, «64» — 56 + 8."},
 tn:"Bolalar har bir qadamni alohida yozsin: «1) eni = …; 2) perimetr = …». Ko'p bosqichli masalalarda bu odat juda muhim."},
{h:"Murakkab shakl: bo'lib yoki to'ldirib",sum:"L-shakl: ikki to'rtburchakka bo'lib qo'shamiz (10 + 6) yoki to'ldirib ayiramiz (25 − 9) — 16 sm².",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Shakl to'g'ri to'rtburchak bo'lmasa-chi? Uni to'rtburchaklarga <b>bo'lish</b> yoki to'rtburchakkacha <b>to'ldirish</b> mumkin.</p>",
 btns:[phaser(P6,'▶ Keyingi usul')],
 after:"<p>Ikki usul, bitta javob — <b>16 sm²</b>. <b>Bo'lish</b>: qismlar yuzini qo'shamiz. <b>To'ldirish</b>: katta to'rtburchakdan ortiqchasini ayiramiz. Ikkinchi usul bilan birinchisini tekshirish qulay.</p>",
 q:{t:"6 × 4 to'g'ri to'rtburchakdan 2 × 2 kvadrat qirqib olindi. Qolgan shaklning yuzi necha sm²?",opts:["20","24","28","4"],ok:0,why:"6 · 4 = 24, 2 · 2 = 4; 24 − 4 = 20.",hint:"Butunning yuzidan qirqilganining yuzini ayiring.",full:"Butun: 6 · 4 = 24 sm². Qirqilgan: 2 · 2 = 4 sm². Qoldi: 24 − 4 = 20 sm². «28» — qo'shib yuborish."},
 tn:"Bu — darslikdagi «nostandart shakllar yuzi» usulining boshlanishi. Uy plani chizib, xonalar yuzini qo'shish ham yaxshi mashq."},
{h:"Tuzoq: perimetri ma'lum kvadrat",sum:"Perimetr 36 sm → tomoni 36 : 4 = 9 sm → yuz 9 · 9 = 81 sm².",a:"m07",
 start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Testlarda eng ko'p takrorlanadigan savol: <i>«Kvadratning perimetri 36 sm. Uning yuzini toping.»</i></p>",
 btns:[phaser(P7)],
 after:"<p>Perimetrdan avval <b>tomonni</b> topamiz (4 ga bo'lib), keyin tomonni <b>o'ziga ko'paytiramiz</b>. Javoblardagi tuzoqlar: 36 (perimetrning o'zi), 18 (2 ga bo'lish), 9 (faqat tomoni).</p>",
 q:{t:"Kvadratning perimetri 28 sm. Uning yuzi necha sm²?",opts:["14","28","49","196"],ok:2,why:"Tomoni 28 : 4 = 7, yuzi 7 · 7 = 49.",hint:"Kvadratning nechta tomoni bor? Avval bitta tomonni toping.",full:"Tomoni: 28 : 4 = 7 sm. Yuzi: 7 · 7 = 49 sm². «196» — 28 · 7 kabi xato ko'paytirish, «14» — 28 : 2."},
 tn:"Doskaga «P → tomoni → S» zanjirini yozing va bolalar har safar shu tartibda yechishsin."},
{h:"Bilasizmi? Geometriya — «yer o'lchash»",sum:"Misrda Nil toshqinidan keyin dalalar qayta o'lchangan; «geometriya» — yunoncha «yer o'lchash».",a:"m08",
 start:function(){t10Field()},fin:function(){t10Field()},
 html:"<p>📜 Qadimgi Misrda har yili Nil daryosi toshib, dalalarning chegaralarini yuvib ketardi. Shundan keyin o'lchovchilar arqon bilan dalalarni <b>qayta o'lchab</b>, kimga qancha yer tegishini hisoblashgan. Yunonlar bu ilmni «<b>geometriya</b>» — «yer o'lchash» deb atashgan.</p><p>⭐ Vatandoshimiz <b>al-Xorazmiy</b> ham «Al-jabr» kitobida yer maydonlarini o'lchash qoidalarini yozgan.</p>",
 tn:"Maktab hovlisida qadam bilan bo'yi va enini o'lchab, maydon yuzini taxminan hisoblang."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){t10Rect(4,3,{rows:3});t10Msg('4 · 3 = 12 sm²')},fin:function(){t10Rect(4,3,{rows:3});t10Msg('4 · 3 = 12 sm²')},
 html:"<div class='memo'><ul><li>To'g'ri to'rtburchak yuzi: <b>S = bo'yi · eni</b> (4 · 3 = 12 sm²).</li><li>Kvadrat yuzi: <b>S = tomoni · tomoni</b> (6 · 6 = 36 sm²).</li><li>Birliklar bir xil bo'lsin: sm · sm = sm², m · m = m².</li><li>Teskari: <b>eni = S : bo'yi</b> (42 : 7 = 6).</li><li>S dan P ga: avval ikkinchi tomon, keyin P = 2 bo'yi + 2 eni.</li><li>Kvadrat P dan S ga: tomoni = P : 4, keyin S = tomoni · tomoni (36 → 9 → 81).</li><li>Murakkab shakl: bo'lib qo'shing yoki to'ldirib ayiring.</li></ul></div>",
 tn:"Keyingi darsni «Perimetri 16 sm bo'lgan to'rtburchaklardan qaysi birining yuzi eng katta?» savoli bilan boshlang (kvadrat 4 × 4 = 16)."}
];
function t10Draw(){t10Rect(S.w,S.h,{c0:S.w>12?1:2});t10Msg('Yuz = bo‘yi · eni = '+S.w+' · '+S.h+' = <b>'+(S.w*S.h)+' sm²</b>')}
function t10L(k){t10Paper();var K=TG,g=S.g,r0=1,c0=6,cell=function(r,c,col){E('rect',{x:K.x0+(c0+c)*K.cs+1,y:K.y0+(r0+r)*K.cs+1,width:K.cs-2,height:K.cs-2,rx:2,fill:col},g)};
 for(var r=0;r<5;r++)for(var c=0;c<5;c++){var inL=(r>=3)||(c<2);if(inL)cell(r,c,k===1?(r>=3?'#5aa9e6':C.a):C.a);else if(k===2)cell(r,c,'#ffd0d0')}
 if(k===2)E('rect',{x:K.x0+c0*K.cs,y:K.y0+r0*K.cs,width:5*K.cs,height:5*K.cs,fill:'none',stroke:C.bad,'stroke-width':2,'stroke-dasharray':'5 4'},g);
 T(g,K.x0+(c0+2.5)*K.cs,K.y0+(r0+5)*K.cs+14,'5 sm',{'font-size':10,'font-weight':700,fill:C.blue});T(g,K.x0+c0*K.cs-6,K.y0+(r0+2.5)*K.cs+4,'5 sm',{'font-size':10,'font-weight':700,fill:C.blue,'text-anchor':'end'})}
function t10Sq(k){t10Paper();var K=TG,g=S.g,c0=7,r0=0,n=9,s=K.cs*n/9;E('rect',{x:K.x0+c0*K.cs,y:K.y0+r0*K.cs,width:n*K.cs,height:n*K.cs,fill:k===2?'#f6c98a':'#fff7ea',stroke:k===0?C.bad:C.line,'stroke-width':k===0?3.5:2},g);
 if(k>=1){T(g,K.x0+(c0+4.5)*K.cs,K.y0+(r0+n)*K.cs-4,'9 sm',{'font-size':11,'font-weight':800,fill:C.blue});T(g,K.x0+c0*K.cs-6,K.y0+(r0+4.5)*K.cs+4,'9 sm',{'font-size':11,'font-weight':800,fill:C.blue,'text-anchor':'end'})}
 if(k===2)T(g,K.x0+(c0+4.5)*K.cs,K.y0+(r0+4.5)*K.cs+6,'81 sm²',{'font-size':18,'font-weight':800,fill:C.t1});if(k===0)T(g,K.x0+(c0+4.5)*K.cs,K.y0+(r0+4.5)*K.cs+6,'P = 36 sm',{'font-size':14,'font-weight':800,fill:C.bad})}
function t10Field(){clear('#f6ead0');var g=S.g;E('path',{d:'M0 150 Q90 120 180 150 T360 150 L360 174 L0 174 Z',fill:'#7fb3e0'},g);T(g,180,168,'Nil',{'font-size':11,'font-weight':800,fill:'#fff'});
 [[40,30,90,70,'#cfe8b8'],[140,30,70,70,'#e3d38e'],[220,30,100,70,'#cfe8b8']].forEach(function(f){E('rect',{x:f[0],y:f[1],width:f[2],height:f[3],fill:f[4],stroke:'#6b3d12','stroke-width':2,'stroke-dasharray':'6 3'},g)});
 t10Msg('Dalalarning chegarasi arqon bilan qayta o‘lchangan')}
var PROBS=[
{t:"Bo'yi 5 sm, eni 3 sm bo'lgan to'g'ri to'rtburchakning yuzi?",o:["15 sm²","8 sm²","16 sm","15 sm"],k:0,s:"5 · 3 = 15 sm²."},
{t:"Tomoni 4 sm bo'lgan kvadratning yuzi?",o:["16 sm²","8 sm²","16 sm","12 sm²"],k:0,s:"4 · 4 = 16 sm²."},
{t:"Gilamning bo'yi 7 dm, eni 3 dm. Uning yuzi?",o:["21 dm²","10 dm²","20 dm²","24 dm²"],k:0,s:"7 · 3 = 21 dm²."},
{t:"Devorning eni 7 m, balandligi 3 m. Uning yuzi?",o:["21 m²","10 m²","20 m²","24 m²"],k:0,s:"7 · 3 = 21 m²."},
{t:"Hovlining yuzi 42 m², bo'yi 7 m. Eni necha metr?",o:["6 m","7 m","35 m","49 m"],k:0,s:"42 : 7 = 6."},
{t:"To'g'ri to'rtburchakning yuzi 24 sm², bo'yi 6 sm. Perimetri?",o:["20 sm","10 sm","18 sm","24 sm"],k:0,s:"Eni 24 : 6 = 4; P = 6 + 4 + 6 + 4 = 20."},
{t:"Kvadratning perimetri 36 sm. Yuzi?",o:["81 sm²","36 sm²","72 sm²","54 sm²"],k:0,s:"Tomoni 36 : 4 = 9; 9 · 9 = 81."},
{t:"Yuzi 49 sm² bo'lgan kvadratning perimetri?",o:["28 sm","14 sm","32 sm","49 sm"],k:0,s:"7 · 7 = 49, tomoni 7; P = 7 · 4 = 28."},
{t:"Maydonning bo'yi 16 m, eni bo'yining yarmiga teng. Yuzi?",o:["128 m²","24 m²","48 m²","256 m²"],k:0,s:"Eni 8; 16 · 8 = 128."},
{t:"Qaysi to'rtburchakning yuzi eng katta: 5 × 2, 3 × 3, 6 × 1, 4 × 2?",o:["5 × 2","3 × 3","6 × 1","4 × 2"],k:0,s:"Yuzlar: 10, 9, 6, 8. Eng kattasi 5 × 2 = 10."},
{t:"6 × 4 to'rtburchakdan 2 × 2 kvadrat qirqildi. Qolgan yuz?",o:["20 sm²","24 sm²","28 sm²","22 sm²"],k:0,s:"24 − 4 = 20."},
{t:"Ikki to'rtburchak yonma-yon: 5 × 4 va 5 × 6. Umumiy yuz?",o:["50 m²","20 m²","30 m²","60 m²"],k:0,s:"20 + 30 = 50."},
{t:"Tomoni 3 sm kvadratning tomoni 2 marta oshirildi. Yuzi necha marta oshdi?",o:["4 marta","2 marta","3 marta","6 marta"],k:0,s:"9 dan 36 ga: 4 marta."},
{t:"Bo'yi 9 dm, eni 4 dm to'rtburchakning bo'yi 2 marta oshirildi. Yangi yuz?",o:["72 dm²","36 dm²","18 dm²","26 dm²"],k:0,s:"Bo'yi 18; 18 · 4 = 72."},
{t:"Kvadrat va to'g'ri to'rtburchakning yuzlari teng. Kvadrat tomoni 6 sm, to'rtburchak eni 4 sm. To'rtburchak perimetri?",o:["26 sm","24 sm","36 sm","18 sm"],k:0,s:"Yuz 36; bo'yi 36 : 4 = 9; P = 9 + 4 + 9 + 4 = 26."},
{t:"Perimetri 24 sm, bo'yi enidan 2 marta uzun to'rtburchakning yuzi?",o:["32 sm²","48 sm²","24 sm²","36 sm²"],k:0,s:"Eni + bo'yi = 12, bo'yi = 2 eni: eni 4, bo'yi 8; 8 · 4 = 32."},
{t:"Perimetri 46 sm, bo'yi 14 sm bo'lgan to'rtburchakning yuzi?",o:["126 sm²","32 sm²","448 sm²","644 sm²"],k:0,s:"Eni (46 − 28) : 2 = 9; 14 · 9 = 126."},
{t:"Kvadratning yuzi 64 sm². Perimetrining yarmi?",o:["16 sm","32 sm","8 sm","28 sm"],k:0,s:"Tomoni 8; P = 32, yarmi 16."},
{t:"Yuzi 54 dm² to'rtburchak 6 ta teng kvadratga bo'lindi. Har kvadrat tomoni?",o:["3 dm","9 dm","6 dm","48 dm"],k:0,s:"Har kvadrat 54 : 6 = 9 dm², tomoni 3 dm."},
{t:"Bo'yi 6 sm, eni 3 sm to'rtburchakning eni 3 marta oshirildi. Yuzi necha sm² ga ortdi?",o:["36 sm²","54 sm²","18 sm²","9 sm²"],k:0,s:"Avval 18, keyin 6 · 9 = 54; ortish 54 − 18 = 36."}
];
function PRACT_STAGE(){t10Rect(4,3,{rows:3});t10Msg('S = bo‘yi · eni')}
var PREP_DATA={teach:["Qatorlab sanash → ko'paytirish; to'g'ri to'rtburchak yuzi S = bo'yi · eni.","Kvadrat yuzi; birliklar (sm², dm², m²).","Teskari masala: eni = S : bo'yi.","Murakkab qism: S dan P ga, kvadrat P dan S ga, L-shakl (bo'lish va to'ldirish)."],
 mist:["Bo'yi va enini qo'shib yuboradi (7 + 3 = 10).","Yuz va perimetrni chalkashtiradi; birlikni sm deb yozadi.","Kvadrat perimetridan yuzga o'tishda 36 ni javob deydi.","Ikki qadamli masalada birinchi qadamda to'xtaydi."],
 need:["Katakli qog'oz, chizg'ich.","1 sm² kvadratchalar (kartondan)."],
 board:["4 × 3: <span class='w2'>4 + 4 + 4 = 4 · 3 = 12 sm²</span>.","<span class='w2'>S = a · b</span>, kvadrat <span class='w2'>S = a · a</span>.","<span class='w2'>42 : 7 = 6</span> m.","<span class='w2'>24 : 6 = 4 → P = 20</span>.","<span class='w2'>P = 36 → a = 9 → S = 81</span>.","L-shakl: <span class='w2'>10 + 6 = 25 − 9 = 16</span>."]};
