var CODE='3J16',TITLE='3-sinf · Labirint, yo‘l va xarita';
// --- labirint (yo'lak bo'ylab yurish, chorrahada tanlash) ---
var J16M=["S#.....#.",".###.#.#.","...#.#...","##.#.###.",".....#..F"],J16={},J16D=[[0,-1],[0,1],[-1,0],[1,0]];
function j16Free(c,r){return r>=0&&r<5&&c>=0&&c<9&&J16M[r][c]!=='#'}
function j16Nb(c,r){return J16D.filter(function(d){return j16Free(c+d[0],r+d[1])}).length}
function j16Has(L,c,r){return L.some(function(p){return p[0]===c&&p[1]===r})}
function j16Maze(){clear();var g=S.g,cell=30,x0=45,y0=12,path=J16.p;
 j2Grid(9,5,cell,x0,y0,function(c,r){if(J16M[r][c]==='#')return '#5b4a3a';if(j16Has(path,c,r))return '#9fdcb8';if(j16Has(J16.dead,c,r))return '#f6c9c9';return '#fff'});
 var d='';path.forEach(function(p,i){d+=(i?'L':'M')+(x0+p[0]*cell+14.5)+' '+(y0+p[1]*cell+14.5)});E('path',{d:d,fill:'none',stroke:'#1e8e5a','stroke-width':4,'stroke-linecap':'round','stroke-linejoin':'round'},g);
 var L=path[path.length-1];T(g,x0+L[0]*cell+14.5,y0+L[1]*cell+21,'🐭',{'font-size':18});if(!(L[0]===8&&L[1]===4))T(g,x0+8*cell+14.5,y0+4*cell+21,'🧀',{'font-size':18})}
function j16Go(k0){return function(c,done){var k=k0,nm=['yuqoriga','pastga','chapga','o‘ngga'][k],p=J16.p,L=p[p.length-1];
 if(L[0]===8&&L[1]===4)return;if(J16.from>=0&&k===(J16.from^1)){j2Msg('Orqaga qaytmaymiz — u yo‘l allaqachon ko‘rilgan');return}
 var d=J16D[k],x=L[0],y=L[1],cells=[];if(!j16Free(x+d[0],y+d[1])){j2Msg(nm.charAt(0).toUpperCase()+nm.slice(1)+' — devor!');return}
 while(true){x+=d[0];y+=d[1];cells.push([x,y]);if(J16M[y][x]==='F'){J16.p=p.concat(cells);j16Maze();j2Msg('✓ Pishloq topildi! Yo‘l: <b>'+(J16.p.length-1)+'</b> qadam');done();return}
  var n=j16Nb(x,y);if(n>2)break;if(n===1){J16.dead=J16.dead.concat(cells);j16Maze();j2Msg('Boshi berk! Sichqoncha chorrahaga qaytdi. Pushti — tekshirilgan yo‘l');return}
  var nk=-1;for(var j=0;j<4;j++){if(j===(k^1))continue;if(j16Free(x+J16D[j][0],y+J16D[j][1])){nk=j;break}}k=nk;d=J16D[k]}
 J16.p=p.concat(cells);J16.from=k;j16Maze();j2Msg('Chorraha! Qaysi tomonga yuramiz?')}}
// --- xarita (graf) ---
var J16N={U:[34,96,'Uy'],P:[130,30,'Park'],B:[130,150,'Bozor'],D:[240,30,'Do‘kon'],M:[322,96,'Maktab']},J16E=[['U','P',4],['P','D',3],['D','M',4],['U','B',3],['B','M',9],['P','B',2],['B','D',5]];
function j16Map(hl){clear();var g=S.g;hl=hl||[];J16E.forEach(function(e){var a=J16N[e[0]],b=J16N[e[1]],on=hl.indexOf(e[0]+e[1])>=0||hl.indexOf(e[1]+e[0])>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#c9b48f','stroke-width':on?6:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-14,y:my-10,width:28,height:18,rx:5,fill:'#fff',stroke:'#c9b48f'},g);T(g,mx,my+4,e[2]+' km',{'font-size':10,'font-weight':800,fill:'#5b4a3a'})});
 for(var k in J16N){var n=J16N[k];E('rect',{x:n[0]-25,y:n[1]-11,width:50,height:22,rx:11,fill:'#fff7ea',stroke:'#8a5a24','stroke-width':2},g);T(g,n[0],n[1]+4,n[2],{'font-size':10,'font-weight':800,fill:'#8a5a24'})}}
var J16R=[['UP','PD','DM'],['UB','BM'],['UB','BD','DM']];
// --- panjara yo'llari ---
function j16Lat(W,H,vals,o){o=o||{};clear();var g=S.g,s=Math.min(46,120/H,240/W),x0=180-W*s/2,y0=86+H*s/2;
 for(var i=0;i<=W;i++)E('line',{x1:x0+i*s,y1:y0,x2:x0+i*s,y2:y0-H*s,stroke:'#b9c7d6','stroke-width':3},g);for(var j=0;j<=H;j++)E('line',{x1:x0,y1:y0-j*s,x2:x0+W*s,y2:y0-j*s,stroke:'#b9c7d6','stroke-width':3},g);
 T(g,x0-12,y0+14,'A',{'font-size':14,'font-weight':800,fill:C.blue});T(g,x0+W*s+12,y0-H*s-4,'B',{'font-size':14,'font-weight':800,fill:C.bad});
 for(var j=0;j<=H;j++)for(var i=0;i<=W;i++){var v=vals&&vals[j]&&vals[j][i];if(v!=null){E('circle',{cx:x0+i*s,cy:y0-j*s,r:11,fill:i===W&&j===H?'#fde6e6':'#fff',stroke:i===W&&j===H?C.bad:'#4b8fd9','stroke-width':2},g);T(g,x0+i*s,y0-j*s+4,v,{'font-size':11,'font-weight':800,fill:'#1d2b3a'})}}}
var P3=[function(){j16Lat(3,2);j2Msg('Pochtachi A dan B ga faqat <b>o‘ngga</b> yoki <b>yuqoriga</b> yuradi. Nechta yo‘l bor?')},
 function(){j16Lat(3,2,[[1,1,1,1],[1],[1]]);j2Msg('Pastki qator va chap ustun chorrahalariga faqat <b>1</b> xil yo‘l bilan boriladi')},
 function(){j16Lat(3,2,[[1,1,1,1],[1,2,3,4],[1]]);j2Msg('Har chorrahaga: <b>pastdagi + chapdagi</b>. 1 + 1 = 2, 2 + 1 = 3, 3 + 1 = 4')},
 function(){j16Lat(3,2,[[1,1,1,1],[1,2,3,4],[1,3,6,10]]);j2Msg('Yuqori qator: 1 + 2 = 3, 3 + 3 = 6, 6 + 4 = <b>10</b>. Jami <b>10</b> ta yo‘l')}];
// --- kompas ---
var J16W=[[0,0],[0,3],[4,3],[4,2],[2,2]];
function j16Comp(n){clear();var g=S.g,cell=24,x0=100,y0=140;for(var i=0;i<=8;i++)E('line',{x1:x0+i*cell-48,y1:y0+12,x2:x0+i*cell-48,y2:y0-5*cell+12,stroke:'#e6ecf2'},g);for(var j=0;j<=5;j++)E('line',{x1:x0-48,y1:y0-j*cell+12,x2:x0+8*cell-48,y2:y0-j*cell+12,stroke:'#e6ecf2'},g);
 var X=function(p){return x0+p[0]*cell-36},Y=function(p){return y0-p[1]*cell};var d='M'+X(J16W[0])+' '+Y(J16W[0]);for(var k=1;k<=n;k++)d+='L'+X(J16W[k])+' '+Y(J16W[k]);E('path',{d:d,fill:'none',stroke:C.blue,'stroke-width':4,'stroke-linejoin':'round'},g);
 E('circle',{cx:X(J16W[0]),cy:Y(J16W[0]),r:7,fill:C.ok},g);var L=J16W[n];T(g,X(L),Y(L)+6,'🚶',{'font-size':18});
 var cx=310,cy=62;E('circle',{cx:cx,cy:cy,r:22,fill:'#fff',stroke:'#33475b','stroke-width':2},g);E('polygon',{points:cx+','+(cy-16)+' '+(cx-5)+','+cy+' '+(cx+5)+','+cy,fill:C.bad},g);[['Sh',0,-28],['J',0,36],['Shq',36,4],['G‘',-33,4]].forEach(function(a){T(g,cx+a[1],cy+a[2],a[0],{'font-size':10,'font-weight':800})});
 if(n===4){E('line',{x1:X(J16W[0]),y1:Y(J16W[0]),x2:X(L),y2:Y(L),stroke:C.bad,'stroke-width':2.5,'stroke-dasharray':'5 4'},g)}}
var P5=[function(){j16Comp(0);j2Msg('Yo‘riqnoma: 3 shimolga, 4 sharqqa, 1 janubga, 2 g‘arbga')},
 function(){j16Comp(1);j2Msg('3 qadam <b>shimolga</b> (yuqoriga)')},function(){j16Comp(2);j2Msg('4 qadam <b>sharqqa</b> (o‘ngga)')},function(){j16Comp(3);j2Msg('1 qadam <b>janubga</b> (pastga)')},
 function(){j16Comp(4);j2Msg('2 qadam <b>g‘arbga</b>. Natija: boshidan <b>2 shimolda va 2 sharqda</b>. Shimol−janub: 3 − 1 = 2; sharq−g‘arb: 4 − 2 = 2')}];
// --- bir chiziq bilan chizish ---
function j16Fig(kind,deg){clear();var g=S.g,pts,ed;if(kind==='uy'){pts=[[130,150],[230,150],[230,80],[130,80],[180,24]];ed=[[0,1],[1,2],[2,3],[3,0],[0,2],[1,3],[3,4],[4,2]]}else{pts=[[130,140],[230,140],[230,40],[130,40]];ed=[[0,1],[1,2],[2,3],[3,0],[0,2],[1,3]]}
 ed.forEach(function(e){E('line',{x1:pts[e[0]][0],y1:pts[e[0]][1],x2:pts[e[1]][0],y2:pts[e[1]][1],stroke:'#33475b','stroke-width':3},g)});
 if(deg)pts.forEach(function(p,i){var n=ed.filter(function(e){return e[0]===i||e[1]===i}).length,odd=n%2;E('circle',{cx:p[0],cy:p[1],r:11,fill:odd?'#fde6e6':'#e3f6ea',stroke:odd?C.bad:C.ok,'stroke-width':2},g);T(g,p[0],p[1]+4,n,{'font-size':11,'font-weight':800,fill:odd?C.bad:C.ok})})}
var P6=[function(){j16Fig('uy');j2Msg('«Uy» shaklini qalamni ko‘tarmay, har chiziqdan <b>bir marta</b> o‘tib chizish mumkinmi?')},
 function(){j16Fig('uy',1);j2Msg('Har tugundan nechta chiziq chiqishini sanaymiz. <b>Toq</b> tugunlar (qizil): faqat 2 ta')},
 function(){j16Fig('uy',1);j2Msg('Qoida: toq tugunlar <b>0 yoki 2</b> ta bo‘lsa — chizish mumkin. 2 ta bo‘lsa, ularning birida <b>boshlab</b>, ikkinchisida tugatamiz')},
 function(){j16Fig('kv',1);j2Msg('Kvadrat + 2 diagonal (o‘rtadagi kesishishda burilmaymiz): 4 ta toq tugun → bir chiziq bilan <b>chizib bo‘lmaydi</b>')}];
var STEPS=[
{h:"Labirintdan chiqing",sum:"Labirintda yo'lni katakma-katak quramiz; boshi berk yo'ldan orqaga qaytamiz.",a:"m01",
 start:function(){J16.p=[[0,0]];J16.dead=[];J16.from=-1;j16Maze();j2Msg('Sichqonchani pishloqqa olib boring. U yo\u2018lak bo\u2018ylab o\u2018zi yuradi, <b>chorrahada</b> siz tanlaysiz')},
 fin:function(){J16.p=[[0,0],[0,1],[0,2],[1,2],[2,2],[2,3],[2,4],[3,4],[4,4],[4,3],[4,2],[4,1],[4,0],[5,0],[6,0],[6,1],[6,2],[7,2],[8,2],[8,3],[8,4]];J16.dead=[];j16Maze();j2Msg('✓ 20 qadam')},
 html:"<p>Jigarrang kataklar — devor. Yo'nalishni tanlang: sichqoncha keyingi chorrahagacha o'zi yuradi. Boshi berk yo'lga kirsa — qaytib keladi va bu yo'l pushti rangga bo'yaladi.</p>",
 g2:1,btns:[["⬆ Yuqoriga",j16Go(0)],["⬇ Pastga",j16Go(1)],["⬅ Chapga",j16Go(2)],["➡ O\u2018ngga",j16Go(3)]],
 after:"<p>Labirint usullari: <b>orqadan boshlash</b> (pishloqdan sichqonga), <b>boshi berk yo'llarni bo'yab yopish</b>. Katta labirintlarda «o'ng qo'l qoidasi» ham yordam beradi: devorga o'ng qo'lingizni tegizib yuravering.</p>",
 q:{t:"Labirintda bitta yo'l chorrahasidan 3 ta yo'lak chiqadi: biri — kelgan yo'lingiz, ikkitasi — yangi. Ikkala yangi yo'lak ham boshi berk chiqdi. Nima qilish kerak?",opts:["Chorrahadan oldingi chorrahaga qaytib, boshqa yo'lni sinash","Shu chorrahada qolish","Devordan o'tish","Boshidan qayta boshlab, xuddi shu yo'ldan yurish"],ok:0,why:"Boshi berk joydan orqaga qaytib, sinab ko'rilmagan yo'lni tanlaymiz.",hint:"Hamma yangi yo'l yopiq bo'lsa, xato qayerda qilingan?",full:"Xato oldingi tanlovda bo'lgan. Orqaga — oxirgi tekshirilmagan yo'li bor chorrahaga — qaytib, o'sha yo'lni sinaymiz. Bir xil yo'ldan qayta yurish natija bermaydi."},
 tn:"Bolalar qog'ozda labirint chizib, sherigiga almashtirsin. Boshi berk yo'llarni qalam bilan bo'yab yopish usulini ko'rsating."},
{h:"Eng qisqa yo'l",sum:"Xaritada Uy → Maktab: Park va Do'kon orqali 4+3+4 = 11 km — eng qisqasi; Bozor orqali 3+9 = 12 km.",a:"m02",
 start:function(){j16Map();j2Msg('Uydan maktabga <b>eng qisqa</b> yo‘l qaysi?')},fin:function(){j16Map(J16R[0]);j2Msg('✓ 4 + 3 + 4 = <b>11 km</b>')},
 html:"<p>Har yo'lning uzunligi yozilgan. Eng <b>kam bo'lakli</b> yo'l eng qisqasi bo'lmasligi mumkin! Har yo'lni qo'shib chiqing va tanlang:</p>",
 btns:j2Pick(["Uy → Park → Do‘kon → Maktab","Uy → Bozor → Maktab","Uy → Bozor → Do‘kon → Maktab"],0,function(){j16Map(J16R[0]);j2Msg('✓ 4 + 3 + 4 = <b>11 km</b> — eng qisqasi')},function(i){j16Map(J16R[i]);j2Msg(i===1?'3 + 9 = <b>12 km</b>. Faqat 2 bo‘lak, lekin uzunroq!':'3 + 5 + 4 = <b>12 km</b>')}),
 after:"<p>Usul: <b>barcha</b> yo'llarni yozib, har birini qo'shamiz. Yoki aqlliroq — har shaharga eng qisqa masofani belgilab boramiz: Park — 4, Bozor — 3, Do'kon — 7, Maktab — 11.</p>",
 q:{t:"A–B 5 km, B–D 4 km, A–C 3 km, C–D 7 km, C–B 1 km. A dan D gacha eng qisqa yo'l necha km?",opts:["8","9","10","5"],ok:0,why:"A → C → B → D: 3 + 1 + 4 = 8.",hint:"Uch bo'lakli yo'lni ham tekshiring: A → C → B → D.",full:"A–B–D: 9, A–C–D: 10, A–C–B–D: 3 + 1 + 4 = 8 — eng qisqasi. Bo'laklar ko'p bo'lsa ham, yig'indi kichik bo'lishi mumkin."},
 tn:"Doskada xarita chizing, bolalar guruhlarda yo'llarni topib qo'shsin. Kim hamma yo'lni topdi — g'olib."},
{h:"Nechta yo'l bor? (panjara)",sum:"Faqat o'ngga/yuqoriga: har chorrahaga yo'llar = pastdagi + chapdagi. 3×2 panjarada 10 ta yo'l.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=3;P3[3]()},
 html:"<p>Ko'chalar panjara shaklida. Yo'llarni bittalab sanash — adashish xavfi katta. Ayyor usul — <b>har chorrahaga sonni yozib</b> borish.</p>",
 btns:[phaser(P3,'▶ Keyingi')],
 after:"<p>Nega qo'shamiz? Chorrahaga faqat ikki joydan kelish mumkin: <b>pastdan</b> yoki <b>chapdan</b>. Demak, u yerga yo'llar = pastki chorrahaga yo'llar + chapdagisiga yo'llar.</p>",
 q:{t:"2×2 panjarada (2 katak o'ngga, 2 katak yuqoriga) A dan B ga faqat o'ngga va yuqoriga yurib nechta yo'l bor?",opts:["6","4","8","12"],ok:0,why:"Chorrahalar: 1,1,1 / 1,2,3 / 1,3,6.",hint:"Har chorrahaga pastdagi va chapdagi sonlar yig'indisini yozing.",full:"Pastki qator va chap ustun — 1. O'rtada 1 + 1 = 2, keyin 2 + 1 = 3, 1 + 2 = 3, oxiri 3 + 3 = 6. «4» — faqat chetdagi yo'llarni sanash."},
 tn:"Bu usul — Paskal uchburchagi. Bolalar katakli qog'ozda o'zlari sonlarni yozib chiqsin."},
{h:"Masshtab",sum:"Masshtab 1 sm — 100 m: xaritada 7 sm → haqiqiy 700 m.",a:"m04",
 start:function(){clear();var g=S.g;E('rect',{x:20,y:20,width:320,height:96,rx:8,fill:'#eaf5e4',stroke:'#9cc28a'},g);T(g,54,64,'🏠',{'font-size':24});T(g,306,64,'🏫',{'font-size':24});E('line',{x1:54,y1:76,x2:306,y2:76,stroke:'#8a5a24','stroke-width':3,'stroke-dasharray':'6 4'},g);
  E('rect',{x:54,y:124,width:252,height:24,fill:'#fff3d6',stroke:'#c9a35a'},g);for(var i=0;i<=7;i++){E('line',{x1:54+i*36,y1:124,x2:54+i*36,y2:136,stroke:'#5b4a3a','stroke-width':1.5},g);T(g,54+i*36,146,i,{'font-size':10,'font-weight':800})}T(g,180,166,'xaritada, sm · masshtab: 1 sm — 100 m',{'font-size':11,fill:'#5b4a3a'});j2Msg('Uydan maktabgacha haqiqatda necha metr?')},
 fin:function(){STEPS[3].start();j2Msg('✓ 7 · 100 m = <b>700 m</b>')},
 html:"<p>Xaritada hamma narsa kichraytirilgan. <b>Masshtab</b> xaritadagi 1 sm haqiqatda qancha ekanini aytadi. Javobni tanlang:</p>",
 g2:1,btns:j2Pick(["700 m","7 m","70 m","107 m"],0,function(){j2Msg('✓ 7 sm · 100 m = <b>700 m</b>')},function(i){j2Msg(['','7 m — masshtabni hisobga olmadingiz','70 m — har 1 sm 100 m, 10 m emas','107 m — qo‘shmaymiz, ko‘paytiramiz'][i])}),
 after:"<p>Xaritadan haqiqatga — <b>ko'paytiramiz</b>, haqiqatdan xaritaga — <b>bo'lamiz</b>. 3 km = 3000 m, masshtab 1 sm — 500 m → 3000 : 500 = 6 sm.</p>",
 q:{t:"Masshtab: 1 sm — 5 km. Xaritada ikki shahar orasi 8 sm. Haqiqatda necha km?",opts:["40 km","13 km","8 km","400 km"],ok:0,why:"8 · 5 = 40 km.",hint:"Har 1 sm — 5 km. 8 sm-chi?",full:"8 · 5 km = 40 km. «13» — 8 + 5 qo'shildi, «400» — birliklar chalkashdi."},
 tn:"Sinf xonasining rejasini birga chizing: 1 katak — 1 metr. Bolalar partalar orasini haqiqatda o'lchab, rejadan tekshirsin."},
{h:"Kompas bo'yicha yurish",sum:"3 shimol, 4 sharq, 1 janub, 2 g'arb → boshidan 2 shimolda, 2 sharqda.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=4;P5[4]()},
 html:"<p>Xaritada shimol — yuqorida, janub — pastda, sharq — o'ngda, g'arb — chapda. Yo'lovchi yo'riqnoma bo'yicha yuradi. Kuzating:</p>",
 btns:[phaser(P5,'▶ Keyingi qadam')],
 after:"<p>Ayyor usul: qarama-qarshi yo'nalishlar bir-birini «yeydi». Shimol 3 − janub 1 = <b>2 shimol</b>; sharq 4 − g'arb 2 = <b>2 sharq</b>. Barcha qadamlar soni (10) — masofa emas!</p>",
 q:{t:"Ali 5 qadam shimolga, 3 qadam sharqqa, 5 qadam janubga yurdi. U boshlang'ich joydan qayerda?",opts:["3 qadam sharqda","3 qadam g'arbda","13 qadam narida","joyida"],ok:0,why:"Shimol 5 va janub 5 bir-birini yo'qotadi, 3 sharq qoladi.",hint:"Shimolga va janubga yurishlar bir-birini yo'qotadi.",full:"5 shimol − 5 janub = 0. Qoladi 3 qadam sharqqa. «13» — barcha qadamlarni qo'shish, «g'arb» — sharq bilan chalkashtirish."},
 tn:"Hovlida o'ynang: bitta bola yo'riqnoma o'qiydi, boshqasi yuradi. Oxirida qayerda turganini oldindan hisoblab, tekshiring."},
{h:"Bir chiziq bilan chizish",sum:"Shaklni qalamni ko'tarmay chizish mumkin, agar toq tugunlar soni 0 yoki 2 bo'lsa.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Mashhur jumboq: «uy»ni qalamni ko'tarmay va hech bir chiziqdan ikki marta o'tmay chizing. Sirni bilib olamiz:</p>",
 btns:[phaser(P6,'▶ Keyingi')],
 after:"<p>Nega? O'rtadagi har tugunga <b>kirsak — chiqamiz</b>, shuning uchun chiziqlar juft-juft. Toq tugun faqat <b>boshlanish</b> yoki <b>tugash</b> bo'la oladi. Ular 2 tadan ko'p bo'lsa — chizib bo'lmaydi.</p>",
 q:{t:"Shaklda 4 ta toq tugun bor. Uni chizish uchun qalamni kamida necha marta ko'tarish kerak?",opts:["1","2","4","0"],ok:0,why:"4 toq tugun → 2 ta alohida chiziq kerak → qalam 1 marta ko'tariladi.",hint:"Har bitta uzluksiz chiziq ikki toq tugunni «yopadi».",full:"Har uzluksiz chiziq ko'pi bilan 2 ta toq tugunda boshlanib-tugaydi. 4 ta toq tugun → 2 ta chiziq → ular orasida qalam 1 marta ko'tariladi. «0» — mumkin emas (toq tugunlar 2 dan ko'p), «2» — chiziqlar soni, ko'tarishlar emas."},
 tn:"Doskada 3–4 ta shakl chizing: bolalar avval tugunlarni sanab bashorat qilsin, keyin chizib tekshirsin."},
{h:"Bilasizmi? Kyonigsberg ko'priklari",sum:"1736-yilda Leonard Eyler Kyonigsbergning 7 ko'prigidan har biridan bir marta o'tib aylanib chiqish mumkin emasligini isbotlagan.",a:"m07",
 start:function(){clear();var g=S.g;E('rect',{x:10,y:66,width:340,height:42,fill:'#bfe0f5'},g);E('ellipse',{cx:150,cy:87,rx:38,ry:14,fill:'#d9f0c8',stroke:'#8ab76f'},g);E('ellipse',{cx:265,cy:87,rx:28,ry:12,fill:'#d9f0c8',stroke:'#8ab76f'},g);
  [[128,66,128,77],[172,66,172,77],[128,97,128,108],[172,97,172,108],[188,87,237,87],[265,66,265,75],[265,99,265,108]].forEach(function(b){E('line',{x1:b[0],y1:b[1],x2:b[2],y2:b[3],stroke:'#8a5a24','stroke-width':6},g)});
  T(g,180,40,'Pregel daryosi · 4 ta quruqlik · 7 ta ko‘prik',{'font-size':12,'font-weight':800,fill:'#33475b'});T(g,180,150,'toq tugunlar: 4 ta (5, 3, 3, 3)',{'font-size':12,fill:C.bad,'font-weight':800})},
 fin:function(){STEPS[6].start()},
 html:"<p>🌉 Kyonigsberg shahrida (hozir Kaliningrad) 7 ta ko'prik bo'lgan. Odamlar har ko'prikdan <b>bir martadan</b> o'tib aylanib chiqishga urinishgan — hech kim uddalay olmagan. <b>1736</b>-yilda <b>Leonard Eyler</b> buning mumkin emasligini isbotladi: to'rtala quruqlikdan ham toq sondagi ko'prik chiqadi.</p>",
 btns:[["Tushundim",function(c,done){j2Msg('Eyler shu jumboqdan matematikaning yangi bo‘limi — <b>graflar nazariyasi</b>ni boshlab berdi');done()}]],
 after:"<p>Bugun xuddi shu g'oyalar navigatorlar eng qisqa yo'lni topishida va pochta yo'nalishlarini tuzishda ishlatiladi.</p>",
 tn:"Ko'priklar xaritasini doskaga chizing — bolalar 2 daqiqa urinib ko'rsin, keyin Eyler qoidasi bilan tushuntiring."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j16Lat(3,2,[[1,1,1,1],[1,2,3,4],[1,3,6,10]])},fin:function(){j16Lat(3,2,[[1,1,1,1],[1,2,3,4],[1,3,6,10]])},
 html:"<div class='memo'><ul><li>Labirint: boshi berk yo'ldan orqaga; ba'zan oxiridan boshlash oson.</li><li>Eng qisqa yo'l: <b>hamma</b> yo'llarni qo'shib solishtiring — kam bo'lakli ≠ qisqa.</li><li>Panjara yo'llari: har chorrahaga <b>pastdagi + chapdagi</b>.</li><li>Masshtab: xaritadan haqiqatga — ko'paytiring, aksincha — bo'ling.</li><li>Kompas: shimol − janub, sharq − g'arb.</li><li>Bir chiziq bilan chizish: toq tugunlar <b>0 yoki 2</b>.</li><li>Ketma-ket yo'llar: 2 yo'l · 3 yo'l = 6 xil.</li></ul></div>",
 tn:"Uyga vazifa: uydan maktabgacha yo'lning sxemasini chizib, masshtab tanlash."}
];
var PROBS=[
{t:"Masshtab: 1 sm — 100 m. Xaritada uydan maktabgacha 7 sm. Haqiqatda necha metr?",o:["700 m","7 m","70 m","107 m"],k:0,s:"7 · 100 = 700 m."},
{t:"Masshtab: 1 sm — 5 km. Xaritada shaharlar orasi 8 sm. Haqiqatda necha km?",o:["40 km","13 km","8 km","400 km"],k:0,s:"8 · 5 = 40 km."},
{t:"Masshtab: 1 sm — 500 m. Haqiqiy masofa 3 km. Xaritada necha sm bo'ladi?",o:["6 sm","3 sm","15 sm","60 sm"],k:0,s:"3 km = 3000 m; 3000 : 500 = 6 sm."},
{t:"Masshtab: 1 sm — 2 km. Xaritada masofa 4 sm 5 mm. Haqiqatda necha km?",o:["9 km","8 km","10 km","45 km"],k:0,s:"4 sm → 4 · 2 = 8 km; 5 mm — yarim sm → 1 km. Jami 9 km."},
{t:"Ali 5 qadam shimolga, 3 qadam sharqqa, 5 qadam janubga yurdi. U boshlang'ich joydan qayerda?",o:["3 qadam sharqda","3 qadam g'arbda","13 qadam narida","joyida"],k:0,s:"Shimol va janub bir-birini yo'qotadi."},
{t:"Vali 4 qadam shimolga, 2 qadam sharqqa, 1 qadam janubga, 2 qadam g'arbga yurdi. U boshlang'ich joydan qayerda?",o:["3 qadam shimolda","2 qadam sharqda","9 qadam narida","joyida"],k:0,s:"4 − 1 = 3 shimol; 2 − 2 = 0."},
{t:"Ali shimolga qarab turibdi. U o'ngga burildi, keyin yana o'ngga burildi. Endi qayerga qaraydi?",o:["janubga","shimolga","sharqqa","g'arbga"],k:0,s:"Shimol → sharq → janub."},
{t:"Ali shimolga qarab turibdi. U 3 marta chapga burildi (har safar chorak aylanish). Endi qayerga qaraydi?",o:["sharqqa","g'arbga","janubga","shimolga"],k:0,s:"Shimol → g'arb → janub → sharq."},
{t:"Uydan maktabga 2 xil yo'l, maktabdan parkka 3 xil yo'l bor. Uydan maktab orqali parkka necha xil yo'l bilan borish mumkin?",o:["6","5","3","9"],k:0,s:"Har yo'lga 3 davom: 2 · 3 = 6."},
{t:"A dan B ga 3 yo'l, B dan C ga 2 yo'l, A dan C ga to'g'ridan 1 yo'l bor. A dan C ga necha xil yo'l bilan borish mumkin?",o:["7","6","5","3"],k:0,s:"B orqali 3 · 2 = 6, to'g'ridan 1. Jami 7."},
{t:"A–B 5 km, B–D 4 km, A–C 3 km, C–D 7 km, C–B 1 km. A dan D gacha eng qisqa yo'l necha km?",o:["8","9","10","5"],k:0,s:"A → C → B → D: 3 + 1 + 4 = 8."},
{t:"Uy–A 2 km, A–Maktab 5 km, Uy–B 4 km, B–Maktab 2 km, A–B 1 km. Uydan maktabgacha eng qisqa yo'l necha km?",o:["5 km","6 km","7 km","3 km"],k:0,s:"Uy → A → B → Maktab: 2 + 1 + 2 = 5."},
{t:"Faqat o'ngga yoki yuqoriga yurib, 2×2 panjarada A dan B ga nechta yo'l bor?",o:["6","4","8","12"],k:0,s:"1,1,1 / 1,2,3 / 1,3,6."},
{t:"Faqat o'ngga yoki yuqoriga yurib, 3×2 panjarada (3 o'ngga, 2 yuqoriga) nechta yo'l bor?",o:["10","6","12","5"],k:0,s:"Yuqori qator: 1, 3, 6, 10."},
{t:"Faqat o'ngga yoki yuqoriga yurib, 3×3 panjarada nechta yo'l bor?",o:["20","9","16","12"],k:0,s:"1,1,1,1 / 1,2,3,4 / 1,3,6,10 / 1,4,10,20."},
{t:"Faqat o'ngga yoki yuqoriga yurib, 2×2 panjarada, lekin o'rtadagi chorrahadan o'tmasdan, nechta yo'l bor?",o:["2","4","6","3"],k:0,s:"Jami 6; o'rtadan o'tadiganlari 2 · 2 = 4. 6 − 4 = 2 (chetlardan)."},
{t:"Robot har buyruqda bitta katak o'ngga yoki yuqoriga yuradi. B nuqta A dan 3 katak o'ngda va 2 katak yuqorida. Robot eng kamida nechta buyruqda yetadi?",o:["5","6","3","2"],k:0,s:"3 + 2 = 5 buyruq."},
{t:"Qaysi shaklni qalamni ko'tarmay, har chiziqdan bir marta o'tib chizish mumkin?",o:["kvadrat va uning bitta diagonali","kvadrat va ikkala diagonali","ikkita alohida doira","«+» belgisi"],k:0,s:"Bitta diagonalda toq tugun 2 ta. Ikkala diagonalda 4 ta, «+» da 4 ta toq tugun; alohida doiralar tutashmagan."},
{t:"Shaklda 4 ta toq tugun bor. Uni chizish uchun qalamni kamida necha marta ko'tarish kerak?",o:["1","2","4","0"],k:0,s:"4 toq tugun → 2 ta chiziq → 1 marta ko'tarish."},
{t:"Kyonigsbergning 7 ko'prigi haqidagi jumboqni kim yechgan (mumkin emasligini isbotlagan)?",o:["Leonard Eyler","Isaak Nyuton","Pifagor","Al-Xorazmiy"],k:0,s:"Eyler, 1736-yil."}
];
function PRACT_STAGE(){j16Map()}
var PREP_DATA={teach:["Labirintda yo'l izlash, orqaga qaytish.","Xaritada eng qisqa yo'l: barcha yo'llarni solishtirish.","Panjara yo'llarini sanash (pastdagi + chapdagi).","Masshtab, kompas yo'nalishlari.","Bir chiziq bilan chizish (toq tugunlar)."],
 mist:["Kam bo'lakli yo'lni eng qisqa deb oladi.","Panjara yo'llarini bittalab sanab adashadi.","Masshtabda qo'shadi yoki birliklarni chalkashtiradi.","Kompasda barcha qadamlarni qo'shib, masofa deb oladi.","Toq tugunlarni sanamay, faqat sinab ko'radi."],
 need:["Katakli qog'oz, rangli qalam.","Doskada xarita va panjara.","Chizg'ich."],
 board:["<span class='w2'>Uy → Park → Do'kon → Maktab: 4+3+4 = 11</span>.","<span class='w2'>Panjara: pastdagi + chapdagi → 10</span>.","<span class='w2'>1 sm — 100 m: 7 sm → 700 m</span>.","<span class='w2'>3Sh 4Shq 1J 2G' → 2Sh, 2Shq</span>.","<span class='w2'>Toq tugun 0 yoki 2 → chizish mumkin</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
