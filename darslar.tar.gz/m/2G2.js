var CODE='2G2',TITLE='2-sinf · Piktogramma';
function g2Msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function g2Star(g,x,y,r,half,col){var p=[];for(var k=0;k<10;k++){var a=-Math.PI/2+k*Math.PI/5,rr=k%2?r*0.45:r;p.push((x+rr*Math.cos(a)).toFixed(1)+','+(y+rr*Math.sin(a)).toFixed(1))}
 if(half){var id='g2c'+(S.g2id=(S.g2id||0)+1);var cp=E('clipPath',{id:id},g);E('rect',{x:x-r,y:y-r,width:r,height:2*r},cp);E('polygon',{points:p.join(' '),fill:'none',stroke:'#c9a227','stroke-width':1,'stroke-dasharray':'2 2'},g);E('polygon',{points:p.join(' '),fill:col||'#f5c518',stroke:'#c9a227','stroke-width':1,'clip-path':'url(#'+id+')'},g)}
 else E('polygon',{points:p.join(' '),fill:col||'#f5c518',stroke:'#c9a227','stroke-width':1},g)}
// rows=[[nom, yulduzlar(0.5 mumkin)]], key — 1 ★ qiymati
function g2Pic(rows,o){o=o||{};clear();var g=S.g,y0=o.top||18,rh=Math.min(30,(o.key!==false?128:150)/rows.length);
 if(o.title)T(g,180,12,o.title,{'font-size':11,'font-weight':800,fill:C.blue});
 rows.forEach(function(r,i){var y=y0+8+i*rh+rh/2,on=o.hl&&o.hl.indexOf(i)>=0;E('rect',{x:6,y:y-rh/2+2,width:348,height:rh-4,rx:6,fill:on?'#fff4d6':'#f7f9fb',stroke:'#e1e7ee'},g);T(g,48,y+4,r[0],{'font-size':11,'font-weight':800});
  var n=Math.floor(r[1]);for(var k=0;k<n;k++)g2Star(g,100+k*24,y,Math.min(10,rh/2-4),0,o.col);if(r[1]-n>0)g2Star(g,100+n*24,y,Math.min(10,rh/2-4),1,o.col);
  if(o.vals&&o.key)T(g,340,y+4,'= '+(r[1]*o.key),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'})});
 if(o.key!==false){var ky=166;g2Star(g,24,ky-4,7,0,o.col);T(g,40,ky,'= '+(o.key?o.key:'?')+(o.unit||' ta'),{'font-size':11,'font-weight':800,'text-anchor':'start',fill:C.blue});
  if(o.halfkey){g2Star(g,124,ky-4,7,1,o.col);T(g,140,ky,'= '+o.halfkey,{'font-size':11,'font-weight':800,'text-anchor':'start',fill:C.blue})}}}
var R1=[['Olma',4],['Nok',6],['Anor',3]];
var R2=[['Ali',3],['Vali',5],['Soli',2]];
var R3=[['Kitob',2.5],['Daftar',4],['Ruchka',1.5]];
var P2=[function(){g2Pic(R2,{key:1,title:'Kim nechta medal oldi (★ = 1)'});g2Msg('★ = 1. Ali — 3 ★ = <b>3</b> medal')},
 function(){g2Pic(R2,{key:2,title:'Endi kalit o‘zgardi: ★ = 2'});g2Msg('Xuddi shu rasm, lekin ★ = 2. Ali — 3 ★ = 2 + 2 + 2 = <b>6</b>')},
 function(){g2Pic(R2,{key:10,vals:1,title:'Kalit: ★ = 10'});g2Msg('★ = 10 bo‘lsa, Vali — 5 ★ = <b>50</b>. Kalitsiz piktogrammani o‘qib bo‘lmaydi!')}];
var P3=[function(){g2Pic(R3,{key:2,halfkey:1,title:'Do‘konda sotilgan buyumlar (★ = 2)'});g2Msg('Yarim yulduz nimani bildiradi?')},
 function(){g2Pic(R3,{key:2,halfkey:1,hl:[0],title:'Do‘konda sotilgan buyumlar (★ = 2)'});g2Msg('★ = 2 bo‘lsa, yarim ★ = <b>1</b>. Kitob: 2 + 2 + 1 = <b>5</b>')},
 function(){g2Pic(R3,{key:2,halfkey:1,vals:1,title:'Do‘konda sotilgan buyumlar (★ = 2)'});g2Msg('Daftar — 8, ruchka — 2 + 1 = <b>3</b>')}];
var P5=[function(){g2Pic([['1-hafta',5],['2-hafta',3]],{key:false,title:'Ekilgan ko‘chatlar'});g2Msg('Kalit yo‘q! Lekin bilamiz: 1-haftada 8 ta <b>ko‘p</b> ekilgan')},
 function(){g2Pic([['1-hafta',5],['2-hafta',3]],{key:false,hl:[0],title:'Ekilgan ko‘chatlar'});g2Msg('Yulduzlar farqi: 5 − 3 = <b>2 ★</b>. Demak, 2 ★ = 8')},
 function(){g2Pic([['1-hafta',5],['2-hafta',3]],{key:4,vals:1,title:'Ekilgan ko‘chatlar'});g2Msg('2 ★ = 8, demak 1 ★ = <b>4</b>. 1-hafta: 20, 2-hafta: 12')}];
var STEPS=[
{h:"Piktogramma nima?",sum:"Piktogramma — sonlarni rasmlar bilan ko'rsatish. Har bir rasm kalitdagi songa teng.",a:"m01",
 start:function(){g2Pic(R1,{key:1,title:'Bog‘dagi daraxtlar'});g2Msg('Qatorni bosing yoki savolga qarang: nechta olma daraxti?')},fin:function(){g2Pic(R1,{key:1,vals:1,title:'Bog‘dagi daraxtlar'});g2Msg('Olma 4, nok 6, anor 3')},
 html:"<p><b>Piktogramma</b> — sonlar o'rniga <b>rasmlar</b> chizilgan diagramma. Pastda <b>kalit</b> bor: bitta ★ nechani bildirishini ko'rsatadi. Har bir mevani sanang:</p>",
 btns:[["🍎 Olma",function(c,done){g2Pic(R1,{key:1,hl:[0],title:'Bog‘dagi daraxtlar'});g2Msg('Olma: 4 ★ = <b>4</b> ta');S.g2a=(S.g2a||0)|1;if(S.g2a===7)done()}],["🍐 Nok",function(c,done){g2Pic(R1,{key:1,hl:[1],title:'Bog‘dagi daraxtlar'});g2Msg('Nok: 6 ★ = <b>6</b> ta');S.g2a=(S.g2a||0)|2;if(S.g2a===7)done()}],["🔴 Anor",function(c,done){g2Pic(R1,{key:1,hl:[2],title:'Bog‘dagi daraxtlar'});g2Msg('Anor: 3 ★ = <b>3</b> ta');S.g2a=(S.g2a||0)|4;if(S.g2a===7)done()},'u']],g3:1,
 after:"<p>Kalit ★ = 1 bo'lsa, yulduzlarni oddiy sanaymiz. Bog'da hammasi: 4 + 6 + 3 = <b>13</b> daraxt.</p>",
 q:{t:"Piktogrammada ★ = 1. Nok qatorida 6 ★, anorda 3 ★. Nok anordan nechta ko'p?",opts:["9","3","6","2"],ok:1,why:"6 − 3 = 3.",hint:"Yulduzlar farqini toping.",full:"Nok — 6, anor — 3. 6 − 3 = 3. «9» — qo'shib yuborgan."},
 tn:"Bolalar sinfdagi sevimli ranglar bo'yicha doskaga magnit yoki stiker yopishtirib piktogramma tuzsin."},
{h:"Kalit muhim: ★ = 2, ★ = 10",sum:"Bir xil rasm, lekin kalit boshqa bo'lsa — son ham boshqa. 3 ★ (★=2) = 6.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Ko'pincha bitta rasm <b>bir nechta</b> narsani bildiradi. Kalitni o'zgartirib ko'ramiz:</p>",
 btns:[phaser(P2)],
 after:"<p>Piktogrammani o'qishdan oldin <b>doim kalitga qarang</b>. ★ = 2 bo'lsa, ikkilab sanaymiz: 2, 4, 6…; ★ = 10 bo'lsa, o'nlab: 10, 20, 30…</p>",
 q:{t:"★ = 5. Qatorda 4 ★. Bu nechani bildiradi?",opts:["4","9","20","45"],ok:2,why:"5, 10, 15, 20.",hint:"Beshlab sanang: har ★ uchun 5.",full:"4 ta ★, har biri 5: 5 + 5 + 5 + 5 = 20. «4» — kalitni unutgan, «9» — 4 + 5 qilgan."},
 tn:"Sonlar o'qida ikkilab, beshlab, o'nlab sanashni takrorlang — piktogramma shunga tayanadi."},
{h:"Yarim rasm",sum:"★ = 2 bo'lsa, yarim ★ = 1. Kitob: 2 ★ va yarim ★ = 5.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ba'zan qator oxirida <b>yarim rasm</b> turadi. U kalitning yarmini bildiradi:</p>",
 btns:[phaser(P3)],
 after:"<p>Yarim ★ = kalitning yarmi. ★ = 2 → yarmi 1; ★ = 10 → yarmi 5. Shuning uchun yarim rasm faqat <b>juft</b> kalitda ishlatiladi.</p>",
 q:{t:"★ = 10. Qatorda 3 ★ va yarim ★. Nechta?",opts:["35","31","30","40"],ok:0,why:"10 + 10 + 10 + 5 = 35.",hint:"Yarim ★ — 10 ning yarmi.",full:"3 ★ = 30, yarim ★ = 5. 30 + 5 = 35. «31» — yarim rasmni 1 deb olgan."},
 tn:"Qog'oz doirachani qaychi bilan yarmiga kesib, yarim rasm nima ekanini ko'rsating."},
{h:"Piktogramma chizamiz",sum:"14 bola, ★ = 2 → 14 : 2 = 7 ta ★.",a:"m04",
 start:function(){S.g2n=0;g2Draw()},fin:function(){S.g2n=7;g2Draw()},
 html:"<p>Sinfda <b>14</b> bola tushlikka osh tanladi. Kalit: <b>★ = 2</b>. Nechta yulduz chizish kerak? Tugmani bosib, yulduz qo'shing:</p>",
 btns:[["➕ ★ qo'shish",function(c,done){if(S.g2n<9)S.g2n++;if(g2Draw())done()}],["➖ olib tashlash",function(c,done){if(S.g2n>0)S.g2n--;if(g2Draw())done()},'u']],g2:1,
 after:"<p>Ikkilab sanaymiz: 2, 4, 6, 8, 10, 12, <b>14</b> — 7 ta ★. Agar 15 bola bo'lsa — 7 ta butun va bitta yarim ★.</p>",
 q:{t:"Sho'rva tanlagan bolalar — 8 ta. ★ = 2. Nechta ★ chiziladi?",opts:["8","4","16","6"],ok:1,why:"2, 4, 6, 8 — 4 ta ★.",hint:"8 ga yetguncha ikkilab sanang.",full:"Har ★ — 2 bola. 2, 4, 6, 8 → 4 ta ★. «16» — ko'paytirib yuborgan."},
 tn:"Bolalar o'zlari kalit tanlab (★ = 2 yoki ★ = 5) bir xil ma'lumotni turli piktogrammada chizsin."},
{h:"Tuzoq: kalit yashiringan",sum:"5 ★ va 3 ★, farq 8 → 2 ★ = 8 → ★ = 4.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Masala: <i>«1-haftada 2-haftadagidan 8 ta ko'p ko'chat ekildi. Bitta ★ nechani bildiradi?»</i> Kalit berilmagan — topamiz:</p>",
 btns:[phaser(P5)],
 after:"<p>Yulduzlar <b>farqi</b> sonlar farqiga teng: 2 ★ = 8. Bitta ★ = 8 : 2 = <b>4</b>. Endi hamma qatorni o'qish mumkin: 20 va 12.</p>",
 q:{t:"Ali 6 ★, Vali 4 ★ oldi. Ali Validan 10 ball ko'p. ★ = ?",opts:["10","5","2","4"],ok:1,why:"2 ★ = 10, 1 ★ = 5.",hint:"Yulduzlar farqi nechta? U 10 ga teng.",full:"6 − 4 = 2 ★. 2 ★ = 10, demak ★ = 5. «2» — yulduzlar farqini javob deb olgan."},
 tn:"Bu bankdagi eng qiyin tur. Doskada farqni rangli qalam bilan alohida belgilang."},
{h:"Taqqoslash va jami",sum:"Avval har qatorni songa aylantiramiz, keyin qo'shamiz yoki ayiramiz.",a:"m06",
 start:function(){g2Pic([['Dushanba',3],['Seshanba',5],['Chorshanba',4]],{key:5,title:'Kutubxonaga kelgan bolalar (★ = 5)'});g2Msg('Uch kunda jami nechta bola keldi?')},fin:function(){g2Pic([['Dushanba',3],['Seshanba',5],['Chorshanba',4]],{key:5,vals:1,title:'Kutubxonaga kelgan bolalar (★ = 5)'});g2Msg('15 + 25 + 20 = <b>60</b> · yoki 12 ★ × 5 = 60')},
 html:"<p>Kutubxonaga kelgan bolalar, ★ = 5. Har bir kunni songa aylantiring:</p>",
 btns:[["🔢 Sonlarni ko'rsat",function(c,done){g2Pic([['Dushanba',3],['Seshanba',5],['Chorshanba',4]],{key:5,vals:1,title:'Kutubxonaga kelgan bolalar (★ = 5)'});g2Msg('15 + 25 + 20 = <b>60</b>');done()}]],
 after:"<p>Qisqa yo'l: avval <b>yulduzlarni</b> qo'shamiz: 3 + 5 + 4 = 12 ★, keyin beshlab: 12 ★ = <b>60</b>. Seshanba dushanbadan 2 ★ = <b>10</b> ta ko'p.</p>",
 q:{t:"★ = 5. Seshanba 5 ★, chorshanba 4 ★. Seshanba nechta ko'p bola kelgan?",opts:["1","5","9","45"],ok:1,why:"1 ★ farq = 5.",hint:"Avval yulduzlar farqi, keyin kalit.",full:"5 − 4 = 1 ★ = 5 bola. «1» — kalitni unutgan."},
 tn:"Bolalarga ikki yo'lni solishtiring: har qatorni alohida hisoblash va avval yulduzlarni qo'shish."},
{h:"Bilasizmi? Rasmlar tili",sum:"Piktogrammalarni 1920-yillarda Otto Noyrat tizimga solgan.",a:"m07",
 start:function(){g2Pic(R1,{key:1,col:'#7cc47c',title:'Rasm — hamma tushunadigan til'});g2Msg('Isotype — «rasmlar bilan xalqaro til»')},fin:function(){g2Pic(R1,{key:1,col:'#7cc47c',title:'Rasm — hamma tushunadigan til'});g2Msg('Isotype — «rasmlar bilan xalqaro til»')},
 html:"<p>🧍 <b>1920</b>-yillarda avstriyalik olim <b>Otto Noyrat</b> sonlarni bir xil kichik rasmchalar bilan ko'rsatishni o'ylab topdi. U buni <b>Isotype</b> deb atadi — tilni bilmagan odam ham tushunadigan «rasmlar tili».</p><p>🚻 Bugun aeroport, vokzal va yo'llardagi belgilar ham shu fikrdan kelib chiqqan.</p>",
 tn:"Bolalar maktab yo'lida ko'rgan belgi-rasmlarni (piktogrammalarni) chizib kelsin."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){g2Pic(R3,{key:2,halfkey:1,vals:1,title:'★ = 2'});g2Msg('Avval kalit, keyin sanash')},fin:function(){g2Pic(R3,{key:2,halfkey:1,vals:1,title:'★ = 2'});g2Msg('Avval kalit, keyin sanash')},
 html:"<div class='memo'><ul><li><b>Piktogramma</b> — sonlarni rasmlar bilan ko'rsatish.</li><li>Avval <b>kalitga</b> qarang: ★ = 1, 2, 5, 10?</li><li>Kalit bo'yicha sanang: ★ = 2 → 2, 4, 6…</li><li><b>Yarim rasm</b> = kalitning yarmi.</li><li>Kalit yo'q bo'lsa: yulduzlar farqi = sonlar farqi.</li><li>Jami: avval ★ larni qo'shing, keyin kalitga ko'paytiring.</li></ul></div>",
 tn:"Uyga vazifa: oiladagi har kishining bir haftada ichgan choy piyolalari bo'yicha piktogramma."}
];
function g2Draw(){var n=S.g2n;g2Pic([['Osh',n]],{key:2,title:'Osh tanlagan bolalar: 14 ta'});var ok=n===7;g2Msg(ok?'7 ta ★ × 2 = <b>14</b> — to‘g‘ri!':n+' ta ★ = '+(n*2)+' bola'+(n*2>14?' — ko‘p!':' — yana qo‘shing'));return ok}
var PROBS=[
{t:"★ = 1. Qatorda 7 ★. Nechta?",o:["7","1","8","14"],k:0,s:"Har ★ — 1."},
{t:"★ = 2. Qatorda 5 ★. Nechta?",o:["10","5","7","2"],k:0,s:"2, 4, 6, 8, 10."},
{t:"★ = 10. Qatorda 4 ★. Nechta?",o:["40","14","4","10"],k:0,s:"10, 20, 30, 40."},
{t:"★ = 5. Qatorda 3 ★. Nechta?",o:["15","8","3","35"],k:0,s:"5 + 5 + 5."},
{t:"★ = 2. Qatorda 3 ★ va yarim ★. Nechta?",o:["7","6","8","3"],k:0,s:"6 + 1 = 7."},
{t:"★ = 10. Qatorda 2 ★ va yarim ★. Nechta?",o:["25","21","20","30"],k:0,s:"20 + 5 = 25."},
{t:"★ = 2. 14 bolani ko'rsatish uchun nechta ★?",o:["7","14","12","28"],k:0,s:"14 : 2 = 7."},
{t:"★ = 5. 20 ta kitobni ko'rsatish uchun nechta ★?",o:["4","5","20","15"],k:0,s:"5, 10, 15, 20 — 4 ta."},
{t:"★ = 2. Ali 6 ★, Vali 4 ★. Ali nechta ko'p?",o:["4","2","10","20"],k:0,s:"2 ★ × 2 = 4."},
{t:"★ = 10. Olma 5 ★, nok 3 ★. Jami nechta?",o:["80","8","50","30"],k:0,s:"8 ★ × 10 = 80."},
{t:"5 ★ va 3 ★. Birinchisi 8 ta ko'p. ★ = ?",o:["4","8","2","16"],k:0,s:"2 ★ = 8 → ★ = 4."},
{t:"6 ★ va 4 ★. Birinchisi 10 ta ko'p. ★ = ?",o:["5","10","2","4"],k:0,s:"2 ★ = 10 → ★ = 5."},
{t:"4 ★ va 1 ★. Farq 9. ★ = ?",o:["3","9","4","5"],k:0,s:"3 ★ = 9 → ★ = 3."},
{t:"★ = 5. Dushanba 3 ★, seshanba 5 ★, chorshanba 4 ★. Jami?",o:["60","12","50","55"],k:0,s:"12 ★ × 5 = 60."},
{t:"★ = 2. Kitob 2 ★ va yarim ★, ruchka 1 ★ va yarim ★. Kitob nechta ko'p?",o:["2","1","8","3"],k:0,s:"5 − 3 = 2."},
{t:"Piktogrammada ★ ostidagi «★ = 2» yozuvi nima deyiladi?",o:["kalit","sarlavha","shkala","ustun"],k:0,s:"Kalit rasm qiymatini aytadi."},
{t:"★ = 10 bo'lsa, yarim ★ = ?",o:["5","1","10","2"],k:0,s:"10 ning yarmi — 5."},
{t:"★ = 5 bo'lsa, 35 ni ko'rsatish uchun nechta ★?",o:["7","5","35","6"],k:0,s:"5 × 7 = 35."},
{t:"★ = 2. Osh 7 ★, sho'rva 4 ★. Hammasi nechta bola?",o:["22","11","14","8"],k:0,s:"11 ★ × 2 = 22."},
{t:"Nega ★ = 1 o'rniga ★ = 10 olinadi?",o:["Katta sonlarni kam rasm bilan ko'rsatish uchun","Chiroyli bo'lishi uchun","Hisoblash qiyin bo'lishi uchun","Farqi yo'q"],k:0,s:"100 ta rasm o'rniga 10 ta yetadi."}
];
function PRACT_STAGE(){g2Pic(R3,{key:2,halfkey:1,vals:1,title:'★ = 2'});g2Msg('Avval kalit, keyin sanash')}
var PREP_DATA={teach:["Piktogramma va kalit tushunchasi.","★ = 2, 5, 10 bo'yicha sanash; yarim rasm.","Piktogramma chizish (14 : 2 = 7).","Kalitni farqdan topish; taqqoslash va jami."],
 mist:["Kalitga qaramay, rasmlarni sanaydi.","Yarim rasmni 1 deb oladi.","Yulduzlar farqini javob deb yozadi.","Chizishda bolalar sonicha rasm chizadi."],
 need:["Stikerlar yoki magnitlar, katakli qog'oz."],
 board:["★ = <span class='w2'>2</span> → 2, 4, 6…","Yarim ★ = <span class='w2'>1</span>.","5 ★ − 3 ★ = 2 ★ = 8 → <span class='w2'>★ = 4</span>."]};
