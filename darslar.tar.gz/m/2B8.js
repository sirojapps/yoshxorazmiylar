var CODE='2B8',TITLE='2-sinf · Qo‘shish va ayirishning bog‘liqligi, natijani tekshirish';
// son uchburchagi (bir oila tengliklar)
function b8Tri(top,a,b,eqs){clear();var g=S.g;E('path',{d:'M180 20 L80 140 L280 140 Z',fill:'#fdf3e3',stroke:C.line,'stroke-width':2},g);
 E('circle',{cx:180,cy:44,r:22,fill:'#fff',stroke:C.blue,'stroke-width':2.5},g);T(g,180,51,String(top),{'font-size':18,'font-weight':800,fill:C.blue});
 E('circle',{cx:118,cy:122,r:20,fill:'#fff',stroke:C.line,'stroke-width':2},g);T(g,118,129,String(a),{'font-size':17,'font-weight':800});E('circle',{cx:242,cy:122,r:20,fill:'#fff',stroke:C.line,'stroke-width':2},g);T(g,242,129,String(b),{'font-size':17,'font-weight':800});
 T(g,180,100,'butun',{'font-size':10,fill:'#5b6b7b'});T(g,180,160,'qismlar',{'font-size':10,fill:'#5b6b7b'});
 if(eqs&&eqs.length){var gx=E('g',{},g);eqs.forEach(function(e,i){T(gx,i<2?40:320,58+(i%2)*40,e,{'font-size':12,'font-weight':800,fill:i<2?C.ok:C.bad})})}}
var P2=[function(){bqExpr(['64 + 29 = 83 ?']);bqMsg('Vali shunday yozdi. To‘g‘rimi? Ayirish bilan tekshiramiz')},
 function(){bqExpr(['64 + 29 = 83 ?','83 − 29 = [54]']);bqMsg('Yig‘indidan bir qo‘shiluvchini ayirsak, ikkinchisi chiqishi kerak')},
 function(){bqExpr(['54 ≠ 64','✗ xato: 64 + 29 = 93']);bqMsg('54 chiqdi, 64 emas — demak Vali <b>xato</b> qilgan. To‘g‘risi: 93')}];
var P3=[function(){bqExpr(['63 − 28 = 45 ?']);bqMsg('Ali shunday hisobladi. Qo‘shish bilan tekshiramiz')},
 function(){bqExpr(['63 − 28 = 45 ?','45 + 28 = [73]']);bqMsg('Ayirma + ayriluvchi = kamayuvchi bo‘lishi kerak')},
 function(){bqExpr(['73 ≠ 63','✗ to‘g‘risi: 63 − 28 = 35']);bqMsg('73 chiqdi, 63 emas — Ali <b>xato</b>. To‘g‘risi 35: 35 + 28 = 63 ✓')}];
var P4=[function(){bqLine(30,100,[],[[47,C.blue],[38,'#9aa8b6']],{step:10});bqMsg('47 + 38 = 75 ? Avval taxminan hisoblaymiz')},
 function(){bqLine(30,100,[[50,90,'+40',C.ok]],[[50,C.blue],[90,C.ok]],{step:10});bqMsg('47 ≈ 50, 38 ≈ 40. Taxminan: 50 + 40 = <b>90</b>')},
 function(){bqLine(30,100,[[50,90,'+40',C.ok]],[[75,C.bad],[85,C.ok]],{step:10});bqMsg('75 — 90 dan juda uzoq. Haqiqiy javob: <b>85</b> (Vali 10 ga kam topgan)')}];
var STEPS=[
{h:"Bitta oila — to'rtta tenglik",sum:"45, 28, 73 sonlari: 45 + 28 = 73, 28 + 45 = 73, 73 − 28 = 45, 73 − 45 = 28.",a:"m01",
 start:function(){S.eq=[];b8Tri(73,45,28,[]);bqMsg('Uchburchakdagi sonlardan tengliklar tuzing')},fin:function(){b8Tri(73,45,28,['45 + 28 = 73','28 + 45 = 73','73 − 28 = 45','73 − 45 = 28'])},
 html:"<p>Uchburchak tepasida — <b>butun</b> (73), pastida — ikki <b>qism</b> (45 va 28). Ulardan to'rtta tenglik tuziladi. Tugmalarni bosing:</p>",
 btns:[["45 + 28",function(c,done,b){b8Add('45 + 28 = 73',done,b)}],["28 + 45",function(c,done,b){b8Add('28 + 45 = 73',done,b)}],["73 − 28",function(c,done,b){b8Add('73 − 28 = 45',done,b)},'u'],["73 − 45",function(c,done,b){b8Add('73 − 45 = 28',done,b)},'u']],g2:1,
 after:"<p>Qo'shish va ayirish — <b>bir-biriga teskari</b> amallar. Qismlarni qo'shsak — butun, butundan qismni ayirsak — ikkinchi qism. Shuning uchun bitta qo'shishdan ikkita ayirish «tug'iladi».</p>",
 q:{t:"36 + 47 = 83. Qaysi tenglik ham to'g'ri?",opts:["83 − 36 = 47","47 − 36 = 83","83 + 47 = 36","36 − 47 = 83"],ok:0,why:"Butundan bir qismni ayirsak — ikkinchisi: 83 − 36 = 47.",hint:"Butun qaysi son? Undan qismni ayiring.",full:"83 — butun, 36 va 47 — qismlar. 83 − 36 = 47 va 83 − 47 = 36 to'g'ri. Qolganlarida butun va qismlar aralashib ketgan."},
 tn:"«Son oilasi uchburchagi» — AQSh va Singapur darsliklarida keng ishlatiladi. Bolalar kartochkada uchburchak chizib, 4 ta tenglik yozsin."},
{h:"Qo'shishni ayirish bilan tekshiramiz",sum:"64 + 29 = 83? 83 − 29 = 54 ≠ 64 → xato. To'g'risi 93.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Vali yozdi: <b>64 + 29 = 83</b>. Bu to'g'rimi? Teskari amal bilan tekshiramiz:</p>",
 btns:[phaser(P2)],
 after:"<p><b>Qo'shishni tekshirish:</b> yig'indidan bir qo'shiluvchini ayiring — ikkinchi qo'shiluvchi chiqishi kerak. Chiqmasa — hisobda xato bor.</p>",
 q:{t:"Vali 64 + 29 = 83 deb yozdi va 83 − 29 ni hisobladi. U nimani topdi?",opts:["55 chiqdi, demak xato","54 chiqdi, demak to'g'ri","54 chiqdi, demak xato","64 chiqdi, demak to'g'ri"],ok:2,why:"83 − 29 = 54, bu 64 emas — xato.",hint:"83 − 29 ni hisoblang. Natija 64 ga tengmi?",full:"83 − 29 = 54. 54 ≠ 64, demak 64 + 29 = 83 xato (to'g'risi 93). «54, to'g'ri» — tekshiruv natijasini noto'g'ri baholash."},
 tn:"Bolalarni har yechimdan keyin tekshirishga o'rgating — bu xalqaro tadqiqotlarda yaxshi natija beradigan odat."},
{h:"Ayirishni qo'shish bilan tekshiramiz",sum:"63 − 28 = 45? 45 + 28 = 73 ≠ 63 → xato. To'g'risi 35.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>Ali yozdi: <b>63 − 28 = 45</b>. Tekshiramiz:</p>",
 btns:[phaser(P3)],
 after:"<p><b>Ayirishni tekshirish:</b> ayirmaga ayriluvchini qo'shing — kamayuvchi chiqishi kerak. Chunki qolgan + ayrilgan = butun.</p>",
 q:{t:"82 − 37 = 45 ayirmasini qaysi tenglik to'g'ri tekshiradi?",opts:["45 − 37 = 8","82 + 37 = 119","45 + 37 = 82","45 + 82 = 127"],ok:2,why:"Ayirma + ayriluvchi = kamayuvchi.",hint:"Qolgan qismga ayrilgan qismni qo'shsak, nima chiqishi kerak?",full:"Tekshiruv: 45 + 37 = 82 — kamayuvchi chiqdi, demak to'g'ri. Qolgan variantlar teskari amalni noto'g'ri tanlagan."},
 tn:"Qisqa qoida: «qo'shishni — ayirib, ayirishni — qo'shib tekshiramiz»."},
{h:"Chamalab tekshiramiz",sum:"47 + 38 ≈ 50 + 40 = 90. 75 juda uzoq → xato. To'g'risi 85.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ba'zan aniq hisoblamasdan ham xatoni sezish mumkin: sonlarni <b>yaxlitlab</b>, javob taxminan qancha bo'lishini topamiz.</p>",
 btns:[phaser(P4)],
 after:"<p><b>Chamalash</b> — javob «mantiqiy»mi, tez tekshirish. Agar javob chamalanganidan juda uzoq bo'lsa — aniq hisobda xato bor.</p>",
 q:{t:"Vali 47 + 38 = 75 deb hisobladi. Uning javobi to'g'ri javobdan qanday farq qiladi?",opts:["javob to'g'ri","1 ga kam","10 ga kam","10 ga ko'p"],ok:2,why:"To'g'ri javob 85, Vali 75 — 10 ga kam.",hint:"To'g'ri javobni toping va Valinikiga solishtiring.",full:"47 + 38 = 85. 85 − 75 = 10. Vali o'nlikka o'tishda eslab qolgan 1 ni unutgan — shuning uchun 10 ga kam."},
 tn:"Chamalash — 4-sinf darsligida alohida mavzu (64–65-darslar). Hozirdan odat qilish foydali."},
{h:"Tuzoq: qaysi biri xato?",sum:"Oxirgi raqamni tekshiring: 56 + 35 — 6 + 5 = 11 → javob 1 bilan tugaydi; 81 to'g'ri ko'rinadi, lekin o'nliklar 9 bo'lishi kerak → 91.",a:"m05",
 start:function(){b8Three(null);bqMsg('Sardor uchta misol yechdi. Xato yechilganini bosing')},fin:function(){b8Three(2)},
 html:"<p>Sardor uchta misol yechdi. Ulardan <b>bittasi xato</b>. Uni toping va bosing:</p>",
 act:function(c,done){S.d5=function(){S.d5=null;done()}},
 after:"<p>56 + 35: birliklar 6 + 5 = 11 — 1 yoziladi, 1 eslab qolinadi; o'nliklar 5 + 3 + 1 = 9. Javob <b>91</b>, Sardor 81 yozgan — <b>eslab qolgan 1 ni unutgan</b>. Bu — eng ko'p uchraydigan xato.</p>",
 q:{t:"Sardor: 47 + 18 = 65; 72 − 29 = 43; 56 + 35 = 81. Nechtasi to'g'ri?",opts:["3","2","1","0"],ok:1,why:"Birinchi ikkitasi to'g'ri, uchinchisi xato (91).",hint:"Har birini teskari amal bilan tekshiring.",full:"65 − 18 = 47 ✓; 43 + 29 = 72 ✓; 81 − 35 = 46 ≠ 56 ✗. Demak 2 tasi to'g'ri."},
 tn:"«Xatoni top» topshiriqlari bolani faol fikrlashga majbur qiladi — Yaponiya darslarida keng qo'llanadi."},
{h:"Tuzoq: noma'lum butun",sum:"Ayirma 26, ayriluvchi 38 → kamayuvchi = 26 + 38 = 64.",a:"m06",
 start:function(){bqBar('?',[{v:'38',w:38,lab:'ayriluvchi'},{v:'26',w:26,lab:'ayirma'}],{title:'□ − 38 = 26',tq:1});bqMsg('Kamayuvchi — butun, u noma‘lum')},fin:function(){bqBar('64',[{v:'38',w:38,lab:'ayriluvchi'},{v:'26',w:26,lab:'ayirma'}],{title:'64 − 38 = 26'});bqMsg('26 + 38 = <b>64</b>')},
 html:"<p>«Ayirma 26 ga, ayriluvchi 38 ga teng. Kamayuvchi qaysi son?» Bog'liqlikdan foydalanamiz:</p>",
 btns:[["➕ Qismlarni birlashtirish",function(c,done,b){b.disabled=true;bqBar('64',[{v:'38',w:38,lab:'ayriluvchi'},{v:'26',w:26,lab:'ayirma'}],{title:'64 − 38 = 26'});bqMsg('26 + 38 = <b>64</b>. Tekshiramiz: 64 − 38 = 26 ✓');done()}]],
 after:"<p>Kamayuvchi — butun, ayriluvchi va ayirma — uning qismlari. Butun = qismlar yig'indisi: <b>26 + 38 = 64</b>.</p>",
 q:{t:"Ayirma 26, ayriluvchi 38. Kamayuvchi qaysi son?",opts:["12","64","74","54"],ok:1,why:"26 + 38 = 64.",hint:"Kamayuvchi butunmi yoki qism?",full:"Kamayuvchi — butun: 26 + 38 = 64. «12» — ayirib yuborish xatosi (38 − 26)."},
 tn:"Komponent nomlarini (kamayuvchi, ayriluvchi, ayirma) chizmada yozib qo'ying."},
{h:"Tuzoq: tengliklar zanjiri",sum:"14 − 7 = 5 + 2 to'g'ri (7 = 7), 14 + 2 = 7 + 5 noto'g'ri (16 ≠ 12).",a:"m07",
 start:function(){bqExpr(['2, 5, 7, 14']);bqMsg('Bu sonlar bilan tengliklar tuzilgan. Qaysi biri noto‘g‘ri?')},fin:function(){bqExpr(['14 − 7 = 5 + 2  ✓','14 + 2 = 7 + 5  ✗','16 ≠ 12'])},
 html:"<p>«=» belgisi «natija» degani emas — u <b>ikki tomon teng</b> degani. Ikkala tomonni alohida hisoblab tekshiramiz.</p>",
 btns:[["14 − 7 = 5 + 2",function(c,done){bqExpr(['14 − 7 = 5 + 2','7 = 7  ✓']);bqMsg('Ikkala tomon 7 — to‘g‘ri');mvK(done,2)}],["14 + 2 = 7 + 5",function(c,done){bqExpr(['14 + 2 = 7 + 5','16 ≠ 12  ✗']);bqMsg('Chap 16, o‘ng 12 — <b>noto‘g‘ri</b>');mvK(done,2)}]],g2:1,
 after:"<p>Tenglikni tekshirish uchun <b>chap tomonni ham, o'ng tomonni ham</b> hisoblang. Teng bo'lsa — to'g'ri. Bolalar ko'pincha «=» dan keyin faqat javob turadi deb o'ylaydi.</p>",
 q:{t:"2, 5, 7, 14 sonlari bilan tuzilgan qaysi tenglik NOTO'G'RI?",opts:["14 − 7 = 5 + 2","7 + 5 = 14 − 2","14 − 5 = 2 + 7","14 + 2 = 7 + 5"],ok:3,why:"14 + 2 = 16, 7 + 5 = 12 — teng emas.",hint:"Har tenglikda chap va o'ng tomonni alohida hisoblang.",full:"7 = 7 ✓; 12 = 12 ✓; 9 = 9 ✓; 16 ≠ 12 ✗. Noto'g'risi — oxirgisi."},
 tn:"Tadqiqotlar ko'rsatadi: ko'p bolalar «=» ni «natijani yoz» deb tushunadi. «8 = 5 + 3» kabi teskari yozilgan tengliklarni ham ko'rsating."},
{h:"Bilasizmi? Qadimgi tekshiruv usuli",sum:"Qadimgi hind va arab hisobchilari natijani maxsus «to'qqiz» usuli bilan tekshirgan.",a:"m08",
 start:function(){bqExpr(['47 + 38 = 85','4 + 7 = 11 → 2','3 + 8 = 11 → 2','2 + 2 = 4;  8 + 5 = 13 → 4 ✓']);bqMsg('Raqamlar yig‘indisi bilan tekshirish')},fin:function(){bqExpr(['47 + 38 = 85','4 + 7 = 11 → 2','3 + 8 = 11 → 2','2 + 2 = 4;  8 + 5 = 13 → 4 ✓'])},
 html:"<p>📜 Qalam va qog'oz qimmat bo'lgan zamonlarda hind va arab hisobchilari natijani tez tekshirishning ayyor usulini qo'llashgan: har sonning <b>raqamlarini qo'shib</b>, bir xonali songa keltirishgan. Qo'shiluvchilardan chiqqan sonlar yig'indisi javobnikiga mos kelishi kerak.</p>",
 btns:[["🔍 Ko'rdim",function(c,done,b){b.disabled=true;done()}]],
 after:"<p>Bu usul O'rta asrlarda Sharqdan Yevropaga tarqalgan va ko'p asrlar davomida savdogarlar ishlatgan. Bugun biz oddiyroq yo'l — <b>teskari amal</b> bilan tekshiramiz, u har doim ishonchli.</p>",
 tn:"Bu qism faqat qiziqish uchun; testga kirmaydi."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){b8Tri(73,45,28,['45 + 28 = 73','28 + 45 = 73','73 − 28 = 45','73 − 45 = 28'])},fin:function(){b8Tri(73,45,28,['45 + 28 = 73','28 + 45 = 73','73 − 28 = 45','73 − 45 = 28'])},
 html:"<div class='memo'><ul><li>Qo'shish va ayirish — <b>teskari</b> amallar: 45 + 28 = 73 → 73 − 28 = 45, 73 − 45 = 28.</li><li><b>Qo'shishni</b> ayirish bilan tekshiramiz: yig'indi − qo'shiluvchi = boshqa qo'shiluvchi.</li><li><b>Ayirishni</b> qo'shish bilan: ayirma + ayriluvchi = kamayuvchi.</li><li><b>Chamalang</b>: 47 + 38 ≈ 50 + 40 = 90 — javob shunga yaqin bo'lishi kerak.</li><li>«=» — ikki tomon <b>teng</b> degani: ikkalasini hisoblang.</li><li>Eng ko'p xato — eslab qolingan <b>1</b> ni unutish.</li></ul></div>",
 tn:"Har mustaqil ishning oxirida «Tekshirdim ✓» belgisini qo'yish odatini kiriting."}
];
function b8Add(e,done,b){if(!S.eq)S.eq=[];if(S.eq.indexOf(e)<0)S.eq.push(e);b.disabled=true;b8Tri(73,45,28,S.eq);bqMsg(e);if(S.eq.length>=4){bqMsg('To‘rttala tenglik — bitta «oila»!');done()}}
function b8Three(bad){clear();var g=S.g,L=['47 + 18 = 65','72 − 29 = 43','56 + 35 = 81'];L.forEach(function(t,i){var y=30+i*44,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:70,y:y,width:220,height:36,rx:10,fill:bad===i?'#fdeaea':'#fff',stroke:bad===i?C.bad:'#c9d3dd','stroke-width':2},c);T(c,180,y+24,t,{'font-size':18,'font-weight':800,fill:bad===i?C.bad:'#1d2b3a'});
 c.addEventListener('click',function(){if(i===2){b8Three(2);bqMsg('To‘g‘ri! 81 − 35 = 46, 56 emas. To‘g‘ri javob: 91');if(S.d5)S.d5()}else{r.setAttribute('stroke',C.ok);bqMsg(i===0?'65 − 18 = 47 ✓ — bu to‘g‘ri':'43 + 29 = 72 ✓ — bu to‘g‘ri')}})})}
var PROBS=[
{t:"36 + 47 = 83. Qaysi tenglik ham to'g'ri?",o:["83 − 36 = 47","47 − 36 = 83","83 + 47 = 36","36 − 47 = 83"],k:0,s:"Butundan qismni ayiramiz."},
{t:"Ali 63 − 28 = 45 deb hisobladi. Natijani qo'shish bilan tekshiring. Qaysi xulosa to'g'ri?",o:["45 + 28 = 73, demak xato","45 + 28 = 63, demak to'g'ri","35 + 28 = 63, demak to'g'ri","45 − 28 = 17, demak to'g'ri"],k:0,s:"45 + 28 = 73 ≠ 63 — xato."},
{t:"82 − 37 = 45 ni qaysi tenglik tekshiradi?",o:["45 + 37 = 82","45 − 37 = 8","82 + 37 = 119","45 + 82 = 127"],k:0,s:"Ayirma + ayriluvchi = kamayuvchi."},
{t:"Ayirma 26, ayriluvchi 38. Kamayuvchi qaysi son?",o:["64","12","74","54"],k:0,s:"26 + 38 = 64."},
{t:"Vali 47 + 38 = 75 deb hisobladi. Javobi to'g'risidan qanday farq qiladi?",o:["10 ga kam","1 ga kam","to'g'ri","10 ga ko'p"],k:0,s:"To'g'risi 85, 85 − 75 = 10."},
{t:"Sardor: 47 + 18 = 65; 72 − 29 = 43; 56 + 35 = 81. Nechtasi to'g'ri?",o:["2","3","1","0"],k:0,s:"Uchinchisi xato (91)."},
{t:"Qaysi misol NOTO'G'RI yechilgan?",o:["71 − 25 = 56","56 − 28 = 28","44 − 36 = 8","82 − 44 = 38"],k:0,s:"56 + 25 = 81 ≠ 71; to'g'risi 46."},
{t:"2, 5, 7, 14 bilan tuzilgan qaysi tenglik NOTO'G'RI?",o:["14 + 2 = 7 + 5","14 − 7 = 5 + 2","7 + 5 = 14 − 2","14 − 5 = 2 + 7"],k:0,s:"16 ≠ 12."},
{t:"Yig'indi 90, bir qo'shiluvchi 54. Ikkinchi qo'shiluvchi qaysi?",o:["36","144","46","44"],k:0,s:"90 − 54 = 36."},
{t:"Kamayuvchi 70, ayirma 28. Ayriluvchi qaysi?",o:["42","98","52","38"],k:0,s:"70 − 28 = 42."},
{t:"Vali 64 + 29 = 83 deb yozdi. To'g'ri javob qaysi?",o:["93","83","35","103"],k:0,s:"64 + 29 = 93."},
{t:"58 + 26 ning qiymati taxminan qancha (chamalang)?",o:["80–90 atrofida","40 atrofida","120 dan ko'p","60 atrofida"],k:0,s:"58 ≈ 60, 26 ≈ 30: taxminan 90; aniq javob 84."},
{t:"Qaysi tenglik to'g'ri?",o:["9 = 4 + 5","9 + 4 = 5","4 = 9 + 5","5 + 4 = 8"],k:0,s:"4 + 5 = 9 — ikki tomon teng."},
{t:"35 + □ = 80. □ ni qaysi amal bilan topamiz?",o:["80 − 35","80 + 35","35 − 80","35 + 80"],k:0,s:"Yig'indidan ma'lum qo'shiluvchini ayiramiz."},
{t:"□ − 19 = 44. □ ni qaysi amal bilan topamiz?",o:["44 + 19","44 − 19","19 − 44","19 · 44"],k:0,s:"Kamayuvchi = ayirma + ayriluvchi."},
{t:"72, 27, 45 sonlari bilan qaysi tenglik to'g'ri?",o:["72 − 45 = 27","45 − 27 = 72","27 + 72 = 45","72 + 27 = 45"],k:0,s:"72 — butun, 27 va 45 — qismlar."},
{t:"Bekzod 91 − 47 = 54 deb yozdi. Xatosi nimada?",o:["44 bo'lishi kerak","to'g'ri yechgan","64 bo'lishi kerak","34 bo'lishi kerak"],k:0,s:"54 + 47 = 101 ≠ 91. To'g'risi 44."},
{t:"Yig'indi 100. Bir qo'shiluvchi ikkinchisidan 20 ta ko'p. Kattasi qaysi?",o:["60","40","80","50"],k:0,s:"(100 − 20) : 2 = 40 — kichigi, kattasi 40 + 20 = 60."},
{t:"Qaysi juftlik bir «oila»dan (bir xil uchta son)?",o:["30 + 25 = 55 va 55 − 30 = 25","30 + 25 = 55 va 55 − 25 = 20","30 + 25 = 55 va 30 − 25 = 55","30 + 25 = 55 va 55 + 30 = 25"],k:0,s:"Butun 55, qismlar 30 va 25."},
{t:"83 − 47 ni hisoblab, tekshirish uchun qaysi amal bajariladi?",o:["36 + 47","36 − 47","83 + 47","83 + 36"],k:0,s:"Ayirma 36 + ayriluvchi 47 = 83."}
];
function PRACT_STAGE(){b8Tri(73,45,28,['45 + 28 = 73','28 + 45 = 73','73 − 28 = 45','73 − 45 = 28']);bqMsg('Teskari amal bilan tekshiring')}
var PREP_DATA={teach:["Son oilasi: bitta qo'shishdan ikki ayirish.","Qo'shishni ayirish, ayirishni qo'shish bilan tekshirish.","Chamalash orqali tez tekshirish.","«=» — ikki tomon tengligi; xatoni topish."],
 mist:["Eslab qolingan 1 ni unutadi (56 + 35 = 81).","Tekshiruvda teskari amalni noto'g'ri tanlaydi.","«=» dan keyin faqat javob bo'ladi deb o'ylaydi.","Kamayuvchini ayirib topadi."],
 need:["Uchburchak kartochkalar (son oilasi)."],
 board:["Uchburchak: <span class='w2'>73 / 45, 28</span>.","<span class='w2'>64 + 29 = 83? → 83 − 29 = 54 ✗</span>.","<span class='w2'>63 − 28 = 45? → 45 + 28 = 73 ✗</span>.","Chamalash: <span class='w2'>47 + 38 ≈ 50 + 40</span>.","<span class='w2'>14 − 7 = 5 + 2</span> — ikki tomon 7."]};
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=40,x1=230,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}
