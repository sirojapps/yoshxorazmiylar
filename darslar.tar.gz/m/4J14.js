var CODE='4J14',TITLE="4-sinf · Bo'linish belgilari va sonlar xossalari";
// xonalar bloklari: 471 = 4 yuzlik + 7 o'nlik + 1 birlik; yuzlik = 99 + 1, o'nlik = 9 + 1
function q14Blocks(d,ph){clear();var g=S.g;var lab=['yuzlik','o‘nlik','birlik'],x0=[20,140,262];
 d.forEach(function(n,i){T(g,x0[i]+40,22,n+' ta '+lab[i],{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  for(var k=0;k<n;k++){var x=x0[i]+(k%4)*22,y=34+Math.floor(k/4)*30;
   if(i<2){E('rect',{x:x,y:y,width:18,height:24,rx:3,fill:i?'#5aa9e6':'#f0a040'},g);if(ph)E('rect',{x:x+11,y:y+16,width:7,height:8,rx:2,fill:C.bad},g)}
   else E('rect',{x:x,y:y+8,width:16,height:16,rx:3,fill:C.bad},g)}});
 if(ph){T(g,180,152,'qizil «qoldiq» bo‘laklar: 4 + 7 + 1 = 12 → 3 ga bo‘linadi',{'font-size':12,'font-weight':800,fill:C.bad})}}
var P1=[function(){q14Blocks([4,7,1]);j2Msg("471 = 4 yuzlik + 7 o'nlik + 1 birlik. Nega 3 ga bo'linishni raqamlar yig'indisi aytadi?")},
 function(){q14Blocks([4,7,1],1);j2Msg("Har yuzlik = 99 + <b>1</b>, har o'nlik = 9 + <b>1</b>. 99 va 9 — 3 ga (va 9 ga) bo'linadi. Qolgan qizil bo'laklar soni — raqamlar yig'indisi!")},
 function(){j2Lines([["471 = 4 · 99 + 7 · 9 + (4 + 7 + 1)",C.blue,16],["3 ga bo'linadi  +  12",null,16],["12 : 3 = 4 → 471 : 3 = 157 ✓",C.ok,18]]);j2Msg("Shuning uchun: raqamlar yig'indisi 3 ga (9 ga) bo'linsa — son ham bo'linadi.")}];
var P3=[function(){j2Lines([["6 = 2 · 3",C.blue,26]]);j2Msg("6 ga bo'linish — bir vaqtda <b>2 ga</b> va <b>3 ga</b> bo'linish.")},
 function(){j2Lines([["4 512",C.blue,28],["juft ✓   4 + 5 + 1 + 2 = 12 ✓",null,16],["→ 6 ga bo'linadi",C.ok,18]]);j2Msg("4 512: oxiri juft (2 ga ✓), raqamlar yig'indisi 12 (3 ga ✓) → 6 ga bo'linadi: 4 512 : 6 = 752.")}];
var P6=[function(){j2Lines([["36 ning bo'luvchilari",C.blue,22]]);j2Msg("Bo'luvchilarni <b>juft-juft</b> qilib topamiz: ko'paytmasi 36 bo'lgan juftlar.")},
 function(){j2Lines([["1 · 36    2 · 18    3 · 12",null,18],["4 · 9    6 · 6",null,18]]);j2Msg("1·36, 2·18, 3·12, 4·9, 6·6. 5 ga bo'linmaydi, 6 dan keyin juftlar takrorlanadi.")},
 function(){j2Lines([["1, 2, 3, 4, 6, 9, 12, 18, 36",C.blue,18],["9 ta — toq son! (6 · 6)",C.bad,18]]);j2Msg("Bo'luvchilar 9 ta. Odatda juft bo'ladi, lekin 6 · 6 da 6 <b>bir marta</b> sanaladi — kvadrat sonlarda bo'luvchilar soni toq.")}];
var STEPS=[
{h:"Nega raqamlar yig'indisi?",sum:"Yuzlik = 99 + 1, o'nlik = 9 + 1: qoldiq bo'laklar soni = raqamlar yig'indisi.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>3 va 9 ga bo'linish belgisini bilasiz. Endi <b>nega</b> u ishlashini ko'ramiz — shunda hech qachon unutmaysiz.</p>",
 btns:[phaser(P1)],
 after:"<p>10 = 9 + 1, 100 = 99 + 1, 1000 = 999 + 1. «Ortiqcha birlar» yig'indisi raqamlar yig'indisiga teng. Shu sababli <b>3 ga</b> va <b>9 ga</b> bo'linish raqamlar yig'indisiga qarab aniqlanadi.</p>",
 q:{t:"5□2 soni 9 ga bo'linishi uchun □ o'rnida qaysi raqam turishi kerak?",opts:["7","2","0","4"],ok:1,why:"5 + 2 + 2 = 9.",hint:"5 + □ + 2 qaysi songa teng bo'lsa, 9 ga bo'linadi?",full:"Raqamlar yig'indisi 9 ga bo'linishi kerak: 5 + □ + 2 = 7 + □. 9 bo'lishi uchun □ = 2; 18 bo'lishi uchun □ = 11 kerak — bunday raqam yo'q. 7 → 14, 0 → 7, 4 → 11 — 9 ga bo'linmaydi."},
 tn:"O'nlik bloklarni (cho'plar) qo'lda ko'rsating: har 10 likdan bittasini ajratsangiz, qolgani 9 — 3 ga bo'linadi."},
{h:"4 va 25 ga: oxirgi ikki raqam",sum:"100 son 4 ga va 25 ga bo'linadi, shuning uchun faqat oxirgi ikki raqamga qaraymiz.",a:"m02",
 start:function(){j2Lines([["100 = 4 · 25",C.blue,26],["yuzliklar har doim 4 ga va 25 ga bo'linadi",null,14]]);j2Msg("Qaysi son 4 ga bo'linadi? Tanlang.")},
 fin:function(){j2Lines([["3 7|16",C.blue,30],["16 : 4 = 4 ✓",C.ok,20]]);j2Msg("Faqat oxirgi ikki raqam: 16 — 4 ga bo'linadi.")},
 html:"<p>100 = 4 · 25. Demak, har qanday sonning yuzliklar qismi 4 ga ham, 25 ga ham bo'linadi — faqat <b>oxirgi ikki raqam</b> qoladi. Qaysi son 4 ga bo'linadi?</p>",
 btns:j2Pick(["2 342","3 716","5 518","1 126"],1,function(){j2Lines([["3 7|16",C.blue,30],["16 : 4 = 4 ✓",C.ok,20]]);j2Msg("To'g'ri: 16 — 4 ga bo'linadi.")},function(i){j2Msg(["42","","18","26"][i]+" 4 ga bo'linmaydi — oxirgi ikki raqamga qarang.")}),
 g2:1,
 after:"<p>4 ga: oxirgi ikki raqam 4 ga bo'linsa. 25 ga: oxiri 00, 25, 50 yoki 75. Faqat oxirgi raqamga qarash (juft) — bu 2 ga bo'linish, 4 ga emas!</p>",
 q:{t:"73□6 soni 4 ga bo'linadi. □ o'rniga nechta har xil raqam qo'yish mumkin?",opts:["4","5","2","10"],ok:1,why:"□6 4 ga bo'linsin: 16, 36, 56, 76, 96 → □ = 1, 3, 5, 7, 9.",hint:"□6 ikki xonali son 4 ga bo'linishi kerak. 06, 16, 26, … ni tekshiring.",full:"□6: 06 (6 ✗), 16 ✓, 26 ✗, 36 ✓, 46 ✗, 56 ✓, 66 ✗, 76 ✓, 86 ✗, 96 ✓. Mos raqamlar: 1, 3, 5, 7, 9 — 5 ta."},
 tn:"Bolalarga 4 ga karrali sonlar (04, 08, 12, …, 96) jadvalini yozdiring — qonuniyatni o'zlari ko'rsin."},
{h:"6 ga bo'linish = 2 ga va 3 ga",sum:"6 = 2 · 3: juft va raqamlar yig'indisi 3 ga bo'linsa — 6 ga bo'linadi.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>Ko'p bo'linish belgilari ikki oddiy belgidan «yig'iladi».</p>",
 btns:[phaser(P3)],
 after:"<p>Xuddi shunday: 15 ga = 3 ga va 5 ga; 18 ga = 2 ga va 9 ga; 36 ga = 4 ga va 9 ga.</p>",
 q:{t:"Qaysi son 6 ga bo'linadi?",opts:["3 213","2 410","4 512","1 006"],ok:2,why:"4 512 — juft va 4 + 5 + 1 + 2 = 12.",hint:"Avval juftlarini ajrating, keyin raqamlar yig'indisini tekshiring.",full:"3 213 — toq ✗. 2 410: 2 + 4 + 1 + 0 = 7 ✗. 1 006: 1 + 6 = 7 ✗. 4 512: juft, yig'indi 12 ✓ → 6 ga bo'linadi."},
 tn:"Doskada ikki ustun: «2 ga?» va «3 ga?». Ikkalasida ✓ bo'lgan sonlar — 6 ga bo'linadi."},
{h:"Tuzoq: 12 ga bo'linish",sum:"12 ga = 3 ga va 4 ga (2 va 6 emas!): 18 — 2 ga ham, 6 ga ham bo'linadi, 12 ga emas.",a:"m04",
 start:function(){j2Lines([["18 : 2 ✓     18 : 6 ✓",null,20],["18 : 12 ?",C.bad,24]]);j2Msg("«2 ga va 6 ga bo'linsa — 12 ga bo'linadi»mi? Tekshiring!")},
 fin:function(){j2Lines([["12 = 3 · 4",C.ok,26],["3 va 4 — umumiy bo'luvchisi yo'q",null,15]]);j2Msg("12 ga bo'linish: <b>3 ga va 4 ga</b>.")},
 html:"<p>Ko'pchilik: «12 = 2 · 6, demak 2 ga va 6 ga bo'linsa — 12 ga bo'linadi». 18 ni tekshiring! Qaysi qoida to'g'ri?</p>",
 btns:j2Pick(["2 ga va 6 ga","3 ga va 4 ga","2 ga va 3 ga"],1,function(){j2Lines([["12 = 3 · 4",C.ok,26],["3 va 4 — umumiy bo'luvchisi yo'q",null,15]]);j2Msg("To'g'ri! 3 va 4 ning umumiy bo'luvchisi yo'q (1 dan boshqa).")},function(i){j2Msg(i===0?"18 — 2 ga ham, 6 ga ham bo'linadi, lekin 12 ga emas!":"6 — 2 ga ham, 3 ga ham bo'linadi, lekin 12 ga emas!")}),
 after:"<p>Qoida: ikki belgini birlashtirsak, ular <b>umumiy bo'luvchisiz</b> (1 dan tashqari) bo'lishi kerak. 2 va 6 ning umumiy bo'luvchisi 2 — shuning uchun ishlamaydi.</p>",
 q:{t:"36 ga bo'linishni qanday tekshiramiz?",opts:["6 ga va 6 ga","3 ga va 12 ga","4 ga va 9 ga","2 ga va 18 ga"],ok:2,why:"36 = 4 · 9, 4 va 9 ning umumiy bo'luvchisi yo'q.",hint:"Ko'paytuvchilar umumiy bo'luvchisiz bo'lishi kerak.",full:"36 = 4 · 9 va 4, 9 umumiy bo'luvchisiz → to'g'ri. 3 va 12: 24 ikkalasiga bo'linadi, 36 ga emas. 2 va 18: 18 ning o'zi misol — 36 ga bo'linmaydi."},
 tn:"Bolalar o'zi qarshi misol topsin: «2 ga va 6 ga bo'linadi, lekin 12 ga emas» — 6, 18, 30, 42…"},
{h:"Juft va toq: yig'indini oldindan bilamiz",sum:"Toq sonlar soni toq bo'lsa — yig'indi toq. 1+2+…+10 = 55 — toq.",a:"m05",
 start:function(){j2Lines([["juft + juft = juft",null,16],["toq + toq = juft",null,16],["juft + toq = toq",null,16],["toq · toq = toq",C.blue,16]]);j2Msg("Hisoblamasdan aniqlang: 1 + 2 + 3 + … + 10 juftmi yoki toq?")},
 fin:function(){j2Lines([["1, 3, 5, 7, 9 — 5 ta toq",null,17],["5 ta toq → yig'indi toq",C.ok,19],["(55)",null,16]]);j2Msg("5 ta toq qo'shiluvchi → yig'indi toq: 55.")},
 html:"<p>Yig'indining juft-toqligini <b>hisoblamasdan</b> aniqlash mumkin: faqat toq qo'shiluvchilarni sanang. 1 + 2 + … + 10 qanday?</p>",
 btns:j2Pick(["Juft","Toq"],1,function(){j2Lines([["1, 3, 5, 7, 9 — 5 ta toq",null,17],["5 ta toq → yig'indi toq",C.ok,19],["(55)",null,16]]);j2Msg("To'g'ri: 5 ta toq qo'shiluvchi → toq.")},function(){j2Msg("Toq qo'shiluvchilarni sanang: 1, 3, 5, 7, 9.")}),
 after:"<p>Ikki toq — juft beradi. Toqlar <b>juft</b> sonda bo'lsa — yig'indi juft, <b>toq</b> sonda bo'lsa — toq. Juft qo'shiluvchilar natijani o'zgartirmaydi.</p>",
 q:{t:"13 + 25 + 37 + 49 + 55 yig'indisi qanday?",opts:["Juft","Toq","5 ga bo'linadi","3 ga bo'linadi"],ok:1,why:"5 ta toq son → toq. (179)",hint:"Nechta toq qo'shiluvchi bor?",full:"Beshala son toq — 5 ta toq qo'shiluvchi, demak yig'indi toq: 179. 179 oxiri 9 — 5 ga bo'linmaydi; 1 + 7 + 9 = 17 — 3 ga ham bo'linmaydi."},
 tn:"«Juft/toq» o'yini: bolalar kartochkadagi sonlarning yig'indisini hisoblamasdan juft/toq deb aytsin."},
{h:"Bo'luvchilar juft-juft",sum:"36 = 1·36 = 2·18 = 3·12 = 4·9 = 6·6 → 9 bo'luvchi (kvadrat son — toq).",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Sonning hamma bo'luvchilarini qanday tez va hech birini tashlab ketmasdan topamiz?</p>",
 btns:[phaser(P6)],
 after:"<p>Bo'luvchilar juft bo'lib keladi: biri kichik, biri katta. Kichigi ko'paytma ildizigacha (6) qidiriladi. Juftdagi ikki son teng bo'lsa (6 · 6), bo'luvchilar soni <b>toq</b>.</p>",
 q:{t:"24 ning nechta bo'luvchisi bor?",opts:["6","7","8","12"],ok:2,why:"1·24, 2·12, 3·8, 4·6 → 8 ta.",hint:"Ko'paytmasi 24 bo'lgan juftlarni yozing.",full:"1 · 24, 2 · 12, 3 · 8, 4 · 6 — 4 ta juft, 8 ta bo'luvchi: 1, 2, 3, 4, 6, 8, 12, 24. 24 kvadrat son emas, shuning uchun soni juft."},
 tn:"To'g'ri to'rtburchaklar bilan ko'rsating: 24 ta katakdan nechta har xil to'g'ri to'rtburchak yasash mumkin? (1×24, 2×12, 3×8, 4×6)."},
{h:"Bilasizmi? To'qqizlar bilan tekshirish",sum:"Hisob natijasini raqamlar yig'indisi bilan tekshirish usuli qadimdan ma'lum.",a:"m07",
 start:function(){j2Lines([["47 · 36 = 1 692 ?",C.blue,20],["4+7 → 2,  3+6 → 0",null,15],["1+6+9+2 = 18 → 0  ✓",C.ok,17]]);j2Msg("To'qqizlar bilan tekshirish")},fin:function(){j2Lines([["47 · 36 = 1 692 ?",C.blue,20],["4+7 → 2,  3+6 → 0",null,15],["1+6+9+2 = 18 → 0  ✓",C.ok,17]]);j2Msg("To'qqizlar bilan tekshirish")},
 html:"<p>🧮 O'rta asrlarda hisobchilar uzun hisoblarni «to'qqizlar bilan» tekshirgan. Har sonni raqamlari yig'indisining 9 ga bo'lgandagi qoldig'i bilan almashtirib, amalni shu kichik sonlarda takrorlashgan.</p><p>47 → 11 → 2, 36 → 9 → 0. 2 · 0 = 0. Javob 1 692: 1 + 6 + 9 + 2 = 18 → 0. Mos keldi! (Mos kelmasa — albatta xato bor.)</p>",
 btns:[["🧮 Sinab ko'raman",function(c,done){done()}]],
 tn:"Bolalar o'z ko'paytirish misollarini shu usulda tekshirsin. Eslatma: mos kelishi to'g'rilikni 100% kafolatlamaydi (raqamlar o'rni almashgan bo'lsa ham mos keladi)."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){j2Lines([["10 = 9 + 1",C.blue,26]]);j2Msg("Asosiy qoidalar")},fin:function(){j2Lines([["10 = 9 + 1",C.blue,26]]);j2Msg("Asosiy qoidalar")},
 html:"<div class='memo'><ul><li><b>3 ga, 9 ga</b>: raqamlar yig'indisi bo'linsa (chunki 10 = 9 + 1).</li><li><b>4 ga</b>: oxirgi ikki raqam 4 ga bo'linsa. <b>25 ga</b>: oxiri 00, 25, 50, 75.</li><li><b>6 ga</b> = 2 ga + 3 ga; <b>12 ga</b> = 3 ga + 4 ga; <b>36 ga</b> = 4 ga + 9 ga.</li><li>Belgilarni birlashtirganda ular umumiy bo'luvchisiz bo'lsin (2 va 6 — yo'q!).</li><li>Toq qo'shiluvchilar soni toq → yig'indi toq.</li><li>Bo'luvchilarni juft-juft toping; kvadrat sonda soni toq.</li></ul></div>",
 tn:"Uyga: «Yilingiz (masalan 2026) qaysi sonlarga bo'linadi?» — belgilar bilan tekshirish."}
];
var PROBS=[
{t:"Qaysi son 3 ga bo'linadi?",o:["5 271","4 271","2 470","1 001"],k:0,s:"5 + 2 + 7 + 1 = 15."},
{t:"Qaysi son 9 ga bo'linadi?",o:["7 362","7 361","5 552","8 119"],k:0,s:"7 + 3 + 6 + 2 = 18."},
{t:"5□2 soni 9 ga bo'linadi. □ o'rnida qaysi raqam?",o:["2","7","0","4"],k:0,s:"5 + 2 + 2 = 9."},
{t:"73□6 soni 4 ga bo'linadi. □ o'rniga nechta har xil raqam qo'yish mumkin?",o:["5","4","10","2"],k:0,s:"16, 36, 56, 76, 96 → 5 ta."},
{t:"Qaysi son 6 ga bo'linadi?",o:["4 512","3 213","2 410","1 006"],k:0,s:"Juft va 4 + 5 + 1 + 2 = 12."},
{t:"Qaysi son 4 ga bo'linadi?",o:["3 716","2 342","5 518","1 126"],k:0,s:"16 : 4 = 4."},
{t:"Qaysi son 25 ga bo'linadi?",o:["4 175","4 155","3 105","2 520"],k:0,s:"Oxiri 75."},
{t:"36 ga bo'linishni qanday tekshiramiz?",o:["4 ga va 9 ga","6 ga va 6 ga","3 ga va 12 ga","2 ga va 18 ga"],k:0,s:"36 = 4 · 9, umumiy bo'luvchisiz."},
{t:"18 soni 2 ga ham, 6 ga ham bo'linadi. 12 ga-chi?",o:["Bo'linmaydi: 18 = 12 + 6","Bo'linadi, chunki 2 · 6 = 12","Bo'linadi, chunki juft","Bo'linadi, chunki 1 + 8 = 9"],k:0,s:"12 ga bo'linish 3 ga va 4 ga bo'linishni talab qiladi; 18 4 ga bo'linmaydi."},
{t:"13 + 25 + 37 + 49 + 55 yig'indisi qanday?",o:["Toq","Juft","5 ga bo'linadi","3 ga bo'linadi"],k:0,s:"5 ta toq → toq (179)."},
{t:"1 + 2 + 3 + … + 10 yig'indisi qanday?",o:["Toq","Juft","10 ga bo'linadi","3 ga bo'linadi"],k:0,s:"5 ta toq qo'shiluvchi → toq (55)."},
{t:"24 ning nechta bo'luvchisi bor?",o:["8","6","7","12"],k:0,s:"1, 2, 3, 4, 6, 8, 12, 24."},
{t:"36 ning nechta bo'luvchisi bor?",o:["9","8","10","6"],k:0,s:"1, 2, 3, 4, 6, 9, 12, 18, 36."},
{t:"Qaysi sonning bo'luvchilari soni toq?",o:["49","50","48","45"],k:0,s:"49 = 7 · 7: 1, 7, 49."},
{t:"2, 3 va 5 ga bo'linadigan eng kichik uch xonali son?",o:["120","100","105","130"],k:0,s:"30 ga karrali: 120."},
{t:"4 dan boshlanuvchi, 45 ga bo'linadigan eng katta uch xonali son?",o:["495","490","450","499"],k:0,s:"Oxiri 0 yoki 5, raqamlar yig'indisi 9 ga: 4 + 9 + 5 = 18."},
{t:"Raqamlari har xil, 5 ga ham, 9 ga ham bo'linadigan eng kichik uch xonali son?",o:["135","180","105","145"],k:0,s:"45 · 3 = 135."},
{t:"47 ni 6 ga bo'lganda qoldiq nechaga teng?",o:["5","1","7","4"],k:0,s:"6 · 7 = 42, 47 − 42 = 5."},
{t:"Bir son 6 ga bo'lganda qoldiq 4. Shu sonni 3 ga bo'lganda qoldiq?",o:["1","4","2","0"],k:0,s:"Son = 6 · k + 4 = 3 · (2k + 1) + 1."},
{t:"2□4 soni 12 ga bo'linadi. □ ning eng katta qiymati?",o:["6","0","3","8"],k:0,s:"4 ga: □ juft; 3 ga: 6 + □ — □ = 0 yoki 6. Eng kattasi 6."}
];
function PRACT_STAGE(){j2Lines([["3 · 9 → yig'indi",C.blue,20],["4 · 25 → oxirgi 2 raqam",null,16]])}
var PREP_DATA={teach:["3 va 9 ga belgining sababi: 10 = 9 + 1.","4 va 25 ga: oxirgi ikki raqam.","Murakkab belgilar: 6, 12, 15, 36.","Juft-toqlik va bo'luvchilar soni."],
 mist:["4 ga bo'linishni faqat oxirgi raqamga qarab aytadi.","12 ga = 2 ga + 6 ga deb o'ylaydi.","Yig'indining juft-toqligini barcha sonni qo'shib topadi.","Kvadrat sonda bir xil bo'luvchini ikki marta sanaydi."],
 need:["O'nlik bloklar yoki cho'p bog'lamlari.","Sonlar kartochkalari."],
 board:["<span class='w2'>471 = 4 · 99 + 7 · 9 + 12</span>.","<span class='w2'>3 7|16 → 16 : 4</span>.","<span class='w2'>6 = 2 · 3, 12 = 3 · 4</span>.","<span class='w2'>36: 1·36, 2·18, 3·12, 4·9, 6·6</span>."]};

// ---------- 3J umumiy sahna yordamchilari (w_3j2) ----------
function j2Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// markazda katta yozuv qatorlari: [[matn, rang?, o'lcham?], ...]
function j2Lines(lines,o){o=o||{};clear(o.bg);var g=S.g,y0=o.y0||(87-(lines.length-1)*17);lines.forEach(function(l,i){var a=typeof l==='string'?[l]:l;T(g,180,y0+i*(o.dy||34)+8,a[0],{'font-size':a[2]||22,'font-weight':800,fill:a[1]||'#1d2b3a','font-family':o.mono?'ui-monospace,Menlo,monospace':'inherit'})})}
// variant tugmalari: faqat to'g'risi done() chaqiradi
function j2Pick(list,ok,good,bad){return list.map(function(t,i){return [t,function(c,done,b){if(i===ok){b.style.background='#1e8e5a';[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});if(good)good();done()}else{b.style.background='#d94b4b';setTimeout(function(){b.style.background=''},1200);if(bad)bad(i)}}]})}
// qutilar qatori: items[i] — massiv (emoji/son), names — tepasidagi nomlar
function j2Boxes(items,o){o=o||{};clear();var g=S.g,n=items.length,w=Math.min(96,(340-(n-1)*8)/n),x0=180-(n*w+(n-1)*8)/2;S.bx=[];
 items.forEach(function(it,i){var x=x0+i*(w+8),hl=o.hl&&o.hl.indexOf(i)>=0;S.bx.push(x);E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:hl?'#fde6e6':'#fff7ea',stroke:hl?C.bad:'#d9b98a','stroke-width':hl?3:1.6},g);
  if(o.names)T(g,x+w/2,22,o.names[i],{'font-size':11,'font-weight':800,fill:'#8a5a24'});
  it.forEach(function(e,k){var per=Math.max(1,Math.floor((w-8)/26)),cx=x+16+(k%per)*26,cy=56+Math.floor(k/per)*28;T(g,cx,cy+7,e,{'font-size':o.fs||20})});
  if(o.tap){var r=E('rect',{x:x,y:30,width:w,height:112,rx:10,fill:'transparent',style:'cursor:pointer'},g);(function(i){r.addEventListener('click',function(){o.tap(i)})})(i)}})}
// katakli to'r (labirint, xarita, simmetriya uchun)
function j2Grid(cols,rows,cell,x0,y0,fill){var g=S.g,cs=[];for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){var e=E('rect',{x:x0+c*cell,y:y0+r*cell,width:cell-1,height:cell-1,rx:2,fill:(fill&&fill(c,r))||'#fff',stroke:'#dde5ee'},g);e._c=c;e._r=r;cs.push(e)}return cs}
// ---------- 4J qo'shimcha chizma yordamchilari (w_4j2) ----------
// pallali tarozi: l, r — pallalardagi yozuvlar massivi; tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function k4Bal(l,r,tilt,cap){clear();var g=S.g,d=(tilt||0)*12;E('rect',{x:172,y:60,width:16,height:96,rx:3,fill:'#8a6a4a'},g);E('rect',{x:130,y:152,width:100,height:10,rx:4,fill:'#6b4f35'},g);
 E('line',{x1:70,y1:60+d,x2:290,y2:60-d,stroke:'#5a4630','stroke-width':6,'stroke-linecap':'round'},g);E('circle',{cx:180,cy:60,r:7,fill:'#d9a441'},g);
 [[70,60+d,l],[290,60-d,r]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0]-40,y2:p[1]+44,stroke:'#999'},g);E('line',{x1:p[0],y1:p[1],x2:p[0]+40,y2:p[1]+44,stroke:'#999'},g);
  E('path',{d:'M'+(p[0]-50)+' '+(p[1]+44)+' h100 q-8 22 -50 22 q-42 0 -50 -22z',fill:'#f3e3c4',stroke:'#c9a46a'},g);
  (p[2]||[]).forEach(function(t,i,a){var w=100/a.length;T(g,p[0]-50+w*(i+.5),p[1]+40,t,{'font-size':a.length>3?11:13,'font-weight':800,fill:'#3a2a1a'})})});
 if(cap)T(g,180,22,cap,{'font-size':13,'font-weight':800,fill:C.blue})}
// idishlar: caps — sig'imlar, v — hozirgi suv
function k4Jugs(caps,v,cap){clear();var g=S.g,n=caps.length,mx=Math.max.apply(null,caps),x0=180-(n*80+(n-1)*24)/2;
 caps.forEach(function(c,i){var x=x0+i*104,h=110*c/mx,y=150-h,wh=110*v[i]/mx;E('rect',{x:x,y:y,width:80,height:h,rx:6,fill:'#f4f8fb',stroke:'#7a8a9a','stroke-width':2},g);
  if(v[i]>0)E('rect',{x:x+2,y:150-wh,width:76,height:wh-2,rx:4,fill:'#7ec3ef'},g);T(g,x+40,y-6,c+' L idish',{'font-size':11,'font-weight':800,fill:'#5a6a7a'});
  T(g,x+40,150-Math.max(wh,22)/2+6,v[i]+' L',{'font-size':16,'font-weight':900,fill:v[i]?'#0b4f7a':'#9aa'})});if(cap)T(g,180,168,cap,{'font-size':11,'font-weight':700,fill:'#556'})}
// glif (harf/son) transform bilan: tr — 'scale(-1,1)' kabi
function k4Glyph(x,y,ch,tr,col,fs){var g=E('g',{transform:'translate('+x+','+y+') '+(tr||'')},S.g);var t=E('text',{x:0,y:fs?fs*.35:14,'text-anchor':'middle','font-size':fs||40,'font-weight':900,fill:col||C.blue,'font-family':'Arial,sans-serif'},g);t.textContent=ch;return g}
// tugunli xarita: nodes {A:[x,y]}, edges [[a,b,km]], hl — ajratilgan qirralar indekslari
function k4Graph(nodes,edges,hl){clear();var g=S.g;edges.forEach(function(e,i){var a=nodes[e[0]],b=nodes[e[1]],on=hl&&hl.indexOf(i)>=0;E('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:on?C.ok:'#b8c4d0','stroke-width':on?5:3},g);
  var mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;E('rect',{x:mx-13,y:my-10,width:26,height:18,rx:5,fill:'#fff',stroke:on?C.ok:'#c9d3dd'},g);T(g,mx,my+4,e[2],{'font-size':11,'font-weight':800,fill:on?C.ok:'#4a5a6a'})});
 for(var k in nodes){E('circle',{cx:nodes[k][0],cy:nodes[k][1],r:13,fill:'#1f5f9e'},g);T(g,nodes[k][0],nodes[k][1]+5,k,{'font-size':13,'font-weight':900,fill:'#fff'})}}
