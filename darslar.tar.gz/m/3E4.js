var CODE='3E4',TITLE='3-sinf · Birga keltirish va ulushlarga bo‘lish';
// ---------- chizma model (Singapur «bar model») yordamchilari ----------
var BMC={a:'#f0a040',b:'#5aa9e6',c:'#f08aa8',g:'#7cc98f',x:'#e9e2d6',q:'#ffffff',y:'#ffd24d'};
function bmDraw(f){clear(f.bg);var g=S.g,bars=f.bars||[],x0=f.x0||78,W=f.w||262,max=0;
 bars.forEach(function(b){var s=b.off||0;b.segs.forEach(function(z){s+=z.w});if(s>max)max=s});var k=W/(f.max||max||1);
 if(f.t){var tl=bmWrap(f.t,52);tl.forEach(function(l,i){T(g,180,tl.length>1?12+i*13:17,l,{'font-size':tl.length>1?11:12,'font-weight':800,fill:C.blue})})}
 bars.forEach(function(b,i){var y=b.y!=null?b.y:(f.t?40:30)+i*(f.gap||52),x=x0+(b.off||0)*k;b._x=[];b._y=y;var h=b.h||26;
  if(b.lab)T(g,x0-6,y+h/2+5,b.lab,{'font-size':12,'font-weight':700,'text-anchor':'end',fill:'#33475b'});
  b.segs.forEach(function(z){var w=z.w*k,col=BMC[z.c||'a']||z.c;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:col,stroke:z.c==='q'?C.bad:C.line,'stroke-width':1.5,'stroke-dasharray':z.c==='q'?'5 4':''},g);
   if(z.txt!=null&&z.txt!=='')T(g,x+w/2,y+h/2+5,String(z.txt),{'font-size':z.fs||13,'font-weight':800,fill:z.c==='q'?C.bad:'#2b2b2b'});b._x.push([x,x+w]);x+=w})});
 (f.br||[]).forEach(function(r){var b=bars[r.b],h=b.h||26,a=b._x[r.from!=null?r.from:0][0],e=b._x[r.to!=null?r.to:b._x.length-1][1];Br(a,e,r.up?b._y-3:b._y+h+3,r.lab,r.up,r.col)});
 (f.txt||[]).forEach(function(t){T(g,t[0],t[1],t[2],Object.assign({'font-size':12,'font-weight':700},t[3]||{}))});
 if(f.lines)bmLines(f.lines,f.hl,f.t?26:0);
 if(f.calc)calc(f.calc,f.note);else calc([f.note||''])}
// sahnada matn qatorlari (masala shartlari) — hl: ajratilgan qator(lar) {i:rang}
function bmLines(L,hl,top){var g=S.g;hl=hl||{};top=top||0;var H=156-top;L.forEach(function(s,i){var y=10+top+i*(H/L.length),h=Math.min(34,H/L.length-6),col=hl[i];
 E('rect',{x:10,y:y,width:340,height:h,rx:8,fill:col?(col==='ok'?'#e6f6ee':col==='bad'?'#fdeaea':col==='q'?'#fff4d6':'#eef3f8'):'#fff',stroke:col==='ok'?C.ok:col==='bad'?C.bad:col==='q'?'#e0b84a':'#dde5ee','stroke-width':col?2:1},g);
 T(g,20,y+h/2+5,s,{'font-size':s.length>52?10:12,'font-weight':600,'text-anchor':'start',fill:col==='bad'?C.bad:'#1d2b3a','text-decoration':col==='bad'?'line-through':''})})}
function bmWrap(t,n){if(t.length<=n)return [t];var m=Math.floor(t.length/2),a=t.lastIndexOf(' ',m),b=t.indexOf(' ',m),k=(a<0||(b>=0&&b-m<m-a))?b:a;if(k<0)return [t];return [t.slice(0,k),t.slice(k+1)]}
function bmP(F){return F.map(function(f){return function(){bmDraw(f)}})}
function bmStep(o){var F=o.frames,P=bmP(F);o._P=P;o.start=o.start||function(){if(P.length>1)startPh(P);else P[0]()};o.fin=o.fin||function(){S.ph=P.length-1;P[P.length-1]()};
 if(P.length>1&&!o.btns&&!o.act)o.btns=[phaser(P,o.btn)];if(P.length===1&&!o.btns&&!o.act)o.act=function(c,done){done()};delete o.frames;return o}
// variantli tanlov tugmalari: to'g'ri bosilganda sahna okF kadriga o'tadi
function bmPick(opts,ok,okF,msg){return opts.map(function(t,i){return [t,function(c,done,b){if(i===ok){if(okF)bmDraw(okF);b.style.background=C.ok;b.style.boxShadow='none';done()}else{b.style.background=C.bad;setTimeout(function(){b.style.background=''},1300);calc([(msg&&msg[i])||'Yana bir o‘ylab ko‘ring'],'')}}]})}
function w4u(n,v,c,w){var s=[];for(var i=0;i<n;i++)s.push({w:w,txt:v,c:c||'a'});return s}
var STEPS=[
bmStep({h:"Birga keltirish: avval «1 ta»",sum:"7 kunda 91 eshik → 1 kunda 91 : 7 = 13 → 5 kunda 13 · 5 = 65.",a:"m01",
 frames:[{t:'Ustaxonada 7 kunda 91 ta eshik yasaldi (har kuni teng). 5 kunda nechta?',bars:[{lab:'7 kun',y:68,segs:w4u(7,'?','a',1)},{lab:'5 kun',y:112,segs:w4u(5,'?','q',1)}],br:[{b:0,lab:'91 ta',up:true}],note:'Bitta bo‘lak — 1 kunlik ish'},
  {t:'Ustaxonada 7 kunda 91 ta eshik yasaldi (har kuni teng). 5 kunda nechta?',bars:[{lab:'7 kun',y:68,segs:w4u(7,'13','a',1)},{lab:'5 kun',y:112,segs:w4u(5,'?','q',1)}],br:[{b:0,lab:'91 ta',up:true}],calc:['1) 1 kunda: 91 : 7 = 13']},
  {t:'Ustaxonada 7 kunda 91 ta eshik yasaldi (har kuni teng). 5 kunda nechta?',bars:[{lab:'7 kun',y:68,segs:w4u(7,'13','a',1)},{lab:'5 kun',y:112,segs:w4u(5,'13','g',1)}],br:[{b:0,lab:'91 ta',up:true},{b:1,lab:'65 ta',up:false,col:C.ok}],calc:['1) 91 : 7 = 13','2) 13 · 5 = <b>65</b> ta']}],
 html:"<p>«Har kuni teng» degan so'z — kalit. Avval <b>1 kunda</b> nechta yasalganini topamiz. Kuzating.</p>",
 after:"<p><b>Birga keltirish</b> usuli ikki qadam: 1) <b>bo'lish</b> — 1 birlikka nechta to'g'ri keladi; 2) <b>ko'paytirish</b> — kerakli birliklar soniga.</p>",
 q:{t:"4 ta bir xil qutida 96 ta konfet bor. 7 ta shunday qutida nechta konfet?",opts:["24","168","99","672"],ok:1,why:"96 : 4 = 24; 24 · 7 = 168.",hint:"Avval 1 qutida nechta?",full:"1 qutida: 96 : 4 = 24. 7 qutida: 24 · 7 = 168. «24» — faqat 1-qadam, «99» — 96 + (7 − 4) qo'shish xatosi."},
 tn:"Bank misoli (744-id). Doskada jadval: «kun | eshik»: 7 → 91, 1 → ?, 5 → ?. Strelkalar bilan «: 7» va «· 5» ni ko'rsating."}),
bmStep({h:"Ko‘proq miqdorga",sum:"6 kg undan 252 somsa → 1 kg 42 → 9 kg 42 · 9 = 378.",a:"m02",
 frames:[{t:'6 kg undan 252 ta somsa pishirildi. 9 kg undan nechta somsa chiqadi?',bars:[{lab:'6 kg',y:68,segs:w4u(6,'?','a',1)},{lab:'9 kg',y:112,segs:w4u(9,'?','q',1)}],br:[{b:0,lab:'252 ta',up:true}],calc:['1) 1 kg: 252 : 6 = 42']},
  {t:'6 kg undan 252 ta somsa pishirildi. 9 kg undan nechta somsa chiqadi?',bars:[{lab:'6 kg',y:68,segs:w4u(6,'42','a',1)},{lab:'9 kg',y:112,segs:w4u(9,'42','g',1)}],br:[{b:0,lab:'252 ta',up:true},{b:1,lab:'378 ta',up:false,col:C.ok}],calc:['1) 252 : 6 = 42','2) 42 · 9 = <b>378</b> ta']}],
 html:"<p>Endi miqdor ko'payadi: 6 kg → 9 kg. Usul o'sha — avval 1 kg. Kuzating.</p>",
 after:"<p>Tekshirish: un ko'paydi — somsa ham ko'payishi kerak (378 &gt; 252) ✓. Javobning «mantiqan to'g'ri»ligini doim tekshiring.</p>",
 q:{t:"5 m sim 15 000 so'm. 8 m shunday sim necha so'm?",opts:["24 000","18 000","3000","120 000"],ok:0,why:"15 000 : 5 = 3000; 3000 · 8 = 24 000.",hint:"1 metr necha so'm?",full:"1 m: 15 000 : 5 = 3000 so'm. 8 m: 3000 · 8 = 24 000 so'm. «18 000» — 15 000 + 3000 (bir metr qo'shildi xolos)."},
 tn:"Bank misoli (747-id). Bolalardan javobni «mantiq bilan» baholashni so'rang: ko'payishi kerakmi, kamayishimi?"}),
bmStep({h:"Teskari yo‘nalish: nima kerak?",sum:"150 kg uzum → 25 kg mayiz; 1 kg mayiz uchun 150 : 25 = 6 kg uzum; 12 kg mayiz uchun 72 kg.",a:"m03",
 frames:[{t:'150 kg uzumdan 25 kg mayiz olinadi. 12 kg mayiz uchun necha kg uzum kerak?',bars:[{lab:'mayiz 25',y:68,segs:w4u(25,'','a',1)}],br:[{b:0,lab:'150 kg uzum',up:true}],note:'Har bir bo‘lak — 1 kg mayiz'},
  {t:'150 kg uzumdan 25 kg mayiz olinadi. 12 kg mayiz uchun necha kg uzum kerak?',bars:[{lab:'mayiz 25',y:68,segs:w4u(25,'','a',1)},{lab:'mayiz 12',y:112,segs:w4u(12,'','g',1)}],br:[{b:0,lab:'150 kg uzum',up:true},{b:1,lab:'72 kg uzum',up:false,col:C.ok}],calc:['1) 1 kg mayiz: 150 : 25 = 6 kg uzum','2) 6 · 12 = <b>72</b> kg uzum']}],
 html:"<p>Bu safar «1 kg mayiz uchun necha kg uzum?» deb so'raymiz. Kuzating.</p>",
 after:"<p>Qaysi kattalikni «1 ta»ga keltirish kerak? — <b>savoldagi</b> kattalikni (mayiz). 12 kg mayiz — 12 bo'lak, har biri 6 kg uzum.</p>",
 q:{t:"40 kg sutdan 8 kg qaymoq olinadi. 5 kg qaymoq uchun necha kg sut kerak?",opts:["25","1","200","13"],ok:0,why:"40 : 8 = 5 kg sut; 5 · 5 = 25.",hint:"1 kg qaymoq uchun necha kg sut?",full:"1 kg qaymoq uchun 40 : 8 = 5 kg sut. 5 kg qaymoq uchun 5 · 5 = 25 kg. «1» — 8 : 8 kabi chalkashish, «200» — 40 · 5."},
 tn:"Bank misoli (746-id), 3-daraja. «Nimadan nima olinadi?» degan savolni bolalarga ovoz chiqarib aytdiring."}),
bmStep({h:"Tuzoq: keraksiz son",sum:"Spidometr 620 → 860: 4 soatda 860 − 620 = 240 km; 1 soatda 60 km. 620 — yo'l emas, boshlang'ich ko'rsatkich.",a:"m04",
 frames:[{t:'Spidometr 620 km ni ko‘rsatdi. 4 soat yurgandan keyin 860 km ni ko‘rsatdi. 1 soatda necha km?',bars:[{lab:'spidometr',y:76,segs:[{w:620,txt:'620',c:'x'},{w:240,txt:'?',c:'q'}]}],br:[{b:0,lab:'860',up:true}],note:'Javobni tanlang:'}],
 html:"<p>Masalada son ko'p, lekin hammasi ham kerak emas. Chizmaga qarab tanlang:</p>",
 btns:bmPick(["155 km","60 km","215 km"],1,{t:'4 soatda yurilgan yo‘l — faqat yangi qism',bars:[{lab:'spidometr',y:76,segs:[{w:620,txt:'620 (oldin)',c:'x'},{w:60,txt:'60',c:'g'},{w:60,txt:'60',c:'g'},{w:60,txt:'60',c:'g'},{w:60,txt:'60',c:'g'}]}],br:[{b:0,from:1,to:4,lab:'240 km',up:true,col:C.ok}],calc:['1) 860 − 620 = 240 km','2) 240 : 4 = <b>60</b> km']},["155 = 620 : 4 — 620 km avval yurilgan, bu 4 soatda emas.","","215 = 860 : 4 — spidometr umumiy yo‘lni ko‘rsatadi."]),
 after:"<p>Spidometr — mashina <b>umr bo'yi</b> yurgan yo'l. 4 soatdagi yo'l = keyingi ko'rsatkich − oldingi. Bunday «chalg'ituvchi son» — xalqaro testlarda (PISA, TIMSS) sevimli tuzoq.</p>",
 q:{t:"Soat 9 da hisoblagich 1250 kVt·soat, soat 15 da 1310 kVt·soat ko'rsatdi. 1 soatda o'rtacha qancha sarflandi?",opts:["10","60","210","6"],ok:0,why:"60 kVt·soat 6 soatda: 60 : 6 = 10.",hint:"Necha soat o'tdi? Qancha sarflandi?",full:"15 − 9 = 6 soat, 1310 − 1250 = 60 kVt·soat. 60 : 6 = 10. «60» — 6 soatdagi jami, «6» — soatlar soni."},
 tn:"Bank misoli (748-id). Sinfda haqiqiy spidometr yoki elektr hisoblagich rasmini ko'rsating."}),
bmStep({h:"Bo‘shagan yashiklar",sum:"12 yashikda 360 shisha → 1 yashikda 30; 180 shisha sotilsa 180 : 30 = 6 yashik bo'shaydi.",a:"m05",
 frames:[{t:'12 ta yashikda 360 ta shisha (har birida teng). 180 ta sotildi. Nechta yashik bo‘shadi?',bars:[{lab:'12 yashik',y:76,segs:w4u(12,'?','a',1)}],br:[{b:0,lab:'360 ta',up:true}],calc:['1) 1 yashikda: 360 : 12 = 30']},
  {t:'12 ta yashikda 360 ta shisha (har birida teng). 180 ta sotildi. Nechta yashik bo‘shadi?',bars:[{lab:'12 yashik',y:76,segs:w4u(6,'30','x',1).concat(w4u(6,'30','a',1))}],br:[{b:0,from:0,to:5,lab:'180 ta sotildi',up:false,col:C.ok}],calc:['1) 360 : 12 = 30','2) 180 : 30 = <b>6</b> yashik bo‘shadi']}],
 html:"<p>Sotuvchi yashiklarni birin-ketin bo'shatadi. Kuzating.</p>",
 after:"<p>Bu yerda 2-qadam — ko'paytirish emas, <b>bo'lish</b>: «180 ichida nechta 30 bor?». Javob 6 — yarim shisha (180 — 360 ning yarmi), yarim yashik ✓.</p>",
 q:{t:"8 ta qutida 240 ta tuxum (har birida teng). 150 ta tuxum ishlatildi. Nechta quti to'liq bo'shadi?",opts:["5","30","3","90"],ok:0,why:"240 : 8 = 30; 150 : 30 = 5.",hint:"Avval 1 qutida nechta?",full:"1 qutida 30 ta. 150 : 30 = 5 quti bo'shadi (3 tasi qoldi). «3» — qolgan qutilar, «30» — 1 qutidagi tuxum."},
 tn:"Bank misoli (745-id). Kartondan 12 ta «yashik» chizib, 6 tasini o'chirib ko'rsating."}),
bmStep({h:"Ikkinchi usul: «necha marta ko‘p?»",sum:"4 kg — 6000 so'm; 12 kg 4 kg dan 3 marta ko'p → 6000 · 3 = 18 000 so'm.",a:"m06",
 frames:[{t:'4 kg kartoshka 6000 so‘m. 12 kg kartoshka necha so‘m?',bars:[{lab:'4 kg',y:62,segs:[{w:4,txt:'6000',c:'a'}]},{lab:'12 kg',y:114,segs:w4u(3,'?','q',4)}],note:'Qisqa yo‘lni tanlang:'}],
 html:"<p>Ba'zan «1 ta»ga keltirmasdan ham bo'ladi. 12 kg — necha marta 4 kg? Qaysi hisob to'g'ri?</p>",
 btns:bmPick(["6000 · 8","6000 · 3","6000 + 8"],1,{t:'12 kg = 3 marta 4 kg',bars:[{lab:'4 kg',y:62,segs:[{w:4,txt:'6000',c:'a'}]},{lab:'12 kg',y:114,segs:w4u(3,'6000','g',4)}],br:[{b:1,lab:'18 000 so‘m',up:false,col:C.ok}],calc:['12 : 4 = 3 marta','6000 · 3 = <b>18 000</b> so‘m']},["8 = 12 − 4 — «necha marta» bo‘lish bilan topiladi: 12 : 4 = 3.","","Miqdor 3 marta oshsa, narx ham 3 marta oshadi — qo‘shish emas."]),
 after:"<p>Ikki usul — bitta javob: 1 kg = 1500 so'm, 1500 · 12 = 18 000 ✓. Sonlar «qulay» bo'lsa (12 : 4 butun), «necha marta» usuli tezroq.</p>",
 q:{t:"3 ta bir xil kitob 21 000 so'm. 9 ta shunday kitob necha so'm?",opts:["63 000","27 000","189 000","7000"],ok:0,why:"9 : 3 = 3 marta; 21 000 · 3 = 63 000.",hint:"9 ta — 3 tadan necha marta ko'p?",full:"9 : 3 = 3 marta ko'p, demak narx ham 3 marta: 63 000. Tekshiruv: 1 kitob 7000, 7000 · 9 = 63 000 ✓. «189 000» — 21 000 · 9."},
 tn:"Bolalarga ikkala usulni ko'rsatib, «qaysi biri sizga qulay?» deb so'rang — Yaponiya darslarida bola o'z usulini tushuntiradi."}),
bmStep({h:"Tuzoq: ulushlarga bo‘lish",sum:"Lola 5 kg, Gul 3 kg olma terdi, 16 000 so'm terilgan olmaga qarab bo'linadi: 1 kg = 2000; Lola 10 000, Gul 6000.",a:"m07",
 frames:[{t:'Lola 5 kg, Gul 3 kg olma terdi. 16 000 so‘m haq terilgan olmaga qarab bo‘linadi.',bars:[{lab:'Lola',y:62,segs:w4u(5,'?','a',1)},{lab:'Gul',y:114,segs:w4u(3,'?','b',1)}],note:'Lola qancha oladi?'}],
 html:"<p>Pulni teng emas — <b>mehnatga qarab</b> bo'lish adolatli. Lola qancha oladi?</p>",
 btns:bmPick(["8000 so‘m","10 000 so‘m","5000 so‘m"],1,{t:'Jami 8 kg — 8 ta teng bo‘lak',bars:[{lab:'Lola',y:62,segs:w4u(5,'2000','g',1)},{lab:'Gul',y:114,segs:w4u(3,'2000','b',1)}],br:[{b:0,lab:'10 000',up:true,col:C.ok},{b:1,lab:'6000',up:false}],calc:['1) 5 + 3 = 8 kg;  16 000 : 8 = 2000 (1 kg uchun)','2) Lola: 2000 · 5 = <b>10 000</b>, Gul: 2000 · 3 = 6000']},["8000 — teng bo‘lingan (16 000 : 2). Lekin Lola ko‘proq terdi!","","5000 — kilogramni so‘mga aylantirmadingiz: avval 1 kg uchun haqni toping."]),
 after:"<p><b>Ulushlarga bo'lish</b>: 1) jami bo'laklar (5 + 3 = 8); 2) bitta bo'lak (16 000 : 8); 3) har kimning ulushi. Tekshirish: 10 000 + 6000 = 16 000 ✓.</p>",
 q:{t:"Ikki ishchi 4 soat va 6 soat ishladi. Ular 50 000 so'm oldi, ishlagan soatiga qarab bo'lishdi. Ko'p ishlagan qancha oladi?",opts:["25 000","30 000","20 000","5000"],ok:1,why:"10 soat; 1 soat 5000; 6 · 5000 = 30 000.",hint:"Jami necha soat? 1 soat uchun qancha?",full:"Jami 4 + 6 = 10 soat. 1 soatga 50 000 : 10 = 5000. Ko'p ishlagan: 6 · 5000 = 30 000 (ikkinchisi 20 000). «25 000» — teng bo'lish, «5000» — faqat 1 soatlik haq."},
 tn:"Bu — «proporsional bo'lish», 5–6-sinf mavzusining chizmali boshlanishi. Konfetlarni 5 : 3 nisbatda bo'lib, sinfda ko'rsating."}),
bmStep({h:"Bilasizmi? Al-Xorazmiy va «muomalalar bobi»",sum:"Al-Xorazmiyning «Al-jabr» kitobida savdo-sotiq masalalari bo'limi bor: 3 son ma'lum bo'lsa, 4-sini topish.",a:"m08",
 frames:[{t:'Narx ↔ miqdor: uchta son ma’lum — to‘rtinchisi topiladi',bars:[{lab:'ma’lum',y:62,segs:[{w:1,txt:'miqdor',c:'a'},{w:1,txt:'narx',c:'b'}]},{lab:'savol',y:114,segs:[{w:1,txt:'miqdor',c:'a'},{w:1,txt:'?',c:'q'}]}],note:'Al-Xorazmiy bu yo‘lni IX asrda tushuntirgan'}],
 html:"<p>📜 Buyuk vatandoshimiz <b>Muhammad al-Xorazmiy</b> (IX asr) «Al-jabr val-muqobala» kitobida alohida <b>«muomalalar bobi»</b>ni yozgan. Unda bozordagi savdo masalalari bor: narx va miqdordan uchtasi ma'lum bo'lsa, to'rtinchisini qanday topish.</p>",
 after:"<p>Siz bugun aynan shu usulni — al-Xorazmiyning usulini qo'lladingiz! Keyinchalik Yevropada u «<b>uchlik qoidasi</b>» deb ataldi va savdogarlar uchun eng kerakli qoidaga aylandi.</p>",
 tn:"Bolalarga al-Xorazmiy nomidan «algoritm» so'zi kelib chiqqanini eslating. Xiva va Urganchdagi haykali haqida qisqa so'zlab bering."}),
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){bmDraw({t:'Birga keltirish: avval «1 ta»',bars:[{lab:'ma’lum',y:62,segs:w4u(4,'1 ta','a',1)},{lab:'kerak',y:114,segs:w4u(6,'1 ta','g',1)}],br:[{b:0,lab:': bo‘lish',up:true},{b:1,lab:'· ko‘paytirish',up:false}]})},fin:function(){this.start()},
 html:"<div class='memo'><ul><li>«Har biri teng / xuddi shunday» → <b>birga keltirish</b>.</li><li>1-qadam: <b>bo'lish</b> — 1 birlikka qancha; 2-qadam: <b>ko'paytirish</b>.</li><li>«1 ta»ga <b>savoldagi</b> kattalikni keltiring.</li><li>Sonlar qulay bo'lsa — «<b>necha marta?</b>» usuli tezroq.</li><li>Keraksiz sonni toping va chetga surib qo'ying.</li><li><b>Ulushlarga bo'lish</b>: jami bo'laklar → bitta bo'lak → har kimning ulushi.</li><li>Javobni mantiq bilan tekshiring: ko'payishi kerakmi, kamayishimi?</li></ul></div>",
 tn:"Keyingi darsda «kun | ish» jadvalida bitta katakni yashirib, bolalarga topdiring."}
];
var PROBS=[
{t:"7 kunda 91 ta eshik yasaldi (har kuni teng). 5 kunda nechta eshik yasaladi?",o:["65","13","78","60"],k:0,s:"91 : 7 = 13; 13 · 5 = 65."},
{t:"4 ta bir xil qutida 96 ta konfet. 7 ta qutida nechta?",o:["168","24","99","672"],k:0,s:"96 : 4 = 24; 24 · 7 = 168."},
{t:"6 kg undan 252 ta somsa. 9 kg undan nechta somsa?",o:["378","368","360","42"],k:0,s:"252 : 6 = 42; 42 · 9 = 378."},
{t:"5 m sim 15 000 so'm. 8 m sim necha so'm?",o:["24 000","18 000","3000","120 000"],k:0,s:"3000 · 8 = 24 000."},
{t:"150 kg uzumdan 25 kg mayiz olinadi. 12 kg mayiz uchun necha kg uzum kerak?",o:["72","6","78","66"],k:0,s:"150 : 25 = 6; 6 · 12 = 72."},
{t:"40 kg sutdan 8 kg qaymoq olinadi. 5 kg qaymoq uchun necha kg sut kerak?",o:["25","200","13","1"],k:0,s:"40 : 8 = 5; 5 · 5 = 25."},
{t:"Spidometr 620 km, 4 soatdan keyin 860 km ni ko'rsatdi. Mashina 1 soatda necha km yurgan?",o:["60","155","215","240"],k:0,s:"240 : 4 = 60."},
{t:"12 yashikda 360 ta shisha (teng). 180 ta sotildi. Nechta yashik bo'shadi?",o:["6","15","30","2"],k:0,s:"360 : 12 = 30; 180 : 30 = 6."},
{t:"8 qutida 240 ta tuxum (teng). 150 tasi ishlatildi. Nechta quti to'liq bo'shadi?",o:["5","3","30","90"],k:0,s:"30 tadan; 150 : 30 = 5."},
{t:"4 kg kartoshka 6000 so'm. 12 kg kartoshka necha so'm?",o:["18 000","48 000","14 000","1500"],k:0,s:"12 : 4 = 3; 6000 · 3 = 18 000."},
{t:"3 ta kitob 21 000 so'm. 9 ta kitob necha so'm?",o:["63 000","27 000","189 000","7000"],k:0,s:"21 000 · 3 = 63 000."},
{t:"Lola 5 kg, Gul 3 kg olma terdi. 16 000 so'm terganiga qarab bo'lindi. Lola qancha oldi?",o:["10 000","8000","6000","5000"],k:0,s:"16 000 : 8 = 2000; 2000 · 5 = 10 000."},
{t:"Ikki ishchi 4 va 6 soat ishladi, 50 000 so'm soatiga qarab bo'lindi. Kam ishlagan qancha oldi?",o:["20 000","25 000","30 000","4000"],k:0,s:"50 000 : 10 = 5000; 5000 · 4 = 20 000."},
{t:"Soat 9 da hisoblagich 1250, soat 15 da 1310 ni ko'rsatdi. 1 soatda o'rtacha qancha sarflandi?",o:["10","60","6","210"],k:0,s:"60 : 6 = 10."},
{t:"9 ta bir xil stul 270 kg. 4 ta stul necha kg?",o:["120","30","1080","265"],k:0,s:"270 : 9 = 30; 30 · 4 = 120."},
{t:"Nasos 5 daqiqada 450 l suv chiqaradi. 900 l suvni necha daqiqada chiqaradi?",o:["10","90","2","4500"],k:0,s:"900 = 2 · 450 → 2 · 5 = 10."},
{t:"3 ta bola 2 soatda 24 ta daraxt ekdi. Har bola soatiga teng ishlasa, 1 bola 1 soatda nechta ekadi?",o:["4","8","12","6"],k:0,s:"24 : 2 = 12 (3 bolaga soatiga); 12 : 3 = 4."},
{t:"Uch do'st 3, 4 va 5 ta kitob olib keldi. 60 000 so'mga sotilgan kitob puli kitob soniga qarab bo'lindi. 5 ta kitob olib kelgan qancha oldi?",o:["25 000","20 000","15 000","12 000"],k:0,s:"12 kitob; 60 000 : 12 = 5000; 5 · 5000 = 25 000."},
{t:"6 ta bir xil qalam 4200 so'm. 10 000 so'mga nechta shunday qalam olish mumkin?",o:["14","10","16","15"],k:0,s:"Qalam 700; 10 000 : 700 = 14 (qoldiq 200)."},
{t:"8 kg guruchdan 2 qozon palov chiqadi. 5 qozon palov uchun necha kg guruch kerak?",o:["20","16","40","13"],k:0,s:"1 qozon 4 kg; 4 · 5 = 20."}
];
function PRACT_STAGE(){bmDraw({t:'Avval «1 ta», keyin kerakli miqdor',bars:[{lab:'ma’lum',y:62,segs:w4u(4,'?','a',1)},{lab:'kerak',y:114,segs:w4u(6,'?','q',1)}]})}
var PREP_DATA={teach:["Birga keltirish: bo'lish → ko'paytirish.","Teskari yo'nalish (nima uchun nima kerak).","Keraksiz son (spidometr) va ikki usul («1 ta» yoki «necha marta»).","Ulushlarga (proporsional) bo'lish."],
 mist:["Birinchi qadamdagi sonni javob deb beradi.","Ko'paytirish o'rniga qo'shadi (6000 + 8).","Spidometrning umumiy ko'rsatkichini bo'ladi.","Pulni mehnatga qarab emas, teng bo'ladi."],
 need:["«kun | ish», «kg | so'm» jadvali chizilgan doska.","Konfet yoki cho'plar (ulushlarga bo'lish uchun)."],
 board:["<span class='w2'>91 : 7 = 13; 13 · 5 = 65</span>.","<span class='w2'>150 : 25 = 6; 6 · 12 = 72</span>.","<span class='w2'>860 − 620 = 240; 240 : 4 = 60</span>.","<span class='w2'>12 : 4 = 3; 6000 · 3 = 18 000</span>.","<span class='w2'>16 000 : 8 = 2000</span>; 10 000 va 6000."]};
