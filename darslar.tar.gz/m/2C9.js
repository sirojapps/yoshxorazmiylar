// --- k2c9_ yordamchilari ---
function k2c9_msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function k2c9_big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// r qator, c ustun nuqtalar massivi. o.cols(i,j) -> rang; o.cross: qatorlar ro'yxati; o.lbl: pastdagi yozuv
function k2c9_arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,128/r,24),rr=Math.max(3,s*.36),x0=180-(c-1)*s/2,y0=Math.max(18,82-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var col=o.cols?o.cols(i,j):C.b;E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:col,stroke:'rgba(0,0,0,.18)'},g)}
 (o.cross||[]).forEach(function(i){E('line',{x1:x0-s/2,y1:y0+i*s,x2:x0+(c-.5)*s,y2:y0+i*s,stroke:C.bad,'stroke-width':2.5},g)});
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.hline!=null)E('line',{x1:x0-s/2,y1:y0+(o.hline-.5)*s,x2:x0+(c-.5)*s,y2:y0+(o.hline-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.rl)for(var k=0;k<r;k++)T(g,x0-s/2-12,y0+k*s+4,o.rl(k),{'font-size':10,fill:'#5b6b7b'});
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue});return {x0:x0,y0:y0,s:s}}
// chizma (bar) model: n ta teng quti, ichida yozuv; ustida qavs
function k2c9_bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||34,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}
 E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g);return {x0:x0,w:w}}
var CODE='2C9',TITLE='2-sinf · 6, 7, 8, 9 ga ko‘paytirish va bo‘lish; ko‘paytirish jadvali';
// ko'paytirish jadvali (1..9)
function k2c9_tab(mode,hl){clear();var g=S.g,x0=44,y0=4,c=32,h=16.6;
 for(var i=0;i<=9;i++)for(var j=0;j<=9;j++){var x=x0+j*c,y=y0+i*h;if(i===0&&j===0)continue;
  var head=i===0||j===0,v=head?(i||j):i*j,f='#fff';
  if(head)f='#e8f1fb';else if(mode==='known'&&(i<=5||j<=5))f='#e6f6ee';else if(mode==='known')f=(i<=j)?'#ffe2b8':'#fff3df';
  if(hl&&!head&&((i===hl[0]&&j===hl[1])||(i===hl[1]&&j===hl[0])))f=C.hi;
  E('rect',{x:x,y:y,width:c-1,height:h-1,rx:2,fill:f,stroke:'#dde5ee'},g);T(g,x+c/2,y+12,String(v),{'font-size':head?10:9.5,'font-weight':head?800:500,fill:head?C.blue:'#33475b'})}
 E('text',{x:x0+c/2,y:y0+12.5,'text-anchor':'middle','font-size':11,'font-weight':800,fill:C.bad},g).textContent='·'}
var P2=[function(){k2c9_arr(6,7,{cols:function(){return C.b},rl:function(k){return k<6?'7':''},lbl:'6 qator, har birida 7 ta: 6 · 7 = ?'});k2c9_big('6 · 7 = ?','6 ta qator, har birida 7 tadan')},
 function(){k2c9_arr(6,7,{cols:function(i){return i<5?C.b:C.a},hline:5,lbl:'5 qator + 1 qator'});k2c9_big('5 · 7 = <b>35</b> — buni bilamiz','Avval 5 ta qatorni olamiz')},
 function(){k2c9_arr(6,7,{cols:function(i){return i<5?C.b:C.a},hline:5,lbl:'35 + 7 = 42'});k2c9_big('6 · 7 = 5 · 7 + 7 = 35 + 7 = <b>42</b>','Yana bitta qator — yana 7 ta')}];
var P3=[function(){k2c9_arr(10,6,{cols:function(i){return C.b},lbl:'10 qator, har birida 6 ta: 10 · 6 = 60'});k2c9_big('9 · 6 = ?','Avval 10 ta qator — bu oson: 60')},
 function(){k2c9_arr(10,6,{cols:function(i){return i<9?C.b:'#e9e2d6'},cross:[9],lbl:'1 qatorni olib tashlaymiz'});k2c9_big('9 · 6 = 10 · 6 − 6 = 60 − 6 = <b>54</b>','To‘qqizta — bu o‘nta bitta kam')}];
var P4=[function(){k2c9_arr(2,6,{cols:function(){return C.b},lbl:'2 · 6 = 12'});k2c9_big('8 · 6 = ? → avval 2 · 6 = <b>12</b>','8 = 2 · 2 · 2 — uch marta ikkilantiramiz')},
 function(){k2c9_arr(4,6,{cols:function(i){return i<2?C.b:C.a},hline:2,lbl:'4 · 6 = 24 (ikkilantirdik)'});k2c9_big('2 · 6 = 12 → 4 · 6 = <b>24</b>')},
 function(){k2c9_arr(8,6,{cols:function(i){return i<4?C.b:C.a},hline:4,lbl:'8 · 6 = 48 (yana ikkilantirdik)'});k2c9_big('12 → 24 → <b>48</b>: 8 · 6 = 48')}];
var P5=[function(){k2c9_arr(7,8,{cols:function(){return C.b},lbl:'7 · 8 = ?'});k2c9_big('7 · 8 = ?','7 ni 5 va 2 ga ajratamiz')},
 function(){k2c9_arr(7,8,{cols:function(i){return i<5?C.b:C.a},hline:5,lbl:'5 · 8 = 40 va 2 · 8 = 16'});k2c9_big('7 · 8 = 5 · 8 + 2 · 8 = 40 + 16 = <b>56</b>')}];
var STEPS=[
{h:"Jadvalning ko'pini allaqachon bilasiz!",sum:"1–5 ga ko'paytirishni bilasiz; o'rin almashtirish tufayli 6–9 dan faqat 10 ta yangi ko'paytma qoladi.",a:"m01",
 start:function(){k2c9_tab('');k2c9_msg('Ko‘paytirish jadvali: 81 ta katak. Qo‘rqinchli-mi? Tugmani bosing')},fin:function(){k2c9_tab('known');k2c9_msg('Yashil — bilasiz. Faqat <b>10 ta</b> to‘q sariq katak yangi!')},
 html:"<p>Bu — to'liq <b>ko'paytirish jadvali</b>. 81 ta katak! Lekin qo'rqmang: siz 1, 2, 3, 4, 5 ga ko'paytirishni bilasiz. Bilganlaringizni bo'yab ko'ramiz.</p>",
 btns:[["🎨 Bilganlarimni bo'ya",function(c,done){k2c9_tab('known');k2c9_msg('Yashil — bilasiz. Qolgan to‘q sariqlar: 6·6, 6·7, 6·8, 6·9, 7·7, 7·8, 7·9, 8·8, 8·9, 9·9 — atigi <b>10 ta</b>!');done()}]],
 after:"<p>O'rin almashtirish xossasini eslang: <b>6 · 4 = 4 · 6</b>. Shuning uchun jadvalning yarmi ikkinchi yarmini takrorlaydi. Yangi o'rganiladiganlari — atigi <b>10 ta</b> ko'paytma. Ularni bugun «ayyor usullar» bilan topamiz.</p>",
 q:{t:"4 · 7 = 28 ekanini bilasiz. 7 · 4 nechaga teng?",opts:["28","11","47","24"],ok:0,why:"Ko'paytuvchilar o'rni almashsa, ko'paytma o'zgarmaydi.",hint:"O'rin almashtirish xossasini eslang.",full:"7 · 4 = 4 · 7 = 28. Ko'paytuvchilarning o'rni almashganda ko'paytma o'zgarmaydi. «11» — qo'shib yuborilgan."},
 tn:"Yaponiyada bolalar 2-sinfda «kuku» (ko'paytirish jadvali)ni qo'shiq qilib yod oladi, lekin avval har bir ko'paytmani massiv (nuqtalar) bilan tushunadi. Doskada jadvalni chizib, bilganlarini bolalarning o'zi bo'yasin."},
{h:"6 ga: «beshta va yana bitta»",sum:"6 · 7 = 5 · 7 + 7 = 42. Oltita — beshta va yana bitta.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=2;P2[2]()},
 html:"<p>Massivga qarang: <b>6 qator</b>, har birida <b>7 ta</b> nuqta. 6 · 7 ni bilmasangiz ham, 5 · 7 ni bilasiz! Kuzating.</p>",btns:[phaser(P2)],
 after:"<p>Usul: <b>6 · son = 5 · son + son</b>. 6 · 8 = 40 + 8 = 48, 6 · 9 = 45 + 9 = 54.</p>",
 q:{t:"6 · 8 nechaga teng?",opts:["46","48","14","54"],ok:1,why:"5 · 8 = 40, yana 8: 48.",hint:"Avval 5 · 8 ni toping, keyin yana bitta 8 qo'shing.",full:"6 · 8 = 5 · 8 + 8 = 40 + 8 = 48. «14» — 6 + 8 qo'shilgan, «54» — bu 6 · 9."},
 tn:"Singapur va Yaponiyada «ma'lum ko'paytmadan yangisini yasash» asosiy strategiya. Bolalar massivni qog'ozda chizib, chiziq bilan 5 + 1 ga ajratsin."},
{h:"9 ga: «o'nta bitta kam»",sum:"9 · 6 = 10 · 6 − 6 = 54. Javob raqamlari yig'indisi doim 9 (5 + 4).",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=1;P3[1]()},
 html:"<p>9 — bu 10 dan bitta kam. 10 ga ko'paytirish esa juda oson. Kuzating.</p>",btns:[phaser(P3)],
 after:"<p>Usul: <b>9 · son = 10 · son − son</b>. Yana bir sir: 9 ga ko'paytmalarda raqamlar yig'indisi doim <b>9</b>: 18 (1+8), 27, 36, 45, 54, 63, 72, 81.</p><div class='life'><div>🖐🖐<span><b>Barmoq usuli:</b> 10 barmoqni yozing, 9 · 4 uchun 4-barmoqni bukting: chapda <b>3</b>, o'ngda <b>6</b> → 36</span></div></div>",
 q:{t:"9 · 7 nechaga teng?",opts:["63","56","72","16"],ok:0,why:"10 · 7 = 70, 70 − 7 = 63.",hint:"Avval 10 · 7 ni toping, keyin bitta 7 ni ayiring.",full:"9 · 7 = 70 − 7 = 63. Tekshiramiz: 6 + 3 = 9 ✓. «72» — bu 9 · 8, «56» — 7 · 8."},
 tn:"Barmoq usuli bolalarga juda yoqadi va 9 ga ko'paytirishni bir darsda mustahkamlaydi."},
{h:"8 ga: uch marta ikkilantiramiz",sum:"8 · 6: 2 · 6 = 12 → 24 → 48. Har safar ikkilantiramiz.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>8 = 2 · 2 · 2. Demak 8 ga ko'paytirish — <b>uch marta ikkilantirish</b>. Kuzating.</p>",btns:[phaser(P4)],
 after:"<p>Usul: <b>son → 2 barobar → 4 barobar → 8 barobar</b>. 8 · 7: 14 → 28 → 56. 8 · 9: 18 → 36 → 72.</p>",
 q:{t:"8 · 7 nechaga teng?",opts:["54","56","64","48"],ok:1,why:"7 → 14 → 28 → 56.",hint:"2 · 7 ni toping va yana ikki marta ikkilantiring.",full:"2 · 7 = 14, 4 · 7 = 28, 8 · 7 = 56. «64» — 8 · 8, «48» — 8 · 6."},
 tn:"Ikkilantirish — qadimgi Misr ko'paytirish usuli. Bolalar 14 + 14, 28 + 28 ni og'zaki tez topsin."},
{h:"7 ga: 5 va 2 ga ajratamiz",sum:"7 · 8 = 5 · 8 + 2 · 8 = 40 + 16 = 56.",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=1;P5[1]()},
 html:"<p>7 eng «qiyin» ko'paytuvchi deyiladi. Lekin 7 = 5 + 2, ikkalasini esa bilasiz!</p>",btns:[phaser(P5)],
 after:"<p>Usul: <b>7 · son = 5 · son + 2 · son</b>. 7 · 6 = 30 + 12 = 42, 7 · 9 = 45 + 18 = 63. Mashhur 7 · 8 = 56 ni eslab qolish uchun: <b>5, 6, 7, 8</b> → 56 = 7 · 8.</p>",
 q:{t:"7 · 6 nechaga teng?",opts:["36","42","48","13"],ok:1,why:"5 · 6 = 30, 2 · 6 = 12, jami 42.",hint:"7 ni 5 va 2 ga ajrating.",full:"7 · 6 = 5 · 6 + 2 · 6 = 30 + 12 = 42. «36» — 6 · 6, «48» — 8 · 6, «13» — qo'shilgan."},
 tn:"Bolalar o'zi tanlasin: 7 · 8 ni 5 + 2 bilanmi yoki 8 · 7 ni ikkilantirish bilanmi — ikkalasi ham to'g'ri. Yaponiyada bola usulini sinfga tushuntirib beradi."},
{h:"Bo'lish — ko'paytirishning teskarisi",sum:"7 · 8 = 56 bo'lsa: 56 : 8 = 7, 56 : 7 = 8. Bitta «uchburchak» — to'rtta misol.",a:"m06",
 start:function(){k2c9_tri([7,8,56],0)},fin:function(){k2c9_tri([7,8,56],4)},
 html:"<p>Bitta ko'paytmani bilsangiz, <b>ikkita bo'lishni</b> ham bilasiz. Uchburchak tugmasini bosib, to'rtta misolni oching.</p>",
 btns:[["🔺 Keyingi misol",function(c,done){S.k3=(S.k3||0)+1;k2c9_tri([7,8,56],S.k3);if(S.k3>=4)done()}]],
 act:function(){S.k3=0},
 after:"<p>Bo'lishda savol: <b>«nechaga ko'paytirsak, shu chiqadi?»</b> 63 : 9 — «9 ni nechaga ko'paytirsak 63?» — 7 ga. Demak 63 : 9 = 7.</p>",
 q:{t:"63 : 9 nechaga teng?",opts:["8","6","7","54"],ok:2,why:"9 · 7 = 63, demak 63 : 9 = 7.",hint:"9 ni nechaga ko'paytirsak 63 chiqadi?",full:"9 · 7 = 63. Shuning uchun 63 : 9 = 7 va 63 : 7 = 9. «8» — 9 · 8 = 72, «54» — ayirib yuborilgan."},
 tn:"«Son uchburchagi» (fact family) — AQSh va Singapur darsliklarida keng qo'llanadi. Bolalar kartochkaning burchagini yopib, yashirin sonni topsin."},
{h:"Tuzoq: ko'paytma ma'lum, sonlar noma'lum",sum:"Ikki bir xonali sonning ko'paytmasi 56 → 7 va 8 → yig'indisi 15.",a:"m07",
 start:function(){k2c9_tab('',null);k2c9_msg('«Ikkita bir xonali sonning ko‘paytmasi 56. Ularning yig‘indisi?»')},fin:function(){k2c9_tab('',[7,8]);k2c9_msg('56 = <b>7 · 8</b> → 7 + 8 = <b>15</b>')},
 html:"<p>«Ikkita <b>bir xonali</b> sonning ko'paytmasi 56. Ularning yig'indisi nechaga teng?» Jadvaldan 56 ni qidiramiz.</p>",
 btns:[["🔍 56 ni qidir",function(c,done){k2c9_tab('',[7,8]);k2c9_msg('56 = <b>7 · 8</b> (yoki 8 · 7). Bir xonali sonlar bilan boshqa yo‘li yo‘q!');done()}]],
 after:"<p>56 jadvalda faqat <b>7 · 8</b> da bor. Yig'indisi: 7 + 8 = <b>15</b>. Diqqat: «bir xonali» degan shart muhim — 2 · 28 ham 56, lekin 28 ikki xonali.</p>",
 q:{t:"Ikkita bir xonali sonning ko'paytmasi 54. Ularning ayirmasi (katta − kichik) nechaga teng?",opts:["3","15","9","6"],ok:0,why:"54 = 6 · 9; 9 − 6 = 3.",hint:"Jadvalda 54 qaysi ikki sonning ko'paytmasi?",full:"54 = 6 · 9 (bir xonali sonlar bilan boshqa yo'li yo'q: 2 · 27, 3 · 18 — ikki xonali bor). Ayirma: 9 − 6 = 3. «15» — yig'indi."},
 tn:"Bank va olimpiadalarda ko'p keladi. Jadvaldan teskari qidirishni mashq qildiring: «24 qaysi ko'paytmalarda bor?» (3·8, 4·6)."},
{h:"Tuzoq: ikki noma'lum bir masalada",sum:"□ : 6 = 8 → □ = 48; 72 : △ = 9 → △ = 8; □ − △ = 40.",a:"m08",
 start:function(){S.ph=0;k2c9_big('□ : 6 = 8 &nbsp; va &nbsp; 72 : △ = 9','□ − △ = ?');clear();k2c9_bars(30,6,['8','8','8','8','8','8'],{});T(S.g,180,22,'□ = ?',{'font-size':13,'font-weight':800,fill:C.blue});k2c9_bars(100,9,[],{});T(S.g,180,92,'72 — 9 ta teng bo‘lak, har biri △',{'font-size':12,'font-weight':800,fill:C.blue})},
 fin:function(){clear();k2c9_bars(30,6,['8','8','8','8','8','8'],{});T(S.g,180,22,'□ = 6 · 8 = 48',{'font-size':13,'font-weight':800,fill:C.ok});k2c9_bars(100,9,['8','8','8','8','8','8','8','8','8'],{fs:11});T(S.g,180,92,'△ = 72 : 9 = 8',{'font-size':13,'font-weight':800,fill:C.ok});k2c9_big('□ − △ = 48 − 8 = <b>40</b>')},
 html:"<p>«<b>□ : 6 = 8</b> va <b>72 : △ = 9</b> bo'lsa, □ − △ nechaga teng?» Har bir noma'lumni chizma bilan alohida topamiz.</p>",
 btns:[["▶ Yechish",function(c,done){STEPS[7].fin();done()}]],
 after:"<p>□ — 6 ta teng bo'lakka bo'lingan, har bo'lak 8: □ = <b>48</b>. 72 — 9 ta teng bo'lak, △ — bitta bo'lak: △ = <b>8</b>. Javob: 48 − 8 = <b>40</b>.</p>",
 q:{t:"□ · 7 = 63 va △ : 4 = 8 bo'lsa, □ + △ nechaga teng?",opts:["41","15","39","40"],ok:0,why:"□ = 63 : 7 = 9, △ = 8 · 4 = 32; 9 + 32 = 41.",hint:"Avval □ ni, keyin △ ni alohida toping.",full:"□ · 7 = 63 → □ = 63 : 7 = 9. △ : 4 = 8 → △ = 8 · 4 = 32. □ + △ = 9 + 32 = 41. «15» — 7 + 8 qo'shilgan."},
 tn:"Ikki noma'lumli savolda bolalar avval har birini alohida yozib qo'ysin: «□ = …», «△ = …»."},
{h:"Bilasizmi? Pifagor jadvali va «kuku»",sum:"Ko'paytirish jadvali «Pifagor jadvali» deb ham ataladi; Yaponiyada uni «kuku» qo'shig'i bilan yod olishadi.",a:"m09",
 start:function(){k2c9_tab('');k2c9_msg('Ko‘paytirish jadvali — «Pifagor jadvali»')},fin:function(){k2c9_tab('');k2c9_msg('Ko‘paytirish jadvali — «Pifagor jadvali»')},
 html:"<p>📜 Ko'paytirish jadvali ko'p mamlakatlarda <b>«Pifagor jadvali»</b> deb ataladi — qadimgi yunon olimi Pifagor nomi bilan.</p><p>🇯🇵 Yaponiyada 2-sinf o'quvchilari jadvalni <b>«kuku»</b> deb ataladigan she'r-qo'shiq bilan yod olishadi: «ku-ku hachi-ju-ichi» — «to'qqiz to'qqiz — sakson bir».</p><p>⭐ Siz ham jadvalni yod oling — lekin avval har bir ko'paytmaning <b>qayerdan kelishini</b> tushuning. Endi buni bilasiz!</p>",
 tn:"Sinfda «kuku» kabi o'z qo'shig'ingizni tuzing yoki har kuni 2 daqiqa «ko'paytirish zanjiri» o'yinini o'ynang."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){k2c9_tab('known');k2c9_msg('Faqat 10 ta yangi ko‘paytma')},fin:function(){k2c9_tab('known');k2c9_msg('Faqat 10 ta yangi ko‘paytma')},
 html:"<div class='memo'><ul><li><b>6 ·</b> son = 5 · son + son: 6 · 7 = 35 + 7 = 42.</li><li><b>9 ·</b> son = 10 · son − son: 9 · 6 = 60 − 6 = 54 (raqamlar yig'indisi 9).</li><li><b>8 ·</b> son — uch marta ikkilantirish: 6 → 12 → 24 → 48.</li><li><b>7 ·</b> son = 5 · son + 2 · son: 7 · 8 = 40 + 16 = 56.</li><li>Yangi 10 ta: 6·6=36, 6·7=42, 6·8=48, 6·9=54, 7·7=49, 7·8=56, 7·9=63, 8·8=64, 8·9=72, 9·9=81.</li><li><b>Bo'lish</b> — teskarisi: 56 : 8 = 7, chunki 8 · 7 = 56.</li></ul></div>",
 tn:"Kartochkani daftarga yopishtiring; har kuni 3 ta yangi ko'paytmani so'rang."}
];
function k2c9_tri(v,k){clear();var g=S.g;E('path',{d:'M180 14 L290 150 L70 150 Z',fill:'#fff7ea',stroke:C.line,'stroke-width':2},g);
 T(g,180,56,String(v[2]),{'font-size':26,'font-weight':800,fill:C.a2});T(g,110,138,String(v[0]),{'font-size':24,'font-weight':800,fill:C.blue});T(g,250,138,String(v[1]),{'font-size':24,'font-weight':800,fill:C.blue});T(g,180,138,'·',{'font-size':22,'font-weight':800});
 var f=[v[0]+' · '+v[1]+' = '+v[2],v[1]+' · '+v[0]+' = '+v[2],v[2]+' : '+v[1]+' = '+v[0],v[2]+' : '+v[0]+' = '+v[1]];
 k2c9_big(k?f.slice(0,k).join(' &nbsp;·&nbsp; '):'Uchburchak: ikki ko‘paytuvchi va ko‘paytma',k?('Ochildi: '+k+' / 4'):'')}
var PROBS=[
{t:"6 · 9 nechaga teng?",o:["54","56","45","63"],k:0,s:"5 · 9 = 45, yana 9: 54."},
{t:"7 · 7 nechaga teng?",o:["49","42","56","14"],k:0,s:"5 · 7 + 2 · 7 = 35 + 14 = 49."},
{t:"8 · 8 nechaga teng?",o:["64","56","72","16"],k:0,s:"8 → 16 → 32 → 64."},
{t:"9 · 9 nechaga teng?",o:["81","72","99","18"],k:0,s:"10 · 9 − 9 = 90 − 9 = 81."},
{t:"72 : 8 nechaga teng?",o:["9","8","7","64"],k:0,s:"8 · 9 = 72, demak 72 : 8 = 9."},
{t:"42 : 7 nechaga teng?",o:["6","7","5","35"],k:0,s:"7 · 6 = 42."},
{t:"48 : 6 nechaga teng?",o:["8","7","9","6"],k:0,s:"6 · 8 = 48."},
{t:"81 : 9 nechaga teng?",o:["9","8","7","72"],k:0,s:"9 · 9 = 81."},
{t:"Bir qutida 8 ta qalam. 7 ta qutida nechta qalam?",o:["56","15","54","64"],k:0,s:"8 · 7 = 56."},
{t:"63 ta olma 9 ta savatga teng bo'lindi. Har savatda nechta?",o:["7","8","6","54"],k:0,s:"63 : 9 = 7."},
{t:"Qaysi ko'paytma eng katta?",o:["8 · 9","9 · 7","7 · 8","6 · 9"],k:0,s:"72, 63, 56, 54 — eng kattasi 8 · 9 = 72."},
{t:"Ikkita bir xonali sonning ko'paytmasi 56. Ularning yig'indisini toping.",o:["15","14","16","22"],k:0,s:"56 = 7 · 8; 7 + 8 = 15."},
{t:"□ : 6 = 8 va 72 : △ = 9 bo'lsa, □ − △ nechaga teng?",o:["40","39","42","56"],k:0,s:"□ = 48, △ = 8; 48 − 8 = 40."},
{t:"6 · 7 dan 5 · 7 qanchaga katta?",o:["7","1","6","42"],k:0,s:"6 · 7 − 5 · 7 = bitta 7 ko'p: 42 − 35 = 7."},
{t:"9 · 8 ni «o'nta bitta kam» usulida qanday hisoblaymiz?",o:["80 − 8","90 − 8","80 − 9","72 − 8"],k:0,s:"9 · 8 = 10 · 8 − 8 = 80 − 8 = 72."},
{t:"7 · □ = 63. □ nechaga teng?",o:["9","8","7","56"],k:0,s:"63 : 7 = 9."},
{t:"Qaysi son 6 ga ham, 8 ga ham qoldiqsiz bo'linadi?",o:["48","36","56","42"],k:0,s:"48 : 6 = 8, 48 : 8 = 6. 36 : 8, 56 : 6, 42 : 8 butun chiqmaydi."},
{t:"Ali 9 tadan 6 qator stul terdi, Vali 8 tadan 7 qator. Kim ko'p stul terdi va nechtaga?",o:["Vali, 2 taga","Ali, 2 taga","Teng","Vali, 1 taga"],k:0,s:"Ali: 54, Vali: 56. Vali 2 ta ko'p."},
{t:"Ikkita bir xonali sonning ko'paytmasi 63, ayirmasi 2. Kattasi qaysi?",o:["9","7","8","21"],k:0,s:"63 = 7 · 9, 9 − 7 = 2. Kattasi 9."},
{t:"8 · 6 + 8 · 3 nechaga teng?",o:["72","56","48","64"],k:0,s:"8 · (6 + 3) = 8 · 9 = 72. Yoki 48 + 24 = 72."}
];
function PRACT_STAGE(){k2c9_tab('known');k2c9_msg('Kerak bo‘lsa, jadvalga qarang')}
var PREP_DATA={teach:["To'liq ko'paytirish jadvali; 6, 7, 8, 9 ga ko'paytirish va bo'lish.","Strategiyalar: 6 = 5 + 1, 9 = 10 − 1, 8 = ikkilantirish ×3, 7 = 5 + 2.","Bo'lish — ko'paytirishning teskarisi (son uchburchagi).","Tuzoqlar: ko'paytma bo'yicha sonlarni topish; ikki noma'lumli misollar."],
 mist:["Yod olmagan ko'paytmani taxmin qiladi (7 · 8 = 54).","Ko'paytirish o'rniga qo'shadi (6 · 8 = 14).","Bo'lishni ko'paytirishga bog'lamaydi.","«Bir xonali» shartini e'tiborsiz qoldiradi."],
 need:["Nuqtali massiv kartochkalari (6×7, 9×6 …).","Ko'paytirish jadvali plakati.","«Son uchburchagi» kartochkalari."],
 board:["Jadval: bilganlar yashil, 10 ta yangi to'q sariq.","<span class='w2'>6 · 7 = 5 · 7 + 7 = 42</span>.","<span class='w2'>9 · 6 = 60 − 6 = 54</span>.","<span class='w2'>8 · 6: 12 → 24 → 48</span>.","<span class='w2'>7 · 8 = 40 + 16 = 56</span>.","Uchburchak: <span class='w2'>7, 8, 56</span> → 4 ta misol."]};
