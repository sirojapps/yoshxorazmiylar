var CODE='4E2',TITLE='4-sinf · Harakat: tezlik, vaqt, masofa';
function e2Car(x,y,col){var g=E('g',{transform:'translate('+(x-14)+','+(y-22)+')'},S.g);E('rect',{x:0,y:4,width:28,height:10,rx:3,fill:col||C.bad},g);E('rect',{x:6,y:0,width:14,height:7,rx:2,fill:col||C.bad},g);E('circle',{cx:7,cy:15,r:3,fill:'#33475b'},g);E('circle',{cx:21,cy:15,r:3,fill:'#33475b'},g)}
function e2Road(h,carAt,lab){var X=w3Ray(0,300,60,[],{all:1,y:110});for(var i=0;i<h;i++)w3Jump(i*60,(i+1)*60,'1 soat',C.ok,110,30);e2Car(X(carAt),110);if(lab)T(S.g,X(carAt),60,lab,{'font-size':12,'font-weight':800,fill:C.bad});T(S.g,346,98,'km',{'font-size':11,fill:'#5b6b7b'})}
var P1=[function(){e2Road(0,0);w3Msg('Mashina tezligi 60 km/soat — har soatda 60 km yuradi')},
 function(){e2Road(1,60);w3Msg('1 soatda: 60 km')},
 function(){e2Road(2,120);w3Msg('2 soatda: 60 + 60 = 120 km')},
 function(){e2Road(3,180);w3Msg('3 soatda: 60 · 3 = <b>180 km</b>.  s = v · t')}];
var P6=[function(){var X=w3Ray(0,320,40,[[0,'A',C.blue]],{all:1,y:110});w3Msg('Yo‘l ikki qismdan iborat')},
 function(){var X=w3Ray(0,320,40,[[0,'A',C.blue],[140,'140',C.ok]],{all:1,y:110});w3Jump(0,140,'2 soat · 70',C.ok,110,34);w3Msg('1-qism: 70 · 2 = <b>140 km</b>')},
 function(){var X=w3Ray(0,320,40,[[0,'A',C.blue],[140,'140',C.ok],[320,'320',C.bad]],{all:1,y:110});w3Jump(0,140,'2 soat · 70',C.ok,110,34);w3Jump(140,320,'3 soat · 60',C.bad,110,34);w3Msg('2-qism: 60 · 3 = 180 km. Jami: 140 + 180 = <b>320 km</b>')}];
var STEPS=[
{h:"Tezlik — 1 soatdagi yo'l",sum:"60 km/soat — har soatda 60 km. 3 soatda: s = v · t = 60 · 3 = 180 km.",a:"m01",
 start:w4St(P1),fin:w4Fin(P1),
 html:"<p><b>Tezlik</b> — vaqt birligida (1 soatda, 1 minutda) bosib o'tiladigan masofa. «60 km/soat» — «soatiga 60 km» deb o'qiladi. Kuzating:</p>",btns:[phaser(P1)],
 after:"<p>Uchta kattalik: <b>s</b> — masofa, <b>v</b> — tezlik, <b>t</b> — vaqt. Asosiy formula: <b>s = v · t</b>. Undan: <b>v = s : t</b>, <b>t = s : v</b>.</p>",
 q:{t:"Mashina 60 km/soat tezlikda 3 soat yurdi. Qancha yo'l bosdi?",opts:["180 km","63 km","20 km","57 km"],ok:0,why:"60 · 3 = 180.",hint:"s = v · t.",full:"s = 60 · 3 = 180 km. «20» — 60 : 3 (bo'lish xatosi); «63» — qo'shish."},
 tn:"Sinf xonasida «1 qadam — 1 sekund» o'yini: bola 5 sekundda necha qadam yuradi? Tezlik tushunchasini tanada his qilsin."},
{h:"Tezlikni topish",sum:"240 km ni 4 soatda bosdi: v = s : t = 240 : 4 = 60 km/soat.",a:"m02",
 start:function(){w3Expr(['s = 240 km,  t = 4 soat','v = ?']);w3Msg('Qaysi amal?')},fin:function(){w3Expr(['v = s : t','v = 240 : 4 = {60} km/soat']);w3Msg('Tezlik — 1 soatga to‘g‘ri keladigan yo‘l')},
 html:"<p>Avtobus 240 km yo'lni 4 soatda bosdi. Tezligini qanday topamiz?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['240 : 4','240 · 4','240 − 4'],'240 : 4',function(){w3Expr(['v = s : t','v = 240 : 4 = {60} km/soat']);w3Msg('To‘g‘ri: 1 soatga 60 km');done()},{'240 · 4':'960 km/soat — samolyotdan ham tez! Javob ma’nosiz','240 − 4':'Kilometrdan soatni ayirib bo‘lmaydi — birliklar har xil'})},
 after:"<p>Mantiq: 4 soatda 240 km bo'lsa, 1 soatda 4 marta kam — 240 : 4. Birlik: km : soat = <b>km/soat</b>.</p>",
 q:{t:"Poyezd 480 km ni 6 soatda bosdi. Uning tezligi?",opts:["80 km/soat","2880 km/soat","486 km/soat","474 km/soat"],ok:0,why:"480 : 6 = 80.",hint:"v = s : t.",full:"v = 480 : 6 = 80 km/soat. «2880» — ko'paytirish xatosi."},
 tn:"Bolalar s–v–t uchburchagini (4D3 darsidan) eslasin: v ni yoping — s : t qoladi."},
{h:"Vaqtni topish",sum:"360 km, 90 km/soat: t = s : v = 360 : 90 = 4 soat.",a:"m03",
 start:function(){w3Expr(['s = 360 km,  v = 90 km/soat','t = ?']);w3Msg('Necha soat kerak?')},fin:function(){w3Expr(['t = s : v','t = 360 : 90 = {4} soat']);w3Msg('360 ichida 90 necha marta bor?')},
 html:"<p>Mashina 360 km ni 90 km/soat tezlikda bosib o'tdi. Necha soat yurdi?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['4 soat','5 soat','270 soat'],'4 soat',function(){w3Expr(['t = s : v','t = 360 : 90 = {4} soat']);w3Msg('To‘g‘ri! Tekshiruv: 90 · 4 = 360 ✓');done()},{'5 soat':'90 · 5 = 450 km — ko‘p bo‘ldi','270 soat':'360 − 90 = 270 — ayirish emas, bo‘lish kerak'})},
 after:"<p>Vaqt = masofa : tezlik. Savol: «360 km ichida 90 km li bo'lak necha marta bor?» — 4 marta, demak 4 soat. Doim tekshiring: v · t = s.</p>",
 q:{t:"Samolyot tezligi 900 km/soat. 2700 km ni necha soatda uchib o'tadi?",opts:["3 soat","30 soat","1800 soat","4 soat"],ok:0,why:"2700 : 900 = 3.",hint:"t = s : v.",full:"2700 : 900 = 3 soat. Tekshiruv: 900 · 3 = 2700 ✓. «1800» — ayirish."},
 tn:"Xaritada ikki shahar orasidagi masofani ko'rsating va «mashinada necha soat?» deb so'rang."},
{h:"Birliklar: minut va soat",sum:"1 minutda 1 km → 1 soatda (60 minut) 60 km: tezlik 60 km/soat.",a:"m04",
 start:function(){w3Expr(['1 minutda — 1 km','1 soatda — ?']);w3Msg('1 soat = 60 minut')},fin:function(){w3Expr(['1 soat = 60 minut','60 · 1 km = {60} km','v = 60 km/soat']);w3Msg('Birliklarni bir xil qilish — birinchi ish!')},
 html:"<p>Mashina har <b>minutda 1 km</b> yuradi. Uning tezligi soatiga necha km?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['60 km/soat','1 km/soat','100 km/soat'],'60 km/soat',function(){w3Expr(['1 soat = 60 minut','60 · 1 km = {60} km','v = 60 km/soat']);w3Msg('To‘g‘ri!');done()},{'1 km/soat':'Bu piyodadan ham sekin! 1 km — bir minutda, soatda emas','100 km/soat':'1 soatda 100 minut emas, 60 minut bor'})},
 after:"<p>Tuzoq: tezlik minutda, vaqt soatda (yoki aksincha) berilsa — avval <b>birliklarni bir xil</b> qiling. Masalan: piyoda 4 km/soat tezlikda 2 soat 30 minut yursa: 2 soatda 8 km, yarim soatda 2 km — jami 10 km.</p>",
 q:{t:"Ali 80 m/min tezlikda yuradi. Maktabgacha 15 minutda yetadi. Uydan maktabgacha masofa?",opts:["1200 m","95 m","1500 m","120 m"],ok:0,why:"80 · 15 = 1200 m.",hint:"s = v · t, birliklar mos (m/min va min).",full:"80 · 15 = 1200 m = 1 km 200 m. «95» — qo'shish."},
 tn:"Sekundomer bilan bola sinf bo'ylab 20 m ni necha sekundda yurishini o'lchang — tezlikni m/sek da hisoblang."},
{h:"Tezliklarni taqqoslash",sum:"Velosipedchi 3 soatda 45 km (15 km/soat), piyoda 2 soatda 10 km (5 km/soat): velosipedchi 3 marta tez.",a:"m05",
 start:function(){w3Expr(['velosipedchi: 45 km — 3 soat','piyoda: 10 km — 2 soat']);w3Msg('Kim necha marta tez?')},fin:function(){w3Expr(['45 : 3 = {15} km/soat','10 : 2 = {5} km/soat','15 : 5 = {3} marta']);w3Msg('Taqqoslash uchun avval tezliklarni toping')},
 html:"<p>Velosipedchi 3 soatda 45 km, piyoda 2 soatda 10 km yurdi. Velosipedchi piyodadan necha marta tez?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['3 marta','35 marta','4 marta'],'3 marta',function(){w3Expr(['45 : 3 = {15} km/soat','10 : 2 = {5} km/soat','15 : 5 = {3} marta']);w3Msg('To‘g‘ri!');done()},{'35 marta':'45 − 10 = 35 — bu masofalar farqi, tezliklar nisbati emas','4 marta':'45 : 10 ≈ 4 — lekin vaqtlar har xil! Avval tezliklarni toping'})},
 after:"<p>Masofalarni to'g'ridan-to'g'ri taqqoslab bo'lmaydi, chunki vaqtlar har xil. Avval har birining <b>tezligini</b> (1 soatdagi yo'lini) topamiz — keyin «necha marta» yoki «qanchaga» savoliga javob beramiz.</p>",
 q:{t:"Piyoda 2 soatda 8 km yuradi. Velosipedchi undan 3 marta tez. Velosipedchi 3 soatda qancha yo'l bosadi?",opts:["36 km","24 km","12 km","72 km"],ok:0,why:"Piyoda 4 km/soat, velosipedchi 12 km/soat, 3 soatda 36 km.",hint:"Avval piyoda tezligi.",full:"8 : 2 = 4 km/soat; 4 · 3 = 12 km/soat; 12 · 3 = 36 km. «24» — 8 · 3 (vaqtni hisobga olmaslik)."},
 tn:"Hayvonlar tezligi kartochkalari bilan «kim tezroq?» o'yinini o'tkazing."},
{h:"Ikki qismli yo'l",sum:"2 soat 70 km/soat + 3 soat 60 km/soat: 140 + 180 = 320 km.",a:"m06",
 start:w4St(P6),fin:w4Fin(P6),
 html:"<p>«Avtobus 2 soat 70 km/soat tezlikda, keyin 3 soat 60 km/soat tezlikda yurdi. Jami qancha yo'l bosdi?» Son nurida kuzating:</p>",btns:[phaser(P6)],
 after:"<p>Har qismni alohida hisoblab, qo'shamiz: <b>70 · 2 + 60 · 3 = 320 km</b>. Xato: (70 + 60) · (2 + 3) = 650 — tezliklar va vaqtlar aralashib ketadi.</p>",
 q:{t:"Avtobus 2 soat 70 km/soat, keyin 3 soat 60 km/soat tezlikda yurdi. Jami yo'l?",opts:["320 km","650 km","130 km","390 km"],ok:0,why:"140 + 180 = 320.",hint:"Har qism — o'z tezligi bilan.",full:"70 · 2 = 140, 60 · 3 = 180, jami 320. «650» — (70 + 60) · 5; «390» — 130 · 3."},
 tn:"Doskaga yo'lni ikki rangda chizing: har qism uchun s = v · t ni alohida yozing."},
{h:"Tuzoq: o'rtacha tezlik",sum:"320 km ni 5 soatda: o'rtacha tezlik 320 : 5 = 64 km/soat, (70 + 60) : 2 = 65 emas!",a:"m07",
 start:function(){w3Expr(['2 soat · 70 + 3 soat · 60','o‘rtacha tezlik = ?']);w3Msg('65 mi yoki boshqa son?')},fin:function(){w3Expr(['jami yo‘l: 320 km','jami vaqt: 5 soat','v = 320 : 5 = {64} km/soat']);w3Msg('O‘rtacha tezlik = jami yo‘l : jami vaqt')},
 html:"<p>Oldingi avtobusning <b>o'rtacha tezligi</b> qancha?</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['64 km/soat','65 km/soat','130 km/soat'],'64 km/soat',function(){w3Expr(['jami yo‘l: 320 km','jami vaqt: 5 soat','v = 320 : 5 = {64} km/soat']);w3Msg('To‘g‘ri!');done()},{'65 km/soat':'(70 + 60) : 2 = 65 — lekin avtobus 60 tezlikda ko‘proq vaqt yurdi! Jami yo‘l : jami vaqt','130 km/soat':'Tezliklarni qo‘shib bo‘lmaydi'})},
 after:"<p><b>O'rtacha tezlik = jami yo'l : jami vaqt</b>. Tezliklarning o'rtachasi faqat har bir tezlikda <b>bir xil vaqt</b> yurilganda to'g'ri chiqadi. Bu yerda 60 tezlikda ko'proq (3 soat) yurilgani uchun o'rtacha 65 dan kam — 64.</p>",
 q:{t:"Mashina A dan B ga 3 soatda 80 km/soat tezlikda bordi. Qaytishda 4 soat ketdi. Qaytishdagi tezligi?",opts:["60 km/soat","80 km/soat","320 km/soat","70 km/soat"],ok:0,why:"Yo'l 240 km, 240 : 4 = 60.",hint:"Avval masofa: 80 · 3.",full:"AB = 80 · 3 = 240 km. Qaytish: 240 : 4 = 60 km/soat. «70» — tezliklar o'rtachasi deb taxmin qilish."},
 tn:"Hayotiy misol: shahar ichida sekin, trassada tez — o'rtacha tezlik qanday hisoblanadi?"},
{h:"Son nurida harakat",sum:"75 km/soat, 4 soatdan keyin: 75 · 4 = 300 km belgisida.",a:"m08",
 start:function(){S.w4ok=0;var dr=function(m){w3Ray(0,400,50,m||[[0,'0',C.blue]],{all:1,y:110,tap:function(v){if(S.w4ok)return;if(v===300){S.w4ok=1;dr([[0,'0',C.blue],[300,'300',C.ok]]);w3Jump(0,300,'4 soat · 75',C.ok,110,40);w3Msg('To‘g‘ri: 75 · 4 = <b>300 km</b>');if(S.w4done)S.w4done()}else{w3Msg(v+' km — noto‘g‘ri. 1 soatda 75 km, 4 soatda-chi? 75 · 4 = ?')}}});e2Car(S.X(0),110)};S.w4dr=dr;dr();w3Msg('Mashina 0 dan 75 km/soat tezlikda chiqdi. 4 soatdan keyin qayerda? Nuqtani bosing')},
 fin:function(){w3Ray(0,400,50,[[0,'0',C.blue],[300,'300',C.ok]],{all:1,y:110});w3Jump(0,300,'4 soat · 75',C.ok,110,40);w3Msg('75 · 4 = 300 km')},
 html:"<p>Son nurida mashina 0 dan <b>75 km/soat</b> tezlikda yo'lga chiqdi. <b>4 soatdan</b> keyin u qayerda bo'ladi? Nurdagi nuqtani bosing:</p>",
 act:function(c,done){S.w4done=done;if(S.w4ok)done()},
 after:"<p>Son nuri — harakat masalalarining eng yaxshi «xaritasi». Keyingi mavzuda (qarama-qarshi va quvlash harakati) ikki mashina bitta nurda harakat qiladi!</p>",
 q:{t:"A shahardan soat 8:00 da mashina chiqdi. Tezligi 75 km/soat, B gacha 300 km. Soat nechada yetib boradi?",opts:["12:00","11:00","4:00","12:30"],ok:0,why:"300 : 75 = 4 soat; 8 + 4 = 12.",hint:"Avval yo'l vaqti.",full:"t = 300 : 75 = 4 soat, 8:00 + 4 soat = 12:00. «4:00» — yo'l vaqtini soat deb berish."},
 tn:"Polga lenta-nur yopishtiring, o'yinchoq mashina bilan har «soat»da 75 qadam (yoki katak) siljiting."},
{h:"Bilasizmi? Eng katta tezlik",sum:"Yorug'lik sekundiga taxminan 300 000 km yuradi — Yerni sekundiga 7 martadan ko'proq aylanib chiqa oladi.",a:"m09",
 start:function(){w3Expr(['yorug‘lik: ≈ 300 000 km/sek']);w3Msg('Olamdagi eng katta tezlik')},fin:function(){w3Expr(['yorug‘lik: ≈ 300 000 km/sek']);w3Msg('Olamdagi eng katta tezlik')},
 html:"<p>📜 <b>Yorug'lik</b> bo'shliqda sekundiga taxminan <b>300 000 km</b> yuradi — bu olamdagi eng katta tezlik. Ekvator bo'ylab Yer aylanasi taxminan 40 000 km, demak yorug'lik 1 sekundda Yerni 7 martadan ko'proq aylanib chiqa oladi!</p><p>⭐ Quyosh nuri Yerga taxminan <b>8 minutda</b> yetib keladi. Biz Quyoshni doim 8 minut «oldingi» holida ko'ramiz.</p>",
 tn:"300 000 : 40 000 = 7 (qoldiq 20 000) — bolalar o'zlari hisoblasin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['s = v · t','v = s : t','t = s : v']);w3Msg('Harakat formulalari')},fin:function(){w3Expr(['s = v · t','v = s : t','t = s : v']);w3Msg('Harakat formulalari')},
 html:"<div class='memo'><ul><li>s = v · t; v = s : t; t = s : v.</li><li>Tezlik birligi: km/soat, m/min, m/sek. Avval birliklarni bir xil qiling (1 soat = 60 minut).</li><li>Tezliklarni taqqoslashdan oldin har birini 1 soatga keltiring.</li><li>Yo'l bir necha qismdan iborat bo'lsa — har qismni alohida hisoblang.</li><li>O'rtacha tezlik = jami yo'l : jami vaqt (tezliklar o'rtachasi emas!).</li><li>Tekshiruv: v · t = s; javob ma'nolimi (piyoda 100 km/soat yurmaydi!).</li></ul></div>",
 tn:"Kartochka 4E3, 4E9, 4E13 (harakat turlari) uchun asos."}
];
var PROBS=[
{t:"Mashina 60 km/soat tezlikda 3 soat yurdi. Qancha yo'l bosdi?",o:["180 km","63 km","20 km","57 km"],k:0,s:"60 · 3 = 180."},
{t:"Avtobus 240 km ni 4 soatda bosdi. Uning tezligi?",o:["60 km/soat","960 km/soat","244 km/soat","236 km/soat"],k:0,s:"240 : 4 = 60."},
{t:"Mashina 360 km ni 90 km/soat tezlikda bosdi. Necha soat yurdi?",o:["4 soat","5 soat","270 soat","450 soat"],k:0,s:"360 : 90 = 4."},
{t:"Velosipedchi 3 soatda 45 km, piyoda 2 soatda 10 km yurdi. Velosipedchi necha marta tez?",o:["3 marta","35 marta","4 marta","9 marta"],k:0,s:"15 : 5 = 3."},
{t:"Avtobus 2 soat 70 km/soat, keyin 3 soat 60 km/soat tezlikda yurdi. Jami yo'l?",o:["320 km","130 km","650 km","390 km"],k:0,s:"140 + 180 = 320."},
{t:"Avtobus 320 km ni 5 soatda bosdi (2 soat 70 km/soat, 3 soat 60 km/soat). O'rtacha tezligi?",o:["64 km/soat","65 km/soat","130 km/soat","1600 km/soat"],k:0,s:"320 : 5 = 64."},
{t:"Mashina har minutda 1 km yuradi. Uning tezligi?",o:["60 km/soat","1 km/soat","100 km/soat","3600 km/soat"],k:0,s:"1 soat = 60 minut → 60 km."},
{t:"Piyoda 4 km/soat tezlikda 2 soat 30 minut yurdi. Qancha yo'l bosdi?",o:["10 km","8 km","9 km","12 km"],k:0,s:"2 soatda 8 km, yarim soatda 2 km."},
{t:"Poyezd 480 km ni 6 soatda bosdi. Shu tezlikda 3 soatda qancha yo'l bosadi?",o:["240 km","160 km","80 km","1440 km"],k:0,s:"80 · 3 = 240."},
{t:"Samolyot tezligi 900 km/soat. 2700 km ni necha soatda uchib o'tadi?",o:["3 soat","30 soat","1800 soat","4 soat"],k:0,s:"2700 : 900 = 3."},
{t:"Velosipedchi 15 km/soat tezlikda 75 km yo'l bosishi kerak. Har 2 soat yurgach 1 soat dam oladi. Butun yo'lga necha soat ketadi?",o:["7 soat","5 soat","8 soat","6 soat"],k:0,s:"Yurish 5 soat; 2- va 4-soatdan keyin 2 marta dam: 5 + 2 = 7."},
{t:"Ali 80 m/min tezlikda yuradi va maktabga 15 minutda yetadi. Masofa?",o:["1200 m","95 m","1500 m","120 m"],k:0,s:"80 · 15 = 1200."},
{t:"Mashina soat 8:00 da chiqdi, tezligi 75 km/soat, manzilgacha 300 km. Soat nechada yetadi?",o:["12:00","11:00","4:00","12:30"],k:0,s:"300 : 75 = 4; 8 + 4 = 12."},
{t:"Tezlik 2 marta oshsa, o'sha masofani bosish uchun vaqt qanday o'zgaradi?",o:["2 marta kamayadi","2 marta oshadi","O'zgarmaydi","2 soatga kamayadi"],k:0,s:"t = s : v — v ikki baravar bo'lsa, t ikki baravar kamayadi."},
{t:"Mashina 4 soat yurdi: 1-soatda 70 km, keyingi 3 soatda soatiga 60 km. Jami yo'l?",o:["250 km","260 km","280 km","130 km"],k:0,s:"70 + 180 = 250."},
{t:"Salyangoz minutiga 3 sm yuradi. 1 soatda qancha yo'l bosadi?",o:["1 m 80 sm","18 sm","63 sm","3 m"],k:0,s:"3 · 60 = 180 sm."},
{t:"Piyoda 2 soatda 8 km yuradi. Velosipedchi undan 3 marta tez. Velosipedchi 3 soatda qancha yo'l bosadi?",o:["36 km","24 km","12 km","72 km"],k:0,s:"4 · 3 = 12 km/soat; 12 · 3 = 36."},
{t:"Avtobus 3 soatda 195 km yurdi. Shu tezlikda 5 soatda qancha yuradi?",o:["325 km","585 km","390 km","260 km"],k:0,s:"195 : 3 = 65; 65 · 5 = 325."},
{t:"Mashina A dan B ga 3 soatda 80 km/soat tezlikda bordi. Qaytishda 4 soat ketdi. Qaytishdagi tezligi?",o:["60 km/soat","80 km/soat","320 km/soat","70 km/soat"],k:0,s:"240 : 4 = 60."},
{t:"Yorug'lik sekundiga taxminan 300 000 km yuradi. 5 sekundda qancha yo'l bosadi?",o:["1 500 000 km","60 000 km","150 000 km","15 000 000 km"],k:0,s:"300 000 · 5 = 1 500 000."}
];
function PRACT_STAGE(){d3TriE()}
function d3TriE(){clear();var g=S.g;E('path',{d:'M180 14 L290 150 L70 150 Z',fill:'#fff7e6',stroke:'#8a5a24','stroke-width':2.5},g);E('line',{x1:110,y1:100,x2:250,y2:100,stroke:'#8a5a24','stroke-width':2},g);E('line',{x1:180,y1:100,x2:180,y2:150,stroke:'#8a5a24','stroke-width':2},g);[['s',180,78],['v',140,135],['t',220,135]].forEach(function(z){T(g,z[1],z[2],z[0],{'font-size':26,'font-weight':800,fill:'#1d2b3a'})});w3Msg('s = v · t,  v = s : t,  t = s : v')}
var PREP_DATA={teach:["Tezlik tushunchasi va birliklari (km/soat, m/min).","s = v · t formulasi va undan v, t ni topish.","Tezliklarni taqqoslash; ikki qismli yo'l.","O'rtacha tezlik; son nurida harakatni tasvirlash."],
 mist:["v = s · t deb ko'paytiradi.","Minut va soatni aralashtirib hisoblaydi.","Masofalarni taqqoslab, tezlikni taqqosladim deb o'ylaydi.","O'rtacha tezlikni tezliklarning o'rtachasi deb oladi."],
 need:["Polga yopishtirilgan lenta-nur va o'yinchoq mashina.","Sekundomer (telefon)."],
 board:["<span class='w2'>s = v · t: 60 · 3 = 180 km</span>.","<span class='w2'>v = s : t: 240 : 4 = 60 km/soat</span>.","<span class='w2'>t = s : v: 360 : 90 = 4 soat</span>.","<span class='w2'>70 · 2 + 60 · 3 = 320 km</span>.","<span class='w2'>o'rtacha: 320 : 5 = 64 km/soat</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
