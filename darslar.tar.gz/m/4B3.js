var CODE='4B3',TITLE='4-sinf · Qulay usulda hisoblash';
function a43pair(nums,pairs,title){clear();var g=S.g,n=nums.length,cw=Math.min(80,340/n),x0=180-n*cw/2,cols=['#1e8e5a','#1f6fb2','#e07a2f'];T(g,180,26,title||'',{'font-size':13,'font-weight':800,fill:C.blue});
 nums.forEach(function(v,i){var pi=-1;(pairs||[]).forEach(function(p,k){if(p[0]===i||p[1]===i)pi=k});E('rect',{x:x0+i*cw+4,y:52,width:cw-8,height:42,rx:9,fill:pi>=0?'#e6f6ee':'#fff',stroke:pi>=0?cols[pi]:'#c9d3dd','stroke-width':2},g);T(g,x0+i*cw+cw/2,80,String(v),{'font-size':cw<45?13:(cw<70?15:18),'font-weight':800,fill:'#1d2b3a'})});
 (pairs||[]).forEach(function(p,k){var a=x0+p[0]*cw+cw/2,b=x0+p[1]*cw+cw/2,yy=96;E('path',{d:'M'+a+' '+yy+' Q'+(a+b)/2+' '+(yy+40+k*10)+' '+b+' '+yy,fill:'none',stroke:cols[k],'stroke-width':2.4},g);if(p[2])T(g,(a+b)/2,yy+34+k*10,p[2],{'font-size':13,'font-weight':800,fill:cols[k]})})}
var STEPS=[
{h:"Do'st sonlarni juftlash",sum:"2 637 + 1 485 + 363 + 515 = (2 637 + 363) + (1 485 + 515) = 3 000 + 2 000 = 5 000.",a:"m01",
 start:function(){a43pair(['2 637','1 485','363','515'],[],'Yumaloq son beradigan juftlarni toping');msg('Oxirgi raqamlarga qarang: 7 + 3, 5 + 5')},fin:function(){a43pair(['2 637','1 485','363','515'],[[0,2,'3 000'],[1,3,'2 000']],'3 000 + 2 000 = 5 000');msg('Javob: <b>5 000</b>')},
 html:"<p>2 637 + 1 485 + 363 + 515 ni hisoblang. Qaysi juftlash qulay?</p>",
 btns:a4ch(["(2 637 + 363) + (1 485 + 515)","(2 637 + 1 485) + (363 + 515)","(2 637 + 515) + (1 485 + 363)"],0,function(){a43pair(['2 637','1 485','363','515'],[[0,2,'3 000'],[1,3,'2 000']],'3 000 + 2 000 = 5 000');msg('637 + 363 = 1 000, 485 + 515 = 1 000 → <b>5 000</b>')},function(i){msg(i===1?'Tartib bilan qo‘shish — qiyin: 4 122 + 878':'2 637 + 515 = 3 152 — yumaloq emas')}),
 after:"<p>Qo'shishda sonlarning <b>o'rnini almashtirish</b> va <b>guruhlash</b> mumkin — yig'indi o'zgarmaydi. «Do'st» juftlar: oxirgi raqamlari 10 ga, oxirgi ikki raqami 100 ga, oxirgi uch raqami 1 000 ga to'ldiradi.</p>",
 q:{t:"348 + 1 275 + 652 + 725 = ?",opts:["3 000","2 900","3 100","2 000"],ok:0,why:"(348 + 652) + (1 275 + 725) = 1 000 + 2 000.",hint:"348 ning do'sti qaysi?",full:"348 + 652 = 1 000, 1 275 + 725 = 2 000. Jami 3 000."},
 tn:"«Do'st sonlar» kartochkalari: juftini topgan bola ularni bir-biriga qo'yadi (Yaponiya — 10 ni yasash)."},
{h:"Yaxlitlab, keyin tuzatish",sum:"4 675 + 2 998 = 4 675 + 3 000 − 2 = 7 673.",a:"m02",
 start:function(){bqLine(4600,7800,[],[[4675,C.blue]],{step:400});msg('4 675 + 2 998 = ? &nbsp; 2 998 — 3 000 dan atigi 2 kam')},
 fin:function(){bqLine(4600,7800,[[4675,7675,'+3 000',C.ok],[7675,7673,'',C.bad]],[[7673,C.ok]],{step:400});msg('4 675 + 3 000 − 2 = <b>7 673</b>')},
 html:"<p>4 675 + 2 998. 2 998 ni yumaloq songa aylantirsak osonlashadi. Qanday?</p>",
 btns:a4ch(["+ 3 000, keyin − 2","+ 3 000, keyin + 2","+ 2 000, keyin + 98"],0,function(){STEPS[1].fin()},function(i){msg(i===1?'3 000 — 2 ta ortiqcha qo‘shildi, ularni olib tashlash kerak':'Bu ham mumkin, lekin qiyinroq: + 3 000 − 2 qulayroq')}),g3:1,
 after:"<p><b>Ko'proq qo'shsangiz — ortiqchasini ayiring</b>. Ayirishda teskarisi: 8 350 − 1 997 = 8 350 − 2 000 + 3 = 6 353 (ko'proq ayirdik — qaytarib qo'shamiz).</p>",
 q:{t:"8 350 − 1 997 = ?",opts:["6 353","6 347","6 350","10 347"],ok:0,why:"8 350 − 2 000 + 3.",hint:"1 997 = 2 000 − 3. Ko'proq ayirdik…",full:"8 350 − 2 000 = 6 350. 3 ta ortiqcha ayirdik — qaytaramiz: 6 353. «6 347» — tuzatishni noto'g'ri tomonga qilish."},
 tn:"Son o'qida: katta sakrash, keyin kichik qaytish (Gollandiya RME)."},
{h:"Ayirmani saqlab siljitish",sum:"7 003 − 2 997 = 7 006 − 3 000 = 4 006: ikkalasini bir xil oshirsak, ayirma o'zgarmaydi.",a:"m03",
 start:function(){bqLine(2000,8000,[[2997,7003,'7 003 − 2 997 = ?',C.blue]],[],{step:1000});msg('Ayirma — masofa. Ikkala uchini bir xil sursak, masofa o‘zgarmaydi')},
 fin:function(){bqLine(2000,8000,[[3000,7006,'7 006 − 3 000 = 4 006',C.ok]],[],{step:1000});msg('Ikkalasiga +3: <b>4 006</b>')},
 html:"<p>7 003 − 2 997. Qarzlar ko'p, noqulay. Ikkala songa ham 3 qo'shsak nima bo'ladi?</p>",
 btns:a4ch(["7 006 − 3 000 = 4 006","7 006 − 3 000 = 4 006 − 3 = 4 003","7 003 − 3 000 = 4 003"],0,function(){STEPS[2].fin()},function(i){msg(i===1?'Ikkalasini bir xil o‘zgartirdik — ayirma o‘zgarmaydi, tuzatish kerak emas!':'Faqat ayriluvchini o‘zgartirsangiz — tuzatish kerak: 4 003 + 3')}),
 after:"<p>Qoida: kamayuvchi va ayriluvchini <b>bir xil songa</b> oshirsak yoki kamaytirsak — ayirma o'zgarmaydi (yoshlar farqi har yili bir xil!). Yumaloq ayriluvchi yasaymiz.</p>",
 q:{t:"10 004 − 6 996 = ?",opts:["3 008","3 000","3 012","4 008"],ok:0,why:"10 008 − 7 000 = 3 008.",hint:"Ikkalasiga 4 qo'shing.",full:"10 004 + 4 = 10 008; 6 996 + 4 = 7 000. 10 008 − 7 000 = 3 008."},
 tn:"Yoshlar farqi misoli: aka 12, uka 7 — 5 yildan keyin ham farq 5."},
{h:"Sondan yig'indini ayirish",sum:"8 450 − (450 + 1 279) = 8 000 − 1 279 = 6 721.",a:"m04",
 start:function(){bqExpr(['8 450 − ([450] + 1 279)','qaysi qo‘shiluvchini avval ayirish qulay?']);msg('Sondan yig‘indini ayirish — har bir qo‘shiluvchini navbat bilan ayirish')},fin:function(){bqExpr(['8 450 − 450 − 1 279','= 8 000 − 1 279','= 6 721']);msg('<b>6 721</b>')},
 html:"<p>8 450 − (450 + 1 279). Qavsni ochmasdan qulay usul bormi?</p>",
 btns:a4ch(["(8 450 − 450) − 1 279","8 450 − 450 + 1 279","(8 450 − 1 279) + 450"],0,function(){STEPS[3].fin()},function(i){msg(i===1?'Yig‘indini ayirganda ikkala qo‘shiluvchi ham AYIRILADI':'Ikkinchi qo‘shiluvchi ham ayirilishi kerak, qo‘shilmaydi')}),
 after:"<p>Qoida: a − (b + c) = a − b − c. Yig'indidan son ayirish: (a + b) − c = (a − c) + b — qaysi qo'shiluvchidan ayirish oson bo'lsa, o'shandan. Masalan (3 760 + 2 425) − 760 = 3 000 + 2 425 = 5 425.</p>",
 q:{t:"(3 760 + 2 425) − 760 = ?",opts:["5 425","6 945","4 665","5 525"],ok:0,why:"(3 760 − 760) + 2 425.",hint:"760 ni qaysi qo'shiluvchidan ayirish oson?",full:"3 760 − 760 = 3 000; 3 000 + 2 425 = 5 425. «6 945» — 760 ni qo'shib yuborish."},
 tn:"Ifodalarni kartochkalarga yozib, «qavsni ochish» o'yini."},
{h:"Ko'paytirishda do'stlar: 25 · 4, 125 · 8",sum:"25 · 37 · 4 = (25 · 4) · 37 = 3 700.",a:"m05",
 start:function(){a43pair(['25','37','4'],[],'25 · 37 · 4 = ?');msg('25 · 4 = 100 — eng yaxshi do‘stlar')},fin:function(){a43pair(['25','37','4'],[[0,2,'100']],'100 · 37 = 3 700');msg('Javob: <b>3 700</b>')},
 html:"<p>25 · 37 · 4 ni og'zaki hisoblang:</p>",
 btns:a4ch(["3 700","925","370","37 000"],0,function(){STEPS[4].fin()},function(i){msg(i===1?'25 · 37 = 925 — davom eting… lekin 25 · 4 = 100 qulayroq':'25 · 4 = 100, 100 · 37 = ?')}),g2:1,
 after:"<p>Ko'paytirishda ham o'rin almashtirish va guruhlash mumkin. Eslab qoling: <b>25 · 4 = 100</b>, <b>125 · 8 = 1 000</b>, <b>50 · 2 = 100</b>, <b>250 · 4 = 1 000</b>, <b>20 · 5 = 100</b>.</p>",
 q:{t:"125 · 6 · 8 = ?",opts:["6 000","750","48 000","1 006"],ok:0,why:"(125 · 8) · 6 = 1 000 · 6.",hint:"125 ning do'sti qaysi?",full:"125 · 8 = 1 000; 1 000 · 6 = 6 000."},
 tn:"Do'st juftlar jadvalini daftarga yozib olish."},
{h:"99 ga ko'paytirish",sum:"48 · 99 = 48 · 100 − 48 = 4 752.",a:"m06",
 start:function(){bqExpr(['48 · 99 = 48 · (100 − 1)','100 ta 48 dan bitta 48 kam']);msg('99 — 100 dan 1 kam')},fin:function(){bqExpr(['48 · 99 = 48 · 100 − 48','= 4 800 − 48','= 4 752']);msg('<b>4 752</b>')},
 html:"<p>48 · 99 ni og'zaki hisoblang. 99 = 100 − 1 dan foydalaning:</p>",
 btns:a4ch(["4 752","4 800","4 848","4 751"],0,function(){STEPS[5].fin()},function(i){msg(i===1?'Bu 48 · 100. Bitta 48 ortiqcha!':i===2?'Ortiqcha 48 ni ayirish kerak, qo‘shish emas':'4 800 − 48 ni aniq hisoblang')}),g2:1,
 after:"<p>Taqsimot qonuni: a · (b − c) = a · b − a · c. Xuddi shunday: 36 · 101 = 3 600 + 36 = 3 636; 25 · 98 = 2 500 − 50 = 2 450.</p>",
 q:{t:"36 · 101 = ?",opts:["3 636","3 600","3 564","3 637"],ok:0,why:"36 · 100 + 36.",hint:"101 = 100 + 1.",full:"36 · 100 = 3 600; + 36 = 3 636. «3 564» — 36 · 99."},
 tn:"Maydon modeli: 48 × 100 to'rtburchakdan 48 × 1 polosani kesib olish."},
{h:"Umumiy ko'paytuvchini chiqarish",sum:"37 · 64 + 37 · 36 = 37 · (64 + 36) = 3 700.",a:"m07",
 start:function(){bqExpr(['[37] · 64 + [37] · 36','ikkalasida 37 bor']);msg('64 ta 37 va 36 ta 37 — jami nechta 37?')},fin:function(){bqExpr(['37 · (64 + 36)','= 37 · 100','= 3 700']);msg('<b>3 700</b>')},
 html:"<p>37 · 64 + 37 · 36. 64 ta 37 va yana 36 ta 37 — jami nechta 37?</p>",
 btns:a4ch(["100 ta → 3 700","100 ta → 370","28 ta → 1 036"],0,function(){STEPS[6].fin()},function(i){msg(i===1?'37 · 100 = 3 700 — ikkita nol!':'64 + 36 = 100, 64 − 36 emas')}),
 after:"<p>Teskari taqsimot: a · b + a · c = a · (b + c). Ayirishda ham: 54 · 127 − 54 · 27 = 54 · 100 = 5 400. Umumiy ko'paytuvchini ko'rish — olimpiada masalalarining kaliti.</p>",
 q:{t:"54 · 127 − 54 · 27 = ?",opts:["5 400","8 316","540","54 000"],ok:0,why:"54 · (127 − 27) = 54 · 100.",hint:"Umumiy ko'paytuvchi — 54.",full:"54 · (127 − 27) = 54 · 100 = 5 400."},
 tn:"Bank 4B3 qiyin turi. Massiv chizmasi: 37 qator, 64 va 36 ustun yonma-yon."},
{h:"Tuzoq: o'rtadagi son",sum:"296 + 297 + … + 304 (9 ta son) = 300 · 9 = 2 700.",a:"m08",
 start:function(){a43pair(['296','297','298','299','300','301','302','303','304'],[],'9 ta ketma-ket son');msg('Chetdagilarni juftlang: 296 + 304, 297 + 303, …')},fin:function(){a43pair(['296','297','298','299','300','301','302','303','304'],[[0,8,''],[1,7,''],[2,6,'']],'har juft 600 → 300 · 9 = 2 700');T(S.g,180,166,'296 + 304 = 297 + 303 = 298 + 302 = … = 600',{'font-size':12,'font-weight':800,fill:C.ok});msg('<b>2 700</b>')},
 html:"<p>296 + 297 + 298 + 299 + 300 + 301 + 302 + 303 + 304 = ? Bir qadamda hisoblang.</p>",
 btns:a4ch(["2 700","2 600","3 000","2 709"],0,function(){STEPS[7].fin()},function(i){msg(i===2?'10 ta emas, 9 ta son!':'Har bir juft 600, o‘rtada 300 — ya‘ni har son o‘rtacha 300')}),g2:1,
 after:"<p>Ketma-ket sonlarda <b>o'rtadagi son</b> hammasining «o'rtachasi»: 300 dan kam (296) va ko'p (304) bir-birini yopadi. Yig'indi = o'rtadagi son · sonlar soni.</p>",
 q:{t:"995 + 996 + 997 + 998 + 999 = ?",opts:["4 985","4 995","5 000","4 975"],ok:0,why:"997 · 5 = 4 985.",hint:"O'rtadagi son qaysi?",full:"O'rtadagi 997, 5 ta son: 997 · 5 = 4 985. Yoki: 5 000 − (5 + 4 + 3 + 2 + 1) = 4 985."},
 tn:"Gauss usuli bilan bog'lang (3B5)."},
{h:"Bilasizmi?",sum:"Yaponiyada bolalar soroban (cho't) bilan og'zaki hisobni mashq qiladi.",a:"m09",
 start:function(){a43pair(['25 · 4','125 · 8','50 · 2'],[],'Do‘st juftlar');msg('Yodda saqlang')},fin:function(){a43pair(['25 · 4','125 · 8','50 · 2'],[],'Do‘st juftlar');msg('Yodda saqlang')},
 html:"<p>🧮 Yaponiyada ko'p bolalar <b>soroban</b> — yog'och cho't bilan hisoblashni o'rganadi. Mashq qilganlar keyinchalik cho'tni ko'z oldiga keltirib, katta sonlarni <b>xayolan</b> juda tez qo'shadi. Bunday hisob bo'yicha musobaqalar ham o'tkaziladi.</p><p>🎯 Sirlari bitta: sonlarni «qulay bo'laklarga» ajratish — biz bugun o'rgangan usullar.</p>",
 tn:"Haftada 5 daqiqa og'zaki hisob «sprinti» — usullarni avtomatlashtiradi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){a43pair(['2 637','1 485','363','515'],[[0,2,'3 000'],[1,3,'2 000']],'Do‘st juftlar')},fin:function(){a43pair(['2 637','1 485','363','515'],[[0,2,'3 000'],[1,3,'2 000']],'Do‘st juftlar')},
 html:"<div class='memo'><ul><li>Do'st juftlar: 637 + 363 = 1 000; 25 · 4 = 100; 125 · 8 = 1 000.</li><li>+ 2 998 = + 3 000 − 2; − 1 997 = − 2 000 + 3.</li><li>Ayirmada ikkalasini bir xil o'zgartirish — javob o'zgarmaydi.</li><li>a − (b + c) = a − b − c.</li><li>48 · 99 = 4 800 − 48; 37 · 64 + 37 · 36 = 37 · 100.</li><li>Ketma-ket sonlar: o'rtadagi · soni.</li></ul></div>",
 tn:"Keyingi dars — natijani chamalash va tekshirish."}
];
var PROBS=[
{t:"2 637 + 1 485 + 363 + 515 = ?",o:["5 000","4 900","5 100","4 000"],k:0,s:"3 000 + 2 000."},
{t:"348 + 1 275 + 652 + 725 = ?",o:["3 000","2 900","3 100","2 000"],k:0,s:"1 000 + 2 000."},
{t:"4 675 + 2 998 = ?",o:["7 673","7 677","7 675","7 573"],k:0,s:"+ 3 000 − 2."},
{t:"8 350 − 1 997 = ?",o:["6 353","6 347","6 350","6 453"],k:0,s:"− 2 000 + 3."},
{t:"7 003 − 2 997 = ?",o:["4 006","4 000","4 003","4 016"],k:0,s:"7 006 − 3 000."},
{t:"10 004 − 6 996 = ?",o:["3 008","3 000","3 012","3 108"],k:0,s:"10 008 − 7 000."},
{t:"8 450 − (450 + 1 279) = ?",o:["6 721","9 279","6 821","7 721"],k:0,s:"8 000 − 1 279."},
{t:"(3 760 + 2 425) − 760 = ?",o:["5 425","6 945","4 665","5 525"],k:0,s:"3 000 + 2 425."},
{t:"25 · 37 · 4 = ?",o:["3 700","925","370","37 000"],k:0,s:"100 · 37."},
{t:"125 · 6 · 8 = ?",o:["6 000","750","48 000","600"],k:0,s:"1 000 · 6."},
{t:"48 · 99 = ?",o:["4 752","4 800","4 848","4 742"],k:0,s:"4 800 − 48."},
{t:"36 · 101 = ?",o:["3 636","3 600","3 564","3 606"],k:0,s:"3 600 + 36."},
{t:"37 · 64 + 37 · 36 = ?",o:["3 700","370","1 036","37 000"],k:0,s:"37 · 100."},
{t:"54 · 127 − 54 · 27 = ?",o:["5 400","8 316","540","54 000"],k:0,s:"54 · 100."},
{t:"296 + 297 + … + 304 = ?",o:["2 700","2 600","3 000","2 709"],k:0,s:"300 · 9."},
{t:"995 + 996 + 997 + 998 + 999 = ?",o:["4 985","4 995","5 000","4 975"],k:0,s:"997 · 5."},
{t:"25 · 98 = ?",o:["2 450","2 500","2 550","2 400"],k:0,s:"2 500 − 50."},
{t:"250 · 17 · 4 = ?",o:["17 000","1 700","4 250","170 000"],k:0,s:"1 000 · 17."},
{t:"9 999 + 999 + 99 + 9 = ?",o:["11 106","11 116","11 096","10 106"],k:0,s:"10 000 + 1 000 + 100 + 10 − 4."},
{t:"(1 000 − 1) + (1 000 − 2) + … + (1 000 − 9) = ?",o:["8 955","9 000","8 945","9 045"],k:0,s:"9 000 − 45."}
];
function PRACT_STAGE(){a43pair(['2 637','1 485','363','515'],[[0,2,'3 000'],[1,3,'2 000']],'Do‘st juftlar')}
var PREP_DATA={teach:["Qo'shish va ko'paytirishning o'rin almashtirish va guruhlash xossalari.","Yaxlitlab tuzatish, ayirmani saqlab siljitish, sondan yig'indini ayirish.","Taqsimot qonuni (99, 101, umumiy ko'paytuvchi), ketma-ket sonlar yig'indisi."],mist:["+ 2 998 da tuzatishni noto'g'ri tomonga qiladi.","Ayirmada ikkalasini oshirgach yana tuzatadi.","a − (b + c) ni a − b + c deb ochadi.","48 · 99 da 4 800 + 48 qiladi."],need:["Son kartochkalari, son o'qi, maydon modeli chizmasi."],board:["<span class='w2'>637 + 363 = 1 000</span>, <span class='w2'>25 · 4 = 100</span>, <span class='w2'>125 · 8 = 1 000</span>.","<span class='w2'>+ 2 998 = + 3 000 − 2</span>.","<span class='w2'>7 003 − 2 997 = 7 006 − 3 000</span>.","<span class='w2'>48 · 99 = 4 800 − 48</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
