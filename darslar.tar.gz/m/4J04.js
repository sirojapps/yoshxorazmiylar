var CODE='4J04',TITLE="4-sinf · Gugurt cho'plari bilan masalalar";
function g4Row(){clear();j3Mt(j3SqRow(4,60,50,44));T(S.g,148,128,'1 → 4,  2 → 7,  3 → 10,  4 → 13',{'font-size':13,'font-weight':800,fill:'#1d2b3a'});T(S.g,148,152,'20 ta kvadrat → ?',{'font-size':14,'font-weight':800,fill:C.bad})}
function g4Grid(){clear();j3Mt(j3SqGrid(3,3,40,22,40));T(S.g,270,70,'3×3: 24',{'font-size':15,'font-weight':800,fill:'#1d2b3a'});T(S.g,270,100,'4×4: ?',{'font-size':15,'font-weight':800,fill:C.bad})}
function g4Tri(){clear();var s=[],L=46,h=40,x0=40,y0=120;for(var i=0;i<6;i++){var up=i%2===0,x=x0+i*L/2;if(up){s.push([x,y0,x+L/2,y0-h]);s.push([x+L/2,y0-h,x+L,y0])}else{}}for(var k=0;k<3;k++)s.push([x0+k*L,y0,x0+(k+1)*L,y0]);for(var m=0;m<2;m++)s.push([x0+L/2+m*L,y0-h,x0+L/2+(m+1)*L,y0-h]);j3Mt(s);T(S.g,240,70,'5 ta: 11 cho‘p',{'font-size':14,'font-weight':800,fill:'#1d2b3a'});T(S.g,240,100,'15 ta: ?',{'font-size':14,'font-weight':800,fill:C.bad})}
function g4Cubes(n){clear();for(var i=0;i<n;i++)j4Cube(120+i*56,128,56,['#fff8ec','#f3e2c4','#fdf0da']);T(S.g,180,160,n===1?'1 kub karkasi: 12 cho‘p':n+' ta kub karkasi: ?',{'font-size':14,'font-weight':800,fill:n===1?'#1d2b3a':C.bad})}
function g4Eq(str,col){clear();j3Num(str,36,56,{w:26,h:52,gap:18,col:col})}
var STEPS=[
J4({h:"Kvadratlar qatori",sum:"1-kvadrat 4 cho'p, har keyingisi +3 (bitta tomon umumiy). n kvadrat: 3 · n + 1. 20 ta → 61.",a:"m01",
 s:g4Row,m:"Har yangi kvadratga faqat 3 ta cho‘p kerak — chap tomoni tayyor",f:function(){j3Lines(['1-kvadrat: 4 cho‘p','qolgan 19 tasi: 19 · 3 = 57','4 + 57 = [61]'],{fs:17,lh:34})},fm:"Yoki 3 · 20 + 1 = 61",
 html:"<p>Cho'plardan qatorasiga kvadratlar terilmoqda: 1 ta kvadrat — 4 cho'p, 2 ta — 7, 3 ta — 10. <b>20 ta</b> kvadratli qator uchun nechta cho'p kerak?</p>",
 ch:["80","60","61","63"],ok:2,bad:["4 · 20 = 80 — umumiy tomonlar ikki marta sanaldi","3 · 20 = 60 — eng birinchi chap tomonni unutdingiz","","Har yangi kvadratga 3 ta: 4 + 19 · 3 = ?"],
 after:"<p>Ikki usul: birinchi kvadrat 4 ta, qolgan 19 tasiga 3 tadan — 4 + 57 = 61. Yoki har kvadratga «Π» shakli (3 ta) va boshida bitta tik cho'p: 3 · 20 + 1 = 61. Formula: <b>3 · n + 1</b>.</p>",
 q:{t:"100 ta cho'p bor. Qatorasiga eng ko'pi bilan nechta kvadrat terish mumkin?",opts:["33","25","34","32"],ok:0,why:"3 · n + 1 ≤ 100 → n = 33 (3 · 33 + 1 = 100).",hint:"3 · n + 1 = 100 bo'lsa, n nechchi?",full:"100 − 1 = 99, 99 : 3 = 33. «25» — 100 : 4, umumiy tomonlarni hisobga olmaslik."},
 tn:"Haqiqiy cho'plar (yoki sanoq tayoqchalari) bilan 5 ta kvadratgacha terib, jadval to'ldiring."}),
J4({h:"Kvadrat to'r",sum:"n×n to'rda yotiq cho'plar (n + 1) · n, tik cho'plar ham shuncha: 2 · n · (n + 1). 4×4 → 40.",a:"m02",
 s:g4Grid,m:"Yotiq va tik cho‘plarni alohida sanang",f:function(){j3Lines(['yotiq: 5 qator · 4 = 20','tik: 5 ustun · 4 = 20','jami [40]'],{fs:18,lh:36})},fm:"4×4 to‘rda 5 ta yotiq va 5 ta tik chiziq",
 html:"<p>3×3 kvadrat to'r uchun 24 ta cho'p kerak. <b>4×4</b> to'r uchun-chi? Yotiq cho'plarni bir alohida, tik cho'plarni alohida sanang.</p>",
 ch:["32","40","64","36"],ok:1,bad:["16 · 2 = 32? Har katak 4 ta tomondan, lekin ular umumiy — chiziqlar bo‘yicha sanang","","16 · 4 = 64 — umumiy tomonlar ikki marta sanaldi","Yotiq chiziqlar 4 ta emas, 5 ta"],
 after:"<p>4 qatorli to'rda yotiq chiziqlar 5 ta (yuqori, oraliq 3 ta, pastki), har birida 4 cho'p: 20. Tik ham 5 · 4 = 20. Jami <b>40</b>. Formula: 2 · n · (n + 1).</p>",
 q:{t:"5×5 kvadrat to'r uchun nechta cho'p kerak?",opts:["60","50","100","36"],ok:0,why:"2 · 5 · 6 = 60.",hint:"5×5 da yotiq chiziqlar nechta?",full:"6 ta yotiq chiziq · 5 = 30, 6 ta tik · 5 = 30. Jami 60. «100» — 25 · 4."},
 tn:"Bolalar 1×1, 2×2, 3×3 to'r uchun sanab, «4, 12, 24, 40» qatorini ko'rsin — bu 4J01 dagi farqlar usuli bilan ham topiladi."}),
J4({h:"Uchburchaklar lentasi",sum:"Uchburchaklar lentasi: 1 ta — 3 cho'p, har keyingisi +2. n ta → 2 · n + 1. 15 ta → 31.",a:"m03",
 s:g4Tri,m:"Har yangi uchburchakka 2 ta cho‘p qo‘shiladi",f:function(){j3Lines(['1-uchburchak: 3','qolgan 14 tasi: 14 · 2 = 28','3 + 28 = [31]'],{fs:17,lh:34})},fm:"Formula: 2 · n + 1",
 html:"<p>Cho'plardan teng tomonli uchburchaklar lentasi terilgan (biri uchi yuqoriga, biri pastga). 5 ta uchburchak — 11 cho'p. <b>15 ta</b> uchburchak uchun nechta cho'p kerak?</p>",
 ch:["45","30","31","33"],ok:2,bad:["15 · 3 = 45 — umumiy tomonlar ikki marta sanaldi","2 · 15 = 30 — birinchi cho‘p tushib qoldi","","5 ta → 11 dan har biriga 2: 11 + 10 · 2 = ?"],
 after:"<p>Har yangi uchburchak oldingisi bilan bitta tomonni bo'lishadi — unga 2 ta cho'p yetadi. 3 + 14 · 2 = <b>31</b>. Kvadratlar qatorida 3 · n + 1, uchburchaklarda 2 · n + 1: qo'shiladigan cho'plar = tomonlar soni − 1.</p>",
 q:{t:"Katta uchburchakning har tomoni 3 ta cho'pdan iborat, ichida 9 ta kichik uchburchak bor. Nechta cho'p ishlatilgan?",opts:["18","27","9","24"],ok:0,why:"9 ta kichikdan 6 tasi uchi yuqoriga: 6 · 3 = 18 — har cho'p aynan bitta ▲ ga tegishli.",hint:"Uchi yuqoriga qaragan kichik uchburchaklar nechta?",full:"Uchi yuqoriga qaragan kichik uchburchaklar 1 + 2 + 3 = 6 ta, ularning tomonlari barcha cho'plarni bir martadan qamraydi: 6 · 3 = 18. «27» — 9 · 3."},
 tn:"Ko'rgazmali: yuqoriga qaragan uchburchaklarni bir rangda bo'yang — har cho'p faqat bittasida."}),
J4({h:"Fazoda: kub karkasi",sum:"Kub karkasi 12 cho'p. Ikki kub yonma-yon: umumiy yoqning 4 cho'pi bir marta → 12 + 8 = 20.",a:"m04",
 s:function(){g4Cubes(1)},m:"Kubning 12 ta qirrasi bor",f:function(){g4Cubes(2);j3Msg('12 + 8 = <b>20</b>: ikkinchi kubga umumiy yoqdan tashqari 8 ta cho‘p')},
 html:"<p>Bitta kubning karkasi (qirralari) uchun 12 ta cho'p kerak. Ikkita kub yonma-yon qo'yilib, umumiy karkas yasaldi (2×1×1 quti). Nechta cho'p kerak?</p>",
 ch:["24","20","16","22"],ok:1,bad:["12 · 2 = 24 — umumiy yoqning 4 ta cho‘pi ikki marta sanaldi","","Umumiy yoqda 4 ta cho‘p: 24 − 4 = ?","Umumiy qirralar 2 ta emas, 4 ta"],
 after:"<p>Ikkinchi kubning bitta yog'i birinchisi bilan umumiy — uning 4 ta qirrasi tayyor. Qolgan 8 tasi yangi: 12 + 8 = <b>20</b>. Har keyingi kubga ham 8 ta qo'shiladi: 3 kub — 28.</p>",
 q:{t:"Uchta kub qatorasiga (3×1×1 quti) karkas qilinsa, nechta cho'p kerak?",opts:["28","36","32","24"],ok:0,why:"12 + 8 + 8 = 28.",hint:"Har yangi kubga nechta cho'p qo'shiladi?",full:"Birinchi kub 12, keyingi har biriga 8: 12 + 16 = 28. «36» — 3 · 12."},
 tn:"Plastilin va tish cho'plaridan kub karkasi yasating — 3D tasavvur uchun eng yaxshi mashq."}),
J4({h:"Tenglamani tuzatish",sum:"6 + 4 = 4 noto'g'ri. 6 ning o'rtasidagi cho'pni yuqori o'ngga ko'chirsak 0 bo'ladi: 0 + 4 = 4.",a:"m05",
 s:function(){g4Eq('6+4=4')},m:"Faqat BITTA cho‘pni boshqa joyga ko‘chirish mumkin",f:function(){g4Eq('0+4=4');j3Msg('6 → 0: o‘rtadagi cho‘p yuqori o‘ngga ko‘chdi. 0 + 4 = 4 ✓')},
 html:"<p>Cho'plardan «6 + 4 = 4» yozilgan — bu noto'g'ri. <b>Bitta</b> cho'pni boshqa joyga ko'chirib, to'g'ri tenglik hosil qiling. Qaysi o'zgarish yordam beradi?</p>",
 ch:["6 ni 0 ga aylantirish","+ ni − ga aylantirish","birinchi 4 ni 9 ga","oxirgi 4 ni 1 ga"],ok:0,bad:["","6 − 4 = 2, 4 emas. Olingan cho‘p ham qayergadir qo‘yilishi kerak","4 ni 9 ga aylantirish uchun 2 ta cho‘p qo‘shish kerak","4 dan 1 qilish uchun 2 ta cho‘p olinadi — bittasini ko‘chira olmaymiz"],
 after:"<p>6 raqamida 6 ta cho'p, 0 raqamida ham 6 ta — faqat bittasining joyi boshqa. O'rtadagi cho'pni yuqori o'ng tomonga ko'chiramiz: 0 + 4 = 4 ✓. Usul: avval qaysi raqamlar <b>bir xil cho'p soniga</b> ega ekanini eslang: 0, 6, 9 — 6 tadan; 2, 3, 5 — 5 tadan.</p>",
 q:{t:"«3 + 3 = 8» — bitta cho'pni olib tashlab to'g'ri tenglik qiling. Nima qilinadi?",opts:["8 ni 6 ga","8 ni 9 ga","3 ni 2 ga","+ ni − ga"],ok:0,why:"8 dan yuqori o'ng cho'pni olsak — 6: 3 + 3 = 6.",hint:"3 + 3 nechchi? 8 dan qaysi raqam chiqadi?",full:"3 + 3 = 6. 8 dan yuqori o'ng cho'p olinsa 6 bo'ladi. 8 → 9 (3 + 3 = 9 xato), + → − (3 − 3 = 0, 8 emas)."},
 tn:"Kalkulyator raqamlari jadvalini (har raqam necha cho'p) doskaga yozib qo'ying — keyingi jumboqlarda asqotadi."}),
J4({h:"Ichidagi kvadratlar",sum:"2×2 to'r (12 cho'p) da 5 ta kvadrat: 4 ta kichik va 1 ta katta. Tashqi cho'p olinsa — 1 kichik va katta buziladi: 3 qoladi.",a:"m06",
 s:function(){clear();j3Mt(j3SqGrid(2,2,130,40,48))},m:"Kvadratlar faqat kichiklar emas!",
 f:function(){clear();j3Mt(j3SqGrid(2,2,130,40,48));E('rect',{x:130,y:40,width:96,height:96,fill:'none',stroke:C.bad,'stroke-width':4,rx:3},S.g);j3Msg('4 ta kichik + 1 ta katta = <b>5</b>')},
 html:"<p>12 ta cho'pdan 2×2 to'r terildi. Unda <b>nechta kvadrat</b> bor?</p>",
 ch:["4","5","3","6"],ok:1,bad:["4 — faqat kichiklari. Butun shakl ham kvadrat!","","3 — bu bitta cho‘p olinganda","Kvadratlar 1×1 va 2×2 bo‘ladi, boshqa o‘lcham yo‘q"],
 after:"<p>Kichik kvadratlar 4 ta, ular birgalikda yana bitta katta kvadrat hosil qiladi: <b>5</b>. Agar tashqi chegaradan bitta cho'pni olib tashlasak, bitta kichik va katta kvadrat buziladi — 3 ta qoladi. Ichki cho'pni olsak — 2 ta kichik buziladi, katta saqlanadi: yana 3 ta.</p>",
 q:{t:"Shu 2×2 to'rdan tashqi chegaradagi bitta cho'p olindi. Nechta kvadrat qoldi?",opts:["3","4","2","5"],ok:0,why:"Bitta kichik va katta kvadrat buziladi: 5 − 2 = 3.",hint:"Shu cho'p qaysi kvadratlarning tomoni?",full:"Tashqi cho'p bitta kichik kvadratning va katta kvadratning tomoni. Ikkalasi buziladi: 5 − 2 = 3."},
 tn:"«Qaysi cho'p nechta kvadratga tegishli?» — har cho'pga raqam yozdiring. Bu cho'p olib tashlash jumboqlarining kaliti."}),
J4info({h:"Bilasizmi? Gugurt qachon paydo bo'lgan",a:"m07",s:function(){g4Eq('2026')},m:"2026 soni: 5 + 6 + 5 + 6 = 22 cho‘p",
 html:"<p>🔥 Ishqalanganda yonadigan gugurtni 1826-yilda ingliz kimyogari <b>Jon Uoker</b> ixtiro qilgan. Shundan beri gugurt cho'plari jumboqlar uchun eng arzon «o'yinchoq» bo'lib qoldi: ularni sanash, ko'chirish, olib tashlash orqali sanoq, geometriya va mantiq bir vaqtda mashq qilinadi. ⚠️ Darsda gugurt o'rniga sanoq tayoqchalaridan foydalaning!</p>",
 tn:"Sanoq tayoqchalari yoki tish cho'plari bilan ishlang — haqiqiy gugurt ishlatilmasin."}),
J4info({h:"Eslatma kartochka",a:"m08",memo:1,s:g4Row,m:"Umumiy tomonlarni bir marta sanang",
 html:"<div class='memo'><ul><li>Kvadratlar qatori: <b>3 · n + 1</b>.</li><li>Uchburchaklar lentasi: <b>2 · n + 1</b>.</li><li>n×n to'r: yotiq + tik = <b>2 · n · (n + 1)</b>.</li><li>Kub karkasi 12, har qo'shni kubga +8.</li><li>Raqamlar: 1 — 2 cho'p, 7 — 3, 4 — 4, 2, 3, 5 — 5 tadan; 0, 6, 9 — 6 tadan, 8 — 7.</li><li>Kvadratlarni sanaganda kattasini ham hisobga oling.</li></ul></div>",
 tn:"Uyga: 3 ta qatordan (1, 2, 3 kvadrat) foydalanib, 10 ta kvadratli qator uchun cho'plar sonini topib kelish."})
];
var PROBS=[
{t:"Qatorasiga 5 ta kvadrat terish uchun nechta cho'p kerak?",o:["16","20","15","21"],k:0,s:"3 · 5 + 1 = 16."},
{t:"Qatorasiga 10 ta kvadrat terish uchun nechta cho'p kerak?",o:["31","40","30","33"],k:0,s:"3 · 10 + 1 = 31."},
{t:"3×3 kvadrat to'r uchun nechta cho'p kerak?",o:["24","36","16","27"],k:0,s:"4 ta yotiq chiziq · 3 + 4 ta tik · 3 = 24."},
{t:"2 qator, 3 ustunli to'r (6 ta katak) uchun nechta cho'p kerak?",o:["17","18","24","15"],k:0,s:"Yotiq: 3 chiziq · 3 = 9, tik: 4 chiziq · 2 = 8. Jami 17."},
{t:"Uchburchaklar lentasi: 6 ta uchburchak uchun nechta cho'p?",o:["13","18","12","14"],k:0,s:"2 · 6 + 1 = 13."},
{t:"49 ta cho'pdan qatorasiga nechta kvadrat terish mumkin (hammasi ishlatiladi)?",o:["16","12","17","49"],k:0,s:"3 · n + 1 = 49 → n = 16."},
{t:"Uycha: kvadrat va ustida uchburchak tom (6 cho'p). Yonma-yon 5 ta uycha terildi (devorlari umumiy). Nechta cho'p?",o:["26","30","25","31"],k:0,s:"Har yangi uychaga 5 ta: 6 + 4 · 5 = 26."},
{t:"Kub karkasi uchun nechta cho'p kerak?",o:["12","6","8","24"],k:0,s:"Kubning 12 ta qirrasi bor."},
{t:"To'rtta kubdan 2×2 qilib (bir qavat) quti yasaldi. Uning karkasi uchun nechta cho'p kerak?",o:["33","48","36","30"],k:0,s:"Pastki va ustki qatlam 12 tadan (2×2 to'r) = 24, tik cho'plar 9 ta: 33."},
{t:"Kvadrat to'r uchun 60 ta cho'p ishlatildi. To'r necha katakka necha katak?",o:["5×5","6×6","4×4","15×15"],k:0,s:"2 · n · (n + 1) = 60 → n · (n + 1) = 30 → n = 5."},
{t:"Kalkulyator raqami 8 uchun nechta cho'p kerak?",o:["7","8","6","5"],k:0,s:"8 — barcha 7 ta bo'lak."},
{t:"Kalkulyator raqamlaridan qaysi biri eng ko'p cho'p talab qiladi?",o:["8","0","6","9"],k:0,s:"8 — 7 ta; 0, 6, 9 — 6 tadan."},
{t:"2026 sonini kalkulyator raqamlarida yozish uchun nechta cho'p kerak?",o:["22","20","24","21"],k:0,s:"2 — 5, 0 — 6, 2 — 5, 6 — 6: 22."},
{t:"Qaysi raqam eng kam cho'p talab qiladi?",o:["1","7","4","2"],k:0,s:"1 — 2 ta cho'p."},
{t:"«9 − 3 = 8» — bitta cho'pni olib tashlab to'g'ri tenglik qiling. Qaysi tenglik chiqadi?",o:["9 − 3 = 6","9 − 3 = 9","5 − 3 = 2","9 − 3 = 0"],k:0,s:"8 dan yuqori o'ng cho'p olinsa — 6: 9 − 3 = 6."},
{t:"Tomoni 4 ta cho'pdan iborat kvadratning faqat chegarasi terildi. Nechta cho'p?",o:["16","20","12","40"],k:0,s:"4 tomon · 4 cho'p = 16."},
{t:"Uchburchaklar lentasi uchun 31 ta cho'p ishlatildi. Nechta uchburchak bor?",o:["15","10","16","30"],k:0,s:"2 · n + 1 = 31 → n = 15."},
{t:"3×3 kvadrat to'rni 4×4 to'rga kattalashtirish uchun yana nechta cho'p kerak?",o:["16","12","8","7"],k:0,s:"4×4 — 40, 3×3 — 24: 40 − 24 = 16."},
{t:"Pog'onali zina: yuqori qatorda 1, o'rtada 2, pastda 3 ta kvadrat (chapdan tekislangan). Nechta cho'p kerak?",o:["18","24","16","20"],k:0,s:"Yotiq: 1 + 2 + 3 + 3 = 9, tik: 2 + 3 + 4 = 9. Jami 18."},
{t:"12 ta cho'pdan tomoni 3 ta cho'p bo'lgan kvadrat terildi. Ichiga 1×1 katakdan nechtasi sig'adi?",o:["9","12","6","3"],k:0,s:"3 × 3 = 9."}
];
function PRACT_STAGE(){g4Row()}
var PREP_DATA={teach:["Kvadratlar qatori: 3 · n + 1.","Kvadrat to'r: yotiq va tik cho'plarni alohida sanash.","Uchburchaklar lentasi va kub karkasi.","Raqamli cho'plar: bitta cho'pni ko'chirish yoki olib tashlash."],
 mist:["Umumiy tomonlarni ikki marta sanaydi.","Birinchi cho'pni (+1) unutadi.","2×2 to'rda faqat 4 ta kvadrat ko'radi."],
 need:["Sanoq tayoqchalari yoki tish cho'plari (gugurt emas!).","Plastilin (kub karkasi uchun).","Kalkulyator raqamlari jadvali."],
 board:["qator: 3 · n + 1","lenta: 2 · n + 1","to'r: 2 · n · (n + 1)","0, 6, 9 — 6 cho'p; 8 — 7 cho'p"]};

// ===== 3J umumiy yordamchilar (w_3j1) =====
function j3Msg(h,bad){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center'+(bad?';color:#d94b4b':'')+'">'+h+'</div></div>'}
// tanlov tugmalari: to'g'risi done() ni chaqiradi, xatosi izoh beradi
function j3Ch(labels,ok,onOk,bad){return labels.map(function(l,i){return [l,function(c,done,b){if(i===ok){if(onOk)onOk();[].forEach.call(c.querySelectorAll('.acts .ab'),function(x){x.disabled=true});b.disabled=false;b.style.background='#1e8e5a';b.style.boxShadow='none';done()}else{j3Msg(typeof bad==='function'?bad(i):(bad||'Yana bir o‘ylab ko‘ring'),1)}}]})}
// matn qatorlari; [..] ichidagi qism qizil
function j3Lines(arr,o){o=o||{};clear(o.bg);var lh=o.lh||30,n=arr.length,y0=o.y0||(87-(n-1)*lh/2);arr.forEach(function(l,i){var t=T(S.g,180,y0+i*lh+7,'',{'font-size':o.fs||20,'font-weight':800,fill:'#1d2b3a'});String(l).split(/(\[[^\]]*\])/).forEach(function(p){if(!p)return;var s=E('tspan',{},t);var h=p[0]==='[';s.textContent=h?p.slice(1,-1):p;if(h)s.setAttribute('fill',C.bad)})})}
// jadval
function j3Tab(rows,o){o=o||{};clear(o.bg);var nr=rows.length,nc=rows[0].length,cw=o.cw||Math.min(70,330/nc),ch=o.ch||Math.min(34,160/nr),x0=180-nc*cw/2,y0=o.y0!=null?o.y0:(87-nr*ch/2);S.cells=[];
 rows.forEach(function(r,i){r.forEach(function(v,j){var hdr=(o.hr&&i===0)||(o.hc&&j===0);var f=(o.fill&&o.fill[i+','+j])||(hdr?'#eef3f8':'#fff');var rc=E('rect',{x:x0+j*cw,y:y0+i*ch,width:cw-1,height:ch-1,rx:3,fill:f,stroke:'#c9d3dd'},S.g);var t=T(S.g,x0+j*cw+cw/2,y0+i*ch+ch/2+5,v==null?'':String(v),{'font-size':o.fs||(hdr?11:16),'font-weight':hdr?700:800,fill:(o.col&&o.col[i+','+j])||'#1d2b3a'});S.cells.push({r:i,c:j,rect:rc,t:t,x:x0+j*cw,y:y0+i*ch,w:cw,h:ch})})})}
// gugurt cho'plari
function j3Mt(segs){var g=S.g;segs.forEach(function(s){var c=s[4]||'#d9a35a';E('line',{x1:s[0],y1:s[1],x2:s[2],y2:s[3],stroke:c,'stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:s[2],cy:s[3],r:3.4,fill:s[5]||C.bad},g)})}
function j3SqRow(n,x0,y0,L,col){var s=[];for(var i=0;i<n;i++){s.push([x0+i*L,y0,x0+(i+1)*L,y0,col]);s.push([x0+i*L,y0+L,x0+(i+1)*L,y0+L,col])}for(var k=0;k<=n;k++)s.push([x0+k*L,y0,x0+k*L,y0+L,col]);return s}
function j3SqGrid(r,c,x0,y0,L,col){var s=[];for(var i=0;i<=r;i++)for(var j=0;j<c;j++)s.push([x0+j*L,y0+i*L,x0+(j+1)*L,y0+i*L,col]);for(var i2=0;i2<r;i2++)for(var j2=0;j2<=c;j2++)s.push([x0+j2*L,y0+i2*L,x0+j2*L,y0+(i2+1)*L,col]);return s}
// 7 bo'lakli raqam (kalkulyator raqami)
var J3SEG={0:'abcdef',1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgedc',7:'abc',8:'abcdefg',9:'abcfgd'};
function j3Dig(d,x,y,w,h,col){var P={a:[x,y,x+w,y],b:[x+w,y,x+w,y+h/2],c:[x+w,y+h/2,x+w,y+h],d:[x,y+h,x+w,y+h],e:[x,y+h/2,x,y+h],f:[x,y,x,y+h/2],g:[x,y+h/2,x+w,y+h/2]};J3SEG[d].split('').forEach(function(k){var p=P[k];E('line',{x1:p[0],y1:p[1],x2:p[2],y2:p[3],stroke:col||'#d9a35a','stroke-width':5,'stroke-linecap':'round'},S.g)})}
function j3Num(str,x0,y0,o){o=o||{};var w=o.w||22,h=o.h||40,gap=o.gap||14;String(str).split('').forEach(function(ch,i){var x=x0+i*(w+gap);if(J3SEG[ch])j3Dig(ch,x,y0,w,h,o.col);else T(S.g,x+w/2,y0+h/2+8,ch,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})})}
// ustunli chizma (bar model) — qatorlar: [{lab, parts:[[qiymat yoki matn, rang, kenglik]]}]
function j3Bars(rows,o){o=o||{};clear();var x0=o.x0||86,y=o.y0||24,h=o.h||26,gap=o.gap||14,u=o.u||8;rows.forEach(function(r){T(S.g,x0-8,y+h/2+5,r.lab,{'font-size':12,'font-weight':800,'text-anchor':'end',fill:'#1d2b3a'});var x=x0;r.parts.forEach(function(p){var w=p[2]*u;E('rect',{x:x,y:y,width:w,height:h,rx:3,fill:p[1]||C.b,stroke:C.line,'stroke-width':1.3},S.g);if(p[0]!=null&&p[0]!=='')T(S.g,x+w/2,y+h/2+5,String(p[0]),{'font-size':12,'font-weight':800,fill:'#1d2b3a'});x+=w});if(r.right)T(S.g,x+8,y+h/2+5,r.right,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:C.blue});y+=h+gap})}

// ===== 4J umumiy yordamchilar (w_4j1) =====
// ketma-ketlik kataklari: '?' qizil; o.d — oraliqdagi farqlar
function j4Seq(a,o){o=o||{};clear();var n=a.length,w=Math.min(46,330/n-6),g=6,x0=180-(n*(w+g)-g)/2,y=o.y||62;
 if(o.t)T(S.g,180,y-22,o.t,{'font-size':13,'font-weight':700,fill:'#3a4a5a',nofr:1});
 a.forEach(function(v,i){var q=v==='?';E('rect',{x:x0+i*(w+g),y:y,width:w,height:38,rx:8,fill:q?'#ffe9e9':'#fff',stroke:q?C.bad:'#c9d3dd','stroke-width':1.5},S.g);T(S.g,x0+i*(w+g)+w/2,y+25,String(v),{'font-size':String(v).length>3?12:(String(v).length>2?14:17),'font-weight':800,fill:q?C.bad:'#1d2b3a',nofr:1})});
 if(o.d)o.d.forEach(function(v,i){if(v===''||v==null)return;var cx=x0+i*(w+g)+w+g/2;E('path',{d:'M'+(cx-w/2)+','+(y+42)+' Q'+cx+','+(y+60)+' '+(cx+w/2)+','+(y+42),fill:'none',stroke:C.blue,'stroke-width':1.3},S.g);T(S.g,cx,y+68,String(v),{'font-size':11,'font-weight':800,fill:C.blue,nofr:1})})}
// umumiy qadam quruvchi: tanlov tugmalari bilan
function J4(o){var dr=function(x,m,so){if(typeof x==='function')x();else j3Lines(x,so||o.so);if(m)j3Msg(m)};
 return {h:o.h,sum:o.sum,a:o.a,start:function(){dr(o.s,o.m)},fin:function(){dr(o.f||o.s,o.fm||o.m,o.fso)},html:o.html,
  btns:j3Ch(o.ch,o.ok,function(){dr(o.f||o.s,o.fm||o.m,o.fso)},function(i){return (o.bad&&o.bad[i])||'Yana bir o‘ylab ko‘ring'}),g2:o.ch.length===4||o.ch.length===2?1:0,g3:o.ch.length===3||o.ch.length===6?1:0,
  after:o.after,q:o.q,tn:o.tn}}
function J4info(o){var dr=function(){if(typeof o.s==='function')o.s();else j3Lines(o.s,o.so);if(o.m)j3Msg(o.m)};return {h:o.h,sum:o.sum||'',a:o.a,memo:o.memo?1:0,start:dr,fin:dr,html:o.html,tn:o.tn}}
// izometrik kubik (x,y — oldingi pastki chap burchak)
function j4Cube(x,y,s,f){f=f||['#9cc9ef','#6fa8dc','#cfe5f7'];var d=s*.5,e=s*.3,g=S.g;
 E('path',{d:'M'+x+','+y+' h'+s+' v'+(-s)+' h'+(-s)+'z',fill:f[0],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+(x+s)+','+y+' l'+d+','+(-e)+' v'+(-s)+' l'+(-d)+','+e+'z',fill:f[1],stroke:'#2a4a6a','stroke-width':1.1},g);
 E('path',{d:'M'+x+','+(y-s)+' l'+d+','+(-e)+' h'+s+' l'+(-d)+','+e+'z',fill:f[2],stroke:'#2a4a6a','stroke-width':1.1},g)}
