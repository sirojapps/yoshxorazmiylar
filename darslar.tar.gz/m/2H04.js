var CODE='2H04',TITLE='2-sinf olimpiada · Gugurt cho‘plari bilan masalalar';
// ---------- gugurt cho'pi ----------
function h4m(x1,y1,x2,y2,o){o=o||{};var g=S.g;E('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:o.off?'#e3d5c0':(o.hl?C.bad:'#e0b26b'),'stroke-width':5,'stroke-linecap':'round','stroke-dasharray':o.off?'4 4':''},g);if(!o.off)E('circle',{cx:x2,cy:y2,r:4,fill:o.hl?'#8a1d1d':'#b3261e'},g)}
// kvadratlar qatori: n ta kvadrat (tomon s), x0,y0; new — oxirgi qo'shilganlarni belgilash
function h4row(n,o){o=o||{};var s=o.s||40,x0=o.x||(180-n*s/2),y0=o.y||50,cnt=0;
 for(var i=0;i<n;i++){var x=x0+i*s,nw=o.nw&&i===n-1;h4m(x+3,y0,x+s-3,y0,{hl:nw});h4m(x+3,y0+s,x+s-3,y0+s,{hl:nw});if(i===0){h4m(x,y0+3,x,y0+s-3,{hl:nw});cnt++}h4m(x+s,y0+3,x+s,y0+s-3,{hl:nw});cnt+=3}return cnt}
function h4msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
var P2=[function(){clear();h4row(1,{nw:1});h4msg('1 kvadrat — <b>4</b> cho‘p')},function(){clear();h4row(2,{nw:1});h4msg('2 kvadrat — 4 + <b>3</b> = 7 cho‘p (umumiy tomon bor!)')},function(){clear();h4row(3,{nw:1});h4msg('3 kvadrat — 7 + <b>3</b> = 10 cho‘p')},function(){clear();h4row(4,{nw:1});h4msg('4 kvadrat — 10 + 3 = <b>13</b> cho‘p. Har yangi kvadrat — +3')}];
var P4=[function(){h4sq(0)},function(){h4sq(1)},function(){h4sq(2)}];
var P5=[function(){h4rem(0)},function(){h4rem(1)},function(){h4rem(2)}];
var STEPS=[
{h:"Alohida kvadratlar",sum:"1 kvadrat — 4 cho'p. 3 ta alohida (tegmaydigan) kvadrat — 3 · 4 = 12 cho'p.",a:"m01",
 start:function(){clear();h4row(1,{x:160});h4msg('1 kvadrat uchun nechta cho‘p?')},fin:function(){clear();h4row(1,{x:30});h4row(1,{x:150});h4row(1,{x:270});h4msg('3 · 4 = <b>12</b> cho‘p')},
 html:"<p>Bitta kvadrat 4 ta gugurt cho'pidan yasaladi. Bir-biriga <b>tegmaydigan</b> 3 ta kvadrat uchun nechta cho'p kerak? Tugmani bosing.</p>",
 btns:[["➕ Yana 2 ta kvadrat",function(c,done){clear();h4row(1,{x:30});h4row(1,{x:150});h4row(1,{x:270});h4msg('Har biri alohida: 4 + 4 + 4 = <b>12</b>');done()}]],
 after:"<p>Kvadratlar tegmasa, har biriga to'liq 4 ta cho'p kerak: 3 · 4 = <b>12</b>. Endi esa ular tegib tursa nima bo'lishini ko'ramiz — u yerda tejash bor!</p>",
 q:{t:"Bir-biriga tegmaydigan 5 ta uchburchak uchun nechta cho'p kerak?",opts:["15","11","5","10"],ok:0,why:"Har uchburchak 3 cho'p: 5 · 3 = 15.",hint:"Bitta uchburchakka nechta cho'p kerak?",full:"Uchburchak — 3 ta cho'p. Tegmasa: 5 · 3 = 15. «11» — tegib turgan qator uchun (2 · 5 + 1)."},
 tn:"Haqiqiy gugurt cho'plari yoki tish tozalagich bilan bolalar o'zi yasasin. Xavfsizlik uchun boshi yo'q cho'plar ishlating."},
{h:"Qatordagi kvadratlar",sum:"Yonma-yon kvadratlar: 4, 7, 10, 13 … — har yangi kvadrat +3 cho'p.",a:"m02",
 start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Kvadratlar endi <b>yonma-yon</b> teriladi. Har yangi kvadrat uchun nechta cho'p kerakligini kuzating — qizil cho'plar yangilari.</p>",
 btns:[phaser(P2,'➕ Kvadrat qo‘shish')],
 after:"<p>Birinchi kvadrat — 4 cho'p, keyingi har biri faqat <b>3</b> ta, chunki bitta tomoni qo'shnisidan olinadi. 4 kvadrat: 4 + 3 + 3 + 3 = 13.</p>",
 q:{t:"Yonma-yon 6 ta kvadrat uchun nechta cho'p kerak?",opts:["19","24","18","21"],ok:0,why:"4 + 5 · 3 = 19.",hint:"Birinchi kvadratga 4, keyingi har biriga 3.",full:"4 + 3 + 3 + 3 + 3 + 3 = 19. «24» — har biriga 4 ta deb hisoblangan, umumiy tomonlar hisobga olinmagan."},
 tn:"Jadval tuzdiring: kvadratlar soni | cho'plar (1–4, 2–7, 3–10 …) — bolalar qonuniyatni o'zi topsin."},
{h:"Qatordagi uchburchaklar",sum:"Umumiy tomonli uchburchaklar: 3, 5, 7 … — har yangisi +2.",a:"m03",
 start:function(){h4tr(1)},fin:function(){h4tr(3)},
 html:"<p>Uchburchaklar ham bir-biriga tegib turishi mumkin. Har yangisi uchun nechta cho'p kerak?</p>",
 btns:[["➕ Uchburchak qo'shish",function(c,done,b){S.h4t=(S.h4t||1)+1;h4tr(S.h4t);if(S.h4t>=3){b.disabled=true;done()}}]],
 after:"<p>Birinchi uchburchak — 3 cho'p, keyingilari — <b>2</b> tadan (bitta tomon umumiy). 3 ta uchburchak: 3 + 2 + 2 = 7.</p>",
 q:{t:"Bitta tomoni umumiy bo'lgan ikkita uchburchak uchun nechta cho'p kerak?",opts:["5","6","4","3"],ok:0,why:"3 + 2 = 5.",hint:"Umumiy tomon ikki marta sanalmaydi.",full:"Birinchisi — 3 ta, ikkinchisi umumiy tomondan foydalanadi — yana 2 ta. Jami 5. «6» — umumiy tomon ikki marta sanalgan."},
 tn:"Bolalar «umumiy tomon»ni barmoq bilan ko'rsatsin."},
{h:"Kvadrat to'r",sum:"2 × 2 to'r (4 kvadrat): 3 gorizontal qator · 2 + 3 vertikal qator · 2 = 12 cho'p.",a:"m04",
 start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>To'rtta kvadratdan iborat katta kvadrat (2 × 2). Nechta cho'p ishlatilgan? Sanab adashmaslik uchun <b>qatorlab</b> sanaymiz.</p>",
 btns:[phaser(P4)],
 after:"<p>Gorizontal chiziqlar: 3 qator, har birida 2 cho'p — 6. Vertikal: 3 ustun, har birida 2 — 6. Jami <b>12</b>. 4 · 4 = 16 emas, chunki ichki cho'plar ikki kvadratga umumiy.</p>",
 q:{t:"3 × 3 to'r (9 kvadrat) uchun nechta cho'p kerak?",opts:["24","36","27","18"],ok:0,why:"Gorizontal: 4 qator · 3 = 12, vertikal: 4 · 3 = 12. Jami 24.",hint:"Nechta gorizontal chiziq bor va har birida nechta cho'p?",full:"3 × 3 to'rda 4 ta gorizontal chiziq, har birida 3 cho'p — 12. Vertikal ham 12. Jami 24. «36» — 9 · 4, umumiy tomonlar hisobga olinmagan."},
 tn:"Gugurt to'rini chizib, gorizontallarni bir rangga, vertikallarni boshqa rangga bo'yatish sanashni osonlashtiradi."},
{h:"Tuzoq: olib tashlash jumbog'i",sum:"3 kvadrat qatoridan chetki kvadratni yo'qotish uchun 3 ta cho'p olinadi (umumiy tomon qoladi).",a:"m05",
 start:function(){startPh(P5)},fin:function(){S.ph=2;P5[2]()},
 html:"<p>Bank savoli: <i>«Uchta kvadratdan iborat qatordan bitta chetki kvadratni yo'qotish kerak, qolgan cho'plar kvadratlarni hosil qilishi kerak. Nechta cho'p olib tashlanadi?»</i> «4» deb shoshilmang!</p>",
 btns:[phaser(P5)],
 after:"<p>Chetki kvadratning 4 tomonidan bittasi — <b>qo'shni kvadrat bilan umumiy</b>. Uni olsak, qo'shni kvadrat buziladi! Shuning uchun faqat <b>3</b> ta cho'p olinadi.</p>",
 q:{t:"4 ta kvadrat qatoridan (13 cho'p) ikkita chetki kvadratni (har ikki uchidan) olib tashlash kerak. Nechta cho'p olinadi?",opts:["6","8","7","5"],ok:0,why:"Har bir chetki kvadratdan 3 tadan: 6.",hint:"Har bir chetki kvadratning bitta tomoni qo'shnisi bilan umumiy.",full:"Har bir chetki kvadrat — 3 ta cho'p (umumiy tomon qoladi). 3 + 3 = 6. Qoladi 13 − 6 = 7 cho'p — 2 ta kvadrat ✓."},
 tn:"Bolalar haqiqiy cho'plarni olib, natijani tekshirsin — bu masalada qo'l bilan sinash eng ishonchli."},
{h:"Ko'chirish jumbog'i",sum:"X + I = IX noto'g'ri; bitta cho'pni ko'chirsak: X + I = XI (10 + 1 = 11).",a:"m06",
 start:function(){h4rom(false)},fin:function(){h4rom(true)},
 html:"<p>Gugurt cho'plaridan Rim raqamlarida tenglik yozilgan: <b>X + I = IX</b>, ya'ni 10 + 1 = 9 — noto'g'ri! <b>Bitta</b> cho'pni ko'chirib, tenglikni to'g'rilang. Tugmani bosing.</p>",
 btns:[["🔁 Cho'pni ko'chirish",function(c,done){h4rom(true);done()}]],
 after:"<p>IX dagi I ni X ning <b>o'ng</b> tomoniga o'tkazdik: <b>XI</b> = 11. Endi 10 + 1 = 11 ✓. Rim raqamlarida I chapda tursa — ayiriladi (IX = 9), o'ngda tursa — qo'shiladi (XI = 11).</p>",
 q:{t:"Rim raqamlari: IV = 4, VI = 6. Qaysi biri 9?",opts:["IX","XI","VIIII","IIX"],ok:0,why:"I X ning chapida — 10 − 1 = 9.",hint:"I chapda tursa — ayiriladi.",full:"IX = 10 − 1 = 9. XI = 10 + 1 = 11. «VIIII» — to'g'ri yozilmaydi: bir xil belgi 3 tadan ko'p takrorlanmaydi."},
 tn:"Rim raqamlarini cho'plardan yasash oson: ular to'g'ri chiziqlardan iborat. Bolalarga o'z jumbog'ini tuzdiring."},
{h:"Bilasizmi? Tayoqchalar va Rim raqamlari",sum:"Rim raqamlari I, V, X — qadimgi cho'pon tayog'idagi kertiklardan kelib chiqqan bo'lishi mumkin.",a:"m07",
 start:function(){h4rom(true)},fin:function(){h4rom(true)},
 html:"<p>🏛 Rim raqamlari I, V, X to'g'ri chiziqlardan iborat — shuning uchun ularni cho'plardan yasash oson. Olimlar ular qadimgi cho'ponlarning tayog'iga sanab o'yilgan <b>kertiklardan</b> kelib chiqqan bo'lishi mumkin, deb taxmin qilishadi.</p><p>⭐ Gugurt jumboqlari esa butun dunyoda mantiqiy fikrlashni o'stiruvchi mashqlar sifatida mashhur: ular «nima o'zgarmaydi, nima o'zgaradi?» deb o'ylashga o'rgatadi.</p>",
 tn:"Darsdan keyin «bitta cho'pni ko'chir» musobaqasini o'tkazing."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){clear();h4row(3);h4msg('4 + 3 + 3 = 10')},fin:function(){clear();h4row(3);h4msg('4 + 3 + 3 = 10')},
 html:"<div class='memo'><ul><li>Alohida kvadrat — 4 cho'p, uchburchak — 3 cho'p.</li><li>Qatordagi kvadratlar: 4, 7, 10, 13 … (har yangisi <b>+3</b>).</li><li>Qatordagi uchburchaklar: 3, 5, 7 … (har yangisi <b>+2</b>).</li><li>To'rlarni <b>qatorlab</b> sanang: gorizontal + vertikal. 2 × 2 — 12 cho'p.</li><li>Olib tashlashda <b>umumiy tomonlarni</b> qoldiring.</li><li>Rim raqamlari: I chapda — ayiriladi (IX), o'ngda — qo'shiladi (XI).</li></ul></div>",
 tn:"Keyingi darsni «10 ta kvadrat qatori uchun nechta cho'p?» (31) savoli bilan boshlang."}
];
function h4tr(n){clear();var s=50,x0=180-(n+1)*s/4-10,y=120,cnt=3+(n-1)*2;
 var pts=[];for(var i=0;i<=n+1;i++)pts.push(i%2===0?[x0+i*s/2,y]:[x0+i*s/2,y-43]);
 for(var k=0;k<n;k++){var a=pts[k],b=pts[k+1],c=pts[k+2],nw=k===n-1;if(k===0)h4m(a[0],a[1],b[0],b[1],{hl:nw});h4m(b[0],b[1],c[0],c[1],{hl:nw});h4m(a[0],a[1],c[0],c[1],{hl:nw&&n===1})}
 h4msg(n+' ta uchburchak — <b>'+cnt+'</b> cho‘p'+(n>1?' (oxirgisi +2)':''))}
function h4sq(k){clear();var s=44,x0=136,y0=30;for(var r=0;r<=2;r++)for(var c=0;c<2;c++)h4m(x0+c*s+3,y0+r*s,x0+(c+1)*s-3,y0+r*s,{hl:k===1});for(var c2=0;c2<=2;c2++)for(var r2=0;r2<2;r2++)h4m(x0+c2*s,y0+r2*s+3,x0+c2*s,y0+(r2+1)*s-3,{hl:k===2});
 h4msg(['2 × 2 to‘r: nechta cho‘p?','Gorizontal: 3 qator · 2 = <b>6</b>','Vertikal: 3 ustun · 2 = <b>6</b>. Jami 6 + 6 = <b>12</b>'][k])}
function h4rem(k){clear();var s=44,x0=114,y0=50;for(var i=0;i<3;i++){var x=x0+i*s,last=i===2;var rm=last&&k>=1;h4m(x+3,y0,x+s-3,y0,{hl:rm&&k===1,off:rm&&k===2});h4m(x+3,y0+s,x+s-3,y0+s,{hl:rm&&k===1,off:rm&&k===2});if(i===0)h4m(x,y0+3,x,y0+s-3);h4m(x+s,y0+3,x+s,y0+s-3,{hl:last&&k===1,off:last&&k===2})}
 if(k>=1)T(S.g,x0+2*s,y0+s/2+4,'umumiy',{'font-size':9,'font-weight':800,fill:C.ok});
 h4msg(['3 kvadrat — 10 cho‘p. Chetki kvadratni yo‘qotamiz','Qizil — olinadigan 3 ta cho‘p. Umumiy tomon qoladi!','3 ta cho‘p olindi — 2 ta kvadrat qoldi (7 cho‘p)'][k])}
function h4rom(ok){clear();var g=S.g,y1=50,y2=120;function I(x,hl){h4m(x,y2,x,y1,{hl:hl})}function X(x){h4m(x-18,y2,x+18,y1);h4m(x-18,y1,x+18,y2)}
 X(50);T(g,98,95,'+',{'font-size':30,'font-weight':800});I(130);T(g,170,95,'=',{'font-size':30,'font-weight':800});
 if(!ok){I(210,true);X(250)}else{X(230);I(272,true)}
 T(g,180,160,ok?'10 + 1 = 11 ✓':'10 + 1 = 9 ✗',{'font-size':16,'font-weight':800,fill:ok?C.ok:C.bad});h4msg(ok?'<b>X + I = XI</b> — bitta cho‘p ko‘chirildi':'Bitta cho‘pni ko‘chirib to‘g‘rilang')}
var PROBS=[
{t:"Bir-biriga tegmaydigan 3 ta kvadrat uchun nechta cho'p kerak?",o:["12","10","9","16"],k:0,s:"3 · 4 = 12."},
{t:"Yonma-yon 4 ta kvadrat uchun nechta cho'p kerak?",o:["13","16","12","10"],k:0,s:"4 + 3 + 3 + 3 = 13."},
{t:"Yonma-yon 10 ta kvadrat uchun nechta cho'p kerak?",o:["31","40","30","33"],k:0,s:"4 + 9 · 3 = 31."},
{t:"Bitta tomoni umumiy 2 ta uchburchak uchun nechta cho'p?",o:["5","6","4","3"],k:0,s:"3 + 2 = 5."},
{t:"Qatordagi 5 ta uchburchak (har qo'shnisi umumiy tomonli) uchun nechta cho'p?",o:["11","15","10","13"],k:0,s:"3 + 4 · 2 = 11."},
{t:"2 × 2 kvadrat to'r uchun nechta cho'p?",o:["12","16","10","8"],k:0,s:"Gorizontal 6 + vertikal 6 = 12."},
{t:"3 × 3 kvadrat to'r uchun nechta cho'p?",o:["24","36","27","21"],k:0,s:"4 · 3 + 4 · 3 = 24."},
{t:"3 kvadrat qatoridan bitta chetki kvadratni yo'qotish uchun nechta cho'p olinadi?",o:["3","4","2","1"],k:0,s:"Umumiy tomon qoladi: 3 ta."},
{t:"Ali 22 ta cho'p bilan yonma-yon kvadratlar terdi. Nechta kvadrat chiqdi?",o:["7","5","6","8"],k:0,s:"4 + 3 · 6 = 22 → 7 ta."},
{t:"16 ta cho'pdan nechta alohida (tegmaydigan) kvadrat yasash mumkin?",o:["4","5","3","6"],k:0,s:"16 : 4 = 4."},
{t:"Rim raqamlarida XI qaysi son?",o:["11","9","12","10"],k:0,s:"X + I = 11."},
{t:"Rim raqamlarida IX qaysi son?",o:["9","11","8","10"],k:0,s:"X − I = 9."},
{t:"VI + I = V tengligini bitta cho'pni ko'chirib to'g'rilang. Qaysi yozuv chiqadi?",o:["IV + I = V","VI + I = VII","V + I = V","VI − I = V"],k:0,s:"VI dagi I ni V ning chapiga ko'chiramiz: IV + I = V (4 + 1 = 5)."},
{t:"Uchburchak 3 cho'p, kvadrat 4 cho'p. 2 uchburchak va 3 kvadrat (hammasi alohida) uchun nechta cho'p?",o:["18","17","14","20"],k:0,s:"2 · 3 + 3 · 4 = 6 + 12 = 18."},
{t:"«Uy»: kvadrat ustida uchburchak tom (umumiy tomon bilan). Nechta cho'p?",o:["6","7","5","8"],k:0,s:"Kvadrat 4 + tom 2 = 6."},
{t:"Yonma-yon 2 ta «uy» (devorlari umumiy, tomlari alohida). Nechta cho'p?",o:["11","12","10","14"],k:0,s:"2 kvadrat qatori 7 + 2 tom · 2 = 11."},
{t:"Yonma-yon kvadratlar qatori 25 cho'pdan yasaldi. Nechta kvadrat?",o:["8","6","7","9"],k:0,s:"4 + 3 · 7 = 25 → 8 ta."},
{t:"1 × 3 to'g'ri to'rtburchak (3 kvadrat) cho'plardan. Uning perimetri nechta cho'p?",o:["8","10","6","12"],k:0,s:"Tepada 3, pastda 3, yonlarda 1 + 1 = 8."},
{t:"2 × 2 to'rdan markazdagi xoch (4 ta ichki cho'p) olinsa, nechta kvadrat qoladi?",o:["1","2","0","4"],k:0,s:"Faqat tashqi katta kvadrat qoladi — 1 ta."},
{t:"12 ta cho'pdan qaysi shaklni yasab bo'lmaydi?",o:["4 ta alohida kvadrat","3 ta alohida kvadrat","2 × 2 kvadrat to'r","4 ta alohida uchburchak"],k:0,s:"4 alohida kvadrat uchun 16 ta cho'p kerak."}
];
function PRACT_STAGE(){clear();h4row(3);h4msg('Umumiy tomonlarni bir marta sanang')}
var PREP_DATA={teach:["Alohida va yonma-yon shakllar uchun cho'plar soni.","Qatorlar qonuniyati: kvadrat +3, uchburchak +2.","To'rlarni qatorlab sanash.","Olib tashlash va ko'chirish jumboqlari, Rim raqamlari."],
 mist:["Umumiy tomonlarni ikki marta sanaydi.","Olib tashlashda umumiy tomonni ham oladi.","To'rni «kvadratlar · 4» deb hisoblaydi.","IX va XI ni aralashtiradi."],
 need:["Boshi yo'q gugurt cho'plari yoki tish tozalagichlar (har bolaga 20–25 ta)."],
 board:["1 kvadrat — 4, 3 alohida — 12.","Qator: <span class='w2'>4, 7, 10, 13</span>.","Uchburchaklar: <span class='w2'>3, 5, 7</span>.","2 × 2: <span class='w2'>6 + 6 = 12</span>.","Olib tashlash: 3 ta (umumiy qoladi).","<span class='w2'>X + I = IX → X + I = XI</span>."]};
