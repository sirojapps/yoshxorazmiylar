var CODE='4C2',TITLE='4-sinf · Ikki va uch xonali songa ko‘paytirish';
var P1=[function(){W3area([36],243,{lbl:'243 · 36 = ?'});W3msg('36 ni o‘nlik va birlikka ajratamiz')},
 function(){W3area([30,6],243,{show:1,lbl:'36 = 30 + 6'})},
 function(){W3area([30,6],243,{show:2,lbl:'7 290 + 1 458 = 8 748'});W3msg('243 · 36 = 243 · 30 + 243 · 6 = <b>8 748</b>')}];
var P2=[function(){C4col(['..243','×..36','─────'],'Ustunda xuddi shu ikki bo‘lak — ikki qator bo‘ladi')},
 function(){C4col(['..243','×..36','─────','.[1458]'],'1-qator: 243 · <b>6</b> = 1 458')},
 function(){C4col(['..243','×..36','─────','.1458','+[729].'],'2-qator: 243 · <b>3 o‘nlik</b> = 729 o‘nlik — <b>bir xona chapga</b>','Bo‘sh birlik o‘rni aslida 0: 7 290')},
 function(){C4col(['..243','×..36','─────','.1458','+729.','─────','{8748}'],'Qatorlarni qo‘shamiz: 1 458 + 7 290 = <b>8 748</b>')}];
var P4=[function(){W3area([125],324,{lbl:'324 · 125 = ?'})},
 function(){W3area([100,20,5],324,{show:1,lbl:'125 = 100 + 20 + 5'})},
 function(){W3area([100,20,5],324,{show:2,lbl:'32 400 + 6 480 + 1 620 = 40 500'});W3msg('Uch xonali ko‘paytuvchi — uch bo‘lak, ustunda uch qator')}];
var P5=[function(){C4col(['...436','×..205','──────'],'Ko‘paytuvchi 205 — o‘rtasida nol')},
 function(){C4col(['...436','×..205','──────','..[2180]'],'436 · 5 = 2 180')},
 function(){C4col(['...436','×..205','──────','..2180','+[872]..'],'436 · <b>0 o‘nlik</b> = 0 — bu qatorni yozmaymiz. 436 · 2 <b>yuzlik</b> — ikki xona chapga')},
 function(){C4col(['...436','×..205','──────','..2180','+872..','──────','{89380}'],'2 180 + 87 200 = <b>89 380</b>')}];
var P7=[function(){W3eq(['456 · 99 = ?']);W3msg('99 — 100 ga juda yaqin')},
 function(){W3eq(['456 · 100 = 45 600','456 · 1 = 456']);W3msg('99 ta 456 = 100 ta 456 − 1 ta 456')},
 function(){W3eq(['45 600 − 456 = [45 144]']);W3msg('456 · 99 = <b>45 144</b>','Ustunsiz, 10 soniyada!')}];
var STEPS=[
{h:"Maydon modeli: 243 · 36",sum:"243 · 36 = 243 · 30 + 243 · 6 = 7 290 + 1 458 = 8 748.",a:"m01",start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Ikki xonali songa ko'paytirish = <b>ikkita</b> oddiy ko'paytirish. Tugmani bosing.</p>",btns:[phaser(P1)],
 after:"<p>36 = 30 + 6, shuning uchun 243 · 36 = 243 · 30 + 243 · 6. <b>Taqsimot xossasi</b> — ko'p xonali ko'paytirishning siri.</p>",
 q:{t:"152 · 24 = ?",opts:["3 648","608","3 040","3 448"],ok:0,why:"3 040 + 608.",hint:"152 · 20 va 152 · 4.",full:"152 · 20 = 3 040, 152 · 4 = 608, jami 3 648. «608» va «3 040» — bitta bo'lak xolos."},
 tn:"Katakli qog'ozda to'rtburchakni 30 va 6 ga bo'ling. Bolalar har bo'lak yuzini alohida hisoblasin — Singapur/AQSh area model."},
{h:"Ustun usuli",sum:"243 × 36: 1 458 va 729 (bir xona chapga) → 8 748.",a:"m02",start:function(){startPh(P2)},fin:function(){S.ph=3;P2[3]()},
 html:"<p>Maydon modelining ikki bo'lagi ustunda ikki qatorga aylanadi.</p>",btns:[phaser(P2)],
 after:"<p>1-qator — <b>birliklar</b> raqamiga ko'paytma, 2-qator — <b>o'nliklar</b> raqamiga (bir xona chapga suriladi). Keyin qatorlar qo'shiladi.</p>",
 q:{t:"Ustunda 314 × 27. Ikkinchi qatorga (surib) nima yoziladi?",opts:["628","2 198","314","8 478"],ok:0,why:"314 · 2 = 628 o'nlik.",hint:"Ikkinchi qator — o'nliklar raqami 2 ga ko'paytma.",full:"1-qator: 314 · 7 = 2 198. 2-qator: 314 · 2 = 628, bir xona surib (6 280). Javob: 2 198 + 6 280 = 8 478."},
 tn:"Avvaliga 2-qatorning bo'sh birligiga kichik 0 yozdiring — nega surilishini ko'rishadi."},
{h:"Tuzoq: surishni unutish",sum:"512 · 23 = 1 536 + 10 240 = 11 776; surilmasa 2 560 chiqadi.",a:"m03",start:function(){C4col(['..512','×..23','─────','.1536','+1024','─────','..???'],'Bola 2-qatorni surmadi. Javob qancha bo‘lishi kerak?')},fin:function(){C4col(['..512','×..23','─────','.1536','+1024.','─────','{11776}'])},
 html:"<p>Bola <b>512 · 23</b> ni ustunda yozdi, lekin 2-qatorni surmadi. To'g'ri javobni tanlang:</p>",
 btns:[["11 776",function(c,done){C4col(['..512','×..23','─────','.1536','+1024.','─────','{11776}'],'1 024 — bu 1 024 <b>o‘nlik</b> = 10 240. 1 536 + 10 240 = <b>11 776</b>');done()}],["2 560",function(){C4col(['.1536','+1024','─────','[2560]'],'Bu — bolaning xatosi. Chamalang: 512 · 23 ≈ 500 · 20 = 10 000. 2 560 juda kichik!','Qayta tanlang')}],["103 936",function(){C4col(['...1536','+102400','───────','[103936]'],'Bu holda ikki xona surilgan. 23 da 2 — o‘nlik, bitta xona yetadi','Qayta tanlang')}]],g3:1,
 after:"<p>Chamalash — eng yaxshi tekshiruv: 512 · 23 ≈ 500 · 20 = 10 000. Javob 10 000 atrofida bo'lishi kerak.</p>",
 q:{t:"Bola 213 · 32 = 426 + 639 = 1 065 deb yozdi. To'g'ri javob?",opts:["6 816","1 065","4 686","63 906"],ok:0,why:"426 + 6 390 = 6 816.",hint:"639 — bu o'nliklar.",full:"213 · 2 = 426, 213 · 3 = 639 o'nlik = 6 390. 426 + 6 390 = 6 816. «1 065» — surish unutilgan."},
 tn:"Xatoli ishni doskaga yozing: «Bola qayerda adashdi?» Bolalar chamalash bilan xatoni ushlasin."},
{h:"Uch xonali songa",sum:"324 · 125 = 32 400 + 6 480 + 1 620 = 40 500.",a:"m04",start:function(){startPh(P4)},fin:function(){S.ph=2;P4[2]()},
 html:"<p>Ko'paytuvchi uch xonali bo'lsa — uch bo'lak.</p>",btns:[phaser(P4)],
 after:"<p>Ustunda uch qator: birliklarga, o'nliklarga (<b>bir xona</b> surib), yuzliklarga (<b>ikki xona</b> surib).</p>",
 q:{t:"Ustunda 213 × 312. Uchinchi qator (yuzliklar) qancha va qancha suriladi?",opts:["639, ikki xona","639, bir xona","213, ikki xona","426, bir xona"],ok:0,why:"213 · 3 = 639 yuzlik.",hint:"312 da yuzliklar raqami — 3.",full:"312 = 300 + 10 + 2. Uchinchi qator 213 · 3 = 639, u yuzliklar — ikki xona chapga (63 900). Jami: 426 + 2 130 + 63 900 = 66 456."},
 tn:"Uch rangli bo'laklar: har qator o'z rangida. Ustunda ham shu ranglar bilan yozdiring."},
{h:"Ko'paytuvchida nol",sum:"436 · 205 = 2 180 + 87 200 = 89 380: nol qatori yozilmaydi.",a:"m05",start:function(){startPh(P5)},fin:function(){S.ph=3;P5[3]()},
 html:"<p><b>436 · 205</b> — ko'paytuvchining o'rtasida 0. Necha qator bo'ladi?</p>",btns:[phaser(P5)],
 after:"<p>Nol qatorida faqat nollar — uni yozmaymiz, lekin keyingi qatorni <b>ikki xona</b> suramiz. Eng ko'p xato: bir xona surib, 2 180 + 8 720 = 10 900 deb yozish.</p>",
 q:{t:"318 · 104 = ?",opts:["33 072","4 452","32 072","31 872"],ok:0,why:"31 800 + 1 272.",hint:"318 · 100 + 318 · 4.",full:"318 · 4 = 1 272, 318 · 100 = 31 800, jami 33 072. «4 452» — 1 272 + 3 180: bir xona surilgan (318 · 14)."},
 tn:"Maydon modelida 205 = 200 + 5 — faqat ikki bo'lak. Shu sababli nol qatori yo'q."},
{h:"Qaysi sonni yuqoriga yozamiz?",sum:"37 · 1 248 = 1 248 × 37: ikki qator, 46 176.",a:"m06",start:function(){W3eq(['37 · 1 248 = ?']);W3msg('Ustunda qaysi sonni yuqoriga yozgan qulay?')},fin:function(){C4col(['.1248','×..37','─────','.8736','+3744.','─────','{46176}'])},
 html:"<p><b>37 · 1 248</b>. Ustunda qanday yozasiz?</p>",
 btns:[["1 248 yuqorida",function(c,done){C4col(['.1248','×..37','─────','.8736','+3744.','─────','{46176}'],'Faqat <b>2 qator</b>: 1 248 · 7 = 8 736 va 1 248 · 3 = 3 744. Javob <b>46 176</b>');done()}],["37 yuqorida",function(){C4col(['...37','×.1248','──────','...296','..148.','..74..','+37...'],'Bu ham to‘g‘ri, lekin <b>4 qator</b> — ko‘p ish, ko‘p xato ehtimoli','Qulayrog‘ini tanlang')}]],
 after:"<p>O'rin almashtirish xossasi: 37 · 1 248 = 1 248 · 37. <b>Ko'p xonali sonni yuqoriga</b> yozsak, qatorlar kam bo'ladi.</p>",
 q:{t:"25 · 3 104 ni ustunda yozganda nechta qator bo'ladi (qulay usulda, yig'indidan tashqari)?",opts:["2","4","3","1"],ok:0,why:"3 104 × 25: 25 ning ikki raqami — 2 qator.",hint:"Ko'p xonali sonni yuqoriga yozing.",full:"3 104 × 25: 3 104 · 5 va 3 104 · 2 — ikki qator. 25 ni yuqoriga yozsak, 3 104 ning har raqami uchun qator: 4 ta (0 qatorini tashlasak 3 ta)."},
 tn:"Bolalarga ikkala usulda yozdirib, vaqtini solishtiring — qulaylik o'zi ko'rinadi."},
{h:"Qulay usul: 99 ga ko'paytirish",sum:"456 · 99 = 45 600 − 456 = 45 144.",a:"m07",start:function(){startPh(P7)},fin:function(){S.ph=2;P7[2]()},
 html:"<p>Ba'zan ustun kerak emas.</p>",btns:[phaser(P7)],
 after:"<p>99 = 100 − 1, 101 = 100 + 1, 49 = 50 − 1. Yaxlit songa yaqin ko'paytuvchi bo'lsa — <b>yaxlitga ko'paytirib, tuzatamiz</b>.</p>",
 q:{t:"238 · 101 = ?",opts:["24 038","23 800","2 618","23 562"],ok:0,why:"23 800 + 238.",hint:"101 = 100 + 1.",full:"238 · 100 = 23 800, + 238 = 24 038. «23 562» — 238 qo'shish o'rniga ayirilgan (238 · 99)."},
 tn:"«Kim tez?» o'yini: bir guruh ustunda, boshqasi qulay usulda hisoblaydi."},
{h:"Masala: uch bosqich",sum:"28 sinf · 32 o'quvchi = 896; 896 · 15 = 13 440 ta daftar.",a:"m08",start:function(){W3eq(['28 sinf · 32 o‘quvchi','har biriga 15 ta daftar','Jami ? ta'],{fs:19});W3msg('Maktabda 28 ta sinf, har birida 32 tadan o‘quvchi')},fin:function(){W3eq(['28 · 32 = 896','896 · 15 = [13 440]'])},
 html:"<p>Maktabda <b>28</b> ta sinf, har sinfda <b>32</b> tadan o'quvchi. Har o'quvchiga <b>15</b> tadan daftar berildi. Jami nechta daftar?</p>",
 btns:[["1: o‘quvchilar",function(c,done,b){b.disabled=true;W3eq(['28 · 32 = 896 o‘quvchi']);W3msg('28 · 32 = 560 + 336 = <b>896</b>')}],["2: daftarlar",function(c,done){W3eq(['28 · 32 = 896','896 · 15 = [13 440]']);W3msg('896 · 15 = 8 960 + 4 480 = <b>13 440</b> ta daftar');done()}]],
 after:"<p>Boshqa yo'l: 32 · 15 = 480 (bir sinfga), 480 · 28 = 13 440. Tartib boshqa — javob bir xil (<b>guruhlash xossasi</b>).</p>",
 q:{t:"Bir qutida 24 ta paket, har paketda 125 g choy. 16 ta qutida necha gramm choy?",opts:["48 000 g","3 000 g","4 800 g","38 400 g"],ok:0,why:"125 · 24 = 3 000 g; 3 000 · 16 = 48 000.",hint:"Avval bir qutidagi choy.",full:"Bir qutida 125 · 24 = 3 000 g. 16 qutida 3 000 · 16 = 48 000 g (48 kg). «3 000» — faqat bir quti."},
 tn:"Chizma model chizdiring: sinf — paket, o'quvchi — bo'lak. Qaysi tartib qulayroq — bolalar tanlasin."},
{h:"Bilasizmi? Dehqon usuli",sum:"Bir sonni ikkiga bo'lib, ikkinchisini ikkilantirib borib ham ko'paytirish mumkin.",a:"m09",start:function(){W3eq(['23 · 14','11 · 28','5 · 56','2 · 112','1 · 224'],{fs:18});W3msg('Toq qatorlar: 14 + 28 + 56 + 224 = <b>322</b>')},fin:function(){STEPS[8].start()},
 html:"<p>📚 Ko'p xalqlarda <b>«dehqon usuli»</b> bo'lgan: chap sonni ikkiga bo'lib (qoldiqni tashlab), o'ng sonni ikkilantirib boramiz. Chap son <b>toq</b> bo'lgan qatorlardagi o'ng sonlarni qo'shamiz.</p><p>⭐ 23 · 14: toq qatorlar 23, 11, 5, 1 → 14 + 28 + 56 + 224 = 322. Bu usul faqat ikkilantirish va bo'lishni bilishni talab qiladi — kompyuterlar ham shunga o'xshash hisoblaydi.</p>",
 tn:"Doskada 23 · 14 ni ikkala usulda yechib ko'rsating. Nega toq qatorlar olinishini qiziquvchilar uchun 23 = 16 + 4 + 2 + 1 orqali tushuntirish mumkin."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){C4col(['..243','×..36','─────','.1458','+729.','─────','{8748}'],'Har raqamga — alohida qator, surib yoziladi')},fin:function(){STEPS[9].start()},
 html:"<div class='memo'><ul><li>243 · 36 = 243 · 30 + 243 · 6 = 7 290 + 1 458.</li><li>Ustunda 2-qator <b>bir xona</b>, 3-qator <b>ikki xona</b> chapga.</li><li>Ko'paytuvchida 0: 436 · 205 — nol qatori yozilmaydi, keyingisi ikki xona suriladi.</li><li>Ko'p xonali sonni yuqoriga yozing — qatorlar kam.</li><li>99 = 100 − 1: 456 · 99 = 45 600 − 456.</li><li>Doim chamalang: 512 · 23 ≈ 10 000.</li></ul></div>",
 tn:"Keyingi mavzu: oxiri nol bilan tugaydigan sonlarni ko'paytirish va bo'lish."}
];
var PROBS=[
{t:"134 · 21 = ?",o:["2 814","402","2 680","2 714"],k:0,s:"2 680 + 134."},
{t:"215 · 34 = ?",o:["7 310","1 505","6 450","7 210"],k:0,s:"6 450 + 860."},
{t:"407 · 26 = ?",o:["10 582","3 256","10 482","9 582"],k:0,s:"8 140 + 2 442."},
{t:"1 236 · 45 = ?",o:["55 620","10 124","54 620","55 520"],k:0,s:"49 440 + 6 180."},
{t:"2 008 · 37 = ?",o:["74 296","20 296","74 096","14 056"],k:0,s:"60 240 + 14 056."},
{t:"124 · 213 = ?",o:["26 412","3 844","26 312","24 812"],k:0,s:"24 800 + 1 240 + 372."},
{t:"352 · 105 = ?",o:["36 960","5 280","35 960","36 860"],k:0,s:"35 200 + 1 760."},
{t:"609 · 304 = ?",o:["185 136","20 706","185 036","184 136"],k:0,s:"182 700 + 2 436."},
{t:"Bola 321 · 23 = 963 + 642 = 1 605 deb yozdi. To'g'ri javob?",o:["7 383","1 605","6 420","7 283"],k:0,s:"963 + 6 420."},
{t:"Bola 254 · 103 = 762 + 2 540 = 3 302 deb yozdi. To'g'ri javob?",o:["26 162","3 302","25 400","26 062"],k:0,s:"762 + 25 400: ikki xona surish kerak."},
{t:"Qaysi javob 498 · 61 ga to'g'ri kelishi mumkin?",o:["30 378","3 078","303 780","24 378"],k:0,s:"≈ 500 · 60 = 30 000."},
{t:"345 · 99 = ?",o:["34 155","34 500","34 845","34 255"],k:0,s:"34 500 − 345."},
{t:"125 · 48 = ?",o:["6 000","5 000","600","6 200"],k:0,s:"125 · 8 = 1 000; · 6."},
{t:"Ustunda 1 254 × 36: qatorlar 7 524 va 3 762. Javob?",o:["45 144","11 286","37 620","45 044"],k:0,s:"7 524 + 37 620."},
{t:"Bir kitobda 236 bet. 48 ta kitobda nechta bet?",o:["11 328","2 832","1 888","11 228"],k:0,s:"9 440 + 1 888."},
{t:"Poyezdda 18 vagon, har vagonda 54 o'rin. 750 yo'lovchi tushdi. Nechta bo'sh o'rin qoldi?",o:["222","972","172","1 722"],k:0,s:"18 · 54 = 972; 972 − 750."},
{t:"1 kg qand 14 500 so'm. 25 kg qand uchun 400 000 so'm berildi. Qaytim?",o:["37 500","362 500","27 500","47 500"],k:0,s:"14 500 · 25 = 362 500."},
{t:"Qaysi ko'paytma eng katta?",o:["298 · 101","299 · 100","301 · 99","300 · 98"],k:0,s:"30 098; 29 900; 29 799; 29 400."},
{t:"a · 25 = 3 175. a · 26 = ?",o:["3 302","3 176","3 200","82 550"],k:0,s:"a = 127; 3 175 + 127."},
{t:"□ = 37 · 48. □ ni 37 ga bo'lsak, nima chiqadi?",o:["48","37","1 776","85"],k:0,s:"Ko'paytmani bir ko'paytuvchiga bo'lsak — ikkinchisi."}
];
function PRACT_STAGE(){C4col(['..243','×..36','─────','.1458','+729.','─────','{8748}'],'Qator — surib yoz — qo‘sh')}
var PREP_DATA={teach:["Ikki xonali songa: maydon modeli va ustun usuli.","Uch xonali songa ko'paytirish.","Ko'paytuvchida nol bo'lsa (205, 104).","Qaysi sonni yuqoriga yozish qulay.","Qulay usul (99, 101) va ko'p bosqichli masalalar."],
 mist:["2-qatorni surmaydi: 512 · 23 = 2 560.","Ko'paytuvchida 0 bo'lsa bir xona suradi: 436 · 205 = 10 900.","Qatorlarni qo'shishda xato.","Masalada oraliq natijani (bir qutidagi) topmay qoladi."],
 need:["Katakli daftar.","Uch rangli qalam (har qator uchun)."],
 board:["<span class='w2'>243 · 36 = 7 290 + 1 458 = 8 748</span>","<span class='w2'>436 · 205 = 2 180 + 87 200</span>","<span class='w2'>456 · 99 = 45 600 − 456</span>"]};
// ====== 3C yordamchilari (W3 prefiksi) ======
function W3msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
function W3big(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:20px">'+h+'</div></div>'}
// katta ifoda qatorlari; [..] ichidagi qism qizil
function W3eq(lines,o){o=o||{};clear();var g=S.g,n=lines.length,dy=Math.min(40,150/n);lines.forEach(function(l,i){var y=(o.y0||34)+i*dy,plain=l.replace(/[\[\]{}]/g,''),fs=Math.min(o.fs||24,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
 l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);var hl=p[0]==='[',gr=p[0]==='{';ts.textContent=(hl||gr)?p.slice(1,-1):p;if(hl)ts.setAttribute('fill',C.bad);if(gr)ts.setAttribute('fill',C.ok)})})}
// xonalar jadvali: num ni ko'rsatadi, cols ta ustun (o'ngdan: birlik, o'nlik, yuzlik, ming, o'n ming, yuz ming)
var W3L=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming'];
function W3pv(rows,o){o=o||{};clear();var g=S.g,cols=o.cols||5,cw=Math.min(52,290/cols),x1=180+cols*cw/2-cw/2+(cols>=6?14:0),y0=26,rh=Math.min(38,124/rows.length),bg=['#e1f4f2','#fdf0e1','#fde6c8','#e8f1fb','#efe8fb','#fbe8ef'];
 for(var i=0;i<cols;i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rows.length*rh+24,rx:6,fill:bg[i]},g);T(g,x,y0-6,W3L[i],{'font-size':9,fill:'#5b6b7b'})}
 rows.forEach(function(r,k){var s=String(r.v),y=y0+18+k*rh;for(var i=0;i<s.length;i++){var d=s[s.length-1-i];T(g,x1-i*cw,y+4,d,{'font-size':Math.min(24,rh-6),'font-weight':800,fill:(r.zero&&d==='0'&&i<r.zero)?C.bad:(r.col||'#1d2b3a'),'font-family':'ui-monospace,Menlo,monospace'})}
  if(r.lab)T(g,x1-cols*cw+cw/2-8,y+2,r.lab,{'font-size':13,'font-weight':800,fill:C.blue,'text-anchor':'end'})});
 if(o.arrow){var y=y0+18+rh/2-6;E('path',{d:'M'+(x1+cw/2+6)+' '+(y-14)+' q12 14 0 28',fill:'none',stroke:C.bad,'stroke-width':2},g);T(g,x1+cw/2+30,y+4,o.arrow,{'font-size':12,'font-weight':800,fill:C.bad})}}
// massiv (nuqtalar)
function W3arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(300/c,140/r,22),rr=Math.max(2.5,s*.34),x0=180-(c-1)*s/2,y0=Math.max(16,84-(r-1)*s/2);
 for(var i=0;i<r;i++)for(var j=0;j<c;j++)E('circle',{cx:x0+j*s,cy:y0+i*s,r:rr,fill:o.cols?o.cols(i,j):C.b,stroke:'rgba(0,0,0,.15)'},g);
 if(o.vline!=null)E('line',{x1:x0+(o.vline-.5)*s,y1:y0-s/2,x2:x0+(o.vline-.5)*s,y2:y0+(r-.5)*s,stroke:C.bad,'stroke-width':2,'stroke-dasharray':'4 3'},g);
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// maydon (yuz) modeli: a = [qismlar], b = ko'paytuvchi; to'g'ri to'rtburchak qismlarga bo'lingan
function W3area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),W=280,H=80,x=44,y=46,cols=[C.a,C.b,C.c,'#b9e3c6'];
 var ws=parts.map(function(p){return Math.max(48,W*p/tot)}),sw=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/sw});
 T(g,26,y+H/2+6,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y,width:w,height:H,fill:cols[i%4],stroke:C.line,'stroke-width':1.5,opacity:.85},g);T(g,x+w/2,y-8,String(p),{'font-size':14,'font-weight':800,fill:C.line});
  if(o.show)T(g,x+w/2,y+H/2+6,o.show>1?String(p*b):p+'·'+b,{'font-size':w<70?12:15,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.lbl)T(g,180,166,o.lbl,{'font-size':13,'font-weight':800,fill:C.ok})}
// guruhlarga bo'lish (qoldiq bilan): n ta nuqta, k tadan guruh
function W3groups(n,k,o){o=o||{};clear();var g=S.g,q=o.q!=null?o.q:Math.floor(n/k),r=n-q*k,per=Math.min(6,Math.ceil(Math.sqrt(k))),bw=per*13+10,bh=Math.ceil(k/per)*13+10,cols=Math.max(1,Math.min(q+(r?1:0),Math.floor(330/(bw+8)))),i=0;
 for(var gi=0;gi<q+(r?1:0);gi++){var gx=18+(gi%cols)*(bw+8),gy=14+Math.floor(gi/cols)*(bh+8),m=gi<q?k:r,isR=gi>=q;var h2=Math.max(bh,Math.ceil(m/per)*13+10);
  E('rect',{x:gx,y:gy,width:bw,height:h2,rx:8,fill:isR?'#fdeaea':'#e8f1fb',stroke:isR?C.bad:'#9cc3e8','stroke-width':1.5,'stroke-dasharray':isR?'4 3':''},g);
  for(var j=0;j<m;j++)E('circle',{cx:gx+11+(j%per)*13,cy:gy+11+Math.floor(j/per)*13,r:5,fill:isR?C.bad:C.a},g)}
 if(o.lbl)T(g,180,168,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// burchakli bo'lish: a : d (d bir xonali), stage — nechta qadam ko'rsatilsin (null = hammasi)
function W3steps(a,d){var s=String(a),cur=0,q='',out=[],start=-1;for(var i=0;i<s.length;i++){cur=cur*10+(+s[i]);if(q===''&&cur<d&&i<s.length-1)continue;var qd=Math.floor(cur/d);q+=qd;out.push({end:i,part:cur,qd:qd,sub:qd*d,rem:cur-qd*d});cur=cur-qd*d}return {q:+q,r:cur,st:out}}
function W3div(a,d,stage,o){o=o||{};clear();var g=S.g,s=String(a),R=W3steps(a,d),cw=18,x0=60,y0=30,lh=20,ff='ui-monospace,Menlo,monospace';
 var dx=function(i){return x0+i*cw};for(var i=0;i<s.length;i++)T(g,dx(i)+cw/2,y0,s[i],{'font-size':20,'font-weight':800,fill:'#1d2b3a','font-family':ff});
 var xr=dx(s.length)+6;E('line',{x1:xr,y1:y0-20,x2:xr,y2:y0+26,stroke:'#33475b','stroke-width':2},g);E('line',{x1:xr,y1:y0+6,x2:xr+80,y2:y0+6,stroke:'#33475b','stroke-width':2},g);T(g,xr+10,y0,String(d),{'font-size':20,'font-weight':800,fill:C.blue,'font-family':ff,'text-anchor':'start'});
 var n=stage==null?R.st.length:stage,qs=String(R.q),y=y0;
 T(g,xr+10,y0+28,R.st.slice(0,n).map(function(x){return x.qd}).join(''),{'font-size':20,'font-weight':800,fill:C.ok,'font-family':ff,'text-anchor':'start'});
 for(var k=0;k<n;k++){var st=R.st[k],ps=String(st.sub),pend=st.end;if(k>0){var pt=String(st.part);y+=lh;for(var j=0;j<pt.length;j++)T(g,dx(pend-pt.length+1+j)+cw/2,y,pt[j],{'font-size':18,'font-weight':800,fill:'#5b6b7b','font-family':ff})}
  y+=lh;T(g,dx(pend-ps.length+1)-4,y,'−',{'font-size':16,fill:C.bad});for(var j2=0;j2<ps.length;j2++)T(g,dx(pend-ps.length+1+j2)+cw/2,y,ps[j2],{'font-size':18,'font-weight':800,fill:C.bad,'font-family':ff});
  E('line',{x1:dx(pend-Math.max(ps.length,String(st.part).length)+1)-2,y1:y+5,x2:dx(pend+1)+2,y2:y+5,stroke:'#33475b','stroke-width':1.5},g);
  if(k===R.st.length-1){y+=lh;T(g,dx(pend)+cw/2,y,String(st.rem),{'font-size':18,'font-weight':800,fill:st.rem?C.bad:C.ok,'font-family':ff})}}
 if(o.lbl)T(g,270,160,o.lbl,{'font-size':12,'font-weight':800,fill:C.blue})}
// 100 jadvali (yoki 1..60), belgilangan sonlar
function W3grid(fn,o){o=o||{};clear();var g=S.g,N=o.n||100,c=10,cw=30,ch=Math.min(28,160/Math.ceil(N/c)),x0=30,y0=6;for(var n=1;n<=N;n++){var r=Math.floor((n-1)/c),q=(n-1)%c,f=fn?fn(n):null;E('rect',{x:x0+q*cw,y:y0+r*ch,width:cw-1,height:ch-1,rx:2,fill:f||'#fff',stroke:'#dde5ee'},g);T(g,x0+q*cw+cw/2,y0+r*ch+ch/2+4,String(n),{'font-size':ch>20?12:9,'font-weight':f?800:500,fill:'#33475b'})}}
// chizma (bar)
function W3bars(y,n,txt,o){o=o||{};var x0=o.x0||40,w=o.w||280,h=o.h||32,g=S.g;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:h,fill:(o.fill&&o.fill(i))||C.off,stroke:C.line,'stroke-width':1.5},g);if(txt&&txt[i]!=null)T(g,x0+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':o.fs||13,'font-weight':800,fill:'#1d2b3a'})}E('rect',{x:x0,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2},g)}


// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=o.x0||40,W=o.W||280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}

// ===== 4C: ustun yozuvi (o'ngdan tekislangan qatorlar). '[..]' qizil, '{..}' yashil, '─' chiziq, '.' bo'sh joy
function C4col(lines,msg,note,o){o=o||{};clear();var g=S.g,n=lines.length,mx=0;lines.forEach(function(l){mx=Math.max(mx,l.replace(/[\[\]{}]/g,'').length)});
 var cw=Math.min(18,300/Math.max(1,mx)),fs=Math.min(22,cw*1.25),dy=Math.min(30,158/n),xR=180+mx*cw/2-cw/2,col=null;
 lines.forEach(function(l,k){var y=24+k*dy,ch=[];for(var i=0;i<l.length;i++){var c=l[i];if(c==='['){col=C.bad;continue}if(c==='{'){col=C.ok;continue}if(c===']'||c==='}'){col=null;continue}ch.push([c,col])}
  if(ch.length&&ch[0][0]==='─'){E('line',{x1:xR-cw*(mx-.5),y1:y-dy/2+3,x2:xR+cw/2,y2:y-dy/2+3,stroke:'#33475b','stroke-width':2},g);return}
  ch.forEach(function(q,i){if(q[0]===' '||q[0]==='.')return;T(g,xR-(ch.length-1-i)*cw,y,q[0],{'font-size':fs,'font-weight':800,fill:q[1]||(k===n-1?'#1d2b3a':'#33475b'),'font-family':'ui-monospace,Menlo,monospace'})})});
 if(o.carry)o.carry.forEach(function(c){T(g,xR-c[0]*cw+cw*.3,10,String(c[1]),{'font-size':11,'font-weight':800,fill:C.blue})});
 if(msg!=null)W3msg(msg,note)}
// burchakli bo'lish: har raqam uchun bitta bosqich (bo'l+ko'paytir+ayir birga), tushirish alohida
function w4LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);W3msg(intro||(D+' : '+d))}],i=0;
 while(i<ops.length){(function(){var op=ops[i];
  if(op.t==='div'&&ops[i+1]&&ops[i+1].t==='mul'){var k=i+3,m=op;P.push(function(){w3Long(D,d,k);W3msg('<b>'+m.part+' : '+d+' → '+m.qd+'</b>; '+m.qd+' · '+d+' = '+(m.qd*d)+'; '+m.part+' − '+(m.qd*d)+' = <b>'+(m.part-m.qd*d)+'</b>'+((m.part-m.qd*d)<d?' &lt; '+d+' ✓':''))});i+=3}
  else{var k2=i+1,o2=op;P.push(function(){w3Long(D,d,k2);W3msg(w3OpMsg(o2,d))});i+=1}})()}
 return P}
