var CODE='2C7',TITLE='2-sinf · Ko‘paytirish va bo‘lishning bog‘liqligi';
// ---------- 2C sahna vositalari: likopchalar, massivlar, son o'qi, tarqatish ----------
function cMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center;font-size:16px">'+h+'</div></div>'}
function cPos(n){var cols=n<=5?n:Math.ceil(n/2),rows=n<=5?1:2,cw=340/cols,R=Math.min(28,cw/2-5,rows===1?38:28),out=[];
 for(var i=0;i<n;i++){var r=Math.floor(i/cols),c=i%cols;out.push({x:10+cw*(c+.5),y:rows===1?84:(r===0?50:122),R:R})}return out}
function cDots(p,x,y,m,R,col,hl){var cols=Math.ceil(Math.sqrt(m)),rows=Math.ceil(m/cols),rr=Math.min(6.5,R/(Math.max(cols,rows)*1.25+.4)),sp=rr*2.5;
 for(var i=0;i<m;i++){var cc=i%cols,r=Math.floor(i/cols);E('circle',{cx:x+(cc-(cols-1)/2)*sp,cy:y+(r-(rows-1)/2)*sp,r:rr,fill:(hl&&hl(i))||col||C.a,stroke:'rgba(0,0,0,.2)','stroke-width':.8},p)}}
// n ta likopcha, har birida k ta (k — son yoki massiv)
function cPlates(n,k,o){o=o||{};clear(o.bg);var P=cPos(n);S.P=P;
 P.forEach(function(q,i){var m=Array.isArray(k)?k[i]:k,on=o.hl&&o.hl.indexOf(i)>=0;E('circle',{cx:q.x,cy:q.y,r:q.R,fill:on?'#fff3c4':'#fff',stroke:on?C.a2:'#c9b28d','stroke-width':on?3:1.6},S.g);cDots(S.g,q.x,q.y,m,q.R,o.col);
  if(o.lab)T(S.g,q.x,q.y+q.R+13,typeof o.lab==='function'?o.lab(i,m):String(m),{'font-size':11,'font-weight':800,fill:on?C.a2:'#5b6b7b'})});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// r qator, c ustun massiv
function cArr(r,c,o){o=o||{};clear(o.bg);var sp=Math.min(300/c,130/r,26),rr=Math.min(7,sp*.32),x0=180-(c-1)*sp/2,y0=(o.y||84)-(r-1)*sp/2;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var on=(o.hr&&o.hr.indexOf(i)>=0)||(o.hc&&o.hc.indexOf(j)>=0);E('circle',{cx:x0+j*sp,cy:y0+i*sp,r:rr,fill:on?C.hi:(o.col||C.b),stroke:'rgba(0,0,0,.2)'},S.g)}
 if(o.rowLab)for(var i2=0;i2<r;i2++)T(S.g,x0-sp*.8,y0+i2*sp+4,String(c),{'font-size':10,'font-weight':800,fill:C.blue});
 if(o.title)T(S.g,180,14,o.title,{'font-size':11,'font-weight':700,fill:C.blue})}
// son o'qi 0..max, qadam step, count ta sakrash
function cLine(max,step,count,o){o=o||{};clear();var x0=18,x1=342,y=112,k=(x1-x0)/max,X=function(v){return x0+v*k};
 E('line',{x1:x0-6,y1:y,x2:x1+6,y2:y,stroke:'#33475b','stroke-width':2.4},S.g);
 for(var v=0;v<=max;v++){var big=v%step===0;E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},S.g);if(big)T(S.g,X(v),y+24,String(v),{'font-size':max>40?9:11,'font-weight':700,fill:'#33475b'})}
 var back=o.back,start=o.from!=null?o.from:0;
 for(var i=0;i<count;i++){var a=back?start-i*step:start+i*step,b=back?a-step:a+step;var xa=X(a),xb=X(b);E('path',{d:'M'+xa+' '+(y-8)+' Q'+(xa+xb)/2+' '+(y-8-Math.min(46,Math.abs(xb-xa)*.9))+' '+xb+' '+(y-8),fill:'none',stroke:back?C.bad:C.ok,'stroke-width':2},S.g);
  T(S.g,(xa+xb)/2,y-12-Math.min(46,Math.abs(xb-xa)*.9)/2-4,(back?'−':'+')+step,{'font-size':10,'font-weight':800,fill:back?C.bad:C.ok})}
 var end=back?start-count*step:start+count*step;E('circle',{cx:X(end),cy:y,r:7,fill:C.blue,stroke:'#fff','stroke-width':2},S.g);S.X=X}
// tarqatish: total ta narsa, g ta likopcha; mode 'round' (bittadan navbat bilan) yoki 'per' (har likopchaga per tadan)
function cDeal(total,g,dealt,o){o=o||{};clear();var per=o.per,inPl=[],i;for(i=0;i<g;i++)inPl.push(0);
 for(i=0;i<dealt;i++){if(per){inPl[Math.floor(i/per)]++}else inPl[i%g]++}
 var left=total-dealt,rest=Math.min(left,40),cols=Math.min(20,Math.max(rest,1)),sp=16;
 for(i=0;i<rest;i++){var r=Math.floor(i/cols),c=i%cols;E('circle',{cx:180-(cols-1)*sp/2+c*sp,cy:20+r*15,r:5.5,fill:o.col||C.a,stroke:'rgba(0,0,0,.2)'},S.g)}
 if(left)T(S.g,346,24,String(left),{'font-size':11,'font-weight':800,fill:C.a2,'text-anchor':'end'});
 var cw=340/g,R=Math.min(30,cw/2-5);for(i=0;i<g;i++){var x=10+cw*(i+.5),y=118;E('circle',{cx:x,cy:y,r:R,fill:'#fff',stroke:'#c9b28d','stroke-width':1.6},S.g);cDots(S.g,x,y,inPl[i],R,o.col);
  T(S.g,x,y+R+13,o.who?o.who+' '+(i+1)+': '+inPl[i]:String(inPl[i]),{'font-size':10,'font-weight':800,fill:'#5b6b7b'})}
 return inPl}
async function cDealAnim(total,g,o,cb){var tok=S.tok;var n=o&&o.per?Math.floor(total/o.per)*o.per:Math.floor(total/g)*g;for(var d=1;d<=n;d++){cDeal(total,g,d,o);tok=S.tok;await wait(o&&o.fast?60:110);if(tok!==S.tok)return}cb&&cb()}
// ko'rinadigan «qutichalar» chizmasi (chizma model): n ta katak, har birida yozuv
function cBar(y,n,lab,total,o){o=o||{};var x0=40,w=280;for(var i=0;i<n;i++){E('rect',{x:x0+i*w/n,y:y,width:w/n,height:30,fill:(o.fills&&o.fills[i])||C.off,stroke:C.line,'stroke-width':1.4},S.g);T(S.g,x0+(i+.5)*w/n,y+20,typeof lab==='function'?lab(i):lab,{'font-size':12,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x0,y:y,width:w,height:30,fill:'none',stroke:C.line,'stroke-width':2.2},S.g);if(total!=null)Br(x0,x0+w,y-4,String(total),true)}

var P6=[function(){c7Box('□ : 4 = 6','');cMsg('□ ni topamiz: bo‘linuvchi = bo‘linma · bo‘luvchi')},
 function(){c7Box('□ = 6 · 4 = 24','');cMsg('□ = <b>24</b>. Tekshiramiz: 24 : 4 = 6 ✓')},
 function(){c7Box('24 : 3 = 8','');cMsg('Savol □ : 3 edi: 24 : 3 = <b>8</b>')}];
var STEPS=[
{h:"Bitta rasm — to'rtta misol",sum:"3 qator 4 tadan: 3 · 4 = 12, 4 · 3 = 12, 12 : 3 = 4, 12 : 4 = 3 — «son oilasi».",a:"m01",
 start:function(){cArr(3,4,{rowLab:1});S.f={};c7Fam()},fin:function(){cArr(3,4,{rowLab:1});S.f={a:1,b:1,c:1,d:1};c7Fam()},
 html:"<p>Massivda <b>12</b> ta nuqta: 3 qator, 4 tadan. Shu bitta rasmdan <b>to'rtta</b> misol yozish mumkin. Har birini oching:</p>",
 btns:[["3 · 4",function(c,done){S.f.a=1;c7Fam();if(c7All())done()}],["4 · 3",function(c,done){S.f.b=1;c7Fam();if(c7All())done()}],["12 : 3",function(c,done){S.f.c=1;c7Fam();if(c7All())done()}],["12 : 4",function(c,done){S.f.d=1;c7Fam();if(c7All())done()}]],g2:1,
 after:"<p>3, 4 va 12 — bitta <b>«son oilasi»</b>. Ko'paytirishni bilsangiz, bo'lish ham tayyor: 3 · 4 = 12 → 12 : 3 = 4 va 12 : 4 = 3.</p>",
 q:{t:"6 · 5 = 30 ekanini bilib, 30 : 6 ning qiymatini toping.",opts:["30","24","5","6"],ok:2,why:"6 · 5 = 30 → 30 : 6 = 5.",hint:"Oilada qaysi sonlar bor: 6, 5, 30. 30 ni 6 ga bo'lsak, qolgan son qaysi?",full:"Son oilasi: 6, 5, 30. 30 : 6 = 5 va 30 : 5 = 6. «24» — ayirish (30 − 6)."},
 tn:"«Son oilasi» uchburchagi: tepada ko'paytma (12), pastda ko'paytuvchilar (3 va 4). Yarim uchburchakni yopib, noma'lumni topish o'yini — AQSh va Singapurda keng tarqalgan."},
{h:"Amallar hadlarining nomi",sum:"ko'paytuvchi · ko'paytuvchi = ko'paytma; bo'linuvchi : bo'luvchi = bo'linma.",a:"m02",
 start:function(){c7Names(0)},fin:function(){c7Names(2)},
 html:"<p>Har bir sonning o'z <b>nomi</b> bor. Tugmalarni bosib, nomlarni ko'ring:</p>",
 btns:[["Ko'paytirish",function(c,done){c7Names(1);mvK(done,2)}],["Bo'lish",function(c,done){c7Names(2);mvK(done,2)}]],g2:1,
 after:"<p>Bog'lanish: <b>bo'linuvchi</b> — bu ko'paytma (12), <b>bo'luvchi va bo'linma</b> — bu ko'paytuvchilar (3 va 4). Nomlarni bilish masalani tushunishga yordam beradi.</p>",
 q:{t:"35 : 7 = 5 misolida 7 qanday ataladi?",opts:["Bo'linuvchi","Bo'luvchi","Bo'linma","Ko'paytma"],ok:1,why:"Nimaga bo'lamiz — bo'luvchi.",hint:"Birinchi son — bo'linuvchi, natija — bo'linma. 7 qaysi joyda?",full:"35 — bo'linuvchi (nimani bo'lamiz), 7 — bo'luvchi (nimaga bo'lamiz), 5 — bo'linma (natija)."},
 tn:"Nomlarni kartochkaga yozib, doskadagi misol ostiga bolalar o'zi qo'ysin."},
{h:"Noma'lum ko'paytuvchi",sum:"4 · □ = 24 → □ = 24 : 4 = 6. Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi.",a:"m03",
 start:function(){clear();cBar(70,4,'?',24);cMsg('4 · □ = 24: 4 ta teng bo‘lak — 24')},fin:function(){clear();cBar(70,4,'6',24);cMsg('□ = 24 : 4 = <b>6</b>')},
 html:"<p><b>4 · □ = 24</b>. Chizmada: 24 — 4 ta teng bo'lakka bo'lingan. Bitta bo'lak qancha? Tugmani bosing:</p>",
 btns:[["▶ Bo'lakni topish",function(c,done){clear();cBar(70,4,'6',24);cMsg('□ = 24 : 4 = <b>6</b>. Tekshiramiz: 4 · 6 = 24 ✓');done()}]],
 after:"<p>Qoida: <b>noma'lum ko'paytuvchini topish uchun ko'paytmani ma'lum ko'paytuvchiga bo'lamiz</b>. 4 · □ = 24 → □ = 24 : 4 = 6.</p>",
 q:{t:"Ko'paytma 24 ga, ko'paytuvchilardan biri 4 ga teng. Ikkinchi ko'paytuvchi bilan 4 ning yig'indisini toping.",opts:["28","10","6","20"],ok:1,why:"Ikkinchi ko'paytuvchi 24 : 4 = 6, 6 + 4 = 10.",hint:"Avval ikkinchi ko'paytuvchini toping.",full:"24 : 4 = 6 — ikkinchi ko'paytuvchi. Yig'indi: 6 + 4 = 10. «6» — oxirgi qadamni unutish, «28» — 24 + 4."},
 tn:"Chizma model: ko'paytma — butun chiziq, ko'paytuvchi — bo'laklar soni."},
{h:"Noma'lum bo'linuvchi va bo'luvchi",sum:"□ : 5 = 4 → □ = 4 · 5 = 20; 20 : □ = 4 → □ = 20 : 4 = 5.",a:"m04",
 start:function(){c7Box('□ : 5 = 4','?');cMsg('Noma‘lum bo‘linuvchi')},fin:function(){c7Box('□ = 4 · 5 = 20','');cMsg('Bo‘linuvchi = bo‘linma · bo‘luvchi')},
 html:"<p>Ikki holat bor. Har birini yeching:</p>",
 btns:[["□ : 5 = 4",function(c,done){c7Box('□ = 4 · 5 = 20','');cMsg('Bo‘linuvchi = bo‘linma · bo‘luvchi: □ = <b>20</b>');mvK(done,2)}],["20 : □ = 4",function(c,done){c7Box('□ = 20 : 4 = 5','');cMsg('Bo‘luvchi = bo‘linuvchi : bo‘linma: □ = <b>5</b>');mvK(done,2)}]],g2:1,
 after:"<p><b>Bo'linuvchi</b> noma'lum bo'lsa — <b>ko'paytiramiz</b>: bo'linma · bo'luvchi. <b>Bo'luvchi</b> noma'lum bo'lsa — <b>bo'lamiz</b>: bo'linuvchi : bo'linma. Javobni doim tekshiring.</p>",
 q:{t:"Bo'linma 4 ga, bo'luvchi 5 ga teng. Bo'linuvchini 2 ga ko'paytirsak, nechchi chiqadi?",opts:["8","40","20","10"],ok:1,why:"Bo'linuvchi 4 · 5 = 20, 20 · 2 = 40.",hint:"Avval bo'linuvchini toping: bo'linma · bo'luvchi.",full:"Bo'linuvchi = 4 · 5 = 20. Uni 2 ga ko'paytiramiz: 40. «20» — ikkinchi qadamni unutish."},
 tn:"Ikki qoidani adashtirmaslik uchun «son oilasi» uchburchagiga qayting."},
{h:"Bo'lishni tekshirish",sum:"Bo'lish to'g'rimi? Bo'linma · bo'luvchi = bo'linuvchi bo'lishi kerak: 42 : 6 = 7, chunki 7 · 6 = 42.",a:"m05",
 start:function(){c7Check(0)},fin:function(){c7Check(9)},
 html:"<p>Uchta o'quvchi bo'lish misollarini yechdi. Ko'paytirish bilan tekshiring — kim adashgan?</p>",
 btns:[["42 : 6 = 7",function(c,done){c7Check(1);mvK(done,3)}],["56 : 8 = 6",function(c,done){c7Check(2);mvK(done,3)}],["27 : 3 = 9",function(c,done){c7Check(3);mvK(done,3)}]],
 after:"<p>56 : 8 = 6 — <b>xato</b>, chunki 6 · 8 = 48. To'g'risi 56 : 8 = 7. Har bo'lishni ko'paytirish bilan 2 soniyada tekshirish mumkin.</p>",
 q:{t:"Uch bola gapirdi: Laziz — «32 : 4 = 9», Mahmud — «32 : 4 = 8», Sardor — «8 · 4 = 32». Kim nohaq?",opts:["Laziz","Mahmud","Sardor","Hammasi haq"],ok:0,why:"9 · 4 = 36, 32 emas.",hint:"Lazizning javobini ko'paytirish bilan tekshiring.",full:"Laziz: 9 · 4 = 36 ≠ 32 — nohaq. Mahmud: 8 · 4 = 32 ✓. Sardor: 8 · 4 = 32 ✓."},
 tn:"Har bo'lishdan keyin bolalar «tekshirish» qatorini yozsin — bu odat 3–4-sinflarda burchakli bo'lishda juda kerak bo'ladi."},
{h:"Tuzoq: ikki bosqichli noma'lum",sum:"□ : 4 = 6 → □ = 24; savol □ : 3 → 24 : 3 = 8.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=2;P6[2]()},
 html:"<p>Masala: <b>□ : 4 = 6 bo'lsa, □ : 3 nechaga teng?</b> Ko'pchilik 6 : 3 = 2 deb xato qiladi. Kuzating:</p>",
 btns:[phaser(P6)],
 after:"<p>Avval noma'lumni <b>to'liq</b> topamiz (24), keyin savolga javob beramiz (24 : 3 = 8). Bo'linma 6 — bu □ emas!</p>",
 q:{t:"Ko'paytuvchilardan biri 3 ga, ko'paytma 27 ga teng. Ikkinchi ko'paytuvchini 3 ga bo'lsak, nechchi chiqadi?",opts:["3","9","1","81"],ok:0,why:"Ikkinchi ko'paytuvchi 27 : 3 = 9, 9 : 3 = 3.",hint:"Avval ikkinchi ko'paytuvchini toping.",full:"27 : 3 = 9 — ikkinchi ko'paytuvchi. 9 : 3 = 3. «9» — oxirgi qadamni unutish, «81» — ko'paytirib yuborish."},
 tn:"Bunday masalalarda noma'lumni ramka ichiga olib, alohida qatorda yozdiring."},
{h:"Bilasizmi? Teskari amallar",sum:"Ko'paytirish va bo'lish — teskari amallar. Al-Xorazmiyning «al-jabr» kitobi aynan noma'lumni teskari amallar bilan topish haqida.",a:"m07",
 start:function(){clear('#f6ead0');T(S.g,180,70,'· ⇄ :',{'font-size':50,'font-weight':800,fill:'#6b3d12'});T(S.g,180,125,'al-Xorazmiy · «Al-jabr va al-muqobala»',{'font-size':13,fill:'#6b3d12'});cMsg('Teskari amallar')},fin:function(){STEPS[6].start()},
 html:"<p>⭐ Vatandoshimiz <b>Muhammad al-Xorazmiy</b> IX asrda «Al-jabr va al-muqobala» kitobini yozgan. Unda noma'lum sonni <b>teskari amallar</b> bilan topish usullari bor — biz bugun aynan shuni qildik: □ : 4 = 6 → □ = 6 · 4.</p><p>«Algebra» so'zi shu kitob nomidan kelib chiqqan.</p>",
 tn:"Bolalarga «siz bugun algebrachi bo'ldingiz» deyish — motivatsiya uchun ajoyib."},
{h:"Eslatma kartochka",sum:"",a:"m08",memo:1,start:function(){cArr(3,4,{rowLab:1});S.f={a:1,b:1,c:1,d:1};c7Fam()},fin:function(){STEPS[7].start()},
 html:"<div class='memo'><ul><li>Son oilasi: 3 · 4 = 12, 4 · 3 = 12, 12 : 3 = 4, 12 : 4 = 3.</li><li>ko'paytuvchi · ko'paytuvchi = <b>ko'paytma</b>; bo'linuvchi : bo'luvchi = <b>bo'linma</b>.</li><li>Noma'lum ko'paytuvchi = ko'paytma : ma'lum ko'paytuvchi.</li><li>Noma'lum bo'linuvchi = bo'linma · bo'luvchi.</li><li>Noma'lum bo'luvchi = bo'linuvchi : bo'linma.</li><li>Tekshirish: 42 : 6 = 7, chunki 7 · 6 = 42.</li><li>Avval noma'lumni to'liq toping, keyin savolga javob bering.</li></ul></div>",
 tn:"Keyingi darsni «□ · 7 = 56, □ : 2 = ?» bilan boshlang (8 → 4)."}
];
function c7All(){return S.f.a&&S.f.b&&S.f.c&&S.f.d}
function c7Fam(){var f=S.f,l=[];if(f.a)l.push('3 · 4 = 12');if(f.b)l.push('4 · 3 = 12');if(f.c)l.push('12 : 3 = 4');if(f.d)l.push('12 : 4 = 3');cMsg(l.length?l.join(' &nbsp;·&nbsp; '):'Tugmalarni bosing','Son oilasi: 3, 4, 12')}
function c7Names(k){clear();if(k===0){T(S.g,180,90,'Tugmani bosing',{'font-size':16,fill:'#9aa8b6'});cMsg('Hadlarning nomlari');return}
 var a=k===1?['3','·','4','=','12']:['12',':','3','=','4'],nm=k===1?['ko‘paytuvchi','','ko‘paytuvchi','','ko‘paytma']:['bo‘linuvchi','','bo‘luvchi','','bo‘linma'],X=[50,115,180,245,310];
 a.forEach(function(t,i){T(S.g,X[i],80,t,{'font-size':32,'font-weight':800,fill:i%2?'#9aa8b6':'#1d2b3a'});if(nm[i])T(S.g,X[i],116,nm[i],{'font-size':11,'font-weight':800,fill:C.blue})});cMsg(k===1?'3 · 4 = 12':'12 : 3 = 4')}
function c7Box(t,sub){clear();T(S.g,180,92,t,{'font-size':32,'font-weight':800,fill:'#1d2b3a'})}
function c7Check(k){clear();S.ck=S.ck||{};if(k===0)S.ck={};else if(k===9)S.ck={1:1,2:1,3:1};else S.ck[k]=1;var L=[['42 : 6 = 7','7 · 6 = 42 ✓',C.ok],['56 : 8 = 6','6 · 8 = 48 ≠ 56 ✗',C.bad],['27 : 3 = 9','9 · 3 = 27 ✓',C.ok]];
 L.forEach(function(r,i){T(S.g,100,50+i*40,r[0],{'font-size':18,'font-weight':800,fill:'#1d2b3a'});if(S.ck[i+1])T(S.g,255,50+i*40,r[1],{'font-size':16,'font-weight':800,fill:r[2]})});cMsg(Object.keys(S.ck).length?'Tekshirish: bo‘linma · bo‘luvchi = bo‘linuvchi?':'Qaysi misolni tekshiramiz?')}
var PROBS=[
{t:"6 · 5 = 30 ekanini bilib, 30 : 6 ning qiymatini toping.",o:["5","30","24","6"],k:0,s:"6 · 5 = 30 → 30 : 6 = 5."},
{t:"4 · □ = 28. □ nechaga teng?",o:["7","24","32","8"],k:0,s:"□ = 28 : 4 = 7."},
{t:"□ : 5 = 6. □ nechaga teng?",o:["30","11","1","35"],k:0,s:"□ = 6 · 5 = 30."},
{t:"36 : □ = 4. □ nechaga teng?",o:["9","32","40","8"],k:0,s:"□ = 36 : 4 = 9."},
{t:"35 : 7 = 5 misolida 7 qanday ataladi?",o:["Bo'luvchi","Bo'linuvchi","Bo'linma","Ko'paytma"],k:0,s:"Nimaga bo'lamiz — bo'luvchi."},
{t:"Ko'paytma 24 ga, ko'paytuvchilardan biri 4 ga teng. Ikkinchi ko'paytuvchi bilan 4 ning yig'indisini toping.",o:["10","28","6","20"],k:0,s:"24 : 4 = 6, 6 + 4 = 10."},
{t:"Ko'paytma 30, birinchi ko'paytuvchi 5. Ikkinchi ko'paytuvchidan 2 ni ayirsak, nechchi qoladi?",o:["4","6","8","28"],k:0,s:"30 : 5 = 6, 6 − 2 = 4."},
{t:"Bo'linma 4 ga, bo'luvchi 5 ga teng. Bo'linuvchini 2 ga ko'paytirsak, nechchi chiqadi?",o:["40","8","20","10"],k:0,s:"Bo'linuvchi 20, 20 · 2 = 40."},
{t:"Ko'paytuvchilardan biri 3 ga, ko'paytma 27 ga teng. Ikkinchi ko'paytuvchini 3 ga bo'lsak, nechchi chiqadi?",o:["3","9","1","81"],k:0,s:"27 : 3 = 9, 9 : 3 = 3."},
{t:"□ : 4 = 6 bo'lsa, □ : 3 nechaga teng?",o:["8","2","6","18"],k:0,s:"□ = 24, 24 : 3 = 8."},
{t:"Qaysi bo'lish XATO?",o:["56 : 8 = 6","42 : 6 = 7","27 : 3 = 9","24 : 4 = 6"],k:0,s:"6 · 8 = 48 ≠ 56."},
{t:"3, 7 va 21 sonlari bilan qaysi misolni yozib BO'LMAYDI?",o:["7 : 3 = 21","3 · 7 = 21","21 : 7 = 3","21 : 3 = 7"],k:0,s:"7 : 3 ≠ 21. Qolganlari son oilasi."},
{t:"□ · 7 = 56 bo'lsa, □ : 2 nechaga teng?",o:["4","8","28","49"],k:0,s:"□ = 56 : 7 = 8, 8 : 2 = 4."},
{t:"Bo'linuvchi 40, bo'linma 8. Bo'luvchi nechaga teng?",o:["5","32","48","320"],k:0,s:"Bo'luvchi = 40 : 8 = 5."},
{t:"Noma'lum ko'paytuvchini qanday topamiz?",o:["Ko'paytmani ma'lum ko'paytuvchiga bo'lamiz","Ko'paytmani ma'lum ko'paytuvchiga ko'paytiramiz","Ko'paytmadan ko'paytuvchini ayiramiz","Ikkalasini qo'shamiz"],k:0,s:"4 · □ = 24 → □ = 24 : 4."},
{t:"9 · 4 = 36 ga mos bo'lish misoli qaysi?",o:["36 : 9 = 4","36 : 6 = 6","9 : 4 = 36","36 : 3 = 12"],k:0,s:"Son oilasi: 9, 4, 36."},
{t:"Bir son 6 ga ko'paytirilganda 42 chiqdi. Shu sonni 7 ga ko'paytirsak, nechchi chiqadi?",o:["49","42","36","56"],k:0,s:"Son 42 : 6 = 7, 7 · 7 = 49."},
{t:"Bir son 5 ga bo'linganda 3 chiqdi. Shu sonni 3 ga bo'lsak, nechchi chiqadi?",o:["5","1","15","9"],k:0,s:"Son 3 · 5 = 15, 15 : 3 = 5."},
{t:"a · 8 = 32 va b : 4 = 2. a + b nechaga teng?",o:["12","6","40","10"],k:0,s:"a = 4, b = 8, 4 + 8 = 12."},
{t:"Bo'linma — bu qaysi son?",o:["Bo'lish natijasi","Birinchi son","Ikkinchi son","Ko'paytirish natijasi"],k:0,s:"Bo'linma — bo'lish natijasi."}
];
function PRACT_STAGE(){cArr(3,4,{rowLab:1});cMsg('3 · 4 = 12 ⇄ 12 : 3 = 4 ⇄ 12 : 4 = 3')}
var PREP_DATA={teach:["«Son oilasi»: bitta massivdan to'rtta misol.","Hadlarning nomlari: ko'paytuvchi, ko'paytma, bo'linuvchi, bo'luvchi, bo'linma.","Noma'lum ko'paytuvchi, bo'linuvchi, bo'luvchini topish qoidalari.","Bo'lishni ko'paytirish bilan tekshirish; ikki bosqichli noma'lum."],
 mist:["Bo'luvchi va bo'linmani adashtiradi.","Noma'lum bo'linuvchini topishda bo'lib yuboradi (□ : 5 = 4 → 4 : 5).","Oraliq natijani javob deb yozadi (□ : 4 = 6 → □ : 3 = 2).","Tekshirishni o'tkazib yuboradi."],
 need:["Son oilasi uchburchagi kartochkalari.","Doskada massiv."],
 board:["Uchburchak: <span class='w2'>12 / 3 · 4</span>.","<span class='w2'>3 · 4 = 12, 12 : 3 = 4</span>.","Nomlar sxemasi.","<span class='w2'>4 · □ = 24 → □ = 24 : 4</span>.","<span class='w2'>□ : 5 = 4 → □ = 4 · 5</span>.","<span class='w2'>□ : 4 = 6 → □ = 24 → 24 : 3 = 8</span>."]};
