var CODE='4B1',TITLE='4-sinf · Ko‘p xonali sonlarni qo‘shish va ayirish';
var A4BL=['birliklar','o‘nliklar','yuzliklar','minglar','o‘n minglar','yuz minglar','millionlar'];
function a4bP(a,b,op,last){var r=op==='+'?a+b:a-b,n=String(Math.max(a,b,r)).length,P=[],sa=String(a),sb=String(b),c=0,msgs=[];
 for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0),m;
  if(op==='+'){var s=da+db+c;m=A4BL[k]+': '+da+' + '+db+(c?' + 1':'')+' = '+s+(s>9?' → '+(s%10)+' yozamiz, 1 o‘tadi':'');c=s>9?1:0}
  else{var x=da-c;if(x<db){m=A4BL[k]+': '+(c&&da===0?'0 (qarz bergan) → ':'')+x+' dan '+db+' ayrilmaydi → qarz: '+(x+10)+' − '+db+' = '+(x+10-db);c=1}else{m=A4BL[k]+': '+x+' − '+db+' = '+(x-db);c=0}}
  msgs.push(m)}
 P.push(function(){bqCol(a,b,op,0);bqMsg('Xonalarni o‘ng chetdan tekislab yozdik. Birliklardan boshlaymiz')});
 msgs.forEach(function(m,k){P.push(function(){bqCol(a,b,op,k+1,{hl:k});bqMsg(k===n-1?m+'<br><b>Javob: '+fmt(r)+'</b>'+(last?' — '+last:''):m)})});return P}
var P1=a4bP(4625387,2478965,'+'),P2=a4bP(5000000,1234567,'-','nollardan qarz zanjiri');
function a4bF(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
var STEPS=[
{h:"Ustunda qo'shish",sum:"4 625 387 + 2 478 965 = 7 104 352 — xonama-xona, o'ngdan.",a:"m01",
 start:function(){startPh(P1)},fin:a4bF(P1),
 html:"<p>Katta sonlarni qo'shish 3 xonali sonlarnikidek: <b>o'ng chetdan tekislab</b> yozamiz, birliklardan boshlaymiz, 10 dan oshsa — 1 keyingi xonaga o'tadi. Har bir xonani kuzating:</p>",
 btns:[phaser(P1,'▶ Keyingi xona')],
 after:"<p>Bitta xonada yig'indi ko'pi bilan 9 + 9 + 1 = 19 bo'ladi, shuning uchun keyingi xonaga doim faqat <b>1</b> o'tadi (ikki son qo'shilganda). O'tgan 1 ni xona ustiga kichik qilib yozib qo'ying — unutmaslik uchun.</p>",
 q:{t:"3 586 + 4 727 = ?",opts:["8 313","7 213","8 213","7 313"],ok:0,why:"6+7=13, 8+2+1=11, 5+7+1=13, 3+4+1=8.",hint:"Har bir xonada o'tkazish bor!",full:"Birliklar 13 → 3, 1 o'tadi; o'nliklar 8+2+1 = 11 → 1, 1 o'tadi; yuzliklar 5+7+1 = 13 → 3, 1 o'tadi; minglar 3+4+1 = 8. Javob 8 313. Boshqa variantlar — o'tkazilgan 1 ni unutish."},
 tn:"Xonalar jadvali chizilgan daftar (katakcha) — har raqam o'z katagiga. Yaponiya: bola har xonani ovoz chiqarib aytadi."},
{h:"Nollardan qarz olish",sum:"5 000 000 − 1 234 567 = 3 765 433: qarz zanjir bo'lib chapga boradi.",a:"m02",
 start:function(){startPh(P2)},fin:a4bF(P2),
 html:"<p>Eng qiyin holat — kamayuvchida ko'p nol. Birliklarda 0 dan 7 ayrilmaydi, qo'shnilar ham 0… Qarz qayerdan keladi? Kuzating:</p>",
 btns:[phaser(P2,'▶ Keyingi xona')],
 after:"<p>Qarz birinchi nol bo'lmagan xonadan olinadi (5 → 4), oradagi nollar <b>9</b> ga aylanadi, birliklar esa <b>10</b> bo'ladi. Qisqa yo'l: 5 000 000 = 4 999 999 + 1 → 4 999 999 − 1 234 567 = 3 765 432, keyin +1 = <b>3 765 433</b>.</p>",
 q:{t:"40 000 − 2 368 = ?",opts:["37 632","38 632","37 742","42 368"],ok:0,why:"39 999 − 2 368 = 37 631, +1 = 37 632.",hint:"40 000 = 39 999 + 1.",full:"39 999 − 2 368 = 37 631 (qarzsiz), keyin + 1 = 37 632. «38 632» — qarz olingan 4 → 3 ni unutish; «42 368» — qo'shib yuborish."},
 tn:"«4 999 999 + 1» usuli — qarzsiz ayirish (Singapur kompensatsiya usuli)."},
{h:"Ayirishni tekshirish",sum:"Ayirma + ayriluvchi = kamayuvchi: 3 765 433 + 1 234 567 = 5 000 000.",a:"m03",
 start:function(){bqCol(3765433,1234567,'+',0);bqMsg('Javobni qo‘shish bilan tekshiramiz')},fin:function(){bqCol(3765433,1234567,'+');bqMsg('5 000 000 chiqdi — ayirish <b>to‘g‘ri</b>')},
 html:"<p>Ayirish to'g'riligini qanday tekshiramiz? Qaysi amal kerak?</p>",
 btns:a4ch(["ayirma + ayriluvchi","ayirma + kamayuvchi","kamayuvchi − ayirma − ayriluvchi = ayirma"],0,function(){bqCol(3765433,1234567,'+');bqMsg('3 765 433 + 1 234 567 = <b>5 000 000</b> ✓')},function(i){bqMsg(i===1?'Bu kamayuvchidan ham katta son beradi':'Murakkab va keraksiz — oddiy qo‘shish yetarli')}),
 after:"<p>Qo'shishni esa <b>ayirish</b> bilan tekshiramiz: yig'indi − bir qo'shiluvchi = ikkinchi qo'shiluvchi. Tekshirish 30 soniya oladi, lekin xatoni albatta topadi.</p>",
 q:{t:"Ali 8 205 − 3 467 = 4 838 deb topdi. Tekshirish nima ko'rsatadi?",opts:["4 838 + 3 467 = 8 305 — xato, javob 4 738","To'g'ri","4 838 − 3 467 = 1 371 — xato","8 205 + 3 467 = 11 672 — to'g'ri"],ok:0,why:"Yig'indi 8 205 emas, 8 305 chiqdi.",hint:"Ayirma + ayriluvchi kamayuvchiga tengmi?",full:"4 838 + 3 467 = 8 305 ≠ 8 205. Demak 100 ga xato: to'g'ri javob 4 738 (yuzliklarda qarz unutilgan)."},
 tn:"Har bir ayirishdan keyin tekshiruv ustuni — odatga aylantiring."},
{h:"Tuzoq: tekislash",sum:"45 300 + 2 708 = 48 008: sonlar O'NG chetdan tekislanadi.",a:"m04",
 start:function(){bqCol(45300,2708,'+',0);bqMsg('Birliklar ostida birliklar')},fin:function(){bqCol(45300,2708,'+');bqMsg('45 300 + 2 708 = <b>48 008</b>')},
 html:"<p>Har xil xonali sonlarni qo'shamiz: 45 300 + 2 708. Javobni tanlang:</p>",
 btns:a4ch(["72 380","48 008","47 008","48 018"],1,function(){bqCol(45300,2708,'+');bqMsg('O‘ng chetdan: 300 + 708 = 1 008, minglar 45 + 2 + 1 = 48 → <b>48 008</b>')},function(i){bqMsg(i===0?'Bu — sonlarni CHAP chetdan yozish xatosi (45 300 + 27 080)':i===2?'Yuzliklarda 3 + 7 = 10 — 1 mingga o‘tadi!':'Birliklar: 0 + 8 = 8, o‘nliklar 0 + 0 = 0')}),g2:1,
 after:"<p>Matnda sonlar yonma-yon berilsa, ularni ustunga ko'chirayotganda <b>oxirgi raqamlarni</b> bir chiziqqa qo'ying. Katakli daftar yordam beradi.</p>",
 q:{t:"602 040 − 9 506 = ?",opts:["592 534","592 544","507 980","593 534"],ok:0,why:"602 040 − 9 506 = 592 534.",hint:"O'ng chetdan tekislang; birliklarda 0 − 6 — qarz.",full:"Birliklar: 10 − 6 = 4 (o'nliklardan qarz: 4 → 3); o'nliklar 3 − 0 = 3; yuzliklar 0 − 5 → qarz: 10 − 5 = 5 (minglar 2 → 1); minglar 1 − 9 → qarz: 11 − 9 = 2 (o'n minglar 0 → 9, yuz minglar 6 → 5); o'n minglar 9; yuz minglar 5. 592 534."},
 tn:"Bank 4B1-turi: matnli misollarda sonlarni ustunga ko'chirish xatosi eng ko'p uchraydi."},
{h:"Yashirin raqamlar",sum:"6 □48 − 2 7□9 = 3 859 → 6 648 − 2 789.",a:"m05",
 start:function(){bqExpr(['6 [□]48 − 2 7[□]9 = 3 859','O‘ngdan tiklaymiz']);bqMsg('Ayirishni qo‘shishga aylantiring: 3 859 + 2 7□9 = 6 □48')},fin:function(){bqCol(6648,2789,'-');bqMsg('6 648 − 2 789 = 3 859 ✓')},
 html:"<p>Yashirin raqamlarni toping: <b>6 □48 − 2 7□9 = 3 859</b>. (Birinchi □ va ikkinchi □)</p>",
 btns:a4ch(["6 va 8","5 va 8","6 va 9","7 va 8"],0,function(){bqCol(6648,2789,'-');bqMsg('3 859 + 2 7□9: birliklar 9 + 9 = 18 → 8 ✓; o‘nliklar 5 + □ + 1 = …4 → □ = 8; yuzliklar 8 + 7 + 1 = 16 → <b>6</b>')},function(){bqMsg('Qo‘shish bilan tekshiring: 3 859 + 2 7□9 = 6 □48. O‘nliklardan boshlang')}),g2:1,
 after:"<p>Usul: ayirishni <b>qo'shishga</b> aylantiramiz (ayirma + ayriluvchi = kamayuvchi) va o'ngdan xonama-xona tiklaymiz. O'tkazishlarni hisobga olish — asosiy kalit.</p>",
 q:{t:"□3□ + 2□7 = 1 000. Uchala yashirin raqam yig'indisi:",opts:["16","17","15","20"],ok:0,why:"733 + 267 = 1 000: 7 + 3 + 6 = 16.",hint:"Birliklar: □ + 7 = 10.",full:"Birliklar: □ + 7 = 10 → □ = 3, 1 o'tadi. O'nliklar: 3 + □ + 1 = 10 → □ = 6, 1 o'tadi. Yuzliklar: □ + 2 + 1 = 10 → □ = 7. 733 + 267 = 1 000. Yig'indi: 7 + 3 + 6 = 16. «17» — o'tgan 1 ni hisobga olmay o'nliklarda □ = 7 deb olish."},
 tn:"Bank 4B1 qiyin turi. Bolalar o'zlari yashirin raqamli misol tuzib, qo'shnisiga bersin."},
{h:"Ikki bosqichli masala",sum:"1-ombor 2 345 600 kg, 2-si 487 900 kg kam: jami 4 203 300 kg.",a:"m06",
 start:function(){bqBar(null,[{v:'2 345 600'}],{title:'1-ombor va 2-ombor',y:50});T(S.g,22,73,'1',{'font-size':12,'font-weight':800,fill:'#5b6b7b'});T(S.g,22,145,'2',{'font-size':12,'font-weight':800,fill:'#5b6b7b'});var g=S.g;E('rect',{x:30,y:126,width:238,height:30,fill:C.b||'#cfe6f7',stroke:C.line,'stroke-width':1.5},g);T(g,149,146,'? (2-ombor)',{'font-size':14,'font-weight':800,fill:C.bad});E('rect',{x:268,y:126,width:62,height:30,fill:'#fff',stroke:C.bad,'stroke-width':1.5,'stroke-dasharray':'5 4'},g);T(g,299,146,'−487 900',{'font-size':10,'font-weight':800,fill:C.bad});bqMsg('Avval 2-omborni topamiz')},
 fin:function(){bqBar('4 203 300',[{v:'2 345 600',lab:'1-ombor'},{v:'1 857 700',lab:'2-ombor'}],{title:'Jami'});bqMsg('2 345 600 + 1 857 700 = <b>4 203 300</b> kg')},
 html:"<p>1-omborda 2 345 600 kg don, 2-omborda undan 487 900 kg kam. Ikkala omborda <b>jami</b> qancha don bor?</p>",
 btns:a4ch(["1 857 700 kg","4 203 300 kg","2 833 500 kg"],1,function(){bqBar('4 203 300',[{v:'2 345 600',lab:'1-ombor'},{v:'1 857 700',lab:'2-ombor'}],{title:'Jami'});bqMsg('2-ombor: 2 345 600 − 487 900 = 1 857 700. Jami: <b>4 203 300</b>')},function(i){bqMsg(i===0?'Bu faqat 2-ombor. Savol — jami!':'«Kam» — ayirish, qo‘shish emas: 2-ombor 2 345 600 − 487 900')}),g3:1,
 after:"<p>Ikki bosqichli masalada «<b>jami</b>», «<b>ikkalasida</b>» degan so'zlar — ikkinchi amalni bildiradi. Chizma model bilan oraliq javob (2-ombor) ko'rinib turadi va unda to'xtab qolmaysiz.</p>",
 q:{t:"Kitobxonada 125 400 ta kitob bor edi. 18 750 tasi berildi, 9 600 tasi keltirildi. Nechta bo'ldi?",opts:["116 250","134 250","97 050","106 650"],ok:0,why:"125 400 − 18 750 + 9 600 = 116 250.",hint:"Berildi — kamaydi, keltirildi — ko'paydi.",full:"125 400 − 18 750 = 106 650; 106 650 + 9 600 = 116 250. «106 650» — ikkinchi amalni unutish; «134 250» — ishoralarni almashtirish."},
 tn:"Chizma modelni doskada chizish — bolalar raqamlarni o'zlari joylaydi (Singapur)."},
{h:"Ayirma qanday o'zgaradi?",sum:"Kamayuvchi +300, ayriluvchi +500 → ayirma 200 ga kamayadi.",a:"m07",
 start:function(){bqLine(0,1000,[[300,700,'ayirma 400',C.blue]],[[300,C.bad],[700,C.blue]],{step:100});msg('Ayirma — ikki son orasidagi masofa')},
 fin:function(){bqLine(0,1000,[[800,1000,'200',C.ok]],[[800,C.bad],[1000,C.blue]],{step:100});T(S.g,180,166,'(700 + 300) − (300 + 500) = 200',{'font-size':12,'font-weight':800,fill:C.ok});msg('Masofa 400 dan 200 ga qisqardi: +300 − 500 = −200')},
 html:"<p>Kamayuvchini 300 ga, ayriluvchini 500 ga oshirsak, ayirma qanday o'zgaradi?</p>",
 btns:a4ch(["200 ga oshadi","200 ga kamayadi","800 ga oshadi","o'zgarmaydi"],1,function(){STEPS[6].fin();bqMsg('Kamayuvchi +300 → ayirma +300; ayriluvchi +500 → ayirma −500. Jami: <b>−200</b>')},function(i){bqMsg(i===0?'Ayriluvchi oshsa — ayirma kamayadi!':i===2?'300 + 500 — ayriluvchining oshishi ayirmani kamaytiradi':'O‘zgarmaydi — faqat ikkalasi bir xil oshsa')}),g2:1,
 after:"<p>Qoida: kamayuvchi oshsa — ayirma oshadi; ayriluvchi oshsa — ayirma <b>kamayadi</b>; ikkalasi bir xil o'zgarsa — ayirma o'zgarmaydi. Bu qoidadan qulay hisoblashda foydalanamiz: 5 002 − 1 998 = 5 004 − 2 000 = 3 004.</p>",
 q:{t:"Yig'indida bir qo'shiluvchi 1 250 ga oshdi, ikkinchisi 800 ga kamaydi. Yig'indi:",opts:["450 ga oshadi","2 050 ga oshadi","450 ga kamayadi","o'zgarmaydi"],ok:0,why:"+1 250 − 800 = +450.",hint:"Har bir o'zgarishni yig'indiga qo'shing.",full:"Birinchi qo'shiluvchi +1 250 → yig'indi +1 250; ikkinchisi −800 → yig'indi −800. Natija: +450."},
 tn:"Bank 4B1/3B6-turi. Son o'qida ikki nuqtani surib ko'rsating."},
{h:"Uchta sonni qo'shish: 2 o'tadi",sum:"8 796 + 9 587 + 7 958 = 26 341: birliklarda 21 → 2 o'tadi.",a:"m08",
 start:function(){bqExpr(['8 796 + 9 587 + 7 958','birliklar: 6 + 7 + 8 = ?']);bqMsg('Uch son qo‘shilsa — o‘tkazish 2 bo‘lishi mumkin')},fin:function(){bqExpr(['6+7+8=21 → 1, [2] o‘tadi','9+8+5+2=24 → 4, [2] o‘tadi','7+5+9+2=23 → 3, [2] o‘tadi','8+9+7+2=26 → 26 341']);bqMsg('8 796 + 9 587 + 7 958 = <b>26 341</b>')},
 html:"<p>8 796 + 9 587 + 7 958 = ? Uch son ustunda qo'shilganda nechta o'tishi mumkin?</p>",
 btns:a4ch(["26 341","24 341","26 241","25 341"],0,function(){bqExpr(['6+7+8=21 → 1, [2] o‘tadi','9+8+5+2=24 → 4, [2] o‘tadi','7+5+9+2=23 → 3, [2] o‘tadi','8+9+7+2=26 → 26 341']);bqMsg('Har xonada <b>2</b> o‘tdi')},function(){bqMsg('Uch son qo‘shilganda 1 emas, 2 ham o‘tishi mumkin: 6 + 7 + 8 = 21')}),g2:1,
 after:"<p>Uchta son: bitta xonada ko'pi bilan 9 + 9 + 9 + 2 = 29, shuning uchun <b>2</b> gacha o'tadi. O'tganini ustiga aniq yozing — «1» deb odatlanib qolmang.</p>",
 q:{t:"Uchta sonning yig'indisi 100 000. Ikkitasi 37 456 va 28 979. Uchinchisi:",opts:["33 565","33 465","34 565","66 435"],ok:0,why:"37 456 + 28 979 = 66 435; 100 000 − 66 435 = 33 565.",hint:"Avval ikkitasini qo'shing.",full:"37 456 + 28 979 = 66 435; 100 000 − 66 435 = 33 565. «66 435» — ikkitasining yig'indisi; «33 465» — nollardan qarz xatosi."},
 tn:"3 ta son — 3 xil rangli ruchka bilan yozish."},
{h:"Bilasizmi?",sum:"«+» va «−» belgilari birinchi marta 1489-yilda bosma kitobda paydo bo'lgan.",a:"m09",
 start:function(){bqExpr(['+   −','1489']);bqMsg('Yoxann Vidman')},fin:function(){bqExpr(['+   −','1489']);bqMsg('Yoxann Vidman')},
 html:"<p>➕➖ Bugun oddiy ko'rinadigan <b>+</b> va <b>−</b> belgilari birinchi marta 1489-yilda nemis matematigi <b>Yoxann Vidman</b> kitobida bosilgan. Undan oldin «qo'shish» va «ayirish» so'z bilan yozilardi. «=» belgisi esa ancha keyin — 1557-yilda (Robert Rekord) paydo bo'lgan.</p>",
 tn:"Bolalar «+» va «−» belgilarisiz misol yozib ko'rsin — qanchalik noqulayligini his qilishadi."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){bqCol(4625387,2478965,'+')},fin:function(){bqCol(4625387,2478965,'+')},
 html:"<div class='memo'><ul><li>O'ng chetdan tekislang, birliklardan boshlang.</li><li>Qo'shish: 10 dan oshsa — 1 o'tadi (uch sonda — 2 gacha).</li><li>Nollardan qarz: 5 000 000 = 4 999 999 + 1.</li><li>Tekshirish: ayirma + ayriluvchi = kamayuvchi.</li><li>Yashirin raqam — ayirishni qo'shishga aylantiring.</li><li>Ayriluvchi oshsa — ayirma kamayadi.</li></ul></div>",
 tn:"Keyingi dars — noma'lum komponentni topish."}
];
var PROBS=[
{t:"4 625 387 + 2 478 965 = ?",o:["7 104 352","6 104 352","7 103 352","7 094 352"],k:0,s:"Har xonada o'tkazish."},
{t:"3 586 + 4 727 = ?",o:["8 313","7 213","8 213","7 313"],k:0,s:"Uchta o'tkazish."},
{t:"5 000 000 − 1 234 567 = ?",o:["3 765 433","3 765 432","4 765 433","3 875 433"],k:0,s:"4 999 999 − 1 234 567 + 1."},
{t:"40 000 − 2 368 = ?",o:["37 632","38 632","37 742","37 732"],k:0,s:"39 999 − 2 368 + 1."},
{t:"45 300 + 2 708 = ?",o:["48 008","72 380","47 008","48 018"],k:0,s:"O'ng chetdan tekislash."},
{t:"602 040 − 9 506 = ?",o:["592 534","592 544","507 980","593 534"],k:0,s:"Qarzlar zanjiri."},
{t:"Ali 8 205 − 3 467 = 4 838 deb topdi. To'g'ri javob:",o:["4 738","4 838","4 748","5 838"],k:0,s:"4 838 + 3 467 = 8 305 ≠ 8 205."},
{t:"6 □48 − 2 7□9 = 3 859. Yashirin raqamlar:",o:["6 va 8","5 va 8","6 va 9","7 va 8"],k:0,s:"6 648 − 2 789."},
{t:"□3□ + 2□7 = 1 000. Uchala yashirin raqam yig'indisi:",o:["16","17","15","18"],k:0,s:"733 + 267: 7 + 3 + 6."},
{t:"1-ombor 2 345 600 kg, 2-si 487 900 kg kam. Jami:",o:["4 203 300 kg","1 857 700 kg","2 833 500 kg","5 179 100 kg"],k:0,s:"2 345 600 + 1 857 700."},
{t:"125 400 kitob; 18 750 tasi berildi, 9 600 tasi keltirildi. Nechta bo'ldi?",o:["116 250","134 250","106 650","97 050"],k:0,s:"− 18 750 + 9 600."},
{t:"Kamayuvchi +300, ayriluvchi +500. Ayirma:",o:["200 ga kamayadi","200 ga oshadi","800 ga oshadi","o'zgarmaydi"],k:0,s:"+300 − 500."},
{t:"Bir qo'shiluvchi +1 250, ikkinchisi −800. Yig'indi:",o:["450 ga oshadi","2 050 ga oshadi","450 ga kamayadi","o'zgarmaydi"],k:0,s:"+1 250 − 800."},
{t:"8 796 + 9 587 + 7 958 = ?",o:["26 341","24 341","26 241","25 341"],k:0,s:"Har xonada 2 o'tadi."},
{t:"Uchta son yig'indisi 100 000, ikkitasi 37 456 va 28 979. Uchinchisi:",o:["33 565","33 465","34 565","66 435"],k:0,s:"100 000 − 66 435."},
{t:"Eng katta besh xonali son va eng kichik to'rt xonali son yig'indisi:",o:["100 999","109 999","100 998","99 999 999"],k:0,s:"99 999 + 1 000."},
{t:"Qaysi son 1 000 000 dan 1 ta kichik bo'lgan sondan 999 ta katta?",o:["1 000 998","999 999","1 000 999","1 999 998"],k:0,s:"999 999 + 999."},
{t:"Ayirma 2 450. Kamayuvchini 1 000 ga kamaytirib, ayriluvchini 1 000 ga oshirsak, ayirma:",o:["450","2 450","3 450","4 450"],k:0,s:"2 450 − 1 000 − 1 000."},
{t:"Zavod yanvarda 48 750 ta, fevralda yanvardan 3 980 ta ko'p, martda fevraldan 7 250 ta kam mahsulot chiqardi. Martda:",o:["45 480","52 730","59 980","37 520"],k:0,s:"48 750 + 3 980 − 7 250."},
{t:"Ikki sonning yig'indisi 70 000, biri ikkinchisidan 12 000 ta katta. Kattasi:",o:["41 000","29 000","58 000","35 000"],k:0,s:"(70 000 + 12 000) : 2."}
];
function PRACT_STAGE(){bqCol(4625387,2478965,'+')}
var PREP_DATA={teach:["Ko'p xonali sonlarni ustunda qo'shish va ayirish (7 xonagacha).","Nollardan qarz olish, tekshirish, tekislash tuzog'i.","Yashirin raqamlar, ikki bosqichli masalalar, ayirma/yig'indining o'zgarishi."],mist:["Sonlarni chap chetdan tekislaydi.","Nollardan qarz olganda oradagi nollarni 9 ga aylantirmaydi.","Uch son qo'shilganda faqat 1 o'tkazadi.","Ikki bosqichli masalada oraliq javobda to'xtaydi."],need:["Katakli daftar, xonalar jadvali, rangli ruchkalar."],board:["<span class='w2'>4 625 387 + 2 478 965 = 7 104 352</span>.","<span class='w2'>5 000 000 − 1 234 567 = 3 765 433</span>.","<span class='w2'>ayirma + ayriluvchi = kamayuvchi</span>.","<span class='w2'>45 300 + 2 708 = 48 008</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
// ---------- qo'shish-ayirish bo'limi uchun sahna vositalari (bq…) ----------
function bqMsg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// chizma model: butun chiziq + qismlar. parts: [{v:matn, w:og'irlik, col, q:true(noma'lum)}]
function bqBar(total,parts,o){o=o||{};clear();var g=S.g,x0=30,W=300,y=o.y||70,h=36,sum=parts.reduce(function(a,p){return a+(p.w||1)},0),x=x0;
 if(o.title)T(g,180,20,o.title,{'font-size':12,'font-weight':700,fill:'#3a4a5a'});
 parts.forEach(function(p){var w=W*(p.w||1)/sum;E('rect',{x:x,y:y,width:w,height:h,fill:p.q?'#fff':(p.col||C.a),stroke:p.q?C.bad:C.line,'stroke-width':p.q?2.5:1.5,'stroke-dasharray':p.q?'6 4':''},g);
  T(g,x+w/2,y+h/2+6,p.v,{'font-size':16,'font-weight':800,fill:p.q?C.bad:'#2b2b2b'});if(p.lab)T(g,x+w/2,y+h+18,p.lab,{'font-size':11,fill:'#5b6b7b'});x+=w});
 E('rect',{x:x0,y:y,width:W,height:h,fill:'none',stroke:C.line,'stroke-width':2.4},g);
 if(total!=null)Br(x0,x0+W,y-4,String(total),true,o.tq?C.bad:C.blue)}
// tarozi: chap va o'ng pallalar (narsalar ro'yxati), tilt: -1 chap og'ir, 0 teng, 1 o'ng og'ir
function bqScale(L,R,tilt){clear();var g=S.g,a=(tilt||0)*8,cx=180,cy=56;E('path',{d:'M'+(cx-30)+' 168 L'+cx+' 128 L'+(cx+30)+' 168 Z',fill:'#c9d3dd'},g);E('line',{x1:cx,y1:128,x2:cx,y2:cy,stroke:'#6b7b8b','stroke-width':5},g);
 var dx=116,ly=cy-a,ry=cy+a;E('line',{x1:cx-dx,y1:ly,x2:cx+dx,y2:ry,stroke:'#6b7b8b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:6,fill:'#33475b'},g);
 [[L,cx-dx,ly],[R,cx+dx,ry]].forEach(function(z){var px=z[1],py=z[2]+40;E('line',{x1:px-44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('line',{x1:px+44,y1:py,x2:px,y2:z[2],stroke:'#9aa8b6','stroke-width':1.5},g);E('path',{d:'M'+(px-50)+' '+py+' Q'+px+' '+(py+14)+' '+(px+50)+' '+py+' Z',fill:'#e3ebf3',stroke:'#9aa8b6'},g);
  var n=z[0].length,bw=Math.min(40,92/n);z[0].forEach(function(it,i){var bx=px-n*bw/2+i*bw;var q=String(it).indexOf('?')>=0||/^[a-z]$/.test(String(it));E('rect',{x:bx+1,y:py-28,width:bw-2,height:26,rx:4,fill:q?'#fff':C.a,stroke:q?C.bad:C.line,'stroke-width':q?2:1.2,'stroke-dasharray':q?'4 3':''},g);T(g,bx+bw/2,py-10,String(it),{'font-size':bw<30?10:13,'font-weight':800,fill:q?C.bad:'#2b2b2b'})})})}
// son o'qi va sakrashlar: jumps [[a,b,label,col]]
function bqLine(from,to,jumps,marks,o){o=o||{};clear();var x0=22,x1=338,y=o.y||110,k=(x1-x0)/(to-from),X=function(v){return x0+(v-from)*k};S.X=X;var g=S.g,step=o.step||(to-from>40?10:(to-from>20?5:1));
 E('line',{x1:x0-8,y1:y,x2:x1+8,y2:y,stroke:'#33475b','stroke-width':2.5},g);
 for(var v=from;v<=to;v++){var big=v%step===0;if(to-from<=60||big)E('line',{x1:X(v),y1:y-(big?8:4),x2:X(v),y2:y+(big?8:4),stroke:'#33475b','stroke-width':big?2:1},g);if(big)T(g,X(v),y+24,String(v),{'font-size':11,fill:'#5b6b7b'})}
 (jumps||[]).forEach(function(j,i){var a=X(j[0]),b=X(j[1]),h=Math.min(60,28+Math.abs(b-a)*.3),c=j[3]||(j[1]>j[0]?C.ok:C.bad);E('path',{d:'M'+a+' '+(y-8)+' Q'+(a+b)/2+' '+(y-8-h*2)+' '+b+' '+(y-8),fill:'none',stroke:c,'stroke-width':2.2},g);
  E('path',{d:'M'+(b-5*(b>a?1:-1))+' '+(y-16)+' L'+b+' '+(y-8)+' L'+(b-8*(b>a?1:-1))+' '+(y-10),fill:'none',stroke:c,'stroke-width':2},g);if(j[2])T(g,(a+b)/2,y-12-h,j[2],{'font-size':13,'font-weight':800,fill:c})});
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y+40,String(m[0]),{'font-size':14,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish/ayirish. st: nechta xona ochilgan (o'ngdan), shows carries/borrows
function bqCol(a,b,op,st,o){o=o||{};clear();var g=S.g,r=op==='+'?a+b:a-b,n=Math.max(String(a).length,String(b).length,String(r).length),cw=n>4?34:40,x1=n>4?292:230,y0=40,rh=34,FS=n>4?21:24;
 var lab=n>5?['bir','o‘n','yuz','ming','o‘n m.','yuz m.','mln']:['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb','#f6e9f2','#eef'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':n>5?10:(n>4?8:9),fill:'#5b6b7b'})}
 function digits(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){var d=s[s.length-1-i];if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,d,{'font-size':FS,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 digits(a,y0+rh-6);digits(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,op==='+'?'+':'−',{'font-size':FS,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 // ko'chirish/qarz
 var sa=String(a),sb=String(b),carry=0,marks=[];for(var k=0;k<n;k++){var da=+(sa[sa.length-1-k]||0),db=+(sb[sb.length-1-k]||0);if(op==='+'){var s2=da+db+carry;carry=s2>9?1:0;if(carry)marks.push(k+1)}else{var t=da-carry;carry=t<db?1:0;if(carry)marks.push(k)}}
 if(op==='+')marks.forEach(function(k){if(st==null||k<=st)T(g,x1-k*cw,y0+6,'1',{'font-size':13,'font-weight':800,fill:C.bad})});
 else{var cin=0;for(var k2=0;k2<n;k2++){var da2=+(sa[sa.length-1-k2]||0),db2=+(sb[sb.length-1-k2]||0),t2=da2-cin,co=0;if(t2<db2){t2+=10;co=1}
  if((cin||co)&&(st==null||k2<=st||(cin&&k2-1<=st&&k2<=st+1))){var xc=x1-k2*cw;E('line',{x1:xc-9,y1:y0+rh-22,x2:xc+9,y2:y0+rh-4,stroke:C.bad,'stroke-width':2},g);T(g,xc,y0+4,String(t2),{'font-size':13,'font-weight':800,fill:C.bad})}cin=co}}
 digits(r,y0+3*rh-2,st==null?99:st,C.ok);
 if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// ifoda: tokenlar qatori, belgilangan qism (hl: [i,j] oraliq), pastida natija qatorlari
function bqExpr(lines,o){o=o||{};clear();var g=S.g;lines.forEach(function(l,i){var y=40+i*40;var base=i===lines.length-1?24:20,plain=l.replace(/[\[\]]/g,''),fs=Math.min(base,Math.floor(560/Math.max(1,plain.length)));var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===lines.length-1?'#1d2b3a':'#5b6b7b','font-family':'ui-monospace,Menlo,monospace'});
  l.split(/(\[[^\]]*\])/).forEach(function(part){if(!part)return;var ts=E('tspan',{},t);var hl=part[0]==='[';ts.textContent=hl?part.slice(1,-1):part;if(hl){ts.setAttribute('fill',C.bad)}})})}
// juftlash o'yini: sonlar kartochkalarda, bola ikkitasini bosadi; ok(a,b) to'g'ri juft bo'lsa yashil bo'ladi
function bqPairs(nums,ok,onAll,o){o=o||{};clear();var g=S.g,n=nums.length,cw=Math.min(64,300/n),x0=180-n*cw/2,sel=null,done2=0;S.pairs=[];
 var lines=E('g',{},g);
 nums.forEach(function(v,i){var x=x0+i*cw,c=E('g',{style:'cursor:pointer'},g);var r=E('rect',{x:x+3,y:60,width:cw-6,height:44,rx:9,fill:'#fff',stroke:'#c9d3dd','stroke-width':2},c);T(c,x+cw/2,89,String(v),{'font-size':cw<50?16:20,'font-weight':800,fill:'#1d2b3a'});c._r=r;c._v=v;c._x=x+cw/2;
  c.addEventListener('click',function(){if(c._done)return;if(sel===null){sel=c;r.setAttribute('stroke',C.blue);return}if(sel===c){r.setAttribute('stroke','#c9d3dd');sel=null;return}
   var a=sel;sel=null;if(ok(a._v,c._v)){[a,c].forEach(function(z){z._done=1;z._r.setAttribute('fill','#e6f6ee');z._r.setAttribute('stroke',C.ok)});var col=['#1e8e5a','#1f6fb2','#e07a2f','#8a4fc7'][done2%4];
     E('path',{d:'M'+a._x+' 104 Q'+(a._x+c._x)/2+' '+(140+done2*6)+' '+c._x+' 104',fill:'none',stroke:col,'stroke-width':2.5},lines);T(lines,(a._x+c._x)/2,136+done2*6,String(a._v+c._v),{'font-size':12,'font-weight':800,fill:col});done2++;S.pairs.push([a._v,c._v]);if(o.onPair)o.onPair(a._v,c._v);if(done2>=Math.floor(n/2)&&onAll)onAll()}
   else{[a,c].forEach(function(z){z._r.setAttribute('stroke',C.bad)});setTimeout(function(){[a,c].forEach(function(z){if(!z._done)z._r.setAttribute('stroke','#c9d3dd')})},900);if(o.onBad)o.onBad(a._v,c._v)}})});
 if(o.title)T(g,180,30,o.title,{'font-size':13,'font-weight':700,fill:'#3a4a5a'})}

// ---------- 3-sinf (w3…) qo'shimcha vositalar ----------
// ustun ko'rinishida ko'paytirish: ko'p xonali a × bir xonali b; st — o'ngdan nechta xona ochilgan
function w3Mul(a,b,st,o){o=o||{};clear();var g=S.g,r=a*b,n=String(r).length,cw=40,x1=250,y0=40,rh=34;
 var lab=['birlik','o‘nlik','yuzlik','ming','o‘n ming'],cols=['#e1f4f2','#fdf0e1','#fde6c8','#eceaf8','#e6f0fb'];
 for(var i=0;i<n;i++){var x=x1-i*cw;E('rect',{x:x-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:cols[i]},g);T(g,x,y0-10,lab[i],{'font-size':9,fill:'#5b6b7b'})}
 function dg(v,y,show,col){var s=String(v);for(var i=0;i<s.length;i++){if(show!=null&&i>=show)continue;T(g,x1-i*cw,y,s[s.length-1-i],{'font-size':24,'font-weight':800,fill:col||'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})}}
 dg(a,y0+rh-6);dg(b,y0+2*rh-6);T(g,x1-n*cw+4,y0+2*rh-6,'×',{'font-size':24,'font-weight':800,fill:C.blue});
 E('line',{x1:x1-n*cw+10,y1:y0+2*rh+2,x2:x1+cw/2,y2:y0+2*rh+2,stroke:'#33475b','stroke-width':2.5},g);
 var sa=String(a),c=0;for(var k=0;k<sa.length;k++){var p=(+sa[sa.length-1-k])*b+c;c=Math.floor(p/10);if(c&&(st==null||k<st)&&k+1<sa.length)T(g,x1-(k+1)*cw,y0+6,String(c),{'font-size':13,'font-weight':800,fill:C.bad})}
 dg(r,y0+3*rh-2,st==null?99:st,C.ok);if(o.hl!=null)E('rect',{x:x1-o.hl*cw-cw/2,y:y0-22,width:cw-2,height:rh*3+30,rx:6,fill:'none',stroke:C.blue,'stroke-width':2.5},g)}
// maydon modeli: a (bo'laklarga ajratilgan: parts) × b
function w3Area(parts,b,o){o=o||{};clear();var g=S.g,tot=parts.reduce(function(x,y){return x+y},0),x0=40,W=290,y0=38,H=88,x=x0,cl=['#f2b766','#bfe9e3','#d9c8f2','#f6d9a8'];
 T(g,22,y0+H/2+5,String(b),{'font-size':16,'font-weight':800,fill:C.blue});
 var ws=parts.map(function(p){return Math.max(W*p/tot,o.show?60:34)}),wt=ws.reduce(function(x,y){return x+y},0);ws=ws.map(function(w){return w*W/wt});parts.forEach(function(p,i){var w=ws[i];E('rect',{x:x,y:y0,width:w,height:H,fill:cl[i%4],stroke:C.line,'stroke-width':1.5},g);T(g,x+w/2,y0-8,String(p),{'font-size':14,'font-weight':800,fill:'#1d2b3a'});
  if(o.show)T(g,x+w/2,y0+H/2+6,w<80?String(p*b):p+' · '+b+' = '+(p*b),{'font-size':w<80?14:13,'font-weight':800,fill:'#1d2b3a'});x+=w});
 if(o.show)T(g,180,y0+H+30,parts.map(function(p){return p*b}).join(' + ')+' = '+(tot*b),{'font-size':15,'font-weight':800,fill:C.ok})}
// ko'paytirish jadvali (bosiladigan): hl — [[r,c],...] yoritiladi; onCell(r,c)
function w3Tab(hl,onCell,o){o=o||{};clear();var g=S.g,x0=40,y0=8,cw=31,ch=15.6;
 for(var r=0;r<=9;r++)for(var c=0;c<=9;c++){var x=x0+c*cw,y=y0+r*ch,head=!r||!c;if(!r&&!c)continue;var v=head?(r||c):r*c,isH=(hl||[]).some(function(h){return h[0]===r&&h[1]===c}),row=o.row&&r===o.row&&c,col=o.col&&c===o.col&&r;
  var e=E('rect',{x:x,y:y,width:cw-1,height:ch-1,rx:2,fill:head?'#e8f1fb':(isH?C.hi:(row||col?'#e6f6ee':(o.diag&&r===c?'#fdeaea':'#fff'))),stroke:'#dde5ee'},g);T(g,x+cw/2,y+11.5,String(v),{'font-size':head?10:9,'font-weight':head||isH?800:500,fill:head?C.blue:'#33475b','pointer-events':'none'});
  if(onCell&&!head){e.style.cursor='pointer';(function(rr,cc){e.addEventListener('click',function(){onCell(rr,cc)})})(r,c)}}}
// nuqtali massiv: r qator × c ustun
function w3Arr(r,c,o){o=o||{};clear();var g=S.g,s=Math.min(26,150/Math.max(r,1),300/Math.max(c,1)),x0=180-c*s/2,y0=o.y||20;
 for(var i=0;i<r;i++)for(var j=0;j<c;j++){var hl=o.split&&j>=o.split;E('circle',{cx:x0+j*s+s/2,cy:y0+i*s+s/2,r:s*.36,fill:hl?C.b:C.a,stroke:'rgba(0,0,0,.15)'},g)}
 if(o.lab)T(g,180,y0+r*s+20,o.lab,{'font-size':14,'font-weight':800,fill:'#1d2b3a'})}
// ===== w_4a qo'shimchalar =====
var A4CL=['birlar sinfi','minglar sinfi','millionlar sinfi','milliardlar sinfi'],A4CC=['#12a39f','#b07a33','#7a5ac2','#c2410c'];
var A4COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million','o‘n mln','yuz mln','milliard'];
function a4table(n,o){o=o||{};clear();var g=S.g,s=o.str!=null?o.str:String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2,shrt=L>7;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:['#e1f4f2','#fdf0e1','#ede7fb','#fde4d8'][cls%4],stroke:'#c9d3dd'},g);
  T(g,x+cw/2,56,shrt?['bir','o‘n','yuz'][i%3]:A4COL[i],{'font-size':shrt?10:Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null||d===' '?'':d,{'font-size':L>8?22:26,'font-weight':800,fill:d==='?'?C.bad:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;var bw=xb-xa,lb=bw>=118?A4CL[c]:(bw>=70?A4CL[c].split(' ')[0]:['bir.','ming','mln','mlrd'][c]);Br(xa+3,xb-3,108,lb,false,A4CC[c])}
 if(o.top)T(g,180,26,o.top,{'font-size':o.tfs||14,'font-weight':800,fill:C.blue})}
// variant tugmalari: xato — 2 soniya qizil, o'chmaydi; to'g'ri — yashil va done
function a4ch(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.style.background='#d9f2e3';b.style.borderColor='#2e9e5b';onRight&&onRight();done()}else{var bg=b.style.background;b.style.background='#f8d7d7';onWrong&&onWrong(i);setTimeout(function(){b.style.background=bg},2000)}}]})}
// kartochkalar: bosiladigan sonlar qatori (sahnada), ok(i) — to'g'ri bosilganmi; need — nechta to'g'ri bosish kerak
function a4cards(items,o){o=o||{};clear();var g=S.g,N=items.length,nc=o.cols||N,nr=Math.ceil(N/nc),n=nc,cw=Math.min(o.cw||78,340/n),x0=180-n*cw/2,y0=o.y||(nr>1?40:60),h=o.h||(nr>1?40:46),y=y0;S.cardEls=[];
 if(o.title)T(g,180,24,o.title,{'font-size':13,'font-weight':800,fill:C.blue});
 items.forEach(function(t,k){var i=k%nc,y=y0+Math.floor(k/nc)*(h+10);var gg=E('g',{style:'cursor:pointer'},g),r=E('rect',{x:x0+i*cw+3,y:y,width:cw-6,height:h,rx:8,fill:'#fff',stroke:'#9fb3c8','stroke-width':1.6},gg);T(gg,x0+i*cw+cw/2,y+h/2+6,String(t),{'font-size':o.fs||(cw<60?13:16),'font-weight':800,fill:'#1d2b3a'});S.cardEls.push(r);
  if(o.onTap)gg.addEventListener('click',function(){o.onTap(k,r)})})}
function a4mark(r,ok){r.setAttribute('fill',ok?'#d9f2e3':'#f8d7d7');r.setAttribute('stroke',ok?'#2e9e5b':C.bad);if(!ok)setTimeout(function(){r.setAttribute('fill','#fff');r.setAttribute('stroke','#9fb3c8')},2000)}
