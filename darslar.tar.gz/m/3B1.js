var CODE='3B1',TITLE='3-sinf · 1000 ichida og‘zaki qo‘shish va ayirish';
function b1(lines){clear();var g=S.g,n=lines.length,y0=n>3?30:(n>2?44:60);lines.forEach(function(l,i){var t=typeof l==='string'?[l]:l;T(g,180,y0+i*(n>3?36:42),t[0],{'font-size':t[2]||(i===0?26:22),'font-weight':800,fill:t[1]||'#1d2b3a'})})}
var P1=[function(){b1(['540 − 270 + 130']);msg('Yaxlit o‘nliklar — o‘nliklarda hisoblaymiz')},function(){b1(['540 − 270 + 130',['54 − 27 + 13 (o‘nlik)',C.blue,18]]);msg('Nollarni «yashirib», o‘nliklarni sanaymiz')},function(){b1(['540 − 270 + 130',['54 − 27 + 13 (o‘nlik)',C.blue,18],['27 + 13 = 40 o‘nlik',C.blue,18],['= 400',C.ok,26]]);msg('40 o‘nlik = <b>400</b>')}];
var P3=[function(){w3line(260,350,10,[[268,C.blue]],{big:10,fs:10});msg('268 + 77 — bo‘laklab qo‘shamiz')},function(){w3line(260,350,10,[[268,C.blue,''],[270,C.a,'']],{big:10,fs:10});b1arc(268,270,'+2');b1l();msg('Avval yaxlit o‘nlikkacha: 268 + <b>2</b> = 270')},function(){w3line(260,350,10,[[268,C.blue,''],[270,C.a,''],[345,C.ok,'345']],{big:10,fs:10});b1arc(268,270,'+2');b1l();b1arc(270,345,'+75');msg('Qolgani: 77 − 2 = 75. 270 + 75 = <b>345</b>')}];
var P6=[function(){b1(['685 − 127 + 236 − 794']);msg('Tartib bilan: chapdan o‘ngga')},function(){b1(['685 − 127 + 236 − 794',['685 − 127 = 558',C.blue,18]]);msg('1-amal')},function(){b1(['685 − 127 + 236 − 794',['685 − 127 = 558',C.blue,18],['558 + 236 = 794',C.blue,18]]);msg('2-amal — 794 chiqdi! Bu ayriladigan son bilan bir xil')},function(){b1(['685 − 127 + 236 − 794',['685 − 127 = 558',C.blue,18],['558 + 236 = 794',C.blue,18],['794 − 794 = 0',C.ok,22]]);msg('Javob: <b>0</b>')}];
function b1l(){T(S.g,S.X(268),148,'↑ 268',{'font-size':12,'font-weight':800,fill:C.blue})}
function b1arc(a,b,t){var X=S.X;E('path',{d:'M'+X(a)+' 98 Q'+(X(a)+X(b))/2+' '+(b-a>10?46:70)+' '+X(b)+' 98',fill:'none',stroke:C.ok,'stroke-width':2},S.g);T(S.g,(X(a)+X(b))/2,b-a>10?60:66,t,{'font-size':13,'font-weight':800,fill:C.ok})}
var STEPS=[
{h:"Yaxlit sonlar bilan og'zaki hisob",sum:"540 − 270 + 130 = 54 − 27 + 13 o'nlik = 40 o'nlik = 400.",a:"m01",
 start:function(){startPh(P1)},fin:function(){S.ph=2;P1[2]()},
 html:"<p>Oxiri nol bilan tugaydigan sonlarni <b>o'nliklarda</b> (yoki yuzliklarda) hisoblash oson. Kuzating:</p>",
 btns:[phaser(P1)],
 after:"<p>540 = 54 o'nlik, 270 = 27 o'nlik, 130 = 13 o'nlik. 54 − 27 = 27, 27 + 13 = 40 o'nlik = <b>400</b>. Yuzliklar bilan: 700 + 600 = 7 + 6 = 13 yuzlik = 1 300.</p>",
 q:{t:"620 − 380 + 160 = ?",opts:["400","300","1 160","240"],ok:0,why:"62 − 38 = 24 o'nlik, 24 + 16 = 40 o'nlik = 400.",hint:"O'nliklarda hisoblang: 62 − 38 + 16.",full:"620 − 380 = 240, 240 + 160 = 400. «240» — oxirgi amalni unutish; «1 160» — ishoralarni aralashtirish (620 + 380 + 160)."},
 tn:"Bank (2235). Pul bilan: 10 so'mlik tangalar o'rniga «o'nliklar» deb hisoblash."},
{h:"Xonama-xona qo'shish",sum:"356 + 230: yuzlik + yuzlik, o'nlik + o'nlik: 586.",a:"m02",
 start:function(){b1(['356 + 230 = ?']);msg('O‘tishsiz — xonama-xona')},fin:function(){b1(['356 + 230 = 586',['300 + 200 = 500',C.t1,16],['50 + 30 = 80',C.blue,16],['6 + 0 = 6',C.u,16]])},
 html:"<p>Xonalarda o'tish bo'lmasa, har bir xonani alohida qo'shamiz. Javobni tanlang:</p>",
 btns:w3choose(["586","3 586","559"],0,function(){b1(['356 + 230 = 586',['300 + 200 = 500',C.t1,16],['50 + 30 = 80',C.blue,16],['6 + 0 = 6',C.u,16]]);msg('500 + 80 + 6 = <b>586</b>')},function(i){msg(i===1?'230 ni 3 va 230 ga ajratib yubordingiz — xonalarni tekislang':'559 — 230 ni 203 deb oldingiz: 3 — o‘nlik, 0 — birlik')}),g3:1,
 after:"<p>Og'zaki hisobda <b>yuqori xonadan</b> boshlash qulay: 300 + 200 = 500, 50 + 30 = 80, 6 — jami 586. Ayirish ham shunday: 786 − 350 = 436.</p>",
 q:{t:"874 − 420 = ?",opts:["454","474","434","054"],ok:0,why:"800 − 400 = 400, 70 − 20 = 50, 4 − 0 = 4: 454.",hint:"Har bir xonani alohida ayiring.",full:"874 − 420 = 454. «474» — o'nliklarni ayirmaslik; «434» — 20 o'rniga 40 ni ayirish."},
 tn:"Raqam kartochkalarini xonalab ustma-ust qo'yish."},
{h:"O'tish bilan: yaxlit songacha to'ldiramiz",sum:"268 + 77: 268 + 2 = 270, 270 + 75 = 345.",a:"m03",
 start:function(){startPh(P3)},fin:function(){S.ph=2;P3[2]()},
 html:"<p>268 + 77 da birliklar o'tadi (8 + 7 = 15). Og'zaki eng qulay yo'l — avval <b>yaxlit o'nlikka</b> yetkazish. Son o'qida kuzating:</p>",
 btns:[phaser(P3)],
 after:"<p>«10 ni yasash» usuli: 268 ga 2 yetmaydi — 77 dan 2 ni olamiz, 75 qoladi: 270 + 75 = <b>345</b>. Ayirishda ham: 345 − 77 = 345 − 45 − 32 = 300 − 32 = 268.</p>",
 q:{t:"457 + 68 = ?",opts:["525","515","425","535"],ok:0,why:"457 + 3 = 460, 460 + 65 = 525.",hint:"457 ga nechta qo'shsak 460 bo'ladi?",full:"457 + 3 = 460, 68 − 3 = 65, 460 + 65 = 525. «515» — o'nlikka o'tishni unutish; «535» — o'tishni ikki marta hisoblash."},
 tn:"Singapur «bog'lanish» (number bond) chizmasi: 77 → 2 va 75."},
{h:"Yaxlitlab, keyin tuzatamiz",sum:"486 + 299 = 486 + 300 − 1 = 785.",a:"m04",
 start:function(){b1(['486 + 299 = ?',['299 ≈ 300',C.blue,18]]);msg('299 — yaxlit 300 ga juda yaqin')},fin:function(){b1(['486 + 299',['= 486 + 300 − 1',C.blue,20],['= 785',C.ok,26]])},
 html:"<p>299 ni qo'shish o'rniga 300 qo'shib, keyin <b>ortiqcha 1 ni</b> olib tashlaymiz. Qaysi yozuv to'g'ri?</p>",
 btns:w3choose(["486 + 300 + 1","486 + 300 − 1","486 − 300 + 1"],1,function(){b1(['486 + 299',['= 486 + 300 − 1',C.blue,20],['= 785',C.ok,26]]);msg('786 − 1 = <b>785</b>')},function(i){msg(i===0?'300 qo‘shib, 1 ta ortiqcha qo‘shdik — uni ayirish kerak, qo‘shish emas!':'Biz qo‘shyapmiz, ayirmayapmiz')}),g3:1,
 after:"<p>Ayirishda teskari tuzatiladi: 734 − 298 = 734 − 300 <b>+ 2</b> = 436. Ko'p ayirib yubordik — 2 ni qaytaramiz.</p>",
 q:{t:"652 − 397 = ?",opts:["255","249","245","1 049"],ok:0,why:"652 − 400 + 3 = 255.",hint:"397 ≈ 400. Ortiqcha ayirgan 3 ni qaytaring.",full:"652 − 400 = 252, 3 ta ortiq ayirdik — qaytaramiz: 252 + 3 = 255. «249» — 3 ni qaytarish o'rniga ayirish (xato tuzatish yo'nalishi)."},
 tn:"Bu usulni pul bilan tushuntirish: 299 so'm = 300 so'm berib, 1 so'm qaytim olish."},
{h:"1000 dan ayirish",sum:"1000 − 456: 999 − 456 = 543, keyin + 1 = 544.",a:"m05",
 start:function(){b1(['1000 − 456 = ?']);msg('Ko‘p nollar — ko‘p «qarz olish». Qulay yo‘l bormi?')},fin:function(){b1(['1000 − 456',['= 999 − 456 + 1',C.blue,20],['= 543 + 1 = 544',C.ok,24]])},
 html:"<p>1000 dan ayirishda «qarz olish» chalkashtiradi. Ayyor usul: 1000 = 999 + 1. 999 dan ayirishda hech qanday o'tish yo'q! Javobni tanlang:</p>",
 btns:w3choose(["544","654","644"],0,function(){b1(['1000 − 456',['= 999 − 456 + 1',C.blue,20],['= 543 + 1 = 544',C.ok,24]]);msg('9 − 4 = 5, 9 − 5 = 4, 9 − 6 = 3 → 543, + 1 = <b>544</b>')},function(i){msg(i===1?'654 — har xonada kichikdan kattani ayirdingiz (6 − 0 = 6?)':'644 — qarz olishni bir xonada unutdingiz')}),g3:1,
 after:"<p>Tekshiruv: 544 + 456 = 1 000 ✓. Har bir xonada yig'indi 9 ga, oxirgisida 10 ga teng: 5 + 4 = 9, 4 + 5 = 9, 4 + 6 = 10.</p>",
 q:{t:"1000 − 273 = ?",opts:["727","837","827","737"],ok:0,why:"999 − 273 = 726, + 1 = 727.",hint:"999 − 273 ni hisoblang, keyin 1 qo'shing.",full:"999 − 273 = 726, 726 + 1 = 727. Tekshiruv: 727 + 273 = 1 000. «837» — kichikdan kattani ayirish; «737» — o'nlikda qarzni unutish."},
 tn:"Bank (1) masalasi: 1000 − 456 − 189 + 245 = 600. Shu usul bilan boshlang."},
{h:"Tuzoq: uzun ifoda",sum:"685 − 127 + 236 − 794: chapdan o'ngga — 558, 794, 0.",a:"m06",
 start:function(){startPh(P6)},fin:function(){S.ph=3;P6[3]()},
 html:"<p>Qavslar bo'lmasa, qo'shish va ayirish <b>chapdan o'ngga</b> tartib bilan bajariladi. Kuzating:</p>",
 btns:[phaser(P6)],
 after:"<p>Tuzoq: «avval qo'shishlarni bajaraman» deb 127 + 236 ni hisoblash — <b>xato</b>. Faqat chapdan o'ngga! Ammo ayriladigan sonlarni birga ayirish mumkin: 1000 − 456 − 189 = 1000 − (456 + 189) = 1000 − 645 = 355.</p>",
 q:{t:"874 − 168 + 125 − 624 = ?",opts:["207","197","581","217"],ok:0,why:"706 + 125 = 831, 831 − 624 = 207.",hint:"Chapdan o'ngga: 874 − 168 = ?",full:"874 − 168 = 706; 706 + 125 = 831; 831 − 624 = 207. «581» — «+ 125» ni ayirish deb olish (874 − 168 − 125); «197», «217» — o'tishda xato."},
 tn:"Bank (405, 406, 1). Har bir oraliq natijani doskaga yozdiring."},
{h:"Tuzoq: adashib yozilgan son",sum:"Yig'indi 900 chiqdi, lekin 201 o'rniga 102 yozilgan: to'g'ri yig'indi 900 − 102 + 201 = 999.",a:"m07",
 start:function(){b1(['… + 102 + … = 900',['(201 o‘rniga 102 yozilgan)',C.bad,15]]);msg('To‘g‘ri yig‘indi qancha bo‘lardi?')},fin:function(){b1(['900 − 102 + 201',['= 999',C.ok,28]])},
 html:"<p>Ali bir nechta sonni qo'shib <b>900</b> oldi. Keyin bilsa, 201 o'rniga adashib <b>102</b> yozgan ekan. To'g'ri yig'indi qancha?</p>",
 btns:w3choose(["801","999","1 203"],1,function(){b1(['900 − 102 + 201',['= 999',C.ok,28]]);msg('Xato sonni olib tashlaymiz, to‘g‘risini qo‘shamiz: 201 − 102 = 99 ga ko‘p')},function(i){msg(i===0?'Yig‘indi kamaymaydi: 201 > 102, demak to‘g‘ri yig‘indi katta':'1 203 — 102 ni olib tashlamadingiz')}),g3:1,
 after:"<p>Usul: xato qo'shiluvchini <b>ayiramiz</b>, to'g'risini <b>qo'shamiz</b>. Yoki farq bilan: 201 − 102 = 99 ga katta bo'lardi → 900 + 99 = <b>999</b>.</p>",
 q:{t:"Sonlar yig'indisi 760 chiqdi. Ammo 350 o'rniga 530 yozilgan. To'g'ri yig'indi?",opts:["580","940","760","1 290"],ok:0,why:"760 − 530 + 350 = 580.",hint:"530 katta — demak to'g'ri yig'indi kichikroq.",full:"Xato: 530, to'g'ri: 350. 760 − 530 + 350 = 580 (yoki 760 − 180). «940» — farqni qo'shish (yo'nalish xatosi)."},
 tn:"Bank (150) turi. Kassadagi chek misolida tushuntirish."},
{h:"Bilasizmi? 1 dan 100 gacha",sum:"1 + 2 + … + 100 = 5 050: juftlab qo'shamiz — 50 ta juft, har biri 101.",a:"m08",
 start:function(){b1(['1 + 100 = 101',['2 + 99 = 101',C.blue,20],['3 + 98 = 101',C.blue,20],['… 50 juft · 101 = 5 050',C.ok,20]])},fin:function(){b1(['1 + 100 = 101',['2 + 99 = 101',C.blue,20],['3 + 98 = 101',C.blue,20],['… 50 juft · 101 = 5 050',C.ok,20]])},
 html:"<p>📚 Rivoyat qilinishicha, nemis matematigi <b>Karl Gauss</b> maktabda o'qituvchi 1 dan 100 gacha sonlarni qo'shishni topshirganda, javobni bir necha daqiqada aytgan. U sonlarni <b>juftlab</b> qo'shgan: 1 + 100, 2 + 99, … — har biri 101, jami 50 juft: <b>5 050</b>.</p><p>Og'zaki hisobning siri — sonlarni qulay guruhlash!</p>",
 tn:"Kichik variant: 1 + 2 + … + 10 = 5 juft · 11 = 55 — bolalar o'zlari topsin."},
{h:"Eslatma kartochka",sum:"",a:"m09",memo:1,start:function(){b1(['486 + 299',['= 486 + 300 − 1',C.blue,20],['= 785',C.ok,26]])},fin:function(){b1(['486 + 299',['= 486 + 300 − 1',C.blue,20],['= 785',C.ok,26]])},
 html:"<div class='memo'><ul><li>Yaxlit sonlar — o'nlik/yuzliklarda: 540 − 270 = 54 − 27 o'nlik.</li><li>O'tishsiz — xonama-xona: 356 + 230 = 586.</li><li>O'tish bilan — yaxlitgacha to'ldiring: 268 + 2 + 75.</li><li>299 = 300 − 1: qo'shishda −1, ayirishda +1.</li><li>1000 − a = (999 − a) + 1.</li><li>Qavssiz ifoda — chapdan o'ngga.</li><li>Adashgan son: xatoni ayir, to'g'rini qo'sh.</li></ul></div>",
 tn:"Keyingi dars — yozma (ustun) qo'shish."}
];
var PROBS=[
{t:"540 − 270 + 130 = ?",o:["400","140","300","940"],k:0,s:"54 − 27 + 13 = 40 o'nlik."},
{t:"700 + 600 = ?",o:["1 300","130","13 000","1 200"],k:0,s:"7 + 6 = 13 yuzlik."},
{t:"356 + 230 = ?",o:["586","559","596","3 586"],k:0,s:"Xonama-xona."},
{t:"874 − 420 = ?",o:["454","474","434","464"],k:0,s:"800 − 400, 70 − 20, 4."},
{t:"268 + 77 = ?",o:["345","335","355","245"],k:0,s:"270 + 75."},
{t:"486 + 299 = ?",o:["785","787","786","685"],k:0,s:"486 + 300 − 1."},
{t:"652 − 397 = ?",o:["255","249","245","265"],k:0,s:"652 − 400 + 3."},
{t:"1000 − 456 = ?",o:["544","654","644","554"],k:0,s:"999 − 456 + 1."},
{t:"1000 − 456 − 189 + 245 = ?",o:["600","610","590","500"],k:0,s:"544 − 189 = 355, 355 + 245 = 600."},
{t:"685 − 127 + 236 − 794 = ?",o:["0","10","100","20"],k:0,s:"558, 794, 0."},
{t:"874 − 168 + 125 − 624 = ?",o:["207","197","217","581"],k:0,s:"706, 831, 207."},
{t:"348 va 293 yig'indisini 362 ta kamaytiring.",o:["279","289","379","1 003"],k:0,s:"641 − 362 = 279."},
{t:"Birinchi son 98, ikkinchisi 82. Uchinchi son ularning yig'indisidan 30 ta ortiq. Uchinchi son:",o:["210","180","150","200"],k:0,s:"98 + 82 + 30 = 210."},
{t:"420 o'quvchidan 190 nafari o'g'il bola. Qizlar o'g'il bolalardan nechta ko'p?",o:["40","230","50","610"],k:0,s:"Qizlar 230, 230 − 190 = 40."},
{t:"Sirkda 900 o'rin. Ertalab 650 kishi, kechqurun ertalabkidan 180 ta kam keldi. Kechqurun nechta o'rin bo'sh qoldi?",o:["430","250","470","70"],k:0,s:"650 − 180 = 470; 900 − 470 = 430."},
{t:"Yig'indi 900 chiqdi, lekin 201 o'rniga 102 yozilgan. To'g'ri yig'indi:",o:["999","801","1 203","900"],k:0,s:"900 − 102 + 201."},
{t:"Yig'indi 760 chiqdi, lekin 350 o'rniga 530 yozilgan. To'g'ri yig'indi:",o:["580","940","760","1 290"],k:0,s:"760 − 530 + 350."},
{t:"Uchta ketma-ket sonning yig'indisi 87. Eng kattasi:",o:["30","29","28","31"],k:0,s:"O'rtasi 29."},
{t:"86, 117, 154 va 37 yig'indisining yarmi:",o:["197","394","187","207"],k:0,s:"86 + 154 = 240, 117 + 37 = 154; 394 : 2 = 197."},
{t:"Son o'qida 64 dan chapga 27 ga, keyin yana 9 ga sakrab x ga tushildi. x + 37 = ?",o:["65","28","73","37"],k:0,s:"64 − 27 − 9 = 28; 28 + 37 = 65."}
];
function PRACT_STAGE(){b1(['486 + 299',['= 486 + 300 − 1',C.blue,20],['= 785',C.ok,26]])}
var PREP_DATA={teach:["Yaxlit sonlar bilan, xonama-xona va yaxlitgacha to'ldirib og'zaki hisob.","Yaxlitlab tuzatish (±1, ±2), 1000 dan ayirish.","Qavssiz ifodalarda tartib; adashib yozilgan son masalalari."],mist:["299 ni qo'shishda +300 +1 qiladi.","1000 − 456 da qarz olishni chalkashtiradi.","Qavssiz ifodada avval qo'shishni bajaradi.","Adashgan son masalasida ayirish/qo'shishni almashtiradi."],need:["Son o'qi, 10 va 100 lik kartochkalar."],board:["<span class='w2'>540 − 270 + 130 = 400</span>.","<span class='w2'>268 + 77 = 270 + 75</span>.","<span class='w2'>486 + 299 = 486 + 300 − 1</span>.","<span class='w2'>1000 − 456 = 999 − 456 + 1</span>.","<span class='w2'>900 − 102 + 201 = 999</span>."]};

// ===== w_3a umumiy sahna vositalari (3A1–3A7, 3B1, 3B2) =====
function msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
var W3H=['','bir yuz','ikki yuz','uch yuz','to‘rt yuz','besh yuz','olti yuz','yetti yuz','sakkiz yuz','to‘qqiz yuz'];
function w3a(n){if(n===0)return 'nol';if(n<100)return word(n);var h=Math.floor(n/100),r=n%100;return (W3H[h]+(r?' '+word(r):'')).trim()}
function wbig(n){if(n===0)return 'nol';var parts=[],m=Math.floor(n/1000000),k=Math.floor(n/1000)%1000,r=n%1000;if(m)parts.push(w3a(m)+' million');if(k)parts.push(w3a(k)+' ming');if(r)parts.push(w3a(r));return parts.join(' ')}
function fmt(n){return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
// yuzlik kvadrat, o'nlik tayoqcha, birlik nuqta — bitta qator
function w3flat(p,x,y,s,hl){E('rect',{x:x,y:y,width:s,height:s,rx:2,fill:hl?C.hi:'#f2b766',stroke:C.t1,'stroke-width':1.1},p);for(var k=1;k<5;k++){E('line',{x1:x+k*s/5,y1:y,x2:x+k*s/5,y2:y+s,stroke:'#c98b45','stroke-width':.5},p);E('line',{x1:x,y1:y+k*s/5,x2:x+s,y2:y+k*s/5,stroke:'#c98b45','stroke-width':.5},p)}}
function w3blocks(n,y,hl,o){o=o||{};var g=S.g,h=o.h!=null?o.h:Math.floor(n/100),t=o.t!=null?o.t:Math.floor(n/10)%10,u=o.u!=null?o.u:n%10;
 if(o.lab!==false)T(g,34,y+24,o.label||String(n),{'font-size':17,'font-weight':800,fill:'#1d2b3a'});
 for(var i=0;i<h;i++)w3flat(g,66+(i%9)*17,y+6+Math.floor(i/9)*17,15,hl==='h');
 for(var j=0;j<t;j++)E('rect',{x:226+(j%12)*5.5,y:y+4+Math.floor(j/12)*34,width:4,height:30,rx:1.5,fill:hl==='t'?C.hi:C.t2,stroke:C.t1,'stroke-width':.6},g);
 for(var k=0;k<u;k++)E('circle',{cx:296+(k%5)*11,cy:y+10+Math.floor(k/5)*11,r:4.3,fill:hl==='u'?C.hi:C.u},g)}
function w3heads(){var g=S.g;T(g,128,14,'yuzliklar',{'font-size':10,'font-weight':800,fill:C.t1});T(g,256,14,'o‘nliklar',{'font-size':10,'font-weight':800,fill:'#b07a33'});T(g,318,14,'birliklar',{'font-size':10,'font-weight':800,fill:C.u})}
// xonalar jadvali (ko'p xonali son): digits massivi chapdan o'ngga; hl — ajratilgan xona indekslari (o'ngdan 0)
var W3COL=['birlik','o‘nlik','yuzlik','ming','o‘n ming','yuz ming','million'];
function w3table(n,o){o=o||{};clear();var g=S.g,s=String(n),L=Math.max(s.length,o.min||1),cw=Math.min(46,330/L),x0=180+L*cw/2;
 for(var i=0;i<L;i++){var x=x0-(i+1)*cw,cls=Math.floor(i/3),d=s[s.length-1-i];
  E('rect',{x:x+1,y:40,width:cw-2,height:62,rx:6,fill:(o.hl&&o.hl.indexOf(i)>=0)?C.hi:(cls===0?'#e1f4f2':(cls===1?'#fdf0e1':'#ede7fb')),stroke:'#c9d3dd'},g);
  T(g,x+cw/2,58,W3COL[i]||'',{'font-size':Math.min(10,cw/4.2),fill:'#5b6b7b'});
  T(g,x+cw/2,92,d==null?'':d,{'font-size':26,'font-weight':800,fill:'#1d2b3a'})}
 var nc=Math.ceil(L/3);for(var c=0;c<nc;c++){var xa=x0-Math.min(L,(c+1)*3)*cw,xb=x0-c*3*cw;Br(xa+4,xb-4,108,['birlar sinfi','minglar sinfi','millionlar sinfi'][c],false,['#12a39f','#b07a33','#7a5ac2'][c])}
 if(o.top)T(g,180,26,o.top,{'font-size':14,'font-weight':800,fill:C.blue})}
// son o'qi
function w3line(a,b,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=336,y=o.y||100,X=function(v){return x0+(v-a)*(x1-x0)/(b-a)};S.X=X;
 E('line',{x1:x0-8,y1:y,x2:x1+10,y2:y,stroke:'#33475b','stroke-width':2.4},g);E('path',{d:'M'+(x1+10)+' '+(y-6)+' L'+(x1+18)+' '+y+' L'+(x1+10)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var v=a;v<=b+1e-9;v+=step){var big=o.big?Math.abs(v%o.big)<1e-9:true;E('line',{x1:X(v),y1:y-(big?9:5),x2:X(v),y2:y+(big?9:5),stroke:'#33475b','stroke-width':big?2:1},g);if(big&&o.lab!==false)T(g,X(v),y+26,fmt(v),{'font-size':o.fs||11,fill:'#5b6b7b'})}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[1]||C.blue,stroke:'#fff','stroke-width':2},g);T(g,X(m[0]),y-14,m[2]!=null?m[2]:fmt(m[0]),{'font-size':13,'font-weight':800,fill:m[1]||C.blue})})}
// ustun ko'rinishida qo'shish: st — nechta xona hisoblangan (o'ngdan); hl — ajratilgan xona
function w3col(nums,st,o){o=o||{};clear();var g=S.g,sum=nums.reduce(function(a,b){return a+b},0),n=String(sum).length,cw=34,x1=250,y0=36,rh=30;
 for(var i=0;i<Math.max(n,String(nums[0]).length);i++){var x=x1-i*cw;E('rect',{x:x-cw/2+1,y:y0-18,width:cw-2,height:rh*(nums.length+1)+30,rx:6,fill:i===o.hl?'#fff3c4':['#e1f4f2','#fdf0e1','#fde6c8','#ede7fb','#eee'][i]},g)}
 nums.forEach(function(v,r){var s=String(v);for(var i=0;i<s.length;i++)T(g,x1-i*cw,y0+rh*(r+1)-8,s[s.length-1-i],{'font-size':22,'font-weight':800,fill:'#1d2b3a','font-family':'ui-monospace,Menlo,monospace'})});
 T(g,x1-n*cw-4,y0+rh*nums.length-8,'+',{'font-size':22,'font-weight':800,fill:C.blue});
 var yl=y0+rh*nums.length+2;E('line',{x1:x1-n*cw-8,y1:yl,x2:x1+cw/2,y2:yl,stroke:'#33475b','stroke-width':2.4},g);
 var carry=0,carries=[];for(var k=0;k<n;k++){var c=nums.reduce(function(a,v){return a+(+(String(v)[String(v).length-1-k]||0))},0)+carry;carry=Math.floor(c/10);carries.push(carry)}
 var s2=String(sum);for(var k2=0;k2<n;k2++){if(st!=null&&k2>=st)continue;T(g,x1-k2*cw,yl+24,s2[s2.length-1-k2],{'font-size':22,'font-weight':800,fill:C.ok,'font-family':'ui-monospace,Menlo,monospace'});if(carries[k2]&&k2+1<n)T(g,x1-(k2+1)*cw,y0+4,String(carries[k2]),{'font-size':13,'font-weight':800,fill:C.bad})}}
// tugma bilan tanlash (variant tugmalari), to'g'ri bo'lsa done
function w3choose(list,okIdx,onRight,onWrong){return list.map(function(t,i){return [t,function(c,done,b){if(i===okIdx){b.classList.add('u');onRight&&onRight();done()}else{onWrong&&onWrong(i);b.disabled=true}}]})}
