var CODE='4D5',TITLE='4-sinf · Masala shartiga ko‘ra ifoda va tenglama tuzish';
var P5=[function(){w3Bar([{lab:'son',segs:[{w:1,t:'x'}],tot:5.4}]);w3Msg('«Bir son o‘ylandi…»')},
 function(){w3Bar([{lab:'4 marta',segs:[{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'}],tot:5.4}]);w3Msg('«…uni 4 marta orttirdik…» → x · 4')},
 function(){w3Bar([{lab:'+150',segs:[{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'},{w:1.4,t:'150',c:C.a}],tot:5.4,br:'590',brw:1}],{top:60});w3Msg('«…150 qo‘shdik — 590 chiqdi» → x · 4 + 150 = 590')},
 function(){w3Bar([{lab:'',segs:[{w:1,t:'110'},{w:1,t:'110'},{w:1,t:'110'},{w:1,t:'110'},{w:1.4,t:'150',c:C.a}],tot:5.4,br:'590',brw:1}],{top:60});w3Msg('x · 4 = 590 − 150 = 440,  x = 440 : 4 = <b>110</b>')}];
var P6=[function(){w3Bar([{lab:'I',segs:[{w:1,t:'?'},{w:1,t:'?'},{w:1,t:'?'}],tot:3},{lab:'II',segs:[{w:1,t:'?',c:C.a}],tot:3}]);w3Msg('I savatda II dan 3 marta ko‘p — 3 ta bir xil bo‘lak')},
 function(){w3Bar([{lab:'I',segs:[{w:1,t:'x'},{w:1,t:'x'},{w:1,t:'x'}],tot:3},{lab:'II',segs:[{w:1,t:'x',c:C.a}],tot:3}]);w3Msg('Kichik bo‘lak — x. Jami: x · 3 + x = 96 → 4 ta bo‘lak')},
 function(){w3Bar([{lab:'I',segs:[{w:1,t:'24'},{w:1,t:'24'},{w:1,t:'24'}],tot:3},{lab:'II',segs:[{w:1,t:'24',c:C.a}],tot:3}]);w3Msg('x = 96 : 4 = 24. Ikkinchisida <b>24</b>, birinchisida <b>72</b>')}];
var STEPS=[
{h:"So'zdan amalga",sum:"«… ta ko'p» → +, «… marta ko'p» → ·, «… ta kam» → −, «… marta kam» → :.",a:"m01",
 start:function(){S.w4={};w3Expr(['Ali: 12 ta','Vali — ?']);w3Msg('Har bir iborani bosib, qaysi amal ekanini ko‘ring')},fin:function(){w3Expr(['3 ta ko‘p → 12 + 3','3 marta ko‘p → 12 · 3','3 ta kam → 12 − 3','3 marta kam → 12 : 3']);w3Msg('To‘rtta kalit ibora')},
 html:"<p>Alida 12 ta qalam bor. Valida… To'rttala iborani bosing:</p>",
 btns:[["3 ta ko'p",function(c,done){S.w4.a=1;w3Expr(['Valida 3 ta ko‘p','12 + 3 = {15}']);w3Msg('«ta ko‘p» → qo‘shish');if(S.w4.a&&S.w4.b&&S.w4.c&&S.w4.d)done()}],["3 marta ko'p",function(c,done){S.w4.b=1;w3Expr(['Valida 3 marta ko‘p','12 · 3 = {36}']);w3Msg('«marta ko‘p» → ko‘paytirish');if(S.w4.a&&S.w4.b&&S.w4.c&&S.w4.d)done()}],["3 ta kam",function(c,done){S.w4.c=1;w3Expr(['Valida 3 ta kam','12 − 3 = {9}']);w3Msg('«ta kam» → ayirish');if(S.w4.a&&S.w4.b&&S.w4.c&&S.w4.d)done()}],["3 marta kam",function(c,done){S.w4.d=1;w3Expr(['Valida 3 marta kam','12 : 3 = {4}']);w3Msg('«marta kam» → bo‘lish');if(S.w4.a&&S.w4.b&&S.w4.c&&S.w4.d)done()},'u']],g2:1,
 after:"<p>Kalit iboralar — masala va ifoda orasidagi «ko'prik». Lekin ehtiyot bo'ling: ibora <b>kimga nisbatan</b> aytilganini ham tekshirish kerak — keyingi qadamlarda ko'rasiz.</p>",
 q:{t:"Akasida 48 ta marka bor, singlisida 4 marta kam. Singlisida nechta?",opts:["12","192","44","52"],ok:0,why:"«4 marta kam» → 48 : 4 = 12.",hint:"«marta kam» qaysi amal?",full:"48 : 4 = 12. «44» — «4 ta kam» bilan adashtirish; «192» — ko'paytirish."},
 tn:"Doskaga to'rt kalit iborani jadval qilib yozing va har biriga bitta misol qo'ydiring."},
{h:"Masaladan ifoda",sum:"540 kg un, har kuni 45 kg sotildi, 8 kundan keyin: 540 − 45 · 8 = 180 kg.",a:"m02",
 start:function(){w3Bar([{lab:'un',segs:[{w:360,t:'8 kunda sotildi'},{w:180,t:'qoldi',c:C.a}],tot:540,br:'540 kg',brw:1}],{top:60});w3Msg('Har kuni 45 kg, 8 kun')},fin:function(){w3Expr(['540 − 45 · 8','540 − 360 = {180} kg']);w3Msg('Amallar tartibi tufayli qavs kerak emas')},
 html:"<p>«Do'konda 540 kg un bor edi. Har kuni 45 kg dan sotildi. 8 kundan keyin qancha un qoldi?» Mos ifodani tanlang:</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['540 − 45 · 8','(540 − 45) · 8','540 − 45 + 8','540 : 45 · 8'],'540 − 45 · 8',function(){w3Expr(['540 − 45 · 8','540 − 360 = {180} kg']);w3Msg('To‘g‘ri!');done()},{'(540 − 45) · 8':'Qolgan unni 8 ga ko‘paytirish ma’nosiz — un ko‘paymaydi!','540 − 45 + 8':'8 — kunlar soni, kilogramm emas','540 : 45 · 8':'Bo‘lish bu yerda kerak emas — sotilgan un 45 · 8'})},
 after:"<p>Mantiqiy tekshiruv: javob ma'noli bo'lishi kerak. Un sotilsa — kamayadi, demak javob 540 dan kichik. (540 − 45) · 8 = 3960 kg — undan ham ko'p, demak xato!</p>",
 q:{t:"Do'konda 540 kg un bor edi. Har kuni 45 kg dan sotildi. 8 kundan keyin qancha un qoldi?",opts:["180 kg","3960 kg","360 kg","225 kg"],ok:0,why:"540 − 360 = 180.",hint:"8 kunda qancha sotildi?",full:"45 · 8 = 360 kg sotildi, 540 − 360 = 180 kg qoldi. «360» — sotilgani, qolgani emas; «225» — 7 kun deb hisoblash."},
 tn:"Bolalarga ifodani so'z bilan «o'qitish»ni o'rgating: «540 dan 8 kunlik savdoni ayiramiz»."},
{h:"Tuzoq: «…dan ko'p» kimga tegishli?",sum:"«Alida 35 ta, bu Validan 12 ta ko'p» → Valida kam: 35 − 12 = 23 (47 emas!).",a:"m03",
 start:function(){w3Bar([{lab:'Ali',segs:[{w:23,t:'Vali qadar'},{w:12,t:'+12',c:C.a}],tot:35,br:'35',brw:1},{lab:'Vali',segs:[{w:23,t:'?'}],tot:35}],{top:30,gap:62});w3Msg('Kimda ko‘p — Alida yoki Valida?')},fin:function(){w3Bar([{lab:'Ali',segs:[{w:23,t:'23'},{w:12,t:'+12',c:C.a}],tot:35,br:'35',brw:1},{lab:'Vali',segs:[{w:23,t:'23'}],tot:35}],{top:30,gap:62});w3Msg('Vali: 35 − 12 = 23')},
 html:"<p>«Ali 35 ta yong'oq terdi, bu <b>Validan 12 ta ko'p</b>. Vali nechta terdi?»</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['23','47'],'23',function(){w3Bar([{lab:'Ali',segs:[{w:23,t:'23'},{w:12,t:'+12',c:C.a}],tot:35,br:'35',brw:1},{lab:'Vali',segs:[{w:23,t:'23'}],tot:35}],{top:30,gap:62});w3Msg('To‘g‘ri: Vali 35 − 12 = 23 ta');done()},{'47':'«ko‘p» so‘zini ko‘rib qo‘shib yubordingiz. Lekin ko‘p — Alida! Valida kam'})},
 after:"<p>Eng mashhur tuzoq! «Ko'p» so'zi bor, lekin javob <b>ayirish</b>. Qoida: avval kimda ko'p, kimda kam ekanini aniqlang (chizma!), keyin amal tanlang.</p>",
 q:{t:"Olma 84 ta, bu nokdan 4 marta kam. Nok nechta?",opts:["336","21","88","80"],ok:0,why:"Olma kam → nok ko'p: 84 · 4 = 336.",hint:"Kimda ko'p: olmada yoki nokda?",full:"Olma nokdan kam, demak nok olmadan 4 marta ko'p: 84 · 4 = 336. «21» — «kam» so'zini ko'rib bo'lish."},
 tn:"Ikki bolani doska oldiga chiqarib, kartochkalarni qo'lida ushlatib ko'rsating: «Alida ko'p — demak Valida kam»."},
{h:"Masaladan tenglama",sum:"«O'ylangan sonni 4 marta orttirib, 150 qo'shsak 590»: x · 4 + 150 = 590 → x = 110.",a:"m04",
 start:w4St(P5),fin:w4Fin(P5),
 html:"<p>Masalani so'zma-so'z tenglamaga «tarjima» qilamiz. Chizma model yordam beradi:</p>",btns:[phaser(P5)],
 after:"<p>Usul: 1) noma'lumni <b>x</b> bilan belgilang; 2) masaladagi amallarni <b>aytilgan tartibda</b> yozing; 3) tenglik — masaladagi «chiqdi», «bo'ldi», «teng» so'zlari.</p>",
 q:{t:"O'ylangan sonni 4 marta orttirib, 150 qo'shsak, 590 chiqadi. O'ylangan son?",opts:["110","185","440","160"],ok:0,why:"x · 4 = 440, x = 110.",hint:"x · 4 + 150 = 590.",full:"x · 4 = 590 − 150 = 440, x = 110. «440» — 4 marta orttirilgan son; «185» — (590 + 150) : 4."},
 tn:"Bolalar masala uchun avval lenta chizsin, keyin har bo'lakka tenglama bo'lagini yozsin (Singapur model)."},
{h:"Ikki noma'lum: bo'laklar usuli",sum:"96 ta, 1-savatda 3 marta ko'p: x · 3 + x = 96 → x = 24; 72 va 24.",a:"m05",
 start:w4St(P6),fin:w4Fin(P6),
 html:"<p>«Ikki savatda jami 96 ta olma. Birinchisida ikkinchisidan <b>3 marta ko'p</b>. Har birida nechta?» Kuzating:</p>",btns:[phaser(P6)],
 after:"<p>«Marta ko'p» masalasida kichik miqdorni <b>bitta bo'lak</b> (x) deb olamiz. Jami bo'laklar: 3 + 1 = 4. 96 : 4 = 24 — bitta bo'lak. Tekshiruv: 72 + 24 = 96 ✓, 72 : 24 = 3 ✓.</p>",
 q:{t:"Alida Validan 2 marta ko'p pul bor. Ikkalasida jami 1500 so'm. Alida qancha?",opts:["1000 so'm","500 so'm","750 so'm","3000 so'm"],ok:0,why:"3 bo'lak = 1500, 1 bo'lak = 500, Ali — 2 bo'lak = 1000.",hint:"Jami nechta bo'lak?",full:"Vali — 1 bo'lak, Ali — 2 bo'lak, jami 3 bo'lak = 1500 → 1 bo'lak = 500. Ali: 1000. «750» — 1500 : 2 (bo'laklarni teng deb olish)."},
 tn:"Rangli qog'oz lentalardan bo'laklarni kesib, «bo'laklar usuli»ni qo'lda ko'rsating."},
{h:"Bitta masala — ikki yo'l",sum:"Daftar 2500 so'm, 20 000 berildi, 5000 qaytim: ifoda (20000 − 5000) : 2500 = 6 yoki tenglama 20000 − 2500 · x = 5000.",a:"m06",
 start:function(){S.w4={};w3Expr(['20 000 − 2500 · x = 5000']);w3Msg('Ifoda bilan ham, tenglama bilan ham yeching')},fin:function(){w3Expr(['(20 000 − 5000) : 2500 = {6}','20 000 − 2500 · x = 5000 → x = {6}']);w3Msg('Ikki yo‘l — bitta javob')},
 html:"<p>«Ali 2500 so'mlik daftarlardan bir nechtasini olib, 20 000 so'm berdi va 5000 so'm qaytim oldi. Nechta daftar oldi?» Ikkala usulni ham bosing:</p>",
 btns:[["Ifoda bilan",function(c,done){S.w4.a=1;w3Expr(['daftarlarga: 20 000 − 5000 = 15 000','15 000 : 2500 = {6}']);w3Msg('Arifmetik usul: oxiridan o‘ylash');if(S.w4.b)done()}],["Tenglama bilan",function(c,done){S.w4.b=1;w3Expr(['20 000 − 2500 · x = 5000','2500 · x = 15 000','x = {6}']);w3Msg('Algebraik usul: shartni so‘zma-so‘z yozish');if(S.w4.a)done()},'u']],g2:1,
 after:"<p>Ikkala usul ham to'g'ri. Ifoda bilan — har qadamni o'ylab topasiz. Tenglama bilan — shartni «tarjima» qilasiz, qolgani qoidalar bo'yicha. Murakkab masalalarda tenglama ko'pincha osonroq!</p>",
 q:{t:"4 ta bir xil qalam va 7000 so'mlik kitob uchun 10 000 so'm to'landi. Bitta qalam necha so'm?",opts:["750 so'm","3000 so'm","4250 so'm","2500 so'm"],ok:0,why:"x · 4 + 7000 = 10 000 → x · 4 = 3000 → x = 750.",hint:"Avval qalamlarga qancha ketgan?",full:"Qalamlarga 10 000 − 7000 = 3000 so'm, bittasi 3000 : 4 = 750. «3000» — 4 ta qalam narxi; «2500» — kitob hisobga olinmagan."},
 tn:"Sinfni ikki guruhga bo'ling: biri ifoda, biri tenglama bilan yechsin. Javoblar mos kelishini birga tekshiring."},
{h:"Tenglamadan masalaga",sum:"x : 3 + 8 = 20 — «konfetlar 3 bolaga teng bo'lindi, Aliga yana 8 ta berildi — unda 20 ta bo'ldi».",a:"m07",
 start:function(){w3Expr(['x : 3 + 8 = 20']);w3Msg('Qaysi masala shu tenglamaga mos?')},fin:function(){w3Expr(['x : 3 + 8 = 20','x : 3 = 12','x = {36}']);w3Msg('A masala mos. Jami 36 ta konfet')},
 html:"<p>Teskari vazifa: <b>x : 3 + 8 = 20</b> tenglamaga qaysi masala mos?</p><p><b>A</b>: Konfetlar 3 bolaga teng bo'lindi, Aliga yana 8 ta berildi — unda 20 ta bo'ldi.<br><b>B</b>: 3 ta qutida bir xil konfet bor edi, yana 8 ta qo'shildi — jami 20 ta bo'ldi.<br><b>C</b>: Konfetlarga yana 8 ta qo'shib, 3 bolaga teng bo'lindi — har biriga 20 ta tegdi.</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['A','B','C'],'A',function(){w3Expr(['x : 3 + 8 = 20','x : 3 = 12','x = {36}']);w3Msg('To‘g‘ri: avval bo‘lish, keyin 8 qo‘shish');done()},{'B':'B ga x · 3 + 8 = 20 mos — ko‘paytirish, bo‘lish emas','C':'C ga (x + 8) : 3 = 20 mos — avval qo‘shilgan'})},
 after:"<p>Tenglamani «o'qish» — amallar tartibini masala voqealari tartibiga aylantirish: <b>x : 3</b> — avval bo'lindi, <b>+ 8</b> — keyin qo'shildi. Qavs bo'lsa — qavsdagi voqea birinchi sodir bo'ladi.</p>",
 q:{t:"«Sonning yarmiga 15 qo'shsak, 40 chiqadi.» Qaysi tenglama mos?",opts:["x : 2 + 15 = 40","(x + 15) : 2 = 40","x · 2 + 15 = 40","x : 2 = 40 + 15"],ok:0,why:"Avval yarmi (x : 2), keyin + 15.",hint:"Qaysi amal birinchi bajariladi?",full:"«Yarmiga qo'shsak» — avval yarmini olamiz: x : 2, keyin + 15 = 40. x = 50. «(x + 15) : 2» — yig'indining yarmi, boshqa masala."},
 tn:"Bolalar bitta tenglama uchun o'zlari masala o'ylab topsin — eng qiziqarlisini sinf tanlaydi."},
{h:"Murakkab: ketma-ket sonlar va yosh",sum:"Uchta ketma-ket son yig'indisi 75: x + (x + 1) + (x + 2) = 75 → 24, 25, 26.",a:"m08",
 start:function(){w3Bar([{lab:'',segs:[{w:1,t:'x'}],tot:1.2},{lab:'',segs:[{w:1,t:'x'},{w:0.1,t:'',c:C.a}],tot:1.2},{lab:'',segs:[{w:1,t:'x'},{w:0.2,t:'',c:C.a}],tot:1.2}],{top:20,gap:44});w3Msg('Uchta son: x, x + 1, x + 2')},fin:function(){w3Expr(['x · 3 + 3 = 75','x · 3 = 72,  x = {24}','24 + 25 + 26 = 75 ✓']);w3Msg('Eng kattasi — 26')},
 html:"<p>«Uchta ketma-ket natural sonning yig'indisi 75. Eng kattasi qaysi?» Avval tenglama: x + (x + 1) + (x + 2) = 75, ya'ni <b>x · 3 + 3 = 75</b>.</p><div class='digs w4a'></div>",
 act:function(c,done){w4Sel(c,'.w4a',['24','25','26'],'26',function(){w3Expr(['x · 3 + 3 = 75','x · 3 = 72,  x = {24}','24 + 25 + 26 = 75 ✓']);w3Msg('To‘g‘ri: eng kattasi 26');done()},{'24':'24 — eng kichigi (x). Eng kattasi x + 2','25':'25 — o‘rtadagisi (75 : 3). Eng kattasi undan bitta ko‘p'})},
 after:"<p>Aqlli yo'l: o'rtadagi son = 75 : 3 = 25 (chunki chetdagilar «±1» bilan muvozanatlashadi). Unda sonlar 24, 25, 26. Savol nimani so'rayotganini oxirida yana bir o'qing — «eng kattasi»!</p>",
 q:{t:"Ota 40 yoshda, u o'g'lidan 4 marta katta. 5 yildan keyin o'g'li necha yoshda bo'ladi?",opts:["15","10","45","9"],ok:0,why:"O'g'li hozir 40 : 4 = 10; 5 yildan keyin 15.",hint:"Avval o'g'lining hozirgi yoshi.",full:"40 : 4 = 10 yosh, 10 + 5 = 15. «10» — «5 yildan keyin» unutilgan; «45» — otaning 5 yildan keyingi yoshi."},
 tn:"Ko'p bosqichli masalada bolalar savolni oxirida qayta o'qib, javob aynan o'sha savolga ekanini tekshirsin."},
{h:"Bilasizmi? Qadimgi Misrning «aha» masalalari",sum:"Rind papirusida (miloddan avvalgi XVII asr) noma'lum son «aha» deb atalgan tenglamaga oid masalalar bor.",a:"m09",
 start:function(){w3Expr(['«aha» = x']);w3Msg('3500 yildan ortiq yoshdagi tenglamalar')},fin:function(){w3Expr(['«aha» = x']);w3Msg('3500 yildan ortiq yoshdagi tenglamalar')},
 html:"<p>📜 Qadimgi Misrda kotib <b>Ahmes</b> ko'chirgan <b>Rind papirusi</b> (miloddan avvalgi XVII asr) — eng qadimgi matematik qo'llanmalardan biri. Unda noma'lum son <b>«aha»</b> (to'da, miqdor) deb atalgan masalalar bor.</p><p>⭐ Masalan: «Miqdor va uning yettidan biri birga 19 ga teng. Miqdor nechaga teng?» — bu bugungi tilda tenglama! Misrliklar uni «tanlab ko'rish» usulida yechishgan.</p>",
 tn:"Bolalarga ayting: biz bugun x deb yozadigan narsani misrliklar «aha», al-Xorazmiy esa «shay» (narsa) deb atagan."},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){w3Expr(['1) x ni belgila','2) chizma chiz','3) tenglama tuz, yech, tekshir']);w3Msg('Masaladan tenglamaga')},fin:function(){w3Expr(['1) x ni belgila','2) chizma chiz','3) tenglama tuz, yech, tekshir']);w3Msg('Masaladan tenglamaga')},
 html:"<div class='memo'><ul><li>«ta ko'p» → +, «marta ko'p» → ·, «ta kam» → −, «marta kam» → :.</li><li>Tuzoq: «Ali 35 ta, bu Validan 12 ta ko'p» → Vali: 35 − 12.</li><li>«Marta ko'p» masalasida kichik miqdor = 1 bo'lak; jami bo'laklarni sanang.</li><li>Tenglama: x ni belgilang → amallarni aytilgan tartibda yozing → «chiqdi/bo'ldi» = tenglik.</li><li>Javob ma'nolimi? Savolga aynan javob berdingizmi?</li></ul></div>",
 tn:"4E mavzularidagi barcha matnli masalalarda shu kartochka asos bo'ladi."}
];
var PROBS=[
{t:"Do'konda 540 kg un bor edi. Har kuni 45 kg dan sotildi. 8 kundan keyin qancha un qoldi?",o:["180 kg","3960 kg","360 kg","225 kg"],k:0,s:"540 − 45 · 8 = 180."},
{t:"Ali 35 ta yong'oq terdi, bu Validan 12 ta ko'p. Vali nechta terdi?",o:["23","47","420","22"],k:0,s:"35 − 12 = 23."},
{t:"Olma 84 ta, bu nokdan 4 marta kam. Nok nechta?",o:["336","21","88","80"],k:0,s:"84 · 4 = 336."},
{t:"O'ylangan sonni 4 marta orttirib, 150 qo'shsak, 590 chiqadi. O'ylangan son?",o:["110","185","440","160"],k:0,s:"x · 4 = 440 → x = 110."},
{t:"Ikki savatda jami 96 ta olma. Birinchisida ikkinchisidan 3 marta ko'p. Birinchi savatda nechta?",o:["72","24","32","64"],k:0,s:"4 bo'lak = 96, 1 bo'lak = 24, birinchisi 72."},
{t:"Ali 2500 so'mlik daftarlardan bir nechtasini olib, 20 000 so'm berdi va 5000 so'm qaytim oldi. Nechta daftar oldi?",o:["6","8","2","10"],k:0,s:"15 000 : 2500 = 6."},
{t:"x : 3 + 8 = 20 tenglamaga qaysi masala mos?",o:["Konfetlar 3 bolaga teng bo'lindi, birining konfetiga yana 8 ta qo'shilib 20 ta bo'ldi","3 ta qutida x tadan konfet va yana 8 ta — jami 20 ta","Konfetlarga 8 ta qo'shib, 3 bolaga bo'lindi — har biriga 20 ta","Konfetlardan 8 tasi yeyilib, qolgani 3 bolaga 20 tadan bo'lindi"],k:0,s:"Avval : 3, keyin + 8."},
{t:"Sinfda 32 o'quvchi. Qizlar o'g'il bolalardan 4 ta ko'p. Qizlar nechta?",o:["18","14","16","36"],k:0,s:"(32 + 4) : 2 = 18; o'g'il bolalar 14."},
{t:"Ota 40 yoshda, u o'g'lidan 4 marta katta. 5 yildan keyin o'g'li necha yoshda bo'ladi?",o:["15","10","45","9"],k:0,s:"40 : 4 = 10, 10 + 5 = 15."},
{t:"Bir son 7 ga bo'linganda bo'linma 15, qoldiq 3 chiqdi. Shu son?",o:["108","105","102","25"],k:0,s:"7 · 15 + 3 = 108."},
{t:"Alida Validan 2 marta ko'p pul bor. Ikkalasida jami 1500 so'm. Alida qancha?",o:["1000 so'm","500 so'm","750 so'm","3000 so'm"],k:0,s:"1 bo'lak = 500, Ali 2 bo'lak."},
{t:"Bog'da 3 qator olma daraxti (har qatorda bir xil) va 12 ta nok daraxti bor. Jami 60 ta daraxt. Har qatorda nechta olma daraxti?",o:["16","24","20","4"],k:0,s:"x · 3 + 12 = 60 → x = 16."},
{t:"«Sonning yarmiga 15 qo'shsak, 40 chiqadi.» Qaysi tenglama mos?",o:["x : 2 + 15 = 40","(x + 15) : 2 = 40","x · 2 + 15 = 40","x : 2 = 40 + 15"],k:0,s:"Avval yarmi, keyin + 15."},
{t:"Uchta ketma-ket natural sonning yig'indisi 75. Eng kattasi?",o:["26","25","24","27"],k:0,s:"24 + 25 + 26 = 75."},
{t:"Avtobusda yo'lovchilar bor edi. Bekatda 12 kishi tushdi, 8 kishi chiqdi va 30 kishi bo'ldi. Avval nechta yo'lovchi bor edi?",o:["34","26","50","10"],k:0,s:"30 − 8 + 12 = 34."},
{t:"Akasida singlisidan 3 marta ko'p marka bor. Ikkalasida jami 120 ta. Akasida singlisidan nechta ko'p?",o:["60","90","30","40"],k:0,s:"Singlisi 30, akasi 90, farq 60."},
{t:"Ruchka daftardan 1200 so'm qimmat. 2 ta ruchka va 3 ta daftar 12 400 so'm turadi. Ruchka necha so'm?",o:["3200 so'm","2000 so'm","2480 so'm","1200 so'm"],k:0,s:"2 · (d + 1200) + 3 · d = 12 400 → 5 · d = 10 000 → d = 2000; ruchka 3200."},
{t:"Sonni 6 ga ko'paytirib, natijadan 120 ni ayirsak, shu sonning o'zi chiqadi. Son nechaga teng?",o:["24","20","120","30"],k:0,s:"x · 6 − 120 = x → x · 5 = 120 → x = 24."},
{t:"Opada 300 so'm, singlisida 180 so'm. Opa singlisiga qancha bersa, pullari teng bo'ladi?",o:["60 so'm","120 so'm","240 so'm","90 so'm"],k:0,s:"Farq 120, yarmi 60: 240 va 240."},
{t:"4 ta bir xil qalam va 7000 so'mlik kitob uchun 10 000 so'm to'landi. Bitta qalam necha so'm?",o:["750 so'm","3000 so'm","4250 so'm","2500 so'm"],k:0,s:"3000 : 4 = 750."}
];
function PRACT_STAGE(){w3Expr(['1) x ni belgila','2) chizma chiz','3) tenglama tuz']);w3Msg('Masaladan tenglamaga')}
var PREP_DATA={teach:["Kalit iboralar: «ta ko'p/kam», «marta ko'p/kam».","Masala shartidan ifoda tuzish.","Masala shartidan tenglama tuzish; bo'laklar usuli.","Tenglamaga mos masala tanlash yoki tuzish; ko'p bosqichli masalalar."],
 mist:["«Validan 12 ta ko'p» so'zini ko'rib qo'shib yuboradi.","«Marta kam» da bo'ladi, holbuki so'ralgan miqdor katta.","Ifodada amallar tartibini masala voqealari tartibiga moslamaydi.","Oraliq natijani javob deb beradi (savolni qayta o'qimaydi)."],
 need:["Rangli qog'oz lentalar (bo'laklar usuli).","Kalit iboralar jadvali plakati."],
 board:["<span class='w2'>540 − 45 · 8 = 180</span>.","<span class='w2'>Ali 35, Validan 12 ta ko'p → Vali 23</span>.","<span class='w2'>x · 4 + 150 = 590 → x = 110</span>.","<span class='w2'>x · 3 + x = 96 → 24 va 72</span>.","<span class='w2'>x : 3 + 8 = 20 → x = 36</span>."]};
// ===== w4: 4D/4E uchun qo'shimcha =====
function w4Sel(c,sel,vals,ok,okFn,badMsg){w3Btns(c,sel,vals,function(v,b){var k=b.className.replace(/ (no|yes)/g,'');if(v===ok){b.className=k+' yes';okFn()}else{b.className=k+' no';setTimeout(function(){b.className=k},1200);w3Msg((badMsg&&badMsg[v])||'Yana bir o‘ylab ko‘ring')}})}
function w4Fin(P){return function(){S.ph=P.length-1;P[P.length-1]()}}
function w4St(P){return function(){S.ph=0;startPh(P)}}
function w4Bal(L,R){clear();var g=S.g,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 E('line',{x1:cx-120,y1:cy+12,x2:cx+120,y2:cy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-112],[R,cx+112]].forEach(function(z){var x=z[1],yt=cy+12,yb=yt+56;E('line',{x1:x,y1:yt,x2:x-46,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:yt,x2:x+46,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-56)+' '+yb+' q56 18 112 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0].map(function(it){return typeof it==='string'?{t:it}:it}),ws=items.map(function(it){return Math.max(24,it.t.length*8+8)}),tw=ws.reduce(function(a,b){return a+b},0)+(items.length-1)*3,xx=x-tw/2;
  items.forEach(function(it,i){var isX=/x/.test(it.t),col=it.c||(isX?C.a:'#cfe6f7');E('rect',{x:xx,y:yb-24,width:ws[i],height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx+ws[i]/2,yb-8,it.t,{'font-size':12,'font-weight':800,fill:'#1d2b3a'});xx+=ws[i]+3})})}

// ===== w3: 3C14–3C16, 3D1–3D6 uchun umumiy sahna vositalari =====
function w3Msg(h,note){strip.innerHTML='<div class="calc">'+(note?'<div class="nt">'+note+'</div>':'')+'<div class="cl last" style="text-align:center">'+h+'</div></div>'}
// ifoda qatorlari: [..] — qizil, {..} — yashil
function w3Expr(lines,o){o=o||{};clear();var g=S.g,n=lines.length,top=o.top||(n>3?28:44),gap=o.gap||(n>3?34:40);
 lines.forEach(function(l,i){var y=top+i*gap,plain=l.replace(/[\[\]{}]/g,''),base=o.fs||(i===n-1?24:21),fs=Math.min(base,Math.floor(500/Math.max(1,plain.length)));
  var t=T(g,180,y,'',{'font-size':fs,'font-weight':800,fill:i===n-1&&n>1?'#1d2b3a':'#46586a','font-family':'ui-monospace,Menlo,Consolas,monospace'});
  l.split(/(\[[^\]]*\]|\{[^}]*\})/).forEach(function(p){if(!p)return;var ts=E('tspan',{},t);if(p[0]==='['){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.bad)}else if(p[0]==='{'){ts.textContent=p.slice(1,-1);ts.setAttribute('fill',C.ok)}else ts.textContent=p})})}
// ---- burchakli bo'lish ----
function w3Ops(D,d){var s=String(D),ops=[],i=0,part=+s[0];while(part<d&&i<s.length-1){i++;part=part*10+(+s[i])}
 var q='';while(true){var qd=Math.floor(part/d),pr=qd*d,rem=part-pr;
  if(qd===0&&q.length){ops.push({t:'zero',part:part,pos:i});q+='0'}
  else{ops.push({t:'div',part:part,qd:qd,pos:i});q+=qd;ops.push({t:'mul',pr:pr,pos:i,qd:qd});ops.push({t:'sub',rem:rem,pos:i,part:part,pr:pr})}
  if(i>=s.length-1){ops.push({t:'end',rem:rem,q:q});break}
  i++;var nd=+s[i];ops.push({t:'down',dig:nd,pos:i,val:rem*10+nd});part=rem*10+nd}
 return ops}
function w3Long(D,d,k){clear();var g=S.g,s=String(D),ops=w3Ops(D,d),cw=14,x0=40+Math.max(0,5-s.length)*cw,rh=19,y=26,fs=19,MF='ui-monospace,Menlo,Consolas,monospace';
 function num(v,pos,yy,col,minLen){var t=String(v);if(minLen&&t.length<minLen)t=Array(minLen-t.length+1).join('0')+t;for(var j=0;j<t.length;j++){T(g,x0+(pos-(t.length-1-j))*cw+cw/2,yy,t[j],{'font-size':fs,'font-weight':800,fill:col||'#1d2b3a','font-family':MF})}}
 num(D,s.length-1,y);var xl=x0+s.length*cw+6;E('line',{x1:xl,y1:y-17,x2:xl,y2:y+rh+2,stroke:'#33475b','stroke-width':2},g);
 T(g,xl+8,y,String(d),{'font-size':fs,'font-weight':800,fill:C.blue,'text-anchor':'start','font-family':MF});E('line',{x1:xl,y1:y+4,x2:xl+Math.max(60,String(d).length*cw+40),y2:y+4,stroke:'#33475b','stroke-width':2},g);
 var q='',row=0,cur=null,shown=ops.slice(0,k),last=shown[shown.length-1];
 shown.forEach(function(op,idx){var isL=idx===shown.length-1;
  if(op.t==='div'){q+=op.qd;if(row===0)E('path',{d:'M'+(x0+(op.pos-String(op.part).length+1)*cw)+' '+(y+5)+' q'+(String(op.part).length*cw/2)+' 6 '+(String(op.part).length*cw)+' 0',fill:'none',stroke:isL?C.bad:'#c9d3dd','stroke-width':1.6},g)}
  else if(op.t==='zero'){q+='0'}
  else if(op.t==='mul'){row++;var yy=y+row*rh;num(op.pr,op.pos,yy,isL?C.bad:'#46586a');T(g,x0+(op.pos-String(op.pr).length+1)*cw-8,yy-6,'−',{'font-size':14,'font-weight':800,fill:'#5b6b7b'});E('line',{x1:x0+(op.pos-String(op.pr).length+1)*cw-2,y1:yy+4,x2:x0+(op.pos+1)*cw,y2:yy+4,stroke:'#5b6b7b','stroke-width':1.4},g)}
  else if(op.t==='sub'){row++;cur={v:op.rem,pos:op.pos,row:row};var nx=ops[ops.indexOf(op)+1];num(op.rem,op.pos,y+row*rh,(op.rem===0&&nx&&nx.t==='down'&&!isL)?'#c9d3dd':(isL?C.ok:'#1d2b3a'))}
  else if(op.t==='down'){T(g,x0+op.pos*cw+cw/2,y+row*rh,String(op.dig),{'font-size':fs,'font-weight':800,fill:isL?C.blue:'#1d2b3a','font-family':MF});
   if(isL){E('path',{d:'M'+(x0+op.pos*cw+cw/2)+' '+(y+5)+' L'+(x0+op.pos*cw+cw/2)+' '+(y+row*rh-16),stroke:C.blue,'stroke-width':1.3,'stroke-dasharray':'3 3',fill:'none'},g)}
   if(cur&&cur.v===0&&op.val<10&&false){}}
 });
 T(g,xl+8,y+rh+4,q||' ',{'font-size':fs,'font-weight':800,fill:C.ok,'text-anchor':'start','font-family':MF});
 if(last&&last.t==='end'&&last.rem)T(g,xl+8,y+2*rh+8,'qoldiq '+last.rem,{'font-size':13,'font-weight':800,fill:C.bad,'text-anchor':'start'});
 return ops}
function w3OpMsg(op,d){if(!op)return '';switch(op.t){
 case 'div':return '<b>Bo‘l:</b> '+op.part+' : '+d+' ≈ <b>'+op.qd+'</b> (bo‘linmaga '+op.qd+' yozamiz)';
 case 'mul':return '<b>Ko‘paytir:</b> '+op.qd+' · '+d+' = <b>'+op.pr+'</b> (ostiga yozamiz)';
 case 'sub':return '<b>Ayir:</b> '+op.part+' − '+op.pr+' = <b>'+op.rem+'</b>'+(op.rem>=d?' — xato!':' ('+op.rem+' &lt; '+d+' ✓)');
 case 'down':return '<b>Tushir:</b> keyingi raqam '+op.dig+' → yangi son <b>'+op.val+'</b>';
 case 'zero':return op.part+' : '+d+' — <b>sig‘maydi</b>! Bo‘linmaga <b>0</b> yozamiz';
 case 'end':return 'Tayyor: bo‘linma <b>'+op.q.replace(/^0+/,'')+'</b>'+(op.rem?', qoldiq <b>'+op.rem+'</b>':', qoldiq 0');}}
function w3LongPh(D,d,intro){var ops=w3Ops(D,d),P=[function(){w3Long(D,d,0);w3Msg(intro||(D+' : '+d+' — burchak chizdik. Boshlaymiz!'))}];
 ops.forEach(function(op,i){P.push(function(){w3Long(D,d,i+1);w3Msg(w3OpMsg(op,d))})});return P}
// ---- tarozi ----
function w3Bal(L,R,o){o=o||{};clear();var g=S.g,tilt=o.tilt||0,cx=180,cy=40;E('path',{d:'M'+(cx-24)+' 160 L'+(cx+24)+' 160 L'+cx+' 52 Z',fill:'#c9d3dd',stroke:'#8a99a8'},g);
 var a=tilt*0.12,dx=120*Math.cos(a),dy=120*Math.sin(a);E('line',{x1:cx-dx,y1:cy+dy+12,x2:cx+dx,y2:cy-dy+12,stroke:'#5b6b7b','stroke-width':5,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy+12,r:5,fill:'#5b6b7b'},g);
 [[L,cx-dx,cy+dy+12],[R,cx+dx,cy-dy+12]].forEach(function(z){var x=z[1],yb=z[2]+56;E('line',{x1:x,y1:z[2],x2:x-38,y2:yb,stroke:'#8a99a8'},g);E('line',{x1:x,y1:z[2],x2:x+38,y2:yb,stroke:'#8a99a8'},g);E('path',{d:'M'+(x-46)+' '+yb+' q46 18 92 0 Z',fill:'#e9eef3',stroke:'#8a99a8'},g);
  var items=z[0],w=Math.min(30,88/Math.max(1,items.length));items.forEach(function(it,i){var xx=x-(items.length*w)/2+i*w+w/2,isX=/x/.test(it.t||it),col=(it.c)||(isX?C.a:'#cfe6f7');var lbl=it.t||it;var bw=Math.max(w-3,lbl.length*7+6);E('rect',{x:xx-bw/2,y:yb-24,width:bw,height:22,rx:5,fill:col,stroke:'#8a5a24','stroke-width':1},g);T(g,xx,yb-8,lbl,{'font-size':12,'font-weight':800,fill:'#1d2b3a'})})})}
// ---- koordinata nuri ----
function w3Ray(from,to,step,marks,o){o=o||{};clear();var g=S.g,x0=24,x1=330,y=o.y||100,n=(to-from)/step,k=(x1-x0)/n,X=function(v){return x0+(v-from)/step*k};S.X=X;
 E('line',{x1:x0,y1:y,x2:x1+14,y2:y,stroke:'#33475b','stroke-width':2.5},g);E('path',{d:'M'+(x1+14)+' '+(y-6)+' L'+(x1+22)+' '+y+' L'+(x1+14)+' '+(y+6)+' Z',fill:'#33475b'},g);
 for(var i=0;i<=n;i++){var v=from+i*step,xx=X(v);E('line',{x1:xx,y1:y-7,x2:xx,y2:y+7,stroke:'#33475b','stroke-width':v===from?2.5:1.4},g);if(o.all||i%(o.every||1)===0)T(g,xx,y+24,String(v),{'font-size':n>14?9:11,fill:'#5b6b7b'});
  if(o.tap){(function(vv,xx2){var r=E('rect',{x:xx2-k/2,y:y-30,width:k,height:62,fill:'transparent',style:'cursor:pointer'},g);r.addEventListener('click',function(){o.tap(vv)})})(v,xx)}}
 (marks||[]).forEach(function(m){E('circle',{cx:X(m[0]),cy:y,r:7,fill:m[2]||C.blue,stroke:'#fff','stroke-width':2,'pointer-events':'none'},g);T(g,X(m[0]),y-14,m[1]!=null?m[1]:String(m[0]),{'font-size':13,'font-weight':800,fill:m[2]||C.blue,'pointer-events':'none'})});return X}
function w3Jump(a,b,lab,col,y,h){var X=S.X;y=y||100;h=h||36;col=col||C.ok;E('path',{d:'M'+X(a)+' '+(y-27)+' Q'+(X(a)+X(b))/2+' '+(y-27-h)+' '+X(b)+' '+(y-27),fill:'none',stroke:col,'stroke-width':2},S.g);
 E('path',{d:'M'+(X(b)-6*(b>a?1:-1))+' '+(y-35)+' L'+X(b)+' '+(y-27)+' L'+(X(b)-9*(b>a?1:-1))+' '+(y-30),fill:'none',stroke:col,'stroke-width':2},S.g);if(lab)T(S.g,(X(a)+X(b))/2,y-29-h*0.6,lab,{'font-size':12,'font-weight':800,fill:col})}
// ---- chiziqli model (lenta) ----
function w3Bar(rows,o){o=o||{};clear();var g=S.g,x0=40,W=280;rows.forEach(function(r,i){var y=(o.top||28)+i*(o.gap||52),tot=r.tot||r.segs.reduce(function(a,s){return a+s.w},0),x=x0;
  if(r.lab)T(g,x0-6,y+17,r.lab,{'font-size':11,'font-weight':700,fill:'#5b6b7b','text-anchor':'end'});
  r.segs.forEach(function(s){var w=W*s.w/tot;E('rect',{x:x,y:y,width:w,height:26,rx:3,fill:s.c||C.b,stroke:C.line,'stroke-width':1.3},g);if(s.t)T(g,x+w/2,y+18,s.t,{'font-size':13,'font-weight':800,fill:'#1d2b3a'});x+=w});
  if(r.br)Br(x0,x0+W*(r.brw||1),y-4,r.br,true)})}
// raqam/variant tugmalari html ichida (act uchun)
function w3Btns(c,sel,vals,fn){var box=c.querySelector(sel);box.innerHTML='';vals.forEach(function(v){var b=document.createElement('button');b.type='button';b.className='dg'+(String(v).length>2?' wide':'');b.textContent=v;if(String(v).length>3)b.style.cssText='white-space:nowrap;width:auto;padding:0 12px';b.onclick=function(){fn(v,b)};box.appendChild(b)});return box}
