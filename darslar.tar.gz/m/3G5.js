
// ===== w_3f umumiy sahna vositalari (3F, 3G) =====
function f3msg(h){strip.innerHTML='<div class="calc"><div class="cl last" style="text-align:center">'+h+'</div></div>'}
function f3calc(lines,note){calc(lines,note)}
function f3sector(p,cx,cy,r,a0,a1,fill){var x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),L=(a1-a0)>Math.PI?1:0;
 if(a1-a0>=2*Math.PI-1e-6)return E('circle',{cx:cx,cy:cy,r:r,fill:fill,stroke:C.line,'stroke-width':1.6},p);
 return E('path',{d:'M'+cx+' '+cy+' L'+x0+' '+y0+' A'+r+' '+r+' 0 '+L+' 1 '+x1+' '+y1+' Z',fill:fill,stroke:C.line,'stroke-width':1.6},p)}
// doira: n ta teng bo'lak, sh — bo'yalganlar (massiv yoki son), onTap(i) — bosilganda
function f3circle(cx,cy,r,n,sh,onTap,col){var g=E('g',{},S.g),cells=[],a=-Math.PI/2,d=2*Math.PI/n;
 for(var i=0;i<n;i++){var on=typeof sh==='number'?i<sh:(sh||[]).indexOf(i)>=0;var c=f3sector(g,cx,cy,r,a+i*d,a+(i+1)*d,on?(col||C.a):C.off);c._i=i;c._on=on;cells.push(c);
  if(onTap){c.style.cursor='pointer';(function(c){c.addEventListener('click',function(){c._on=!c._on;c.setAttribute('fill',c._on?(col||C.a):C.off);onTap(c._i,cells)})})(c)}}
 return cells}
// to'rtburchak tasma: n bo'lak, k bo'yalgan
function f3bar(x,y,w,h,n,k,col,txt){var g=E('g',{},S.g),cells=[];for(var i=0;i<n;i++){var on=typeof k==='number'?i<k:(k||[]).indexOf(i)>=0;cells.push(E('rect',{x:x+i*w/n,y:y,width:w/n,height:h,fill:on?(col||C.a):C.off,stroke:C.line,'stroke-width':1.4},g));if(txt&&txt[i]!=null)T(g,x+(i+.5)*w/n,y+h/2+5,String(txt[i]),{'font-size':13,'font-weight':800,fill:'#2b2b2b'})}
 E('rect',{x:x,y:y,width:w,height:h,fill:'none',stroke:C.line,'stroke-width':2.2,rx:2},g);return cells}
// soat: hh (0–23), mm
function f3clock(cx,cy,r,hh,mm,o){o=o||{};var g=E('g',{},S.g);E('circle',{cx:cx,cy:cy,r:r,fill:'#fff',stroke:'#33475b','stroke-width':3},g);
 if(o.shade){var a0=-Math.PI/2+o.shade[0]/60*2*Math.PI,a1=-Math.PI/2+o.shade[1]/60*2*Math.PI;f3sector(g,cx,cy,r-3,a0,a1,o.shadeCol||'#ffe2b8')}
 for(var i=0;i<60;i++){var a=i/60*2*Math.PI-Math.PI/2,big=i%5===0;E('line',{x1:cx+(r-(big?9:5))*Math.cos(a),y1:cy+(r-(big?9:5))*Math.sin(a),x2:cx+(r-2)*Math.cos(a),y2:cy+(r-2)*Math.sin(a),stroke:'#33475b','stroke-width':big?2:1},g)}
 for(var h=1;h<=12;h++){var a2=h/12*2*Math.PI-Math.PI/2;T(g,cx+(r-19)*Math.cos(a2),cy+(r-19)*Math.sin(a2)+4,String(h),{'font-size':Math.max(10,r/6),'font-weight':700,fill:'#1d2b3a'})}
 var ah=((hh%12)+mm/60)/12*2*Math.PI-Math.PI/2,am=mm/60*2*Math.PI-Math.PI/2;
 E('line',{x1:cx,y1:cy,x2:cx+r*.5*Math.cos(ah),y2:cy+r*.5*Math.sin(ah),stroke:'#1d2b3a','stroke-width':5,'stroke-linecap':'round'},g);
 E('line',{x1:cx,y1:cy,x2:cx+r*.78*Math.cos(am),y2:cy+r*.78*Math.sin(am),stroke:C.bad,'stroke-width':3,'stroke-linecap':'round'},g);E('circle',{cx:cx,cy:cy,r:4,fill:'#1d2b3a'},g);return g}
function f3hm(h,m){return (h<10?'0':'')+h+':'+(m<10?'0':'')+m}
// chizg'ich: x0..x0+w, from..to (sm), mm belgilari
function f3ruler(x0,y,w,from,to,o){o=o||{};var g=E('g',{},S.g),k=w/(to-from);E('rect',{x:x0-8,y:y,width:w+16,height:34,rx:4,fill:'#fff3c4',stroke:'#c9a764'},g);
 for(var v=from*10;v<=to*10;v++){var X=x0+(v/10-from)*k,big=v%10===0,mid=v%5===0;E('line',{x1:X,y1:y,x2:X,y2:y+(big?14:mid?10:6),stroke:'#5b4a1e','stroke-width':big?1.4:.7},g);if(big)T(g,X,y+27,String(v/10),{'font-size':10,fill:'#5b4a1e'})}
 return function(v){return x0+(v-from)*k}}
// tarozi
function f3scale(lw,rw,ll,rl){var g=E('g',{},S.g),tilt=Math.max(-12,Math.min(12,(rw-lw)/Math.max(lw,rw,1)*14));E('path',{d:'M180 150 L165 165 L195 165 Z',fill:'#5b6b7b'},g);E('line',{x1:180,y1:150,x2:180,y2:70,stroke:'#5b6b7b','stroke-width':4},g);
 var a=tilt*Math.PI/180,lx=180-110*Math.cos(a),ly=70-110*Math.sin(a),rx=180+110*Math.cos(a),ry=70+110*Math.sin(a);E('line',{x1:lx,y1:ly,x2:rx,y2:ry,stroke:'#33475b','stroke-width':4},g);
 [[lx,ly,ll],[rx,ry,rl]].forEach(function(p){E('line',{x1:p[0],y1:p[1],x2:p[0],y2:p[1]+30,stroke:'#33475b'},g);E('path',{d:'M'+(p[0]-40)+' '+(p[1]+30)+' h80 l-10 12 h-60 Z',fill:'#cfd6de',stroke:'#33475b'},g);T(g,p[0],p[1]+24,p[2]||'',{'font-size':12,'font-weight':800,fill:'#1d2b3a'})});return g}
// kalendar oy jadvali: start — 1-sana hafta kuni (0=Du), days — kunlar soni, hl — {sana:rang}
var F3WD=['Du','Se','Ch','Pa','Ju','Sh','Ya'];
function f3month(start,days,hl,onTap,o){o=o||{};var g=E('g',{},S.g),x0=22,y0=o.y0||34,cw=45,rh=20;F3WD.forEach(function(d,i){T(g,x0+i*cw+cw/2,y0-8,d,{'font-size':11,'font-weight':800,fill:i>=5?C.bad:'#33475b'})});
 for(var dd=1;dd<=days;dd++){var p=start+dd-1,r=Math.floor(p/7),c=p%7,x=x0+c*cw,y=y0+r*rh,col=(hl&&hl[dd])||'#fff';var re=E('rect',{x:x+1,y:y,width:cw-2,height:rh-2,rx:3,fill:col,stroke:'#dde5ee'},g);T(g,x+cw/2,y+14,String(dd),{'font-size':11,'font-weight':600,fill:'#1d2b3a','pointer-events':'none'});
  if(onTap){re.style.cursor='pointer';(function(dd){re.addEventListener('click',function(){onTap(dd)})})(dd)}}return g}
// tanga/pul kupyurasi
function f3note(x,y,val,col){var g=E('g',{},S.g);E('rect',{x:x,y:y,width:64,height:30,rx:4,fill:col||'#d8eecf',stroke:'#4a7a3a','stroke-width':1.5},g);T(g,x+32,y+20,val,{'font-size':12,'font-weight':800,fill:'#2f5a22'});return g}
var CODE='3G5',TITLE='3-sinf · Ismli sonlar ustida amallar';
// ustunli yozuv: units — ustun nomlari, rows — [[..],[..]], op, res, o.carry {ustun:matn}, o.res
function g5col(title,units,rows,op,o){o=o||{};clear();var g=S.g,xs=units.map(function(u,i){return 200+i*80});T(g,14,18,title,{'font-size':12,'font-weight':800,'text-anchor':'start',fill:'#1d2b3a'});
 units.forEach(function(u,i){T(g,xs[i],42,u,{'font-size':12,'font-weight':800,fill:C.blue})});
 rows.forEach(function(r,j){r.forEach(function(v,i){T(g,xs[i],70+j*28,String(v),{'font-size':18,'font-weight':800,fill:'#1d2b3a'})})});T(g,140,84,op,{'font-size':20,'font-weight':800,fill:'#33475b'});
 E('line',{x1:150,y1:110,x2:xs[xs.length-1]+30,y2:110,stroke:'#33475b','stroke-width':2.5},g);
 if(o.carry)Object.keys(o.carry).forEach(function(i){T(g,xs[i]+22,54,o.carry[i],{'font-size':11,'font-weight':800,fill:C.bad})});
 if(o.cross)o.cross.forEach(function(i){E('line',{x1:xs[i]-16,y1:72,x2:xs[i]+16,y2:58,stroke:C.bad,'stroke-width':2},g)});
 if(o.res)o.res.forEach(function(v,i){T(g,xs[i],138,String(v),{'font-size':18,'font-weight':800,fill:C.ok})});if(o.note)T(g,180,164,o.note,{'font-size':11,'font-weight':700,fill:C.a})}
var G5P1=[function(){g5col('18 sm 7 mm + 24 sm 6 mm',['sm','mm'],[[18,7],[24,6]],'+');f3calc(['Bir xil birliklarni ustma-ust yozamiz'])},
 function(){g5col('18 sm 7 mm + 24 sm 6 mm',['sm','mm'],[[18,7],[24,6]],'+',{res:['','13'],note:'13 mm = 1 sm 3 mm — 10 mm dan oshdi!'});f3calc(['mm: 7 + 6 = 13 mm'])},
 function(){g5col('18 sm 7 mm + 24 sm 6 mm',['sm','mm'],[[18,7],[24,6]],'+',{carry:{0:'+1'},res:['43','3'],note:'1 sm ni sm ustuniga o‘tkazdik'});f3calc(['13 mm = 1 sm 3 mm; sm: 18 + 24 + 1 = 43','Javob: <b>43 sm 3 mm</b> (= 433 mm)'])}];
var G5P2=[function(){g5col('7 m 4 dm − 3 m 58 sm',['m','sm'],[[7,40],[3,58]],'−');f3calc(['Avval 4 dm = 40 sm. Endi 40 − 58 — yetmaydi!'])},
 function(){g5col('7 m 4 dm − 3 m 58 sm',['m','sm'],[[7,40],[3,58]],'−',{carry:{0:'6',1:'140'},cross:[0,1]});f3calc(['1 m ni «maydalaymiz»: 7 m 40 sm = 6 m 140 sm'])},
 function(){g5col('7 m 4 dm − 3 m 58 sm',['m','sm'],[[7,40],[3,58]],'−',{carry:{0:'6',1:'140'},cross:[0,1],res:['3','82']});f3calc(['sm: 140 − 58 = 82; m: 6 − 3 = 3','Javob: <b>3 m 82 sm</b>. Tekshirish: 740 − 358 = 382 sm ✓'])}];
var G5P4=[function(){g5col('5 soat 10 min − 2 soat 45 min',['soat','min'],[[5,10],[2,45]],'−');f3calc(['10 − 45 — yetmaydi. 1 soatni maydalaymiz…'])},
 function(){g5col('5 soat 10 min − 2 soat 45 min',['soat','min'],[[5,10],[2,45]],'−',{carry:{0:'4',1:'70'},cross:[0,1],res:['2','25'],note:'1 soat = 60 min (100 emas!): 10 + 60 = 70'});f3calc(['70 − 45 = 25; 4 − 2 = 2 → 2 soat 25 min'])},
 function(){g5col('2 soat 25 min + 35 min',['soat','min'],[[2,25],['',35]],'+',{carry:{0:'+1'},res:['3','0'],note:'60 min = 1 soat'});f3calc(['25 + 35 = 60 min = 1 soat','Javob: <b>3 soat</b>'])}];
function g5tape(st){clear();var g=S.g,x0=20,w=320,n=35;T(g,14,18,'5 m 60 sm tasma, har sovg‘aga 16 sm',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});E('rect',{x:x0,y:60,width:w,height:30,fill:'#f7d9e3',stroke:'#c0587e','stroke-width':2},g);
 if(st>=1){for(var i=1;i<n;i++)E('line',{x1:x0+i*w/n,y1:60,x2:x0+i*w/n,y2:90,stroke:'#c0587e','stroke-width':.8},g);Br(x0,x0+w/n,94,'16',false,C.a)}
 Br(x0,x0+w,56,st?'560 sm':'5 m 60 sm',true);if(st>=2)T(g,180,140,'560 : 16 = 35 ta sovg‘a',{'font-size':15,'font-weight':800,fill:C.ok})}
var G5P5=[function(){g5tape(0);f3calc(['Nechta sovg‘a bog‘lanadi? Avval bir xil birlik'])},function(){g5tape(1);f3calc(['5 m 60 sm = 500 + 60 = <b>560 sm</b>'])},function(){g5tape(2);f3calc(['560 : 16 = <b>35</b> (16 · 35 = 560 ✓)'])}];
function g5bar(st){clear();var g=S.g,k=0.13;T(g,14,18,'Pishloq 1 kg 400 g, sariyog‘ undan 350 g kam',{'font-size':11,'text-anchor':'start',fill:'#3a4a5a'});
 T(g,62,58,'pishloq',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:C.a});E('rect',{x:68,y:42,width:1400*k,height:24,fill:C.a,rx:3},g);T(g,68+1400*k/2,59,'1400 g',{'font-size':11,'font-weight':800,fill:'#fff'});
 T(g,62,98,'sariyog‘',{'font-size':11,'font-weight':800,'text-anchor':'end',fill:C.b});E('rect',{x:68,y:82,width:1050*k,height:24,fill:C.b,rx:3},g);E('rect',{x:68+1050*k,y:82,width:350*k,height:24,fill:'none',stroke:C.bad,'stroke-dasharray':'4 3'},g);T(g,68+1225*k,99,'−350',{'font-size':11,'font-weight':800,fill:C.bad});
 if(st>=1)T(g,68+525*k,99,'1050 g',{'font-size':11,'font-weight':800,fill:'#fff'});if(st>=2){Br(68,68+1400*k,112,'',false,C.line);T(g,180,152,'Jami: 1400 + 1050 = 2450 g = 2 kg 450 g',{'font-size':13,'font-weight':800,fill:C.ok})}}
var G5P7=[function(){g5bar(0);f3calc(['Ikki narsa: «undan kam» — avval sariyog‘ni topamiz'])},function(){g5bar(1);f3calc(['Sariyog‘: 1400 − 350 = <b>1050 g</b>'])},function(){g5bar(2);f3calc(['Hammasi: 1400 + 1050 = <b>2 kg 450 g</b>','Xato: 1 kg 400 g − 350 g = 1 kg 50 g ni javob qilish'])}];
var G5P8;
function g5expr(st){clear();var g=S.g,parts=[['(8 dm + 2 m 64 sm)',90,'344'],[': 4',190,'86'],['−',222,''],['35 sm · 2',275,'70']];T(g,180,22,'Amallar tartibi',{'font-size':11,fill:'#3a4a5a'});
 parts.forEach(function(p){T(g,p[1],70,p[0],{'font-size':14,'font-weight':800,fill:'#1d2b3a'})});
 if(st>=1){T(g,90,100,'344 sm',{'font-size':13,'font-weight':800,fill:C.a});T(g,90,46,'1',{'font-size':12,'font-weight':800,fill:C.bad})}
 if(st>=1){T(g,190,100,'86 sm',{'font-size':13,'font-weight':800,fill:C.b});T(g,190,46,'2',{'font-size':12,'font-weight':800,fill:C.bad});T(g,275,100,'70 sm',{'font-size':13,'font-weight':800,fill:C.blue});T(g,275,46,'3',{'font-size':12,'font-weight':800,fill:C.bad})}
 if(st>=2){T(g,222,46,'4',{'font-size':12,'font-weight':800,fill:C.bad});T(g,180,140,'86 − 70 = 16 sm',{'font-size':17,'font-weight':800,fill:C.ok})}}
G5P8=[function(){g5expr(0);f3calc(['Hammasini sm ga: 8 dm = 80 sm, 2 m 64 sm = 264 sm'])},function(){g5expr(1);f3calc(['1) qavs: 80 + 264 = 344','2) 344 : 4 = 86;  3) 35 · 2 = 70'])},function(){g5expr(2);f3calc(['4) 86 − 70 = <b>16 sm</b>','Tartib: qavs → ko‘paytirish/bo‘lish → ayirish'])}];
function g5pick(okI,msgs,fin){return msgs.map(function(m,i){return [m[0],function(c,done){if(i===okI){fin();f3msg('✓ '+m[1]);done()}else f3msg('<span style="color:#c0392b">✗</span> '+m[1])}]})}
function g5kg(st){g5col('4 kg 300 g − 1 kg 750 g',['kg','g'],[[4,300],[1,750]],'−',st?{carry:{0:'3',1:'1300'},cross:[0,1],res:['2','550'],note:'1 kg = 1000 g: 300 + 1000 = 1300'}:{})}
function g5rib(st){clear();var g=S.g,k=1.45,x0=30;E('rect',{x:x0,y:60,width:207*k,height:26,fill:'#cfe6f7',stroke:C.blue,'stroke-width':2},g);Br(x0,x0+207*k,56,st?'207 sm':'2 m 7 sm',true);
 if(st){E('rect',{x:x0+122*k,y:60,width:85*k,height:26,fill:'#ffd6d0',stroke:C.bad},g);T(g,x0+164*k,78,'85 sm',{'font-size':12,'font-weight':800,fill:C.bad});Br(x0,x0+122*k,90,'122 sm qoldi',false,C.ok)}}
var STEPS=[
{h:"Qo'shish: birlikdan o'tish",sum:"18 sm 7 mm + 24 sm 6 mm: 13 mm = 1 sm 3 mm → 43 sm 3 mm.",a:"m01",
 start:function(){startPh(G5P1)},fin:function(){S.ph=2;G5P1[2]()},
 html:"<p><b>Ismli son</b> — birlik nomi bilan yozilgan son: 18 sm 7 mm, 3 kg 200 g, 2 soat 15 min. Ular ustida amal xuddi xonalar bilan ishlagandek:</p>",btns:[phaser(G5P1)],
 after:"<p>Kichik birlik «to'lsa» (10 mm, 100 sm, 1000 g, 60 min) — uni <b>katta birlikka o'tkazamiz</b>. Xuddi o'nlikdan o'tib qo'shish kabi.</p>",
 q:{t:"2 m 5 sm + 85 sm = ?",opts:["2 m 90 sm","3 m 90 sm","2 m 80 sm","3 m 30 sm"],ok:0,why:"5 + 85 = 90 sm, 100 ga yetmadi.",hint:"Santimetrlarni qo'shing: 100 dan oshdimi?",full:"5 sm + 85 sm = 90 sm — 1 m (100 sm) ga yetmaydi. Javob 2 m 90 sm. «3 m 30 sm» — 2 m 5 sm ni 2 m 50 sm deb o'qish xatosi."},
 tn:"Ustunli yozuvni doskada katakli jadvalda ko'rsating: har ustun — bitta birlik."},
{h:"Ayirish: katta birlikni maydalash",sum:"7 m 40 sm − 3 m 58 sm: 1 m ni 100 sm ga maydalaymiz → 6 m 140 sm − 3 m 58 sm = 3 m 82 sm.",a:"m02",
 start:function(){startPh(G5P2)},fin:function(){S.ph=2;G5P2[2]()},
 html:"<p><i>7 m 4 dm − 3 m 58 sm = ?</i> Kichik birlik yetmasa, katta birlikdan <b>qarz</b> olamiz:</p>",btns:[phaser(G5P2)],
 after:"<p>Ikki usul: 1) qarz olish (1 m = 100 sm); 2) hammasini bir birlikka: 740 sm − 358 sm = 382 sm = <b>3 m 82 sm</b>. Ikkinchisi xatoga kamroq yo'l qo'yadi.</p>",
 q:{t:"52 m 35 sm − 27 m 80 sm = ? sm",opts:["2455","2545","2555","2445"],ok:0,why:"5235 − 2780 = 2455.",hint:"35 sm dan 80 sm ayirib bo'lmaydi — 1 m qarz oling.",full:"51 m 135 sm − 27 m 80 sm = 24 m 55 sm = 2455 sm. «2545» — 80 − 35 ni teskari ayirish xatosi."},
 tn:"Yaponiya usuli: «maydalash»ni haqiqiy lentada ko'rsating — 1 metrlik bo'lakni santimetrli bo'laklarga «almashtiramiz»."},
{h:"Massa: 1 kg = 1000 g",sum:"4 kg 300 g − 1 kg 750 g = 3 kg 1300 g − 1 kg 750 g = 2 kg 550 g.",a:"m03",
 start:function(){g5kg(0);f3calc(['300 g dan 750 g ayirib bo‘lmaydi. Javobni tanlang'])},fin:function(){g5kg(1);f3msg('<b>2 kg 550 g</b>')},
 html:"<p><i>4 kg 300 g − 1 kg 750 g = ?</i> To'g'ri javobni tanlang — xato variantlar bolalarning odatiy xatolari:</p>",
 btns:g5pick(1,[["3 kg 450 g","Bu — «kattadan kichigini» ayirish: 750 − 300. Yuqoridan pastni ayirish kerak!"],["2 kg 550 g","1 kg = 1000 g: 1300 − 750 = 550; 3 − 1 = 2."],["3 kg 550 g","550 to‘g‘ri, lekin qarz olingan 1 kg ni kilogrammlardan ayirishni unutdingiz."],["2 kg 450 g","1 kg ni 1000 g emas, 900 g deb oldingizmi? 1300 − 750 = 550."]],function(){g5kg(1)}),g2:1,
 after:"<p>Massada qarz <b>1000 g</b>, uzunlikda (m → sm) <b>100 sm</b>, vaqtda <b>60 min</b>. Har birlikning o'z «o'tish soni» bor!</p>",
 q:{t:"Olma solingan yashik 24 kg 300 g, bo'sh yashik 2 kg 750 g. Olmaning o'zi?",opts:["21 kg 550 g","22 kg 550 g","27 kg 50 g","21 kg 650 g"],ok:0,why:"24 300 − 2 750 = 21 550 g.",hint:"300 g dan 750 g ayirib bo'lmaydi — 1 kg qarz oling.",full:"23 kg 1300 g − 2 kg 750 g = 21 kg 550 g. «22 kg 550 g» — qarz olingan 1 kg ni ayirishni unutish, «27 kg 50 g» — qo'shib yuborish."},
 tn:"Xato variantlarni muhokama qiling: «Bu bola qayerda adashdi?» — bolalarni o'qituvchi rolida qo'ying."},
{h:"Vaqt: qarz 60 minut",sum:"5 soat 10 min − 2 soat 45 min = 2 soat 25 min; + 35 min = 3 soat.",a:"m04",
 start:function(){startPh(G5P4)},fin:function(){S.ph=2;G5P4[2]()},
 html:"<p><i>5 soat 10 min − 2 soat 45 min + 35 min = ?</i> Vaqtda qarz — <b>60 minut</b>!</p>",btns:[phaser(G5P4)],
 after:"<p>Ko'p bola 1 soatni 100 minut deb oladi va 110 − 45 = 65 ni yozadi. Vaqtda: 1 soat = 60 min, 10 + 60 = <b>70</b>.</p>",
 q:{t:"3 soat 20 min − 1 soat 40 min = ?",opts:["1 soat 40 min","2 soat 20 min","1 soat 80 min","2 soat 40 min"],ok:0,why:"2 soat 80 min − 1 soat 40 min = 1 soat 40 min.",hint:"20 min dan 40 min ayirib bo'lmaydi — 1 soatni 60 minutga maydalang.",full:"3 soat 20 min = 2 soat 80 min. 80 − 40 = 40, 2 − 1 = 1. Javob 1 soat 40 min. «2 soat 20 min» — 40 − 20 ni teskari ayirish va qarzni unutish."},
 tn:"Soat modelida ko'rsating: 1 soat — katta mil bir to'liq aylanadi (60 min)."},
{h:"Ismli sonni songa bo'lish",sum:"5 m 60 sm = 560 sm; 560 : 16 = 35 ta sovg'a.",a:"m05",
 start:function(){startPh(G5P5)},fin:function(){S.ph=2;G5P5[2]()},
 html:"<p><i>«5 m 60 sm tasma olindi. Har bir sovg'aga 16 sm sarflansa, nechta sovg'a bog'lanadi?»</i></p>",btns:[phaser(G5P5)],
 after:"<p>Ko'paytirish va bo'lishda ham avval <b>bitta birlikka</b> o'tamiz. 5 m 60 sm ni 56 yoki 5060 deb o'qisak — xato chiqadi.</p>",
 q:{t:"Bobur qadami 45 sm. 9 m yo'lakni qadamlab o'lchadi. Necha qadam?",opts:["20","200","18","22"],ok:0,why:"900 : 45 = 20.",hint:"9 m = ? sm.",full:"9 m = 900 sm; 900 : 45 = 20 qadam. «200» — 9 m ni 9000 sm deb olish (1 m = 1000 mm, sm emas)."},
 tn:"Bolalar o'z qadamini o'lchab, sinf uzunligini qadam bilan hisoblasin."},
{h:"Tuzoq: «2 m 7 sm» qanday o'qiladi",sum:"2 m 7 sm = 207 sm (270 emas!); 207 − 85 = 122 sm.",a:"m06",
 start:function(){g5rib(0);f3calc(['Lenta 2 m 7 sm edi, 85 sm qirqildi. Qoldi?'])},fin:function(){g5rib(1);f3msg('207 − 85 = <b>122 sm</b>')},
 html:"<p><i>«Lenta 2 m 7 sm edi. Undan 85 sm qirqib olindi. Necha santimetr qoldi?»</i> Javobni tanlang:</p>",
 btns:g5pick(0,[["122 sm","2 m 7 sm = 207 sm; 207 − 85 = 122."],["185 sm","Bu 2 m 70 sm − 85 sm. Lekin 7 sm — 70 emas!"],["132 sm","207 − 85 ni qayta hisoblang: 207 − 80 = 127, 127 − 5 = 122."],["22 sm","Bu — 107 − 85. 2 m = 200 sm, 100 emas."]],function(){g5rib(1)}),g2:1,
 after:"<p>«2 m 7 sm» — o'nliklar xonasi bo'sh: <b>2 | 0 | 7</b> = 207. Bo'sh xonaga 0 — eng ko'p uchraydigan xato.</p>",
 q:{t:"Lenta 3 m 6 sm edi. 85 sm qirqildi. Qoldi?",opts:["221 sm","275 sm","391 sm","215 sm"],ok:0,why:"306 − 85 = 221.",hint:"3 m 6 sm necha santimetr?",full:"3 m 6 sm = 306 sm; 306 − 85 = 221 sm. «275» — 360 − 85 (6 sm ni 60 deb o'qish), «391» — qo'shib yuborish."},
 tn:"Bank misollaridan (#1399, #1404) olingan tur. Doskada m | dm | sm jadvalini chizing."},
{h:"Tuzoq: «undan ... kam» va jami",sum:"Pishloq 1 kg 400 g, sariyog' 350 g kam = 1050 g; jami 2 kg 450 g.",a:"m07",
 start:function(){startPh(G5P7)},fin:function(){S.ph=2;G5P7[2]()},
 html:"<p><i>«1 kg 400 g pishloq va undan 350 g kam sariyog' olindi. Hammasi bo'lib qancha mahsulot?»</i></p>",btns:[phaser(G5P7)],
 after:"<p>Ikki bosqich: 1) «undan kam» — sariyog'ni topamiz; 2) «hammasi» — qo'shamiz. Chizma (Singapur bar modeli) ikkala bosqichni ko'rsatadi.</p>",
 q:{t:"Birinchi arqon 24 m 7 dm. Ikkinchisi undan 8 m 5 dm uzun. Ikkalasi birgalikda?",opts:["57 m 9 dm","33 m 2 dm","57 m 2 dm","58 m 9 dm"],ok:0,why:"Ikkinchisi 33 m 2 dm; 24 m 7 dm + 33 m 2 dm = 57 m 9 dm.",hint:"Avval ikkinchi arqonni toping.",full:"Ikkinchi: 24 m 7 dm + 8 m 5 dm = 32 m 12 dm = 33 m 2 dm. Jami: 24 m 7 dm + 33 m 2 dm = 57 m 9 dm. «33 m 2 dm» — faqat ikkinchi arqon."},
 tn:"Har ko'p bosqichli masalada «savolga qaytish» odatini shakllantiring: «Nimani so'rayapti?»"},
{h:"Tuzoq: amallar tartibi",sum:"(8 dm + 2 m 64 sm) : 4 − 35 sm · 2 = 344 : 4 − 70 = 86 − 70 = 16 sm.",a:"m08",
 start:function(){startPh(G5P8)},fin:function(){S.ph=2;G5P8[2]()},
 html:"<p><i>Hisoblang va javobni santimetrda yozing: (8 dm + 2 m 64 sm) : 4 − 35 sm · 2</i></p>",btns:[phaser(G5P8)],
 after:"<p>Ikki qoida birga: <b>birliklarni bir xil qilish</b> va <b>amallar tartibi</b> (qavs → ko'paytirish/bo'lish → qo'shish/ayirish). 86 − 35 · 2 ni chapdan o'ngga hisoblasak (51 · 2 = 102) — xato!</p>",
 q:{t:"8 dm + 26 sm − 350 mm = ? sm",opts:["71","106","81","76"],ok:0,why:"80 + 26 − 35 = 71.",hint:"350 mm necha santimetr?",full:"8 dm = 80 sm, 350 mm = 35 sm. 80 + 26 − 35 = 71 sm. «106» — 350 mm ni ayirishni unutish, «81» — 350 mm ni 25 sm deb olish."},
 tn:"Amallar tartibini raqamlar bilan belgilash (1, 2, 3, 4) — doskada har ifodada."},
{h:"Bilasizmi? O'nlik vaqt",sum:"1793-yilda Fransiyada sutkani 10 soatga bo'lishga urinishgan, lekin odamlar ko'nikmagani uchun tez orada bekor qilingan.",a:"m09",
 start:function(){clear();f3clock(180,86,70,10,10);f3msg('1 sutka = 24 soat, 1 soat = 60 min — o‘nlik emas')},fin:function(){STEPS[8].start()},
 html:"<p>⏰ Fransiyada 1793-yilda metr bilan bir qatorda <b>o'nlik vaqt</b> ham joriy qilingan: sutka <b>10 soatga</b>, soat <b>100 minutga</b> bo'lingan. Lekin odamlar eski soatlarga o'rganib qolgani uchun, bu tizim tez orada bekor qilingan.</p><p>Shuning uchun bugun ham uzunlik va massa o'nlik (10, 100, 1000), vaqt esa <b>24 va 60</b> bilan o'lchanadi — ismli sonlarda shunga e'tibor bering!</p>",
 tn:"Bolalardan so'rang: agar soatda 100 minut bo'lganda, vaqtni hisoblash osonroq bo'larmidi?"},
{h:"Eslatma kartochka",sum:"",a:"m10",memo:1,start:function(){S.ph=2;G5P2[2]()},fin:function(){S.ph=2;G5P2[2]()},
 html:"<div class='memo'><ul><li>Bir xil birliklarni ustma-ust yozamiz.</li><li>«O'tish sonlari»: <b>10 mm = 1 sm</b>, <b>100 sm = 1 m</b>, <b>1000 m = 1 km</b>, <b>1000 g = 1 kg</b>, <b>60 min = 1 soat</b>.</li><li>Qo'shishda to'lsa — katta birlikka o'tkazamiz; ayirishda yetmasa — katta birlikdan qarz.</li><li>Ko'paytirish/bo'lishdan oldin — <b>bitta birlikka</b>.</li><li>2 m 7 sm = <b>207</b> sm (bo'sh xonaga 0).</li><li>Amallar tartibi: qavs → · va : → + va −.</li></ul></div>",
 tn:"Kartochkani daftarga ko'chirtiring."}
];
var PROBS=[
{t:"2 m 5 sm + 85 sm = ?",o:["2 m 90 sm","3 m 90 sm","2 m 80 sm","3 m 30 sm"],k:0,s:"5 + 85 = 90."},
{t:"18 sm 7 mm + 24 sm 6 mm = ? mm",o:["433","423","453","443"],k:0,s:"43 sm 3 mm."},
{t:"2 m 5 dm 7 sm + 3 m 6 dm 8 sm = ? sm",o:["625","615","525","635"],k:0,s:"257 + 368."},
{t:"7 m 4 dm − 3 m 58 sm = ?",o:["3 m 82 sm","4 m 46 sm","3 m 92 sm","3 m 46 sm"],k:0,s:"740 − 358 = 382 sm."},
{t:"4 kg 300 g − 1 kg 750 g = ?",o:["2 kg 550 g","3 kg 450 g","2 kg 650 g","3 kg 550 g"],k:0,s:"4300 − 1750 = 2550."},
{t:"5 soat 10 min − 2 soat 45 min + 35 min = ?",o:["3 soat","2 soat 50 min","2 soat 25 min","3 soat 10 min"],k:0,s:"2 s 25 min + 35 min."},
{t:"Lenta 2 m 7 sm edi, 85 sm qirqildi. Necha sm qoldi?",o:["122","185","132","22"],k:0,s:"207 − 85."},
{t:"Lenta 3 m 40 sm edi, 85 sm kesildi. Qoldi?",o:["255 sm","355 sm","265 sm","55 sm"],k:0,s:"340 − 85."},
{t:"Opa bo'yi 1 m 84 sm, ukasi 96 sm. Opa necha sm baland?",o:["88 sm","1 m 12 sm","98 sm","78 sm"],k:0,s:"184 − 96."},
{t:"Halqa 3 m 5 sm balandlikda, bola bo'yi 1 m 38 sm. Halqa boshidan necha sm baland?",o:["167 sm","233 sm","177 sm","443 sm"],k:0,s:"305 − 138."},
{t:"Onam 4 kg 75 g go'sht va 2 kg 950 g sabzi oldi. Hammasi necha gramm?",o:["7025","6025","7700","7125"],k:0,s:"4075 + 2950."},
{t:"5 m 60 sm tasmadan har sovg'aga 16 sm. Nechta sovg'a?",o:["35","30","45","36"],k:0,s:"560 : 16."},
{t:"1 kg 400 g pishloq va undan 350 g kam sariyog' olindi. Hammasi?",o:["2 kg 450 g","1 kg 750 g","3 kg 150 g","2 kg 550 g"],k:0,s:"1400 + 1050."},
{t:"Sayyohlar 1-kuni 6 km 800 m, 2-kuni 1 km 500 m kam yurdi. Ikki kunda?",o:["12 km 100 m","15 km 100 m","11 km 100 m","5 km 300 m"],k:0,s:"6800 + 5300."},
{t:"1-kuni 5 m 65 sm sim, 2-kuni 2 m 80 sm ko'p sim keltirildi. Jami?",o:["14 m 10 sm","13 m 10 sm","8 m 45 sm","14 m 45 sm"],k:0,s:"565 + 845 = 1410 sm."},
{t:"(8 dm + 2 m 64 sm) : 4 − 35 sm · 2 = ? sm",o:["16","6","26","172"],k:0,s:"86 − 70."},
{t:"8 dm + 26 sm − 350 mm = ? sm",o:["71","106","81","76"],k:0,s:"80 + 26 − 35."},
{t:"Jirafa 5 m 2 sm. Zebra undan 3 m 48 sm past, ot zebradan 18 sm baland. Ot necha sm?",o:["172","154","136","868"],k:0,s:"502 − 348 = 154, + 18."},
{t:"3 m 4 dm 2 sm − 1 m 7 dm 5 sm = ? sm",o:["167","177","157","233"],k:0,s:"342 − 175."},
{t:"3 soat 20 min − 1 soat 40 min = ?",o:["1 soat 40 min","2 soat 20 min","1 soat 80 min","2 soat 40 min"],k:0,s:"200 − 100 = 100 min."}
];
function PRACT_STAGE(){S.ph=2;G5P2[2]()}
var PREP_DATA={teach:["Ismli sonlarni ustunda qo'shish (birlikdan o'tish).","Ayirishda katta birlikni maydalash (qarz olish): 100 sm, 1000 g, 60 min.","Ismli sonni songa ko'paytirish/bo'lish — bitta birlikka o'tib.","Tuzoqlar: 2 m 7 sm = 207 sm; «undan kam» va jami; amallar tartibi."],
 mist:["Vaqtda 1 soatni 100 minut deb qarz oladi.","Ustunda «kattadan kichigini» ayiradi: 750 − 300.","2 m 7 sm ni 270 sm deb o'qiydi.","Qarz olingan birlikni katta ustundan ayirishni unutadi."],
 need:["Metrli tasma, tarozi, karton soat.","Ustunli yozuv uchun katakli jadval kartochkalari."],
 board:["<span class='w2'>18 sm 7 mm + 24 sm 6 mm = 43 sm 3 mm</span>.","<span class='w2'>7 m 40 sm = 6 m 140 sm</span> (qarz).","<span class='w2'>4 kg 300 g = 3 kg 1300 g</span>.","<span class='w2'>5 soat 10 min = 4 soat 70 min</span>."]};
